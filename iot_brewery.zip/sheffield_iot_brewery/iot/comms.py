"""Simulated MQTT / IoT messaging layer.

:class:`SimulatedBroker` gives the whole platform an in-process
publish/subscribe message bus that behaves like an MQTT broker
(topic hierarchies, ``+``/``#`` wildcards) with zero external
dependencies — this is what SIMULATION and HYBRID mode run against.

:class:`MQTTBridge` is the deployment-time extension point: when
``paho-mqtt`` is installed and a broker address is supplied it forwards
the exact same publish/subscribe calls to a real MQTT broker, so a
plant can go from "simulated messaging" to "real IoT messaging" by
swapping this one object.
"""
from __future__ import annotations

from typing import Any, Callable, Optional

from sheffield_iot_brewery.core.event_bus import Event, EventBus


class SimulatedBroker:
    """An in-process message broker built on the internal event bus."""

    def __init__(self) -> None:
        self._bus = EventBus()
        self.sent_count = 0

    def publish(self, topic: str, payload: Any = None, source: str = "iot") -> Event:
        self.sent_count += 1
        return self._bus.publish(topic, payload, source=source)

    def subscribe(self, topic_pattern: str, callback: Callable[[Event], None]) -> None:
        self._bus.subscribe(topic_pattern, callback)

    def history(self, topic_pattern: str = "#"):
        return self._bus.history(topic_pattern)


class MQTTBridge:
    """Optional bridge to a real MQTT broker via ``paho-mqtt``.

    Falls back to a :class:`SimulatedBroker` transparently if the
    dependency is missing or no ``host`` is configured, so application
    code can always talk to a single object regardless of deployment
    mode ("the same system that simulates the plant can run it").
    """

    def __init__(self, host: Optional[str] = None, port: int = 1883,
                 client_id: str = "sheffield-brewery"):
        self.host = host
        self.port = port
        self.client_id = client_id
        self._simulated = SimulatedBroker()
        self._client = None
        if host:
            self._try_connect_real_broker()

    def _try_connect_real_broker(self) -> None:
        try:
            import paho.mqtt.client as mqtt  # type: ignore
        except ImportError:
            # No real MQTT stack available - stay in simulated mode.
            self._client = None
            return
        client = mqtt.Client(client_id=self.client_id)
        client.connect(self.host, self.port)
        client.loop_start()
        self._client = client

    @property
    def is_live(self) -> bool:
        return self._client is not None

    def publish(self, topic: str, payload: Any = None, source: str = "iot") -> None:
        if self._client is not None:
            self._client.publish(topic, str(payload))
        self._simulated.publish(topic, payload, source=source)

    def subscribe(self, topic_pattern: str, callback: Callable[[Event], None]) -> None:
        # Simulated bus always receives the subscription so in-process
        # automation logic keeps working regardless of live/sim mode.
        self._simulated.subscribe(topic_pattern, callback)
        if self._client is not None:
            def _on_message(_client, _userdata, msg):
                callback(Event(topic=msg.topic, payload=msg.payload, source="mqtt"))
            self._client.on_message = _on_message
            self._client.subscribe(topic_pattern.replace("#", "#").replace("+", "+"))

    def disconnect(self) -> None:
        if self._client is not None:
            self._client.loop_stop()
            self._client.disconnect()
            self._client = None
