"""Sensor abstraction layer.

Every physical measurement point in the plant — real or simulated —
is exposed through this uniform interface: ``read()``, ``status()``.
Sensors wrap :mod:`plant.equipment` objects; in LIVE mode a
:class:`integration.hardware_interface.HardwareInterface` implementation
would refresh the underlying equipment values from real field devices
before ``read()`` is called.
"""
from __future__ import annotations

import random
import time
from abc import ABC, abstractmethod
from enum import Enum
from typing import Any, Dict, Optional

from sheffield_iot_brewery.plant.equipment import Tank


class SensorType(str, Enum):
    LEVEL = "level"
    TEMPERATURE = "temperature"
    PRESSURE = "pressure"
    FLOW = "flow"


class Sensor(ABC):
    """Base class for all IoT sensor nodes."""

    def __init__(self, device_id: str, name: str, sensor_type: SensorType, unit: str,
                 noise_std: float = 0.0, min_value: Optional[float] = None):
        self.device_id = device_id
        self.name = name
        self.sensor_type = sensor_type
        self.unit = unit
        self.noise_std = noise_std
        self.min_value = min_value
        self._last_value: Optional[float] = None
        self._last_read_at: Optional[float] = None
        self.fault = False

    def _apply_noise(self, value: float) -> float:
        if self.noise_std:
            value += random.gauss(0.0, self.noise_std)
        if self.min_value is not None:
            value = max(self.min_value, value)
        return value

    def read(self) -> float:
        value = self._apply_noise(self._raw_value())
        self._last_value = value
        self._last_read_at = time.time()
        return value

    @abstractmethod
    def _raw_value(self) -> float:
        ...

    def status(self) -> Dict[str, Any]:
        return {
            "device_id": self.device_id,
            "name": self.name,
            "type": self.sensor_type.value,
            "unit": self.unit,
            "last_value": self._last_value,
            "last_read_at": self._last_read_at,
            "fault": self.fault,
        }


class TankLevelSensor(Sensor):
    def __init__(self, device_id: str, tank: Tank, noise_std: float = 0.0):
        super().__init__(device_id, f"{tank.name} Level", SensorType.LEVEL, "L", noise_std,
                          min_value=0.0)
        self.tank = tank

    def _raw_value(self) -> float:
        return self.tank.level_l


class TankTemperatureSensor(Sensor):
    def __init__(self, device_id: str, tank: Tank, noise_std: float = 0.0):
        super().__init__(device_id, f"{tank.name} Temperature", SensorType.TEMPERATURE, "C",
                          noise_std)
        self.tank = tank

    def _raw_value(self) -> float:
        return self.tank.temperature_c


class TankPressureSensor(Sensor):
    """Synthetic hydrostatic pressure abstraction based on fill fraction.

    Not a chemically accurate model — a linear proxy (0-2 bar over an
    empty-to-full tank) good enough for level-redundancy and overflow
    cross-checks in the automation layer.
    """

    def __init__(self, device_id: str, tank: Tank, noise_std: float = 0.0,
                 max_bar_at_full: float = 2.0):
        super().__init__(device_id, f"{tank.name} Pressure", SensorType.PRESSURE, "bar",
                          noise_std, min_value=0.0)
        self.tank = tank
        self.max_bar_at_full = max_bar_at_full

    def _raw_value(self) -> float:
        return self.tank.fill_fraction * self.max_bar_at_full


class FlowSensor(Sensor):
    """Wraps a Pump or Valve and reports its current flow rate."""

    def __init__(self, device_id: str, carrier, noise_std: float = 0.0):
        name = f"{carrier.name} Flow"
        super().__init__(device_id, name, SensorType.FLOW, "L/min", noise_std, min_value=0.0)
        self.carrier = carrier

    def _raw_value(self) -> float:
        return self.carrier.flow_lpm()
