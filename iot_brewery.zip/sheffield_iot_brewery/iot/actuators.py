"""Device control interfaces (actuators).

Uniform ``write(value)`` / ``status()`` surface over pumps, valves,
heaters and coolers so the automation and control layers never need to
know equipment-specific details.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from enum import Enum
from typing import Any, Dict

from sheffield_iot_brewery.plant.equipment import Cooler, Heater, Pump, Valve
from sheffield_iot_brewery.utils.math_utils import clamp


class ActuatorType(str, Enum):
    PUMP = "pump"
    VALVE = "valve"
    HEATER = "heater"
    COOLER = "cooler"


class Actuator(ABC):
    def __init__(self, device_id: str, name: str, actuator_type: ActuatorType):
        self.device_id = device_id
        self.name = name
        self.actuator_type = actuator_type
        self.fault = False
        self._last_command: Any = None

    @abstractmethod
    def write(self, value: float) -> None:
        ...

    @abstractmethod
    def _current_value(self) -> float:
        ...

    def status(self) -> Dict[str, Any]:
        return {
            "device_id": self.device_id,
            "name": self.name,
            "type": self.actuator_type.value,
            "value": self._current_value(),
            "last_command": self._last_command,
            "fault": self.fault,
        }


class PumpActuator(Actuator):
    """write(value): 0 stops the pump; >0 sets speed percent and starts it."""

    def __init__(self, device_id: str, pump: Pump):
        super().__init__(device_id, f"{pump.name} Actuator", ActuatorType.PUMP)
        self.pump = pump

    def write(self, value: float) -> None:
        if self.fault:
            return
        speed = clamp(value, 0.0, 100.0)
        self._last_command = speed
        self.pump.speed_pct = speed
        self.pump.running = speed > 0.0

    def _current_value(self) -> float:
        return self.pump.speed_pct if self.pump.running else 0.0


class ValveActuator(Actuator):
    """write(value): open percentage 0-100."""

    def __init__(self, device_id: str, valve: Valve):
        super().__init__(device_id, f"{valve.name} Actuator", ActuatorType.VALVE)
        self.valve = valve

    def write(self, value: float) -> None:
        if self.fault:
            return
        self._last_command = clamp(value, 0.0, 100.0)
        self.valve.open_pct = self._last_command

    def _current_value(self) -> float:
        return self.valve.open_pct


class HeaterActuator(Actuator):
    """write(value): duty cycle percentage 0-100."""

    def __init__(self, device_id: str, heater: Heater):
        super().__init__(device_id, f"{heater.name} Actuator", ActuatorType.HEATER)
        self.heater = heater

    def write(self, value: float) -> None:
        if self.fault or not self.heater.enabled:
            self.heater.duty_cycle_pct = 0.0
            self._last_command = 0.0
            return
        self._last_command = clamp(value, 0.0, 100.0)
        self.heater.duty_cycle_pct = self._last_command

    def _current_value(self) -> float:
        return self.heater.duty_cycle_pct


class CoolerActuator(Actuator):
    """write(value): duty cycle percentage 0-100."""

    def __init__(self, device_id: str, cooler: Cooler):
        super().__init__(device_id, f"{cooler.name} Actuator", ActuatorType.COOLER)
        self.cooler = cooler

    def write(self, value: float) -> None:
        if self.fault or not self.cooler.enabled:
            self.cooler.duty_cycle_pct = 0.0
            self._last_command = 0.0
            return
        self._last_command = clamp(value, 0.0, 100.0)
        self.cooler.duty_cycle_pct = self._last_command

    def _current_value(self) -> float:
        return self.cooler.duty_cycle_pct
