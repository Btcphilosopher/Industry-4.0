"""IoT device mapping system.

Auto-discovers every sensor/actuator implied by a :class:`BreweryModel`
and registers them under stable device ids, so the control loop, the
protocol adapter and the deployment engine all share one source of
truth for "what devices exist and what are they called".
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterator, Optional

from sheffield_iot_brewery.iot.actuators import (Actuator, CoolerActuator, HeaterActuator,
                                                  PumpActuator, ValveActuator)
from sheffield_iot_brewery.iot.sensors import (FlowSensor, Sensor, TankLevelSensor,
                                                TankPressureSensor, TankTemperatureSensor)
from sheffield_iot_brewery.plant.brewery_model import BreweryModel


@dataclass
class DeviceRegistry:
    sensors: Dict[str, Sensor] = field(default_factory=dict)
    actuators: Dict[str, Actuator] = field(default_factory=dict)
    # device_id -> owning equipment id, useful for protocol/deployment mapping
    equipment_of: Dict[str, str] = field(default_factory=dict)

    def register_sensor(self, sensor: Sensor, equipment_id: str) -> None:
        self.sensors[sensor.device_id] = sensor
        self.equipment_of[sensor.device_id] = equipment_id

    def register_actuator(self, actuator: Actuator, equipment_id: str) -> None:
        self.actuators[actuator.device_id] = actuator
        self.equipment_of[actuator.device_id] = equipment_id

    def get_sensor(self, device_id: str) -> Optional[Sensor]:
        return self.sensors.get(device_id)

    def get_actuator(self, device_id: str) -> Optional[Actuator]:
        return self.actuators.get(device_id)

    def all_devices(self) -> Iterator[str]:
        yield from self.sensors.keys()
        yield from self.actuators.keys()

    def read_all(self) -> Dict[str, float]:
        return {device_id: sensor.read() for device_id, sensor in self.sensors.items()}

    def actuator_states(self) -> Dict[str, float]:
        return {device_id: actuator.status()["value"] for device_id, actuator in
                self.actuators.items()}

    @classmethod
    def from_plant(cls, plant: BreweryModel, sensor_noise_std: float = 0.0) -> "DeviceRegistry":
        registry = cls()

        for tank in plant.tanks.values():
            level = TankLevelSensor(f"{tank.id}:level", tank, noise_std=sensor_noise_std)
            temp = TankTemperatureSensor(f"{tank.id}:temperature", tank, noise_std=sensor_noise_std)
            pressure = TankPressureSensor(f"{tank.id}:pressure", tank, noise_std=sensor_noise_std)
            registry.register_sensor(level, tank.id)
            registry.register_sensor(temp, tank.id)
            registry.register_sensor(pressure, tank.id)

        for pump in plant.pumps.values():
            flow = FlowSensor(f"{pump.id}:flow", pump, noise_std=sensor_noise_std)
            registry.register_sensor(flow, pump.id)
            actuator = PumpActuator(f"{pump.id}:cmd", pump)
            registry.register_actuator(actuator, pump.id)

        for valve in plant.valves.values():
            flow = FlowSensor(f"{valve.id}:flow", valve, noise_std=sensor_noise_std)
            registry.register_sensor(flow, valve.id)
            actuator = ValveActuator(f"{valve.id}:cmd", valve)
            registry.register_actuator(actuator, valve.id)

        for heater in plant.heaters.values():
            actuator = HeaterActuator(f"{heater.id}:cmd", heater)
            registry.register_actuator(actuator, heater.id)

        for cooler in plant.coolers.values():
            actuator = CoolerActuator(f"{cooler.id}:cmd", cooler)
            registry.register_actuator(actuator, cooler.id)

        return registry
