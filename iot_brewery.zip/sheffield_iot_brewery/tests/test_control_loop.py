from sheffield_iot_brewery.core.control_loop import ControlLoop
from sheffield_iot_brewery.core.event_bus import EventBus
from sheffield_iot_brewery.core.state_manager import StateManager
from sheffield_iot_brewery.iot.device_registry import DeviceRegistry
from sheffield_iot_brewery.monitoring.telemetry import TelemetryCollector
from sheffield_iot_brewery.replication.factory_blueprint import (SHEFFIELD_BLUEPRINT, build_plant,
                                                                   configure_default_automation)
from sheffield_iot_brewery.simulation.plant_simulator import PlantSimulator
from sheffield_iot_brewery.simulation.timestep_engine import TimestepEngine
from sheffield_iot_brewery.utils.config import OperatingMode


def _build_loop(ticks_dt=1.0):
    plant = build_plant(SHEFFIELD_BLUEPRINT)
    registry = DeviceRegistry.from_plant(plant)
    rules, pid_manager, safety = configure_default_automation(plant, registry, SHEFFIELD_BLUEPRINT)
    bus = EventBus()
    state = StateManager()
    telemetry = TelemetryCollector(window=200)
    simulator = PlantSimulator(plant)
    timestep = TimestepEngine(dt_seconds=ticks_dt, seed=1)

    loop = ControlLoop(device_registry=registry, rules_engine=rules, pid_manager=pid_manager,
                        safety_system=safety, state=state, bus=bus, telemetry=telemetry,
                        simulator=simulator, timestep=timestep, mode=OperatingMode.SIMULATION)
    return plant, loop


def test_control_loop_runs_without_error():
    plant, loop = _build_loop()
    loop.run(max_ticks=50)
    assert loop.timestep.tick_count == 50


def test_hlt_autofill_rule_keeps_tank_topped_up():
    plant, loop = _build_loop()
    hlt = plant.tank_by_name("Hot Liquor Tank")
    hlt.level_l = 500  # well below the 85% auto-fill trigger

    loop.run(max_ticks=200)

    assert hlt.level_l > 500  # mains fill rule topped it back up


def test_mash_tun_pid_moves_temperature_toward_setpoint():
    plant, loop = _build_loop()
    mash_tun = plant.tank_by_name("Mash Tun")
    mash_tun.level_l = 500  # needs liquid for the heater to act on
    mash_tun.temperature_c = 20.0

    loop.run(max_ticks=300)

    # Should be climbing toward the 66C setpoint, not still at ambient.
    assert mash_tun.temperature_c > 20.0


def test_emergency_shutdown_halts_all_actuators():
    plant, loop = _build_loop()
    loop.run(max_ticks=10)
    loop.safety_system.emergency_shutdown(loop.state, loop.bus, loop.device_registry,
                                           reason="test")
    for pump in plant.pumps.values():
        assert pump.running is False
    for heater in plant.heaters.values():
        assert heater.duty_cycle_pct == 0
