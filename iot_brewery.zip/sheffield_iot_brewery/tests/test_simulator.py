from sheffield_iot_brewery.plant.brewery_model import BreweryModel
from sheffield_iot_brewery.plant.equipment import create_heater, create_pump, create_tank
from sheffield_iot_brewery.simulation.plant_simulator import PlantSimulator


def test_pump_moves_volume_between_tanks():
    plant = BreweryModel(name="test")
    a = plant.add_tank(create_tank("A", capacity_l=1000, level_l=500, temperature_c=20))
    b = plant.add_tank(create_tank("B", capacity_l=1000, level_l=0, temperature_c=20))
    plant.add_pump(create_pump("P", max_flow_lpm=60, source=a, destination=b,
                                speed_pct=100, running=True))

    sim = PlantSimulator(plant)
    sim.step(dt=60)  # 1 minute at 60 L/min -> 60L moved

    assert a.level_l == 440
    assert b.level_l == 60


def test_pump_respects_destination_capacity():
    plant = BreweryModel(name="test")
    a = plant.add_tank(create_tank("A", capacity_l=1000, level_l=1000))
    b = plant.add_tank(create_tank("B", capacity_l=50, level_l=45))
    plant.add_pump(create_pump("P", max_flow_lpm=60, source=a, destination=b,
                                speed_pct=100, running=True))

    sim = PlantSimulator(plant)
    sim.step(dt=60)

    assert b.level_l == 50  # capped by headroom
    assert a.level_l == 995  # only 5L actually moved


def test_mains_fill_has_unlimited_source():
    plant = BreweryModel(name="test")
    b = plant.add_tank(create_tank("B", capacity_l=1000, level_l=0))
    plant.add_pump(create_pump("Mains", max_flow_lpm=100, source=None, destination=b,
                                speed_pct=100, running=True))

    sim = PlantSimulator(plant)
    sim.step(dt=60)

    assert b.level_l == 100


def test_heater_raises_tank_temperature():
    plant = BreweryModel(name="test")
    tank = plant.add_tank(create_tank("Kettle", capacity_l=1000, level_l=500,
                                       temperature_c=20, heat_loss_rate=0.0))
    plant.add_heater(create_heater("Heater", tank, power_kw=20, duty_cycle_pct=100))

    sim = PlantSimulator(plant)
    initial = tank.temperature_c
    sim.step(dt=60)

    assert tank.temperature_c > initial


def test_tank_relaxes_toward_ambient_with_no_heater():
    plant = BreweryModel(name="test")
    tank = plant.add_tank(create_tank("Tank", capacity_l=1000, level_l=500,
                                       temperature_c=80, ambient_c=18, heat_loss_rate=0.01))
    sim = PlantSimulator(plant)
    sim.step(dt=60)
    assert tank.temperature_c < 80
    assert tank.temperature_c > 18
