from sheffield_iot_brewery.automation.safety_system import SafetySystem, Severity
from sheffield_iot_brewery.core.event_bus import EventBus
from sheffield_iot_brewery.core.state_manager import StateManager
from sheffield_iot_brewery.iot.actuators import HeaterActuator, PumpActuator
from sheffield_iot_brewery.iot.device_registry import DeviceRegistry
from sheffield_iot_brewery.plant.brewery_model import BreweryModel
from sheffield_iot_brewery.plant.equipment import create_heater, create_pump, create_tank
from sheffield_iot_brewery.utils.config import SafetyConfig


def _build_plant():
    plant = BreweryModel(name="test")
    source = plant.add_tank(create_tank("Source", capacity_l=1000, level_l=1000))
    tank = plant.add_tank(create_tank("Tank", capacity_l=100, level_l=96, temperature_c=50))
    pump = plant.add_pump(create_pump("Fill Pump", max_flow_lpm=10, source=source,
                                       destination=tank, speed_pct=100, running=True))
    heater = plant.add_heater(create_heater("Heater", tank, power_kw=5, duty_cycle_pct=100))
    return plant, tank, pump, heater


def test_check_detects_overflow_risk():
    plant, tank, _, _ = _build_plant()
    safety = SafetySystem(plant, SafetyConfig(max_tank_fill_fraction=0.95))
    violations = safety.check()
    assert any(v.kind == "overflow_risk" and v.severity == Severity.CRITICAL for v in violations)


def test_enforce_stops_inflow_pump_on_overflow_risk():
    plant, tank, pump, _ = _build_plant()
    registry = DeviceRegistry()
    registry.register_actuator(PumpActuator(f"{pump.id}:cmd", pump), pump.id)

    safety = SafetySystem(plant, SafetyConfig(max_tank_fill_fraction=0.95))
    state = StateManager()
    bus = EventBus()

    safety.enforce(state, bus, registry)
    assert pump.speed_pct == 0
    assert pump.running is False


def test_thermal_protection_disables_heater():
    plant, tank, _, heater = _build_plant()
    tank.temperature_c = 110
    registry = DeviceRegistry()
    registry.register_actuator(HeaterActuator(f"{heater.id}:cmd", heater), heater.id)

    safety = SafetySystem(plant, SafetyConfig(max_process_temperature_c=105))
    state = StateManager()
    bus = EventBus()

    safety.enforce(state, bus, registry)
    assert heater.duty_cycle_pct == 0


def test_emergency_shutdown_stops_everything():
    plant, tank, pump, heater = _build_plant()
    registry = DeviceRegistry.from_plant(plant)
    safety = SafetySystem(plant)
    state = StateManager()
    bus = EventBus()

    safety.emergency_shutdown(state, bus, registry, reason="test")

    assert safety.shutdown_active is True
    assert pump.running is False
    assert heater.duty_cycle_pct == 0
    assert state.get("safety.shutdown_active") is True
