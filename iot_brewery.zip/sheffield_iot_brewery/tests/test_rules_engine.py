from sheffield_iot_brewery.automation.rules_engine import Rule, RulesEngine
from sheffield_iot_brewery.core.event_bus import EventBus
from sheffield_iot_brewery.core.state_manager import StateManager
from sheffield_iot_brewery.iot.device_registry import DeviceRegistry


def test_rule_fires_when_condition_true():
    engine = RulesEngine()
    state = StateManager()
    bus = EventBus()
    registry = DeviceRegistry()
    fired = []

    engine.add_rule(Rule(
        name="low_level_pump_on",
        condition=lambda s: s.get("level", 100) < 10,
        action=lambda s, b, r: fired.append(True),
    ))

    state.set("level", 50)
    engine.evaluate(state, bus, registry)
    assert fired == []

    state.set("level", 5)
    names = engine.evaluate(state, bus, registry)
    assert names == ["low_level_pump_on"]
    assert fired == [True]


def test_rule_cooldown_prevents_refire():
    engine = RulesEngine()
    state = StateManager()
    bus = EventBus()
    registry = DeviceRegistry()
    count = {"n": 0}

    engine.add_rule(Rule(
        name="always_true",
        condition=lambda s: True,
        action=lambda s, b, r: count.__setitem__("n", count["n"] + 1),
        cooldown_s=1000,
    ))

    engine.evaluate(state, bus, registry)
    engine.evaluate(state, bus, registry)
    engine.evaluate(state, bus, registry)
    assert count["n"] == 1  # only fired once due to cooldown


def test_disabled_rule_never_fires():
    engine = RulesEngine()
    state = StateManager()
    bus = EventBus()
    registry = DeviceRegistry()
    fired = []

    engine.add_rule(Rule(name="r", condition=lambda s: True,
                          action=lambda s, b, r: fired.append(True)))
    engine.set_enabled("r", False)
    engine.evaluate(state, bus, registry)
    assert fired == []


def test_rule_error_does_not_crash_loop():
    engine = RulesEngine()
    state = StateManager()
    bus = EventBus()
    registry = DeviceRegistry()

    def bad_condition(s):
        raise ValueError("boom")

    engine.add_rule(Rule(name="bad", condition=bad_condition, action=lambda s, b, r: None))
    names = engine.evaluate(state, bus, registry)
    assert names == []
    assert any(e.topic == "rule.error" for e in bus.history("#"))
