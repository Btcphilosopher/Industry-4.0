from sheffield_iot_brewery.core.event_bus import EventBus


def test_publish_subscribe_exact_topic():
    bus = EventBus()
    received = []
    bus.subscribe("tank.level", lambda e: received.append(e.payload))
    bus.publish("tank.level", {"value": 42})
    assert received == [{"value": 42}]


def test_wildcard_single_segment():
    bus = EventBus()
    received = []
    bus.subscribe("tank.+.level", lambda e: received.append(e.topic))
    bus.publish("tank.hlt.level")
    bus.publish("tank.mash_tun.level")
    bus.publish("pump.hlt.flow")
    assert received == ["tank.hlt.level", "tank.mash_tun.level"]


def test_wildcard_multi_segment():
    bus = EventBus()
    received = []
    bus.subscribe("safety.#", lambda e: received.append(e.topic))
    bus.publish("safety.overflow_prevented")
    bus.publish("safety.thermal.protection")
    bus.publish("rule.fired")
    assert received == ["safety.overflow_prevented", "safety.thermal.protection"]


def test_history_filters_by_pattern():
    bus = EventBus()
    bus.publish("a.b")
    bus.publish("c.d")
    assert [e.topic for e in bus.history("a.b")] == ["a.b"]
    assert len(bus.history("#")) == 2
