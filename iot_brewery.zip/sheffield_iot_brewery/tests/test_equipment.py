from sheffield_iot_brewery.plant.equipment import create_pump, create_tank


def test_create_tank_defaults():
    tank = create_tank("Test Tank", capacity_l=1000)
    assert tank.capacity_l == 1000
    assert tank.level_l == 0.0
    assert tank.fill_fraction == 0.0
    assert tank.id.startswith("tank-")


def test_tank_fill_fraction_and_headroom():
    tank = create_tank("Test Tank", capacity_l=1000, level_l=250)
    assert tank.fill_fraction == 0.25
    assert tank.headroom_l() == 750


def test_tank_set_level_clamps():
    tank = create_tank("Test Tank", capacity_l=100)
    tank.set_level(150)
    assert tank.level_l == 100
    tank.set_level(-10)
    assert tank.level_l == 0


def test_pump_flow_requires_running():
    tank_a = create_tank("A", capacity_l=1000)
    tank_b = create_tank("B", capacity_l=1000)
    pump = create_pump("P1", max_flow_lpm=50, source=tank_a, destination=tank_b)
    assert pump.flow_lpm() == 0  # not running yet

    pump.running = True
    pump.speed_pct = 50
    assert pump.flow_lpm() == 25
