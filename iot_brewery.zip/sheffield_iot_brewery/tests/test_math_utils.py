import pytest

from sheffield_iot_brewery.utils.math_utils import (MovingAverage, clamp, energy_balance_mix,
                                                      exponential_decay_toward,
                                                      heater_temperature_rise_c, lerp,
                                                      rate_of_change)


def test_clamp():
    assert clamp(5, 0, 10) == 5
    assert clamp(-5, 0, 10) == 0
    assert clamp(15, 0, 10) == 10


def test_lerp():
    assert lerp(0, 10, 0.5) == 5
    assert lerp(0, 10, -1) == 0  # clamps t
    assert lerp(0, 10, 2) == 10


def test_energy_balance_mix():
    # equal volumes at 10 and 20 -> 15
    assert energy_balance_mix(10, 10, 10, 20) == 15
    # zero volumes -> returns temp_a unchanged
    assert energy_balance_mix(0, 42, 0, 99) == 42


def test_exponential_decay_toward_moves_closer_to_target():
    value = exponential_decay_toward(current=100.0, target=20.0, rate=0.01, dt=10.0)
    assert 20.0 < value < 100.0


def test_heater_temperature_rise_positive():
    rise = heater_temperature_rise_c(power_kw=10, duty_pct=100, efficiency=0.9,
                                      mass_kg=100, dt_s=60)
    assert rise > 0


def test_moving_average():
    ma = MovingAverage(window=3)
    ma.push(1)
    ma.push(2)
    ma.push(3)
    assert ma.value == 2
    ma.push(9)  # window slides: [2, 3, 9]
    assert ma.value == pytest.approx(14 / 3)


def test_rate_of_change():
    assert rate_of_change(previous=0, current=10, dt_s=5) == 2
    assert rate_of_change(previous=0, current=10, dt_s=0) == 0
