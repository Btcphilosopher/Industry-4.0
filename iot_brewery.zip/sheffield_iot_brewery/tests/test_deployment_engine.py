from sheffield_iot_brewery.replication.deployment_engine import DeploymentEngine, SiteSpec
from sheffield_iot_brewery.replication.factory_blueprint import SHEFFIELD_BLUEPRINT


def test_generate_deployment_scales_capacity():
    engine = DeploymentEngine()
    site = SiteSpec(site_name="Test Site", scale_factor=2.0, location="Leeds")
    deployment = engine.generate_deployment(SHEFFIELD_BLUEPRINT, site)

    assert deployment.site_name == "Test Site"
    assert deployment.scale_factor == 2.0
    assert deployment.plant_summary["tanks"] == len(SHEFFIELD_BLUEPRINT.tanks)
    assert len(deployment.device_map) > 0
    assert len(deployment.modbus_registers) == len(deployment.device_map)


def test_replicate_produces_one_config_per_site():
    engine = DeploymentEngine()
    sites = [
        SiteSpec(site_name="Site A", scale_factor=1.0),
        SiteSpec(site_name="Site B", scale_factor=0.5),
        SiteSpec(site_name="Site C", scale_factor=3.0),
    ]
    deployments = engine.replicate(SHEFFIELD_BLUEPRINT, sites)
    assert [d.site_name for d in deployments] == ["Site A", "Site B", "Site C"]


def test_deployment_serialises_to_json_round_trip():
    import json
    engine = DeploymentEngine()
    deployment = engine.generate_deployment(SHEFFIELD_BLUEPRINT, SiteSpec(site_name="RT"))
    text = json.dumps(deployment.to_dict())
    data = json.loads(text)
    assert data["site_name"] == "RT"


def test_blueprint_scaled_preserves_topology_keys():
    scaled = SHEFFIELD_BLUEPRINT.scaled(1.5)
    assert len(scaled.tanks) == len(SHEFFIELD_BLUEPRINT.tanks)
    assert scaled.tanks[0].capacity_l == SHEFFIELD_BLUEPRINT.tanks[0].capacity_l * 1.5
