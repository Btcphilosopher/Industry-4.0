from sheffield_iot_brewery.optimisation.load_balancer import LoadBalancer, PowerDemand


def test_load_balancer_full_allocation_within_budget():
    lb = LoadBalancer(max_total_power_kw=100)
    demands = [PowerDemand("a", 30), PowerDemand("b", 40)]
    allocation = lb.allocate(demands)
    assert allocation["a"] == 30
    assert allocation["b"] == 40


def test_load_balancer_scales_down_when_over_budget():
    lb = LoadBalancer(max_total_power_kw=50)
    demands = [PowerDemand("a", 30), PowerDemand("b", 30)]
    allocation = lb.allocate(demands)
    assert allocation["a"] + allocation["b"] == 50
    assert allocation["a"] == allocation["b"] == 25


def test_load_balancer_priority_served_first():
    lb = LoadBalancer(max_total_power_kw=40)
    demands = [
        PowerDemand("high", 40, priority=10),
        PowerDemand("low", 40, priority=0),
    ]
    allocation = lb.allocate(demands)
    assert allocation["high"] == 40
    assert allocation["low"] == 0


def test_duty_cycle_from_allocation_scales_proportionally():
    duty = LoadBalancer.duty_cycle_from_allocation(requested_kw=10, allotted_kw=5,
                                                     requested_duty_pct=80)
    assert duty == 40
