from sheffield_iot_brewery.automation.pid_controllers import PIDController


def test_pid_output_moves_toward_setpoint():
    pid = PIDController("test", kp=2.0, ki=0.1, kd=0.0, setpoint=50, output_min=0, output_max=100)
    output = pid.compute(measurement=20, dt=1.0)
    assert output > 0  # error is positive (setpoint > measurement) -> heat up


def test_pid_output_clamped_to_bounds():
    pid = PIDController("test", kp=1000.0, ki=0.0, kd=0.0, setpoint=1000, output_min=0,
                         output_max=100)
    output = pid.compute(measurement=0, dt=1.0)
    assert output == 100


def test_pid_settles_near_setpoint_over_time():
    pid = PIDController("test", kp=5.0, ki=0.5, kd=0.1, setpoint=66.0, output_min=0,
                         output_max=100, integral_limit=500)
    measurement = 18.0
    for _ in range(400):
        output = pid.compute(measurement, dt=1.0)
        # crude first-order plant: output drives measurement up, with loss
        measurement += (output / 100.0) * 0.6 - (measurement - 18.0) * 0.01
    assert abs(measurement - 66.0) < 3.0


def test_pid_reset_clears_state():
    pid = PIDController("test", kp=1.0, ki=1.0, kd=1.0, setpoint=10)
    pid.compute(0, dt=1.0)
    pid.compute(1, dt=1.0)
    pid.reset()
    assert pid._integral == 0.0
    assert pid._previous_error is None
