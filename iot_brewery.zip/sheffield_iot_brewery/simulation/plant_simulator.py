"""Virtual plant execution engine.

Advances tank levels and temperatures forward in time using simple,
deterministic flow and heat-transfer abstractions. This is intentionally
*not* a chemistry/brewing-science model — it is a control-systems
physics abstraction good enough to validate automation logic (levels
rise/fall correctly, temperatures respond to heaters/coolers, overflow
and thermal limits are reachable) before it runs a real plant.
"""
from __future__ import annotations

from dataclasses import dataclass

from sheffield_iot_brewery.plant.brewery_model import BreweryModel
from sheffield_iot_brewery.utils.math_utils import (energy_balance_mix, exponential_decay_toward,
                                                      heater_temperature_rise_c,
                                                      cooler_temperature_drop_c)


@dataclass
class PlantSimulator:
    plant: BreweryModel

    def step(self, dt: float) -> None:
        if dt <= 0:
            return
        self._apply_flows(dt)
        self._apply_thermal(dt)

    # -- flow / level physics -----------------------------------------
    def _apply_flows(self, dt: float) -> None:
        for pump in self.plant.pumps.values():
            self._move_volume(pump.flow_lpm(), dt, pump.source, pump.destination,
                               pump.supply_temperature_c)
        for valve in self.plant.valves.values():
            self._move_volume(valve.flow_lpm(), dt, valve.upstream, valve.downstream,
                               valve.supply_temperature_c)

    def _move_volume(self, flow_lpm: float, dt: float, source, destination,
                      external_supply_temp_c: float) -> None:
        if flow_lpm <= 0:
            return
        requested = flow_lpm * (dt / 60.0)  # L/min -> litres over dt

        # Cap by what the source tank actually has available (mains supply,
        # represented by ``source is None``, is treated as unlimited).
        available = requested if source is None else min(requested, source.level_l)
        if available <= 0:
            return

        # Cap by headroom in the destination tank (drain, represented by
        # ``destination is None``, always has room).
        headroom = available if destination is None else destination.headroom_l()
        moved = min(available, headroom)
        if moved <= 0:
            return

        source_temp = source.temperature_c if source is not None else external_supply_temp_c

        if source is not None:
            source.level_l = max(0.0, source.level_l - moved)

        if destination is not None:
            destination.temperature_c = energy_balance_mix(
                destination.level_l, destination.temperature_c, moved, source_temp,
            )
            destination.level_l = min(destination.capacity_l, destination.level_l + moved)

    # -- thermal physics -------------------------------------------------
    def _apply_thermal(self, dt: float) -> None:
        for heater in self.plant.heaters.values():
            tank = heater.tank
            if tank is None or heater.duty_cycle_pct <= 0 or not heater.enabled:
                continue
            rise = heater_temperature_rise_c(
                heater.power_kw, heater.duty_cycle_pct, heater.efficiency,
                mass_kg=max(tank.mass_kg, 1.0), dt_s=dt,
            )
            tank.temperature_c += rise

        for cooler in self.plant.coolers.values():
            tank = cooler.tank
            if tank is None or cooler.duty_cycle_pct <= 0 or not cooler.enabled:
                continue
            drop = cooler_temperature_drop_c(
                cooler.cooling_power_kw, cooler.duty_cycle_pct, cooler.efficiency,
                mass_kg=max(tank.mass_kg, 1.0), dt_s=dt,
            )
            tank.temperature_c -= drop

        # Passive heat loss/gain toward ambient for every tank.
        for tank in self.plant.tanks.values():
            tank.temperature_c = exponential_decay_toward(
                tank.temperature_c, tank.ambient_c, tank.heat_loss_rate, dt,
            )
