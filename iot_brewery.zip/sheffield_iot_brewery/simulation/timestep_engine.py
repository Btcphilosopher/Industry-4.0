"""Deterministic timestep driver for simulation mode.

Decouples "how much virtual time passed this tick" from wall-clock
time, so simulations run reproducibly (fixed dt, fixed random seed)
regardless of how fast the host machine executes each iteration.
"""
from __future__ import annotations

import random
from dataclasses import dataclass


@dataclass
class TimestepEngine:
    dt_seconds: float = 1.0
    seed: int | None = 42

    def __post_init__(self) -> None:
        self.tick_count = 0
        self.simulated_time_s = 0.0
        self._rng = random.Random(self.seed)
        if self.seed is not None:
            random.seed(self.seed)

    def advance(self) -> float:
        """Advance one deterministic step; returns the new simulated time."""
        self.tick_count += 1
        self.simulated_time_s += self.dt_seconds
        return self.simulated_time_s

    def reset(self) -> None:
        self.tick_count = 0
        self.simulated_time_s = 0.0
        self._rng = random.Random(self.seed)
        if self.seed is not None:
            random.seed(self.seed)

    @property
    def rng(self) -> random.Random:
        return self._rng
