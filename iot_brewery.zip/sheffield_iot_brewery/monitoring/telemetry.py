"""System metrics collector.

Keeps a rolling per-key time series of every value that passes through
the state manager each tick, and exposes summary statistics used by the
dashboard, alerting and efficiency engine.
"""
from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass
from typing import Any, Deque, Dict, List, Tuple


@dataclass
class TelemetryCollector:
    window: int = 600
    sample_every_n_ticks: int = 1

    def __post_init__(self) -> None:
        self._series: Dict[str, Deque[Tuple[float, float]]] = defaultdict(
            lambda: deque(maxlen=self.window)
        )
        self._tick_count = 0

    def record(self, timestamp: float, snapshot: Dict[str, Any]) -> None:
        self._tick_count += 1
        if self._tick_count % self.sample_every_n_ticks != 0:
            return
        for key, value in snapshot.items():
            if isinstance(value, (int, float)) and not isinstance(value, bool):
                self._series[key].append((timestamp, float(value)))

    def get_series(self, key: str) -> List[Tuple[float, float]]:
        return list(self._series.get(key, deque()))

    def latest(self, key: str) -> Any:
        series = self._series.get(key)
        return series[-1][1] if series else None

    def summary(self, key: str) -> Dict[str, float]:
        series = self._series.get(key)
        if not series:
            return {}
        values = [v for _, v in series]
        return {
            "min": min(values),
            "max": max(values),
            "avg": sum(values) / len(values),
            "last": values[-1],
            "samples": len(values),
        }

    def all_keys(self) -> List[str]:
        return list(self._series.keys())

    def full_summary(self) -> Dict[str, Dict[str, float]]:
        return {key: self.summary(key) for key in self._series}
