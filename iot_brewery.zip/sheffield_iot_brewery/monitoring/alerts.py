"""Anomaly detection and warnings.

Watches the telemetry stream for threshold breaches and abnormal rates
of change, independent of the hard safety interlocks in
:mod:`automation.safety_system` (this is observability/warning, that is
enforcement). Alerts are published onto the event bus so dashboards and
external integrations can subscribe.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional

from sheffield_iot_brewery.core.event_bus import EventBus
from sheffield_iot_brewery.monitoring.telemetry import TelemetryCollector
from sheffield_iot_brewery.utils.math_utils import rate_of_change


class AlertSeverity(str, Enum):
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"


@dataclass
class Alert:
    key: str
    severity: AlertSeverity
    message: str
    value: float
    timestamp: float = field(default_factory=time.time)


@dataclass
class ThresholdRule:
    key: str
    minimum: Optional[float] = None
    maximum: Optional[float] = None
    severity: AlertSeverity = AlertSeverity.WARNING


@dataclass
class RateOfChangeRule:
    key: str
    max_abs_rate_per_s: float
    severity: AlertSeverity = AlertSeverity.WARNING


class AlertManager:
    def __init__(self, telemetry: TelemetryCollector, bus: Optional[EventBus] = None):
        self.telemetry = telemetry
        self.bus = bus
        self.threshold_rules: List[ThresholdRule] = []
        self.rate_rules: List[RateOfChangeRule] = []
        self.active_alerts: Dict[str, Alert] = {}
        self.history: List[Alert] = []

    def add_threshold_rule(self, rule: ThresholdRule) -> None:
        self.threshold_rules.append(rule)

    def add_rate_rule(self, rule: RateOfChangeRule) -> None:
        self.rate_rules.append(rule)

    def _raise(self, alert: Alert) -> None:
        self.active_alerts[alert.key] = alert
        self.history.append(alert)
        if len(self.history) > 5000:
            self.history.pop(0)
        if self.bus:
            self.bus.publish("alert.raised", {
                "key": alert.key, "severity": alert.severity.value,
                "message": alert.message, "value": alert.value,
            }, source="alerts")

    def _clear(self, key: str) -> None:
        self.active_alerts.pop(key, None)

    def evaluate(self) -> List[Alert]:
        raised: List[Alert] = []

        for rule in self.threshold_rules:
            value = self.telemetry.latest(rule.key)
            if value is None:
                continue
            breached = (rule.minimum is not None and value < rule.minimum) or \
                       (rule.maximum is not None and value > rule.maximum)
            if breached:
                alert = Alert(rule.key, rule.severity,
                               f"{rule.key} out of range: {value:.2f}", value)
                self._raise(alert)
                raised.append(alert)
            else:
                self._clear(rule.key)

        for rule in self.rate_rules:
            series = self.telemetry.get_series(rule.key)
            if len(series) < 2:
                continue
            (t0, v0), (t1, v1) = series[-2], series[-1]
            roc = rate_of_change(v0, v1, t1 - t0)
            if abs(roc) > rule.max_abs_rate_per_s:
                alert = Alert(rule.key, rule.severity,
                               f"{rule.key} changing too fast: {roc:.3f}/s", roc)
                self._raise(alert)
                raised.append(alert)

        return raised

    def snapshot(self) -> List[Alert]:
        return list(self.active_alerts.values())
