"""Live system UI.

A dependency-free text dashboard: renders tank levels, equipment
status and active alerts as an aligned table suitable for a terminal,
plus a JSON-serialisable form for feeding a real web dashboard later.
"""
from __future__ import annotations

from typing import Any, Dict, List

from sheffield_iot_brewery.monitoring.alerts import Alert
from sheffield_iot_brewery.plant.brewery_model import BreweryModel


class DashboardRenderer:
    def __init__(self, plant: BreweryModel):
        self.plant = plant

    def render_json(self, alerts: List[Alert], mode: str, tick: int) -> Dict[str, Any]:
        return {
            "plant": self.plant.name,
            "mode": mode,
            "tick": tick,
            "tanks": [
                {
                    "id": t.id, "name": t.name,
                    "level_l": round(t.level_l, 2),
                    "capacity_l": t.capacity_l,
                    "fill_pct": round(t.fill_fraction * 100, 1),
                    "temperature_c": round(t.temperature_c, 1),
                }
                for t in self.plant.tanks.values()
            ],
            "pumps": [
                {"id": p.id, "name": p.name, "running": p.running,
                 "speed_pct": round(p.speed_pct, 1), "flow_lpm": round(p.flow_lpm(), 2)}
                for p in self.plant.pumps.values()
            ],
            "valves": [
                {"id": v.id, "name": v.name, "open_pct": round(v.open_pct, 1),
                 "flow_lpm": round(v.flow_lpm(), 2)}
                for v in self.plant.valves.values()
            ],
            "heaters": [
                {"id": h.id, "name": h.name, "duty_pct": round(h.duty_cycle_pct, 1)}
                for h in self.plant.heaters.values()
            ],
            "coolers": [
                {"id": c.id, "name": c.name, "duty_pct": round(c.duty_cycle_pct, 1)}
                for c in self.plant.coolers.values()
            ],
            "alerts": [
                {"key": a.key, "severity": a.severity.value, "message": a.message}
                for a in alerts
            ],
        }

    def render_text(self, alerts: List[Alert], mode: str, tick: int) -> str:
        lines = [f"=== {self.plant.name} | mode={mode} | tick={tick} ==="]

        lines.append("-- Tanks " + "-" * 40)
        for t in self.plant.tanks.values():
            bar = self._bar(t.fill_fraction)
            lines.append(f"  {t.name:<20} {bar} {t.fill_fraction*100:5.1f}%  "
                         f"{t.level_l:8.1f}L / {t.capacity_l:8.1f}L   {t.temperature_c:5.1f}C")

        lines.append("-- Pumps / Valves " + "-" * 32)
        for p in self.plant.pumps.values():
            state = "RUN" if p.running else "off"
            lines.append(f"  {p.name:<20} [{state}] speed={p.speed_pct:5.1f}%  "
                         f"flow={p.flow_lpm():6.2f} L/min")
        for v in self.plant.valves.values():
            lines.append(f"  {v.name:<20} open={v.open_pct:5.1f}%  "
                         f"flow={v.flow_lpm():6.2f} L/min")

        lines.append("-- Heaters / Coolers " + "-" * 29)
        for h in self.plant.heaters.values():
            lines.append(f"  {h.name:<20} duty={h.duty_cycle_pct:5.1f}%")
        for c in self.plant.coolers.values():
            lines.append(f"  {c.name:<20} duty={c.duty_cycle_pct:5.1f}%")

        if alerts:
            lines.append("-- Alerts " + "-" * 40)
            for a in alerts:
                lines.append(f"  [{a.severity.value.upper():<8}] {a.message}")
        else:
            lines.append("-- No active alerts --")

        return "\n".join(lines)

    @staticmethod
    def _bar(fraction: float, width: int = 20) -> str:
        filled = max(0, min(width, round(fraction * width)))
        return "[" + ("#" * filled) + ("." * (width - filled)) + "]"
