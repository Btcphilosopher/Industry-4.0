"""Maps the software device model onto real IoT hardware (mockable).

This is the seam between "software brain" and "physical plant". In
SIMULATION mode nothing implements this interface. In LIVE/HYBRID mode a
concrete subclass is responsible for two things each tick:

* ``refresh`` - pull fresh field values into the equipment objects that
  back each :mod:`iot.sensors` sensor, before the control loop reads them.
* ``commit`` - push each actuator's commanded value out to the real
  device (PLC output, relay, VFD, etc.) after the control loop has
  decided what to do.

:class:`SimulatedHardwareInterface` is a pass-through used for testing
the interface contract itself. :class:`RealHardwareInterface` is the
extension point a deployment integrates a fieldbus driver into.
"""
from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import Dict

from sheffield_iot_brewery.iot.device_registry import DeviceRegistry

logger = logging.getLogger("sheffield_iot_brewery.hardware_interface")


class HardwareInterface(ABC):
    @abstractmethod
    def connect(self) -> None:
        ...

    @abstractmethod
    def disconnect(self) -> None:
        ...

    @abstractmethod
    def refresh(self, registry: DeviceRegistry) -> None:
        """Pull live field values into the sensor-backing equipment."""

    @abstractmethod
    def commit(self, registry: DeviceRegistry) -> None:
        """Push actuator commands out to the field."""

    @abstractmethod
    def is_connected(self) -> bool:
        ...


class SimulatedHardwareInterface(HardwareInterface):
    """No-op hardware interface: the simulator already owns equipment
    state, so refresh/commit have nothing extra to do. Useful for
    exercising HYBRID-mode code paths in tests without real devices."""

    def __init__(self) -> None:
        self._connected = False

    def connect(self) -> None:
        self._connected = True

    def disconnect(self) -> None:
        self._connected = False

    def refresh(self, registry: DeviceRegistry) -> None:
        return None

    def commit(self, registry: DeviceRegistry) -> None:
        return None

    def is_connected(self) -> bool:
        return self._connected


class RealHardwareInterface(HardwareInterface):
    """Extension point for a real fieldbus/PLC driver.

    Subclass this and implement the four methods against your protocol
    of choice (Modbus TCP, OPC-UA, EtherNet/IP, vendor SDK, ...). The
    ``device_addresses`` mapping (device_id -> field address) is
    typically produced by :mod:`integration.protocol_adapter` and/or
    :mod:`replication.deployment_engine` at deployment time.
    """

    def __init__(self, device_addresses: Dict[str, str]):
        self.device_addresses = device_addresses
        self._connected = False

    def connect(self) -> None:
        logger.info("connecting to real hardware (%d mapped devices)",
                    len(self.device_addresses))
        # A concrete driver would open its transport (socket, serial
        # port, SDK session) here.
        self._connected = True

    def disconnect(self) -> None:
        self._connected = False

    def is_connected(self) -> bool:
        return self._connected

    def refresh(self, registry: DeviceRegistry) -> None:
        if not self._connected:
            raise RuntimeError("hardware interface not connected")
        raise NotImplementedError(
            "Wire this to a real fieldbus/OPC-UA/Modbus driver: for each "
            "sensor device_id in `registry.sensors`, read the mapped "
            "address in `self.device_addresses` and write the value into "
            "the sensor's underlying equipment object."
        )

    def commit(self, registry: DeviceRegistry) -> None:
        if not self._connected:
            raise RuntimeError("hardware interface not connected")
        raise NotImplementedError(
            "Wire this to a real fieldbus/OPC-UA/Modbus driver: for each "
            "actuator device_id in `registry.actuators`, write its current "
            "commanded value to the mapped address in "
            "`self.device_addresses`."
        )
