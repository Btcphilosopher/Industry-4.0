"""MQTT / REST / industrial-protocol addressing layer.

Pure, dependency-free functions and a small adapter class that turn
device ids into the addressing schemes different transports need:
MQTT topics, REST payloads, and a synthetic Modbus-style register map.
Used by :mod:`iot.comms`, :mod:`replication.deployment_engine` and any
:class:`integration.hardware_interface.RealHardwareInterface` driver.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict


def mqtt_topic_for(plant_name: str, equipment_id: str, measurement: str) -> str:
    slug = plant_name.lower().replace(" ", "-")
    return f"{slug}/{equipment_id}/{measurement}"


def rest_payload_for(device_id: str, value: Any, unit: str = "", timestamp: float = 0.0) -> Dict:
    return {
        "device_id": device_id,
        "value": value,
        "unit": unit,
        "timestamp": timestamp,
    }


@dataclass
class ProtocolAdapter:
    """Bundles the addressing schemes for one plant's device registry."""

    plant_name: str

    def to_mqtt_topic(self, equipment_id: str, measurement: str) -> str:
        return mqtt_topic_for(self.plant_name, equipment_id, measurement)

    def to_mqtt_message(self, device_id: str, value: Any, unit: str = "") -> Dict:
        return {
            "topic": self.to_mqtt_topic(device_id, "value"),
            "payload": rest_payload_for(device_id, value, unit),
        }

    def to_rest_payload(self, device_id: str, value: Any, unit: str = "") -> Dict:
        return rest_payload_for(device_id, value, unit)

    def to_modbus_registers(self, device_ids: list) -> Dict[str, int]:
        """Deterministically assign a synthetic holding-register address
        to each device id, starting at 40001 (standard Modbus holding
        register base), in the order given. Purely illustrative — a real
        deployment would use the field device's documented map."""
        return {device_id: 40001 + i for i, device_id in enumerate(sorted(device_ids))}
