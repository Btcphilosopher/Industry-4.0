"""Physical plant equipment models.

These are plain data-holding objects that represent the physical world.
They know nothing about IoT, control loops or automation — that
separation is what lets the exact same objects be driven by a live
control loop (real plant) or a simulated one (virtual plant), matching
the platform's core principle: "the same system that simulates the
plant can run it".
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass
from enum import Enum
from typing import Optional


class EquipmentType(str, Enum):
    TANK = "tank"
    PUMP = "pump"
    VALVE = "valve"
    HEATER = "heater"
    COOLER = "cooler"


def make_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:6]}"


@dataclass
class Equipment:
    id: str
    name: str
    equipment_type: EquipmentType


@dataclass
class Tank(Equipment):
    capacity_l: float
    level_l: float = 0.0
    temperature_c: float = 18.0
    ambient_c: float = 18.0
    heat_loss_rate: float = 0.0015  # per-second relaxation toward ambient
    density_kg_per_l: float = 1.0

    @property
    def fill_fraction(self) -> float:
        if self.capacity_l <= 0:
            return 0.0
        return self.level_l / self.capacity_l

    @property
    def mass_kg(self) -> float:
        return self.level_l * self.density_kg_per_l

    def headroom_l(self) -> float:
        return max(0.0, self.capacity_l - self.level_l)

    def set_level(self, litres: float) -> None:
        self.level_l = max(0.0, min(self.capacity_l, litres))


@dataclass
class Pump(Equipment):
    source: Optional[Tank] = None
    destination: Optional[Tank] = None
    max_flow_lpm: float = 0.0
    speed_pct: float = 0.0  # commanded by actuator, 0-100
    running: bool = False
    supply_temperature_c: float = 15.0  # used when source is an external mains feed (None)

    def flow_lpm(self) -> float:
        if not self.running:
            return 0.0
        return self.max_flow_lpm * (max(0.0, min(100.0, self.speed_pct)) / 100.0)


@dataclass
class Valve(Equipment):
    upstream: Optional[Tank] = None
    downstream: Optional[Tank] = None
    open_pct: float = 0.0  # commanded by actuator, 0-100
    max_flow_lpm: float = 0.0
    supply_temperature_c: float = 15.0

    def flow_lpm(self) -> float:
        return self.max_flow_lpm * (max(0.0, min(100.0, self.open_pct)) / 100.0)


@dataclass
class Heater(Equipment):
    tank: Tank = None  # type: ignore[assignment]
    power_kw: float = 0.0
    duty_cycle_pct: float = 0.0  # commanded by actuator, 0-100
    efficiency: float = 0.9
    enabled: bool = True


@dataclass
class Cooler(Equipment):
    tank: Tank = None  # type: ignore[assignment]
    cooling_power_kw: float = 0.0
    duty_cycle_pct: float = 0.0  # commanded by actuator, 0-100
    efficiency: float = 0.85
    enabled: bool = True


def create_tank(name: str, capacity_l: float, **kwargs) -> Tank:
    return Tank(id=make_id("tank"), name=name, equipment_type=EquipmentType.TANK,
                capacity_l=capacity_l, **kwargs)


def create_pump(name: str, max_flow_lpm: float, source: Optional[Tank] = None,
                 destination: Optional[Tank] = None, **kwargs) -> Pump:
    return Pump(id=make_id("pump"), name=name, equipment_type=EquipmentType.PUMP,
                source=source, destination=destination, max_flow_lpm=max_flow_lpm, **kwargs)


def create_valve(name: str, max_flow_lpm: float, upstream: Optional[Tank] = None,
                  downstream: Optional[Tank] = None, **kwargs) -> Valve:
    return Valve(id=make_id("valve"), name=name, equipment_type=EquipmentType.VALVE,
                 upstream=upstream, downstream=downstream, max_flow_lpm=max_flow_lpm, **kwargs)


def create_heater(name: str, tank: Tank, power_kw: float, **kwargs) -> Heater:
    return Heater(id=make_id("heater"), name=name, equipment_type=EquipmentType.HEATER,
                  tank=tank, power_kw=power_kw, **kwargs)


def create_cooler(name: str, tank: Tank, cooling_power_kw: float, **kwargs) -> Cooler:
    return Cooler(id=make_id("cooler"), name=name, equipment_type=EquipmentType.COOLER,
                  tank=tank, cooling_power_kw=cooling_power_kw, **kwargs)
