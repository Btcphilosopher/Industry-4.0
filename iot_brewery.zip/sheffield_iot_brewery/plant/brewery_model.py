"""The physical plant structure: a container of equipment + topology."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterator, Optional, Union

from .equipment import Cooler, Heater, Pump, Tank, Valve
from .network_topology import NetworkTopology

AnyEquipment = Union[Tank, Pump, Valve, Heater, Cooler]


@dataclass
class BreweryModel:
    """A complete plant: every piece of equipment plus how it is wired."""

    name: str
    tanks: Dict[str, Tank] = field(default_factory=dict)
    pumps: Dict[str, Pump] = field(default_factory=dict)
    valves: Dict[str, Valve] = field(default_factory=dict)
    heaters: Dict[str, Heater] = field(default_factory=dict)
    coolers: Dict[str, Cooler] = field(default_factory=dict)
    topology: NetworkTopology = field(default_factory=NetworkTopology)

    # -- registration -----------------------------------------------
    def add_tank(self, tank: Tank) -> Tank:
        self.tanks[tank.id] = tank
        return tank

    def add_pump(self, pump: Pump) -> Pump:
        self.pumps[pump.id] = pump
        self.topology.connect(
            pump.id, "pump",
            pump.source.id if pump.source else None,
            pump.destination.id if pump.destination else None,
        )
        return pump

    def add_valve(self, valve: Valve) -> Valve:
        self.valves[valve.id] = valve
        self.topology.connect(
            valve.id, "valve",
            valve.upstream.id if valve.upstream else None,
            valve.downstream.id if valve.downstream else None,
        )
        return valve

    def add_heater(self, heater: Heater) -> Heater:
        self.heaters[heater.id] = heater
        return heater

    def add_cooler(self, cooler: Cooler) -> Cooler:
        self.coolers[cooler.id] = cooler
        return cooler

    # -- lookups -------------------------------------------------------
    def get(self, equipment_id: str) -> Optional[AnyEquipment]:
        for registry in (self.tanks, self.pumps, self.valves, self.heaters, self.coolers):
            if equipment_id in registry:
                return registry[equipment_id]
        return None

    def all_equipment(self) -> Iterator[AnyEquipment]:
        for registry in (self.tanks, self.pumps, self.valves, self.heaters, self.coolers):
            yield from registry.values()

    def tank_by_name(self, name: str) -> Optional[Tank]:
        for tank in self.tanks.values():
            if tank.name == name:
                return tank
        return None

    def summary(self) -> Dict[str, int]:
        return {
            "tanks": len(self.tanks),
            "pumps": len(self.pumps),
            "valves": len(self.valves),
            "heaters": len(self.heaters),
            "coolers": len(self.coolers),
        }
