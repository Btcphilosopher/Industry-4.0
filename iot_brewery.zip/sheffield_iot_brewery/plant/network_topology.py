"""Describes how plant equipment is physically connected.

The topology is a simple directed graph: nodes are equipment ids, and
edges represent a flow path carried by a pump or valve. It underpins
both the simulator (to know what feeds what) and the deployment engine
(to serialise the plant's wiring into a deployable schema/diagram).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

EXTERNAL = "EXTERNAL"  # sentinel node id for mains supply / drain


@dataclass
class FlowEdge:
    carrier_id: str  # id of the Pump or Valve driving this flow
    carrier_kind: str  # "pump" | "valve"
    from_node: str  # equipment id, or EXTERNAL for mains supply
    to_node: str  # equipment id, or EXTERNAL for drain/waste


@dataclass
class NetworkTopology:
    edges: List[FlowEdge] = field(default_factory=list)

    def connect(self, carrier_id: str, carrier_kind: str,
                from_node: Optional[str], to_node: Optional[str]) -> None:
        self.edges.append(FlowEdge(
            carrier_id=carrier_id,
            carrier_kind=carrier_kind,
            from_node=from_node or EXTERNAL,
            to_node=to_node or EXTERNAL,
        ))

    def upstream_of(self, node_id: str) -> List[FlowEdge]:
        return [e for e in self.edges if e.to_node == node_id]

    def downstream_of(self, node_id: str) -> List[FlowEdge]:
        return [e for e in self.edges if e.from_node == node_id]

    def carriers_between(self, from_node: str, to_node: str) -> List[FlowEdge]:
        return [e for e in self.edges if e.from_node == from_node and e.to_node == to_node]

    def to_dict(self) -> Dict:
        return {
            "edges": [
                {
                    "carrier_id": e.carrier_id,
                    "carrier_kind": e.carrier_kind,
                    "from": e.from_node,
                    "to": e.to_node,
                }
                for e in self.edges
            ]
        }

    def to_mermaid(self) -> str:
        """Render a Mermaid flowchart diagram for documentation/dashboards."""
        lines = ["flowchart LR"]
        for e in self.edges:
            label = f"{e.carrier_kind}:{e.carrier_id}"
            lines.append(f'    {e.from_node} -->|{label}| {e.to_node}')
        return "\n".join(lines)
