"""The Sheffield Brewery reference model.

Declares the canonical plant layout as a serialisable
:class:`PlantBlueprint` (equipment specs + connections + control specs)
and provides :func:`build_plant` to materialise it into a live
:class:`BreweryModel` plus the automation/safety wiring that goes with
it. The blueprint is the "deployable configuration" the replication
engine scales and clones to new sites.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Tuple

from sheffield_iot_brewery.automation.pid_controllers import PIDController, PIDControllerManager, PIDLoop
from sheffield_iot_brewery.automation.rules_engine import Rule, RulesEngine
from sheffield_iot_brewery.automation.safety_system import SafetySystem
from sheffield_iot_brewery.iot.device_registry import DeviceRegistry
from sheffield_iot_brewery.plant.brewery_model import BreweryModel
from sheffield_iot_brewery.plant.equipment import (create_cooler, create_heater, create_pump,
                                                     create_tank, create_valve)
from sheffield_iot_brewery.utils.config import SafetyConfig


@dataclass
class TankSpec:
    key: str
    name: str
    capacity_l: float
    initial_level_l: float = 0.0
    initial_temperature_c: float = 18.0
    ambient_c: float = 18.0


@dataclass
class PumpSpec:
    key: str
    name: str
    source: Optional[str]  # TankSpec.key or None for mains
    destination: Optional[str]
    max_flow_lpm: float


@dataclass
class ValveSpec:
    key: str
    name: str
    upstream: Optional[str]
    downstream: Optional[str]
    max_flow_lpm: float


@dataclass
class HeaterSpec:
    key: str
    name: str
    tank: str
    power_kw: float


@dataclass
class CoolerSpec:
    key: str
    name: str
    tank: str
    cooling_power_kw: float


@dataclass
class PlantBlueprint:
    """Declarative, JSON-friendly description of a plant."""

    name: str
    tanks: List[TankSpec] = field(default_factory=list)
    pumps: List[PumpSpec] = field(default_factory=list)
    valves: List[ValveSpec] = field(default_factory=list)
    heaters: List[HeaterSpec] = field(default_factory=list)
    coolers: List[CoolerSpec] = field(default_factory=list)
    mash_temperature_setpoint_c: float = 66.0
    boil_temperature_setpoint_c: float = 100.0
    fermenter_temperature_setpoint_c: float = 18.0
    safety: SafetyConfig = field(default_factory=SafetyConfig)

    def scaled(self, factor: float, name: Optional[str] = None) -> "PlantBlueprint":
        """Return a copy scaled by ``factor`` (capacity/flow/power), used
        to size the reference model up or down for a new site."""
        return PlantBlueprint(
            name=name or f"{self.name} (x{factor:g})",
            tanks=[TankSpec(t.key, t.name, t.capacity_l * factor,
                             t.initial_level_l * factor, t.initial_temperature_c, t.ambient_c)
                   for t in self.tanks],
            pumps=[PumpSpec(p.key, p.name, p.source, p.destination, p.max_flow_lpm * factor)
                   for p in self.pumps],
            valves=[ValveSpec(v.key, v.name, v.upstream, v.downstream, v.max_flow_lpm * factor)
                    for v in self.valves],
            heaters=[HeaterSpec(h.key, h.name, h.tank, h.power_kw * factor)
                     for h in self.heaters],
            coolers=[CoolerSpec(c.key, c.name, c.tank, c.cooling_power_kw * factor)
                     for c in self.coolers],
            mash_temperature_setpoint_c=self.mash_temperature_setpoint_c,
            boil_temperature_setpoint_c=self.boil_temperature_setpoint_c,
            fermenter_temperature_setpoint_c=self.fermenter_temperature_setpoint_c,
            safety=self.safety,
        )


# --------------------------------------------------------------------
# The Sheffield reference model: hot liquor tank -> mash tun -> lauter
# tun -> boil kettle -> whirlpool -> fermenter -> bright tank.
# --------------------------------------------------------------------
SHEFFIELD_BLUEPRINT = PlantBlueprint(
    name="Sheffield Brewery Reference Plant",
    tanks=[
        TankSpec("hlt", "Hot Liquor Tank", capacity_l=2000, initial_level_l=1800,
                  initial_temperature_c=80.0, ambient_c=18.0),
        TankSpec("mash_tun", "Mash Tun", capacity_l=1500, initial_level_l=0.0,
                  initial_temperature_c=18.0, ambient_c=18.0),
        TankSpec("lauter_tun", "Lauter Tun", capacity_l=1500, initial_level_l=0.0,
                  initial_temperature_c=18.0, ambient_c=18.0),
        TankSpec("boil_kettle", "Boil Kettle", capacity_l=1500, initial_level_l=0.0,
                  initial_temperature_c=18.0, ambient_c=18.0),
        TankSpec("whirlpool", "Whirlpool", capacity_l=1500, initial_level_l=0.0,
                  initial_temperature_c=18.0, ambient_c=18.0),
        TankSpec("fermenter", "Fermenter", capacity_l=2000, initial_level_l=0.0,
                  initial_temperature_c=18.0, ambient_c=16.0),
        TankSpec("bright_tank", "Bright Tank", capacity_l=2000, initial_level_l=0.0,
                  initial_temperature_c=4.0, ambient_c=4.0),
    ],
    pumps=[
        PumpSpec("hlt_to_mash", "HLT to Mash Tun Pump", "hlt", "mash_tun", max_flow_lpm=80),
        PumpSpec("mash_to_lauter", "Mash to Lauter Pump", "mash_tun", "lauter_tun", max_flow_lpm=60),
        PumpSpec("lauter_to_kettle", "Lauter to Kettle Pump", "lauter_tun", "boil_kettle",
                  max_flow_lpm=60),
        PumpSpec("kettle_to_whirlpool", "Kettle to Whirlpool Pump", "boil_kettle", "whirlpool",
                  max_flow_lpm=60),
        PumpSpec("whirlpool_to_fermenter", "Whirlpool to Fermenter Pump", "whirlpool",
                  "fermenter", max_flow_lpm=60),
        PumpSpec("fermenter_to_bright", "Fermenter to Bright Tank Pump", "fermenter",
                  "bright_tank", max_flow_lpm=50),
        PumpSpec("mains_fill_hlt", "Mains Water Fill Pump", None, "hlt", max_flow_lpm=100),
    ],
    valves=[
        ValveSpec("bright_tank_outlet", "Bright Tank Packaging Valve", "bright_tank", None,
                   max_flow_lpm=40),
    ],
    heaters=[
        HeaterSpec("hlt_heater", "HLT Immersion Heater", "hlt", power_kw=24.0),
        HeaterSpec("mash_tun_heater", "Mash Tun Heater", "mash_tun", power_kw=18.0),
        HeaterSpec("boil_kettle_heater", "Boil Kettle Heater", "boil_kettle", power_kw=36.0),
    ],
    coolers=[
        CoolerSpec("whirlpool_cooler", "Whirlpool Plate Chiller", "whirlpool",
                    cooling_power_kw=20.0),
        CoolerSpec("fermenter_cooler", "Fermenter Glycol Jacket", "fermenter",
                    cooling_power_kw=8.0),
        CoolerSpec("bright_tank_cooler", "Bright Tank Glycol Jacket", "bright_tank",
                    cooling_power_kw=6.0),
    ],
)


def build_plant(blueprint: PlantBlueprint) -> BreweryModel:
    """Materialise a declarative :class:`PlantBlueprint` into a live,
    wired-up :class:`BreweryModel`."""
    plant = BreweryModel(name=blueprint.name)

    tanks_by_key = {}
    for spec in blueprint.tanks:
        tank = create_tank(spec.name, spec.capacity_l, level_l=spec.initial_level_l,
                            temperature_c=spec.initial_temperature_c, ambient_c=spec.ambient_c)
        plant.add_tank(tank)
        tanks_by_key[spec.key] = tank

    for spec in blueprint.pumps:
        pump = create_pump(spec.name, spec.max_flow_lpm,
                            source=tanks_by_key.get(spec.source) if spec.source else None,
                            destination=tanks_by_key.get(spec.destination) if spec.destination else None)
        plant.add_pump(pump)

    for spec in blueprint.valves:
        valve = create_valve(spec.name, spec.max_flow_lpm,
                              upstream=tanks_by_key.get(spec.upstream) if spec.upstream else None,
                              downstream=tanks_by_key.get(spec.downstream) if spec.downstream else None)
        plant.add_valve(valve)

    for spec in blueprint.heaters:
        heater = create_heater(spec.name, tanks_by_key[spec.tank], spec.power_kw)
        plant.add_heater(heater)

    for spec in blueprint.coolers:
        cooler = create_cooler(spec.name, tanks_by_key[spec.tank], spec.cooling_power_kw)
        plant.add_cooler(cooler)

    return plant


def configure_default_automation(
    plant: BreweryModel, registry: DeviceRegistry, blueprint: PlantBlueprint = SHEFFIELD_BLUEPRINT,
) -> Tuple[RulesEngine, PIDControllerManager, SafetySystem]:
    """Wire up the baseline rules, PID loops and safety system that ship
    with the Sheffield reference model. A deployment can start from this
    and layer site-specific automation on top."""

    rules = RulesEngine()
    pid_manager = PIDControllerManager()
    safety = SafetySystem(plant, blueprint.safety)

    hlt = plant.tank_by_name("Hot Liquor Tank")
    mash_tun = plant.tank_by_name("Mash Tun")
    boil_kettle = plant.tank_by_name("Boil Kettle")
    fermenter = plant.tank_by_name("Fermenter")

    def find_pump(name: str):
        return next((p for p in plant.pumps.values() if p.name == name), None)

    def find_heater(name: str):
        return next((h for h in plant.heaters.values() if h.name == name), None)

    def find_cooler(name: str):
        return next((c for c in plant.coolers.values() if c.name == name), None)

    mains_pump = find_pump("Mains Water Fill Pump")
    if hlt is not None and mains_pump is not None:
        mains_actuator = registry.get_actuator(f"{mains_pump.id}:cmd")
        rules.add_rule(Rule(
            name="hlt_auto_fill",
            description="Keep the hot liquor tank topped up from mains",
            condition=lambda state: hlt.fill_fraction < 0.85,
            action=lambda state, bus, reg: mains_actuator.write(100.0),
            cooldown_s=2.0,
        ))
        rules.add_rule(Rule(
            name="hlt_stop_fill",
            description="Stop mains fill once the HLT is full enough",
            condition=lambda state: hlt.fill_fraction >= 0.9,
            action=lambda state, bus, reg: mains_actuator.write(0.0),
            cooldown_s=2.0,
        ))

    if mash_tun is not None:
        mash_heater = find_heater("Mash Tun Heater")
        if mash_heater is not None:
            controller = PIDController("mash_tun_temperature", kp=8.0, ki=0.05, kd=1.0,
                                        setpoint=blueprint.mash_temperature_setpoint_c,
                                        output_min=0.0, output_max=100.0, integral_limit=200.0)
            actuator = registry.get_actuator(f"{mash_heater.id}:cmd")
            pid_manager.add_loop(PIDLoop(controller, measure=lambda: mash_tun.temperature_c,
                                          actuate=actuator.write))

    if boil_kettle is not None:
        kettle_heater = find_heater("Boil Kettle Heater")
        if kettle_heater is not None:
            controller = PIDController("boil_kettle_temperature", kp=10.0, ki=0.08, kd=1.5,
                                        setpoint=blueprint.boil_temperature_setpoint_c,
                                        output_min=0.0, output_max=100.0, integral_limit=200.0)
            actuator = registry.get_actuator(f"{kettle_heater.id}:cmd")
            pid_manager.add_loop(PIDLoop(controller, measure=lambda: boil_kettle.temperature_c,
                                          actuate=actuator.write))

    if fermenter is not None:
        ferm_cooler = find_cooler("Fermenter Glycol Jacket")
        if ferm_cooler is not None:
            # Cooling output should ramp UP as temperature rises above
            # setpoint (the opposite sense to a heater), so both the
            # setpoint and the measurement are negated to reuse the same
            # PID error convention (error = setpoint - measurement).
            controller = PIDController("fermenter_temperature", kp=6.0, ki=0.03, kd=0.5,
                                        setpoint=-blueprint.fermenter_temperature_setpoint_c,
                                        output_min=0.0, output_max=100.0, integral_limit=200.0)
            actuator = registry.get_actuator(f"{ferm_cooler.id}:cmd")
            pid_manager.add_loop(PIDLoop(controller, measure=lambda: -fermenter.temperature_c,
                                          actuate=actuator.write))

    return rules, pid_manager, safety
