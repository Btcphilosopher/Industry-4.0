"""Converts a software plant model into a deployable plant configuration.

This is the "software model -> real brewery" seam: given a
:class:`PlantBlueprint`, generate the IoT device map, addressing scheme
and control schema needed to stand up a new physical site, and support
scaling the reference model to a different capacity or replicating it
across multiple geographies.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List

from sheffield_iot_brewery.iot.device_registry import DeviceRegistry
from sheffield_iot_brewery.integration.protocol_adapter import ProtocolAdapter
from sheffield_iot_brewery.replication.factory_blueprint import PlantBlueprint, build_plant


@dataclass
class SiteSpec:
    site_name: str
    scale_factor: float = 1.0
    location: str = ""


@dataclass
class DeploymentConfig:
    site_name: str
    location: str
    scale_factor: float
    plant_summary: Dict[str, int]
    equipment: List[Dict[str, Any]]
    device_map: List[Dict[str, Any]]
    modbus_registers: Dict[str, int]
    control_schema: Dict[str, Any]
    topology: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "site_name": self.site_name,
            "location": self.location,
            "scale_factor": self.scale_factor,
            "plant_summary": self.plant_summary,
            "equipment": self.equipment,
            "device_map": self.device_map,
            "modbus_registers": self.modbus_registers,
            "control_schema": self.control_schema,
            "topology": self.topology,
        }

    def save(self, path: str) -> None:
        Path(path).write_text(json.dumps(self.to_dict(), indent=2))


class DeploymentEngine:
    """Generates deployable configuration from a declarative blueprint."""

    def generate_deployment(self, blueprint: PlantBlueprint, site: SiteSpec) -> DeploymentConfig:
        scaled = blueprint.scaled(site.scale_factor, name=site.site_name)
        plant = build_plant(scaled)
        registry = DeviceRegistry.from_plant(plant)
        adapter = ProtocolAdapter(plant_name=site.site_name)

        equipment = [
            {"id": e.id, "name": e.name, "type": e.equipment_type.value}
            for e in plant.all_equipment()
        ]

        device_map = []
        for device_id, sensor in registry.sensors.items():
            device_map.append({
                "device_id": device_id,
                "kind": "sensor",
                "measurement": sensor.sensor_type.value,
                "unit": sensor.unit,
                "mqtt_topic": adapter.to_mqtt_topic(registry.equipment_of[device_id],
                                                     sensor.sensor_type.value),
            })
        for device_id, actuator in registry.actuators.items():
            device_map.append({
                "device_id": device_id,
                "kind": "actuator",
                "measurement": actuator.actuator_type.value,
                "mqtt_topic": adapter.to_mqtt_topic(registry.equipment_of[device_id], "command"),
            })

        modbus_registers = adapter.to_modbus_registers(list(registry.all_devices()))

        control_schema = self._control_schema(scaled)

        return DeploymentConfig(
            site_name=site.site_name,
            location=site.location,
            scale_factor=site.scale_factor,
            plant_summary=plant.summary(),
            equipment=equipment,
            device_map=device_map,
            modbus_registers=modbus_registers,
            control_schema=control_schema,
            topology=plant.topology.to_dict(),
        )

    def replicate(self, blueprint: PlantBlueprint, sites: List[SiteSpec]) -> List[DeploymentConfig]:
        """Generate deployment configs for multiple sites/scales at once —
        the "replicate the Sheffield model across facilities" feature."""
        return [self.generate_deployment(blueprint, site) for site in sites]

    @staticmethod
    def _control_schema(blueprint: PlantBlueprint) -> Dict[str, Any]:
        return {
            "mash_temperature_setpoint_c": blueprint.mash_temperature_setpoint_c,
            "boil_temperature_setpoint_c": blueprint.boil_temperature_setpoint_c,
            "fermenter_temperature_setpoint_c": blueprint.fermenter_temperature_setpoint_c,
            "safety": {
                "max_tank_fill_fraction": blueprint.safety.max_tank_fill_fraction,
                "min_tank_fill_fraction": blueprint.safety.min_tank_fill_fraction,
                "max_process_temperature_c": blueprint.safety.max_process_temperature_c,
                "min_process_temperature_c": blueprint.safety.min_process_temperature_c,
                "thermal_rate_limit_c_per_min": blueprint.safety.thermal_rate_limit_c_per_min,
            },
            "rules": [
                "hlt_auto_fill", "hlt_stop_fill",
            ],
            "pid_loops": [
                "mash_tun_temperature", "boil_kettle_temperature", "fermenter_temperature",
            ],
        }
