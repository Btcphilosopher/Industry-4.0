"""Resource allocation system.

When simultaneous demand for a shared, finite resource (typically
electrical power) exceeds supply, this proportionally scales back the
lowest-priority consumers first, so the plant degrades gracefully
instead of tripping a breaker or blowing a safety interlock.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List


@dataclass
class PowerDemand:
    device_id: str
    requested_kw: float
    priority: int = 0  # higher = served first


@dataclass
class LoadBalancer:
    max_total_power_kw: float

    def allocate(self, demands: List[PowerDemand]) -> Dict[str, float]:
        """Return device_id -> allotted_kw, respecting max_total_power_kw.

        Higher-priority demands are satisfied first; if the budget runs
        out mid-priority-tier, that tier is scaled down proportionally
        so no single device is unfairly starved within its own tier.
        """
        allocation: Dict[str, float] = {d.device_id: 0.0 for d in demands}
        remaining = max(0.0, self.max_total_power_kw)

        tiers: Dict[int, List[PowerDemand]] = {}
        for d in demands:
            tiers.setdefault(d.priority, []).append(d)

        for priority in sorted(tiers.keys(), reverse=True):
            tier = tiers[priority]
            tier_request = sum(d.requested_kw for d in tier)
            if tier_request <= remaining:
                for d in tier:
                    allocation[d.device_id] = d.requested_kw
                remaining -= tier_request
            else:
                scale = (remaining / tier_request) if tier_request > 0 else 0.0
                for d in tier:
                    allocation[d.device_id] = d.requested_kw * scale
                remaining = 0.0

        return allocation

    @staticmethod
    def duty_cycle_from_allocation(requested_kw: float, allotted_kw: float,
                                    requested_duty_pct: float) -> float:
        """Scale a requested duty cycle down in proportion to a power cut."""
        if requested_kw <= 0:
            return 0.0
        ratio = max(0.0, min(1.0, allotted_kw / requested_kw))
        return requested_duty_pct * ratio
