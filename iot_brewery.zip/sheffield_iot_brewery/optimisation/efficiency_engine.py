"""Throughput and efficiency optimisation.

Derives operational KPIs from the telemetry history: litres processed,
energy consumed, and process efficiency ratios. Used both live (to
surface on the dashboard) and offline (to compare simulation runs when
tuning automation logic before deployment).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict

from sheffield_iot_brewery.monitoring.telemetry import TelemetryCollector
from sheffield_iot_brewery.plant.brewery_model import BreweryModel


@dataclass
class EfficiencyReport:
    total_energy_kwh: float
    total_throughput_l: float
    average_fill_fraction: float
    energy_per_litre_kwh: float
    uptime_fraction: float


class EfficiencyEngine:
    def __init__(self, plant: BreweryModel, telemetry: TelemetryCollector):
        self.plant = plant
        self.telemetry = telemetry

    def _energy_kwh_for(self, key_prefix: str, power_kw: float) -> float:
        """Integrate a duty-cycle series (0-100) into kWh, given the
        device's rated power and the sample spacing recorded in telemetry."""
        series = self.telemetry.get_series(key_prefix)
        if len(series) < 2:
            return 0.0
        energy = 0.0
        for (t0, duty0), (t1, _duty1) in zip(series, series[1:]):
            dt_h = max(0.0, (t1 - t0)) / 3600.0
            energy += power_kw * (duty0 / 100.0) * dt_h
        return energy

    def report(self) -> EfficiencyReport:
        total_energy = 0.0
        for heater in self.plant.heaters.values():
            total_energy += self._energy_kwh_for(f"actuator.{heater.id}:cmd", heater.power_kw)
        for cooler in self.plant.coolers.values():
            total_energy += self._energy_kwh_for(f"actuator.{cooler.id}:cmd",
                                                   cooler.cooling_power_kw)

        total_throughput = 0.0
        for pump in self.plant.pumps.values():
            series = self.telemetry.get_series(f"sensor.{pump.id}:flow")
            for (t0, f0), (t1, _f1) in zip(series, series[1:]):
                dt_min = max(0.0, (t1 - t0)) / 60.0
                total_throughput += f0 * dt_min

        fill_fractions = [t.fill_fraction for t in self.plant.tanks.values()]
        avg_fill = sum(fill_fractions) / len(fill_fractions) if fill_fractions else 0.0

        running_pumps = sum(1 for p in self.plant.pumps.values() if p.running)
        uptime = running_pumps / len(self.plant.pumps) if self.plant.pumps else 0.0

        energy_per_litre = (total_energy / total_throughput) if total_throughput > 0 else 0.0

        return EfficiencyReport(
            total_energy_kwh=round(total_energy, 4),
            total_throughput_l=round(total_throughput, 2),
            average_fill_fraction=round(avg_fill, 4),
            energy_per_litre_kwh=round(energy_per_litre, 6),
            uptime_fraction=round(uptime, 4),
        )

    def per_equipment_summary(self) -> Dict[str, Dict[str, float]]:
        return {
            key: self.telemetry.summary(key)
            for key in self.telemetry.all_keys()
            if key.startswith("sensor.")
        }
