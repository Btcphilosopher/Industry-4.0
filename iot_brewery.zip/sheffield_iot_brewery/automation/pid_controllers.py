"""Closed-loop PID control for continuous process variables.

Used for things like holding a mash tun or boil kettle at a target
temperature by modulating heater duty cycle.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, Optional

from sheffield_iot_brewery.utils.math_utils import clamp


@dataclass
class PIDController:
    name: str
    kp: float
    ki: float
    kd: float
    setpoint: float
    output_min: float = 0.0
    output_max: float = 100.0
    integral_limit: Optional[float] = None

    _integral: float = field(default=0.0, init=False)
    _previous_error: Optional[float] = field(default=None, init=False)
    last_output: float = field(default=0.0, init=False)
    last_error: float = field(default=0.0, init=False)

    def reset(self) -> None:
        self._integral = 0.0
        self._previous_error = None
        self.last_output = 0.0

    def compute(self, measurement: float, dt: float) -> float:
        if dt <= 0:
            return self.last_output

        error = self.setpoint - measurement

        self._integral += error * dt
        if self.integral_limit is not None:
            self._integral = clamp(self._integral, -self.integral_limit, self.integral_limit)

        derivative = 0.0
        if self._previous_error is not None:
            derivative = (error - self._previous_error) / dt

        raw_output = (self.kp * error) + (self.ki * self._integral) + (self.kd * derivative)
        output = clamp(raw_output, self.output_min, self.output_max)

        # anti-windup: if the raw (pre-clamp) output saturates, undo this
        # step's integral contribution so it doesn't keep growing while clamped.
        if raw_output != output and self.ki != 0:
            self._integral -= error * dt

        self._previous_error = error
        self.last_error = error
        self.last_output = output
        return output


@dataclass
class PIDLoop:
    """Binds a PID controller to live measurement/actuator functions."""

    controller: PIDController
    measure: Callable[[], float]
    actuate: Callable[[float], None]
    enabled: bool = True

    def step(self, dt: float) -> float:
        if not self.enabled:
            return self.controller.last_output
        measurement = self.measure()
        output = self.controller.compute(measurement, dt)
        self.actuate(output)
        return output


class PIDControllerManager:
    """Holds and steps every PID loop registered in the plant."""

    def __init__(self) -> None:
        self._loops: Dict[str, PIDLoop] = {}

    def add_loop(self, loop: PIDLoop) -> None:
        self._loops[loop.controller.name] = loop

    def get(self, name: str) -> Optional[PIDLoop]:
        return self._loops.get(name)

    def set_enabled(self, name: str, enabled: bool) -> None:
        loop = self._loops.get(name)
        if loop:
            loop.enabled = enabled

    def set_setpoint(self, name: str, setpoint: float) -> None:
        loop = self._loops.get(name)
        if loop:
            loop.controller.setpoint = setpoint

    def step_all(self, dt: float) -> Dict[str, float]:
        return {name: loop.step(dt) for name, loop in self._loops.items()}

    def disable_all(self) -> None:
        for loop in self._loops.values():
            loop.enabled = False
            loop.actuate(0.0)
