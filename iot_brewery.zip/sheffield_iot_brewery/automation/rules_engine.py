"""Event-driven, rule-based automation logic.

Rules are simple condition/action pairs evaluated every control loop
tick against the live :class:`StateManager`. This is the layer that
implements requirements like:

    IF tank level < threshold -> activate pump
    IF temperature > limit -> activate cooling
    IF overflow risk -> emergency shutdown (delegated to SafetySystem)
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Callable, List, Optional

from sheffield_iot_brewery.core.event_bus import EventBus
from sheffield_iot_brewery.core.state_manager import StateManager
from sheffield_iot_brewery.iot.device_registry import DeviceRegistry

Condition = Callable[[StateManager], bool]
Action = Callable[[StateManager, EventBus, DeviceRegistry], None]


@dataclass
class Rule:
    name: str
    condition: Condition
    action: Action
    cooldown_s: float = 0.0
    enabled: bool = True
    description: str = ""

    _last_fired_at: Optional[float] = field(default=None, init=False, repr=False)
    fire_count: int = field(default=0, init=False)

    def _on_cooldown(self, now: float) -> bool:
        if self._last_fired_at is None:
            return False
        return (now - self._last_fired_at) < self.cooldown_s

    def try_fire(self, state: StateManager, bus: EventBus, registry: DeviceRegistry) -> bool:
        if not self.enabled:
            return False
        now = time.time()
        if self._on_cooldown(now):
            return False
        try:
            triggered = self.condition(state)
        except Exception as exc:  # defensive: a bad rule must not crash the loop
            bus.publish("rule.error", {"rule": self.name, "error": str(exc)})
            return False
        if not triggered:
            return False

        self._last_fired_at = now
        self.fire_count += 1
        self.action(state, bus, registry)
        bus.publish("rule.fired", {"rule": self.name, "fire_count": self.fire_count})
        return True


class RulesEngine:
    def __init__(self) -> None:
        self._rules: List[Rule] = []

    def add_rule(self, rule: Rule) -> Rule:
        self._rules.append(rule)
        return rule

    def remove_rule(self, name: str) -> None:
        self._rules = [r for r in self._rules if r.name != name]

    def get(self, name: str) -> Optional[Rule]:
        return next((r for r in self._rules if r.name == name), None)

    def set_enabled(self, name: str, enabled: bool) -> None:
        rule = self.get(name)
        if rule:
            rule.enabled = enabled

    @property
    def rules(self) -> List[Rule]:
        return list(self._rules)

    def evaluate(self, state: StateManager, bus: EventBus, registry: DeviceRegistry) -> List[str]:
        """Evaluate every rule once; returns the names of rules that fired."""
        fired = []
        for rule in self._rules:
            if rule.try_fire(state, bus, registry):
                fired.append(rule.name)
        return fired
