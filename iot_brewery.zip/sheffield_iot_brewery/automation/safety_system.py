"""Emergency shutdown logic and safety interlocks.

This is the highest-priority subsystem in the control loop: it runs
after rules/PID have proposed actuator commands but before those
commands are actually sent, so it can veto or override anything that
would put the plant in an unsafe state (overflow, thermal runaway).
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional

from sheffield_iot_brewery.core.event_bus import EventBus
from sheffield_iot_brewery.core.state_manager import StateManager
from sheffield_iot_brewery.iot.device_registry import DeviceRegistry
from sheffield_iot_brewery.plant.brewery_model import BreweryModel
from sheffield_iot_brewery.utils.config import SafetyConfig


class Severity(str, Enum):
    WARNING = "warning"
    CRITICAL = "critical"


@dataclass
class SafetyViolation:
    tank_or_device_id: str
    kind: str
    severity: Severity
    message: str
    value: float
    limit: float
    timestamp: float = field(default_factory=time.time)


class SafetySystem:
    """Overflow prevention, thermal protection and fault detection."""

    def __init__(self, plant: BreweryModel, config: Optional[SafetyConfig] = None):
        self.plant = plant
        self.config = config or SafetyConfig()
        self.shutdown_active = False
        self.violation_log: List[SafetyViolation] = []

    # -- checks ----------------------------------------------------------
    def check(self) -> List[SafetyViolation]:
        violations: List[SafetyViolation] = []
        for tank in self.plant.tanks.values():
            if tank.fill_fraction >= self.config.max_tank_fill_fraction:
                violations.append(SafetyViolation(
                    tank.id, "overflow_risk", Severity.CRITICAL,
                    f"{tank.name} at {tank.fill_fraction:.0%} capacity",
                    tank.level_l, self.config.max_tank_fill_fraction * tank.capacity_l,
                ))
            if tank.temperature_c >= self.config.max_process_temperature_c:
                violations.append(SafetyViolation(
                    tank.id, "over_temperature", Severity.CRITICAL,
                    f"{tank.name} at {tank.temperature_c:.1f}C",
                    tank.temperature_c, self.config.max_process_temperature_c,
                ))
            elif tank.temperature_c <= self.config.min_process_temperature_c:
                violations.append(SafetyViolation(
                    tank.id, "under_temperature", Severity.WARNING,
                    f"{tank.name} at {tank.temperature_c:.1f}C",
                    tank.temperature_c, self.config.min_process_temperature_c,
                ))
        self.violation_log.extend(violations)
        return violations

    # -- enforcement -------------------------------------------------------
    def enforce(self, state: StateManager, bus: EventBus, registry: DeviceRegistry) -> List[SafetyViolation]:
        """Run checks and apply protective overrides. Call every tick,
        after rules/PID have proposed commands but before/along with
        sending them, so interlocks always have the final say."""
        violations = self.check()

        for tank in self.plant.tanks.values():
            if tank.fill_fraction >= self.config.max_tank_fill_fraction:
                self._stop_inflows_to(tank, registry)
                bus.publish("safety.overflow_prevented", {"tank": tank.id}, source="safety")

            if tank.temperature_c >= self.config.max_process_temperature_c:
                self._thermal_protect(tank, registry)
                bus.publish("safety.thermal_protection", {"tank": tank.id}, source="safety")

        critical = [v for v in violations if v.severity == Severity.CRITICAL]
        state.set("safety.violations", [v.message for v in violations])
        state.set("safety.critical_count", len(critical))
        return violations

    def _stop_inflows_to(self, tank, registry: DeviceRegistry) -> None:
        for pump in self.plant.pumps.values():
            if pump.destination is tank:
                actuator = registry.get_actuator(f"{pump.id}:cmd")
                if actuator:
                    actuator.write(0.0)
        for valve in self.plant.valves.values():
            if valve.downstream is tank:
                actuator = registry.get_actuator(f"{valve.id}:cmd")
                if actuator:
                    actuator.write(0.0)

    def _thermal_protect(self, tank, registry: DeviceRegistry) -> None:
        for heater in self.plant.heaters.values():
            if heater.tank is tank:
                actuator = registry.get_actuator(f"{heater.id}:cmd")
                if actuator:
                    actuator.write(0.0)
        for cooler in self.plant.coolers.values():
            if cooler.tank is tank:
                actuator = registry.get_actuator(f"{cooler.id}:cmd")
                if actuator:
                    actuator.write(100.0)

    # -- emergency shutdown -----------------------------------------------
    def emergency_shutdown(self, state: StateManager, bus: EventBus,
                            registry: DeviceRegistry, reason: str = "manual") -> None:
        """Stop every actuator in the plant immediately."""
        self.shutdown_active = True
        for pump in self.plant.pumps.values():
            actuator = registry.get_actuator(f"{pump.id}:cmd")
            if actuator:
                actuator.write(0.0)
        for valve in self.plant.valves.values():
            actuator = registry.get_actuator(f"{valve.id}:cmd")
            if actuator:
                actuator.write(0.0)
        for heater in self.plant.heaters.values():
            actuator = registry.get_actuator(f"{heater.id}:cmd")
            if actuator:
                actuator.write(0.0)
        for cooler in self.plant.coolers.values():
            actuator = registry.get_actuator(f"{cooler.id}:cmd")
            if actuator:
                actuator.write(0.0)
        state.set("safety.shutdown_active", True)
        state.set("safety.shutdown_reason", reason)
        bus.publish("safety.emergency_shutdown", {"reason": reason}, source="safety")

    def reset(self) -> None:
        self.shutdown_active = False
        self.violation_log.clear()
