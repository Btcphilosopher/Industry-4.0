"""Multi-system coordination: sequences process phases across the plant.

A brew is not one continuous control problem — it's a sequence of
phases (mash, lauter, boil, whirlpool, ferment) each with its own
setpoints and active equipment. The orchestrator is a light state
machine that walks through phases, adjusting PID setpoints and
enabling/disabling rules as it goes, so those subsystems don't need to
know about "the recipe" themselves.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, List, Optional

from sheffield_iot_brewery.automation.pid_controllers import PIDControllerManager
from sheffield_iot_brewery.automation.rules_engine import RulesEngine
from sheffield_iot_brewery.core.event_bus import EventBus
from sheffield_iot_brewery.core.state_manager import StateManager


class ProcessPhase(str, Enum):
    IDLE = "idle"
    MASH = "mash"
    LAUTER = "lauter"
    BOIL = "boil"
    WHIRLPOOL = "whirlpool"
    FERMENT = "ferment"
    COMPLETE = "complete"


@dataclass
class PhaseDefinition:
    phase: ProcessPhase
    on_enter: Callable[[PIDControllerManager, RulesEngine], None]
    is_complete: Callable[[StateManager], bool]
    min_duration_s: float = 0.0


@dataclass
class Orchestrator:
    """Advances a plant through an ordered list of process phases."""

    phases: List[PhaseDefinition] = field(default_factory=list)
    current_index: int = field(default=-1, init=False)
    _phase_started_at: float = field(default=0.0, init=False)

    def add_phase(self, phase_def: PhaseDefinition) -> None:
        self.phases.append(phase_def)

    @property
    def current_phase(self) -> ProcessPhase:
        if self.current_index < 0 or self.current_index >= len(self.phases):
            return ProcessPhase.IDLE if self.current_index < 0 else ProcessPhase.COMPLETE
        return self.phases[self.current_index].phase

    def start(self, pid_manager: PIDControllerManager, rules_engine: RulesEngine,
              bus: Optional[EventBus] = None) -> None:
        self.current_index = 0
        self._enter_current(pid_manager, rules_engine, bus)

    def _enter_current(self, pid_manager: PIDControllerManager, rules_engine: RulesEngine,
                        bus: Optional[EventBus]) -> None:
        self._phase_started_at = time.time()
        if 0 <= self.current_index < len(self.phases):
            phase_def = self.phases[self.current_index]
            phase_def.on_enter(pid_manager, rules_engine)
            if bus:
                bus.publish("orchestration.phase_entered", {"phase": phase_def.phase.value})

    def step(self, state: StateManager, pid_manager: PIDControllerManager,
              rules_engine: RulesEngine, bus: Optional[EventBus] = None) -> ProcessPhase:
        """Call once per control loop tick once :meth:`start` has run."""
        if self.current_index < 0 or self.current_index >= len(self.phases):
            return self.current_phase

        phase_def = self.phases[self.current_index]
        elapsed = time.time() - self._phase_started_at
        state.set("orchestration.phase", phase_def.phase.value)
        state.set("orchestration.phase_elapsed_s", elapsed)

        if elapsed >= phase_def.min_duration_s and phase_def.is_complete(state):
            self.current_index += 1
            self._enter_current(pid_manager, rules_engine, bus)

        return self.current_phase

    def is_finished(self) -> bool:
        return self.current_index >= len(self.phases)
