"""CLI entrypoint for the Sheffield IoT Brewery control platform.

Examples
--------
Run a 5-minute simulated brew day, printing the dashboard every 30 ticks::

    python -m sheffield_iot_brewery.main --mode simulation --ticks 300 \\
        --dashboard-every 30

Generate a deployment configuration for a new site at 1.5x capacity::

    python -m sheffield_iot_brewery.main --deploy --site "Leeds Site A" \\
        --scale 1.5 --out leeds_deployment.json
"""
from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

if __package__ in (None, ""):
    # Allow `python main.py` / `python sheffield_iot_brewery/main.py` by
    # putting the repo root (this package's parent) on sys.path. The
    # preferred invocation is `python -m sheffield_iot_brewery.main`.
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from sheffield_iot_brewery.core.control_loop import ControlLoop
from sheffield_iot_brewery.core.event_bus import EventBus
from sheffield_iot_brewery.core.state_manager import StateManager
from sheffield_iot_brewery.iot.device_registry import DeviceRegistry
from sheffield_iot_brewery.monitoring.alerts import AlertManager, ThresholdRule, AlertSeverity
from sheffield_iot_brewery.monitoring.dashboard import DashboardRenderer
from sheffield_iot_brewery.monitoring.telemetry import TelemetryCollector
from sheffield_iot_brewery.optimisation.efficiency_engine import EfficiencyEngine
from sheffield_iot_brewery.replication.deployment_engine import DeploymentEngine, SiteSpec
from sheffield_iot_brewery.replication.factory_blueprint import (SHEFFIELD_BLUEPRINT,
                                                                   build_plant,
                                                                   configure_default_automation)
from sheffield_iot_brewery.simulation.plant_simulator import PlantSimulator
from sheffield_iot_brewery.simulation.timestep_engine import TimestepEngine
from sheffield_iot_brewery.utils.config import OperatingMode, PlantConfig


def build_default_platform(config: PlantConfig):
    plant = build_plant(SHEFFIELD_BLUEPRINT)
    registry = DeviceRegistry.from_plant(plant, sensor_noise_std=0.05)
    rules, pid_manager, safety = configure_default_automation(plant, registry, SHEFFIELD_BLUEPRINT)

    bus = EventBus()
    state = StateManager()
    telemetry = TelemetryCollector(window=config.telemetry.history_window,
                                    sample_every_n_ticks=config.telemetry.sample_every_n_ticks)
    simulator = PlantSimulator(plant)
    timestep = TimestepEngine(dt_seconds=config.tick_seconds, seed=config.random_seed)

    loop = ControlLoop(
        device_registry=registry, rules_engine=rules, pid_manager=pid_manager,
        safety_system=safety, state=state, bus=bus, telemetry=telemetry,
        simulator=simulator, timestep=timestep, mode=config.mode,
    )

    alerts = AlertManager(telemetry, bus)
    for tank in plant.tanks.values():
        alerts.add_threshold_rule(ThresholdRule(
            key=f"sensor.{tank.id}:level", maximum=tank.capacity_l * 0.98,
            severity=AlertSeverity.CRITICAL,
        ))

    dashboard = DashboardRenderer(plant)
    efficiency = EfficiencyEngine(plant, telemetry)

    return {
        "plant": plant, "registry": registry, "loop": loop, "alerts": alerts,
        "dashboard": dashboard, "efficiency": efficiency, "state": state, "bus": bus,
    }


def run_control_loop(args: argparse.Namespace) -> None:
    config = PlantConfig(mode=OperatingMode(args.mode), tick_seconds=args.tick_seconds,
                          random_seed=args.seed, max_ticks=args.ticks, realtime=args.realtime)
    platform = build_default_platform(config)
    loop: ControlLoop = platform["loop"]
    alerts: AlertManager = platform["alerts"]
    dashboard: DashboardRenderer = platform["dashboard"]

    def on_tick(control_loop: ControlLoop) -> None:
        alerts.evaluate()
        if control_loop.timestep.tick_count % max(1, args.dashboard_every) == 0:
            print(dashboard.render_text(alerts.snapshot(), control_loop.mode.value,
                                         control_loop.timestep.tick_count))
            print()

    loop.run(max_ticks=args.ticks, realtime=args.realtime, on_tick=on_tick)

    print(dashboard.render_text(alerts.snapshot(), loop.mode.value, loop.timestep.tick_count))
    report = platform["efficiency"].report()
    print("\n=== Efficiency Report ===")
    for key, value in report.__dict__.items():
        print(f"  {key}: {value}")


def run_deployment(args: argparse.Namespace) -> None:
    engine = DeploymentEngine()
    site = SiteSpec(site_name=args.site, scale_factor=args.scale, location=args.location)
    deployment = engine.generate_deployment(SHEFFIELD_BLUEPRINT, site)
    if args.out:
        deployment.save(args.out)
        print(f"Deployment configuration written to {args.out}")
    else:
        import json
        print(json.dumps(deployment.to_dict(), indent=2))


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Sheffield IoT Brewery control platform")
    parser.add_argument("--mode", choices=["simulation", "live", "hybrid"], default="simulation")
    parser.add_argument("--ticks", type=int, default=120, help="max control loop ticks to run")
    parser.add_argument("--tick-seconds", type=float, default=1.0, help="seconds of simulated "
                         "time advanced per tick")
    parser.add_argument("--realtime", action="store_true", help="sleep tick-seconds between "
                         "ticks instead of running as fast as possible")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--dashboard-every", type=int, default=20)
    parser.add_argument("--verbose", action="store_true")

    parser.add_argument("--deploy", action="store_true", help="generate a deployment config "
                         "instead of running the control loop")
    parser.add_argument("--site", default="New Brewery Site")
    parser.add_argument("--location", default="")
    parser.add_argument("--scale", type=float, default=1.0)
    parser.add_argument("--out", default=None, help="write deployment JSON to this path")
    return parser


def main(argv=None) -> int:
    parser = build_arg_parser()
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.WARNING)

    if args.deploy:
        run_deployment(args)
    else:
        run_control_loop(args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
