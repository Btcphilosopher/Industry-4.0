# Sheffield IoT Brewery — Industry 4.0 Autonomous Plant Platform

A production-grade Python platform that **simulates, monitors, and
actively controls** a fully automated brewery/distillery plant. It acts
as both:

- 🧠 a real-time IoT control system, and
- 🏭 a process simulation + optimisation engine.

Core design principle: **the same system that simulates the plant can
run it.** Every subsystem (rules, PID loops, safety interlocks) talks to
the same `DeviceRegistry` / `StateManager` interfaces whether the plant
behind them is virtual (`SIMULATION`), real (`LIVE`), or a mix of both
(`HYBRID`).

## Architecture

```
sheffield_iot_brewery/
├── core/            real-time control loop, live state registry, event bus
├── plant/           physical plant structure: tanks, pumps, valves, heaters, topology
├── iot/             sensor/actuator abstraction, device registry, simulated MQTT comms
├── automation/       rules engine, PID controllers, safety system, phase orchestration
├── simulation/      deterministic timestep engine + virtual plant physics
├── optimisation/    throughput/efficiency metrics, power load balancing
├── replication/     the Sheffield reference blueprint + deployment engine
├── monitoring/      telemetry collector, anomaly alerts, text/JSON dashboard
├── integration/     hardware interface (mockable) + MQTT/REST/Modbus addressing
├── utils/           config, math helpers
├── main.py          CLI entrypoint
└── tests/           pytest suite covering every layer
```

## The control loop

```python
while system_running:
    read_all_sensors()
    evaluate_automation_rules()
    update_pid_controllers()
    send_commands_to_actuators()   # safety system has final say here
    update_simulated_physics()     # skipped entirely in LIVE mode
    log_system_state()
```

See `core/control_loop.py`. Runs in three modes:

- **SIMULATION** — no hardware; `simulation/plant_simulator.py` advances
  tank levels/temperatures using flow and heat-transfer abstractions.
- **LIVE** — real hardware only, via an
  `integration.hardware_interface.HardwareInterface` implementation.
- **HYBRID** — real devices where available, simulated physics filling
  in the rest, for validating automation against a partial rig.

## Quick start

```bash
cd solar-battery.os          # repo root (parent of this package)
pip install -r sheffield_iot_brewery/requirements.txt

# Run a simulated brew day
python -m sheffield_iot_brewery.main --mode simulation --ticks 300 --dashboard-every 30

# Generate a deployment config for a new site at 1.5x capacity
python -m sheffield_iot_brewery.main --deploy --site "Leeds Site A" --scale 1.5 \
    --out leeds_deployment.json

# Run the test suite
python -m pytest sheffield_iot_brewery/tests -q
```

## The Sheffield reference model

`replication/factory_blueprint.py` declares the canonical plant as a
serialisable `PlantBlueprint`: Hot Liquor Tank → Mash Tun → Lauter Tun →
Boil Kettle → Whirlpool → Fermenter → Bright Tank, wired with pumps,
valves, heaters and glycol coolers, plus baseline automation (mains
auto-fill rules, mash/boil temperature PID loops, fermenter cooling PID).

`replication/deployment_engine.py` turns that blueprint into a
deployable configuration: scaled equipment, an IoT device map with MQTT
topics and synthetic Modbus register addresses, and the control schema
(setpoints, safety limits, active rules/PID loops) — everything needed
to stand up a new physical site or replicate the model across
facilities at a different capacity.

## Safety system

`automation/safety_system.py` runs every tick, after rules/PID have
proposed actuator commands but before they're committed, so it always
has the final say:

- **Overflow prevention** — stops every pump/valve feeding a tank once
  it crosses `max_tank_fill_fraction`.
- **Thermal protection** — kills heaters and forces coolers to 100% once
  a tank exceeds `max_process_temperature_c`.
- **Emergency shutdown** — `emergency_shutdown()` stops every actuator
  in the plant immediately; the control loop calls this automatically
  on `KeyboardInterrupt`.

## Going from simulation to a real plant

1. Tune rules, PID gains and safety limits against the simulator using
   `main.py --mode simulation`.
2. Implement `integration.hardware_interface.RealHardwareInterface`
   against your fieldbus/OPC-UA/Modbus driver, using the device
   addresses from `replication/deployment_engine.py`.
3. Switch `--mode live` (or `hybrid` while commissioning) — the rules
   engine, PID loops and safety system are unchanged; only where sensor
   values come from and where actuator commands go has changed.

## Zero required third-party dependencies

The platform runs on the standard library alone (`pytest` only for
tests). `pyyaml` and `paho-mqtt` are optional: install them to load YAML
config files or bridge to a real MQTT broker — both are imported lazily
and the platform falls back to JSON config / an in-process simulated
broker when they're absent.
