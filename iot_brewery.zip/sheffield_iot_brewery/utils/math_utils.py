"""Small numerical helpers shared across the platform.

Kept dependency-free (no numpy) so the platform can run on minimal
embedded/edge Python installs as well as full servers.
"""
from __future__ import annotations

from collections import deque
from typing import Deque, Iterable


def clamp(value: float, minimum: float, maximum: float) -> float:
    """Clamp ``value`` to the inclusive ``[minimum, maximum]`` range."""
    if minimum > maximum:
        minimum, maximum = maximum, minimum
    return max(minimum, min(maximum, value))


def lerp(a: float, b: float, t: float) -> float:
    """Linearly interpolate between ``a`` and ``b`` at fraction ``t``."""
    return a + (b - a) * clamp(t, 0.0, 1.0)


def c_to_k(celsius: float) -> float:
    return celsius + 273.15


def k_to_c(kelvin: float) -> float:
    return kelvin - 273.15


def exponential_decay_toward(current: float, target: float, rate: float, dt: float) -> float:
    """Move ``current`` toward ``target`` following first-order decay.

    ``rate`` is a per-second decay constant. Used to model passive heat
    loss/gain toward ambient temperature, or any relaxation process.
    """
    if dt <= 0:
        return current
    factor = 1.0 - pow(2.718281828459045, -rate * dt)
    return current + (target - current) * clamp(factor, 0.0, 1.0)


def energy_balance_mix(volume_a: float, temp_a: float, volume_b: float, temp_b: float) -> float:
    """Return the resulting temperature of mixing two liquid volumes.

    Simple mass/energy-weighted average; assumes equal specific heat and
    density for both volumes (reasonable abstraction for wort/water at
    brewery process temperatures).
    """
    total = volume_a + volume_b
    if total <= 0:
        return temp_a
    return (volume_a * temp_a + volume_b * temp_b) / total


def heater_temperature_rise_c(power_kw: float, duty_pct: float, efficiency: float,
                               mass_kg: float, dt_s: float,
                               specific_heat_j_per_kgk: float = 4186.0) -> float:
    """Temperature rise (deg C) delivered by a heater element over ``dt_s``.

    Uses Q = P * t -> dT = Q / (m * c). Water-like specific heat is used
    as the default abstraction for wort/liquor.
    """
    if mass_kg <= 0:
        return 0.0
    duty = clamp(duty_pct, 0.0, 100.0) / 100.0
    energy_joules = power_kw * 1000.0 * duty * clamp(efficiency, 0.0, 1.0) * dt_s
    return energy_joules / (mass_kg * specific_heat_j_per_kgk)


def cooler_temperature_drop_c(cooling_power_kw: float, duty_pct: float, efficiency: float,
                               mass_kg: float, dt_s: float,
                               specific_heat_j_per_kgk: float = 4186.0) -> float:
    """Temperature drop (deg C) removed by a cooling system over ``dt_s``."""
    return heater_temperature_rise_c(cooling_power_kw, duty_pct, efficiency, mass_kg, dt_s,
                                      specific_heat_j_per_kgk)


def litres_to_kg(litres: float, density_kg_per_l: float = 1.0) -> float:
    return litres * density_kg_per_l


class MovingAverage:
    """Fixed-window moving average, useful for smoothing noisy sensor reads."""

    def __init__(self, window: int = 10):
        if window < 1:
            raise ValueError("window must be >= 1")
        self.window = window
        self._values: Deque[float] = deque(maxlen=window)

    def push(self, value: float) -> float:
        self._values.append(value)
        return self.value

    @property
    def value(self) -> float:
        if not self._values:
            return 0.0
        return sum(self._values) / len(self._values)

    def reset(self) -> None:
        self._values.clear()


def mean(values: Iterable[float]) -> float:
    values = list(values)
    if not values:
        return 0.0
    return sum(values) / len(values)


def rate_of_change(previous: float, current: float, dt_s: float) -> float:
    """Instantaneous rate of change per second between two samples."""
    if dt_s <= 0:
        return 0.0
    return (current - previous) / dt_s
