"""Platform-wide configuration.

Configuration can be supplied as JSON (always available) or YAML (if
``pyyaml`` is installed — optional dependency, imported lazily so the
platform has zero hard third-party dependencies).
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, Optional


class OperatingMode(str, Enum):
    """The three operating modes required by the control loop."""

    SIMULATION = "simulation"
    LIVE = "live"
    HYBRID = "hybrid"


@dataclass
class SafetyConfig:
    max_tank_fill_fraction: float = 0.95
    min_tank_fill_fraction: float = 0.0
    overflow_margin_l: float = 5.0
    max_process_temperature_c: float = 105.0
    min_process_temperature_c: float = -5.0
    thermal_rate_limit_c_per_min: float = 15.0


@dataclass
class TelemetryConfig:
    history_window: int = 600  # samples retained per metric
    sample_every_n_ticks: int = 1


@dataclass
class PlantConfig:
    """Root configuration object for a running plant instance."""

    plant_name: str = "Sheffield Brewery Reference Plant"
    mode: OperatingMode = OperatingMode.SIMULATION
    tick_seconds: float = 1.0
    random_seed: Optional[int] = 42
    max_ticks: Optional[int] = None
    realtime: bool = False
    dashboard_every_n_ticks: int = 10
    safety: SafetyConfig = field(default_factory=SafetyConfig)
    telemetry: TelemetryConfig = field(default_factory=TelemetryConfig)

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["mode"] = self.mode.value
        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PlantConfig":
        data = dict(data)
        if "mode" in data:
            data["mode"] = OperatingMode(data["mode"])
        if "safety" in data and isinstance(data["safety"], dict):
            data["safety"] = SafetyConfig(**data["safety"])
        if "telemetry" in data and isinstance(data["telemetry"], dict):
            data["telemetry"] = TelemetryConfig(**data["telemetry"])
        return cls(**data)


def load_config(path: Optional[str] = None) -> PlantConfig:
    """Load a :class:`PlantConfig` from a JSON or YAML file.

    Falls back to defaults if ``path`` is ``None`` or the file does not
    exist. YAML is only supported when ``pyyaml`` is installed.
    """
    if not path:
        return PlantConfig()

    file_path = Path(path)
    if not file_path.exists():
        return PlantConfig()

    text = file_path.read_text()
    if file_path.suffix.lower() in (".yaml", ".yml"):
        try:
            import yaml  # type: ignore
        except ImportError as exc:  # pragma: no cover - optional dependency
            raise RuntimeError(
                "pyyaml is required to load YAML config files; install it "
                "or supply a JSON config instead"
            ) from exc
        data = yaml.safe_load(text) or {}
    else:
        data = json.loads(text) if text.strip() else {}

    return PlantConfig.from_dict(data)


def save_config(config: PlantConfig, path: str) -> None:
    Path(path).write_text(json.dumps(config.to_dict(), indent=2))
