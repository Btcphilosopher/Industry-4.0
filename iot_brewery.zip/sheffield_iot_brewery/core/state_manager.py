"""Live system state registry.

A thread-safe key/value store representing the current best-known state
of the whole plant (sensor readings, actuator positions, derived
metrics, safety flags). This is the single source of truth that every
other subsystem reads from and writes to during a control loop tick.
"""
from __future__ import annotations

import time
from collections import deque
from threading import RLock
from typing import Any, Deque, Dict, Iterable, Optional, Tuple


class StateManager:
    def __init__(self, history_per_key: int = 300) -> None:
        self._lock = RLock()
        self._state: Dict[str, Any] = {}
        self._updated_at: Dict[str, float] = {}
        self._history_per_key = history_per_key
        self._history: Dict[str, Deque[Tuple[float, Any]]] = {}

    def set(self, key: str, value: Any) -> None:
        with self._lock:
            now = time.time()
            self._state[key] = value
            self._updated_at[key] = now
            hist = self._history.setdefault(key, deque(maxlen=self._history_per_key))
            hist.append((now, value))

    def bulk_update(self, mapping: Dict[str, Any]) -> None:
        for key, value in mapping.items():
            self.set(key, value)

    def get(self, key: str, default: Any = None) -> Any:
        with self._lock:
            return self._state.get(key, default)

    def get_many(self, keys: Iterable[str]) -> Dict[str, Any]:
        with self._lock:
            return {k: self._state.get(k) for k in keys}

    def snapshot(self) -> Dict[str, Any]:
        with self._lock:
            return dict(self._state)

    def history_for(self, key: str) -> Deque[Tuple[float, Any]]:
        with self._lock:
            return deque(self._history.get(key, deque()))

    def age_seconds(self, key: str) -> Optional[float]:
        with self._lock:
            ts = self._updated_at.get(key)
            return None if ts is None else time.time() - ts

    def keys_matching(self, prefix: str) -> Iterable[str]:
        with self._lock:
            return [k for k in self._state if k.startswith(prefix)]

    def clear(self) -> None:
        with self._lock:
            self._state.clear()
            self._updated_at.clear()
            self._history.clear()
