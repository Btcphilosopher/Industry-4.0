"""Generic publish/subscribe event system used throughout the platform.

This is the internal nervous system: rule firings, alarms, mode changes
and safety trips are all published here so any subsystem (dashboard,
telemetry, orchestration) can react without being tightly coupled to
whoever raised the event.
"""
from __future__ import annotations

import fnmatch
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List

EventHandler = Callable[["Event"], None]


@dataclass
class Event:
    topic: str
    payload: Any = None
    timestamp: float = field(default_factory=time.time)
    source: str = "system"


class EventBus:
    """A minimal topic-based pub/sub bus with MQTT-style wildcards.

    ``+`` matches a single topic segment, ``#`` matches any number of
    trailing segments — mirroring MQTT semantics so the same mental
    model applies to internal events and IoT messaging (see
    :mod:`iot.comms`).
    """

    def __init__(self) -> None:
        self._subscribers: Dict[str, List[EventHandler]] = {}
        self._history: List[Event] = []
        self._history_limit = 2000

    def subscribe(self, topic_pattern: str, handler: EventHandler) -> None:
        self._subscribers.setdefault(topic_pattern, []).append(handler)

    def unsubscribe(self, topic_pattern: str, handler: EventHandler) -> None:
        handlers = self._subscribers.get(topic_pattern, [])
        if handler in handlers:
            handlers.remove(handler)

    def publish(self, topic: str, payload: Any = None, source: str = "system") -> Event:
        event = Event(topic=topic, payload=payload, source=source)
        self._history.append(event)
        if len(self._history) > self._history_limit:
            self._history.pop(0)

        for pattern, handlers in self._subscribers.items():
            if self._matches(pattern, topic):
                for handler in handlers:
                    handler(event)
        return event

    @staticmethod
    def _matches(pattern: str, topic: str) -> bool:
        if pattern == topic:
            return True
        # translate MQTT-style wildcards into fnmatch glob syntax
        glob = pattern.replace("+", "*")
        if glob.endswith("#"):
            glob = glob[:-1] + "*"
        return fnmatch.fnmatch(topic, glob)

    def history(self, topic_pattern: str = "#") -> List[Event]:
        return [e for e in self._history if self._matches(topic_pattern, e.topic)]


def topic_pattern_to_glob(pattern: str) -> str:
    glob = pattern.replace("+", "*")
    if glob.endswith("#"):
        glob = glob[:-1] + "*"
    return glob
