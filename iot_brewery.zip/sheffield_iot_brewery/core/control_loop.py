"""The real-time plant control loop.

    while system_running:
        read_all_sensors()
        evaluate_automation_rules()
        update_pid_controllers()
        send_commands_to_actuators()
        update_simulated_physics()
        log_system_state()

Supports three operating modes:

* ``SIMULATION`` - no hardware; physics is advanced by the plant simulator.
* ``LIVE`` - real hardware only; the simulator step is skipped and sensor
  refresh comes from :mod:`integration.hardware_interface`.
* ``HYBRID`` - real hardware is read/written where a
  :class:`HardwareInterface` provides it, and the simulator fills in the
  physics for whatever is not physically present, so automation logic can
  be validated against a partially real rig.
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Optional

from sheffield_iot_brewery.automation.pid_controllers import PIDControllerManager
from sheffield_iot_brewery.automation.rules_engine import RulesEngine
from sheffield_iot_brewery.automation.safety_system import SafetySystem
from sheffield_iot_brewery.core.event_bus import EventBus
from sheffield_iot_brewery.core.state_manager import StateManager
from sheffield_iot_brewery.integration.hardware_interface import HardwareInterface
from sheffield_iot_brewery.iot.device_registry import DeviceRegistry
from sheffield_iot_brewery.monitoring.telemetry import TelemetryCollector
from sheffield_iot_brewery.simulation.plant_simulator import PlantSimulator
from sheffield_iot_brewery.simulation.timestep_engine import TimestepEngine
from sheffield_iot_brewery.utils.config import OperatingMode

logger = logging.getLogger("sheffield_iot_brewery.control_loop")


@dataclass
class ControlLoop:
    device_registry: DeviceRegistry
    rules_engine: RulesEngine
    pid_manager: PIDControllerManager
    safety_system: SafetySystem
    state: StateManager
    bus: EventBus
    telemetry: TelemetryCollector
    simulator: Optional[PlantSimulator] = None
    hardware: Optional[HardwareInterface] = None
    timestep: TimestepEngine = field(default_factory=TimestepEngine)
    mode: OperatingMode = OperatingMode.SIMULATION

    def __post_init__(self) -> None:
        self._running = False
        self.state.set("mode", self.mode.value)
        self.state.set("shutdown_active", False)

    # -- individual loop stages --------------------------------------
    def read_all_sensors(self) -> None:
        if self.mode in (OperatingMode.LIVE, OperatingMode.HYBRID) and self.hardware is not None:
            self.hardware.refresh(self.device_registry)
        readings = self.device_registry.read_all()
        self.state.bulk_update({f"sensor.{k}": v for k, v in readings.items()})

    def evaluate_automation_rules(self) -> list:
        return self.rules_engine.evaluate(self.state, self.bus, self.device_registry)

    def update_pid_controllers(self) -> dict:
        if self.safety_system.shutdown_active:
            return {}
        return self.pid_manager.step_all(self.timestep.dt_seconds)

    def send_commands_to_actuators(self) -> None:
        # Safety system always has final say, run after rules/PID have
        # written their commands, and may veto/override them.
        violations = self.safety_system.enforce(self.state, self.bus, self.device_registry)
        if self.mode in (OperatingMode.LIVE, OperatingMode.HYBRID) and self.hardware is not None:
            self.hardware.commit(self.device_registry)
        self.state.bulk_update(
            {f"actuator.{k}": v for k, v in self.device_registry.actuator_states().items()}
        )
        if violations:
            logger.debug("safety violations this tick: %s", [v.message for v in violations])

    def update_simulated_physics(self) -> None:
        if self.mode == OperatingMode.LIVE:
            return
        if self.simulator is not None:
            self.simulator.step(self.timestep.dt_seconds)

    def log_system_state(self) -> None:
        snapshot = self.state.snapshot()
        self.telemetry.record(self.timestep.simulated_time_s, snapshot)

    # -- orchestrating a full tick / run ------------------------------
    def tick(self) -> None:
        self.timestep.advance()
        self.read_all_sensors()
        self.evaluate_automation_rules()
        self.update_pid_controllers()
        self.send_commands_to_actuators()
        self.update_simulated_physics()
        self.log_system_state()

    def run(self, max_ticks: Optional[int] = None, realtime: bool = False,
             on_tick=None) -> None:
        self._running = True
        try:
            while self._running:
                self.tick()
                if on_tick is not None:
                    on_tick(self)
                if max_ticks is not None and self.timestep.tick_count >= max_ticks:
                    break
                if realtime:
                    time.sleep(self.timestep.dt_seconds)
        except KeyboardInterrupt:
            logger.warning("control loop interrupted - triggering emergency shutdown")
            self.safety_system.emergency_shutdown(self.state, self.bus, self.device_registry,
                                                    reason="keyboard_interrupt")
        finally:
            self._running = False

    def stop(self) -> None:
        self._running = False

    @property
    def running(self) -> bool:
        return self._running
