import { Injectable, computed, signal } from '@angular/core';
import {
  AuditLogItem,
  BrownfieldStatus,
  BuildingStructure,
  CollisionEvent,
  Equipment,
  FactoryMode,
  HeatmapType,
  OptimisationScenario,
  PLCSignal,
  ProcessNode,
  ProductPart,
  SimulationKPIs,
  Vector3D,
  ViewMode,
} from '../models/factory.types';
import {
  INITIAL_BUILDING,
  INITIAL_EQUIPMENT,
  INITIAL_PARTS,
  INITIAL_PLC_SIGNALS,
  INITIAL_PROCESS_GRAPH,
  INITIAL_SCENARIOS,
} from './sample-data';

@Injectable({
  providedIn: 'root',
})
export class FactoryStateService {
  // Navigation & Mode
  readonly currentMode = signal<FactoryMode>('DESIGN');
  readonly currentViewMode = signal<ViewMode>('ORBIT');
  readonly currentHeatmap = signal<HeatmapType>('NONE');
  readonly snapToGrid = signal<boolean>(true);
  readonly snapGridSizeMm = signal<number>(500); // 500mm default
  readonly showSafetyZones = signal<boolean>(true);
  readonly showMaintenanceZones = signal<boolean>(false);
  readonly showClearanceBoxes = signal<boolean>(false);
  readonly showFlowArrows = signal<boolean>(true);
  readonly isBrownfieldOverlay = signal<boolean>(false);
  readonly sectionCutPlaneMm = signal<number>(14000); // Z height clipping

  // Factory State Hierarchy
  readonly projectCode = signal<string>('FACTORY-2027-001');
  readonly projectName = signal<string>('SHEFFIELD PRECISION WORKS');
  readonly activeVersion = signal<string>('v2.1-OPTIMISED');
  readonly building = signal<BuildingStructure>(INITIAL_BUILDING);
  readonly equipmentList = signal<Equipment[]>(INITIAL_EQUIPMENT);
  readonly processGraph = signal<ProcessNode[]>(INITIAL_PROCESS_GRAPH);
  readonly partsList = signal<ProductPart[]>(INITIAL_PARTS);
  readonly scenarios = signal<OptimisationScenario[]>(INITIAL_SCENARIOS);
  readonly plcSignals = signal<PLCSignal[]>(INITIAL_PLC_SIGNALS);

  // Selected Entities
  readonly selectedEquipmentId = signal<string | null>('ROB-01');
  readonly selectedProcessNodeId = signal<string | null>(null);
  readonly selectedPartId = signal<string | null>('PART-004182');
  readonly followedPartId = signal<string | null>(null);
  readonly selectedScenarioId = signal<string>('SCEN-E');

  // Simulation Timeline & Playback
  readonly simulationRunning = signal<boolean>(true);
  readonly simulationSpeed = signal<number>(1.0); // 0.5x, 1x, 2x, 5x
  readonly simulationTime = signal<number>(18.4); // Current seconds in timeline
  readonly simulationMaxTime = signal<number>(120.0); // Max timeline seconds

  // Active Collisions & Warnings
  readonly collisions = signal<CollisionEvent[]>([]);

  // Audit Log & Digital Thread History
  readonly auditLogs = signal<AuditLogItem[]>([
    { id: 'LOG-01', timestamp: '2027-03-24 09:15:00', userRole: 'Robotics Engineer', action: 'Tool Configuration', details: 'Assigned Precision Dual-Jaw Hydraulic Gripper to ROB-01' },
    { id: 'LOG-02', timestamp: '2027-03-24 10:22:30', userRole: 'Factory Architect', action: 'Building Parametric Grid', details: 'Updated Hall A Column Grid to 12m x 12m' },
    { id: 'LOG-03', timestamp: '2027-03-24 11:05:14', userRole: 'Process Engineer', action: 'Routing Optimisation', details: 'Rebalanced CNC-04 outfeed queue to dynamic WIP buffer' },
  ]);

  // Derived Computed Properties
  readonly selectedEquipment = computed(() => {
    const id = this.selectedEquipmentId();
    if (!id) return null;
    return this.equipmentList().find((e) => e.id === id) || null;
  });

  readonly selectedProcessNode = computed(() => {
    const id = this.selectedProcessNodeId();
    if (!id) return null;
    return this.processGraph().find((p) => p.id === id) || null;
  });

  readonly selectedPart = computed(() => {
    const id = this.selectedPartId();
    if (!id) return null;
    return this.partsList().find((p) => p.id === id) || null;
  });

  readonly selectedScenario = computed(() => {
    const id = this.selectedScenarioId();
    return this.scenarios().find((s) => s.id === id) || this.scenarios()[0];
  });

  readonly totalCapex = computed(() => {
    return this.equipmentList().reduce((sum, eq) => sum + eq.capexCost + eq.installationCost, 0);
  });

  readonly totalInstantPowerMw = computed(() => {
    const totalKw = this.equipmentList().reduce((sum, eq) => {
      if (eq.state === 'PROCESSING' || eq.state === 'HEATING' || eq.state === 'RUNNING') {
        return sum + eq.processPowerKw;
      }
      return sum + eq.idlePowerKw;
    }, 0);
    return Number((totalKw / 1000).toFixed(3));
  });

  readonly simulationKPIs = computed<SimulationKPIs>(() => {
    const t = this.simulationTime();
    const partsDone = Math.floor(t * 0.35) + 12;
    const partsTotal = partsDone + this.partsList().length;
    const throughput = Math.floor(1284 * (1 - (this.equipmentList().some(e => e.state === 'FAULT') ? 0.32 : 0)));
    
    return {
      simulatedTimeSeconds: Number(t.toFixed(1)),
      totalPartsCreated: partsTotal,
      totalPartsCompleted: partsDone,
      totalPartsRejected: Math.floor(partsDone * 0.015),
      throughputPerHour: throughput,
      materialTravelKmPerHour: 14.8,
      averageCycleTimeSeconds: 18.2,
      wipPartCount: this.partsList().length + 18,
      averageRobotUtilisationPct: 81.4,
      averageMachineUtilisationPct: 88.6,
      floorSpaceUtilisationPct: 73.2,
      totalInstantPowerMw: this.totalInstantPowerMw(),
      energyPerPartKwh: 1.84,
      primaryBottleneckEquipmentId: 'CNC-04',
      bottleneckReason: 'Spline Milling Cycle (19.5s) exceeds upstream Laser Cutter feed rate',
      activeCollisions: this.collisions().filter((c) => c.severity === 'COLLISION').length,
      activeWarnings: this.collisions().filter((c) => c.severity === 'WARNING').length,
    };
  });

  // State Mutators
  setMode(mode: FactoryMode): void {
    this.currentMode.set(mode);
  }

  setViewMode(mode: ViewMode): void {
    this.currentViewMode.set(mode);
    if (mode === 'SECTION') {
      this.sectionCutPlaneMm.set(8000);
    } else {
      this.sectionCutPlaneMm.set(14000);
    }
  }

  setHeatmap(heatmap: HeatmapType): void {
    this.currentHeatmap.set(heatmap);
  }

  selectEquipment(id: string | null): void {
    this.selectedEquipmentId.set(id);
    if (id) {
      // Find associated process node if any
      const matchingProc = this.processGraph().find((p) => p.assignedEquipmentId === id);
      if (matchingProc) {
        this.selectedProcessNodeId.set(matchingProc.id);
      }
    }
  }

  selectProcessNode(id: string | null): void {
    this.selectedProcessNodeId.set(id);
    if (id) {
      const node = this.processGraph().find((p) => p.id === id);
      if (node && node.assignedEquipmentId) {
        this.selectedEquipmentId.set(node.assignedEquipmentId);
      }
    }
  }

  selectPart(id: string | null): void {
    this.selectedPartId.set(id);
  }

  followPart(id: string | null): void {
    this.followedPartId.set(id);
    if (id) {
      this.selectedPartId.set(id);
    }
  }

  selectScenario(id: string): void {
    this.selectedScenarioId.set(id);
  }

  updateEquipmentPosition(id: string, newPos: Partial<Vector3D>): void {
    this.equipmentList.update((list) =>
      list.map((eq) => {
        if (eq.id === id) {
          const updatedPos = { ...eq.position, ...newPos };
          return { ...eq, position: updatedPos };
        }
        return eq;
      })
    );
    this.addAuditLog('Equipment Layout', `Moved ${id} to (${newPos.x ?? '?'}, ${newPos.y ?? '?'}, ${newPos.z ?? '?'})`);
  }

  updateEquipmentProperty(id: string, updates: Partial<Equipment>): void {
    this.equipmentList.update((list) =>
      list.map((eq) => {
        if (eq.id === id) {
          return { ...eq, ...updates };
        }
        return eq;
      })
    );
  }

  addEquipment(newEq: Equipment): void {
    this.equipmentList.update((list) => [...list, newEq]);
    this.selectedEquipmentId.set(newEq.id);
    this.addAuditLog('Equipment Added', `Placed ${newEq.name} (${newEq.id}) in Hall A`);
  }

  removeEquipment(id: string): void {
    this.equipmentList.update((list) => list.filter((eq) => eq.id !== id));
    if (this.selectedEquipmentId() === id) {
      this.selectedEquipmentId.set(null);
    }
    this.addAuditLog('Equipment Removed', `Decommissioned ${id}`);
  }

  updateRobotJoint(equipmentId: string, jointId: number, angle: number): void {
    this.equipmentList.update((list) =>
      list.map((eq) => {
        if (eq.id === equipmentId && eq.robotJoints) {
          const updatedJoints = eq.robotJoints.map((j) => (j.id === jointId ? { ...j, currentAngle: angle } : j));
          return { ...eq, robotJoints: updatedJoints };
        }
        return eq;
      })
    );
  }

  toggleEquipmentFault(id: string): void {
    this.equipmentList.update((list) =>
      list.map((eq) => {
        if (eq.id === id) {
          const isFault = eq.state === 'FAULT';
          const newState = isFault ? 'PROCESSING' : 'FAULT';
          return { ...eq, state: newState, healthIndex: isFault ? 92 : 35 };
        }
        return eq;
      })
    );
  }

  setSimulationTime(time: number): void {
    this.simulationTime.set(Math.max(0, Math.min(this.simulationMaxTime(), time)));
  }

  toggleSimulationPlay(): void {
    this.simulationRunning.update((r) => !r);
  }

  addAuditLog(action: string, details: string): void {
    const newLog: AuditLogItem = {
      id: `LOG-${Date.now().toString().slice(-4)}`,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      userRole: 'Factory Engineer',
      action,
      details,
    };
    this.auditLogs.update((logs) => [newLog, ...logs.slice(0, 49)]);
  }

  // Signature Demos Loader
  loadSignatureDemo(demoId: 1 | 2 | 3 | 4 | 5): void {
    switch (demoId) {
      case 1: // Signature Demo 1: Sheffield Precision Factory
        this.building.set(INITIAL_BUILDING);
        this.equipmentList.set(INITIAL_EQUIPMENT);
        this.processGraph.set(INITIAL_PROCESS_GRAPH);
        this.partsList.set(INITIAL_PARTS);
        this.currentMode.set('DESIGN');
        this.currentViewMode.set('ORBIT');
        this.selectedEquipmentId.set('ROB-01');
        this.followedPartId.set(null);
        this.addAuditLog('Signature Demo', 'Loaded Demo 1: Full Sheffield Precision Components Factory');
        break;

      case 2: // Signature Demo 2: Design the Robot Cell
        this.currentMode.set('ROBOT_STUDIO');
        this.selectedEquipmentId.set('ROB-01');
        this.showSafetyZones.set(true);
        this.showClearanceBoxes.set(true);
        this.addAuditLog('Signature Demo', 'Loaded Demo 2: Robot Cell Kinematics & Reach Studio');
        break;

      case 3: // Signature Demo 3: Break the Factory (Failure Lab)
        this.currentMode.set('FAILURE_LAB');
        this.toggleEquipmentFault('FURN-02');
        this.addAuditLog('Signature Demo', 'Loaded Demo 3: Injected Furnace 02 Critical Thermal Fault');
        break;

      case 4: // Signature Demo 4: Follow One Part (PART-004182)
        this.currentMode.set('SIMULATE');
        this.selectedPartId.set('PART-004182');
        this.followedPartId.set('PART-004182');
        this.simulationRunning.set(true);
        this.addAuditLog('Signature Demo', 'Loaded Demo 4: Following Part-004182 Digital Journey');
        break;

      case 5: // Signature Demo 5: Brownfield Modernisation
        this.currentMode.set('COMPARE');
        this.isBrownfieldOverlay.set(true);
        this.equipmentList.update((list) =>
          list.map((eq) => {
            let status: BrownfieldStatus = 'EXISTING';
            if (eq.id === 'ROB-02' || eq.id === 'VIS-01') status = 'PROPOSED';
            if (eq.id === 'CUT-02') status = 'REMOVED';
            if (eq.id === 'CNC-04') status = 'MODIFIED';
            return { ...eq, brownfieldStatus: status };
          })
        );
        this.addAuditLog('Signature Demo', 'Loaded Demo 5: Brownfield vs Proposed Modernisation');
        break;
    }
  }
}
