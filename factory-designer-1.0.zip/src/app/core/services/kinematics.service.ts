import { Injectable } from '@angular/core';
import { RobotJoint, RobotTool, Vector3D } from '../models/factory.types';

export interface KinematicSegment {
  position: Vector3D;
  rotation: Vector3D;
  length: number;
}

export interface GripSafetyEvaluation {
  partMassKg: number;
  partLengthMm: number;
  partDiameterMm: number;
  gripperForceN: number;
  requiredForceN: number;
  safetyFactor: number;
  payloadMarginKg: number;
  comOffsetMm: number;
  feasibilityStatus: 'SAFE' | 'WARNING_ACCEL_LOAD' | 'EXCEEDS_PAYLOAD' | 'UNSAFE_GRIP';
  simulationNote: string;
}

@Injectable({
  providedIn: 'root',
})
export class KinematicsService {
  /**
   * Forward Kinematics for a standard 6-Axis industrial robot arm (SR-210 class)
   * Link lengths: L1=650mm, L2=950mm, L3=850mm, L4=350mm, L5=150mm, Tool=200mm
   */
  calculateForwardKinematics(basePos: Vector3D, joints: RobotJoint[], tool?: RobotTool): KinematicSegment[] {
    const l1 = 650;
    const l2 = 950;
    const l3 = 850;
    const l4 = 350;
    const toolOffset = tool ? tool.reachOffset : 180;

    const j1 = (joints[0]?.currentAngle ?? 0) * (Math.PI / 180);
    const j2 = (joints[1]?.currentAngle ?? 0) * (Math.PI / 180);
    const j3 = (joints[2]?.currentAngle ?? 0) * (Math.PI / 180);
    const j4 = (joints[3]?.currentAngle ?? 0) * (Math.PI / 180);
    const j5 = (joints[4]?.currentAngle ?? 0) * (Math.PI / 180);
    const j6 = (joints[5]?.currentAngle ?? 0) * (Math.PI / 180);

    // Joint 1: Base Yaw
    const p1: Vector3D = {
      x: basePos.x,
      y: basePos.y,
      z: basePos.z + l1,
    };

    // Joint 2: Shoulder Pitch
    const r2 = l2 * Math.sin(j2);
    const z2 = l2 * Math.cos(j2);
    const p2: Vector3D = {
      x: p1.x + r2 * Math.cos(j1),
      y: p1.y + r2 * Math.sin(j1),
      z: p1.z + z2,
    };

    // Joint 3: Elbow Pitch
    const angle23 = j2 + j3;
    const r3 = l3 * Math.sin(angle23);
    const z3 = l3 * Math.cos(angle23);
    const p3: Vector3D = {
      x: p2.x + r3 * Math.cos(j1),
      y: p2.y + r3 * Math.sin(j1),
      z: p2.z + z3,
    };

    // Joint 4 & 5: Wrist
    const angle235 = angle23 + j5;
    const r4 = l4 * Math.sin(angle235);
    const z4 = l4 * Math.cos(angle235);
    const p4: Vector3D = {
      x: p3.x + r4 * Math.cos(j1 + j4 * 0.1),
      y: p3.y + r4 * Math.sin(j1 + j4 * 0.1),
      z: p3.z + z4,
    };

    // Tool Tip Center Point (TCP)
    const pTool: Vector3D = {
      x: p4.x + toolOffset * Math.cos(j1),
      y: p4.y + toolOffset * Math.sin(j1),
      z: p4.z - 50,
    };

    return [
      { position: basePos, rotation: { x: 0, y: 0, z: j1 }, length: l1 },
      { position: p1, rotation: { x: j2, y: 0, z: j1 }, length: l2 },
      { position: p2, rotation: { x: angle23, y: 0, z: j1 }, length: l3 },
      { position: p3, rotation: { x: angle235, y: j4, z: j1 }, length: l4 },
      { position: p4, rotation: { x: angle235, y: j5, z: j6 }, length: toolOffset },
      { position: pTool, rotation: { x: 0, y: 0, z: j6 }, length: 0 },
    ];
  }

  /**
   * Evaluates Grip Safety physics model for cylindrical/bracket components
   */
  evaluateGripSafety(
    partMassKg: number,
    partLengthMm: number,
    partDiameterMm: number,
    tool: RobotTool
  ): GripSafetyEvaluation {
    const g = 9.81; // m/s2
    const robotMaxAccel = 4.5; // m/s2 dynamic acceleration load
    const frictionCoeff = 0.28; // steel-on-hardened jaw friction

    const weightForceN = partMassKg * (g + robotMaxAccel);
    const requiredGripForceN = Number((weightForceN / (2 * frictionCoeff)).toFixed(1));
    const actualGripForceN = tool.gripForce;
    const safetyFactor = Number((actualGripForceN / (requiredGripForceN || 1)).toFixed(2));
    const payloadMarginKg = Number((tool.maxPayload - partMassKg).toFixed(1));
    const comOffsetMm = Number((partLengthMm * 0.05).toFixed(1));

    let feasibilityStatus: 'SAFE' | 'WARNING_ACCEL_LOAD' | 'EXCEEDS_PAYLOAD' | 'UNSAFE_GRIP' = 'SAFE';
    if (payloadMarginKg < 0) {
      feasibilityStatus = 'EXCEEDS_PAYLOAD';
    } else if (safetyFactor < 1.5) {
      feasibilityStatus = 'UNSAFE_GRIP';
    } else if (safetyFactor < 2.2) {
      feasibilityStatus = 'WARNING_ACCEL_LOAD';
    }

    return {
      partMassKg,
      partLengthMm,
      partDiameterMm,
      gripperForceN: actualGripForceN,
      requiredForceN: requiredGripForceN,
      safetyFactor,
      payloadMarginKg,
      comOffsetMm,
      feasibilityStatus,
      simulationNote: 'Simulation estimate based on synthetic dynamic acceleration (4.5 m/s²). Not physical certification.',
    };
  }

  /**
   * Generates abstract Offline Programming (OLP) robot program representation
   */
  generateOLPProgram(robotId: string, robotName: string, joints: RobotJoint[], tool?: RobotTool): string {
    const timestamp = new Date().toISOString();
    return `// ========================================================
// ABSTRACT ROBOT PROGRAM (OLP LAYER v1.0)
// ROBOT: ${robotId} (${robotName})
// TOOL: ${tool?.name ?? 'Standard Flange'} (Mass: ${tool?.mass ?? 0}kg)
// CONTROLLER TARGET: Generic Industrial Kinematic Core
// GENERATED: ${timestamp}
// ========================================================

MODULE MainCellControl
  CONST speeddata v_fast := [2000, 500, 5000, 1000];
  CONST speeddata v_grip := [250, 100, 1000, 500];
  CONST zonedata z_fine := [FALSE, 0, 0, 0, 0, 0, 0];

  ! Current Joint Configuration
  VAR jointtarget j_home := [${joints.map((j) => j.currentAngle.toFixed(2)).join(', ')}];
  VAR robtarget p_pick := [[-24000.0, -12000.0, 1400.0], [1.0, 0.0, 0.0, 0.0], [0,0,0,0], [9E9,9E9,9E9,9E9,9E9,9E9]];
  VAR robtarget p_place := [[-16000.0, -16000.0, 1200.0], [0.707, 0.0, 0.707, 0.0], [0,0,0,0], [9E9,9E9,9E9,9E9,9E9,9E9]];

  PROC main()
    ! 1. Wait for Infeed Ready Interlock
    WaitDI di_ConveyorReady, 1;
    MoveAbsJ j_home, v_fast, z_fine, tool0;

    ! 2. Approach Vector & Part Grip
    MoveL RelTool(p_pick, 0, 0, -150), v_fast, z_fine, ${tool?.id ?? 'tool0'};
    MoveL p_pick, v_grip, z_fine, ${tool?.id ?? 'tool0'};
    SetDO do_GripperClamp, 1;
    WaitDI di_GripPressureSatisfied, 1;
    WaitTime 0.6;

    ! 3. Transfer Trajectory to CNC Chuck
    MoveL RelTool(p_pick, 0, 0, -200), v_fast, z_fine, ${tool?.id ?? 'tool0'};
    MoveJ RelTool(p_place, 0, 0, -250), v_fast, z_fine, ${tool?.id ?? 'tool0'};
    MoveL p_place, v_grip, z_fine, ${tool?.id ?? 'tool0'};

    ! 4. Release and Machine Start
    SetDO do_GripperClamp, 0;
    WaitDI di_GripPressureSatisfied, 0;
    MoveL RelTool(p_place, 0, 0, -200), v_fast, z_fine, ${tool?.id ?? 'tool0'};
    SetDO do_CNCStartCycle, 1;
    MoveAbsJ j_home, v_fast, z_fine, tool0;
  ENDPROC
ENDMODULE
`;
  }
}
