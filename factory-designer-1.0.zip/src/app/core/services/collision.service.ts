import { Injectable } from '@angular/core';
import { CollisionEvent, Equipment } from '../models/factory.types';

@Injectable({
  providedIn: 'root',
})
export class CollisionService {
  /**
   * Evaluates pairwise geometric interference and safety zone overlaps
   */
  evaluateCollisions(equipmentList: Equipment[]): CollisionEvent[] {
    const events: CollisionEvent[] = [];
    const count = equipmentList.length;

    for (let i = 0; i < count; i++) {
      const eqA = equipmentList[i];

      // Check human operator inside active robot zone
      if (eqA.category === 'PEOPLE') {
        for (let j = 0; j < count; j++) {
          if (i === j) continue;
          const eqB = equipmentList[j];
          if (eqB.category === 'ROBOTICS' && eqB.reachRadius) {
            const dist = this.getDistance(eqA.position, eqB.position);
            if (dist < eqB.reachRadius + 600) {
              events.push({
                id: `WARN-PED-${eqA.id}-${eqB.id}`,
                timestamp: Date.now(),
                severity: 'WARNING',
                entityAId: eqA.id,
                entityAName: eqA.name,
                entityBId: eqB.id,
                entityBName: eqB.name,
                description: `Pedestrian / Operator within ${eqB.name} active reach perimeter (${(dist / 1000).toFixed(1)}m < ${(eqB.reachRadius / 1000).toFixed(1)}m)`,
                location: eqA.position,
              });
            }
          }
        }
      }

      // Check equipment ↔ equipment physical bounding box collision
      for (let j = i + 1; j < count; j++) {
        const eqB = equipmentList[j];
        if (eqA.category === 'PEOPLE' || eqB.category === 'PEOPLE') continue;
        if (eqA.type === 'agv' || eqB.type === 'agv') continue; // AGVs use dynamic routing

        const isColliding = this.checkAABBOverlap(eqA, eqB);
        if (isColliding) {
          events.push({
            id: `COLL-${eqA.id}-${eqB.id}`,
            timestamp: Date.now(),
            severity: 'COLLISION',
            entityAId: eqA.id,
            entityAName: eqA.name,
            entityBId: eqB.id,
            entityBName: eqB.name,
            description: `Physical geometry intersection detected between ${eqA.code} and ${eqB.code}`,
            location: {
              x: (eqA.position.x + eqB.position.x) / 2,
              y: (eqA.position.y + eqB.position.y) / 2,
              z: 0,
            },
          });
        } else {
          // Check clearance warning (< 500mm spacing between heavy machine bases)
          const clearance = this.calculateClearanceMm(eqA, eqB);
          if (clearance < 400 && clearance >= 0) {
            events.push({
              id: `WARN-CLR-${eqA.id}-${eqB.id}`,
              timestamp: Date.now(),
              severity: 'WARNING',
              entityAId: eqA.id,
              entityAName: eqA.name,
              entityBId: eqB.id,
              entityBName: eqB.name,
              description: `Maintenance access clearance below threshold (${clearance}mm < 400mm)`,
              location: eqA.position,
            });
          }
        }
      }
    }

    return events;
  }

  private checkAABBOverlap(a: Equipment, b: Equipment): boolean {
    const halfAW = a.dimensions.width / 2;
    const halfAL = a.dimensions.length / 2;
    const halfBW = b.dimensions.width / 2;
    const halfBL = b.dimensions.length / 2;

    const overlapX = Math.abs(a.position.x - b.position.x) < halfAW + halfBW;
    const overlapY = Math.abs(a.position.y - b.position.y) < halfAL + halfBL;
    return overlapX && overlapY;
  }

  private calculateClearanceMm(a: Equipment, b: Equipment): number {
    const halfAW = a.dimensions.width / 2;
    const halfAL = a.dimensions.length / 2;
    const halfBW = b.dimensions.width / 2;
    const halfBL = b.dimensions.length / 2;

    const dx = Math.max(0, Math.abs(a.position.x - b.position.x) - (halfAW + halfBW));
    const dy = Math.max(0, Math.abs(a.position.y - b.position.y) - (halfAL + halfBL));
    return Math.floor(Math.sqrt(dx * dx + dy * dy));
  }

  private getDistance(p1: { x: number; y: number }, p2: { x: number; y: number }): number {
    const dx = p1.x - p2.x;
    const dy = p1.y - p2.y;
    return Math.sqrt(dx * dx + dy * dy);
  }
}
