import { Injectable, inject } from '@angular/core';
import { CollisionService } from './collision.service';
import { FactoryStateService } from './factory-state.service';

export interface SimulationSnapshot {
  timestamp: number;
  equipmentStates: Record<string, string>;
  partPositions: Record<string, { x: number; y: number; z: number; status: string }>;
}

@Injectable({
  providedIn: 'root',
})
export class SimulationService {
  private readonly state = inject(FactoryStateService);
  private readonly collisionService = inject(CollisionService);

  private animationFrameId: number | null = null;
  private lastTickTimestamp = 0;
  private readonly snapshots: SimulationSnapshot[] = [];

  initSimulationLoop(): void {
    if (typeof window === 'undefined') return;

    const tick = (now: number) => {
      if (this.lastTickTimestamp === 0) this.lastTickTimestamp = now;
      const deltaSeconds = (now - this.lastTickTimestamp) / 1000;
      this.lastTickTimestamp = now;

      if (this.state.simulationRunning() && deltaSeconds > 0 && deltaSeconds < 0.2) {
        this.stepSimulation(deltaSeconds * this.state.simulationSpeed());
      }

      this.animationFrameId = requestAnimationFrame(tick);
    };

    this.animationFrameId = requestAnimationFrame(tick);
  }

  destroySimulationLoop(): void {
    if (this.animationFrameId !== null && typeof window !== 'undefined') {
      cancelAnimationFrame(this.animationFrameId);
    }
  }

  stepSimulation(delta: number): void {
    const currentT = this.state.simulationTime();
    const nextT = currentT + delta;
    const maxT = this.state.simulationMaxTime();

    if (nextT >= maxT) {
      this.state.setSimulationTime(0); // loop
    } else {
      this.state.setSimulationTime(nextT);
    }

    this.updateDynamicEntities(nextT, delta);

    // Collision check evaluation periodically
    if (Math.floor(nextT * 10) % 5 === 0) {
      const collisions = this.collisionService.evaluateCollisions(this.state.equipmentList());
      this.state.collisions.set(collisions);
    }
  }

  private updateDynamicEntities(simTime: number, delta: number): void {
    // 1. Move AGVs along floor path
    this.state.equipmentList.update((list) =>
      list.map((eq) => {
        if (eq.type === 'agv') {
          // Patrol route between (-30m, -22m) and (30m, -22m)
          const period = 30; // 30 sec round trip
          const phase = (simTime % period) / period;
          const pingPong = phase < 0.5 ? phase * 2 : (1 - phase) * 2;
          const xPos = -30000 + pingPong * 60000;
          const rotZ = phase < 0.5 ? 0 : 180;
          return {
            ...eq,
            position: { ...eq.position, x: xPos },
            rotation: { ...eq.rotation, z: rotZ },
          };
        }

        // 2. Animate Robot Arm picking/placing oscillations
        if (eq.category === 'ROBOTICS' && eq.robotJoints && eq.state !== 'FAULT') {
          const j1Angle = Math.sin(simTime * 1.5 + (eq.id === 'ROB-01' ? 0 : 1.2)) * 45;
          const j2Angle = -20 + Math.cos(simTime * 1.2) * 20;
          const j3Angle = 40 + Math.sin(simTime * 1.4) * 25;
          const updatedJoints = eq.robotJoints.map((j) => {
            if (j.id === 1) return { ...j, currentAngle: Number(j1Angle.toFixed(1)) };
            if (j.id === 2) return { ...j, currentAngle: Number(j2Angle.toFixed(1)) };
            if (j.id === 3) return { ...j, currentAngle: Number(j3Angle.toFixed(1)) };
            return j;
          });
          return { ...eq, robotJoints: updatedJoints };
        }

        // 3. Furnace temperature modulation
        if (eq.category === 'METALLURGY' && eq.furnaceTempC !== undefined) {
          if (eq.state === 'FAULT') {
            const cooledTemp = Math.max(120, eq.furnaceTempC - delta * 15);
            return { ...eq, furnaceTempC: Number(cooledTemp.toFixed(1)) };
          }
          const normalFluctuation = (eq.targetTempC ?? 850) + Math.sin(simTime * 0.8) * 3;
          return { ...eq, furnaceTempC: Number(normalFluctuation.toFixed(1)) };
        }

        return eq;
      })
    );

    // 4. Update Part Positions along physical machine coordinates
    this.state.partsList.update((parts) =>
      parts.map((p, index) => {
        // Offset time per part so they are spaced along the line
        const partLocalT = (simTime + index * 12) % 60;
        let x = -45000;
        let y = -12000;
        let z = 1200;
        let status = p.status;
        let currentEq = 'CUT-01';

        if (partLocalT < 8.0) {
          // Cutting station
          x = -45000;
          y = -12000;
          status = 'PROCESSING';
          currentEq = 'CUT-01';
        } else if (partLocalT < 14.0) {
          // Conveyor 1
          const ratio = (partLocalT - 8.0) / 6.0;
          x = -35000 + ratio * 10000;
          y = -8000;
          z = 800;
          status = 'IN_TRANSIT';
          currentEq = 'CONV-01';
        } else if (partLocalT < 19.0) {
          // Robot 1 Transfer
          x = -24000;
          y = -12000;
          z = 1400;
          status = 'PROCESSING';
          currentEq = 'ROB-01';
        } else if (partLocalT < 36.0) {
          // CNC Mill
          x = -16000;
          y = -16000;
          z = 1200;
          status = 'PROCESSING';
          currentEq = 'CNC-01';
        } else if (partLocalT < 42.0) {
          // Conveyor 2 to Thermal
          const ratio = (partLocalT - 36.0) / 6.0;
          x = -6000 + ratio * 12000;
          y = -4000;
          status = 'IN_TRANSIT';
          currentEq = 'CONV-02';
        } else if (partLocalT < 54.0) {
          // Furnace Induction
          x = 8000;
          y = -12000;
          z = 1600;
          status = 'HEATING';
          currentEq = 'FURN-01';
        } else {
          // Finish Grinding & QA
          const ratio = (partLocalT - 54.0) / 6.0;
          x = 34000 + ratio * 14000;
          y = -10000;
          status = 'PROCESSING';
          currentEq = 'VIS-01';
        }

        return {
          ...p,
          position: { x, y, z },
          status,
          currentEquipmentId: currentEq,
        };
      })
    );
  }

  exportSimulationData(format: 'JSON' | 'CSV' | 'PARQUET'): string {
    const kpis = this.state.simulationKPIs();
    const timestamp = new Date().toISOString();
    
    if (format === 'CSV') {
      const header = 'Timestamp,SimulatedSeconds,Throughput_PartsPerHour,Power_MW,WIP_Parts,RobotUtil_Pct,MachineUtil_Pct,Bottleneck\n';
      const row = `${timestamp},${kpis.simulatedTimeSeconds},${kpis.throughputPerHour},${kpis.totalInstantPowerMw},${kpis.wipPartCount},${kpis.averageRobotUtilisationPct},${kpis.averageMachineUtilisationPct},${kpis.primaryBottleneckEquipmentId}\n`;
      return header + row;
    }

    return JSON.stringify(
      {
        exportedAt: timestamp,
        factory: this.state.projectName(),
        projectCode: this.state.projectCode(),
        kpis,
        equipment: this.state.equipmentList().map((e) => ({
          id: e.id,
          code: e.code,
          name: e.name,
          state: e.state,
          position: e.position,
          powerKw: e.processPowerKw,
          healthIndex: e.healthIndex,
        })),
        parts: this.state.partsList(),
      },
      null,
      2
    );
  }
}
