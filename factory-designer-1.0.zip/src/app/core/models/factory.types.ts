export type FactoryMode = 'DESIGN' | 'SIMULATE' | 'OPTIMISE' | 'COMMISSION' | 'DRAWING' | 'REPORT' | 'GRAPH' | 'ROBOT_STUDIO' | 'FAILURE_LAB' | 'COMPARE';

export type ViewMode = 'ORBIT' | 'TOP_DOWN' | 'FIRST_PERSON' | 'ISOMETRIC' | 'SECTION';

export type HeatmapType = 'NONE' | 'ROBOT_UTIL' | 'MACHINE_UTIL' | 'FLOOR_UTIL' | 'TRAFFIC' | 'ENERGY' | 'CONGESTION' | 'MAINTENANCE' | 'SAFETY';

export type EquipmentCategory =
  | 'ROBOTICS'
  | 'MATERIAL_HANDLING'
  | 'MACHINING'
  | 'METALLURGY'
  | 'ASSEMBLY'
  | 'FINISHING'
  | 'STORAGE'
  | 'PEOPLE'
  | 'SAFETY'
  | 'SENSORS';

export type EquipmentType =
  | 'industrial_6_axis'
  | 'scara_robot'
  | 'delta_robot'
  | 'gantry_robot'
  | 'cobot'
  | 'mobile_manipulator'
  | 'belt_conveyor'
  | 'roller_conveyor'
  | 'overhead_conveyor'
  | 'pallet_conveyor'
  | 'agv'
  | 'amr'
  | 'cnc_mill'
  | 'cnc_lathe'
  | 'laser_cutter'
  | 'hydraulic_press'
  | 'grinding_machine'
  | 'induction_furnace'
  | 'heat_treatment_furnace'
  | 'quench_tank'
  | 'cooling_station'
  | 'fixture_station'
  | 'torque_station'
  | 'paint_booth'
  | 'cleaning_station'
  | 'vision_inspection'
  | 'cmm_station'
  | 'pallet_rack'
  | 'fifo_buffer'
  | 'asrs_storage'
  | 'human_operator'
  | 'maintenance_engineer';

export type EquipmentState =
  | 'IDLE'
  | 'RUNNING'
  | 'PROCESSING'
  | 'HEATING'
  | 'COOLING'
  | 'PICKING'
  | 'PLACING'
  | 'MOVING'
  | 'BLOCKED'
  | 'STARVED'
  | 'FAULT'
  | 'MAINTENANCE'
  | 'OFFLINE';

export type ProvenanceType = 'DESIGNED' | 'IMPORTED' | 'MEASURED' | 'SIMULATED' | 'LIVE';

export type BrownfieldStatus = 'EXISTING' | 'PROPOSED' | 'MODIFIED' | 'REMOVED';

export interface Vector3D {
  x: number;
  y: number;
  z: number;
}

export interface Rotation3D {
  x: number; // in degrees
  y: number;
  z: number;
}

export interface Dimensions3D {
  width: number;  // X (mm)
  length: number; // Y (mm)
  height: number; // Z (mm)
}

export interface RobotJoint {
  id: number;
  name: string;
  minAngle: number; // degrees
  maxAngle: number;
  currentAngle: number;
  maxSpeed: number; // deg/sec
}

export interface RobotTool {
  id: string;
  name: string;
  type: 'parallel_gripper' | 'three_finger_gripper' | 'vacuum_gripper' | 'magnetic_gripper' | 'welding_torch' | 'grinding_spindle' | 'vision_probe';
  mass: number; // kg
  maxPayload: number; // kg
  gripForce: number; // N
  reachOffset: number; // mm
  operatingTime: number; // s
}

export interface SensorDevice {
  id: string;
  name: string;
  type: 'proximity' | 'photoelectric' | 'temperature' | 'pressure' | 'encoder' | 'load_cell' | 'vision' | 'vibration' | 'current';
  unit: string;
  currentValue: number;
  threshold: number;
  status: 'NORMAL' | 'TRIGGERED' | 'FAULT';
  updateRateHz: number;
}

export interface Equipment {
  id: string;
  code: string;
  name: string;
  category: EquipmentCategory;
  type: EquipmentType;
  manufacturer: string;
  model: string;
  position: Vector3D; // mm in factory coordinates
  rotation: Rotation3D;
  dimensions: Dimensions3D;
  state: EquipmentState;
  provenance: ProvenanceType;
  brownfieldStatus: BrownfieldStatus;
  
  // Performance & Cycle
  cycleTime: number; // seconds
  processTime: number; // seconds
  transferTime: number; // seconds
  availability: number; // 0.0 - 1.0 (e.g. 0.98)
  mtbfHours: number; // Mean Time Between Failures
  mttrHours: number; // Mean Time To Repair
  
  // Energy
  idlePowerKw: number;
  processPowerKw: number;
  peakPowerKw: number;
  
  // Financial
  capexCost: number; // £
  installationCost: number; // £
  maintenanceCostPerHour: number; // £/h
  expectedLifeYears: number;
  
  // Safety & Clearance
  safetyRadius: number; // mm
  maintenanceClearance: number; // mm
  reachRadius?: number; // mm (for robots)
  maxPayloadKg?: number; // kg
  
  // Connections
  upstreamEquipmentIds: string[];
  downstreamEquipmentIds: string[];
  currentPartId?: string;
  queueCount: number;
  maxQueueCapacity: number;
  
  // Specific configurations
  robotJoints?: RobotJoint[];
  activeTool?: RobotTool;
  furnaceTempC?: number;
  targetTempC?: number;
  conveyorSpeedMps?: number;
  attachedSensors?: SensorDevice[];
  
  // Maintenance Digital Twin
  lastServiceDate?: string;
  hoursRunTotal: number;
  healthIndex: number; // 0 - 100%
  failureProbability: number;
}

export interface BuildingStructure {
  name: string;
  factoryName: string;
  hallName: string;
  length: number; // m (e.g. 180)
  width: number;  // m (e.g. 60)
  height: number; // m (e.g. 14)
  columnGridX: number; // m (e.g. 12)
  columnGridY: number; // m (e.g. 12)
  floorThickness: number; // mm
  floorMaxLoadTonPerM2: number;
  loadingBays: { id: string; name: string; position: Vector3D; width: number }[];
  pedestrianCorridors: { id: string; start: Vector3D; end: Vector3D; width: number }[];
  overheadCranes: { id: string; capacityTons: number; yPosition: number }[];
  clippingPlaneZ: number; // for section view
}

export interface ProductPart {
  id: string;
  serialNumber: string;
  name: string;
  productType: 'STEEL_SHAFT' | 'PRECISION_BRACKET' | 'TURBINE_BLADE' | 'GEAR_HOUSING';
  material: string;
  massKg: number;
  dimensions: Dimensions3D;
  creationTimestamp: number;
  currentStepIndex: number;
  routeStepEquipmentIds: string[];
  currentEquipmentId?: string;
  position: Vector3D;
  status: 'RAW' | 'IN_TRANSIT' | 'PROCESSING' | 'HEATING' | 'COOLING' | 'INSPECTED_PASS' | 'INSPECTED_FAIL' | 'COMPLETED';
  temperatureC: number;
  qualityDefectDetected: boolean;
  defectReason?: string;
  history: {
    timestamp: number;
    equipmentId: string;
    action: string;
    duration: number;
    energyConsumedKwh: number;
  }[];
}

export interface ProcessNode {
  id: string;
  name: string;
  stepNumber: number;
  category: 'CUT' | 'CNC' | 'ROBOT_PICK' | 'FURNACE' | 'COOL' | 'GRIND' | 'VISION_QA' | 'PACKAGING';
  assignedEquipmentId: string;
  targetDurationSeconds: number;
  nextStepIds: string[];
  requiredTool?: string;
  targetTemp?: number;
  toleranceMm?: number;
}

export interface SimulationKPIs {
  simulatedTimeSeconds: number;
  totalPartsCreated: number;
  totalPartsCompleted: number;
  totalPartsRejected: number;
  throughputPerHour: number;
  materialTravelKmPerHour: number;
  averageCycleTimeSeconds: number;
  wipPartCount: number;
  averageRobotUtilisationPct: number;
  averageMachineUtilisationPct: number;
  floorSpaceUtilisationPct: number;
  totalInstantPowerMw: number;
  energyPerPartKwh: number;
  primaryBottleneckEquipmentId?: string;
  bottleneckReason?: string;
  activeCollisions: number;
  activeWarnings: number;
}

export interface CollisionEvent {
  id: string;
  timestamp: number;
  severity: 'WARNING' | 'COLLISION';
  entityAId: string;
  entityAName: string;
  entityBId: string;
  entityBName: string;
  description: string;
  location: Vector3D;
}

export interface OptimisationScenario {
  id: string;
  name: string;
  code: string;
  description: string;
  throughputPerHour: number;
  floorSpaceM2: number;
  capexMillionGbp: number;
  energyDemandMw: number;
  materialTravelKm: number;
  wipCount: number;
  scorecard: {
    throughputDeltaPct: number;
    materialTravelDeltaPct: number;
    energyDeltaPct: number;
    floorSpaceDeltaPct: number;
    capexDeltaPct: number;
  };
  keyChanges: string[];
}

export interface PLCSignal {
  id: string;
  tag: string;
  description: string;
  type: 'BOOL' | 'INT' | 'REAL';
  direction: 'INPUT' | 'OUTPUT';
  value: boolean | number;
  sourceEquipmentId: string;
}

export interface AuditLogItem {
  id: string;
  timestamp: string;
  userRole: string;
  action: string;
  details: string;
}
