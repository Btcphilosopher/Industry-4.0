import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  OnDestroy,
  inject,
} from '@angular/core';
import { FactoryStateService } from './core/services/factory-state.service';
import { SimulationService } from './core/services/simulation.service';
import { FactoryCanvas } from './features/canvas/factory-canvas';
import { CommissioningView } from './features/commissioning-view/commissioning-view';
import { DrawingView } from './features/drawing-view/drawing-view';
import { FailureLab } from './features/failure-lab/failure-lab';
import { Inspector } from './features/inspector/inspector';
import { EquipmentLibrary } from './features/library/equipment-library';
import { OptimiserView } from './features/optimiser-view/optimiser-view';
import { ProcessGraphView } from './features/process-graph/process-graph';
import { ReportView } from './features/report-view/report-view';
import { RobotStudio } from './features/robot-studio/robot-studio';
import { ScenariosCompareView } from './features/scenarios-view/scenarios-view';
import { SimulationTimeline } from './features/timeline/simulation-timeline';
import { Topbar } from './features/topbar/topbar';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [
    Topbar,
    EquipmentLibrary,
    FactoryCanvas,
    Inspector,
    SimulationTimeline,
    RobotStudio,
    ProcessGraphView,
    OptimiserView,
    CommissioningView,
    FailureLab,
    DrawingView,
    ReportView,
    ScenariosCompareView,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit, OnDestroy {
  readonly state = inject(FactoryStateService);
  private readonly simulationService = inject(SimulationService);

  ngOnInit(): void {
    this.simulationService.initSimulationLoop();
  }

  ngOnDestroy(): void {
    this.simulationService.destroySimulationLoop();
  }
}
