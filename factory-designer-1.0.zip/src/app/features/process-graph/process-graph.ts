import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { ProcessNode } from '../../core/models/factory.types';
import { FactoryStateService } from '../../core/services/factory-state.service';

@Component({
  selector: 'app-process-graph',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [],
  template: `
    <div class="w-full h-full bg-[#111415] text-[#ECEBE5] p-6 overflow-y-auto font-sans select-none">
      <!-- Process Header -->
      <div class="flex items-center justify-between pb-4 border-b border-[#252A2C] mb-6">
        <div>
          <h2 class="text-lg font-bold tracking-tight text-[#ECEBE5]">Material Flow & Process Graph Architecture</h2>
          <p class="text-xs font-mono text-[#687174]">Sequential Manufacturing Operations · Equipment Mapping · Directed Acyclic Graph (DAG)</p>
        </div>
        <button
          type="button"
          (click)="state.setMode('DESIGN')"
          class="px-3 py-1.5 bg-[#304F60] hover:bg-[#426A7A] rounded-lg text-xs font-semibold text-white transition-colors cursor-pointer"
        >
          Back to 3D Canvas
        </button>
      </div>

      <!-- Process Node Graph Pipeline (Flow Layout) -->
      <div class="space-y-4 max-w-5xl mx-auto">
        @for (node of state.processGraph(); track node.id; let idx = $index) {
          <div
            tabindex="0"
            role="button"
            class="flex items-center gap-4 group cursor-pointer focus:outline-none"
            (click)="selectNode(node)"
            (keydown.enter)="selectNode(node)"
          >
            <!-- Step Sequence Badge -->
            <div class="w-8 h-8 rounded-lg bg-[#191d1e] border border-[#252A2C] flex items-center justify-center font-mono text-xs font-bold text-[#A7ADAA] group-hover:border-[#426A7A]">
              {{ node.stepNumber }}
            </div>

            <!-- Node Card Container -->
            <div
              class="flex-1 p-4 rounded-xl border transition-all"
              [class]="state.selectedProcessNodeId() === node.id ? 'bg-[#191d1e] border-[#304F60] ring-1 ring-[#426A7A]' : 'bg-[#191d1e] border-[#252A2C] hover:border-[#32383a]'"
            >
              <div class="flex items-start justify-between">
                <div>
                  <h4 class="text-sm font-semibold text-[#ECEBE5]">{{ node.name }}</h4>
                  <p class="text-[11px] font-mono text-[#687174] mt-0.5">
                    Assigned Equipment ID: <span class="text-[#A7ADAA]">{{ node.assignedEquipmentId }}</span>
                  </p>
                </div>
                <div class="flex items-center gap-3 font-mono text-xs">
                  <span class="text-[#C18A35] font-bold">{{ node.targetDurationSeconds }}s Cycle</span>
                  @if (node.toleranceMm) {
                    <span class="text-[#48654F]">±{{ node.toleranceMm }}mm</span>
                  }
                  @if (node.targetTemp) {
                    <span class="text-[#C18A35]">{{ node.targetTemp }}°C</span>
                  }
                </div>
              </div>

              <!-- Downstream Transition Indicator -->
              <div class="mt-2.5 pt-2 border-t border-[#252A2C] flex items-center justify-between text-[11px] font-mono text-[#687174]">
                <span>Category: {{ node.category }}</span>
                <span class="text-[#A7ADAA]">
                  Next Step: {{ node.nextStepIds.length ? node.nextStepIds.join(', ') : 'END OF LINE (STORAGE)' }}
                </span>
              </div>
            </div>
          </div>

          <!-- Connector Flow Indicator -->
          @if (idx < state.processGraph().length - 1) {
            <div class="pl-7 py-1 text-[#32383a] font-mono text-xs flex items-center gap-2">
              <span class="h-4 w-0.5 bg-[#252A2C]"></span>
              <span class="text-[10px] text-[#687174]">↓ In-line automated handoff</span>
            </div>
          }
        }
      </div>
    </div>
  `,
})
export class ProcessGraphView {
  readonly state = inject(FactoryStateService);

  selectNode(node: ProcessNode): void {
    this.state.selectProcessNode(node.id);
  }
}
