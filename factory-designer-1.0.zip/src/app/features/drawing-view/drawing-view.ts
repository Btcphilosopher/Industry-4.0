import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { FactoryStateService } from '../../core/services/factory-state.service';

@Component({
  selector: 'app-drawing-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [],
  template: `
    <div class="w-full h-full bg-[#111415] text-[#ECEBE5] p-6 overflow-y-auto font-sans select-none">
      <!-- Drawings Header -->
      <div class="flex items-center justify-between pb-4 border-b border-[#252A2C] mb-6">
        <div>
          <h2 class="text-lg font-bold tracking-tight text-[#ECEBE5]">2D Technical Engineering CAD Drawings</h2>
          <p class="text-xs font-mono text-[#687174]">Architectural Plan · Section Profiles · Equipment Schedule · Millimeter Precision</p>
        </div>
        <div class="flex items-center gap-2">
          <button
            type="button"
            (click)="printDrawing()"
            class="px-3 py-1.5 bg-[#252A2C] hover:bg-[#32383a] border border-[#32383a] rounded-lg text-xs font-mono text-[#ECEBE5] transition-colors cursor-pointer"
          >
            🖨 Print / Export Plot
          </button>
          <button
            type="button"
            (click)="state.setMode('DESIGN')"
            class="px-3 py-1.5 bg-[#304F60] hover:bg-[#426A7A] rounded-lg text-xs font-semibold text-white transition-colors cursor-pointer"
          >
            Back to 3D Canvas
          </button>
        </div>
      </div>

      <!-- Engineering Drawing Sheet (Blueprint Border Style) -->
      <div class="bg-[#191d1e] border-2 border-[#32383a] p-6 rounded-xl space-y-6 max-w-6xl mx-auto shadow-2xl">
        <!-- Drawing Title Block -->
        <div class="border-b-2 border-[#32383a] pb-4 flex items-center justify-between font-mono text-xs">
          <div>
            <span class="text-[#687174] text-[10px] block uppercase">PROJECT / FACILITY</span>
            <span class="font-bold text-sm text-[#ECEBE5]">{{ state.projectName() }}</span>
            <span class="text-[#A7ADAA] block text-[11px]">{{ state.building().hallName }}</span>
          </div>
          <div class="grid grid-cols-3 gap-6 text-right">
            <div>
              <span class="text-[#687174] text-[10px] block">DRAWING NO.</span>
              <span class="font-bold text-[#ECEBE5]">DWG-2027-042-A</span>
            </div>
            <div>
              <span class="text-[#687174] text-[10px] block">SCALE</span>
              <span class="font-bold text-[#ECEBE5]">1 : 200</span>
            </div>
            <div>
              <span class="text-[#687174] text-[10px] block">REVISION</span>
              <span class="font-bold text-[#48654F]">{{ state.activeVersion() }}</span>
            </div>
          </div>
        </div>

        <!-- 2D SVG Schematic Floor Plan -->
        <div class="bg-[#111415] border border-[#252A2C] rounded-lg p-4 relative overflow-hidden">
          <svg viewBox="-65000 -35000 130000 70000" class="w-full h-96">
            <!-- Grid Lines -->
            <defs>
              <pattern id="cadGrid" width="12000" height="12000" patternUnits="userSpaceOnUse">
                <path d="M 12000 0 L 0 0 0 12000" fill="none" stroke="#252A2C" stroke-width="150" />
              </pattern>
            </defs>
            <rect x="-60000" y="-30000" width="120000" height="60000" fill="url(#cadGrid)" stroke="#426A7A" stroke-width="400" />

            <!-- Dimension Annotations -->
            <text x="0" y="-31500" fill="#A7ADAA" font-family="monospace" font-size="2200" text-anchor="middle">HALL LENGTH: 120,000 mm</text>
            <text x="-62500" y="0" fill="#A7ADAA" font-family="monospace" font-size="2200" text-anchor="middle" transform="rotate(-90 -62500 0)">HALL WIDTH: 60,000 mm</text>

            <!-- Column Markers -->
            @for (x of [-48000, -36000, -24000, -12000, 0, 12000, 24000, 36000, 48000]; track x) {
              @for (y of [-18000, -6000, 6000, 18000]; track y) {
                <circle [attr.cx]="x" [attr.cy]="y" r="600" fill="#304F60" />
              }
            }

            <!-- Equipment Footprints -->
            @for (eq of state.equipmentList(); track eq.id) {
              <g [attr.transform]="'translate(' + eq.position.x + ',' + eq.position.y + ') rotate(' + eq.rotation.z + ')'">
                <rect
                  [attr.x]="-eq.dimensions.width / 2"
                  [attr.y]="-eq.dimensions.length / 2"
                  [attr.width]="eq.dimensions.width"
                  [attr.height]="eq.dimensions.length"
                  fill="#252A2C"
                  stroke="#687174"
                  stroke-width="180"
                />
                <text
                  x="0"
                  y="400"
                  fill="#ECEBE5"
                  font-family="monospace"
                  font-size="1100"
                  text-anchor="middle"
                >
                  {{ eq.code }}
                </text>
              </g>
            }
          </svg>
        </div>

        <!-- Coordinate Schedule Table -->
        <div class="space-y-3">
          <div class="flex items-center justify-between">
            <h4 class="text-xs font-bold uppercase tracking-wider font-mono text-[#ECEBE5]">Equipment Coordinate Schedule (mm)</h4>
            <span class="text-[11px] font-mono text-[#687174]">{{ state.equipmentList().length }} Registered Items</span>
          </div>

          <div class="overflow-x-auto max-h-56">
            <table class="w-full text-left font-mono text-[11px]">
              <thead>
                <tr class="border-b border-[#252A2C] text-[#687174] text-[10px] uppercase sticky top-0 bg-[#191d1e]">
                  <th class="py-1.5 px-3">Tag</th>
                  <th class="py-1.5 px-3">Equipment Name</th>
                  <th class="py-1.5 px-3 text-right">X (mm)</th>
                  <th class="py-1.5 px-3 text-right">Y (mm)</th>
                  <th class="py-1.5 px-3 text-right">Z (mm)</th>
                  <th class="py-1.5 px-3 text-right">Rot Z (°)</th>
                  <th class="py-1.5 px-3 text-right">Envelope (W×L×H)</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-[#252A2C]">
                @for (eq of state.equipmentList(); track eq.id) {
                  <tr class="hover:bg-[#111415]">
                    <td class="py-1.5 px-3 font-bold text-[#ECEBE5]">{{ eq.code }}</td>
                    <td class="py-1.5 px-3 text-[#A7ADAA]">{{ eq.name }}</td>
                    <td class="py-1.5 px-3 text-right text-[#ECEBE5]">{{ eq.position.x }}</td>
                    <td class="py-1.5 px-3 text-right text-[#ECEBE5]">{{ eq.position.y }}</td>
                    <td class="py-1.5 px-3 text-right text-[#ECEBE5]">{{ eq.position.z }}</td>
                    <td class="py-1.5 px-3 text-right text-[#C18A35]">{{ eq.rotation.z }}°</td>
                    <td class="py-1.5 px-3 text-right text-[#687174]">
                      {{ eq.dimensions.width }} × {{ eq.dimensions.length }} × {{ eq.dimensions.height }}
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>

        <div class="border-t border-[#32383a] pt-3 text-[10px] font-mono text-[#687174] flex justify-between">
          <span>* Generated automatically from digital twin geometry. Simulation estimate; not construction certification.</span>
          <span>APPROVED: CHIEF MANUFACTURING ARCHITECT</span>
        </div>
      </div>
    </div>
  `,
})
export class DrawingView {
  readonly state = inject(FactoryStateService);

  printDrawing(): void {
    if (typeof window !== 'undefined') {
      window.print();
    }
  }
}
