import {
  AfterViewInit,
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  OnDestroy,
  ViewChild,
  effect,
  inject,
} from '@angular/core';
import * as THREE from 'three';
import { Equipment, HeatmapType, ViewMode } from '../../core/models/factory.types';
import { FactoryStateService } from '../../core/services/factory-state.service';
import { KinematicsService } from '../../core/services/kinematics.service';

@Component({
  selector: 'app-factory-canvas',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [],
  template: `
    <div class="relative w-full h-full overflow-hidden bg-[#111415]">
      <canvas #renderCanvas class="w-full h-full block cursor-grab active:cursor-grabbing outline-none"></canvas>

      <!-- 3D Viewport Semantic HUD Overlay -->
      <div class="absolute top-3 left-4 z-10 flex items-center gap-2 pointer-events-auto">
        <div class="flex items-center gap-1 bg-[#191d1e]/90 backdrop-blur-md border border-[#32383a] p-1 rounded-lg text-xs font-mono">
          <button
            type="button"
            (click)="setViewMode('ORBIT')"
            [class]="state.currentViewMode() === 'ORBIT' ? 'bg-[#304F60] text-white' : 'text-[#A7ADAA] hover:text-white'"
            class="px-2.5 py-1 rounded transition-colors whitespace-nowrap"
            title="Free 3D Orbit Camera"
          >
            3D Orbit
          </button>
          <button
            type="button"
            (click)="setViewMode('TOP_DOWN')"
            [class]="state.currentViewMode() === 'TOP_DOWN' ? 'bg-[#304F60] text-white' : 'text-[#A7ADAA] hover:text-white'"
            class="px-2.5 py-1 rounded transition-colors whitespace-nowrap"
            title="Orthographic Top-Down Layout Plan"
          >
            Plan (2D)
          </button>
          <button
            type="button"
            (click)="setViewMode('ISOMETRIC')"
            [class]="state.currentViewMode() === 'ISOMETRIC' ? 'bg-[#304F60] text-white' : 'text-[#A7ADAA] hover:text-white'"
            class="px-2.5 py-1 rounded transition-colors whitespace-nowrap"
            title="Isometric Engineering View"
          >
            Isometric
          </button>
          <button
            type="button"
            (click)="setViewMode('SECTION')"
            [class]="state.currentViewMode() === 'SECTION' ? 'bg-[#304F60] text-white' : 'text-[#A7ADAA] hover:text-white'"
            class="px-2.5 py-1 rounded transition-colors whitespace-nowrap"
            title="Section Clipping Plane"
          >
            Section
          </button>
          <button
            type="button"
            (click)="setViewMode('FIRST_PERSON')"
            [class]="state.currentViewMode() === 'FIRST_PERSON' ? 'bg-[#304F60] text-white' : 'text-[#A7ADAA] hover:text-white'"
            class="px-2.5 py-1 rounded transition-colors whitespace-nowrap"
            title="Human Walkthrough Perspective"
          >
            Walkthrough
          </button>
        </div>

        <!-- Follow Part Indicator -->
        @if (state.followedPartId()) {
          <div class="flex items-center gap-2 bg-[#304F60]/90 border border-[#426A7A] px-3 py-1.5 rounded-lg text-xs">
            <span class="w-2 h-2 rounded-full bg-[#C18A35] animate-ping"></span>
            <span class="font-mono text-[#ECEBE5]">Following: {{ state.followedPartId() }}</span>
            <button
              type="button"
              (click)="state.followPart(null)"
              class="ml-1 text-[#A7ADAA] hover:text-white cursor-pointer"
              title="Stop Following"
            >
              ✕
            </button>
          </div>
        }
      </div>

      <!-- Quick Toggles Overlay (Right-Top) -->
      <div class="absolute top-3 right-4 z-10 flex items-center gap-2 pointer-events-auto">
        <div class="flex items-center gap-1 bg-[#191d1e]/90 backdrop-blur-md border border-[#32383a] p-1 rounded-lg text-xs">
          <button
            type="button"
            (click)="toggleSafetyZones()"
            [class]="state.showSafetyZones() ? 'bg-[#48654F] text-white' : 'text-[#687174] hover:text-[#ECEBE5]'"
            class="px-2.5 py-1 rounded font-mono transition-colors whitespace-nowrap"
          >
            Safety Zones
          </button>
          <button
            type="button"
            (click)="toggleFlowArrows()"
            [class]="state.showFlowArrows() ? 'bg-[#304F60] text-white' : 'text-[#687174] hover:text-[#ECEBE5]'"
            class="px-2.5 py-1 rounded font-mono transition-colors whitespace-nowrap"
          >
            Material Flow
          </button>
        </div>
      </div>

      <!-- Bottom Coordinate / Scale HUD -->
      <div class="absolute bottom-3 left-4 z-10 pointer-events-none flex items-center gap-4 text-[11px] font-mono text-[#687174]">
        <span>HALL A: 120m × 60m</span>
        <span>·</span>
        <span>GRID SNAP: {{ state.snapGridSizeMm() }}mm</span>
        <span>·</span>
        <span>CURSOR: {{ hoveredCoords() }}</span>
      </div>
    </div>
  `,
})
export class FactoryCanvas implements AfterViewInit, OnDestroy {
  @ViewChild('renderCanvas', { static: true }) canvasRef!: ElementRef<HTMLCanvasElement>;

  readonly state = inject(FactoryStateService);
  private readonly kinematicsService = inject(KinematicsService);

  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private orthoCamera!: THREE.OrthographicCamera;
  private renderer!: THREE.WebGLRenderer;
  private raycaster = new THREE.Raycaster();
  private mouse = new THREE.Vector2();

  // Mesh registries for fast delta updates
  private equipmentGroup = new THREE.Group();
  private partsGroup = new THREE.Group();
  private safetyGroup = new THREE.Group();
  private flowLinesGroup = new THREE.Group();
  private buildingGroup = new THREE.Group();
  private envelopeGroup = new THREE.Group();

  private equipmentMeshMap = new Map<string, THREE.Group>();
  private partMeshMap = new Map<string, THREE.Mesh>();

  // Camera Orbit State
  private isMouseDown = false;
  private isRightMouseDown = false;
  private prevMouseX = 0;
  private prevMouseY = 0;
  private cameraTarget = new THREE.Vector3(0, 0, 0);
  private cameraSpherical = { radius: 110, theta: Math.PI / 4, phi: Math.PI / 3.2 };

  hoveredCoords = () => {
    return `X: ${(this.cameraTarget.x).toFixed(1)}m | Y: ${(this.cameraTarget.y).toFixed(1)}m`;
  };

  constructor() {
    // React to selected equipment changes
    effect(() => {
      const selectedId = this.state.selectedEquipmentId();
      this.highlightSelectedEquipment(selectedId);
      this.updateRobotReachEnvelope();
    });

    // React to heatmap mode changes
    effect(() => {
      const heatmap = this.state.currentHeatmap();
      const isBrownfield = this.state.isBrownfieldOverlay();
      this.applyHeatmapMaterials(heatmap, isBrownfield);
    });

    // React to safety zones toggle
    effect(() => {
      this.safetyGroup.visible = this.state.showSafetyZones();
    });

    // React to flow arrows toggle
    effect(() => {
      this.flowLinesGroup.visible = this.state.showFlowArrows();
    });
  }

  ngAfterViewInit(): void {
    this.initThreeScene();
    this.buildBuildingGeometry();
    this.buildEquipmentMeshes();
    this.buildSafetyZones();
    this.buildFlowPathLines();
    this.setupEventListeners();
    this.startRenderLoop();
  }

  ngOnDestroy(): void {
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  setViewMode(mode: ViewMode): void {
    this.state.setViewMode(mode);
    switch (mode) {
      case 'TOP_DOWN':
        this.cameraSpherical = { radius: 130, theta: 0, phi: 0.01 };
        this.cameraTarget.set(0, 0, 0);
        break;
      case 'ISOMETRIC':
        this.cameraSpherical = { radius: 120, theta: Math.PI / 4, phi: Math.PI / 3.5 };
        this.cameraTarget.set(0, 0, 0);
        break;
      case 'ORBIT':
        this.cameraSpherical = { radius: 100, theta: Math.PI / 5, phi: Math.PI / 3 };
        break;
      case 'FIRST_PERSON':
        this.cameraSpherical = { radius: 15, theta: 0, phi: Math.PI / 2.1 };
        this.cameraTarget.set(-16, -18, 1.8);
        break;
      case 'SECTION':
        this.cameraSpherical = { radius: 90, theta: Math.PI / 2, phi: Math.PI / 2.3 };
        this.cameraTarget.set(0, 0, 2);
        break;
    }
  }

  toggleSafetyZones(): void {
    this.state.showSafetyZones.update((v) => !v);
  }

  toggleFlowArrows(): void {
    this.state.showFlowArrows.update((v) => !v);
  }

  private initThreeScene(): void {
    const canvas = this.canvasRef.nativeElement;
    const width = canvas.clientWidth || 1000;
    const height = canvas.clientHeight || 700;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x111415);
    this.scene.fog = new THREE.FogExp2(0x111415, 0.005);

    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    this.updateCameraPosition();

    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      powerPreference: 'high-performance',
    });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    // Industrial Lighting Setup (Studio Rim + Key Light + Ambient)
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.85);
    this.scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 1.4);
    dirLight.position.set(40, 80, 60);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    dirLight.shadow.camera.near = 10;
    dirLight.shadow.camera.far = 250;
    dirLight.shadow.camera.left = -80;
    dirLight.shadow.camera.right = 80;
    dirLight.shadow.camera.top = 80;
    dirLight.shadow.camera.bottom = -80;
    this.scene.add(dirLight);

    const rimLight = new THREE.DirectionalLight(0x304f60, 0.9);
    rimLight.position.set(-60, -40, 30);
    this.scene.add(rimLight);

    // Groups Hierarchy
    this.scene.add(this.buildingGroup);
    this.scene.add(this.equipmentGroup);
    this.scene.add(this.partsGroup);
    this.scene.add(this.safetyGroup);
    this.scene.add(this.flowLinesGroup);
    this.scene.add(this.envelopeGroup);
  }

  private buildBuildingGeometry(): void {
    this.buildingGroup.clear();

    const building = this.state.building();
    const lengthM = building.length; // e.g. 120m
    const widthM = building.width;   // e.g. 60m
    const heightM = building.height; // e.g. 14m

    // 1. Polished Industrial Concrete Floor Slab
    const floorGeo = new THREE.PlaneGeometry(lengthM, widthM);
    const floorMat = new THREE.MeshStandardMaterial({
      color: 0x191d1e,
      roughness: 0.8,
      metalness: 0.15,
    });
    const floorMesh = new THREE.Mesh(floorGeo, floorMat);
    floorMesh.receiveShadow = true;
    this.buildingGroup.add(floorMesh);

    // 2. Metric Coordinate Grid Lines
    const gridHelper = new THREE.GridHelper(lengthM, lengthM / 2, 0x32383a, 0x222729);
    gridHelper.rotation.x = Math.PI / 2;
    gridHelper.position.z = 0.02;
    this.buildingGroup.add(gridHelper);

    // 3. Structural Columns (12m Grid)
    const colMat = new THREE.MeshStandardMaterial({ color: 0x304f60, metalness: 0.6, roughness: 0.4 });
    const colGeo = new THREE.BoxGeometry(0.8, 0.8, heightM);

    for (let x = -lengthM / 2 + 12; x < lengthM / 2; x += 12) {
      for (let y = -widthM / 2 + 12; y < widthM / 2; y += 12) {
        const colMesh = new THREE.Mesh(colGeo, colMat);
        colMesh.position.set(x, y, heightM / 2);
        colMesh.castShadow = true;
        this.buildingGroup.add(colMesh);
      }
    }

    // 4. Perimeter Low Architectural Curbing & Loading Bays
    const wallMat = new THREE.MeshStandardMaterial({ color: 0x252a2c, metalness: 0.3, roughness: 0.7 });
    const curbNorth = new THREE.Mesh(new THREE.BoxGeometry(lengthM, 0.6, 1.2), wallMat);
    curbNorth.position.set(0, widthM / 2, 0.6);
    this.buildingGroup.add(curbNorth);

    const curbSouth = new THREE.Mesh(new THREE.BoxGeometry(lengthM, 0.6, 1.2), wallMat);
    curbSouth.position.set(0, -widthM / 2, 0.6);
    this.buildingGroup.add(curbSouth);

    // 5. Overhead Crane Rails
    const railMat = new THREE.MeshStandardMaterial({ color: 0xc18a35, metalness: 0.8, roughness: 0.3 });
    const railA = new THREE.Mesh(new THREE.BoxGeometry(lengthM, 0.4, 0.6), railMat);
    railA.position.set(0, -widthM / 2 + 3, heightM - 2);
    this.buildingGroup.add(railA);

    const railB = new THREE.Mesh(new THREE.BoxGeometry(lengthM, 0.4, 0.6), railMat);
    railB.position.set(0, widthM / 2 - 3, heightM - 2);
    this.buildingGroup.add(railB);
  }

  private buildEquipmentMeshes(): void {
    this.equipmentGroup.clear();
    this.equipmentMeshMap.clear();

    const equipmentList = this.state.equipmentList();
    equipmentList.forEach((eq) => {
      const mesh = this.createEquipmentModel(eq);
      this.equipmentMeshMap.set(eq.id, mesh);
      this.equipmentGroup.add(mesh);
    });
  }

  private createEquipmentModel(eq: Equipment): THREE.Group {
    const group = new THREE.Group();
    // Convert factory mm coordinates to Three.js metres (1m = 1000mm)
    const posX = eq.position.x / 1000;
    const posY = eq.position.y / 1000;
    const posZ = eq.position.z / 1000;

    group.position.set(posX, posY, posZ);
    group.rotation.z = (eq.rotation.z * Math.PI) / 180;
    group.userData = { equipmentId: eq.id };

    const dimW = eq.dimensions.width / 1000;
    const dimL = eq.dimensions.length / 1000;
    const dimH = eq.dimensions.height / 1000;

    // Material definitions
    const baseMat = new THREE.MeshStandardMaterial({ color: 0x252a2c, metalness: 0.6, roughness: 0.4 });
    const machineBodyMat = new THREE.MeshStandardMaterial({ color: 0x304f60, metalness: 0.4, roughness: 0.3 });
    const accentMat = new THREE.MeshStandardMaterial({ color: 0xc18a35, metalness: 0.5, roughness: 0.4 });
    const glassMat = new THREE.MeshStandardMaterial({ color: 0x88ccff, transparent: true, opacity: 0.4, roughness: 0.1 });

    switch (eq.category) {
      case 'ROBOTICS': {
        // Pedestal base
        const base = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.55, 0.4, 24), baseMat);
        base.rotation.x = Math.PI / 2;
        base.position.z = 0.2;
        base.castShadow = true;
        group.add(base);

        // Turntable
        const turret = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.35, 0.35, 20), accentMat);
        turret.rotation.x = Math.PI / 2;
        turret.position.z = 0.55;
        group.add(turret);

        // Arm Link 1 & 2
        const link1 = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.3, 1.2), accentMat);
        link1.position.set(0, 0, 1.2);
        link1.rotation.y = 0.2;
        link1.castShadow = true;
        group.add(link1);

        const link2 = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.25, 1.1), baseMat);
        link2.position.set(0.3, 0, 1.8);
        link2.rotation.y = -0.5;
        group.add(link2);

        // Tool Wrist
        const wrist = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.25, 16), accentMat);
        wrist.position.set(0.7, 0, 1.9);
        group.add(wrist);
        break;
      }

      case 'MACHINING': {
        // CNC Machine Enclosure
        const body = new THREE.Mesh(new THREE.BoxGeometry(dimW, dimL, dimH), machineBodyMat);
        body.position.z = dimH / 2;
        body.castShadow = true;
        body.receiveShadow = true;
        group.add(body);

        // Front window panel
        const windowMesh = new THREE.Mesh(new THREE.PlaneGeometry(dimW * 0.6, dimH * 0.4), glassMat);
        windowMesh.position.set(0, -dimL / 2 - 0.02, dimH * 0.55);
        windowMesh.rotation.y = Math.PI;
        group.add(windowMesh);

        // Top Status Light Tower
        const lightPole = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.5), baseMat);
        lightPole.position.set(dimW * 0.4, -dimL * 0.35, dimH + 0.25);
        lightPole.rotation.x = Math.PI / 2;
        group.add(lightPole);

        const statusIndicator = new THREE.Mesh(
          new THREE.SphereGeometry(0.08, 12, 12),
          new THREE.MeshBasicMaterial({ color: eq.state === 'FAULT' ? 0xa44038 : 0x48654f })
        );
        statusIndicator.position.set(dimW * 0.4, -dimL * 0.35, dimH + 0.55);
        group.add(statusIndicator);
        break;
      }

      case 'METALLURGY': {
        // Heavy Furnace Body
        const furnaceMesh = new THREE.Mesh(new THREE.BoxGeometry(dimW, dimL, dimH), new THREE.MeshStandardMaterial({ color: 0x426a7a, metalness: 0.6, roughness: 0.5 }));
        furnaceMesh.position.z = dimH / 2;
        furnaceMesh.castShadow = true;
        group.add(furnaceMesh);

        // Glowing Thermal Chamber Core
        const chamberCore = new THREE.Mesh(
          new THREE.BoxGeometry(dimW * 0.7, dimL * 0.2, dimH * 0.3),
          new THREE.MeshBasicMaterial({ color: eq.state === 'FAULT' ? 0x687174 : 0xc18a35 })
        );
        chamberCore.position.set(0, -dimL / 2 - 0.01, dimH * 0.4);
        group.add(chamberCore);
        break;
      }

      case 'MATERIAL_HANDLING': {
        if (eq.type === 'agv') {
          // Low profile AGV vehicle
          const agvBody = new THREE.Mesh(new THREE.BoxGeometry(dimW, dimL, dimH), accentMat);
          agvBody.position.z = dimH / 2;
          agvBody.castShadow = true;
          group.add(agvBody);

          // Top cargo tray
          const tray = new THREE.Mesh(new THREE.BoxGeometry(dimW * 0.8, dimL * 0.8, 0.08), baseMat);
          tray.position.z = dimH + 0.04;
          group.add(tray);
        } else {
          // Roller / Belt Conveyor
          const frame = new THREE.Mesh(new THREE.BoxGeometry(dimW, dimL, 0.2), baseMat);
          frame.position.z = dimH;
          group.add(frame);

          // Conveyor belt surface
          const belt = new THREE.Mesh(new THREE.BoxGeometry(dimW * 0.8, dimL * 0.96, 0.05), new THREE.MeshStandardMaterial({ color: 0x111415, roughness: 0.9 }));
          belt.position.z = dimH + 0.1;
          group.add(belt);

          // Support legs
          for (let y = -dimL / 2 + 1; y < dimL / 2; y += 3) {
            const legL = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, dimH), baseMat);
            legL.rotation.x = Math.PI / 2;
            legL.position.set(-dimW / 2 + 0.1, y, dimH / 2);
            group.add(legL);

            const legR = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, dimH), baseMat);
            legR.rotation.x = Math.PI / 2;
            legR.position.set(dimW / 2 - 0.1, y, dimH / 2);
            group.add(legR);
          }
        }
        break;
      }

      case 'STORAGE': {
        // High density pallet rack framework
        const rackFrame = new THREE.Mesh(new THREE.BoxGeometry(dimW, dimL, dimH), new THREE.MeshStandardMaterial({ color: 0x304f60, wireframe: true }));
        rackFrame.position.z = dimH / 2;
        group.add(rackFrame);

        // Pallet boxes inside rack
        for (let z = 1.2; z < dimH; z += 1.8) {
          for (let y = -dimL / 2 + 1.5; y < dimL / 2; y += 2.5) {
            const crate = new THREE.Mesh(new THREE.BoxGeometry(dimW * 0.7, 1.8, 1.0), new THREE.MeshStandardMaterial({ color: 0xa7adaa }));
            crate.position.set(0, y, z);
            group.add(crate);
          }
        }
        break;
      }

      case 'PEOPLE': {
        // Human Digital Twin Mannequin
        const bodyMat = new THREE.MeshStandardMaterial({ color: 0xc18a35 }); // Hi-vis vest
        const torso = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.18, 0.7), bodyMat);
        torso.rotation.x = Math.PI / 2;
        torso.position.z = 1.2;
        group.add(torso);

        const head = new THREE.Mesh(new THREE.SphereGeometry(0.14, 16, 16), new THREE.MeshStandardMaterial({ color: 0xecebe5 }));
        head.position.z = 1.7;
        group.add(head);

        const legs = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.8), new THREE.MeshStandardMaterial({ color: 0x252a2c }));
        legs.rotation.x = Math.PI / 2;
        legs.position.z = 0.45;
        group.add(legs);
        break;
      }

      default: {
        const box = new THREE.Mesh(new THREE.BoxGeometry(dimW, dimL, dimH), machineBodyMat);
        box.position.z = dimH / 2;
        group.add(box);
        break;
      }
    }

    return group;
  }

  private buildSafetyZones(): void {
    this.safetyGroup.clear();
    const equipmentList = this.state.equipmentList();

    equipmentList.forEach((eq) => {
      const radiusM = (eq.reachRadius || eq.safetyRadius || 2000) / 1000;
      const posX = eq.position.x / 1000;
      const posY = eq.position.y / 1000;

      // Circular transparent safety ring on floor
      const ringGeo = new THREE.RingGeometry(radiusM - 0.1, radiusM, 32);
      const ringMat = new THREE.MeshBasicMaterial({
        color: eq.category === 'ROBOTICS' ? 0xc18a35 : 0x48654f,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.6,
      });
      const ringMesh = new THREE.Mesh(ringGeo, ringMat);
      ringMesh.position.set(posX, posY, 0.05);
      this.safetyGroup.add(ringMesh);

      // Translucent exclusion disc
      const discGeo = new THREE.CircleGeometry(radiusM, 32);
      const discMat = new THREE.MeshBasicMaterial({
        color: eq.category === 'ROBOTICS' ? 0xc18a35 : 0x48654f,
        transparent: true,
        opacity: 0.08,
      });
      const discMesh = new THREE.Mesh(discGeo, discMat);
      discMesh.position.set(posX, posY, 0.04);
      this.safetyGroup.add(discMesh);
    });
  }

  private buildFlowPathLines(): void {
    this.flowLinesGroup.clear();
    const processNodes = this.state.processGraph();
    const equipmentList = this.state.equipmentList();

    const linePoints: THREE.Vector3[] = [];
    processNodes.forEach((node) => {
      const eq = equipmentList.find((e) => e.id === node.assignedEquipmentId);
      if (eq) {
        linePoints.push(new THREE.Vector3(eq.position.x / 1000, eq.position.y / 1000, 0.8));
      }
    });

    if (linePoints.length > 1) {
      const curve = new THREE.CatmullRomCurve3(linePoints);
      const points = curve.getPoints(80);
      const geometry = new THREE.BufferGeometry().setFromPoints(points);
      const material = new THREE.LineDashedMaterial({
        color: 0x426a7a,
        dashSize: 1.5,
        gapSize: 0.8,
        linewidth: 2,
      });
      const line = new THREE.Line(geometry, material);
      line.computeLineDistances();
      this.flowLinesGroup.add(line);
    }
  }

  private updateRobotReachEnvelope(): void {
    this.envelopeGroup.clear();
    const selectedEq = this.state.selectedEquipment();
    if (selectedEq && selectedEq.category === 'ROBOTICS' && selectedEq.reachRadius) {
      const radiusM = selectedEq.reachRadius / 1000;
      const posX = selectedEq.position.x / 1000;
      const posY = selectedEq.position.y / 1000;
      const posZ = selectedEq.position.z / 1000 + 0.6;

      // Translucent Reachable Dome
      const sphereGeo = new THREE.SphereGeometry(radiusM, 32, 16, 0, Math.PI * 2, 0, Math.PI / 1.8);
      const sphereMat = new THREE.MeshBasicMaterial({
        color: 0x304f60,
        wireframe: true,
        transparent: true,
        opacity: 0.35,
      });
      const sphereMesh = new THREE.Mesh(sphereGeo, sphereMat);
      sphereMesh.position.set(posX, posY, posZ);
      this.envelopeGroup.add(sphereMesh);
    }
  }

  private highlightSelectedEquipment(selectedId: string | null): void {
    this.equipmentMeshMap.forEach((mesh, id) => {
      mesh.traverse((child) => {
        if (child instanceof THREE.Mesh && child.material instanceof THREE.MeshStandardMaterial) {
          if (id === selectedId) {
            child.material.emissive = new THREE.Color(0x304f60);
            child.material.emissiveIntensity = 0.4;
          } else {
            child.material.emissive = new THREE.Color(0x000000);
            child.material.emissiveIntensity = 0.0;
          }
        }
      });
    });
  }

  private applyHeatmapMaterials(heatmap: HeatmapType, isBrownfield: boolean): void {
    const equipmentList = this.state.equipmentList();

    equipmentList.forEach((eq) => {
      const mesh = this.equipmentMeshMap.get(eq.id);
      if (!mesh) return;

      mesh.traverse((child) => {
        if (child instanceof THREE.Mesh && child.material instanceof THREE.MeshStandardMaterial) {
          if (isBrownfield) {
            switch (eq.brownfieldStatus) {
              case 'EXISTING':
                child.material.color = new THREE.Color(0x687174); // Grey
                break;
              case 'PROPOSED':
                child.material.color = new THREE.Color(0x304f60); // Blue
                break;
              case 'REMOVED':
                child.material.color = new THREE.Color(0xa44038); // Red
                break;
              case 'MODIFIED':
                child.material.color = new THREE.Color(0x48654f); // Green
                break;
            }
          } else {
            switch (heatmap) {
              case 'ENERGY': {
                const kw = eq.processPowerKw;
                const ratio = Math.min(1.0, kw / 150);
                child.material.color = new THREE.Color().setHSL(0.6 - ratio * 0.6, 0.8, 0.45);
                break;
              }
              case 'MAINTENANCE': {
                const health = eq.healthIndex / 100;
                child.material.color = new THREE.Color().setHSL(health * 0.33, 0.8, 0.4);
                break;
              }
              case 'ROBOT_UTIL': {
                if (eq.category === 'ROBOTICS') {
                  child.material.color = new THREE.Color(0x48654f);
                } else {
                  child.material.color = new THREE.Color(0x252a2c);
                }
                break;
              }
              case 'NONE':
              default:
                // Revert to natural domain colors
                child.material.color = new THREE.Color(eq.category === 'ROBOTICS' ? 0xc18a35 : 0x304f60);
                break;
            }
          }
        }
      });
    });
  }

  private setupEventListeners(): void {
    const canvas = this.canvasRef.nativeElement;

    canvas.addEventListener('mousedown', (e) => {
      this.isMouseDown = true;
      this.isRightMouseDown = e.button === 2;
      this.prevMouseX = e.clientX;
      this.prevMouseY = e.clientY;

      if (e.button === 0) {
        this.handleRaycastPick(e);
      }
    });

    window.addEventListener('mouseup', () => {
      this.isMouseDown = false;
      this.isRightMouseDown = false;
    });

    canvas.addEventListener('contextmenu', (e) => e.preventDefault());

    canvas.addEventListener('mousemove', (e) => {
      if (!this.isMouseDown) return;

      const deltaX = e.clientX - this.prevMouseX;
      const deltaY = e.clientY - this.prevMouseY;
      this.prevMouseX = e.clientX;
      this.prevMouseY = e.clientY;

      if (this.isRightMouseDown || e.shiftKey) {
        // Pan camera target in floor XY plane
        const panSpeed = 0.08 * (this.cameraSpherical.radius / 50);
        const forward = new THREE.Vector3()
          .subVectors(this.cameraTarget, this.camera.position)
          .setZ(0)
          .normalize();
        const right = new THREE.Vector3().crossVectors(forward, new THREE.Vector3(0, 0, 1)).normalize();

        this.cameraTarget.addScaledVector(right, -deltaX * panSpeed);
        this.cameraTarget.addScaledVector(forward, deltaY * panSpeed);
      } else {
        // Orbit rotation
        this.cameraSpherical.theta -= deltaX * 0.008;
        this.cameraSpherical.phi = Math.max(0.1, Math.min(Math.PI / 2 - 0.05, this.cameraSpherical.phi - deltaY * 0.008));
      }

      this.updateCameraPosition();
    });

    canvas.addEventListener('wheel', (e) => {
      e.preventDefault();
      const zoomSpeed = 0.08;
      this.cameraSpherical.radius = Math.max(5, Math.min(220, this.cameraSpherical.radius + e.deltaY * zoomSpeed));
      this.updateCameraPosition();
    });

    window.addEventListener('resize', () => {
      const w = canvas.parentElement?.clientWidth || window.innerWidth;
      const h = canvas.parentElement?.clientHeight || window.innerHeight;
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(w, h);
    });
  }

  private handleRaycastPick(e: MouseEvent): void {
    const canvas = this.canvasRef.nativeElement;
    const rect = canvas.getBoundingClientRect();
    this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(this.mouse, this.camera);
    const intersects = this.raycaster.intersectObjects(this.equipmentGroup.children, true);

    if (intersects.length > 0) {
      let currentObj: THREE.Object3D | null = intersects[0].object;
      while (currentObj && !currentObj.userData['equipmentId'] && currentObj.parent) {
        currentObj = currentObj.parent;
      }
      if (currentObj && currentObj.userData['equipmentId']) {
        const id = currentObj.userData['equipmentId'];
        this.state.selectEquipment(id);
      }
    }
  }

  private updateCameraPosition(): void {
    const x = this.cameraTarget.x + this.cameraSpherical.radius * Math.sin(this.cameraSpherical.phi) * Math.sin(this.cameraSpherical.theta);
    const y = this.cameraTarget.y - this.cameraSpherical.radius * Math.sin(this.cameraSpherical.phi) * Math.cos(this.cameraSpherical.theta);
    const z = this.cameraTarget.z + this.cameraSpherical.radius * Math.cos(this.cameraSpherical.phi);

    this.camera.position.set(x, y, z);
    this.camera.lookAt(this.cameraTarget);
  }

  private startRenderLoop(): void {
    const render = () => {
      // 1. Follow part camera if active
      const followId = this.state.followedPartId();
      if (followId) {
        const part = this.state.partsList().find((p) => p.id === followId);
        if (part) {
          const partX = part.position.x / 1000;
          const partY = part.position.y / 1000;
          const partZ = part.position.z / 1000;
          this.cameraTarget.lerp(new THREE.Vector3(partX, partY, partZ), 0.05);
          this.updateCameraPosition();
        }
      }

      // 2. Synchronize dynamic 3D Part positions
      this.syncPartMeshes();

      // 3. Synchronize AGV & Robot dynamic transformations
      this.syncEquipmentTransforms();

      this.renderer.render(this.scene, this.camera);
      requestAnimationFrame(render);
    };

    requestAnimationFrame(render);
  }

  private syncPartMeshes(): void {
    const parts = this.state.partsList();
    parts.forEach((p) => {
      let mesh = this.partMeshMap.get(p.id);
      if (!mesh) {
        // Create 3D Cylindrical Transmission Shaft part
        const geo = new THREE.CylinderGeometry(0.12, 0.12, 0.64, 16);
        const mat = new THREE.MeshStandardMaterial({ color: 0xa7adaa, metalness: 0.9, roughness: 0.2 });
        mesh = new THREE.Mesh(geo, mat);
        mesh.castShadow = true;
        this.partMeshMap.set(p.id, mesh);
        this.partsGroup.add(mesh);
      }

      mesh.position.set(p.position.x / 1000, p.position.y / 1000, p.position.z / 1000);
      mesh.rotation.x = Math.PI / 2;

      // Glow hot when heated in furnace
      const stdMat = mesh.material as THREE.MeshStandardMaterial;
      if (p.temperatureC > 400) {
        stdMat.emissive = new THREE.Color(0xc18a35);
        stdMat.emissiveIntensity = Math.min(1.0, (p.temperatureC - 400) / 450);
      } else {
        stdMat.emissiveIntensity = 0.0;
      }
    });
  }

  private syncEquipmentTransforms(): void {
    const equipmentList = this.state.equipmentList();
    equipmentList.forEach((eq) => {
      const mesh = this.equipmentMeshMap.get(eq.id);
      if (mesh) {
        mesh.position.set(eq.position.x / 1000, eq.position.y / 1000, eq.position.z / 1000);
        mesh.rotation.z = (eq.rotation.z * Math.PI) / 180;
      }
    });
  }
}
