import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { PLCSignal } from '../../core/models/factory.types';
import { FactoryStateService } from '../../core/services/factory-state.service';

@Component({
  selector: 'app-commissioning-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [],
  template: `
    <div class="w-full h-full bg-[#111415] text-[#ECEBE5] p-6 overflow-y-auto font-sans select-none">
      <!-- Commissioning Header -->
      <div class="flex items-center justify-between pb-4 border-b border-[#252A2C] mb-6">
        <div>
          <h2 class="text-lg font-bold tracking-tight text-[#ECEBE5]">Virtual Commissioning & Control Logic Bench</h2>
          <p class="text-xs font-mono text-[#687174]">PLC Signal Emulation · Sensor/Actuator Interlocks · Vision QA Defect Inspection</p>
        </div>
        <div class="flex items-center gap-2">
          <button
            type="button"
            (click)="triggerEmergencyStop()"
            class="px-3 py-1.5 bg-[#A44038] hover:bg-[#85322c] rounded-lg text-xs font-semibold text-white transition-colors cursor-pointer"
          >
            🛑 E-STOP INTERLOCK
          </button>
          <button
            type="button"
            (click)="state.setMode('DESIGN')"
            class="px-3 py-1.5 bg-[#304F60] hover:bg-[#426A7A] rounded-lg text-xs font-semibold text-white transition-colors cursor-pointer"
          >
            Back to 3D Canvas
          </button>
        </div>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Column 1 & 2: Real-time PLC Signal IO Table -->
        <div class="lg:col-span-2 bg-[#191d1e] border border-[#252A2C] rounded-xl p-5 space-y-4">
          <div class="flex items-center justify-between border-b border-[#252A2C] pb-3">
            <h3 class="text-xs font-semibold uppercase tracking-wider font-mono text-[#ECEBE5]">PLC Digital & Analog I/O Signals</h3>
            <span class="text-[11px] font-mono text-[#48654F]">IEC 61131-3 Emulation Loop Active</span>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left font-mono text-xs">
              <thead>
                <tr class="border-b border-[#252A2C] text-[#687174] text-[10px] uppercase">
                  <th class="py-2 px-3">Tag</th>
                  <th class="py-2 px-3">Description</th>
                  <th class="py-2 px-3">Type</th>
                  <th class="py-2 px-3">Dir</th>
                  <th class="py-2 px-3">Source Equipment</th>
                  <th class="py-2 px-3 text-right">Value</th>
                  <th class="py-2 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-[#252A2C]">
                @for (sig of state.plcSignals(); track sig.id) {
                  <tr class="hover:bg-[#111415] transition-colors">
                    <td class="py-2.5 px-3 font-bold text-[#ECEBE5]">{{ sig.tag }}</td>
                    <td class="py-2.5 px-3 text-[#A7ADAA] text-[11px]">{{ sig.description }}</td>
                    <td class="py-2.5 px-3 text-[#687174]">{{ sig.type }}</td>
                    <td class="py-2.5 px-3">
                      <span class="text-[10px] px-1.5 py-0.5 rounded font-bold" [class]="sig.direction === 'INPUT' ? 'bg-[#304F60]/30 text-[#88ccff]' : 'bg-[#C18A35]/30 text-[#C18A35]'">
                        {{ sig.direction }}
                      </span>
                    </td>
                    <td class="py-2.5 px-3 text-[#687174]">{{ sig.sourceEquipmentId }}</td>
                    <td class="py-2.5 px-3 text-right font-bold" [class]="getSignalValueClass(sig)">
                      {{ sig.value }}
                    </td>
                    <td class="py-2.5 px-3 text-right">
                      @if (sig.type === 'BOOL') {
                        <button
                          type="button"
                          (click)="toggleSignal(sig)"
                          class="px-2 py-0.5 rounded text-[10px] bg-[#252A2C] hover:bg-[#32383a] text-[#ECEBE5] transition-colors cursor-pointer"
                        >
                          Toggle
                        </button>
                      }
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>

        <!-- Column 3: Machine Vision Metrology Inspection Camera -->
        <div class="bg-[#191d1e] border border-[#252A2C] rounded-xl p-5 space-y-4">
          <div class="flex items-center justify-between border-b border-[#252A2C] pb-3">
            <h3 class="text-xs font-semibold uppercase tracking-wider font-mono text-[#ECEBE5]">Machine Vision QA Station</h3>
            <span class="text-[11px] font-mono text-[#48654F]">CAM-01 Metrology</span>
          </div>

          <!-- Synthetic Inspection Camera Viewport -->
          <div class="h-44 bg-[#111415] border border-[#252A2C] rounded-lg relative overflow-hidden flex items-center justify-center p-4">
            <!-- Grid Lines & Laser Crosshair -->
            <div class="absolute inset-0 bg-[radial-gradient(#304F60_1px,transparent_1px)] [background-size:16px_16px] opacity-30"></div>
            <div class="absolute w-full h-0.5 bg-[#426A7A]/60 animate-pulse"></div>
            <div class="absolute h-full w-0.5 bg-[#426A7A]/60"></div>

            <!-- Part Target Silhouette -->
            <div class="relative z-10 text-center space-y-1">
              <div class="w-32 h-10 border-2 border-[#48654F] bg-[#304F60]/20 rounded flex items-center justify-center font-mono text-[10px] text-[#ECEBE5]">
                STEEL-SHAFT-120mm
              </div>
              <span class="text-[10px] font-mono text-[#48654F] block">✓ DIAMETER: 120.002mm (±0.005)</span>
            </div>
          </div>

          <div class="p-3 bg-[#111415] rounded-lg border border-[#252A2C] space-y-2 text-xs font-mono">
            <div class="flex justify-between">
              <span class="text-[#687174]">Barcode Check:</span>
              <span class="text-[#ECEBE5] font-bold">SN-2027-4182-SHF (VALID)</span>
            </div>
            <div class="flex justify-between">
              <span class="text-[#687174]">Surface Defect Index:</span>
              <span class="text-[#48654F] font-bold">0.02% (PASS)</span>
            </div>
            <div class="flex justify-between">
              <span class="text-[#687174]">Spline Pitch Tolerance:</span>
              <span class="text-[#48654F] font-bold">0.001mm</span>
            </div>
          </div>

          <button
            type="button"
            (click)="simulateDefect()"
            class="w-full py-2 bg-[#252A2C] hover:bg-[#A44038] text-xs font-mono text-[#ECEBE5] rounded-lg transition-colors cursor-pointer"
          >
            Simulate Vision QA Defect Reject
          </button>
        </div>
      </div>
    </div>
  `,
})
export class CommissioningView {
  readonly state = inject(FactoryStateService);

  getSignalValueClass(sig: PLCSignal): string {
    if (sig.type === 'BOOL') {
      return sig.value ? 'text-[#48654F]' : 'text-[#687174]';
    }
    return 'text-[#C18A35]';
  }

  toggleSignal(sig: PLCSignal): void {
    this.state.plcSignals.update((signals) =>
      signals.map((s) => (s.id === sig.id ? { ...s, value: !s.value } : s))
    );
  }

  triggerEmergencyStop(): void {
    this.state.plcSignals.update((signals) =>
      signals.map((s) => {
        if (s.tag === 'EMERGENCY_CIRCUIT_OK') return { ...s, value: false };
        if (s.tag === 'ROBOT_01_BUSY') return { ...s, value: false };
        return s;
      })
    );
    this.state.simulationRunning.set(false);
    this.state.addAuditLog('E-STOP', 'Interlock opened. All active machinery halted in fail-safe state.');
  }

  simulateDefect(): void {
    this.state.plcSignals.update((signals) =>
      signals.map((s) => (s.tag === 'VISION_QA_PASS' ? { ...s, value: false } : s))
    );
    this.state.addAuditLog('Vision QA Reject', 'Detected surface defect on transmission shaft. Routed to reject bin.');
  }
}
