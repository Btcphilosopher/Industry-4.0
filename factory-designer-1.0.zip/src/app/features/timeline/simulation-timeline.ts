import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { FactoryStateService } from '../../core/services/factory-state.service';
import { SimulationService } from '../../core/services/simulation.service';

@Component({
  selector: 'app-simulation-timeline',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [],
  template: `
    <footer class="h-16 bg-[#111415] border-t border-[#252A2C] px-5 flex items-center justify-between z-20 select-none">
      <!-- Playback Controls & Speed Selector -->
      <div class="flex items-center gap-3">
        <div class="flex items-center gap-1 bg-[#191d1e] p-1 rounded-lg border border-[#252A2C]">
          <!-- Reset to 0s -->
          <button
            type="button"
            (click)="resetTime()"
            class="px-2 py-1 text-xs text-[#A7ADAA] hover:text-white rounded hover:bg-[#252A2C] transition-colors cursor-pointer"
            title="Reset to 0.0s"
          >
            ⏮
          </button>
          <!-- Step -0.5s -->
          <button
            type="button"
            (click)="stepTime(-0.5)"
            class="px-2 py-1 text-xs text-[#A7ADAA] hover:text-white rounded hover:bg-[#252A2C] transition-colors cursor-pointer"
            title="Step Back -0.5s"
          >
            ◀
          </button>
          <!-- Play / Pause -->
          <button
            type="button"
            (click)="togglePlay()"
            [class]="state.simulationRunning() ? 'bg-[#304F60] text-white' : 'bg-[#252A2C] text-[#ECEBE5] hover:text-white'"
            class="px-3 py-1 text-xs font-semibold rounded transition-colors cursor-pointer"
          >
            {{ state.simulationRunning() ? '❚❚ PAUSE' : '▶ PLAY' }}
          </button>
          <!-- Step +0.5s -->
          <button
            type="button"
            (click)="stepTime(0.5)"
            class="px-2 py-1 text-xs text-[#A7ADAA] hover:text-white rounded hover:bg-[#252A2C] transition-colors cursor-pointer"
            title="Step Forward +0.5s"
          >
            ▶
          </button>
        </div>

        <!-- Simulation Speed Multiplier Tabs -->
        <div class="flex items-center gap-1 text-[11px] font-mono bg-[#191d1e] p-1 rounded-lg border border-[#252A2C]">
          <button
            type="button"
            (click)="setSpeed(0.5)"
            [class]="state.simulationSpeed() === 0.5 ? 'bg-[#304F60] text-white' : 'text-[#687174] hover:text-white'"
            class="px-1.5 py-0.5 rounded transition-colors"
          >
            0.5x
          </button>
          <button
            type="button"
            (click)="setSpeed(1.0)"
            [class]="state.simulationSpeed() === 1.0 ? 'bg-[#304F60] text-white' : 'text-[#687174] hover:text-white'"
            class="px-1.5 py-0.5 rounded transition-colors"
          >
            1.0x
          </button>
          <button
            type="button"
            (click)="setSpeed(2.0)"
            [class]="state.simulationSpeed() === 2.0 ? 'bg-[#304F60] text-white' : 'text-[#687174] hover:text-white'"
            class="px-1.5 py-0.5 rounded transition-colors"
          >
            2.0x
          </button>
          <button
            type="button"
            (click)="setSpeed(5.0)"
            [class]="state.simulationSpeed() === 5.0 ? 'bg-[#304F60] text-white' : 'text-[#687174] hover:text-white'"
            class="px-1.5 py-0.5 rounded transition-colors"
          >
            5.0x
          </button>
        </div>

        <!-- Time Timestamp Counter -->
        <div class="text-xs font-mono text-[#ECEBE5] tabular-nums bg-[#191d1e] px-3 py-1.5 rounded border border-[#252A2C]">
          <span class="text-[#687174]">SIM:</span> {{ state.simulationTime().toFixed(1) }}s / {{ state.simulationMaxTime().toFixed(0) }}s
        </div>
      </div>

      <!-- Center Scrubbing Slider Bar -->
      <div class="flex-1 max-w-xl mx-6 flex items-center gap-2">
        <span class="text-[10px] font-mono text-[#687174]">0.0s</span>
        <input
          type="range"
          min="0"
          [max]="state.simulationMaxTime()"
          step="0.1"
          [value]="state.simulationTime()"
          (input)="onTimelineInput($event)"
          class="w-full accent-[#304F60] bg-[#252A2C] h-1.5 rounded cursor-pointer"
        />
        <span class="text-[10px] font-mono text-[#687174]">{{ state.simulationMaxTime().toFixed(0) }}s</span>
      </div>

      <!-- Right Industrial KPI Mini Scoreboard -->
      <div class="hidden xl:flex items-center gap-4 text-xs font-mono">
        <div class="flex flex-col text-right">
          <span class="text-[10px] text-[#687174]">THROUGHPUT</span>
          <span class="font-bold text-[#ECEBE5]">{{ state.simulationKPIs().throughputPerHour }} parts/h</span>
        </div>
        <div class="flex flex-col text-right">
          <span class="text-[10px] text-[#687174]">POWER DEMAND</span>
          <span class="font-bold text-[#C18A35]">{{ state.simulationKPIs().totalInstantPowerMw }} MW</span>
        </div>
        <div class="flex flex-col text-right">
          <span class="text-[10px] text-[#687174]">BOTTLENECK</span>
          <span class="font-bold text-[#A44038]">{{ state.simulationKPIs().primaryBottleneckEquipmentId }}</span>
        </div>
        @if (state.simulationKPIs().activeWarnings > 0 || state.simulationKPIs().activeCollisions > 0) {
          <div class="flex items-center gap-1 bg-[#A44038]/20 border border-[#A44038]/40 px-2 py-1 rounded text-[#A44038] text-[11px]">
            <span>⚠ {{ state.simulationKPIs().activeCollisions }} Collision</span>
          </div>
        }
      </div>
    </footer>
  `,
})
export class SimulationTimeline {
  readonly state = inject(FactoryStateService);
  private readonly simulationService = inject(SimulationService);

  togglePlay(): void {
    this.state.toggleSimulationPlay();
  }

  resetTime(): void {
    this.state.setSimulationTime(0);
  }

  stepTime(delta: number): void {
    this.simulationService.stepSimulation(delta);
  }

  setSpeed(speed: number): void {
    this.state.simulationSpeed.set(speed);
  }

  onTimelineInput(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.state.setSimulationTime(parseFloat(input.value));
  }
}
