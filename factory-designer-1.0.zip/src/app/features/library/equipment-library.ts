import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { Equipment, EquipmentCategory } from '../../core/models/factory.types';
import { FactoryStateService } from '../../core/services/factory-state.service';

interface LibraryItemPreset {
  name: string;
  category: EquipmentCategory;
  type: Equipment['type'];
  manufacturer: string;
  model: string;
  dimensions: { width: number; length: number; height: number };
  powerKw: number;
  capex: number;
  cycleTime: number;
  reachRadius?: number;
  icon: string;
}

@Component({
  selector: 'app-equipment-library',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [],
  template: `
    <aside class="w-80 h-full bg-[#191d1e] border-r border-[#252A2C] flex flex-col z-20 select-none">
      <!-- Library Header & Category Filter Tabs -->
      <div class="p-3 border-b border-[#252A2C]">
        <div class="flex items-center justify-between mb-2">
          <span class="text-xs font-semibold text-[#ECEBE5] tracking-wider uppercase font-mono">Equipment Catalog</span>
          <span class="text-[11px] font-mono text-[#687174]">{{ presets().length }} Presets</span>
        </div>

        <!-- Filter Segmented Tabs -->
        <div class="flex items-center gap-1 overflow-x-auto pb-1 text-xs">
          @for (cat of categories; track cat.id) {
            <button
              type="button"
              (click)="activeCategory.set(cat.id)"
              [class]="activeCategory() === cat.id ? 'bg-[#304F60] text-white' : 'text-[#A7ADAA] hover:text-white bg-[#252A2C]'"
              class="px-2.5 py-1 rounded text-[11px] font-mono whitespace-nowrap transition-colors"
            >
              {{ cat.label }}
            </button>
          }
        </div>
      </div>

      <!-- Presets Scrollable List -->
      <div class="flex-1 overflow-y-auto p-3 space-y-2">
        @for (item of filteredPresets(); track item.model) {
          <div
            tabindex="0"
            role="button"
            class="p-3 bg-[#111415] border border-[#252A2C] hover:border-[#426A7A] rounded-lg transition-all group cursor-pointer focus:outline-none focus:border-[#426A7A]"
            (click)="spawnEquipment(item)"
            (keydown.enter)="spawnEquipment(item)"
          >
            <div class="flex items-start justify-between">
              <div>
                <h4 class="text-xs font-semibold text-[#ECEBE5] group-hover:text-white">{{ item.name }}</h4>
                <p class="text-[11px] font-mono text-[#687174]">{{ item.manufacturer }} · {{ item.model }}</p>
              </div>
              <span class="text-[11px] font-mono text-[#C18A35] font-semibold">£{{ (item.capex / 1000).toFixed(0) }}k</span>
            </div>

            <!-- Specs Grid -->
            <div class="mt-2.5 pt-2 border-t border-[#252A2C] grid grid-cols-3 gap-1 text-[10px] font-mono text-[#A7ADAA]">
              <div>
                <span class="text-[#687174]">Cycle:</span> {{ item.cycleTime }}s
              </div>
              <div>
                <span class="text-[#687174]">Power:</span> {{ item.powerKw }}kW
              </div>
              <div>
                <span class="text-[#687174]">Dim:</span> {{ (item.dimensions.width / 1000).toFixed(1) }}m
              </div>
            </div>

            <button
              type="button"
              class="mt-2.5 w-full py-1 text-[11px] font-mono text-center text-[#ECEBE5] bg-[#252A2C] hover:bg-[#304F60] rounded transition-colors"
            >
              + Place into Factory
            </button>
          </div>
        }
      </div>

      <!-- Footer Quick Status -->
      <div class="p-3 border-t border-[#252A2C] bg-[#111415] text-[11px] font-mono text-[#687174] flex justify-between items-center">
        <span>INSTALLED: {{ state.equipmentList().length }} UNITS</span>
        <span>TOTAL: £{{ (state.totalCapex() / 1000000).toFixed(2) }}M</span>
      </div>
    </aside>
  `,
})
export class EquipmentLibrary {
  readonly state = inject(FactoryStateService);

  readonly activeCategory = signal<string>('ALL');

  readonly categories = [
    { id: 'ALL', label: 'All' },
    { id: 'ROBOTICS', label: 'Robots' },
    { id: 'MACHINING', label: 'Machining' },
    { id: 'METALLURGY', label: 'Thermal' },
    { id: 'MATERIAL_HANDLING', label: 'Conveyors' },
    { id: 'STORAGE', label: 'Storage' },
    { id: 'FINISHING', label: 'QA / Inspection' },
  ];

  readonly presets = signal<LibraryItemPreset[]>([
    {
      name: 'SR-210 Industrial 6-Axis Robot',
      category: 'ROBOTICS',
      type: 'industrial_6_axis',
      manufacturer: 'Synthetic Robotics UK',
      model: 'SR-210 Heavy',
      dimensions: { width: 1400, length: 1400, height: 2600 },
      powerKw: 7.2,
      capex: 145000,
      cycleTime: 4.8,
      reachRadius: 2400,
      icon: 'precision_manufacturing',
    },
    {
      name: 'SC-450 High-Speed SCARA Robot',
      category: 'ROBOTICS',
      type: 'scara_robot',
      manufacturer: 'Synthetic Robotics UK',
      model: 'SC-450 Pick',
      dimensions: { width: 1000, length: 1000, height: 1800 },
      powerKw: 3.5,
      capex: 85000,
      cycleTime: 1.8,
      reachRadius: 1200,
      icon: 'precision_manufacturing',
    },
    {
      name: '5-Axis High-Torque CNC Mill',
      category: 'MACHINING',
      type: 'cnc_mill',
      manufacturer: 'Derby Precision Tools',
      model: 'DPT-M5000',
      dimensions: { width: 3400, length: 3200, height: 2800 },
      powerKw: 38.0,
      capex: 420000,
      cycleTime: 18.0,
      icon: 'settings',
    },
    {
      name: 'Precision Fiber Laser Cutter',
      category: 'MACHINING',
      type: 'laser_cutter',
      manufacturer: 'Sheffield Toolworks',
      model: 'ST-FL8000',
      dimensions: { width: 4200, length: 3000, height: 2400 },
      powerKw: 28.5,
      capex: 285000,
      cycleTime: 8.5,
      icon: 'content_cut',
    },
    {
      name: 'Induction Austenitising Hardening Furnace',
      category: 'METALLURGY',
      type: 'induction_furnace',
      manufacturer: 'Vulcan Thermal Systems',
      model: 'VT-IND850',
      dimensions: { width: 4800, length: 5200, height: 3800 },
      powerKw: 145.0,
      capex: 580000,
      cycleTime: 24.0,
      icon: 'local_fire_department',
    },
    {
      name: 'Automated Polymer Quench Tank',
      category: 'METALLURGY',
      type: 'quench_tank',
      manufacturer: 'Vulcan Thermal Systems',
      model: 'VT-QNK400',
      dimensions: { width: 3600, length: 4200, height: 2600 },
      powerKw: 18.0,
      capex: 180000,
      cycleTime: 12.0,
      icon: 'waves',
    },
    {
      name: 'Heavy Duty Modular Roller Conveyor',
      category: 'MATERIAL_HANDLING',
      type: 'roller_conveyor',
      manufacturer: 'Derby Conveyors Ltd',
      model: 'DC-ROLLER-800',
      dimensions: { width: 1200, length: 14000, height: 800 },
      powerKw: 4.8,
      capex: 65000,
      cycleTime: 4.0,
      icon: 'linear_scale',
    },
    {
      name: 'Autonomous Guided Vehicle (AGV 2-Ton)',
      category: 'MATERIAL_HANDLING',
      type: 'agv',
      manufacturer: 'Sheffield Autonomous',
      model: 'SA-AGV-2000',
      dimensions: { width: 1400, length: 2200, height: 550 },
      powerKw: 2.8,
      capex: 68000,
      cycleTime: 15.0,
      icon: 'local_shipping',
    },
    {
      name: '3D Optical Metrology & Vision QA',
      category: 'FINISHING',
      type: 'vision_inspection',
      manufacturer: 'CogniMetrix UK',
      model: 'CM-3D-SCAN-900',
      dimensions: { width: 2800, length: 2400, height: 2600 },
      powerKw: 4.5,
      capex: 185000,
      cycleTime: 4.2,
      icon: 'camera_alt',
    },
    {
      name: 'High-Density Automated Pallet Buffer',
      category: 'STORAGE',
      type: 'pallet_rack',
      manufacturer: 'Sheffield Logistics',
      model: 'SL-RACK-400',
      dimensions: { width: 6000, length: 12000, height: 6500 },
      powerKw: 2.0,
      capex: 140000,
      cycleTime: 2.0,
      icon: 'inventory_2',
    },
  ]);

  filteredPresets = () => {
    const cat = this.activeCategory();
    if (cat === 'ALL') return this.presets();
    return this.presets().filter((p) => p.category === cat);
  };

  spawnEquipment(preset: LibraryItemPreset): void {
    const nextIdNum = this.state.equipmentList().length + 1;
    const newEq: Equipment = {
      id: `EQ-AUTO-${nextIdNum}`,
      code: `${preset.model}-${nextIdNum}`,
      name: `${preset.name} #${nextIdNum}`,
      category: preset.category,
      type: preset.type,
      manufacturer: preset.manufacturer,
      model: preset.model,
      position: { x: (Math.random() - 0.5) * 40000, y: (Math.random() - 0.5) * 20000, z: 0 },
      rotation: { x: 0, y: 0, z: 0 },
      dimensions: { ...preset.dimensions },
      state: 'IDLE',
      provenance: 'DESIGNED',
      brownfieldStatus: 'PROPOSED',
      cycleTime: preset.cycleTime,
      processTime: preset.cycleTime * 0.85,
      transferTime: preset.cycleTime * 0.15,
      availability: 0.98,
      mtbfHours: 2000,
      mttrHours: 2.0,
      idlePowerKw: Number((preset.powerKw * 0.2).toFixed(1)),
      processPowerKw: preset.powerKw,
      peakPowerKw: Number((preset.powerKw * 1.3).toFixed(1)),
      capexCost: preset.capex,
      installationCost: preset.capex * 0.12,
      maintenanceCostPerHour: 35,
      expectedLifeYears: 12,
      safetyRadius: 3000,
      maintenanceClearance: 1200,
      reachRadius: preset.reachRadius,
      upstreamEquipmentIds: [],
      downstreamEquipmentIds: [],
      queueCount: 0,
      maxQueueCapacity: 6,
      hoursRunTotal: 0,
      healthIndex: 100,
      failureProbability: 0.01,
      robotJoints:
        preset.category === 'ROBOTICS'
          ? [
              { id: 1, name: 'Joint 1 (Base Yaw)', minAngle: -170, maxAngle: 170, currentAngle: 0, maxSpeed: 120 },
              { id: 2, name: 'Joint 2 (Shoulder Pitch)', minAngle: -65, maxAngle: 85, currentAngle: 0, maxSpeed: 110 },
              { id: 3, name: 'Joint 3 (Elbow Pitch)', minAngle: -180, maxAngle: 70, currentAngle: 0, maxSpeed: 130 },
              { id: 4, name: 'Joint 4 (Wrist Roll)', minAngle: -300, maxAngle: 300, currentAngle: 0, maxSpeed: 210 },
              { id: 5, name: 'Joint 5 (Wrist Pitch)', minAngle: -130, maxAngle: 130, currentAngle: 0, maxSpeed: 220 },
              { id: 6, name: 'Joint 6 (Tool Flange)', minAngle: -360, maxAngle: 360, currentAngle: 0, maxSpeed: 300 },
            ]
          : undefined,
    };

    this.state.addEquipment(newEq);
  }
}
