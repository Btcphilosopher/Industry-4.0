import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { FactoryStateService } from '../../core/services/factory-state.service';

@Component({
  selector: 'app-report-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [],
  template: `
    <div class="w-full h-full bg-[#111415] text-[#ECEBE5] p-6 overflow-y-auto font-sans select-none">
      <!-- Report Header -->
      <div class="flex items-center justify-between pb-4 border-b border-[#252A2C] mb-6">
        <div>
          <h2 class="text-lg font-bold tracking-tight text-[#ECEBE5]">Digital Factory Engineering Report & BOM Register</h2>
          <p class="text-xs font-mono text-[#687174]">Capital Expenditure (CAPEX) · Operating Cost (OPEX) · Energy Audit · Audit Trail</p>
        </div>
        <div class="flex items-center gap-2">
          <button
            type="button"
            (click)="printReport()"
            class="px-3 py-1.5 bg-[#252A2C] hover:bg-[#32383a] border border-[#32383a] rounded-lg text-xs font-mono text-[#ECEBE5] transition-colors cursor-pointer"
          >
            🖨 Print / Export PDF
          </button>
          <button
            type="button"
            (click)="state.setMode('DESIGN')"
            class="px-3 py-1.5 bg-[#304F60] hover:bg-[#426A7A] rounded-lg text-xs font-semibold text-white transition-colors cursor-pointer"
          >
            Back to 3D Canvas
          </button>
        </div>
      </div>

      <div class="space-y-6 max-w-6xl mx-auto">
        <!-- Top Executive Financial & KPI Summary -->
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div class="p-4 bg-[#191d1e] border border-[#252A2C] rounded-xl font-mono">
            <span class="text-[10px] text-[#687174] uppercase block">Total Installed CAPEX</span>
            <span class="text-xl font-bold text-[#ECEBE5] mt-1 block">£{{ (totalCapex() / 1000000).toFixed(2) }}M</span>
            <span class="text-[10px] text-[#48654F]">Equipment + Commissioning</span>
          </div>

          <div class="p-4 bg-[#191d1e] border border-[#252A2C] rounded-xl font-mono">
            <span class="text-[10px] text-[#687174] uppercase block">Simulated Throughput</span>
            <span class="text-xl font-bold text-[#C18A35] mt-1 block">{{ state.simulationKPIs().throughputPerHour }} parts/h</span>
            <span class="text-[10px] text-[#A7ADAA]">2.8s tact time target</span>
          </div>

          <div class="p-4 bg-[#191d1e] border border-[#252A2C] rounded-xl font-mono">
            <span class="text-[10px] text-[#687174] uppercase block">Peak Power Demand</span>
            <span class="text-xl font-bold text-[#ECEBE5] mt-1 block">{{ state.simulationKPIs().totalInstantPowerMw }} MW</span>
            <span class="text-[10px] text-[#687174]">Grid connection compliant</span>
          </div>

          <div class="p-4 bg-[#191d1e] border border-[#252A2C] rounded-xl font-mono">
            <span class="text-[10px] text-[#687174] uppercase block">Energy per Part</span>
            <span class="text-xl font-bold text-[#48654F] mt-1 block">{{ state.simulationKPIs().energyPerPartKwh }} kWh</span>
            <span class="text-[10px] text-[#48654F]">Est. £0.38 / component</span>
          </div>
        </div>

        <!-- Bill of Materials (BOM) Category Aggregation -->
        <div class="bg-[#191d1e] border border-[#252A2C] rounded-xl p-5 space-y-4">
          <div class="flex items-center justify-between border-b border-[#252A2C] pb-3">
            <h3 class="text-xs font-semibold uppercase tracking-wider font-mono text-[#ECEBE5]">Bill of Materials (BOM) Summary</h3>
            <span class="text-[11px] font-mono text-[#687174]">{{ state.equipmentList().length }} Total Assets</span>
          </div>

          <div class="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs font-mono">
            <div class="bg-[#111415] p-3 rounded border border-[#252A2C]">
              <span class="text-[#687174] text-[10px] block">ROBOTIC ARMS</span>
              <span class="text-lg font-bold text-[#ECEBE5]">{{ getCategoryCount('ROBOTICS') }} Units</span>
            </div>
            <div class="bg-[#111415] p-3 rounded border border-[#252A2C]">
              <span class="text-[#687174] text-[10px] block">CNC & MACHINING</span>
              <span class="text-lg font-bold text-[#ECEBE5]">{{ getCategoryCount('MACHINING') }} Units</span>
            </div>
            <div class="bg-[#111415] p-3 rounded border border-[#252A2C]">
              <span class="text-[#687174] text-[10px] block">THERMAL & METALLURGY</span>
              <span class="text-lg font-bold text-[#ECEBE5]">{{ getCategoryCount('METALLURGY') }} Units</span>
            </div>
            <div class="bg-[#111415] p-3 rounded border border-[#252A2C]">
              <span class="text-[#687174] text-[10px] block">CONVEYORS & AGVs</span>
              <span class="text-lg font-bold text-[#ECEBE5]">{{ getCategoryCount('MATERIAL_HANDLING') }} Units</span>
            </div>
          </div>
        </div>

        <!-- Detailed Equipment Inventory Table -->
        <div class="bg-[#191d1e] border border-[#252A2C] rounded-xl p-5 space-y-3">
          <h3 class="text-xs font-semibold uppercase tracking-wider font-mono text-[#ECEBE5]">Asset Inventory & Financial Schedule</h3>

          <div class="overflow-x-auto">
            <table class="w-full text-left font-mono text-xs">
              <thead>
                <tr class="border-b border-[#252A2C] text-[#687174] text-[10px] uppercase">
                  <th class="py-2 px-3">Asset Code</th>
                  <th class="py-2 px-3">Equipment Name</th>
                  <th class="py-2 px-3">Category</th>
                  <th class="py-2 px-3 text-right">Power (kW)</th>
                  <th class="py-2 px-3 text-right">CAPEX (£)</th>
                  <th class="py-2 px-3 text-right">Install (£)</th>
                  <th class="py-2 px-3 text-right">MTBF (h)</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-[#252A2C]">
                @for (item of state.equipmentList(); track item.id) {
                  <tr class="hover:bg-[#111415] transition-colors">
                    <td class="py-2 px-3 font-bold text-[#ECEBE5]">{{ item.code }}</td>
                    <td class="py-2 px-3 text-[#A7ADAA]">{{ item.name }}</td>
                    <td class="py-2 px-3 text-[#687174]">{{ item.category }}</td>
                    <td class="py-2 px-3 text-right text-[#C18A35]">{{ item.processPowerKw }}</td>
                    <td class="py-2 px-3 text-right text-[#ECEBE5]">£{{ item.capexCost.toLocaleString() }}</td>
                    <td class="py-2 px-3 text-right text-[#687174]">£{{ item.installationCost.toLocaleString() }}</td>
                    <td class="py-2 px-3 text-right text-[#48654F]">{{ item.mtbfHours }}</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>

        <!-- Audit Trail / Digital Thread -->
        <div class="bg-[#191d1e] border border-[#252A2C] rounded-xl p-5 space-y-3">
          <h3 class="text-xs font-semibold uppercase tracking-wider font-mono text-[#ECEBE5]">Digital Thread Audit Trail</h3>

          <div class="space-y-2 font-mono text-xs max-h-48 overflow-y-auto">
            @for (log of state.auditLogs(); track log.id) {
              <div class="p-2.5 bg-[#111415] rounded border border-[#252A2C] flex items-center justify-between">
                <div class="flex items-center gap-3">
                  <span class="text-[10px] text-[#687174]">{{ log.timestamp }}</span>
                  <span class="text-[11px] font-bold text-[#304F60]">{{ log.userRole }}</span>
                  <span class="text-[#ECEBE5] text-[11px]">{{ log.action }}: {{ log.details }}</span>
                </div>
                <span class="text-[10px] text-[#48654F]">Verified</span>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `,
})
export class ReportView {
  readonly state = inject(FactoryStateService);

  readonly totalCapex = this.state.totalCapex;

  getCategoryCount(category: string): number {
    return this.state.equipmentList().filter((e) => e.category === category).length;
  }

  printReport(): void {
    if (typeof window !== 'undefined') {
      window.print();
    }
  }
}
