import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { FactoryStateService } from '../../core/services/factory-state.service';

@Component({
  selector: 'app-scenarios-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [],
  template: `
    <div class="w-full h-full bg-[#111415] text-[#ECEBE5] p-6 overflow-y-auto font-sans select-none">
      <!-- Compare Header -->
      <div class="flex items-center justify-between pb-4 border-b border-[#252A2C] mb-6">
        <div>
          <h2 class="text-lg font-bold tracking-tight text-[#ECEBE5]">Brownfield Facility Modernisation Comparison</h2>
          <p class="text-xs font-mono text-[#687174]">Current Brownfield Baseline vs Proposed Industry 4.0 Automated Plant</p>
        </div>
        <button
          type="button"
          (click)="state.setMode('DESIGN')"
          class="px-3 py-1.5 bg-[#304F60] hover:bg-[#426A7A] rounded-lg text-xs font-semibold text-white transition-colors cursor-pointer"
        >
          Back to 3D Canvas
        </button>
      </div>

      <!-- Comparison Cards -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8 max-w-6xl mx-auto">
        <!-- Baseline Existing Facility -->
        <div class="bg-[#191d1e] border border-[#252A2C] rounded-xl p-6 space-y-4">
          <div class="flex items-center justify-between border-b border-[#252A2C] pb-3">
            <div>
              <h3 class="font-bold text-sm text-[#A7ADAA]">BEFORE: Brownfield Baseline (2024)</h3>
              <p class="text-[11px] font-mono text-[#687174]">Manual load/unload · Legacy batch ovens · Forklift logistics</p>
            </div>
            <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#252A2C] text-[#687174]">LEGACY</span>
          </div>

          <div class="space-y-3 font-mono text-xs">
            <div class="flex justify-between p-2.5 bg-[#111415] rounded border border-[#252A2C]">
              <span class="text-[#687174]">THROUGHPUT:</span>
              <span class="font-bold text-[#ECEBE5]">980 parts/hour</span>
            </div>
            <div class="flex justify-between p-2.5 bg-[#111415] rounded border border-[#252A2C]">
              <span class="text-[#687174]">OPERATOR HEADCOUNT:</span>
              <span class="font-bold text-[#A44038]">42 Operators / shift</span>
            </div>
            <div class="flex justify-between p-2.5 bg-[#111415] rounded border border-[#252A2C]">
              <span class="text-[#687174]">AVERAGE CYCLE TIME:</span>
              <span class="font-bold text-[#ECEBE5]">24.5 seconds</span>
            </div>
            <div class="flex justify-between p-2.5 bg-[#111415] rounded border border-[#252A2C]">
              <span class="text-[#687174]">SCRAP / DEFECT RATE:</span>
              <span class="font-bold text-[#A44038]">3.8% (Manual Inspection)</span>
            </div>
          </div>
        </div>

        <!-- Proposed Modernised Facility -->
        <div class="bg-[#191d1e] border-2 border-[#304F60] rounded-xl p-6 space-y-4 ring-1 ring-[#426A7A]">
          <div class="flex items-center justify-between border-b border-[#252A2C] pb-3">
            <div>
              <h3 class="font-bold text-sm text-[#ECEBE5]">AFTER: Proposed Digital Factory 1.0</h3>
              <p class="text-[11px] font-mono text-[#48654F]">8x 6-Axis Robots · Induction Thermal Loop · AGV Autonomous Fleet</p>
            </div>
            <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#48654F]/30 text-[#48654F]">OPTIMISED</span>
          </div>

          <div class="space-y-3 font-mono text-xs">
            <div class="flex justify-between p-2.5 bg-[#111415] rounded border border-[#304F60]/40">
              <span class="text-[#687174]">THROUGHPUT:</span>
              <span class="font-bold text-[#48654F]">1,284 parts/hour (+31.0%)</span>
            </div>
            <div class="flex justify-between p-2.5 bg-[#111415] rounded border border-[#304F60]/40">
              <span class="text-[#687174]">OPERATOR HEADCOUNT:</span>
              <span class="font-bold text-[#48654F]">12 Supervisors / shift (-71%)</span>
            </div>
            <div class="flex justify-between p-2.5 bg-[#111415] rounded border border-[#304F60]/40">
              <span class="text-[#687174]">AVERAGE CYCLE TIME:</span>
              <span class="font-bold text-[#48654F]">18.2 seconds (-25.7%)</span>
            </div>
            <div class="flex justify-between p-2.5 bg-[#111415] rounded border border-[#304F60]/40">
              <span class="text-[#687174]">SCRAP / DEFECT RATE:</span>
              <span class="font-bold text-[#48654F]">0.4% (3D Optical QA)</span>
            </div>
          </div>
        </div>
      </div>

      <!-- ROI & Financial Payback Scorecard -->
      <div class="bg-[#191d1e] border border-[#252A2C] rounded-xl p-6 max-w-6xl mx-auto space-y-4">
        <h3 class="text-sm font-bold uppercase tracking-wider font-mono text-[#ECEBE5]">Capital Investment & Payback Analysis</h3>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
          <div class="p-4 bg-[#111415] rounded-lg border border-[#252A2C]">
            <span class="text-[10px] text-[#687174] block uppercase">Net Capital Outlay</span>
            <span class="text-xl font-bold text-[#ECEBE5] mt-1 block">£10.2M</span>
            <span class="text-[10px] text-[#A7ADAA]">Retrofit + New Equipment</span>
          </div>

          <div class="p-4 bg-[#111415] rounded-lg border border-[#252A2C]">
            <span class="text-[10px] text-[#687174] block uppercase">Annual OPEX Savings</span>
            <span class="text-xl font-bold text-[#48654F] mt-1 block">£5.6M / year</span>
            <span class="text-[10px] text-[#48654F]">Labor + Energy + Scrap</span>
          </div>

          <div class="p-4 bg-[#111415] rounded-lg border border-[#252A2C]">
            <span class="text-[10px] text-[#687174] block uppercase">Estimated Payback</span>
            <span class="text-xl font-bold text-[#C18A35] mt-1 block">1.82 Years</span>
            <span class="text-[10px] text-[#48654F]">Internal Rate of Return: 54.8%</span>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class ScenariosCompareView {
  readonly state = inject(FactoryStateService);
}
