import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { RobotTool } from '../../core/models/factory.types';
import { FactoryStateService } from '../../core/services/factory-state.service';
import { GripSafetyEvaluation, KinematicsService } from '../../core/services/kinematics.service';

@Component({
  selector: 'app-robot-studio',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [],
  template: `
    <div class="w-full h-full bg-[#111415] text-[#ECEBE5] p-6 overflow-y-auto font-sans select-none">
      <!-- Studio Header -->
      <div class="flex items-center justify-between pb-4 border-b border-[#252A2C] mb-6">
        <div>
          <h2 class="text-lg font-bold tracking-tight text-[#ECEBE5]">Robot Configuration & Precision Grip Studio</h2>
          <p class="text-xs font-mono text-[#687174]">Kinematic Forward/Inverse Kinematics · Reach Envelope · Dynamic Grip Safety</p>
        </div>
        <div class="flex items-center gap-2">
          <select
            (change)="onRobotSelect($event)"
            class="bg-[#191d1e] border border-[#32383a] rounded-lg px-3 py-1.5 text-xs font-mono text-[#ECEBE5] outline-none"
          >
            @for (robot of robots(); track robot.id) {
              <option [value]="robot.id" [selected]="selectedRobot()?.id === robot.id">
                {{ robot.code }} · {{ robot.name }}
              </option>
            }
          </select>
          <button
            type="button"
            (click)="state.setMode('DESIGN')"
            class="px-3 py-1.5 bg-[#304F60] hover:bg-[#426A7A] rounded-lg text-xs font-semibold text-white transition-colors cursor-pointer"
          >
            Back to 3D Canvas
          </button>
        </div>
      </div>

      @if (selectedRobot(); as robot) {
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <!-- Column 1: Kinematics & Joint Angle Controller -->
          <div class="bg-[#191d1e] border border-[#252A2C] rounded-xl p-5 space-y-4">
            <div class="flex justify-between items-center border-b border-[#252A2C] pb-3">
              <h3 class="text-xs font-semibold uppercase tracking-wider font-mono text-[#ECEBE5]">6-Axis Joint Kinematics</h3>
              <span class="text-[11px] font-mono text-[#48654F]">Forward Kinematics Solved</span>
            </div>

            <div class="space-y-3">
              @for (joint of robot.robotJoints || []; track joint.id) {
                <div class="space-y-1">
                  <div class="flex justify-between text-xs font-mono">
                    <span class="text-[#A7ADAA]">J{{ joint.id }} · {{ joint.name }}</span>
                    <span class="text-[#ECEBE5] font-bold">{{ joint.currentAngle.toFixed(1) }}°</span>
                  </div>
                  <input
                    type="range"
                    [min]="joint.minAngle"
                    [max]="joint.maxAngle"
                    [value]="joint.currentAngle"
                    (input)="onJointChange(joint.id, $event)"
                    class="w-full accent-[#304F60] bg-[#252A2C] h-1.5 rounded cursor-pointer"
                  />
                  <div class="flex justify-between text-[10px] font-mono text-[#687174]">
                    <span>{{ joint.minAngle }}°</span>
                    <span>Max: {{ joint.maxSpeed }}°/s</span>
                    <span>{{ joint.maxAngle }}°</span>
                  </div>
                </div>
              }
            </div>

            <!-- Workspace Reach Envelope Metrics -->
            <div class="pt-3 border-t border-[#252A2C] grid grid-cols-2 gap-2 text-xs font-mono">
              <div class="bg-[#111415] p-2.5 rounded border border-[#252A2C]">
                <span class="text-[10px] text-[#687174] block">MAX SPHERICAL REACH</span>
                <span class="text-sm font-bold text-[#ECEBE5]">{{ ((robot.reachRadius ?? 2400) / 1000).toFixed(2) }} m</span>
              </div>
              <div class="bg-[#111415] p-2.5 rounded border border-[#252A2C]">
                <span class="text-[10px] text-[#687174] block">RATED PAYLOAD</span>
                <span class="text-sm font-bold text-[#C18A35]">{{ robot.maxPayloadKg ?? 180 }} kg</span>
              </div>
            </div>
          </div>

          <!-- Column 2: Precision Grip Designer & Physics Model -->
          <div class="bg-[#191d1e] border border-[#252A2C] rounded-xl p-5 space-y-4">
            <div class="flex justify-between items-center border-b border-[#252A2C] pb-3">
              <h3 class="text-xs font-semibold uppercase tracking-wider font-mono text-[#ECEBE5]">Precision Grip Physics Safety</h3>
              <span class="text-[11px] font-mono" [class]="gripEval().feasibilityStatus === 'SAFE' ? 'text-[#48654F]' : 'text-[#A44038]'">
                {{ gripEval().feasibilityStatus }}
              </span>
            </div>

            <!-- Parametric Part Input Controls -->
            <div class="space-y-3">
              <span class="text-[11px] font-mono text-[#687174] uppercase tracking-wider block">Target Component (Steel Shaft)</span>
              <div class="grid grid-cols-3 gap-2 text-xs font-mono">
                <div>
                  <span class="text-[10px] text-[#A7ADAA] block">Mass (kg)</span>
                  <input
                    type="number"
                    [value]="partMass()"
                    (input)="partMass.set(getInputValue($event))"
                    class="w-full bg-[#111415] border border-[#252A2C] rounded px-2 py-1 text-[#ECEBE5]"
                  />
                </div>
                <div>
                  <span class="text-[10px] text-[#A7ADAA] block">Length (mm)</span>
                  <input
                    type="number"
                    [value]="partLength()"
                    (input)="partLength.set(getInputValue($event))"
                    class="w-full bg-[#111415] border border-[#252A2C] rounded px-2 py-1 text-[#ECEBE5]"
                  />
                </div>
                <div>
                  <span class="text-[10px] text-[#A7ADAA] block">Diameter (mm)</span>
                  <input
                    type="number"
                    [value]="partDiameter()"
                    (input)="partDiameter.set(getInputValue($event))"
                    class="w-full bg-[#111415] border border-[#252A2C] rounded px-2 py-1 text-[#ECEBE5]"
                  />
                </div>
              </div>
            </div>

            <!-- Active End-Effector Tool -->
            <div class="space-y-2 pt-2 border-t border-[#252A2C]">
              <span class="text-[11px] font-mono text-[#687174] uppercase tracking-wider block">End-Effector Gripper</span>
              <div class="p-3 bg-[#111415] border border-[#252A2C] rounded-lg space-y-1">
                <div class="flex justify-between text-xs font-semibold text-[#ECEBE5]">
                  <span>{{ robot.activeTool?.name ?? 'Standard Hydraulic Gripper' }}</span>
                  <span class="font-mono text-[#C18A35]">{{ robot.activeTool?.gripForce }} N Force</span>
                </div>
                <div class="text-[11px] font-mono text-[#687174]">
                  Tool Mass: {{ robot.activeTool?.mass }}kg · Jaw Stroke: 160mm
                </div>
              </div>
            </div>

            <!-- Synthetic Grip Physics Metrics -->
            <div class="p-3 bg-[#111415] border border-[#252A2C] rounded-lg space-y-2 text-xs font-mono">
              <div class="flex justify-between">
                <span class="text-[#A7ADAA]">Required Clamping Force (4.5m/s² load):</span>
                <span class="text-[#ECEBE5] font-bold">{{ gripEval().requiredForceN }} N</span>
              </div>
              <div class="flex justify-between">
                <span class="text-[#A7ADAA]">Grip Safety Factor (SF):</span>
                <span class="text-[#48654F] font-bold">{{ gripEval().safetyFactor }}x</span>
              </div>
              <div class="flex justify-between">
                <span class="text-[#A7ADAA]">Available Payload Margin:</span>
                <span class="text-[#ECEBE5] font-bold">{{ gripEval().payloadMarginKg }} kg</span>
              </div>
              <div class="flex justify-between">
                <span class="text-[#A7ADAA]">Center of Mass Offset:</span>
                <span class="text-[#ECEBE5] font-bold">{{ gripEval().comOffsetMm }} mm</span>
              </div>
            </div>

            <p class="text-[10px] font-mono text-[#687174] italic">
              {{ gripEval().simulationNote }}
            </p>
          </div>

          <!-- Column 3: Abstract Offline Robot Program (OLP) Layer -->
          <div class="bg-[#191d1e] border border-[#252A2C] rounded-xl p-5 flex flex-col">
            <div class="flex justify-between items-center border-b border-[#252A2C] pb-3 mb-3">
              <h3 class="text-xs font-semibold uppercase tracking-wider font-mono text-[#ECEBE5]">Offline Program (OLP)</h3>
              <button
                type="button"
                (click)="copyOLP()"
                class="px-2.5 py-1 bg-[#252A2C] hover:bg-[#304F60] text-[11px] font-mono text-[#ECEBE5] rounded transition-colors"
              >
                {{ copied() ? '✓ Copied' : 'Copy Code' }}
              </button>
            </div>

            <pre class="flex-1 bg-[#111415] border border-[#252A2C] rounded-lg p-3 text-[10px] font-mono text-[#A7ADAA] overflow-x-auto leading-relaxed">{{ olpCode() }}</pre>
          </div>
        </div>
      }
    </div>
  `,
})
export class RobotStudio {
  readonly state = inject(FactoryStateService);
  private readonly kinematicsService = inject(KinematicsService);

  readonly partMass = signal<number>(48.0);
  readonly partLength = signal<number>(640);
  readonly partDiameter = signal<number>(120);
  readonly copied = signal<boolean>(false);

  readonly robots = computed(() => this.state.equipmentList().filter((e) => e.category === 'ROBOTICS'));

  readonly selectedRobot = computed(() => {
    const selId = this.state.selectedEquipmentId();
    return this.robots().find((r) => r.id === selId) || this.robots()[0] || null;
  });

  readonly gripEval = computed<GripSafetyEvaluation>(() => {
    const robot = this.selectedRobot();
    const tool: RobotTool = robot?.activeTool ?? {
      id: 'TOOL-DEF',
      name: 'Standard Jaw',
      type: 'parallel_gripper',
      mass: 14.5,
      maxPayload: 180,
      gripForce: 4200,
      reachOffset: 240,
      operatingTime: 0.6,
    };
    return this.kinematicsService.evaluateGripSafety(this.partMass(), this.partLength(), this.partDiameter(), tool);
  });

  readonly olpCode = computed(() => {
    const robot = this.selectedRobot();
    if (!robot) return '';
    return this.kinematicsService.generateOLPProgram(robot.id, robot.name, robot.robotJoints || [], robot.activeTool);
  });

  onRobotSelect(event: Event): void {
    const select = event.target as HTMLSelectElement;
    this.state.selectEquipment(select.value);
  }

  onJointChange(jointId: number, event: Event): void {
    const robot = this.selectedRobot();
    if (robot) {
      const input = event.target as HTMLInputElement;
      this.state.updateRobotJoint(robot.id, jointId, parseFloat(input.value));
    }
  }

  getInputValue(event: Event): number {
    return parseFloat((event.target as HTMLInputElement).value) || 0;
  }

  copyOLP(): void {
    navigator.clipboard.writeText(this.olpCode());
    this.copied.set(true);
    setTimeout(() => this.copied.set(false), 2000);
  }
}
