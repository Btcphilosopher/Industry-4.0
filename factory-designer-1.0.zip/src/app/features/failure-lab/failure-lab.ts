import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { FactoryStateService } from '../../core/services/factory-state.service';

@Component({
  selector: 'app-failure-lab',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [],
  template: `
    <div class="w-full h-full bg-[#111415] text-[#ECEBE5] p-6 overflow-y-auto font-sans select-none">
      <!-- Failure Lab Header -->
      <div class="flex items-center justify-between pb-4 border-b border-[#252A2C] mb-6">
        <div>
          <h2 class="text-lg font-bold tracking-tight text-[#A44038]">Industrial Failure Lab & Resilience Sandbox</h2>
          <p class="text-xs font-mono text-[#687174]">Deliberate Fault Injection · Failure Propagation · Dynamic Buffer Depletion · MTTR Recovery</p>
        </div>
        <div class="flex items-center gap-2">
          <button
            type="button"
            (click)="resetAllFaults()"
            class="px-3 py-1.5 bg-[#48654F] hover:bg-[#3b5441] rounded-lg text-xs font-semibold text-white transition-colors cursor-pointer"
          >
            ✓ Clear All Faults
          </button>
          <button
            type="button"
            (click)="state.setMode('DESIGN')"
            class="px-3 py-1.5 bg-[#304F60] hover:bg-[#426A7A] rounded-lg text-xs font-semibold text-white transition-colors cursor-pointer"
          >
            Back to 3D Canvas
          </button>
        </div>
      </div>

      <!-- Quick Failure Injections Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <!-- Fault 1: Furnace 02 Failure -->
        <div class="p-4 bg-[#191d1e] border border-[#252A2C] rounded-xl space-y-3">
          <div class="flex items-start justify-between">
            <span class="text-xs font-bold text-[#ECEBE5]">Furnace 02 Downtime</span>
            <span class="text-[10px] font-mono px-1.5 py-0.5 rounded font-bold" [class]="isFaulted('FURN-02') ? 'bg-[#A44038]/30 text-[#A44038]' : 'bg-[#252A2C] text-[#687174]'">
              {{ isFaulted('FURN-02') ? 'FAULTED' : 'NORMAL' }}
            </span>
          </div>
          <p class="text-[11px] text-[#A7ADAA]">
            Heating element coil failure. Temperature drops from 880°C to ambient.
          </p>
          <button
            type="button"
            (click)="toggleFault('FURN-02')"
            class="w-full py-1.5 rounded text-xs font-mono font-semibold transition-colors cursor-pointer"
            [class]="isFaulted('FURN-02') ? 'bg-[#48654F] text-white' : 'bg-[#A44038] text-white'"
          >
            {{ isFaulted('FURN-02') ? 'Recover Machine' : 'Inject Failure' }}
          </button>
        </div>

        <!-- Fault 2: Robot 01 Joint Stall -->
        <div class="p-4 bg-[#191d1e] border border-[#252A2C] rounded-xl space-y-3">
          <div class="flex items-start justify-between">
            <span class="text-xs font-bold text-[#ECEBE5]">Robot 01 Servo Stall</span>
            <span class="text-[10px] font-mono px-1.5 py-0.5 rounded font-bold" [class]="isFaulted('ROB-01') ? 'bg-[#A44038]/30 text-[#A44038]' : 'bg-[#252A2C] text-[#687174]'">
              {{ isFaulted('ROB-01') ? 'FAULTED' : 'NORMAL' }}
            </span>
          </div>
          <p class="text-[11px] text-[#A7ADAA]">
            Joint 2 shoulder pitch overload. Halts CNC chuck loading cell.
          </p>
          <button
            type="button"
            (click)="toggleFault('ROB-01')"
            class="w-full py-1.5 rounded text-xs font-mono font-semibold transition-colors cursor-pointer"
            [class]="isFaulted('ROB-01') ? 'bg-[#48654F] text-white' : 'bg-[#A44038] text-white'"
          >
            {{ isFaulted('ROB-01') ? 'Recover Machine' : 'Inject Failure' }}
          </button>
        </div>

        <!-- Fault 3: CNC 04 Spindle Vibration -->
        <div class="p-4 bg-[#191d1e] border border-[#252A2C] rounded-xl space-y-3">
          <div class="flex items-start justify-between">
            <span class="text-xs font-bold text-[#ECEBE5]">CNC-04 Bearing Fault</span>
            <span class="text-[10px] font-mono px-1.5 py-0.5 rounded font-bold" [class]="isFaulted('CNC-04') ? 'bg-[#A44038]/30 text-[#A44038]' : 'bg-[#252A2C] text-[#687174]'">
              {{ isFaulted('CNC-04') ? 'FAULTED' : 'NORMAL' }}
            </span>
          </div>
          <p class="text-[11px] text-[#A7ADAA]">
            High vibration sensor trip on 12,000 RPM spindle. Halts spline milling.
          </p>
          <button
            type="button"
            (click)="toggleFault('CNC-04')"
            class="w-full py-1.5 rounded text-xs font-mono font-semibold transition-colors cursor-pointer"
            [class]="isFaulted('CNC-04') ? 'bg-[#48654F] text-white' : 'bg-[#A44038] text-white'"
          >
            {{ isFaulted('CNC-04') ? 'Recover Machine' : 'Inject Failure' }}
          </button>
        </div>

        <!-- Fault 4: AGV Fleet Depletion -->
        <div class="p-4 bg-[#191d1e] border border-[#252A2C] rounded-xl space-y-3">
          <div class="flex items-start justify-between">
            <span class="text-xs font-bold text-[#ECEBE5]">AGV-01 Battery Drop</span>
            <span class="text-[10px] font-mono px-1.5 py-0.5 rounded font-bold" [class]="isFaulted('AGV-01') ? 'bg-[#A44038]/30 text-[#A44038]' : 'bg-[#252A2C] text-[#687174]'">
              {{ isFaulted('AGV-01') ? 'FAULTED' : 'NORMAL' }}
            </span>
          </div>
          <p class="text-[11px] text-[#A7ADAA]">
            State of Charge drops below 10%. AGV stalls on main transfer aisle.
          </p>
          <button
            type="button"
            (click)="toggleFault('AGV-01')"
            class="w-full py-1.5 rounded text-xs font-mono font-semibold transition-colors cursor-pointer"
            [class]="isFaulted('AGV-01') ? 'bg-[#48654F] text-white' : 'bg-[#A44038] text-white'"
          >
            {{ isFaulted('AGV-01') ? 'Recover Machine' : 'Inject Failure' }}
          </button>
        </div>
      </div>

      <!-- Failure Propagation Analysis & Cascading Impact -->
      <div class="bg-[#191d1e] border border-[#252A2C] rounded-xl p-6 space-y-4">
        <div class="flex items-center justify-between border-b border-[#252A2C] pb-3">
          <h3 class="text-sm font-bold uppercase tracking-wider font-mono text-[#ECEBE5]">Cascading Impact Analysis</h3>
          <span class="text-xs font-mono text-[#C18A35]">Live Factory Response</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
          <div class="p-4 bg-[#111415] rounded-lg border border-[#252A2C] space-y-1">
            <span class="text-[10px] text-[#687174] block uppercase">Throughput Impact</span>
            <span class="text-xl font-bold text-[#A44038]">
              {{ isAnyFault() ? '-32.4% (868 parts/h)' : '0.0% Nominal (1,284/h)' }}
            </span>
            <span class="text-[10px] text-[#A7ADAA]">Downstream station starvation</span>
          </div>

          <div class="p-4 bg-[#111415] rounded-lg border border-[#252A2C] space-y-1">
            <span class="text-[10px] text-[#687174] block uppercase">Buffer Accumulation</span>
            <span class="text-xl font-bold text-[#C18A35]">
              {{ isAnyFault() ? '+4.2 parts/min' : 'Balanced (0.0)' }}
            </span>
            <span class="text-[10px] text-[#A7ADAA]">WIP Queue filling upstream</span>
          </div>

          <div class="p-4 bg-[#111415] rounded-lg border border-[#252A2C] space-y-1">
            <span class="text-[10px] text-[#687174] block uppercase">Estimated Recovery MTTR</span>
            <span class="text-xl font-bold text-[#ECEBE5]">2.5 hours</span>
            <span class="text-[10px] text-[#48654F]">Sheffield spare parts stock verified</span>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class FailureLab {
  readonly state = inject(FactoryStateService);

  isFaulted(id: string): boolean {
    const eq = this.state.equipmentList().find((e) => e.id === id);
    return eq?.state === 'FAULT';
  }

  isAnyFault(): boolean {
    return this.state.equipmentList().some((e) => e.state === 'FAULT');
  }

  toggleFault(id: string): void {
    this.state.toggleEquipmentFault(id);
    this.state.addAuditLog('Failure Lab', `Toggled fault injection state for ${id}`);
  }

  resetAllFaults(): void {
    this.state.equipmentList.update((list) =>
      list.map((eq) => (eq.state === 'FAULT' ? { ...eq, state: 'PROCESSING', healthIndex: 95 } : eq))
    );
    this.state.addAuditLog('Failure Lab', 'Cleared all factory equipment faults');
  }
}
