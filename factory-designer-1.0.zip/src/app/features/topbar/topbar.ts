import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { FactoryMode } from '../../core/models/factory.types';
import { FactoryStateService } from '../../core/services/factory-state.service';
import { SimulationService } from '../../core/services/simulation.service';

@Component({
  selector: 'app-topbar',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [],
  template: `
    <header class="h-14 bg-[#111415] border-b border-[#252A2C] px-5 flex items-center justify-between z-30 select-none">
      <!-- Zone 1: Single text element wordmark -->
      <div class="flex items-center gap-4">
        <a href="/" class="text-base font-bold tracking-tight text-[#ECEBE5] flex items-center gap-2">
          <span class="w-3 h-3 bg-[#304F60] border border-[#426A7A] inline-block"></span>
          <span>FACTORY DESIGNER 1.0</span>
        </a>
        <div class="hidden lg:flex items-center gap-2 text-xs font-mono text-[#687174] pl-2 border-l border-[#252A2C]">
          <span>{{ state.projectName() }}</span>
          <span>·</span>
          <span>{{ state.activeVersion() }}</span>
        </div>
      </div>

      <!-- Zone 2: Primary Mode Navigation Links -->
      <nav class="hidden md:flex items-center gap-1 bg-[#191d1e] p-1 rounded-lg border border-[#252A2C]">
        <button
          type="button"
          (click)="setMode('DESIGN')"
          [class]="state.currentMode() === 'DESIGN' ? 'bg-[#304F60] text-white' : 'text-[#A7ADAA] hover:text-[#ECEBE5]'"
          class="px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap"
        >
          Design
        </button>
        <button
          type="button"
          (click)="setMode('SIMULATE')"
          [class]="state.currentMode() === 'SIMULATE' ? 'bg-[#304F60] text-white' : 'text-[#A7ADAA] hover:text-[#ECEBE5]'"
          class="px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap"
        >
          Simulate
        </button>
        <button
          type="button"
          (click)="setMode('ROBOT_STUDIO')"
          [class]="state.currentMode() === 'ROBOT_STUDIO' ? 'bg-[#304F60] text-white' : 'text-[#A7ADAA] hover:text-[#ECEBE5]'"
          class="px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap"
        >
          Robot Studio
        </button>
        <button
          type="button"
          (click)="setMode('GRAPH')"
          [class]="state.currentMode() === 'GRAPH' ? 'bg-[#304F60] text-white' : 'text-[#A7ADAA] hover:text-[#ECEBE5]'"
          class="px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap"
        >
          Process Graph
        </button>
        <button
          type="button"
          (click)="setMode('OPTIMISE')"
          [class]="state.currentMode() === 'OPTIMISE' ? 'bg-[#304F60] text-white' : 'text-[#A7ADAA] hover:text-[#ECEBE5]'"
          class="px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap"
        >
          Optimise
        </button>
        <button
          type="button"
          (click)="setMode('COMMISSION')"
          [class]="state.currentMode() === 'COMMISSION' ? 'bg-[#304F60] text-white' : 'text-[#A7ADAA] hover:text-[#ECEBE5]'"
          class="px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap"
        >
          Commissioning
        </button>
        <button
          type="button"
          (click)="setMode('FAILURE_LAB')"
          [class]="state.currentMode() === 'FAILURE_LAB' ? 'bg-[#A44038] text-white' : 'text-[#A7ADAA] hover:text-[#ECEBE5]'"
          class="px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap"
        >
          Failure Lab
        </button>
        <button
          type="button"
          (click)="setMode('DRAWING')"
          [class]="state.currentMode() === 'DRAWING' ? 'bg-[#304F60] text-white' : 'text-[#A7ADAA] hover:text-[#ECEBE5]'"
          class="px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap"
        >
          2D Drawings
        </button>
        <button
          type="button"
          (click)="setMode('REPORT')"
          [class]="state.currentMode() === 'REPORT' ? 'bg-[#304F60] text-white' : 'text-[#A7ADAA] hover:text-[#ECEBE5]'"
          class="px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap"
        >
          BOM / Report
        </button>
      </nav>

      <!-- Zone 3: Primary Actions & Signature Demos Dropdown -->
      <div class="flex items-center gap-2">
        <div class="relative">
          <button
            type="button"
            (click)="toggleDemoDropdown()"
            class="px-3 py-1.5 text-xs font-medium text-[#ECEBE5] bg-[#252A2C] hover:bg-[#32383a] border border-[#32383a] rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <span class="w-2 h-2 rounded-full bg-[#C18A35]"></span>
            <span>Signature Demos</span>
            <span class="text-[10px] text-[#A7ADAA]">▼</span>
          </button>

          @if (showDemoMenu()) {
            <div class="absolute right-0 mt-2 w-72 bg-[#191d1e] border border-[#32383a] rounded-lg shadow-2xl p-2 z-50 text-xs font-sans">
              <div class="text-[11px] font-mono text-[#687174] px-2 py-1 uppercase tracking-wider">Industrial Test Environments</div>
              <button
                type="button"
                (click)="loadDemo(1)"
                class="w-full text-left px-3 py-2 rounded hover:bg-[#252A2C] transition-colors flex flex-col gap-0.5"
              >
                <span class="font-semibold text-[#ECEBE5]">1. Sheffield Precision Works</span>
                <span class="text-[#687174] text-[11px]">24 CNCs, 8 Robots, 4 Furnaces, 12 Conveyors</span>
              </button>
              <button
                type="button"
                (click)="loadDemo(2)"
                class="w-full text-left px-3 py-2 rounded hover:bg-[#252A2C] transition-colors flex flex-col gap-0.5"
              >
                <span class="font-semibold text-[#ECEBE5]">2. Design the Robot Cell</span>
                <span class="text-[#687174] text-[11px]">Kinematic reach envelope & grip force solver</span>
              </button>
              <button
                type="button"
                (click)="loadDemo(3)"
                class="w-full text-left px-3 py-2 rounded hover:bg-[#252A2C] transition-colors flex flex-col gap-0.5"
              >
                <span class="font-semibold text-[#A44038]">3. Break the Factory</span>
                <span class="text-[#687174] text-[11px]">Furnace 02 critical failure & dynamic queue rerun</span>
              </button>
              <button
                type="button"
                (click)="loadDemo(4)"
                class="w-full text-left px-3 py-2 rounded hover:bg-[#252A2C] transition-colors flex flex-col gap-0.5"
              >
                <span class="font-semibold text-[#ECEBE5]">4. Follow Part-004182</span>
                <span class="text-[#687174] text-[11px]">End-to-end digital twin part journey tracking</span>
              </button>
              <button
                type="button"
                (click)="loadDemo(5)"
                class="w-full text-left px-3 py-2 rounded hover:bg-[#252A2C] transition-colors flex flex-col gap-0.5"
              >
                <span class="font-semibold text-[#ECEBE5]">5. Brownfield Modernisation</span>
                <span class="text-[#687174] text-[11px]">Before vs After retrofit color-coded comparison</span>
              </button>
            </div>
          }
        </div>

        <button
          type="button"
          (click)="exportData()"
          class="px-3.5 py-1.5 text-xs font-semibold text-white bg-[#304F60] hover:bg-[#426A7A] rounded-lg transition-colors whitespace-nowrap cursor-pointer"
        >
          Export CSV / JSON
        </button>
      </div>
    </header>
  `,
})
export class Topbar {
  readonly state = inject(FactoryStateService);
  private readonly simulationService = inject(SimulationService);

  readonly showDemoMenu = signal<boolean>(false);

  setMode(mode: FactoryMode): void {
    this.state.setMode(mode);
  }

  toggleDemoDropdown(): void {
    this.showDemoMenu.update((v) => !v);
  }

  loadDemo(demoId: 1 | 2 | 3 | 4 | 5): void {
    this.state.loadSignatureDemo(demoId);
    this.showDemoMenu.set(false);
  }

  exportData(): void {
    const data = this.simulationService.exportSimulationData('CSV');
    const blob = new Blob([data], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `factory_simulation_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}
