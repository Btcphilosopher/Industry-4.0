import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { FactoryStateService } from '../../core/services/factory-state.service';
import { KinematicsService } from '../../core/services/kinematics.service';

@Component({
  selector: 'app-inspector',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [],
  template: `
    <aside class="w-88 h-full bg-[#191d1e] border-l border-[#252A2C] flex flex-col z-20 select-none">
      <!-- Inspector Header -->
      <div class="p-3 border-b border-[#252A2C] flex items-center justify-between">
        <div class="flex items-center gap-2">
          <span class="w-2 h-2 rounded-full" [class]="eq() ? 'bg-[#48654F]' : 'bg-[#304F60]'"></span>
          <span class="text-xs font-semibold text-[#ECEBE5] uppercase tracking-wider font-mono">
            {{ eq() ? 'Digital Twin Inspector' : 'Parametric Hall Spec' }}
          </span>
        </div>
        @if (eq()) {
          <span class="text-[11px] font-mono text-[#C18A35] font-semibold">{{ eq()?.code }}</span>
        }
      </div>

      <!-- Inspector Body Scrollable -->
      <div class="flex-1 overflow-y-auto p-4 space-y-4 text-xs font-sans">
        @if (eq(); as item) {
          <!-- Machine Identity & State Card -->
          <div class="p-3 bg-[#111415] border border-[#252A2C] rounded-lg">
            <div class="flex items-start justify-between">
              <div>
                <h3 class="font-semibold text-sm text-[#ECEBE5]">{{ item.name }}</h3>
                <p class="text-[11px] font-mono text-[#687174]">{{ item.manufacturer }} · {{ item.model }}</p>
              </div>
              <span
                class="px-2 py-0.5 rounded text-[10px] font-mono font-semibold uppercase"
                [class]="getStateBadgeClass(item.state)"
              >
                {{ item.state }}
              </span>
            </div>

            <!-- Health & Reliability Bar -->
            <div class="mt-3 pt-2 border-t border-[#252A2C]">
              <div class="flex justify-between text-[11px] font-mono text-[#A7ADAA] mb-1">
                <span>Health Index: {{ item.healthIndex }}%</span>
                <span>MTBF: {{ item.mtbfHours }}h</span>
              </div>
              <div class="w-full bg-[#252A2C] h-1.5 rounded-full overflow-hidden">
                <div
                  class="h-full rounded-full transition-all"
                  [style.width.%]="item.healthIndex"
                  [class]="item.healthIndex > 80 ? 'bg-[#48654F]' : 'bg-[#A44038]'"
                ></div>
              </div>
            </div>
          </div>

          <!-- Millimeter Coordinates & Spatial Transforms -->
          <div class="p-3 bg-[#111415] border border-[#252A2C] rounded-lg space-y-2">
            <span class="text-[11px] font-mono text-[#687174] uppercase tracking-wider block">Spatial Coordinates (mm)</span>
            <div class="grid grid-cols-3 gap-2">
              <div>
                <span class="text-[10px] font-mono text-[#A7ADAA] block">X (mm)</span>
                <input
                  type="number"
                  [value]="item.position.x"
                  (change)="updatePos('x', $event)"
                  class="w-full bg-[#252A2C] border border-[#32383a] rounded px-2 py-1 text-xs font-mono text-[#ECEBE5] focus:border-[#426A7A] outline-none"
                />
              </div>
              <div>
                <span class="text-[10px] font-mono text-[#A7ADAA] block">Y (mm)</span>
                <input
                  type="number"
                  [value]="item.position.y"
                  (change)="updatePos('y', $event)"
                  class="w-full bg-[#252A2C] border border-[#32383a] rounded px-2 py-1 text-xs font-mono text-[#ECEBE5] focus:border-[#426A7A] outline-none"
                />
              </div>
              <div>
                <span class="text-[10px] font-mono text-[#A7ADAA] block">Z (mm)</span>
                <input
                  type="number"
                  [value]="item.position.z"
                  (change)="updatePos('z', $event)"
                  class="w-full bg-[#252A2C] border border-[#32383a] rounded px-2 py-1 text-xs font-mono text-[#ECEBE5] focus:border-[#426A7A] outline-none"
                />
              </div>
            </div>

            <div class="grid grid-cols-2 gap-2 pt-1">
              <div>
                <span class="text-[10px] font-mono text-[#A7ADAA] block">Rotation Z (°)</span>
                <input
                  type="number"
                  [value]="item.rotation.z"
                  (change)="updateRotZ($event)"
                  class="w-full bg-[#252A2C] border border-[#32383a] rounded px-2 py-1 text-xs font-mono text-[#ECEBE5] focus:border-[#426A7A] outline-none"
                />
              </div>
              <div>
                <span class="text-[10px] font-mono text-[#A7ADAA] block">Safety Envelope (mm)</span>
                <input
                  type="number"
                  [value]="item.safetyRadius"
                  (change)="updateSafetyRadius($event)"
                  class="w-full bg-[#252A2C] border border-[#32383a] rounded px-2 py-1 text-xs font-mono text-[#ECEBE5] focus:border-[#426A7A] outline-none"
                />
              </div>
            </div>
          </div>

          <!-- Process Timing & Cycle Engine -->
          <div class="p-3 bg-[#111415] border border-[#252A2C] rounded-lg space-y-2">
            <span class="text-[11px] font-mono text-[#687174] uppercase tracking-wider block">Cycle Timing & Performance</span>
            <div class="grid grid-cols-2 gap-2 text-xs font-mono">
              <div class="bg-[#191d1e] p-2 rounded border border-[#252A2C]">
                <span class="text-[#687174] text-[10px] block">TOTAL CYCLE</span>
                <span class="text-sm font-bold text-[#ECEBE5]">{{ item.cycleTime }}s</span>
              </div>
              <div class="bg-[#191d1e] p-2 rounded border border-[#252A2C]">
                <span class="text-[#687174] text-[10px] block">PROCESS POWER</span>
                <span class="text-sm font-bold text-[#C18A35]">{{ item.processPowerKw }} kW</span>
              </div>
              <div class="bg-[#191d1e] p-2 rounded border border-[#252A2C]">
                <span class="text-[#687174] text-[10px] block">AVAILABILITY</span>
                <span class="text-sm font-bold text-[#48654F]">{{ (item.availability * 100).toFixed(1) }}%</span>
              </div>
              <div class="bg-[#191d1e] p-2 rounded border border-[#252A2C]">
                <span class="text-[#687174] text-[10px] block">UNIT CAPEX</span>
                <span class="text-sm font-bold text-[#ECEBE5]">£{{ (item.capexCost / 1000).toFixed(0) }}k</span>
              </div>
            </div>
          </div>

          <!-- Robot Kinematics Quick Slider (If Robot) -->
          @if (item.category === 'ROBOTICS' && item.robotJoints) {
            <div class="p-3 bg-[#111415] border border-[#252A2C] rounded-lg space-y-2.5">
              <div class="flex justify-between items-center">
                <span class="text-[11px] font-mono text-[#687174] uppercase tracking-wider">6-Axis Joint Positioner</span>
                <span class="text-[10px] font-mono text-[#A7ADAA]">Reach: {{ ((item.reachRadius ?? 2400) / 1000).toFixed(1) }}m</span>
              </div>
              @for (joint of item.robotJoints; track joint.id) {
                <div class="space-y-1">
                  <div class="flex justify-between text-[10px] font-mono">
                    <span class="text-[#A7ADAA]">J{{ joint.id }} · {{ joint.name }}</span>
                    <span class="text-[#ECEBE5]">{{ joint.currentAngle }}°</span>
                  </div>
                  <input
                    type="range"
                    [min]="joint.minAngle"
                    [max]="joint.maxAngle"
                    [value]="joint.currentAngle"
                    (input)="onJointSlider(item.id, joint.id, $event)"
                    class="w-full accent-[#304F60] bg-[#252A2C] h-1.5 rounded cursor-pointer"
                  />
                </div>
              }
            </div>
          }

          <!-- Actions & Fault Injection Buttons -->
          <div class="pt-2 flex items-center gap-2">
            <button
              type="button"
              (click)="state.toggleEquipmentFault(item.id)"
              [class]="item.state === 'FAULT' ? 'bg-[#48654F]' : 'bg-[#A44038]'"
              class="flex-1 py-1.5 rounded text-xs font-mono font-semibold text-white transition-colors cursor-pointer"
            >
              {{ item.state === 'FAULT' ? '✓ Clear Fault' : '⚠ Inject Fault' }}
            </button>
            <button
              type="button"
              (click)="state.removeEquipment(item.id)"
              class="px-3 py-1.5 rounded text-xs font-mono text-[#A7ADAA] hover:text-[#A44038] bg-[#252A2C] hover:bg-[#32383a] transition-colors cursor-pointer"
              title="Decommission Equipment"
            >
              Delete
            </button>
          </div>
        } @else {
          <!-- Parametric Hall Settings (Default when no equipment selected) -->
          <div class="space-y-4">
            <div class="p-3 bg-[#111415] border border-[#252A2C] rounded-lg">
              <h3 class="font-semibold text-sm text-[#ECEBE5]">{{ state.building().hallName }}</h3>
              <p class="text-[11px] font-mono text-[#687174]">{{ state.projectName() }} · {{ state.projectCode() }}</p>
            </div>

            <div class="p-3 bg-[#111415] border border-[#252A2C] rounded-lg space-y-3">
              <span class="text-[11px] font-mono text-[#687174] uppercase tracking-wider block">Building Parameters</span>
              
              <div class="grid grid-cols-3 gap-2 font-mono text-xs">
                <div>
                  <span class="text-[10px] text-[#A7ADAA] block">Length (m)</span>
                  <input
                    type="number"
                    [value]="state.building().length"
                    (change)="updateBuildingProp('length', $event)"
                    class="w-full bg-[#252A2C] border border-[#32383a] rounded px-2 py-1 text-[#ECEBE5] outline-none"
                  />
                </div>
                <div>
                  <span class="text-[10px] text-[#A7ADAA] block">Width (m)</span>
                  <input
                    type="number"
                    [value]="state.building().width"
                    (change)="updateBuildingProp('width', $event)"
                    class="w-full bg-[#252A2C] border border-[#32383a] rounded px-2 py-1 text-[#ECEBE5] outline-none"
                  />
                </div>
                <div>
                  <span class="text-[10px] text-[#A7ADAA] block">Height (m)</span>
                  <input
                    type="number"
                    [value]="state.building().height"
                    (change)="updateBuildingProp('height', $event)"
                    class="w-full bg-[#252A2C] border border-[#32383a] rounded px-2 py-1 text-[#ECEBE5] outline-none"
                  />
                </div>
              </div>

              <div class="grid grid-cols-2 gap-2 font-mono text-xs pt-1">
                <div>
                  <span class="text-[10px] text-[#A7ADAA] block">Column Grid X (m)</span>
                  <input
                    type="number"
                    [value]="state.building().columnGridX"
                    (change)="updateBuildingProp('columnGridX', $event)"
                    class="w-full bg-[#252A2C] border border-[#32383a] rounded px-2 py-1 text-[#ECEBE5] outline-none"
                  />
                </div>
                <div>
                  <span class="text-[10px] text-[#A7ADAA] block">Column Grid Y (m)</span>
                  <input
                    type="number"
                    [value]="state.building().columnGridY"
                    (change)="updateBuildingProp('columnGridY', $event)"
                    class="w-full bg-[#252A2C] border border-[#32383a] rounded px-2 py-1 text-[#ECEBE5] outline-none"
                  />
                </div>
              </div>
            </div>

            <!-- Heatmap Visualization Switcher -->
            <div class="p-3 bg-[#111415] border border-[#252A2C] rounded-lg space-y-2">
              <span class="text-[11px] font-mono text-[#687174] uppercase tracking-wider block">Factory Heatmap Overlays</span>
              <div class="grid grid-cols-2 gap-1.5 text-xs font-mono">
                <button
                  type="button"
                  (click)="state.setHeatmap('NONE')"
                  [class]="state.currentHeatmap() === 'NONE' ? 'bg-[#304F60] text-white' : 'bg-[#252A2C] text-[#A7ADAA] hover:text-white'"
                  class="py-1.5 px-2 rounded text-left transition-colors"
                >
                  Standard 3D
                </button>
                <button
                  type="button"
                  (click)="state.setHeatmap('ENERGY')"
                  [class]="state.currentHeatmap() === 'ENERGY' ? 'bg-[#304F60] text-white' : 'bg-[#252A2C] text-[#A7ADAA] hover:text-white'"
                  class="py-1.5 px-2 rounded text-left transition-colors"
                >
                  Energy Density
                </button>
                <button
                  type="button"
                  (click)="state.setHeatmap('ROBOT_UTIL')"
                  [class]="state.currentHeatmap() === 'ROBOT_UTIL' ? 'bg-[#304F60] text-white' : 'bg-[#252A2C] text-[#A7ADAA] hover:text-white'"
                  class="py-1.5 px-2 rounded text-left transition-colors"
                >
                  Robot Utilisation
                </button>
                <button
                  type="button"
                  (click)="state.setHeatmap('MAINTENANCE')"
                  [class]="state.currentHeatmap() === 'MAINTENANCE' ? 'bg-[#304F60] text-white' : 'bg-[#252A2C] text-[#A7ADAA] hover:text-white'"
                  class="py-1.5 px-2 rounded text-left transition-colors"
                >
                  Health / MTBF
                </button>
              </div>
            </div>
          </div>
        }
      </div>
    </aside>
  `,
})
export class Inspector {
  readonly state = inject(FactoryStateService);
  private readonly kinematicsService = inject(KinematicsService);

  readonly eq = this.state.selectedEquipment;

  getStateBadgeClass(state: string): string {
    switch (state) {
      case 'RUNNING':
      case 'PROCESSING':
        return 'bg-[#48654F]/30 text-[#48654F] border border-[#48654F]/40';
      case 'HEATING':
        return 'bg-[#C18A35]/30 text-[#C18A35] border border-[#C18A35]/40';
      case 'FAULT':
        return 'bg-[#A44038]/30 text-[#A44038] border border-[#A44038]/40';
      case 'PICKING':
      case 'PLACING':
        return 'bg-[#304F60]/30 text-[#88ccff] border border-[#304F60]/40';
      default:
        return 'bg-[#252A2C] text-[#A7ADAA]';
    }
  }

  updatePos(axis: 'x' | 'y' | 'z', event: Event): void {
    const input = event.target as HTMLInputElement;
    const val = parseFloat(input.value) || 0;
    const item = this.eq();
    if (item) {
      this.state.updateEquipmentPosition(item.id, { [axis]: val });
    }
  }

  updateRotZ(event: Event): void {
    const input = event.target as HTMLInputElement;
    const val = parseFloat(input.value) || 0;
    const item = this.eq();
    if (item) {
      this.state.updateEquipmentProperty(item.id, {
        rotation: { ...item.rotation, z: val },
      });
    }
  }

  updateSafetyRadius(event: Event): void {
    const input = event.target as HTMLInputElement;
    const val = parseFloat(input.value) || 2000;
    const item = this.eq();
    if (item) {
      this.state.updateEquipmentProperty(item.id, { safetyRadius: val });
    }
  }

  onJointSlider(equipmentId: string, jointId: number, event: Event): void {
    const input = event.target as HTMLInputElement;
    const angle = parseFloat(input.value);
    this.state.updateRobotJoint(equipmentId, jointId, angle);
  }

  updateBuildingProp(prop: string, event: Event): void {
    const input = event.target as HTMLInputElement;
    const val = parseFloat(input.value) || 10;
    this.state.building.update((b) => ({ ...b, [prop]: val }));
  }
}
