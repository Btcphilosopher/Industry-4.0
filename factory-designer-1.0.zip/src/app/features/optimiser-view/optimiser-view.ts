import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { OptimisationScenario } from '../../core/models/factory.types';
import { FactoryStateService } from '../../core/services/factory-state.service';

@Component({
  selector: 'app-optimiser-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [],
  template: `
    <div class="w-full h-full bg-[#111415] text-[#ECEBE5] p-6 overflow-y-auto font-sans select-none">
      <!-- Optimiser Header -->
      <div class="flex items-center justify-between pb-4 border-b border-[#252A2C] mb-6">
        <div>
          <h2 class="text-lg font-bold tracking-tight text-[#ECEBE5]">Multi-Objective Factory Optimiser & Design Space</h2>
          <p class="text-xs font-mono text-[#687174]">Throughput · CAPEX · Footprint · Energy Demand · Bottleneck Elimination</p>
        </div>
        <div class="flex items-center gap-2">
          <button
            type="button"
            (click)="runMonteCarlo()"
            class="px-3 py-1.5 bg-[#252A2C] hover:bg-[#32383a] border border-[#32383a] rounded-lg text-xs font-mono text-[#ECEBE5] transition-colors cursor-pointer"
          >
            {{ isRunningExploration() ? 'Evaluating 1,000 Candidates...' : '⚡ Explore 1,000 Scenarios' }}
          </button>
          <button
            type="button"
            (click)="state.setMode('DESIGN')"
            class="px-3 py-1.5 bg-[#304F60] hover:bg-[#426A7A] rounded-lg text-xs font-semibold text-white transition-colors cursor-pointer"
          >
            Back to 3D Canvas
          </button>
        </div>
      </div>

      <!-- Scenarios Comparison Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mb-8">
        @for (scen of state.scenarios(); track scen.id) {
          <div
            class="p-5 rounded-xl border transition-all flex flex-col justify-between"
            [class]="state.selectedScenarioId() === scen.id ? 'bg-[#191d1e] border-[#304F60] ring-1 ring-[#426A7A]' : 'bg-[#191d1e] border-[#252A2C] hover:border-[#32383a]'"
          >
            <div>
              <div class="flex items-start justify-between">
                <div>
                  <h3 class="font-bold text-sm text-[#ECEBE5]">{{ scen.name }}</h3>
                  <p class="text-[11px] font-mono text-[#687174] mt-0.5">{{ scen.code }}</p>
                </div>
                <span class="text-xs font-mono font-bold text-[#C18A35]">{{ scen.throughputPerHour }} /h</span>
              </div>

              <p class="text-xs text-[#A7ADAA] mt-3 leading-relaxed">
                {{ scen.description }}
              </p>

              <!-- Metric Table -->
              <div class="mt-4 pt-3 border-t border-[#252A2C] grid grid-cols-2 gap-2 text-xs font-mono">
                <div class="bg-[#111415] p-2 rounded">
                  <span class="text-[10px] text-[#687174] block">CAPEX</span>
                  <span class="font-bold text-[#ECEBE5]">£{{ scen.capexMillionGbp }}m</span>
                </div>
                <div class="bg-[#111415] p-2 rounded">
                  <span class="text-[10px] text-[#687174] block">POWER</span>
                  <span class="font-bold text-[#C18A35]">{{ scen.energyDemandMw }} MW</span>
                </div>
                <div class="bg-[#111415] p-2 rounded">
                  <span class="text-[10px] text-[#687174] block">FLOOR SPACE</span>
                  <span class="font-bold text-[#ECEBE5]">{{ scen.floorSpaceM2 }} m²</span>
                </div>
                <div class="bg-[#111415] p-2 rounded">
                  <span class="text-[10px] text-[#687174] block">TRAVEL DISTANCE</span>
                  <span class="font-bold text-[#48654F]">{{ scen.materialTravelKm }} km/h</span>
                </div>
              </div>

              <!-- Key Changes Bulleted -->
              <div class="mt-3 space-y-1 text-[11px] font-mono text-[#687174]">
                @for (change of scen.keyChanges; track change) {
                  <div class="flex items-start gap-1.5">
                    <span class="text-[#304F60]">•</span>
                    <span>{{ change }}</span>
                  </div>
                }
              </div>
            </div>

            <button
              type="button"
              (click)="applyScenario(scen)"
              class="mt-4 w-full py-2 bg-[#252A2C] hover:bg-[#304F60] rounded-lg text-xs font-mono font-semibold text-[#ECEBE5] transition-colors cursor-pointer"
            >
              {{ state.selectedScenarioId() === scen.id ? '✓ Active Scenario' : 'Select Layout' }}
            </button>
          </div>
        }
      </div>

      <!-- Factory Scorecard & Bottleneck Identification -->
      <div class="bg-[#191d1e] border border-[#252A2C] rounded-xl p-6">
        <div class="flex items-center justify-between border-b border-[#252A2C] pb-4 mb-4">
          <h3 class="text-sm font-bold uppercase tracking-wider font-mono text-[#ECEBE5]">Factory Design Scorecard</h3>
          <span class="text-xs font-mono text-[#48654F]">Continuous Simulation Metrics</span>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-mono">
          <div class="p-3 bg-[#111415] rounded-lg border border-[#252A2C]">
            <span class="text-[10px] text-[#687174] block uppercase">Throughput Rate</span>
            <span class="text-xl font-bold text-[#ECEBE5] mt-1 block">1,284 parts/h</span>
            <span class="text-[10px] text-[#48654F]">+24.8% vs Base</span>
          </div>
          <div class="p-3 bg-[#111415] rounded-lg border border-[#252A2C]">
            <span class="text-[10px] text-[#687174] block uppercase">Material Travel</span>
            <span class="text-xl font-bold text-[#ECEBE5] mt-1 block">14.8 km/h</span>
            <span class="text-[10px] text-[#48654F]">-18.7% Congestion</span>
          </div>
          <div class="p-3 bg-[#111415] rounded-lg border border-[#252A2C]">
            <span class="text-[10px] text-[#687174] block uppercase">Robot Utilisation</span>
            <span class="text-xl font-bold text-[#48654F] mt-1 block">81.4%</span>
            <span class="text-[10px] text-[#687174]">Optimal Load Range</span>
          </div>
          <div class="p-3 bg-[#111415] rounded-lg border border-[#252A2C]">
            <span class="text-[10px] text-[#687174] block uppercase">Primary Bottleneck</span>
            <span class="text-xl font-bold text-[#A44038] mt-1 block">CNC-04</span>
            <span class="text-[10px] text-[#A44038]">Utilisation: 94.2% · Queue: 5</span>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class OptimiserView {
  readonly state = inject(FactoryStateService);

  readonly isRunningExploration = signal<boolean>(false);

  runMonteCarlo(): void {
    this.isRunningExploration.set(true);
    setTimeout(() => {
      this.isRunningExploration.set(false);
      this.state.addAuditLog('Monte Carlo Optimisation', 'Evaluated 1,000 candidate layouts. Scenario E remains Pareto optimal.');
    }, 1200);
  }

  applyScenario(scen: OptimisationScenario): void {
    this.state.selectScenario(scen.id);
    this.state.addAuditLog('Layout Applied', `Applied ${scen.name} (${scen.code})`);
  }
}
