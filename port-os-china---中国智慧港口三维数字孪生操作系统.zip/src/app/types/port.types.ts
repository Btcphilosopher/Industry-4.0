export type ObjectType = 
  | 'ship' 
  | 'berth' 
  | 'quay_crane' 
  | 'rtg_crane' 
  | 'agv' 
  | 'truck' 
  | 'container' 
  | 'yard_block' 
  | 'rail_train' 
  | 'rail_line' 
  | 'bulk_equipment' 
  | 'oil_tank' 
  | 'pipeline' 
  | 'gate' 
  | 'warehouse' 
  | 'substation' 
  | 'safety_zone' 
  | 'weather_station'
  | 'person';

export type EquipmentStatus = 'idle' | 'working' | 'traveling' | 'charging' | 'maintenance' | 'fault' | 'offline';
export type ShipStatus = 'approaching' | 'anchorage' | 'piloting' | 'berthing' | 'operating' | 'unberthing' | 'departed';
export type ContainerSize = '20GP' | '40GP' | '40HQ' | '45HQ' | 'REEFER_40' | 'HAZ_40' | 'BULK_TANK';

export interface Vector3D {
  x: number;
  y: number;
  z: number;
}

export interface GeoLocation {
  lng: number;
  lat: number;
  alt?: number;
}

export interface DigitalTwinBase {
  id: string;
  name: string;
  type: ObjectType;
  position: Vector3D;
  rotation?: Vector3D;
  geoPosition: GeoLocation;
  status: string;
  lastUpdated: string;
  responsibleDept: string;
  healthScore: number; // 0 - 100
  alerts: PortAlert[];
}

export interface ShipTwin extends DigitalTwinBase {
  type: 'ship';
  imo: string;
  callSign: string;
  flag: string;
  shipType: '集装箱船' | '散货船' | 'VLCC油轮' | 'LNG船' | '滚装汽车船' | '拖轮' | '引航艇';
  length: number; // meters
  beam: number; // meters
  draft: number; // current draft meters
  maxDraft: number;
  speedKnots: number;
  heading: number; // degrees
  destination: string;
  lastPort: string;
  nextPort: string;
  eta: string;
  etd: string;
  cargoTeuOrTons: number;
  capacityTeu: number;
  assignedBerthId?: string;
  berthProgress: number; // 0 - 100%
  aisStatus: string;
  shorePowerConnected: boolean;
  berthingStep?: 'ETA' | '引航' | '拖轮助泊' | '系缆靠泊' | '装卸作业' | '离泊解缆' | 'ETD';
}

export interface BerthTwin extends DigitalTwinBase {
  type: 'berth';
  berthNo: string;
  terminalType: '集装箱码头' | '散货码头' | '油气码头' | '滚装码头';
  length: number; // meters
  waterDepth: number; // meters
  maxVesselDwt: number;
  currentShipId?: string;
  currentShipName?: string;
  nextShipName?: string;
  plannedEta?: string;
  plannedEtd?: string;
  utilizationRate: number; // percentage
  assignedCranes: string[];
  shorePowerCapacityKw: number;
  bollardTensionKn: number;
}

export interface QuayCraneTwin extends DigitalTwinBase {
  type: 'quay_crane';
  craneNo: string;
  berthId: string;
  trolleyPosition: number; // -30 to 30 along boom
  hoistHeight: number; // 0 to 45m
  spreaderLocked: boolean;
  currentContainerId?: string;
  currentTask: string;
  movesPerHour: number;
  targetMovesPerHour: number;
  totalWorkingHours: number;
  vibrationRms: number; // mm/s
  motorTempC: number;
  powerKw: number;
  totalEnergyKWh: number;
  railTrackPos: number; // meters along quay
}

export interface RTGCraneTwin extends DigitalTwinBase {
  type: 'rtg_crane';
  rtgNo: string;
  assignedYardBlockId: string;
  gantryPosition: number; // along bay
  trolleyPosition: number; // along row
  hoistHeight: number; // tier height
  spreaderLocked: boolean;
  currentContainerId?: string;
  movesPerHour: number;
  batteryLevelPercent: number; // for E-RTG
  powerKw: number;
}

export interface AGVTwin extends DigitalTwinBase {
  type: 'agv';
  agvNo: string;
  state: 'idle' | 'to_pick' | 'loaded' | 'transporting' | 'waiting' | 'unloading' | 'charging' | 'fault';
  batteryLevel: number; // percentage 0-100
  speedKmh: number;
  currentPayloadContainerId?: string;
  targetDestination: string; // e.g., 'QC-03' or 'YARD-A04-B12'
  routeWaypoints: Vector3D[];
  mileageTodayKm: number;
  radarObstacleDistanceM: number;
}

export interface AutonomousTruckTwin extends DigitalTwinBase {
  type: 'truck';
  plateNo: string;
  vehicleType: '无人集卡 (A-Truck)' | '外集卡 (External)' | '危险品专用车' | '港区抢险车';
  speedKmh: number;
  driverType: 'L4_AUTONOMOUS' | 'HUMAN_DRIVER';
  cargoContainerId?: string;
  gateEntryTime: string;
  v2xLatencyMs: number;
}

export interface ContainerTwin {
  id: string; // e.g. MSCU7849201
  containerNo: string;
  size: ContainerSize;
  grossWeightTon: number;
  type: '普通干箱' | '冷藏箱 (Reefer)' | '危险品箱 (DG Class 3)' | '空箱 (Empty)';
  cargoOwner: string;
  carrier: string;
  shipName?: string;
  originPort: string;
  destinationPort: string;
  currentLocation: string; // e.g. 'YARD-A02-B08-R03-T02' | 'QC-02' | 'AGV-014' | 'VESSEL' | 'TRAIN'
  temperatureTargetC?: number;
  temperatureActualC?: number;
  reeferPowerPlugged?: boolean;
  hazardClass?: string;
  journeyLogs: ContainerJourneyStep[];
  position?: Vector3D;
}

export interface ContainerJourneyStep {
  step: string;
  facility: string;
  timestamp: string;
  deviceUsed: string;
  status: 'completed' | 'in_progress' | 'planned';
}

export interface YardBlockTwin extends DigitalTwinBase {
  type: 'yard_block';
  blockCode: string; // e.g. 'A01'
  blockCategory: '进口重箱' | '出口重箱' | '冷藏箱区' | '危险品箱区' | '海铁联运中转区' | '空箱堆区';
  baysCount: number;
  rowsCount: number;
  tiersMax: number;
  capacityTeu: number;
  currentTeu: number;
  occupancyPercent: number;
  assignedRTGs: string[];
}

export interface RailTrainTwin extends DigitalTwinBase {
  type: 'rail_train';
  trainNo: string; // e.g. 'X8011 (中欧海铁快线)'
  trainType: '集装箱班列' | '煤炭专列' | '铁矿石敞车专列';
  wagonsCount: number;
  currentWagonsLoaded: number;
  progressPercent: number;
  direction: 'ARRIVAL' | 'DEPARTURE' | 'MARSHALLING';
  trackNo: string;
  originStation: string;
  destStation: string;
  eta: string;
  etd: string;
}

export interface BulkTerminalTwin extends DigitalTwinBase {
  type: 'bulk_equipment';
  machineNo: string;
  bulkType: '斗轮堆取料机' | '装船机' | '桥式抓斗卸船机' | '带式输送机廊道' | '筒仓集群';
  material: '铁矿石' | '动力煤' | '散装粮食' | '木材' | '铝矾土';
  flowRateTonsPerHour: number;
  totalTonsProcessedToday: number;
  beltSpeedMs: number;
  dustConcentrationMgM3: number;
}

export interface OilGasTankTwin extends DigitalTwinBase {
  type: 'oil_tank';
  tankNo: string; // e.g. 'TK-101 (原油储罐 10万m³)'
  medium: '超重质原油' | '航空煤油' | 'LNG液化天然气' | 'LPG液化石油气' | '化工甲醇';
  capacityM3: number;
  currentVolumeM3: number;
  liquidLevelM: number;
  maxLevelM: number;
  liquidPercentage: number;
  pressureKPa: number;
  temperatureC: number;
  vocPpm: number;
  nitrogenBlanketStatus: 'NORMAL' | 'HIGH' | 'LOW';
  valveState: 'OPEN' | 'CLOSED' | 'THROTTLING';
}

export interface PipelineTwin extends DigitalTwinBase {
  type: 'pipeline';
  pipelineNo: string;
  medium: string;
  diameterMm: number;
  startPoint: string;
  endPoint: string;
  flowM3PerHour: number;
  pressureBar: number;
  temperatureC: number;
  valveOpenPercent: number;
  points3D: Vector3D[];
}

export interface GateLaneTwin {
  laneId: string;
  laneType: 'INSPECTION_IN' | 'OUTBOUND' | 'HAZMAT_IN';
  ocrStatus: 'PASS' | 'SCANNING' | 'ERROR';
  weighbridgeKg: number;
  currentTruckPlate?: string;
  avgPassSeconds: number;
  todayTrucksCount: number;
}

export interface PortAlert {
  id: string;
  time: string;
  sourceObjectId: string;
  sourceObjectName: string;
  level: 'info' | 'warning' | 'danger' | 'critical';
  category: 'EQUIPMENT_FAULT' | 'AGV_CONFLICT' | 'SAFETY_PERIMETER' | 'WEATHER_TYPHOON' | 'REEFER_TEMP' | 'BERTH_DELAY';
  message: string;
  handled: boolean;
  handler?: string;
  actionTaken?: string;
  location: Vector3D;
}

export interface PortEnergyMetrics {
  totalGridPowerKw: number;
  todayTotalKWh: number;
  peakLoadKw: number;
  solarPvGenerationKw: number;
  bessStorageStateOfCharge: number; // 0 - 100%
  shorePowerSupplyKw: number;
  agvChargingLoadKw: number;
  craneLoadKw: number;
  reeferPlugLoadKw: number;
  carbonEmissionTodayTons: number;
  carbonSavedShorePowerTons: number;
  carbonPerTeuKg: number;
}

export interface WeatherTwinData {
  time: string;
  windSpeedKnots: number;
  windDirectionDeg: number;
  windGustKnots: number;
  windBeaufortScale: number;
  tideLevelMeters: number;
  highTideTime: string;
  highTideMeters: number;
  lowTideTime: string;
  lowTideMeters: number;
  waveHeightM: number;
  visibilityKm: number;
  temperatureC: number;
  humidityPercent: number;
  precipitationMm: number;
  weatherCondition: '晴朗' | '多云' | '小雨' | '大雨/暴风' | '海雾' | '台风警戒';
  craneSafetyLock: boolean; // locked if wind > 20 m/s
}

export interface PortKPIs {
  todayTotalTeu: number;
  targetDailyTeu: number;
  bulkCargoTons: number;
  vesselsInPort: number;
  vesselsWaitingBerth: number;
  activeBerthsCount: number;
  totalBerthsCount: number;
  quayCranesOnline: number;
  quayCranesTotal: number;
  agvOnlineCount: number;
  agvTotalCount: number;
  yardUtilizationPercent: number;
  railTeuVolume: number;
  gateVehiclesToday: number;
  avgGatePassSeconds: number;
  equipmentOnlineRate: number; // %
  carbonFootprintTons: number;
  activeAlertsCount: number;
}

export interface PortLayerVisibility {
  ships: boolean;
  cranes: boolean;
  containers: boolean;
  agvs: boolean;
  trucks: boolean;
  yard: boolean;
  rail: boolean;
  bulk: boolean;
  oilGas: boolean;
  pipelines: boolean;
  energyGrid: boolean;
  safetyZones: boolean;
  weatherEffects: boolean;
  personnel: boolean;
  radarBuoys: boolean;
}

export interface TimeMachineState {
  currentSimulatedTime: Date;
  isPlaying: boolean;
  playbackSpeed: number; // 1x, 5x, 10x, 30x
  timelineRangeStart: Date;
  timelineRangeEnd: Date;
}
