import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PortDataService } from '../../services/port-data.service';
import { Port3DEngineService } from '../../services/port-3d-engine.service';
import { RailTrainTwin } from '../../types/port.types';

@Component({
  selector: 'app-rail-intermodal-panel',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule],
  template: `
    <div class="h-full w-full bg-slate-950/95 backdrop-blur-xl border-l border-white/10 flex flex-col text-slate-200 overflow-hidden font-sans">
      <!-- Header -->
      <div class="p-4 border-b border-white/10 flex items-center justify-between">
        <div class="flex items-center gap-2">
          <span class="text-xl">🚆</span>
          <div>
            <h2 class="text-sm font-bold text-white">海铁联运与铁路中心站数字孪生</h2>
            <p class="text-[11px] text-slate-400">中欧班列 · 沿海铁路线 · 车船直取 · 码头-铁路零换乘</p>
          </div>
        </div>
        <button
          (click)="close()"
          class="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/5"
        >
          ✕
        </button>
      </div>

      <div class="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
        <!-- 1. Intermodal Key Metrics -->
        <div class="grid grid-cols-2 gap-2 font-mono-num text-xs">
          <div class="bg-slate-900/80 p-3 rounded-xl border border-white/5">
            <div class="text-[10px] text-slate-400">今日海铁发运箱量</div>
            <div class="text-xl font-bold text-purple-400 mt-1">420 <span class="text-xs font-normal text-slate-400">TEU</span></div>
            <div class="text-[10px] text-emerald-400 mt-1">同比增长 +18.4%</div>
          </div>

          <div class="bg-slate-900/80 p-3 rounded-xl border border-white/5">
            <div class="text-[10px] text-slate-400">海铁集疏运占比</div>
            <div class="text-xl font-bold text-cyan-400 mt-1">11.6%</div>
            <div class="text-[10px] text-slate-400 mt-1">目标: 2026年底达到15%</div>
          </div>
        </div>

        <!-- 2. Active Freight Train Lineup -->
        <div>
          <div class="flex items-center justify-between mb-2">
            <h3 class="text-xs font-bold text-cyan-400 uppercase tracking-wider">今日班列编组发运计划</h3>
            <span class="text-[10px] text-slate-400">铁总调度协同网联</span>
          </div>

          <div class="space-y-2">
            @for (t of portData.trains(); track t.id) {
              <button
                type="button"
                (click)="focusTrain(t)"
                class="bg-slate-900/80 hover:bg-slate-800 border border-white/5 hover:border-purple-500/40 p-3 rounded-xl cursor-pointer transition-all text-left w-full"
              >
                <div class="flex items-start justify-between">
                  <div>
                    <div class="flex items-center gap-2">
                      <span class="text-xs font-bold text-white">{{ t.trainNo }}</span>
                      <span class="px-1.5 py-0.2 rounded text-[10px] bg-purple-950 text-purple-300 border border-purple-800 font-mono">
                        {{ t.destStation }}
                      </span>
                    </div>
                    <div class="text-[11px] text-slate-400 mt-1 font-mono-num">
                      股道: {{ t.trackNo }} · 节数: {{ t.wagonsCount }} 节 · 载重: {{ t.currentWagonsLoaded * 2 }} TEU
                    </div>
                  </div>
                  <span class="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-950 text-emerald-300 border border-emerald-800 font-mono">
                    装车作业中
                  </span>
                </div>

                <!-- Progress -->
                <div class="mt-3">
                  <div class="flex items-center justify-between text-[10px] text-slate-400 mb-1">
                    <span>自动化龙门吊配载进度</span>
                    <span class="text-white font-mono-num">{{ t.progressPercent }}% ({{ t.currentWagonsLoaded }}/{{ t.wagonsCount }}节)</span>
                  </div>
                  <div class="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden">
                    <div class="bg-purple-500 h-full rounded-full" [style.width.%]="t.progressPercent"></div>
                  </div>
                </div>

                <div class="mt-2 pt-2 border-t border-white/5 flex items-center justify-between text-[11px] text-slate-400 font-mono-num">
                  <div>发车时间 (ETD): <span class="text-white">{{ t.etd }}</span></div>
                  <div class="text-purple-400 hover:underline">三维定位 →</div>
                </div>
              </button>
            }
          </div>
        </div>

        <!-- 3. Direct Vessel-to-Rail Transfer Smart Strategy -->
        <div class="bg-slate-900/70 border border-white/5 rounded-xl p-3 text-xs leading-relaxed">
          <div class="flex items-center gap-1.5 text-cyan-300 font-bold mb-1">
            <span>⚡</span>
            <span>"车船直取" 无缝换装策略</span>
          </div>
          <p class="text-slate-300 text-[11px]">
            依托高精度数字孪生推演，卸船集装箱落地后由 AGV 直接转运至铁路 2 号股道，免除堆场中间落箱与二次翻箱，单箱物流周转时间压缩 <strong>65%</strong>，单箱集疏运成本降低 <strong>120 元</strong>。
          </p>
        </div>
      </div>
    </div>
  `
})
export class RailIntermodalPanel {
  readonly portData = inject(PortDataService);
  readonly engine = inject(Port3DEngineService);

  close() {
    this.portData.activeModule.set('control-tower');
  }

  focusTrain(train: RailTrainTwin) {
    this.portData.selectObject(train);
    this.engine.applyCameraPreset('RAIL_STATION');
  }
}
