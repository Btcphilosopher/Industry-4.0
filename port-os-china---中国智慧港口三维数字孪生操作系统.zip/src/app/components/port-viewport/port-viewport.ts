import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  ViewChild,
  inject
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { Port3DEngineService } from '../../services/port-3d-engine.service';
import { PortDataService } from '../../services/port-data.service';
import {
  DigitalTwinBase,
  ContainerTwin,
  ShipTwin,
  QuayCraneTwin,
  AGVTwin
} from '../../types/port.types';

@Component({
  selector: 'app-port-viewport',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule],
  template: `
    <div class="relative w-full h-full overflow-hidden bg-slate-950 select-none">
      <!-- 3D WebGL Canvas Mount Node -->
      <div #canvasContainer class="w-full h-full cursor-grab active:cursor-grabbing"></div>

      <!-- Top Left Floating: Camera Presets & Perspectives -->
      <div class="absolute top-4 left-4 z-10 flex flex-col gap-2">
        <div class="bg-slate-950/85 backdrop-blur-md border border-white/10 rounded-xl p-2 shadow-2xl flex items-center gap-1">
          <span class="text-[11px] text-slate-400 font-semibold px-2">视角:</span>
          @for (preset of cameraPresets; track preset.id) {
            <button
              (click)="selectPreset(preset.id)"
              type="button"
              class="px-2.5 py-1 rounded-lg text-xs font-medium text-slate-300 hover:text-white hover:bg-cyan-500/20 active:bg-cyan-500/30 transition-all border border-transparent hover:border-cyan-500/30"
            >
              {{ preset.label }}
            </button>
          }
        </div>

        <!-- 3D Measure & Space Tools -->
        <div class="bg-slate-950/85 backdrop-blur-md border border-white/10 rounded-xl p-2 shadow-2xl flex items-center gap-2 text-xs">
          <button
            (click)="toggleMeasureMode()"
            type="button"
            [class.bg-cyan-500]="portData.measureMode()"
            [class.text-white]="portData.measureMode()"
            [class.text-slate-300]="!portData.measureMode()"
            class="px-2.5 py-1 rounded-lg hover:bg-cyan-500/20 transition-all flex items-center gap-1.5"
          >
            <span>📏</span>
            <span>空间测距</span>
          </button>

          @if (portData.measureDistanceM() !== null) {
            <span class="px-2 py-0.5 rounded bg-cyan-950 border border-cyan-700 text-cyan-300 font-mono-num font-bold">
              {{ portData.measureDistanceM() }} 米
            </span>
            <button
              (click)="engine.clearMeasurement()"
              type="button"
              class="text-[11px] text-slate-400 hover:text-rose-400"
            >
              清除
            </button>
          }
        </div>
      </div>

      <!-- Top Right Floating: 3D GIS/BIM Layer Filter Toggles -->
      <div class="absolute top-4 right-4 z-10">
        <div class="bg-slate-950/85 backdrop-blur-md border border-white/10 rounded-xl p-3 shadow-2xl w-60">
          <div class="flex items-center justify-between pb-2 mb-2 border-b border-white/10">
            <span class="text-xs font-bold text-white flex items-center gap-1.5">
              <span>🗺️</span> 港口时空数据图层
            </span>
            <span class="text-[10px] text-slate-400">GIS+BIM+IoT</span>
          </div>

          <div class="grid grid-cols-2 gap-1.5 text-xs">
            <label class="flex items-center gap-2 text-slate-300 cursor-pointer hover:text-white">
              <input type="checkbox" [checked]="portData.layers().ships" (change)="portData.toggleLayer('ships')" class="rounded border-slate-700 text-cyan-500 focus:ring-0" />
              <span>船舶航标</span>
            </label>
            <label class="flex items-center gap-2 text-slate-300 cursor-pointer hover:text-white">
              <input type="checkbox" [checked]="portData.layers().cranes" (change)="portData.toggleLayer('cranes')" class="rounded border-slate-700 text-cyan-500 focus:ring-0" />
              <span>岸桥/场桥</span>
            </label>
            <label class="flex items-center gap-2 text-slate-300 cursor-pointer hover:text-white">
              <input type="checkbox" [checked]="portData.layers().containers" (change)="portData.toggleLayer('containers')" class="rounded border-slate-700 text-cyan-500 focus:ring-0" />
              <span>堆场集装箱</span>
            </label>
            <label class="flex items-center gap-2 text-slate-300 cursor-pointer hover:text-white">
              <input type="checkbox" [checked]="portData.layers().agvs" (change)="portData.toggleLayer('agvs')" class="rounded border-slate-700 text-cyan-500 focus:ring-0" />
              <span>AGV车队</span>
            </label>
            <label class="flex items-center gap-2 text-slate-300 cursor-pointer hover:text-white">
              <input type="checkbox" [checked]="portData.layers().rail" (change)="portData.toggleLayer('rail')" class="rounded border-slate-700 text-cyan-500 focus:ring-0" />
              <span>海铁联运</span>
            </label>
            <label class="flex items-center gap-2 text-slate-300 cursor-pointer hover:text-white">
              <input type="checkbox" [checked]="portData.layers().bulk" (change)="portData.toggleLayer('bulk')" class="rounded border-slate-700 text-cyan-500 focus:ring-0" />
              <span>散货料线</span>
            </label>
            <label class="flex items-center gap-2 text-slate-300 cursor-pointer hover:text-white">
              <input type="checkbox" [checked]="portData.layers().oilGas" (change)="portData.toggleLayer('oilGas')" class="rounded border-slate-700 text-cyan-500 focus:ring-0" />
              <span>油气储罐</span>
            </label>
            <label class="flex items-center gap-2 text-slate-300 cursor-pointer hover:text-white">
              <input type="checkbox" [checked]="portData.layers().pipelines" (change)="portData.toggleLayer('pipelines')" class="rounded border-slate-700 text-cyan-500 focus:ring-0" />
              <span>输油管网</span>
            </label>
            <label class="flex items-center gap-2 text-slate-300 cursor-pointer hover:text-white">
              <input type="checkbox" [checked]="portData.layers().energyGrid" (change)="portData.toggleLayer('energyGrid')" class="rounded border-slate-700 text-cyan-500 focus:ring-0" />
              <span>绿色岸电</span>
            </label>
            <label class="flex items-center gap-2 text-slate-300 cursor-pointer hover:text-white">
              <input type="checkbox" [checked]="portData.layers().safetyZones" (change)="portData.toggleLayer('safetyZones')" class="rounded border-slate-700 text-cyan-500 focus:ring-0" />
              <span>电子围栏</span>
            </label>
          </div>
        </div>
      </div>

      <!-- Selected 3D Twin Object Inspector Drawer (Bottom Left Floating) -->
      @if (portData.selectedObject(); as obj) {
        <div class="absolute bottom-24 left-4 z-20 w-96 bg-slate-950/95 backdrop-blur-md border border-cyan-500/30 rounded-2xl p-4 shadow-2xl text-slate-100 animate-in fade-in slide-in-from-bottom-4 duration-200">
          <div class="flex items-start justify-between pb-3 border-b border-white/10">
            <div>
              <div class="flex items-center gap-2">
                <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-950 text-cyan-400 border border-cyan-800">
                  {{ getObjectId(obj) }}
                </span>
                <span class="text-xs text-emerald-400 font-semibold">● 实时在线</span>
              </div>
              <h3 class="text-sm font-bold text-white mt-1">{{ getObjectName(obj) }}</h3>
            </div>
            <button
              (click)="portData.selectedObject.set(null)"
              type="button"
              class="text-slate-400 hover:text-white text-lg leading-none p-1"
            >
              ✕
            </button>
          </div>

          <!-- Dynamic Properties by Object Type -->
          <div class="py-3 text-xs space-y-2 font-sans">
            <!-- Vessel Info -->
            @if (asShip(obj); as ship) {
              <div class="grid grid-cols-2 gap-2 bg-slate-900/60 p-2.5 rounded-xl border border-white/5 font-mono-num">
                <div><span class="text-slate-400">呼号:</span> <span class="text-white">{{ ship.callSign }}</span></div>
                <div><span class="text-slate-400">吃水:</span> <span class="text-cyan-400">{{ ship.draft }}m</span></div>
                <div><span class="text-slate-400">航速:</span> <span class="text-white">{{ ship.speedKnots }} 节</span></div>
                <div><span class="text-slate-400">装载量:</span> <span class="text-sky-300">{{ ship.cargoTeuOrTons }} TEU</span></div>
                <div class="col-span-2"><span class="text-slate-400">目的港:</span> <span class="text-white">{{ ship.destination }}</span></div>
                <div class="col-span-2"><span class="text-slate-400">AIS 状态:</span> <span class="text-emerald-400">{{ ship.aisStatus }}</span></div>
              </div>
            }

            <!-- Crane Info -->
            @if (asCrane(obj); as crane) {
              <div class="grid grid-cols-2 gap-2 bg-slate-900/60 p-2.5 rounded-xl border border-white/5 font-mono-num">
                <div><span class="text-slate-400">单机效率:</span> <span class="text-emerald-400 font-bold">{{ crane.movesPerHour }} 箱/h</span></div>
                <div><span class="text-slate-400">电机功率:</span> <span class="text-white">{{ crane.powerKw }} kW</span></div>
                <div><span class="text-slate-400">轴承振动:</span> <span [class.text-amber-400]="crane.vibrationRms > 2.5" class="text-white">{{ crane.vibrationRms }} mm/s</span></div>
                <div><span class="text-slate-400">健康指数:</span> <span class="text-cyan-400 font-bold">{{ crane.healthScore }}/100</span></div>
                <div class="col-span-2"><span class="text-slate-400">作业任务:</span> <span class="text-white">{{ crane.currentTask }}</span></div>
              </div>
            }

            <!-- AGV Info -->
            @if (asAGV(obj); as agv) {
              <div class="grid grid-cols-2 gap-2 bg-slate-900/60 p-2.5 rounded-xl border border-white/5 font-mono-num">
                <div><span class="text-slate-400">状态:</span> <span class="text-cyan-400 font-bold">{{ agv.state }}</span></div>
                <div><span class="text-slate-400">剩余电量:</span> <span class="text-emerald-400 font-bold">{{ agv.batteryLevel }}%</span></div>
                <div><span class="text-slate-400">运行车速:</span> <span class="text-white">{{ agv.speedKmh }} km/h</span></div>
                <div><span class="text-slate-400">今日行驶:</span> <span class="text-white">{{ agv.mileageTodayKm }} km</span></div>
                <div class="col-span-2"><span class="text-slate-400">目标导航点:</span> <span class="text-sky-300">{{ agv.targetDestination }}</span></div>
              </div>
            }

            <!-- Container Info -->
            @if (asContainer(obj); as cont) {
              <div class="space-y-2">
                <div class="grid grid-cols-2 gap-2 bg-slate-900/60 p-2.5 rounded-xl border border-white/5 font-mono-num">
                  <div><span class="text-slate-400">箱型:</span> <span class="text-white">{{ cont.size }}</span></div>
                  <div><span class="text-slate-400">总重:</span> <span class="text-white">{{ cont.grossWeightTon }} 吨</span></div>
                  <div><span class="text-slate-400">类型:</span> <span class="text-amber-300">{{ cont.type }}</span></div>
                  <div><span class="text-slate-400">船名:</span> <span class="text-white">{{ cont.shipName }}</span></div>
                  <div class="col-span-2"><span class="text-slate-400">箱位:</span> <span class="text-cyan-300 font-bold">{{ cont.currentLocation }}</span></div>
                </div>

                <button
                  (click)="openContainerJourney(cont.containerNo)"
                  type="button"
                  class="w-full py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs transition-all flex items-center justify-center gap-1.5 shadow-lg shadow-cyan-600/30"
                >
                  <span>🔄</span>
                  <span>集装箱三维全流程路径回放</span>
                </button>
              </div>
            }
          </div>

          <!-- Bottom: IT/OT Safety Barrier Note -->
          <div class="pt-2 border-t border-white/5 flex items-center justify-between text-[11px] text-slate-400">
            <span class="flex items-center gap-1 text-emerald-400">
              <span>🔒</span> IT/OT 隔离与数字孪生防护
            </span>
            <span class="font-mono-num text-[10px]">责任部门: {{ getDept(obj) }}</span>
          </div>
        </div>
      }

      <!-- Bottom Port Time Machine Scrubber Bar -->
      <div class="absolute bottom-4 left-4 right-4 z-10 bg-slate-950/90 backdrop-blur-md border border-white/10 rounded-2xl px-6 py-3 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-4">
        <!-- Play / Pause & Speed -->
        <div class="flex items-center gap-3 shrink-0">
          <button
            (click)="toggleTimeMachinePlay()"
            type="button"
            class="w-9 h-9 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white flex items-center justify-center shadow-md shadow-cyan-600/30 transition-all text-sm font-bold"
          >
            @if (portData.timeMachine().isPlaying) {
              <span>⏸</span>
            } @else {
              <span>▶</span>
            }
          </button>

          <div class="flex items-center gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800 text-xs font-mono">
            @for (spd of [1, 5, 10, 30]; track spd) {
              <button
                (click)="setTimeSpeed(spd)"
                type="button"
                [class.bg-cyan-500]="portData.timeMachine().playbackSpeed === spd"
                [class.text-white]="portData.timeMachine().playbackSpeed === spd"
                [class.text-slate-400]="portData.timeMachine().playbackSpeed !== spd"
                class="px-2 py-0.5 rounded transition-colors"
              >
                {{ spd }}x
              </button>
            }
          </div>

          <div class="text-xs text-slate-400 flex items-center gap-1">
            <span>⏳</span>
            <span class="font-bold text-white">时空回溯 (Time Machine)</span>
          </div>
        </div>

        <!-- Scrubber Range Slider -->
        <div class="w-full flex items-center gap-4">
          <span class="text-xs font-mono text-slate-400">06:00</span>
          <div class="relative w-full flex items-center">
            <input
              type="range"
              min="0"
              max="960"
              [value]="getTimeSliderValue()"
              (input)="onSliderChange($event)"
              class="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
            />
          </div>
          <span class="text-xs font-mono text-slate-400">22:00</span>
        </div>

        <!-- Current Simulated Clock -->
        <div class="shrink-0 flex items-center gap-2 font-mono-num text-xs">
          <span class="px-2 py-1 rounded bg-slate-900 border border-slate-800 text-cyan-400 font-bold">
            {{ formatTime(portData.timeMachine().currentSimulatedTime) }}
          </span>
          <button
            (click)="resetToNow()"
            type="button"
            class="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs"
          >
            恢复实时
          </button>
        </div>
      </div>
    </div>
  `
})
export class PortViewport implements OnInit, OnDestroy {
  @ViewChild('canvasContainer', { static: true }) canvasContainerRef!: ElementRef<HTMLElement>;

  readonly engine = inject(Port3DEngineService);
  readonly portData = inject(PortDataService);

  readonly cameraPresets = [
    { id: 'OVERVIEW', label: '鸟瞰全景' },
    { id: 'TOWER', label: '总控指挥塔' },
    { id: 'BERTH', label: '泊位作业区' },
    { id: 'YARD', label: '自动化堆场' },
    { id: 'SHIP_BRIDGE', label: '船长驾驶台' },
    { id: 'CRANE_CABIN', label: '岸桥司机室' },
    { id: 'RAIL_STATION', label: '海铁联运站' }
  ];

  ngOnInit() {
    this.engine.initialize(this.canvasContainerRef.nativeElement);
  }

  selectPreset(presetId: string) {
    this.engine.applyCameraPreset(presetId);
  }

  toggleMeasureMode() {
    this.portData.measureMode.update(m => !m);
    if (!this.portData.measureMode()) {
      this.engine.clearMeasurement();
    }
  }

  openContainerJourney(containerNo: string) {
    this.portData.selectContainerByNo(containerNo);
    this.portData.activeModule.set('yard');
  }

  toggleTimeMachinePlay() {
    this.portData.setTimeMachinePlaying(!this.portData.timeMachine().isPlaying);
  }

  setTimeSpeed(speed: number) {
    this.portData.setTimeMachineSpeed(speed);
  }

  getTimeSliderValue(): number {
    const tm = this.portData.timeMachine();
    const start = tm.timelineRangeStart.getTime();
    const curr = tm.currentSimulatedTime.getTime();
    return Math.floor((curr - start) / (60 * 1000));
  }

  onSliderChange(event: Event) {
    const minutes = parseInt((event.target as HTMLInputElement).value, 10);
    const tm = this.portData.timeMachine();
    const newDate = new Date(tm.timelineRangeStart.getTime() + minutes * 60 * 1000);
    this.portData.seekTime(newDate);
  }

  resetToNow() {
    this.portData.seekTime(new Date(2026, 8, 20, 10, 30, 0));
  }

  formatTime(date: Date): string {
    return date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  }

  // Type helper functions for template
  getObjectId(obj: DigitalTwinBase | ContainerTwin): string {
    if ('id' in obj && obj.id) return obj.id;
    if ('containerNo' in obj && obj.containerNo) return obj.containerNo;
    return 'OBJ-TWIN';
  }

  getObjectName(obj: DigitalTwinBase | ContainerTwin): string {
    if ('name' in obj && obj.name) return obj.name;
    if ('containerNo' in obj) return `集装箱 (${obj.containerNo})`;
    return '港口单体孪生';
  }

  asShip(obj: DigitalTwinBase | ContainerTwin): ShipTwin | null {
    return 'shipType' in obj ? (obj as ShipTwin) : null;
  }

  asCrane(obj: DigitalTwinBase | ContainerTwin): QuayCraneTwin | null {
    return 'craneNo' in obj ? (obj as QuayCraneTwin) : null;
  }

  asAGV(obj: DigitalTwinBase | ContainerTwin): AGVTwin | null {
    return 'agvNo' in obj ? (obj as AGVTwin) : null;
  }

  asContainer(obj: DigitalTwinBase | ContainerTwin): ContainerTwin | null {
    return 'containerNo' in obj ? (obj as ContainerTwin) : null;
  }

  getDept(obj: DigitalTwinBase | ContainerTwin): string {
    if ('responsibleDept' in obj && obj.responsibleDept) return obj.responsibleDept;
    return '调度指挥中心';
  }

  ngOnDestroy() {
    this.engine.dispose();
  }
}
