import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PortDataService } from '../../services/port-data.service';
import { Port3DEngineService } from '../../services/port-3d-engine.service';

@Component({
  selector: 'app-energy-carbon-panel',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule],
  template: `
    <div class="h-full w-full bg-slate-950/95 backdrop-blur-xl border-l border-white/10 flex flex-col text-slate-200 overflow-hidden font-sans">
      <!-- Header -->
      <div class="p-4 border-b border-white/10 flex items-center justify-between">
        <div class="flex items-center gap-2">
          <span class="text-xl">🌿</span>
          <div>
            <h2 class="text-sm font-bold text-white">智慧绿色低碳港口与微电网调度</h2>
            <p class="text-[11px] text-slate-400">零碳码头能碳一体化 · 高压岸电 · 源网荷储智能协同</p>
          </div>
        </div>
        <button
          type="button"
          (click)="close()"
          class="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/5"
        >
          ✕
        </button>
      </div>

      <div class="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
        <!-- 1. Carbon & Green Port KPIs -->
        <div class="grid grid-cols-2 gap-2 font-mono-num text-xs">
          <div class="bg-slate-900/80 p-3 rounded-xl border border-emerald-500/20">
            <div class="text-[10px] text-slate-400">单箱综合碳排放强度</div>
            <div class="text-xl font-bold text-emerald-400 mt-1">{{ portData.energy().carbonPerTeuKg }} <span class="text-xs font-normal text-slate-400">kg/TEU</span></div>
            <div class="text-[10px] text-emerald-300 mt-1">同比下降 -12.4% (超前达标)</div>
          </div>

          <div class="bg-slate-900/80 p-3 rounded-xl border border-white/5">
            <div class="text-[10px] text-slate-400">今日岸电减碳累计</div>
            <div class="text-xl font-bold text-cyan-400 mt-1">{{ portData.energy().carbonSavedShorePowerTons }} <span class="text-xs font-normal text-slate-400">t</span></div>
            <div class="text-[10px] text-slate-400 mt-1">光伏 + 岸电 + 储能</div>
          </div>
        </div>

        <!-- 2. Real-time Microgrid Load Distribution -->
        <div class="bg-slate-900/70 border border-white/5 rounded-xl p-3 space-y-2">
          <div class="flex items-center justify-between">
            <h4 class="text-xs font-bold text-white flex items-center gap-1.5">
              <span>⚡</span> 港区微电网实时负荷分解
            </h4>
            <span class="text-xs font-bold text-amber-400 font-mono-num">{{ portData.energy().totalGridPowerKw }} kW</span>
          </div>

          <div class="space-y-1.5 text-xs font-mono-num">
            <div class="flex items-center justify-between bg-slate-950/60 p-2 rounded-lg">
              <span class="text-slate-300">岸边集装箱起重机 (QC) 动力</span>
              <span class="text-white font-bold">{{ portData.energy().craneLoadKw }} kW</span>
            </div>
            <div class="flex items-center justify-between bg-slate-950/60 p-2 rounded-lg">
              <span class="text-slate-300">深水泊位高压岸电 (AMP) 供电</span>
              <span class="text-emerald-400 font-bold">{{ portData.energy().shorePowerSupplyKw }} kW</span>
            </div>
            <div class="flex items-center justify-between bg-slate-950/60 p-2 rounded-lg">
              <span class="text-slate-300">冷藏集装箱插座群插电温控</span>
              <span class="text-sky-300 font-bold">{{ portData.energy().reeferPlugLoadKw }} kW</span>
            </div>
            <div class="flex items-center justify-between bg-slate-950/60 p-2 rounded-lg">
              <span class="text-slate-300">AGV 快速充换电站充电负荷</span>
              <span class="text-cyan-300 font-bold">{{ portData.energy().agvChargingLoadKw }} kW</span>
            </div>
          </div>
        </div>

        <!-- 3. Solar PV & Energy Storage System (BESS) -->
        <div class="bg-slate-900/70 border border-white/5 rounded-xl p-3">
          <div class="flex items-center justify-between mb-2">
            <h4 class="text-xs font-bold text-white flex items-center gap-1.5">
              <span>☀️</span> 屋顶分布式光伏与集装箱储能
            </h4>
            <span class="text-[10px] text-emerald-400 font-mono">发电功率: {{ portData.energy().solarPvGenerationKw }} kW</span>
          </div>

          <div class="bg-slate-950/60 p-2.5 rounded-xl border border-white/5 text-xs font-mono-num space-y-1">
            <div class="flex justify-between">
              <span class="text-slate-400">储能电站 (BESS) 状态:</span>
              <span class="text-emerald-400 font-bold">放电中 (平抑峰值负荷)</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">储能剩余电量 (SOC):</span>
              <span class="text-white font-bold">{{ portData.energy().bessStorageStateOfCharge }}% (4.2 MWh)</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">今日总能耗:</span>
              <span class="text-emerald-300 font-bold">{{ portData.energy().todayTotalKWh }} kWh</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class EnergyCarbonPanel {
  readonly portData = inject(PortDataService);
  readonly engine = inject(Port3DEngineService);

  close() {
    this.portData.activeModule.set('control-tower');
  }
}
