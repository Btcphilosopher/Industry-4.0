import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PortDataService } from '../../services/port-data.service';
import { Port3DEngineService } from '../../services/port-3d-engine.service';
import { ShipTwin, BerthTwin } from '../../types/port.types';

@Component({
  selector: 'app-berth-ship-panel',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule],
  template: `
    <div class="h-full w-full bg-slate-950/95 backdrop-blur-xl border-l border-white/10 flex flex-col text-slate-200 overflow-hidden font-sans">
      <!-- Header -->
      <div class="p-4 border-b border-white/10 flex items-center justify-between">
        <div class="flex items-center gap-2">
          <span class="text-xl">⚓</span>
          <div>
            <h2 class="text-sm font-bold text-white">泊位调度与船舶数字孪生</h2>
            <p class="text-[11px] text-slate-400">AIS 实时动态 · 潮位自适应智能配泊 · 拖轮引航协同</p>
          </div>
        </div>
        <button
          (click)="close()"
          class="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/5"
        >
          ✕
        </button>
      </div>

      <div class="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
        <!-- 1. Berth Status Overview Cards -->
        <div>
          <h3 class="text-xs font-bold text-cyan-400 uppercase tracking-wider mb-2 flex items-center justify-between">
            <span>码头深水泊位实时状态</span>
            <span class="text-[10px] text-slate-400">利用率: 100%</span>
          </h3>

          <div class="grid grid-cols-3 gap-2">
            @for (berth of portData.berths(); track berth.id) {
              <button
                type="button"
                (click)="focusBerth(berth)"
                class="bg-slate-900/80 hover:bg-slate-800/80 border border-white/5 hover:border-cyan-500/40 p-2.5 rounded-xl cursor-pointer transition-all text-left w-full"
              >
                <div class="flex items-center justify-between mb-1">
                  <span class="font-bold text-xs text-white">{{ berth.berthNo }}</span>
                  <span class="px-1.5 py-0.5 rounded text-[10px] font-medium bg-emerald-950 text-emerald-300 border border-emerald-800">
                    {{ berth.status === 'occupied' ? '作业中' : '空闲' }}
                  </span>
                </div>
                <div class="text-[11px] text-cyan-300 font-semibold truncate">{{ berth.currentShipName || '无' }}</div>
                <div class="text-[10px] text-slate-400 mt-1 flex justify-between font-mono-num">
                  <span>水深: {{ berth.waterDepth }}m</span>
                  <span>长度: {{ berth.length }}m</span>
                </div>
                <div class="mt-2 text-[10px] flex items-center gap-1 text-emerald-400">
                  <span>⚡ 岸电: {{ berth.shorePowerCapacityKw > 0 ? '已接驳 (10kV)' : '未接' }}</span>
                </div>
              </button>
            }
          </div>
        </div>

        <!-- 2. Berth Gantt Timeline Simulation -->
        <div class="bg-slate-900/70 border border-white/5 rounded-xl p-3">
          <div class="flex items-center justify-between mb-2">
            <h4 class="text-xs font-bold text-white flex items-center gap-1">
              <span>📊</span> 泊位动态配泊甘特图 (未来24小时)
            </h4>
            <span class="text-[10px] text-cyan-400 font-mono">潮位窗口: 14:00 (+4.8m)</span>
          </div>

          <div class="space-y-2 text-xs font-mono-num">
            <div class="flex items-center gap-2">
              <span class="w-12 text-slate-400 text-[11px]">01#泊位</span>
              <div class="flex-1 h-6 bg-slate-950 rounded-lg overflow-hidden flex p-0.5 border border-slate-800 relative">
                <div class="w-3/5 bg-cyan-700/70 border border-cyan-400/50 rounded text-[10px] flex items-center justify-center text-white font-bold truncate">
                  中远海运银河 (卸 2,400 TEU)
                </div>
                <div class="w-2/5 bg-slate-800/40 border border-dashed border-slate-600 rounded text-[9px] flex items-center justify-center text-slate-400 ml-1">
                  18:00 待泊: 长荣长范
                </div>
              </div>
            </div>

            <div class="flex items-center gap-2">
              <span class="w-12 text-slate-400 text-[11px]">02#泊位</span>
              <div class="flex-1 h-6 bg-slate-950 rounded-lg overflow-hidden flex p-0.5 border border-slate-800">
                <div class="w-4/5 bg-sky-700/70 border border-sky-400/50 rounded text-[10px] flex items-center justify-center text-white font-bold truncate">
                  地中海米娅 (装 3,100 TEU)
                </div>
              </div>
            </div>

            <div class="flex items-center gap-2">
              <span class="w-12 text-slate-400 text-[11px]">03#泊位</span>
              <div class="flex-1 h-6 bg-slate-950 rounded-lg overflow-hidden flex p-0.5 border border-slate-800">
                <div class="w-1/2 bg-indigo-700/70 border border-indigo-400/50 rounded text-[10px] flex items-center justify-center text-white font-bold truncate">
                  中远之星 (快线班轮)
                </div>
                <div class="w-1/2 bg-amber-900/40 border border-amber-600/50 rounded text-[9px] flex items-center justify-center text-amber-300 ml-1">
                  14:30 预靠: 达飞香榭丽舍
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- 3. AIS Live Fleet Table -->
        <div>
          <div class="flex items-center justify-between mb-2">
            <h3 class="text-xs font-bold text-cyan-400 uppercase tracking-wider">AIS 实时在港及预抵船舶队列</h3>
            <span class="text-[10px] text-slate-400">总计 4 艘</span>
          </div>

          <div class="space-y-2">
            @for (ship of portData.ships(); track ship.id) {
              <button
                type="button"
                (click)="focusShip(ship)"
                class="bg-slate-900/80 hover:bg-slate-800 border border-white/5 hover:border-cyan-500/40 p-3 rounded-xl cursor-pointer transition-all text-left w-full"
              >
                <div class="flex items-start justify-between">
                  <div>
                    <div class="flex items-center gap-2">
                      <span class="text-xs font-bold text-white">{{ ship.name }}</span>
                      <span class="px-1.5 py-0.2 rounded text-[10px] font-mono bg-slate-800 text-slate-300">
                        {{ ship.callSign }}
                      </span>
                    </div>
                    <div class="text-[11px] text-slate-400 mt-0.5 font-mono-num">
                      {{ ship.shipType }} · 船长 {{ ship.length }}m · 吃水 {{ ship.draft }}m · 载重 {{ ship.cargoTeuOrTons }} TEU
                    </div>
                  </div>
                  <span
                    [class.bg-emerald-950]="ship.aisStatus === 'Moored'"
                    [class.text-emerald-300]="ship.aisStatus === 'Moored'"
                    [class.border-emerald-800]="ship.aisStatus === 'Moored'"
                    [class.bg-amber-950]="ship.aisStatus !== 'Moored'"
                    [class.text-amber-300]="ship.aisStatus !== 'Moored'"
                    [class.border-amber-800]="ship.aisStatus !== 'Moored'"
                    class="px-2 py-0.5 rounded text-[10px] font-semibold border font-mono"
                  >
                    {{ ship.aisStatus === 'Moored' ? '已靠泊作业' : '航行进港中' }}
                  </span>
                </div>

                <div class="mt-2 pt-2 border-t border-white/5 flex items-center justify-between text-[11px] text-slate-400 font-mono-num">
                  <div>ETA: <span class="text-slate-200">{{ ship.eta }}</span></div>
                  <div>ETD: <span class="text-slate-200">{{ ship.etd }}</span></div>
                  <div class="text-cyan-400 hover:underline">三维定位 →</div>
                </div>
              </button>
            }
          </div>
        </div>

        <!-- 4. Smart Berthing AI Assistant Suggestion -->
        <div class="bg-gradient-to-br from-cyan-950/60 to-blue-950/60 border border-cyan-500/30 rounded-xl p-3">
          <div class="flex items-center gap-2 text-cyan-300 text-xs font-bold mb-1">
            <span>🤖</span>
            <span>AI 配泊潮位推荐建议</span>
          </div>
          <p class="text-[11px] text-slate-300 leading-relaxed">
            超大型集装箱船 <strong>"长荣长范" (吃水 16.5m)</strong> 预计 13:45 抵达长江口深水航道。
            建议利用 14:15 高潮时段 (+4.8m 潮高) 直靠 <strong>01#泊位</strong>，配置 4 艘 6000HP 全回转拖轮协助靠泊，可节省船舶压港待泊时间约 <strong>4.2 小时</strong>。
          </p>
          <button
            (click)="triggerBerthSimulation()"
            class="mt-2.5 w-full py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs transition-colors flex items-center justify-center gap-1.5"
          >
            <span>▶</span>
            <span>启动三维进港靠泊推演模拟</span>
          </button>
        </div>
      </div>
    </div>
  `
})
export class BerthShipPanel {
  readonly portData = inject(PortDataService);
  readonly engine = inject(Port3DEngineService);

  close() {
    this.portData.activeModule.set('control-tower');
  }

  focusBerth(berth: BerthTwin) {
    this.portData.selectObject(berth);
    this.engine.applyCameraPreset('BERTH');
  }

  focusShip(ship: ShipTwin) {
    this.portData.selectObject(ship);
    this.engine.applyCameraPreset('SHIP_BRIDGE');
  }

  triggerBerthSimulation() {
    this.engine.applyCameraPreset('OVERVIEW');
    this.portData.setTimeMachinePlaying(true);
  }
}
