import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PortDataService } from '../../services/port-data.service';
import { Port3DEngineService } from '../../services/port-3d-engine.service';
import { QuayCraneTwin } from '../../types/port.types';

@Component({
  selector: 'app-maintenance-rul-panel',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule],
  template: `
    <div class="h-full w-full bg-slate-950/95 backdrop-blur-xl border-l border-white/10 flex flex-col text-slate-200 overflow-hidden font-sans">
      <!-- Header -->
      <div class="p-4 border-b border-white/10 flex items-center justify-between">
        <div class="flex items-center gap-2">
          <span class="text-xl">🔧</span>
          <div>
            <h2 class="text-sm font-bold text-white">港口重装设备预测性维护 (PHM)</h2>
            <p class="text-[11px] text-slate-400">振动频谱分析 · 剩余寿命预测 (RUL) · 状态修智能工单</p>
          </div>
        </div>
        <button
          type="button"
          (click)="close()"
          class="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/5"
        >
          ✕
        </button>
      </div>

      <div class="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
        <!-- 1. Equipment Health Status List -->
        <div>
          <h3 class="text-xs font-bold text-cyan-400 uppercase tracking-wider mb-2">
            核心起重与转运装备健康度评估
          </h3>

          <div class="space-y-2">
            @for (qc of portData.quayCranes(); track qc.id) {
              <button
                type="button"
                (click)="focusCrane(qc)"
                class="bg-slate-900/80 hover:bg-slate-800 border border-white/5 hover:border-cyan-500/40 p-3 rounded-xl cursor-pointer transition-all space-y-2 text-left w-full"
              >
                <div class="flex items-center justify-between">
                  <div class="flex items-center gap-2">
                    <span class="font-bold text-xs text-white">{{ qc.craneNo }} 岸桥起重机</span>
                    <span class="text-[10px] text-slate-400 font-mono">运行小时: 14,280 h</span>
                  </div>
                  <span
                    [class.text-emerald-400]="qc.healthScore >= 90"
                    [class.text-amber-400]="qc.healthScore < 90"
                    class="font-mono-num font-bold text-sm"
                  >
                    {{ qc.healthScore }} <span class="text-xs font-normal">分</span>
                  </span>
                </div>

                <!-- Telemetry parameters -->
                <div class="grid grid-cols-3 gap-2 text-[10px] font-mono-num bg-slate-950/60 p-2 rounded-lg">
                  <div>
                    <span class="text-slate-400">起升减速机振动:</span>
                    <div [class.text-amber-400]="qc.vibrationRms > 2.5" class="font-bold text-slate-200 mt-0.5">
                      {{ qc.vibrationRms }} mm/s
                    </div>
                  </div>
                  <div>
                    <span class="text-slate-400">主电机定子温度:</span>
                    <div class="font-bold text-slate-200 mt-0.5">{{ qc.motorTempC }} °C</div>
                  </div>
                  <div>
                    <span class="text-slate-400">预测剩余寿命:</span>
                    <div class="font-bold text-cyan-300 mt-0.5">380 天</div>
                  </div>
                </div>

                @if (qc.status === 'warning') {
                  <div class="bg-amber-950/50 border border-amber-500/30 p-2 rounded-lg text-[10px] text-amber-200 flex items-center justify-between">
                    <span>⚠️ 轴承高频微振超限，建议下次空档期检查润滑脂</span>
                    <span class="px-2 py-0.5 bg-amber-600 rounded text-white font-bold">
                      生成检修工单
                    </span>
                  </div>
                }
              </button>
            }
          </div>
        </div>

        <!-- 2. AI PHM Diagnostic Engine Summary -->
        <div class="bg-slate-900/70 border border-white/5 rounded-xl p-3 text-xs leading-relaxed">
          <div class="flex items-center gap-1.5 text-cyan-300 font-bold mb-1">
            <span>🧠</span>
            <span>设备智能运维效益总结</span>
          </div>
          <p class="text-slate-300 text-[11px]">
            通过数字孪生实时振动温升监测与多物理场疲劳损伤推演，全港非计划停机率降低 <strong>42%</strong>，关键机械备件库存占用资金压缩 <strong>28%</strong>。
          </p>
        </div>
      </div>
    </div>
  `
})
export class MaintenanceRulPanel {
  readonly portData = inject(PortDataService);
  readonly engine = inject(Port3DEngineService);

  close() {
    this.portData.activeModule.set('control-tower');
  }

  focusCrane(qc: QuayCraneTwin) {
    this.portData.selectObject(qc);
    this.engine.applyCameraPreset('CRANE_CABIN');
  }
}
