import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PortDataService } from '../../services/port-data.service';
import { Port3DEngineService } from '../../services/port-3d-engine.service';
import { AGVTwin } from '../../types/port.types';

@Component({
  selector: 'app-agv-fleet-panel',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule],
  template: `
    <div class="h-full w-full bg-slate-950/95 backdrop-blur-xl border-l border-white/10 flex flex-col text-slate-200 overflow-hidden font-sans">
      <!-- Header -->
      <div class="p-4 border-b border-white/10 flex items-center justify-between">
        <div class="flex items-center gap-2">
          <span class="text-xl">🤖</span>
          <div>
            <h2 class="text-sm font-bold text-white">AGV 与无人集卡高精群控</h2>
            <p class="text-[11px] text-slate-400">北斗厘米级定位 · 5G V2X 车路协同 · 动态路径最优规划</p>
          </div>
        </div>
        <button
          (click)="close()"
          class="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/5"
        >
          ✕
        </button>
      </div>

      <div class="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
        <!-- 1. Fleet Telemetry KPIs -->
        <div class="grid grid-cols-3 gap-2 font-mono-num text-xs">
          <div class="bg-slate-900/80 p-2.5 rounded-xl border border-white/5">
            <div class="text-[10px] text-slate-400">在线车队</div>
            <div class="text-lg font-bold text-white mt-0.5">40 <span class="text-xs font-normal text-slate-400">台</span></div>
            <div class="text-[10px] text-emerald-400">在线率 100%</div>
          </div>

          <div class="bg-slate-900/80 p-2.5 rounded-xl border border-white/5">
            <div class="text-[10px] text-slate-400">空驶率</div>
            <div class="text-lg font-bold text-emerald-400 mt-0.5">11.2%</div>
            <div class="text-[10px] text-slate-400">行业领先 (<15%)</div>
          </div>

          <div class="bg-slate-900/80 p-2.5 rounded-xl border border-white/5">
            <div class="text-[10px] text-slate-400">平均运行车速</div>
            <div class="text-lg font-bold text-cyan-400 mt-0.5">22.4 <span class="text-xs font-normal text-slate-400">km/h</span></div>
            <div class="text-[10px] text-slate-400">安全限速 25km/h</div>
          </div>
        </div>

        <!-- 2. Battery & Charging Station Status -->
        <div class="bg-slate-900/70 border border-white/5 rounded-xl p-3">
          <div class="flex items-center justify-between mb-2">
            <h4 class="text-xs font-bold text-white flex items-center gap-1.5">
              <span>🔋</span> 自动化快速换电站 (BESS Station)
            </h4>
            <span class="text-[10px] text-emerald-400">换电耗时: 3.5分钟/台</span>
          </div>

          <div class="flex items-center justify-between text-xs font-mono-num bg-slate-950/60 p-2 rounded-lg">
            <div>
              <span class="text-slate-400 text-[11px]">可用满电电池包:</span>
              <span class="text-emerald-400 font-bold ml-1">18 组</span>
            </div>
            <div>
              <span class="text-slate-400 text-[11px]">正在充电:</span>
              <span class="text-cyan-400 font-bold ml-1">6 组</span>
            </div>
          </div>
        </div>

        <!-- 3. Active AGV Fleet List -->
        <div>
          <div class="flex items-center justify-between mb-2">
            <h3 class="text-xs font-bold text-cyan-400 uppercase tracking-wider">实时车队调度状态</h3>
            <span class="text-[10px] text-slate-400">点击聚焦三维追踪</span>
          </div>

          <div class="space-y-2 font-mono-num text-xs">
            @for (agv of portData.agvs(); track agv.id) {
              <button
                type="button"
                (click)="focusAGV(agv)"
                class="bg-slate-900/80 hover:bg-slate-800 border border-white/5 hover:border-cyan-500/40 p-2.5 rounded-xl cursor-pointer transition-all flex items-center justify-between text-left w-full"
              >
                <div class="flex items-center gap-2.5">
                  <div class="w-8 h-8 rounded-lg bg-cyan-950 border border-cyan-800 flex items-center justify-center font-bold text-cyan-300">
                    {{ agv.agvNo.slice(-2) }}
                  </div>
                  <div>
                    <div class="flex items-center gap-2">
                      <span class="font-bold text-white">{{ agv.agvNo }}</span>
                      <span
                        [class.bg-emerald-950]="agv.state === 'transporting'"
                        [class.text-emerald-300]="agv.state === 'transporting'"
                        [class.bg-sky-950]="agv.state === 'charging'"
                        [class.text-sky-300]="agv.state === 'charging'"
                        class="px-1.5 py-0.2 rounded text-[10px] font-sans"
                      >
                        {{ agv.state === 'transporting' ? '重载转运' : agv.state === 'charging' ? '换电充电' : '待命' }}
                      </span>
                    </div>
                    <div class="text-[10px] text-slate-400 mt-0.5 font-sans">
                      目标: {{ agv.targetDestination }}
                    </div>
                  </div>
                </div>

                <div class="text-right">
                  <div class="flex items-center gap-1 justify-end font-bold" [class.text-emerald-400]="agv.batteryLevel > 30" [class.text-amber-400]="agv.batteryLevel <= 30">
                    <span>⚡</span>
                    <span>{{ agv.batteryLevel }}%</span>
                  </div>
                  <div class="text-[10px] text-slate-400">{{ agv.speedKmh }} km/h</div>
                </div>
              </button>
            }
          </div>
        </div>
      </div>
    </div>
  `
})
export class AGVFleetPanel {
  readonly portData = inject(PortDataService);
  readonly engine = inject(Port3DEngineService);

  close() {
    this.portData.activeModule.set('control-tower');
  }

  focusAGV(agv: AGVTwin) {
    this.portData.selectObject(agv);
    this.engine.applyCameraPreset('YARD');
  }
}
