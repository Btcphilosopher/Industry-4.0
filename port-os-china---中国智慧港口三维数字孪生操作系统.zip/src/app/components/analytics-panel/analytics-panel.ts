import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PortDataService } from '../../services/port-data.service';

@Component({
  selector: 'app-analytics-panel',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule],
  template: `
    <div class="h-full w-full bg-slate-950/95 backdrop-blur-xl border-l border-white/10 flex flex-col text-slate-200 overflow-hidden font-sans">
      <!-- Header -->
      <div class="p-4 border-b border-white/10 flex items-center justify-between">
        <div class="flex items-center gap-2">
          <span class="text-xl">📈</span>
          <div>
            <h2 class="text-sm font-bold text-white">智慧港口经营分析与效能驾驶舱</h2>
            <p class="text-[11px] text-slate-400">综合吞吐量 · 船舶在港停时 · 综合设备效能 (OEE)</p>
          </div>
        </div>
        <button
          (click)="close()"
          class="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/5"
        >
          ✕
        </button>
      </div>

      <div class="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
        <!-- 1. High Level Executive KPIs -->
        <div class="grid grid-cols-2 gap-2 font-mono-num text-xs">
          <div class="bg-slate-900/80 p-3 rounded-xl border border-white/5">
            <div class="text-[10px] text-slate-400">年度累计集装箱吞吐量</div>
            <div class="text-xl font-bold text-cyan-400 mt-1">18.42 <span class="text-xs font-normal text-slate-400">百万 TEU</span></div>
            <div class="text-[10px] text-emerald-400 mt-1">年度进度 69.5% (超前目标)</div>
          </div>

          <div class="bg-slate-900/80 p-3 rounded-xl border border-white/5">
            <div class="text-[10px] text-slate-400">大型集装箱船平均在港停时</div>
            <div class="text-xl font-bold text-emerald-400 mt-1">21.8 <span class="text-xs font-normal text-slate-400">小时</span></div>
            <div class="text-[10px] text-slate-400 mt-1">同比压缩 14.6%</div>
          </div>
        </div>

        <!-- 2. Throughput Distribution breakdown -->
        <div class="bg-slate-900/70 border border-white/5 rounded-xl p-3 space-y-2">
          <h4 class="text-xs font-bold text-white">全港多货种综合运量构成 (当月)</h4>

          <div class="space-y-1.5 text-xs font-mono-num">
            <div>
              <div class="flex justify-between text-slate-300 text-[11px] mb-1">
                <span>集装箱外贸干线</span>
                <span class="text-white font-bold">1,820,000 TEU (64%)</span>
              </div>
              <div class="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden">
                <div class="bg-cyan-500 h-full rounded-full w-[64%]"></div>
              </div>
            </div>

            <div>
              <div class="flex justify-between text-slate-300 text-[11px] mb-1">
                <span>铁矿石与大宗散货</span>
                <span class="text-white font-bold">4,650,000 吨 (22%)</span>
              </div>
              <div class="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden">
                <div class="bg-amber-500 h-full rounded-full w-[22%]"></div>
              </div>
            </div>

            <div>
              <div class="flex justify-between text-slate-300 text-[11px] mb-1">
                <span>原油与保税 LNG 储运</span>
                <span class="text-white font-bold">2,180,000 吨 (14%)</span>
              </div>
              <div class="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden">
                <div class="bg-purple-500 h-full rounded-full w-[14%]"></div>
              </div>
            </div>
          </div>
        </div>

        <!-- 3. Port Operations Efficiency Index -->
        <div class="bg-slate-900/70 border border-white/5 rounded-xl p-3 space-y-2 font-mono-num text-xs">
          <h4 class="text-xs font-bold text-cyan-400">综合设备整体效能 (OEE)</h4>

          <div class="grid grid-cols-3 gap-2 text-center">
            <div class="bg-slate-950/60 p-2 rounded-lg">
              <div class="text-[10px] text-slate-400">时间利用率</div>
              <div class="text-sm font-bold text-white mt-0.5">92.4%</div>
            </div>
            <div class="bg-slate-950/60 p-2 rounded-lg">
              <div class="text-[10px] text-slate-400">性能发挥率</div>
              <div class="text-sm font-bold text-white mt-0.5">88.9%</div>
            </div>
            <div class="bg-slate-950/60 p-2 rounded-lg">
              <div class="text-[10px] text-slate-400">综合 OEE</div>
              <div class="text-sm font-bold text-emerald-400 mt-0.5">82.1%</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class AnalyticsPanel {
  readonly portData = inject(PortDataService);

  close() {
    this.portData.activeModule.set('control-tower');
  }
}
