import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GeminiPortService } from '../../services/gemini-port.service';
import { PortDataService } from '../../services/port-data.service';

@Component({
  selector: 'app-ai-copilot-drawer',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule],
  template: `
    <div class="h-full w-full bg-slate-950/95 backdrop-blur-xl border-l border-cyan-500/30 flex flex-col text-slate-200 overflow-hidden font-sans">
      <!-- Header -->
      <div class="p-4 border-b border-white/10 flex items-center justify-between bg-gradient-to-r from-slate-900 via-cyan-950/40 to-slate-900">
        <div class="flex items-center gap-2.5">
          <div class="w-8 h-8 rounded-lg bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-300">
            ✨
          </div>
          <div>
            <div class="flex items-center gap-2">
              <h2 class="text-sm font-bold text-white">PORT OS CHINA · 智能调度副驾</h2>
              <span class="px-1.5 py-0.2 rounded text-[10px] font-mono bg-cyan-950 text-cyan-400 border border-cyan-800">
                Gemini 3.7
              </span>
            </div>
            <p class="text-[11px] text-slate-400">大模型运筹赋能 · IT/OT 人机双重确认授权保障</p>
          </div>
        </div>
        <button
          (click)="close()"
          class="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/5"
        >
          ✕
        </button>
      </div>

      <!-- Messages Thread -->
      <div class="flex-1 overflow-y-auto p-4 space-y-3 no-scrollbar text-xs">
        @for (msg of gemini.messages(); track msg.id) {
          <div
            [class.items-end]="msg.sender === 'user'"
            [class.items-start]="msg.sender === 'assistant'"
            class="flex flex-col space-y-1"
          >
            <div class="flex items-center gap-1.5 text-[10px] text-slate-500 font-mono">
              <span>{{ msg.sender === 'user' ? '调度总指挥员' : 'PORT-AI 智能决策中枢' }}</span>
              <span>· {{ msg.timestamp }}</span>
            </div>

            <div
              [class.bg-cyan-600]="msg.sender === 'user'"
              [class.text-white]="msg.sender === 'user'"
              [class.bg-slate-900]="msg.sender === 'assistant'"
              [class.text-slate-200]="msg.sender === 'assistant'"
              [class.border-cyan-500/30]="msg.sender === 'assistant'"
              class="max-w-[92%] p-3 rounded-2xl border border-white/5 shadow-lg whitespace-pre-wrap leading-relaxed"
            >
              {{ msg.content }}
            </div>
          </div>
        }

        @if (gemini.isThinking()) {
          <div class="flex items-center gap-2 p-3 rounded-2xl bg-slate-900/60 border border-cyan-500/20 text-cyan-400 text-xs w-fit">
            <span class="w-2 h-2 rounded-full bg-cyan-400 animate-ping"></span>
            <span>正在分析全港时空数字孪生数据流与运筹学排产模型...</span>
          </div>
        }
      </div>

      <!-- Quick Prompt Suggestion Pills -->
      <div class="px-4 py-2 border-t border-white/5 bg-slate-900/40 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
        @for (p of promptSuggestions; track p) {
          <button
            (click)="sendQuickPrompt(p)"
            class="px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-cyan-600/30 hover:text-cyan-300 text-[11px] text-slate-300 border border-white/5 shrink-0 transition-all"
          >
            {{ p }}
          </button>
        }
      </div>

      <!-- Input Bar -->
      <div class="p-3 border-t border-white/10 bg-slate-900/90">
        <form (submit)="sendMessage($event)" class="flex items-center gap-2">
          <input
            type="text"
            [value]="userInput()"
            (input)="onInputChange($event)"
            placeholder="询问全港船舶、泊位、堆场、设备状态或生成调度方案..."
            class="flex-1 bg-slate-950 border border-slate-700 focus:border-cyan-400 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none"
          />
          <button
            type="submit"
            [disabled]="!userInput().trim() || gemini.isThinking()"
            class="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-semibold text-xs transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-md shadow-cyan-600/30 shrink-0"
          >
            发送
          </button>
        </form>

        <div class="mt-2 flex items-center justify-between text-[10px] text-slate-500">
          <span>🔒 IT/OT 安全隔离防护已启用</span>
          <span>执行调度动作需值班总调度员人工确认授权</span>
        </div>
      </div>
    </div>
  `
})
export class AICopilotDrawer {
  readonly gemini = inject(GeminiPortService);
  readonly portData = inject(PortDataService);

  readonly userInput = signal<string>('');

  readonly promptSuggestions = [
    '目前有哪些船舶正在等待靠泊？',
    '哪个泊位最繁忙？',
    '分析堆场拥堵原因并提出AGV与场桥优化方案',
    '岸桥 QC-03 故障隐患诊断与预测性维护建议',
    '海铁联运班列编组发运情况'
  ];

  close() {
    this.portData.activeModule.set('control-tower');
  }

  onInputChange(event: Event) {
    this.userInput.set((event.target as HTMLInputElement).value);
  }

  sendMessage(e?: Event) {
    if (e) e.preventDefault();
    const text = this.userInput().trim();
    if (!text || this.gemini.isThinking()) return;

    this.userInput.set('');
    const context = {
      kpis: this.portData.kpis(),
      weather: this.portData.weather(),
      berths: this.portData.berths(),
      ships: this.portData.ships(),
      yardBlocks: this.portData.yardBlocks(),
      cranes: this.portData.quayCranes()
    };

    this.gemini.askCopilot(text, context);
  }

  sendQuickPrompt(prompt: string) {
    this.userInput.set(prompt);
    this.sendMessage();
  }
}
