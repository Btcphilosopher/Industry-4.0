import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PortDataService } from '../../services/port-data.service';

@Component({
  selector: 'app-port-header',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule],
  template: `
    <header class="h-16 w-full border-b border-white/10 bg-slate-950/90 backdrop-blur-md px-4 flex items-center justify-between select-none z-30 relative">
      <!-- Left: Logo & System Brand -->
      <div class="flex items-center gap-3">
        <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-700 flex items-center justify-center shadow-lg shadow-cyan-500/20 ring-1 ring-cyan-400/40">
          <svg class="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
          </svg>
        </div>
        <div>
          <div class="flex items-center gap-2">
            <span class="font-display font-bold text-lg tracking-wider text-white bg-gradient-to-r from-cyan-400 via-sky-200 to-white bg-clip-text text-transparent">
              PORT OS CHINA
            </span>
            <span class="px-1.5 py-0.5 rounded text-[10px] font-mono font-semibold bg-cyan-950 text-cyan-400 border border-cyan-700/50">
              v3.7 孪生内核
            </span>
          </div>
          <p class="text-[11px] text-slate-400 font-sans tracking-wide">
            中国智慧港口三维数字孪生操作系统 · 上海型综合港区
          </p>
        </div>
      </div>

      <!-- Center: Key Operational Status Marquee -->
      <div class="hidden lg:flex items-center gap-6 px-4 py-1.5 rounded-xl bg-slate-900/80 border border-white/5 font-mono-num text-xs">
        <div class="flex items-center gap-2">
          <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span class="text-slate-400">今日吞吐:</span>
          <span class="text-white font-bold text-sm">{{ portData.kpis().todayTotalTeu }}</span>
          <span class="text-slate-400 text-[10px]">/ {{ portData.kpis().targetDailyTeu }} TEU</span>
        </div>
        <div class="h-3 w-px bg-slate-800"></div>
        <div class="flex items-center gap-2">
          <span class="text-slate-400">在港/待泊船舶:</span>
          <span class="text-cyan-400 font-bold">{{ portData.kpis().vesselsInPort }}</span>
          <span class="text-slate-400">/</span>
          <span class="text-amber-400 font-bold">{{ portData.kpis().vesselsWaitingBerth }} 艘</span>
        </div>
        <div class="h-3 w-px bg-slate-800"></div>
        <div class="flex items-center gap-2">
          <span class="text-slate-400">岸桥在线率:</span>
          <span class="text-emerald-400 font-bold">{{ portData.kpis().quayCranesOnline }}/{{ portData.kpis().quayCranesTotal }} (100%)</span>
        </div>
        <div class="h-3 w-px bg-slate-800"></div>
        <div class="flex items-center gap-2">
          <span class="text-slate-400">AGV机队:</span>
          <span class="text-sky-400 font-bold">{{ portData.kpis().agvOnlineCount }} 台在线</span>
        </div>
        <div class="h-3 w-px bg-slate-800"></div>
        <div class="flex items-center gap-2">
          <span class="text-slate-400">海铁联运:</span>
          <span class="text-purple-400 font-bold">{{ portData.kpis().railTeuVolume }} TEU</span>
        </div>
      </div>

      <!-- Right: Weather HUD & Time & Emergency Status -->
      <div class="flex items-center gap-3">
        <!-- Weather Widget -->
        <div class="hidden md:flex items-center gap-3 px-3 py-1 rounded-lg bg-slate-900/90 border border-slate-800 text-xs">
          <div class="flex items-center gap-1.5 text-cyan-300">
            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
            </svg>
            <span>{{ portData.weather().windSpeedKnots }} kt ({{ portData.weather().windBeaufortScale }}级)</span>
          </div>
          <div class="h-3 w-px bg-slate-800"></div>
          <div class="flex items-center gap-1.5 text-sky-300">
            <span class="text-[10px] text-slate-400">潮位:</span>
            <span>+{{ portData.weather().tideLevelMeters }}m</span>
          </div>
        </div>

        <!-- Alert badge if active -->
        @if (portData.kpis().activeAlertsCount > 0) {
          <button
            (click)="portData.activeModule.set('safety')"
            class="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-rose-950/80 border border-rose-500/50 text-rose-300 text-xs font-semibold hover:bg-rose-900/60 transition-colors animate-pulse"
          >
            <span class="w-2 h-2 rounded-full bg-rose-500"></span>
            <span>{{ portData.kpis().activeAlertsCount }} 条预警</span>
          </button>
        }

        <!-- Digital Clock -->
        <div class="text-right font-mono-num">
          <div class="text-sm font-bold text-white tracking-wider">
            {{ formatTime(portData.timeMachine().currentSimulatedTime) }}
          </div>
          <div class="text-[10px] text-cyan-400">
            北斗高精度时空基准 (BDS)
          </div>
        </div>
      </div>
    </header>

    <!-- Sub-Navbar: Operational Domain Switcher -->
    <nav class="h-10 w-full bg-slate-900/95 border-b border-white/5 px-4 flex items-center justify-between overflow-x-auto no-scrollbar z-20 relative">
      <div class="flex items-center gap-1 min-w-max">
        @for (item of navItems; track item.id) {
          <button
            (click)="selectModule(item.id)"
            [class.bg-cyan-500/15]="portData.activeModule() === item.id"
            [class.text-cyan-400]="portData.activeModule() === item.id"
            [class.border-cyan-500/40]="portData.activeModule() === item.id"
            [class.text-slate-400]="portData.activeModule() !== item.id"
            [class.border-transparent]="portData.activeModule() !== item.id"
            class="px-3 py-1 rounded-md text-xs font-medium border hover:text-slate-100 hover:bg-white/5 transition-all flex items-center gap-1.5"
          >
            <span>{{ item.icon }}</span>
            <span>{{ item.label }}</span>
          </button>
        }
      </div>

      <!-- Quick AI Trigger -->
      <button
        (click)="portData.activeModule.set('ai-advisor')"
        class="flex items-center gap-1.5 px-3 py-1 rounded-md bg-gradient-to-r from-cyan-600 to-blue-600 text-white text-xs font-semibold shadow-sm hover:from-cyan-500 hover:to-blue-500 transition-all ml-4 shrink-0"
      >
        <span class="text-sm">✨</span>
        <span>AI 智能调度副驾</span>
      </button>
    </nav>
  `
})
export class PortHeader {
  readonly portData = inject(PortDataService);

  readonly navItems = [
    { id: 'control-tower', label: '总控驾驶舱', icon: '🗼' },
    { id: 'berths', label: '泊位与船舶', icon: '⚓' },
    { id: 'yard', label: '岸桥与堆场', icon: '🏗️' },
    { id: 'agv', label: 'AGV无人车队', icon: '🤖' },
    { id: 'rail', label: '海铁联运', icon: '🚆' },
    { id: 'bulk', label: '散货码头', icon: '⛰️' },
    { id: 'oilgas', label: '油气管网', icon: '🛢️' },
    { id: 'energy', label: '绿色能源与碳', icon: '⚡' },
    { id: 'safety', label: '安全与应急', icon: '🛡️' },
    { id: 'maintenance', label: '预测性维护', icon: '🔧' },
    { id: 'analytics', label: '经营分析', icon: '📈' }
  ];

  selectModule(moduleId: string) {
    this.portData.activeModule.set(moduleId);
  }

  formatTime(date: Date): string {
    return date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  }
}
