import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PortDataService } from '../../services/port-data.service';
import { Port3DEngineService } from '../../services/port-3d-engine.service';
import { YardBlockTwin, QuayCraneTwin } from '../../types/port.types';

@Component({
  selector: 'app-yard-container-panel',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule],
  template: `
    <div class="h-full w-full bg-slate-950/95 backdrop-blur-xl border-l border-white/10 flex flex-col text-slate-200 overflow-hidden font-sans">
      <!-- Header -->
      <div class="p-4 border-b border-white/10 flex items-center justify-between">
        <div class="flex items-center gap-2">
          <span class="text-xl">🏗️</span>
          <div>
            <h2 class="text-sm font-bold text-white">自动化堆场与集装箱全生命周期</h2>
            <p class="text-[11px] text-slate-400">场桥 RTG 智能调度 · 箱位数字孪生 · 全程可视化溯源</p>
          </div>
        </div>
        <button
          type="button"
          (click)="close()"
          class="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/5"
        >
          ✕
        </button>
      </div>

      <div class="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
        <!-- 1. Container Fast Search by Box Number -->
        <div class="bg-slate-900/80 border border-cyan-500/30 rounded-xl p-3 shadow-lg">
          <label for="container-search-input" class="text-xs font-bold text-cyan-300 block mb-1">
            🔍 全港集装箱单体溯源检索 (输入箱号)
          </label>
          <div class="flex items-center gap-2">
            <input
              id="container-search-input"
              type="text"
              [value]="searchKeyword()"
              (input)="onSearchInput($event)"
              placeholder="例如: COSU0098421, MSCU7890201..."
              class="flex-1 bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-mono"
            />
            <button
              type="button"
              (click)="searchContainer()"
              class="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold"
            >
              三维定位
            </button>
          </div>
        </div>

        <!-- 2. Selected Container 3D Lifecycle Journey Modal/Card -->
        @if (portData.selectedContainer(); as c) {
          <div class="bg-gradient-to-br from-slate-900 to-cyan-950/40 border border-cyan-400/50 rounded-2xl p-4 shadow-xl text-xs space-y-3 animate-in fade-in">
            <div class="flex items-start justify-between">
              <div>
                <span class="px-2 py-0.5 rounded font-mono text-[11px] font-bold bg-cyan-900 text-cyan-200 border border-cyan-600">
                  {{ c.containerNo }}
                </span>
                <span class="ml-2 text-xs text-white font-semibold">{{ c.size }} ({{ c.type }})</span>
              </div>
              <button
                type="button"
                (click)="portData.selectedContainer.set(null)"
                class="text-slate-400 hover:text-white text-xs"
              >
                关闭
              </button>
            </div>

            <!-- Position & Logistics Meta -->
            <div class="grid grid-cols-2 gap-2 bg-slate-950/60 p-2.5 rounded-xl border border-white/5 font-mono-num">
              <div><span class="text-slate-400">当前箱位:</span> <span class="text-cyan-300 font-bold">{{ c.currentLocation }}</span></div>
              <div><span class="text-slate-400">总重:</span> <span class="text-white">{{ c.grossWeightTon }} 吨</span></div>
              <div><span class="text-slate-400">来源船只:</span> <span class="text-white">{{ c.shipName || '中远海运双鱼座' }}</span></div>
              <div><span class="text-slate-400">货主/船东:</span> <span class="text-emerald-400 font-bold">{{ c.carrier }}</span></div>
              <div class="col-span-2"><span class="text-slate-400">目的港口:</span> <span class="text-white">{{ c.destinationPort }}</span></div>
            </div>

            <!-- 3D Lifecycle Track History (TOS / GIS Journey) -->
            <div>
              <div class="text-[11px] font-bold text-slate-300 mb-1.5 flex items-center justify-between">
                <span>📍 全流程数字孪生作业轨迹回放</span>
                <span class="text-[10px] text-cyan-400">已记录 {{ c.journeyLogs.length }} 个节点</span>
              </div>
              <div class="space-y-1.5 relative pl-4 border-l-2 border-cyan-600/40 font-mono-num text-[11px]">
                @for (step of c.journeyLogs; track step.timestamp) {
                  <div class="relative">
                    <div class="absolute -left-[21px] top-1 w-2 h-2 rounded-full bg-cyan-400 ring-2 ring-slate-950"></div>
                    <div class="flex items-center justify-between">
                      <span class="font-bold text-slate-200">{{ step.step }}</span>
                      <span class="text-[10px] text-slate-400">{{ step.timestamp }}</span>
                    </div>
                    <div class="text-[10px] text-slate-400 font-sans">{{ step.facility }} · 经手设备: {{ step.deviceUsed }}</div>
                  </div>
                }
              </div>
            </div>
          </div>
        }

        <!-- 3. Yard Blocks Overview (A01 - A08) -->
        <div>
          <div class="flex items-center justify-between mb-2">
            <h3 class="text-xs font-bold text-cyan-400 uppercase tracking-wider">全自动化堆区利用率热力矩阵</h3>
            <span class="text-[10px] text-slate-400">全港平均堆存率: 71.4%</span>
          </div>

          <div class="grid grid-cols-2 gap-2">
            @for (blk of portData.yardBlocks(); track blk.id) {
              <button
                type="button"
                (click)="focusYardBlock(blk)"
                class="bg-slate-900/80 hover:bg-slate-800 border border-white/5 hover:border-cyan-500/40 p-2.5 rounded-xl cursor-pointer transition-all text-left w-full"
              >
                <div class="flex items-center justify-between mb-1">
                  <span class="font-bold text-xs text-white">{{ blk.blockCode }} 区</span>
                  <span class="text-[10px] text-slate-400">{{ blk.blockCategory }}</span>
                </div>

                <!-- Capacity Progress Bar -->
                <div class="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden my-1.5">
                  <div
                    [style.width.%]="(blk.currentTeu / blk.capacityTeu) * 100"
                    [class.bg-emerald-500]="(blk.currentTeu / blk.capacityTeu) < 0.75"
                    [class.bg-amber-500]="(blk.currentTeu / blk.capacityTeu) >= 0.75 && (blk.currentTeu / blk.capacityTeu) < 0.9"
                    [class.bg-rose-500]="(blk.currentTeu / blk.capacityTeu) >= 0.9"
                    class="h-full rounded-full transition-all"
                  ></div>
                </div>

                <div class="flex items-center justify-between text-[10px] font-mono-num text-slate-400">
                  <span>{{ blk.currentTeu }} / {{ blk.capacityTeu }} TEU</span>
                  <span class="font-bold text-slate-200">{{ ((blk.currentTeu / blk.capacityTeu) * 100).toFixed(0) }}%</span>
                </div>
              </button>
            }
          </div>
        </div>

        <!-- 4. Quay Cranes Real-time Status -->
        <div>
          <div class="flex items-center justify-between mb-2">
            <h3 class="text-xs font-bold text-cyan-400 uppercase tracking-wider">岸边集装箱起重机 (QC) 效率看板</h3>
            <span class="text-[10px] text-slate-400">平均台效: 31.8 箱/h</span>
          </div>

          <div class="space-y-1.5 font-mono-num text-xs">
            @for (qc of portData.quayCranes(); track qc.id) {
              <button
                type="button"
                (click)="focusCrane(qc)"
                class="bg-slate-900/70 hover:bg-slate-800 p-2 rounded-lg border border-white/5 flex items-center justify-between cursor-pointer text-left w-full"
              >
                <div class="flex items-center gap-2">
                  <span class="font-bold text-white">{{ qc.craneNo }}</span>
                  <span class="text-slate-400 text-[11px] font-sans">({{ qc.currentTask }})</span>
                </div>
                <div class="flex items-center gap-3">
                  <span class="text-emerald-400 font-bold">{{ qc.movesPerHour }} moves/h</span>
                  <span class="text-[10px] text-slate-400">健康度: {{ qc.healthScore }}%</span>
                  <span
                    [class.bg-emerald-500]="qc.healthScore >= 90"
                    [class.bg-amber-500]="qc.healthScore < 90"
                    class="w-2 h-2 rounded-full"
                  ></span>
                </div>
              </button>
            }
          </div>
        </div>
      </div>
    </div>
  `
})
export class YardContainerPanel {
  readonly portData = inject(PortDataService);
  readonly engine = inject(Port3DEngineService);

  readonly searchKeyword = signal<string>('COSU0098421');

  close() {
    this.portData.activeModule.set('control-tower');
  }

  onSearchInput(event: Event) {
    this.searchKeyword.set((event.target as HTMLInputElement).value);
  }

  searchContainer() {
    this.portData.selectContainerByNo(this.searchKeyword().trim());
    this.engine.applyCameraPreset('YARD');
  }

  focusYardBlock(blk: YardBlockTwin) {
    this.portData.selectObject(blk);
    this.engine.applyCameraPreset('YARD');
  }

  focusCrane(qc: QuayCraneTwin) {
    this.portData.selectObject(qc);
    this.engine.applyCameraPreset('CRANE_CABIN');
  }
}
