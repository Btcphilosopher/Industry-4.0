import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PortDataService } from '../../services/port-data.service';
import { Port3DEngineService } from '../../services/port-3d-engine.service';
import { PortAlert } from '../../types/port.types';

@Component({
  selector: 'app-safety-emergency-panel',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule],
  template: `
    <div class="h-full w-full bg-slate-950/95 backdrop-blur-xl border-l border-white/10 flex flex-col text-slate-200 overflow-hidden font-sans">
      <!-- Header -->
      <div class="p-4 border-b border-white/10 flex items-center justify-between">
        <div class="flex items-center gap-2">
          <span class="text-xl">🛡️</span>
          <div>
            <h2 class="text-sm font-bold text-white">智慧港口安防、应急演练与防台防汛</h2>
            <p class="text-[11px] text-slate-400">电子围栏 · 危险源态势推演 · 应急预案一键激活联动</p>
          </div>
        </div>
        <button
          type="button"
          (click)="close()"
          class="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/5"
        >
          ✕
        </button>
      </div>

      <div class="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
        <!-- 1. Real-time Security & Operational Alerts -->
        <div>
          <div class="flex items-center justify-between mb-2">
            <h3 class="text-xs font-bold text-rose-400 uppercase tracking-wider">实时安防与告警事件流</h3>
            <span class="text-[10px] text-slate-400">当前告警: {{ portData.alerts().length }} 起</span>
          </div>

          <div class="space-y-2">
            @for (alert of portData.alerts(); track alert.id) {
              <div
                class="bg-slate-900/90 border border-amber-500/40 p-3 rounded-xl space-y-1.5 animate-pulse"
              >
                <div class="flex items-center justify-between">
                  <div class="flex items-center gap-1.5">
                    <span class="px-1.5 py-0.2 rounded text-[10px] font-bold bg-amber-950 text-amber-300 border border-amber-800">
                      {{ alert.level === 'warning' ? '预警' : '紧急' }}
                    </span>
                    <span class="text-xs font-bold text-white">{{ alert.sourceObjectName }}</span>
                  </div>
                  <span class="text-[10px] text-slate-400 font-mono-num">{{ alert.time }}</span>
                </div>
                <p class="text-[11px] text-slate-300 leading-relaxed">{{ alert.message }}</p>
                <div class="pt-1 flex items-center justify-between text-[10px] text-slate-400">
                  <span>处置预案: {{ alert.actionTaken || '由总指挥下达紧急阻断指令' }}</span>
                  <button
                    type="button"
                    (click)="focusAlertTarget(alert)"
                    class="text-cyan-400 hover:underline font-semibold"
                  >
                    三维定位 →
                  </button>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- 2. One-Click Emergency Drill Scenarios -->
        <div class="bg-slate-900/80 border border-white/5 rounded-xl p-3 space-y-3">
          <div class="flex items-center justify-between">
            <h4 class="text-xs font-bold text-white flex items-center gap-1.5">
              <span>🚨</span> 数字化应急推演实战模拟预案
            </h4>
            <span class="text-[10px] text-cyan-400">三维沙盘联动</span>
          </div>

          <div class="space-y-2">
            <!-- Scenario 1: DG Leakage Drill -->
            <div class="bg-slate-950/70 p-2.5 rounded-xl border border-white/5 space-y-1.5">
              <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-rose-300">预案 1: A06危险品集装箱泄漏应急</span>
                <button
                  type="button"
                  (click)="startDrill('dg')"
                  class="px-2 py-0.8 rounded bg-rose-600 hover:bg-rose-500 text-white text-[11px] font-bold transition-all shadow-md shadow-rose-600/30"
                >
                  启动推演
                </button>
              </div>
              <p class="text-[10px] text-slate-400">
                触发 300 米防爆隔离圈，联动 AGV 自动规避，开启消防水幕与中和喷淋。
              </p>
            </div>

            <!-- Scenario 2: Severe Typhoon/Gust Storm Drill -->
            <div class="bg-slate-950/70 p-2.5 rounded-xl border border-white/5 space-y-1.5">
              <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-amber-300">预案 2: 突发强阵风岸桥防风系缆</span>
                <button
                  type="button"
                  (click)="startDrill('wind')"
                  class="px-2 py-0.8 rounded bg-amber-600 hover:bg-amber-500 text-white text-[11px] font-bold transition-all shadow-md shadow-amber-600/30"
                >
                  启动推演
                </button>
              </div>
              <p class="text-[10px] text-slate-400">
                瞬时风速超 20m/s，岸桥起升吊具至安全高位，自动闭锁防爬楔块与地锚系缆。
              </p>
            </div>

            <!-- Scenario 3: Blackout & Shore Power Microgrid Islanding -->
            <div class="bg-slate-950/70 p-2.5 rounded-xl border border-white/5 space-y-1.5">
              <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-sky-300">预案 3: 主网失电岸电储能无缝倒闸</span>
                <button
                  type="button"
                  (click)="startDrill('power')"
                  class="px-2 py-0.8 rounded bg-sky-600 hover:bg-sky-500 text-white text-[11px] font-bold transition-all shadow-md shadow-sky-600/30"
                >
                  启动推演
                </button>
              </div>
              <p class="text-[10px] text-slate-400">
                储能电站 20ms 内离网构网切换，保障在泊大型冷藏箱船与总控塔台不间断供电。
              </p>
            </div>
          </div>
        </div>

        <!-- 3. Personnel Safety & Geofencing -->
        <div class="bg-slate-900/70 border border-white/5 rounded-xl p-3 text-xs">
          <div class="flex items-center justify-between mb-2">
            <span class="font-bold text-white flex items-center gap-1">
              <span>🦺</span> 现场人员 UWB 高精定位与防闯入
            </span>
            <span class="text-emerald-400 font-mono-num font-bold">42 人在港作业</span>
          </div>
          <div class="bg-slate-950/60 p-2 rounded-lg text-[11px] text-slate-300">
            自动化堆区实现 <strong>"人机物理隔离"</strong>，未授权人员进入警戒区 0.1秒内触发声光报警并刹停周边 AGV。
          </div>
        </div>
      </div>
    </div>
  `
})
export class SafetyEmergencyPanel {
  readonly portData = inject(PortDataService);
  readonly engine = inject(Port3DEngineService);

  close() {
    this.portData.activeModule.set('control-tower');
  }

  focusAlertTarget(alert: PortAlert) {
    if (alert.sourceObjectId.startsWith('QC')) {
      this.engine.applyCameraPreset('CRANE_CABIN');
    } else {
      this.engine.applyCameraPreset('YARD');
    }
  }

  startDrill(type: string) {
    if (type === 'dg') {
      this.engine.applyCameraPreset('YARD');
    } else if (type === 'wind') {
      this.engine.applyCameraPreset('BERTH');
    } else {
      this.engine.applyCameraPreset('GLOBAL');
    }
  }
}
