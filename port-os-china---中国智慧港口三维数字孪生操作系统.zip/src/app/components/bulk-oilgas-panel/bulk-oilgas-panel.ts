import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PortDataService } from '../../services/port-data.service';
import { Port3DEngineService } from '../../services/port-3d-engine.service';

@Component({
  selector: 'app-bulk-oilgas-panel',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule],
  template: `
    <div class="h-full w-full bg-slate-950/95 backdrop-blur-xl border-l border-white/10 flex flex-col text-slate-200 overflow-hidden font-sans">
      <!-- Header -->
      <div class="p-4 border-b border-white/10 flex items-center justify-between">
        <div class="flex items-center gap-2">
          <span class="text-xl">🛢️</span>
          <div>
            <h2 class="text-sm font-bold text-white">散货码头、油气储运与输送管网</h2>
            <p class="text-[11px] text-slate-400">大宗干散货装卸 · 储罐液位温度安全 · 管网压力流速数字孪生</p>
          </div>
        </div>
        <button
          type="button"
          (click)="close()"
          class="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/5"
        >
          ✕
        </button>
      </div>

      <div class="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
        <!-- 1. Bulk Terminal Overview -->
        <div>
          <h3 class="text-xs font-bold text-amber-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <span>⛰️</span> 散货码头作业区 (铁矿石 / 动力煤 / 粮食)
          </h3>

          <div class="space-y-2">
            @for (b of portData.bulkEquipments(); track b.id) {
              <div class="bg-slate-900/80 p-3 rounded-xl border border-white/5 space-y-2">
                <div class="flex items-center justify-between">
                  <span class="font-bold text-xs text-white">{{ b.name }} ({{ b.machineNo }})</span>
                  <span class="px-2 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 font-mono">
                    {{ b.status === 'working' ? '全速运行中' : '待机' }}
                  </span>
                </div>

                <div class="grid grid-cols-2 gap-2 text-xs font-mono-num bg-slate-950/60 p-2 rounded-lg">
                  <div><span class="text-slate-400">作业能力:</span> <span class="text-amber-400 font-bold">{{ b.flowRateTonsPerHour }} t/h</span></div>
                  <div><span class="text-slate-400">皮带线速度:</span> <span class="text-white">{{ b.beltSpeedMs }} m/s</span></div>
                  <div><span class="text-slate-400">今日累计:</span> <span class="text-white">{{ b.totalTonsProcessedToday }} 吨</span></div>
                  <div><span class="text-slate-400">粉尘浓度:</span> <span class="text-emerald-400 font-bold">{{ b.dustConcentrationMgM3 }} mg/m³</span></div>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- 2. Oil & Gas Storage Tanks -->
        <div>
          <h3 class="text-xs font-bold text-cyan-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <span>🛢️</span> 液体散货与LNG保税储罐区
          </h3>

          <div class="space-y-2">
            @for (tank of portData.oilTanks(); track tank.id) {
              <div class="bg-slate-900/80 p-3 rounded-xl border border-white/5 space-y-2">
                <div class="flex items-center justify-between">
                  <span class="font-bold text-xs text-white">{{ tank.tankNo }} · {{ tank.medium }}</span>
                  <span class="px-1.5 py-0.5 rounded text-[10px] bg-cyan-950 text-cyan-300 border border-cyan-800 font-mono">
                    安全受控
                  </span>
                </div>

                <!-- Level Progress -->
                <div>
                  <div class="flex items-center justify-between text-[10px] text-slate-400 mb-1 font-mono-num">
                    <span>液位高度 ({{ tank.liquidLevelM }}m / {{ tank.maxLevelM }}m)</span>
                    <span class="text-cyan-300 font-bold">{{ ((tank.liquidLevelM / tank.maxLevelM) * 100).toFixed(1) }}%</span>
                  </div>
                  <div class="w-full bg-slate-950 h-2 rounded-full overflow-hidden">
                    <div
                      [style.width.%]="(tank.liquidLevelM / tank.maxLevelM) * 100"
                      class="bg-cyan-500 h-full rounded-full transition-all"
                    ></div>
                  </div>
                </div>

                <div class="grid grid-cols-2 gap-2 text-[11px] font-mono-num text-slate-300">
                  <div>压力: <span class="text-white">{{ tank.pressureKPa }} kPa</span></div>
                  <div>介质温度: <span class="text-white">{{ tank.temperatureC }} °C</span></div>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- 3. Smart Pipelines Dynamic Flow -->
        <div>
          <h3 class="text-xs font-bold text-sky-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <span>🚰</span> 港区长输管网水力仿真
          </h3>

          <div class="space-y-2 font-mono-num text-xs">
            @for (p of portData.pipelines(); track p.id) {
              <div class="bg-slate-900/70 p-2.5 rounded-xl border border-white/5 flex items-center justify-between">
                <div>
                  <div class="font-bold text-white text-xs">{{ p.name }}</div>
                  <div class="text-[10px] text-slate-400 mt-0.5">管径: {{ p.diameterMm }}mm · {{ p.medium }}</div>
                </div>
                <div class="text-right">
                  <div class="text-sky-300 font-bold">{{ p.flowM3PerHour }} m³/h</div>
                  <div class="text-[10px] text-slate-400">压力: {{ p.pressureBar }} Bar</div>
                </div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `
})
export class BulkOilGasPanel {
  readonly portData = inject(PortDataService);
  readonly engine = inject(Port3DEngineService);

  close() {
    this.portData.activeModule.set('control-tower');
  }
}
