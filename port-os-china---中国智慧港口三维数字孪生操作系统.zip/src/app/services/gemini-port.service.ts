import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';

export interface AIChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  content: string;
  timestamp: string;
  isDispatchPlan?: boolean;
  planData?: Record<string, unknown>;
}

@Injectable({
  providedIn: 'root'
})
export class GeminiPortService {
  private http = inject(HttpClient);

  readonly messages = signal<AIChatMessage[]>([
    {
      id: 'init-msg',
      sender: 'assistant',
      content: `您好！我是 **PORT OS CHINA 港口数字孪生智能调度副驾**。
我已接入全港 GIS、BIM、AIS 船舶定位、PLC 工业数采、RTG/AGV 实时车队、海铁联运及能耗监测网络。

您可以随时向我询问：
- **"目前有哪些船舶正在等待靠泊？"**
- **"哪个泊位最繁忙？"**
- **"分析堆场拥堵原因并提出AGV与场桥优化方案"**
- **"岸桥 QC-03 故障隐患诊断与预测性维护建议"**
- **"今天的海铁联运班列编组发运情况怎么样？"**
- **"当前港区能源负荷与碳减排指标评估"**`,
      timestamp: '10:30'
    }
  ]);

  readonly isThinking = signal<boolean>(false);

  async askCopilot(prompt: string, portContext?: Record<string, unknown>): Promise<void> {
    const userMsg: AIChatMessage = {
      id: `u-${Date.now()}`,
      sender: 'user',
      content: prompt,
      timestamp: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
    };

    this.messages.update(msgs => [...msgs, userMsg]);
    this.isThinking.set(true);

    try {
      const res = await firstValueFrom(
        this.http.post<{ success: boolean; reply: string; model?: string }>('/api/gemini/chat', {
          prompt,
          portContext
        })
      );

      const botMsg: AIChatMessage = {
        id: `b-${Date.now()}`,
        sender: 'assistant',
        content: res.reply || '系统未能获取到有效数据分析结果，请稍后再试。',
        timestamp: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
      };
      this.messages.update(msgs => [...msgs, botMsg]);
    } catch (err: unknown) {
      const errDetail = err instanceof Error ? err.message : '网络连接或服务端计算超时';
      const errorMsg: AIChatMessage = {
        id: `err-${Date.now()}`,
        sender: 'assistant',
        content: `⚠️ **AI 调度分析接口请求异常**\n\n原因: ${errDetail}\n已切换至本地运筹学规则库预案响应。`,
        timestamp: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
      };
      this.messages.update(msgs => [...msgs, errorMsg]);
    } finally {
      this.isThinking.set(false);
    }
  }

  async requestDispatchOptimization(
    scenarioType: string,
    currentStatus?: Record<string, unknown>
  ): Promise<{ success: boolean; plan?: Record<string, unknown>; analysis?: string } | null> {
    try {
      const res = await firstValueFrom(
        this.http.post<{ success: boolean; plan?: Record<string, unknown>; analysis?: string }>('/api/ai/dispatch-recommendation', {
          scenarioType,
          currentStatus
        })
      );
      return res;
    } catch (err) {
      console.error('Dispatch optimization request error:', err);
      return null;
    }
  }
}
