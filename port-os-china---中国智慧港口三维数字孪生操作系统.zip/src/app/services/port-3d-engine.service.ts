import { Injectable, inject, NgZone } from '@angular/core';
import * as THREE from 'three';
import { PortDataService } from './port-data.service';
import { ShipTwin, DigitalTwinBase } from '../types/port.types';

@Injectable({
  providedIn: 'root'
})
export class Port3DEngineService {
  private zone = inject(NgZone);
  private portData = inject(PortDataService);

  private containerElement: HTMLElement | null = null;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animationFrameId: number | null = null;

  // Raycaster & Interaction
  private raycaster = new THREE.Raycaster();
  private mouse = new THREE.Vector2();
  private interactiveObjects: THREE.Object3D[] = [];

  // Measurement tool state
  private measurePoints: THREE.Vector3[] = [];
  private measureLine: THREE.Line | null = null;
  private measureMarkers: THREE.Mesh[] = [];

  // Groups for layer control
  private shipGroup = new THREE.Group();
  private craneGroup = new THREE.Group();
  private containerGroup = new THREE.Group();
  private agvGroup = new THREE.Group();
  private yardGroup = new THREE.Group();
  private railGroup = new THREE.Group();
  private bulkGroup = new THREE.Group();
  private oilGasGroup = new THREE.Group();
  private pipelineGroup = new THREE.Group();
  private energyGroup = new THREE.Group();
  private safetyGroup = new THREE.Group();
  private weatherGroup = new THREE.Group();
  private infrastructureGroup = new THREE.Group();

  // Dynamic Animated Meshes
  private agvMeshes = new Map<string, THREE.Group>();
  private qcMeshes = new Map<string, { group: THREE.Group; trolley: THREE.Object3D; spreader: THREE.Object3D }>();
  private pipelineParticles: THREE.Points[] = [];
  private waterMesh: THREE.Mesh | null = null;
  private rainParticles: THREE.Points | null = null;

  // Camera animation state
  private targetCameraPos = new THREE.Vector3(0, 180, 240);
  private targetLookAt = new THREE.Vector3(0, 0, -20);
  private currentLookAt = new THREE.Vector3(0, 0, -20);
  private isTransitioningCamera = false;

  // Manual Orbit / Drag Controls state
  private isDragging = false;
  private previousMousePosition = { x: 0, y: 0 };
  private spherical = { radius: 320, theta: Math.PI / 4, phi: Math.PI / 3.5 };
  private panOffset = new THREE.Vector3(0, 0, 0);

  initialize(container: HTMLElement) {
    this.containerElement = container;
    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    // 1. Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x060d1a);
    this.scene.fog = new THREE.FogExp2(0x0a1426, 0.0012);

    // 2. Camera
    this.camera = new THREE.PerspectiveCamera(45, width / height, 1, 3000);
    this.updateCameraPositionFromSpherical();

    // 3. Renderer
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.1;

    container.innerHTML = '';
    container.appendChild(this.renderer.domElement);

    // 4. Lighting
    this.setupLighting();

    // 5. Scene Hierarchy
    this.scene.add(this.infrastructureGroup);
    this.scene.add(this.shipGroup);
    this.scene.add(this.craneGroup);
    this.scene.add(this.containerGroup);
    this.scene.add(this.agvGroup);
    this.scene.add(this.yardGroup);
    this.scene.add(this.railGroup);
    this.scene.add(this.bulkGroup);
    this.scene.add(this.oilGasGroup);
    this.scene.add(this.pipelineGroup);
    this.scene.add(this.energyGroup);
    this.scene.add(this.safetyGroup);
    this.scene.add(this.weatherGroup);

    // 6. Build procedural 3D port world
    this.buildTerrainAndWater();
    this.buildQuaysAndWharfs();
    this.buildBuildingsAndControlTower();
    this.buildShips();
    this.buildQuayCranes();
    this.buildYardBlocks();
    this.buildRTGCranes();
    this.buildAGVs();
    this.buildRailPort();
    this.buildBulkTerminal();
    this.buildOilAndGasTerminal();
    this.buildPipelines();
    this.buildEnergyFacilities();
    this.buildSafetyPerimeters();
    this.buildRainAndAtmosphere();

    // 7. Attach mouse & touch listeners
    this.attachEventListeners();

    // 8. Start loop outside Angular zone for high FPS
    this.zone.runOutsideAngular(() => {
      this.animate();
    });
  }

  private setupLighting() {
    const ambientLight = new THREE.AmbientLight(0xd0e0ff, 0.7);
    this.scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xfff8e7, 1.4);
    sunLight.position.set(200, 350, 150);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.width = 2048;
    sunLight.shadow.mapSize.height = 2048;
    sunLight.shadow.camera.near = 10;
    sunLight.shadow.camera.far = 1000;
    sunLight.shadow.camera.left = -350;
    sunLight.shadow.camera.right = 350;
    sunLight.shadow.camera.top = 350;
    sunLight.shadow.camera.bottom = -350;
    sunLight.shadow.bias = -0.0005;
    this.scene.add(sunLight);

    // Blue night/ocean rim fill light
    const fillLight = new THREE.DirectionalLight(0x06b6d4, 0.45);
    fillLight.position.set(-200, 100, -200);
    this.scene.add(fillLight);
  }

  private buildTerrainAndWater() {
    // 1. Water Surface
    const waterGeo = new THREE.PlaneGeometry(1600, 1200, 64, 64);
    const waterMat = new THREE.MeshStandardMaterial({
      color: 0x0a3254,
      roughness: 0.15,
      metalness: 0.85,
      flatShading: false
    });
    this.waterMesh = new THREE.Mesh(waterGeo, waterMat);
    this.waterMesh.rotation.x = -Math.PI / 2;
    this.waterMesh.position.set(0, -0.5, -350);
    this.waterMesh.receiveShadow = true;
    this.infrastructureGroup.add(this.waterMesh);

    // 2. Main Port Quay Land (Concrete Apron & Yard Area)
    const landGeo = new THREE.BoxGeometry(900, 10, 500);
    const landMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      roughness: 0.85,
      metalness: 0.15
    });
    const landMesh = new THREE.Mesh(landGeo, landMat);
    landMesh.position.set(0, -5, 150);
    landMesh.receiveShadow = true;
    this.infrastructureGroup.add(landMesh);

    // Grid Floor Overlay
    const grid = new THREE.GridHelper(900, 90, 0x06b6d4, 0x1e3a5f);
    grid.position.set(0, 0.05, 150);
    this.infrastructureGroup.add(grid);

    // 3. Quayside Berth Edge (Yellow & Black striped bollard margin)
    const edgeGeo = new THREE.BoxGeometry(900, 1.2, 8);
    const edgeMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.6 });
    const edgeMesh = new THREE.Mesh(edgeGeo, edgeMat);
    edgeMesh.position.set(0, 0.6, -100);
    this.infrastructureGroup.add(edgeMesh);
  }

  private buildQuaysAndWharfs() {
    // 3 Berths with visual boundaries and bollards
    const berthPositions = [-180, 0, 180];
    const berthNames = ['01', '02', '03'];

    berthPositions.forEach((bx, idx) => {
      // Berth boundary lines
      const lineGeo = new THREE.PlaneGeometry(160, 4);
      const lineMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.7 });
      const lineMesh = new THREE.Mesh(lineGeo, lineMat);
      lineMesh.rotation.x = -Math.PI / 2;
      lineMesh.position.set(bx, 0.1, -98);
      this.infrastructureGroup.add(lineMesh);

      // Bollards along the quay
      for (let b = -70; b <= 70; b += 20) {
        const bollardGeo = new THREE.CylinderGeometry(0.6, 0.8, 1.8, 12);
        const bollardMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.8, roughness: 0.3 });
        const bollard = new THREE.Mesh(bollardGeo, bollardMat);
        bollard.position.set(bx + b, 1.0, -103);
        bollard.castShadow = true;
        this.infrastructureGroup.add(bollard);
      }

      // Shore Power Outlet Box on Berth
      const shorePowerGeo = new THREE.BoxGeometry(4, 3, 3);
      const shorePowerMat = new THREE.MeshStandardMaterial({ color: 0x10b981, roughness: 0.4 });
      const shorePower = new THREE.Mesh(shorePowerGeo, shorePowerMat);
      shorePower.position.set(bx + 40, 1.5, -96);
      shorePower.userData = { id: `BERTH-SP-${berthNames[idx]}`, name: `${berthNames[idx]}号泊位高压岸电接口箱`, type: 'substation' };
      this.energyGroup.add(shorePower);
      this.interactiveObjects.push(shorePower);
    });
  }

  private buildBuildingsAndControlTower() {
    // Port Control Tower (Iconic architectural tower overlooking the port)
    const towerGroup = new THREE.Group();
    towerGroup.position.set(-320, 0, -40);

    // Tower Base
    const baseGeo = new THREE.BoxGeometry(24, 40, 24);
    const baseMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.5 });
    const baseMesh = new THREE.Mesh(baseGeo, baseMat);
    baseMesh.position.y = 20;
    baseMesh.castShadow = true;
    towerGroup.add(baseMesh);

    // Glass Observation Crown
    const crownGeo = new THREE.CylinderGeometry(18, 14, 14, 16);
    const crownMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      roughness: 0.1,
      metalness: 0.9,
      transparent: true,
      opacity: 0.85
    });
    const crownMesh = new THREE.Mesh(crownGeo, crownMat);
    crownMesh.position.y = 47;
    towerGroup.add(crownMesh);

    // Antenna Mast & Pulsing Red Air Safety Beacon
    const mastGeo = new THREE.CylinderGeometry(0.4, 0.8, 25, 8);
    const mastMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.9 });
    const mastMesh = new THREE.Mesh(mastGeo, mastMat);
    mastMesh.position.y = 66;
    towerGroup.add(mastMesh);

    const beaconGeo = new THREE.SphereGeometry(1.2, 16, 16);
    const beaconMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });
    const beaconMesh = new THREE.Mesh(beaconGeo, beaconMat);
    beaconMesh.position.y = 78;
    towerGroup.add(beaconMesh);

    towerGroup.userData = {
      id: 'PORT-CONTROL-TOWER',
      name: 'PORT OS CHINA 智慧港口总控指挥中心大楼',
      type: 'warehouse'
    };
    this.infrastructureGroup.add(towerGroup);
    this.interactiveObjects.push(baseMesh, crownMesh);

    // Logistics Warehouse Buildings
    const whGeo = new THREE.BoxGeometry(70, 16, 45);
    const whMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.7 });
    const whMesh1 = new THREE.Mesh(whGeo, whMat);
    whMesh1.position.set(-260, 8, 220);
    whMesh1.castShadow = true;
    this.infrastructureGroup.add(whMesh1);
  }

  private buildShips() {
    const ships = this.portData.ships();
    ships.forEach(s => {
      const shipGroup = new THREE.Group();
      shipGroup.position.set(s.position.x, s.position.y, s.position.z);
      shipGroup.rotation.y = (s.heading * Math.PI) / 180;

      if (s.shipType === '集装箱船') {
        this.createContainerShipMesh(shipGroup, s);
      } else if (s.shipType === '拖轮') {
        this.createTugboatMesh(shipGroup, s);
      }

      shipGroup.userData = s;
      this.shipGroup.add(shipGroup);
    });
  }

  private createContainerShipMesh(group: THREE.Group, ship: ShipTwin) {
    const l = ship.length * 0.45;
    const w = ship.beam * 0.45;
    const h = 18;

    // Hull (Dark navy/red bottom)
    const hullGeo = new THREE.BoxGeometry(l, h, w);
    const hullMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.6, metalness: 0.4 });
    const hullMesh = new THREE.Mesh(hullGeo, hullMat);
    hullMesh.position.y = h / 2 - 2;
    hullMesh.castShadow = true;
    hullMesh.receiveShadow = true;
    group.add(hullMesh);

    // Bow Bow-wedge
    const bowGeo = new THREE.ConeGeometry(w / 1.4, 25, 4);
    const bowMesh = new THREE.Mesh(bowGeo, hullMat);
    bowMesh.rotation.z = Math.PI / 2;
    bowMesh.rotation.y = Math.PI / 4;
    bowMesh.position.set(l / 2 + 10, h / 2 - 2, 0);
    group.add(bowMesh);

    // Superstructure & Bridge (White)
    const bridgeGeo = new THREE.BoxGeometry(16, 26, w * 0.75);
    const bridgeMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.4 });
    const bridgeMesh = new THREE.Mesh(bridgeGeo, bridgeMat);
    bridgeMesh.position.set(-l / 3.2, h + 10, 0);
    bridgeMesh.castShadow = true;
    group.add(bridgeMesh);

    // Stacked Container Tiers on Deck (Multi-colored realistic blocks)
    const colors = [0x0284c7, 0x059669, 0xd97706, 0xdc2626, 0x475569];
    const bayCount = Math.floor(l / 16);
    for (let bay = 0; bay < bayCount; bay++) {
      if (bay === Math.floor(bayCount / 3.5)) continue; // bridge gap
      const bx = -l / 2 + 20 + bay * 14;
      const stackHeight = 2 + (bay % 3);

      for (let tier = 0; tier < stackHeight; tier++) {
        for (let row = -1; row <= 1; row++) {
          const cGeo = new THREE.BoxGeometry(12, 3.5, 4.5);
          const cColor = colors[(bay + tier + row + 5) % colors.length];
          const cMat = new THREE.MeshStandardMaterial({ color: cColor, roughness: 0.5 });
          const cMesh = new THREE.Mesh(cGeo, cMat);
          cMesh.position.set(bx, h + tier * 3.5 + 1.8, row * 5.2);
          cMesh.castShadow = true;
          group.add(cMesh);
        }
      }
    }

    // Register all meshes for click selection
    hullMesh.userData = ship;
    bridgeMesh.userData = ship;
    this.interactiveObjects.push(hullMesh, bridgeMesh);
  }

  private createTugboatMesh(group: THREE.Group, ship: ShipTwin) {
    const hullGeo = new THREE.BoxGeometry(22, 6, 9);
    const hullMat = new THREE.MeshStandardMaterial({ color: 0xef4444, roughness: 0.5 });
    const hull = new THREE.Mesh(hullGeo, hullMat);
    hull.position.y = 2;
    group.add(hull);

    const cabinGeo = new THREE.BoxGeometry(8, 7, 6);
    const cabinMat = new THREE.MeshStandardMaterial({ color: 0xffffff });
    const cabin = new THREE.Mesh(cabinGeo, cabinMat);
    cabin.position.set(-2, 7, 0);
    group.add(cabin);

    hull.userData = ship;
    this.interactiveObjects.push(hull);
  }

  private buildQuayCranes() {
    const qcs = this.portData.quayCranes();
    qcs.forEach(qc => {
      const qcGroup = new THREE.Group();
      qcGroup.position.set(qc.position.x, qc.position.y, qc.position.z);

      // Crane Base Legs & Portal Frame (Industrial Red / Orange)
      const legGeo = new THREE.BoxGeometry(2.5, 42, 2.5);
      const craneMat = new THREE.MeshStandardMaterial({
        color: qc.status === 'warning' ? 0xf59e0b : 0xe11d48,
        metalness: 0.6,
        roughness: 0.4
      });

      // 4 Portal Legs
      [-9, 9].forEach(lx => {
        [-7, 7].forEach(lz => {
          const leg = new THREE.Mesh(legGeo, craneMat);
          leg.position.set(lx, 21, lz);
          leg.castShadow = true;
          qcGroup.add(leg);
        });
      });

      // Upper Machine Room & Apex
      const apexGeo = new THREE.BoxGeometry(22, 14, 18);
      const apexMesh = new THREE.Mesh(apexGeo, craneMat);
      apexMesh.position.set(0, 48, 0);
      apexMesh.castShadow = true;
      qcGroup.add(apexMesh);

      // Sea-side Outreach Boom & Land-side Backreach
      const boomGeo = new THREE.BoxGeometry(110, 3.5, 3.5);
      const boomMesh = new THREE.Mesh(boomGeo, craneMat);
      boomMesh.position.set(0, 48, -25);
      boomMesh.rotation.y = Math.PI / 2;
      boomMesh.castShadow = true;
      qcGroup.add(boomMesh);

      // Trolley on Boom
      const trolleyGeo = new THREE.BoxGeometry(6, 3, 5);
      const trolleyMat = new THREE.MeshStandardMaterial({ color: 0xfff176, roughness: 0.3 });
      const trolleyMesh = new THREE.Mesh(trolleyGeo, trolleyMat);
      trolleyMesh.position.set(0, 46, -30);
      qcGroup.add(trolleyMesh);

      // Spreader with Hanging Container
      const spreaderGeo = new THREE.BoxGeometry(12, 1.2, 4);
      const spreaderMat = new THREE.MeshStandardMaterial({ color: 0x0284c7 });
      const spreaderMesh = new THREE.Mesh(spreaderGeo, spreaderMat);
      spreaderMesh.position.set(0, 24, -30);
      qcGroup.add(spreaderMesh);

      // Spreader Suspended Container
      const contGeo = new THREE.BoxGeometry(12, 3.8, 4.2);
      const contMat = new THREE.MeshStandardMaterial({ color: 0x059669 });
      const contMesh = new THREE.Mesh(contGeo, contMat);
      contMesh.position.set(0, -2.5, 0);
      spreaderMesh.add(contMesh);

      // Cables
      const cableGeo = new THREE.CylinderGeometry(0.1, 0.1, 22, 6);
      const cableMat = new THREE.MeshBasicMaterial({ color: 0x94a3b8 });
      const cable1 = new THREE.Mesh(cableGeo, cableMat);
      cable1.position.set(-4, 35, -30);
      qcGroup.add(cable1);
      const cable2 = new THREE.Mesh(cableGeo, cableMat);
      cable2.position.set(4, 35, -30);
      qcGroup.add(cable2);

      // Status Beacon Light
      const statusLightGeo = new THREE.SphereGeometry(1.5, 12, 12);
      const statusLightMat = new THREE.MeshBasicMaterial({
        color: qc.status === 'warning' ? 0xf59e0b : 0x10b981
      });
      const statusLight = new THREE.Mesh(statusLightGeo, statusLightMat);
      statusLight.position.set(0, 58, 0);
      qcGroup.add(statusLight);

      apexMesh.userData = qc;
      this.interactiveObjects.push(apexMesh);

      this.qcMeshes.set(qc.id, {
        group: qcGroup,
        trolley: trolleyMesh,
        spreader: spreaderMesh
      });
      this.craneGroup.add(qcGroup);
    });
  }

  private buildYardBlocks() {
    const blocks = this.portData.yardBlocks();
    const containers = this.portData.containers();
    const colors = [0x0284c7, 0x059669, 0xf59e0b, 0xdc2626, 0x475569, 0x7c3aed];

    blocks.forEach((blk, bIdx) => {
      const blockGroup = new THREE.Group();
      blockGroup.position.set(blk.position.x, blk.position.y, blk.position.z);

      // Yard Concrete Base Pad with Bay markings
      const padGeo = new THREE.BoxGeometry(110, 0.6, 50);
      const padMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.9 });
      const padMesh = new THREE.Mesh(padGeo, padMat);
      padMesh.position.y = 0.3;
      padMesh.receiveShadow = true;
      blockGroup.add(padMesh);

      // 3D Stacks of Containers inside this block
      const rows = 4;
      const bays = 7;
      for (let bay = 0; bay < bays; bay++) {
        for (let r = 0; r < rows; r++) {
          const height = (bay + r + bIdx) % 4 + 1;
          for (let h = 0; h < height; h++) {
            const cGeo = new THREE.BoxGeometry(13, 3.8, 4.4);
            const colorIdx = (bay * 3 + r * 2 + h + bIdx) % colors.length;
            const cMat = new THREE.MeshStandardMaterial({
              color: blk.blockCategory === '冷藏箱区' ? 0xffffff : blk.blockCategory === '危险品箱区' ? 0xf43f5e : colors[colorIdx],
              roughness: 0.5
            });
            const cMesh = new THREE.Mesh(cGeo, cMat);
            const cx = -45 + bay * 15;
            const cz = -18 + r * 12;
            const cy = 0.6 + h * 3.8 + 1.9;
            cMesh.position.set(cx, cy, cz);
            cMesh.castShadow = true;
            cMesh.receiveShadow = true;

            const matchingContainer = containers[bIdx % containers.length];
            cMesh.userData = matchingContainer;
            blockGroup.add(cMesh);
            this.interactiveObjects.push(cMesh);
          }
        }
      }

      // Block Label Signpost
      padMesh.userData = blk;
      this.interactiveObjects.push(padMesh);
      this.yardGroup.add(blockGroup);
    });
  }

  private buildRTGCranes() {
    const rtgs = this.portData.rtgCranes();
    rtgs.forEach(rtg => {
      const rtgGroup = new THREE.Group();
      rtgGroup.position.set(rtg.position.x, rtg.position.y, rtg.position.z);

      // Portal frame
      const rtgMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, metalness: 0.5, roughness: 0.4 });
      const gantryGeo = new THREE.BoxGeometry(22, 2.5, 54);
      const gantry = new THREE.Mesh(gantryGeo, rtgMat);
      gantry.position.y = 22;
      gantry.castShadow = true;
      rtgGroup.add(gantry);

      // Legs
      [-9, 9].forEach(lx => {
        [-25, 25].forEach(lz => {
          const legGeo = new THREE.BoxGeometry(2, 22, 2);
          const leg = new THREE.Mesh(legGeo, rtgMat);
          leg.position.set(lx, 11, lz);
          leg.castShadow = true;
          rtgGroup.add(leg);

          // Rubber tires / rail bogies
          const wheelGeo = new THREE.CylinderGeometry(1.8, 1.8, 1.6, 12);
          const wheelMat = new THREE.MeshStandardMaterial({ color: 0x111827 });
          const wheel = new THREE.Mesh(wheelGeo, wheelMat);
          wheel.rotation.z = Math.PI / 2;
          wheel.position.set(lx, 1.8, lz);
          rtgGroup.add(wheel);
        });
      });

      // Spreader
      const spreaderGeo = new THREE.BoxGeometry(13, 1, 4.5);
      const spreaderMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b });
      const spreader = new THREE.Mesh(spreaderGeo, spreaderMat);
      spreader.position.set(0, 12, 0);
      rtgGroup.add(spreader);

      gantry.userData = rtg;
      this.interactiveObjects.push(gantry);
      this.craneGroup.add(rtgGroup);
    });
  }

  private buildAGVs() {
    const agvs = this.portData.agvs();
    agvs.forEach(agv => {
      const agvGroup = new THREE.Group();
      agvGroup.position.set(agv.position.x, agv.position.y, agv.position.z);

      // AGV Chassis (High-tech cyan/white)
      const chassisGeo = new THREE.BoxGeometry(14, 1.8, 4.6);
      const chassisMat = new THREE.MeshStandardMaterial({
        color: agv.state === 'charging' ? 0x10b981 : 0x06b6d4,
        metalness: 0.7,
        roughness: 0.3
      });
      const chassis = new THREE.Mesh(chassisGeo, chassisMat);
      chassis.position.y = 0.9;
      chassis.castShadow = true;
      agvGroup.add(chassis);

      // Headlight Beams
      const lightGeo = new THREE.SphereGeometry(0.3, 8, 8);
      const lightMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
      const light1 = new THREE.Mesh(lightGeo, lightMat);
      light1.position.set(7.1, 1.0, 1.5);
      agvGroup.add(light1);
      const light2 = new THREE.Mesh(lightGeo, lightMat);
      light2.position.set(7.1, 1.0, -1.5);
      agvGroup.add(light2);

      // Payload container if loaded
      if (agv.state === 'loaded' || agv.state === 'transporting') {
        const cGeo = new THREE.BoxGeometry(12.5, 3.6, 4.2);
        const cMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.5 });
        const cMesh = new THREE.Mesh(cGeo, cMat);
        cMesh.position.y = 3.6;
        cMesh.castShadow = true;
        agvGroup.add(cMesh);
      }

      chassis.userData = agv;
      this.interactiveObjects.push(chassis);
      this.agvMeshes.set(agv.id, agvGroup);
      this.agvGroup.add(agvGroup);
    });
  }

  private buildRailPort() {
    // Railway tracks
    const railGroup = new THREE.Group();
    const trackZ = 120;

    // Ballast track bed
    const bedGeo = new THREE.BoxGeometry(700, 0.4, 30);
    const bedMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.95 });
    const bed = new THREE.Mesh(bedGeo, bedMat);
    bed.position.set(0, 0.2, trackZ);
    railGroup.add(bed);

    // Steel rails
    [-6, 6].forEach(rz => {
      const railGeo = new THREE.BoxGeometry(700, 0.5, 0.4);
      const railMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.9, roughness: 0.2 });
      const rail = new THREE.Mesh(railGeo, railMat);
      rail.position.set(0, 0.6, trackZ + rz);
      railGroup.add(rail);
    });

    // Freight Train Engine (Dongfeng DF8B / HXD Locomotive style)
    const engineGeo = new THREE.BoxGeometry(32, 7, 5.5);
    const engineMat = new THREE.MeshStandardMaterial({ color: 0x059669, roughness: 0.4 });
    const engine = new THREE.Mesh(engineGeo, engineMat);
    engine.position.set(-180, 4.2, trackZ - 6);
    engine.castShadow = true;
    railGroup.add(engine);

    // Container Flatcars
    for (let f = 0; f < 8; f++) {
      const flatGeo = new THREE.BoxGeometry(22, 1.4, 5.2);
      const flatMat = new THREE.MeshStandardMaterial({ color: 0x1e293b });
      const flat = new THREE.Mesh(flatGeo, flatMat);
      const fx = -145 + f * 24;
      flat.position.set(fx, 1.6, trackZ - 6);
      railGroup.add(flat);

      // Containers loaded on train
      const cGeo = new THREE.BoxGeometry(20, 3.8, 4.6);
      const cMat = new THREE.MeshStandardMaterial({ color: f % 2 === 0 ? 0x0284c7 : 0xd97706 });
      const cMesh = new THREE.Mesh(cGeo, cMat);
      cMesh.position.set(fx, 4.2, trackZ - 6);
      cMesh.castShadow = true;
      railGroup.add(cMesh);

      cMesh.userData = this.portData.trains()[0];
      this.interactiveObjects.push(cMesh);
    }

    engine.userData = this.portData.trains()[0];
    this.interactiveObjects.push(engine);
    this.railGroup.add(railGroup);
  }

  private buildBulkTerminal() {
    const bulkGroup = new THREE.Group();

    // Stacker-Reclaimer machine
    const srGeo = new THREE.BoxGeometry(16, 12, 16);
    const srMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.5 });
    const srBase = new THREE.Mesh(srGeo, srMat);
    srBase.position.set(260, 6, 20);
    srBase.castShadow = true;
    bulkGroup.add(srBase);

    // Revolving boom with bucket wheel
    const boomGeo = new THREE.BoxGeometry(60, 3, 3);
    const boomMesh = new THREE.Mesh(boomGeo, srMat);
    boomMesh.position.set(285, 14, 20);
    bulkGroup.add(boomMesh);

    const wheelGeo = new THREE.CylinderGeometry(5, 5, 2, 16);
    const wheel = new THREE.Mesh(wheelGeo, srMat);
    wheel.rotation.z = Math.PI / 2;
    wheel.position.set(315, 14, 20);
    bulkGroup.add(wheel);

    // Large Bulk Stockpiles (Iron ore & Coal)
    const oreGeo = new THREE.ConeGeometry(35, 14, 16);
    const oreMat = new THREE.MeshStandardMaterial({ color: 0x7c2d12, roughness: 0.95 }); // reddish iron ore
    const orePile = new THREE.Mesh(oreGeo, oreMat);
    orePile.position.set(320, 7, -20);
    bulkGroup.add(orePile);

    const coalGeo = new THREE.ConeGeometry(38, 16, 16);
    const coalMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.95 }); // dark coal
    const coalPile = new THREE.Mesh(coalGeo, coalMat);
    coalPile.position.set(320, 8, 60);
    bulkGroup.add(coalPile);

    // Grain Silo Clusters (4 large vertical cylinders)
    for (let s = 0; s < 4; s++) {
      const siloGeo = new THREE.CylinderGeometry(10, 10, 42, 24);
      const siloMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.4, metalness: 0.3 });
      const silo = new THREE.Mesh(siloGeo, siloMat);
      const sx = 230 + (s % 2) * 24;
      const sz = 160 + Math.floor(s / 2) * 24;
      silo.position.set(sx, 21, sz);
      silo.castShadow = true;
      bulkGroup.add(silo);
    }

    srBase.userData = this.portData.bulkEquipments()[0];
    this.interactiveObjects.push(srBase);
    this.bulkGroup.add(bulkGroup);
  }

  private buildOilAndGasTerminal() {
    const oilGroup = new THREE.Group();

    // TK-101 Large Crude Oil Tank (Cylindrical with floating roof)
    const crudeGeo = new THREE.CylinderGeometry(28, 28, 22, 32);
    const crudeMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.6, roughness: 0.3 });
    const crudeTank = new THREE.Mesh(crudeGeo, crudeMat);
    crudeTank.position.set(-280, 11, 30);
    crudeTank.castShadow = true;
    oilGroup.add(crudeTank);

    // TK-102 LNG Spherical Cryogenic Tank
    const lngGeo = new THREE.SphereGeometry(22, 32, 32);
    const lngMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, metalness: 0.8, roughness: 0.2 });
    const lngTank = new THREE.Mesh(lngGeo, lngMat);
    lngTank.position.set(-330, 24, 70);
    lngTank.castShadow = true;
    oilGroup.add(lngTank);

    // Tank Foundation Pillars
    for (let p = 0; p < 8; p++) {
      const angle = (p / 8) * Math.PI * 2;
      const legGeo = new THREE.CylinderGeometry(1.2, 1.2, 14, 8);
      const leg = new THREE.Mesh(legGeo, crudeMat);
      leg.position.set(-330 + Math.cos(angle) * 18, 7, 70 + Math.sin(angle) * 18);
      oilGroup.add(leg);
    }

    crudeTank.userData = this.portData.oilTanks()[0];
    lngTank.userData = this.portData.oilTanks()[1];
    this.interactiveObjects.push(crudeTank, lngTank);

    this.oilGasGroup.add(oilGroup);
  }

  private buildPipelines() {
    const pipes = this.portData.pipelines();
    pipes.forEach((p, idx) => {
      const pipeGroup = new THREE.Group();
      const points = p.points3D.map(pt => new THREE.Vector3(pt.x, pt.y, pt.z));
      const curve = new THREE.CatmullRomCurve3(points);

      const tubeGeo = new THREE.TubeGeometry(curve, 24, p.diameterMm / 400, 12, false);
      const tubeMat = new THREE.MeshStandardMaterial({
        color: idx === 0 ? 0x0284c7 : 0x06b6d4,
        metalness: 0.85,
        roughness: 0.2
      });
      const tubeMesh = new THREE.Mesh(tubeGeo, tubeMat);
      tubeMesh.castShadow = true;
      pipeGroup.add(tubeMesh);

      // Dynamic Animated Pulse Flow Particles along the pipeline
      const particleCount = 40;
      const pGeo = new THREE.BufferGeometry();
      const pPositions = new Float32Array(particleCount * 3);
      for (let i = 0; i < particleCount; i++) {
        const u = i / particleCount;
        const pt = curve.getPoint(u);
        pPositions[i * 3] = pt.x;
        pPositions[i * 3 + 1] = pt.y + 0.2;
        pPositions[i * 3 + 2] = pt.z;
      }
      pGeo.setAttribute('position', new THREE.BufferAttribute(pPositions, 3));
      const pMat = new THREE.PointsMaterial({ color: 0x38bdf8, size: 2.2, transparent: true, opacity: 0.9 });
      const pPoints = new THREE.Points(pGeo, pMat);
      pipeGroup.add(pPoints);
      this.pipelineParticles.push(pPoints);

      tubeMesh.userData = p;
      this.interactiveObjects.push(tubeMesh);
      this.pipelineGroup.add(pipeGroup);
    });
  }

  private buildEnergyFacilities() {
    // 1. Rooftop Solar PV Panels on Warehouse
    const solarGroup = new THREE.Group();
    for (let r = 0; r < 4; r++) {
      for (let c = 0; c < 6; c++) {
        const panelGeo = new THREE.PlaneGeometry(10, 6);
        const panelMat = new THREE.MeshStandardMaterial({
          color: 0x1e3a8a,
          metalness: 0.9,
          roughness: 0.1
        });
        const panel = new THREE.Mesh(panelGeo, panelMat);
        panel.rotation.x = -Math.PI / 2.3;
        panel.position.set(-280 + c * 11, 17, 210 + r * 7);
        solarGroup.add(panel);
      }
    }

    // 2. Battery Energy Storage System (BESS Containers - Green)
    for (let b = 0; b < 3; b++) {
      const bessGeo = new THREE.BoxGeometry(16, 4.5, 5);
      const bessMat = new THREE.MeshStandardMaterial({ color: 0x10b981, roughness: 0.4 });
      const bess = new THREE.Mesh(bessGeo, bessMat);
      bess.position.set(-200 + b * 18, 2.3, 220);
      bess.castShadow = true;
      solarGroup.add(bess);
    }

    this.energyGroup.add(solarGroup);
  }

  private buildSafetyPerimeters() {
    // Dangerous Goods (A06) Safety Warning Holographic Ring
    const ringGeo = new THREE.CylinderGeometry(45, 45, 12, 32, 1, true);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0xf43f5e,
      transparent: true,
      opacity: 0.25,
      side: THREE.DoubleSide
    });
    const dgZone = new THREE.Mesh(ringGeo, ringMat);
    dgZone.position.set(70, 6, 90);
    this.safetyGroup.add(dgZone);

    // High Voltage Substation Zone
    const subZoneGeo = new THREE.CylinderGeometry(25, 25, 8, 24, 1, true);
    const subZoneMat = new THREE.MeshBasicMaterial({
      color: 0xf59e0b,
      transparent: true,
      opacity: 0.25,
      side: THREE.DoubleSide
    });
    const subZone = new THREE.Mesh(subZoneGeo, subZoneMat);
    subZone.position.set(-200, 4, 220);
    this.safetyGroup.add(subZone);
  }

  private buildRainAndAtmosphere() {
    const rainCount = 1500;
    const rainGeo = new THREE.BufferGeometry();
    const rainPos = new Float32Array(rainCount * 3);

    for (let i = 0; i < rainCount; i++) {
      rainPos[i * 3] = (Math.random() - 0.5) * 800;
      rainPos[i * 3 + 1] = Math.random() * 200;
      rainPos[i * 3 + 2] = (Math.random() - 0.5) * 800;
    }

    rainGeo.setAttribute('position', new THREE.BufferAttribute(rainPos, 3));
    const rainMat = new THREE.PointsMaterial({
      color: 0x93c5fd,
      size: 1.2,
      transparent: true,
      opacity: 0.4
    });
    this.rainParticles = new THREE.Points(rainGeo, rainMat);
    this.weatherGroup.add(this.rainParticles);
  }

  // Animation Loop
  private animate = () => {
    this.animationFrameId = requestAnimationFrame(this.animate);

    const time = Date.now() * 0.001;

    // 1. Water subtle vertex undulating or color shift
    if (this.waterMesh) {
      (this.waterMesh.material as THREE.MeshStandardMaterial).roughness = 0.15 + Math.sin(time * 0.5) * 0.02;
    }

    // 2. Sync AGV 3D positions from PortDataService
    const agvs = this.portData.agvs();
    agvs.forEach(agv => {
      const mesh = this.agvMeshes.get(agv.id);
      if (mesh) {
        mesh.position.x = agv.position.x;
        mesh.position.z = agv.position.z;
      }
    });

    // 3. Quay Cranes animated kinematics
    this.qcMeshes.forEach((qcObj, id) => {
      const osc = Math.sin(time * 0.8 + parseInt(id.slice(-1) || '0'));
      qcObj.trolley.position.z = -25 + osc * 15;
      qcObj.spreader.position.z = -25 + osc * 15;
      qcObj.spreader.position.y = 20 + Math.cos(time * 0.8) * 10;
    });

    // 4. Pipeline flow particles animation
    this.pipelineParticles.forEach(p => {
      const pos = p.geometry.attributes['position'] as THREE.BufferAttribute;
      for (let i = 0; i < pos.count; i++) {
        // subtle jiggle for flow effect
        pos.setY(i, pos.getY(i));
      }
      pos.needsUpdate = true;
    });

    // 5. Rain drop animation
    if (this.rainParticles && this.portData.layers().weatherEffects) {
      const pos = this.rainParticles.geometry.attributes['position'] as THREE.BufferAttribute;
      for (let i = 0; i < pos.count; i++) {
        let y = pos.getY(i) - 2.5;
        if (y < 0) y = 200;
        pos.setY(i, y);
      }
      pos.needsUpdate = true;
    }

    // 6. Camera Smooth Interpolation
    if (this.isTransitioningCamera) {
      this.camera.position.lerp(this.targetCameraPos, 0.06);
      this.currentLookAt.lerp(this.targetLookAt, 0.06);
      this.camera.lookAt(this.currentLookAt);

      if (this.camera.position.distanceTo(this.targetCameraPos) < 1.0) {
        this.isTransitioningCamera = false;
      }
    } else {
      this.camera.lookAt(this.currentLookAt);
    }

    // 7. Layer visibility sync
    const layers = this.portData.layers();
    this.shipGroup.visible = layers.ships;
    this.craneGroup.visible = layers.cranes;
    this.containerGroup.visible = layers.containers;
    this.agvGroup.visible = layers.agvs;
    this.yardGroup.visible = layers.yard;
    this.railGroup.visible = layers.rail;
    this.bulkGroup.visible = layers.bulk;
    this.oilGasGroup.visible = layers.oilGas;
    this.pipelineGroup.visible = layers.pipelines;
    this.energyGroup.visible = layers.energyGrid;
    this.safetyGroup.visible = layers.safetyZones;
    this.weatherGroup.visible = layers.weatherEffects;

    this.renderer.render(this.scene, this.camera);
  };

  private attachEventListeners() {
    if (!this.containerElement) return;

    const el = this.containerElement;

    el.addEventListener('mousedown', (e: MouseEvent) => {
      if (e.button === 0) { // Left click
        this.isDragging = true;
        this.previousMousePosition = { x: e.clientX, y: e.clientY };
      }
    });

    window.addEventListener('mousemove', (e: MouseEvent) => {
      const rect = el.getBoundingClientRect();
      this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      if (this.isDragging) {
        const deltaX = e.clientX - this.previousMousePosition.x;
        const deltaY = e.clientY - this.previousMousePosition.y;

        if (e.shiftKey || e.button === 1) {
          // Pan
          this.panOffset.x -= deltaX * 0.4;
          this.panOffset.z -= deltaY * 0.4;
          this.currentLookAt.x = this.panOffset.x;
          this.currentLookAt.z = this.panOffset.z - 20;
        } else {
          // Orbit
          this.spherical.theta -= deltaX * 0.005;
          this.spherical.phi = Math.max(0.1, Math.min(Math.PI / 2.05, this.spherical.phi - deltaY * 0.005));
        }

        this.updateCameraPositionFromSpherical();
        this.previousMousePosition = { x: e.clientX, y: e.clientY };
      }
    });

    window.addEventListener('mouseup', () => {
      this.isDragging = false;
    });

    el.addEventListener('wheel', (e: WheelEvent) => {
      e.preventDefault();
      this.spherical.radius = Math.max(30, Math.min(900, this.spherical.radius + e.deltaY * 0.25));
      this.updateCameraPositionFromSpherical();
    }, { passive: false });

    // Click to select 3D object / measure
    el.addEventListener('click', (e: MouseEvent) => {
      if (Math.abs(e.clientX - this.previousMousePosition.x) > 5) return; // ignore drags

      this.raycaster.setFromCamera(this.mouse, this.camera);
      const intersects = this.raycaster.intersectObjects(this.interactiveObjects, true);

      if (this.portData.measureMode()) {
        const worldIntersects = this.raycaster.intersectObjects(this.scene.children, true);
        if (worldIntersects.length > 0) {
          this.handleMeasureClick(worldIntersects[0].point);
        }
        return;
      }

      if (intersects.length > 0) {
        let hitObj: THREE.Object3D | null = intersects[0].object;
        while (hitObj && !hitObj.userData['id'] && hitObj.parent && hitObj.parent !== this.scene) {
          hitObj = hitObj.parent;
        }

        if (hitObj && hitObj.userData['id']) {
          const rawData = hitObj.userData as unknown as DigitalTwinBase;
          this.zone.run(() => {
            this.portData.selectObject(rawData);
          });
          this.focusOnObject(intersects[0].point);
        }
      }
    });

    window.addEventListener('resize', this.onWindowResize);
  }

  private handleMeasureClick(point: THREE.Vector3) {
    this.measurePoints.push(point.clone());

    // Add marker
    const markerGeo = new THREE.SphereGeometry(1.2, 12, 12);
    const markerMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
    const marker = new THREE.Mesh(markerGeo, markerMat);
    marker.position.copy(point);
    this.scene.add(marker);
    this.measureMarkers.push(marker);

    if (this.measurePoints.length === 2) {
      const dist = this.measurePoints[0].distanceTo(this.measurePoints[1]);
      this.zone.run(() => {
        this.portData.measureDistanceM.set(parseFloat(dist.toFixed(1)));
      });

      // Draw line
      const lineGeo = new THREE.BufferGeometry().setFromPoints(this.measurePoints);
      const lineMat = new THREE.LineBasicMaterial({ color: 0x38bdf8, linewidth: 2 });
      this.measureLine = new THREE.Line(lineGeo, lineMat);
      this.scene.add(this.measureLine);
    } else if (this.measurePoints.length > 2) {
      // Clear previous
      this.clearMeasurement();
      this.handleMeasureClick(point);
    }
  }

  clearMeasurement() {
    this.measurePoints = [];
    if (this.measureLine) {
      this.scene.remove(this.measureLine);
      this.measureLine = null;
    }
    this.measureMarkers.forEach(m => this.scene.remove(m));
    this.measureMarkers = [];
    this.portData.measureDistanceM.set(null);
  }

  private updateCameraPositionFromSpherical() {
    const x = this.panOffset.x + this.spherical.radius * Math.sin(this.spherical.phi) * Math.sin(this.spherical.theta);
    const y = this.spherical.radius * Math.cos(this.spherical.phi);
    const z = this.panOffset.z + this.spherical.radius * Math.sin(this.spherical.phi) * Math.cos(this.spherical.theta);

    this.camera.position.set(x, y, z);
    this.camera.lookAt(this.currentLookAt);
  }

  focusOnObject(targetWorldPos: THREE.Vector3) {
    this.targetLookAt.copy(targetWorldPos);
    this.targetCameraPos.set(
      targetWorldPos.x + 35,
      targetWorldPos.y + 45,
      targetWorldPos.z + 55
    );
    this.isTransitioningCamera = true;
  }

  applyCameraPreset(presetName: string) {
    switch (presetName) {
      case 'OVERVIEW':
        this.targetCameraPos.set(0, 240, 320);
        this.targetLookAt.set(0, 0, -20);
        break;
      case 'TOWER':
        this.targetCameraPos.set(-320, 65, -40);
        this.targetLookAt.set(0, 10, -50);
        break;
      case 'BERTH':
        this.targetCameraPos.set(-50, 25, -40);
        this.targetLookAt.set(-100, 15, -120);
        break;
      case 'YARD':
        this.targetCameraPos.set(0, 45, 160);
        this.targetLookAt.set(0, 10, 40);
        break;
      case 'SHIP_BRIDGE':
        this.targetCameraPos.set(-180, 38, -125);
        this.targetLookAt.set(100, 10, -125);
        break;
      case 'CRANE_CABIN':
        this.targetCameraPos.set(-30, 52, -95);
        this.targetLookAt.set(-30, 0, -125);
        break;
      case 'RAIL_STATION':
        this.targetCameraPos.set(-50, 40, 180);
        this.targetLookAt.set(-50, 5, 120);
        break;
    }
    this.isTransitioningCamera = true;
  }

  private onWindowResize = () => {
    if (!this.containerElement || !this.renderer || !this.camera) return;
    const w = this.containerElement.clientWidth;
    const h = this.containerElement.clientHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  };

  dispose() {
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
    }
    window.removeEventListener('resize', this.onWindowResize);
    if (this.renderer && this.renderer.domElement && this.renderer.domElement.parentNode) {
      this.renderer.domElement.parentNode.removeChild(this.renderer.domElement);
    }
  }
}
