import { Injectable, OnDestroy, computed, signal } from '@angular/core';
import {
  ShipTwin,
  BerthTwin,
  QuayCraneTwin,
  RTGCraneTwin,
  AGVTwin,
  AutonomousTruckTwin,
  ContainerTwin,
  YardBlockTwin,
  RailTrainTwin,
  BulkTerminalTwin,
  OilGasTankTwin,
  PipelineTwin,
  PortAlert,
  PortEnergyMetrics,
  WeatherTwinData,
  PortKPIs,
  PortLayerVisibility,
  TimeMachineState,
  DigitalTwinBase,
  GateLaneTwin
} from '../types/port.types';

@Injectable({
  providedIn: 'root'
})
export class PortDataService implements OnDestroy {
  // Active selected object in 3D scene
  readonly selectedObject = signal<DigitalTwinBase | ContainerTwin | null>(null);
  readonly selectedContainer = signal<ContainerTwin | null>(null);

  // Active view tab / OS module
  readonly activeModule = signal<string>('control-tower'); // 'control-tower' | 'berths' | 'yard' | 'agv' | 'rail' | 'bulk' | 'oilgas' | 'energy' | 'safety' | 'maintenance' | 'analytics' | 'ai-advisor'

  // Time machine state
  readonly timeMachine = signal<TimeMachineState>({
    currentSimulatedTime: new Date(2026, 8, 20, 10, 30, 0),
    isPlaying: true,
    playbackSpeed: 1,
    timelineRangeStart: new Date(2026, 8, 20, 6, 0, 0),
    timelineRangeEnd: new Date(2026, 8, 20, 22, 0, 0)
  });

  // Layer Visibility
  readonly layers = signal<PortLayerVisibility>({
    ships: true,
    cranes: true,
    containers: true,
    agvs: true,
    trucks: true,
    yard: true,
    rail: true,
    bulk: true,
    oilGas: true,
    pipelines: true,
    energyGrid: true,
    safetyZones: true,
    weatherEffects: true,
    personnel: true,
    radarBuoys: true
  });

  // 3D Measurement Mode
  readonly measureMode = signal<boolean>(false);
  readonly measureDistanceM = signal<number | null>(null);

  // 3D Cross-section / Slice plane
  readonly sliceHeightM = signal<number>(100);

  // Camera preset triggering signal
  readonly cameraPreset = signal<{ name: string; timestamp: number }>({ name: 'OVERVIEW', timestamp: Date.now() });

  // Port Digital Twin Collections
  readonly ships = signal<ShipTwin[]>([]);
  readonly berths = signal<BerthTwin[]>([]);
  readonly quayCranes = signal<QuayCraneTwin[]>([]);
  readonly rtgCranes = signal<RTGCraneTwin[]>([]);
  readonly agvs = signal<AGVTwin[]>([]);
  readonly trucks = signal<AutonomousTruckTwin[]>([]);
  readonly yardBlocks = signal<YardBlockTwin[]>([]);
  readonly containers = signal<ContainerTwin[]>([]);
  readonly trains = signal<RailTrainTwin[]>([]);
  readonly bulkEquipments = signal<BulkTerminalTwin[]>([]);
  readonly oilTanks = signal<OilGasTankTwin[]>([]);
  readonly pipelines = signal<PipelineTwin[]>([]);
  readonly gateLanes = signal<GateLaneTwin[]>([]);
  readonly alerts = signal<PortAlert[]>([]);
  readonly weather = signal<WeatherTwinData>({
    time: '2026-09-20 10:30',
    windSpeedKnots: 11.4,
    windDirectionDeg: 125,
    windGustKnots: 14.8,
    windBeaufortScale: 3,
    tideLevelMeters: 2.85,
    highTideTime: '14:20 (+4.10m)',
    highTideMeters: 4.10,
    lowTideTime: '08:15 (+1.10m)',
    lowTideMeters: 1.10,
    waveHeightM: 0.65,
    visibilityKm: 18.0,
    temperatureC: 24.5,
    humidityPercent: 68,
    precipitationMm: 0.0,
    weatherCondition: '多云',
    craneSafetyLock: false
  });

  readonly energy = signal<PortEnergyMetrics>({
    totalGridPowerKw: 3840,
    todayTotalKWh: 42150,
    peakLoadKw: 4620,
    solarPvGenerationKw: 920,
    bessStorageStateOfCharge: 82.5,
    shorePowerSupplyKw: 1650,
    agvChargingLoadKw: 320,
    craneLoadKw: 1480,
    reeferPlugLoadKw: 470,
    carbonEmissionTodayTons: 28.4,
    carbonSavedShorePowerTons: 14.2,
    carbonPerTeuKg: 7.8
  });

  // Derived Port KPIs
  readonly kpis = computed<PortKPIs>(() => {
    const craneList = this.quayCranes();
    const agvList = this.agvs();
    const shipList = this.ships();
    const berthList = this.berths();
    const alertList = this.alerts();

    const activeBerths = berthList.filter(b => b.currentShipId).length;
    const onlineCranes = craneList.filter(c => c.status === 'working' || c.status === 'idle').length;
    const onlineAgvs = agvList.filter(a => a.state !== 'fault').length;
    const waitingShips = shipList.filter(s => s.status === 'approaching' || s.status === 'anchorage').length;

    return {
      todayTotalTeu: 3620,
      targetDailyTeu: 4500,
      bulkCargoTons: 48500,
      vesselsInPort: shipList.length,
      vesselsWaitingBerth: waitingShips,
      activeBerthsCount: activeBerths,
      totalBerthsCount: berthList.length,
      quayCranesOnline: onlineCranes,
      quayCranesTotal: craneList.length,
      agvOnlineCount: onlineAgvs,
      agvTotalCount: agvList.length,
      yardUtilizationPercent: 78.4,
      railTeuVolume: 420,
      gateVehiclesToday: 1890,
      avgGatePassSeconds: 21.5,
      equipmentOnlineRate: 98.2,
      carbonFootprintTons: 28.4,
      activeAlertsCount: alertList.filter(a => !a.handled).length
    };
  });

  private simulationInterval: ReturnType<typeof setInterval> | null = null;

  constructor() {
    this.seedInitialPortData();
    this.startSimulationEngine();
  }

  toggleLayer(layerKey: keyof PortLayerVisibility) {
    this.layers.update(prev => ({
      ...prev,
      [layerKey]: !prev[layerKey]
    }));
  }

  setCameraPreset(presetName: string) {
    this.cameraPreset.set({ name: presetName, timestamp: Date.now() });
  }

  selectObject(obj: DigitalTwinBase | ContainerTwin | null) {
    this.selectedObject.set(obj);
    if (obj && !('type' in obj) && 'containerNo' in obj) {
      this.selectedContainer.set(obj as ContainerTwin);
    }
  }

  selectContainerByNo(containerNo: string) {
    const found = this.containers().find(c => c.containerNo === containerNo);
    if (found) {
      this.selectedContainer.set(found);
      this.selectedObject.set(found);
    }
  }

  resolveAlert(alertId: string, actionNote: string) {
    this.alerts.update(alerts =>
      alerts.map(a =>
        a.id === alertId
          ? { ...a, handled: true, handler: '调度指挥长 (工号0924)', actionTaken: actionNote }
          : a
      )
    );
  }

  setTimeMachinePlaying(playing: boolean) {
    this.timeMachine.update(tm => ({ ...tm, isPlaying: playing }));
  }

  setTimeMachineSpeed(speed: number) {
    this.timeMachine.update(tm => ({ ...tm, playbackSpeed: speed }));
  }

  seekTime(newTime: Date) {
    this.timeMachine.update(tm => ({ ...tm, currentSimulatedTime: newTime }));
  }

  private seedInitialPortData() {
    // 1. Berths
    const berthsData: BerthTwin[] = [
      {
        id: 'BERTH-01',
        name: '集装箱 1号泊位 (400m / -17.5m)',
        type: 'berth',
        berthNo: '01',
        terminalType: '集装箱码头',
        length: 400,
        waterDepth: 17.5,
        maxVesselDwt: 220000,
        currentShipId: 'SHIP-COSCO-GLORY',
        currentShipName: '远达荣耀 (COSCO GLORY)',
        nextShipName: '中远海运极光 (COSCO AURORA)',
        plannedEta: '18:50',
        plannedEtd: '18:30',
        utilizationRate: 94.2,
        assignedCranes: ['QC-01', 'QC-02'],
        shorePowerCapacityKw: 4000,
        bollardTensionKn: 1500,
        position: { x: -180, y: 0, z: -100 },
        geoPosition: { lng: 121.842, lat: 31.391 },
        status: 'working',
        lastUpdated: '10:30',
        responsibleDept: '集装箱第一操作部',
        healthScore: 98,
        alerts: []
      },
      {
        id: 'BERTH-02',
        name: '集装箱 2号泊位 (380m / -16.0m)',
        type: 'berth',
        berthNo: '02',
        terminalType: '集装箱码头',
        length: 380,
        waterDepth: 16.0,
        maxVesselDwt: 150000,
        currentShipId: 'SHIP-NEW-OCEAN',
        currentShipName: '新海轮 (NEW OCEAN)',
        nextShipName: '地中海米兰 (MSC MILAN)',
        plannedEta: '21:00',
        plannedEtd: '19:40',
        utilizationRate: 88.6,
        assignedCranes: ['QC-03', 'QC-04'],
        shorePowerCapacityKw: 3000,
        bollardTensionKn: 1200,
        position: { x: 0, y: 0, z: -100 },
        geoPosition: { lng: 121.848, lat: 31.393 },
        status: 'working',
        lastUpdated: '10:30',
        responsibleDept: '集装箱第二操作部',
        healthScore: 92,
        alerts: []
      },
      {
        id: 'BERTH-03',
        name: '集装箱 3号泊位 (450m / -18.0m 超深水)',
        type: 'berth',
        berthNo: '03',
        terminalType: '集装箱码头',
        length: 450,
        waterDepth: 18.0,
        maxVesselDwt: 240000,
        currentShipId: 'SHIP-PACIFIC-EXP',
        currentShipName: '太平洋开拓者 (PACIFIC EXPLORER)',
        nextShipName: '东方海外华东 (OOCL EAST)',
        plannedEta: '明日 04:30',
        plannedEtd: '23:15',
        utilizationRate: 96.8,
        assignedCranes: ['QC-05', 'QC-06'],
        shorePowerCapacityKw: 4500,
        bollardTensionKn: 1800,
        position: { x: 180, y: 0, z: -100 },
        geoPosition: { lng: 121.855, lat: 31.395 },
        status: 'working',
        lastUpdated: '10:30',
        responsibleDept: '超大型船舶专线队',
        healthScore: 99,
        alerts: []
      }
    ];

    // 2. Ships
    const shipsData: ShipTwin[] = [
      {
        id: 'SHIP-COSCO-GLORY',
        name: '远达荣耀 (COSCO GLORY)',
        type: 'ship',
        imo: 'IMO 9823412',
        callSign: 'BRS-8831',
        flag: '中国 (China)',
        shipType: '集装箱船',
        length: 366,
        beam: 51.2,
        draft: 14.8,
        maxDraft: 16.0,
        speedKnots: 0.0,
        heading: 90,
        destination: '鹿特丹港 (ROTTERDAM)',
        lastPort: '新加坡港 (SINGAPORE)',
        nextPort: '苏伊士运河港 (PORT SAID)',
        eta: '2026-09-20 06:30',
        etd: '2026-09-20 18:30',
        cargoTeuOrTons: 14200,
        capacityTeu: 18000,
        assignedBerthId: 'BERTH-01',
        berthProgress: 76.5,
        aisStatus: 'Moored / 靠泊系缆作业中',
        shorePowerConnected: true,
        berthingStep: '装卸作业',
        position: { x: -180, y: 0, z: -125 },
        geoPosition: { lng: 121.842, lat: 31.391 },
        status: 'working',
        lastUpdated: '10:30',
        responsibleDept: '中远海运调度中心',
        healthScore: 98,
        alerts: []
      },
      {
        id: 'SHIP-NEW-OCEAN',
        name: '新海轮 (NEW OCEAN)',
        type: 'ship',
        imo: 'IMO 9645129',
        callSign: 'VRKW-4',
        flag: '中国香港 (Hong Kong)',
        shipType: '集装箱船',
        length: 294,
        beam: 38.0,
        draft: 12.6,
        maxDraft: 13.5,
        speedKnots: 0.0,
        heading: 90,
        destination: '釜山港 (BUSAN)',
        lastPort: '深圳盐田港 (YANTIAN)',
        nextPort: '青岛港 (QINGDAO)',
        eta: '2026-09-20 07:15',
        etd: '2026-09-20 19:40',
        cargoTeuOrTons: 6800,
        capacityTeu: 8500,
        assignedBerthId: 'BERTH-02',
        berthProgress: 64.0,
        aisStatus: 'Moored / 靠泊系缆作业中',
        shorePowerConnected: false,
        berthingStep: '装卸作业',
        position: { x: 0, y: 0, z: -125 },
        geoPosition: { lng: 121.848, lat: 31.393 },
        status: 'working',
        lastUpdated: '10:30',
        responsibleDept: '新海航运运营部',
        healthScore: 94,
        alerts: []
      },
      {
        id: 'SHIP-PACIFIC-EXP',
        name: '太平洋开拓者 (PACIFIC EXPLORER)',
        type: 'ship',
        imo: 'IMO 9912048',
        callSign: '9V8812',
        flag: '新加坡 (Singapore)',
        shipType: '集装箱船',
        length: 399.9,
        beam: 61.3,
        draft: 15.6,
        maxDraft: 16.5,
        speedKnots: 0.0,
        heading: 90,
        destination: '洛杉矶长滩 (LONG BEACH)',
        lastPort: '高雄港 (KAOHSIUNG)',
        nextPort: '横滨港 (YOKOHAMA)',
        eta: '2026-09-20 05:00',
        etd: '2026-09-20 23:15',
        cargoTeuOrTons: 21400,
        capacityTeu: 24000,
        assignedBerthId: 'BERTH-03',
        berthProgress: 52.0,
        aisStatus: 'Moored / 靠泊系缆作业中',
        shorePowerConnected: true,
        berthingStep: '装卸作业',
        position: { x: 180, y: 0, z: -125 },
        geoPosition: { lng: 121.855, lat: 31.395 },
        status: 'working',
        lastUpdated: '10:30',
        responsibleDept: '太平洋国际海运',
        healthScore: 99,
        alerts: []
      },
      {
        id: 'SHIP-APPROACHING-AURORA',
        name: '中远海运极光 (COSCO AURORA)',
        type: 'ship',
        imo: 'IMO 9856113',
        callSign: 'BNM-319',
        flag: '中国 (China)',
        shipType: '集装箱船',
        length: 366,
        beam: 51.2,
        draft: 14.2,
        maxDraft: 16.0,
        speedKnots: 8.4,
        heading: 268,
        destination: '上海港 (SHANGHAI)',
        lastPort: '宁波舟山港 (NINGBO)',
        nextPort: '汉堡港 (HAMBURG)',
        eta: '2026-09-20 18:50',
        etd: '2026-09-21 16:00',
        cargoTeuOrTons: 16500,
        capacityTeu: 20000,
        assignedBerthId: 'BERTH-01',
        berthProgress: 0,
        aisStatus: 'Underway Using Engine / 引航进港航行',
        shorePowerConnected: false,
        berthingStep: '引航',
        position: { x: -350, y: 0, z: -280 },
        geoPosition: { lng: 121.825, lat: 31.378 },
        status: 'approaching',
        lastUpdated: '10:30',
        responsibleDept: '引航中心一站',
        healthScore: 100,
        alerts: []
      },
      {
        id: 'SHIP-TUG-01',
        name: '海港拖01 (PORT TUG 01)',
        type: 'ship',
        imo: 'IMO 9553201',
        callSign: 'TUG-01',
        flag: '中国',
        shipType: '拖轮',
        length: 38,
        beam: 11,
        draft: 4.8,
        maxDraft: 5.2,
        speedKnots: 4.2,
        heading: 270,
        destination: '1号泊位护航',
        lastPort: '工作船码头',
        nextPort: '1号泊位',
        eta: '实时',
        etd: '待命',
        cargoTeuOrTons: 0,
        capacityTeu: 0,
        berthProgress: 100,
        aisStatus: 'Engaged in Towing / 伴航拖带作业',
        shorePowerConnected: false,
        position: { x: -240, y: 0, z: -170 },
        geoPosition: { lng: 121.838, lat: 31.385 },
        status: 'working',
        lastUpdated: '10:30',
        responsibleDept: '轮驳分公司',
        healthScore: 97,
        alerts: []
      }
    ];

    // 3. Quay Cranes
    const qcData: QuayCraneTwin[] = [];
    const qcPositions = [-210, -150, -30, 30, 150, 210];
    const qcBerthIds = ['BERTH-01', 'BERTH-01', 'BERTH-02', 'BERTH-02', 'BERTH-03', 'BERTH-03'];

    for (let i = 0; i < 6; i++) {
      const qcNo = `QC-0${i + 1}`;
      const isFault = i === 2; // QC-03 has slight vibration anomaly
      qcData.push({
        id: qcNo,
        name: `双起升双小车岸桥 ${qcNo}`,
        type: 'quay_crane',
        craneNo: qcNo,
        berthId: qcBerthIds[i],
        trolleyPosition: -10 + i * 4,
        hoistHeight: 18 + (i % 3) * 6,
        spreaderLocked: true,
        currentContainerId: `MSCU-789${i}201`,
        currentTask: `卸船作业 (BAY ${14 + i * 4} -> AGV-${(i * 6 + 2).toString().padStart(3, '0')})`,
        movesPerHour: isFault ? 28.4 : 33.6 + (i % 3) * 1.5,
        targetMovesPerHour: 32.0,
        totalWorkingHours: 12450 + i * 820,
        vibrationRms: isFault ? 3.82 : 1.45,
        motorTempC: isFault ? 78.5 : 54.2,
        powerKw: 380 + (i % 2) * 50,
        totalEnergyKWh: 38400 + i * 4200,
        railTrackPos: qcPositions[i],
        position: { x: qcPositions[i], y: 0, z: -95 },
        geoPosition: { lng: 121.840 + i * 0.003, lat: 31.390 + i * 0.001 },
        status: isFault ? 'warning' : 'working',
        lastUpdated: '10:30',
        responsibleDept: '岸桥自动化技术班组',
        healthScore: isFault ? 78 : 96,
        alerts: isFault
          ? [
              {
                id: 'ALT-QC03-VIB',
                time: '10:14:22',
                sourceObjectId: 'QC-03',
                sourceObjectName: '岸桥 QC-03',
                level: 'warning',
                category: 'EQUIPMENT_FAULT',
                message: '主起升减速机输出轴振动RMS均方根值达3.82mm/s，超过正常预警阈值(2.50mm/s)',
                handled: false,
                location: { x: -30, y: 35, z: -95 }
              }
            ]
          : []
      });
    }

    // 4. Yard Blocks & Containers
    const yardBlocksData: YardBlockTwin[] = [];
    const containersData: ContainerTwin[] = [];
    const blockNames = ['A01 (进口重箱)', 'A02 (进口重箱)', 'A03 (冷藏箱区)', 'A04 (出口重箱)', 'A05 (出口重箱)', 'A06 (危险品专区)', 'A07 (海铁联运中转)', 'A08 (空箱堆区)'];
    const categories: YardBlockTwin['blockCategory'][] = [
      '进口重箱',
      '进口重箱',
      '冷藏箱区',
      '出口重箱',
      '出口重箱',
      '危险品箱区',
      '海铁联运中转区',
      '空箱堆区'
    ];

    for (let b = 0; b < 8; b++) {
      const code = `A0${b + 1}`;
      const x = -210 + (b % 4) * 140;
      const z = (Math.floor(b / 4) * 80) + 10;
      const occ = b === 2 ? 87.5 : b === 5 ? 64.0 : 74.0 + (b % 3) * 5;

      yardBlocksData.push({
        id: `YARD-${code}`,
        name: `堆场 ${blockNames[b]}`,
        type: 'yard_block',
        blockCode: code,
        blockCategory: categories[b],
        baysCount: 24,
        rowsCount: 6,
        tiersMax: 5,
        capacityTeu: 1440,
        currentTeu: Math.round(1440 * (occ / 100)),
        occupancyPercent: occ,
        assignedRTGs: [`RTG-0${b + 1}`, `RTG-${(b + 9).toString().padStart(2, '0')}`],
        position: { x, y: 0, z },
        geoPosition: { lng: 121.840 + (b % 4) * 0.004, lat: 31.396 + Math.floor(b / 4) * 0.003 },
        status: occ > 85 ? 'warning' : 'working',
        lastUpdated: '10:30',
        responsibleDept: '自动化堆场集控部',
        healthScore: 95,
        alerts: []
      });

      // Sample representative containers in this block
      for (let c = 0; c < 4; c++) {
        const cNo = `COSU${b}${c}98421`;
        const isReefer = b === 2;
        const isDg = b === 5;
        containersData.push({
          id: cNo,
          containerNo: cNo,
          size: isReefer ? 'REEFER_40' : isDg ? 'HAZ_40' : '40HQ',
          grossWeightTon: 24.5 + c * 2.1,
          type: isReefer ? '冷藏箱 (Reefer)' : isDg ? '危险品箱 (DG Class 3)' : '普通干箱',
          cargoOwner: isReefer ? '上海生鲜冷链进出口集团' : isDg ? '华东精细化工股份公司' : '中远海运集运 (COSCO SHIPPING)',
          carrier: 'COSCO SHIPPING LINES',
          shipName: '远达荣耀 (COSCO GLORY)',
          originPort: '新加坡 (SINGAPORE)',
          destinationPort: '上海港 (SHANGHAI)',
          currentLocation: `YARD-${code}-BAY${(c * 6 + 2).toString().padStart(2, '0')}-ROW03-TIER02`,
          temperatureTargetC: isReefer ? -18.0 : undefined,
          temperatureActualC: isReefer ? -17.8 : undefined,
          reeferPowerPlugged: isReefer ? true : undefined,
          hazardClass: isDg ? 'IMDG Class 3 (易燃液体)' : undefined,
          position: { x: x + c * 8 - 12, y: 4, z: z + (c % 2) * 6 - 3 },
          journeyLogs: [
            { step: '船舶卸货', facility: '远达荣耀 4号舱', timestamp: '2026-09-20 07:15', deviceUsed: 'QC-02', status: 'completed' },
            { step: '水平运输', facility: '海侧岸线通道', timestamp: '2026-09-20 07:22', deviceUsed: 'AGV-014', status: 'completed' },
            { step: '堆场落箱', facility: `堆场 ${code}`, timestamp: '2026-09-20 07:34', deviceUsed: `RTG-0${b + 1}`, status: 'completed' },
            { step: '海铁转运计划', facility: '海铁联运装卸线', timestamp: '2026-09-20 14:00', deviceUsed: 'RMG-01', status: 'planned' }
          ]
        });
      }
    }

    // 5. RTG Yard Cranes (12 units)
    const rtgData: RTGCraneTwin[] = [];
    for (let r = 0; r < 12; r++) {
      const rtgNo = `RTG-${(r + 1).toString().padStart(2, '0')}`;
      const blockIdx = r % 8;
      const parentBlock = yardBlocksData[blockIdx];
      rtgData.push({
        id: rtgNo,
        name: `全电力自动化轨道吊 ${rtgNo}`,
        type: 'rtg_crane',
        rtgNo,
        assignedYardBlockId: parentBlock.id,
        gantryPosition: 10 + (r * 7) % 30,
        trolleyPosition: 3.5,
        hoistHeight: 3.0,
        spreaderLocked: true,
        currentContainerId: `TGHU${r}19284`,
        movesPerHour: 27.8 + (r % 3) * 1.2,
        batteryLevelPercent: 92 - (r % 5) * 4,
        powerKw: 120,
        position: { x: parentBlock.position.x + ((r % 2) === 0 ? -15 : 15), y: 0, z: parentBlock.position.z },
        geoPosition: { ...parentBlock.geoPosition },
        status: 'working',
        lastUpdated: '10:30',
        responsibleDept: '堆场自动化维保处',
        healthScore: 97,
        alerts: []
      });
    }

    // 6. AGVs Fleet (40 units)
    const agvData: AGVTwin[] = [];
    for (let a = 0; a < 40; a++) {
      const agvNo = `AGV-${(a + 1).toString().padStart(3, '0')}`;
      const states: AGVTwin['state'][] = ['transporting', 'loaded', 'to_pick', 'waiting', 'idle', 'charging'];
      const st = a === 3 ? 'charging' : states[a % 6];
      const startX = -220 + (a % 10) * 48;
      const startZ = -60 + Math.floor(a / 10) * 35;

      agvData.push({
        id: agvNo,
        name: `锂电重载无人引导车 ${agvNo}`,
        type: 'agv',
        agvNo,
        state: st,
        batteryLevel: a === 3 ? 42 : 98 - (a % 15) * 3,
        speedKmh: st === 'transporting' ? 22.5 : st === 'to_pick' ? 25.0 : 0,
        currentPayloadContainerId: st === 'loaded' || st === 'transporting' ? `MSCU-AGV${a}01` : undefined,
        targetDestination: (a % 2 === 0) ? `QC-0${(a % 6) + 1}` : `YARD-A0${(a % 8) + 1}`,
        routeWaypoints: [
          { x: startX, y: 0.5, z: startZ },
          { x: startX + 30, y: 0.5, z: startZ }
        ],
        mileageTodayKm: 42.5 + a * 1.8,
        radarObstacleDistanceM: 14.2,
        position: { x: startX, y: 0.5, z: startZ },
        geoPosition: { lng: 121.840 + (a % 10) * 0.002, lat: 31.392 + Math.floor(a / 10) * 0.001 },
        status: st === 'charging' ? 'charging' : 'working',
        lastUpdated: '10:30',
        responsibleDept: 'AGV无人车队调度中心',
        healthScore: 98,
        alerts: []
      });
    }

    // 7. Sea-Rail Intermodal
    const railData: RailTrainTwin[] = [
      {
        id: 'TRAIN-X8011',
        name: 'X8011次 中欧班列 (海铁国际快线)',
        type: 'rail_train',
        trainNo: 'X8011 (海铁联运)',
        trainType: '集装箱班列',
        wagonsCount: 50,
        currentWagonsLoaded: 38,
        progressPercent: 76.0,
        direction: 'DEPARTURE',
        trackNo: '海铁专用1道',
        originStation: '上海港铁路中心站',
        destStation: '德国杜伊斯堡 (DUISBURG)',
        eta: '2026-09-20 08:00',
        etd: '2026-09-20 15:30',
        position: { x: -140, y: 0, z: 120 },
        geoPosition: { lng: 121.845, lat: 31.402 },
        status: 'working',
        lastUpdated: '10:30',
        responsibleDept: '中铁集装箱上海分公司',
        healthScore: 99,
        alerts: []
      },
      {
        id: 'TRAIN-K902',
        name: 'K902次 华东大宗矿石疏运专列',
        type: 'rail_train',
        trainNo: 'K902 (矿石集疏运)',
        trainType: '铁矿石敞车专列',
        wagonsCount: 60,
        currentWagonsLoaded: 60,
        progressPercent: 100.0,
        direction: 'ARRIVAL',
        trackNo: '散货装车2道',
        originStation: '马鞍山钢铁枢纽站',
        destStation: '上海港散货矿石码头',
        eta: '2026-09-20 10:00',
        etd: '2026-09-20 18:00',
        position: { x: 120, y: 0, z: 120 },
        geoPosition: { lng: 121.856, lat: 31.403 },
        status: 'working',
        lastUpdated: '10:30',
        responsibleDept: '大宗散货铁路调度室',
        healthScore: 98,
        alerts: []
      }
    ];

    // 8. Bulk Terminal
    const bulkData: BulkTerminalTwin[] = [
      {
        id: 'BULK-SR-01',
        name: '6000t/h 斗轮堆取料机 (SR-01)',
        type: 'bulk_equipment',
        machineNo: 'SR-01',
        bulkType: '斗轮堆取料机',
        material: '铁矿石',
        flowRateTonsPerHour: 4850,
        totalTonsProcessedToday: 28400,
        beltSpeedMs: 4.5,
        dustConcentrationMgM3: 4.2,
        position: { x: 260, y: 0, z: 20 },
        geoPosition: { lng: 121.865, lat: 31.396 },
        status: 'working',
        lastUpdated: '10:30',
        responsibleDept: '散货矿石作业分部',
        healthScore: 96,
        alerts: []
      },
      {
        id: 'BULK-CONV-01',
        name: '港区主散货封闭皮带机廊道 (CV-01)',
        type: 'bulk_equipment',
        machineNo: 'CV-01',
        bulkType: '带式输送机廊道',
        material: '动力煤',
        flowRateTonsPerHour: 3200,
        totalTonsProcessedToday: 19800,
        beltSpeedMs: 5.2,
        dustConcentrationMgM3: 3.8,
        position: { x: 280, y: 6, z: 70 },
        geoPosition: { lng: 121.867, lat: 31.399 },
        status: 'working',
        lastUpdated: '10:30',
        responsibleDept: '连续输送保障队',
        healthScore: 97,
        alerts: []
      }
    ];

    // 9. Oil & Gas Terminal
    const oilTanksData: OilGasTankTwin[] = [
      {
        id: 'TANK-TK-101',
        name: '原油大型外浮顶储罐 (TK-101 10万m³)',
        type: 'oil_tank',
        tankNo: 'TK-101',
        medium: '超重质原油',
        capacityM3: 100000,
        currentVolumeM3: 78500,
        liquidLevelM: 16.8,
        maxLevelM: 21.5,
        liquidPercentage: 78.5,
        pressureKPa: 102.3,
        temperatureC: 38.2,
        vocPpm: 12.4,
        nitrogenBlanketStatus: 'NORMAL',
        valveState: 'OPEN',
        position: { x: -280, y: 0, z: 30 },
        geoPosition: { lng: 121.832, lat: 31.395 },
        status: 'working',
        lastUpdated: '10:30',
        responsibleDept: '油气储运分公司一库区',
        healthScore: 99,
        alerts: []
      },
      {
        id: 'TANK-TK-102',
        name: 'LNG低温全容储罐 (TK-102 16万m³)',
        type: 'oil_tank',
        tankNo: 'TK-102',
        medium: 'LNG液化天然气',
        capacityM3: 160000,
        currentVolumeM3: 132000,
        liquidLevelM: 24.2,
        maxLevelM: 29.0,
        liquidPercentage: 82.5,
        pressureKPa: 118.5,
        temperatureC: -161.4,
        vocPpm: 0.8,
        nitrogenBlanketStatus: 'NORMAL',
        valveState: 'OPEN',
        position: { x: -330, y: 0, z: 70 },
        geoPosition: { lng: 121.828, lat: 31.397 },
        status: 'working',
        lastUpdated: '10:30',
        responsibleDept: 'LNG深冷作业特种站',
        healthScore: 100,
        alerts: []
      }
    ];

    // 10. Pipelines
    const pipelinesData: PipelineTwin[] = [
      {
        id: 'PIPE-CRUDE-01',
        name: '油品1号码头装卸主输油管线 (DN600)',
        type: 'pipeline',
        pipelineNo: 'PL-CRUDE-01',
        medium: '原油',
        diameterMm: 600,
        startPoint: '油品1号输油臂',
        endPoint: 'TK-101储罐区泵站',
        flowM3PerHour: 3400,
        pressureBar: 18.2,
        temperatureC: 41.5,
        valveOpenPercent: 100,
        points3D: [
          { x: -340, y: 1.5, z: -110 },
          { x: -310, y: 1.5, z: -30 },
          { x: -280, y: 1.5, z: 30 }
        ],
        position: { x: -310, y: 1.5, z: -30 },
        geoPosition: { lng: 121.830, lat: 31.393 },
        status: 'working',
        lastUpdated: '10:30',
        responsibleDept: '管道防腐与SCADA监测班',
        healthScore: 98,
        alerts: []
      },
      {
        id: 'PIPE-LNG-01',
        name: '深冷LNG保冷输送双壁管线 (DN450)',
        type: 'pipeline',
        pipelineNo: 'PL-LNG-01',
        medium: 'LNG',
        diameterMm: 450,
        startPoint: 'LNG专用泊位接卸臂',
        endPoint: 'TK-102储罐区',
        flowM3PerHour: 2800,
        pressureBar: 24.5,
        temperatureC: -162.0,
        valveOpenPercent: 95,
        points3D: [
          { x: -380, y: 2.0, z: -90 },
          { x: -350, y: 2.0, z: 0 },
          { x: -330, y: 2.0, z: 70 }
        ],
        position: { x: -350, y: 2.0, z: 0 },
        geoPosition: { lng: 121.826, lat: 31.395 },
        status: 'working',
        lastUpdated: '10:30',
        responsibleDept: '低温工艺维护处',
        healthScore: 100,
        alerts: []
      }
    ];

    // 11. Gate Lanes
    const gateLanesData: GateLaneTwin[] = [
      { laneId: 'GATE-IN-01', laneType: 'INSPECTION_IN', ocrStatus: 'PASS', weighbridgeKg: 42100, currentTruckPlate: '沪A·89K21', avgPassSeconds: 19.8, todayTrucksCount: 540 },
      { laneId: 'GATE-IN-02', laneType: 'INSPECTION_IN', ocrStatus: 'SCANNING', weighbridgeKg: 38400, currentTruckPlate: '浙B·72M90', avgPassSeconds: 21.2, todayTrucksCount: 512 },
      { laneId: 'GATE-OUT-01', laneType: 'OUTBOUND', ocrStatus: 'PASS', weighbridgeKg: 14200, currentTruckPlate: '苏E·55T66', avgPassSeconds: 16.5, todayTrucksCount: 460 },
      { laneId: 'GATE-HAZ-01', laneType: 'HAZMAT_IN', ocrStatus: 'PASS', weighbridgeKg: 44800, currentTruckPlate: '皖C·99H18', avgPassSeconds: 38.0, todayTrucksCount: 88 }
    ];

    // Set initial signals
    this.ships.set(shipsData);
    this.berths.set(berthsData);
    this.quayCranes.set(qcData);
    this.rtgCranes.set(rtgData);
    this.agvs.set(agvData);
    this.yardBlocks.set(yardBlocksData);
    this.containers.set(containersData);
    this.trains.set(railData);
    this.bulkEquipments.set(bulkData);
    this.oilTanks.set(oilTanksData);
    this.pipelines.set(pipelinesData);
    this.gateLanes.set(gateLanesData);

    // Initial alert list from equipment
    const initialAlerts: PortAlert[] = [
      {
        id: 'ALT-QC03-VIB',
        time: '10:14:22',
        sourceObjectId: 'QC-03',
        sourceObjectName: '岸桥 QC-03',
        level: 'warning',
        category: 'EQUIPMENT_FAULT',
        message: '主起升减速机输出轴振动RMS均方根值达3.82mm/s，超过正常预警阈值(2.50mm/s)',
        handled: false,
        location: { x: -30, y: 35, z: -95 }
      },
      {
        id: 'ALT-YARD-A03',
        time: '10:22:05',
        sourceObjectId: 'YARD-A03',
        sourceObjectName: '冷藏箱堆区 A03',
        level: 'info',
        category: 'REEFER_TEMP',
        message: 'A03冷藏箱区利用率达到87.5%，建议开启备用电源插座并分流后续进港箱',
        handled: false,
        location: { x: 70, y: 10, z: 10 }
      },
      {
        id: 'ALT-WEATHER-GUST',
        time: '10:28:40',
        sourceObjectId: 'WEATHER-STATION-01',
        sourceObjectName: '海侧气象雷达站',
        level: 'info',
        category: 'WEATHER_TYPHOON',
        message: '海面突发阵风 14.8 节，各岸桥防风防爬器状态自检正常',
        handled: true,
        handler: '系统自动防御机制',
        actionTaken: '岸桥微风自动纠偏已激活',
        location: { x: -280, y: 15, z: -160 }
      }
    ];
    this.alerts.set(initialAlerts);
  }

  private startSimulationEngine() {
    let tickCount = 0;
    this.simulationInterval = setInterval(() => {
      tickCount++;

      const tm = this.timeMachine();
      if (tm.isPlaying) {
        // Advance clock
        const current = new Date(tm.currentSimulatedTime.getTime() + 1000 * tm.playbackSpeed);
        this.timeMachine.update(t => ({ ...t, currentSimulatedTime: current }));
      }

      // Continuous dynamic kinematic update for AGVs
      this.agvs.update(agvs => {
        return agvs.map((agv, idx) => {
          if (agv.state === 'transporting' || agv.state === 'to_pick') {
            const speedFactor = 0.4;
            const newX = agv.position.x + (idx % 2 === 0 ? speedFactor : -speedFactor);
            // bounce within port boundaries
            let boundedX = newX;
            if (boundedX > 220) boundedX = -220;
            if (boundedX < -220) boundedX = 220;

            return {
              ...agv,
              position: {
                ...agv.position,
                x: boundedX
              }
            };
          }
          return agv;
        });
      });

      // Periodic subtle fluctuation for weather & pipelines
      if (tickCount % 5 === 0) {
        this.weather.update(w => ({
          ...w,
          windSpeedKnots: +(11.0 + Math.sin(tickCount * 0.1) * 1.5).toFixed(1),
          tideLevelMeters: +(2.85 + Math.sin(tickCount * 0.02) * 0.05).toFixed(2)
        }));

        this.pipelines.update(pipes =>
          pipes.map(p => ({
            ...p,
            flowM3PerHour: +(p.flowM3PerHour + (Math.random() * 20 - 10)).toFixed(0),
            pressureBar: +(p.pressureBar + (Math.random() * 0.4 - 0.2)).toFixed(1)
          }))
        );
      }
    }, 1000);
  }

  ngOnDestroy() {
    if (this.simulationInterval) {
      clearInterval(this.simulationInterval);
    }
  }
}
