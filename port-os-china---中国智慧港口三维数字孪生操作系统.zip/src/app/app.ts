import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PortHeader } from './components/port-header/port-header';
import { PortViewport } from './components/port-viewport/port-viewport';
import { BerthShipPanel } from './components/berth-ship-panel/berth-ship-panel';
import { YardContainerPanel } from './components/yard-container-panel/yard-container-panel';
import { AGVFleetPanel } from './components/agv-fleet-panel/agv-fleet-panel';
import { RailIntermodalPanel } from './components/rail-intermodal-panel/rail-intermodal-panel';
import { BulkOilGasPanel } from './components/bulk-oilgas-panel/bulk-oilgas-panel';
import { EnergyCarbonPanel } from './components/energy-carbon-panel/energy-carbon-panel';
import { SafetyEmergencyPanel } from './components/safety-emergency-panel/safety-emergency-panel';
import { MaintenanceRulPanel } from './components/maintenance-rul-panel/maintenance-rul-panel';
import { AnalyticsPanel } from './components/analytics-panel/analytics-panel';
import { AICopilotDrawer } from './components/ai-copilot-drawer/ai-copilot-drawer';
import { PortDataService } from './services/port-data.service';

@Component({
  selector: 'app-root',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    PortHeader,
    PortViewport,
    BerthShipPanel,
    YardContainerPanel,
    AGVFleetPanel,
    RailIntermodalPanel,
    BulkOilGasPanel,
    EnergyCarbonPanel,
    SafetyEmergencyPanel,
    MaintenanceRulPanel,
    AnalyticsPanel,
    AICopilotDrawer,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  readonly portData = inject(PortDataService);
}
