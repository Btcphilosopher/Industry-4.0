import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';
import {GoogleGenAI} from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());

const angularApp = new AngularNodeAppEngine();

// Initialize Gemini Client safely
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env['GEMINI_API_KEY'];
  if (!apiKey) {
    return null;
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

/**
 * AI Port Assistant Endpoint
 * Provides grounded expert analysis on port operations, berth congestion, equipment health, and energy optimization.
 */
app.post('/api/gemini/chat', async (req, res) => {
  try {
    const { prompt, portContext } = req.body;
    const ai = getGeminiClient();

    const systemInstruction = `你是由中国交通运输部智慧港口数字化规范指导、专为大型港口集团打造的【PORT OS CHINA 港口数字孪生智能调度副驾 (Port Intelligence Copilot)】。
你掌握港口生产调度、泊位甘特图优化、岸桥与AGV协同、集疏运海铁联运、自动化堆场配载、散货皮带机流转、油气储罐管网安全、状态监测与预测性维护(RUL)、绿色岸电节能、危险品隔离(IMDG Code)及应急指挥流程。

【核心工作原则】
1. 回答基于真实的港口运行数据上下文（如果在上下文中提供）。严禁无根据胡编乱造船舶名、设备编号或虚假安全事故。
2. 数据分析必须提供严谨、可落地的业务解释与工程建议（如：泊位转面时间分析、AGV锁闭冲突率、RTG单机作业路、碳排放配额等）。
3. 强调【IT/OT隔离与人机确认安全边界】：任何生产控制、PLC指令、阀门开关、岸桥远程下发都必须提示需经调度指挥长人工确认授权，不得直接执行物理写操作。
4. 使用标准中国港航与智慧物流术语（如：TEU、岸桥单机效率、在港停时、吃水深度、海铁班列编组、IMDG危险品分类、削峰填谷等）。
5. 回复结构清晰、专业干练，使用Markdown表格与要点列表，重点突出。`;

    if (!ai) {
      // Fallback deterministic expert response when API key is unconfigured in development
      const fallbackReplies: Record<string, string> = {
        berth: `### 📊 泊位运行与在港船舶综合分析
当前港区共开放 **3个核心泊位**，实时作业态势如下：
- **泊位 1 (深度 -17.5m)**：当前停靠大型集装箱船【远达荣耀 (COSCO GLORY)】，已作业 1,420 TEU，预计 18:30 完成离泊。后续接靠【中远海运极光】。
- **泊位 2 (深度 -16.0m)**：停靠集装箱船【新海轮 (NEW OCEAN)】，配工 2 台岸桥(QC-03, QC-04)，当前作业利用率 91.2%。
- **泊位 3 (深度 -18.0m)**：停靠超大型集装箱船【太平洋开拓者 (PACIFIC EXPLORER)】，配工 2 台岸桥(QC-05, QC-06)，处于满载装船高峰期。

**调度建议**：
1. 泊位1将在18:30释放，潮位预测在 19:15 达到 +3.8m 高潮窗口，建议安排【中远海运极光】在 18:50 引航靠泊，实现无缝衔接。
2. 调度中心已通过数字孪生仿真验证水深与流速安全，等待调度长人工下达引航指令。`,
        crane: `### ⚙️ 岸桥与堆场作业瓶颈诊断
系统实时监测 6 台岸桥与 12 台 RTG 运行工况：
- **岸桥 QC-03**：当前平均单机作业效率 **28.4 自然箱/小时**（正常标杆为 32.0），主起升电机轴承振动均方根值(RMS)达到 3.8 mm/s（正常阈值 < 2.5 mm/s），存在轻度异常波动。
- **堆场 A03/A04 箱区**：堆场利用率达到 **87.5%**（临界警戒线），AGV 待装卸排队时间平均上升 4.2 分钟。

**优化方案**：
1. 将部分后续卸船重箱动态分流至 **B02 低负荷箱区 (利用率 52%)**，平抑场桥翻箱率。
2. 建议在今日 20:00 船舶装卸间隙，安排机修二班对 QC-03 减速箱轴承实施红外点检与动平衡校验。`,
        energy: `### ⚡ 港区绿色能源与碳排放分析
今日港区综合能耗与碳减排实时监测指标：
- **今日总用电量**：48,250 kWh，当前负荷峰值 **4,280 kW**。
- **清洁能源贡献**：屋顶光伏并网发电 9,450 kWh（占比 19.6%），储能电站处于放电削峰模式。
- **高压岸电接驳**：【远达荣耀】与【太平洋开拓者】已接入 6.6kV 高压岸电系统，累计替代燃油消耗 12.8 吨，减少碳排放 **39.7 吨 CO₂e**。
- **AGV换电站**：当前 40 台 AGV 中有 32 台在线作业，4 台快充中，4 台待命，电池健康度均值 96.4%。`,
        rail: `### 🚆 海铁联运与多式联运动态
- **铁路专用线**：今日已进站海铁班列 **4 列**（共 210 车皮），已完成编组 168 车，累计发送集装箱 **336 TEU**。
- **在途追踪**：X8011次中欧班列（海铁快线）准点到达编组站 2 道，预计 2 小时后开始 RMG 吊装作业。
- **集疏运协同**：进出港主道口平均通行时间 **22 秒/车**，预约集卡集港准时率 94.8%，无大面积压车现象。`
      };

      let selected = fallbackReplies['berth'];
      if (prompt?.includes('岸桥') || prompt?.includes('设备') || prompt?.includes('维护') || prompt?.includes('故障')) {
        selected = fallbackReplies['crane'];
      } else if (prompt?.includes('能') || prompt?.includes('碳') || prompt?.includes('电')) {
        selected = fallbackReplies['energy'];
      } else if (prompt?.includes('铁') || prompt?.includes('多式') || prompt?.includes('车')) {
        selected = fallbackReplies['rail'];
      }

      res.json({
        success: true,
        reply: selected,
        model: 'simulation-engine-v1',
        isSimulated: true
      });
      return;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: `【当前港口实时运行指标快照】:\n${JSON.stringify(portContext || {}, null, 2)}\n\n【调度人员咨询指令】:\n${prompt}`
            }
          ]
        }
      ],
      config: {
        systemInstruction,
        temperature: 0.3,
        topP: 0.85
      }
    });

    res.json({
      success: true,
      reply: response.text || '暂无分析输出',
      model: 'gemini-3.8-flash'
    });
  } catch (error: unknown) {
    console.error('Gemini Chat API Error:', error);
    const msg = error instanceof Error ? error.message : 'AI 调度分析引擎响应异常';
    res.status(500).json({
      success: false,
      error: msg
    });
  }
});

/**
 * AI Scheduling & Dispatch Optimization Engine
 * Calculates optimal Berth Allocation, QC Assignment, AGV Fleet Routing and Yard Slot Placement.
 */
app.post('/api/ai/dispatch-recommendation', async (req, res) => {
  try {
    const { scenarioType } = req.body;
    const ai = getGeminiClient();

    const promptText = `请根据当前港口状态，针对调度场景【${scenarioType || '全面综合调度优化'}】生成一套量化优化方案。
包含：
1. 泊位与船舶靠泊计划重新配载甘特图建议
2. 岸桥(QC)与AGV动态派发比率调整（如：由1:6调整为1:7以缓解堆场等待）
3. 自动化堆场压箱翻箱率降低策略
4. 预期改善指标（如：船舶在港停时减少%、AGV空驶率降低%、单箱能耗下降%）
5. 人工确认安全合规审查清单（列出需要调度员核实的5项关键条件，严禁直接写入OT）。`;

    if (!ai) {
      res.json({
        success: true,
        plan: {
          id: `PLAN-${Date.now().toString().slice(-6)}`,
          title: '海侧-堆场-陆侧一体化多目标协同优化方案',
          target: scenarioType || '峰值拥堵与能耗协同优化',
          generatedTime: new Date().toISOString(),
          berthAdjustments: [
            { berthId: 'BERTH-01', ship: 'COSCO GLORY', action: '提前离泊 15 分钟', reason: '双QC全力推进完工，释放潮位窗口' },
            { berthId: 'BERTH-02', ship: 'NEW OCEAN', action: '增派 QC-02 协同作业', reason: '平抑海侧积压箱' }
          ],
          agvRatio: '由 1:6.2 动态上调至 1:6.8',
          yardOptimization: '重箱集中导入 A01/B02 浅位，预计翻箱率下降 14.3%',
          metricsGain: {
            vesselTurnaroundHoursSaved: 1.8,
            agvEmptyDrivingReduction: '18.4%',
            co2ReductionTons: 6.2,
            energySavedKWh: 1450
          },
          safetyChecklist: [
            '确认泊位水深实时测深数据大于船舶动态吃水 + 1.2m 富余水深',
            '确认 AGV 运行磁钉及激光防撞雷达无告警',
            '确认危险品箱处于集装箱专用防爆隔离区',
            '确认岸电切换过程中船舶辅机负荷平稳',
            '调度长电子签名确认下发至数字孪生任务池（IT/OT安全隔离）'
          ],
          confidence: 0.94
        }
      });
      return;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: promptText,
      config: {
        systemInstruction: '你是一个专业的港口运筹学优化引擎，输出严谨量化的调度决策建议，并严格遵守安全隔离与人工确认要求。'
      }
    });

    res.json({
      success: true,
      analysis: response.text,
      timestamp: new Date().toISOString()
    });
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : '调度优化引擎计算异常';
    res.status(500).json({ success: false, error: errorMsg });
  }
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }
    console.log(`PORT OS CHINA Server listening on http://localhost:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
