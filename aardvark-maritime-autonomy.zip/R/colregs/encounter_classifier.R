#' COLREGs Encounter Classifier and Navigation Role Determiner
#'
#' @description Implements rule-based formal encounter reasoning adhering to International
#' Regulations for Preventing Collisions at Sea (COLREGs Rules 13, 14, 15, 16, 17, 18).
#'
#' @param own_state List with x, y, course_deg, speed_knots
#' @param target_state List with x, y, course_deg, speed_knots, vessel_type
#' @return List with situation, navigation_role, rule_reference, action_advice
#' @export
classify_encounter <- function(own_state, target_state) {
  dx <- target_state$x - own_state$x
  dy <- target_state$y - own_state$y
  distance <- sqrt(dx^2 + dy^2)

  # Relative bearing of target from own ship (0 to 360 deg)
  true_bearing <- (atan2(dy, dx) * 180 / pi) %% 360
  rel_bearing <- (true_bearing - own_state$course_deg) %% 360

  # Relative course difference
  course_diff <- (target_state$course_deg - own_state$course_deg) %% 360

  # Vessel type hierarchy (COLREGs Rule 18: Responsibilities between vessels)
  if (!is.null(target_state$vessel_type) && target_state$vessel_type %in% c("NUC", "RAM", "FISHING", "SAILING")) {
    return(list(
      situation = "SPECIAL_STATUS_VESSEL",
      navigation_role = "GIVE_WAY",
      colregs_rule = "Rule 18 (Responsibilities Between Vessels)",
      action_advice = "Keep well clear of restricted maneuverability vessel; alter course early to starboard or reduce speed.",
      confidence = 0.95
    ))
  }

  # 1. Overtaking Encounter (Rule 13)
  # Target is coming up with another vessel from a direction more than 22.5 deg abaft her beam
  # i.e., relative bearing between 112.5 deg and 247.5 deg
  if (rel_bearing > 112.5 && rel_bearing < 247.5 && target_state$speed_knots > own_state$speed_knots + 1) {
    return(list(
      situation = "BEING_OVERTAKEN",
      navigation_role = "STAND_ON",
      colregs_rule = "Rule 13 (Overtaking) & Rule 17 (Action by Stand-on Vessel)",
      action_advice = "Maintain course and speed; monitor overtaking vessel's clearance.",
      confidence = 0.92
    ))
  }

  if (course_diff < 45 || course_diff > 315) {
    # We are approaching target from behind
    target_rel_to_us <- (true_bearing + 180 - target_state$course_deg) %% 360
    if (target_rel_to_us > 112.5 && target_rel_to_us < 247.5 && own_state$speed_knots > target_state$speed_knots) {
      return(list(
        situation = "OVERTAKING",
        navigation_role = "GIVE_WAY",
        colregs_rule = "Rule 13 (Overtaking) & Rule 16 (Action by Give-way Vessel)",
        action_advice = "Keep out of the way of the vessel being overtaken; pass safely to port or starboard with wide margin.",
        confidence = 0.94
      ))
    }
  }

  # 2. Head-on Situation (Rule 14)
  # Reciprocal or nearly reciprocal courses (course difference ~170 to 190 deg)
  # and relative bearing roughly dead ahead (350 deg to 10 deg)
  is_head_on_course <- (course_diff > 165 && course_diff < 195)
  is_dead_ahead <- (rel_bearing < 12 || rel_bearing > 348)

  if (is_head_on_course && is_dead_ahead) {
    return(list(
      situation = "HEAD_ON",
      navigation_role = "GIVE_WAY", # Both vessels alter course to starboard
      colregs_rule = "Rule 14 (Head-on Situation)",
      action_advice = "Alter course to starboard so that each vessel shall pass on the port side of the other.",
      confidence = 0.96
    ))
  }

  # 3. Crossing Situation (Rule 15)
  # When two power-driven vessels are crossing so as to involve risk of collision
  # Target on our Starboard side (005 deg to 112.5 deg) -> We GIVE WAY
  if (rel_bearing >= 5 && rel_bearing <= 112.5) {
    return(list(
      situation = "CROSSING_TARGET_STARBOARD",
      navigation_role = "GIVE_WAY",
      colregs_rule = "Rule 15 (Crossing Situation) & Rule 16 (Give-way Action)",
      action_advice = "Avoid crossing ahead of the other vessel; make substantial alteration of course to starboard and/or slacken speed.",
      confidence = 0.90
    ))
  }

  # Target on our Port side (247.5 deg to 355 deg) -> We STAND ON
  if (rel_bearing >= 247.5 && rel_bearing <= 355) {
    return(list(
      situation = "CROSSING_TARGET_PORT",
      navigation_role = "STAND_ON",
      colregs_rule = "Rule 15 (Crossing Situation) & Rule 17 (Stand-on Action)",
      action_advice = "Keep course and speed. If give-way vessel fails to take appropriate action, take action to avoid collision (Rule 17b).",
      confidence = 0.90
    ))
  }

  return(list(
    situation = "UNCERTAIN_CLEAR",
    navigation_role = "STAND_ON",
    colregs_rule = "Rule 2 (General Responsibility)",
    action_advice = "Maintain vigilant multi-sensor watch; preserve safe CPA.",
    confidence = 0.75
  ))
}
