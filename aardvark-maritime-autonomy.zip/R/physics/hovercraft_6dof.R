#' Hovercraft 6-DOF Physical and Aerodynamic Model
#'
#' @description Represents a commercial freight hovercraft with full 6-degree-of-freedom
#' numerical dynamics, cushion pressure dynamics, skirt air leakage, and dual ducted fan thrust.
#'
#' @export
#' @import R6
Hovercraft <- R6::R6Class(
  "Hovercraft",
  public = list(
    id = NULL,
    name = NULL,
    length = 28.5,            # m
    beam = 12.0,              # m
    height = 6.8,             # m
    mass_empty = 45000,       # kg (45 tonnes)
    mass_cargo = 25000,       # kg (25 tonnes synthetic payload)
    total_mass = NULL,        # kg
    cushion_area = 240.0,     # m^2
    skirt_perimeter = 75.0,   # m
    skirt_height = 1.4,       # m
    nominal_cushion_press = 2850, # Pa (gauge)
    lift_power_kw = 1200,     # kW (Twin centrifugal lift fans)
    propulsion_power_kw = 2400,# kW (Twin variable-pitch ducted air propellers)
    fuel_capacity_l = 8000,   # Litres Marine Gasoil / Sustainable Fuel
    fuel_remaining_l = 6800,  # Litres
    battery_kwh = 350,        # kWh auxiliary hybrid buffer
    battery_soc = 0.92,       # 92%
    max_speed_knots = 48.0,   # knots (~24.7 m/s)
    
    # State Vector: [x, y, z, u, v, w, roll, pitch, yaw, p, q, r] (SI units: m, m/s, rad, rad/s)
    state = NULL,
    
    # Control Vector: [thrust_port, thrust_stbd, rudder_deg, lift_rpm_pct, bow_thruster]
    control = NULL,

    initialize = function(id = "A01", name = "Aardvark Heavy Freighter A01", payload_kg = 25000) {
      self$id <- id
      self$name <- name
      self$mass_cargo <- payload_kg
      self$total_mass <- self$mass_empty + self$mass_cargo
      
      # Initial state: x=0, y=0, z=1.2 (hover height), u=0, v=0, w=0, roll=0, pitch=0, yaw=0, p=0, q=0, r=0
      self$state <- c(x = 0, y = 0, z = 1.2, u = 0, v = 0, w = 0, roll = 0, pitch = 0, yaw = 0, p = 0, q = 0, r = 0)
      self$control <- c(thrust_port = 0, thrust_stbd = 0, rudder_deg = 0, lift_pct = 100, bow_thruster = 0)
    },

    step_dynamics = function(dt = 0.1, env = list(wind_speed = 0, wind_dir = 0, current_speed = 0, current_dir = 0, wave_height = 0.5)) {
      # Physical Constants
      rho_air <- 1.225   # kg/m^3
      rho_water <- 1025  # kg/m^3
      g <- 9.80665       # m/s^2

      # Extract state
      u <- self$state["u"]
      v <- self$state["v"]
      psi <- self$state["yaw"]
      r <- self$state["r"]
      z <- self$state["z"]

      # Relative wind vector
      v_wind_x <- env$wind_speed * cos(env$wind_dir)
      v_wind_y <- env$wind_speed * sin(env$wind_dir)
      u_rel <- u - (v_wind_x * cos(psi) + v_wind_y * sin(psi))
      v_rel <- v - (-v_wind_x * sin(psi) + v_wind_y * cos(psi))
      v_air_app <- sqrt(u_rel^2 + v_rel^2)

      # Aerodynamic drag forces (Hull body)
      cd_x <- 0.38
      cd_y <- 0.72
      f_aero_x <- -0.5 * rho_air * cd_x * (self$beam * self$height) * u_rel * abs(u_rel)
      f_aero_y <- -0.5 * rho_air * cd_y * (self$length * self$height) * v_rel * abs(v_rel)

      # Cushion dynamics & Skirt friction
      cushion_lift_force <- self$nominal_cushion_press * self$cushion_area * (self$control["lift_pct"] / 100)
      weight_force <- self$total_mass * g
      cushion_gap <- max(0.01, z - self$skirt_height)
      skirt_drag_coeff <- 0.015 / (cushion_gap + 0.05)
      f_skirt_drag_x <- -skirt_drag_coeff * self$total_mass * g * tanh(u / 2)
      f_skirt_drag_y <- -skirt_drag_coeff * self$total_mass * g * tanh(v / 2)

      # Propulsion thrust forces (Twin ducted propellers: 120 kN max combined)
      max_thrust_per_fan <- 60000 # N
      t_port <- (self$control["thrust_port"] / 100) * max_thrust_per_fan
      t_stbd <- (self$control["thrust_stbd"] / 100) * max_thrust_per_fan
      rudder_rad <- self$control["rudder_deg"] * (pi / 180)
      
      thrust_x <- (t_port + t_stbd) * cos(rudder_rad)
      thrust_y <- (t_port + t_stbd) * sin(rudder_rad) + (self$control["bow_thruster"] / 100) * 15000
      
      # Yaw moment: differential thrust lever arm (beam/2 * 0.75) + aerodynamic rudder
      fan_arm <- (self$beam / 2) * 0.75
      moment_yaw <- (t_stbd - t_port) * fan_arm - ((t_port + t_stbd) * sin(rudder_rad) * (self$length * 0.45))
      
      # Hydrodynamic current drift (water-surface contact in high waves)
      f_current_x <- -250 * (u - env$current_speed * cos(env$current_dir - psi))
      f_current_y <- -450 * (v - env$current_speed * sin(env$current_dir - psi))

      # Accelerations
      i_zz <- (1/12) * self$total_mass * (self$length^2 + self$beam^2)
      u_dot <- (thrust_x + f_aero_x + f_skirt_drag_x + f_current_x) / self$total_mass + v * r
      v_dot <- (thrust_y + f_aero_y + f_skirt_drag_y + f_current_y) / self$total_mass - u * r
      r_dot <- (moment_yaw - 0.25 * i_zz * r * abs(r)) / i_zz

      # Update velocities (Euler / Runge-Kutta 2)
      u_new <- u + u_dot * dt
      v_new <- v + v_dot * dt
      r_new <- r + r_dot * dt

      # Global position update
      psi_new <- (psi + r_new * dt) %% (2 * pi)
      x_dot <- u_new * cos(psi_new) - v_new * sin(psi_new)
      y_dot <- u_new * sin(psi_new) + v_new * cos(psi_new)

      x_new <- self$state["x"] + x_dot * dt
      y_new <- self$state["y"] + y_dot * dt
      
      # Fuel consumption calculation (litres/hour based on power)
      total_kw <- (abs(t_port) + abs(t_stbd)) / 1000 * 20 + self$lift_power_kw * (self$control["lift_pct"] / 100)
      fuel_flow_l_per_sec <- (total_kw * 0.24) / 3600 # ~240g/kWh density 0.85
      self$fuel_remaining_l <- max(0, self$fuel_remaining_l - fuel_flow_l_per_sec * dt)

      self$state <- c(
        x = x_new, y = y_new, z = 1.25,
        u = u_new, v = v_new, w = 0,
        roll = -0.05 * v_new / (abs(u_new) + 1),
        pitch = 0.02 * u_dot,
        yaw = psi_new,
        p = 0, q = 0, r = r_new
      )
      return(self$state)
    }
  )
)
