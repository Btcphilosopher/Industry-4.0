#' Closest Point of Approach (CPA) and Time to CPA (TCPA) Engine
#'
#' @description Computes spatial collision risk parameters between own ship and target vessels
#' using relative velocity geometry and kinematic domain projections.
#'
#' @param own_pos Named vector c(x, y) in metres
#' @param own_vel Named vector c(vx, vy) in m/s
#' @param target_pos Named vector c(x, y) in metres
#' @param target_vel Named vector c(vx, vy) in m/s
#' @return List with distance (m), relative bearing (deg), CPA (m), TCPA (s), and risk score
#' @export
calculate_cpa <- function(own_pos, own_vel, target_pos, target_vel) {
  # Relative position vector: r = p_target - p_own
  rx <- target_pos["x"] - own_pos["x"]
  ry <- target_pos["y"] - own_pos["y"]
  current_distance <- sqrt(rx^2 + ry^2)

  # Relative velocity vector: v_rel = v_target - v_own
  vrx <- target_vel["vx"] - own_vel["vx"]
  vry <- target_vel["vy"] - own_vel["vy"]
  rel_speed_sq <- vrx^2 + vry^2

  if (rel_speed_sq < 1e-6) {
    # Parallel courses and equal speeds
    return(list(
      distance = current_distance,
      cpa = current_distance,
      tcpa = Inf,
      relative_speed = 0,
      risk_level = "LOW",
      risk_score = 0.05
    ))
  }

  # TCPA calculation: - (r . v_rel) / |v_rel|^2
  dot_product <- rx * vrx + ry * vry
  tcpa_seconds <- -dot_product / rel_speed_sq

  # CPA calculation
  if (tcpa_seconds < 0) {
    # Targets are already diverging
    cpa_distance <- current_distance
  } else {
    # Position of target at TCPA relative to own position at TCPA
    cpa_x <- rx + vrx * tcpa_seconds
    cpa_y <- ry + vry * tcpa_seconds
    cpa_distance <- sqrt(cpa_x^2 + cpa_y^2)
  }

  # Relative bearing calculation (0 to 360 deg relative to own heading)
  own_heading <- atan2(own_vel["vy"], own_vel["vx"])
  target_bearing_abs <- atan2(ry, rx)
  rel_bearing_rad <- (target_bearing_abs - own_heading) %% (2 * pi)
  rel_bearing_deg <- rel_bearing_rad * (180 / pi)

  # Multi-factor Risk Scoring Function
  # Criteria: CPA safety threshold (500m for hovercraft at cruising speed), TCPA (< 180s = high)
  safe_cpa_radius <- 600.0 # metres
  cpa_factor <- max(0, 1 - (cpa_distance / safe_cpa_radius))
  tcpa_factor <- if (tcpa_seconds > 0 && tcpa_seconds < 600) {
    max(0, 1 - (tcpa_seconds / 600))
  } else {
    0
  }

  combined_risk <- 0.6 * cpa_factor + 0.4 * tcpa_factor
  
  risk_level <- if (combined_risk > 0.75 && tcpa_seconds > 0 && tcpa_seconds < 120) {
    "CRITICAL"
  } else if (combined_risk > 0.45 && tcpa_seconds > 0) {
    "HIGH"
  } else if (combined_risk > 0.20 && tcpa_seconds > 0) {
    "MODERATE"
  } else {
    "LOW"
  }

  return(list(
    distance = current_distance,
    relative_bearing_deg = rel_bearing_deg,
    cpa = cpa_distance,
    tcpa = tcpa_seconds,
    relative_speed = sqrt(rel_speed_sq),
    risk_level = risk_level,
    risk_score = round(combined_risk, 3)
  ))
}
