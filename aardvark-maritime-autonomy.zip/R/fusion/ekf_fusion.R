#' Extended Kalman Filter (EKF) for Maritime Autonomy State Estimation
#'
#' @description Fuses asynchronous multi-sensor streams (GNSS, IMU, Marine Radar, LiDAR, AIS)
#' into a unified state estimate with uncertainty covariance tracking.
#'
#' @param current_estimate Named numeric vector of state: x, y, u, v, psi, r
#' @param covariance 6x6 numeric covariance matrix P
#' @param measurement Named vector of sensor readings (e.g. gnss_x, gnss_y, imu_yaw, etc.)
#' @param dt Time step in seconds
#' @param sensor_health List of sensor health weights (0.0 to 1.0)
#' @return List with updated state estimate, covariance matrix, and innovation residuals
#' @export
ekf_update <- function(current_estimate, covariance, measurement, dt = 0.1, sensor_health = list(gnss = 1.0, imu = 1.0, radar = 1.0)) {
  # State: [x, y, u, v, psi, r]
  x <- current_estimate["x"]
  y <- current_estimate["y"]
  u <- current_estimate["u"]
  v <- current_estimate["v"]
  psi <- current_estimate["psi"]
  r <- current_estimate["r"]

  # 1. State Prediction (Kinematic Motion Model)
  c_psi <- cos(psi)
  s_psi <- sin(psi)
  
  x_pred <- x + (u * c_psi - v * s_psi) * dt
  y_pred <- y + (u * s_psi + v * c_psi) * dt
  u_pred <- u
  v_pred <- v
  psi_pred <- (psi + r * dt) %% (2 * pi)
  r_pred <- r

  state_pred <- c(x = x_pred, y = y_pred, u = u_pred, v = v_pred, psi = psi_pred, r = r_pred)

  # Jacobian of State Transition Model F
  F_mat <- diag(6)
  F_mat[1, 3] <- c_psi * dt
  F_mat[1, 4] <- -s_psi * dt
  F_mat[1, 5] <- (-u * s_psi - v * c_psi) * dt
  F_mat[2, 3] <- s_psi * dt
  F_mat[2, 4] <- c_psi * dt
  F_mat[2, 5] <- (u * c_psi - v * s_psi) * dt
  F_mat[5, 6] <- dt

  # Process Noise Covariance Q
  Q <- diag(c(0.05, 0.05, 0.1, 0.1, 0.005, 0.005)) * dt
  P_pred <- F_mat %*% covariance %*% t(F_mat) + Q

  # 2. Measurement Update
  # Active measurements based on health
  meas_vec <- numeric(0)
  H_rows <- list()
  R_diag <- numeric(0)

  if (!is.null(measurement$gnss_x) && sensor_health$gnss > 0.1) {
    meas_vec <- c(meas_vec, measurement$gnss_x, measurement$gnss_y)
    H_x <- c(1, 0, 0, 0, 0, 0)
    H_y <- c(0, 1, 0, 0, 0, 0)
    H_rows <- c(H_rows, list(H_x, H_y))
    # Noise scales inversely with health
    var_gnss <- (2.5 / sensor_health$gnss)^2
    R_diag <- c(R_diag, var_gnss, var_gnss)
  }

  if (!is.null(measurement$imu_yaw) && sensor_health$imu > 0.1) {
    meas_vec <- c(meas_vec, measurement$imu_yaw, measurement$imu_r)
    H_psi <- c(0, 0, 0, 0, 1, 0)
    H_r <- c(0, 0, 0, 0, 0, 1)
    H_rows <- c(H_rows, list(H_psi, H_r))
    var_yaw <- (0.015 / sensor_health$imu)^2
    var_r <- (0.005 / sensor_health$imu)^2
    R_diag <- c(R_diag, var_yaw, var_r)
  }

  if (!is.null(measurement$speed_over_ground)) {
    meas_vec <- c(meas_vec, measurement$speed_over_ground)
    H_sog <- c(0, 0, 1, 0, 0, 0)
    H_rows <- c(H_rows, list(H_sog))
    R_diag <- c(R_diag, 0.25^2)
  }

  if (length(meas_vec) == 0) {
    # Pure dead reckoning
    return(list(
      estimate = state_pred,
      covariance = P_pred,
      innovation = numeric(0),
      confidence = 0.3
    ))
  }

  H <- do.call(rbind, H_rows)
  R <- diag(R_diag, nrow = length(R_diag))

  # Predicted measurement z_pred = H * state_pred
  z_pred <- H %*% state_pred
  
  # Innovation residual y_res
  y_res <- meas_vec - z_pred

  # Wrap angle innovation if psi was measured
  if (!is.null(measurement$imu_yaw) && sensor_health$imu > 0.1) {
    psi_idx <- 3
    y_res[psi_idx] <- (y_res[psi_idx] + pi) %% (2 * pi) - pi
  }

  # Innovation covariance S = H P H' + R
  S <- H %*% P_pred %*% t(H) + R
  
  # Kalman Gain K = P H' S^-1
  K <- P_pred %*% t(H) %*% solve(S)

  # Posterior state and covariance
  state_post <- state_pred + as.vector(K %*% y_res)
  state_post["psi"] <- state_post["psi"] %% (2 * pi)
  P_post <- (diag(6) - K %*% H) %*% P_pred

  return(list(
    estimate = state_post,
    covariance = P_post,
    innovation = as.vector(y_res),
    confidence = min(1.0, mean(unlist(sensor_health)))
  ))
}
