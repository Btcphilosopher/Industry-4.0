#' Model Predictive Control (MPC) and Candidate Trajectory Scoring for Hovercraft
#'
#' @description Solves finite-horizon optimal control inputs (thrust differential, rudder, lift)
#' subject to hovercraft aerodynamic drift, actuator slew rates, and multi-objective costs.
#'
#' @param current_state Current state vector [x, y, u, v, psi, r]
#' @param reference_waypoint Waypoint coordinates c(x, y, target_speed)
#' @param obstacle_tracks List of tracked dynamic targets with predicted positions
#' @param horizon_steps Prediction horizon in steps (default 10 steps = 5.0 seconds)
#' @param dt Step size in seconds (default 0.5s)
#' @return List containing optimal control vector, predicted trajectory, and scored candidate trajectories
#' @export
mpc_controller <- function(current_state, reference_waypoint, obstacle_tracks = list(), horizon_steps = 10, dt = 0.5) {
  # Candidate control offsets for trajectory rollouts
  rudder_candidates <- c(-25, -15, -8, 0, 8, 15, 25) # degrees
  thrust_candidates <- c(40, 70, 95)                 # percent nominal
  
  scored_trajectories <- list()
  best_cost <- Inf
  best_control <- c(thrust_port = 70, thrust_stbd = 70, rudder_deg = 0, lift_pct = 100)
  best_trajectory <- NULL

  # Objective function weights (Configuration-driven)
  w_cross_track <- 2.5
  w_heading <- 1.8
  w_collision <- 12.0
  w_energy <- 0.4
  w_comfort <- 0.6

  # Heading to target waypoint
  dx_wp <- reference_waypoint$x - current_state["x"]
  dy_wp <- reference_waypoint$y - current_state["y"]
  target_heading <- atan2(dy_wp, dx_wp)

  for (rudder in rudder_candidates) {
    for (thrust in thrust_candidates) {
      # Forward rollout over prediction horizon
      sim_state <- current_state
      traj_points <- matrix(NA, nrow = horizon_steps, ncol = 3)
      colnames(traj_points) <- c("x", "y", "psi")
      
      step_cost <- 0
      min_dist_to_any_obs <- Inf

      for (k in 1:horizon_steps) {
        # Kinematic approximation for fast rollout
        u <- sim_state["u"]
        v <- sim_state["v"]
        psi <- sim_state["psi"]
        r <- sim_state["r"]

        # Rudder steering rate effect
        r_cmd <- (rudder * pi / 180) * 0.25
        r_new <- r + (r_cmd - r) * 0.4
        psi_new <- (psi + r_new * dt) %% (2 * pi)

        # Speed response to thrust
        u_target <- (thrust / 100) * 22.0 # ~42 knots max
        u_new <- u + (u_target - u) * 0.2

        x_new <- sim_state["x"] + (u_new * cos(psi_new) - v * sin(psi_new)) * dt
        y_new <- sim_state["y"] + (u_new * sin(psi_new) + v * cos(psi_new)) * dt

        sim_state <- c(x = x_new, y = y_new, u = u_new, v = v, psi = psi_new, r = r_new)
        traj_points[k, ] <- c(x_new, y_new, psi_new)

        # Distance to line segment (cross track error)
        dist_to_wp <- sqrt((reference_waypoint$x - x_new)^2 + (reference_waypoint$y - y_new)^2)
        step_cost <- step_cost + dist_to_wp * 0.05

        # Check collision risk with predicted obstacle positions
        for (obs in obstacle_tracks) {
          obs_x_at_k <- obs$x + obs$vx * (k * dt)
          obs_y_at_k <- obs$y + obs$vy * (k * dt)
          dist_obs <- sqrt((x_new - obs_x_at_k)^2 + (y_new - obs_y_at_k)^2)
          if (dist_obs < min_dist_to_any_obs) {
            min_dist_to_any_obs <- dist_obs
          }
        }
      }

      # Calculate trajectory cost
      heading_error <- abs(((psi_new - target_heading + pi) %% (2 * pi)) - pi)
      
      collision_cost <- if (min_dist_to_any_obs < 350) {
        1000.0 / (min_dist_to_any_obs + 10)
      } else if (min_dist_to_any_obs < 700) {
        50.0 / (min_dist_to_any_obs - 300)
      } else {
        0
      }

      energy_cost <- (thrust / 100)^2
      comfort_cost <- abs(rudder / 30)^2

      total_cost <- w_cross_track * step_cost +
                    w_heading * (heading_error * 180 / pi) +
                    w_collision * collision_cost +
                    w_energy * energy_cost +
                    w_comfort * comfort_cost

      candidate_info <- list(
        thrust = thrust,
        rudder = rudder,
        cost = round(total_cost, 2),
        min_obstacle_dist = round(min_dist_to_any_obs, 1),
        points = traj_points
      )
      scored_trajectories[[length(scored_trajectories) + 1]] <- candidate_info

      if (total_cost < best_cost) {
        best_cost <- total_cost
        best_control <- c(
          thrust_port = max(20, thrust - rudder * 0.5),
          thrust_stbd = max(20, thrust + rudder * 0.5),
          rudder_deg = rudder,
          lift_pct = 100
        )
        best_trajectory <- traj_points
      }
    }
  }

  return(list(
    optimal_control = best_control,
    optimal_trajectory = best_trajectory,
    optimal_cost = best_cost,
    candidates = scored_trajectories
  ))
}
