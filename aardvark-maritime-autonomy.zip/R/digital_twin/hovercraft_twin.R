#' Hovercraft Digital Twin & Predictive Maintenance Telemetry Comparator
#'
#' @description Maintains an isolated digital shadow of the physical hovercraft,
#' computing model-vs-actual residuals for vibration, aerodynamic cushion decay,
#' fuel burn deviations, and bearing temperature trends.
#'
#' @export
#' @import R6
HovercraftDigitalTwin <- R6::R6Class(
  "HovercraftDigitalTwin",
  public = list(
    vessel_id = NULL,
    model_version = "v3.6.2-synthetic-rc2",
    baseline_drag_coeff = 0.38,
    skirt_wear_index = 0.04, # 0.0 = factory new, 1.0 = worn out
    bearing_temp_c = 68.5,
    fan_vibration_rms_mm_s = 2.1,
    
    initialize = function(vessel_id = "A01") {
      self$vessel_id <- vessel_id
    },

    evaluate_telemetry_residuals = function(physical_telemetry, commanded_state) {
      # Compute discrepancy between physical readings and physics model predictions
      expected_speed <- commanded_state$target_speed_knots
      actual_speed <- physical_telemetry$speed_knots
      speed_residual <- actual_speed - expected_speed

      expected_fuel_rate <- (physical_telemetry$total_power_kw * 0.235) / 1000 # kg/s
      actual_fuel_rate <- physical_telemetry$fuel_flow_kg_s
      fuel_residual_pct <- ((actual_fuel_rate - expected_fuel_rate) / expected_fuel_rate) * 100

      # Skirt wear degradation model
      skirt_pressure_residual <- physical_telemetry$cushion_pressure_kpa - 2.85
      if (skirt_pressure_residual < -0.3) {
        self$skirt_wear_index <- min(1.0, self$skirt_wear_index + 0.001)
      }

      # Mechanical vibration anomaly detection
      self$fan_vibration_rms_mm_s <- physical_telemetry$vibration_rms
      vibration_anomaly <- self$fan_vibration_rms_mm_s > 4.5

      # Thermal anomaly
      self$bearing_temp_c <- physical_telemetry$bearing_temp_c
      thermal_anomaly <- self$bearing_temp_c > 85.0

      status <- if (vibration_anomaly || thermal_anomaly) {
        "ANOMALY_DETECTED"
      } else if (self$skirt_wear_index > 0.4) {
        "MAINTENANCE_RECOMMENDED"
      } else {
        "OPTIMAL"
      }

      return(list(
        status = status,
        speed_residual_knots = round(speed_residual, 2),
        fuel_residual_pct = round(fuel_residual_pct, 1),
        skirt_wear_index = round(self$skirt_wear_index, 3),
        vibration_rms = self$fan_vibration_rms_mm_s,
        bearing_temp_c = self$bearing_temp_c,
        rUL_hours_remaining = round((1.0 - self$skirt_wear_index) * 2400) # Remaining Useful Life (RUL)
      ))
    }
  )
)
