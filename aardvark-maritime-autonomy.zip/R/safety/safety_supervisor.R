#' Independent Safety Supervisor and MASS Autonomy State Machine
#'
#' @description Implements an isolated, deterministic safety supervisory authority.
#' It verifies candidate trajectories against hard envelope limits, detects sensor failures,
#' and enforces failsafe state machine transitions under the 2026 IMO MASS Code.
#'
#' @export
#' @import R6
SafetySupervisor <- R6::R6Class(
  "SafetySupervisor",
  public = list(
    current_mode = "AUTONOMOUS", # MANUAL, ASSISTED, REMOTE, AUTONOMOUS, DEGRADED, EMERGENCY, SAFE_STOP, RETURN_TO_PORT
    active_alarms = list(),
    audit_trail = list(),
    operator_intervention_timeout = 30, # seconds
    time_since_last_heartbeat = 0,

    initialize = function(initial_mode = "AUTONOMOUS") {
      self$current_mode <- initial_mode
      self$active_alarms <- list()
      self$audit_trail <- list()
      self$log_event("INITIALIZED", paste("Safety Supervisor started in mode:", initial_mode))
    },

    evaluate_state = function(vessel_state, sensor_health, max_collision_risk, comms_link_ok = TRUE, human_override = FALSE) {
      alarms <- list()
      new_mode <- self$current_mode
      action_intent <- "ALLOW"
      speed_knots <- vessel_state$speed_knots
      cushion_press <- vessel_state$cushion_pressure_kpa

      # 1. Human override priority
      if (human_override) {
        new_mode <- "REMOTE"
        action_intent <- "HUMAN_CONTROL"
        self$log_event("MODE_TRANSITION", "Human remote operator assumed control authority.")
        self$current_mode <- new_mode
        return(list(mode = new_mode, intent = action_intent, alarms = alarms))
      }

      # 2. Check Communication Link Health
      if (!comms_link_ok && self$current_mode == "REMOTE") {
        alarms[[length(alarms) + 1]] <- "CRITICAL: Remote comms link lost. Reverting to Autonomous Safe Failsafe."
        new_mode <- "AUTONOMOUS"
      }

      # 3. Sensor Health & Degradation Check
      primary_sensors_avg <- (sensor_health$gnss + sensor_health$imu + sensor_health$radar) / 3
      if (primary_sensors_avg < 0.4 || sensor_health$gnss < 0.2) {
        alarms[[length(alarms) + 1]] <- "WARNING: Primary GNSS/Radar degraded. Engaging dead-reckoning filters."
        if (new_mode == "AUTONOMOUS") {
          new_mode <- "DEGRADED"
          action_intent <- "SLOW"
        }
      }

      # 4. Hover Cushion Envelope Check
      if (!is.null(cushion_press) && cushion_press < 1.8) {
        alarms[[length(alarms) + 1]] <- "CRITICAL: Skirt pressure below aerodynamic threshold! Vessel hull contact risk."
        new_mode <- "EMERGENCY"
        action_intent <- "SAFE_STOP"
      }

      # 5. Collision Danger & Safety Supervisor Veto
      if (max_collision_risk$risk_level == "CRITICAL" && max_collision_risk$tcpa < 60) {
        alarms[[length(alarms) + 1]] <- "SAFETY SUPERVISOR VETO: Imminent CPA violation. Overriding planner with emergency hard avoidance."
        action_intent <- "REPLAN"
        if (max_collision_risk$tcpa < 25) {
          action_intent <- "STOP"
        }
      }

      # State transition logging
      if (new_mode != self$current_mode) {
        self$log_event("MODE_TRANSITION", paste("Transition from", self$current_mode, "to", new_mode))
        self$current_mode <- new_mode
      }

      self$active_alarms <- alarms
      return(list(
        mode = self$current_mode,
        action_intent = action_intent,
        alarms = alarms,
        safety_status = if (length(alarms) == 0) "NOMINAL" else if (new_mode == "EMERGENCY") "HAZARDOUS" else "DEGRADED"
      ))
    },

    log_event = function(event_type, description) {
      event_entry <- list(
        timestamp = Sys.time(),
        event_type = event_type,
        description = description,
        mode = self$current_mode
      )
      self$audit_trail[[length(self$audit_trail) + 1]] <- event_entry
    }
  )
)
