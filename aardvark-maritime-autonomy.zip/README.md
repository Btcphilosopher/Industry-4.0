# AARDVARK MARITIME AUTONOMY
## Autonomous Navigation, Control, Digital Twin & Fleet Intelligence for Freight Hovercraft

**Aardvark Maritime Autonomy** is a research-grade computational navigation, simulation, and digital-twin platform developed for heavy freight hovercraft operating in commercial maritime logistics.

```
VESSEL → ENVIRONMENT → SENSORS → PERCEPTION → LOCALISATION → WORLD MODEL 
→ COLLISION RISK → ROUTE → TRAJECTORY → CONTROL (MPC) → PROPULSION 
→ HOVERCRAFT MOTION → TELEMETRY → LEARNING → SAFETY SUPERVISOR → REMOTE OPERATIONS
```

### Key Engineering Capabilities
1. **6-Degree-of-Freedom Hovercraft Dynamics**: Explicit equations of motion for surge, sway, yaw, heave, roll, and pitch with cushion pressure dynamics, skirt air leakage, and differential ducted fan thrust.
2. **Multi-Sensor Fusion (EKF/UKF)**: Fuses GNSS, IMU, Marine Radar, LiDAR, and AIS with active covariance tracking and sensor degradation handling.
3. **COLREGs Reasoning & CPA/TCPA**: Evaluates Rule 13 (Overtaking), Rule 14 (Head-on), Rule 15 (Crossing), and Rule 18 with multi-factor risk quantification.
4. **Model Predictive Control (MPC)**: Finite-horizon trajectory optimization solving differential thrust, aerodynamic rudders, and lift fan power.
5. **Deterministic Safety Supervisor**: Independent authority implementing the 2026 IMO MASS Code state machine (`AUTONOMOUS`, `REMOTE`, `DEGRADED`, `EMERGENCY`, `SAFE_STOP`).
6. **Digital Twin Telemetry Comparator**: Real-time residual tracking for vibration anomalies, bearing temperature divergence, and skirt wear prediction.
7. **Monte Carlo Safety Verification**: Stochastic scenario generation testing confidence intervals for collision avoidance and mission completion.

---
*Notice: This is a synthetic engineering research project inspired by publicly observable characteristics of commercial maritime logistics and hovercraft physics. It is NOT BP internal software and utilizes synthetic vessel, route, and environmental data.*
