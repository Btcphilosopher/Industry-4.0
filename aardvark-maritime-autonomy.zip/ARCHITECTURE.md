# System Architecture & Technical Specifications

```
                     ┌───────────────────────────────────────────────┐
                     │            Synthetic Environment              │
                     │  (Wind Field, Surface Currents, Sea State)    │
                     └───────────────────────┬───────────────────────┘
                                             │
                                             ▼
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                               6-DOF Hovercraft Model                                   │
│  State: [x, y, z, u, v, w, φ, θ, ψ, p, q, r] | Cushion Area: 240 m² | Mass: 70 tonnes  │
└────────────────────────────────────────────┬───────────────────────────────────────────┘
                                             │
                                             ▼
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                                 Sensor Simulation Suite                                │
│   GNSS (RTK/Standard) | 9-DOF IMU | 360° Marine Radar | LiDAR Scanner | AIS Transceiver│
│   (Fault Injection: Multipath, Bias, Noise, Packet Loss, Jamming, Spoofing)            │
└────────────────────────────────────────────┬───────────────────────────────────────────┘
                                             │
                                             ▼
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                        State Estimation & Sensor Fusion (EKF)                          │
│          x̂ = f(x, u) | P = F P Fᵀ + Q | K = P Hᵀ (H P Hᵀ + R)⁻¹ | y = z - H x̂          │
└────────────────────────────────────────────┬───────────────────────────────────────────┘
                                             │
                                             ▼
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                      Maritime World Model & Multi-Target Tracker                       │
│    Track Initiation → Gating → Nearest Neighbour Association → Kalman Filtering        │
└────────────────────────────────────────────┬───────────────────────────────────────────┘
                                             │
                                             ▼
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                       Collision Risk Engine (CPA / TCPA / DCPA)                        │
│          TCPA = - (r · v_rel) / |v_rel|² | CPA = |r + v_rel · TCPA|                    │
└────────────────────────────────────────────┬───────────────────────────────────────────┘
                                             │
                                             ▼
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                     COLREGs Encounter Reasoning & Navigation Role                      │
│             Rule 13 (Overtaking) | Rule 14 (Head-on) | Rule 15 (Crossing)              │
└────────────────────────────────────────────┬───────────────────────────────────────────┘
                                             │
                                             ▼
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                     Model Predictive Trajectory Controller (MPC)                       │
│         min J = w_ct · C_ct + w_hdg · C_hdg + w_col · C_col + w_eng · C_eng            │
└────────────────────────────────────────────┬───────────────────────────────────────────┘
                                             │
                                             ▼
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                         Independent Safety Supervisor (MASS)                           │
│  States: MANUAL | ASSISTED | REMOTE | AUTONOMOUS | DEGRADED | EMERGENCY | SAFE_STOP    │
│  Supervisor Veto & Emergency Envelope Enforcer (Cannot be overridden by AI/Planner)    │
└────────────────────────────────────────────────────────────────────────────────────────┘
```
