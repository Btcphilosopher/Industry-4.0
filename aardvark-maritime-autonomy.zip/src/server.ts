import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { join } from 'node:path';
import { GoogleGenAI } from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());

const angularApp = new AngularNodeAppEngine();

let aiClient: GoogleGenAI | null = null;
function getAiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env['GEMINI_API_KEY'];
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY environment variable is missing.');
    }
    aiClient = new GoogleGenAI({ apiKey });
  }
  return aiClient;
}

app.post('/api/gemini/copilot', async (req, res) => {
  try {
    const { question, context } = req.body;
    const apiKey = process.env['GEMINI_API_KEY'];

    if (!apiKey) {
      return res.status(503).json({
        error: 'API_KEY_MISSING',
        answer: null,
      });
    }

    const ai = getAiClient();
    const systemInstruction = `You are the AI Maritime Safety Officer & Navigation Co-Pilot on board the Aardvark Heavy Freight Hovercraft.
You are an expert in COLREGs (International Regulations for Preventing Collisions at Sea 1972), 6-DOF Hovercraft Aerodynamics, Sensor Fusion (EKF), Model Predictive Control (MPC), and Digital Twin Prognostics.

Current Telemetry Context:
- Autonomy Mode: ${context?.supervisor?.currentMode || 'AUTONOMOUS'}
- Speed: ${context?.telemetry?.speedKnots || 0} knots, Heading: ${context?.telemetry?.headingDeg || 0}°
- Cushion Pressure: ${context?.telemetry?.cushionPressureKpa || 0} kPa, Bearing Temp: ${context?.telemetry?.bearingTempC || 0}°C, Skirt Wear: ${context?.telemetry?.skirtWearIndex || 0}
- Weather: Sea State Beaufort ${context?.env?.seaState || 0}, Wave Height: ${context?.env?.waveHeightM || 0}m, Wind: ${context?.env?.windSpeedKnots || 0} kts
- Radar/AIS Targets: ${JSON.stringify(context?.targets || [])}
- Active Alarms: ${JSON.stringify(context?.supervisor?.alarms || [])}

Provide clear, professional, concise, authoritative maritime navigation & safety advice. Reference specific COLREGs rules (e.g. Rule 13, 14, 15, 18), CPA/TCPA distances, or mechanical diagnostic recommendations where applicable. Use Markdown formatting.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: question,
      config: {
        systemInstruction,
        temperature: 0.3,
      },
    });

    return res.json({ answer: response.text });
  } catch (err: unknown) {
    const errorObj = err as Error;
    console.error('Gemini Copilot Error:', errorObj?.message || err);
    return res.status(500).json({ error: errorObj?.message || 'Failed to call Gemini API' });
  }
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  })
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next()
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 3000;
  app.listen(port, () => {
    console.log(`Node Express server listening on http://0.0.0.0:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
