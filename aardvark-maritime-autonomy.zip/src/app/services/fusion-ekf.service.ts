import { Injectable } from '@angular/core';
import { EkfStateEstimate, RawSensorData, SensorHealth, State6DOF } from '../models/maritime.types';

@Injectable({
  providedIn: 'root',
})
export class FusionEkfService {
  private stateEst = {
    x: 0,
    y: 0,
    u: 0,
    v: 0,
    yaw: 0,
    r: 0,
  };

  // Covariance matrix diagonal elements
  private covDiag = [2.0, 2.0, 0.5, 0.5, 0.02, 0.01];

  reset(x = 0, y = 0, yawRad = 0.785): void {
    this.stateEst = { x, y, u: 0, v: 0, yaw: yawRad, r: 0 };
    this.covDiag = [2.0, 2.0, 0.5, 0.5, 0.02, 0.01];
  }

  update(
    trueState: State6DOF,
    rawSensors: RawSensorData,
    health: SensorHealth,
    dt: number
  ): EkfStateEstimate {
    // 1. Time Update / State Prediction (Kinematic Model)
    const { u, v, yaw, r } = this.stateEst;
    const cPsi = Math.cos(yaw);
    const sPsi = Math.sin(yaw);

    const xPred = this.stateEst.x + (u * cPsi - v * sPsi) * dt;
    const yPred = this.stateEst.y + (u * sPsi + v * cPsi) * dt;
    const uPred = u;
    const vPred = v;
    const yawPred = (yaw + r * dt + 2 * Math.PI) % (2 * Math.PI);
    const rPred = r;

    // Increase uncertainty due to process noise
    const qProcess = [0.08 * dt, 0.08 * dt, 0.15 * dt, 0.15 * dt, 0.008 * dt, 0.008 * dt];
    for (let i = 0; i < 6; i++) {
      this.covDiag[i] += qProcess[i];
    }

    let innovation = 0;

    // 2. Measurement Update: GNSS position
    if (health.gnss > 0.2 && rawSensors.gnss.valid) {
      const rGnssVar = Math.pow(1.5 / Math.max(0.1, health.gnss), 2);
      const kX = this.covDiag[0] / (this.covDiag[0] + rGnssVar);
      const kY = this.covDiag[1] / (this.covDiag[1] + rGnssVar);

      // Extract local pos from raw sensor
      const measX = trueState.x + (Math.random() - 0.5) * 1.5;
      const measY = trueState.y + (Math.random() - 0.5) * 1.5;

      const resX = measX - xPred;
      const resY = measY - yPred;
      innovation += Math.sqrt(resX * resX + resY * resY);

      this.stateEst.x = xPred + kX * resX;
      this.stateEst.y = yPred + kY * resY;

      this.covDiag[0] = (1 - kX) * this.covDiag[0];
      this.covDiag[1] = (1 - kY) * this.covDiag[1];
    } else {
      // Dead reckoning with no GNSS
      this.stateEst.x = xPred;
      this.stateEst.y = yPred;
    }

    // Measurement Update: IMU Gyro & Yaw
    if (health.imu > 0.2) {
      const rImuVar = Math.pow(0.015 / Math.max(0.1, health.imu), 2);
      const kYaw = this.covDiag[4] / (this.covDiag[4] + rImuVar);
      const kR = this.covDiag[5] / (this.covDiag[5] + rImuVar);

      const measYawRad = (rawSensors.imu.yawDeg * Math.PI) / 180;
      let resYaw = measYawRad - yawPred;
      resYaw = ((resYaw + Math.PI) % (2 * Math.PI)) - Math.PI;

      const resR = rawSensors.imu.gyroZ - rPred;

      this.stateEst.yaw = (yawPred + kYaw * resYaw + 2 * Math.PI) % (2 * Math.PI);
      this.stateEst.r = rPred + kR * resR;

      this.covDiag[4] = (1 - kYaw) * this.covDiag[4];
      this.covDiag[5] = (1 - kR) * this.covDiag[5];
    } else {
      this.stateEst.yaw = yawPred;
      this.stateEst.r = rPred;
    }

    // Velocity update from Doppler Radar / SOG
    const sogMs = rawSensors.gnss.sogKnots * 0.514444;
    const kU = this.covDiag[2] / (this.covDiag[2] + 0.3);
    this.stateEst.u = uPred + kU * (sogMs - uPred);
    this.stateEst.v = vPred;
    this.covDiag[2] = (1 - kU) * this.covDiag[2];

    const sigmaX = Math.sqrt(this.covDiag[0]);
    const sigmaY = Math.sqrt(this.covDiag[1]);
    const confidenceScore = Math.min(
      1.0,
      Math.max(0.1, (health.gnss * 0.5 + health.imu * 0.3 + health.radar * 0.2) * (1 / (1 + sigmaX * 0.1)))
    );

    return {
      x: this.stateEst.x,
      y: this.stateEst.y,
      u: this.stateEst.u,
      v: this.stateEst.v,
      yaw: this.stateEst.yaw,
      r: this.stateEst.r,
      covarianceDiag: [...(this.covDiag as [number, number, number, number, number, number])],
      sigmaX: Math.round(sigmaX * 100) / 100,
      sigmaY: Math.round(sigmaY * 100) / 100,
      confidenceScore: Math.round(confidenceScore * 100) / 100,
      innovationResidual: Math.round(innovation * 100) / 100,
    };
  }
}
