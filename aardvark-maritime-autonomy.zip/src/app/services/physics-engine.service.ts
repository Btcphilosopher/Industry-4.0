import { Injectable } from '@angular/core';
import { ControlVector, EnvironmentState, HovercraftSpecs, State6DOF, Telemetry } from '../models/maritime.types';

@Injectable({
  providedIn: 'root',
})
export class PhysicsEngineService {
  readonly specs: HovercraftSpecs = {
    id: 'A01',
    name: 'Aardvark Heavy Freighter A01 (Synthetic Logistics)',
    fleetId: 'AARDVARK-UK-FLEET-NORTHSEA',
    length: 28.5,
    beam: 12.0,
    height: 6.8,
    massEmptyKg: 45000,
    massCargoKg: 25000,
    totalMassKg: 70000,
    cushionAreaM2: 240.0,
    skirtHeightM: 1.4,
    skirtPerimeterM: 75.0,
    nominalCushionPressPa: 2850,
    liftPowerKw: 1200,
    propulsionPowerKw: 2400,
    fuelCapacityL: 8000,
    batteryCapacityKwh: 350,
    maxSpeedKnots: 48.0,
    cruisingSpeedKnots: 38.0,
    minControlSpeedKnots: 4.0,
    turningRadiusM: 180.0,
  };

  private state: State6DOF = {
    x: 0,
    y: 0,
    z: 1.25,
    u: 0,
    v: 0,
    w: 0,
    roll: 0,
    pitch: 0,
    yaw: 0,
    p: 0,
    q: 0,
    r: 0,
  };

  private fuelRemainingL = 7200;
  private batterySoc = 0.94;
  private skirtWear = 0.038;
  private vibrationRms = 2.1;
  private bearingTemp = 67.4;

  getState(): State6DOF {
    return { ...this.state };
  }

  setState(newState: Partial<State6DOF>): void {
    this.state = { ...this.state, ...newState };
  }

  reset(x = 0, y = 0, headingDeg = 45, cargoKg = 25000): void {
    this.specs.massCargoKg = cargoKg;
    this.specs.totalMassKg = this.specs.massEmptyKg + cargoKg;
    this.state = {
      x,
      y,
      z: 1.25,
      u: 0,
      v: 0,
      w: 0,
      roll: 0,
      pitch: 0,
      yaw: (headingDeg * Math.PI) / 180,
      p: 0,
      q: 0,
      r: 0,
    };
    this.fuelRemainingL = 7200;
    this.batterySoc = 0.94;
    this.skirtWear = 0.038;
    this.vibrationRms = 2.1;
    this.bearingTemp = 67.4;
  }

  integrateStep(dt: number, control: ControlVector, env: EnvironmentState, skirtDegraded = false, propulsionDegraded = false): { state: State6DOF; telemetry: Telemetry } {
    const rhoAir = 1.225; // kg/m3
    const g = 9.80665;
    const mass = this.specs.totalMassKg;
    const { u, v, yaw, r } = this.state;

    // Environmental Wind Vector
    const windSpeedMs = env.windSpeedKnots * 0.514444;
    const windDirRad = (env.windDirDeg * Math.PI) / 180;
    const vWindX = windSpeedMs * Math.cos(windDirRad);
    const vWindY = windSpeedMs * Math.sin(windDirRad);

    // Apparent relative wind in body coordinates
    const uRel = u - (vWindX * Math.cos(yaw) + vWindY * Math.sin(yaw));
    const vRel = v - (-vWindX * Math.sin(yaw) + vWindY * Math.cos(yaw));

    // Aerodynamic Drag on Hovercraft Superstructure
    const cdX = 0.38;
    const cdY = 0.75;
    const frontalArea = this.specs.beam * this.specs.height;
    const lateralArea = this.specs.length * this.specs.height;
    const fAeroX = -0.5 * rhoAir * cdX * frontalArea * uRel * Math.abs(uRel);
    const fAeroY = -0.5 * rhoAir * cdY * lateralArea * vRel * Math.abs(vRel);

    // Cushion Aerodynamics & Skirt Hydrodynamic Interaction
    const liftPctEffective = (control.liftPct / 100) * (skirtDegraded ? 0.65 : 1.0);
    const cushionPressurePa = this.specs.nominalCushionPressPa * liftPctEffective;
    const cushionGap = Math.max(0.01, this.state.z - this.specs.skirtHeightM);
    const skirtFrictionCoeff = (0.018 / (cushionGap + 0.05)) * (1.0 + env.waveHeightM * 0.3);
    const fSkirtX = -skirtFrictionCoeff * mass * g * Math.tanh(u / 2);
    const fSkirtY = -skirtFrictionCoeff * mass * g * Math.tanh(v / 2);

    // Propulsion Forces (Twin Variable-Pitch Ducted Propellers: Max 60 kN each)
    const maxThrustPerProp = (propulsionDegraded ? 35000 : 60000);
    const thrustPortN = (control.thrustPortPct / 100) * maxThrustPerProp;
    const thrustStbdN = (control.thrustStbdPct / 100) * maxThrustPerProp;
    const rudderRad = (control.rudderDeg * Math.PI) / 180;
    const bowThrusterN = (control.bowThrusterPct / 100) * 16000;

    const totalPropThrustN = thrustPortN + thrustStbdN;
    const thrustBodyX = totalPropThrustN * Math.cos(rudderRad);
    const thrustBodyY = totalPropThrustN * Math.sin(rudderRad) + bowThrusterN;

    // Yaw Moment: Differential Thrust + Aerodynamic Rudders + Bow Thruster
    const fanMomentArmM = (this.specs.beam / 2) * 0.72;
    const rudderLeverArmM = this.specs.length * 0.44;
    const bowThrusterArmM = this.specs.length * 0.45;
    const momentDiffThrust = (thrustStbdN - thrustPortN) * fanMomentArmM;
    const momentRudder = -totalPropThrustN * Math.sin(rudderRad) * rudderLeverArmM;
    const momentBow = bowThrusterN * bowThrusterArmM;
    const totalYawMoment = momentDiffThrust + momentRudder + momentBow;

    // Tidal Current Drift in High Waves (partial hull contact)
    const currentSpeedMs = env.currentSpeedKnots * 0.514444;
    const currentDirRad = (env.currentDirDeg * Math.PI) / 180;
    const currentRelativeAngle = currentDirRad - yaw;
    const currentDragX = -280 * (u - currentSpeedMs * Math.cos(currentRelativeAngle));
    const currentDragY = -520 * (v - currentSpeedMs * Math.sin(currentRelativeAngle));

    // Moment of Inertia Izz around vertical axis
    const iZz = (1 / 12) * mass * (Math.pow(this.specs.length, 2) + Math.pow(this.specs.beam, 2));

    // Equations of 2D horizontal motion with Coriolis/centrifugal acceleration
    const uDot = (thrustBodyX + fAeroX + fSkirtX + currentDragX) / mass + v * r;
    const vDot = (thrustBodyY + fAeroY + fSkirtY + currentDragY) / mass - u * r;
    const rDot = (totalYawMoment - 0.28 * iZz * r * Math.abs(r)) / iZz;

    // Numerical Integration (RK2 / Euler)
    const uNew = u + uDot * dt;
    const vNew = v + vDot * dt;
    const rNew = r + rDot * dt;

    const yawNew = (yaw + rNew * dt + 2 * Math.PI) % (2 * Math.PI);
    const xDot = uNew * Math.cos(yawNew) - vNew * Math.sin(yawNew);
    const yDot = uNew * Math.sin(yawNew) + vNew * Math.cos(yawNew);

    const xNew = this.state.x + xDot * dt;
    const yNew = this.state.y + yDot * dt;

    // Hover Dynamic Variations
    const rollAngle = -0.04 * (vNew / (Math.abs(uNew) + 1.5)) - (control.rudderDeg * 0.002);
    const pitchAngle = 0.015 * (uDot / g) + 0.01 * (1 - liftPctEffective);
    const heaveHeight = 1.25 + 0.15 * Math.sin(Date.now() * 0.002) * env.waveHeightM;

    this.state = {
      x: xNew,
      y: yNew,
      z: heaveHeight,
      u: uNew,
      v: vNew,
      w: 0,
      roll: rollAngle,
      pitch: pitchAngle,
      yaw: yawNew,
      p: 0,
      q: 0,
      r: rNew,
    };

    // Energy & Telemetry Calculations
    const totalPowerKw =
      ((Math.abs(thrustPortN) + Math.abs(thrustStbdN)) / 1000) * 1.8 +
      this.specs.liftPowerKw * liftPctEffective +
      Math.abs(control.bowThrusterPct) * 15;

    const fuelFlowLPerHour = (totalPowerKw * 0.22) / 0.85; // ~220g/kWh, density 0.85
    this.fuelRemainingL = Math.max(0, this.fuelRemainingL - (fuelFlowLPerHour / 3600) * dt);
    this.batterySoc = Math.max(0.1, this.batterySoc - (0.000005 * totalPowerKw * dt));

    // Telemetry Mechanical Condition
    if (skirtDegraded) {
      this.skirtWear = Math.min(1.0, this.skirtWear + 0.0002 * dt);
      this.vibrationRms = 4.8 + Math.random() * 0.6;
    } else {
      this.vibrationRms = 2.0 + (Math.abs(uNew) / 25) * 0.8 + Math.random() * 0.2;
    }

    this.bearingTemp = 65.0 + (totalPowerKw / 2500) * 22.0 + (propulsionDegraded ? 15.0 : 0);

    const speedMs = Math.sqrt(uNew * uNew + vNew * vNew);
    const speedKnots = speedMs / 0.514444;
    const headingDeg = (yawNew * 180) / Math.PI;
    const courseRad = Math.atan2(yDot, xDot);
    const courseDeg = ((courseRad * 180) / Math.PI + 360) % 360;
    const driftAngleDeg = ((courseDeg - headingDeg + 540) % 360) - 180;

    const telemetry: Telemetry = {
      speedKnots: Math.round(speedKnots * 10) / 10,
      headingDeg: Math.round(headingDeg * 10) / 10,
      courseDeg: Math.round(courseDeg * 10) / 10,
      driftAngleDeg: Math.round(driftAngleDeg * 10) / 10,
      cushionPressureKpa: Math.round((cushionPressurePa / 1000) * 100) / 100,
      liftFanRpm: Math.round(1800 * liftPctEffective),
      portFanRpm: Math.round(1450 * (control.thrustPortPct / 100)),
      stbdFanRpm: Math.round(1450 * (control.thrustStbdPct / 100)),
      fuelRemainingL: Math.round(this.fuelRemainingL),
      fuelFlowLPerHour: Math.round(fuelFlowLPerHour * 10) / 10,
      batterySocPct: Math.round(this.batterySoc * 100),
      totalPowerKw: Math.round(totalPowerKw),
      vibrationRmsMmS: Math.round(this.vibrationRms * 100) / 100,
      bearingTempC: Math.round(this.bearingTemp * 10) / 10,
      skirtWearIndex: Math.round(this.skirtWear * 1000) / 1000,
    };

    return { state: { ...this.state }, telemetry };
  }
}
