import { Injectable } from '@angular/core';
import { DecisionAuditEvent } from '../models/maritime.types';

@Injectable({
  providedIn: 'root',
})
export class DecisionAuditService {
  private events: DecisionAuditEvent[] = [];

  logEvent(event: Omit<DecisionAuditEvent, 'eventId' | 'timestamp'>): DecisionAuditEvent {
    const fullEvent: DecisionAuditEvent = {
      ...event,
      eventId: `AUD-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: Date.now(),
    };
    this.events.unshift(fullEvent);
    if (this.events.length > 200) {
      this.events = this.events.slice(0, 200);
    }
    return fullEvent;
  }

  getEvents(): DecisionAuditEvent[] {
    return [...this.events];
  }

  clear(): void {
    this.events = [];
  }

  exportJson(): string {
    return JSON.stringify(this.events, null, 2);
  }

  exportRScript(): string {
    return `# Aardvark Hovercraft Safety Case Audit Importer & Analysis Script
# Generated automatically by Aardvark Maritime Autonomy Platform

library(jsonlite)
library(dplyr)
library(ggplot2)

# Load JSON Audit Log
audit_data <- fromJSON('aardvark_audit_log.json')

cat("Loaded", nrow(audit_data), "autonomy decision audit records.\\n")

# Summary of Autonomy Modes & Events
event_summary <- audit_data %>%
  group_by(eventType, autonomyMode) %>%
  summarise(count = n(), .groups = 'drop')

print(event_summary)

# Plot Risk Score vs Command Rudder Angle
ggplot(audit_data$causalSnapshot, aes(x = maxRiskScore, y = commandRudder)) +
  geom_point(aes(color = factor(activeAlarmsCount)), size = 3, alpha = 0.7) +
  theme_minimal() +
  labs(title = "Hovercraft Control Response vs Encounter Risk",
       x = "Maximum COLREGs Risk Score (0 - 1)",
       y = "Command Rudder Angle (Deg)")
`;
  }
}
