import { Injectable } from '@angular/core';
import { ColregsSituation, EkfStateEstimate, RiskLevel, WorldObject } from '../models/maritime.types';

@Injectable({
  providedIn: 'root',
})
export class CollisionRiskService {
  evaluateCollisionRisk(
    ownShip: EkfStateEstimate,
    ownSpeedKnots: number,
    target: WorldObject
  ): {
    cpaM: number;
    tcpaS: number;
    riskLevel: RiskLevel;
    riskScore: number;
    colregsSituation: ColregsSituation;
    navigationRole: 'GIVE_WAY' | 'STAND_ON' | 'NEUTRAL';
    ruleReference: string;
    actionAdvice: string;
  } {
    const ownVx = ownShip.u * Math.cos(ownShip.yaw) - ownShip.v * Math.sin(ownShip.yaw);
    const ownVy = ownShip.u * Math.sin(ownShip.yaw) + ownShip.v * Math.cos(ownShip.yaw);

    const rx = target.x - ownShip.x;
    const ry = target.y - ownShip.y;
    const distanceM = Math.sqrt(rx * rx + ry * ry);

    const vrx = target.vx - ownVx;
    const vry = target.vy - ownVy;
    const relSpeedSq = vrx * vrx + vry * vry;

    let tcpaS = 0;
    let cpaM = distanceM;

    if (relSpeedSq > 1e-4) {
      const dotProduct = rx * vrx + ry * vry;
      tcpaS = -dotProduct / relSpeedSq;

      if (tcpaS > 0) {
        const cpaX = rx + vrx * tcpaS;
        const cpaY = ry + vry * tcpaS;
        cpaM = Math.sqrt(cpaX * cpaX + cpaY * cpaY);
      } else {
        cpaM = distanceM;
      }
    }

    // Relative Bearing (0 to 360 deg relative to own heading)
    const ownHeadingDeg = (ownShip.yaw * 180) / Math.PI;
    const trueBearingDeg = ((Math.atan2(ry, rx) * 180) / Math.PI + 360) % 360;
    const relBearingDeg = (trueBearingDeg - ownHeadingDeg + 360) % 360;

    // Course difference
    const courseDiffDeg = (target.courseDeg - ownHeadingDeg + 360) % 360;

    // Multi-factor Risk Score: CPA threshold (750m) and TCPA (<180s)
    const safeCpaM = 750;
    const cpaFactor = Math.max(0, 1 - cpaM / safeCpaM);
    const tcpaFactor = tcpaS > 0 && tcpaS < 450 ? Math.max(0, 1 - tcpaS / 450) : 0;
    const distanceFactor = Math.max(0, 1 - distanceM / 4000);

    const riskScore = Math.min(1.0, 0.5 * cpaFactor + 0.3 * tcpaFactor + 0.2 * distanceFactor);

    let riskLevel: RiskLevel = 'LOW';
    if (riskScore > 0.75 && tcpaS > 0 && tcpaS < 150) {
      riskLevel = 'CRITICAL';
    } else if (riskScore > 0.45 && tcpaS > 0) {
      riskLevel = 'HIGH';
    } else if (riskScore > 0.22 && tcpaS > 0) {
      riskLevel = 'MODERATE';
    }

    // COLREGs Situation Classification
    let colregsSituation: ColregsSituation = 'CLEAR';
    let navigationRole: 'GIVE_WAY' | 'STAND_ON' | 'NEUTRAL' = 'NEUTRAL';
    let ruleReference = 'Rule 2 (General Responsibility)';
    let actionAdvice = 'Maintain active multi-sensor watch; clear passing.';

    if (target.type === 'BUOY' || target.type === 'OBSTACLE' || target.type === 'SHALLOW_BANK') {
      colregsSituation = 'RESTRICTED_WATERS';
      navigationRole = 'GIVE_WAY';
      ruleReference = 'Rule 7 & 8 (Risk of Collision & Action to Avoid Collision)';
      actionAdvice = 'Navigate around stationary hazard maintaining at least 300m clearance.';
    } else if (target.type === 'FISHING_BOAT') {
      colregsSituation = 'SPECIAL_STATUS_VESSEL';
      navigationRole = 'GIVE_WAY';
      ruleReference = 'Rule 18 (Responsibilities Between Vessels)';
      actionAdvice = 'Give way to fishing vessel; alter course early to starboard.';
    } else if (relBearingDeg > 112.5 && relBearingDeg < 247.5 && target.speedKnots > ownSpeedKnots + 2) {
      colregsSituation = 'OVERTAKING_STAND_ON';
      navigationRole = 'STAND_ON';
      ruleReference = 'Rule 13 (Overtaking) & Rule 17 (Action by Stand-on Vessel)';
      actionAdvice = 'Target is overtaking own vessel. Maintain course and speed; monitor passing distance.';
    } else if ((courseDiffDeg < 45 || courseDiffDeg > 315) && ownSpeedKnots > target.speedKnots + 3 && (relBearingDeg < 45 || relBearingDeg > 315)) {
      colregsSituation = 'OVERTAKING_GIVE_WAY';
      navigationRole = 'GIVE_WAY';
      ruleReference = 'Rule 13 (Overtaking) & Rule 16 (Action by Give-way Vessel)';
      actionAdvice = 'Overtaking slower target. Keep well clear by passing to port or starboard with wide margin.';
    } else if (courseDiffDeg > 160 && courseDiffDeg < 200 && (relBearingDeg < 15 || relBearingDeg > 345)) {
      colregsSituation = 'HEAD_ON';
      navigationRole = 'GIVE_WAY';
      ruleReference = 'Rule 14 (Head-on Situation)';
      actionAdvice = 'Head-on encounter. Substantially alter course to STARBOARD so vessels pass port-to-port.';
    } else if (relBearingDeg >= 15 && relBearingDeg <= 112.5) {
      colregsSituation = 'CROSSING_GIVE_WAY';
      navigationRole = 'GIVE_WAY';
      ruleReference = 'Rule 15 (Crossing Situation - Target to Starboard)';
      actionAdvice = 'Target on Starboard side. Own ship must GIVE WAY; alter course to starboard and/or reduce speed.';
    } else if (relBearingDeg >= 247.5 && relBearingDeg <= 345) {
      colregsSituation = 'CROSSING_STAND_ON';
      navigationRole = 'STAND_ON';
      ruleReference = 'Rule 15 (Crossing Situation - Target to Port)';
      actionAdvice = 'Target on Port side. Own ship is STAND-ON; maintain course and speed while monitoring give-way vessel.';
    }

    return {
      cpaM: Math.round(cpaM),
      tcpaS: Math.round(tcpaS),
      riskLevel,
      riskScore: Math.round(riskScore * 100) / 100,
      colregsSituation,
      navigationRole,
      ruleReference,
      actionAdvice,
    };
  }
}
