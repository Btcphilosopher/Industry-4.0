import { Injectable } from '@angular/core';
import { ControlVector, DigitalTwinResiduals, HovercraftSpecs, Telemetry } from '../models/maritime.types';

@Injectable({
  providedIn: 'root',
})
export class DigitalTwinService {
  computeTwinResiduals(
    telemetry: Telemetry,
    control: ControlVector,
    specs: HovercraftSpecs
  ): DigitalTwinResiduals {
    // 1. Expected nominal speed based on total fan thrust
    const totalThrustPct = (control.thrustPortPct + control.thrustStbdPct) / 2;
    const nominalSpeedKnots = (totalThrustPct / 100) * specs.maxSpeedKnots * 0.9;
    const speedResidualKnots = Math.round((telemetry.speedKnots - nominalSpeedKnots) * 10) / 10;

    // 2. Expected cushion pressure vs actual
    const nominalPressureKpa = (specs.nominalCushionPressPa / 1000) * (control.liftPct / 100);
    const cushionPressureResidualKpa = Math.round((telemetry.cushionPressureKpa - nominalPressureKpa) * 100) / 100;

    // 3. Expected fuel flow
    const expectedFuelFlow = (telemetry.totalPowerKw * 0.22) / 0.85;
    const fuelResidualPct = Math.round(((telemetry.fuelFlowLPerHour - expectedFuelFlow) / Math.max(1, expectedFuelFlow)) * 100);

    // 4. Remaining Useful Life (RUL) estimation
    const skirtRulHours = Math.max(0, Math.round((1.0 - telemetry.skirtWearIndex) * 450));
    const bearingRulHours = Math.max(0, Math.round((105 - telemetry.bearingTempC) * 35));

    let anomalyDetected = false;
    let anomalyType: string | undefined = undefined;

    if (Math.abs(cushionPressureResidualKpa) > 0.6) {
      anomalyDetected = true;
      anomalyType = 'Cushion Pressure Loss / Skirt Tear';
    } else if (fuelResidualPct > 20) {
      anomalyDetected = true;
      anomalyType = 'Elevated Specific Fuel Consumption Anomaly';
    } else if (telemetry.vibrationRmsMmS > 4.5) {
      anomalyDetected = true;
      anomalyType = 'Fan Rotor Unbalance & High Bearing Vibration';
    }

    return {
      speedResidualKnots,
      fuelResidualPct,
      cushionPressureResidualKpa,
      vibrationRmsMmS: telemetry.vibrationRmsMmS,
      bearingTempC: telemetry.bearingTempC,
      skirtWearIndex: telemetry.skirtWearIndex,
      rulHoursRemaining: Math.min(skirtRulHours, bearingRulHours),
      anomalyDetected,
      anomalyType,
    };
  }
}
