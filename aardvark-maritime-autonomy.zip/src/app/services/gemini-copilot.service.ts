import { Injectable } from '@angular/core';
import { EkfStateEstimate, EnvironmentState, SafetySupervisorEvaluation, Telemetry, WorldObject } from '../models/maritime.types';

export interface CopilotMessage {
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
}

@Injectable({
  providedIn: 'root',
})
export class GeminiCopilotService {
  private chatHistory: CopilotMessage[] = [];

  getHistory(): CopilotMessage[] {
    return this.chatHistory;
  }

  async askCopilot(
    question: string,
    context: {
      ekf: EkfStateEstimate;
      telemetry: Telemetry;
      env: EnvironmentState;
      supervisor: SafetySupervisorEvaluation;
      targets: WorldObject[];
    }
  ): Promise<string> {
    const timeStr = new Date().toLocaleTimeString();
    this.chatHistory.push({ sender: 'user', text: question, timestamp: timeStr });

    try {
      const response = await fetch('/api/gemini/copilot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question,
          context,
        }),
      });

      if (!response.ok) {
        throw new Error(`Backend response status: ${response.status}`);
      }

      const data = await response.json();
      const answer = data.answer || 'No response returned from Gemini Copilot.';
      this.chatHistory.push({ sender: 'assistant', text: answer, timestamp: new Date().toLocaleTimeString() });
      return answer;
    } catch {
      // Fallback structured maritime co-pilot response if API key is not configured or network error occurs
      const fallbackAnswer = this.generateOfflineResponse(question, context);
      this.chatHistory.push({ sender: 'assistant', text: fallbackAnswer, timestamp: new Date().toLocaleTimeString() });
      return fallbackAnswer;
    }
  }

  private generateOfflineResponse(
    question: string,
    context: {
      ekf: EkfStateEstimate;
      telemetry: Telemetry;
      env: EnvironmentState;
      supervisor: SafetySupervisorEvaluation;
      targets: WorldObject[];
    }
  ): string {
    const q = question.toLowerCase();

    if (q.includes('colreg') || q.includes('collision') || q.includes('risk') || q.includes('tanker')) {
      const highRisk = context.targets.find(t => t.riskLevel === 'HIGH' || t.riskLevel === 'CRITICAL');
      if (highRisk) {
        return `⚠️ **COLREGs Collision Assessment**: Critical encounter detected with vessel **${highRisk.name}** (${highRisk.type}).\n\n- **CPA**: ${highRisk.cpaM} meters | **TCPA**: ${highRisk.tcpaS} seconds.\n- **Situation**: ${highRisk.colregsSituation} under ${highRisk.ruleReference}.\n- **Navigation Role**: Own craft is **${highRisk.navigationRole}**.\n- **Recommended Action**: ${highRisk.actionAdvice}`;
      } else {
        return `✅ **COLREGs Status**: All passing distances nominal. Closest target is ${context.targets[0]?.name || 'Clear'} at CPA ${context.targets[0]?.cpaM || 'N/A'}m. No immediate evasive action required.`;
      }
    }

    if (q.includes('rul') || q.includes('skirt') || q.includes('wear') || q.includes('bearing') || q.includes('health')) {
      return `🔧 **Digital Twin Diagnostic Brief**:\n- **Skirt Wear Index**: ${context.telemetry.skirtWearIndex} (Estimated RUL: ${Math.round((1 - context.telemetry.skirtWearIndex) * 450)} operating hours).\n- **Propeller Bearing Temp**: ${context.telemetry.bearingTempC}°C (Nominal ceiling: 95°C).\n- **Fan Rotor Vibration**: ${context.telemetry.vibrationRmsMmS} mm/s RMS.\n- **Maintenance Recommendation**: Cushion pressure retention is nominal at ${context.telemetry.cushionPressureKpa} kPa. Inspect skirt perimeter at next port turnaround.`;
    }

    if (q.includes('weather') || q.includes('sea state') || q.includes('wind') || q.includes('fog')) {
      return `🌊 **Environmental Briefing**:\n- **Sea State**: Beaufort ${context.env.seaState} (${context.env.waveHeightM}m wave height, ${context.env.wavePeriodS}s period).\n- **Wind**: ${context.env.windSpeedKnots} knots from ${context.env.windDirDeg}°.\n- **Visibility**: ${context.env.visibilityNm} NM (Fog density: ${Math.round(context.env.fogDensity * 100)}%).\n- **Hover Stability**: Aerodynamic drag and wave damping parameters updated in 6-DOF model.`;
    }

    return `⚓ **Aardvark Maritime Co-Pilot Summary**:\n- **Autonomy Mode**: ${context.supervisor.currentMode} (Safety Supervisor: ${context.supervisor.safetyStatus}).\n- **Speed / Heading**: ${context.telemetry.speedKnots} kts @ ${context.telemetry.headingDeg}°.\n- **Active Alarms**: ${context.supervisor.alarms.length > 0 ? context.supervisor.alarms.join('; ') : 'None'}.\n\nHow can I assist you with collision avoidance, MPC trajectory tuning, or safety case generation?`;
  }
}
