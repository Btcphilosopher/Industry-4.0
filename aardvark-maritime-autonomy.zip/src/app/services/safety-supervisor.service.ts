import { Injectable } from '@angular/core';
import {
  AutonomyMode,
  EkfStateEstimate,
  SafetySupervisorEvaluation,
  SensorFaults,
  SensorHealth,
  Telemetry,
  WorldObject,
} from '../models/maritime.types';

@Injectable({
  providedIn: 'root',
})
export class SafetySupervisorService {
  private currentMode: AutonomyMode = 'AUTONOMOUS';
  private lastHeartbeatMs = Date.now();

  sendHeartbeat(): void {
    this.lastHeartbeatMs = Date.now();
  }

  setMode(mode: AutonomyMode): void {
    this.currentMode = mode;
  }

  evaluateSafety(
    ekf: EkfStateEstimate,
    telemetry: Telemetry,
    health: SensorHealth,
    faults: SensorFaults,
    targets: WorldObject[]
  ): SafetySupervisorEvaluation {
    const timeSinceHeartbeatSec = Math.round((Date.now() - this.lastHeartbeatMs) / 1000);
    const alarms: string[] = [];
    let supervisorVetoActive = false;
    let targetMode: AutonomyMode = this.currentMode;
    let actionIntent: SafetySupervisorEvaluation['actionIntent'] = 'ALLOW';
    let safetyStatus: SafetySupervisorEvaluation['safetyStatus'] = 'NOMINAL';
    let operatorInterventionRequired = false;

    // 1. Heartbeat check
    if (timeSinceHeartbeatSec > 5) {
      alarms.push(`WATCHDOG: Remote Heartbeat Timeout (${timeSinceHeartbeatSec}s > 5s)`);
      supervisorVetoActive = true;
      targetMode = 'REMOTE_INTERVENTION' as AutonomyMode;
      actionIntent = 'REMOTE_INTERVENTION';
      safetyStatus = 'HAZARDOUS';
      operatorInterventionRequired = true;
    }

    // 2. Sensor Health & Faults check
    if (faults.gnssSpoofing || faults.gnssDenial) {
      alarms.push('CRITICAL: GNSS Spoofing or Denial Detected. Switching to Dead Reckoning.');
      safetyStatus = 'DEGRADED';
      if (this.currentMode === 'AUTONOMOUS') {
        targetMode = 'DEGRADED';
        actionIntent = 'RESTRICT';
      }
    }

    if (faults.commsLoss) {
      alarms.push('WARNING: Telemetry & Command Radio Link Loss.');
      supervisorVetoActive = true;
      targetMode = 'RETURN_TO_PORT';
      actionIntent = 'RETURN';
      safetyStatus = 'HAZARDOUS';
    }

    if (ekf.confidenceScore < 0.45) {
      alarms.push(`ALARM: Low State Estimate Confidence (${Math.round(ekf.confidenceScore * 100)}%)`);
      if (safetyStatus === 'NOMINAL') safetyStatus = 'DEGRADED';
    }

    // 3. Collision Risk Veto (CPA < 250m & TCPA < 90s)
    let maxRiskScore = 0;
    for (const tgt of targets) {
      if (tgt.riskScore > maxRiskScore) {
        maxRiskScore = tgt.riskScore;
      }
      if (tgt.cpaM < 250 && tgt.tcpaS > 0 && tgt.tcpaS < 90) {
        alarms.push(`EMERGENCY: Immediate Collision Hazard with ${tgt.name} (CPA: ${tgt.cpaM}m, TCPA: ${tgt.tcpaS}s)`);
        supervisorVetoActive = true;
        targetMode = 'EMERGENCY';
        actionIntent = 'STOP';
        safetyStatus = 'EMERGENCY';
        operatorInterventionRequired = true;
      }
    }

    // 4. Mechanical & Digital Twin Health Check
    if (telemetry.bearingTempC > 95.0) {
      alarms.push(`HARDWARE ALARM: Propeller Bearing Temperature Overheat (${telemetry.bearingTempC}°C > 95°C)`);
      actionIntent = 'SLOW';
      safetyStatus = 'DEGRADED';
    }

    if (telemetry.skirtWearIndex > 0.8) {
      alarms.push(`MAINTENANCE ALARM: Severe Skirt Wear Index (${telemetry.skirtWearIndex})`);
      if (safetyStatus === 'NOMINAL') safetyStatus = 'DEGRADED';
    }

    if (telemetry.fuelRemainingL < 800) {
      alarms.push(`FUEL ALARM: Reserve Fuel Threshold Reached (${telemetry.fuelRemainingL} L)`);
      if (this.currentMode === 'AUTONOMOUS') {
        targetMode = 'RETURN_TO_PORT';
        actionIntent = 'RETURN';
      }
    }

    return {
      currentMode: this.currentMode,
      targetMode,
      actionIntent,
      supervisorVetoActive,
      alarms,
      safetyStatus,
      operatorInterventionRequired,
      timeSinceHeartbeatSec,
    };
  }
}
