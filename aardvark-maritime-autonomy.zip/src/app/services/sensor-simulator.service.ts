import { Injectable } from '@angular/core';
import { RawSensorData, SensorFaults, SensorHealth, State6DOF, Telemetry, WorldObject } from '../models/maritime.types';

@Injectable({
  providedIn: 'root',
})
export class SensorSimulatorService {
  private baseLat = 53.582; // Synthetic North Sea / Humber Estuary coordinate
  private baseLon = 0.054;
  private imuGyroBias = 0.002;
  private radarSweepAngle = 0;

  generateSensors(
    trueState: State6DOF,
    telemetry: Telemetry,
    worldObjects: WorldObject[],
    faults: SensorFaults,
    dt: number
  ): { raw: RawSensorData; health: SensorHealth } {
    this.radarSweepAngle = (this.radarSweepAngle + 45 * dt) % 360;

    // 1. GNSS Simulator
    let gnssValid = !faults.gnssDenial;
    let gnssNoiseX = (Math.random() - 0.5) * 1.5;
    let gnssNoiseY = (Math.random() - 0.5) * 1.5;
    let gnssHdop = 0.8;
    let gnssSats = 14;

    if (faults.gnssSpoofing) {
      gnssNoiseX += 250 * Math.sin(Date.now() / 5000);
      gnssNoiseY += 250 * Math.cos(Date.now() / 5000);
      gnssHdop = 2.4;
    } else if (faults.gnssDenial) {
      gnssValid = false;
      gnssHdop = 9.9;
      gnssSats = 2;
    }

    const posXM = trueState.x + (gnssValid ? gnssNoiseX : 0);
    const posYM = trueState.y + (gnssValid ? gnssNoiseY : 0);

    // Convert local ENU metres to Lat/Lon
    const lat = this.baseLat + posYM / 111320;
    const lon = this.baseLon + posXM / (111320 * Math.cos((this.baseLat * Math.PI) / 180));

    // 2. IMU Simulator (Accelerometer + Gyro)
    let gyroNoise = (Math.random() - 0.5) * 0.005;
    if (faults.imuDrift) {
      this.imuGyroBias += 0.0005 * dt;
      gyroNoise += this.imuGyroBias;
    }

    const rawImu = {
      accelX: Math.round(((trueState.u * 0.1) + (Math.random() - 0.5) * 0.1) * 100) / 100,
      accelY: Math.round(((trueState.v * 0.1) + (Math.random() - 0.5) * 0.1) * 100) / 100,
      accelZ: -9.81 + (Math.random() - 0.5) * 0.2,
      gyroX: Math.round(trueState.p * 1000) / 1000,
      gyroY: Math.round(trueState.q * 1000) / 1000,
      gyroZ: Math.round((trueState.r + gyroNoise) * 1000) / 1000,
      pitchDeg: Math.round((trueState.pitch * 180) / Math.PI * 10) / 10,
      rollDeg: Math.round((trueState.roll * 180) / Math.PI * 10) / 10,
      yawDeg: Math.round(((trueState.yaw + gyroNoise) * 180) / Math.PI * 10) / 10,
    };

    // 3. Marine Radar Simulator (360 Sweep)
    const radarContacts: RawSensorData['radar']['contacts'] = [];
    if (!faults.radarBlackout) {
      for (const obj of worldObjects) {
        const dx = obj.x - trueState.x;
        const dy = obj.y - trueState.y;
        const range = Math.sqrt(dx * dx + dy * dy);
        if (range < 8500) {
          const bearingRad = (Math.atan2(dy, dx) - trueState.yaw + 2 * Math.PI) % (2 * Math.PI);
          const bearingDeg = (bearingRad * 180) / Math.PI;
          radarContacts.push({
            id: obj.id,
            rangeM: Math.round(range + (Math.random() - 0.5) * 5),
            bearingDeg: Math.round(bearingDeg * 10) / 10,
            dopplerSpeedKnots: Math.round(obj.speedKnots * Math.cos((obj.courseDeg - bearingDeg) * Math.PI / 180) * 10) / 10,
            rcsDb: 25 + Math.random() * 10,
          });
        }
      }
    }

    // 4. LiDAR Point Cloud Cluster Simulator
    const lidarPoints: RawSensorData['lidar']['points'] = [];
    if (!faults.lidarOcclusion) {
      for (const obj of worldObjects) {
        const dx = obj.x - trueState.x;
        const dy = obj.y - trueState.y;
        const range = Math.sqrt(dx * dx + dy * dy);
        if (range < 1200) {
          // Generate 8-12 return points per close object
          for (let p = 0; p < 8; p++) {
            lidarPoints.push({
              x: dx + (Math.random() - 0.5) * obj.beamM,
              y: dy + (Math.random() - 0.5) * obj.lengthM,
              z: 2.5 + (Math.random() - 0.5) * 3.0,
              intensity: Math.round(60 + Math.random() * 40),
            });
          }
        }
      }
    }

    // 5. AIS Transponder Messages
    const aisMessages: RawSensorData['ais']['messages'] = [];
    if (!faults.aisDropout) {
      for (const obj of worldObjects) {
        if (obj.mmsi) {
          const tLat = this.baseLat + obj.y / 111320;
          const tLon = this.baseLon + obj.x / (111320 * Math.cos((this.baseLat * Math.PI) / 180));
          aisMessages.push({
            mmsi: obj.mmsi,
            name: obj.name,
            vesselType: obj.type,
            lat: tLat,
            lon: tLon,
            sogKnots: obj.speedKnots,
            cogDeg: obj.courseDeg,
            trueHeadingDeg: obj.courseDeg,
            status: 'Under way using engine',
          });
        }
      }
    }

    // Calculate Sensor Health Ratings (0.0 to 1.0)
    const health: SensorHealth = {
      gnss: faults.gnssDenial ? 0.05 : faults.gnssSpoofing ? 0.35 : 0.98,
      imu: faults.imuDrift ? 0.45 : 0.99,
      radar: faults.radarBlackout ? 0.0 : 0.96,
      lidar: faults.lidarOcclusion ? 0.25 : 0.94,
      ais: faults.aisDropout ? 0.1 : 0.98,
      depth: 0.95,
      cushionPressure: faults.skirtLeakage ? 0.4 : 0.99,
      commsLink: faults.commsLoss ? 0.0 : 0.99,
    };

    const raw: RawSensorData = {
      gnss: {
        lat,
        lon,
        alt: 1.25,
        sogKnots: telemetry.speedKnots,
        cogDeg: telemetry.courseDeg,
        hdop: gnssHdop,
        satellites: gnssSats,
        fixQuality: gnssValid ? 'RTK Fixed (Centimetre Level)' : 'No Fix / Denied',
        valid: gnssValid,
      },
      imu: rawImu,
      radar: {
        contacts: radarContacts,
        sweepAngleDeg: Math.round(this.radarSweepAngle),
      },
      lidar: {
        points: lidarPoints,
      },
      ais: {
        messages: aisMessages,
      },
      echoSounderDepthM: 14.5 + Math.sin(trueState.x / 1000) * 4.2,
      cushionPressureKpa: telemetry.cushionPressureKpa,
    };

    return { raw, health };
  }
}
