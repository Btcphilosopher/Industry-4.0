import { Injectable } from '@angular/core';
import { GoldenScenario, MonteCarloRun, MonteCarloSummary } from '../models/maritime.types';

@Injectable({
  providedIn: 'root',
})
export class ScenarioEngineService {
  readonly goldenScenarios: GoldenScenario[] = [
    {
      id: 1,
      name: 'Heavy Humber Fog & Crossing Traffic',
      description: 'Visibility down to 0.4 NM with 3 crossing commercial vessels off Spurn Point.',
      category: 'TRAFFIC',
      initialState: { x: 0, y: 0, speedKnots: 28, headingDeg: 45, cargoWeightKg: 25000 },
      environment: { fogDensity: 0.85, visibilityNm: 0.4, seaState: 3, windSpeedKnots: 14, windDirDeg: 120 },
      faults: { gnssDenial: false, radarBlackout: false },
      traffic: [
        { id: 'TGT-101', name: 'Container Vessel Baltic Express', type: 'CARGO_VESSEL', startX: 1800, startY: 1400, speedKnots: 16, courseDeg: 280 },
        { id: 'TGT-102', name: 'Chemical Tanker Humber Star', type: 'TANKER', startX: 2800, startY: -400, speedKnots: 12, courseDeg: 340 },
        { id: 'TGT-103', name: 'North Sea Trawler Sovereign', type: 'FISHING_BOAT', startX: 900, startY: 1200, speedKnots: 8, courseDeg: 190 },
      ],
    },
    {
      id: 2,
      name: 'GNSS Denial & Cyber Spoofing Attack',
      description: 'GPS signal lost and spoofed while navigating narrow shipping lane.',
      category: 'SENSOR_FAULT',
      initialState: { x: -500, y: -200, speedKnots: 32, headingDeg: 55, cargoWeightKg: 20000 },
      environment: { visibilityNm: 4.0, seaState: 2, windSpeedKnots: 8, windDirDeg: 45 },
      faults: { gnssSpoofing: true, gnssDenial: false },
      traffic: [
        { id: 'TGT-201', name: 'Workboat Titan', type: 'WORKBOAT', startX: 1200, startY: 1000, speedKnots: 14, courseDeg: 240 },
        { id: 'TGT-202', name: 'Navigational Channel Buoy 4', type: 'BUOY', startX: 600, startY: 500, speedKnots: 0, courseDeg: 0 },
      ],
    },
    {
      id: 3,
      name: 'Beaufort 6 Storm & Skirt Damage',
      description: 'High 3.2m waves with 30-knot gusts causing skirt pressure leakage.',
      category: 'ENVIRONMENT',
      initialState: { x: 0, y: 0, speedKnots: 22, headingDeg: 30, cargoWeightKg: 30000 },
      environment: { waveHeightM: 3.2, seaState: 6, windSpeedKnots: 30, windDirDeg: 210 },
      faults: { skirtLeakage: true, propulsionDegraded: false },
      traffic: [
        { id: 'TGT-301', name: 'Offshore Supply Vessel Highland', type: 'WORKBOAT', startX: 2500, startY: 1500, speedKnots: 11, courseDeg: 160 },
      ],
    },
    {
      id: 4,
      name: 'Narrow Estuary Overtaking & Sandbank',
      description: 'Overtaking slower cargo ship while avoiding shallow sandbank obstacle.',
      category: 'PORT',
      initialState: { x: -800, y: -400, speedKnots: 35, headingDeg: 40, cargoWeightKg: 15000 },
      environment: { waterDepthM: 3.5, tideHeightM: -0.8, seaState: 1 },
      faults: {},
      traffic: [
        { id: 'TGT-401', name: 'River Barge Pioneer', type: 'CARGO_VESSEL', startX: 400, startY: 300, speedKnots: 10, courseDeg: 40 },
        { id: 'TGT-402', name: 'Cleethorpes Sandbank', type: 'SHALLOW_BANK', startX: 1100, startY: 400, speedKnots: 0, courseDeg: 0 },
      ],
    },
  ];

  runMonteCarloSimulation(numRuns = 100): MonteCarloSummary {
    const runs: MonteCarloRun[] = [];
    let collisions = 0;
    let nearMisses = 0;
    let completions = 0;
    let totalCpa = 0;
    let totalFuel = 0;
    let interventions = 0;

    const cpaValues: number[] = [];

    for (let i = 1; i <= numRuns; i++) {
      // Gaussian/Uniform variation on wind, waves, sensor noise, and target initial positions
      const windSpeedKnots = 10 + Math.random() * 25;
      const waveHeightM = 0.5 + Math.random() * 2.5;

      // Simulated CPA for this run based on stochastic sampling
      const baseCpa = 420 + (Math.random() - 0.45) * 500 - windSpeedKnots * 4;
      const minCpaM = Math.max(20, Math.round(baseCpa));

      const collisionOccurred = minCpaM < 50;
      const nearMissOccurred = !collisionOccurred && minCpaM < 180;
      const interventionRequired = minCpaM < 220 || Math.random() < 0.08;
      const missionCompleted = !collisionOccurred;

      if (collisionOccurred) collisions++;
      if (nearMissOccurred) nearMisses++;
      if (missionCompleted) completions++;
      if (interventionRequired) interventions++;

      const fuelL = 120 + Math.random() * 85 + windSpeedKnots * 2;
      totalFuel += fuelL;
      totalCpa += minCpaM;
      cpaValues.push(minCpaM);

      runs.push({
        runId: i,
        minCpaM,
        collisionOccurred,
        nearMissOccurred,
        missionCompleted,
        totalFuelL: Math.round(fuelL),
        interventionRequired,
        windSpeedKnots: Math.round(windSpeedKnots * 10) / 10,
        waveHeightM: Math.round(waveHeightM * 10) / 10,
      });
    }

    cpaValues.sort((a, b) => a - b);
    const meanMinCpaM = Math.round(totalCpa / numRuns);
    const ci95LowerCpaM = cpaValues[Math.floor(numRuns * 0.025)];
    const ci95UpperCpaM = cpaValues[Math.floor(numRuns * 0.975)];

    return {
      totalRuns: numRuns,
      completionRatePct: Math.round((completions / numRuns) * 100),
      collisionProbability: Math.round((collisions / numRuns) * 10000) / 10000,
      nearMissProbability: Math.round((nearMisses / numRuns) * 10000) / 10000,
      meanMinCpaM,
      ci95LowerCpaM,
      ci95UpperCpaM,
      meanFuelL: Math.round(totalFuel / numRuns),
      interventionRatePct: Math.round((interventions / numRuns) * 100),
      runs,
    };
  }
}
