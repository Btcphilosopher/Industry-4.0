import { Injectable } from '@angular/core';
import {
  CandidateTrajectory,
  ControlVector,
  EkfStateEstimate,
  EnvironmentState,
  HovercraftSpecs,
  MpcResult,
  TrajectoryPoint,
  WorldObject,
} from '../models/maritime.types';

@Injectable({
  providedIn: 'root',
})
export class MpcTrajectoryService {
  computeMpc(
    ownShip: EkfStateEstimate,
    currentControl: ControlVector,
    specs: HovercraftSpecs,
    env: EnvironmentState,
    targetObjects: WorldObject[],
    waypoint: { x: number; y: number; targetSpeedKnots: number },
    horizonSec = 10,
    dt = 0.5
  ): MpcResult {
    const candidates: CandidateTrajectory[] = [];
    const steps = Math.floor(horizonSec / dt);

    // Grid of candidate control variations (rudder deg offsets, thrust offsets)
    const rudderOptions = [-25, -15, -8, 0, 8, 15, 25];
    const thrustOptions = [40, 65, 85, 100];

    let candidateId = 0;

    for (const rDeg of rudderOptions) {
      for (const tPct of thrustOptions) {
        candidateId++;
        const points: TrajectoryPoint[] = [];

        let simX = ownShip.x;
        let simY = ownShip.y;
        let simU = ownShip.u;
        const simV = ownShip.v;
        let simYaw = ownShip.yaw;
        let simR = ownShip.r;

        let totalCollisionCost = 0;
        let minObstacleDist = 99999;
        let totalEnergy = 0;

        for (let step = 0; step < steps; step++) {
          const t = step * dt;

          // Simple dynamic projection for trajectory candidate sampling
          const thrustRatio = tPct / 100;
          const accel = thrustRatio * 0.8 - 0.02 * simU * Math.abs(simU);

          simU = Math.max(0, simU + accel * dt);

          // Yaw rate dynamics (hovercraft drift)
          const targetR = (rDeg / 30) * 0.25;
          simR += (targetR - simR) * 0.3 * dt;
          simYaw = (simYaw + simR * dt + 2 * Math.PI) % (2 * Math.PI);

          const xDot = simU * Math.cos(simYaw) - simV * Math.sin(simYaw);
          const yDot = simU * Math.sin(simYaw) + simV * Math.cos(simYaw);

          simX += xDot * dt;
          simY += yDot * dt;

          // Wind drift effect
          const windSpeedMs = env.windSpeedKnots * 0.514444;
          const windDirRad = (env.windDirDeg * Math.PI) / 180;
          simX += windSpeedMs * 0.05 * Math.cos(windDirRad) * dt;
          simY += windSpeedMs * 0.05 * Math.sin(windDirRad) * dt;

          // Evaluate distance to obstacles/traffic along trajectory
          let stepRisk = 0;
          for (const obj of targetObjects) {
            // Predict object future position
            const objFutureX = obj.x + obj.vx * t;
            const objFutureY = obj.y + obj.vy * t;

            const dist = Math.sqrt(Math.pow(simX - objFutureX, 2) + Math.pow(simY - objFutureY, 2));
            if (dist < minObstacleDist) {
              minObstacleDist = dist;
            }

            // High penalty for distance < 400m
            if (dist < 400) {
              const penalty = Math.pow((400 - dist) / 40, 2);
              totalCollisionCost += penalty;
              stepRisk = Math.max(stepRisk, Math.min(1.0, penalty / 10));
            }
          }

          const speedKts = simU / 0.514444;
          totalEnergy += tPct * 0.5 * dt;

          points.push({
            t: Math.round(t * 10) / 10,
            x: Math.round(simX * 10) / 10,
            y: Math.round(simY * 10) / 10,
            psi: Math.round(simYaw * 100) / 100,
            speedKnots: Math.round(speedKts * 10) / 10,
            risk: Math.round(stepRisk * 100) / 100,
            energy: Math.round(totalEnergy),
          });
        }

        // Target waypoint attraction cost (Cross-track and Heading alignment)
        const finalPoint = points[points.length - 1];
        const dxWp = waypoint.x - finalPoint.x;
        const dyWp = waypoint.y - finalPoint.y;
        const distToWp = Math.sqrt(dxWp * dxWp + dyWp * dyWp);

        const targetBearing = Math.atan2(dyWp, dxWp);
        let headingErr = Math.abs(targetBearing - simYaw);
        headingErr = Math.min(headingErr, 2 * Math.PI - headingErr);

        const crossTrackCost = distToWp * 0.8;
        const headingCost = headingErr * 120;
        const collisionCost = totalCollisionCost * 45;
        const energyCost = totalEnergy * 0.05;

        const totalCost = crossTrackCost + headingCost + collisionCost + energyCost;

        candidates.push({
          id: `TRAJ-${candidateId}`,
          rudderDeg: rDeg,
          thrustPct: tPct,
          totalCost: Math.round(totalCost),
          crossTrackCost: Math.round(crossTrackCost),
          headingCost: Math.round(headingCost),
          collisionCost: Math.round(collisionCost),
          energyCost: Math.round(energyCost),
          minObstacleDistM: Math.round(minObstacleDist),
          points,
          isSelected: false,
        });
      }
    }

    // Sort by lowest cost
    candidates.sort((a, b) => a.totalCost - b.totalCost);
    if (candidates.length > 0) {
      candidates[0].isSelected = true;
    }

    const best = candidates[0];
    const optimalControl: ControlVector = {
      thrustPortPct: best ? best.thrustPct : currentControl.thrustPortPct,
      thrustStbdPct: best ? best.thrustPct : currentControl.thrustStbdPct,
      rudderDeg: best ? best.rudderDeg : currentControl.rudderDeg,
      liftPct: currentControl.liftPct,
      bowThrusterPct: best ? Math.round(best.rudderDeg * 0.8) : currentControl.bowThrusterPct,
    };

    return {
      optimalControl,
      selectedTrajectory: best ? best.points : [],
      candidates: candidates.slice(0, 12),
      cost: best ? best.totalCost : 0,
      horizonSec,
    };
  }
}
