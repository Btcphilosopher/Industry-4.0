import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EnvironmentState, GoldenScenario, MonteCarloSummary } from '../models/maritime.types';

@Component({
  selector: 'app-monte-carlo-panel',
  imports: [CommonModule],
  template: `
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-5">
      <!-- Left Column: Golden Scenarios Launcher & Custom Weather -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl flex flex-col space-y-4">
        <div class="border-b border-slate-800 pb-3">
          <h3 class="text-sm font-bold font-mono text-cyan-400 flex items-center">
            <span class="material-icons text-base mr-1.5 text-cyan-400">auto_mode</span>
            Golden Test Scenarios
          </h3>
          <p class="text-xs text-slate-400">Pre-configured safety case benchmark scenarios</p>
        </div>

        <div class="space-y-2.5 font-mono text-xs">
          @for (sc of goldenScenarios; track sc.id) {
            <button (click)="selectScenario(sc)"
              class="w-full text-left p-3 rounded-xl border transition-all hover:scale-[1.01]"
              [ngClass]="activeScenarioId === sc.id ? 'bg-cyan-950/40 border-cyan-500 text-cyan-200 shadow-md' : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'">
              <div class="flex items-center justify-between mb-1">
                <span class="font-bold text-slate-100">{{ sc.name }}</span>
                <span class="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-cyan-400 font-mono">{{ sc.category }}</span>
              </div>
              <p class="text-[11px] text-slate-400 leading-snug">{{ sc.description }}</p>
            </button>
          }
        </div>

        <!-- Environmental Controls -->
        <div class="border-t border-slate-800 pt-3 space-y-3 font-mono text-xs">
          <div class="font-bold text-slate-200">Environment & Sea State Customizer</div>

          <div>
            <div class="flex justify-between text-slate-400 mb-1">
              <span>Wind Speed: {{ env.windSpeedKnots }} kts</span>
              <span>Dir: {{ env.windDirDeg }}°</span>
            </div>
            <input type="range" min="0" max="45" [value]="env.windSpeedKnots" (input)="updateWindSpeed($event)" class="w-full accent-cyan-500">
          </div>

          <div>
            <div class="flex justify-between text-slate-400 mb-1">
              <span>Wave Height: {{ env.waveHeightM }} m</span>
              <span>Beaufort: {{ env.seaState }}</span>
            </div>
            <input type="range" min="0.1" max="5.0" step="0.1" [value]="env.waveHeightM" (input)="updateWaveHeight($event)" class="w-full accent-cyan-500">
          </div>

          <div>
            <div class="flex justify-between text-slate-400 mb-1">
              <span>Visibility: {{ env.visibilityNm }} NM</span>
              <span>Fog Density: {{ (env.fogDensity * 100).toFixed(0) }}%</span>
            </div>
            <input type="range" min="0.1" max="10.0" step="0.1" [value]="env.visibilityNm" (input)="updateVisibility($event)" class="w-full accent-cyan-500">
          </div>
        </div>
      </div>

      <!-- Right Column: Monte Carlo 100-Run Stochastic Verification (2 cols wide) -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl flex flex-col space-y-4 lg:col-span-2">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h3 class="text-sm font-bold font-mono text-purple-400 flex items-center">
              <span class="material-icons text-base mr-1.5 text-purple-400">casino</span>
              Monte Carlo Stochastic Safety Verification (100 Parallel Simulations)
            </h3>
            <p class="text-xs text-slate-400">Randomized wind gusts, wave heights, sensor noise & target initial conditions</p>
          </div>
          <button (click)="runSimulation()" class="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white font-bold font-mono text-xs rounded-lg transition-colors flex items-center space-x-2 shadow-lg">
            <span class="material-icons text-sm">play_arrow</span>
            <span>RUN 100-SIM MONTE CARLO</span>
          </button>
        </div>

        <!-- Summary Stats Grid -->
        @if (mcSummary) {
          <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
            <div class="bg-slate-950 p-3 rounded-xl border border-slate-800 text-center">
              <span class="text-slate-400 block text-[10px] mb-1">Mission Completion</span>
              <span class="text-xl font-bold text-emerald-400">{{ mcSummary.completionRatePct }}%</span>
            </div>

            <div class="bg-slate-950 p-3 rounded-xl border border-slate-800 text-center">
              <span class="text-slate-400 block text-[10px] mb-1">Collision Probability</span>
              <span class="text-xl font-bold" [ngClass]="mcSummary.collisionProbability > 0 ? 'text-rose-400' : 'text-emerald-400'">
                {{ (mcSummary.collisionProbability * 100).toFixed(2) }}%
              </span>
            </div>

            <div class="bg-slate-950 p-3 rounded-xl border border-slate-800 text-center">
              <span class="text-slate-400 block text-[10px] mb-1">Near-Miss Probability</span>
              <span class="text-xl font-bold text-amber-400">{{ (mcSummary.nearMissProbability * 100).toFixed(1) }}%</span>
            </div>

            <div class="bg-slate-950 p-3 rounded-xl border border-slate-800 text-center">
              <span class="text-slate-400 block text-[10px] mb-1">Mean CPA (95% CI)</span>
              <span class="text-sm font-bold text-cyan-400">{{ mcSummary.meanMinCpaM }}m</span>
              <span class="text-[9px] text-slate-500 block">[{{ mcSummary.ci95LowerCpaM }}m - {{ mcSummary.ci95UpperCpaM }}m]</span>
            </div>
          </div>
        }

        <!-- Monte Carlo Runs Distribution Table / Plot -->
        @if (mcSummary) {
          <div class="overflow-x-auto max-h-[300px]">
            <table class="w-full text-left text-xs font-mono border-collapse">
              <thead>
                <tr class="bg-slate-950 text-slate-400 border-b border-slate-800">
                  <th class="py-2 px-3">Run ID</th>
                  <th class="py-2 px-3">Min CPA (m)</th>
                  <th class="py-2 px-3">Wind Speed</th>
                  <th class="py-2 px-3">Wave Height</th>
                  <th class="py-2 px-3">Fuel Consumed</th>
                  <th class="py-2 px-3">Safety Result</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-800/60">
                @for (run of mcSummary.runs.slice(0, 15); track run.runId) {
                  <tr class="hover:bg-slate-800/40">
                    <td class="py-2 px-3 font-bold text-slate-300">Run #{{ run.runId }}</td>
                    <td class="py-2 px-3 font-bold" [ngClass]="run.minCpaM < 180 ? 'text-rose-400' : 'text-cyan-300'">{{ run.minCpaM }}m</td>
                    <td class="py-2 px-3 text-slate-400">{{ run.windSpeedKnots }} kts</td>
                    <td class="py-2 px-3 text-slate-400">{{ run.waveHeightM }} m</td>
                    <td class="py-2 px-3 text-slate-400">{{ run.totalFuelL }} L</td>
                    <td class="py-2 px-3">
                      <span class="px-2 py-0.5 rounded text-[10px] font-bold"
                        [ngClass]="{
                          'bg-rose-950 text-rose-300 border border-rose-800': run.collisionOccurred,
                          'bg-amber-950 text-amber-300 border border-amber-800': run.nearMissOccurred,
                          'bg-emerald-950 text-emerald-300 border border-emerald-800': run.missionCompleted && !run.nearMissOccurred
                        }">
                        {{ run.collisionOccurred ? 'COLLISION' : run.nearMissOccurred ? 'NEAR MISS' : 'SUCCESS' }}
                      </span>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        }
      </div>
    </div>
  `,
  styles: [],
})
export class MonteCarloPanel {
  @Input() goldenScenarios: GoldenScenario[] = [];
  @Input() activeScenarioId = 1;
  @Input() env!: EnvironmentState;
  @Input() mcSummary: MonteCarloSummary | null = null;

  @Output() scenarioSelected = new EventEmitter<GoldenScenario>();
  @Output() envUpdated = new EventEmitter<Partial<EnvironmentState>>();
  @Output() runSimulationRequested = new EventEmitter<void>();

  selectScenario(sc: GoldenScenario): void {
    this.scenarioSelected.emit(sc);
  }

  updateWindSpeed(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.envUpdated.emit({ windSpeedKnots: val });
  }

  updateWaveHeight(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    const seaState = val < 0.5 ? 1 : val < 1.25 ? 2 : val < 2.5 ? 4 : 6;
    this.envUpdated.emit({ waveHeightM: val, seaState });
  }

  updateVisibility(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    const fogDensity = Math.max(0, 1 - val / 5.0);
    this.envUpdated.emit({ visibilityNm: val, fogDensity });
  }

  runSimulation(): void {
    this.runSimulationRequested.emit();
  }
}
