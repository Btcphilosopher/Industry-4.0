import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DigitalTwinResiduals, Telemetry } from '../models/maritime.types';

@Component({
  selector: 'app-digital-twin-panel',
  imports: [CommonModule],
  template: `
    <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl flex flex-col space-y-4">
      <div class="flex items-center justify-between border-b border-slate-800 pb-3">
        <div>
          <h2 class="text-lg font-bold font-mono text-purple-400 flex items-center">
            <span class="material-icons text-base mr-2 text-purple-400">memory</span>
            Physics-Informed Digital Twin & Prognostics Diagnostics
          </h2>
          <p class="text-xs text-slate-400">
            Compares live telemetry against 6-DOF mathematical baseline model for early structural anomaly detection
          </p>
        </div>
        <div>
          <span class="px-3 py-1 rounded-full text-xs font-mono font-bold"
            [ngClass]="twin.anomalyDetected ? 'bg-rose-950 border border-rose-800 text-rose-300 animate-pulse' : 'bg-emerald-950 border border-emerald-800 text-emerald-300'">
            {{ twin.anomalyDetected ? 'ANOMALY DETECTED' : 'DIGITAL TWIN NOMINAL' }}
          </span>
        </div>
      </div>

      <!-- Anomaly Alert Banner -->
      @if (twin.anomalyDetected) {
        <div class="bg-rose-950/40 border border-rose-700/80 rounded-xl p-4 text-xs font-mono text-rose-200 flex items-center justify-between">
          <div class="flex items-center space-x-3">
            <span class="material-icons text-2xl text-rose-400">report_problem</span>
            <div>
              <div class="font-bold text-sm text-rose-300">Structural Anomaly Alert: {{ twin.anomalyType }}</div>
              <div class="text-[11px] text-rose-400/80 mt-0.5">Physical telemetry deviates significantly from baseline physics prediction model.</div>
            </div>
          </div>
          <button class="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded text-xs transition-colors">
            Inspect Sensor Logs
          </button>
        </div>
      }

      <!-- Residuals & Prognostics Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 font-mono text-xs">
        <div class="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-1">
          <span class="text-slate-400 block text-[11px]">Speed Residual (Observed vs Model)</span>
          <span class="text-xl font-bold" [ngClass]="Math.abs(twin.speedResidualKnots) > 3.0 ? 'text-amber-400' : 'text-emerald-400'">
            {{ twin.speedResidualKnots > 0 ? '+' : '' }}{{ twin.speedResidualKnots }} kts
          </span>
          <p class="text-[10px] text-slate-500">Hydrodynamic skirt drag variation</p>
        </div>

        <div class="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-1">
          <span class="text-slate-400 block text-[11px]">Cushion Pressure Loss Residual</span>
          <span class="text-xl font-bold" [ngClass]="Math.abs(twin.cushionPressureResidualKpa) > 0.4 ? 'text-rose-400' : 'text-emerald-400'">
            {{ twin.cushionPressureResidualKpa > 0 ? '+' : '' }}{{ twin.cushionPressureResidualKpa }} kPa
          </span>
          <p class="text-[10px] text-slate-500">Skirt perimeter seal integrity</p>
        </div>

        <div class="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-1">
          <span class="text-slate-400 block text-[11px]">Fuel Consumption Anomaly</span>
          <span class="text-xl font-bold" [ngClass]="twin.fuelResidualPct > 15 ? 'text-amber-400' : 'text-emerald-400'">
            {{ twin.fuelResidualPct > 0 ? '+' : '' }}{{ twin.fuelResidualPct }}%
          </span>
          <p class="text-[10px] text-slate-500">Specific fuel consumption deviation</p>
        </div>

        <div class="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-1">
          <span class="text-slate-400 block text-[11px]">RUL (Remaining Useful Life)</span>
          <span class="text-xl font-bold text-purple-400">
            {{ twin.rulHoursRemaining }} hours
          </span>
          <p class="text-[10px] text-slate-500">Limiting component: Skirt & Bearings</p>
        </div>
      </div>

      <!-- Component Condition Gauges -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs pt-2">
        <div class="bg-slate-950/70 p-4 rounded-xl border border-slate-800 space-y-2">
          <div class="flex justify-between font-bold">
            <span class="text-slate-300">Hovercraft Skirt Perimeter Wear</span>
            <span class="text-cyan-400">{{ (telemetry.skirtWearIndex * 100).toFixed(1) }}% Wear</span>
          </div>
          <div class="w-full bg-slate-900 rounded-full h-2 border border-slate-800 overflow-hidden">
            <div class="h-full bg-cyan-500 transition-all duration-300" [style.width.%]="telemetry.skirtWearIndex * 100"></div>
          </div>
          <span class="text-[10px] text-slate-500 block">Estimated skirt life remaining: {{ Math.round((1 - telemetry.skirtWearIndex) * 450) }} operating hours</span>
        </div>

        <div class="bg-slate-950/70 p-4 rounded-xl border border-slate-800 space-y-2">
          <div class="flex justify-between font-bold">
            <span class="text-slate-300">Propeller Bearing Temperature</span>
            <span [ngClass]="telemetry.bearingTempC > 85 ? 'text-rose-400' : 'text-amber-400'">{{ telemetry.bearingTempC }}°C</span>
          </div>
          <div class="w-full bg-slate-900 rounded-full h-2 border border-slate-800 overflow-hidden">
            <div class="h-full transition-all duration-300" [style.width.%]="(telemetry.bearingTempC / 100) * 100" [ngClass]="telemetry.bearingTempC > 85 ? 'bg-rose-500' : 'bg-amber-500'"></div>
          </div>
          <span class="text-[10px] text-slate-500 block">Thermal shutdown limit: 95.0°C</span>
        </div>

        <div class="bg-slate-950/70 p-4 rounded-xl border border-slate-800 space-y-2">
          <div class="flex justify-between font-bold">
            <span class="text-slate-300">Ducted Fan Vibration RMS</span>
            <span [ngClass]="telemetry.vibrationRmsMmS > 4.0 ? 'text-rose-400' : 'text-emerald-400'">{{ telemetry.vibrationRmsMmS }} mm/s</span>
          </div>
          <div class="w-full bg-slate-900 rounded-full h-2 border border-slate-800 overflow-hidden">
            <div class="h-full transition-all duration-300" [style.width.%]="(telemetry.vibrationRmsMmS / 6.0) * 100" [ngClass]="telemetry.vibrationRmsMmS > 4.0 ? 'bg-rose-500' : 'bg-emerald-500'"></div>
          </div>
          <span class="text-[10px] text-slate-500 block">ISO 10816 Vibration Alert Threshold: 4.5 mm/s</span>
        </div>
      </div>
    </div>
  `,
  styles: [],
})
export class DigitalTwinPanel {
  @Input() twin!: DigitalTwinResiduals;
  @Input() telemetry!: Telemetry;

  protected Math = Math;
}
