import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Telemetry } from '../models/maritime.types';

@Component({
  selector: 'app-telemetry-bar',
  imports: [CommonModule],
  template: `
    <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-9 gap-3 w-full">
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-3 flex flex-col items-center justify-center text-center shadow-lg hover:border-cyan-500/50 transition-colors">
        <span class="text-[10px] font-mono text-slate-400 uppercase tracking-wider mb-1">Speed (SOG)</span>
        <span class="text-xl font-bold font-mono text-cyan-400">{{ telemetry.speedKnots }} <span class="text-xs text-slate-400">kts</span></span>
        <span class="text-[10px] text-slate-500 mt-0.5">Max 48.0 kts</span>
      </div>

      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-3 flex flex-col items-center justify-center text-center shadow-lg hover:border-cyan-500/50 transition-colors">
        <span class="text-[10px] font-mono text-slate-400 uppercase tracking-wider mb-1">Heading / COG</span>
        <span class="text-xl font-bold font-mono text-emerald-400">{{ telemetry.headingDeg }}° <span class="text-xs text-slate-400">/ {{ telemetry.courseDeg }}°</span></span>
        <span class="text-[10px] text-slate-500 mt-0.5">Drift: {{ telemetry.driftAngleDeg }}°</span>
      </div>

      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-3 flex flex-col items-center justify-center text-center shadow-lg hover:border-cyan-500/50 transition-colors">
        <span class="text-[10px] font-mono text-slate-400 uppercase tracking-wider mb-1">Cushion Press</span>
        <span class="text-xl font-bold font-mono text-amber-400">{{ telemetry.cushionPressureKpa }} <span class="text-xs text-slate-400">kPa</span></span>
        <span class="text-[10px] text-slate-500 mt-0.5">Nom: 2.85 kPa</span>
      </div>

      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-3 flex flex-col items-center justify-center text-center shadow-lg hover:border-cyan-500/50 transition-colors">
        <span class="text-[10px] font-mono text-slate-400 uppercase tracking-wider mb-1">Lift Fan</span>
        <span class="text-xl font-bold font-mono text-emerald-300">{{ telemetry.liftFanRpm }} <span class="text-xs text-slate-400">RPM</span></span>
        <span class="text-[10px] text-slate-500 mt-0.5">Power: 1.2 MW</span>
      </div>

      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-3 flex flex-col items-center justify-center text-center shadow-lg hover:border-cyan-500/50 transition-colors">
        <span class="text-[10px] font-mono text-slate-400 uppercase tracking-wider mb-1">Port / Stbd Fan</span>
        <span class="text-lg font-bold font-mono text-sky-400">{{ telemetry.portFanRpm }} <span class="text-xs text-slate-400">/ {{ telemetry.stbdFanRpm }}</span></span>
        <span class="text-[10px] text-slate-500 mt-0.5">Dual Ducted Props</span>
      </div>

      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-3 flex flex-col items-center justify-center text-center shadow-lg hover:border-cyan-500/50 transition-colors">
        <span class="text-[10px] font-mono text-slate-400 uppercase tracking-wider mb-1">Fuel Remaining</span>
        <span class="text-xl font-bold font-mono" [ngClass]="telemetry.fuelRemainingL < 1200 ? 'text-rose-400' : 'text-emerald-400'">
          {{ telemetry.fuelRemainingL }} <span class="text-xs text-slate-400">L</span>
        </span>
        <span class="text-[10px] text-slate-500 mt-0.5">{{ telemetry.fuelFlowLPerHour }} L/h</span>
      </div>

      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-3 flex flex-col items-center justify-center text-center shadow-lg hover:border-cyan-500/50 transition-colors">
        <span class="text-[10px] font-mono text-slate-400 uppercase tracking-wider mb-1">Battery SOC</span>
        <span class="text-xl font-bold font-mono text-purple-400">{{ telemetry.batterySocPct }}%</span>
        <span class="text-[10px] text-slate-500 mt-0.5">350 kWh Pack</span>
      </div>

      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-3 flex flex-col items-center justify-center text-center shadow-lg hover:border-cyan-500/50 transition-colors">
        <span class="text-[10px] font-mono text-slate-400 uppercase tracking-wider mb-1">Bearing Temp</span>
        <span class="text-xl font-bold font-mono" [ngClass]="telemetry.bearingTempC > 85 ? 'text-rose-400' : 'text-amber-400'">
          {{ telemetry.bearingTempC }}°C
        </span>
        <span class="text-[10px] text-slate-500 mt-0.5">Limit: 95.0°C</span>
      </div>

      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-3 flex flex-col items-center justify-center text-center shadow-lg hover:border-cyan-500/50 transition-colors">
        <span class="text-[10px] font-mono text-slate-400 uppercase tracking-wider mb-1">Skirt Wear Index</span>
        <span class="text-xl font-bold font-mono" [ngClass]="telemetry.skirtWearIndex > 0.6 ? 'text-rose-400' : 'text-slate-200'">
          {{ telemetry.skirtWearIndex }}
        </span>
        <span class="text-[10px] text-slate-500 mt-0.5">Skirt Height: 1.4m</span>
      </div>
    </div>
  `,
  styles: [],
})
export class TelemetryBar {
  @Input() telemetry!: Telemetry;
}
