import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AutonomyMode, SafetySupervisorEvaluation } from '../models/maritime.types';

@Component({
  selector: 'app-safety-supervisor-panel',
  imports: [CommonModule],
  template: `
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-5">
      <!-- Safety Status Card -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl flex flex-col space-y-4">
        <div class="border-b border-slate-800 pb-3">
          <h3 class="text-sm font-bold font-mono text-cyan-400 flex items-center">
            <span class="material-icons text-base mr-1.5 text-cyan-400">security</span>
            Supervisor Watchdog & Heartbeat
          </h3>
          <p class="text-xs text-slate-400">Deterministic runtime enforcement & veto engine</p>
        </div>

        <div class="space-y-3 font-mono text-xs">
          <div class="p-3 rounded-lg border flex items-center justify-between"
            [ngClass]="{
              'bg-emerald-950/40 border-emerald-700 text-emerald-300': supervisor.safetyStatus === 'NOMINAL',
              'bg-amber-950/40 border-amber-700 text-amber-300': supervisor.safetyStatus === 'DEGRADED',
              'bg-rose-950/40 border-rose-700 text-rose-300': supervisor.safetyStatus === 'HAZARDOUS' || supervisor.safetyStatus === 'EMERGENCY'
            }">
            <div>
              <div class="text-[10px] text-slate-400 uppercase">Supervisor Safety Status</div>
              <div class="text-lg font-bold">{{ supervisor.safetyStatus }}</div>
            </div>
            <span class="px-2.5 py-1 rounded text-xs font-bold"
              [ngClass]="supervisor.supervisorVetoActive ? 'bg-rose-600 text-white animate-pulse' : 'bg-emerald-800 text-emerald-100'">
              VETO: {{ supervisor.supervisorVetoActive ? 'ACTIVE (RESTRICTED)' : 'INACTIVE (PASSTHROUGH)' }}
            </span>
          </div>

          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-2">
            <div class="flex justify-between items-center">
              <span class="text-slate-400">Telemetry Heartbeat:</span>
              <span class="flex items-center text-emerald-400 font-bold">
                <span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping mr-1.5"></span>
                {{ supervisor.timeSinceHeartbeatSec }}s ago (Limit: 5s)
              </span>
            </div>
            <div class="flex justify-between items-center">
              <span class="text-slate-400">Action Intent:</span>
              <span class="font-bold text-amber-400">{{ supervisor.actionIntent }}</span>
            </div>
            <div class="flex justify-between items-center">
              <span class="text-slate-400">Current Mode:</span>
              <span class="font-bold text-cyan-400">{{ supervisor.currentMode }}</span>
            </div>
            <div class="flex justify-between items-center">
              <span class="text-slate-400">Target Mode:</span>
              <span class="font-bold text-purple-400">{{ supervisor.targetMode }}</span>
            </div>
          </div>

          <!-- Emergency Override Action Buttons -->
          <div class="space-y-2 pt-2">
            <button (click)="triggerMode('SAFE_STOP')" class="w-full py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg font-bold transition-colors flex items-center justify-center space-x-2 shadow-lg">
              <span class="material-icons text-base">pan_tool</span>
              <span>INITIATE SAFE STOP (CUSHION LOWER)</span>
            </button>
            <div class="grid grid-cols-2 gap-2">
              <button (click)="triggerMode('RETURN_TO_PORT')" class="py-2 bg-amber-600 hover:bg-amber-700 text-slate-950 rounded-lg font-bold transition-colors text-[11px]">
                RETURN TO PORT
              </button>
              <button (click)="triggerMode('REMOTE')" class="py-2 bg-cyan-600 hover:bg-cyan-700 text-slate-950 rounded-lg font-bold transition-colors text-[11px]">
                REMOTE INTERVENTION
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Active Alarms Log Card (2 columns wide) -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl flex flex-col space-y-4 lg:col-span-2">
        <div class="border-b border-slate-800 pb-3 flex justify-between items-center">
          <div>
            <h3 class="text-sm font-bold font-mono text-rose-400 flex items-center">
              <span class="material-icons text-base mr-1.5 text-rose-500">notifications_active</span>
              Real-time Active Safety Alarms Log
            </h3>
            <p class="text-xs text-slate-400">Supervisor alarms automatically logged to decision audit file</p>
          </div>
          <span class="px-2.5 py-1 bg-rose-950 border border-rose-800 text-rose-300 text-xs font-mono rounded-full font-bold">
            Alarms Count: {{ supervisor.alarms.length }}
          </span>
        </div>

        <div class="space-y-2 max-h-[320px] overflow-y-auto pr-1">
          @if (supervisor.alarms.length === 0) {
            <div class="p-8 text-center text-slate-500 font-mono text-xs border border-dashed border-slate-800 rounded-xl">
              ✓ All safety parameters nominal. No active supervisor alarms.
            </div>
          }
          @for (alarm of supervisor.alarms; track alarm) {
            <div class="p-3 bg-slate-950 border-l-4 border-rose-500 rounded-r-lg text-xs font-mono text-rose-200 shadow-md">
              {{ alarm }}
            </div>
          }
        </div>
      </div>
    </div>
  `,
  styles: [],
})
export class SafetySupervisorPanel {
  @Input() supervisor!: SafetySupervisorEvaluation;
  @Output() modeRequested = new EventEmitter<AutonomyMode>();

  triggerMode(mode: AutonomyMode): void {
    this.modeRequested.emit(mode);
  }
}
