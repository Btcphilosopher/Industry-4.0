import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EkfStateEstimate, RawSensorData, SensorFaults, SensorHealth, State6DOF } from '../models/maritime.types';

@Component({
  selector: 'app-sensor-fusion-panel',
  imports: [CommonModule],
  template: `
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-5">
      <!-- Column 1: Fault Injection Matrix -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl flex flex-col space-y-4">
        <div class="border-b border-slate-800 pb-3">
          <h3 class="text-sm font-bold font-mono text-rose-400 flex items-center">
            <span class="material-icons text-base mr-1.5 text-rose-500">warning</span>
            Cyber-Physical Fault Injection Matrix
          </h3>
          <p class="text-xs text-slate-400">Inject artificial sensor degradations & environmental anomalies</p>
        </div>

        <div class="space-y-2.5 font-mono text-xs">
          <label class="flex items-center justify-between p-2.5 rounded-lg border transition-colors cursor-pointer"
            [ngClass]="faults.gnssDenial ? 'bg-rose-950/40 border-rose-700 text-rose-300' : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'">
            <div class="flex items-center">
              <input type="checkbox" [checked]="faults.gnssDenial" (change)="toggleFault('gnssDenial')" class="accent-rose-500 mr-2.5">
              <span>GNSS Jamming / Blackout</span>
            </div>
            <span class="text-[10px] px-2 py-0.5 rounded" [ngClass]="faults.gnssDenial ? 'bg-rose-900 text-rose-200' : 'bg-slate-800 text-slate-500'">ACTIVE</span>
          </label>

          <label class="flex items-center justify-between p-2.5 rounded-lg border transition-colors cursor-pointer"
            [ngClass]="faults.gnssSpoofing ? 'bg-rose-950/40 border-rose-700 text-rose-300' : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'">
            <div class="flex items-center">
              <input type="checkbox" [checked]="faults.gnssSpoofing" (change)="toggleFault('gnssSpoofing')" class="accent-rose-500 mr-2.5">
              <span>GNSS Cyber Spoofing</span>
            </div>
            <span class="text-[10px] px-2 py-0.5 rounded" [ngClass]="faults.gnssSpoofing ? 'bg-rose-900 text-rose-200' : 'bg-slate-800 text-slate-500'">ACTIVE</span>
          </label>

          <label class="flex items-center justify-between p-2.5 rounded-lg border transition-colors cursor-pointer"
            [ngClass]="faults.imuDrift ? 'bg-amber-950/40 border-amber-700 text-amber-300' : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'">
            <div class="flex items-center">
              <input type="checkbox" [checked]="faults.imuDrift" (change)="toggleFault('imuDrift')" class="accent-amber-500 mr-2.5">
              <span>IMU Gyro Bias Drift</span>
            </div>
            <span class="text-[10px] px-2 py-0.5 rounded" [ngClass]="faults.imuDrift ? 'bg-amber-900 text-amber-200' : 'bg-slate-800 text-slate-500'">ACTIVE</span>
          </label>

          <label class="flex items-center justify-between p-2.5 rounded-lg border transition-colors cursor-pointer"
            [ngClass]="faults.radarBlackout ? 'bg-rose-950/40 border-rose-700 text-rose-300' : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'">
            <div class="flex items-center">
              <input type="checkbox" [checked]="faults.radarBlackout" (change)="toggleFault('radarBlackout')" class="accent-rose-500 mr-2.5">
              <span>Marine Radar Sea Clutter Blackout</span>
            </div>
            <span class="text-[10px] px-2 py-0.5 rounded" [ngClass]="faults.radarBlackout ? 'bg-rose-900 text-rose-200' : 'bg-slate-800 text-slate-500'">ACTIVE</span>
          </label>

          <label class="flex items-center justify-between p-2.5 rounded-lg border transition-colors cursor-pointer"
            [ngClass]="faults.lidarOcclusion ? 'bg-amber-950/40 border-amber-700 text-amber-300' : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'">
            <div class="flex items-center">
              <input type="checkbox" [checked]="faults.lidarOcclusion" (change)="toggleFault('lidarOcclusion')" class="accent-amber-500 mr-2.5">
              <span>LiDAR Dense Spray Occlusion</span>
            </div>
            <span class="text-[10px] px-2 py-0.5 rounded" [ngClass]="faults.lidarOcclusion ? 'bg-amber-900 text-amber-200' : 'bg-slate-800 text-slate-500'">ACTIVE</span>
          </label>

          <label class="flex items-center justify-between p-2.5 rounded-lg border transition-colors cursor-pointer"
            [ngClass]="faults.aisDropout ? 'bg-amber-950/40 border-amber-700 text-amber-300' : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'">
            <div class="flex items-center">
              <input type="checkbox" [checked]="faults.aisDropout" (change)="toggleFault('aisDropout')" class="accent-amber-500 mr-2.5">
              <span>AIS Transponder Packet Loss</span>
            </div>
            <span class="text-[10px] px-2 py-0.5 rounded" [ngClass]="faults.aisDropout ? 'bg-amber-900 text-amber-200' : 'bg-slate-800 text-slate-500'">ACTIVE</span>
          </label>

          <label class="flex items-center justify-between p-2.5 rounded-lg border transition-colors cursor-pointer"
            [ngClass]="faults.skirtLeakage ? 'bg-rose-950/40 border-rose-700 text-rose-300' : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'">
            <div class="flex items-center">
              <input type="checkbox" [checked]="faults.skirtLeakage" (change)="toggleFault('skirtLeakage')" class="accent-rose-500 mr-2.5">
              <span>Skirt Pressure Leakage / Tear</span>
            </div>
            <span class="text-[10px] px-2 py-0.5 rounded" [ngClass]="faults.skirtLeakage ? 'bg-rose-900 text-rose-200' : 'bg-slate-800 text-slate-500'">ACTIVE</span>
          </label>
        </div>
      </div>

      <!-- Column 2: Sensor Health Gauges -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl flex flex-col space-y-4">
        <div class="border-b border-slate-800 pb-3">
          <h3 class="text-sm font-bold font-mono text-cyan-400 flex items-center">
            <span class="material-icons text-base mr-1.5 text-cyan-400">sensors</span>
            Sensor Health & Diagnostics
          </h3>
          <p class="text-xs text-slate-400">Multi-sensor integrity confidence metrics (0.00 - 1.00)</p>
        </div>

        <div class="space-y-3 font-mono text-xs">
          <div>
            <div class="flex justify-between mb-1">
              <span class="text-slate-300">GNSS RTK Satellite Navigation</span>
              <span class="font-bold" [ngClass]="health.gnss > 0.7 ? 'text-emerald-400' : 'text-rose-400'">{{ (health.gnss * 100).toFixed(0) }}%</span>
            </div>
            <div class="w-full bg-slate-950 rounded-full h-2 border border-slate-800 overflow-hidden">
              <div class="h-full transition-all duration-300" [style.width.%]="health.gnss * 100" [ngClass]="health.gnss > 0.7 ? 'bg-emerald-500' : 'bg-rose-500'"></div>
            </div>
            <div class="text-[10px] text-slate-500 mt-0.5">Fix: {{ rawSensors.gnss.fixQuality }} (HDOP: {{ rawSensors.gnss.hdop }})</div>
          </div>

          <div>
            <div class="flex justify-between mb-1">
              <span class="text-slate-300">6-DOF Industrial IMU Gyro & Accelerometers</span>
              <span class="font-bold" [ngClass]="health.imu > 0.7 ? 'text-emerald-400' : 'text-amber-400'">{{ (health.imu * 100).toFixed(0) }}%</span>
            </div>
            <div class="w-full bg-slate-950 rounded-full h-2 border border-slate-800 overflow-hidden">
              <div class="h-full transition-all duration-300" [style.width.%]="health.imu * 100" [ngClass]="health.imu > 0.7 ? 'bg-emerald-500' : 'bg-amber-500'"></div>
            </div>
            <div class="text-[10px] text-slate-500 mt-0.5">Gyro Z Rate: {{ rawSensors.imu.gyroZ }} rad/s</div>
          </div>

          <div>
            <div class="flex justify-between mb-1">
              <span class="text-slate-300">360° X-Band Pulse Marine Radar</span>
              <span class="font-bold" [ngClass]="health.radar > 0.7 ? 'text-emerald-400' : 'text-rose-400'">{{ (health.radar * 100).toFixed(0) }}%</span>
            </div>
            <div class="w-full bg-slate-950 rounded-full h-2 border border-slate-800 overflow-hidden">
              <div class="h-full transition-all duration-300" [style.width.%]="health.radar * 100" [ngClass]="health.radar > 0.7 ? 'bg-emerald-500' : 'bg-rose-500'"></div>
            </div>
            <div class="text-[10px] text-slate-500 mt-0.5">Contacts Detected: {{ rawSensors.radar.contacts.length }}</div>
          </div>

          <div>
            <div class="flex justify-between mb-1">
              <span class="text-slate-300">3D Solid-State LiDAR Point Cloud</span>
              <span class="font-bold" [ngClass]="health.lidar > 0.7 ? 'text-emerald-400' : 'text-amber-400'">{{ (health.lidar * 100).toFixed(0) }}%</span>
            </div>
            <div class="w-full bg-slate-950 rounded-full h-2 border border-slate-800 overflow-hidden">
              <div class="h-full transition-all duration-300" [style.width.%]="health.lidar * 100" [ngClass]="health.lidar > 0.7 ? 'bg-emerald-500' : 'bg-amber-500'"></div>
            </div>
            <div class="text-[10px] text-slate-500 mt-0.5">Return Points: {{ rawSensors.lidar.points.length }} pts</div>
          </div>

          <div>
            <div class="flex justify-between mb-1">
              <span class="text-slate-300">AIS Class-A Transponder Receiver</span>
              <span class="font-bold" [ngClass]="health.ais > 0.7 ? 'text-emerald-400' : 'text-rose-400'">{{ (health.ais * 100).toFixed(0) }}%</span>
            </div>
            <div class="w-full bg-slate-950 rounded-full h-2 border border-slate-800 overflow-hidden">
              <div class="h-full transition-all duration-300" [style.width.%]="health.ais * 100" [ngClass]="health.ais > 0.7 ? 'bg-emerald-500' : 'bg-rose-500'"></div>
            </div>
            <div class="text-[10px] text-slate-500 mt-0.5">AIS Messages Broadcast: {{ rawSensors.ais.messages.length }}</div>
          </div>
        </div>
      </div>

      <!-- Column 3: EKF State Estimate vs True Physics -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl flex flex-col space-y-4">
        <div class="border-b border-slate-800 pb-3">
          <h3 class="text-sm font-bold font-mono text-emerald-400 flex items-center">
            <span class="material-icons text-base mr-1.5 text-emerald-400">alt_route</span>
            EKF State Estimation vs True Physics
          </h3>
          <p class="text-xs text-slate-400">Kalman Gain & Innovation Residual Analysis</p>
        </div>

        <div class="space-y-3 font-mono text-xs">
          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1.5">
            <div class="flex justify-between">
              <span class="text-slate-400">EKF Confidence Score:</span>
              <span class="font-bold text-cyan-400">{{ (ekf.confidenceScore * 100).toFixed(0) }}%</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Innovation Residual:</span>
              <span class="font-bold text-amber-400">{{ ekf.innovationResidual }} m</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Position 1-Sigma Boundary:</span>
              <span class="font-bold text-emerald-400">±{{ ekf.sigmaX }}m (X), ±{{ ekf.sigmaY }}m (Y)</span>
            </div>
          </div>

          <div class="border border-slate-800 rounded-lg overflow-hidden">
            <table class="w-full text-left border-collapse">
              <thead>
                <tr class="bg-slate-950 text-slate-400 border-b border-slate-800">
                  <th class="py-1.5 px-2">Variable</th>
                  <th class="py-1.5 px-2">True State</th>
                  <th class="py-1.5 px-2">EKF Estimate</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-800/60">
                <tr>
                  <td class="py-1.5 px-2 text-slate-300">Pos East (X)</td>
                  <td class="py-1.5 px-2 text-slate-400">{{ trueState.x.toFixed(1) }}m</td>
                  <td class="py-1.5 px-2 text-cyan-400 font-bold">{{ ekf.x.toFixed(1) }}m</td>
                </tr>
                <tr>
                  <td class="py-1.5 px-2 text-slate-300">Pos North (Y)</td>
                  <td class="py-1.5 px-2 text-slate-400">{{ trueState.y.toFixed(1) }}m</td>
                  <td class="py-1.5 px-2 text-cyan-400 font-bold">{{ ekf.y.toFixed(1) }}m</td>
                </tr>
                <tr>
                  <td class="py-1.5 px-2 text-slate-300">Surge Vel (U)</td>
                  <td class="py-1.5 px-2 text-slate-400">{{ (trueState.u / 0.5144).toFixed(1) }} kts</td>
                  <td class="py-1.5 px-2 text-cyan-400 font-bold">{{ (ekf.u / 0.5144).toFixed(1) }} kts</td>
                </tr>
                <tr>
                  <td class="py-1.5 px-2 text-slate-300">Sway Vel (V)</td>
                  <td class="py-1.5 px-2 text-slate-400">{{ (trueState.v / 0.5144).toFixed(1) }} kts</td>
                  <td class="py-1.5 px-2 text-cyan-400 font-bold">{{ (ekf.v / 0.5144).toFixed(1) }} kts</td>
                </tr>
                <tr>
                  <td class="py-1.5 px-2 text-slate-300">Yaw Heading</td>
                  <td class="py-1.5 px-2 text-slate-400">{{ ((trueState.yaw * 180) / 3.1415).toFixed(1) }}°</td>
                  <td class="py-1.5 px-2 text-cyan-400 font-bold">{{ ((ekf.yaw * 180) / 3.1415).toFixed(1) }}°</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [],
})
export class SensorFusionPanel {
  @Input() trueState!: State6DOF;
  @Input() ekf!: EkfStateEstimate;
  @Input() rawSensors!: RawSensorData;
  @Input() health!: SensorHealth;
  @Input() faults!: SensorFaults;

  @Output() faultsChanged = new EventEmitter<SensorFaults>();

  toggleFault(key: keyof SensorFaults): void {
    const updated = { ...this.faults, [key]: !this.faults[key] };
    this.faultsChanged.emit(updated);
  }
}
