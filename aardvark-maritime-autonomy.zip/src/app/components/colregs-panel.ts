import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WorldObject } from '../models/maritime.types';

@Component({
  selector: 'app-colregs-panel',
  imports: [CommonModule],
  template: `
    <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl flex flex-col space-y-4">
      <div class="flex items-center justify-between border-b border-slate-800 pb-3">
        <div>
          <h2 class="text-lg font-bold font-mono text-slate-100 flex items-center">
            <span class="w-3 h-3 rounded-full bg-rose-500 mr-2 animate-pulse"></span>
            COLREGs Encounter Risk Matrix & Traffic Management
          </h2>
          <p class="text-xs text-slate-400">
            Real-time Closest Point of Approach (CPA) & Time to CPA (TCPA) according to COLREGs 1972 Rules 13-18
          </p>
        </div>
        <div class="text-right">
          <span class="text-xs font-mono text-cyan-400 bg-cyan-950/60 border border-cyan-800 px-3 py-1 rounded-full">
            Active AIS/Radar Contacts: {{ targets.length }}
          </span>
        </div>
      </div>

      <!-- Contacts Table -->
      <div class="overflow-x-auto">
        <table class="w-full text-left text-xs text-slate-300 font-mono border-collapse">
          <thead>
            <tr class="bg-slate-950/70 border-b border-slate-800 text-slate-400 uppercase tracking-wider">
              <th class="py-2.5 px-3">Target ID / Vessel</th>
              <th class="py-2.5 px-3">Type</th>
              <th class="py-2.5 px-3">Range (m)</th>
              <th class="py-2.5 px-3">Speed (kts)</th>
              <th class="py-2.5 px-3">Course (°)</th>
              <th class="py-2.5 px-3">CPA (m)</th>
              <th class="py-2.5 px-3">TCPA (s)</th>
              <th class="py-2.5 px-3">COLREGs Encounter</th>
              <th class="py-2.5 px-3">Own Craft Role</th>
              <th class="py-2.5 px-3">Action Advice</th>
              <th class="py-2.5 px-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-800/60">
            @for (target of targets; track target.id) {
              <tr [ngClass]="{'bg-rose-950/20': target.riskLevel === 'CRITICAL', 'bg-amber-950/15': target.riskLevel === 'HIGH'}" class="hover:bg-slate-800/40 transition-colors">
                <td class="py-3 px-3 font-bold text-slate-100">
                  <div>{{ target.name }}</div>
                  <div class="text-[10px] text-slate-500">MMSI: {{ target.mmsi || 'N/A' }}</div>
                </td>
                <td class="py-3 px-3">
                  <span class="px-2 py-0.5 rounded text-[10px] font-bold"
                    [ngClass]="{
                      'bg-blue-950 text-blue-300 border border-blue-800': target.type === 'CARGO_VESSEL',
                      'bg-purple-950 text-purple-300 border border-purple-800': target.type === 'TANKER',
                      'bg-amber-950 text-amber-300 border border-amber-800': target.type === 'FISHING_BOAT',
                      'bg-emerald-950 text-emerald-300 border border-emerald-800': target.type === 'WORKBOAT',
                      'bg-slate-800 text-slate-400': target.type === 'BUOY' || target.type === 'SHALLOW_BANK'
                    }">
                    {{ target.type }}
                  </span>
                </td>
                <td class="py-3 px-3 text-cyan-300 font-bold">{{ target.distanceM }}m</td>
                <td class="py-3 px-3">{{ target.speedKnots }} kts</td>
                <td class="py-3 px-3">{{ target.courseDeg }}°</td>
                <td class="py-3 px-3 font-bold" [ngClass]="target.cpaM < 400 ? 'text-rose-400' : 'text-emerald-400'">
                  {{ target.cpaM }}m
                </td>
                <td class="py-3 px-3 font-bold" [ngClass]="target.tcpaS > 0 && target.tcpaS < 120 ? 'text-rose-400' : 'text-slate-300'">
                  {{ target.tcpaS > 0 ? target.tcpaS + 's' : 'Passed / N/A' }}
                </td>
                <td class="py-3 px-3">
                  <span class="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider"
                    [ngClass]="{
                      'bg-rose-950 text-rose-300 border border-rose-800': target.colregsSituation === 'HEAD_ON' || target.colregsSituation === 'CROSSING_GIVE_WAY',
                      'bg-amber-950 text-amber-300 border border-amber-800': target.colregsSituation === 'OVERTAKING_GIVE_WAY' || target.colregsSituation === 'SPECIAL_STATUS_VESSEL',
                      'bg-slate-800 text-slate-300 border border-slate-700': target.colregsSituation === 'CROSSING_STAND_ON' || target.colregsSituation === 'OVERTAKING_STAND_ON',
                      'bg-teal-950 text-teal-300 border border-teal-800': target.colregsSituation === 'RESTRICTED_WATERS',
                      'bg-emerald-950 text-emerald-300 border border-emerald-800': target.colregsSituation === 'CLEAR'
                    }">
                    {{ target.colregsSituation }}
                  </span>
                  <div class="text-[9px] text-slate-400 mt-0.5">{{ target.ruleReference }}</div>
                </td>
                <td class="py-3 px-3">
                  <span class="px-2 py-0.5 rounded text-[10px] font-bold"
                    [ngClass]="{
                      'bg-rose-900/80 text-rose-200 border border-rose-600': target.navigationRole === 'GIVE_WAY',
                      'bg-blue-900/80 text-blue-200 border border-blue-600': target.navigationRole === 'STAND_ON',
                      'bg-slate-800 text-slate-400': target.navigationRole === 'NEUTRAL'
                    }">
                    {{ target.navigationRole }}
                  </span>
                </td>
                <td class="py-3 px-3 text-slate-300 text-[11px] leading-snug max-w-xs">
                  {{ target.actionAdvice }}
                </td>
                <td class="py-3 px-3 text-right">
                  <button (click)="selectTarget(target)" class="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-cyan-400 rounded border border-slate-700 transition-colors">
                    Inspect
                  </button>
                </td>
              </tr>
            }
          </tbody>
        </table>
      </div>

      <!-- Target Controller Modal / Sub-Card -->
      @if (selectedTarget) {
        <div class="bg-slate-950 border border-cyan-800/80 rounded-xl p-4 mt-2 shadow-xl">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
            <h3 class="text-sm font-bold font-mono text-cyan-400 flex items-center">
              <span class="material-icons text-base mr-1.5">radar</span>
              Target Trajectory Manipulator: {{ selectedTarget.name }}
            </h3>
            <button (click)="selectedTarget = null" class="text-slate-400 hover:text-white text-xs font-mono">✕ Close</button>
          </div>
          <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
            <div>
              <label for="tgtCourseInput" class="text-slate-400 mb-1 block">Target Course: {{ selectedTarget.courseDeg }}°</label>
              <input id="tgtCourseInput" type="range" min="0" max="359" [value]="selectedTarget.courseDeg" (input)="updateTargetCourse($event)" class="w-full accent-cyan-500">
            </div>
            <div>
              <label for="tgtSpeedInput" class="text-slate-400 mb-1 block">Target Speed: {{ selectedTarget.speedKnots }} kts</label>
              <input id="tgtSpeedInput" type="range" min="0" max="35" [value]="selectedTarget.speedKnots" (input)="updateTargetSpeed($event)" class="w-full accent-cyan-500">
            </div>
            <div>
              <label for="tgtXInput" class="text-slate-400 mb-1 block">Distance Offset X: {{ selectedTarget.x }}m</label>
              <input id="tgtXInput" type="range" min="-3000" max="3000" [value]="selectedTarget.x" (input)="updateTargetX($event)" class="w-full accent-cyan-500">
            </div>
          </div>
        </div>
      }
    </div>
  `,
  styles: [],
})
export class ColregsPanel {
  @Input() targets: WorldObject[] = [];
  @Output() targetUpdated = new EventEmitter<WorldObject>();

  selectedTarget: WorldObject | null = null;

  selectTarget(target: WorldObject): void {
    this.selectedTarget = { ...target };
  }

  updateTargetCourse(event: Event): void {
    if (!this.selectedTarget) return;
    const val = Number((event.target as HTMLInputElement).value);
    this.selectedTarget.courseDeg = val;
    this.targetUpdated.emit(this.selectedTarget);
  }

  updateTargetSpeed(event: Event): void {
    if (!this.selectedTarget) return;
    const val = Number((event.target as HTMLInputElement).value);
    this.selectedTarget.speedKnots = val;
    this.targetUpdated.emit(this.selectedTarget);
  }

  updateTargetX(event: Event): void {
    if (!this.selectedTarget) return;
    const val = Number((event.target as HTMLInputElement).value);
    this.selectedTarget.x = val;
    this.targetUpdated.emit(this.selectedTarget);
  }
}
