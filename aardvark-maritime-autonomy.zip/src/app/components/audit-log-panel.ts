import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DecisionAuditEvent } from '../models/maritime.types';

@Component({
  selector: 'app-audit-log-panel',
  imports: [CommonModule],
  template: `
    <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl flex flex-col space-y-4">
      <div class="flex items-center justify-between border-b border-slate-800 pb-3">
        <div>
          <h2 class="text-lg font-bold font-mono text-emerald-400 flex items-center">
            <span class="material-icons text-base mr-2 text-emerald-400">receipt_long</span>
            Black Box Autonomy Decision Audit Recorder
          </h2>
          <p class="text-xs text-slate-400">
            Immutable causal snapshots of state estimates, threat evaluations, control vector adjustments & mode transitions
          </p>
        </div>
        <div class="flex items-center space-x-2">
          <button (click)="exportJson()" class="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-400 font-mono text-xs rounded border border-slate-700 transition-colors flex items-center space-x-1">
            <span class="material-icons text-sm">download</span>
            <span>Export JSON Audit</span>
          </button>
          <button (click)="exportRScript()" class="px-3 py-1.5 bg-purple-900/60 hover:bg-purple-800 text-purple-200 font-mono text-xs rounded border border-purple-700 transition-colors flex items-center space-x-1">
            <span class="material-icons text-sm">code</span>
            <span>Export R Safety Analysis Script</span>
          </button>
        </div>
      </div>

      <!-- Events List -->
      <div class="overflow-x-auto max-h-[480px]">
        <table class="w-full text-left text-xs font-mono border-collapse">
          <thead>
            <tr class="bg-slate-950 text-slate-400 border-b border-slate-800">
              <th class="py-2.5 px-3">Timestamp / Event ID</th>
              <th class="py-2.5 px-3">Event Type</th>
              <th class="py-2.5 px-3">Autonomy Mode</th>
              <th class="py-2.5 px-3">Description</th>
              <th class="py-2.5 px-3">Causal State Snapshot</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-800/60">
            @for (ev of events; track ev.eventId) {
              <tr class="hover:bg-slate-800/40 transition-colors">
                <td class="py-2.5 px-3 font-bold text-slate-300">
                  <div>{{ ev.timestamp | date:'HH:mm:ss.SSS' }}</div>
                  <div class="text-[10px] text-slate-500">{{ ev.eventId }}</div>
                </td>
                <td class="py-2.5 px-3">
                  <span class="px-2 py-0.5 rounded text-[10px] font-bold"
                    [ngClass]="{
                      'bg-cyan-950 text-cyan-300 border border-cyan-800': ev.eventType === 'TRAJECTORY_OPTIMISED',
                      'bg-rose-950 text-rose-300 border border-rose-800': ev.eventType === 'SAFETY_SUPERVISOR_EVALUATED' || ev.eventType === 'SENSOR_FAULT_INJECTED',
                      'bg-amber-950 text-amber-300 border border-amber-800': ev.eventType === 'COLLISION_RISK_EVALUATED' || ev.eventType === 'OPERATOR_INTERVENTION',
                      'bg-purple-950 text-purple-300 border border-purple-800': ev.eventType === 'MODE_TRANSITION',
                      'bg-slate-800 text-slate-300': ev.eventType === 'STATE_ESTIMATE_UPDATED' || ev.eventType === 'OBJECT_DETECTED'
                    }">
                    {{ ev.eventType }}
                  </span>
                </td>
                <td class="py-2.5 px-3 text-cyan-400 font-bold">{{ ev.autonomyMode }}</td>
                <td class="py-2.5 px-3 text-slate-200 text-[11px] leading-snug">{{ ev.description }}</td>
                <td class="py-2.5 px-3 text-slate-400 text-[10px]">
                  Pos: ({{ ev.causalSnapshot.state.x.toFixed(0) }}, {{ ev.causalSnapshot.state.y.toFixed(0) }}) | Risk: {{ ev.causalSnapshot.maxRiskScore }} | Cmd Rudder: {{ ev.causalSnapshot.commandRudder }}°
                </td>
              </tr>
            }
          </tbody>
        </table>
      </div>
    </div>
  `,
  styles: [],
})
export class AuditLogPanel {
  @Input() events: DecisionAuditEvent[] = [];
  @Output() jsonExportRequested = new EventEmitter<void>();
  @Output() rScriptExportRequested = new EventEmitter<void>();

  exportJson(): void {
    this.jsonExportRequested.emit();
  }

  exportRScript(): void {
    this.rScriptExportRequested.emit();
  }
}
