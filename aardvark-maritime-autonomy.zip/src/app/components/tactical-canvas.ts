import { Component, ElementRef, Input, OnChanges, ViewChild, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CandidateTrajectory, EkfStateEstimate, State6DOF, WorldObject } from '../models/maritime.types';

@Component({
  selector: 'app-tactical-canvas',
  imports: [CommonModule],
  template: `
    <div class="relative w-full h-[540px] bg-slate-950 rounded-xl border border-slate-800 overflow-hidden shadow-2xl flex flex-col">
      <!-- Radar Overlay Info Bar -->
      <div class="absolute top-3 left-3 z-10 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-700/60 text-xs font-mono text-cyan-400 flex items-center space-x-3 shadow-lg">
        <span class="flex items-center"><span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping mr-1.5"></span>RADAR 360° SWEEP</span>
        <span>RANGE: 4.0 NM</span>
        <span>GRID: 500m</span>
        <span class="text-amber-400">EKF SIGMA: ±{{ ekf.sigmaX }}m</span>
      </div>

      <div class="absolute top-3 right-3 z-10 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-700/60 text-xs font-mono text-slate-300 flex items-center space-x-3 shadow-lg">
        <span class="text-emerald-400">● OWN CRAFT</span>
        <span class="text-cyan-400">── OPTIMAL MPC</span>
        <span class="text-amber-400">⋯ CANDIDATES</span>
        <span class="text-rose-400">▲ AIS TARGETS</span>
      </div>

      <canvas #radarCanvas class="w-full h-full block cursor-crosshair"></canvas>
    </div>
  `,
  styles: [],
})
export class TacticalCanvas implements AfterViewInit, OnChanges {
  @ViewChild('radarCanvas') canvasRef!: ElementRef<HTMLCanvasElement>;

  @Input() state!: State6DOF;
  @Input() ekf!: EkfStateEstimate;
  @Input() targets: WorldObject[] = [];
  @Input() candidateTrajectories: CandidateTrajectory[] = [];
  @Input() selectedTrajectory: CandidateTrajectory | null = null;
  @Input() sweepAngleDeg = 0;

  private ctx!: CanvasRenderingContext2D;

  ngAfterViewInit(): void {
    const canvas = this.canvasRef.nativeElement;
    canvas.width = canvas.parentElement?.clientWidth || 800;
    canvas.height = canvas.parentElement?.clientHeight || 540;
    this.ctx = canvas.getContext('2d')!;
    this.draw();
  }

  ngOnChanges(): void {
    if (this.ctx) {
      this.draw();
    }
  }

  private draw(): void {
    const canvas = this.canvasRef.nativeElement;
    const ctx = this.ctx;
    const w = canvas.width;
    const h = canvas.height;
    const cx = w / 2;
    const cy = h / 2;
    const scale = 0.12; // 1 pixel = ~8.3 meters

    // Background
    ctx.fillStyle = '#020617';
    ctx.fillRect(0, 0, w, h);

    // Range Rings (500m, 1000m, 1500m, 2000m)
    ctx.strokeStyle = '#0e7490';
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 4]);

    const rings = [500, 1000, 1500, 2000, 2500];
    for (const r of rings) {
      const radiusPx = r * scale;
      ctx.beginPath();
      ctx.arc(cx, cy, radiusPx, 0, 2 * Math.PI);
      ctx.stroke();

      // Range text label
      ctx.fillStyle = '#06b6d4';
      ctx.font = '10px monospace';
      ctx.fillText(`${r}m`, cx + 4, cy - radiusPx + 12);
    }
    ctx.setLineDash([]);

    // Crosshair axis
    ctx.strokeStyle = '#1e293b';
    ctx.beginPath();
    ctx.moveTo(cx, 0);
    ctx.lineTo(cx, h);
    ctx.moveTo(0, cy);
    ctx.lineTo(w, cy);
    ctx.stroke();

    // Radar Sweep Line & Sector
    const sweepRad = (this.sweepAngleDeg * Math.PI) / 180;
    const sweepLen = Math.max(w, h);

    const grad = ctx.createConicGradient(sweepRad, cx, cy);
    grad.addColorStop(0, 'rgba(6, 182, 212, 0.25)');
    grad.addColorStop(0.1, 'rgba(6, 182, 212, 0.05)');
    grad.addColorStop(0.2, 'rgba(6, 182, 212, 0)');
    grad.addColorStop(1, 'rgba(6, 182, 212, 0)');

    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(cx, cy, sweepLen, 0, 2 * Math.PI);
    ctx.fill();

    ctx.strokeStyle = 'rgba(6, 182, 212, 0.8)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.lineTo(cx + sweepLen * Math.cos(sweepRad), cy + sweepLen * Math.sin(sweepRad));
    ctx.stroke();

    // Render EKF Uncertainty Ellipse around Own Craft position
    const ekfPxX = cx + (this.ekf.x - this.state.x) * scale;
    const ekfPxY = cy - (this.ekf.y - this.state.y) * scale;
    const rxPx = Math.max(8, this.ekf.sigmaX * scale * 3);
    const ryPx = Math.max(8, this.ekf.sigmaY * scale * 3);

    ctx.strokeStyle = 'rgba(245, 158, 11, 0.7)';
    ctx.fillStyle = 'rgba(245, 158, 11, 0.1)';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.ellipse(ekfPxX, ekfPxY, rxPx, ryPx, 0, 0, 2 * Math.PI);
    ctx.fill();
    ctx.stroke();
    ctx.setLineDash([]);

    // Render Candidate MPC Trajectories
    for (const traj of this.candidateTrajectories) {
      if (traj.points.length < 2) continue;
      ctx.strokeStyle = traj.isSelected ? '#06b6d4' : 'rgba(245, 158, 11, 0.35)';
      ctx.lineWidth = traj.isSelected ? 3 : 1;

      ctx.beginPath();
      for (let i = 0; i < traj.points.length; i++) {
        const pt = traj.points[i];
        const px = cx + (pt.x - this.state.x) * scale;
        const py = cy - (pt.y - this.state.y) * scale;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.stroke();
    }

    // Render Targets / World Objects
    for (const tgt of this.targets) {
      const tgtPxX = cx + (tgt.x - this.state.x) * scale;
      const tgtPxY = cy - (tgt.y - this.state.y) * scale;

      // Color coding by risk level
      let color = '#38bdf8';
      if (tgt.riskLevel === 'CRITICAL') color = '#ef4444';
      else if (tgt.riskLevel === 'HIGH') color = '#f97316';
      else if (tgt.riskLevel === 'MODERATE') color = '#eab308';

      // Velocity vector line (10 seconds ahead)
      const velVxPx = tgt.vx * 10 * scale;
      const velVyPx = -tgt.vy * 10 * scale;

      ctx.strokeStyle = color;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(tgtPxX, tgtPxY);
      ctx.lineTo(tgtPxX + velVxPx, tgtPxY + velVyPx);
      ctx.stroke();

      // Target Symbol (Diamond for ships, Circle for buoys/obstacles)
      ctx.fillStyle = color;
      if (tgt.type === 'BUOY' || tgt.type === 'OBSTACLE') {
        ctx.beginPath();
        ctx.arc(tgtPxX, tgtPxY, 6, 0, 2 * Math.PI);
        ctx.fill();
      } else {
        ctx.beginPath();
        ctx.moveTo(tgtPxX, tgtPxY - 8);
        ctx.lineTo(tgtPxX + 6, tgtPxY + 6);
        ctx.lineTo(tgtPxX - 6, tgtPxY + 6);
        ctx.closePath();
        ctx.fill();
      }

      // CPA Danger Ring if high risk
      if (tgt.riskLevel === 'HIGH' || tgt.riskLevel === 'CRITICAL') {
        ctx.strokeStyle = 'rgba(239, 68, 68, 0.5)';
        ctx.lineWidth = 1;
        ctx.setLineDash([2, 2]);
        ctx.beginPath();
        ctx.arc(tgtPxX, tgtPxY, Math.max(12, tgt.cpaM * scale), 0, 2 * Math.PI);
        ctx.stroke();
        ctx.setLineDash([]);
      }

      // Target Label
      ctx.fillStyle = '#f8fafc';
      ctx.font = 'bold 10px sans-serif';
      ctx.fillText(`${tgt.name}`, tgtPxX + 10, tgtPxY - 4);
      ctx.fillStyle = color;
      ctx.font = '9px monospace';
      ctx.fillText(`${tgt.speedKnots}kts | CPA: ${tgt.cpaM}m`, tgtPxX + 10, tgtPxY + 8);
    }

    // Render Own Ship (Hovercraft Contour) at Center
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(this.state.yaw - Math.PI / 2); // 0 rad heading North (up on canvas)

    // Hovercraft Hull Blueprint Contour
    const hullL = 28.5 * scale * 2.5; // Scaled up slightly for clear visibility
    const hullW = 12.0 * scale * 2.5;

    // Cushion Air Glow
    ctx.fillStyle = 'rgba(16, 185, 129, 0.25)';
    ctx.beginPath();
    ctx.ellipse(0, 0, hullW / 2 + 4, hullL / 2 + 4, 0, 0, 2 * Math.PI);
    ctx.fill();

    // Skirt Outline
    ctx.strokeStyle = '#10b981';
    ctx.lineWidth = 2.5;
    ctx.fillStyle = '#0f172a';
    ctx.beginPath();
    ctx.roundRect(-hullW / 2, -hullL / 2, hullW, hullL, 6);
    ctx.fill();
    ctx.stroke();

    // Twin Propeller Fans at Rear
    ctx.fillStyle = '#06b6d4';
    ctx.fillRect(-hullW / 3 - 3, hullL / 2 - 4, 6, 8);
    ctx.fillRect(hullW / 3 - 3, hullL / 2 - 4, 6, 8);

    // Bow Arrow
    ctx.fillStyle = '#34d399';
    ctx.beginPath();
    ctx.moveTo(0, -hullL / 2 - 6);
    ctx.lineTo(4, -hullL / 2);
    ctx.lineTo(-4, -hullL / 2);
    ctx.closePath();
    ctx.fill();

    ctx.restore();

    // Heading Compass Indicator (North Rose)
    ctx.fillStyle = '#64748b';
    ctx.font = 'bold 12px sans-serif';
    ctx.fillText('N', cx - 4, 20);
    ctx.fillText('S', cx - 4, h - 10);
    ctx.fillText('E', w - 16, cy + 4);
    ctx.fillText('W', 8, cy + 4);
  }
}
