import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MpcResult } from '../models/maritime.types';

@Component({
  selector: 'app-mpc-planner-panel',
  imports: [CommonModule],
  template: `
    <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl flex flex-col space-y-4">
      <div class="flex items-center justify-between border-b border-slate-800 pb-3">
        <div>
          <h2 class="text-lg font-bold font-mono text-cyan-400 flex items-center">
            <span class="material-icons text-base mr-2">timeline</span>
            Nonlinear Model Predictive Control (NMPC) Receding Horizon Trajectory Optimization
          </h2>
          <p class="text-xs text-slate-400">
            Real-time candidate trajectory rollout evaluation over {{ mpcResult.horizonSec }}s horizon
          </p>
        </div>
        <div class="flex items-center space-x-3 text-xs font-mono">
          <span class="bg-slate-950 px-3 py-1 rounded border border-slate-800 text-slate-300">
            Sampled Rollouts: <strong class="text-cyan-400">{{ mpcResult.candidates.length }}</strong>
          </span>
          <span class="bg-slate-950 px-3 py-1 rounded border border-slate-800 text-slate-300">
            Min Total Cost: <strong class="text-emerald-400">{{ mpcResult.cost }}</strong>
          </span>
        </div>
      </div>

      <!-- Optimal Command Vector Summary -->
      <div class="bg-slate-950 border border-cyan-800/80 rounded-xl p-4 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
        <div>
          <span class="text-slate-400 block mb-1">Opt Command Rudder</span>
          <span class="text-lg font-bold text-cyan-400">{{ mpcResult.optimalControl.rudderDeg > 0 ? '+' : '' }}{{ mpcResult.optimalControl.rudderDeg }}°</span>
        </div>
        <div>
          <span class="text-slate-400 block mb-1">Opt Thrust Port / Stbd</span>
          <span class="text-lg font-bold text-emerald-400">{{ mpcResult.optimalControl.thrustPortPct }}% / {{ mpcResult.optimalControl.thrustStbdPct }}%</span>
        </div>
        <div>
          <span class="text-slate-400 block mb-1">Bow Thruster Effort</span>
          <span class="text-lg font-bold text-amber-400">{{ mpcResult.optimalControl.bowThrusterPct }}%</span>
        </div>
        <div>
          <span class="text-slate-400 block mb-1">Prediction Horizon</span>
          <span class="text-lg font-bold text-purple-400">{{ mpcResult.horizonSec }} seconds</span>
        </div>
      </div>

      <!-- Candidate Rollout Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        @for (cand of mpcResult.candidates; track cand.id) {
          <div class="p-4 rounded-xl border transition-all flex flex-col justify-between"
            [ngClass]="cand.isSelected ? 'bg-cyan-950/30 border-cyan-500 shadow-lg shadow-cyan-950/50' : 'bg-slate-950/70 border-slate-800 hover:border-slate-700'">
            <div>
              <div class="flex items-center justify-between mb-2">
                <span class="font-mono text-xs font-bold" [ngClass]="cand.isSelected ? 'text-cyan-400' : 'text-slate-300'">
                  {{ cand.id }} {{ cand.isSelected ? '(SELECTED OPTIMAL)' : '' }}
                </span>
                <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold"
                  [ngClass]="cand.isSelected ? 'bg-cyan-500 text-slate-950' : 'bg-slate-800 text-slate-400'">
                  Cost: {{ cand.totalCost }}
                </span>
              </div>

              <div class="grid grid-cols-2 gap-2 text-[11px] font-mono mb-3 text-slate-300">
                <div>Rudder: <strong class="text-slate-100">{{ cand.rudderDeg > 0 ? '+' : '' }}{{ cand.rudderDeg }}°</strong></div>
                <div>Thrust: <strong class="text-slate-100">{{ cand.thrustPct }}%</strong></div>
                <div>Min Clear: <strong class="text-slate-100">{{ cand.minObstacleDistM }}m</strong></div>
                <div>Horizon Pt: <strong class="text-slate-100">{{ cand.points.length }} pts</strong></div>
              </div>

              <!-- Cost Breakdown Stacked Bar -->
              <div class="space-y-1">
                <div class="text-[10px] font-mono text-slate-400 flex justify-between">
                  <span>Cost Components</span>
                  <span class="text-slate-500">Cross-track / Coll / Head / Energy</span>
                </div>
                <div class="w-full h-2.5 bg-slate-900 rounded-full overflow-hidden flex">
                  <div [style.width.%]="(cand.crossTrackCost / Math.max(1, cand.totalCost)) * 100" class="bg-blue-500" title="Cross-track"></div>
                  <div [style.width.%]="(cand.collisionCost / Math.max(1, cand.totalCost)) * 100" class="bg-rose-500" title="Collision"></div>
                  <div [style.width.%]="(cand.headingCost / Math.max(1, cand.totalCost)) * 100" class="bg-amber-500" title="Heading"></div>
                  <div [style.width.%]="(cand.energyCost / Math.max(1, cand.totalCost)) * 100" class="bg-emerald-500" title="Energy"></div>
                </div>
              </div>
            </div>
          </div>
        }
      </div>
    </div>
  `,
  styles: [],
})
export class MpcPlannerPanel {
  @Input() mpcResult!: MpcResult;
  protected Math = Math;
}
