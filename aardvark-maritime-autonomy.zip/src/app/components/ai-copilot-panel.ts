import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CopilotMessage } from '../services/gemini-copilot.service';

@Component({
  selector: 'app-ai-copilot-panel',
  imports: [CommonModule, FormsModule],
  template: `
    <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl flex flex-col h-[560px]">
      <div class="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
        <div class="flex items-center space-x-3">
          <div class="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-600 to-emerald-500 flex items-center justify-center text-slate-950 font-bold shadow-lg">
            <span class="material-icons text-xl">psychology</span>
          </div>
          <div>
            <h2 class="text-base font-bold font-mono text-cyan-400">Gemini AI Maritime Safety Officer & Navigation Co-Pilot</h2>
            <p class="text-xs text-slate-400">Grounded in COLREGs 1972 Rules, 6-DOF Hovercraft Dynamics & Prognostics</p>
          </div>
        </div>
        <span class="px-3 py-1 bg-cyan-950 border border-cyan-800 text-cyan-300 text-xs font-mono rounded-full flex items-center">
          <span class="w-2 h-2 rounded-full bg-emerald-400 mr-2 animate-ping"></span>
          Gemini 2.5 Flash Online
        </span>
      </div>

      <!-- Quick Suggestion Chips -->
      <div class="flex flex-wrap gap-2 mb-3 font-mono text-xs">
        <button (click)="sendPreset('Explain current COLREGs risk with surrounding vessels')" class="px-3 py-1 bg-slate-950 hover:bg-slate-800 text-slate-300 rounded-lg border border-slate-800 transition-colors">
          ⚖️ Explain COLREGs Risk
        </button>
        <button (click)="sendPreset('What is the Remaining Useful Life (RUL) of the hovercraft skirt and bearings?')" class="px-3 py-1 bg-slate-950 hover:bg-slate-800 text-slate-300 rounded-lg border border-slate-800 transition-colors">
          🔧 Skirt & Bearing RUL
        </button>
        <button (click)="sendPreset('Recommend safe operating speed for current Beaufort sea state and wave height')" class="px-3 py-1 bg-slate-950 hover:bg-slate-800 text-slate-300 rounded-lg border border-slate-800 transition-colors">
          🌊 Sea State Speed Recs
        </button>
        <button (click)="sendPreset('Summarize active safety supervisor alarms and veto status')" class="px-3 py-1 bg-slate-950 hover:bg-slate-800 text-slate-300 rounded-lg border border-slate-800 transition-colors">
          🛡️ Safety Audit Briefing
        </button>
      </div>

      <!-- Message History List -->
      <div class="flex-1 overflow-y-auto space-y-3 p-3 bg-slate-950/80 rounded-xl border border-slate-800 font-mono text-xs mb-3">
        @if (messages.length === 0) {
          <div class="text-center text-slate-500 py-12">
            Ask Gemini AI Co-Pilot any question regarding COLREGs collision avoidance, EKF sensor health, MPC trajectory optimization, or hovercraft mechanical diagnostics.
          </div>
        }
        @for (msg of messages; track $index) {
          <div class="flex flex-col" [ngClass]="msg.sender === 'user' ? 'items-end' : 'items-start'">
            <div class="flex items-center space-x-1.5 text-[10px] text-slate-500 mb-1">
              <span>{{ msg.sender === 'user' ? 'Operator' : 'Gemini Co-Pilot' }}</span>
              <span>•</span>
              <span>{{ msg.timestamp }}</span>
            </div>
            <div class="p-3.5 rounded-2xl max-w-2xl leading-relaxed text-xs shadow-md whitespace-pre-wrap"
              [ngClass]="msg.sender === 'user' ? 'bg-cyan-600 text-slate-950 font-bold rounded-tr-none' : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-tl-none'">
              {{ msg.text }}
            </div>
          </div>
        }
        @if (loading) {
          <div class="flex items-center space-x-2 text-cyan-400 font-mono text-xs p-2">
            <span class="w-2 h-2 rounded-full bg-cyan-400 animate-ping"></span>
            <span>Gemini is evaluating maritime telemetry & COLREGs rulebase...</span>
          </div>
        }
      </div>

      <!-- Input Box -->
      <form (submit)="onSubmit($event)" class="flex space-x-2">
        <input type="text" [(ngModel)]="inputQuery" name="query" placeholder="Ask AI Maritime Safety Officer..."
          class="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs font-mono text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500">
        <button type="submit" [disabled]="loading || !inputQuery.trim()"
          class="px-5 py-2.5 bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 text-slate-950 font-bold font-mono text-xs rounded-xl transition-colors flex items-center space-x-1 shadow-lg">
          <span>Send</span>
          <span class="material-icons text-sm">send</span>
        </button>
      </form>
    </div>
  `,
  styles: [],
})
export class AiCopilotPanel {
  @Input() messages: CopilotMessage[] = [];
  @Input() loading = false;
  @Output() askRequested = new EventEmitter<string>();

  inputQuery = '';

  onSubmit(event: Event): void {
    event.preventDefault();
    if (!this.inputQuery.trim() || this.loading) return;
    const q = this.inputQuery.trim();
    this.inputQuery = '';
    this.askRequested.emit(q);
  }

  sendPreset(text: string): void {
    if (this.loading) return;
    this.askRequested.emit(text);
  }
}
