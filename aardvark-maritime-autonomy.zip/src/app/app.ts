import { Component, OnInit, OnDestroy, signal, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import {
  AutonomyMode,
  ControlVector,
  DigitalTwinResiduals,
  EkfStateEstimate,
  EnvironmentState,
  GoldenScenario,
  MonteCarloSummary,
  MpcResult,
  RawSensorData,
  SafetySupervisorEvaluation,
  SensorFaults,
  SensorHealth,
  State6DOF,
  Telemetry,
  WorldObject,
} from './models/maritime.types';

import { PhysicsEngineService } from './services/physics-engine.service';
import { SensorSimulatorService } from './services/sensor-simulator.service';
import { FusionEkfService } from './services/fusion-ekf.service';
import { CollisionRiskService } from './services/collision-risk.service';
import { MpcTrajectoryService } from './services/mpc-trajectory.service';
import { SafetySupervisorService } from './services/safety-supervisor.service';
import { DigitalTwinService } from './services/digital-twin.service';
import { ScenarioEngineService } from './services/scenario-engine.service';
import { DecisionAuditService } from './services/decision-audit.service';
import { GeminiCopilotService, CopilotMessage } from './services/gemini-copilot.service';

import { TacticalCanvas } from './components/tactical-canvas';
import { TelemetryBar } from './components/telemetry-bar';
import { ColregsPanel } from './components/colregs-panel';
import { SensorFusionPanel } from './components/sensor-fusion-panel';
import { MpcPlannerPanel } from './components/mpc-planner-panel';
import { SafetySupervisorPanel } from './components/safety-supervisor-panel';
import { DigitalTwinPanel } from './components/digital-twin-panel';
import { MonteCarloPanel } from './components/monte-carlo-panel';
import { AuditLogPanel } from './components/audit-log-panel';
import { AiCopilotPanel } from './components/ai-copilot-panel';

export type ActiveTab =
  | 'TACTICAL'
  | 'COLREGS'
  | 'EKF_FUSION'
  | 'MPC'
  | 'SAFETY'
  | 'DIGITAL_TWIN'
  | 'MONTE_CARLO'
  | 'AUDIT_LOG'
  | 'AI_COPILOT';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    FormsModule,
    TacticalCanvas,
    TelemetryBar,
    ColregsPanel,
    SensorFusionPanel,
    MpcPlannerPanel,
    SafetySupervisorPanel,
    DigitalTwinPanel,
    MonteCarloPanel,
    AuditLogPanel,
    AiCopilotPanel,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class App implements OnInit, OnDestroy {
  private physicsService = inject(PhysicsEngineService);
  private sensorService = inject(SensorSimulatorService);
  private ekfService = inject(FusionEkfService);
  private collisionService = inject(CollisionRiskService);
  private mpcService = inject(MpcTrajectoryService);
  private supervisorService = inject(SafetySupervisorService);
  private twinService = inject(DigitalTwinService);
  private scenarioService = inject(ScenarioEngineService);
  private auditService = inject(DecisionAuditService);
  private copilotService = inject(GeminiCopilotService);

  // App State Signals
  activeTab = signal<ActiveTab>('TACTICAL');
  isPaused = signal<boolean>(false);
  simSpeedMultiplier = signal<number>(1);
  activeScenarioId = signal<number>(1);
  copilotLoading = signal<boolean>(false);

  // Physics & Autonomy State Signals
  state = signal<State6DOF>(this.physicsService.getState());
  telemetry = signal<Telemetry>({
    speedKnots: 28.5,
    headingDeg: 45.0,
    courseDeg: 48.2,
    driftAngleDeg: 3.2,
    cushionPressureKpa: 2.85,
    liftFanRpm: 1800,
    portFanRpm: 1450,
    stbdFanRpm: 1450,
    fuelRemainingL: 7200,
    fuelFlowLPerHour: 340.0,
    batterySocPct: 94,
    totalPowerKw: 1850,
    vibrationRmsMmS: 2.1,
    bearingTempC: 67.4,
    skirtWearIndex: 0.038,
  });

  control = signal<ControlVector>({
    thrustPortPct: 75,
    thrustStbdPct: 75,
    rudderDeg: 0,
    liftPct: 100,
    bowThrusterPct: 0,
  });

  env = signal<EnvironmentState>({
    windSpeedKnots: 14.0,
    windDirDeg: 120.0,
    currentSpeedKnots: 1.2,
    currentDirDeg: 80.0,
    waveHeightM: 1.2,
    wavePeriodS: 4.5,
    visibilityNm: 0.4,
    fogDensity: 0.85,
    waterDepthM: 14.5,
    seaState: 3,
    tideHeightM: 0.4,
    isNight: false,
  });

  faults = signal<SensorFaults>({
    gnssDenial: false,
    gnssSpoofing: false,
    imuDrift: false,
    radarBlackout: false,
    lidarOcclusion: false,
    aisDropout: false,
    commsLoss: false,
    propulsionDegraded: false,
    skirtLeakage: false,
  });

  worldObjects = signal<WorldObject[]>([
    {
      id: 'TGT-101',
      mmsi: 235089123,
      name: 'Container Vessel Baltic Express',
      type: 'CARGO_VESSEL',
      x: 1800,
      y: 1400,
      vx: -7.2,
      vy: -1.5,
      speedKnots: 16.0,
      courseDeg: 280.0,
      lengthM: 140.0,
      beamM: 22.0,
      distanceM: 2280,
      relativeBearingDeg: 38.0,
      cpaM: 410,
      tcpaS: 185,
      riskLevel: 'MODERATE',
      riskScore: 0.42,
      colregsSituation: 'CROSSING_GIVE_WAY',
      navigationRole: 'GIVE_WAY',
      ruleReference: 'Rule 15 (Crossing Situation)',
      actionAdvice: 'Alter course to starboard early to cross stern.',
      trackedHistory: [],
    },
    {
      id: 'TGT-102',
      mmsi: 235091444,
      name: 'Chemical Tanker Humber Star',
      type: 'TANKER',
      x: 2800,
      y: -400,
      vx: -1.8,
      vy: 5.6,
      speedKnots: 12.0,
      courseDeg: 340.0,
      lengthM: 110.0,
      beamM: 18.0,
      distanceM: 2828,
      relativeBearingDeg: 98.0,
      cpaM: 920,
      tcpaS: 310,
      riskLevel: 'LOW',
      riskScore: 0.18,
      colregsSituation: 'CROSSING_STAND_ON',
      navigationRole: 'STAND_ON',
      ruleReference: 'Rule 15 (Target to Port)',
      actionAdvice: 'Maintain course and speed; monitor passing distance.',
      trackedHistory: [],
    },
    {
      id: 'TGT-103',
      mmsi: 235048999,
      name: 'North Sea Trawler Sovereign',
      type: 'FISHING_BOAT',
      x: 900,
      y: 1200,
      vx: -0.7,
      vy: -3.8,
      speedKnots: 8.0,
      courseDeg: 190.0,
      lengthM: 32.0,
      beamM: 8.5,
      distanceM: 1500,
      relativeBearingDeg: 12.0,
      cpaM: 280,
      tcpaS: 95,
      riskLevel: 'HIGH',
      riskScore: 0.68,
      colregsSituation: 'SPECIAL_STATUS_VESSEL',
      navigationRole: 'GIVE_WAY',
      ruleReference: 'Rule 18 (Responsibilities Between Vessels)',
      actionAdvice: 'Give way to fishing vessel; alter course early to starboard.',
      trackedHistory: [],
    },
  ]);

  ekf = signal<EkfStateEstimate>({
    x: 0,
    y: 0,
    u: 14.6,
    v: 0.8,
    yaw: 0.785,
    r: 0,
    covarianceDiag: [2.0, 2.0, 0.5, 0.5, 0.02, 0.01],
    sigmaX: 1.41,
    sigmaY: 1.41,
    confidenceScore: 0.96,
    innovationResidual: 0.12,
  });

  rawSensors = signal<RawSensorData>({
    gnss: { lat: 53.582, lon: 0.054, alt: 1.25, sogKnots: 28.5, cogDeg: 48.2, hdop: 0.8, satellites: 14, fixQuality: 'RTK Fixed', valid: true },
    imu: { accelX: 0.1, accelY: 0.05, accelZ: -9.81, gyroX: 0, gyroY: 0, gyroZ: 0, pitchDeg: 0.8, rollDeg: -1.2, yawDeg: 45.0 },
    radar: { contacts: [], sweepAngleDeg: 0 },
    lidar: { points: [] },
    ais: { messages: [] },
    echoSounderDepthM: 14.5,
    cushionPressureKpa: 2.85,
  });

  health = signal<SensorHealth>({
    gnss: 0.98,
    imu: 0.99,
    radar: 0.96,
    lidar: 0.94,
    ais: 0.98,
    depth: 0.95,
    cushionPressure: 0.99,
    commsLink: 0.99,
  });

  mpcResult = signal<MpcResult>({
    optimalControl: { thrustPortPct: 75, thrustStbdPct: 75, rudderDeg: 0, liftPct: 100, bowThrusterPct: 0 },
    selectedTrajectory: [],
    candidates: [],
    cost: 420,
    horizonSec: 10,
  });

  supervisor = signal<SafetySupervisorEvaluation>({
    currentMode: 'AUTONOMOUS',
    targetMode: 'AUTONOMOUS',
    actionIntent: 'ALLOW',
    supervisorVetoActive: false,
    alarms: [],
    safetyStatus: 'NOMINAL',
    operatorInterventionRequired: false,
    timeSinceHeartbeatSec: 0,
  });

  digitalTwin = signal<DigitalTwinResiduals>({
    speedResidualKnots: 0.2,
    fuelResidualPct: 4,
    cushionPressureResidualKpa: 0.02,
    vibrationRmsMmS: 2.1,
    bearingTempC: 67.4,
    skirtWearIndex: 0.038,
    rulHoursRemaining: 432,
    anomalyDetected: false,
  });

  goldenScenarios = this.scenarioService.goldenScenarios;
  mcSummary = signal<MonteCarloSummary | null>(null);
  copilotMessages = signal<CopilotMessage[]>(this.copilotService.getHistory());

  radarSweepAngle = signal<number>(0);

  private simInterval: ReturnType<typeof setInterval> | null = null;

  ngOnInit(): void {
    // Initial Monte Carlo sample
    this.mcSummary.set(this.scenarioService.runMonteCarloSimulation(100));

    // Audit initial setup
    this.auditService.logEvent({
      eventType: 'MODE_TRANSITION',
      description: 'Aardvark Maritime Autonomy Core Initialised in AUTONOMOUS Mode (A01 Fleet)',
      autonomyMode: 'AUTONOMOUS',
      causalSnapshot: {
        state: { x: 0, y: 0, speedKnots: 28.5, headingDeg: 45 },
        maxRiskScore: 0.42,
        activeAlarmsCount: 0,
        commandThrustPort: 75,
        commandThrustStbd: 75,
        commandRudder: 0,
      },
    });

    // Start Real-Time Physics & Autonomy Loop (100ms step)
    this.simInterval = setInterval(() => {
      this.tickSimulation(0.1);
    }, 100);
  }

  ngOnDestroy(): void {
    if (this.simInterval) {
      clearInterval(this.simInterval);
    }
  }

  tickSimulation(dtBase: number): void {
    if (this.isPaused()) return;
    const dt = dtBase * this.simSpeedMultiplier();

    this.supervisorService.sendHeartbeat();
    this.radarSweepAngle.update(a => (a + 45 * dt) % 360);

    // 1. Target Vessels Kinematic Prediction
    const updatedTargets = this.worldObjects().map(tgt => {
      const vx = tgt.speedKnots * 0.514444 * Math.sin((tgt.courseDeg * Math.PI) / 180);
      const vy = tgt.speedKnots * 0.514444 * Math.cos((tgt.courseDeg * Math.PI) / 180);
      const xNew = tgt.x + vx * dt;
      const yNew = tgt.y + vy * dt;
      const distanceM = Math.round(Math.sqrt(Math.pow(xNew - this.state().x, 2) + Math.pow(yNew - this.state().y, 2)));

      const riskEval = this.collisionService.evaluateCollisionRisk(this.ekf(), this.telemetry().speedKnots, {
        ...tgt,
        x: xNew,
        y: yNew,
        vx,
        vy,
        distanceM,
      });

      return {
        ...tgt,
        x: xNew,
        y: yNew,
        vx,
        vy,
        distanceM,
        ...riskEval,
      };
    });
    this.worldObjects.set(updatedTargets);

    // 2. Physics Simulation Step
    const currentControl = this.control();
    const currentEnv = this.env();
    const currentFaults = this.faults();

    const { state: newPhysicsState, telemetry: newTelemetry } = this.physicsService.integrateStep(
      dt,
      currentControl,
      currentEnv,
      currentFaults.skirtLeakage,
      currentFaults.propulsionDegraded
    );

    this.state.set(newPhysicsState);
    this.telemetry.set(newTelemetry);

    // 3. Sensor Simulator Step
    const { raw: rawData, health: sensorHealth } = this.sensorService.generateSensors(
      newPhysicsState,
      newTelemetry,
      updatedTargets,
      currentFaults,
      dt
    );
    this.rawSensors.set(rawData);
    this.health.set(sensorHealth);

    // 4. Extended Kalman Filter (EKF) Fusion Step
    const ekfEst = this.ekfService.update(newPhysicsState, rawData, sensorHealth, dt);
    this.ekf.set(ekfEst);

    // 5. Model Predictive Control (MPC) Receding Horizon Trajectory Step
    const mpcOut = this.mpcService.computeMpc(
      ekfEst,
      currentControl,
      this.physicsService.specs,
      currentEnv,
      updatedTargets,
      { x: 3500, y: 3500, targetSpeedKnots: 38.0 },
      10,
      0.5
    );
    this.mpcResult.set(mpcOut);

    // If Autonomous & no Veto, apply optimal MPC controls
    if (this.supervisor().currentMode === 'AUTONOMOUS' && !this.supervisor().supervisorVetoActive) {
      this.control.set(mpcOut.optimalControl);
    }

    // 6. Safety Supervisor Watchdog Evaluation Step
    const supervisorEval = this.supervisorService.evaluateSafety(
      ekfEst,
      newTelemetry,
      sensorHealth,
      currentFaults,
      updatedTargets
    );
    this.supervisor.set(supervisorEval);

    // 7. Digital Twin Residual Diagnostics Step
    const twinDiag = this.twinService.computeTwinResiduals(newTelemetry, currentControl, this.physicsService.specs);
    this.digitalTwin.set(twinDiag);
  }

  // Interactive UI Actions
  setTab(tab: ActiveTab): void {
    this.activeTab.set(tab);
  }

  togglePause(): void {
    this.isPaused.update(p => !p);
  }

  setSimSpeed(speed: number): void {
    this.simSpeedMultiplier.set(speed);
  }

  setAutonomyMode(mode: AutonomyMode): void {
    this.supervisorService.setMode(mode);
    this.supervisor.update(s => ({ ...s, currentMode: mode }));
    this.auditService.logEvent({
      eventType: 'MODE_TRANSITION',
      description: `Operator commanded Autonomy Mode transition to: ${mode}`,
      autonomyMode: mode,
      causalSnapshot: {
        state: { x: this.state().x, y: this.state().y, speedKnots: this.telemetry().speedKnots, headingDeg: this.telemetry().headingDeg },
        maxRiskScore: Math.max(...this.worldObjects().map(t => t.riskScore)),
        activeAlarmsCount: this.supervisor().alarms.length,
        commandThrustPort: this.control().thrustPortPct,
        commandThrustStbd: this.control().thrustStbdPct,
        commandRudder: this.control().rudderDeg,
      },
    });
  }

  updateFaults(newFaults: SensorFaults): void {
    this.faults.set(newFaults);
    this.auditService.logEvent({
      eventType: 'SENSOR_FAULT_INJECTED',
      description: `Updated fault injection configuration: ${Object.entries(newFaults).filter(([, val]) => val).map(([key]) => key).join(', ') || 'ALL CLEAR'}`,
      autonomyMode: this.supervisor().currentMode,
      causalSnapshot: {
        state: { x: this.state().x, y: this.state().y, speedKnots: this.telemetry().speedKnots, headingDeg: this.telemetry().headingDeg },
        maxRiskScore: Math.max(...this.worldObjects().map(t => t.riskScore)),
        activeAlarmsCount: this.supervisor().alarms.length,
        commandThrustPort: this.control().thrustPortPct,
        commandThrustStbd: this.control().thrustStbdPct,
        commandRudder: this.control().rudderDeg,
      },
    });
  }

  loadScenario(sc: GoldenScenario): void {
    this.activeScenarioId.set(sc.id);
    this.physicsService.reset(sc.initialState.x, sc.initialState.y, sc.initialState.headingDeg, sc.initialState.cargoWeightKg);
    this.ekfService.reset(sc.initialState.x, sc.initialState.y, (sc.initialState.headingDeg * Math.PI) / 180);

    if (sc.environment) {
      this.env.update(e => ({ ...e, ...sc.environment }));
    }
    if (sc.faults) {
      this.faults.update(f => ({ ...f, ...sc.faults }));
    }

    if (sc.traffic) {
      const newTraffic: WorldObject[] = sc.traffic.map(t => ({
        id: t.id,
        mmsi: 235000000 + Math.floor(Math.random() * 900000),
        name: t.name,
        type: t.type,
        x: t.startX,
        y: t.startY,
        vx: t.speedKnots * 0.5144 * Math.sin((t.courseDeg * Math.PI) / 180),
        vy: t.speedKnots * 0.5144 * Math.cos((t.courseDeg * Math.PI) / 180),
        speedKnots: t.speedKnots,
        courseDeg: t.courseDeg,
        lengthM: 80,
        beamM: 14,
        distanceM: Math.round(Math.sqrt(t.startX * t.startX + t.startY * t.startY)),
        relativeBearingDeg: 45,
        cpaM: 500,
        tcpaS: 200,
        riskLevel: 'LOW',
        riskScore: 0.2,
        colregsSituation: 'CROSSING_GIVE_WAY',
        navigationRole: 'GIVE_WAY',
        ruleReference: 'Rule 15',
        actionAdvice: 'Monitor encounter.',
        trackedHistory: [],
      }));
      this.worldObjects.set(newTraffic);
    }
  }

  updateTarget(updated: WorldObject): void {
    const targets = this.worldObjects().map(t => (t.id === updated.id ? updated : t));
    this.worldObjects.set(targets);
  }

  updateEnv(partial: Partial<EnvironmentState>): void {
    this.env.update(e => ({ ...e, ...partial }));
  }

  runMonteCarlo(): void {
    this.mcSummary.set(this.scenarioService.runMonteCarloSimulation(100));
  }

  updateControlValue(key: keyof ControlVector, event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.control.update(c => ({ ...c, [key]: val }));
  }

  // Audit exports
  exportAuditJson(): void {
    const jsonStr = this.auditService.exportJson();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `aardvark_audit_log_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  exportAuditRScript(): void {
    const rScript = this.auditService.exportRScript();
    const blob = new Blob([rScript], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `aardvark_safety_case_analysis.R`;
    a.click();
    URL.revokeObjectURL(url);
  }

  // Gemini AI Copilot
  async askCopilot(query: string): Promise<void> {
    this.copilotLoading.set(true);
    await this.copilotService.askCopilot(query, {
      ekf: this.ekf(),
      telemetry: this.telemetry(),
      env: this.env(),
      supervisor: this.supervisor(),
      targets: this.worldObjects(),
    });
    this.copilotMessages.set([...this.copilotService.getHistory()]);
    this.copilotLoading.set(false);
  }

  getAuditEvents() {
    return this.auditService.getEvents();
  }
}
