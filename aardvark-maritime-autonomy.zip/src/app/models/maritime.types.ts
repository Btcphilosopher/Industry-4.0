export type AutonomyMode =
  | 'MANUAL'
  | 'ASSISTED'
  | 'REMOTE'
  | 'AUTONOMOUS'
  | 'DEGRADED'
  | 'EMERGENCY'
  | 'SAFE_STOP'
  | 'RETURN_TO_PORT';

export type ColregsSituation =
  | 'HEAD_ON'
  | 'CROSSING_GIVE_WAY'
  | 'CROSSING_STAND_ON'
  | 'OVERTAKING_GIVE_WAY'
  | 'OVERTAKING_STAND_ON'
  | 'SPECIAL_STATUS_VESSEL'
  | 'RESTRICTED_WATERS'
  | 'CLEAR';

export type RiskLevel = 'LOW' | 'MODERATE' | 'HIGH' | 'CRITICAL';

export interface Vector2D {
  x: number;
  y: number;
}

export interface HovercraftSpecs {
  id: string;
  name: string;
  fleetId: string;
  length: number; // m
  beam: number; // m
  height: number; // m
  massEmptyKg: number;
  massCargoKg: number;
  totalMassKg: number;
  cushionAreaM2: number;
  skirtHeightM: number;
  skirtPerimeterM: number;
  nominalCushionPressPa: number;
  liftPowerKw: number;
  propulsionPowerKw: number;
  fuelCapacityL: number;
  batteryCapacityKwh: number;
  maxSpeedKnots: number;
  cruisingSpeedKnots: number;
  minControlSpeedKnots: number;
  turningRadiusM: number;
}

export interface State6DOF {
  x: number; // m East
  y: number; // m North
  z: number; // m (hover height)
  u: number; // m/s surge (longitudinal body)
  v: number; // m/s sway (transverse body)
  w: number; // m/s heave
  roll: number; // rad
  pitch: number; // rad
  yaw: number; // rad (heading from North)
  p: number; // rad/s roll rate
  q: number; // rad/s pitch rate
  r: number; // rad/s yaw rate
}

export interface ControlVector {
  thrustPortPct: number; // 0 - 100%
  thrustStbdPct: number; // 0 - 100%
  rudderDeg: number; // -30 to +30 deg
  liftPct: number; // 0 - 100%
  bowThrusterPct: number; // -100 to +100%
}

export interface Telemetry {
  speedKnots: number;
  headingDeg: number;
  courseDeg: number;
  driftAngleDeg: number;
  cushionPressureKpa: number;
  liftFanRpm: number;
  portFanRpm: number;
  stbdFanRpm: number;
  fuelRemainingL: number;
  fuelFlowLPerHour: number;
  batterySocPct: number;
  totalPowerKw: number;
  vibrationRmsMmS: number;
  bearingTempC: number;
  skirtWearIndex: number;
}

export interface EnvironmentState {
  windSpeedKnots: number;
  windDirDeg: number;
  currentSpeedKnots: number;
  currentDirDeg: number;
  waveHeightM: number;
  wavePeriodS: number;
  visibilityNm: number;
  fogDensity: number; // 0 to 1
  waterDepthM: number;
  seaState: number; // Beaufort 0 - 9
  tideHeightM: number;
  isNight: boolean;
}

export interface SensorHealth {
  gnss: number; // 0.0 to 1.0
  imu: number;
  radar: number;
  lidar: number;
  ais: number;
  depth: number;
  cushionPressure: number;
  commsLink: number;
}

export interface SensorFaults {
  gnssDenial: boolean;
  gnssSpoofing: boolean;
  imuDrift: boolean;
  radarBlackout: boolean;
  lidarOcclusion: boolean;
  aisDropout: boolean;
  commsLoss: boolean;
  propulsionDegraded: boolean;
  skirtLeakage: boolean;
}

export interface RawSensorData {
  gnss: {
    lat: number;
    lon: number;
    alt: number;
    sogKnots: number;
    cogDeg: number;
    hdop: number;
    satellites: number;
    fixQuality: string;
    valid: boolean;
  };
  imu: {
    accelX: number;
    accelY: number;
    accelZ: number;
    gyroX: number;
    gyroY: number;
    gyroZ: number;
    pitchDeg: number;
    rollDeg: number;
    yawDeg: number;
  };
  radar: {
    contacts: {
      id: string;
      rangeM: number;
      bearingDeg: number;
      dopplerSpeedKnots: number;
      rcsDb: number;
    }[];
    sweepAngleDeg: number;
  };
  lidar: {
    points: { x: number; y: number; z: number; intensity: number }[];
  };
  ais: {
    messages: {
      mmsi: number;
      name: string;
      vesselType: string;
      lat: number;
      lon: number;
      sogKnots: number;
      cogDeg: number;
      trueHeadingDeg: number;
      status: string;
    }[];
  };
  echoSounderDepthM: number;
  cushionPressureKpa: number;
}

export interface EkfStateEstimate {
  x: number;
  y: number;
  u: number;
  v: number;
  yaw: number;
  r: number;
  covarianceDiag: [number, number, number, number, number, number];
  sigmaX: number;
  sigmaY: number;
  confidenceScore: number;
  innovationResidual: number;
}

export interface WorldObject {
  id: string;
  mmsi?: number;
  name: string;
  type: 'CARGO_VESSEL' | 'TANKER' | 'FISHING_BOAT' | 'WORKBOAT' | 'BUOY' | 'OBSTACLE' | 'SHALLOW_BANK';
  x: number;
  y: number;
  vx: number;
  vy: number;
  speedKnots: number;
  courseDeg: number;
  lengthM: number;
  beamM: number;
  distanceM: number;
  relativeBearingDeg: number;
  cpaM: number;
  tcpaS: number;
  riskLevel: RiskLevel;
  riskScore: number;
  colregsSituation: ColregsSituation;
  navigationRole: 'GIVE_WAY' | 'STAND_ON' | 'NEUTRAL';
  ruleReference: string;
  actionAdvice: string;
  trackedHistory: { x: number; y: number }[];
}

export interface Waypoint {
  id: string;
  name: string;
  x: number;
  y: number;
  targetSpeedKnots: number;
  radiusM: number;
}

export interface TrajectoryPoint {
  t: number;
  x: number;
  y: number;
  psi: number;
  speedKnots: number;
  risk: number;
  energy: number;
}

export interface CandidateTrajectory {
  id: string;
  rudderDeg: number;
  thrustPct: number;
  totalCost: number;
  crossTrackCost: number;
  headingCost: number;
  collisionCost: number;
  energyCost: number;
  minObstacleDistM: number;
  points: TrajectoryPoint[];
  isSelected: boolean;
}

export interface MpcResult {
  optimalControl: ControlVector;
  selectedTrajectory: TrajectoryPoint[];
  candidates: CandidateTrajectory[];
  cost: number;
  horizonSec: number;
}

export interface SafetySupervisorEvaluation {
  currentMode: AutonomyMode;
  targetMode: AutonomyMode;
  actionIntent: 'ALLOW' | 'RESTRICT' | 'REPLAN' | 'SLOW' | 'STOP' | 'RETURN' | 'REMOTE_INTERVENTION';
  supervisorVetoActive: boolean;
  alarms: string[];
  safetyStatus: 'NOMINAL' | 'DEGRADED' | 'HAZARDOUS' | 'EMERGENCY';
  operatorInterventionRequired: boolean;
  timeSinceHeartbeatSec: number;
}

export interface DigitalTwinResiduals {
  speedResidualKnots: number;
  fuelResidualPct: number;
  cushionPressureResidualKpa: number;
  vibrationRmsMmS: number;
  bearingTempC: number;
  skirtWearIndex: number;
  rulHoursRemaining: number;
  anomalyDetected: boolean;
  anomalyType?: string;
}

export interface GoldenScenario {
  id: number;
  name: string;
  description: string;
  category: 'ENVIRONMENT' | 'TRAFFIC' | 'SENSOR_FAULT' | 'EMERGENCY' | 'PORT';
  initialState: {
    x: number;
    y: number;
    speedKnots: number;
    headingDeg: number;
    cargoWeightKg: number;
  };
  environment: Partial<EnvironmentState>;
  faults: Partial<SensorFaults>;
  traffic: {
    id: string;
    name: string;
    type: WorldObject['type'];
    startX: number;
    startY: number;
    speedKnots: number;
    courseDeg: number;
  }[];
}

export interface MonteCarloRun {
  runId: number;
  minCpaM: number;
  collisionOccurred: boolean;
  nearMissOccurred: boolean;
  missionCompleted: boolean;
  totalFuelL: number;
  interventionRequired: boolean;
  windSpeedKnots: number;
  waveHeightM: number;
}

export interface MonteCarloSummary {
  totalRuns: number;
  completionRatePct: number;
  collisionProbability: number;
  nearMissProbability: number;
  meanMinCpaM: number;
  ci95LowerCpaM: number;
  ci95UpperCpaM: number;
  meanFuelL: number;
  interventionRatePct: number;
  runs: MonteCarloRun[];
}

export interface DecisionAuditEvent {
  eventId: string;
  timestamp: number;
  eventType:
    | 'STATE_ESTIMATE_UPDATED'
    | 'OBJECT_DETECTED'
    | 'COLLISION_RISK_EVALUATED'
    | 'TRAJECTORY_OPTIMISED'
    | 'SAFETY_SUPERVISOR_EVALUATED'
    | 'MODE_TRANSITION'
    | 'OPERATOR_INTERVENTION'
    | 'SENSOR_FAULT_INJECTED';
  description: string;
  autonomyMode: AutonomyMode;
  causalSnapshot: {
    state: { x: number; y: number; speedKnots: number; headingDeg: number };
    maxRiskScore: number;
    activeAlarmsCount: number;
    commandThrustPort: number;
    commandThrustStbd: number;
    commandRudder: number;
  };
}
