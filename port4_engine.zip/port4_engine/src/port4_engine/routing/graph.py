"""The port road graph (section 20): nodes, edges, lanes, speed limits,
restrictions, and shortest/fastest/lowest-energy/least-congested routing
with dynamic (time-varying) travel times.

Built on NetworkX so we get well-tested shortest-path algorithms for free,
while keeping the domain-specific edge attributes (lanes, speed limit,
restrictions, live congestion factor, energy cost) explicit and typed.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

import networkx as nx

from port4_engine.core.ids import EntityId


@dataclass
class RoadEdge:
    from_node: str
    to_node: str
    length_m: float
    speed_limit_kmh: float
    lanes: int = 1
    restrictions: set[str] = field(default_factory=set)  # e.g. {"no_hazardous", "height_limit_4m"}
    congestion_factor: float = 0.0  # 0 = free flow, 1 = gridlock
    energy_per_m: float = 0.02  # kWh/m baseline for a laden truck

    def free_flow_time_s(self) -> float:
        return self.length_m / max(1e-6, self.speed_limit_kmh * 1000 / 3600)

    def current_travel_time_s(self) -> float:
        slowdown = 1.0 + 4.0 * self.congestion_factor  # heavy congestion can 5x travel time
        return self.free_flow_time_s() * slowdown

    def energy_cost(self) -> float:
        return self.length_m * self.energy_per_m


@dataclass
class RouteResult:
    path: list[str]
    total_distance_m: float
    total_time_s: float
    total_energy_kwh: float


RouteMetric = Literal["shortest", "fastest", "lowest_energy", "least_congested"]


class PortRoadGraph:
    def __init__(self) -> None:
        self.graph = nx.DiGraph()

    def add_node(self, node_id: str, **attrs: object) -> None:
        self.graph.add_node(node_id, **attrs)

    def add_edge(self, edge: RoadEdge, *, bidirectional: bool = True) -> None:
        self.graph.add_edge(edge.from_node, edge.to_node, edge=edge)
        if bidirectional:
            reverse = RoadEdge(
                from_node=edge.to_node,
                to_node=edge.from_node,
                length_m=edge.length_m,
                speed_limit_kmh=edge.speed_limit_kmh,
                lanes=edge.lanes,
                restrictions=set(edge.restrictions),
                congestion_factor=edge.congestion_factor,
                energy_per_m=edge.energy_per_m,
            )
            self.graph.add_edge(edge.to_node, edge.from_node, edge=reverse)

    def set_congestion(self, from_node: str, to_node: str, congestion_factor: float) -> None:
        self.graph[from_node][to_node]["edge"].congestion_factor = max(0.0, min(1.0, congestion_factor))

    def _weight_fn(self, metric: RouteMetric, avoid_restrictions: set[str] | None = None):
        avoid = avoid_restrictions or set()

        def weight(u: str, v: str, data: dict) -> float | None:
            edge: RoadEdge = data["edge"]
            if edge.restrictions & avoid:
                return None
            if metric == "shortest":
                return edge.length_m
            if metric == "fastest":
                return edge.current_travel_time_s()
            if metric == "lowest_energy":
                return edge.energy_cost()
            if metric == "least_congested":
                return edge.congestion_factor * edge.length_m + edge.length_m * 0.01
            raise ValueError(f"unknown routing metric: {metric}")

        return weight

    def route(
        self, origin: str, destination: str, *, metric: RouteMetric = "fastest", avoid_restrictions: set[str] | None = None
    ) -> RouteResult:
        path = nx.shortest_path(
            self.graph, origin, destination, weight=self._weight_fn(metric, avoid_restrictions)
        )
        total_distance = 0.0
        total_time = 0.0
        total_energy = 0.0
        for u, v in zip(path[:-1], path[1:]):
            edge: RoadEdge = self.graph[u][v]["edge"]
            total_distance += edge.length_m
            total_time += edge.current_travel_time_s()
            total_energy += edge.energy_cost()
        return RouteResult(path=path, total_distance_m=total_distance, total_time_s=total_time, total_energy_kwh=total_energy)
