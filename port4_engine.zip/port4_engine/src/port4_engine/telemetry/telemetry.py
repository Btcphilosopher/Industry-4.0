"""LIVE-mode digital-twin synchronisation (section 28).

In SIMULATION mode the Python engine generates the world (see
:mod:`port4_engine.simulation`). In LIVE mode, Rust telemetry becomes
*authoritative*: Python consumes live vessel/container/crane/truck/yard
state and reconciles its own models against it, but — critically — never
overwrites live state on its own initiative. A simulated/forecast value
may diverge from a live reading (that divergence is itself useful
information, surfaced via :attr:`TelemetrySnapshot.divergences`), but the
only way live entity state changes here is through an explicit,
operator-authorised command, never as a side effect of running a
forecast or optimisation pass.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from port4_engine.core.ids import EntityId
from port4_engine.core.port import Port


@dataclass
class TelemetrySnapshot:
    received_at: datetime
    entity_states: dict[EntityId, dict[str, Any]]
    divergences: dict[EntityId, dict[str, tuple[Any, Any]]] = field(default_factory=dict)


class LiveStateReconciler:
    """Reconciles a :class:`Port` against live telemetry readings.

    ``observe`` records what Rust reports without touching the Port model
    at all — it only *compares* against Python's current belief and
    reports divergence. ``apply_authorised_update`` is the only path that
    actually mutates entity state from telemetry, and it must be called
    explicitly (by an operator action or an authorised automation rule),
    never implicitly from simulation/forecasting/optimisation code.
    """

    def __init__(self, port: Port) -> None:
        self.port = port

    def observe(self, entity_states: dict[EntityId, dict[str, Any]], *, received_at: datetime) -> TelemetrySnapshot:
        divergences: dict[EntityId, dict[str, tuple[Any, Any]]] = {}
        for entity_id, live_fields in entity_states.items():
            entity = self.port.find(entity_id)
            if entity is None:
                continue
            entity_divergence: dict[str, tuple[Any, Any]] = {}
            for field_name, live_value in live_fields.items():
                current_value = getattr(entity, field_name, None)
                if current_value is not None and current_value != live_value:
                    entity_divergence[field_name] = (current_value, live_value)
            if entity_divergence:
                divergences[entity_id] = entity_divergence

        return TelemetrySnapshot(received_at=received_at, entity_states=entity_states, divergences=divergences)

    def apply_authorised_update(self, entity_id: EntityId, fields: dict[str, Any], *, authorised_by: str) -> bool:
        """The one sanctioned path for live telemetry to overwrite Python's
        model of an entity. ``authorised_by`` is recorded for audit but is
        not itself a permission check — callers are responsible for having
        already established the update is authorised before calling this."""
        entity = self.port.find(entity_id)
        if entity is None:
            return False
        for field_name, value in fields.items():
            if hasattr(entity, field_name):
                setattr(entity, field_name, value)
        return True
