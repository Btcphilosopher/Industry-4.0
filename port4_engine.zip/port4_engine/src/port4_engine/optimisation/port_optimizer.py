"""Port-wide joint optimisation (section 31).

``PortOptimizer`` jointly considers berths, cranes, yards, trucks, rail,
warehouses, gates and energy through a compact decision vector and a fast
analytic surrogate of how each decision affects the
:class:`~port4_engine.optimisation.objective.PortScore` components. This
keeps optimisation calls interactive (sub-second to a few seconds) even
with a metaheuristic algorithm; the resulting recommendation is then
validated against the full discrete-event simulation (see
:mod:`port4_engine.simulation`) before being surfaced as a plan.

Decision vector (each in [0, 1] unless noted):
    x[0] crane_allocation_intensity  — how aggressively cranes are pooled onto priority vessels
    x[1] truck_dispatch_rate         — gate throughput dial (more lanes/faster processing effort)
    x[2] yard_consolidation          — how aggressively the yard optimiser consolidates dwell-heavy cargo
    x[3] rail_utilisation_target     — target fraction of eligible containers routed to rail vs. truck
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from port4_engine.core.port import Port
from port4_engine.optimisation.algorithms import (
    OptimizationResult,
    genetic_search,
    greedy_search,
    local_search,
    particle_swarm,
    simulated_annealing,
)
from port4_engine.optimisation.objective import PortScore, PortScoreInputs, PortScoreWeights
from port4_engine.statistics.kpi import KpiEngine

DECISION_BOUNDS = [(0.0, 1.0), (0.0, 1.0), (0.0, 1.0), (0.0, 1.0)]
DECISION_NAMES = ["crane_allocation_intensity", "truck_dispatch_rate", "yard_consolidation", "rail_utilisation_target"]


@dataclass
class PortOptimizationResult:
    algorithm: str
    decisions: dict[str, float]
    score: float
    score_breakdown: dict[str, float]
    predicted_kpis: PortScoreInputs
    alternative_scores: list[float]


def surrogate_kpis(port: Port, x: np.ndarray, baseline: PortScoreInputs) -> PortScoreInputs:
    """A fast analytic model of how the decision vector perturbs current KPIs.

    Deliberately simple and monotone-consistent with port operations
    intuition: more crane intensity raises throughput and energy while
    cutting vessel waiting; more truck dispatch effort cuts truck waiting
    at an operating-cost premium; yard consolidation cuts dwell time but
    raises rehandle-driven congestion at low utilisation improvement;
    higher rail utilisation cuts truck/gate load and energy per TEU.
    """
    crane_intensity, truck_rate, yard_consolidation, rail_target = x

    throughput = baseline.throughput_teu_per_day * (0.85 + 0.3 * crane_intensity)
    vessel_waiting = baseline.vessel_waiting_hours * (1.3 - 0.6 * crane_intensity)
    truck_waiting = baseline.truck_waiting_minutes * (1.4 - 0.8 * truck_rate) * (1.1 - 0.2 * rail_target)
    container_dwell = baseline.container_dwell_hours * (1.3 - 0.6 * yard_consolidation)
    energy = baseline.energy_kwh * (0.8 + 0.5 * crane_intensity + 0.2 * truck_rate) * (1.0 - 0.15 * rail_target)
    operating_cost = baseline.operating_cost * (0.85 + 0.25 * truck_rate + 0.15 * crane_intensity)
    congestion = max(0.0, min(1.0, baseline.congestion_ratio * (1.25 - 0.5 * yard_consolidation) * (1.1 - 0.3 * rail_target)))
    quality = max(0.0, min(1.0, baseline.quality_score + 0.05 * yard_consolidation - 0.05 * max(0.0, truck_rate - 0.9)))

    return PortScoreInputs(
        throughput_teu_per_day=max(0.0, throughput),
        vessel_waiting_hours=max(0.0, vessel_waiting),
        truck_waiting_minutes=max(0.0, truck_waiting),
        container_dwell_hours=max(0.0, container_dwell),
        energy_kwh=max(0.0, energy),
        operating_cost=max(0.0, operating_cost),
        congestion_ratio=congestion,
        quality_score=quality,
        throughput_reference=baseline.throughput_reference,
        vessel_waiting_reference_hours=baseline.vessel_waiting_reference_hours,
        truck_waiting_reference_minutes=baseline.truck_waiting_reference_minutes,
        container_dwell_reference_hours=baseline.container_dwell_reference_hours,
        energy_reference_kwh=baseline.energy_reference_kwh,
        operating_cost_reference=baseline.operating_cost_reference,
    )


def baseline_inputs_from_port(port: Port, *, window_hours: float = 24.0) -> PortScoreInputs:
    kpis = KpiEngine(port, window_hours=window_hours).compute()
    yard_util = kpis.yard_utilisation
    energy_estimate = kpis.teu_per_day * 6.0  # kWh/TEU rough default, refined by the energy module
    operating_cost_estimate = kpis.teu_per_day * 95.0
    return PortScoreInputs(
        throughput_teu_per_day=kpis.teu_per_day,
        vessel_waiting_hours=max(1.0, kpis.avg_vessel_turnaround_hours * 0.2),
        truck_waiting_minutes=max(1.0, kpis.avg_truck_turnaround_minutes),
        container_dwell_hours=max(1.0, kpis.avg_container_dwell_hours),
        energy_kwh=energy_estimate,
        operating_cost=operating_cost_estimate,
        congestion_ratio=yard_util,
        quality_score=0.9,
    )


class PortOptimizer:
    def __init__(self, weights: PortScoreWeights | None = None) -> None:
        self.port_score = PortScore(weights)

    def optimize(
        self,
        port: Port,
        *,
        algorithm: str = "genetic",
        window_hours: float = 24.0,
        seed: int | None = 42,
    ) -> PortOptimizationResult:
        baseline = baseline_inputs_from_port(port, window_hours=window_hours)

        def score_fn(x: np.ndarray) -> float:
            kpis = surrogate_kpis(port, x, baseline)
            return self.port_score.evaluate(kpis)

        rng = np.random.default_rng(seed)
        result: OptimizationResult[np.ndarray]
        if algorithm == "genetic":
            result = genetic_search(score_fn, DECISION_BOUNDS, seed=seed)
        elif algorithm == "particle_swarm":
            result = particle_swarm(score_fn, DECISION_BOUNDS, rng=rng)
        elif algorithm == "simulated_annealing":
            result = simulated_annealing(score_fn, DECISION_BOUNDS, rng=rng)
        elif algorithm == "greedy":
            result = self._greedy_grid(score_fn)
        else:
            raise ValueError(f"unknown port optimisation algorithm: {algorithm}")

        best_x = np.asarray(result.solution, dtype=float)
        predicted = surrogate_kpis(port, best_x, baseline)
        breakdown = self.port_score.component_breakdown(predicted)

        return PortOptimizationResult(
            algorithm=result.algorithm,
            decisions=dict(zip(DECISION_NAMES, best_x.tolist())),
            score=result.score,
            score_breakdown=breakdown,
            predicted_kpis=predicted,
            alternative_scores=result.history,
        )

    def _greedy_grid(self, score_fn) -> OptimizationResult[np.ndarray]:
        """A coarse, fast, fully deterministic fallback: grid search over a
        small discretisation, coordinate-ascent refined."""
        grid = np.linspace(0.0, 1.0, 5)
        best = np.array([0.5, 0.5, 0.5, 0.5])
        best_score = score_fn(best)
        history = [best_score]
        for _ in range(3):
            for dim in range(len(best)):
                for value in grid:
                    trial = best.copy()
                    trial[dim] = value
                    trial_score = score_fn(trial)
                    if trial_score > best_score:
                        best, best_score = trial, trial_score
                        history.append(best_score)
        return OptimizationResult(solution=best, score=best_score, algorithm="greedy", iterations=len(history), history=history)

    def pareto_frontier(self, port: Port, *, window_hours: float = 24.0, n_samples: int = 200, seed: int | None = 42) -> list[tuple[np.ndarray, float, float]]:
        """Sample the decision space and return the (throughput, -congestion)
        Pareto-efficient set, giving operators alternative solutions rather
        than a single point recommendation (section 32)."""
        rng = np.random.default_rng(seed)
        baseline = baseline_inputs_from_port(port, window_hours=window_hours)
        samples = rng.uniform(0.0, 1.0, size=(n_samples, 4))
        points = []
        for x in samples:
            kpis = surrogate_kpis(port, x, baseline)
            points.append((x, kpis.throughput_teu_per_day, -kpis.congestion_ratio))

        pareto: list[tuple[np.ndarray, float, float]] = []
        for x, t, c in points:
            dominated = any((t2 >= t and c2 >= c) and (t2, c2) != (t, c) for _, t2, c2 in points)
            if not dominated:
                pareto.append((x, t, c))
        return pareto
