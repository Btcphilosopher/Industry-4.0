"""Port capacity curve (section 56).

Builds the relationship between cargo volume and port performance,
identifying the efficient operating region, the congestion threshold and
absolute capacity — derived from a :class:`~port4_engine.optimisation.sweep.ParameterSweep`
over container volume.
"""

from __future__ import annotations

from dataclasses import dataclass

from port4_engine.core.port import Port
from port4_engine.optimisation.sweep import SweepPoint


@dataclass
class CapacityCurve:
    points: list[SweepPoint]
    efficient_region: tuple[float, float]  # (min, max) volume multiplier where congestion stays below threshold
    congestion_threshold_multiplier: float | None  # first multiplier at which congestion crosses the threshold
    absolute_capacity_multiplier: float | None  # first multiplier at which throughput stops growing (saturation)


def build_capacity_curve(
    port: Port, *, multipliers: list[float] | None = None, congestion_threshold: float = 0.90, hours: float = 72.0
) -> CapacityCurve:
    multipliers = multipliers or [0.6, 0.8, 1.0, 1.2, 1.4, 1.6, 1.8, 2.0]

    engine_points: list[SweepPoint] = []
    from port4_engine.scenarios.engine import ScenarioEngine

    engine = ScenarioEngine(port)
    for i, m in enumerate(multipliers):
        scenario = engine.clone_current_state(f"capacity_curve_{i}")
        scenario.container_volume = m
        r = scenario.simulate(hours=hours)
        x = r.projected_inputs
        engine_points.append(
            SweepPoint(
                value=m,
                throughput_teu_per_day=x.throughput_teu_per_day,
                vessel_waiting_hours=x.vessel_waiting_hours,
                yard_congestion_ratio=x.congestion_ratio,
                energy_kwh=x.energy_kwh,
                operating_cost=x.operating_cost,
                port_score=r.projected_score,
            )
        )

    efficient = [p.value for p in engine_points if p.yard_congestion_ratio < congestion_threshold]
    efficient_region = (min(efficient), max(efficient)) if efficient else (0.0, 0.0)

    congestion_crossing = next((p.value for p in engine_points if p.yard_congestion_ratio >= congestion_threshold), None)

    absolute_capacity = None
    for i in range(1, len(engine_points)):
        prev, curr = engine_points[i - 1], engine_points[i]
        if curr.throughput_teu_per_day <= prev.throughput_teu_per_day * 1.01:
            absolute_capacity = curr.value
            break

    return CapacityCurve(
        points=engine_points,
        efficient_region=efficient_region,
        congestion_threshold_multiplier=congestion_crossing,
        absolute_capacity_multiplier=absolute_capacity,
    )
