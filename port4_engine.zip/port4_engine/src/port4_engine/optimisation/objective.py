"""The multi-objective PortScore function (section 32).

    PortScore = w1*Throughput - w2*VesselWaiting - w3*TruckWaiting
              - w4*ContainerDwell - w5*Energy - w6*OperatingCost
              - w7*Congestion + w8*Quality

All weights are configurable (see
:class:`~port4_engine.configuration.config.OptimisationWeights`). Inputs
are normalised to comparable [0, 1]-ish ranges before weighting so that no
single raw-unit term (e.g. energy in kWh vs. waiting in hours) dominates
by scale alone.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class PortScoreWeights:
    throughput: float = 1.0
    vessel_waiting: float = 1.0
    truck_waiting: float = 0.5
    container_dwell: float = 0.5
    energy: float = 0.3
    operating_cost: float = 0.5
    congestion: float = 0.8
    quality: float = 0.4


@dataclass
class PortScoreInputs:
    throughput_teu_per_day: float
    vessel_waiting_hours: float
    truck_waiting_minutes: float
    container_dwell_hours: float
    energy_kwh: float
    operating_cost: float
    congestion_ratio: float  # 0..1
    quality_score: float  # 0..1, e.g. 1 - damage/error rate

    # normalisation reference scales, configurable per port authority
    throughput_reference: float = 12000.0
    vessel_waiting_reference_hours: float = 24.0
    truck_waiting_reference_minutes: float = 60.0
    container_dwell_reference_hours: float = 96.0
    energy_reference_kwh: float = 200_000.0
    operating_cost_reference: float = 500_000.0


class PortScore:
    def __init__(self, weights: PortScoreWeights | None = None) -> None:
        self.weights = weights or PortScoreWeights()

    def evaluate(self, x: PortScoreInputs) -> float:
        w = self.weights
        throughput_term = min(2.0, x.throughput_teu_per_day / x.throughput_reference)
        waiting_term = min(2.0, x.vessel_waiting_hours / x.vessel_waiting_reference_hours)
        truck_term = min(2.0, x.truck_waiting_minutes / x.truck_waiting_reference_minutes)
        dwell_term = min(2.0, x.container_dwell_hours / x.container_dwell_reference_hours)
        energy_term = min(2.0, x.energy_kwh / x.energy_reference_kwh)
        cost_term = min(2.0, x.operating_cost / x.operating_cost_reference)
        congestion_term = max(0.0, min(1.0, x.congestion_ratio))
        quality_term = max(0.0, min(1.0, x.quality_score))

        return (
            w.throughput * throughput_term
            - w.vessel_waiting * waiting_term
            - w.truck_waiting * truck_term
            - w.container_dwell * dwell_term
            - w.energy * energy_term
            - w.operating_cost * cost_term
            - w.congestion * congestion_term
            + w.quality * quality_term
        )

    def component_breakdown(self, x: PortScoreInputs) -> dict[str, float]:
        """Explainable per-component contribution to the overall score,
        so an optimisation result can be justified term by term."""
        w = self.weights
        return {
            "throughput": w.throughput * min(2.0, x.throughput_teu_per_day / x.throughput_reference),
            "vessel_waiting": -w.vessel_waiting * min(2.0, x.vessel_waiting_hours / x.vessel_waiting_reference_hours),
            "truck_waiting": -w.truck_waiting * min(2.0, x.truck_waiting_minutes / x.truck_waiting_reference_minutes),
            "container_dwell": -w.container_dwell * min(2.0, x.container_dwell_hours / x.container_dwell_reference_hours),
            "energy": -w.energy * min(2.0, x.energy_kwh / x.energy_reference_kwh),
            "operating_cost": -w.operating_cost * min(2.0, x.operating_cost / x.operating_cost_reference),
            "congestion": -w.congestion * max(0.0, min(1.0, x.congestion_ratio)),
            "quality": w.quality * max(0.0, min(1.0, x.quality_score)),
        }
