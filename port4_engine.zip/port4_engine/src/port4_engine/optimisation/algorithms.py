"""Pluggable optimisation algorithms (section 33).

Every port-wide or subsystem optimisation problem in this engine (berth
scheduling, crane allocation, yard placement, port-wide resource
allocation) can be solved by more than one algorithm, and the "right" one
is problem-dependent — a MILP is appropriate for a small, well-structured
berth schedule; a genetic algorithm or particle swarm suits a large,
non-convex, multi-resource allocation problem; greedy/local-search is
usually good enough and fast for online, myopic decisions. This module
provides algorithm-agnostic building blocks so callers select rather than
one algorithm being hard-wired everywhere.

All continuous-domain algorithms operate over ``x: np.ndarray`` and a
``score_fn(x) -> float`` to **maximise**.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from dataclasses import dataclass
from typing import Generic, Protocol, TypeVar

import numpy as np
from scipy.optimize import differential_evolution, linprog

T = TypeVar("T")


@dataclass
class OptimizationResult(Generic[T]):
    solution: T
    score: float
    algorithm: str
    iterations: int
    history: list[float]


class Algorithm(Protocol):
    def __call__(self, score_fn: Callable[[np.ndarray], float], bounds: Sequence[tuple[float, float]], **kwargs: object) -> OptimizationResult[np.ndarray]: ...


# -- combinatorial ------------------------------------------------------------
def greedy_search(
    candidates: Sequence[T], score_fn: Callable[[list[T]], float], *, max_select: int | None = None
) -> OptimizationResult[list[T]]:
    """Iteratively add whichever remaining candidate most improves the score."""
    remaining = list(candidates)
    selected: list[T] = []
    history: list[float] = []
    best_score = score_fn(selected)
    history.append(best_score)

    while remaining and (max_select is None or len(selected) < max_select):
        best_candidate = None
        best_candidate_score = best_score
        for c in remaining:
            trial_score = score_fn(selected + [c])
            if trial_score > best_candidate_score:
                best_candidate, best_candidate_score = c, trial_score
        if best_candidate is None:
            break
        selected.append(best_candidate)
        remaining.remove(best_candidate)
        best_score = best_candidate_score
        history.append(best_score)

    return OptimizationResult(solution=selected, score=best_score, algorithm="greedy", iterations=len(history), history=history)


def local_search(
    initial: list[T],
    score_fn: Callable[[list[T]], float],
    neighbors_fn: Callable[[list[T]], list[list[T]]],
    *,
    max_iterations: int = 200,
) -> OptimizationResult[list[T]]:
    """Hill-climb over a discrete solution using a neighbourhood function."""
    current = list(initial)
    current_score = score_fn(current)
    history = [current_score]

    for _ in range(max_iterations):
        neighbours = neighbors_fn(current)
        if not neighbours:
            break
        best_neighbour = max(neighbours, key=score_fn)
        best_neighbour_score = score_fn(best_neighbour)
        if best_neighbour_score <= current_score:
            break
        current, current_score = best_neighbour, best_neighbour_score
        history.append(current_score)

    return OptimizationResult(solution=current, score=current_score, algorithm="local_search", iterations=len(history), history=history)


# -- continuous, metaheuristic --------------------------------------------------
def simulated_annealing(
    score_fn: Callable[[np.ndarray], float],
    bounds: Sequence[tuple[float, float]],
    *,
    rng: np.random.Generator | None = None,
    iterations: int = 2000,
    initial_temperature: float = 1.0,
    cooling_rate: float = 0.995,
) -> OptimizationResult[np.ndarray]:
    rng = rng or np.random.default_rng()
    bounds_arr = np.array(bounds)
    x = rng.uniform(bounds_arr[:, 0], bounds_arr[:, 1])
    best_x, best_score = x.copy(), score_fn(x)
    current_score = best_score
    temperature = initial_temperature
    history = [best_score]

    for _ in range(iterations):
        step_scale = (bounds_arr[:, 1] - bounds_arr[:, 0]) * 0.05
        candidate = np.clip(x + rng.normal(0, step_scale), bounds_arr[:, 0], bounds_arr[:, 1])
        candidate_score = score_fn(candidate)
        delta = candidate_score - current_score
        if delta > 0 or rng.random() < np.exp(delta / max(temperature, 1e-9)):
            x, current_score = candidate, candidate_score
            if current_score > best_score:
                best_x, best_score = x.copy(), current_score
        temperature *= cooling_rate
        history.append(best_score)

    return OptimizationResult(solution=best_x, score=best_score, algorithm="simulated_annealing", iterations=iterations, history=history)


def genetic_search(
    score_fn: Callable[[np.ndarray], float],
    bounds: Sequence[tuple[float, float]],
    *,
    seed: int | None = None,
    max_iterations: int = 100,
    population_size: int = 30,
) -> OptimizationResult[np.ndarray]:
    """Genetic-algorithm-style search via SciPy's differential evolution."""
    history: list[float] = []

    def neg_score(x: np.ndarray) -> float:
        s = score_fn(x)
        history.append(s)
        return -s

    result = differential_evolution(
        neg_score, bounds=list(bounds), seed=seed, maxiter=max_iterations, popsize=max(4, population_size // len(bounds) if bounds else population_size), polish=True
    )
    best_history = list(np.maximum.accumulate(history)) if history else [float(-result.fun)]
    return OptimizationResult(
        solution=result.x, score=float(-result.fun), algorithm="genetic", iterations=int(result.nit), history=best_history
    )


def particle_swarm(
    score_fn: Callable[[np.ndarray], float],
    bounds: Sequence[tuple[float, float]],
    *,
    rng: np.random.Generator | None = None,
    n_particles: int = 30,
    iterations: int = 100,
    inertia: float = 0.6,
    cognitive: float = 1.4,
    social: float = 1.4,
) -> OptimizationResult[np.ndarray]:
    rng = rng or np.random.default_rng()
    bounds_arr = np.array(bounds)
    dim = len(bounds)
    lo, hi = bounds_arr[:, 0], bounds_arr[:, 1]

    positions = rng.uniform(lo, hi, size=(n_particles, dim))
    velocities = rng.uniform(-(hi - lo) * 0.1, (hi - lo) * 0.1, size=(n_particles, dim))
    personal_best = positions.copy()
    personal_best_scores = np.array([score_fn(p) for p in positions])
    global_best_idx = int(np.argmax(personal_best_scores))
    global_best = personal_best[global_best_idx].copy()
    global_best_score = personal_best_scores[global_best_idx]
    history = [global_best_score]

    for _ in range(iterations):
        r1, r2 = rng.random((n_particles, dim)), rng.random((n_particles, dim))
        velocities = (
            inertia * velocities
            + cognitive * r1 * (personal_best - positions)
            + social * r2 * (global_best - positions)
        )
        positions = np.clip(positions + velocities, lo, hi)
        scores = np.array([score_fn(p) for p in positions])
        improved = scores > personal_best_scores
        personal_best[improved] = positions[improved]
        personal_best_scores[improved] = scores[improved]
        best_idx = int(np.argmax(personal_best_scores))
        if personal_best_scores[best_idx] > global_best_score:
            global_best = personal_best[best_idx].copy()
            global_best_score = personal_best_scores[best_idx]
        history.append(global_best_score)

    return OptimizationResult(solution=global_best, score=float(global_best_score), algorithm="particle_swarm", iterations=iterations, history=history)


# -- exact / mathematical programming interfaces --------------------------------
def linear_program(
    c: np.ndarray, A_ub: np.ndarray | None = None, b_ub: np.ndarray | None = None, bounds: Sequence[tuple[float, float]] | None = None
) -> OptimizationResult[np.ndarray]:
    """Thin wrapper over :func:`scipy.optimize.linprog` (minimises ``c @ x``).

    Provided as the engine's LP interface (section 33 "linear programming
    interfaces"); callers negate their maximisation objective into ``c``.
    """
    result = linprog(c, A_ub=A_ub, b_ub=b_ub, bounds=bounds, method="highs")
    return OptimizationResult(
        solution=result.x if result.success else np.array([]),
        score=float(-result.fun) if result.success else float("-inf"),
        algorithm="linear_program",
        iterations=int(getattr(result, "nit", 0)),
        history=[float(-result.fun)] if result.success else [],
    )
