"""Parameter sweep engine (section 55).

    results = sweep.run(parameter="container_volume", values=[8000, 9000, 10000, 11000, 12000])

Lets a port authority discover capacity limits by scanning a scenario
parameter across a range of values and recording the resulting
throughput, turnaround, yard utilisation, energy, cost and congestion —
built directly on :mod:`port4_engine.scenarios`, one scenario per value.
"""

from __future__ import annotations

from dataclasses import dataclass

from port4_engine.core.port import Port
from port4_engine.scenarios.engine import ScenarioEngine

SWEEPABLE_PARAMETERS = {
    "container_volume": "container_volume_multiplier",
    "road_closure_factor": "road_closure_factor",
    "weather_disruption_severity": "weather_disruption_severity",
    "labour_constraint_factor": "labour_constraint_factor",
}


@dataclass
class SweepPoint:
    value: float
    throughput_teu_per_day: float
    vessel_waiting_hours: float
    yard_congestion_ratio: float
    energy_kwh: float
    operating_cost: float
    port_score: float


@dataclass
class SweepResult:
    parameter: str
    points: list[SweepPoint]

    def as_table(self) -> list[dict[str, float]]:
        return [p.__dict__ for p in self.points]


class ParameterSweep:
    def __init__(self, port: Port) -> None:
        self.port = port

    def run(self, *, parameter: str, values: list[float], hours: float = 72.0) -> SweepResult:
        if parameter == "container_volume":
            base = 10_000.0
            values = [v / base for v in values]  # caller passes absolute TEU/day targets; normalise to a multiplier

        attr = SWEEPABLE_PARAMETERS.get(parameter)
        if attr is None:
            raise ValueError(f"unsupported sweep parameter: {parameter}. Supported: {sorted(SWEEPABLE_PARAMETERS)}")

        engine = ScenarioEngine(self.port)
        points: list[SweepPoint] = []
        for i, value in enumerate(values):
            scenario = engine.clone_current_state(f"sweep_{parameter}_{i}")
            setattr(scenario, attr, value)
            result = scenario.simulate(hours=hours)
            x = result.projected_inputs
            points.append(
                SweepPoint(
                    value=value,
                    throughput_teu_per_day=x.throughput_teu_per_day,
                    vessel_waiting_hours=x.vessel_waiting_hours,
                    yard_congestion_ratio=x.congestion_ratio,
                    energy_kwh=x.energy_kwh,
                    operating_cost=x.operating_cost,
                    port_score=result.projected_score,
                )
            )
        return SweepResult(parameter=parameter, points=points)
