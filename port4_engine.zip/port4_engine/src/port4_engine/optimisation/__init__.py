"""Multi-objective port-wide optimisation (sections 31-33)."""

from port4_engine.optimisation.objective import PortScore, PortScoreInputs, PortScoreWeights
from port4_engine.optimisation.algorithms import (
    Algorithm,
    genetic_search,
    greedy_search,
    linear_program,
    local_search,
    particle_swarm,
    simulated_annealing,
)
from port4_engine.optimisation.port_optimizer import PortOptimizer, PortOptimizationResult

# NOTE: `sweep` and `capacity_curve` are deliberately not imported here.
# Both depend on `port4_engine.scenarios`, which itself imports
# `port4_engine.optimisation.objective` — eagerly importing them at
# package init time creates an import cycle. Import them directly from
# `port4_engine.optimisation.sweep` / `.capacity_curve` instead.

__all__ = [
    "PortScore",
    "PortScoreInputs",
    "PortScoreWeights",
    "Algorithm",
    "greedy_search",
    "local_search",
    "simulated_annealing",
    "genetic_search",
    "particle_swarm",
    "linear_program",
    "PortOptimizer",
    "PortOptimizationResult",
]
