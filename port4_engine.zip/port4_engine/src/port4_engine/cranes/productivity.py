"""Crane productivity modelling (section 11).

Models the complete move cycle POSITION -> PICK -> LIFT -> MOVE -> LOWER ->
RELEASE -> RETURN with configurable per-phase probability distributions
(rather than a fixed cycle time), and derives moves/hour, cycle time,
idle/working time and energy/move from it.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum

import numpy as np


class CraneCyclePhase(StrEnum):
    POSITION = "POSITION"
    PICK = "PICK"
    LIFT = "LIFT"
    MOVE = "MOVE"
    LOWER = "LOWER"
    RELEASE = "RELEASE"
    RETURN = "RETURN"


DEFAULT_PHASE_MEANS_SECONDS: dict[CraneCyclePhase, float] = {
    CraneCyclePhase.POSITION: 12.0,
    CraneCyclePhase.PICK: 8.0,
    CraneCyclePhase.LIFT: 10.0,
    CraneCyclePhase.MOVE: 25.0,
    CraneCyclePhase.LOWER: 10.0,
    CraneCyclePhase.RELEASE: 6.0,
    CraneCyclePhase.RETURN: 20.0,
}


@dataclass
class CycleResult:
    phase_seconds: dict[CraneCyclePhase, float]
    total_seconds: float
    energy_kwh: float


@dataclass
class CraneProductivityModel:
    """Configurable per-phase lognormal cycle-time distributions.

    ``phase_means_seconds`` gives the expected duration of each phase;
    ``variability`` controls the coefficient of variation applied via a
    lognormal draw, so cycles are realistically variable rather than
    constant.
    """

    phase_means_seconds: dict[CraneCyclePhase, float] = field(
        default_factory=lambda: dict(DEFAULT_PHASE_MEANS_SECONDS)
    )
    variability: float = 0.20
    energy_rate_kw: float = 65.0
    fault_probability_per_cycle: float = 0.01
    fault_extra_seconds_scale: float = 300.0

    def sample_cycle(self, rng: np.random.Generator) -> CycleResult:
        phases: dict[CraneCyclePhase, float] = {}
        for phase, mean in self.phase_means_seconds.items():
            sigma = self.variability
            mu = np.log(mean) - 0.5 * sigma**2
            duration = float(rng.lognormal(mu, sigma))
            phases[phase] = duration

        if rng.random() < self.fault_probability_per_cycle:
            phases[CraneCyclePhase.LIFT] += float(rng.exponential(self.fault_extra_seconds_scale))

        total_seconds = sum(phases.values())
        energy_kwh = self.energy_rate_kw * (total_seconds / 3600.0)
        return CycleResult(phase_seconds=phases, total_seconds=total_seconds, energy_kwh=energy_kwh)

    def expected_moves_per_hour(self) -> float:
        expected_cycle_s = sum(self.phase_means_seconds.values())
        return 3600.0 / expected_cycle_s if expected_cycle_s else 0.0

    def simulate_shift(self, rng: np.random.Generator, hours: float) -> dict[str, float]:
        """Monte Carlo a working shift and return aggregate productivity stats."""
        elapsed = 0.0
        moves = 0
        energy = 0.0
        horizon_s = hours * 3600.0
        while elapsed < horizon_s:
            cycle = self.sample_cycle(rng)
            elapsed += cycle.total_seconds
            energy += cycle.energy_kwh
            moves += 1
        working_time_s = min(elapsed, horizon_s)
        idle_time_s = max(0.0, horizon_s - working_time_s)
        return {
            "moves_per_hour": moves / hours if hours else 0.0,
            "cycle_time_seconds": (working_time_s / moves) if moves else 0.0,
            "idle_time_hours": idle_time_s / 3600.0,
            "working_time_hours": working_time_s / 3600.0,
            "energy_per_move_kwh": (energy / moves) if moves else 0.0,
            "total_energy_kwh": energy,
            "total_moves": float(moves),
        }
