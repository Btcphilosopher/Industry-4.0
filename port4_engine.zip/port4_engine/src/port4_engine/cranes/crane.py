"""The Crane entity (section 10)."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum

from port4_engine.core.ids import EntityId, IdMixin, new_id
from port4_engine.models.geometry import Point


class CraneType(StrEnum):
    STS = "STS"  # ship-to-shore
    RTG = "RTG"  # rubber-tyred gantry
    RMG = "RMG"  # rail-mounted gantry
    MOBILE_HARBOUR_CRANE = "MOBILE_HARBOUR_CRANE"
    REACH_STACKER = "REACH_STACKER"
    STRADDLE_CARRIER = "STRADDLE_CARRIER"


class CraneStatus(StrEnum):
    IDLE = "IDLE"
    WORKING = "WORKING"
    REPOSITIONING = "REPOSITIONING"
    MAINTENANCE = "MAINTENANCE"
    FAULT = "FAULT"


class MaintenanceState(StrEnum):
    HEALTHY = "HEALTHY"
    DUE_SOON = "DUE_SOON"
    OVERDUE = "OVERDUE"
    UNDER_MAINTENANCE = "UNDER_MAINTENANCE"


@dataclass
class Crane(IdMixin):
    id_prefix = "CRANE"

    crane_type: CraneType
    position: Point
    capacity_tonnes: float
    max_reach_m: float
    speed_m_per_s: float
    energy_rate_kw: float
    id: EntityId = field(default_factory=lambda: new_id("CRANE"))
    status: CraneStatus = CraneStatus.IDLE
    maintenance_state: MaintenanceState = MaintenanceState.HEALTHY
    current_task: EntityId | None = None

    operating_hours: float = 0.0
    total_cycles: int = 0
    fault_count: int = 0

    def health_score(self) -> float:
        """A simple statistical health proxy in [0, 1] (see maintenance module for the full model)."""
        base = 1.0
        base -= min(0.4, self.fault_count * 0.05)
        if self.maintenance_state == MaintenanceState.DUE_SOON:
            base -= 0.1
        elif self.maintenance_state == MaintenanceState.OVERDUE:
            base -= 0.3
        elif self.maintenance_state == MaintenanceState.UNDER_MAINTENANCE:
            base -= 0.5
        wear = min(0.2, self.operating_hours / 50_000)
        return max(0.0, base - wear)

    def start_task(self, task_id: EntityId) -> None:
        self.status = CraneStatus.WORKING
        self.current_task = task_id

    def complete_task(self) -> None:
        self.status = CraneStatus.IDLE
        self.current_task = None
        self.total_cycles += 1
