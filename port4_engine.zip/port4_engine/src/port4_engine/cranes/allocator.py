"""Crane allocation optimisation (section 12).

Assigns cranes to vessels considering cargo volume, deadline, crane
availability/productivity/location and maintenance status, and returns the
allocation together with expected moves/hour, estimated completion time and
estimated energy consumption.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta

from port4_engine.core.ids import EntityId
from port4_engine.cranes.crane import Crane, CraneStatus, MaintenanceState
from port4_engine.cranes.productivity import CraneProductivityModel
from port4_engine.vessels.vessel import Vessel


@dataclass
class CraneAllocation:
    vessel_id: EntityId
    crane_ids: list[EntityId]
    expected_moves_per_hour_total: float
    estimated_completion: datetime
    estimated_energy_kwh: float


class CraneAllocator:
    def __init__(self, productivity_model: CraneProductivityModel | None = None) -> None:
        self.productivity_model = productivity_model or CraneProductivityModel()

    def _crane_score(self, crane: Crane, vessel: Vessel) -> float:
        if crane.status in {CraneStatus.MAINTENANCE, CraneStatus.FAULT}:
            return -1.0
        if crane.maintenance_state == MaintenanceState.UNDER_MAINTENANCE:
            return -1.0
        # Crane location relative to the assigned berth is resolved once a berth
        # geometry is available (see geospatial.PortGeometryClient); until then,
        # health and maintenance status alone drive candidate ranking.
        return crane.health_score()

    def allocate(
        self,
        vessel: Vessel,
        available_cranes: list[Crane],
        *,
        now: datetime,
        max_cranes: int | None = None,
    ) -> CraneAllocation:
        candidates = sorted(
            (c for c in available_cranes if self._crane_score(c, vessel) >= 0),
            key=lambda c: -self._crane_score(c, vessel),
        )
        needed = max(1, int(round(vessel.remaining_cargo_teu() / 800))) if vessel.remaining_cargo_teu() else 1
        if max_cranes is not None:
            needed = min(needed, max_cranes)
        selected = candidates[:needed]

        per_crane_moves_per_hour = self.productivity_model.expected_moves_per_hour()
        total_moves_per_hour = per_crane_moves_per_hour * len(selected)
        teu_per_move = 1.6  # blended average across 20ft/40ft mix
        remaining_moves = vessel.remaining_cargo_teu() / teu_per_move if vessel.remaining_cargo_teu() else 0.0
        hours_to_complete = remaining_moves / total_moves_per_hour if total_moves_per_hour else float("inf")
        estimated_completion = now + timedelta(hours=hours_to_complete if hours_to_complete != float("inf") else 0.0)

        energy_per_move = self.productivity_model.energy_rate_kw * (
            (3600.0 / per_crane_moves_per_hour) / 3600.0 if per_crane_moves_per_hour else 0.0
        )
        estimated_energy = energy_per_move * remaining_moves

        for crane in selected:
            crane.start_task(vessel.id)

        return CraneAllocation(
            vessel_id=vessel.id,
            crane_ids=[c.id for c in selected],
            expected_moves_per_hour_total=total_moves_per_hour,
            estimated_completion=estimated_completion,
            estimated_energy_kwh=estimated_energy,
        )
