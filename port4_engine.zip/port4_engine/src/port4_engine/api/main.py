"""The Port4.Engine FastAPI application (sections 43-44).

Exposes state, KPIs, optimisation, simulation, scenario and forecasting
endpoints over REST, plus real-time WebSocket streams for the simulation
clock, digital-twin entity updates, optimisation progress and alerts.

This reference implementation serves a single in-memory demonstration
port (built lazily on first request via
:func:`~port4_engine.simulation.demo_port.build_demo_port`); a production
deployment would key ``AppState`` by ``port_id`` and back it with the real
:class:`~port4_engine.integration.rust_core.RustPortCore` transport
instead of the local stub.
"""

from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from pydantic import BaseModel

from port4_engine.berths.optimizer import BerthOptimizer
from port4_engine.cranes.allocator import CraneAllocator
from port4_engine.forecasting.congestion import CongestionForecaster
from port4_engine.forecasting.demand import DemandForecaster
from port4_engine.optimisation.port_optimizer import PortOptimizer
from port4_engine.routing.graph import RouteMetric
from port4_engine.scenarios.engine import ScenarioEngine
from port4_engine.simulation.demo_port import DemoPortBundle, build_demo_port, run_demo
from port4_engine.statistics.bottleneck import BottleneckDetector
from port4_engine.statistics.health import compute_port_health
from port4_engine.statistics.kpi import KpiEngine


@dataclass
class AppState:
    bundle: DemoPortBundle | None = None

    def get(self) -> DemoPortBundle:
        if self.bundle is None:
            self.bundle = build_demo_port()
        return self.bundle


_state = AppState()


def get_app_state() -> AppState:
    return _state


app = FastAPI(
    title="Port4.Engine API",
    description="The PORT 4.0 Python intelligence and simulation engine.",
    version="0.1.0",
)


def _entity_summary(entity: Any) -> dict[str, Any]:
    d = {}
    for attr in ("id", "status", "name", "capacity_teu", "length_m", "occupied", "vessel_id"):
        if hasattr(entity, attr):
            d[attr] = getattr(entity, attr)
    return d


# -- state / KPIs --------------------------------------------------------------
@app.get("/port/state")
def port_state() -> dict[str, Any]:
    port = _state.get().port
    return {"port_id": port.port_id, "name": port.name, "entity_counts": port.entity_count()}


@app.get("/port/kpis")
def port_kpis() -> dict[str, float]:
    port = _state.get().port
    return KpiEngine(port).compute().as_dict()


@app.get("/port/health")
def port_health() -> dict[str, float]:
    return compute_port_health(_state.get().port).as_dict()


@app.get("/port/bottlenecks")
def port_bottlenecks() -> list[dict[str, Any]]:
    findings = BottleneckDetector(_state.get().port).detect()
    return [
        {"subsystem": f.subsystem, "identifier": f.identifier, "utilisation": f.utilisation, "severity": f.severity, "causal_chain": f.causal_chain}
        for f in findings
    ]


@app.get("/vessels")
def list_vessels() -> list[dict[str, Any]]:
    return [_entity_summary(v) for v in _state.get().port.vessels.values()]


@app.get("/berths")
def list_berths() -> list[dict[str, Any]]:
    return [_entity_summary(b) for b in _state.get().port.berths.values()]


@app.get("/containers")
def list_containers(limit: int = 200) -> list[dict[str, Any]]:
    return [_entity_summary(c) for c in list(_state.get().port.containers.values())[:limit]]


@app.get("/yards")
def list_yards() -> list[dict[str, Any]]:
    return [{"id": y.id, "name": y.name, "utilisation": y.utilisation(), "capacity": y.capacity()} for y in _state.get().port.yards.values()]


@app.get("/cranes")
def list_cranes() -> list[dict[str, Any]]:
    return [_entity_summary(c) for c in _state.get().port.cranes.values()]


@app.get("/trucks")
def list_trucks() -> list[dict[str, Any]]:
    return [_entity_summary(t) for t in _state.get().port.trucks.values()]


@app.get("/rail")
def rail_state() -> dict[str, Any]:
    rn = _state.get().port.rail_network
    if rn is None:
        return {"terminals": [], "trains": []}
    return {
        "terminals": [{"id": t.id, "name": t.name, "platforms": t.platforms, "occupied": len(t.occupied_platforms)} for t in rn.terminals.values()],
        "trains": [{"id": t.id, "status": t.status.value, "loaded_teu": t.total_loaded_teu()} for t in rn.trains.values()],
        "platform_utilisation": rn.total_platform_utilisation(),
    }


_scenario_store: dict[str, dict[str, Any]] = {}


@app.get("/scenarios")
def list_scenarios() -> list[dict[str, Any]]:
    return [{"name": name, **result} for name, result in _scenario_store.items()]


# -- optimisation ---------------------------------------------------------------
class BerthOptimiseRequest(BaseModel):
    horizon_hours: float = 72.0


@app.post("/optimise/berths")
def optimise_berths(req: BerthOptimiseRequest) -> dict[str, Any]:
    port = _state.get().port
    optimizer = BerthOptimizer()
    schedule = optimizer.optimize(list(port.vessels.values()), list(port.berths.values()), horizon_hours=req.horizon_hours)
    return {
        "total_waiting_hours": schedule.total_waiting_hours(),
        "average_turnaround_hours": schedule.average_turnaround_hours(),
        "unassigned_vessel_ids": schedule.unassigned_vessel_ids,
        "assignment_count": len(schedule.assignments),
    }


class CraneOptimiseRequest(BaseModel):
    vessel_id: str
    max_cranes: int | None = None


@app.post("/optimise/cranes")
def optimise_cranes(req: CraneOptimiseRequest) -> dict[str, Any]:
    port = _state.get().port
    vessel = port.vessels.get(req.vessel_id)
    if vessel is None:
        return {"error": f"unknown vessel_id {req.vessel_id}"}
    allocator = CraneAllocator()
    allocation = allocator.allocate(vessel, list(port.cranes.values()), now=datetime.now(timezone.utc), max_cranes=req.max_cranes)
    return {
        "vessel_id": allocation.vessel_id,
        "crane_ids": allocation.crane_ids,
        "expected_moves_per_hour_total": allocation.expected_moves_per_hour_total,
        "estimated_completion": allocation.estimated_completion.isoformat(),
        "estimated_energy_kwh": allocation.estimated_energy_kwh,
    }


@app.post("/optimise/yards")
def optimise_yards() -> dict[str, Any]:
    from port4_engine.yards.congestion import YardCongestionAnalyzer

    port = _state.get().port
    reports = {y.name: YardCongestionAnalyzer().analyze(y).__dict__ for y in port.yards.values()}
    return {"yards": reports}


class RouteRequest(BaseModel):
    origin: str
    destination: str
    metric: RouteMetric = "fastest"


@app.post("/optimise/routes")
def optimise_routes(req: RouteRequest) -> dict[str, Any]:
    port = _state.get().port
    if port.roads is None:
        return {"error": "no road graph registered for this port"}
    result = port.roads.route(req.origin, req.destination, metric=req.metric)
    return {"path": result.path, "distance_m": result.total_distance_m, "time_s": result.total_time_s, "energy_kwh": result.total_energy_kwh}


class PortOptimiseRequest(BaseModel):
    algorithm: str = "genetic"
    window_hours: float = 24.0


@app.post("/optimise/port")
def optimise_port(req: PortOptimiseRequest) -> dict[str, Any]:
    port = _state.get().port
    result = PortOptimizer().optimize(port, algorithm=req.algorithm, window_hours=req.window_hours)
    return {
        "algorithm": result.algorithm,
        "decisions": result.decisions,
        "score": result.score,
        "score_breakdown": result.score_breakdown,
    }


# -- simulation --------------------------------------------------------------
class SimulateRequest(BaseModel):
    horizon_hours: float = 24.0
    random_seed: int = 42


@app.post("/simulate")
def simulate(req: SimulateRequest) -> dict[str, Any]:
    bundle = run_demo(horizon_hours=req.horizon_hours, random_seed=req.random_seed)
    _state.bundle = bundle
    kpis = KpiEngine(bundle.port, window_hours=req.horizon_hours).compute()
    return {
        "events_processed": bundle.engine.events_processed,
        "vessels_handled": len(bundle.port.vessels),
        "containers_tracked": len(bundle.port.containers),
        "kpis": kpis.as_dict(),
    }


class ScenarioRequest(BaseModel):
    name: str
    container_volume_multiplier: float = 1.0
    disabled_crane_ids: list[str] = []
    disabled_berth_ids: list[str] = []
    rail_closed: bool = False
    road_closure_factor: float = 0.0
    weather_disruption_severity: float = 0.0
    fuel_price_increase_fraction: float = 0.0
    energy_price_increase_fraction: float = 0.0
    labour_constraint_factor: float = 0.0
    horizon_hours: float = 72.0


@app.post("/scenario")
def scenario(req: ScenarioRequest) -> dict[str, Any]:
    port = _state.get().port
    engine = ScenarioEngine(port)
    sc = engine.clone_current_state(req.name)
    sc.container_volume_multiplier = req.container_volume_multiplier
    sc.disabled_crane_ids = set(req.disabled_crane_ids)
    sc.disabled_berth_ids = set(req.disabled_berth_ids)
    sc.rail_closed = req.rail_closed
    sc.road_closure_factor = req.road_closure_factor
    sc.weather_disruption_severity = req.weather_disruption_severity
    sc.fuel_price_multiplier = 1.0 + req.fuel_price_increase_fraction
    sc.energy_price_multiplier = 1.0 + req.energy_price_increase_fraction
    sc.labour_constraint_factor = req.labour_constraint_factor

    result = sc.simulate(hours=req.horizon_hours)
    delta = result.delta()
    _scenario_store[req.name] = {"score": result.projected_score, "delta": delta}
    return {"name": req.name, "baseline_score": result.baseline_score, "projected_score": result.projected_score, "delta": delta}


class ScenarioCompareRequest(BaseModel):
    names: list[str]


@app.post("/scenario/compare")
def scenario_compare(req: ScenarioCompareRequest) -> dict[str, Any]:
    return {name: _scenario_store.get(name, {"error": "not found"}) for name in req.names}


# -- forecasting --------------------------------------------------------------
@app.get("/forecast/demand")
def forecast_demand(periods: int = 24, seasonal_period: int = 24) -> dict[str, Any]:
    port = _state.get().port
    kpi = KpiEngine(port).compute()
    history = [max(0.0, kpi.teu_per_hour + (i % 7 - 3)) for i in range(72)]
    forecaster = DemandForecaster(seasonal_period=seasonal_period)
    result = forecaster.forecast_teu(history, periods)
    return {"point_forecast": result.point_forecast, "p10": result.p10, "p90": result.p90}


@app.get("/forecast/congestion")
def forecast_congestion(subsystem: str = "yard", horizon_hours: float = 24.0) -> dict[str, Any]:
    port = _state.get().port
    yard = next(iter(port.yards.values()), None)
    current = yard.utilisation() if yard else 0.0
    history = [max(0.0, min(1.0, current - 0.01 * i)) for i in range(23, -1, -1)]
    forecast = CongestionForecaster().forecast(subsystem, history, now=datetime.now(timezone.utc), horizon_hours=horizon_hours)
    return {
        "subsystem": forecast.subsystem,
        "current_utilisation": forecast.current_utilisation,
        "forecast_time": forecast.forecast_time.isoformat(),
        "forecast_utilisation": forecast.forecast_utilisation,
        "forecast_level": forecast.forecast_level.value,
        "p10": forecast.p10_utilisation,
        "p90": forecast.p90_utilisation,
    }


@app.get("/forecast/yard")
def forecast_yard(horizon_hours: float = 24.0) -> dict[str, Any]:
    return forecast_congestion(subsystem="yard", horizon_hours=horizon_hours)


# -- websockets ----------------------------------------------------------------
async def _stream(websocket: WebSocket, payload_fn, *, interval_seconds: float = 1.0) -> None:
    await websocket.accept()
    try:
        while True:
            await websocket.send_text(json.dumps(payload_fn(), default=str))
            await asyncio.sleep(interval_seconds)
    except WebSocketDisconnect:
        return


@app.websocket("/ws/simulation")
async def ws_simulation(websocket: WebSocket) -> None:
    def payload() -> dict[str, Any]:
        bundle = _state.get()
        return {
            "clock": bundle.engine.clock.isoformat(),
            "pending_events": bundle.engine.pending_event_count,
            "events_processed": bundle.engine.events_processed,
        }

    await _stream(websocket, payload)


@app.websocket("/ws/digital-twin")
async def ws_digital_twin(websocket: WebSocket) -> None:
    from port4_engine.integration.kotlin_dto import to_digital_twin_updates

    def payload() -> list[dict[str, Any]]:
        port = _state.get().port
        updates = to_digital_twin_updates(port, timestamp=datetime.now(timezone.utc))
        return [u.model_dump(mode="json") for u in updates[:100]]

    await _stream(websocket, payload)


@app.websocket("/ws/optimisation")
async def ws_optimisation(websocket: WebSocket) -> None:
    await websocket.accept()
    try:
        port = _state.get().port
        result = PortOptimizer().optimize(port, algorithm="greedy")
        await websocket.send_text(
            json.dumps({"decisions": result.decisions, "score": result.score, "breakdown": result.score_breakdown})
        )
    except WebSocketDisconnect:
        return


@app.websocket("/ws/alerts")
async def ws_alerts(websocket: WebSocket) -> None:
    def payload() -> list[dict[str, Any]]:
        findings = BottleneckDetector(_state.get().port).detect()
        return [
            {"subsystem": f.subsystem, "identifier": f.identifier, "severity": f.severity}
            for f in findings
            if f.severity in {"CONGESTED", "CRITICAL"}
        ]

    await _stream(websocket, payload, interval_seconds=5.0)
