"""FastAPI application exposing Port4.Engine over REST and WebSocket (sections 43-44)."""

from port4_engine.api.main import app, get_app_state

__all__ = ["app", "get_app_state"]
