"""The port Gate entity (section 24): queues, inspection, security,
document processing, scanning, entry and exit, plus queueing-theory-based
throughput/wait estimates."""

from __future__ import annotations

import math
from collections import deque
from dataclasses import dataclass, field
from enum import StrEnum

from port4_engine.core.ids import EntityId, IdMixin, new_id


class GateProcessStage(StrEnum):
    DOCUMENT_CHECK = "DOCUMENT_CHECK"
    SECURITY = "SECURITY"
    CONTAINER_SCAN = "CONTAINER_SCAN"
    INSPECTION = "INSPECTION"
    ENTRY = "ENTRY"
    EXIT = "EXIT"


@dataclass
class Gate(IdMixin):
    id_prefix = "GATE"

    name: str
    lanes: int
    mean_processing_minutes: float
    id: EntityId = field(default_factory=lambda: new_id("GATE"))
    capacity: int = 50  # max queue length before trucks are diverted/held
    queue: deque[EntityId] = field(default_factory=deque)
    stages: list[GateProcessStage] = field(
        default_factory=lambda: [GateProcessStage.DOCUMENT_CHECK, GateProcessStage.SECURITY, GateProcessStage.ENTRY]
    )
    served_count: int = 0
    total_wait_minutes: float = 0.0
    window_hours: float = 1.0

    @property
    def queue_length(self) -> int:
        return len(self.queue)

    @property
    def throughput_per_hour(self) -> float:
        return self.served_count / self.window_hours if self.window_hours else 0.0

    @property
    def avg_queue_minutes(self) -> float:
        return self.total_wait_minutes / self.served_count if self.served_count else 0.0

    def enqueue(self, truck_id: EntityId) -> bool:
        if len(self.queue) >= self.capacity:
            return False
        self.queue.append(truck_id)
        return True

    def serve_next(self, wait_minutes: float) -> EntityId | None:
        if not self.queue:
            return None
        truck_id = self.queue.popleft()
        self.served_count += 1
        self.total_wait_minutes += wait_minutes
        return truck_id

    def erlang_c_wait_minutes(self, arrival_rate_per_hour: float) -> float:
        """M/M/c queueing-theory estimate of expected wait, used for forecasting
        (independent of the discrete-event simulation's actual queue state)."""
        c = max(1, self.lanes)
        service_rate_per_hour = 60.0 / self.mean_processing_minutes if self.mean_processing_minutes else 1.0
        rho = arrival_rate_per_hour / (c * service_rate_per_hour)
        if rho >= 1.0:
            return float("inf")
        a = arrival_rate_per_hour / service_rate_per_hour
        sum_terms = sum((a**k) / math.factorial(k) for k in range(c))
        last_term = (a**c) / (math.factorial(c) * (1 - rho))
        p0 = 1.0 / (sum_terms + last_term)
        pwait = last_term * p0
        wq_hours = pwait / (c * service_rate_per_hour - arrival_rate_per_hour)
        return max(0.0, wq_hours * 60.0)
