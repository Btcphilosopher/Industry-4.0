"""Port-wide consolidated schedule.

A ``PortSchedule`` is what the engine hands back to Rust/Kotlin as *a
plan* — never an executed action (see the module docstring in
``port4_engine.__init__``): a flat, timestamp-ordered list of tasks drawn
from the berth schedule, crane allocations and yard placement decisions,
suitable for direct display on the operator dashboard or for the API's
``/optimise/port`` response.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from port4_engine.berths.optimizer import BerthSchedule
from port4_engine.core.ids import EntityId


@dataclass
class ScheduledTask:
    task_type: str  # "BERTH_VESSEL" | "CRANE_WORK" | "YARD_PLACEMENT" | ...
    entity_id: EntityId
    resource_id: EntityId
    start: datetime
    end: datetime | None
    detail: str = ""


@dataclass
class PortSchedule:
    tasks: list[ScheduledTask] = field(default_factory=list)

    @classmethod
    def from_berth_schedule(cls, berth_schedule: BerthSchedule) -> "PortSchedule":
        schedule = cls()
        for a in berth_schedule.assignments:
            schedule.tasks.append(
                ScheduledTask(
                    task_type="BERTH_VESSEL",
                    entity_id=a.vessel_id,
                    resource_id=a.berth_id,
                    start=a.start,
                    end=a.end,
                    detail=f"waiting={a.waiting_hours:.1f}h",
                )
            )
        return schedule

    def add_task(self, task: ScheduledTask) -> None:
        self.tasks.append(task)

    def ordered(self) -> list[ScheduledTask]:
        return sorted(self.tasks, key=lambda t: t.start)

    def for_resource(self, resource_id: EntityId) -> list[ScheduledTask]:
        return [t for t in self.tasks if t.resource_id == resource_id]

    def for_entity(self, entity_id: EntityId) -> list[ScheduledTask]:
        return [t for t in self.tasks if t.entity_id == entity_id]
