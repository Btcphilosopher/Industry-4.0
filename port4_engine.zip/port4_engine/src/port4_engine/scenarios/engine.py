"""ScenarioEngine: clone the current port state and compare scenarios."""

from __future__ import annotations

import copy

from port4_engine.core.port import Port
from port4_engine.scenarios.scenario import Scenario, ScenarioResult


class ScenarioEngine:
    def __init__(self, port: Port) -> None:
        self.port = port
        self._scenarios: dict[str, Scenario] = {}

    def clone_current_state(self, name: str = "scenario") -> Scenario:
        cloned_port = copy.deepcopy(self.port)
        scenario = Scenario(name=name, port=cloned_port)
        self._scenarios[name] = scenario
        return scenario

    def get(self, name: str) -> Scenario | None:
        return self._scenarios.get(name)

    def compare(self, baseline: ScenarioResult, scenario: ScenarioResult) -> dict[str, float]:
        delta = scenario.delta()
        delta["baseline_score"] = baseline.baseline_score
        delta["scenario_score"] = scenario.projected_score
        return delta

    def compare_many(self, results: dict[str, ScenarioResult]) -> dict[str, dict[str, float]]:
        return {name: result.delta() for name, result in results.items()}
