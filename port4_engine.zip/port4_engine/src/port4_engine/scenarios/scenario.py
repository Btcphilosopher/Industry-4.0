"""A single what-if Scenario (sections 29-30).

    scenario = engine.clone_current_state()
    scenario.container_volume *= 1.20
    scenario.disable_crane("CRANE_07")
    result = scenario.simulate(hours=72)

A scenario clones the *current* port state, then layers deterministic,
explainable impact factors onto it — cargo volume changes, equipment/
infrastructure failures or closures, price shocks, labour constraints —
and projects their quantitative effect on the standard KPI/PortScore set.
This mirrors the fast surrogate approach used by
:mod:`port4_engine.optimisation.port_optimizer`: a scenario's *headline*
result is available in milliseconds; where a decision is consequential,
follow up with a full discrete-event re-simulation for validation.
"""

from __future__ import annotations

import copy
from dataclasses import dataclass, field

from port4_engine.core.ids import EntityId
from port4_engine.core.port import Port
from port4_engine.optimisation.objective import PortScore, PortScoreInputs
from port4_engine.optimisation.port_optimizer import baseline_inputs_from_port
from port4_engine.statistics.kpi import KpiEngine, PortKpis


@dataclass
class ScenarioResult:
    scenario_name: str
    baseline_kpis: PortKpis
    projected_inputs: PortScoreInputs
    baseline_score: float
    projected_score: float

    def delta(self) -> dict[str, float]:
        b, p = self.baseline_kpis, self.projected_inputs
        return {
            "throughput_teu_per_day": p.throughput_teu_per_day - b.teu_per_day,
            "vessel_waiting_hours": p.vessel_waiting_hours - max(1.0, b.avg_vessel_turnaround_hours * 0.2),
            "truck_waiting_minutes": p.truck_waiting_minutes - max(1.0, b.avg_truck_turnaround_minutes),
            "container_dwell_hours": p.container_dwell_hours - max(1.0, b.avg_container_dwell_hours),
            "congestion_ratio": p.congestion_ratio - b.yard_utilisation,
            "port_score": self.projected_score - self.baseline_score,
        }


@dataclass
class Scenario:
    name: str
    port: Port
    container_volume_multiplier: float = 1.0
    disabled_crane_ids: set[EntityId] = field(default_factory=set)
    disabled_berth_ids: set[EntityId] = field(default_factory=set)
    new_berths: int = 0
    new_cranes: int = 0
    rail_closed: bool = False
    road_closure_factor: float = 0.0  # 0..1, 1 = fully closed
    weather_disruption_severity: float = 0.0  # 0..1
    fuel_price_multiplier: float = 1.0
    energy_price_multiplier: float = 1.0
    labour_constraint_factor: float = 0.0  # 0..1, fraction of labour capacity lost

    @property
    def container_volume(self) -> float:
        return self.container_volume_multiplier

    @container_volume.setter
    def container_volume(self, value: float) -> None:
        self.container_volume_multiplier = value

    def disable_crane(self, crane_id: EntityId) -> None:
        if crane_id in self.port.cranes:
            self.disabled_crane_ids.add(crane_id)

    def disable_berth(self, berth_id: EntityId) -> None:
        if berth_id in self.port.berths:
            self.disabled_berth_ids.add(berth_id)

    def add_berth(self, count: int = 1) -> None:
        self.new_berths += count

    def add_crane(self, count: int = 1) -> None:
        self.new_cranes += count

    def close_rail(self) -> None:
        self.rail_closed = True

    def close_road(self, severity: float = 1.0) -> None:
        self.road_closure_factor = max(0.0, min(1.0, severity))

    def apply_weather_disruption(self, severity: float) -> None:
        self.weather_disruption_severity = max(0.0, min(1.0, severity))

    def apply_fuel_price_increase(self, fraction: float) -> None:
        self.fuel_price_multiplier *= 1.0 + fraction

    def apply_energy_price_increase(self, fraction: float) -> None:
        self.energy_price_multiplier *= 1.0 + fraction

    def apply_labour_constraint(self, fraction_lost: float) -> None:
        self.labour_constraint_factor = max(0.0, min(1.0, fraction_lost))

    def simulate(self, hours: float = 72.0) -> ScenarioResult:
        baseline_kpis = KpiEngine(self.port, window_hours=hours).compute()
        baseline_inputs = baseline_inputs_from_port(self.port, window_hours=hours)

        n_cranes_total = max(1, len(self.port.cranes))
        active_crane_fraction = max(
            0.05,
            (n_cranes_total - len(self.disabled_crane_ids) + self.new_cranes) / n_cranes_total,
        )
        n_berths_total = max(1, len(self.port.berths))
        active_berth_fraction = max(
            0.05,
            (n_berths_total - len(self.disabled_berth_ids) + self.new_berths) / n_berths_total,
        )

        throughput = baseline_inputs.throughput_teu_per_day * self.container_volume_multiplier * active_crane_fraction * active_berth_fraction
        vessel_waiting = baseline_inputs.vessel_waiting_hours * (
            self.container_volume_multiplier / max(active_berth_fraction, 0.05)
        ) * (1.0 + self.weather_disruption_severity)
        truck_waiting = baseline_inputs.truck_waiting_minutes * (1.0 + self.road_closure_factor * 2.0) * (
            1.0 + self.labour_constraint_factor
        )
        rail_penalty = 1.6 if self.rail_closed else 1.0
        container_dwell = baseline_inputs.container_dwell_hours * self.container_volume_multiplier * rail_penalty / max(
            active_crane_fraction, 0.05
        )
        energy = baseline_inputs.energy_kwh * self.container_volume_multiplier * self.energy_price_multiplier / max(active_crane_fraction, 0.2)
        operating_cost = (
            baseline_inputs.operating_cost
            * self.container_volume_multiplier
            * self.fuel_price_multiplier
            * (1.0 + self.labour_constraint_factor * 0.5)
        )
        congestion = max(
            0.0,
            min(
                1.0,
                baseline_inputs.congestion_ratio
                * self.container_volume_multiplier
                * rail_penalty
                / max(active_crane_fraction * active_berth_fraction, 0.05),
            ),
        )
        quality = max(0.0, baseline_inputs.quality_score - self.weather_disruption_severity * 0.1 - self.labour_constraint_factor * 0.1)

        projected = PortScoreInputs(
            throughput_teu_per_day=max(0.0, throughput),
            vessel_waiting_hours=max(0.0, vessel_waiting),
            truck_waiting_minutes=max(0.0, truck_waiting),
            container_dwell_hours=max(0.0, container_dwell),
            energy_kwh=max(0.0, energy),
            operating_cost=max(0.0, operating_cost),
            congestion_ratio=congestion,
            quality_score=quality,
            throughput_reference=baseline_inputs.throughput_reference,
            vessel_waiting_reference_hours=baseline_inputs.vessel_waiting_reference_hours,
            truck_waiting_reference_minutes=baseline_inputs.truck_waiting_reference_minutes,
            container_dwell_reference_hours=baseline_inputs.container_dwell_reference_hours,
            energy_reference_kwh=baseline_inputs.energy_reference_kwh,
            operating_cost_reference=baseline_inputs.operating_cost_reference,
        )

        score_fn = PortScore()
        return ScenarioResult(
            scenario_name=self.name,
            baseline_kpis=baseline_kpis,
            projected_inputs=projected,
            baseline_score=score_fn.evaluate(baseline_inputs),
            projected_score=score_fn.evaluate(projected),
        )
