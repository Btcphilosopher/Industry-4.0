"""Monte Carlo scenario analysis (section 51).

    result = monte_carlo.run(scenario=scenario, iterations=10000)

Repeatedly perturbs a :class:`~port4_engine.scenarios.scenario.Scenario`'s
projected KPIs with realistic sampling noise (cargo volume, crane cycle
variability, weather, equipment reliability — see
:mod:`port4_engine.forecasting.uncertainty`) and summarises the resulting
distribution: probability of congestion, probability of delay, expected
and worst-case throughput, and the energy distribution.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from port4_engine.forecasting.uncertainty import UncertainEstimate
from port4_engine.scenarios.scenario import Scenario
from port4_engine.yards.congestion import CongestionLevel, classify


@dataclass
class MonteCarloResult:
    iterations: int
    probability_of_congestion: float
    probability_of_delay: float
    expected_throughput_teu_per_day: UncertainEstimate
    worst_case_throughput_teu_per_day: float
    energy_kwh: UncertainEstimate
    congestion_ratio: UncertainEstimate


class MonteCarloSimulator:
    def __init__(self, *, seed: int | None = 42) -> None:
        self.rng = np.random.default_rng(seed)

    def run(
        self,
        scenario: Scenario,
        *,
        iterations: int = 10_000,
        hours: float = 72.0,
        congestion_threshold: float = 0.85,
        delay_threshold_hours: float = 12.0,
        cargo_noise_std: float = 0.08,
        weather_disruption_probability: float = 0.10,
    ) -> MonteCarloResult:
        base_result = scenario.simulate(hours=hours)
        base = base_result.projected_inputs

        throughput_samples = np.empty(iterations)
        congestion_samples = np.empty(iterations)
        energy_samples = np.empty(iterations)
        vessel_waiting_samples = np.empty(iterations)

        for i in range(iterations):
            cargo_shock = max(0.4, self.rng.normal(1.0, cargo_noise_std))
            weather_hit = self.rng.random() < weather_disruption_probability
            weather_factor = 1.0 + (self.rng.exponential(0.3) if weather_hit else 0.0)

            throughput_samples[i] = base.throughput_teu_per_day * cargo_shock / weather_factor
            congestion_samples[i] = min(1.0, base.congestion_ratio * cargo_shock * weather_factor)
            energy_samples[i] = base.energy_kwh * cargo_shock
            vessel_waiting_samples[i] = base.vessel_waiting_hours * cargo_shock * weather_factor

        return MonteCarloResult(
            iterations=iterations,
            probability_of_congestion=float(np.mean(congestion_samples >= congestion_threshold)),
            probability_of_delay=float(np.mean(vessel_waiting_samples >= delay_threshold_hours)),
            expected_throughput_teu_per_day=UncertainEstimate.from_samples(throughput_samples),
            worst_case_throughput_teu_per_day=float(np.percentile(throughput_samples, 5)),
            energy_kwh=UncertainEstimate.from_samples(energy_samples),
            congestion_ratio=UncertainEstimate.from_samples(congestion_samples),
        )

    def congestion_level_distribution(self, result: MonteCarloResult, thresholds: dict[str, float] | None = None) -> dict[str, float]:
        """A coarse read-out of the Monte Carlo congestion distribution in
        terms of the same NORMAL/BUSY/CONGESTED/CRITICAL bands used
        elsewhere in the engine, for direct display alongside deterministic
        congestion reports."""
        est = result.congestion_ratio
        return {
            "p10_level": classify(est.p10, thresholds or {}).value,
            "p50_level": classify(est.p50, thresholds or {}).value,
            "p90_level": classify(est.p90, thresholds or {}).value,
        }
