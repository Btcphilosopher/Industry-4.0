"""The canonical PortEvent — everything in the engine is event-driven."""

from __future__ import annotations

from datetime import datetime, timezone
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field

from port4_engine.core.ids import new_id


class EventType(StrEnum):
    VESSEL_ARRIVED = "VesselArrived"
    VESSEL_ANCHORED = "VesselAnchored"
    VESSEL_BERTHED = "VesselBerthed"
    VESSEL_CARGO_COMPLETE = "VesselCargoComplete"
    VESSEL_DEPARTED = "VesselDeparted"

    CONTAINER_DISCHARGED = "ContainerDischarged"
    CONTAINER_LOADED = "ContainerLoaded"
    CONTAINER_STACKED = "ContainerStacked"
    CONTAINER_RETRIEVED = "ContainerRetrieved"
    CONTAINER_GATE_OUT = "ContainerGateOut"
    CONTAINER_LOADED_TO_TRAIN = "ContainerLoadedToTrain"

    TRUCK_ARRIVED = "TruckArrived"
    TRUCK_DEPARTED = "TruckDeparted"

    TRAIN_ARRIVED = "TrainArrived"
    TRAIN_DEPARTED = "TrainDeparted"

    CRANE_STARTED = "CraneStarted"
    CRANE_STOPPED = "CraneStopped"
    CRANE_FAULT = "CraneFault"

    YARD_CONGESTION = "YardCongestion"
    WEATHER_ALERT = "WeatherAlert"
    MAINTENANCE_REQUIRED = "MaintenanceRequired"

    SCHEDULE_PUBLISHED = "SchedulePublished"
    OPTIMISATION_COMPLETE = "OptimisationComplete"
    SCENARIO_COMPLETE = "ScenarioComplete"


class PortEvent(BaseModel):
    """A single timestamped, immutable event.

    ``event_time`` is simulation/wall-clock time the event occurred at;
    ``entity`` names the affected entity id; ``payload`` carries free-form,
    event-type-specific data. Every state transition anywhere in the engine
    (vessel, container, truck, train, crane, gate) should emit one of these.
    """

    id: str = Field(default_factory=lambda: new_id("EVT"))
    event_type: EventType
    event_time: datetime
    entity: str
    action: str = ""
    payload: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    def __lt__(self, other: "PortEvent") -> bool:
        # Enables use in heaps when tie-broken purely by event_time upstream.
        return self.event_time < other.event_time
