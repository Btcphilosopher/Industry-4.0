"""A minimal, synchronous publish/subscribe event bus.

Kept deliberately simple (no external broker) because the discrete-event
simulation engine is itself single-threaded and deterministic; every
subscriber runs synchronously in event_time order. The API layer's
WebSocket endpoints subscribe to this bus to stream updates outward, and
Kotlin DTO / Rust integration adapters subscribe to translate PortEvents
into their respective wire formats.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Callable

from port4_engine.events.event import EventType, PortEvent

Subscriber = Callable[[PortEvent], None]


class EventBus:
    def __init__(self) -> None:
        self._subscribers: dict[EventType | None, list[Subscriber]] = defaultdict(list)
        self.log: list[PortEvent] = []
        self._record_history = True

    def subscribe(self, event_type: EventType | None, handler: Subscriber) -> None:
        """Subscribe to one event type, or None to subscribe to everything."""
        self._subscribers[event_type].append(handler)

    def unsubscribe(self, event_type: EventType | None, handler: Subscriber) -> None:
        if handler in self._subscribers[event_type]:
            self._subscribers[event_type].remove(handler)

    def publish(self, event: PortEvent) -> None:
        if self._record_history:
            self.log.append(event)
        for handler in self._subscribers.get(event.event_type, []):
            handler(event)
        for handler in self._subscribers.get(None, []):
            handler(event)

    def events_for(self, entity: str) -> list[PortEvent]:
        return [e for e in self.log if e.entity == entity]

    def events_of_type(self, event_type: EventType) -> list[PortEvent]:
        return [e for e in self.log if e.event_type == event_type]

    def clear_history(self) -> None:
        self.log.clear()

    def set_record_history(self, enabled: bool) -> None:
        self._record_history = enabled
