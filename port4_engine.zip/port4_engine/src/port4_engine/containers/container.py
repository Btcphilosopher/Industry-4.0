"""The Container entity and its formal state machine (sections 13-14)."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import StrEnum
from typing import Any

from port4_engine.core.ids import EntityId, IdMixin, new_id
from port4_engine.core.state_machine import StateMachine


class IsoType(StrEnum):
    FT20 = "20FT"
    FT40 = "40FT"
    FT45 = "45FT"
    REEFER = "REEFER"
    TANK = "TANK"
    HAZARDOUS = "HAZARDOUS"
    OVERSIZED = "OVERSIZED"
    EMPTY = "EMPTY"


ISO_TEU: dict[IsoType, float] = {
    IsoType.FT20: 1.0,
    IsoType.FT40: 2.0,
    IsoType.FT45: 2.25,
    IsoType.REEFER: 2.0,
    IsoType.TANK: 1.0,
    IsoType.HAZARDOUS: 1.0,
    IsoType.OVERSIZED: 2.0,
    IsoType.EMPTY: 1.0,
}


class ContainerStatus(StrEnum):
    BOOKED = "BOOKED"
    ON_VESSEL = "ON_VESSEL"
    DISCHARGING = "DISCHARGING"
    ON_QUAY = "ON_QUAY"
    IN_TRANSIT = "IN_TRANSIT"
    YARD_ARRIVAL = "YARD_ARRIVAL"
    STACKED = "STACKED"
    AWAITING_TRUCK = "AWAITING_TRUCK"
    AWAITING_RAIL = "AWAITING_RAIL"
    RETRIEVAL = "RETRIEVAL"
    GATE_OUT = "GATE_OUT"
    LOADED_TO_TRAIN = "LOADED_TO_TRAIN"
    DEPARTED = "DEPARTED"


CONTAINER_TRANSITIONS: dict[ContainerStatus, set[ContainerStatus]] = {
    ContainerStatus.BOOKED: {ContainerStatus.ON_VESSEL},
    ContainerStatus.ON_VESSEL: {ContainerStatus.DISCHARGING},
    ContainerStatus.DISCHARGING: {ContainerStatus.ON_QUAY},
    ContainerStatus.ON_QUAY: {ContainerStatus.IN_TRANSIT},
    ContainerStatus.IN_TRANSIT: {ContainerStatus.YARD_ARRIVAL, ContainerStatus.ON_VESSEL},
    ContainerStatus.YARD_ARRIVAL: {ContainerStatus.STACKED},
    ContainerStatus.STACKED: {ContainerStatus.AWAITING_TRUCK, ContainerStatus.AWAITING_RAIL, ContainerStatus.RETRIEVAL},
    ContainerStatus.AWAITING_TRUCK: {ContainerStatus.RETRIEVAL},
    ContainerStatus.AWAITING_RAIL: {ContainerStatus.RETRIEVAL},
    ContainerStatus.RETRIEVAL: {ContainerStatus.GATE_OUT, ContainerStatus.LOADED_TO_TRAIN, ContainerStatus.IN_TRANSIT},
    ContainerStatus.GATE_OUT: {ContainerStatus.DEPARTED},
    ContainerStatus.LOADED_TO_TRAIN: {ContainerStatus.DEPARTED},
    ContainerStatus.DEPARTED: set(),
}


@dataclass
class Container(IdMixin):
    id_prefix = "CTR"

    container_id: str
    iso_type: IsoType
    length_ft: float
    height_ft: float
    weight_kg: float
    origin: str
    destination: str
    vessel: EntityId | None = None
    cargo_type: str = "general"
    hazardous: bool = False
    reefer: bool = False
    id: EntityId = field(default_factory=lambda: new_id("CTR"))
    status: ContainerStatus = ContainerStatus.BOOKED
    location: Any = None  # yard slot / gps position, set by yard/routing modules

    yard_arrival_time: datetime | None = None
    retrieval_time: datetime | None = None
    needed_by: datetime | None = None
    rehandle_count: int = 0

    _fsm: StateMachine[ContainerStatus] | None = field(default=None, repr=False)

    def __post_init__(self) -> None:
        self._fsm = StateMachine(entity_id=self.id, state=self.status, transitions=CONTAINER_TRANSITIONS)
        if self.iso_type in (IsoType.REEFER,):
            self.reefer = True
        if self.iso_type in (IsoType.HAZARDOUS,):
            self.hazardous = True

    @property
    def teu(self) -> float:
        return ISO_TEU[self.iso_type]

    def bind_event_listener(self, listener: Any) -> None:
        assert self._fsm is not None
        self._fsm.add_listener(listener)

    def transition(self, target: ContainerStatus, *, when: datetime | None = None) -> None:
        assert self._fsm is not None
        self._fsm.transition(target)
        self.status = target
        if target == ContainerStatus.YARD_ARRIVAL and when is not None:
            self.yard_arrival_time = when
        if target == ContainerStatus.RETRIEVAL and when is not None:
            self.retrieval_time = when

    def dwell_hours(self) -> float | None:
        if self.yard_arrival_time is None:
            return None
        end = self.retrieval_time or datetime.now(timezone.utc)
        return (end - self.yard_arrival_time).total_seconds() / 3600.0
