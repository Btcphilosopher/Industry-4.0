"""Container flow engine (section 15).

Drives a container through the import flow

    VESSEL -> CRANE -> QUAY -> YARD VEHICLE -> YARD -> TRUCK/RAIL -> EXIT

and the reverse export flow

    TRUCK -> GATE -> YARD -> CRANE -> VESSEL

Every transition both advances the container's own state machine and
publishes a :class:`~port4_engine.events.event.PortEvent` on the shared
:class:`~port4_engine.events.bus.EventBus`, so downstream consumers
(KPIs, bottleneck detection, the Kotlin digital twin) observe container
movement purely through events.
"""

from __future__ import annotations

from datetime import datetime

from port4_engine.containers.container import Container, ContainerStatus
from port4_engine.events.bus import EventBus
from port4_engine.events.event import EventType, PortEvent


class ContainerFlowEngine:
    def __init__(self, event_bus: EventBus) -> None:
        self.event_bus = event_bus

    def _emit(self, event_type: EventType, container: Container, when: datetime, **payload: object) -> None:
        self.event_bus.publish(
            PortEvent(event_type=event_type, event_time=when, entity=container.id, action=event_type.value, payload=payload)
        )

    # -- import flow -----------------------------------------------------
    def discharge(self, container: Container, when: datetime) -> None:
        container.transition(ContainerStatus.DISCHARGING, when=when)
        self._emit(EventType.CONTAINER_DISCHARGED, container, when)

    def move_to_quay(self, container: Container, when: datetime) -> None:
        container.transition(ContainerStatus.ON_QUAY, when=when)

    def move_to_yard(self, container: Container, when: datetime) -> None:
        container.transition(ContainerStatus.IN_TRANSIT, when=when)
        container.transition(ContainerStatus.YARD_ARRIVAL, when=when)

    def stack(self, container: Container, when: datetime, location: object) -> None:
        container.location = location
        container.transition(ContainerStatus.STACKED, when=when)
        self._emit(EventType.CONTAINER_STACKED, container, when, location=str(location))

    def request_retrieval(self, container: Container, when: datetime, *, via_rail: bool = False) -> None:
        container.transition(
            ContainerStatus.AWAITING_RAIL if via_rail else ContainerStatus.AWAITING_TRUCK, when=when
        )

    def retrieve(self, container: Container, when: datetime) -> None:
        container.transition(ContainerStatus.RETRIEVAL, when=when)
        self._emit(EventType.CONTAINER_RETRIEVED, container, when)

    def gate_out(self, container: Container, when: datetime) -> None:
        container.transition(ContainerStatus.GATE_OUT, when=when)
        self._emit(EventType.CONTAINER_GATE_OUT, container, when)
        container.transition(ContainerStatus.DEPARTED, when=when)

    def load_to_train(self, container: Container, when: datetime) -> None:
        container.transition(ContainerStatus.LOADED_TO_TRAIN, when=when)
        self._emit(EventType.CONTAINER_LOADED_TO_TRAIN, container, when)
        container.transition(ContainerStatus.DEPARTED, when=when)

    # -- export / reverse flow --------------------------------------------
    def truck_delivers_to_yard(self, container: Container, when: datetime, location: object) -> None:
        """Export flow: TRUCK -> GATE -> YARD."""
        container.transition(ContainerStatus.IN_TRANSIT, when=when)
        container.transition(ContainerStatus.YARD_ARRIVAL, when=when)
        self.stack(container, when, location)

    def load_to_vessel(self, container: Container, when: datetime, vessel_id: str) -> None:
        """Export flow: YARD -> CRANE -> VESSEL."""
        container.transition(ContainerStatus.RETRIEVAL, when=when)
        container.vessel = vessel_id
        container.transition(ContainerStatus.IN_TRANSIT, when=when)
        container.transition(ContainerStatus.ON_VESSEL, when=when)
        self._emit(EventType.CONTAINER_LOADED, container, when, vessel_id=vessel_id)
