"""PortHealth — a single explainable health score (section 48)."""

from __future__ import annotations

from dataclasses import dataclass

from port4_engine.core.port import Port
from port4_engine.statistics.kpi import KpiEngine, PortKpis


@dataclass
class PortHealth:
    operational_health: float
    capacity_health: float
    congestion_health: float
    equipment_health: float
    energy_health: float
    financial_health: float
    kpis: PortKpis

    @property
    def score(self) -> float:
        components = [
            self.operational_health,
            self.capacity_health,
            self.congestion_health,
            self.equipment_health,
            self.energy_health,
            self.financial_health,
        ]
        return sum(components) / len(components)

    def as_dict(self) -> dict[str, float]:
        return {
            "score": self.score,
            "operational_health": self.operational_health,
            "capacity_health": self.capacity_health,
            "congestion_health": self.congestion_health,
            "equipment_health": self.equipment_health,
            "energy_health": self.energy_health,
            "financial_health": self.financial_health,
        }


def _clamp(x: float) -> float:
    return max(0.0, min(1.0, x))


def compute_port_health(port: Port) -> PortHealth:
    kpis = KpiEngine(port).compute()

    operational_health = _clamp(1.0 - kpis.avg_vessel_turnaround_hours / 48.0)
    capacity_health = _clamp(1.0 - max(0.0, kpis.yard_utilisation - 0.85) / 0.15)
    congestion_health = _clamp(1.0 - kpis.avg_queue_time_minutes / 60.0)

    equipment = list(port.cranes.values()) + list(port.trucks.values())
    health_scores = [getattr(e, "health_score", lambda: 1.0)() for e in equipment]
    equipment_health = sum(health_scores) / len(health_scores) if health_scores else 1.0

    energy_assets = list(port.energy_assets.values())
    energy_health = _clamp(
        sum(getattr(a, "efficiency", 1.0) for a in energy_assets) / len(energy_assets)
    ) if energy_assets else 0.85

    financial_health = _clamp(0.5 + (kpis.teu_per_day - 0) / (2 * max(1.0, kpis.teu_per_day + 1)))

    return PortHealth(
        operational_health=operational_health,
        capacity_health=capacity_health,
        congestion_health=congestion_health,
        equipment_health=equipment_health,
        energy_health=energy_health,
        financial_health=financial_health,
        kpis=kpis,
    )
