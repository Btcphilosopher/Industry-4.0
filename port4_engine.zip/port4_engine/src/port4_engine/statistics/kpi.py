"""Port KPI engine (section 45).

Computes the standard port operations KPI set from the current state of a
:class:`~port4_engine.core.port.Port`. The same engine is reused to report
*current*, *forecast* and *scenario* KPIs — callers simply pass whichever
``Port`` snapshot they want measured.
"""

from __future__ import annotations

from dataclasses import dataclass
from statistics import mean

from port4_engine.core.port import Port


@dataclass
class PortKpis:
    teu_per_hour: float
    teu_per_day: float
    avg_vessel_turnaround_hours: float
    berth_utilisation: float
    crane_utilisation: float
    yard_utilisation: float
    avg_truck_turnaround_minutes: float
    rail_throughput_containers_per_day: float
    avg_container_dwell_hours: float
    gate_throughput_trucks_per_hour: float
    avg_queue_time_minutes: float

    def as_dict(self) -> dict[str, float]:
        return {
            "teu_per_hour": self.teu_per_hour,
            "teu_per_day": self.teu_per_day,
            "avg_vessel_turnaround_hours": self.avg_vessel_turnaround_hours,
            "berth_utilisation": self.berth_utilisation,
            "crane_utilisation": self.crane_utilisation,
            "yard_utilisation": self.yard_utilisation,
            "avg_truck_turnaround_minutes": self.avg_truck_turnaround_minutes,
            "rail_throughput_containers_per_day": self.rail_throughput_containers_per_day,
            "avg_container_dwell_hours": self.avg_container_dwell_hours,
            "gate_throughput_trucks_per_hour": self.gate_throughput_trucks_per_hour,
            "avg_queue_time_minutes": self.avg_queue_time_minutes,
        }


class KpiEngine:
    def __init__(self, port: Port, *, window_hours: float = 24.0) -> None:
        self.port = port
        self.window_hours = window_hours

    def compute(self) -> PortKpis:
        p = self.port

        moved_teu = sum(
            getattr(c, "teu", 1.0)
            for c in p.containers.values()
            if getattr(c, "status", None) in {"GATE_OUT", "DEPARTED", "LOADED_TO_TRAIN"}
        )
        teu_per_hour = moved_teu / self.window_hours if self.window_hours else 0.0

        turnarounds = [
            v.turnaround_hours()
            for v in p.vessels.values()
            if hasattr(v, "turnaround_hours") and v.turnaround_hours() is not None
        ]

        berths = list(p.berths.values())
        berth_util = (
            sum(1 for b in berths if getattr(b, "occupied", False)) / len(berths) if berths else 0.0
        )

        cranes = list(p.cranes.values())
        crane_util = (
            sum(1 for c in cranes if getattr(c, "status", "") == "WORKING") / len(cranes)
            if cranes
            else 0.0
        )

        yards = list(p.yards.values())
        yard_util = mean((y.utilisation() for y in yards)) if yards else 0.0

        trucks = list(p.trucks.values())
        truck_turnarounds = [
            t.turnaround_minutes() for t in trucks if hasattr(t, "turnaround_minutes") and t.turnaround_minutes() is not None
        ]

        containers_departed_rail = sum(
            1 for c in p.containers.values() if getattr(c, "status", None) == "LOADED_TO_TRAIN"
        )

        dwell_times = [
            c.dwell_hours() for c in p.containers.values() if hasattr(c, "dwell_hours") and c.dwell_hours() is not None
        ]

        gates = list(p.gates.values())
        gate_throughput = sum(getattr(g, "throughput_per_hour", 0.0) for g in gates)
        queue_times = [getattr(g, "avg_queue_minutes", 0.0) for g in gates]

        return PortKpis(
            teu_per_hour=teu_per_hour,
            teu_per_day=teu_per_hour * 24,
            avg_vessel_turnaround_hours=mean(turnarounds) if turnarounds else 0.0,
            berth_utilisation=berth_util,
            crane_utilisation=crane_util,
            yard_utilisation=yard_util,
            avg_truck_turnaround_minutes=mean(truck_turnarounds) if truck_turnarounds else 0.0,
            rail_throughput_containers_per_day=containers_departed_rail
            * (24.0 / self.window_hours if self.window_hours else 0.0),
            avg_container_dwell_hours=mean(dwell_times) if dwell_times else 0.0,
            gate_throughput_trucks_per_hour=gate_throughput,
            avg_queue_time_minutes=mean(queue_times) if queue_times else 0.0,
        )
