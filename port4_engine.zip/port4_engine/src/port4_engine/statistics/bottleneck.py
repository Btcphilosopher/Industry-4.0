"""Bottleneck detection and causal-chain explanation (sections 46-47).

Ranks congestion/utilisation across every subsystem and, where a plausible
causal chain can be inferred from current state (arrivals -> discharge rate
-> yard inflow -> capacity -> truck shortage -> dwell -> congestion), states
it explicitly rather than reporting a bare utilisation number.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from port4_engine.core.port import Port


@dataclass
class Bottleneck:
    subsystem: str
    identifier: str
    utilisation: float
    severity: str
    causal_chain: list[str] = field(default_factory=list)

    def explain(self) -> str:
        chain = " -> ".join(self.causal_chain) if self.causal_chain else "no causal chain inferred"
        return f"{self.subsystem} {self.identifier} at {self.utilisation:.0%} ({self.severity}): {chain}"


def _severity(utilisation: float, thresholds: dict[str, float]) -> str:
    if utilisation >= thresholds.get("congested", 0.95):
        return "CRITICAL"
    if utilisation >= thresholds.get("busy", 0.85):
        return "CONGESTED"
    if utilisation >= thresholds.get("normal", 0.70):
        return "BUSY"
    return "NORMAL"


class BottleneckDetector:
    def __init__(self, port: Port, thresholds: dict[str, float] | None = None) -> None:
        self.port = port
        self.thresholds = thresholds or {"normal": 0.70, "busy": 0.85, "congested": 0.95}

    def detect(self) -> list[Bottleneck]:
        p = self.port
        findings: list[Bottleneck] = []

        for yard_id, yard in p.yards.items():
            util = yard.utilisation()
            findings.append(
                Bottleneck(
                    subsystem="yard",
                    identifier=yard_id,
                    utilisation=util,
                    severity=_severity(util, self.thresholds),
                    causal_chain=self._yard_causal_chain(yard_id, util),
                )
            )

        for gate_id, gate in p.gates.items():
            util = min(1.0, getattr(gate, "queue_length", 0) / max(1, getattr(gate, "capacity", 1)))
            findings.append(
                Bottleneck(
                    subsystem="gate",
                    identifier=gate_id,
                    utilisation=util,
                    severity=_severity(util, self.thresholds),
                )
            )

        berths = list(p.berths.values())
        if berths:
            util = sum(1 for b in berths if getattr(b, "occupied", False)) / len(berths)
            findings.append(
                Bottleneck(
                    subsystem="berth",
                    identifier="ALL_BERTHS",
                    utilisation=util,
                    severity=_severity(util, self.thresholds),
                )
            )

        cranes = list(p.cranes.values())
        if cranes:
            util = sum(1 for c in cranes if getattr(c, "status", "") == "WORKING") / len(cranes)
            findings.append(
                Bottleneck(
                    subsystem="crane",
                    identifier="ALL_CRANES",
                    utilisation=util,
                    severity=_severity(util, self.thresholds),
                )
            )

        for rn_id, road in (p.roads.edges.items() if p.roads and hasattr(p.roads, "edges") else {}):
            util = getattr(road, "congestion_factor", 0.0)
            findings.append(
                Bottleneck(subsystem="road", identifier=rn_id, utilisation=util, severity=_severity(util, self.thresholds))
            )

        for wh_id, wh in p.warehouses.items():
            util = getattr(wh, "occupancy_ratio", lambda: 0.0)()
            findings.append(
                Bottleneck(subsystem="warehouse", identifier=wh_id, utilisation=util, severity=_severity(util, self.thresholds))
            )

        findings.sort(key=lambda b: b.utilisation, reverse=True)
        return findings

    def _yard_causal_chain(self, yard_id: str, util: float) -> list[str]:
        p = self.port
        chain: list[str] = []
        recent_arrivals = sum(
            1 for v in p.vessels.values() if getattr(v, "status", "") in {"BERThed", "UNLOADING"}
        )
        if recent_arrivals:
            chain.append(f"{recent_arrivals} vessels discharging")
        n_trucks_idle = sum(1 for t in p.trucks.values() if getattr(t, "status", "") == "IDLE")
        n_trucks = len(p.trucks) or 1
        if n_trucks_idle / n_trucks < 0.15 and util > self.thresholds.get("busy", 0.85):
            chain.append("truck availability low relative to demand")
        if util > self.thresholds.get("busy", 0.85):
            chain.append(f"yard {yard_id} inflow exceeding outflow")
            chain.append("rising container dwell time")
            chain.append("yard congestion")
        return chain
