"""Port4.Engine — the Python intelligence and simulation engine for PORT 4.0.

Port4.Engine is the middle tier of the PORT 4.0 stack:

    Kotlin  (digital twin, animation, dashboard, geospatial visualisation)
        |
    Rust    (high-performance port core, telemetry, events, spatial indexing)
        |
    Python  (this package: simulation, optimisation, forecasting, AI)
        |
    PostgreSQL / PostGIS (authoritative port data)

Python never bypasses safety-critical control. It observes state, builds
models, runs simulations, optimises operations, forecasts the future, and
produces *plans, predictions, recommendations, optimised schedules and
scenario results*. Rust and other authorised operational systems remain
responsible for executing real-world actions.

The control loop this package is built around:

    OBSERVE -> MODEL -> SIMULATE -> OPTIMISE -> VALIDATE -> RECOMMEND -> EXECUTE -> OBSERVE AGAIN
"""

from __future__ import annotations

__version__ = "0.1.0"
__engine_name__ = "Port4.Engine"

from port4_engine.core.port import Port

__all__ = ["Port", "__version__", "__engine_name__"]
