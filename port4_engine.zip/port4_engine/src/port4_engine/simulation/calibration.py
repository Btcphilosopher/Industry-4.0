"""Digital-twin calibration and validation (sections 57-58).

    calibrator.fit(historical_data, simulation_model)

Calibrates simulation parameters (crane productivity, truck travel time,
gate processing, berth turnaround, yard retrieval) to minimise
simulation-vs-real-world error, and reports the accuracy metrics (MAE,
RMSE, MAPE, throughput error, turnaround error) rather than assuming the
digital twin is automatically accurate.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

import numpy as np
from scipy.optimize import minimize


@dataclass
class ValidationMetrics:
    mae: float
    rmse: float
    mape: float

    @classmethod
    def compute(cls, actual: np.ndarray, predicted: np.ndarray) -> "ValidationMetrics":
        actual, predicted = np.asarray(actual, dtype=float), np.asarray(predicted, dtype=float)
        errors = predicted - actual
        mae = float(np.mean(np.abs(errors)))
        rmse = float(np.sqrt(np.mean(errors**2)))
        nonzero = actual != 0
        mape = float(np.mean(np.abs(errors[nonzero] / actual[nonzero])) * 100) if np.any(nonzero) else float("nan")
        return cls(mae=mae, rmse=rmse, mape=mape)


@dataclass
class CalibrationResult:
    calibrated_parameters: dict[str, float]
    validation: ValidationMetrics
    initial_validation: ValidationMetrics


class Calibrator:
    """Fits a small set of named simulation parameters (e.g.
    ``crane_moves_per_hour``, ``truck_travel_time_multiplier``,
    ``gate_processing_minutes``, ``berth_turnaround_hours``,
    ``yard_retrieval_minutes``) against historical throughput/turnaround
    observations, by minimising validation error between the simulator's
    output (via ``simulation_model``) and reality.
    """

    def fit(
        self,
        historical_data: np.ndarray,
        simulation_model: Callable[[dict[str, float]], np.ndarray],
        *,
        initial_parameters: dict[str, float],
        parameter_bounds: dict[str, tuple[float, float]] | None = None,
    ) -> CalibrationResult:
        param_names = list(initial_parameters.keys())
        x0 = np.array([initial_parameters[name] for name in param_names])
        bounds = [parameter_bounds.get(name, (None, None)) for name in param_names] if parameter_bounds else None

        initial_prediction = simulation_model(initial_parameters)
        initial_validation = ValidationMetrics.compute(historical_data, initial_prediction)

        def objective(x: np.ndarray) -> float:
            params = dict(zip(param_names, x))
            prediction = simulation_model(params)
            return float(np.mean((np.asarray(prediction) - np.asarray(historical_data)) ** 2))

        result = minimize(objective, x0, method="Nelder-Mead", bounds=bounds)
        calibrated = dict(zip(param_names, result.x.tolist()))

        final_prediction = simulation_model(calibrated)
        final_validation = ValidationMetrics.compute(historical_data, final_prediction)

        return CalibrationResult(
            calibrated_parameters=calibrated, validation=final_validation, initial_validation=initial_validation
        )
