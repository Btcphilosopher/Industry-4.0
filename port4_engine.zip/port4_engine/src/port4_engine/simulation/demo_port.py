"""The PORT 4.0 demonstration port (sections 61-62).

Builds a complete synthetic port authority — 4 berths, 8 STS cranes, 20
yard blocks (pre-populated with 1000+ containers), 50 trucks, 2 rail
terminals, warehouses, multiple gates and an internal road network — and
wires it to the discrete-event :class:`SimulationEngine` so that vessel
arrivals, container flows, truck arrivals, rail schedules, crane
operations and yard movements all run as one coherent simulation over a
configurable horizon (24 hours, 7 days, 30 days, ...).

Run directly with ``port4-demo`` (see ``pyproject.toml``) or::

    python -m port4_engine.simulation.demo_port --hours 24
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

import numpy as np

from port4_engine.berths.berth import Berth
from port4_engine.berths.optimizer import BerthOptimizer
from port4_engine.core.ids import reset_counters
from port4_engine.core.port import Port
from port4_engine.cranes.allocator import CraneAllocator
from port4_engine.cranes.crane import Crane, CraneStatus, CraneType
from port4_engine.containers.container import Container, ContainerStatus, IsoType
from port4_engine.containers.flow import ContainerFlowEngine
from port4_engine.gates.gate import Gate
from port4_engine.models.geometry import Point
from port4_engine.rail.rail import RailNetwork, RailTerminal, RailWagon, Train
from port4_engine.routing.graph import PortRoadGraph, RoadEdge
from port4_engine.simulation.engine import SimulationEngine
from port4_engine.trucks.truck import Truck, TruckStatus
from port4_engine.vessels.arrivals import ArrivalGenerator
from port4_engine.vessels.vessel import Vessel, VesselStatus
from port4_engine.warehouses.warehouse import Warehouse
from port4_engine.yards.optimizer import YardPlacementOptimizer
from port4_engine.yards.yard import Block, Yard, YardArea

N_BERTHS = 4
N_STS_CRANES = 8
N_YARD_BLOCKS = 20
N_PRELOADED_CONTAINERS = 1000
N_TRUCKS = 50
N_RAIL_TERMINALS = 2
N_WAREHOUSES = 3
N_GATES = 3


@dataclass
class DemoPortBundle:
    port: Port
    engine: SimulationEngine
    road_graph: PortRoadGraph
    flow: ContainerFlowEngine
    berth_optimizer: BerthOptimizer
    crane_allocator: CraneAllocator
    yard_optimizer: YardPlacementOptimizer
    arrival_generator: ArrivalGenerator


def _build_yard(rng: np.random.Generator, deterministic: bool) -> Yard:
    yard = Yard(name="MAIN_YARD", id=Yard.generate_id(deterministic))
    area_cycle = (
        [YardArea.IMPORT] * 10
        + [YardArea.EXPORT] * 5
        + [YardArea.EMPTY] * 2
        + [YardArea.REEFER] * 2
        + [YardArea.HAZARDOUS] * 1
    )
    for i in range(N_YARD_BLOCKS):
        area = area_cycle[i % len(area_cycle)]
        block = Block(
            name=f"BLK{i + 1:02d}",
            area=area,
            bays_count=10,
            rows=6,
            max_tier=5,
            id=Block.generate_id(deterministic),
        )
        yard.add_block(block)
    return yard


def _preload_containers(port: Port, yard: Yard, rng: np.random.Generator, count: int, deterministic: bool) -> None:
    iso_choices = [IsoType.FT20, IsoType.FT40, IsoType.FT45, IsoType.REEFER, IsoType.EMPTY]
    iso_weights = [0.35, 0.40, 0.05, 0.10, 0.10]
    for _ in range(count):
        iso = rng.choice(iso_choices, p=iso_weights)
        area = YardArea.REEFER if iso == IsoType.REEFER else YardArea.IMPORT
        container = Container(
            container_id=f"PORT4U{rng.integers(1_000_000, 9_999_999)}",
            iso_type=IsoType(iso),
            length_ft=20.0 if iso == IsoType.FT20 else 40.0,
            height_ft=8.5,
            weight_kg=float(rng.uniform(2000, 24000)),
            origin="ORIGIN",
            destination="DESTINATION",
            id=Container.generate_id(deterministic),
        )
        container.transition(ContainerStatus.ON_VESSEL)
        container.transition(ContainerStatus.DISCHARGING)
        container.transition(ContainerStatus.ON_QUAY)
        container.transition(ContainerStatus.IN_TRANSIT)
        container.transition(ContainerStatus.YARD_ARRIVAL)
        slot = yard.place_container(container.id, area=area)
        if slot is not None:
            container.transition(ContainerStatus.STACKED)
            container.location = slot.coordinate
        port.register("containers", container)


def _build_road_graph() -> PortRoadGraph:
    g = PortRoadGraph()
    nodes = ["GATE1", "GATE2", "GATE3", "BERTH_AREA", "MAIN_YARD", "RAILTERM1", "RAILTERM2", "WH1", "WH2", "WH3"]
    for n in nodes:
        g.add_node(n)
    edges = [
        ("GATE1", "MAIN_YARD", 800),
        ("GATE2", "MAIN_YARD", 900),
        ("GATE3", "MAIN_YARD", 750),
        ("MAIN_YARD", "BERTH_AREA", 600),
        ("MAIN_YARD", "RAILTERM1", 500),
        ("MAIN_YARD", "RAILTERM2", 550),
        ("MAIN_YARD", "WH1", 400),
        ("MAIN_YARD", "WH2", 420),
        ("MAIN_YARD", "WH3", 440),
    ]
    for u, v, length in edges:
        g.add_edge(RoadEdge(from_node=u, to_node=v, length_m=length, speed_limit_kmh=25, lanes=2))
    return g


def build_demo_port(
    *, random_seed: int = 42, start_time: datetime | None = None, deterministic_ids: bool = True
) -> DemoPortBundle:
    if deterministic_ids:
        reset_counters()
    rng = np.random.default_rng(random_seed)
    start_time = start_time or datetime(2026, 1, 1, tzinfo=timezone.utc)

    port = Port(port_authority="Port4.Demo Authority", port_id="demo_port", name="Port4.Engine Demonstration Port")

    # -- berths & cranes -----------------------------------------------------
    berth_lengths = [280.0, 320.0, 260.0, 340.0]
    for i, length in enumerate(berth_lengths):
        berth = Berth(
            length_m=length,
            depth_m=16.0,
            maximum_draft_m=15.0,
            terminal_id="TERMINAL_1",
            available_from=start_time,
            id=Berth.generate_id(deterministic_ids),
        )
        port.register("berths", berth)

    for i in range(N_STS_CRANES):
        crane = Crane(
            crane_type=CraneType.STS,
            position=Point(lon=0.0, lat=0.0),
            capacity_tonnes=65.0,
            max_reach_m=60.0,
            speed_m_per_s=1.2,
            energy_rate_kw=65.0,
            id=Crane.generate_id(deterministic_ids),
        )
        port.register("cranes", crane)

    # -- yard -----------------------------------------------------------------
    yard = _build_yard(rng, deterministic_ids)
    port.register("yards", yard)
    _preload_containers(port, yard, rng, N_PRELOADED_CONTAINERS, deterministic_ids)

    # -- trucks -----------------------------------------------------------------
    for _ in range(N_TRUCKS):
        truck = Truck(capacity_teu=2.0, position="GATE1", status=TruckStatus.IDLE, id=Truck.generate_id(deterministic_ids))
        port.register("trucks", truck)

    # -- rail -----------------------------------------------------------------
    rail_network = RailNetwork(id=RailNetwork.generate_id(deterministic_ids))
    for i in range(N_RAIL_TERMINALS):
        terminal = RailTerminal(
            name=f"RAILTERM{i + 1}", platforms=3, loading_tracks=2, id=RailTerminal.generate_id(deterministic_ids)
        )
        rail_network.add_terminal(terminal)
    port.rail_network = rail_network

    # -- warehouses -----------------------------------------------------------------
    for i in range(N_WAREHOUSES):
        wh = Warehouse(
            name=f"WH{i + 1}",
            capacity_m3=20_000.0,
            loading_bays=4,
            unloading_bays=4,
            processing_rate_units_per_hour=120.0,
            id=Warehouse.generate_id(deterministic_ids),
        )
        port.register("warehouses", wh)

    # -- gates -----------------------------------------------------------------
    for i in range(N_GATES):
        gate = Gate(name=f"GATE{i + 1}", lanes=4, mean_processing_minutes=3.5, id=Gate.generate_id(deterministic_ids))
        port.register("gates", gate)

    port.roads = _build_road_graph()

    engine = SimulationEngine(port, start_time=start_time, random_seed=random_seed)
    flow = ContainerFlowEngine(port.events)
    berth_optimizer = BerthOptimizer(safety_margin_m=10.0)
    crane_allocator = CraneAllocator()
    yard_optimizer = YardPlacementOptimizer()
    arrival_generator = ArrivalGenerator(rng, mean_teu=2200.0)

    return DemoPortBundle(
        port=port,
        engine=engine,
        road_graph=port.roads,
        flow=flow,
        berth_optimizer=berth_optimizer,
        crane_allocator=crane_allocator,
        yard_optimizer=yard_optimizer,
        arrival_generator=arrival_generator,
    )


def seed_vessel_arrivals(bundle: DemoPortBundle, *, horizon_hours: float, arrivals_per_day: float = 3.0) -> list[Vessel]:
    """Generate vessels, plan berth assignments, and schedule discrete events
    for the whole horizon (berthing, cargo handling, departure)."""
    port, engine = bundle.port, bundle.engine
    arrival_times = bundle.arrival_generator.poisson_arrival_times(
        engine.start_time, horizon_hours, arrivals_per_day, seasonality={h: 1.3 if 6 <= h <= 18 else 0.7 for h in range(24)}
    )

    vessels: list[Vessel] = []
    for i, eta in enumerate(arrival_times):
        length = float(bundle.arrival_generator.rng.uniform(180, 330))
        plan = bundle.arrival_generator.build_arrival_plan(f"V{i}", eta, vessel_length_m=length)
        vessel = Vessel(
            imo=f"IMO{9000000 + i}",
            name=f"MV DEMO {i + 1}",
            length_m=length,
            beam_m=length / 7.0,
            draft_m=min(15.0, 8.0 + length / 40.0),
            capacity_teu=plan.cargo_teu * 1.4,
            current_teu=plan.cargo_teu,
            eta=plan.eta_p50,
            priority=int(bundle.arrival_generator.rng.integers(0, 3)),
            id=Vessel.generate_id(True),
        )
        vessel.expected_turnaround_hours = plan.turnaround_hours_estimate  # type: ignore[attr-defined]
        vessel.bind_event_listener(_make_vessel_listener(port))
        vessels.append(vessel)
        port.register("vessels", vessel)

    berths = list(port.berths.values())
    schedule = bundle.berth_optimizer.optimize(vessels, berths, horizon_hours=horizon_hours, reference_time=engine.start_time)

    vessels_by_id = {v.id: v for v in vessels}
    for assignment in schedule.assignments:
        vessel = vessels_by_id[assignment.vessel_id]

        def make_berth_event(v: Vessel = vessel, a=assignment) -> None:
            v.transition(VesselStatus.APPROACHING)
            v.transition(VesselStatus.BERTH_WAIT)
            v.transition(VesselStatus.BERTHING)
            v.transition(VesselStatus.BERTHED)
            v.assigned_berth = a.berth_id
            port.berths[a.berth_id].assign(v.id)
            v.arrival_time = a.start
            _handle_cargo_operations(bundle, v, a.berth_id, when=a.start)

        engine.schedule_at(max(engine.clock, assignment.start), make_berth_event, label=f"berth:{vessel.id}")

        def make_departure_event(v: Vessel = vessel, a=assignment) -> None:
            v.transition(VesselStatus.DEPARTING)
            v.transition(VesselStatus.DEPARTED)
            if v.assigned_berth:
                port.berths[v.assigned_berth].release()
            v.departure_time = a.end

        engine.schedule_at(max(engine.clock, assignment.end), make_departure_event, label=f"depart:{vessel.id}")

    return vessels


def _make_vessel_listener(port: Port):
    from port4_engine.events.event import EventType, PortEvent

    status_to_event = {
        VesselStatus.BERTHED: EventType.VESSEL_BERTHED,
        VesselStatus.CARGO_COMPLETE: EventType.VESSEL_CARGO_COMPLETE,
        VesselStatus.DEPARTED: EventType.VESSEL_DEPARTED,
    }

    def listener(entity_id: str, old, new) -> None:
        event_type = status_to_event.get(new)
        if event_type:
            port.events.publish(
                PortEvent(event_type=event_type, event_time=datetime.now(timezone.utc), entity=entity_id, action=str(new))
            )

    return listener


def _handle_cargo_operations(bundle: DemoPortBundle, vessel: Vessel, berth_id: str, *, when: datetime) -> None:
    """Discharge a bounded, representative sample of the vessel's cargo into
    the yard (bounding container-object creation keeps multi-week runs fast
    while still exercising the full container flow and yard placement
    logic for every vessel call)."""
    port = bundle.port
    yard = next(iter(port.yards.values()))
    cranes = [c for c in port.cranes.values() if c.status == CraneStatus.IDLE][:4]
    allocation = bundle.crane_allocator.allocate(vessel, cranes, now=when)

    n_containers = max(1, min(80, int(vessel.remaining_cargo_teu() / 20)))
    rng = bundle.arrival_generator.rng
    for _ in range(n_containers):
        iso = IsoType(rng.choice([IsoType.FT20, IsoType.FT40, IsoType.REEFER], p=[0.4, 0.5, 0.1]))
        container = Container(
            container_id=f"PORT4U{rng.integers(1_000_000, 9_999_999)}",
            iso_type=iso,
            length_ft=20.0 if iso == IsoType.FT20 else 40.0,
            height_ft=8.5,
            weight_kg=float(rng.uniform(2000, 24000)),
            origin=vessel.origin or "ORIGIN",
            destination=vessel.destination or "DESTINATION",
            vessel=vessel.id,
            id=Container.generate_id(True),
        )
        container.transition(ContainerStatus.ON_VESSEL)
        bundle.flow.discharge(container, when)
        bundle.flow.move_to_quay(container, when)
        bundle.flow.move_to_yard(container, when)
        decision = bundle.yard_optimizer.place(yard, container, now=when)
        if decision.slot is not None:
            bundle.flow.stack(container, when, decision.slot.coordinate)
        port.register("containers", container)

    for crane in cranes:
        crane.complete_task()
    vessel.transition(VesselStatus.UNLOADING)
    vessel.transition(VesselStatus.CARGO_COMPLETE)
    vessel.current_teu = max(0.0, vessel.current_teu - n_containers * 1.7)


def seed_truck_and_rail_activity(bundle: DemoPortBundle, *, horizon_hours: float, trucks_per_day: float = 200.0) -> None:
    """Poisson-generate gate/truck retrieval activity and periodic rail
    departures against the currently stacked container population."""
    port, engine = bundle.port, bundle.engine
    rng = bundle.arrival_generator.rng
    arrival_times = bundle.arrival_generator.poisson_arrival_times(engine.start_time, horizon_hours, trucks_per_day)
    gates = list(port.gates.values())
    idle_trucks = [t for t in port.trucks.values() if t.status == TruckStatus.IDLE]

    for i, when in enumerate(arrival_times):
        def truck_event(t_index: int = i, arrival: datetime = when) -> None:
            _process_truck_gate_pickup(bundle, arrival)

        engine.schedule_at(when, truck_event, label="truck_pickup")

    # rail departures roughly every 8 hours per terminal
    t = 4.0
    terminal_ids = list(port.rail_network.terminals.keys()) if port.rail_network else []
    train_idx = 0
    while t < horizon_hours and terminal_ids:
        for terminal_id in terminal_ids:
            when = engine.start_time + timedelta(hours=t)

            def rail_event(term_id: str = terminal_id, arrival: datetime = when, idx: int = train_idx) -> None:
                _process_rail_departure(bundle, term_id, arrival, idx)

            engine.schedule_at(when, rail_event, label="rail_departure")
            train_idx += 1
        t += 8.0


def _process_truck_gate_pickup(bundle: DemoPortBundle, when: datetime) -> None:
    port = bundle.port
    gates = list(port.gates.values())
    if not gates:
        return
    gate = min(gates, key=lambda g: g.queue_length)
    idle_trucks = [t for t in port.trucks.values() if t.status == TruckStatus.IDLE]
    if not idle_trucks:
        return
    truck = idle_trucks[0]
    gate.enqueue(truck.id)
    truck.status = TruckStatus.GATE_QUEUE

    yard = next(iter(port.yards.values()))
    stacked = [c for c in port.containers.values() if c.status.value == "STACKED"]
    if not stacked:
        gate.serve_next(wait_minutes=gate.mean_processing_minutes)
        truck.status = TruckStatus.IDLE
        return

    container = stacked[0]
    gate.serve_next(wait_minutes=gate.mean_processing_minutes)
    truck.status = TruckStatus.LOADING
    truck.arrival_time = when

    block_name, bay, row, tier = container.location
    slot = yard.get_location(block_name, bay, row, tier)
    yard.remove_container(slot)

    bundle.flow.request_retrieval(container, when)
    bundle.flow.retrieve(container, when)
    truck.load(container.id)
    bundle.flow.gate_out(container, when)
    truck.departure_time = when + timedelta(minutes=15)
    truck.status = TruckStatus.IDLE
    truck.container = None


def _process_rail_departure(bundle: DemoPortBundle, terminal_id: str, when: datetime, idx: int) -> None:
    port = bundle.port
    yard = next(iter(port.yards.values()))
    rail_network = port.rail_network
    if rail_network is None:
        return
    wagons = [RailWagon(capacity_teu=2.0, id=RailWagon.generate_id(True)) for _ in range(20)]
    train = Train(wagons=wagons, id=Train.generate_id(True), scheduled_arrival=when)
    rail_network.schedule_train(train)
    if not rail_network.arrive(train.id, terminal_id, when):
        return
    port.trains[train.id] = train

    stacked = [c for c in port.containers.values() if c.status.value == "STACKED"][:40]
    for container in stacked:
        if train.load_container(container.id):
            block_name, bay, row, tier = container.location
            slot = yard.get_location(block_name, bay, row, tier)
            yard.remove_container(slot)
            bundle.flow.request_retrieval(container, when, via_rail=True)
            bundle.flow.retrieve(container, when)
            bundle.flow.load_to_train(container, when)

    rail_network.depart(train.id, when + timedelta(hours=1))


def run_demo(*, horizon_hours: float = 24.0, random_seed: int = 42) -> DemoPortBundle:
    bundle = build_demo_port(random_seed=random_seed)
    seed_vessel_arrivals(bundle, horizon_hours=horizon_hours)
    seed_truck_and_rail_activity(bundle, horizon_hours=horizon_hours)
    bundle.engine.run(until=bundle.engine.start_time + timedelta(hours=horizon_hours))
    return bundle


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the Port4.Engine demonstration port simulation.")
    parser.add_argument("--hours", type=float, default=24.0, help="Simulation horizon in hours (default: 24).")
    parser.add_argument("--seed", type=int, default=42, help="Random seed (default: 42).")
    args = parser.parse_args()

    bundle = run_demo(horizon_hours=args.hours, random_seed=args.seed)

    from port4_engine.statistics.kpi import KpiEngine

    kpis = KpiEngine(bundle.port, window_hours=args.hours).compute()
    print(f"Port4.Engine demonstration port — {args.hours}h simulation, seed={args.seed}")
    print(f"  events processed:    {bundle.engine.events_processed}")
    print(f"  vessels handled:     {len(bundle.port.vessels)}")
    print(f"  containers tracked:  {len(bundle.port.containers)}")
    for k, v in kpis.as_dict().items():
        print(f"  {k:32s} {v:10.2f}")


if __name__ == "__main__":
    main()
