"""The discrete-event simulation engine (sections 26-27).

This is the heart of the digital twin: rather than a brute-force loop that
re-evaluates every entity on every millisecond tick, work is scheduled as
discrete events keyed by ``event_time``, and the engine advances the clock
by popping the next-soonest event off a heap. This scales to weeks of
simulated time in seconds of wall-clock time, and — with a fixed
``random_seed`` — is fully deterministic and replayable.

    sim = SimulationEngine(port, start_time=..., random_seed=42)
    sim.schedule_in(0, lambda: spawn_vessel_arrivals(sim))
    sim.run(until=start_time + timedelta(hours=72))
"""

from __future__ import annotations

import heapq
import itertools
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import StrEnum
from typing import Any

import numpy as np

from port4_engine.core.ids import reset_counters
from port4_engine.core.port import Port


class SimulationMode(StrEnum):
    SIMULATION = "SIMULATION"  # Python generates the world
    LIVE = "LIVE"  # Rust telemetry is authoritative; Python only observes/reconciles


@dataclass(order=True)
class SimEvent:
    """An internal scheduling record: an ``event_time`` and a zero-argument
    callback. Distinct from :class:`~port4_engine.events.event.PortEvent`,
    which is the domain-level, published record of *what happened* —
    callbacks scheduled here are typically what publishes a PortEvent."""

    event_time: datetime
    seq: int
    callback: Callable[[], None] = field(compare=False)
    label: str = field(default="", compare=False)


class SimulationEngine:
    def __init__(
        self,
        port: Port,
        *,
        start_time: datetime,
        random_seed: int = 42,
        timestep_seconds: int = 1,
        mode: SimulationMode = SimulationMode.SIMULATION,
    ) -> None:
        self.port = port
        self.start_time = start_time
        self.clock = start_time
        self.random_seed = random_seed
        self.rng = np.random.default_rng(random_seed)
        self.timestep_seconds = timestep_seconds
        self.mode = mode

        self._queue: list[SimEvent] = []
        self._counter = itertools.count()
        self._paused = False
        self._events_processed = 0

        self._on_step_hooks: list[Callable[["SimulationEngine", SimEvent], None]] = []

    # -- scheduling -----------------------------------------------------------
    def schedule_at(self, when: datetime, callback: Callable[[], None], *, label: str = "") -> None:
        if when < self.clock:
            raise ValueError(f"cannot schedule an event in the past: {when} < {self.clock}")
        heapq.heappush(self._queue, SimEvent(event_time=when, seq=next(self._counter), callback=callback, label=label))

    def schedule_in(self, delay_seconds: float, callback: Callable[[], None], *, label: str = "") -> None:
        self.schedule_at(self.clock + timedelta(seconds=delay_seconds), callback, label=label)

    def on_step(self, hook: Callable[["SimulationEngine", SimEvent], None]) -> None:
        self._on_step_hooks.append(hook)

    # -- control ----------------------------------------------------------------
    def step(self) -> bool:
        """Process exactly one event. Returns False if the queue is empty."""
        if self._paused or not self._queue:
            return False
        event = heapq.heappop(self._queue)
        self.clock = event.event_time
        event.callback()
        self._events_processed += 1
        for hook in self._on_step_hooks:
            hook(self, event)
        return True

    def run(self, *, until: datetime | None = None, max_events: int | None = None) -> int:
        """Run the simulation until the queue is empty, ``until`` is reached,
        or ``max_events`` have been processed. Returns the number of events
        processed in this call."""
        processed = 0
        while self._queue and not self._paused:
            next_time = self._queue[0].event_time
            if until is not None and next_time > until:
                break
            if max_events is not None and processed >= max_events:
                break
            if not self.step():
                break
            processed += 1
        if until is not None and self.clock < until:
            self.clock = until
        return processed

    def fast_forward(self, to: datetime) -> int:
        """Process all events up to ``to`` as fast as possible (no real-time
        pacing) — the natural mode for 10x/100x/1000x speed simulation,
        since discrete-event processing has no per-tick cost when nothing
        is scheduled."""
        return self.run(until=to)

    def pause(self) -> None:
        self._paused = True

    def resume(self) -> None:
        self._paused = False

    def reset(self, *, deterministic_ids: bool = True) -> None:
        self.clock = self.start_time
        self.rng = np.random.default_rng(self.random_seed)
        self._queue.clear()
        self._counter = itertools.count()
        self._paused = False
        self._events_processed = 0
        if deterministic_ids:
            reset_counters()

    # -- introspection ---------------------------------------------------------
    @property
    def pending_event_count(self) -> int:
        return len(self._queue)

    @property
    def events_processed(self) -> int:
        return self._events_processed

    def peek_next(self) -> SimEvent | None:
        return self._queue[0] if self._queue else None
