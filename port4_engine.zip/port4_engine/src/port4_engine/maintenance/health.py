"""Equipment health / maintenance engine (section 36).

Applies to cranes, vehicles, yard equipment, gates and rail equipment
alike — any asset exposing operating hours, cycles, temperature, energy
draw and fault history. Uses a statistical (Weibull-hazard-inspired)
model before reaching for anything ML-based, per the engine's "use
statistical models before complex ML" principle.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import datetime, timedelta


@dataclass
class EquipmentReading:
    operating_hours: float
    cycles: int
    temperature_c: float
    energy_kwh: float
    fault_count: int
    last_maintenance: datetime | None = None
    maintenance_history: list[datetime] = field(default_factory=list)


@dataclass
class AssetHealthReport:
    asset_id: str
    health_score: float  # 0..1, 1 = perfect health
    maintenance_priority: float  # 0..1, higher = more urgent
    failure_probability_30d: float
    recommended_maintenance_window: tuple[datetime, datetime]


class AssetHealthModel:
    """A two-parameter Weibull hazard model over operating hours since last
    maintenance, adjusted for fault history and thermal stress, gives a
    principled (if simple) failure probability without requiring any
    training data — a sound baseline the ML layer must beat before it is
    used in its place (section 52)."""

    def __init__(self, *, shape: float = 1.8, characteristic_life_hours: float = 8000.0) -> None:
        self.shape = shape
        self.characteristic_life_hours = characteristic_life_hours

    def _hours_since_maintenance(self, reading: EquipmentReading, now: datetime) -> float:
        if reading.last_maintenance is None:
            return reading.operating_hours
        elapsed_days = (now - reading.last_maintenance).total_seconds() / 86400.0
        return max(0.0, elapsed_days * 24.0)

    def weibull_survival(self, hours: float) -> float:
        return math.exp(-((hours / self.characteristic_life_hours) ** self.shape))

    def evaluate(self, asset_id: str, reading: EquipmentReading, *, now: datetime) -> AssetHealthReport:
        hours = self._hours_since_maintenance(reading, now)
        survival = self.weibull_survival(hours)

        fault_penalty = min(0.4, reading.fault_count * 0.04)
        thermal_penalty = max(0.0, (reading.temperature_c - 45.0) / 100.0) if reading.temperature_c > 45 else 0.0
        health_score = max(0.0, min(1.0, survival - fault_penalty - thermal_penalty))

        hours_30d = hours + 30 * 24
        survival_30d = self.weibull_survival(hours_30d)
        failure_probability_30d = max(0.0, min(1.0, 1.0 - (survival_30d / survival) if survival > 0 else 1.0))

        maintenance_priority = max(0.0, min(1.0, 1.0 - health_score))

        # recommend a maintenance window: sooner if priority is high
        days_out = max(1, int(round(30 * (1 - maintenance_priority))))
        window_start = now + timedelta(days=days_out)
        window_end = window_start + timedelta(days=3)

        return AssetHealthReport(
            asset_id=asset_id,
            health_score=health_score,
            maintenance_priority=maintenance_priority,
            failure_probability_30d=failure_probability_30d,
            recommended_maintenance_window=(window_start, window_end),
        )

    def rank_fleet(self, readings: dict[str, EquipmentReading], *, now: datetime) -> list[AssetHealthReport]:
        reports = [self.evaluate(asset_id, r, now=now) for asset_id, r in readings.items()]
        return sorted(reports, key=lambda r: -r.maintenance_priority)
