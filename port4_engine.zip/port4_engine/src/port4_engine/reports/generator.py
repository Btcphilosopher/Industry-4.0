"""Report generation (section 54): Daily Port, Vessel, Terminal, Yard,
Energy, Maintenance, Congestion, Optimisation, Scenario and Investment
reports, each available as a machine-readable dict and a human-readable
Markdown document, built directly from the same engines the rest of
Port4.Engine uses (no data is fabricated for reporting purposes)."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from port4_engine.core.port import Port
from port4_engine.economics.investment import InvestmentEvaluation
from port4_engine.energy.energy import EnergyEngine, EnergyReport
from port4_engine.maintenance.health import AssetHealthReport
from port4_engine.optimisation.port_optimizer import PortOptimizationResult
from port4_engine.scenarios.scenario import ScenarioResult
from port4_engine.statistics.bottleneck import BottleneckDetector
from port4_engine.statistics.health import compute_port_health
from port4_engine.statistics.kpi import KpiEngine


@dataclass
class Report:
    title: str
    generated_at: datetime
    sections: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {"title": self.title, "generated_at": self.generated_at.isoformat(), **self.sections}

    def to_markdown(self) -> str:
        lines = [f"# {self.title}", "", f"_Generated {self.generated_at.isoformat()}_", ""]
        for heading, content in self.sections.items():
            lines.append(f"## {heading}")
            lines.append("")
            if isinstance(content, dict):
                for k, v in content.items():
                    lines.append(f"- **{k}**: {v}")
            elif isinstance(content, list):
                for item in content:
                    lines.append(f"- {item}")
            else:
                lines.append(str(content))
            lines.append("")
        return "\n".join(lines)


class ReportGenerator:
    def __init__(self, port: Port) -> None:
        self.port = port

    def daily_port_report(self, *, window_hours: float = 24.0) -> Report:
        kpis = KpiEngine(self.port, window_hours=window_hours).compute()
        health = compute_port_health(self.port)
        return Report(
            title="Daily Port Report",
            generated_at=datetime.now(timezone.utc),
            sections={"KPIs": kpis.as_dict(), "Health": health.as_dict(), "Entity counts": self.port.entity_count()},
        )

    def vessel_report(self) -> Report:
        vessels = [
            {
                "id": v.id,
                "name": v.name,
                "status": v.status.value,
                "berth": v.assigned_berth,
                "turnaround_hours": v.turnaround_hours(),
            }
            for v in self.port.vessels.values()
        ]
        return Report(title="Vessel Report", generated_at=datetime.now(timezone.utc), sections={"Vessels": vessels})

    def terminal_report(self) -> Report:
        berth_summary = [
            {"id": b.id, "occupied": b.occupied, "vessel_id": b.vessel_id, "length_m": b.length_m}
            for b in self.port.berths.values()
        ]
        return Report(title="Terminal Report", generated_at=datetime.now(timezone.utc), sections={"Berths": berth_summary})

    def yard_report(self) -> Report:
        yard_summary = {
            y.name: {"utilisation": y.utilisation(), "capacity": y.capacity(), "occupancy": y.occupancy()}
            for y in self.port.yards.values()
        }
        return Report(title="Yard Report", generated_at=datetime.now(timezone.utc), sections={"Yards": yard_summary})

    def energy_report(self, energy_engine: EnergyEngine, *, total_teu: float, total_containers: int, total_vessels: int, window_days: float = 1.0) -> Report:
        report: EnergyReport = energy_engine.report(
            total_teu=total_teu, total_containers=total_containers, total_vessels=total_vessels, window_days=window_days
        )
        return Report(title="Energy Report", generated_at=datetime.now(timezone.utc), sections={"Energy": report.__dict__})

    def maintenance_report(self, asset_reports: list[AssetHealthReport]) -> Report:
        ranked = sorted(asset_reports, key=lambda r: -r.maintenance_priority)
        return Report(
            title="Maintenance Report",
            generated_at=datetime.now(timezone.utc),
            sections={
                "Ranked assets": [
                    {
                        "asset_id": r.asset_id,
                        "health_score": round(r.health_score, 3),
                        "maintenance_priority": round(r.maintenance_priority, 3),
                        "failure_probability_30d": round(r.failure_probability_30d, 3),
                    }
                    for r in ranked
                ]
            },
        )

    def congestion_report(self) -> Report:
        findings = BottleneckDetector(self.port).detect()
        return Report(
            title="Congestion Report",
            generated_at=datetime.now(timezone.utc),
            sections={"Bottlenecks": [f.explain() for f in findings]},
        )

    def optimisation_report(self, result: PortOptimizationResult) -> Report:
        return Report(
            title="Optimisation Report",
            generated_at=datetime.now(timezone.utc),
            sections={"Algorithm": result.algorithm, "Decisions": result.decisions, "Score breakdown": result.score_breakdown},
        )

    def scenario_report(self, result: ScenarioResult) -> Report:
        return Report(
            title=f"Scenario Report: {result.scenario_name}",
            generated_at=datetime.now(timezone.utc),
            sections={
                "Baseline score": result.baseline_score,
                "Projected score": result.projected_score,
                "Delta": result.delta(),
            },
        )

    def investment_report(self, evaluations: list[InvestmentEvaluation]) -> Report:
        ranked = sorted(evaluations, key=lambda e: -e.five_year_roi)
        return Report(
            title="Investment Report",
            generated_at=datetime.now(timezone.utc),
            sections={
                "Ranked investments": [
                    {
                        "type": e.investment.investment_type.value,
                        "capital_cost": e.investment.capital_cost,
                        "annual_net_cash_flow": round(e.annual_net_cash_flow, 2),
                        "payback_period_years": round(e.payback_period_years, 2) if e.payback_period_years else None,
                        "five_year_roi": round(e.five_year_roi, 3),
                    }
                    for e in ranked
                ]
            },
        )
