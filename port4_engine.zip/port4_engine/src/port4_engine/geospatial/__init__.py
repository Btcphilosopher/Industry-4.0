"""Geospatial interface layer (section 40).

Python does not replace Rust's high-performance spatial engine — it
consumes geometry *from* it (or from static GeoJSON/config data) through
:class:`PortGeometryClient` for analysis, simulation and scenario
modelling, using Shapely/GeoPandas/PyProj where installed (the ``geo``
extra) and falling back to the dependency-free
:mod:`port4_engine.models.geometry` types otherwise.
"""

from port4_engine.geospatial.client import PortGeometryClient

__all__ = ["PortGeometryClient"]
