"""PortGeometryClient: the Python-side geospatial interface (section 40).

High-performance spatial indexing and hit-testing stay in Rust; this
client is how Python *obtains* port boundaries, berth geometry, the road
graph, rail geometry, yard polygons and asset positions for analysis,
simulation and scenario modelling, and (optionally, when the ``geo``
extra is installed) converts them into Shapely geometries for spatial
analysis via GeoPandas/PyProj.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from port4_engine.core.ids import EntityId
from port4_engine.core.port import Port
from port4_engine.models.geometry import Point, Polygon

try:  # optional `geo` extra
    import shapely.geometry as shapely_geometry

    _HAS_SHAPELY = True
except ImportError:  # pragma: no cover - exercised only without the geo extra
    shapely_geometry = None
    _HAS_SHAPELY = False


@dataclass
class GeospatialCapabilities:
    shapely_available: bool
    geopandas_available: bool
    pyproj_available: bool


def capabilities() -> GeospatialCapabilities:
    def _has(mod: str) -> bool:
        try:
            __import__(mod)
            return True
        except ImportError:
            return False

    return GeospatialCapabilities(
        shapely_available=_HAS_SHAPELY,
        geopandas_available=_has("geopandas"),
        pyproj_available=_has("pyproj"),
    )


class PortGeometryClient:
    """A read-oriented geospatial facade over the canonical :class:`Port`.

    In a full deployment this would call out to the Rust port core's
    geospatial service (over the same efficient binary channel described
    in :mod:`port4_engine.integration`); here it reads geometry already
    attached to Port entities, which is sufficient for simulation and
    scenario analysis and keeps this client's contract identical either
    way.
    """

    def __init__(self, port: Port) -> None:
        self.port = port

    def port_boundary(self) -> Polygon | None:
        return self.port.boundary

    def berth_geometry(self, berth_id: EntityId) -> Polygon | None:
        berth = self.port.berths.get(berth_id)
        return getattr(berth, "geometry", None) if berth else None

    def yard_polygons(self) -> dict[EntityId, Polygon]:
        return {
            yard_id: getattr(yard, "geometry", None)
            for yard_id, yard in self.port.yards.items()
            if getattr(yard, "geometry", None) is not None
        }

    def road_graph(self) -> Any:
        return self.port.roads

    def rail_geometry(self) -> Any:
        return self.port.rail_network

    def asset_positions(self) -> dict[EntityId, Point]:
        positions: dict[EntityId, Point] = {}
        for crane_id, crane in self.port.cranes.items():
            pos = getattr(crane, "position", None)
            if isinstance(pos, Point):
                positions[crane_id] = pos
        return positions

    # -- Shapely conversion (requires the `geo` extra) --------------------------
    def to_shapely_polygon(self, polygon: Polygon):
        if not _HAS_SHAPELY:
            raise ImportError(
                "shapely is required for to_shapely_polygon(); install port4-engine[geo]"
            )
        return shapely_geometry.Polygon([(p.lon, p.lat) for p in polygon.points])

    def to_shapely_point(self, point: Point):
        if not _HAS_SHAPELY:
            raise ImportError("shapely is required for to_shapely_point(); install port4-engine[geo]")
        return shapely_geometry.Point(point.lon, point.lat)

    def containing_yard(self, point: Point) -> EntityId | None:
        """Point-in-polygon test across yard polygons.

        Uses Shapely when available for a robust general-polygon test;
        falls back to the dependency-free bounding-box containment on
        :class:`~port4_engine.models.geometry.Polygon` otherwise (exact for
        axis-aligned yard footprints, an approximation for irregular ones —
        Rust's spatial index is the source of truth for anything precise).
        """
        for yard_id, polygon in self.yard_polygons().items():
            if polygon is None:
                continue
            if _HAS_SHAPELY:
                if self.to_shapely_polygon(polygon).contains(self.to_shapely_point(point)):
                    return yard_id
            else:
                if polygon.bounding_box().contains(point):
                    return yard_id
        return None
