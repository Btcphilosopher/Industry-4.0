"""Stable entity identifiers.

Every entity in the Port4.Engine data model (vessels, berths, cranes,
containers, ...) carries a stable, human-legible, prefixed ID so that
Rust and Kotlin can reference the same entity without ambiguity, and so
that IDs are stable across simulation runs when a fixed seed/counter is
used (important for deterministic replay and testing).
"""

from __future__ import annotations

import itertools
import uuid
from typing import ClassVar

EntityId = str

_counters: dict[str, itertools.count] = {}


def new_id(prefix: str, *, deterministic: bool = False) -> EntityId:
    """Generate a new prefixed entity ID.

    If ``deterministic`` is True, uses a monotonically increasing per-prefix
    counter instead of a random UUID, which keeps IDs stable and readable
    across deterministic simulation runs (e.g. ``VESSEL-000001``).
    """
    if deterministic:
        counter = _counters.setdefault(prefix, itertools.count(1))
        return f"{prefix}-{next(counter):06d}"
    return f"{prefix}-{uuid.uuid4().hex[:12]}"


def reset_counters() -> None:
    """Reset all deterministic ID counters (used at the start of a seeded run)."""
    _counters.clear()


class IdMixin:
    """Mixin providing a class-scoped ID prefix and a factory."""

    id_prefix: ClassVar[str] = "ENTITY"

    @classmethod
    def generate_id(cls, deterministic: bool = False) -> EntityId:
        return new_id(cls.id_prefix, deterministic=deterministic)
