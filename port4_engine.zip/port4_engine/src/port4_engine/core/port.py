"""The canonical Port data model — the root object of the digital twin.

``Port`` is deliberately a plain, dependency-light aggregate of entity
registries keyed by stable entity ID. It does not import the concrete
entity classes (vessels, berths, cranes, ...) at module scope, to keep the
dependency graph acyclic: those modules import ``Port`` (via
``core.port``) for type hints, not the other way around. Entities are
typed loosely as ``Any`` here and precisely wherever they are constructed
and inserted, giving every subsystem (simulation, optimisation,
forecasting, scenarios) a single, uniform place to look up "the state of
the port" regardless of which concrete module produced an entity.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from port4_engine.core.ids import EntityId
from port4_engine.events.bus import EventBus
from port4_engine.models.geometry import Polygon


@dataclass
class Port:
    """Root object of the PORT 4.0 canonical port data model."""

    port_authority: str
    port_id: EntityId
    name: str
    country: str = "unknown"
    timezone: str = "UTC"
    boundary: Polygon | None = None

    terminals: dict[EntityId, Any] = field(default_factory=dict)
    berths: dict[EntityId, Any] = field(default_factory=dict)
    cranes: dict[EntityId, Any] = field(default_factory=dict)
    yards: dict[EntityId, Any] = field(default_factory=dict)
    containers: dict[EntityId, Any] = field(default_factory=dict)
    vessels: dict[EntityId, Any] = field(default_factory=dict)
    trucks: dict[EntityId, Any] = field(default_factory=dict)
    rail_network: Any | None = None
    trains: dict[EntityId, Any] = field(default_factory=dict)
    warehouses: dict[EntityId, Any] = field(default_factory=dict)
    gates: dict[EntityId, Any] = field(default_factory=dict)
    roads: Any | None = None
    energy_assets: dict[EntityId, Any] = field(default_factory=dict)
    maintenance_assets: dict[EntityId, Any] = field(default_factory=dict)

    events: EventBus = field(default_factory=EventBus)

    # --- convenience registries -------------------------------------------------
    def register(self, registry_name: str, entity: Any) -> EntityId:
        """Register an entity with an ``id`` attribute into ``getattr(self, registry_name)``."""
        registry: dict[EntityId, Any] = getattr(self, registry_name)
        entity_id = getattr(entity, "id")
        registry[entity_id] = entity
        return entity_id

    def all_entities(self) -> dict[str, dict[EntityId, Any]]:
        return {
            "terminals": self.terminals,
            "berths": self.berths,
            "cranes": self.cranes,
            "yards": self.yards,
            "containers": self.containers,
            "vessels": self.vessels,
            "trucks": self.trucks,
            "trains": self.trains,
            "warehouses": self.warehouses,
            "gates": self.gates,
            "energy_assets": self.energy_assets,
            "maintenance_assets": self.maintenance_assets,
        }

    def entity_count(self) -> dict[str, int]:
        return {name: len(reg) for name, reg in self.all_entities().items()}

    def find(self, entity_id: EntityId) -> Any | None:
        """Look up any entity by ID across every registry."""
        for registry in self.all_entities().values():
            if entity_id in registry:
                return registry[entity_id]
        return None
