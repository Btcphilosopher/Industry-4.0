"""A small, formal, generic state machine used by every stateful entity.

Vessels, containers, trucks, trains, cranes and gates all move through a
constrained set of states. Rather than let ad-hoc string assignment drive
state changes, every such entity is built on top of :class:`StateMachine`,
which enforces a transition table, raises structured errors on illegal
transitions, and emits a callback (used to publish domain events) on every
successful transition.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from enum import Enum
from typing import Generic, TypeVar

S = TypeVar("S", bound=Enum)


class StateTransitionError(RuntimeError):
    """Raised when an illegal state transition is attempted."""

    def __init__(self, entity_id: str, current: Enum, target: Enum) -> None:
        self.entity_id = entity_id
        self.current = current
        self.target = target
        super().__init__(
            f"Illegal transition for {entity_id}: {current.name} -> {target.name} is not allowed"
        )


TransitionListener = Callable[[str, S, S], None]


@dataclass
class StateMachine(Generic[S]):
    """A generic finite state machine bound to one owning entity.

    ``transitions`` maps a state to the set of states it may legally move
    to. ``on_transition`` listeners are called with (entity_id, old, new)
    after every successful transition, which is how the event bus is wired
    up without every model needing to know about it directly.
    """

    entity_id: str
    state: S
    transitions: dict[S, set[S]]
    _listeners: list[TransitionListener] = field(default_factory=list)
    history: list[tuple[S, S]] = field(default_factory=list)

    def can_transition(self, target: S) -> bool:
        return target in self.transitions.get(self.state, set())

    def transition(self, target: S) -> None:
        if not self.can_transition(target):
            raise StateTransitionError(self.entity_id, self.state, target)
        old = self.state
        self.state = target
        self.history.append((old, target))
        for listener in self._listeners:
            listener(self.entity_id, old, target)

    def add_listener(self, listener: TransitionListener) -> None:
        self._listeners.append(listener)

    def force(self, target: S) -> None:
        """Force a transition bypassing the transition table.

        Reserved for reconciling with authoritative live telemetry from
        Rust, never for simulation logic — see ``telemetry`` module.
        """
        old = self.state
        self.state = target
        self.history.append((old, target))
        for listener in self._listeners:
            listener(self.entity_id, old, target)


def build_linear_transitions(order: Iterable[S], *, allow_skip: bool = False) -> dict[S, set[S]]:
    """Helper to build a transition table for a mostly-linear lifecycle.

    If ``allow_skip`` is False, each state may only move to the next state
    in ``order`` (a strict pipeline). If True, each state may move to any
    later state (skipping intermediate ones is allowed).
    """
    states = list(order)
    table: dict[S, set[S]] = {}
    for i, s in enumerate(states):
        if allow_skip:
            table[s] = set(states[i + 1 :])
        else:
            table[s] = {states[i + 1]} if i + 1 < len(states) else set()
    return table
