"""Structured data validation (section 49).

Detects physically impossible conditions (a vessel longer than its
assigned berth, a container exceeding crane capacity, a yard stack past
its configured height, a truck carrying an impossible load, negative
capacity, invalid geometry) and raises a structured
:class:`ValidationError` rather than silently coercing bad data.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class ValidationIssue:
    field: str
    message: str


class ValidationError(ValueError):
    def __init__(self, issues: list[ValidationIssue]) -> None:
        self.issues = issues
        summary = "; ".join(f"{i.field}: {i.message}" for i in issues)
        super().__init__(f"validation failed: {summary}")


def validate_vessel_berth_fit(vessel_length_m: float, vessel_draft_m: float, berth_length_m: float, berth_depth_m: float, *, safety_margin_m: float = 10.0) -> None:
    issues: list[ValidationIssue] = []
    if vessel_length_m <= 0:
        issues.append(ValidationIssue("vessel_length_m", "must be positive"))
    if berth_length_m <= 0:
        issues.append(ValidationIssue("berth_length_m", "must be positive"))
    if vessel_length_m + safety_margin_m > berth_length_m:
        issues.append(ValidationIssue("vessel_length_m", f"vessel + safety margin ({vessel_length_m + safety_margin_m}m) exceeds berth length ({berth_length_m}m)"))
    if vessel_draft_m > berth_depth_m:
        issues.append(ValidationIssue("vessel_draft_m", f"draft ({vessel_draft_m}m) exceeds berth depth ({berth_depth_m}m)"))
    if issues:
        raise ValidationError(issues)


def validate_crane_lift(container_weight_kg: float, crane_capacity_tonnes: float) -> None:
    issues: list[ValidationIssue] = []
    if container_weight_kg <= 0:
        issues.append(ValidationIssue("container_weight_kg", "must be positive"))
    if container_weight_kg / 1000.0 > crane_capacity_tonnes:
        issues.append(
            ValidationIssue(
                "container_weight_kg",
                f"container weight ({container_weight_kg / 1000.0:.1f}t) exceeds crane capacity ({crane_capacity_tonnes}t)",
            )
        )
    if issues:
        raise ValidationError(issues)


def validate_yard_stack_height(tier: int, max_tier: int) -> None:
    issues: list[ValidationIssue] = []
    if tier < 1:
        issues.append(ValidationIssue("tier", "must be >= 1"))
    if tier > max_tier:
        issues.append(ValidationIssue("tier", f"tier {tier} exceeds configured maximum stack height {max_tier}"))
    if issues:
        raise ValidationError(issues)


def validate_truck_load(load_teu: float, truck_capacity_teu: float) -> None:
    issues: list[ValidationIssue] = []
    if load_teu < 0:
        issues.append(ValidationIssue("load_teu", "cannot be negative"))
    if load_teu > truck_capacity_teu:
        issues.append(ValidationIssue("load_teu", f"load ({load_teu} TEU) exceeds truck capacity ({truck_capacity_teu} TEU)"))
    if issues:
        raise ValidationError(issues)


def validate_capacity(name: str, capacity: float) -> None:
    if capacity < 0:
        raise ValidationError([ValidationIssue(name, "capacity cannot be negative")])


def validate_polygon_ring(points: list[tuple[float, float]]) -> None:
    if len(points) < 3:
        raise ValidationError([ValidationIssue("points", "a polygon requires at least 3 points")])
