"""Physical berth-fit checking (section 8).

Determines whether a vessel can *physically* occupy a berth, considering
length, beam-driven safety margins, draft/depth, and any operational
restrictions declared on the berth or terminal. This is a pure feasibility
check; the *scheduling* decision (which vessel gets which berth *when*) is
made by :class:`~port4_engine.berths.optimizer.BerthOptimizer`.
"""

from __future__ import annotations

from dataclasses import dataclass

from port4_engine.berths.berth import Berth
from port4_engine.vessels.vessel import Vessel


@dataclass
class FitResult:
    fits: bool
    reasons: list[str]

    def __bool__(self) -> bool:
        return self.fits


class BerthAllocator:
    def __init__(self, safety_margin_m: float = 10.0) -> None:
        self.safety_margin_m = safety_margin_m

    def check_fit(self, vessel: Vessel, berth: Berth) -> FitResult:
        reasons: list[str] = []
        required_length = vessel.length_m + self.safety_margin_m
        if required_length > berth.length_m:
            reasons.append(
                f"vessel length {vessel.length_m}m + safety margin {self.safety_margin_m}m "
                f"exceeds berth length {berth.length_m}m"
            )
        if vessel.draft_m > berth.maximum_draft_m:
            reasons.append(f"vessel draft {vessel.draft_m}m exceeds berth max draft {berth.maximum_draft_m}m")
        if vessel.draft_m > berth.depth_m:
            reasons.append(f"vessel draft {vessel.draft_m}m exceeds berth depth {berth.depth_m}m")
        return FitResult(fits=not reasons, reasons=reasons)

    def eligible_berths(self, vessel: Vessel, berths: list[Berth]) -> list[Berth]:
        return [b for b in berths if self.check_fit(vessel, b).fits]
