"""The Berth entity (section 8)."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from port4_engine.core.ids import EntityId, IdMixin, new_id
from port4_engine.models.geometry import Polygon


@dataclass
class Berth(IdMixin):
    id_prefix = "BERTH"

    length_m: float
    depth_m: float
    maximum_draft_m: float
    terminal_id: EntityId
    geometry: Polygon | None = None
    available_from: datetime | None = None
    available_until: datetime | None = None
    occupied: bool = False
    vessel_id: EntityId | None = None
    id: EntityId = field(default_factory=lambda: new_id("BERTH"))

    def is_available_at(self, when: datetime) -> bool:
        if self.occupied:
            return False
        if self.available_from and when < self.available_from:
            return False
        if self.available_until and when > self.available_until:
            return False
        return True

    def assign(self, vessel_id: EntityId) -> None:
        self.occupied = True
        self.vessel_id = vessel_id

    def release(self) -> None:
        self.occupied = False
        self.vessel_id = None
