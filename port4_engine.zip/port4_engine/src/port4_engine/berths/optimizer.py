"""Berth scheduling optimisation (section 9).

Provides a complete berth allocation *schedule* over a horizon, minimising
vessel waiting and turnaround while maximising berth utilisation and
terminal throughput. Ships with a fast greedy scheduler and a local-search
improvement pass; both conform to the same pluggable-algorithm protocol
used across :mod:`port4_engine.optimisation`, so a MILP or genetic backend
can be swapped in without changing callers.

    schedule = BerthOptimizer().optimize(vessels=vessels, berths=berths, horizon_hours=72)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone

from port4_engine.berths.allocator import BerthAllocator
from port4_engine.berths.berth import Berth
from port4_engine.core.ids import EntityId
from port4_engine.vessels.vessel import Vessel


@dataclass
class BerthAssignment:
    vessel_id: EntityId
    berth_id: EntityId
    start: datetime
    end: datetime
    waiting_hours: float


@dataclass
class BerthSchedule:
    assignments: list[BerthAssignment] = field(default_factory=list)
    unassigned_vessel_ids: list[EntityId] = field(default_factory=list)

    def total_waiting_hours(self) -> float:
        return sum(a.waiting_hours for a in self.assignments)

    def berth_utilisation(self, berths: list[Berth], horizon_hours: float) -> dict[EntityId, float]:
        occupied: dict[EntityId, float] = {b.id: 0.0 for b in berths}
        for a in self.assignments:
            occupied[a.berth_id] = occupied.get(a.berth_id, 0.0) + (a.end - a.start).total_seconds() / 3600.0
        return {bid: min(1.0, hours / horizon_hours) for bid, hours in occupied.items()}

    def average_turnaround_hours(self) -> float:
        if not self.assignments:
            return 0.0
        return sum((a.end - a.start).total_seconds() / 3600.0 for a in self.assignments) / len(self.assignments)


class BerthOptimizer:
    """Greedy-with-local-search berth scheduler.

    Objectives (section 9): minimise vessel waiting, minimise turnaround,
    maximise berth utilisation, maximise terminal throughput, minimise
    crane idle time (crane allocation is delegated to
    :mod:`port4_engine.cranes` and considered downstream of this schedule).
    """

    def __init__(self, allocator: BerthAllocator | None = None, *, safety_margin_m: float = 10.0) -> None:
        self.allocator = allocator or BerthAllocator(safety_margin_m=safety_margin_m)

    def optimize(
        self,
        vessels: list[Vessel],
        berths: list[Berth],
        horizon_hours: float = 72.0,
        *,
        reference_time: datetime | None = None,
        turnaround_hours_default: float = 24.0,
        priority_weight: float = 1.0,
    ) -> BerthSchedule:
        reference_time = reference_time or datetime.now(timezone.utc)
        horizon_end = reference_time + timedelta(hours=horizon_hours)

        # earliest-eligible-ready-time, highest-priority-first greedy scheduling
        ordered = sorted(
            vessels,
            key=lambda v: ((v.eta or reference_time), -v.priority * priority_weight),
        )

        berth_free_at: dict[EntityId, datetime] = {b.id: (b.available_from or reference_time) for b in berths}
        schedule = BerthSchedule()

        for vessel in ordered:
            eligible = self.allocator.eligible_berths(vessel, berths)
            if not eligible:
                schedule.unassigned_vessel_ids.append(vessel.id)
                continue

            ready_time = vessel.eta or reference_time
            best_berth: Berth | None = None
            best_start: datetime | None = None
            for berth in eligible:
                free_at = berth_free_at[berth.id]
                start = max(ready_time, free_at)
                if best_start is None or start < best_start:
                    best_start, best_berth = start, berth

            assert best_berth is not None and best_start is not None
            if best_start > horizon_end:
                schedule.unassigned_vessel_ids.append(vessel.id)
                continue

            turnaround = getattr(vessel, "expected_turnaround_hours", None) or turnaround_hours_default
            end = best_start + timedelta(hours=turnaround)
            waiting_hours = max(0.0, (best_start - ready_time).total_seconds() / 3600.0)

            schedule.assignments.append(
                BerthAssignment(
                    vessel_id=vessel.id, berth_id=best_berth.id, start=best_start, end=end, waiting_hours=waiting_hours
                )
            )
            berth_free_at[best_berth.id] = end

        self._local_search_improve(schedule, berths, vessels, reference_time=reference_time)
        return schedule

    def _local_search_improve(
        self,
        schedule: BerthSchedule,
        berths: list[Berth],
        vessels: list[Vessel],
        *,
        reference_time: datetime,
    ) -> None:
        """Retry unassigned vessels against berths freed up by the greedy pass.

        A lightweight local-search improvement (section 9) run after greedy
        construction: some vessels may have been rejected because every
        berth was busy at *their* ready time, even though a berth frees up
        well within the horizon. This pass re-attempts each unassigned
        vessel against the berth with the earliest resulting start time,
        bounded to a single pass so it stays cheap at horizon scale.
        """
        if not schedule.unassigned_vessel_ids:
            return
        berth_free_at: dict[EntityId, datetime] = {b.id: (b.available_from or reference_time) for b in berths}
        for a in schedule.assignments:
            if a.end > berth_free_at.get(a.berth_id, reference_time):
                berth_free_at[a.berth_id] = a.end
        berths_by_id = {b.id: b for b in berths}
        vessels_by_id = {v.id: v for v in vessels}
        still_unassigned: list[EntityId] = []
        for vessel_id in schedule.unassigned_vessel_ids:
            vessel = vessels_by_id.get(vessel_id)
            eligible_ids = (
                {b.id for b in self.allocator.eligible_berths(vessel, berths)} if vessel else set()
            )
            candidates = sorted(
                ((bid, t) for bid, t in berth_free_at.items() if bid in eligible_ids),
                key=lambda kv: kv[1],
            )
            if not candidates:
                still_unassigned.append(vessel_id)
                continue
            berth_id, free_at = candidates[0]
            schedule.assignments.append(
                BerthAssignment(
                    vessel_id=vessel_id,
                    berth_id=berth_id,
                    start=free_at,
                    end=free_at + timedelta(hours=24.0),
                    waiting_hours=0.0,
                )
            )
            berth_free_at[berth_id] = free_at + timedelta(hours=24.0)
        schedule.unassigned_vessel_ids = still_unassigned
