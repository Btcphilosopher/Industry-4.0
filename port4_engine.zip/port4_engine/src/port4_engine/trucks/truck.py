"""The Truck entity (section 19)."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum

from port4_engine.core.ids import EntityId, IdMixin, new_id


class TruckStatus(StrEnum):
    EN_ROUTE = "EN_ROUTE"
    GATE_QUEUE = "GATE_QUEUE"
    GATE_PROCESSING = "GATE_PROCESSING"
    LOADING = "LOADING"
    IN_TERMINAL = "IN_TERMINAL"
    UNLOADING = "UNLOADING"
    IDLE = "IDLE"
    EXITING = "EXITING"
    DEPARTED = "DEPARTED"


@dataclass
class Truck(IdMixin):
    id_prefix = "TRUCK"

    capacity_teu: float
    id: EntityId = field(default_factory=lambda: new_id("TRUCK"))
    container: EntityId | None = None
    position: str | None = None  # current road-graph node id
    route: list[str] = field(default_factory=list)
    speed_kmh: float = 30.0
    status: TruckStatus = TruckStatus.EN_ROUTE
    arrival_time: datetime | None = None
    departure_time: datetime | None = None
    fuel_or_energy_kwh_remaining: float = 100.0

    def turnaround_minutes(self) -> float | None:
        if self.arrival_time is None or self.departure_time is None:
            return None
        return (self.departure_time - self.arrival_time).total_seconds() / 60.0

    def load(self, container_id: EntityId) -> None:
        self.container = container_id
        self.status = TruckStatus.LOADING

    def unload(self) -> EntityId | None:
        c = self.container
        self.container = None
        self.status = TruckStatus.UNLOADING
        return c
