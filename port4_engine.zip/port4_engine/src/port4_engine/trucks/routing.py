"""Truck routing over the shared :class:`PortRoadGraph` (section 20)."""

from __future__ import annotations

from port4_engine.routing.graph import PortRoadGraph, RouteMetric, RouteResult
from port4_engine.trucks.truck import Truck


class TruckRouter:
    def __init__(self, road_graph: PortRoadGraph) -> None:
        self.road_graph = road_graph

    def plan_route(self, truck: Truck, destination: str, *, metric: RouteMetric = "fastest") -> RouteResult:
        if truck.position is None:
            raise ValueError(f"truck {truck.id} has no current position to route from")
        result = self.road_graph.route(truck.position, destination, metric=metric)
        truck.route = result.path
        return result

    def advance(self, truck: Truck, *, seconds: float) -> bool:
        """Advance a truck along its planned route by ``seconds`` of travel time.

        Returns True if the truck reached the end of its route. This is a
        coarse, edge-granularity advance intended for use from the discrete
        event simulation engine, not a continuous physics integrator.
        """
        if not truck.route or len(truck.route) < 2:
            return True
        remaining = seconds
        while remaining > 0 and len(truck.route) >= 2:
            u, v = truck.route[0], truck.route[1]
            edge = self.road_graph.graph[u][v]["edge"]
            edge_time = edge.current_travel_time_s()
            if edge_time <= remaining:
                remaining -= edge_time
                truck.route.pop(0)
                truck.position = v
            else:
                break
        return len(truck.route) <= 1
