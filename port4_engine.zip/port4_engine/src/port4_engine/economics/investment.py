"""Capital investment scenario analysis (section 39).

Evaluates candidate infrastructure investments (new berth, crane, yard,
rail terminal, gate, warehouse, road, electrification) for capital cost,
capacity increase, throughput increase, operating cost delta, energy
impact, congestion reduction and payback period.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


class InvestmentType(StrEnum):
    NEW_BERTH = "NEW_BERTH"
    NEW_CRANE = "NEW_CRANE"
    NEW_YARD = "NEW_YARD"
    NEW_RAIL_TERMINAL = "NEW_RAIL_TERMINAL"
    NEW_GATE = "NEW_GATE"
    NEW_WAREHOUSE = "NEW_WAREHOUSE"
    NEW_ROAD = "NEW_ROAD"
    ELECTRIFICATION = "ELECTRIFICATION"


@dataclass
class CapitalInvestment:
    investment_type: InvestmentType
    capital_cost: float
    expected_capacity_increase_teu_per_year: float
    expected_annual_operating_cost_delta: float
    expected_annual_energy_delta_kwh: float
    expected_congestion_reduction_ratio: float  # fractional reduction, e.g. 0.10 = -10 points
    revenue_per_teu: float


@dataclass
class InvestmentEvaluation:
    investment: CapitalInvestment
    annual_incremental_revenue: float
    annual_net_cash_flow: float
    payback_period_years: float | None
    five_year_roi: float


def evaluate_investment(investment: CapitalInvestment, *, energy_cost_per_kwh: float = 0.22) -> InvestmentEvaluation:
    annual_incremental_revenue = investment.expected_capacity_increase_teu_per_year * investment.revenue_per_teu
    annual_energy_cost_delta = investment.expected_annual_energy_delta_kwh * energy_cost_per_kwh
    annual_net_cash_flow = (
        annual_incremental_revenue - investment.expected_annual_operating_cost_delta - annual_energy_cost_delta
    )

    payback_period_years = (
        investment.capital_cost / annual_net_cash_flow if annual_net_cash_flow > 0 else None
    )
    five_year_cash_flows = annual_net_cash_flow * 5 - investment.capital_cost
    five_year_roi = five_year_cash_flows / investment.capital_cost if investment.capital_cost else 0.0

    return InvestmentEvaluation(
        investment=investment,
        annual_incremental_revenue=annual_incremental_revenue,
        annual_net_cash_flow=annual_net_cash_flow,
        payback_period_years=payback_period_years,
        five_year_roi=five_year_roi,
    )


def rank_investments(investments: list[CapitalInvestment], *, energy_cost_per_kwh: float = 0.22) -> list[InvestmentEvaluation]:
    evaluations = [evaluate_investment(inv, energy_cost_per_kwh=energy_cost_per_kwh) for inv in investments]
    return sorted(evaluations, key=lambda e: -e.five_year_roi)
