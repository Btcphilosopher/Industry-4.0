"""Port economic engine (section 38).

Models revenue, handling costs, energy costs, labour, maintenance,
equipment, congestion/delay costs and capital investment, and derives
``cost_per_teu``, ``revenue_per_teu``, ``operating_margin`` and
``investment_return`` (identifiers corrected from the loosely specified
"cost_per_TE U" / "revenue_per_TE U" naming).
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class EconomicsInputs:
    teu_handled: float
    revenue_per_teu: float
    handling_cost_per_teu: float
    energy_cost: float
    labour_cost: float
    maintenance_cost: float
    equipment_cost: float
    congestion_delay_cost: float
    capital_investment: float = 0.0


@dataclass
class EconomicsReport:
    revenue: float
    handling_cost: float
    total_operating_cost: float
    operating_margin: float
    cost_per_teu: float
    revenue_per_teu: float
    investment_return: float | None


class PortEconomics:
    def evaluate(self, x: EconomicsInputs) -> EconomicsReport:
        revenue = x.teu_handled * x.revenue_per_teu
        handling_cost = x.teu_handled * x.handling_cost_per_teu
        total_operating_cost = (
            handling_cost + x.energy_cost + x.labour_cost + x.maintenance_cost + x.equipment_cost + x.congestion_delay_cost
        )
        operating_profit = revenue - total_operating_cost
        operating_margin = operating_profit / revenue if revenue else 0.0
        cost_per_teu = total_operating_cost / x.teu_handled if x.teu_handled else 0.0
        revenue_per_teu = revenue / x.teu_handled if x.teu_handled else 0.0
        investment_return = (operating_profit / x.capital_investment) if x.capital_investment else None

        return EconomicsReport(
            revenue=revenue,
            handling_cost=handling_cost,
            total_operating_cost=total_operating_cost,
            operating_margin=operating_margin,
            cost_per_teu=cost_per_teu,
            revenue_per_teu=revenue_per_teu,
            investment_return=investment_return,
        )
