"""The Vessel entity and its formal lifecycle state machine (section 6-7)."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from typing import Any

from port4_engine.core.ids import EntityId, IdMixin, new_id
from port4_engine.core.state_machine import StateMachine


class VesselStatus(StrEnum):
    AT_SEA = "AT_SEA"
    APPROACHING = "APPROACHING"
    ANCHORING = "ANCHORING"
    BERTH_WAIT = "BERTH_WAIT"
    BERTHING = "BERTHING"
    BERTHED = "BERTHED"
    LOADING = "LOADING"
    UNLOADING = "UNLOADING"
    CARGO_COMPLETE = "CARGO_COMPLETE"
    DEPARTING = "DEPARTING"
    DEPARTED = "DEPARTED"


VESSEL_TRANSITIONS: dict[VesselStatus, set[VesselStatus]] = {
    VesselStatus.AT_SEA: {VesselStatus.APPROACHING},
    VesselStatus.APPROACHING: {VesselStatus.ANCHORING, VesselStatus.BERTH_WAIT, VesselStatus.BERTHING},
    VesselStatus.ANCHORING: {VesselStatus.BERTH_WAIT, VesselStatus.BERTHING},
    VesselStatus.BERTH_WAIT: {VesselStatus.BERTHING},
    VesselStatus.BERTHING: {VesselStatus.BERTHED},
    VesselStatus.BERTHED: {VesselStatus.LOADING, VesselStatus.UNLOADING},
    VesselStatus.LOADING: {VesselStatus.UNLOADING, VesselStatus.CARGO_COMPLETE},
    VesselStatus.UNLOADING: {VesselStatus.LOADING, VesselStatus.CARGO_COMPLETE},
    VesselStatus.CARGO_COMPLETE: {VesselStatus.DEPARTING},
    VesselStatus.DEPARTING: {VesselStatus.DEPARTED},
    VesselStatus.DEPARTED: set(),
}


@dataclass
class Vessel(IdMixin):
    id_prefix = "VESSEL"

    imo: str
    name: str
    length_m: float
    beam_m: float
    draft_m: float
    capacity_teu: float
    current_teu: float = 0.0
    eta: datetime | None = None
    etd: datetime | None = None
    arrival_time: datetime | None = None
    departure_time: datetime | None = None
    origin: str | None = None
    destination: str | None = None
    cargo: list[EntityId] = field(default_factory=list)
    priority: int = 0
    assigned_berth: EntityId | None = None
    assigned_cranes: list[EntityId] = field(default_factory=list)

    id: EntityId = field(default_factory=lambda: new_id("VESSEL"))
    status: VesselStatus = VesselStatus.AT_SEA
    _fsm: StateMachine[VesselStatus] | None = field(default=None, repr=False)

    def __post_init__(self) -> None:
        self._fsm = StateMachine(entity_id=self.id, state=self.status, transitions=VESSEL_TRANSITIONS)

    def bind_event_listener(self, listener: Any) -> None:
        assert self._fsm is not None
        self._fsm.add_listener(listener)

    def transition(self, target: VesselStatus) -> None:
        assert self._fsm is not None
        self._fsm.transition(target)
        self.status = target
        if target == VesselStatus.BERTHED and self.arrival_time is None:
            pass  # arrival_time is set by the simulation clock, not here
        if target == VesselStatus.DEPARTED:
            pass

    def turnaround_hours(self) -> float | None:
        if self.arrival_time is None or self.departure_time is None:
            return None
        return (self.departure_time - self.arrival_time).total_seconds() / 3600.0

    def remaining_cargo_teu(self) -> float:
        return max(0.0, self.current_teu)

    def fits_berth(self, berth_length_m: float, berth_depth_m: float, safety_margin_m: float = 10.0) -> bool:
        return (self.length_m + safety_margin_m) <= berth_length_m and self.draft_m <= berth_depth_m
