"""Realistic vessel arrival generation (section 7).

Supports fixed schedules, Poisson arrival processes, historical empirical
distributions, seasonality multipliers and stochastic delay injection
(random operational delay + weather delay + congestion-driven delay).
Generated arrivals carry not just an ETA but also cargo volume and
berth/crane requirements, and explicit arrival uncertainty (P10/P50/P90),
consistent with the engine's uncertainty-first philosophy (section 50).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta

import numpy as np

from port4_engine.core.ids import EntityId, new_id


@dataclass
class ArrivalPlan:
    vessel_ref: EntityId
    eta_p50: datetime
    eta_p10: datetime
    eta_p90: datetime
    cargo_teu: float
    required_berth_length_m: float
    required_crane_count: int
    turnaround_hours_estimate: float


class ArrivalGenerator:
    """Generates a stream of :class:`ArrivalPlan` objects.

    ``rng`` should be a seeded ``numpy.random.Generator`` for determinism.
    """

    def __init__(
        self,
        rng: np.random.Generator,
        *,
        mean_teu: float = 2500.0,
        teu_std_fraction: float = 0.25,
        weather_delay_probability: float = 0.08,
        weather_delay_hours_scale: float = 6.0,
        congestion_delay_hours_per_util: float = 12.0,
    ) -> None:
        self.rng = rng
        self.mean_teu = mean_teu
        self.teu_std_fraction = teu_std_fraction
        self.weather_delay_probability = weather_delay_probability
        self.weather_delay_hours_scale = weather_delay_hours_scale
        self.congestion_delay_hours_per_util = congestion_delay_hours_per_util

    # -- arrival processes -------------------------------------------------
    def poisson_arrival_times(
        self, start: datetime, horizon_hours: float, arrivals_per_day: float, *, seasonality: dict[int, float] | None = None
    ) -> list[datetime]:
        """Generate arrival times via a (optionally time-inhomogeneous) Poisson process.

        ``seasonality`` maps hour-of-day (0-23) to a multiplier on the base
        rate, letting callers model tidal/day-night arrival patterns.
        """
        times: list[datetime] = []
        t = 0.0
        base_rate_per_hour = arrivals_per_day / 24.0
        while t < horizon_hours:
            hour_of_day = int((start + timedelta(hours=t)).hour)
            multiplier = 1.0
            if seasonality:
                multiplier = seasonality.get(hour_of_day, 1.0)
            rate = max(1e-6, base_rate_per_hour * multiplier)
            dt = self.rng.exponential(1.0 / rate)
            t += dt
            if t < horizon_hours:
                times.append(start + timedelta(hours=t))
        return times

    def fixed_schedule(self, base_times: list[datetime]) -> list[datetime]:
        return list(base_times)

    def from_historical_distribution(
        self, start: datetime, horizon_hours: float, historical_interarrival_hours: list[float]
    ) -> list[datetime]:
        """Bootstrap-resample historical inter-arrival times to build a new arrival stream."""
        if not historical_interarrival_hours:
            raise ValueError("historical_interarrival_hours must be non-empty")
        times: list[datetime] = []
        t = 0.0
        arr = np.asarray(historical_interarrival_hours)
        while t < horizon_hours:
            dt = float(self.rng.choice(arr))
            t += dt
            if t < horizon_hours:
                times.append(start + timedelta(hours=t))
        return times

    # -- delay injection -----------------------------------------------------
    def sample_delay_hours(self, current_yard_utilisation: float = 0.0) -> float:
        delay = 0.0
        if self.rng.random() < self.weather_delay_probability:
            delay += self.rng.exponential(self.weather_delay_hours_scale)
        if current_yard_utilisation > 0.70:
            excess = current_yard_utilisation - 0.70
            delay += excess * self.congestion_delay_hours_per_util
        delay += max(0.0, self.rng.normal(0, 0.5))  # generic operational noise
        return delay

    # -- cargo / requirement generation --------------------------------------
    def sample_cargo_teu(self) -> float:
        std = self.mean_teu * self.teu_std_fraction
        return float(max(50.0, self.rng.normal(self.mean_teu, std)))

    def build_arrival_plan(
        self,
        vessel_ref: EntityId,
        base_eta: datetime,
        *,
        vessel_length_m: float,
        current_yard_utilisation: float = 0.0,
    ) -> ArrivalPlan:
        cargo_teu = self.sample_cargo_teu()
        delay_hours = self.sample_delay_hours(current_yard_utilisation)
        eta_p50 = base_eta + timedelta(hours=delay_hours)
        uncertainty_hours = 2.0 + delay_hours * 0.3
        eta_p10 = eta_p50 - timedelta(hours=uncertainty_hours)
        eta_p90 = eta_p50 + timedelta(hours=uncertainty_hours)
        required_cranes = max(1, int(round(cargo_teu / 800)))
        turnaround = max(4.0, cargo_teu / (required_cranes * 28 * 2))  # ~28 moves/hr/crane, 2 TEU/move avg
        return ArrivalPlan(
            vessel_ref=vessel_ref,
            eta_p50=eta_p50,
            eta_p10=eta_p10,
            eta_p90=eta_p90,
            cargo_teu=cargo_teu,
            required_berth_length_m=vessel_length_m + 10.0,
            required_crane_count=required_cranes,
            turnaround_hours_estimate=turnaround,
        )
