"""Rail network model (section 21): tracks, sidings, platforms, loading
areas, capacity, train schedules and the arrival/load/unload/departure
cycle."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum

from port4_engine.core.ids import EntityId, IdMixin, new_id


class TrainStatus(StrEnum):
    SCHEDULED = "SCHEDULED"
    APPROACHING = "APPROACHING"
    ARRIVED = "ARRIVED"
    LOADING = "LOADING"
    UNLOADING = "UNLOADING"
    READY_TO_DEPART = "READY_TO_DEPART"
    DEPARTED = "DEPARTED"


@dataclass
class RailWagon(IdMixin):
    id_prefix = "WAGON"

    capacity_teu: float
    id: EntityId = field(default_factory=lambda: new_id("WAGON"))
    containers: list[EntityId] = field(default_factory=list)

    def load(self, container_id: EntityId) -> bool:
        current_teu = len(self.containers)
        if current_teu >= self.capacity_teu:
            return False
        self.containers.append(container_id)
        return True

    def unload_all(self) -> list[EntityId]:
        out = list(self.containers)
        self.containers.clear()
        return out


@dataclass
class Train(IdMixin):
    id_prefix = "TRAIN"

    wagons: list[RailWagon]
    id: EntityId = field(default_factory=lambda: new_id("TRAIN"))
    status: TrainStatus = TrainStatus.SCHEDULED
    scheduled_arrival: datetime | None = None
    actual_arrival: datetime | None = None
    departure_time: datetime | None = None
    assigned_platform: EntityId | None = None

    def total_capacity_teu(self) -> float:
        return sum(w.capacity_teu for w in self.wagons)

    def total_loaded_teu(self) -> float:
        return sum(len(w.containers) for w in self.wagons)

    def load_container(self, container_id: EntityId) -> bool:
        for wagon in self.wagons:
            if wagon.load(container_id):
                return True
        return False


@dataclass
class RailTerminal(IdMixin):
    id_prefix = "RAILTERM"

    name: str
    platforms: int
    loading_tracks: int
    id: EntityId = field(default_factory=lambda: new_id("RAILTERM"))
    occupied_platforms: set[EntityId] = field(default_factory=set)

    def has_free_platform(self) -> bool:
        return len(self.occupied_platforms) < self.platforms

    def assign_platform(self, train_id: EntityId) -> bool:
        if not self.has_free_platform():
            return False
        self.occupied_platforms.add(train_id)
        return True

    def release_platform(self, train_id: EntityId) -> None:
        self.occupied_platforms.discard(train_id)


@dataclass
class RailNetwork(IdMixin):
    id_prefix = "RAILNET"

    id: EntityId = field(default_factory=lambda: new_id("RAILNET"))
    terminals: dict[EntityId, RailTerminal] = field(default_factory=dict)
    trains: dict[EntityId, Train] = field(default_factory=dict)

    def add_terminal(self, terminal: RailTerminal) -> None:
        self.terminals[terminal.id] = terminal

    def schedule_train(self, train: Train) -> None:
        self.trains[train.id] = train

    def total_platform_capacity(self) -> int:
        return sum(t.platforms for t in self.terminals.values())

    def total_platform_utilisation(self) -> float:
        occupied = sum(len(t.occupied_platforms) for t in self.terminals.values())
        cap = self.total_platform_capacity()
        return occupied / cap if cap else 0.0

    def arrive(self, train_id: EntityId, terminal_id: EntityId, when: datetime) -> bool:
        train = self.trains[train_id]
        terminal = self.terminals[terminal_id]
        if not terminal.assign_platform(train_id):
            return False
        train.status = TrainStatus.ARRIVED
        train.actual_arrival = when
        train.assigned_platform = terminal_id
        return True

    def depart(self, train_id: EntityId, when: datetime) -> None:
        train = self.trains[train_id]
        if train.assigned_platform:
            self.terminals[train.assigned_platform].release_platform(train_id)
        train.status = TrainStatus.DEPARTED
        train.departure_time = when
