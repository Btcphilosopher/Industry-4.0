"""DTOs for the Kotlin digital twin (section 42).

    DigitalTwinUpdate(
        timestamp=...,
        entity_id="CRANE_07",
        entity_type="CRANE",
        position=...,
        orientation=...,
        status="ACTIVE",
        animation_state="MOVING_CONTAINER",
    )

Kept as a flat, JSON- and Arrow-friendly Pydantic model so Kotlin (via
whatever wire format the platform standardises on — JSON over WebSocket
for interactive use, Arrow for bulk backfills) can deserialise it with a
matching Kotlin data class without any Python-specific type leaking
through.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field

from port4_engine.core.ids import EntityId
from port4_engine.core.port import Port
from port4_engine.models.geometry import Point


class DigitalTwinUpdate(BaseModel):
    timestamp: datetime
    entity_id: EntityId
    entity_type: str
    position: Point | None = None
    orientation: float | None = None  # degrees, 0..360
    status: str
    animation_state: str = "IDLE"
    extra: dict[str, Any] = Field(default_factory=dict)


_ANIMATION_BY_STATUS = {
    "WORKING": "MOVING_CONTAINER",
    "BERTHING": "MANOEUVRING",
    "BERTHED": "IDLE",
    "LOADING": "LOADING_CONTAINER",
    "UNLOADING": "UNLOADING_CONTAINER",
    "EN_ROUTE": "DRIVING",
    "GATE_QUEUE": "QUEUING",
}


def _entity_update(entity_type: str, entity_id: EntityId, entity: Any, *, timestamp: datetime) -> DigitalTwinUpdate:
    status = str(getattr(entity, "status", "UNKNOWN"))
    position = getattr(entity, "position", None)
    if not isinstance(position, Point):
        position = None
    return DigitalTwinUpdate(
        timestamp=timestamp,
        entity_id=entity_id,
        entity_type=entity_type,
        position=position,
        status=status,
        animation_state=_ANIMATION_BY_STATUS.get(status, "IDLE"),
    )


def to_digital_twin_updates(port: Port, *, timestamp: datetime) -> list[DigitalTwinUpdate]:
    """Snapshot every entity that has a meaningful visual/animation state
    into a flat list of :class:`DigitalTwinUpdate` DTOs, ready to stream to
    Kotlin (see the ``/ws/digital-twin`` endpoint in
    :mod:`port4_engine.api.main`)."""
    updates: list[DigitalTwinUpdate] = []
    for crane_id, crane in port.cranes.items():
        updates.append(_entity_update("CRANE", crane_id, crane, timestamp=timestamp))
    for truck_id, truck in port.trucks.items():
        updates.append(_entity_update("TRUCK", truck_id, truck, timestamp=timestamp))
    for vessel_id, vessel in port.vessels.items():
        updates.append(_entity_update("VESSEL", vessel_id, vessel, timestamp=timestamp))
    return updates
