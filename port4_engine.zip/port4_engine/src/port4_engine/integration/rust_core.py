"""Adapter to the Rust high-performance port core (section 41).

    from port4_engine.integration import RustPortCore
    core = RustPortCore()
    state = core.get_port_state(port_id="example_port")

The real deployment talks to Rust over whatever efficient channel the
platform standardises on (gRPC/shared memory/IPC carrying Arrow/Parquet
payloads for bulk telemetry — never large datasets over JSON, per
section 41). :class:`RustPortCore` here defines that contract as an
abstract transport plus a working in-process ``LocalRustPortCoreStub`` so
the rest of the Python engine, tests and examples can run against it
without a live Rust process; a real deployment supplies a transport
(``grpc_channel=...`` or similar) instead of the stub.
"""

from __future__ import annotations

import io
from dataclasses import dataclass, field
from typing import Any, Protocol

from port4_engine.core.ids import EntityId
from port4_engine.core.port import Port

try:
    import pyarrow as pa
    import pyarrow.parquet as pq

    _HAS_ARROW = True
except ImportError:  # pragma: no cover - exercised only without the `data` extra
    pa = None
    pq = None
    _HAS_ARROW = False


@dataclass
class RustPortState:
    port_id: str
    entity_counts: dict[str, int]
    raw: dict[str, Any] = field(default_factory=dict)


class PortCoreTransport(Protocol):
    def request(self, method: str, payload: dict[str, Any]) -> dict[str, Any]: ...


class LocalRustPortCoreStub:
    """An in-process stand-in for the real Rust transport, backed by
    whichever :class:`~port4_engine.core.port.Port` objects are registered
    with it. Lets the rest of the engine, and integration tests, exercise
    the ``RustPortCore`` contract without a live Rust process."""

    def __init__(self) -> None:
        self._ports: dict[str, Port] = {}

    def register_port(self, port: Port) -> None:
        self._ports[port.port_id] = port

    def request(self, method: str, payload: dict[str, Any]) -> dict[str, Any]:
        port_id = payload.get("port_id")
        port = self._ports.get(port_id) if port_id else None
        if method == "get_port_state":
            if port is None:
                return {"port_id": port_id, "entity_counts": {}, "found": False}
            return {"port_id": port_id, "entity_counts": port.entity_count(), "found": True}
        if method == "get_entity":
            if port is None:
                return {"found": False}
            entity = port.find(payload["entity_id"])
            return {"found": entity is not None, "entity_id": payload["entity_id"]}
        raise ValueError(f"unknown RustPortCore method: {method}")


class RustPortCore:
    """Python-side client for the Rust port core.

    All read paths return data; Python never issues an *execution* command
    to Rust from this client directly — every write path is named
    ``submit_*`` and returns a plan/recommendation acknowledgement, never a
    guarantee of execution, consistent with the engine-wide rule that Rust
    and authorised operational systems alone execute real-world actions.
    """

    def __init__(self, transport: PortCoreTransport | None = None) -> None:
        self.transport = transport or LocalRustPortCoreStub()

    def get_port_state(self, port_id: str) -> RustPortState:
        raw = self.transport.request("get_port_state", {"port_id": port_id})
        return RustPortState(port_id=port_id, entity_counts=raw.get("entity_counts", {}), raw=raw)

    def get_entity(self, port_id: str, entity_id: EntityId) -> dict[str, Any]:
        return self.transport.request("get_entity", {"port_id": port_id, "entity_id": entity_id})

    def submit_schedule(self, port_id: str, schedule_payload: dict[str, Any]) -> dict[str, Any]:
        """Submit an optimised schedule/plan for Rust's operational systems
        to review and, if approved, execute — never executed directly here."""
        return self.transport.request("submit_schedule", {"port_id": port_id, "schedule": schedule_payload})

    # -- efficient bulk telemetry (section 41: prefer Arrow/Parquet over JSON) --
    def encode_telemetry_batch(self, rows: list[dict[str, Any]]) -> bytes:
        if not _HAS_ARROW:
            raise ImportError("pyarrow is required for encode_telemetry_batch(); install port4-engine[data]")
        table = pa.Table.from_pylist(rows)
        sink = io.BytesIO()
        with pq.ParquetWriter(sink, table.schema) as writer:
            writer.write_table(table)
        return sink.getvalue()

    def decode_telemetry_batch(self, data: bytes) -> list[dict[str, Any]]:
        if not _HAS_ARROW:
            raise ImportError("pyarrow is required for decode_telemetry_batch(); install port4-engine[data]")
        table = pq.read_table(io.BytesIO(data))
        return table.to_pylist()
