"""Lightweight geometry value types.

These are deliberately dependency-free (no Shapely requirement) so that the
core data model can be imported without the optional ``geo`` extra. The
:mod:`port4_engine.geospatial` package provides a richer, Shapely-backed
interface for analysis when that extra is installed, and can convert to/from
these plain types.
"""

from __future__ import annotations

import math
from pydantic import BaseModel, Field


class Point(BaseModel):
    """A WGS84 longitude/latitude point (optionally with elevation)."""

    lon: float
    lat: float
    elevation_m: float | None = None

    def distance_to(self, other: "Point") -> float:
        """Great-circle distance in metres (haversine)."""
        r = 6_371_000.0
        p1, p2 = math.radians(self.lat), math.radians(other.lat)
        dphi = math.radians(other.lat - self.lat)
        dlambda = math.radians(other.lon - self.lon)
        a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dlambda / 2) ** 2
        return 2 * r * math.asin(math.sqrt(a))


class BoundingBox(BaseModel):
    min_lon: float
    min_lat: float
    max_lon: float
    max_lat: float

    def contains(self, point: Point) -> bool:
        return self.min_lon <= point.lon <= self.max_lon and self.min_lat <= point.lat <= self.max_lat


class Polygon(BaseModel):
    """A simple closed polygon expressed as an ordered ring of points."""

    points: list[Point] = Field(default_factory=list)

    def bounding_box(self) -> BoundingBox:
        if not self.points:
            raise ValueError("cannot compute bounding box of an empty polygon")
        lons = [p.lon for p in self.points]
        lats = [p.lat for p in self.points]
        return BoundingBox(min_lon=min(lons), min_lat=min(lats), max_lon=max(lons), max_lat=max(lats))

    def centroid(self) -> Point:
        if not self.points:
            raise ValueError("cannot compute centroid of an empty polygon")
        return Point(
            lon=sum(p.lon for p in self.points) / len(self.points),
            lat=sum(p.lat for p in self.points) / len(self.points),
        )
