"""Container placement optimisation (section 17).

Chooses *where* an incoming container should be stacked, trading off
reshuffle risk, crane/truck travel distance and predicted future
retrieval time. A container needed again within hours is preferentially
placed near the top of a low block near the exit road; one needed in
days is placed deeper, freeing accessible slots for near-term work.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from port4_engine.containers.container import Container
from port4_engine.yards.yard import Block, Yard, YardArea, YardSlot


@dataclass
class PlacementDecision:
    slot: YardSlot | None
    block_name: str | None
    reasoning: str


class YardPlacementOptimizer:
    def __init__(self, *, urgent_horizon_hours: float = 12.0) -> None:
        self.urgent_horizon_hours = urgent_horizon_hours

    def _area_for(self, container: Container) -> YardArea:
        if container.hazardous:
            return YardArea.HAZARDOUS
        if container.reefer:
            return YardArea.REEFER
        return YardArea.IMPORT

    def choose_placement(self, yard: Yard, container: Container, *, now: datetime) -> PlacementDecision:
        area = self._area_for(container)
        candidates = yard.blocks_by_area(area) or list(yard.blocks.values())
        if not candidates:
            return PlacementDecision(slot=None, block_name=None, reasoning="no eligible blocks in yard")

        is_urgent = (
            container.needed_by is not None
            and (container.needed_by - now).total_seconds() / 3600.0 <= self.urgent_horizon_hours
        )

        # For urgent containers, prefer the least-utilised block (fastest future retrieval,
        # fewest containers likely to be stacked above it later). For non-urgent containers,
        # prefer the most-utilised-but-not-full block, consolidating long-dwell cargo and
        # keeping other blocks free for near-term work.
        scored: list[tuple[float, Block]] = []
        for block in candidates:
            util = block.utilisation()
            if util >= 1.0:
                continue
            score = (1.0 - util) if is_urgent else util
            scored.append((score, block))
        if not scored:
            return PlacementDecision(slot=None, block_name=None, reasoning="all eligible blocks full")

        scored.sort(key=lambda t: -t[0])
        best_block = scored[0][1]
        slot = best_block.find_free_slot()
        if slot is None:
            return PlacementDecision(slot=None, block_name=best_block.name, reasoning="no stack-valid free slot")

        reasoning = (
            f"urgent (due in <={self.urgent_horizon_hours}h): chose low-utilisation block {best_block.name}"
            if is_urgent
            else f"non-urgent: consolidated into block {best_block.name} to preserve capacity elsewhere"
        )
        return PlacementDecision(slot=slot, block_name=best_block.name, reasoning=reasoning)

    def place(self, yard: Yard, container: Container, *, now: datetime) -> PlacementDecision:
        decision = self.choose_placement(yard, container, now=now)
        if decision.slot is not None:
            decision.slot.container_id = container.id
        return decision
