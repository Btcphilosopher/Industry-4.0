"""Hierarchical yard model (section 16): Yard -> Block -> Bay -> Row -> Tier.

    yard.get_location(block="A", bay=12, row=4, tier=3)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum

from port4_engine.core.ids import EntityId, IdMixin, new_id


class YardArea(StrEnum):
    IMPORT = "IMPORT"
    EXPORT = "EXPORT"
    EMPTY = "EMPTY"
    REEFER = "REEFER"
    HAZARDOUS = "HAZARDOUS"
    GENERAL = "GENERAL"


@dataclass
class YardSlot:
    block: str
    bay: int
    row: int
    tier: int
    container_id: EntityId | None = None

    @property
    def coordinate(self) -> tuple[str, int, int, int]:
        return (self.block, self.bay, self.row, self.tier)

    @property
    def occupied(self) -> bool:
        return self.container_id is not None


@dataclass
class Bay:
    """A bay's slot grid is populated by its owning :class:`Block`, which
    knows the block name each :class:`YardSlot` needs to carry."""

    bay_number: int
    rows: int
    tiers: int
    slots: dict[tuple[int, int], YardSlot] = field(default_factory=dict)

    def occupancy(self) -> int:
        return sum(1 for s in self.slots.values() if s.occupied)

    def capacity(self) -> int:
        return self.rows * self.tiers


@dataclass
class Block(IdMixin):
    id_prefix = "BLOCK"

    name: str
    area: YardArea
    bays_count: int
    rows: int
    max_tier: int
    id: EntityId = field(default_factory=lambda: new_id("BLOCK"))
    bays: dict[int, Bay] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.bays:
            for bay_number in range(1, self.bays_count + 1):
                bay = Bay(bay_number=bay_number, rows=self.rows, tiers=self.max_tier)
                for row in range(1, self.rows + 1):
                    for tier in range(1, self.max_tier + 1):
                        bay.slots[(row, tier)] = YardSlot(block=self.name, bay=bay_number, row=row, tier=tier)
                self.bays[bay_number] = bay

    def capacity(self) -> int:
        return sum(b.capacity() for b in self.bays.values())

    def occupancy(self) -> int:
        return sum(b.occupancy() for b in self.bays.values())

    def utilisation(self) -> float:
        cap = self.capacity()
        return self.occupancy() / cap if cap else 0.0

    def find_free_slot(self, bay_number: int | None = None) -> YardSlot | None:
        """Find a free slot, preferring the lowest tier (stacking should build up, not skip)."""
        bays = [self.bays[bay_number]] if bay_number is not None else self.bays.values()
        best: YardSlot | None = None
        for bay in bays:
            for row in range(1, bay.rows + 1):
                for tier in range(1, bay.tiers + 1):
                    slot = bay.slots[(row, tier)]
                    if slot.occupied:
                        continue
                    # can only place at tier T if tier T-1 in the same row is occupied (or T==1)
                    if tier > 1 and not bay.slots[(row, tier - 1)].occupied:
                        continue
                    if best is None or (slot.bay, slot.tier) < (best.bay, best.tier):
                        best = slot
        return best


@dataclass
class Yard(IdMixin):
    id_prefix = "YARD"

    name: str
    id: EntityId = field(default_factory=lambda: new_id("YARD"))
    blocks: dict[str, Block] = field(default_factory=dict)

    def add_block(self, block: Block) -> None:
        self.blocks[block.name] = block

    def get_location(self, block: str, bay: int, row: int, tier: int) -> YardSlot:
        b = self.blocks[block]
        try:
            return b.bays[bay].slots[(row, tier)]
        except KeyError as exc:
            raise KeyError(f"no such yard location {block}/{bay}/{row}/{tier}") from exc

    def capacity(self) -> int:
        return sum(b.capacity() for b in self.blocks.values())

    def occupancy(self) -> int:
        return sum(b.occupancy() for b in self.blocks.values())

    def utilisation(self) -> float:
        cap = self.capacity()
        return self.occupancy() / cap if cap else 0.0

    def blocks_by_area(self, area: YardArea) -> list[Block]:
        return [b for b in self.blocks.values() if b.area == area]

    def place_container(self, container_id: EntityId, *, area: YardArea, preferred_block: str | None = None) -> YardSlot | None:
        """Place a container into the first free (stack-valid) slot in an area-matching block."""
        candidate_blocks: list[Block]
        if preferred_block and preferred_block in self.blocks:
            candidate_blocks = [self.blocks[preferred_block]]
        else:
            candidate_blocks = sorted(self.blocks_by_area(area), key=lambda b: b.utilisation())
        for block in candidate_blocks:
            slot = block.find_free_slot()
            if slot is not None:
                slot.container_id = container_id
                return slot
        return None

    def remove_container(self, slot: YardSlot) -> int:
        """Remove a container, returning the number of rehandles (containers above it) required."""
        block = self.blocks[slot.block]
        bay = block.bays[slot.bay]
        rehandles = 0
        tier = block.max_tier
        while tier > slot.tier:
            above = bay.slots.get((slot.row, tier))
            if above and above.occupied:
                rehandles += 1
                above.container_id = None
            tier -= 1
        slot.container_id = None
        return rehandles
