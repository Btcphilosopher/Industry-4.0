"""Yard congestion metrics and thresholds (section 18)."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from port4_engine.yards.yard import Yard


class CongestionLevel(StrEnum):
    NORMAL = "NORMAL"
    BUSY = "BUSY"
    CONGESTED = "CONGESTED"
    CRITICAL = "CRITICAL"


DEFAULT_THRESHOLDS: dict[str, float] = {"normal": 0.70, "busy": 0.85, "congested": 0.95}


def classify(utilisation: float, thresholds: dict[str, float] = DEFAULT_THRESHOLDS) -> CongestionLevel:
    if utilisation >= thresholds.get("congested", 0.95):
        return CongestionLevel.CRITICAL
    if utilisation >= thresholds.get("busy", 0.85):
        return CongestionLevel.CONGESTED
    if utilisation >= thresholds.get("normal", 0.70):
        return CongestionLevel.BUSY
    return CongestionLevel.NORMAL


@dataclass
class YardCongestionReport:
    yard_utilisation: float
    block_utilisation: dict[str, float]
    container_density: float
    average_rehandles: float
    average_retrieval_time_hours: float
    level: CongestionLevel


class YardCongestionAnalyzer:
    def __init__(self, thresholds: dict[str, float] | None = None) -> None:
        self.thresholds = thresholds or dict(DEFAULT_THRESHOLDS)

    def analyze(
        self,
        yard: Yard,
        *,
        rehandle_samples: list[int] | None = None,
        retrieval_time_samples_hours: list[float] | None = None,
    ) -> YardCongestionReport:
        util = yard.utilisation()
        block_util = {name: b.utilisation() for name, b in yard.blocks.items()}
        cap = yard.capacity()
        density = yard.occupancy() / cap if cap else 0.0
        avg_rehandles = (sum(rehandle_samples) / len(rehandle_samples)) if rehandle_samples else 0.0
        avg_retrieval = (
            sum(retrieval_time_samples_hours) / len(retrieval_time_samples_hours)
            if retrieval_time_samples_hours
            else 0.0
        )
        return YardCongestionReport(
            yard_utilisation=util,
            block_utilisation=block_util,
            container_density=density,
            average_rehandles=avg_rehandles,
            average_retrieval_time_hours=avg_retrieval,
            level=classify(util, self.thresholds),
        )
