"""Demand forecasting engine (section 34).

Forecasts TEU, vessel arrivals, truck arrivals, rail demand, yard
occupancy and warehouse demand from historical time series, decomposed
into trend + seasonality (+ optional exogenous/calendar effects), with
uncertainty intervals derived from residual variance.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from port4_engine.forecasting.uncertainty import UncertainEstimate


@dataclass
class DemandForecast:
    horizon_index: list[int]
    point_forecast: list[float]
    p10: list[float]
    p50: list[float]
    p90: list[float]

    def at(self, index: int) -> UncertainEstimate:
        i = self.horizon_index.index(index)
        return UncertainEstimate(
            expected_value=self.point_forecast[i], p10=self.p10[i], p50=self.p50[i], p90=self.p90[i]
        )


class DemandForecaster:
    """A lightweight, dependency-free trend + seasonality forecaster.

    Fits a linear trend and a repeating seasonal profile (e.g. period=24
    for hourly data with a daily cycle, or period=7 for daily data with a
    weekly cycle) via ordinary least squares, then forecasts forward with
    a normal-residual uncertainty band. This is deliberately simple and
    explainable — a full ML layer (:mod:`port4_engine.ai`) is offered
    where it demonstrably beats this baseline, never in place of it
    (section 52: "always compare ML models against simple baseline
    models").
    """

    def __init__(self, *, seasonal_period: int = 24) -> None:
        self.seasonal_period = seasonal_period
        self._trend_coef: tuple[float, float] | None = None
        self._seasonal_profile: np.ndarray | None = None
        self._residual_std: float = 0.0

    def fit(self, history: np.ndarray, *, calendar_multipliers: np.ndarray | None = None) -> "DemandForecaster":
        n = len(history)
        if n < self.seasonal_period * 2:
            # not enough data for seasonality; fall back to trend-only
            t = np.arange(n)
            a, b = np.polyfit(t, history, 1) if n >= 2 else (0.0, float(np.mean(history)) if n else 0.0)
            self._trend_coef = (a, b)
            self._seasonal_profile = np.zeros(self.seasonal_period)
            self._residual_std = float(np.std(history - (a * t + b))) if n >= 2 else 0.0
            return self

        t = np.arange(n)
        a, b = np.polyfit(t, history, 1)
        detrended = history - (a * t + b)
        profile = np.array(
            [detrended[i :: self.seasonal_period].mean() for i in range(self.seasonal_period)]
        )
        self._trend_coef = (a, b)
        self._seasonal_profile = profile
        seasonal_component = np.tile(profile, n // self.seasonal_period + 1)[:n]
        residuals = detrended - seasonal_component
        self._residual_std = float(np.std(residuals))
        return self

    def forecast(self, history_length: int, horizon: int, *, z_p10: float = -1.2816, z_p90: float = 1.2816) -> DemandForecast:
        if self._trend_coef is None:
            raise RuntimeError("call fit() before forecast()")
        a, b = self._trend_coef
        profile = self._seasonal_profile if self._seasonal_profile is not None else np.zeros(self.seasonal_period)

        idx = list(range(history_length, history_length + horizon))
        point = []
        for i in idx:
            trend = a * i + b
            seasonal = profile[i % self.seasonal_period]
            point.append(max(0.0, trend + seasonal))

        # uncertainty widens with forecast distance (compounding process uncertainty)
        p10, p50, p90 = [], [], []
        for k, value in enumerate(point):
            growth = 1.0 + 0.05 * k
            spread = self._residual_std * growth
            p10.append(max(0.0, value + z_p10 * spread))
            p50.append(value)
            p90.append(max(0.0, value + z_p90 * spread))

        return DemandForecast(horizon_index=idx, point_forecast=point, p10=p10, p50=p50, p90=p90)

    def forecast_teu(self, historical_teu_series: list[float], horizon_periods: int) -> DemandForecast:
        self.fit(np.asarray(historical_teu_series))
        return self.forecast(len(historical_teu_series), horizon_periods)

    def forecast_vessel_arrivals(self, historical_arrivals_per_period: list[float], horizon_periods: int) -> DemandForecast:
        self.fit(np.asarray(historical_arrivals_per_period))
        return self.forecast(len(historical_arrivals_per_period), horizon_periods)

    def forecast_truck_arrivals(self, historical_truck_counts: list[float], horizon_periods: int) -> DemandForecast:
        self.fit(np.asarray(historical_truck_counts))
        return self.forecast(len(historical_truck_counts), horizon_periods)

    def forecast_rail_demand(self, historical_rail_teu: list[float], horizon_periods: int) -> DemandForecast:
        self.fit(np.asarray(historical_rail_teu))
        return self.forecast(len(historical_rail_teu), horizon_periods)

    def forecast_yard_occupancy(self, historical_occupancy_ratio: list[float], horizon_periods: int) -> DemandForecast:
        self.fit(np.asarray(historical_occupancy_ratio))
        return self.forecast(len(historical_occupancy_ratio), horizon_periods)

    def forecast_warehouse_demand(self, historical_throughput_m3: list[float], horizon_periods: int) -> DemandForecast:
        self.fit(np.asarray(historical_throughput_m3))
        return self.forecast(len(historical_throughput_m3), horizon_periods)
