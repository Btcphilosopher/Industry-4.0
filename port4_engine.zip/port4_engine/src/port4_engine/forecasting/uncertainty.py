"""Uncertainty primitives shared across forecasting, arrivals, maintenance
and Monte Carlo modules (section 50).

Port simulation is not perfectly deterministic: ETAs, cargo volume, crane
cycle time, truck arrivals, weather, equipment reliability, customs and
gate processing all carry real uncertainty. Rather than silently reporting
a point estimate everywhere, quantities that are genuinely uncertain are
represented as :class:`UncertainEstimate` (expected value + P10/P50/P90),
or, for reusable sampling, a light :class:`Distribution` wrapper.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

import numpy as np


@dataclass
class UncertainEstimate:
    expected_value: float
    p10: float
    p50: float
    p90: float

    @property
    def confidence_interval_80(self) -> tuple[float, float]:
        return (self.p10, self.p90)

    @classmethod
    def from_samples(cls, samples: np.ndarray) -> "UncertainEstimate":
        return cls(
            expected_value=float(np.mean(samples)),
            p10=float(np.percentile(samples, 10)),
            p50=float(np.percentile(samples, 50)),
            p90=float(np.percentile(samples, 90)),
        )


DistributionKind = Literal["normal", "lognormal", "exponential", "triangular", "uniform"]


@dataclass
class Distribution:
    """A named parametric distribution that can be sampled deterministically
    given a seeded ``numpy.random.Generator``."""

    kind: DistributionKind
    params: dict[str, float]

    def sample(self, rng: np.random.Generator, size: int = 1) -> np.ndarray:
        if self.kind == "normal":
            return rng.normal(self.params["mean"], self.params["std"], size=size)
        if self.kind == "lognormal":
            return rng.lognormal(self.params["mean"], self.params["sigma"], size=size)
        if self.kind == "exponential":
            return rng.exponential(self.params["scale"], size=size)
        if self.kind == "triangular":
            return rng.triangular(self.params["left"], self.params["mode"], self.params["right"], size=size)
        if self.kind == "uniform":
            return rng.uniform(self.params["low"], self.params["high"], size=size)
        raise ValueError(f"unknown distribution kind: {self.kind}")

    def estimate(self, rng: np.random.Generator, n: int = 5000) -> UncertainEstimate:
        return UncertainEstimate.from_samples(self.sample(rng, size=n))
