"""Congestion forecasting (section 35).

Example::

    CURRENT:  Yard utilisation = 78%
    FORECAST: Tomorrow 14:00 = 91%
    EXPECTED: Critical congestion
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta

from port4_engine.forecasting.demand import DemandForecaster
from port4_engine.yards.congestion import CongestionLevel, classify


@dataclass
class CongestionForecast:
    subsystem: str
    current_utilisation: float
    forecast_time: datetime
    forecast_utilisation: float
    forecast_level: CongestionLevel
    p10_utilisation: float
    p90_utilisation: float


class CongestionForecaster:
    def __init__(self, thresholds: dict[str, float] | None = None) -> None:
        self.thresholds = thresholds or {"normal": 0.70, "busy": 0.85, "congested": 0.95}

    def forecast(
        self,
        subsystem: str,
        historical_utilisation: list[float],
        *,
        now: datetime,
        horizon_hours: float,
        period_hours: float = 1.0,
        seasonal_period: int = 24,
    ) -> CongestionForecast:
        forecaster = DemandForecaster(seasonal_period=seasonal_period)
        periods_ahead = max(1, int(round(horizon_hours / period_hours)))
        demand_forecast = forecaster.forecast_yard_occupancy(historical_utilisation, periods_ahead)

        util = min(1.0, max(0.0, demand_forecast.point_forecast[-1]))
        p10 = min(1.0, max(0.0, demand_forecast.p10[-1]))
        p90 = min(1.0, max(0.0, demand_forecast.p90[-1]))

        return CongestionForecast(
            subsystem=subsystem,
            current_utilisation=historical_utilisation[-1] if historical_utilisation else 0.0,
            forecast_time=now + timedelta(hours=horizon_hours),
            forecast_utilisation=util,
            forecast_level=classify(util, self.thresholds),
            p10_utilisation=p10,
            p90_utilisation=p90,
        )

    def forecast_all(
        self,
        subsystem_histories: dict[str, list[float]],
        *,
        now: datetime,
        horizon_hours: float,
    ) -> list[CongestionForecast]:
        return [
            self.forecast(name, history, now=now, horizon_hours=horizon_hours)
            for name, history in subsystem_histories.items()
        ]
