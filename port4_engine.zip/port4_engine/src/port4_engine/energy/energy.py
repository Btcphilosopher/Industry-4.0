"""Port energy engine (section 37).

Calculates energy usage for cranes, trucks, yard equipment, warehouses,
rail, shore power and lighting, derives kWh/container, kWh/TEU, kWh/vessel
and kWh/day, and optimises energy against throughput (traded off jointly
with everything else in :mod:`port4_engine.optimisation.port_optimizer`).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum

from port4_engine.core.ids import EntityId, IdMixin, new_id


class EnergyAssetType(StrEnum):
    CRANE = "CRANE"
    TRUCK = "TRUCK"
    YARD_EQUIPMENT = "YARD_EQUIPMENT"
    WAREHOUSE = "WAREHOUSE"
    RAIL = "RAIL"
    SHORE_POWER = "SHORE_POWER"
    LIGHTING = "LIGHTING"


@dataclass
class EnergyAsset(IdMixin):
    id_prefix = "ENERGY"

    asset_type: EnergyAssetType
    rated_power_kw: float
    id: EntityId = field(default_factory=lambda: new_id("ENERGY"))
    efficiency: float = 0.9  # 0..1, used by PortHealth.energy_health
    cumulative_kwh: float = 0.0

    def consume(self, kwh: float) -> None:
        self.cumulative_kwh += kwh


@dataclass
class EnergyReport:
    total_kwh: float
    kwh_by_asset_type: dict[str, float]
    kwh_per_teu: float
    kwh_per_container: float
    kwh_per_vessel: float
    kwh_per_day: float


class EnergyEngine:
    def __init__(self, assets: dict[EntityId, EnergyAsset] | None = None) -> None:
        self.assets = assets or {}

    def register(self, asset: EnergyAsset) -> None:
        self.assets[asset.id] = asset

    def record_consumption(self, asset_id: EntityId, kwh: float) -> None:
        self.assets[asset_id].consume(kwh)

    def report(
        self, *, total_teu: float, total_containers: int, total_vessels: int, window_days: float
    ) -> EnergyReport:
        total_kwh = sum(a.cumulative_kwh for a in self.assets.values())
        by_type: dict[str, float] = {}
        for asset in self.assets.values():
            by_type[asset.asset_type.value] = by_type.get(asset.asset_type.value, 0.0) + asset.cumulative_kwh

        return EnergyReport(
            total_kwh=total_kwh,
            kwh_by_asset_type=by_type,
            kwh_per_teu=(total_kwh / total_teu) if total_teu else 0.0,
            kwh_per_container=(total_kwh / total_containers) if total_containers else 0.0,
            kwh_per_vessel=(total_kwh / total_vessels) if total_vessels else 0.0,
            kwh_per_day=(total_kwh / window_days) if window_days else 0.0,
        )

    def energy_efficiency_score(self) -> float:
        """Average asset efficiency, weighted by rated power, used as the
        ``energy_health`` component of :mod:`port4_engine.statistics.health`."""
        assets = list(self.assets.values())
        if not assets:
            return 1.0
        total_power = sum(a.rated_power_kw for a in assets) or 1.0
        return sum(a.efficiency * a.rated_power_kw for a in assets) / total_power

    def optimal_throughput_energy_tradeoff(
        self, throughput_teu_per_hour_options: list[float], energy_kwh_per_teu_at_option: list[float], *, energy_weight: float = 0.3
    ) -> int:
        """Pick the throughput operating point maximising throughput minus a
        weighted energy penalty; a minimal, explainable stand-in for the
        full :class:`~port4_engine.optimisation.port_optimizer.PortOptimizer`
        when only the throughput/energy trade-off is in scope."""
        if len(throughput_teu_per_hour_options) != len(energy_kwh_per_teu_at_option):
            raise ValueError("options and energy_kwh_per_teu_at_option must be the same length")
        scores = [
            t - energy_weight * e for t, e in zip(throughput_teu_per_hour_options, energy_kwh_per_teu_at_option)
        ]
        return int(max(range(len(scores)), key=lambda i: scores[i]))
