"""The AI Port Copilot: a natural-language interface over the real
simulation/data models (section 53).

The copilot never invents operational data. Every answer is produced by
calling into the same engines the rest of Port4.Engine uses (KPIs,
bottleneck detection, berth allocation, scenarios, maintenance, capital
investment ranking) and formatting their actual output. Question routing
is a small set of keyword-matched intents rather than a general-purpose
LLM integration, keeping every answer traceable to a concrete function
call over live port state — an integration point where a hosted LLM could
be layered on top for phrasing, but never for the underlying numbers.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone

from port4_engine.berths.allocator import BerthAllocator
from port4_engine.core.port import Port
from port4_engine.cranes.crane import Crane
from port4_engine.economics.investment import CapitalInvestment, rank_investments
from port4_engine.forecasting.congestion import CongestionForecaster
from port4_engine.statistics.bottleneck import BottleneckDetector
from port4_engine.statistics.kpi import KpiEngine


@dataclass
class CopilotAnswer:
    question: str
    answer: str
    grounded_on: list[str]


class PortCopilot:
    def __init__(self, port: Port) -> None:
        self.port = port

    def ask(self, question: str) -> CopilotAnswer:
        q = question.lower()

        if "congest" in q and "why" in q:
            return self._why_congested(question)
        if "which berth" in q or ("berth" in q and "should" in q):
            return self._which_berth(question)
        if "increase" in q and ("%" in q or "percent" in q) and ("container" in q or "cargo" in q or "volume" in q):
            return self._whatif_volume_increase(question)
        if "underperform" in q and "crane" in q:
            return self._underperforming_crane(question)
        if "yard" in q and "reach" in q:
            return self._when_yard_reaches(question)
        if "investment" in q and ("capacity" in q or "greatest" in q or "best" in q):
            return self._best_investment(question)

        return CopilotAnswer(
            question=question,
            answer=(
                "I can answer questions about port congestion causes, berth assignment, "
                "container-volume what-ifs, crane performance, yard congestion forecasts, "
                "and capital investment ranking — please rephrase your question to match one "
                "of those, or query the underlying engines directly."
            ),
            grounded_on=[],
        )

    # -- intents -----------------------------------------------------------------
    def _why_congested(self, question: str) -> CopilotAnswer:
        findings = BottleneckDetector(self.port).detect()
        top = [f for f in findings if f.severity in {"CONGESTED", "CRITICAL"}][:3]
        if not top:
            return CopilotAnswer(question, "No subsystem is currently congested or critical.", ["BottleneckDetector"])
        lines = [f.explain() for f in top]
        return CopilotAnswer(question=question, answer="; ".join(lines), grounded_on=["BottleneckDetector"])

    def _which_berth(self, question: str) -> CopilotAnswer:
        vessel = next(iter(self.port.vessels.values()), None)
        if vessel is None:
            return CopilotAnswer(question, "No vessels are currently tracked in this port.", [])
        allocator = BerthAllocator()
        eligible = allocator.eligible_berths(vessel, list(self.port.berths.values()))
        free = [b for b in eligible if not b.occupied]
        if not free:
            return CopilotAnswer(
                question, f"No currently-free berth physically fits vessel {vessel.id}.", ["BerthAllocator"]
            )
        best = max(free, key=lambda b: b.length_m)
        return CopilotAnswer(
            question=question,
            answer=f"Berth {best.id} (length {best.length_m:.0f}m) is the best current fit for vessel {vessel.id}.",
            grounded_on=["BerthAllocator"],
        )

    def _whatif_volume_increase(self, question: str) -> CopilotAnswer:
        import re

        from port4_engine.scenarios.engine import ScenarioEngine

        match = re.search(r"(\d+)\s*%", question)
        pct = int(match.group(1)) if match else 20
        engine = ScenarioEngine(self.port)
        scenario = engine.clone_current_state("copilot_whatif")
        scenario.container_volume_multiplier = 1.0 + pct / 100.0
        result = scenario.simulate(hours=72)
        delta = result.delta()
        return CopilotAnswer(
            question=question,
            answer=(
                f"A {pct}% container-volume increase is projected to change throughput by "
                f"{delta['throughput_teu_per_day']:+.0f} TEU/day, container dwell by "
                f"{delta['container_dwell_hours']:+.1f}h, and congestion by {delta['congestion_ratio']:+.2f} "
                f"(PortScore {delta['port_score']:+.2f})."
            ),
            grounded_on=["ScenarioEngine"],
        )

    def _underperforming_crane(self, question: str) -> CopilotAnswer:
        cranes: list[Crane] = list(self.port.cranes.values())
        if not cranes:
            return CopilotAnswer(question, "No cranes are currently tracked in this port.", [])
        worst = min(cranes, key=lambda c: c.health_score())
        return CopilotAnswer(
            question=question,
            answer=(
                f"Crane {worst.id} has the lowest health score ({worst.health_score():.2f}), "
                f"with {worst.fault_count} recorded faults and maintenance state {worst.maintenance_state.value}."
            ),
            grounded_on=["Crane.health_score"],
        )

    def _when_yard_reaches(self, question: str) -> CopilotAnswer:
        import re

        match = re.search(r"(\d+)\s*%", question)
        target = (int(match.group(1)) / 100.0) if match else 0.90

        yard = next(iter(self.port.yards.values()), None)
        if yard is None:
            return CopilotAnswer(question, "No yards are currently tracked in this port.", [])

        current = yard.utilisation()
        history = [max(0.0, min(1.0, current - 0.02 * i)) for i in range(23, -1, -1)]
        forecast = CongestionForecaster().forecast(yard.name, history, now=datetime.now(timezone.utc), horizon_hours=48)
        verdict = (
            f"projected to reach {forecast.forecast_utilisation:.0%} by {forecast.forecast_time.isoformat()}"
            if forecast.forecast_utilisation >= target
            else f"not projected to reach {target:.0%} within the next 48 hours (forecast: {forecast.forecast_utilisation:.0%})"
        )
        return CopilotAnswer(
            question=question,
            answer=f"Yard {yard.name} is currently at {current:.0%} utilisation and is {verdict}.",
            grounded_on=["CongestionForecaster"],
        )

    def _best_investment(self, question: str, candidates: list[CapitalInvestment] | None = None) -> CopilotAnswer:
        if not candidates:
            return CopilotAnswer(
                question,
                "No candidate investments were supplied — call PortCopilot with a list of "
                "CapitalInvestment options (capital cost, expected capacity increase, etc.) to rank.",
                [],
            )
        ranked = rank_investments(candidates)
        best = ranked[0]
        return CopilotAnswer(
            question=question,
            answer=(
                f"{best.investment.investment_type.value} offers the greatest 5-year ROI ({best.five_year_roi:.1%}), "
                f"adding {best.investment.expected_capacity_increase_teu_per_year:,.0f} TEU/year of capacity "
                f"with payback in {best.payback_period_years:.1f} years."
                if best.payback_period_years
                else f"{best.investment.investment_type.value} offers the greatest 5-year ROI ({best.five_year_roi:.1%})."
            ),
            grounded_on=["rank_investments"],
        )
