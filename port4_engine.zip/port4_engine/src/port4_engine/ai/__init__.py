"""Optional ML layer and the natural-language Port Copilot (sections 52-53)."""

from port4_engine.ai.copilot import PortCopilot
from port4_engine.ai.ml import ModelMetadata, BaselineComparison, compare_to_baseline

__all__ = ["PortCopilot", "ModelMetadata", "BaselineComparison", "compare_to_baseline"]
