"""The optional ML layer (section 52).

ML is offered for ETA prediction, container dwell prediction, equipment
failure, congestion prediction, demand forecasting and quality
prediction — but only ever *instead of* a deterministic/statistical
baseline where it demonstrably wins, and always tracked with version,
training data description, features, metrics and a timestamp so a model
in production is auditable.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone

import numpy as np


@dataclass
class ModelMetadata:
    model_name: str
    version: str
    training_data_description: str
    features: list[str]
    metrics: dict[str, float]
    trained_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


@dataclass
class BaselineComparison:
    baseline_mae: float
    candidate_mae: float
    baseline_rmse: float
    candidate_rmse: float
    candidate_wins: bool
    improvement_ratio: float


def _mae(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.mean(np.abs(y_true - y_pred)))


def _rmse(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.sqrt(np.mean((y_true - y_pred) ** 2)))


def compare_to_baseline(
    y_true: np.ndarray, baseline_pred: np.ndarray, candidate_pred: np.ndarray, *, min_improvement: float = 0.05
) -> BaselineComparison:
    """Compare a candidate (ML) model's predictions against a simple
    baseline's on the same held-out data. The candidate is only judged a
    "win" if it beats the baseline by at least ``min_improvement``
    (default 5%) MAE — matching the guiding principle that ML replaces a
    baseline only when it demonstrably, not marginally, outperforms it."""
    baseline_mae, candidate_mae = _mae(y_true, baseline_pred), _mae(y_true, candidate_pred)
    baseline_rmse, candidate_rmse = _rmse(y_true, baseline_pred), _rmse(y_true, candidate_pred)
    improvement_ratio = (baseline_mae - candidate_mae) / baseline_mae if baseline_mae else 0.0
    return BaselineComparison(
        baseline_mae=baseline_mae,
        candidate_mae=candidate_mae,
        baseline_rmse=baseline_rmse,
        candidate_rmse=candidate_rmse,
        candidate_wins=improvement_ratio >= min_improvement,
        improvement_ratio=improvement_ratio,
    )


class LinearBaselineRegressor:
    """A minimal ordinary-least-squares baseline any ETA/dwell/failure ML
    model is expected to beat before it is deployed in the model's place."""

    def __init__(self) -> None:
        self.coef_: np.ndarray | None = None
        self.metadata: ModelMetadata | None = None

    def fit(self, X: np.ndarray, y: np.ndarray, *, feature_names: list[str], description: str) -> "LinearBaselineRegressor":
        X_design = np.column_stack([np.ones(len(X)), X])
        coef, *_ = np.linalg.lstsq(X_design, y, rcond=None)
        self.coef_ = coef
        preds = X_design @ coef
        self.metadata = ModelMetadata(
            model_name="linear_baseline",
            version="1.0.0",
            training_data_description=description,
            features=feature_names,
            metrics={"train_mae": _mae(y, preds), "train_rmse": _rmse(y, preds)},
        )
        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        if self.coef_ is None:
            raise RuntimeError("call fit() before predict()")
        X_design = np.column_stack([np.ones(len(X)), X])
        return X_design @ self.coef_
