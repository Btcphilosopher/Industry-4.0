"""Configuration schema and loader.

Example (see ``configs/example_port.yaml``)::

    port:
      id: example_port
      name: Example Port
      timezone: Europe/London

    simulation:
      timestep_seconds: 1
      random_seed: 42

    operations:
      target_teu_per_day: 10000

    optimisation:
      objective: balanced

A second port authority is onboarded purely through a new file of this
shape plus new asset/geospatial data — never a code change.
"""

from __future__ import annotations

from pathlib import Path
from typing import Literal

import yaml
from pydantic import BaseModel, Field


class PortIdentityConfig(BaseModel):
    id: str
    name: str
    country: str = "unknown"
    timezone: str = "UTC"


class SimulationConfig(BaseModel):
    timestep_seconds: int = 1
    random_seed: int = 42
    speed_multiplier: float = 1.0
    default_horizon_hours: float = 72.0


class OperationsConfig(BaseModel):
    target_teu_per_day: float = 10_000.0
    working_hours_per_day: float = 24.0
    safety_margin_m: float = 10.0
    yard_congestion_thresholds: dict[str, float] = Field(
        default_factory=lambda: {"normal": 0.70, "busy": 0.85, "congested": 0.95}
    )


class OptimisationWeights(BaseModel):
    """Weights for the multi-objective PortScore function (section 32)."""

    throughput: float = 1.0
    vessel_waiting: float = 1.0
    truck_waiting: float = 0.5
    container_dwell: float = 0.5
    energy: float = 0.3
    operating_cost: float = 0.5
    congestion: float = 0.8
    quality: float = 0.4


class OptimisationConfig(BaseModel):
    objective: Literal["throughput", "cost", "balanced", "energy", "custom"] = "balanced"
    algorithm: Literal[
        "greedy", "local_search", "simulated_annealing", "genetic", "particle_swarm", "milp"
    ] = "greedy"
    weights: OptimisationWeights = Field(default_factory=OptimisationWeights)


class EconomicsConfig(BaseModel):
    revenue_per_teu: float = 180.0
    handling_cost_per_teu: float = 95.0
    energy_cost_per_kwh: float = 0.22
    labour_cost_per_hour: float = 45.0
    delay_penalty_per_vessel_hour: float = 1200.0


class PortAuthorityConfig(BaseModel):
    """Root configuration object for a single port authority deployment."""

    port: PortIdentityConfig
    simulation: SimulationConfig = Field(default_factory=SimulationConfig)
    operations: OperationsConfig = Field(default_factory=OperationsConfig)
    optimisation: OptimisationConfig = Field(default_factory=OptimisationConfig)
    economics: EconomicsConfig = Field(default_factory=EconomicsConfig)
    assets_path: str | None = None
    geospatial_path: str | None = None

    @classmethod
    def from_yaml(cls, path: str | Path) -> "PortAuthorityConfig":
        data = yaml.safe_load(Path(path).read_text())
        return cls.model_validate(data)

    def to_yaml(self, path: str | Path) -> None:
        Path(path).write_text(yaml.safe_dump(self.model_dump(mode="json"), sort_keys=False))


def load_config(path: str | Path) -> PortAuthorityConfig:
    return PortAuthorityConfig.from_yaml(path)
