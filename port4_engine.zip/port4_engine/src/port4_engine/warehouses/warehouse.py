"""The Warehouse entity (section 23)."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import time
from enum import StrEnum

from port4_engine.core.ids import EntityId, IdMixin, new_id


class WarehouseOperation(StrEnum):
    STRIPPING = "STRIPPING"  # unloading a container into the warehouse
    STUFFING = "STUFFING"  # loading warehouse goods into a container
    CROSS_DOCKING = "CROSS_DOCKING"
    TEMPORARY_STORAGE = "TEMPORARY_STORAGE"


@dataclass
class Warehouse(IdMixin):
    id_prefix = "WH"

    name: str
    capacity_m3: float
    loading_bays: int
    unloading_bays: int
    processing_rate_units_per_hour: float
    id: EntityId = field(default_factory=lambda: new_id("WH"))
    inventory_m3: float = 0.0
    operating_hours_start: time = time(0, 0)
    operating_hours_end: time = time(23, 59)
    busy_loading_bays: int = 0
    busy_unloading_bays: int = 0

    def is_open(self, when: time) -> bool:
        return self.operating_hours_start <= when <= self.operating_hours_end

    def occupancy_ratio(self) -> float:
        return self.inventory_m3 / self.capacity_m3 if self.capacity_m3 else 0.0

    def can_accept(self, volume_m3: float) -> bool:
        return self.inventory_m3 + volume_m3 <= self.capacity_m3

    def receive(self, volume_m3: float) -> bool:
        if not self.can_accept(volume_m3):
            return False
        self.inventory_m3 += volume_m3
        return True

    def dispatch(self, volume_m3: float) -> bool:
        if volume_m3 > self.inventory_m3:
            return False
        self.inventory_m3 -= volume_m3
        return True

    def free_loading_bay(self) -> bool:
        if self.busy_loading_bays >= self.loading_bays:
            return False
        self.busy_loading_bays += 1
        return True

    def release_loading_bay(self) -> None:
        self.busy_loading_bays = max(0, self.busy_loading_bays - 1)

    def free_unloading_bay(self) -> bool:
        if self.busy_unloading_bays >= self.unloading_bays:
            return False
        self.busy_unloading_bays += 1
        return True

    def release_unloading_bay(self) -> None:
        self.busy_unloading_bays = max(0, self.busy_unloading_bays - 1)
