Place port-authority-specific asset/geospatial datasets here (see configs/example_port.yaml).
