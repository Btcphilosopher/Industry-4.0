Exploratory notebooks go here.
