from __future__ import annotations

import numpy as np
import pytest

from port4_engine.core.state_machine import StateTransitionError
from port4_engine.vessels.arrivals import ArrivalGenerator
from port4_engine.vessels.vessel import Vessel, VesselStatus


def make_vessel(**overrides) -> Vessel:
    defaults = dict(
        imo="IMO1234567",
        name="MV Test",
        length_m=300.0,
        beam_m=45.0,
        draft_m=12.0,
        capacity_teu=8000.0,
    )
    defaults.update(overrides)
    return Vessel(**defaults)


def test_vessel_lifecycle_happy_path():
    v = make_vessel()
    assert v.status == VesselStatus.AT_SEA
    v.transition(VesselStatus.APPROACHING)
    v.transition(VesselStatus.BERTH_WAIT)
    v.transition(VesselStatus.BERTHING)
    v.transition(VesselStatus.BERTHED)
    v.transition(VesselStatus.UNLOADING)
    v.transition(VesselStatus.CARGO_COMPLETE)
    v.transition(VesselStatus.DEPARTING)
    v.transition(VesselStatus.DEPARTED)
    assert v.status == VesselStatus.DEPARTED


def test_vessel_illegal_transition_raises():
    v = make_vessel()
    with pytest.raises(StateTransitionError):
        v.transition(VesselStatus.DEPARTED)


def test_vessel_fits_berth():
    v = make_vessel(length_m=300.0, draft_m=14.0)
    assert v.fits_berth(berth_length_m=320.0, berth_depth_m=16.0, safety_margin_m=10.0)
    assert not v.fits_berth(berth_length_m=305.0, berth_depth_m=16.0, safety_margin_m=10.0)
    assert not v.fits_berth(berth_length_m=320.0, berth_depth_m=13.0, safety_margin_m=10.0)


def test_arrival_generator_is_deterministic_given_seed():
    from datetime import datetime, timezone

    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    gen_a = ArrivalGenerator(np.random.default_rng(7))
    gen_b = ArrivalGenerator(np.random.default_rng(7))

    times_a = gen_a.poisson_arrival_times(start, horizon_hours=48, arrivals_per_day=3)
    times_b = gen_b.poisson_arrival_times(start, horizon_hours=48, arrivals_per_day=3)
    assert times_a == times_b
    assert len(times_a) > 0


def test_arrival_plan_has_sane_uncertainty_ordering():
    from datetime import datetime, timezone

    gen = ArrivalGenerator(np.random.default_rng(1))
    plan = gen.build_arrival_plan("V1", datetime(2026, 1, 1, tzinfo=timezone.utc), vessel_length_m=280.0)
    assert plan.eta_p10 <= plan.eta_p50 <= plan.eta_p90
    assert plan.cargo_teu > 0
    assert plan.required_crane_count >= 1
