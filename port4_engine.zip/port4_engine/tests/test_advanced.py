from __future__ import annotations

import numpy as np
import pytest

from port4_engine.core.validation import ValidationError, validate_crane_lift, validate_truck_load, validate_vessel_berth_fit
from port4_engine.optimisation.capacity_curve import build_capacity_curve
from port4_engine.optimisation.sweep import ParameterSweep
from port4_engine.reports.generator import ReportGenerator
from port4_engine.scenarios.engine import ScenarioEngine
from port4_engine.scenarios.monte_carlo import MonteCarloSimulator
from port4_engine.simulation.calibration import Calibrator, ValidationMetrics


def test_validate_vessel_berth_fit_raises_for_oversized_vessel():
    with pytest.raises(ValidationError):
        validate_vessel_berth_fit(300, 12, 250, 16)


def test_validate_vessel_berth_fit_passes_for_valid_case():
    validate_vessel_berth_fit(250, 12, 300, 16)  # should not raise


def test_validate_crane_lift_rejects_overweight_container():
    with pytest.raises(ValidationError):
        validate_crane_lift(container_weight_kg=70_000, crane_capacity_tonnes=65)


def test_validate_truck_load_rejects_over_capacity():
    with pytest.raises(ValidationError):
        validate_truck_load(load_teu=3.0, truck_capacity_teu=2.0)


def test_monte_carlo_probabilities_are_within_unit_interval(ran_demo_bundle):
    engine = ScenarioEngine(ran_demo_bundle.port)
    scenario = engine.clone_current_state("mc")
    result = MonteCarloSimulator(seed=1).run(scenario, iterations=300, hours=48)
    assert 0.0 <= result.probability_of_congestion <= 1.0
    assert 0.0 <= result.probability_of_delay <= 1.0
    assert result.worst_case_throughput_teu_per_day <= result.expected_throughput_teu_per_day.expected_value + 1e-6


def test_parameter_sweep_returns_one_point_per_value(ran_demo_bundle):
    sweep = ParameterSweep(ran_demo_bundle.port)
    result = sweep.run(parameter="weather_disruption_severity", values=[0.0, 0.3, 0.6], hours=24)
    assert len(result.points) == 3
    assert [p.value for p in result.points] == [0.0, 0.3, 0.6]


def test_capacity_curve_identifies_efficient_region(ran_demo_bundle):
    curve = build_capacity_curve(ran_demo_bundle.port, multipliers=[0.5, 1.0, 1.5, 2.0], hours=24)
    lo, hi = curve.efficient_region
    assert lo <= hi


def test_calibrator_recovers_known_linear_parameter():
    true_a = 3.0
    data = np.array([true_a * x for x in range(1, 10)])

    def model(params: dict[str, float]) -> np.ndarray:
        return np.array([params["a"] * x for x in range(1, 10)])

    result = Calibrator().fit(data, model, initial_parameters={"a": 1.0})
    assert abs(result.calibrated_parameters["a"] - true_a) < 0.05
    assert result.validation.mae < result.initial_validation.mae + 1e-6


def test_validation_metrics_zero_for_perfect_prediction():
    actual = np.array([10.0, 20.0, 30.0])
    metrics = ValidationMetrics.compute(actual, actual)
    assert metrics.mae == 0.0
    assert metrics.rmse == 0.0
    assert metrics.mape == 0.0


def test_report_generator_produces_markdown_and_dict(ran_demo_bundle):
    rg = ReportGenerator(ran_demo_bundle.port)
    report = rg.daily_port_report()
    md = report.to_markdown()
    d = report.to_dict()
    assert "Daily Port Report" in md
    assert d["title"] == "Daily Port Report"

    congestion_report = rg.congestion_report()
    assert "Bottlenecks" in congestion_report.sections
