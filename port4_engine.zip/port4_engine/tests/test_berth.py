from __future__ import annotations

from datetime import datetime, timedelta, timezone

from port4_engine.berths.allocator import BerthAllocator
from port4_engine.berths.berth import Berth
from port4_engine.berths.optimizer import BerthOptimizer
from port4_engine.vessels.vessel import Vessel


def make_berth(length_m=300.0, depth_m=16.0, max_draft=15.0) -> Berth:
    return Berth(length_m=length_m, depth_m=depth_m, maximum_draft_m=max_draft, terminal_id="T1")


def make_vessel(length_m=250.0, draft_m=12.0, eta=None, priority=0) -> Vessel:
    return Vessel(
        imo="IMO1", name="V", length_m=length_m, beam_m=length_m / 7, draft_m=draft_m, capacity_teu=5000.0, eta=eta, priority=priority
    )


def test_allocator_rejects_oversized_vessel():
    allocator = BerthAllocator(safety_margin_m=10.0)
    berth = make_berth(length_m=260.0)
    vessel = make_vessel(length_m=255.0)
    result = allocator.check_fit(vessel, berth)
    assert not result.fits
    assert result.reasons


def test_allocator_accepts_fitting_vessel():
    allocator = BerthAllocator(safety_margin_m=10.0)
    berth = make_berth(length_m=300.0, depth_m=16.0, max_draft=15.0)
    vessel = make_vessel(length_m=250.0, draft_m=12.0)
    assert allocator.check_fit(vessel, berth).fits


def test_berth_optimizer_assigns_all_vessels_when_capacity_allows():
    now = datetime(2026, 1, 1, tzinfo=timezone.utc)
    berths = [make_berth() for _ in range(2)]
    vessels = [make_vessel(eta=now + timedelta(hours=i)) for i in range(2)]
    schedule = BerthOptimizer().optimize(vessels, berths, horizon_hours=72, reference_time=now)
    assert len(schedule.assignments) == 2
    assert not schedule.unassigned_vessel_ids


def test_berth_optimizer_serialises_vessels_onto_single_berth():
    now = datetime(2026, 1, 1, tzinfo=timezone.utc)
    berths = [make_berth()]
    vessels = [make_vessel(eta=now), make_vessel(eta=now)]
    schedule = BerthOptimizer().optimize(vessels, berths, horizon_hours=72, reference_time=now)
    assert len(schedule.assignments) == 2
    starts = sorted(a.start for a in schedule.assignments)
    assert starts[0] < starts[1]  # the second vessel had to wait
    assert schedule.total_waiting_hours() > 0


def test_berth_optimizer_rejects_vessel_with_no_fitting_berth():
    now = datetime(2026, 1, 1, tzinfo=timezone.utc)
    berths = [make_berth(length_m=150.0)]
    vessels = [make_vessel(length_m=250.0, eta=now)]
    schedule = BerthOptimizer().optimize(vessels, berths, horizon_hours=72, reference_time=now)
    assert schedule.unassigned_vessel_ids == [vessels[0].id]
