from __future__ import annotations

from datetime import datetime, timedelta, timezone

from port4_engine.core.ids import reset_counters
from port4_engine.simulation.demo_port import (
    build_demo_port,
    run_demo,
    seed_truck_and_rail_activity,
    seed_vessel_arrivals,
)
from port4_engine.simulation.engine import SimulationEngine
from port4_engine.core.port import Port


def test_engine_processes_events_in_time_order():
    port = Port(port_authority="A", port_id="p1", name="Test")
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    engine = SimulationEngine(port, start_time=start, random_seed=1)

    order: list[int] = []
    engine.schedule_at(start + timedelta(hours=3), lambda: order.append(3))
    engine.schedule_at(start + timedelta(hours=1), lambda: order.append(1))
    engine.schedule_at(start + timedelta(hours=2), lambda: order.append(2))

    engine.run()
    assert order == [1, 2, 3]
    assert engine.clock == start + timedelta(hours=3)


def test_engine_run_until_stops_early():
    port = Port(port_authority="A", port_id="p1", name="Test")
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    engine = SimulationEngine(port, start_time=start, random_seed=1)
    fired: list[int] = []
    engine.schedule_at(start + timedelta(hours=1), lambda: fired.append(1))
    engine.schedule_at(start + timedelta(hours=10), lambda: fired.append(10))
    engine.run(until=start + timedelta(hours=5))
    assert fired == [1]
    assert engine.pending_event_count == 1


def test_engine_reset_clears_queue_and_clock():
    port = Port(port_authority="A", port_id="p1", name="Test")
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    engine = SimulationEngine(port, start_time=start, random_seed=1)
    engine.schedule_at(start + timedelta(hours=1), lambda: None)
    engine.reset()
    assert engine.pending_event_count == 0
    assert engine.clock == start


def test_engine_rejects_scheduling_in_the_past():
    port = Port(port_authority="A", port_id="p1", name="Test")
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    engine = SimulationEngine(port, start_time=start, random_seed=1)
    engine.clock = start + timedelta(hours=5)
    import pytest

    with pytest.raises(ValueError):
        engine.schedule_at(start + timedelta(hours=1), lambda: None)


def test_demo_port_builds_expected_scale():
    reset_counters()
    bundle = build_demo_port(random_seed=42)
    port = bundle.port
    assert len(port.berths) == 4
    assert len(port.cranes) == 8
    yard = next(iter(port.yards.values()))
    assert len(yard.blocks) == 20
    assert len(port.containers) == 1000
    assert len(port.trucks) == 50
    assert port.rail_network is not None and len(port.rail_network.terminals) == 2
    assert len(port.warehouses) == 3
    assert len(port.gates) == 3


def test_run_demo_is_deterministic_given_seed():
    reset_counters()
    bundle_a = run_demo(horizon_hours=24, random_seed=99)
    reset_counters()
    bundle_b = run_demo(horizon_hours=24, random_seed=99)

    assert bundle_a.engine.events_processed == bundle_b.engine.events_processed
    assert len(bundle_a.port.vessels) == len(bundle_b.port.vessels)
    assert len(bundle_a.port.containers) == len(bundle_b.port.containers)
    ids_a = sorted(bundle_a.port.vessels.keys())
    ids_b = sorted(bundle_b.port.vessels.keys())
    assert ids_a == ids_b


def test_run_demo_produces_completed_events():
    bundle = run_demo(horizon_hours=48, random_seed=42)
    assert bundle.engine.events_processed > 0
    assert bundle.engine.pending_event_count == 0
