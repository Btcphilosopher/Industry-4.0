from __future__ import annotations

from fastapi.testclient import TestClient

from port4_engine.api.main import app, get_app_state


def _client() -> TestClient:
    get_app_state().bundle = None  # ensure a clean lazily-built demo port per test module
    return TestClient(app)


def test_port_state_endpoint():
    client = _client()
    resp = client.get("/port/state")
    assert resp.status_code == 200
    body = resp.json()
    assert body["port_id"] == "demo_port"
    assert body["entity_counts"]["berths"] == 4


def test_kpis_endpoint():
    client = _client()
    resp = client.get("/port/kpis")
    assert resp.status_code == 200
    assert "teu_per_hour" in resp.json()


def test_list_endpoints_return_lists():
    client = _client()
    for path in ["/vessels", "/berths", "/containers", "/yards", "/cranes", "/trucks"]:
        resp = client.get(path)
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)


def test_rail_endpoint_structure():
    client = _client()
    resp = client.get("/rail")
    body = resp.json()
    assert "terminals" in body and "trains" in body


def test_optimise_port_endpoint():
    client = _client()
    resp = client.post("/optimise/port", json={"algorithm": "greedy"})
    assert resp.status_code == 200
    body = resp.json()
    assert "decisions" in body and "score" in body


def test_optimise_routes_endpoint():
    client = _client()
    resp = client.post("/optimise/routes", json={"origin": "GATE1", "destination": "MAIN_YARD"})
    assert resp.status_code == 200
    assert resp.json()["path"][0] == "GATE1"


def test_simulate_endpoint_updates_state():
    client = _client()
    resp = client.post("/simulate", json={"horizon_hours": 12, "random_seed": 5})
    assert resp.status_code == 200
    assert "kpis" in resp.json()


def test_scenario_and_compare_endpoints():
    client = _client()
    resp = client.post("/scenario", json={"name": "surge", "container_volume_multiplier": 1.25})
    assert resp.status_code == 200
    assert resp.json()["name"] == "surge"

    compare_resp = client.post("/scenario/compare", json={"names": ["surge"]})
    assert compare_resp.status_code == 200
    assert "surge" in compare_resp.json()


def test_forecast_endpoints():
    client = _client()
    assert client.get("/forecast/demand").status_code == 200
    assert client.get("/forecast/congestion").status_code == 200
    assert client.get("/forecast/yard").status_code == 200


def test_websocket_simulation_stream():
    client = _client()
    with client.websocket_connect("/ws/simulation") as ws:
        message = ws.receive_json()
        assert "clock" in message


def test_websocket_digital_twin_stream():
    client = _client()
    with client.websocket_connect("/ws/digital-twin") as ws:
        message = ws.receive_json()
        assert isinstance(message, list)
