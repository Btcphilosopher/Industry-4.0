from __future__ import annotations

from hypothesis import given, settings
from hypothesis import strategies as st

from port4_engine.berths.allocator import BerthAllocator
from port4_engine.berths.berth import Berth
from port4_engine.vessels.vessel import Vessel
from port4_engine.yards.congestion import CongestionLevel, classify


@given(
    vessel_length=st.floats(min_value=10, max_value=500),
    berth_length=st.floats(min_value=10, max_value=500),
    margin=st.floats(min_value=0, max_value=50),
)
@settings(max_examples=100)
def test_berth_fit_is_consistent_with_arithmetic(vessel_length: float, berth_length: float, margin: float):
    vessel = Vessel(imo="I1", name="V", length_m=vessel_length, beam_m=vessel_length / 7, draft_m=5.0, capacity_teu=1000)
    berth = Berth(length_m=berth_length, depth_m=20.0, maximum_draft_m=20.0, terminal_id="T1")
    result = BerthAllocator(safety_margin_m=margin).check_fit(vessel, berth)
    expected = (vessel_length + margin) <= berth_length
    assert result.fits == expected


@given(utilisation=st.floats(min_value=0.0, max_value=1.0))
@settings(max_examples=200)
def test_congestion_classification_is_monotonic_with_utilisation(utilisation: float):
    level = classify(utilisation)
    # a higher utilisation must never map to a *lower* congestion level
    higher = classify(min(1.0, utilisation + 0.2))
    order = [CongestionLevel.NORMAL, CongestionLevel.BUSY, CongestionLevel.CONGESTED, CongestionLevel.CRITICAL]
    assert order.index(higher) >= order.index(level)


@given(st.lists(st.integers(min_value=-100, max_value=100), min_size=0, max_size=20))
@settings(max_examples=50)
def test_yard_capacity_never_negative_after_operations(values: list[int]):
    from port4_engine.yards.yard import Block, Yard, YardArea

    yard = Yard(name="Y")
    yard.add_block(Block(name="A", area=YardArea.IMPORT, bays_count=2, rows=2, max_tier=2))
    placed = []
    for i, _ in enumerate(values):
        slot = yard.place_container(f"C{i}", area=YardArea.IMPORT)
        if slot is not None:
            placed.append(slot)
    assert yard.occupancy() >= 0
    assert yard.occupancy() <= yard.capacity()
