from __future__ import annotations

from datetime import datetime, timedelta, timezone

from port4_engine.containers.container import Container, IsoType
from port4_engine.yards.congestion import CongestionLevel, YardCongestionAnalyzer, classify
from port4_engine.yards.optimizer import YardPlacementOptimizer
from port4_engine.yards.yard import Block, Yard, YardArea


def make_yard() -> Yard:
    yard = Yard(name="Y1")
    yard.add_block(Block(name="A", area=YardArea.IMPORT, bays_count=3, rows=2, max_tier=3))
    yard.add_block(Block(name="B", area=YardArea.IMPORT, bays_count=3, rows=2, max_tier=3))
    return yard


def test_get_location_returns_expected_slot():
    yard = make_yard()
    slot = yard.get_location(block="A", bay=1, row=1, tier=1)
    assert slot.coordinate == ("A", 1, 1, 1)
    assert not slot.occupied


def test_place_container_respects_stacking_order():
    yard = make_yard()
    slot = yard.place_container("CTR-1", area=YardArea.IMPORT, preferred_block="A")
    assert slot is not None and slot.tier == 1
    slot2 = yard.place_container("CTR-2", area=YardArea.IMPORT, preferred_block="A")
    # second container in the same bay/row must stack on top only if row1/tier1 taken;
    # optimiser fills lowest tier first across rows before stacking up
    assert slot2 is not None


def test_remove_container_computes_rehandles():
    yard = make_yard()
    block = yard.blocks["A"]
    bay = block.bays[1]
    bay.slots[(1, 1)].container_id = "BASE"
    bay.slots[(1, 2)].container_id = "ABOVE"
    slot = yard.get_location("A", 1, 1, 1)
    rehandles = yard.remove_container(slot)
    assert rehandles == 1
    assert not bay.slots[(1, 2)].occupied


def test_congestion_classification_thresholds():
    assert classify(0.5) == CongestionLevel.NORMAL
    assert classify(0.75) == CongestionLevel.BUSY
    assert classify(0.90) == CongestionLevel.CONGESTED
    assert classify(0.99) == CongestionLevel.CRITICAL


def test_congestion_analyzer_reports_block_breakdown():
    yard = make_yard()
    yard.place_container("CTR-1", area=YardArea.IMPORT, preferred_block="A")
    report = YardCongestionAnalyzer().analyze(yard)
    assert "A" in report.block_utilisation
    assert 0 <= report.yard_utilisation <= 1


def test_yard_placement_optimizer_prefers_low_utilisation_for_urgent_cargo():
    yard = make_yard()
    # fill block A halfway
    for _ in range(3):
        yard.place_container(f"FILL-{_}", area=YardArea.IMPORT, preferred_block="A")

    now = datetime(2026, 1, 1, tzinfo=timezone.utc)
    urgent_container = Container(
        container_id="URGENT1",
        iso_type=IsoType.FT20,
        length_ft=20,
        height_ft=8.5,
        weight_kg=5000,
        origin="X",
        destination="Y",
        needed_by=now + timedelta(hours=2),
    )
    decision = YardPlacementOptimizer(urgent_horizon_hours=12).choose_placement(yard, urgent_container, now=now)
    assert decision.slot is not None
    assert decision.block_name == "B"  # less utilised than A
