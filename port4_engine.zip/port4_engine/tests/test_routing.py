from __future__ import annotations

from datetime import datetime, timezone

from port4_engine.gates.gate import Gate
from port4_engine.rail.rail import RailNetwork, RailTerminal, RailWagon, Train, TrainStatus
from port4_engine.routing.graph import PortRoadGraph, RoadEdge
from port4_engine.trucks.routing import TruckRouter
from port4_engine.trucks.truck import Truck
from port4_engine.warehouses.warehouse import Warehouse


def make_graph() -> PortRoadGraph:
    g = PortRoadGraph()
    for n in ["A", "B", "C"]:
        g.add_node(n)
    g.add_edge(RoadEdge(from_node="A", to_node="B", length_m=1000, speed_limit_kmh=30))
    g.add_edge(RoadEdge(from_node="B", to_node="C", length_m=500, speed_limit_kmh=30))
    g.add_edge(RoadEdge(from_node="A", to_node="C", length_m=2000, speed_limit_kmh=60))
    return g


def test_road_graph_shortest_vs_fastest_can_differ():
    g = make_graph()
    shortest = g.route("A", "C", metric="shortest")
    fastest = g.route("A", "C", metric="fastest")
    assert shortest.total_distance_m <= fastest.total_distance_m + 1e-6 or shortest.path != fastest.path


def test_road_graph_congestion_increases_travel_time():
    g = make_graph()
    baseline = g.route("A", "B", metric="fastest").total_time_s
    g.set_congestion("A", "B", 0.9)
    congested = g.route("A", "B", metric="fastest").total_time_s
    assert congested > baseline


def test_truck_router_advances_along_route():
    g = make_graph()
    truck = Truck(capacity_teu=2.0, position="A")
    router = TruckRouter(g)
    result = router.plan_route(truck, "C", metric="shortest")
    assert result.path[0] == "A" and result.path[-1] == "C"
    done = router.advance(truck, seconds=10_000)
    assert done
    assert truck.position == "C"


def test_gate_enqueue_and_serve():
    gate = Gate(name="G1", lanes=2, mean_processing_minutes=3.0, capacity=5)
    assert gate.enqueue("TRUCK-1")
    assert gate.queue_length == 1
    served = gate.serve_next(wait_minutes=2.5)
    assert served == "TRUCK-1"
    assert gate.served_count == 1
    assert gate.avg_queue_minutes == 2.5


def test_gate_erlang_c_wait_grows_with_utilisation():
    gate = Gate(name="G1", lanes=2, mean_processing_minutes=3.0)
    low = gate.erlang_c_wait_minutes(arrival_rate_per_hour=10)
    high = gate.erlang_c_wait_minutes(arrival_rate_per_hour=35)
    assert high > low


def test_rail_network_arrival_and_departure():
    rn = RailNetwork()
    terminal = RailTerminal(name="RT1", platforms=1, loading_tracks=1)
    rn.add_terminal(terminal)
    train = Train(wagons=[RailWagon(capacity_teu=2.0) for _ in range(3)])
    rn.schedule_train(train)

    now = datetime(2026, 1, 1, tzinfo=timezone.utc)
    assert rn.arrive(train.id, terminal.id, now)
    assert train.status == TrainStatus.ARRIVED
    assert train.load_container("CTR-1")
    assert train.total_loaded_teu() == 1

    rn.depart(train.id, now)
    assert train.status == TrainStatus.DEPARTED
    assert terminal.has_free_platform()


def test_warehouse_capacity_and_bays():
    wh = Warehouse(name="WH1", capacity_m3=1000, loading_bays=1, unloading_bays=1, processing_rate_units_per_hour=50)
    assert wh.receive(500)
    assert not wh.receive(600)
    assert wh.free_loading_bay()
    assert not wh.free_loading_bay()
    wh.release_loading_bay()
    assert wh.free_loading_bay()
