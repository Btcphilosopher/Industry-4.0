from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest

from port4_engine.containers.container import Container, ContainerStatus, IsoType
from port4_engine.containers.flow import ContainerFlowEngine
from port4_engine.core.state_machine import StateTransitionError
from port4_engine.events.bus import EventBus
from port4_engine.events.event import EventType


def make_container(**overrides) -> Container:
    defaults = dict(
        container_id="PORT4U1234567",
        iso_type=IsoType.FT40,
        length_ft=40.0,
        height_ft=8.5,
        weight_kg=15000.0,
        origin="A",
        destination="B",
    )
    defaults.update(overrides)
    return Container(**defaults)


def test_container_teu_by_iso_type():
    assert make_container(iso_type=IsoType.FT20).teu == 1.0
    assert make_container(iso_type=IsoType.FT40).teu == 2.0


def test_container_reefer_hazardous_flags_set_from_iso_type():
    c = make_container(iso_type=IsoType.REEFER)
    assert c.reefer
    c2 = make_container(iso_type=IsoType.HAZARDOUS)
    assert c2.hazardous


def test_container_illegal_transition_raises():
    c = make_container()
    with pytest.raises(StateTransitionError):
        c.transition(ContainerStatus.GATE_OUT)


def test_container_flow_engine_emits_events_and_advances_state():
    bus = EventBus()
    flow = ContainerFlowEngine(bus)
    c = make_container()
    now = datetime(2026, 1, 1, tzinfo=timezone.utc)

    c.transition(ContainerStatus.ON_VESSEL)
    flow.discharge(c, now)
    assert c.status == ContainerStatus.DISCHARGING
    flow.move_to_quay(c, now)
    flow.move_to_yard(c, now)
    assert c.status == ContainerStatus.YARD_ARRIVAL
    flow.stack(c, now, ("BLK01", 1, 1, 1))
    assert c.status == ContainerStatus.STACKED

    later = now + timedelta(hours=5)
    flow.retrieve(c, later)
    flow.gate_out(c, later)
    assert c.status == ContainerStatus.DEPARTED

    event_types = {e.event_type for e in bus.log}
    assert EventType.CONTAINER_DISCHARGED in event_types
    assert EventType.CONTAINER_STACKED in event_types
    assert EventType.CONTAINER_GATE_OUT in event_types

    dwell = c.dwell_hours()
    assert dwell is not None and abs(dwell - 5.0) < 1e-6


def test_container_export_reverse_flow():
    bus = EventBus()
    flow = ContainerFlowEngine(bus)
    c = make_container()
    now = datetime(2026, 1, 1, tzinfo=timezone.utc)
    c.transition(ContainerStatus.ON_VESSEL)
    c.transition(ContainerStatus.DISCHARGING)
    c.transition(ContainerStatus.ON_QUAY)
    c.transition(ContainerStatus.IN_TRANSIT)
    c.transition(ContainerStatus.YARD_ARRIVAL)
    c.transition(ContainerStatus.STACKED)

    flow.load_to_vessel(c, now, "VESSEL-X")
    assert c.status == ContainerStatus.ON_VESSEL
    assert c.vessel == "VESSEL-X"
