from __future__ import annotations

from datetime import datetime, timezone

import numpy as np

from port4_engine.cranes.allocator import CraneAllocator
from port4_engine.cranes.crane import Crane, CraneStatus, CraneType
from port4_engine.cranes.productivity import CraneProductivityModel
from port4_engine.models.geometry import Point
from port4_engine.vessels.vessel import Vessel


def make_crane(**overrides) -> Crane:
    defaults = dict(
        crane_type=CraneType.STS, position=Point(lon=0, lat=0), capacity_tonnes=65.0, max_reach_m=60.0, speed_m_per_s=1.2, energy_rate_kw=65.0
    )
    defaults.update(overrides)
    return Crane(**defaults)


def test_productivity_model_moves_per_hour_reasonable():
    model = CraneProductivityModel()
    assert 15 < model.expected_moves_per_hour() < 60


def test_productivity_shift_simulation_deterministic_with_seed():
    model = CraneProductivityModel()
    stats_a = model.simulate_shift(np.random.default_rng(5), hours=8)
    stats_b = model.simulate_shift(np.random.default_rng(5), hours=8)
    assert stats_a == stats_b
    assert stats_a["total_moves"] > 0
    assert stats_a["working_time_hours"] <= 8.01


def test_crane_health_score_degrades_with_faults():
    healthy = make_crane()
    faulty = make_crane(fault_count=5, status=CraneStatus.FAULT)
    assert healthy.health_score() > faulty.health_score()


def test_crane_allocator_selects_healthy_cranes_and_estimates_completion():
    cranes = [make_crane() for _ in range(4)]
    cranes[0].status = CraneStatus.MAINTENANCE
    vessel = Vessel(imo="I1", name="V", length_m=280, beam_m=40, draft_m=13, capacity_teu=6000, current_teu=3000)
    allocation = CraneAllocator().allocate(vessel, cranes, now=datetime.now(timezone.utc))
    assert cranes[0].id not in allocation.crane_ids
    assert allocation.estimated_energy_kwh > 0
    assert allocation.estimated_completion is not None
