from __future__ import annotations

from datetime import datetime, timezone

import pytest

from port4_engine.core.ids import reset_counters
from port4_engine.simulation.demo_port import DemoPortBundle, build_demo_port, run_demo


@pytest.fixture(autouse=True)
def _reset_id_counters():
    reset_counters()
    yield
    reset_counters()


@pytest.fixture
def now() -> datetime:
    return datetime(2026, 1, 1, tzinfo=timezone.utc)


@pytest.fixture
def demo_bundle() -> DemoPortBundle:
    return build_demo_port(random_seed=42)


@pytest.fixture
def ran_demo_bundle() -> DemoPortBundle:
    return run_demo(horizon_hours=24.0, random_seed=42)
