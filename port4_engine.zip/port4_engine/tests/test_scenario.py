from __future__ import annotations

from port4_engine.scenarios.engine import ScenarioEngine


def test_scenario_clone_is_independent_of_live_port(demo_bundle):
    port = demo_bundle.port
    engine = ScenarioEngine(port)
    scenario = engine.clone_current_state("test")
    original_berth_count = len(port.berths)

    scenario.port.berths.clear()
    assert len(port.berths) == original_berth_count  # live port untouched
    assert len(scenario.port.berths) == 0


def test_scenario_cargo_increase_raises_congestion_and_waiting(demo_bundle):
    engine = ScenarioEngine(demo_bundle.port)
    scenario = engine.clone_current_state("plus50")
    scenario.container_volume = 1.5
    result = scenario.simulate(hours=72)
    delta = result.delta()
    assert delta["container_dwell_hours"] >= 0
    assert delta["congestion_ratio"] >= 0


def test_scenario_crane_failure_reduces_throughput(demo_bundle):
    engine = ScenarioEngine(demo_bundle.port)
    baseline_scenario = engine.clone_current_state("baseline")
    baseline_result = baseline_scenario.simulate(hours=72)

    failure_scenario = engine.clone_current_state("crane_failure")
    crane_id = next(iter(failure_scenario.port.cranes.keys()))
    failure_scenario.disable_crane(crane_id)
    failure_result = failure_scenario.simulate(hours=72)

    assert failure_result.projected_inputs.throughput_teu_per_day <= baseline_result.projected_inputs.throughput_teu_per_day


def test_scenario_rail_closure_increases_dwell(demo_bundle):
    engine = ScenarioEngine(demo_bundle.port)
    open_scenario = engine.clone_current_state("rail_open")
    open_result = open_scenario.simulate(hours=72)

    closed_scenario = engine.clone_current_state("rail_closed")
    closed_scenario.close_rail()
    closed_result = closed_scenario.simulate(hours=72)

    assert closed_result.projected_inputs.container_dwell_hours >= open_result.projected_inputs.container_dwell_hours


def test_scenario_engine_compare_many(demo_bundle):
    engine = ScenarioEngine(demo_bundle.port)
    results = {}
    for name, mult in [("base", 1.0), ("surge", 1.3)]:
        sc = engine.clone_current_state(name)
        sc.container_volume = mult
        results[name] = sc.simulate(hours=48)
    comparison = engine.compare_many(results)
    assert set(comparison.keys()) == {"base", "surge"}
