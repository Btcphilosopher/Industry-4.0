from __future__ import annotations

from datetime import datetime, timedelta, timezone

from port4_engine.economics.economics import EconomicsInputs, PortEconomics
from port4_engine.economics.investment import CapitalInvestment, InvestmentType, evaluate_investment, rank_investments
from port4_engine.energy.energy import EnergyAsset, EnergyAssetType, EnergyEngine
from port4_engine.maintenance.health import AssetHealthModel, EquipmentReading


def test_port_economics_margin_and_per_teu_metrics():
    econ = PortEconomics().evaluate(
        EconomicsInputs(
            teu_handled=10000, revenue_per_teu=180, handling_cost_per_teu=95, energy_cost=5000,
            labour_cost=20000, maintenance_cost=3000, equipment_cost=2000, congestion_delay_cost=1000,
        )
    )
    assert econ.revenue == 1_800_000
    assert econ.operating_margin > 0
    assert econ.cost_per_teu > 0
    assert econ.revenue_per_teu == 180.0


def test_port_economics_zero_teu_does_not_divide_by_zero():
    econ = PortEconomics().evaluate(
        EconomicsInputs(
            teu_handled=0, revenue_per_teu=180, handling_cost_per_teu=95, energy_cost=0,
            labour_cost=0, maintenance_cost=0, equipment_cost=0, congestion_delay_cost=0,
        )
    )
    assert econ.cost_per_teu == 0.0
    assert econ.revenue_per_teu == 0.0


def test_investment_ranking_prefers_higher_roi():
    small = CapitalInvestment(
        investment_type=InvestmentType.NEW_GATE, capital_cost=1_000_000, expected_capacity_increase_teu_per_year=20000,
        expected_annual_operating_cost_delta=50000, expected_annual_energy_delta_kwh=10000,
        expected_congestion_reduction_ratio=0.05, revenue_per_teu=180,
    )
    big = CapitalInvestment(
        investment_type=InvestmentType.NEW_BERTH, capital_cost=50_000_000, expected_capacity_increase_teu_per_year=500000,
        expected_annual_operating_cost_delta=2_000_000, expected_annual_energy_delta_kwh=1_000_000,
        expected_congestion_reduction_ratio=0.2, revenue_per_teu=180,
    )
    ranked = rank_investments([small, big])
    assert ranked[0].five_year_roi >= ranked[1].five_year_roi


def test_energy_engine_reports_per_teu_and_per_container():
    engine = EnergyEngine()
    crane_asset = EnergyAsset(asset_type=EnergyAssetType.CRANE, rated_power_kw=65, efficiency=0.9)
    engine.register(crane_asset)
    engine.record_consumption(crane_asset.id, 1000.0)
    report = engine.report(total_teu=500, total_containers=250, total_vessels=5, window_days=1)
    assert report.total_kwh == 1000.0
    assert report.kwh_per_teu == 2.0
    assert report.kwh_per_container == 4.0


def test_asset_health_model_priority_increases_with_hours_and_faults():
    model = AssetHealthModel(characteristic_life_hours=8000)
    now = datetime(2026, 1, 1, tzinfo=timezone.utc)
    fresh = model.evaluate("A1", EquipmentReading(operating_hours=100, cycles=1000, temperature_c=30, energy_kwh=100, fault_count=0), now=now)
    worn = model.evaluate("A2", EquipmentReading(operating_hours=9000, cycles=100000, temperature_c=60, energy_kwh=50000, fault_count=6), now=now)
    assert worn.maintenance_priority > fresh.maintenance_priority
    assert worn.health_score < fresh.health_score
    assert 0 <= worn.failure_probability_30d <= 1
