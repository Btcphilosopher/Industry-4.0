from __future__ import annotations

import time

from port4_engine.core.ids import reset_counters
from port4_engine.simulation.demo_port import run_demo


def test_seven_day_demo_runs_within_time_budget():
    """The discrete-event engine should process a full 7-day demo port
    simulation in well under a wall-clock second per simulated day (event
    scheduling, not brute-force per-tick evaluation — see section 26)."""
    reset_counters()
    start = time.perf_counter()
    bundle = run_demo(horizon_hours=168.0, random_seed=11)
    elapsed = time.perf_counter() - start

    assert bundle.engine.events_processed > 0
    assert elapsed < 30.0, f"7-day demo simulation took too long: {elapsed:.2f}s"
