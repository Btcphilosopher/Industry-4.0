from __future__ import annotations

from datetime import datetime, timezone

import numpy as np

from port4_engine.forecasting.congestion import CongestionForecaster
from port4_engine.forecasting.demand import DemandForecaster
from port4_engine.forecasting.uncertainty import Distribution, UncertainEstimate
from port4_engine.yards.congestion import CongestionLevel


def test_demand_forecaster_extrapolates_upward_trend():
    history = [100 + 2 * i for i in range(60)]
    forecaster = DemandForecaster(seasonal_period=24)
    forecast = forecaster.forecast_teu(history, horizon_periods=10)
    assert forecast.point_forecast[-1] > history[-1]
    assert all(p10 <= p50 <= p90 for p10, p50, p90 in zip(forecast.p10, forecast.p50, forecast.p90))


def test_demand_forecaster_handles_short_history_without_seasonality():
    forecaster = DemandForecaster(seasonal_period=24)
    forecast = forecaster.forecast_teu([10.0, 12.0, 11.0], horizon_periods=3)
    assert len(forecast.point_forecast) == 3


def test_congestion_forecaster_classifies_high_utilisation_as_severe():
    now = datetime(2026, 1, 1, tzinfo=timezone.utc)
    history = [0.5 + 0.02 * i for i in range(48)]  # trending toward >0.9
    result = CongestionForecaster().forecast("yard", history, now=now, horizon_hours=24)
    assert result.forecast_level in {CongestionLevel.CONGESTED, CongestionLevel.CRITICAL, CongestionLevel.BUSY}


def test_uncertain_estimate_from_samples_orders_percentiles():
    samples = np.random.default_rng(1).normal(50, 5, size=10000)
    estimate = UncertainEstimate.from_samples(samples)
    assert estimate.p10 < estimate.p50 < estimate.p90


def test_distribution_sampling_is_seed_deterministic():
    dist = Distribution(kind="lognormal", params={"mean": 1.0, "sigma": 0.3})
    a = dist.sample(np.random.default_rng(3), size=100)
    b = dist.sample(np.random.default_rng(3), size=100)
    assert np.allclose(a, b)
