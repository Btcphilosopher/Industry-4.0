from __future__ import annotations

import numpy as np

from port4_engine.optimisation.algorithms import (
    genetic_search,
    greedy_search,
    linear_program,
    local_search,
    particle_swarm,
    simulated_annealing,
)
from port4_engine.optimisation.objective import PortScore, PortScoreInputs
from port4_engine.optimisation.port_optimizer import PortOptimizer


def test_port_score_rewards_throughput_and_penalises_waiting():
    score = PortScore()
    good = PortScoreInputs(
        throughput_teu_per_day=15000, vessel_waiting_hours=2, truck_waiting_minutes=5,
        container_dwell_hours=20, energy_kwh=50000, operating_cost=200000, congestion_ratio=0.2, quality_score=0.95,
    )
    bad = PortScoreInputs(
        throughput_teu_per_day=3000, vessel_waiting_hours=40, truck_waiting_minutes=90,
        container_dwell_hours=150, energy_kwh=300000, operating_cost=800000, congestion_ratio=0.95, quality_score=0.6,
    )
    assert score.evaluate(good) > score.evaluate(bad)


def test_port_score_component_breakdown_sums_close_to_total():
    score = PortScore()
    x = PortScoreInputs(
        throughput_teu_per_day=10000, vessel_waiting_hours=10, truck_waiting_minutes=20,
        container_dwell_hours=40, energy_kwh=100000, operating_cost=400000, congestion_ratio=0.5, quality_score=0.8,
    )
    breakdown = score.component_breakdown(x)
    assert abs(sum(breakdown.values()) - score.evaluate(x)) < 1e-9


def test_greedy_search_selects_positive_contributors():
    candidates = [1, -5, 3, 2, -1]

    def score_fn(selected: list[int]) -> float:
        return sum(selected)

    result = greedy_search(candidates, score_fn)
    assert set(result.solution) == {1, 3, 2}


def test_local_search_improves_on_initial_solution():
    def score_fn(x: list[int]) -> float:
        return -abs(sum(x) - 10)

    def neighbours(x: list[int]) -> list[list[int]]:
        return [x[:-1] + [x[-1] + delta] for delta in (-1, 1)]

    result = local_search([0], score_fn, neighbours, max_iterations=50)
    assert result.score >= -1


def test_simulated_annealing_finds_near_optimum_of_simple_quadratic():
    def score_fn(x: np.ndarray) -> float:
        return -float((x[0] - 3.0) ** 2)

    result = simulated_annealing(score_fn, [(-10, 10)], rng=np.random.default_rng(0), iterations=1000)
    assert abs(result.solution[0] - 3.0) < 1.0


def test_particle_swarm_finds_near_optimum_of_simple_quadratic():
    def score_fn(x: np.ndarray) -> float:
        return -float((x[0] - 3.0) ** 2 + (x[1] + 2.0) ** 2)

    result = particle_swarm(score_fn, [(-10, 10), (-10, 10)], rng=np.random.default_rng(0), iterations=60)
    assert abs(result.solution[0] - 3.0) < 1.5
    assert abs(result.solution[1] + 2.0) < 1.5


def test_genetic_search_finds_near_optimum():
    def score_fn(x: np.ndarray) -> float:
        return -float((x[0] - 1.5) ** 2)

    result = genetic_search(score_fn, [(-5, 5)], seed=0, max_iterations=30)
    assert abs(result.solution[0] - 1.5) < 0.5


def test_linear_program_minimises_correctly():
    # minimise -x - 2y subject to x + y <= 4, x,y >=0 -> optimum at (0,4), score=8
    result = linear_program(c=np.array([-1.0, -2.0]), A_ub=np.array([[1.0, 1.0]]), b_ub=np.array([4.0]), bounds=[(0, None), (0, None)])
    assert abs(result.score - 8.0) < 1e-6


def test_port_optimizer_returns_valid_decisions(demo_bundle):
    result = PortOptimizer().optimize(demo_bundle.port, algorithm="greedy")
    assert all(0.0 <= v <= 1.0 for v in result.decisions.values())
    assert isinstance(result.score, float)


def test_port_optimizer_pareto_frontier_nonempty(demo_bundle):
    optimizer = PortOptimizer()
    frontier = optimizer.pareto_frontier(demo_bundle.port, n_samples=40)
    assert len(frontier) >= 1
