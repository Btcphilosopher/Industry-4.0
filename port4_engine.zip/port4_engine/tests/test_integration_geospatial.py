from __future__ import annotations

from datetime import datetime, timezone

from port4_engine.geospatial.client import PortGeometryClient, capabilities
from port4_engine.integration.kotlin_dto import to_digital_twin_updates
from port4_engine.integration.rust_core import LocalRustPortCoreStub, RustPortCore
from port4_engine.models.geometry import Point, Polygon
from port4_engine.telemetry.telemetry import LiveStateReconciler


def test_geospatial_capabilities_reports_availability():
    caps = capabilities()
    assert isinstance(caps.shapely_available, bool)


def test_port_geometry_client_reads_asset_positions(demo_bundle):
    client = PortGeometryClient(demo_bundle.port)
    positions = client.asset_positions()
    assert len(positions) == len(demo_bundle.port.cranes)


def test_port_geometry_bounding_box_containment():
    boundary = Polygon(points=[Point(lon=0, lat=0), Point(lon=0, lat=10), Point(lon=10, lat=10), Point(lon=10, lat=0)])
    box = boundary.bounding_box()
    assert box.contains(Point(lon=5, lat=5))
    assert not box.contains(Point(lon=50, lat=50))


def test_rust_core_stub_round_trip(demo_bundle):
    stub = LocalRustPortCoreStub()
    stub.register_port(demo_bundle.port)
    core = RustPortCore(transport=stub)
    state = core.get_port_state(demo_bundle.port.port_id)
    assert state.entity_counts["cranes"] == len(demo_bundle.port.cranes)


def test_rust_core_unknown_port_returns_not_found():
    core = RustPortCore(transport=LocalRustPortCoreStub())
    state = core.get_port_state("unknown_port")
    assert state.raw["found"] is False


def test_kotlin_dto_updates_carry_entity_ids(demo_bundle):
    updates = to_digital_twin_updates(demo_bundle.port, timestamp=datetime.now(timezone.utc))
    entity_ids = {u.entity_id for u in updates}
    assert set(demo_bundle.port.cranes.keys()).issubset(entity_ids)


def test_telemetry_reconciler_detects_divergence(demo_bundle):
    reconciler = LiveStateReconciler(demo_bundle.port)
    crane_id = next(iter(demo_bundle.port.cranes.keys()))
    snapshot = reconciler.observe({crane_id: {"status": "FAULT"}}, received_at=datetime.now(timezone.utc))
    assert crane_id in snapshot.divergences


def test_telemetry_reconciler_authorised_update_mutates_entity(demo_bundle):
    reconciler = LiveStateReconciler(demo_bundle.port)
    crane_id = next(iter(demo_bundle.port.cranes.keys()))
    assert reconciler.apply_authorised_update(crane_id, {"fault_count": 3}, authorised_by="operator")
    assert demo_bundle.port.cranes[crane_id].fault_count == 3
