"""Benchmark the discrete-event simulation engine across horizons (section 59).

    python benchmarks/bench_simulation.py

Reports wall-clock time and events/second for 24h/168h/720h demo runs, to
make explicit which workloads stay comfortably in Python (event
scheduling, optimisation, forecasting — all sub-second to low-single-digit
seconds here) versus where a real deployment would hand off to Rust
(bulk per-tick telemetry processing, spatial indexing, anything below
millisecond latency budgets) rather than duplicating that work in Python.
"""

from __future__ import annotations

import time

from port4_engine.core.ids import reset_counters
from port4_engine.simulation.demo_port import run_demo

HORIZONS_HOURS = [24.0, 168.0, 720.0]


def main() -> None:
    print(f"{'horizon (h)':>12s} {'wall time (s)':>15s} {'events':>10s} {'events/s':>12s}")
    for horizon in HORIZONS_HOURS:
        reset_counters()
        start = time.perf_counter()
        bundle = run_demo(horizon_hours=horizon, random_seed=42)
        elapsed = time.perf_counter() - start
        events = bundle.engine.events_processed
        rate = events / elapsed if elapsed else float("inf")
        print(f"{horizon:12.0f} {elapsed:15.3f} {events:10d} {rate:12.1f}")


if __name__ == "__main__":
    main()
