"""Compare an unoptimised baseline port against the PortOptimizer's
recommended operating point (section 62).

    python examples/run_optimisation_comparison.py

Runs the demonstration port, then compares:
  - the "baseline" operating point (today's KPIs, decision vector left at
    its naive default)
  - the optimiser's recommended decision vector

across throughput, vessel turnaround (via waiting hours), yard congestion,
energy and operating cost.
"""

from __future__ import annotations

from port4_engine.optimisation.objective import PortScore
from port4_engine.optimisation.port_optimizer import PortOptimizer, surrogate_kpis, baseline_inputs_from_port
from port4_engine.simulation.demo_port import run_demo
import numpy as np


def main() -> None:
    bundle = run_demo(horizon_hours=72.0, random_seed=42)
    port = bundle.port

    baseline = baseline_inputs_from_port(port, window_hours=72.0)
    naive_decision = np.array([0.3, 0.3, 0.3, 0.3])  # an unoptimised, low-effort operating point
    naive_kpis = surrogate_kpis(port, naive_decision, baseline)

    optimizer = PortOptimizer()
    result = optimizer.optimize(port, algorithm="genetic", window_hours=72.0)
    score_fn = PortScore()

    print("PORT4.ENGINE — UNOPTIMISED vs OPTIMISED PORT")
    print("=" * 60)
    print(f"{'metric':32s} {'unoptimised':>14s} {'optimised':>14s}")
    rows = [
        ("throughput (TEU/day)", naive_kpis.throughput_teu_per_day, result.predicted_kpis.throughput_teu_per_day),
        ("vessel waiting (h)", naive_kpis.vessel_waiting_hours, result.predicted_kpis.vessel_waiting_hours),
        ("truck waiting (min)", naive_kpis.truck_waiting_minutes, result.predicted_kpis.truck_waiting_minutes),
        ("container dwell (h)", naive_kpis.container_dwell_hours, result.predicted_kpis.container_dwell_hours),
        ("energy (kWh)", naive_kpis.energy_kwh, result.predicted_kpis.energy_kwh),
        ("operating cost", naive_kpis.operating_cost, result.predicted_kpis.operating_cost),
        ("congestion ratio", naive_kpis.congestion_ratio, result.predicted_kpis.congestion_ratio),
    ]
    for name, before, after in rows:
        print(f"{name:32s} {before:14.2f} {after:14.2f}")

    print("-" * 60)
    print(f"{'PortScore':32s} {score_fn.evaluate(naive_kpis):14.3f} {score_fn.evaluate(result.predicted_kpis):14.3f}")
    print()
    print(f"Optimiser: {result.algorithm}, decisions: {result.decisions}")


if __name__ == "__main__":
    main()
