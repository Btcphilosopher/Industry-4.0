"""Run the PORT 4.0 demonstration port for a chosen horizon and print KPIs.

    python examples/run_demo.py --hours 24
    python examples/run_demo.py --hours 168   # 7 days
    python examples/run_demo.py --hours 720   # 30 days

Equivalent to the ``port4-demo`` console script installed by the package.
"""

from __future__ import annotations

from port4_engine.simulation.demo_port import main

if __name__ == "__main__":
    main()
