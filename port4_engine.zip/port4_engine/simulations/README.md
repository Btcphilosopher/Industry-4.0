Simulation run outputs land here (gitignored by default).
