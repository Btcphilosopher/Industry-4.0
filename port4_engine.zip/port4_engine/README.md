# Port4.Engine

**The Python intelligence and simulation engine for PORT 4.0** — a reusable
operating system and digital-twin platform for port authorities.

Port4.Engine is the middle tier of the PORT 4.0 stack:

```
KOTLIN   — digital twin, animation, dashboard, geospatial visualisation
   ↕
RUST     — high-performance port core, telemetry, events, spatial indexing
   ↕
PYTHON   — simulation, optimisation, forecasting, AI      ←  this package
   ↕
POSTGRESQL / POSTGIS — authoritative port data
```

Python never bypasses safety-critical control. It **observes** state,
**models** it, **simulates**, **optimises**, **validates** and
**recommends** — producing plans, predictions, recommendations, optimised
schedules and scenario results. Rust and other authorised operational
systems remain responsible for executing real-world actions.

```
OBSERVE → MODEL → SIMULATE → OPTIMISE → VALIDATE → RECOMMEND → EXECUTE → OBSERVE AGAIN
```

## Five capabilities

1. **Digital-twin simulation** — a discrete-event engine (`port4_engine.simulation`)
   covering vessels, berths, cranes, containers, yards, trucks, rail,
   warehouses and gates.
2. **Port operations optimisation** — berth scheduling, crane allocation,
   yard placement, routing, and a joint port-wide optimiser with pluggable
   algorithms (`port4_engine.optimisation`).
3. **Forecasting & prediction** — demand and congestion forecasting with
   explicit P10/P50/P90 uncertainty (`port4_engine.forecasting`).
4. **Scenario / what-if analysis** — clone the port, perturb it, simulate,
   compare, and run Monte Carlo analysis (`port4_engine.scenarios`).
5. **Economic & energy modelling** — cost/revenue/margin, capital
   investment ranking, and kWh/TEU energy accounting
   (`port4_engine.economics`, `port4_engine.energy`).

## Install

```bash
pip install -e ".[dev]"          # core + test tooling
pip install -e ".[dev,geo,data,ml]"  # + Shapely/GeoPandas/PyProj, Arrow/Parquet, scikit-learn
```

Requires Python 3.12+.

## Quick start

Run the demonstration port (4 berths, 8 STS cranes, 20 yard blocks,
1000+ pre-loaded containers, 50 trucks, 2 rail terminals, 3 warehouses,
3 gates — see `port4_engine.simulation.demo_port`):

```bash
python -m port4_engine.simulation.demo_port --hours 24
# or, once installed:
port4-demo --hours 168   # 7 days
```

Compare an unoptimised operating point against the port-wide optimiser's
recommendation:

```bash
python examples/run_optimisation_comparison.py
```

Serve the API:

```bash
uvicorn port4_engine.api.main:app --reload
```

then, e.g.:

```bash
curl localhost:8000/port/state
curl localhost:8000/port/kpis
curl -X POST localhost:8000/optimise/port -d '{"algorithm":"genetic"}' -H 'content-type: application/json'
```

## Configuration-driven, multi-tenant by design

Onboarding a second port authority requires a **new configuration file**
(`configs/example_port.yaml`), new geospatial data and new asset data —
never a rewritten codebase:

```python
from port4_engine.configuration import load_config
config = load_config("configs/example_port.yaml")
```

## Project layout

```
src/port4_engine/
├── core/            canonical Port data model, IDs, state machines, validation
├── models/          shared geometry value types
├── simulation/       discrete-event engine, demo port, calibration/validation
├── vessels/          Vessel entity, arrival generation
├── berths/            Berth entity, fit checking, scheduling optimisation
├── cranes/            Crane entity, productivity model, allocation
├── containers/        Container entity, state machine, flow engine
├── yards/             hierarchical Yard→Block→Bay→Row→Tier, placement, congestion
├── trucks/            Truck entity, routing
├── rail/              RailNetwork, Train, RailWagon, RailTerminal
├── warehouses/        Warehouse entity
├── gates/             Gate entity, queueing
├── routing/           shared port road graph (NetworkX-backed)
├── scheduling/        consolidated PortSchedule
├── optimisation/      PortScore, pluggable algorithms, PortOptimizer, sweeps, capacity curve
├── forecasting/       demand/congestion forecasting, uncertainty primitives
├── maintenance/       equipment health / failure-probability model
├── energy/            energy accounting
├── economics/         PortEconomics, capital investment evaluation
├── geospatial/        PortGeometryClient (Shapely/GeoPandas/PyProj optional)
├── scenarios/         Scenario, ScenarioEngine, Monte Carlo
├── telemetry/         LIVE-mode digital-twin reconciliation
├── events/            PortEvent, EventBus
├── statistics/        KPI engine, bottleneck detection, PortHealth
├── ai/                PortCopilot, ML baseline-comparison layer
├── integration/       RustPortCore adapter, Kotlin DigitalTwinUpdate DTOs
├── configuration/     PortAuthorityConfig (YAML-driven)
├── reports/           machine- and human-readable report generation
└── api/               FastAPI REST + WebSocket application

tests/        pytest suite (unit, integration, simulation, property-based, performance)
simulations/  simulation run outputs
configs/      port-authority configuration files
datasets/     port-authority asset/geospatial data
notebooks/    exploratory notebooks
benchmarks/   performance benchmarks
examples/     runnable example scripts
```

## Determinism

Every stochastic component (vessel arrivals, crane cycle times, Monte
Carlo sampling) is driven by a seeded `numpy.random.Generator`. Given the
same `random_seed`, `port4_engine.simulation.demo_port.run_demo(...)`
produces an identical event count, entity population and entity IDs run
to run — see `tests/test_simulation.py::test_run_demo_is_deterministic_given_seed`.

## Testing

```bash
pytest                 # full suite (unit, integration, simulation, property-based, performance)
pytest -k optimisation # a subset
```

## Design notes / known simplifications

This is a complete, working reference implementation of the full PORT 4.0
Python engine surface — every module in the specification is implemented
with real logic (not stubs), and the demonstration port actually runs
end-to-end discrete-event simulation, optimisation, forecasting, scenario
analysis and reporting. A few things are worth knowing before treating any
number as production-calibrated:

- **The port-wide optimiser (`PortOptimizer`) and scenario engine
  (`Scenario.simulate`) use a fast analytic surrogate model**, not a full
  re-run of the discrete-event simulation, so that optimisation and
  what-if calls stay interactive (see their docstrings). The engine's
  design principle is that a surrogate result is a *recommendation* to be
  validated against the full simulation before being trusted for a real
  operational decision — that validation loop is provided
  (`port4_engine.simulation.calibration.Calibrator`) but is not wired up
  automatically.
- **`RustPortCore` ships with an in-process stub transport**
  (`LocalRustPortCoreStub`) so the rest of the engine and its tests run
  without a live Rust process. A real deployment supplies a real
  transport (gRPC, shared memory, etc.) implementing the same
  `PortCoreTransport` protocol.
- **The demo port bounds container-object creation per vessel** (rather
  than materialising every TEU as a distinct `Container`) so that 7- and
  30-day runs stay fast; the container flow, yard placement and state
  machine logic exercised per container is otherwise the real logic used
  everywhere else in the engine.
- Reference economic/energy constants (revenue/TEU, kWh/TEU, etc.) are
  illustrative defaults from `configs/example_port.yaml` — a real
  deployment supplies its own.
