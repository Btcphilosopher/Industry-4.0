export type GrowthStage = 
  | 'BARE_SOIL'
  | 'SEEDING'
  | 'GERMINATION'
  | 'EARLY_GROWTH'
  | 'VEGETATIVE_GROWTH'
  | 'FLOWERING'
  | 'RIPENING'
  | 'HARVESTING'
  | 'HARVESTED'
  | 'POST_HARVEST';

export type MachineType = 
  | 'TRACTOR'
  | 'COMBINE'
  | 'HARVESTER'
  | 'SPRAYER'
  | 'SEEDER'
  | 'CULTIVATOR'
  | 'TRAILER'
  | 'DRONE'
  | 'IRRIGATION_PIVOT';

export type MachineState = 
  | 'IDLE'
  | 'MOVING'
  | 'WORKING'
  | 'STOPPED'
  | 'OFFLINE'
  | 'MAINTENANCE';

export type HeatmapMode = 
  | 'RGB'
  | 'NDVI'
  | 'NDRE'
  | 'SOIL_MOISTURE'
  | 'SOIL_TEMP'
  | 'NITROGEN'
  | 'PHOSPHORUS'
  | 'POTASSIUM'
  | 'BIOMASS'
  | 'CROP_STRESS'
  | 'DISEASE_RISK'
  | 'YIELD_PREDICTION'
  | 'WEED_PROBABILITY'
  | 'ELEVATION';

export type ViewMode = '2D_GIS' | '3D_TWIN' | 'HYBRID';

export type WeatherType = 'SUNNY' | 'PARTLY_CLOUDY' | 'OVERCAST' | 'LIGHT_RAIN' | 'HEAVY_STORM' | 'WIND_WARNING';

export interface Point2D {
  x: number;
  y: number;
}

export interface GeoCoordinate {
  lat: number;
  lng: number;
  elevationM: number;
}

export interface FieldDigitalTwin {
  id: string;
  code: string;
  name: string;
  areaHa: number;
  crop: string;
  variety: string;
  boundary: Point2D[];
  center: Point2D;
  geoCoords: GeoCoordinate;
  soilType: string;
  plantingDate: string;
  expectedHarvest: string;
  yieldTargetTonneHa: number;
  currentYieldForecastTonneHa: number;
  growthStage: GrowthStage;
  growthIndex: number; // 0.0 to 1.0
  soilMoisturePct: number; // 0 to 100%
  soilTemperatureC: number; // °C
  soilOrganicMatterPct: number;
  soilPH: number;
  soilCompactionPsi: number;
  nitrogenKgHa: number;
  phosphorusPpm: number;
  potassiumPpm: number;
  ndvi: number; // 0.0 to 1.0
  ndre: number; // 0.0 to 1.0
  biomassKgM2: number;
  cropStressPct: number;
  weedPressurePct: number;
  diseaseRisk: 'LOW' | 'MODERATE' | 'HIGH' | 'CRITICAL';
  diseaseType?: string;
  irrigationStatus: 'OFF' | 'SCHEDULED' | 'ACTIVE_DRIP' | 'ACTIVE_PIVOT';
  irrigationRateMmH: number;
  activeMachineryId?: string;
  harvestProgressPct: number; // 0 to 100%
  seedingProgressPct: number; // 0 to 100%
  sprayingProgressPct: number; // 0 to 100%
  elevationProfile: { minM: number; maxM: number; slopePct: number; aspect: string };
  anomalies: string[];
}

export interface MachineTelemetry {
  id: string;
  name: string;
  type: MachineType;
  state: MachineState;
  position: Point2D;
  targetPosition?: Point2D;
  speedKmh: number;
  headingDeg: number;
  fuelPct: number;
  batteryPct: number;
  engineRpm: number;
  engineTempC: number;
  engineLoadPct?: number;
  model?: string;
  currentImplement: string;
  activeTaskId?: string;
  fieldId?: string;
  operatorName: string;
  operatorStatus: 'ACTIVE' | 'BREAK' | 'AUTONOMOUS_SUPERVISED';
  workingWidthM: number;
  applicationRateLHa?: number; // for sprayer
  seedingRateKgHa?: number; // for seeder
  grainTankFillPct?: number; // for combine
  grainFlowKgS?: number;
  swathPoints: Point2D[];
  lastTelemetryTimestamp: number;
  telemetryQuality: 'EXCELLENT' | 'GOOD' | 'DEGRADED' | 'STALE';
}

export interface IrrigationNode {
  id: string;
  name: string;
  type: 'PIVOT' | 'DRIP_BLOCK' | 'PUMP_STATION' | 'MAIN_VALVE' | 'RESERVOIR';
  position: Point2D;
  radiusM?: number;
  angleDeg?: number;
  status: 'IDLE' | 'ACTIVE' | 'FAULT' | 'MAINTENANCE' | 'STANDBY';
  flowRateM3H: number;
  flowRateM3h?: number;
  pressureBar: number;
  coverageHa: number;
  assignedFieldId?: string;
}

export interface DrainageNode {
  id: string;
  name: string;
  type: 'DITCH' | 'CULVERT' | 'RETENTION_POND' | 'WEIR' | 'OUTFLOW';
  path: Point2D[];
  currentWaterLevelM: number;
  maxCapacityM: number;
  flowRateLSec: number;
  waterLevelPct?: number;
  flowM3Sec?: number;
  status: 'NORMAL' | 'SURGE' | 'FLOOD_WARNING';
}

export interface InfrastructureObject {
  id: string;
  name: string;
  type: 'BARN' | 'GRAIN_SILO' | 'GREENHOUSE' | 'WORKSHOP' | 'SOLAR_ARRAY' | 'BATTERY_STORAGE' | 'WATER_TANK' | 'FUEL_DEPOT' | 'WEATHER_STATION';
  position: Point2D;
  width: number;
  height: number;
  capacity?: string;
  currentLevelPct?: number;
  status: 'OPERATIONAL' | 'STANDBY' | 'MAINTENANCE';
  metricValue?: string;
}

export interface LivestockZone {
  id: string;
  name: string;
  species: 'CATTLE' | 'SHEEP' | 'DAIRY';
  headCount: number;
  boundary: Point2D[];
  pastureHealthPct: number;
  waterSupplyStatus: 'NORMAL' | 'LOW' | 'REFILLED';
  avgWeightKg: number;
  grazingRotationDay: number;
}

export interface WeatherCondition {
  currentType: WeatherType;
  temperatureC: number;
  feelsLikeC: number;
  humidityPct: number;
  rainfallMmH: number;
  precipitationAccumulation24hMm: number;
  windSpeedKmh: number;
  windDirectionDeg: number;
  windGustKmh: number;
  solarRadiationWm2: number;
  dewPointC: number;
  barometricPressureHpa: number;
  forecast: { time: string; tempC: number; rainChancePct: number; type: WeatherType }[];
}

export interface WorkOrder {
  id: string;
  code?: string;
  title?: string;
  fieldId: string;
  fieldName: string;
  type?: 'PLANTING' | 'SPRAYING' | 'FERTILISING' | 'FERTILIZING' | 'TILLAGE' | 'HARVEST' | 'HARVESTING' | 'IRRIGATION' | 'SOIL_SAMPLING' | 'SCOUTING' | 'INSPECTION';
  taskType?: 'PLANTING' | 'SPRAYING' | 'FERTILIZING' | 'TILLAGE' | 'HARVESTING' | 'IRRIGATION' | 'SOIL_SAMPLING' | 'INSPECTION';
  assignedMachineId?: string;
  assignedMachine?: string;
  assignedMachineName?: string;
  operatorName?: string;
  assignedOperator?: string;
  targetRate?: string;
  priority?: 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';
  status: 'PLANNED' | 'ACTIVE' | 'COMPLETED' | 'DELAYED';
  scheduledStartTime?: string;
  scheduledDate?: string;
  targetAreaHa?: number;
  completedAreaHa?: number;
  progressPct?: number;
  prescriptionRate?: string;
  notes?: string;
}

export interface FarmAlert {
  id: string;
  timestamp: string;
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
  type: 'FIELD_STRESS' | 'LOW_SOIL_MOISTURE' | 'HIGH_WIND' | 'HEAVY_RAIN' | 'MACHINERY_FAULT' | 'HARVEST_WINDOW' | 'IRRIGATION_REQUIRED' | 'DISEASE_RISK' | 'NUTRIENT_DEFICIENCY';
  fieldId?: string;
  fieldName?: string;
  machineId?: string;
  title: string;
  message: string;
  actionRequired: string;
  acknowledged: boolean;
}

export interface ScenarioSimulationParams {
  rainfallMultiplierPct: number; // e.g. -20% or +20%
  temperatureDeltaC: number; // e.g. +1.5°C
  fertilizerReductionPct: number; // e.g. -25%
  irrigationBoostPct: number; // e.g. +30%
  plantingDelayDays: number; // e.g. +10 days
  selectedFieldIds: string[];
}

export interface ScenarioSimulationResult {
  baselineYieldTonne: number;
  simulatedYieldTonne: number;
  yieldDeltaPct: number;
  baselineRevenueUsd: number;
  simulatedRevenueUsd: number;
  revenueDeltaUsd: number;
  soilMoistureTrajectory: { day: number; baseline: number; simulated: number }[];
  cropStressRiskTrajectory: { day: number; baseline: number; simulated: number }[];
  recommendations: string[];
}

export interface AIInsight {
  id: string;
  category: 'PREDICTION' | 'RECOMMENDATION' | 'ALERT';
  target: string;
  title: string;
  confidencePct: number;
  reasoning: string;
  recommendedAction: string;
  impactMetric: string;
}

export interface FarmProfile {
  id: string;
  name: string;
  location: string;
  totalAreaHa: number;
  activeFieldsCount: number;
  primaryCrops: string[];
  soilClassification: string;
  elevationRangeM: string;
  energyCapacityKw: number;
  waterStorageCapacityM3: number;
}
