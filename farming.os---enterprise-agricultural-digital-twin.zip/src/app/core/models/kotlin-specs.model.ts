export interface KotlinModuleSpec {
  id: string;
  name: string;
  package: string;
  filename: string;
  description: string;
  codeSnippet: string;
}

export type KotlinCodeModule = KotlinModuleSpec;

export const KOTLIN_ARCHITECTURE_MODULES: KotlinModuleSpec[] = [
  {
    id: "engine",
    name: "DigitalTwinState Engine",
    package: "com.farmingos.core.digitaltwin",
    filename: "FarmDigitalTwinEngine.kt",
    description: "Thread-safe Coroutines StateFlow hub coordinating Field, Machine, Weather and Soil telemetry with incremental rendering caches.",
    codeSnippet: `package com.farmingos.core.digitaltwin

import kotlinx.coroutines.flow.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import com.farmingos.domain.model.*

sealed interface FarmDigitalTwinEvent {
    data class FieldGrowthChanged(val fieldId: String, val newStage: GrowthStage, val growthIndex: Float) : FarmDigitalTwinEvent
    data class SoilMoistureChanged(val fieldId: String, val moisturePct: Float, val tempC: Float) : FarmDigitalTwinEvent
    data class MachineTelemetryReceived(val machineId: String, val telemetry: MachineTelemetry) : FarmDigitalTwinEvent
    data class HarvestProgressChanged(val fieldId: String, val machineId: String, val harvestedHa: Float, val flowKgS: Float) : FarmDigitalTwinEvent
    data class WeatherAlertTriggered(val alert: FarmAlert) : FarmDigitalTwinEvent
}

class FarmDigitalTwinEngine(
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
) {
    private val _farmState = MutableStateFlow<FarmState>(FarmState.Initial)
    val farmState: StateFlow<FarmState> = _farmState.asStateFlow()

    private val _eventBus = MutableSharedFlow<FarmDigitalTwinEvent>(extraBufferCapacity = 64)
    val eventBus: SharedFlow<FarmDigitalTwinEvent> = _eventBus.asSharedFlow()

    suspend fun emitEvent(event: FarmDigitalTwinEvent) {
        _eventBus.emit(event)
    }
}`
  },
  {
    id: "state_machine",
    name: "Machinery State Machine",
    package: "com.farmingos.machinery.statemachine",
    filename: "MachineryStateMachine.kt",
    description: "Finite State Machine with telemetry validation, working trail swath generation, and fuel consumption modeling.",
    codeSnippet: `package com.farmingos.machinery.statemachine

sealed class MachineState(val stateCode: String) {
    object Idle : MachineState("TRACTOR_IDLE")
    data class Moving(val speedKmh: Float, val headingDeg: Float) : MachineState("TRACTOR_MOVING")
    data class Working(val implement: String, val swathWidthM: Float, val rate: Float) : MachineState("TRACTOR_WORKING")
    object Stopped : MachineState("TRACTOR_STOPPED")
    object Offline : MachineState("TRACTOR_OFFLINE")
    data class Fault(val errorCode: String, val severity: Int) : MachineState("TRACTOR_FAULT")
}

class MachineryStateMachine(val machineId: String) {
    private val _currentState = MutableStateFlow<MachineState>(MachineState.Idle)
    val currentState = _currentState.asStateFlow()

    fun handleTelemetry(telemetry: RawCanBusPacket) {
        // Evaluate CAN-Bus speed, RPM, GPS lock
        if (telemetry.speedKmh > 0.5f && telemetry.isImplementEngaged) {
            _currentState.value = MachineState.Working(telemetry.implementName, telemetry.widthM, telemetry.rate)
        } else if (telemetry.speedKmh > 0.5f) {
            _currentState.value = MachineState.Moving(telemetry.speedKmh, telemetry.headingDeg)
        } else {
            _currentState.value = MachineState.Idle
        }
    }
}`
  },
  {
    id: "phenology",
    name: "Crop Phenology & GDD Model",
    package: "com.farmingos.agronomy.phenology",
    filename: "CropPhenologyModel.kt",
    description: "Thermal growth modeling with daily base temperature calculations and BBCH growth stage transitions.",
    codeSnippet: `package com.farmingos.agronomy.phenology

enum class BBCHStage(val scale: Int, val description: String) {
    GERMINATION(0, "Germination & Emergence"),
    LEAF_DEVELOPMENT(1, "Canopy Vegetative Growth"),
    TILLERING(2, "Stem Elongation"),
    FLOWERING(6, "Anthesis / Flowering"),
    GRAIN_FILL(7, "Milky to Dough Development"),
    RIPENING(8, "Maturity / Ready for Harvest"),
    SENESCENCE(9, "Post-Harvest Stubble")
}

data class CropGDDThreshold(
    val crop: String,
    val baseTempC: Float,
    val gddEmergence: Float,
    val gddFlowering: Float,
    val gddRipening: Float
)

class CropPhenologyCalculator {
    fun calculateDailyGDD(tMax: Float, tMin: Float, tBase: Float): Float {
        val tMean = (tMax + tMin) / 2f
        return maxOf(0f, tMean - tBase)
    }
}`
  },
  {
    id: "isobus",
    name: "ISOBUS 11783 CAN-Bus Bridge",
    package: "com.farmingos.telemetry.isobus",
    filename: "ISOBUSBridge.kt",
    description: "J1939 / ISO 11783 Task Controller Bridge streaming real-time GNSS RTK and application rate parameters.",
    codeSnippet: `package com.farmingos.telemetry.isobus

data class IsobusTaskControllerPacket(
    val pgn: Int,
    val sourceAddress: Byte,
    val latitude: Double,
    val longitude: Double,
    val targetRateM3Ha: Float,
    val actualRateM3Ha: Float,
    val sectionControlBitmask: UShort
)

interface ISOBUSListener {
    fun onPacketReceived(packet: IsobusTaskControllerPacket)
}`
  },
  {
    id: "repo",
    name: "Repository & Offline Sync",
    package: "com.farmingos.data.repository",
    filename: "OfflineFirstFarmRepository.kt",
    description: "Offline-first repository managing SQLite/Room cache, mutation queue, and telemetry stream sync with confidence metadata.",
    codeSnippet: `package com.farmingos.data.repository

import kotlinx.coroutines.flow.Flow
import com.farmingos.data.local.FarmLocalCache
import com.farmingos.data.remote.FarmingOsApiClient
import com.farmingos.domain.model.FieldDigitalTwin

interface FarmRepository {
    fun observeFields(): Flow<List<FieldDigitalTwin>>
    suspend fun dispatchWorkOrder(workOrder: WorkOrder): Result<Unit>
    suspend fun syncOfflineTelemetryQueue(): SyncResult
}

class OfflineFirstFarmRepository(
    private val localCache: FarmLocalCache,
    private val remoteApi: FarmingOsApiClient
) : FarmRepository {
    override fun observeFields(): Flow<List<FieldDigitalTwin>> =
        localCache.observeAllFields()
}`
  }
];
