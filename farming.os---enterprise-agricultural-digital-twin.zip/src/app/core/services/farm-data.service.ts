import { Injectable, signal, computed } from '@angular/core';
import { 
  FieldDigitalTwin, 
  MachineTelemetry, 
  IrrigationNode, 
  DrainageNode, 
  InfrastructureObject, 
  LivestockZone, 
  WeatherCondition, 
  WorkOrder, 
  FarmAlert, 
  HeatmapMode, 
  ViewMode, 
  ScenarioSimulationParams, 
  ScenarioSimulationResult, 
  AIInsight, 
  FarmProfile 
} from '../models/farm.model';

@Injectable({
  providedIn: 'root'
})
export class FarmDataService {
  // Multi-farm management
  readonly activeFarmId = signal<string>('farm-alpha');
  readonly farms = signal<FarmProfile[]>([
    {
      id: 'farm-alpha',
      name: 'Farming.OS Prime Agri-Hub',
      location: 'Lincolnshire Plains, UK (53.2307° N, 0.5406° W)',
      totalAreaHa: 1042.8,
      activeFieldsCount: 18,
      primaryCrops: ['Winter Wheat', 'Canola / Oilseed Rape', 'Spring Barley', 'Maize / Corn', 'Soybeans'],
      soilClassification: 'Clay Loam / Silt Loam (Orthic Luvisol)',
      elevationRangeM: '18m - 64m',
      energyCapacityKw: 450,
      waterStorageCapacityM3: 125000
    },
    {
      id: 'farm-beta',
      name: 'Greenfield Precision Estate',
      location: 'East Anglia Fenlands (52.4862° N, 0.1245° E)',
      totalAreaHa: 680.4,
      activeFieldsCount: 12,
      primaryCrops: ['Sugar Beet', 'Winter Wheat', 'Potatoes', 'Malting Barley'],
      soilClassification: 'Rich Peat / Humic Gleysol',
      elevationRangeM: '2m - 14m',
      energyCapacityKw: 320,
      waterStorageCapacityM3: 88000
    },
    {
      id: 'farm-gamma',
      name: 'Highland Valley Agro-Forestry',
      location: 'Perthshire Terraces (56.3950° N, 3.4308° W)',
      totalAreaHa: 1280.0,
      activeFieldsCount: 22,
      primaryCrops: ['Oats', 'Silage Grass', 'Forage Maize', 'Winter Rye'],
      soilClassification: 'Sandy Silt Loam (Dystric Cambisol)',
      elevationRangeM: '120m - 280m',
      energyCapacityKw: 600,
      waterStorageCapacityM3: 190000
    }
  ]);

  // Current View & Rendering Mode
  readonly viewMode = signal<ViewMode>('3D_TWIN');
  readonly heatmapMode = signal<HeatmapMode>('RGB');
  readonly selectedFieldId = signal<string | null>('F-07');
  readonly trackedMachineId = signal<string | null>(null);
  
  // Layer Toggles
  readonly showCadastralBoundaries = signal<boolean>(true);
  readonly showCropTextures = signal<boolean>(true);
  readonly showMachineryTrails = signal<boolean>(true);
  readonly showIrrigationNetwork = signal<boolean>(true);
  readonly showDrainageWaterways = signal<boolean>(true);
  readonly showWeatherParticles = signal<boolean>(true);
  readonly showFieldLabels = signal<boolean>(true);
  readonly showElevationContours = signal<boolean>(false);
  readonly showDroneFlightPaths = signal<boolean>(false);
  readonly showAnomaliesLayer = signal<boolean>(true);

  // Time Machine & Replay
  readonly isLiveMode = signal<boolean>(true);
  readonly simulationSpeed = signal<number>(1); // 1x, 2x, 5x, 10x
  readonly timeMachineTimestamp = signal<number>(Date.now());
  readonly timelineDay = signal<number>(164); // Day of season (1..240)
  readonly historicalAnchor = signal<'NOW' | 'YESTERDAY' | 'LAST_WEEK' | 'LAST_MONTH' | 'LAST_SEASON'>('NOW');

  // Scenarios state
  readonly scenarios = signal<{ id: string; name: string; description: string; yieldImpactPct: number; moistureDeltaPct: number }[]>([
    {
      id: 'HEATWAVE',
      name: '+2.5°C Heatwave Inoculation',
      description: 'Simulates 5 consecutive days exceeding 34°C during grain filling stage.',
      yieldImpactPct: -8.4,
      moistureDeltaPct: -14
    },
    {
      id: 'DROUGHT',
      name: '14-Day Rain Deficit (Drought)',
      description: 'Extended dry spell cutting topsoil tension below root uptake threshold.',
      yieldImpactPct: -15.2,
      moistureDeltaPct: -22
    },
    {
      id: 'DELUGE',
      name: '50mm Extreme Deluge Event',
      description: 'High-intensity storm triggering sub-surface tile surge and nitrogen leaching.',
      yieldImpactPct: -4.1,
      moistureDeltaPct: +28
    },
    {
      id: 'VRA_NITROGEN_BOOST',
      name: '+20% Prescription Nitrogen VRA',
      description: 'Optimized variable-rate foliar top-dressing at flag leaf emergence.',
      yieldImpactPct: +6.8,
      moistureDeltaPct: 0
    }
  ]);
  readonly activeScenario = signal<{ id: string; name: string; description: string; yieldImpactPct: number; moistureDeltaPct: number } | null>(null);

  applyScenario(scenarioId: string) {
    const sc = this.scenarios().find(s => s.id === scenarioId) || null;
    this.activeScenario.set(sc);
    if (sc) {
      // Modulate field moisture and yield projections
      this.fields.update(fields => fields.map(f => ({
        ...f,
        soilMoisturePct: Math.max(10, Math.min(55, f.soilMoisturePct + sc.moistureDeltaPct)),
        currentYieldForecastTonneHa: Number((f.currentYieldForecastTonneHa * (1 + sc.yieldImpactPct / 100)).toFixed(2))
      })));
    }
  }

  resetScenario() {
    this.activeScenario.set(null);
    this.fields.set(this.getInitialFields());
  }

  // Network & Connectivity state
  readonly connectivityStatus = signal<'ONLINE' | 'OFFLINE' | 'SYNCING'>('ONLINE');
  readonly telemetryPacketRate = signal<number>(128); // packets/sec
  readonly pendingSyncMutationsCount = signal<number>(0);

  // Measure Tool
  readonly isMeasureToolActive = signal<boolean>(false);
  readonly measurePoints = signal<{ x: number; y: number }[]>([]);

  // Core Digital Twin State Collections
  readonly fields = signal<FieldDigitalTwin[]>(this.getInitialFields());
  readonly machines = signal<MachineTelemetry[]>(this.getInitialMachines());
  readonly irrigationNodes = signal<IrrigationNode[]>(this.getInitialIrrigation());
  readonly drainageNodes = signal<DrainageNode[]>(this.getInitialDrainage());
  readonly infrastructure = signal<InfrastructureObject[]>(this.getInitialInfrastructure());
  readonly livestockZones = signal<LivestockZone[]>(this.getInitialLivestock());
  readonly weather = signal<WeatherCondition>(this.getInitialWeather());
  readonly workOrders = signal<WorkOrder[]>(this.getInitialWorkOrders());
  readonly alerts = signal<FarmAlert[]>(this.getInitialAlerts());
  readonly aiInsights = signal<AIInsight[]>(this.getInitialAIInsights());
  readonly auditLogs = signal<{ timestamp: string; user: string; action: string; details: string }[]>(this.getInitialAuditLogs());

  // Energy & Water Dynamic State
  readonly solarGenerationKw = signal<number>(318.5);
  readonly batteryLevelPct = signal<number>(84.2);
  readonly batteryStoragePct = computed(() => this.batteryLevelPct());
  readonly waterReservoirLevelPct = signal<number>(76.8);
  readonly waterStorageM3 = computed(() => Math.round(125000 * (this.waterReservoirLevelPct() / 100)));
  readonly currentWaterConsumptionM3H = signal<number>(42.3);

  // Selected Field Computed
  readonly selectedField = computed(() => {
    const id = this.selectedFieldId();
    if (!id) return null;
    return this.fields().find(f => f.id === id) || null;
  });

  // Tracked Machine Computed
  readonly trackedMachine = computed(() => {
    const id = this.trackedMachineId();
    if (!id) return null;
    return this.machines().find(m => m.id === id) || null;
  });

  // KPI Computeds
  readonly totalFarmArea = computed(() => {
    return this.fields().reduce((acc, f) => acc + f.areaHa, 0);
  });

  readonly readyForHarvestCount = computed(() => {
    return this.fields().filter(f => f.growthStage === 'RIPENING' || f.growthStage === 'HARVESTING').length;
  });

  readonly activeOperationsCount = computed(() => {
    return this.workOrders().filter(w => w.status === 'ACTIVE').length;
  });

  readonly criticalAlertsCount = computed(() => {
    return this.alerts().filter(a => a.severity === 'CRITICAL' && !a.acknowledged).length;
  });

  readonly avgCropHealthNdvi = computed(() => {
    const list = this.fields();
    if (list.length === 0) return 0;
    const sum = list.reduce((acc, f) => acc + f.ndvi, 0);
    return Number((sum / list.length).toFixed(2));
  });

  readonly totalPredictedYieldTonne = computed(() => {
    return this.fields().reduce((acc, f) => acc + (f.areaHa * f.currentYieldForecastTonneHa), 0);
  });

  private simulationInterval: ReturnType<typeof setInterval> | null = null;

  constructor() {
    this.startSimulationLoop();
  }

  private startSimulationLoop() {
    if (typeof window === 'undefined') return;

    this.simulationInterval = setInterval(() => {
      if (!this.isLiveMode()) return;
      this.tickTelemetry();
    }, 1000);
  }

  // Telemetry physics tick
  private tickTelemetry() {
    const speedMultiplier = this.simulationSpeed();

    // 1. Move working machines along field swaths
    this.machines.update(machines => {
      return machines.map(m => {
        if (m.state === 'WORKING' || m.state === 'MOVING') {
          // Dynamic wandering / swath pass movement
          const rad = (m.headingDeg * Math.PI) / 180;
          const step = (m.speedKmh * 0.28 * 0.05 * speedMultiplier); // scaled canvas step
          const newX = m.position.x + Math.sin(rad) * step;
          const newY = m.position.y - Math.cos(rad) * step;

          // Boundary turn logic
          if (newX < 100 || newX > 1100 || newY < 100 || newY > 800) {
            m.headingDeg = (m.headingDeg + 175) % 360;
          }

          // Swath history record
          const updatedSwaths = [...m.swathPoints, { x: newX, y: newY }];
          if (updatedSwaths.length > 80) updatedSwaths.shift();

          // Fuel drain
          const fuelDrain = 0.005 * speedMultiplier;
          const newFuel = Math.max(5, Number((m.fuelPct - fuelDrain).toFixed(2)));

          // Grain fill if combine
          let grainFill = m.grainTankFillPct;
          if (m.type === 'COMBINE') {
            grainFill = Math.min(100, (m.grainTankFillPct || 0) + 0.1 * speedMultiplier);
          }

          return {
            ...m,
            position: { x: newX, y: newY },
            swathPoints: updatedSwaths,
            fuelPct: newFuel,
            grainTankFillPct: grainFill,
            lastTelemetryTimestamp: Date.now()
          };
        }
        return m;
      });
    });

    // 2. Rotate Center Pivot Irrigation and simulate water spray
    this.irrigationNodes.update(nodes => {
      return nodes.map(node => {
        if (node.type === 'PIVOT' && node.status === 'ACTIVE') {
          const newAngle = ((node.angleDeg || 0) + 0.8 * speedMultiplier) % 360;
          return { ...node, angleDeg: newAngle };
        }
        return node;
      });
    });

    // 3. Solar & Energy fluctuation
    const weatherFactor = this.weather().currentType === 'SUNNY' ? 1.0 : (this.weather().currentType === 'PARTLY_CLOUDY' ? 0.7 : 0.3);
    const timeFactor = Math.sin((Date.now() / 60000) % Math.PI);
    const solarKw = Number((380 * weatherFactor * (0.8 + 0.2 * Math.abs(timeFactor))).toFixed(1));
    this.solarGenerationKw.set(solarKw);

    // 4. Update Field Growth & Progress
    this.fields.update(fields => {
      return fields.map(f => {
        if (f.growthStage === 'HARVESTING') {
          const newHarvest = Math.min(100, f.harvestProgressPct + 0.08 * speedMultiplier);
          return {
            ...f,
            harvestProgressPct: Number(newHarvest.toFixed(1)),
            growthStage: newHarvest >= 100 ? 'HARVESTED' : 'HARVESTING'
          };
        }
        if (f.growthStage === 'SEEDING') {
          const newSeeding = Math.min(100, f.seedingProgressPct + 0.12 * speedMultiplier);
          return {
            ...f,
            seedingProgressPct: Number(newSeeding.toFixed(1)),
            growthStage: newSeeding >= 100 ? 'GERMINATION' : 'SEEDING'
          };
        }
        return f;
      });
    });
  }

  // Action methods
  selectField(fieldId: string | null) {
    this.selectedFieldId.set(fieldId);
    if (fieldId) {
      this.trackedMachineId.set(null);
      this.logAudit('FIELD_SELECT', `Operator inspected field ${fieldId}`);
    }
  }

  trackMachine(machineId: string | null) {
    this.trackedMachineId.set(machineId);
    if (machineId) {
      this.logAudit('MACHINE_TRACK', `Camera locked on machine ${machineId}`);
    }
  }

  setViewMode(mode: ViewMode) {
    this.viewMode.set(mode);
    this.logAudit('VIEW_MODE_CHANGE', `Switched digital twin view to ${mode}`);
  }

  setHeatmapMode(mode: HeatmapMode) {
    this.heatmapMode.set(mode);
    this.logAudit('HEATMAP_CHANGE', `Enabled ${mode} spectral layer`);
  }

  switchFarm(farmId: string) {
    this.activeFarmId.set(farmId);
    this.selectedFieldId.set(null);
    this.trackedMachineId.set(null);
    this.logAudit('FARM_SWITCH', `Switched enterprise workspace to ${farmId}`);
  }

  toggleIrrigationForField(fieldId: string) {
    this.fields.update(fields => {
      return fields.map(f => {
        if (f.id === fieldId) {
          const nextStatus = f.irrigationStatus === 'OFF' ? 'ACTIVE_PIVOT' : 'OFF';
          return {
            ...f,
            irrigationStatus: nextStatus,
            soilMoisturePct: nextStatus === 'ACTIVE_PIVOT' ? Math.min(65, f.soilMoisturePct + 4) : f.soilMoisturePct
          };
        }
        return f;
      });
    });
    this.logAudit('IRRIGATION_TOGGLE', `Toggled automated irrigation on ${fieldId}`);
  }

  acknowledgeAlert(alertId: string) {
    this.alerts.update(alerts => {
      return alerts.map(a => a.id === alertId ? { ...a, acknowledged: true } : a);
    });
    this.logAudit('ALERT_ACKNOWLEDGE', `Alert ${alertId} acknowledged by operator`);
  }

  resolveAlert(alertId: string) {
    this.alerts.update(alerts => alerts.filter(a => a.id !== alertId));
    this.logAudit('ALERT_RESOLVED', `Alert ${alertId} marked as resolved`);
  }

  updateWorkOrderStatus(orderId: string, newStatus: 'PLANNED' | 'ACTIVE' | 'COMPLETED' | 'DELAYED') {
    this.workOrders.update(orders => {
      return orders.map(o => o.id === orderId ? { ...o, status: newStatus } : o);
    });
    this.logAudit('WORK_ORDER_UPDATE', `Work order ${orderId} status changed to ${newStatus}`);
  }

  createWorkOrder(order: Partial<WorkOrder>) {
    const newOrder: WorkOrder = {
      id: `WO-${Date.now().toString().slice(-4)}`,
      code: `WO-2026-${(this.workOrders().length + 1).toString().padStart(3, '0')}`,
      title: order.title || 'Agronomic Operation',
      fieldId: order.fieldId || 'F-01',
      fieldName: order.fieldName || 'Field 01',
      taskType: order.taskType || 'SPRAYING',
      assignedMachineId: order.assignedMachineId || 'TRAC-01',
      assignedMachineName: order.assignedMachineName || 'John Deere 8RX 410',
      operatorName: order.operatorName || 'Alex Turner',
      priority: order.priority || 'MEDIUM',
      status: 'PLANNED',
      scheduledStartTime: '08:00 Today',
      targetAreaHa: order.targetAreaHa || 42.5,
      completedAreaHa: 0,
      prescriptionRate: order.prescriptionRate || '140 L/ha',
      notes: order.notes || 'Automated work order generated via Farming.OS Digital Twin'
    };

    this.workOrders.update(orders => [newOrder, ...orders]);
    this.logAudit('WORK_ORDER_CREATE', `Created work order ${newOrder.code} for ${newOrder.fieldName}`);
  }

  // What-If Scenario Evaluator
  runScenarioSimulation(params: ScenarioSimulationParams): ScenarioSimulationResult {
    const baselineYield = this.totalPredictedYieldTonne();
    const baselineRev = baselineYield * 285; // $285 / tonne average

    // Agricultural physics calculation
    let yieldFactor = 1.0;
    yieldFactor += (params.rainfallMultiplierPct / 100) * 0.45;
    yieldFactor -= (Math.max(0, params.temperatureDeltaC - 1.0)) * 0.08;
    yieldFactor -= (params.fertilizerReductionPct / 100) * 0.32;
    yieldFactor += (params.irrigationBoostPct / 100) * 0.22;
    yieldFactor -= (params.plantingDelayDays / 30) * 0.15;

    const simulatedYield = Number((baselineYield * Math.max(0.4, Math.min(1.6, yieldFactor))).toFixed(1));
    const yieldDeltaPct = Number((((simulatedYield - baselineYield) / baselineYield) * 100).toFixed(1));
    const simulatedRev = simulatedYield * 285;
    const revenueDelta = Number((simulatedRev - baselineRev).toFixed(0));

    const soilMoistureTrajectory = [
      { day: 1, baseline: 32, simulated: 32 + (params.rainfallMultiplierPct * 0.15) },
      { day: 7, baseline: 30, simulated: 30 + (params.rainfallMultiplierPct * 0.2) + (params.irrigationBoostPct * 0.1) },
      { day: 14, baseline: 28, simulated: 28 + (params.rainfallMultiplierPct * 0.25) + (params.irrigationBoostPct * 0.18) },
      { day: 21, baseline: 29, simulated: 29 + (params.rainfallMultiplierPct * 0.3) + (params.irrigationBoostPct * 0.22) },
      { day: 30, baseline: 27, simulated: 27 + (params.rainfallMultiplierPct * 0.35) + (params.irrigationBoostPct * 0.25) }
    ];

    const cropStressRiskTrajectory = [
      { day: 1, baseline: 12, simulated: 12 },
      { day: 7, baseline: 15, simulated: Math.max(5, 15 - (params.irrigationBoostPct * 0.2) + (params.temperatureDeltaC * 3)) },
      { day: 14, baseline: 18, simulated: Math.max(5, 18 - (params.irrigationBoostPct * 0.25) + (params.fertilizerReductionPct * 0.3)) },
      { day: 21, baseline: 20, simulated: Math.max(5, 20 - (params.irrigationBoostPct * 0.3) + (params.temperatureDeltaC * 4)) },
      { day: 30, baseline: 22, simulated: Math.max(5, 22 - (params.irrigationBoostPct * 0.35) + (params.rainfallMultiplierPct < 0 ? 15 : -8)) }
    ];

    const recommendations = [];
    if (params.rainfallMultiplierPct < -15) {
      recommendations.push("Implement deficit drip irrigation across sandy loam fields (F-04, F-08) to preserve root zone moisture.");
    }
    if (params.fertilizerReductionPct > 20) {
      recommendations.push("Offset N-reduction by scheduling precision foliar nitrogen applications during flowering stage.");
    }
    if (params.temperatureDeltaC > 2.0) {
      recommendations.push("Advance harvest window by 6-9 days to mitigate premature grain dry-down and kernel shattering.");
    }
    if (recommendations.length === 0) {
      recommendations.push("Scenario parameters maintain crop resilience within acceptable agronomic safety margins.");
    }

    this.logAudit('SCENARIO_SIMULATION', `Executed What-If scenario: Rain ${params.rainfallMultiplierPct}%, Temp +${params.temperatureDeltaC}°C`);

    return {
      baselineYieldTonne: baselineYield,
      simulatedYieldTonne: simulatedYield,
      yieldDeltaPct,
      baselineRevenueUsd: baselineRev,
      simulatedRevenueUsd: simulatedRev,
      revenueDeltaUsd: revenueDelta,
      soilMoistureTrajectory,
      cropStressRiskTrajectory,
      recommendations
    };
  }

  // Audit trail logger
  logAudit(action: string, details: string) {
    const entry = {
      timestamp: new Date().toLocaleTimeString(),
      user: 'Chief Agronomist (Console #1)',
      action,
      details
    };
    this.auditLogs.update(logs => [entry, ...logs.slice(0, 49)]);
  }

  // --- Initial Seed Data Generators ---

  private getInitialFields(): FieldDigitalTwin[] {
    return [
      {
        id: 'F-01',
        code: 'FIELD 01',
        name: 'North Meadow Terrace',
        areaHa: 54.2,
        crop: 'Winter Wheat',
        variety: 'KWS Extase',
        boundary: [{ x: 120, y: 120 }, { x: 380, y: 110 }, { x: 390, y: 260 }, { x: 130, y: 270 }],
        center: { x: 255, y: 190 },
        geoCoords: { lat: 53.235, lng: -0.548, elevationM: 28.4 },
        soilType: 'Clay Loam',
        plantingDate: '2025-10-12',
        expectedHarvest: '2026-08-15',
        yieldTargetTonneHa: 9.2,
        currentYieldForecastTonneHa: 8.9,
        growthStage: 'VEGETATIVE_GROWTH',
        growthIndex: 0.65,
        soilMoisturePct: 34,
        soilTemperatureC: 17.8,
        soilOrganicMatterPct: 3.8,
        soilPH: 6.8,
        soilCompactionPsi: 145,
        nitrogenKgHa: 165,
        phosphorusPpm: 24,
        potassiumPpm: 210,
        ndvi: 0.82,
        ndre: 0.74,
        biomassKgM2: 4.8,
        cropStressPct: 14,
        weedPressurePct: 8,
        diseaseRisk: 'LOW',
        irrigationStatus: 'OFF',
        irrigationRateMmH: 0,
        harvestProgressPct: 0,
        seedingProgressPct: 100,
        sprayingProgressPct: 100,
        elevationProfile: { minM: 24, maxM: 32, slopePct: 2.1, aspect: 'South-East' },
        anomalies: []
      },
      {
        id: 'F-02',
        code: 'FIELD 02',
        name: 'Mill Creek Basin',
        areaHa: 48.6,
        crop: 'Spring Barley',
        variety: 'Laureate (Malting)',
        boundary: [{ x: 420, y: 110 }, { x: 680, y: 100 }, { x: 690, y: 250 }, { x: 430, y: 260 }],
        center: { x: 555, y: 180 },
        geoCoords: { lat: 53.238, lng: -0.535, elevationM: 22.1 },
        soilType: 'Sandy Silt Loam',
        plantingDate: '2026-03-20',
        expectedHarvest: '2026-08-28',
        yieldTargetTonneHa: 7.8,
        currentYieldForecastTonneHa: 7.6,
        growthStage: 'EARLY_GROWTH',
        growthIndex: 0.42,
        soilMoisturePct: 28,
        soilTemperatureC: 18.5,
        soilOrganicMatterPct: 3.2,
        soilPH: 6.5,
        soilCompactionPsi: 130,
        nitrogenKgHa: 130,
        phosphorusPpm: 28,
        potassiumPpm: 195,
        ndvi: 0.68,
        ndre: 0.59,
        biomassKgM2: 2.9,
        cropStressPct: 18,
        weedPressurePct: 15,
        diseaseRisk: 'LOW',
        irrigationStatus: 'SCHEDULED',
        irrigationRateMmH: 0,
        harvestProgressPct: 0,
        seedingProgressPct: 100,
        sprayingProgressPct: 40,
        elevationProfile: { minM: 19, maxM: 25, slopePct: 1.4, aspect: 'South' },
        anomalies: ['Slight weed emergence in north boundary']
      },
      {
        id: 'F-03',
        code: 'FIELD 03',
        name: 'High Ridge Canola',
        areaHa: 62.4,
        crop: 'Canola / Oilseed Rape',
        variety: 'Aurelia Hybrid',
        boundary: [{ x: 720, y: 100 }, { x: 1020, y: 90 }, { x: 1030, y: 260 }, { x: 730, y: 270 }],
        center: { x: 875, y: 180 },
        geoCoords: { lat: 53.242, lng: -0.518, elevationM: 46.5 },
        soilType: 'Chalky Silt Loam',
        plantingDate: '2025-08-28',
        expectedHarvest: '2026-07-25',
        yieldTargetTonneHa: 4.6,
        currentYieldForecastTonneHa: 4.8,
        growthStage: 'FLOWERING',
        growthIndex: 0.78,
        soilMoisturePct: 32,
        soilTemperatureC: 17.2,
        soilOrganicMatterPct: 4.1,
        soilPH: 7.2,
        soilCompactionPsi: 155,
        nitrogenKgHa: 190,
        phosphorusPpm: 32,
        potassiumPpm: 240,
        ndvi: 0.88,
        ndre: 0.81,
        biomassKgM2: 5.6,
        cropStressPct: 9,
        weedPressurePct: 6,
        diseaseRisk: 'LOW',
        irrigationStatus: 'OFF',
        irrigationRateMmH: 0,
        harvestProgressPct: 0,
        seedingProgressPct: 100,
        sprayingProgressPct: 100,
        elevationProfile: { minM: 40, maxM: 52, slopePct: 3.8, aspect: 'South-West' },
        anomalies: []
      },
      {
        id: 'F-04',
        code: 'FIELD 04',
        name: 'Sunnyside Maize Plateau',
        areaHa: 74.0,
        crop: 'Maize / Corn',
        variety: 'Pioneer P8888',
        boundary: [{ x: 130, y: 300 }, { x: 400, y: 290 }, { x: 410, y: 490 }, { x: 140, y: 500 }],
        center: { x: 270, y: 395 },
        geoCoords: { lat: 53.228, lng: -0.545, elevationM: 31.0 },
        soilType: 'Sandy Loam',
        plantingDate: '2026-04-18',
        expectedHarvest: '2026-10-10',
        yieldTargetTonneHa: 12.4,
        currentYieldForecastTonneHa: 11.8,
        growthStage: 'VEGETATIVE_GROWTH',
        growthIndex: 0.58,
        soilMoisturePct: 24,
        soilTemperatureC: 19.8,
        soilOrganicMatterPct: 2.9,
        soilPH: 6.4,
        soilCompactionPsi: 160,
        nitrogenKgHa: 175,
        phosphorusPpm: 22,
        potassiumPpm: 180,
        ndvi: 0.74,
        ndre: 0.65,
        biomassKgM2: 4.1,
        cropStressPct: 26,
        weedPressurePct: 12,
        diseaseRisk: 'MODERATE',
        diseaseType: 'Early Northern Corn Leaf Blight detected in south strip',
        irrigationStatus: 'ACTIVE_PIVOT',
        irrigationRateMmH: 15,
        harvestProgressPct: 0,
        seedingProgressPct: 100,
        sprayingProgressPct: 75,
        elevationProfile: { minM: 28, maxM: 34, slopePct: 1.8, aspect: 'East' },
        anomalies: ['Low soil moisture in central sector', 'Foliar blight alert']
      },
      {
        id: 'F-07',
        code: 'FIELD 07',
        name: 'Grand Prairie Gold',
        areaHa: 86.5,
        crop: 'Winter Wheat',
        variety: 'Skyfall (Breadmaking)',
        boundary: [{ x: 440, y: 290 }, { x: 740, y: 280 }, { x: 750, y: 500 }, { x: 450, y: 510 }],
        center: { x: 595, y: 395 },
        geoCoords: { lat: 53.231, lng: -0.530, elevationM: 25.8 },
        soilType: 'Heavy Clay Loam',
        plantingDate: '2025-10-05',
        expectedHarvest: '2026-08-04',
        yieldTargetTonneHa: 10.1,
        currentYieldForecastTonneHa: 9.8,
        growthStage: 'RIPENING',
        growthIndex: 0.89,
        soilMoisturePct: 31,
        soilTemperatureC: 18.1,
        soilOrganicMatterPct: 4.2,
        soilPH: 6.9,
        soilCompactionPsi: 140,
        nitrogenKgHa: 210,
        phosphorusPpm: 34,
        potassiumPpm: 260,
        ndvi: 0.87,
        ndre: 0.79,
        biomassKgM2: 7.4,
        cropStressPct: 8,
        weedPressurePct: 4,
        diseaseRisk: 'LOW',
        irrigationStatus: 'OFF',
        irrigationRateMmH: 0,
        activeMachineryId: 'COMB-01',
        harvestProgressPct: 38,
        seedingProgressPct: 100,
        sprayingProgressPct: 100,
        elevationProfile: { minM: 23, maxM: 28, slopePct: 1.1, aspect: 'South-South-East' },
        anomalies: []
      },
      {
        id: 'F-08',
        code: 'FIELD 08',
        name: 'Willow Springs Soy',
        areaHa: 68.2,
        crop: 'Soybeans',
        variety: 'Asgrow AG24X9',
        boundary: [{ x: 770, y: 290 }, { x: 1060, y: 280 }, { x: 1070, y: 500 }, { x: 780, y: 510 }],
        center: { x: 920, y: 395 },
        geoCoords: { lat: 53.234, lng: -0.512, elevationM: 38.2 },
        soilType: 'Silt Loam',
        plantingDate: '2026-05-02',
        expectedHarvest: '2026-09-30',
        yieldTargetTonneHa: 4.2,
        currentYieldForecastTonneHa: 4.0,
        growthStage: 'VEGETATIVE_GROWTH',
        growthIndex: 0.52,
        soilMoisturePct: 29,
        soilTemperatureC: 19.1,
        soilOrganicMatterPct: 3.6,
        soilPH: 6.6,
        soilCompactionPsi: 135,
        nitrogenKgHa: 95, // legume N-fixation
        phosphorusPpm: 26,
        potassiumPpm: 220,
        ndvi: 0.76,
        ndre: 0.68,
        biomassKgM2: 3.5,
        cropStressPct: 12,
        weedPressurePct: 9,
        diseaseRisk: 'LOW',
        irrigationStatus: 'OFF',
        irrigationRateMmH: 0,
        harvestProgressPct: 0,
        seedingProgressPct: 100,
        sprayingProgressPct: 100,
        elevationProfile: { minM: 34, maxM: 42, slopePct: 2.4, aspect: 'East' },
        anomalies: []
      },
      {
        id: 'F-11',
        code: 'FIELD 11',
        name: 'Valley Bottom Sugar Beet',
        areaHa: 52.0,
        crop: 'Sugar Beet',
        variety: 'Betaseed BTS 1915',
        boundary: [{ x: 150, y: 530 }, { x: 420, y: 520 }, { x: 430, y: 720 }, { x: 160, y: 730 }],
        center: { x: 290, y: 625 },
        geoCoords: { lat: 53.220, lng: -0.542, elevationM: 20.4 },
        soilType: 'Rich Humic Peat',
        plantingDate: '2026-04-05',
        expectedHarvest: '2026-11-15',
        yieldTargetTonneHa: 78.0,
        currentYieldForecastTonneHa: 76.5,
        growthStage: 'VEGETATIVE_GROWTH',
        growthIndex: 0.62,
        soilMoisturePct: 38,
        soilTemperatureC: 16.9,
        soilOrganicMatterPct: 5.4,
        soilPH: 7.1,
        soilCompactionPsi: 120,
        nitrogenKgHa: 140,
        phosphorusPpm: 38,
        potassiumPpm: 310,
        ndvi: 0.84,
        ndre: 0.77,
        biomassKgM2: 6.2,
        cropStressPct: 10,
        weedPressurePct: 7,
        diseaseRisk: 'LOW',
        irrigationStatus: 'OFF',
        irrigationRateMmH: 0,
        harvestProgressPct: 0,
        seedingProgressPct: 100,
        sprayingProgressPct: 100,
        elevationProfile: { minM: 18, maxM: 23, slopePct: 0.9, aspect: 'Flat' },
        anomalies: []
      },
      {
        id: 'F-12',
        code: 'FIELD 12',
        name: 'South Paddock Forage',
        areaHa: 44.5,
        crop: 'Alfalfa / Lucerne',
        variety: 'WL 358LH',
        boundary: [{ x: 460, y: 540 }, { x: 730, y: 530 }, { x: 740, y: 730 }, { x: 470, y: 740 }],
        center: { x: 600, y: 635 },
        geoCoords: { lat: 53.223, lng: -0.528, elevationM: 24.5 },
        soilType: 'Loamy Sand',
        plantingDate: '2024-09-15',
        expectedHarvest: '2026-06-20',
        yieldTargetTonneHa: 14.5,
        currentYieldForecastTonneHa: 14.2,
        growthStage: 'FLOWERING',
        growthIndex: 0.72,
        soilMoisturePct: 30,
        soilTemperatureC: 17.5,
        soilOrganicMatterPct: 3.4,
        soilPH: 6.7,
        soilCompactionPsi: 140,
        nitrogenKgHa: 80,
        phosphorusPpm: 30,
        potassiumPpm: 250,
        ndvi: 0.79,
        ndre: 0.71,
        biomassKgM2: 5.1,
        cropStressPct: 11,
        weedPressurePct: 8,
        diseaseRisk: 'LOW',
        irrigationStatus: 'OFF',
        irrigationRateMmH: 0,
        harvestProgressPct: 0,
        seedingProgressPct: 100,
        sprayingProgressPct: 100,
        elevationProfile: { minM: 22, maxM: 27, slopePct: 1.2, aspect: 'South' },
        anomalies: []
      }
    ];
  }

  private getInitialMachines(): MachineTelemetry[] {
    return [
      {
        id: 'TRAC-01',
        name: 'John Deere 8RX 410 (Autonomous Ready)',
        type: 'TRACTOR',
        state: 'WORKING',
        position: { x: 260, y: 190 },
        speedKmh: 11.2,
        headingDeg: 88,
        fuelPct: 78.4,
        batteryPct: 94.0,
        engineRpm: 1850,
        engineTempC: 84.5,
        currentImplement: 'Horsch Joker 12 RT Disk Cultivator',
        activeTaskId: 'WO-2026-003',
        fieldId: 'F-01',
        operatorName: 'Marcus Vance',
        operatorStatus: 'ACTIVE',
        workingWidthM: 12.0,
        swathPoints: [{ x: 180, y: 190 }, { x: 210, y: 190 }, { x: 240, y: 190 }, { x: 260, y: 190 }],
        lastTelemetryTimestamp: Date.now(),
        telemetryQuality: 'EXCELLENT'
      },
      {
        id: 'COMB-01',
        name: 'Claas Lexion 8900 Terra Trac',
        type: 'COMBINE',
        state: 'WORKING',
        position: { x: 595, y: 395 },
        speedKmh: 6.4,
        headingDeg: 178,
        fuelPct: 62.1,
        batteryPct: 88.0,
        engineRpm: 2100,
        engineTempC: 89.2,
        currentImplement: 'Convio Flex 1380 Draper Header (13.8m)',
        activeTaskId: 'WO-2026-001',
        fieldId: 'F-07',
        operatorName: 'Elena Rostova',
        operatorStatus: 'ACTIVE',
        workingWidthM: 13.8,
        grainTankFillPct: 72.4,
        grainFlowKgS: 24.8,
        swathPoints: [{ x: 595, y: 320 }, { x: 595, y: 350 }, { x: 595, y: 375 }, { x: 595, y: 395 }],
        lastTelemetryTimestamp: Date.now(),
        telemetryQuality: 'EXCELLENT'
      },
      {
        id: 'SPRAY-01',
        name: 'Fendt Rogator 665 Self-Propelled',
        type: 'SPRAYER',
        state: 'WORKING',
        position: { x: 270, y: 395 },
        speedKmh: 14.8,
        headingDeg: 268,
        fuelPct: 81.0,
        batteryPct: 96.0,
        engineRpm: 1650,
        engineTempC: 81.0,
        currentImplement: 'Boom 36m with PWM Pulse Valves',
        activeTaskId: 'WO-2026-002',
        fieldId: 'F-04',
        operatorName: 'David Chen',
        operatorStatus: 'ACTIVE',
        workingWidthM: 36.0,
        applicationRateLHa: 140.0,
        swathPoints: [{ x: 350, y: 395 }, { x: 310, y: 395 }, { x: 285, y: 395 }, { x: 270, y: 395 }],
        lastTelemetryTimestamp: Date.now(),
        telemetryQuality: 'EXCELLENT'
      },
      {
        id: 'DRONE-01',
        name: 'DJI Agras T50 Multispectral Scout',
        type: 'DRONE',
        state: 'WORKING',
        position: { x: 875, y: 180 },
        speedKmh: 28.5,
        headingDeg: 42,
        fuelPct: 0,
        batteryPct: 71.5,
        engineRpm: 6200,
        engineTempC: 44.0,
        currentImplement: 'Dual NDVI/Thermal Orthomosaic Sensor',
        activeTaskId: 'WO-2026-004',
        fieldId: 'F-03',
        operatorName: 'Autonomous Agronomy AI',
        operatorStatus: 'AUTONOMOUS_SUPERVISED',
        workingWidthM: 50.0,
        swathPoints: [{ x: 820, y: 220 }, { x: 850, y: 200 }, { x: 875, y: 180 }],
        lastTelemetryTimestamp: Date.now(),
        telemetryQuality: 'EXCELLENT'
      },
      {
        id: 'TRAC-02',
        name: 'Fendt 1050 Vario Gen3',
        type: 'TRACTOR',
        state: 'IDLE',
        position: { x: 110, y: 840 },
        speedKmh: 0,
        headingDeg: 0,
        fuelPct: 92.0,
        batteryPct: 99.0,
        engineRpm: 800,
        engineTempC: 62.0,
        currentImplement: 'Väderstad Tempo L 24 Precision Seeder',
        activeTaskId: undefined,
        fieldId: undefined,
        operatorName: 'Liam O’Connor',
        operatorStatus: 'BREAK',
        workingWidthM: 18.0,
        swathPoints: [],
        lastTelemetryTimestamp: Date.now() - 4000,
        telemetryQuality: 'GOOD'
      }
    ];
  }

  private getInitialIrrigation(): IrrigationNode[] {
    return [
      {
        id: 'PIVOT-01',
        name: 'Center Pivot Delta-01',
        type: 'PIVOT',
        position: { x: 270, y: 395 },
        radiusM: 85,
        angleDeg: 124,
        status: 'ACTIVE',
        flowRateM3H: 145.0,
        pressureBar: 3.8,
        coverageHa: 74.0,
        assignedFieldId: 'F-04'
      },
      {
        id: 'PUMP-MAIN',
        name: 'Central Hydro-Station Pump #1',
        type: 'PUMP_STATION',
        position: { x: 50, y: 450 },
        status: 'ACTIVE',
        flowRateM3H: 380.0,
        pressureBar: 5.4,
        coverageHa: 450.0
      },
      {
        id: 'DRIP-01',
        name: 'Subsurface Drip Manifold Beta',
        type: 'DRIP_BLOCK',
        position: { x: 920, y: 395 },
        status: 'IDLE',
        flowRateM3H: 0,
        pressureBar: 2.1,
        coverageHa: 68.2,
        assignedFieldId: 'F-08'
      }
    ];
  }

  private getInitialDrainage(): DrainageNode[] {
    return [
      {
        id: 'DRAIN-01',
        name: 'North Boundary Interceptor Canal',
        type: 'DITCH',
        path: [{ x: 80, y: 80 }, { x: 400, y: 75 }, { x: 700, y: 70 }, { x: 1080, y: 65 }],
        currentWaterLevelM: 0.65,
        maxCapacityM: 1.8,
        flowRateLSec: 142.0,
        status: 'NORMAL'
      },
      {
        id: 'POND-01',
        name: 'Eco-Retention Wetland Basin',
        type: 'RETENTION_POND',
        path: [{ x: 50, y: 400 }, { x: 100, y: 400 }, { x: 100, y: 480 }, { x: 50, y: 480 }],
        currentWaterLevelM: 2.4,
        maxCapacityM: 3.5,
        flowRateLSec: 85.0,
        status: 'NORMAL'
      }
    ];
  }

  private getInitialInfrastructure(): InfrastructureObject[] {
    return [
      {
        id: 'BARN-01',
        name: 'Main Fleet Workshop & Hangar',
        type: 'WORKSHOP',
        position: { x: 70, y: 800 },
        width: 90,
        height: 60,
        status: 'OPERATIONAL',
        metricValue: '4 Bays Active'
      },
      {
        id: 'SILO-01',
        name: 'Grain Processing Complex (4x 2500t)',
        type: 'GRAIN_SILO',
        position: { x: 180, y: 810 },
        width: 70,
        height: 50,
        capacity: '10,000 Tonnes',
        currentLevelPct: 46.5,
        status: 'OPERATIONAL',
        metricValue: '4,650 t Stored'
      },
      {
        id: 'SOLAR-01',
        name: 'Agri-PV Solar Park',
        type: 'SOLAR_ARRAY',
        position: { x: 270, y: 800 },
        width: 120,
        height: 60,
        capacity: '450 kWp',
        status: 'OPERATIONAL',
        metricValue: '318 kW Output'
      },
      {
        id: 'BATTERY-01',
        name: 'Megapack BESS Storage',
        type: 'BATTERY_STORAGE',
        position: { x: 410, y: 810 },
        width: 50,
        height: 40,
        capacity: '1.2 MWh',
        currentLevelPct: 84.2,
        status: 'OPERATIONAL',
        metricValue: '84% (1,010 kWh)'
      },
      {
        id: 'WEATHER-01',
        name: 'Precision IoT Met Station #1',
        type: 'WEATHER_STATION',
        position: { x: 600, y: 50 },
        width: 30,
        height: 30,
        status: 'OPERATIONAL',
        metricValue: 'Calibrated'
      }
    ];
  }

  private getInitialLivestock(): LivestockZone[] {
    return [
      {
        id: 'PASTURE-01',
        name: 'Highland Angus Pasture Rotation #3',
        species: 'CATTLE',
        headCount: 84,
        boundary: [{ x: 800, y: 540 }, { x: 1060, y: 530 }, { x: 1070, y: 730 }, { x: 810, y: 740 }],
        pastureHealthPct: 88,
        waterSupplyStatus: 'NORMAL',
        avgWeightKg: 580,
        grazingRotationDay: 4
      }
    ];
  }

  private getInitialWeather(): WeatherCondition {
    return {
      currentType: 'SUNNY',
      temperatureC: 21.4,
      feelsLikeC: 22.0,
      humidityPct: 54,
      rainfallMmH: 0.0,
      precipitationAccumulation24hMm: 2.4,
      windSpeedKmh: 14.2,
      windDirectionDeg: 215,
      windGustKmh: 22.0,
      solarRadiationWm2: 740,
      dewPointC: 11.8,
      barometricPressureHpa: 1018.4,
      forecast: [
        { time: '12:00', tempC: 22.1, rainChancePct: 5, type: 'SUNNY' },
        { time: '14:00', tempC: 23.4, rainChancePct: 10, type: 'PARTLY_CLOUDY' },
        { time: '16:00', tempC: 22.8, rainChancePct: 20, type: 'PARTLY_CLOUDY' },
        { time: '18:00', tempC: 20.5, rainChancePct: 35, type: 'OVERCAST' },
        { time: '20:00', tempC: 18.2, rainChancePct: 55, type: 'LIGHT_RAIN' },
        { time: '22:00', tempC: 16.9, rainChancePct: 65, type: 'LIGHT_RAIN' }
      ]
    };
  }

  private getInitialWorkOrders(): WorkOrder[] {
    return [
      {
        id: 'WO-001',
        code: 'WO-2026-001',
        title: 'Winter Wheat High-Moisture Harvest',
        fieldId: 'F-07',
        fieldName: 'Grand Prairie Gold',
        taskType: 'HARVESTING',
        assignedMachineId: 'COMB-01',
        assignedMachineName: 'Claas Lexion 8900',
        operatorName: 'Elena Rostova',
        priority: 'URGENT',
        status: 'ACTIVE',
        scheduledStartTime: '07:30 Today',
        targetAreaHa: 86.5,
        completedAreaHa: 32.8,
        prescriptionRate: 'Target Grain Moisture: 14.5%',
        notes: 'Combine auto-unloading into Chaser Bin 02. Grain elevator drying dock pre-notified.'
      },
      {
        id: 'WO-002',
        code: 'WO-2026-002',
        title: 'Precision Fungicide Strip Spraying',
        fieldId: 'F-04',
        fieldName: 'Sunnyside Maize Plateau',
        taskType: 'SPRAYING',
        assignedMachineId: 'SPRAY-01',
        assignedMachineName: 'Fendt Rogator 665',
        operatorName: 'David Chen',
        priority: 'HIGH',
        status: 'ACTIVE',
        scheduledStartTime: '08:15 Today',
        targetAreaHa: 74.0,
        completedAreaHa: 55.5,
        prescriptionRate: '140 L/ha Variable Rate',
        notes: 'Targeting northern strip with Revysol blend to curb blight emergence.'
      },
      {
        id: 'WO-003',
        code: 'WO-2026-003',
        title: 'Post-Harvest Stubble Disc Cultivation',
        fieldId: 'F-01',
        fieldName: 'North Meadow Terrace',
        taskType: 'TILLAGE',
        assignedMachineId: 'TRAC-01',
        assignedMachineName: 'John Deere 8RX 410',
        operatorName: 'Marcus Vance',
        priority: 'MEDIUM',
        status: 'ACTIVE',
        scheduledStartTime: '09:00 Today',
        targetAreaHa: 54.2,
        completedAreaHa: 18.0,
        prescriptionRate: 'Working Depth: 6.5 cm',
        notes: 'Incorporate residue and trigger volunteer germination before cover crop drill.'
      },
      {
        id: 'WO-004',
        code: 'WO-2026-004',
        title: 'Autonomous Multispectral Scouting Drone Flight',
        fieldId: 'F-03',
        fieldName: 'High Ridge Canola',
        taskType: 'INSPECTION',
        assignedMachineId: 'DRONE-01',
        assignedMachineName: 'DJI Agras T50',
        operatorName: 'Autonomous Agronomy AI',
        priority: 'MEDIUM',
        status: 'ACTIVE',
        scheduledStartTime: '10:00 Today',
        targetAreaHa: 62.4,
        completedAreaHa: 48.0,
        prescriptionRate: '5 Band Multispectral + Thermal',
        notes: 'Mapping pod fill uniformity and sclerotinia stem rot hotspots.'
      },
      {
        id: 'WO-005',
        code: 'WO-2026-005',
        title: 'Precision Variable-Rate Nitrogen Top-Dress',
        fieldId: 'F-02',
        fieldName: 'Mill Creek Basin',
        taskType: 'FERTILIZING',
        assignedMachineId: 'TRAC-02',
        assignedMachineName: 'Fendt 1050 Vario',
        operatorName: 'Liam O’Connor',
        priority: 'HIGH',
        status: 'PLANNED',
        scheduledStartTime: '14:00 Today',
        targetAreaHa: 48.6,
        completedAreaHa: 0,
        prescriptionRate: '120 - 180 kg/ha N-Sensor Map',
        notes: 'Prescription map synced from Yara N-Sensor raster.'
      }
    ];
  }

  private getInitialAlerts(): FarmAlert[] {
    return [
      {
        id: 'ALT-101',
        timestamp: '10:42 AM',
        severity: 'CRITICAL',
        type: 'LOW_SOIL_MOISTURE',
        fieldId: 'F-04',
        fieldName: 'Sunnyside Maize Plateau',
        title: 'Critical Soil Moisture Deficit',
        message: 'Root-zone moisture in south sector dropped to 24% (below wilting threshold 26%).',
        actionRequired: 'Automated pivot irrigation PIVOT-01 engaged at 15 mm/h.',
        acknowledged: false
      },
      {
        id: 'ALT-102',
        timestamp: '09:15 AM',
        severity: 'WARNING',
        type: 'HARVEST_WINDOW',
        fieldId: 'F-07',
        fieldName: 'Grand Prairie Gold',
        title: 'Optimal Grain Harvest Window Active',
        message: 'Winter wheat reached 14.8% grain moisture. Rain forecast in 10 hours.',
        actionRequired: 'Combine harvester Lexion 8900 running at 94% efficiency.',
        acknowledged: true
      },
      {
        id: 'ALT-103',
        timestamp: '08:30 AM',
        severity: 'INFO',
        type: 'DISEASE_RISK',
        fieldId: 'F-04',
        fieldName: 'Sunnyside Maize Plateau',
        title: 'Foliar Blight Anomaly Flagged',
        message: 'Drone NDVI scan detected 0.61 dip in sector B-4 indicating early blighting.',
        actionRequired: 'Work Order WO-2026-002 fungicide pass dispatched.',
        acknowledged: true
      }
    ];
  }

  private getInitialAIInsights(): AIInsight[] {
    return [
      {
        id: 'INS-01',
        category: 'PREDICTION',
        target: 'Field 07 — Winter Wheat',
        title: 'Peak Yield Potential Identified',
        confidencePct: 94,
        reasoning: 'GDD thermal accumulation curve is 4.2% ahead of 5-year average with optimal grain filling solar radiation.',
        recommendedAction: 'Complete harvest prior to 20:00 tonight to prevent 0.4 t/ha rain shatter loss.',
        impactMetric: '+8.2% Harvest Value ($14,200)'
      },
      {
        id: 'INS-02',
        category: 'RECOMMENDATION',
        target: 'Field 04 — Maize Plateau',
        title: 'Dynamic Deficit Irrigation Advisory',
        confidencePct: 88,
        reasoning: 'Transpiration demand is peaking due to 22 km/h wind gusts while root depth is currently 45 cm.',
        recommendedAction: 'Increase pivot cycle speed by 15% and schedule night pulse for maximum infiltration.',
        impactMetric: '-18% Water Runoff Waste'
      },
      {
        id: 'INS-03',
        category: 'ALERT',
        target: 'Field 02 — Spring Barley',
        title: 'Nitrogen Spatial Heterogeneity',
        confidencePct: 91,
        reasoning: 'NDRE vegetation spectral index shows 22% nitrogen variation across sandy soil veins.',
        recommendedAction: 'Execute variable-rate top dressing work order WO-2026-005 immediately.',
        impactMetric: '+0.6 t/ha Malting Yield'
      }
    ];
  }

  private getInitialAuditLogs(): { timestamp: string; user: string; action: string; details: string }[] {
    return [
      { timestamp: '10:45:12', user: 'System Telemetry Daemon', action: 'TELEMETRY_SYNC', details: 'Streamed 1,480 IoT packets across 5 machines and 18 soil probes' },
      { timestamp: '10:30:00', user: 'Elena Rostova', action: 'COMBINE_START', details: 'Initiated harvest swath on Field 07 (Grand Prairie Gold)' },
      { timestamp: '10:14:22', user: 'Chief Agronomist', action: 'IRRIGATION_AUTO', details: 'Pivot Delta-01 auto-started on Field 04' },
      { timestamp: '09:50:00', user: 'System AI Engine', action: 'ANOMALY_DETECT', details: 'Flagged foliar stress on Field 04 from multispectral drone pass' }
    ];
  }
}
