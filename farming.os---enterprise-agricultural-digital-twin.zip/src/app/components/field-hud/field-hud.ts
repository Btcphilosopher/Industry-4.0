import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FarmDataService } from '../../core/services/farm-data.service';
import { GeminiAgronomistService } from '../../core/services/gemini-agronomist.service';
import { FieldDigitalTwin } from '../../core/models/farm.model';

@Component({
  selector: 'app-field-hud',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (farmData.selectedField(); as field) {
      <div class="h-full flex flex-col bg-[#080808]/95 backdrop-blur-xl border-l border-white/10 text-[#d1d5db] shadow-2xl overflow-y-auto font-sans">
        <!-- Header: Field Code & Close Button -->
        <div class="p-4 border-b border-white/10 flex items-center justify-between bg-black/80 sticky top-0 z-10 backdrop-blur-md">
          <div class="flex items-center gap-2.5">
            <div class="w-8 h-8 rounded bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 font-display font-bold text-sm shadow-[0_0_10px_rgba(16,185,129,0.3)]">
              {{ field.id.split('-')[1] }}
            </div>
            <div>
              <div class="flex items-center gap-2">
                <h2 class="text-sm font-bold tracking-tight text-white font-display">{{ field.code }}</h2>
                <span class="px-2 py-0.5 rounded-full text-[10px] font-mono font-medium bg-white/5 text-emerald-400 border border-white/10">
                  {{ field.areaHa }} ha
                </span>
              </div>
              <p class="text-xs text-white/50 truncate max-w-[190px]">{{ field.name }}</p>
            </div>
          </div>
          <button 
            type="button"
            (click)="farmData.selectField(null)"
            class="p-1.5 rounded-lg text-white/50 hover:text-white hover:bg-white/5 transition-colors cursor-pointer">
            <mat-icon class="text-base leading-none">close</mat-icon>
          </button>
        </div>

        <div class="p-4 space-y-4 flex-1">
          <!-- Crop Profile Card -->
          <div class="bg-white/5 border border-white/10 rounded-lg p-3.5 space-y-3">
            <div class="flex items-center justify-between">
              <div class="flex items-center gap-2 text-emerald-400">
                <mat-icon class="text-base">grass</mat-icon>
                <span class="text-xs font-semibold uppercase tracking-wider">Crop Digital Twin</span>
              </div>
              <span class="text-xs font-mono font-bold text-white">{{ field.crop }}</span>
            </div>

            <div class="grid grid-cols-2 gap-2 text-[11px]">
              <div class="bg-black/60 p-2 rounded-lg border border-white/10">
                <div class="text-white/40">Variety</div>
                <div class="font-semibold text-white truncate">{{ field.variety }}</div>
              </div>
              <div class="bg-black/60 p-2 rounded-lg border border-white/10">
                <div class="text-white/40">Harvest Forecast</div>
                <div class="font-semibold text-amber-400">{{ field.expectedHarvest }}</div>
              </div>
            </div>

            <!-- Growth Stage Indicator -->
            <div class="space-y-1.5">
              <div class="flex justify-between text-xs">
                <span class="text-white/50">Phenological Stage</span>
                <span class="font-mono font-bold text-emerald-400">{{ field.growthStage.replace('_', ' ') }}</span>
              </div>
              <div class="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
                <div 
                  class="h-full bg-emerald-500 transition-all duration-500 rounded-full shadow-[0_0_8px_rgba(16,185,129,0.6)]"
                  [style.width.%]="field.growthIndex * 100">
                </div>
              </div>
            </div>
          </div>

          <!-- Soil & Microclimate Gauges -->
          <div class="bg-white/5 border border-white/10 rounded-lg p-3.5 space-y-3">
            <div class="flex items-center justify-between text-xs">
              <div class="flex items-center gap-1.5 text-blue-400">
                <mat-icon class="text-base">sensors</mat-icon>
                <span class="font-semibold uppercase tracking-wider">Soil & Microclimate</span>
              </div>
              <span class="text-[10px] font-mono text-white/50">{{ field.soilType }}</span>
            </div>

            <div class="grid grid-cols-3 gap-2">
              <div class="bg-black/60 p-2.5 rounded-lg border border-white/10 text-center">
                <div class="text-[10px] text-white/40 mb-0.5">Moisture</div>
                <div class="text-base font-bold font-mono text-blue-400">{{ field.soilMoisturePct }}%</div>
                <div class="text-[9px] text-blue-500/80 mt-0.5">Opt: 28-36%</div>
              </div>

              <div class="bg-black/60 p-2.5 rounded-lg border border-white/10 text-center">
                <div class="text-[10px] text-white/40 mb-0.5">Soil Temp</div>
                <div class="text-base font-bold font-mono text-amber-400">{{ field.soilTemperatureC }}°C</div>
                <div class="text-[9px] text-white/40 mt-0.5">10cm depth</div>
              </div>

              <div class="bg-black/60 p-2.5 rounded-lg border border-white/10 text-center">
                <div class="text-[10px] text-white/40 mb-0.5">Soil pH</div>
                <div class="text-base font-bold font-mono text-emerald-400">{{ field.soilPH }}</div>
                <div class="text-[9px] text-emerald-500/80 mt-0.5">OM: {{ field.soilOrganicMatterPct }}%</div>
              </div>
            </div>

            <!-- N-P-K Bar Levels -->
            <div class="space-y-1.5 pt-1">
              <div class="text-[10px] font-mono text-white/40 uppercase tracking-wider">Nutrient Bio-Availability (NPK)</div>
              <div class="space-y-1">
                <div class="flex items-center gap-2 text-[11px]">
                  <span class="w-4 font-mono font-bold text-blue-400">N</span>
                  <div class="flex-1 h-1.5 bg-white/10 rounded-full overflow-hidden">
                    <div class="h-full bg-blue-500 rounded-full" [style.width.%]="(field.nitrogenKgHa / 220) * 100"></div>
                  </div>
                  <span class="w-16 text-right font-mono text-white/70">{{ field.nitrogenKgHa }} kg/ha</span>
                </div>
                <div class="flex items-center gap-2 text-[11px]">
                  <span class="w-4 font-mono font-bold text-amber-400">P</span>
                  <div class="flex-1 h-1.5 bg-white/10 rounded-full overflow-hidden">
                    <div class="h-full bg-amber-500 rounded-full" [style.width.%]="(field.phosphorusPpm / 40) * 100"></div>
                  </div>
                  <span class="w-16 text-right font-mono text-white/70">{{ field.phosphorusPpm }} ppm</span>
                </div>
                <div class="flex items-center gap-2 text-[11px]">
                  <span class="w-4 font-mono font-bold text-purple-400">K</span>
                  <div class="flex-1 h-1.5 bg-white/10 rounded-full overflow-hidden">
                    <div class="h-full bg-purple-500 rounded-full" [style.width.%]="(field.potassiumPpm / 300) * 100"></div>
                  </div>
                  <span class="w-16 text-right font-mono text-white/70">{{ field.potassiumPpm }} ppm</span>
                </div>
              </div>
            </div>
          </div>

          <!-- Yield & Health Predictions -->
          <div class="bg-white/5 border border-white/10 rounded-lg p-3.5 space-y-2.5">
            <div class="flex items-center justify-between text-xs">
              <div class="flex items-center gap-1.5 text-amber-400">
                <mat-icon class="text-base">analytics</mat-icon>
                <span class="font-semibold uppercase tracking-wider">Yield & Biomass Model</span>
              </div>
              <span class="text-emerald-400 font-mono font-bold">NDVI: {{ field.ndvi }}</span>
            </div>

            <div class="flex items-end justify-between p-2.5 bg-black/60 rounded-lg border border-white/10">
              <div>
                <div class="text-[10px] text-white/40">Target vs AI Forecast</div>
                <div class="text-lg font-bold font-display text-white">
                  {{ field.currentYieldForecastTonneHa }} <span class="text-xs font-normal text-white/40">t/ha</span>
                </div>
              </div>
              <div class="text-right">
                <div class="text-[10px] text-white/40">Target</div>
                <div class="text-sm font-mono text-white/80">{{ field.yieldTargetTonneHa }} t/ha</div>
              </div>
            </div>
          </div>

          <!-- Irrigation & Action Controls -->
          <div class="bg-white/5 border border-white/10 rounded-lg p-3.5 space-y-2.5">
            <div class="flex items-center justify-between text-xs">
              <span class="font-semibold text-white/80">Irrigation Actuator</span>
              <span 
                [class.text-cyan-400]="field.irrigationStatus !== 'OFF'"
                [class.text-white/40]="field.irrigationStatus === 'OFF'"
                class="font-mono text-xs font-bold">
                {{ field.irrigationStatus }}
              </span>
            </div>

            <button 
              type="button"
              (click)="farmData.toggleIrrigationForField(field.id)"
              [class.bg-cyan-600]="field.irrigationStatus !== 'OFF'"
              [class.hover:bg-cyan-500]="field.irrigationStatus !== 'OFF'"
              [class.bg-white/5]="field.irrigationStatus === 'OFF'"
              [class.hover:bg-white/10]="field.irrigationStatus === 'OFF'"
              [class.border]="field.irrigationStatus === 'OFF'"
              [class.border-white/10]="field.irrigationStatus === 'OFF'"
              class="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-xs font-semibold text-white transition-all shadow-md cursor-pointer">
              <mat-icon class="text-base">water_drop</mat-icon>
              {{ field.irrigationStatus === 'OFF' ? 'Engage Precision Irrigation' : 'Disengage Active Pivot' }}
            </button>
          </div>

          <!-- AI Agronomist Diagnostic Button -->
          <button 
            type="button"
            (click)="consultAIAgronomist(field)"
            [disabled]="agronomistService.isAnalyzing()"
            class="w-full flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg text-xs font-bold bg-emerald-500 hover:bg-emerald-400 text-black transition-all shadow-[0_0_12px_rgba(16,185,129,0.4)] cursor-pointer disabled:opacity-50">
            <mat-icon class="text-base">{{ agronomistService.isAnalyzing() ? 'sync' : 'psychology' }}</mat-icon>
            {{ agronomistService.isAnalyzing() ? 'Analyzing Field Twin...' : 'Consult AI Agronomist' }}
          </button>

          <!-- AI Diagnostic Box -->
          @if (agronomistService.lastResponse(); as aiRes) {
            <div class="bg-black/60 border border-emerald-500/40 rounded-lg p-3 space-y-2 text-xs">
              <div class="flex items-center justify-between text-emerald-400 font-semibold">
                <span class="flex items-center gap-1.5">
                  <mat-icon class="text-sm">auto_awesome</mat-icon>
                  AI Agronomic Advisory
                </span>
                <span class="text-[10px] font-mono bg-emerald-500/20 text-emerald-400 px-1.5 py-0.5 rounded border border-emerald-500/30">
                  {{ aiRes.riskLevel }} RISK
                </span>
              </div>
              <p class="text-white/80 leading-relaxed text-[11px]">{{ aiRes.analysis }}</p>
              <div class="space-y-1 pt-1 border-t border-white/10">
                @for (rec of aiRes.recommendations; track rec) {
                  <div class="flex items-start gap-1.5 text-[11px] text-emerald-300">
                    <span class="text-emerald-400 font-bold">•</span>
                    <span>{{ rec }}</span>
                  </div>
                }
              </div>
            </div>
          }
        </div>
      </div>
    }
  `,
  styles: [`
    :host {
      display: block;
      height: 100%;
    }
  `]
})
export class FieldHUD {
  readonly farmData = inject(FarmDataService);
  readonly agronomistService = inject(GeminiAgronomistService);

  consultAIAgronomist(field: FieldDigitalTwin) {
    const prompt = `Analyze Field ${field.code} (${field.name}): Crop ${field.crop} (${field.variety}), Soil moisture ${field.soilMoisturePct}%, NDVI ${field.ndvi}, NPK (${field.nitrogenKgHa}-${field.phosphorusPpm}-${field.potassiumPpm}), Growth stage ${field.growthStage}. Provide risk assessment, yield outlook, and recommended agronomy actions.`;
    this.agronomistService.consultAgronomist(prompt, field as unknown as Record<string, unknown>);
  }
}
