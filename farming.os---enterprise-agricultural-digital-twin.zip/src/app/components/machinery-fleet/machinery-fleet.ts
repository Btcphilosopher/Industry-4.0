import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FarmDataService } from '../../core/services/farm-data.service';

@Component({
  selector: 'app-machinery-fleet',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full overflow-y-auto p-5 space-y-6 text-slate-100 bg-slate-950/80">
      <!-- Fleet Header -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h1 class="text-xl font-bold font-display text-white flex items-center gap-2.5">
            <mat-icon class="text-emerald-400">precision_manufacturing</mat-icon>
            Autonomous & Connected Fleet Manager
          </h1>
          <p class="text-xs text-slate-400 mt-0.5">ISOBUS / CAN-Bus Telemetry Stream • RTK GNSS ±1.5cm Precision</p>
        </div>
        <div class="flex items-center gap-2 text-xs font-mono">
          <span class="px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-semibold">
            {{ activeMachinesCount }} / {{ farmData.machines().length }} ACTIVE IN FIELD
          </span>
        </div>
      </div>

      <!-- Machinery Cards Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        @for (machine of farmData.machines(); track machine.id) {
          <div 
            [class.border-cyan-500/50]="farmData.trackedMachineId() === machine.id"
            [class.bg-slate-900/95]="farmData.trackedMachineId() === machine.id"
            [class.border-slate-800]="farmData.trackedMachineId() !== machine.id"
            class="bg-slate-900/80 border rounded-2xl p-4.5 space-y-4 shadow-xl transition-all hover:border-slate-700">
            <!-- Machine Title & Status -->
            <div class="flex items-start justify-between">
              <div class="flex items-center gap-3">
                <div 
                  [class.bg-emerald-500/20]="machine.state === 'WORKING'"
                  [class.text-emerald-400]="machine.state === 'WORKING'"
                  [class.bg-slate-800]="machine.state !== 'WORKING'"
                  [class.text-slate-400]="machine.state !== 'WORKING'"
                  class="w-10 h-10 rounded-xl flex items-center justify-center font-bold">
                  <mat-icon class="text-xl">
                    {{ machine.type === 'COMBINE' ? 'agriculture' : (machine.type === 'DRONE' ? 'flight' : 'directions_car') }}
                  </mat-icon>
                </div>
                <div>
                  <h3 class="text-sm font-bold text-white font-display">{{ machine.name }}</h3>
                  <div class="text-[11px] text-slate-400 font-mono">{{ machine.model || machine.name }} ({{ machine.id }})</div>
                </div>
              </div>

              <span 
                [class.bg-emerald-500/10]="machine.state === 'WORKING'"
                [class.text-emerald-400]="machine.state === 'WORKING'"
                [class.border-emerald-500/30]="machine.state === 'WORKING'"
                [class.bg-slate-800]="machine.state !== 'WORKING'"
                [class.text-slate-400]="machine.state !== 'WORKING'"
                class="px-2 py-0.5 rounded-full text-[10px] font-mono font-semibold border">
                {{ machine.state }}
              </span>
            </div>

            <!-- Operational Metrics -->
            <div class="grid grid-cols-3 gap-2 text-center text-xs">
              <div class="bg-slate-950/70 p-2 rounded-xl border border-slate-800">
                <div class="text-[10px] text-slate-400">Speed</div>
                <div class="font-mono font-bold text-white text-sm">{{ machine.speedKmh.toFixed(1) }} <span class="text-[9px] font-normal text-slate-400">km/h</span></div>
              </div>
              <div class="bg-slate-950/70 p-2 rounded-xl border border-slate-800">
                <div class="text-[10px] text-slate-400">Engine Load</div>
                <div class="font-mono font-bold text-amber-300 text-sm">{{ machine.engineLoadPct || 74 }}%</div>
              </div>
              <div class="bg-slate-950/70 p-2 rounded-xl border border-slate-800">
                <div class="text-[10px] text-slate-400">Fuel Level</div>
                <div class="font-mono font-bold text-cyan-300 text-sm">{{ machine.fuelPct }}%</div>
              </div>
            </div>

            <!-- Implements & Tank / Hopper Details -->
            <div class="bg-slate-950/60 p-3 rounded-xl border border-slate-800/80 space-y-2 text-xs">
              <div class="flex justify-between items-center text-[11px]">
                <span class="text-slate-400">Attached Implement:</span>
                <span class="font-semibold text-white">{{ machine.currentImplement }} ({{ machine.workingWidthM }}m)</span>
              </div>
              <div class="flex justify-between items-center text-[11px]">
                <span class="text-slate-400">Operator / Mode:</span>
                <span class="font-mono text-emerald-400">{{ machine.operatorName }}</span>
              </div>

              @if (machine.grainTankFillPct !== undefined) {
                <div class="space-y-1 pt-1 border-t border-slate-800/60">
                  <div class="flex justify-between text-[11px]">
                    <span class="text-slate-400">Grain Hopper Fill</span>
                    <span class="font-mono font-bold text-amber-300">{{ machine.grainTankFillPct }}%</span>
                  </div>
                  <div class="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div 
                      class="h-full bg-amber-400 rounded-full transition-all"
                      [style.width.%]="machine.grainTankFillPct">
                    </div>
                  </div>
                </div>
              }
            </div>

            <!-- Action Controls -->
            <div class="flex items-center gap-2 pt-1">
              <button 
                (click)="toggleTrack(machine.id)"
                [class.bg-cyan-600]="farmData.trackedMachineId() === machine.id"
                [class.text-white]="farmData.trackedMachineId() === machine.id"
                [class.bg-slate-800]="farmData.trackedMachineId() !== machine.id"
                [class.text-slate-200]="farmData.trackedMachineId() !== machine.id"
                class="flex-1 py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 hover:bg-cyan-500 transition-all shadow-md">
                <mat-icon class="text-sm">my_location</mat-icon>
                {{ farmData.trackedMachineId() === machine.id ? 'Tracking Live Cam' : 'Lock Camera View' }}
              </button>

              <button 
                (click)="farmData.showMachineryTrails.set(!farmData.showMachineryTrails())"
                title="Toggle Swath Trails"
                class="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-all">
                <mat-icon class="text-base">route</mat-icon>
              </button>
            </div>
          </div>
        }
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      height: 100%;
    }
  `]
})
export class MachineryFleet {
  readonly farmData = inject(FarmDataService);

  get activeMachinesCount(): number {
    return this.farmData.machines().filter(m => m.state === 'WORKING').length;
  }

  toggleTrack(machineId: string) {
    if (this.farmData.trackedMachineId() === machineId) {
      this.farmData.trackMachine(null);
    } else {
      this.farmData.trackMachine(machineId);
    }
  }
}
