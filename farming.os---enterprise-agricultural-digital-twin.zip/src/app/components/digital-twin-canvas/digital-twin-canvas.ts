import { 
  ChangeDetectionStrategy, 
  Component, 
  ElementRef, 
  OnDestroy, 
  OnInit, 
  ViewChild, 
  inject, 
  effect 
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FarmDataService } from '../../core/services/farm-data.service';
import { FieldDigitalTwin, Point2D, HeatmapMode } from '../../core/models/farm.model';

interface RainParticle {
  x: number;
  y: number;
  speed: number;
  length: number;
  opacity: number;
}

interface SprayParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
}

@Component({
  selector: 'app-digital-twin-canvas',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-full bg-slate-950 overflow-hidden select-none">
      <!-- Main Rendering Canvas -->
      <canvas 
        #twinCanvas 
        class="w-full h-full cursor-grab active:cursor-grabbing block"
        (mousedown)="onMouseDown($event)"
        (mousemove)="onMouseMove($event)"
        (mouseup)="onMouseUp()"
        (mouseleave)="onMouseUp()"
        (wheel)="onWheel($event)"
        (click)="onCanvasClick($event)">
      </canvas>

      <!-- Floating Map Overlays & HUD Controls (Immersive UI) -->
      <!-- Top Left: Map Coordinates & Scale HUD -->
      <div class="absolute top-4 left-4 z-10 flex items-center gap-3 bg-black/60 backdrop-blur-md border border-white/10 rounded-lg px-3 py-2 text-xs font-mono shadow-2xl text-white/80">
        <div class="flex items-center gap-1.5 text-emerald-400">
          <span class="inline-block w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.8)] animate-pulse"></span>
          <span class="font-bold tracking-wider">GIS COORD:</span>
        </div>
        <span>{{ cursorGeoCoord.lat.toFixed(5) }}°N, {{ cursorGeoCoord.lng.toFixed(5) }}°W</span>
        <span class="text-white/20">|</span>
        <span class="text-white/60">ELEV: {{ cursorElevation.toFixed(1) }}m</span>
        <span class="text-white/20">|</span>
        <span class="text-emerald-400 font-bold">ZOOM: {{ (cameraZoom * 100).toFixed(0) }}%</span>
      </div>

      <!-- Top Right: View Modes & Camera Reset Controls -->
      <div class="absolute top-4 right-4 z-10 flex items-center gap-2">
        <!-- View Mode Selector -->
        <div class="flex bg-black/60 backdrop-blur-md border border-white/10 rounded-lg p-1 shadow-2xl">
          <button 
            type="button"
            (click)="farmData.setViewMode('2D_GIS')"
            [class.bg-emerald-500]="farmData.viewMode() === '2D_GIS'"
            [class.text-black]="farmData.viewMode() === '2D_GIS'"
            [class.font-bold]="farmData.viewMode() === '2D_GIS'"
            [class.text-white/60]="farmData.viewMode() !== '2D_GIS'"
            class="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium transition-all hover:text-white cursor-pointer">
            <mat-icon class="text-base leading-none">map</mat-icon>
            2D GIS
          </button>
          <button 
            type="button"
            (click)="farmData.setViewMode('3D_TWIN')"
            [class.bg-emerald-500]="farmData.viewMode() === '3D_TWIN'"
            [class.text-black]="farmData.viewMode() === '3D_TWIN'"
            [class.font-bold]="farmData.viewMode() === '3D_TWIN'"
            [class.text-white/60]="farmData.viewMode() !== '3D_TWIN'"
            class="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium transition-all hover:text-white cursor-pointer">
            <mat-icon class="text-base leading-none">view_in_ar</mat-icon>
            3D Farm Twin
          </button>
          <button 
            type="button"
            (click)="farmData.setViewMode('HYBRID')"
            [class.bg-emerald-500]="farmData.viewMode() === 'HYBRID'"
            [class.text-black]="farmData.viewMode() === 'HYBRID'"
            [class.font-bold]="farmData.viewMode() === 'HYBRID'"
            [class.text-white/60]="farmData.viewMode() !== 'HYBRID'"
            class="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium transition-all hover:text-white cursor-pointer">
            <mat-icon class="text-base leading-none">layers</mat-icon>
            Hybrid
          </button>
        </div>

        <!-- Camera Preset & Measurement Tool -->
        <div class="flex bg-black/60 backdrop-blur-md border border-white/10 rounded-lg p-1 shadow-2xl">
          <button 
            type="button"
            (click)="toggleMeasureTool()"
            [class.bg-blue-600]="farmData.isMeasureToolActive()"
            [class.text-white]="farmData.isMeasureToolActive()"
            [class.text-white/60]="!farmData.isMeasureToolActive()"
            title="Measure Distance & Area"
            class="p-1.5 rounded text-white/60 hover:text-white hover:bg-white/5 transition-all cursor-pointer">
            <mat-icon class="text-base leading-none">straighten</mat-icon>
          </button>
          <button 
            type="button"
            (click)="resetCamera()"
            title="Reset Farm Overview"
            class="p-1.5 rounded text-white/60 hover:text-white hover:bg-white/5 transition-all cursor-pointer">
            <mat-icon class="text-base leading-none">filter_center_focus</mat-icon>
          </button>
        </div>
      </div>

      <!-- Bottom Center: Spectral Visual Layers Bar -->
      <div class="absolute bottom-6 left-1/2 -translate-x-1/2 z-10 flex items-center gap-1.5 bg-black/60 backdrop-blur-md border border-white/10 rounded-lg p-1.5 shadow-2xl overflow-x-auto max-w-[92vw]">
        <span class="px-2.5 text-[10px] font-mono text-white/40 uppercase tracking-widest font-bold">Visual Layers:</span>
        @for (layer of heatmapLayers; track layer.mode) {
          <button 
            type="button"
            (click)="farmData.setHeatmapMode(layer.mode)"
            [class.bg-emerald-500]="farmData.heatmapMode() === layer.mode"
            [class.text-black]="farmData.heatmapMode() === layer.mode"
            [class.font-bold]="farmData.heatmapMode() === layer.mode"
            [class.bg-white/5]="farmData.heatmapMode() !== layer.mode"
            [class.text-white/60]="farmData.heatmapMode() !== layer.mode"
            [class.border]="farmData.heatmapMode() !== layer.mode"
            [class.border-white/10]="farmData.heatmapMode() !== layer.mode"
            class="flex items-center gap-1.5 px-3 py-1 rounded text-[10px] uppercase font-bold whitespace-nowrap transition-all cursor-pointer hover:text-white">
            <span class="w-1.5 h-1.5 rounded-full" [style.backgroundColor]="layer.dotColor"></span>
            {{ layer.label }}
          </button>
        }
      </div>

      <!-- Telemetry Stream Watermark (Bottom Right) -->
      <div class="absolute bottom-6 right-6 text-right font-mono pointer-events-none hidden md:block">
        <div class="text-[10px] text-white/40 uppercase tracking-widest">Telemetry Stream</div>
        <div class="text-emerald-500 text-xs font-bold">LAT: 52.3842 | LON: -1.4822 | ALT: 114m</div>
        <div class="text-white/60 text-[10px]">SATELLITE SYNC: 14/14 CHANNELS</div>
      </div>

      <!-- Measurement Floating Output Badge -->
      @if (farmData.isMeasureToolActive() && measureDistanceM > 0) {
        <div class="absolute top-16 left-4 z-10 bg-black/80 backdrop-blur-md border border-cyan-500/50 rounded-lg px-3 py-2 text-xs font-mono text-cyan-200 shadow-2xl flex items-center gap-3">
          <mat-icon class="text-cyan-400 text-sm">square_foot</mat-icon>
          <div>
            <div>Distance: <span class="font-bold text-white">{{ measureDistanceM.toFixed(1) }} m</span></div>
            <div>Area: <span class="font-bold text-white">{{ measureAreaHa.toFixed(2) }} ha</span></div>
          </div>
          <button type="button" (click)="clearMeasurement()" class="text-cyan-400 hover:text-white ml-2 text-xs underline cursor-pointer">Clear</button>
        </div>
      }

      <!-- Hover Tooltip -->
      @if (hoveredField) {
        <div 
          class="absolute pointer-events-none z-20 bg-slate-900/95 border border-emerald-500/60 rounded-xl p-3 shadow-2xl text-xs font-sans max-w-xs"
          [style.left.px]="hoverX + 15"
          [style.top.px]="hoverY + 15">
          <div class="flex items-center justify-between gap-2 border-b border-slate-800 pb-1.5 mb-1.5">
            <span class="font-bold text-emerald-400 font-display">{{ hoveredField.code }}</span>
            <span class="text-slate-400 font-mono">{{ hoveredField.areaHa }} ha</span>
          </div>
          <div class="font-medium text-white mb-1">{{ hoveredField.name }}</div>
          <div class="grid grid-cols-2 gap-x-2 gap-y-1 text-[11px] text-slate-300">
            <div>Crop: <span class="text-emerald-300 font-semibold">{{ hoveredField.crop }}</span></div>
            <div>Stage: <span class="text-slate-200">{{ hoveredField.growthStage }}</span></div>
            <div>Moisture: <span class="text-cyan-300 font-semibold">{{ hoveredField.soilMoisturePct }}%</span></div>
            <div>NDVI: <span class="text-emerald-300 font-semibold">{{ hoveredField.ndvi }}</span></div>
            <div>Forecast: <span class="text-amber-300 font-semibold">{{ hoveredField.currentYieldForecastTonneHa }} t/ha</span></div>
            <div>Risk: <span [class.text-red-400]="hoveredField.diseaseRisk !== 'LOW'" class="text-emerald-400">{{ hoveredField.diseaseRisk }}</span></div>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    :host {
      display: block;
      width: 100%;
      height: 100%;
    }
  `]
})
export class DigitalTwinCanvas implements OnInit, OnDestroy {
  @ViewChild('twinCanvas', { static: true }) canvasRef!: ElementRef<HTMLCanvasElement>;
  
  readonly farmData = inject(FarmDataService);

  readonly heatmapLayers: { mode: HeatmapMode; label: string; dotColor: string }[] = [
    { mode: 'RGB', label: 'True Color (RGB)', dotColor: '#10b981' },
    { mode: 'NDVI', label: 'NDVI Vegetation', dotColor: '#22c55e' },
    { mode: 'NDRE', label: 'NDRE Canopy Red-Edge', dotColor: '#84cc16' },
    { mode: 'SOIL_MOISTURE', label: 'Soil Moisture %', dotColor: '#06b6d4' },
    { mode: 'SOIL_TEMP', label: 'Soil Temperature °C', dotColor: '#f97316' },
    { mode: 'NITROGEN', label: 'Nitrogen (N) kg/ha', dotColor: '#3b82f6' },
    { mode: 'BIOMASS', label: 'Biomass Index', dotColor: '#a855f7' },
    { mode: 'CROP_STRESS', label: 'Stress Heatmap', dotColor: '#ef4444' },
    { mode: 'YIELD_PREDICTION', label: 'Yield Prediction', dotColor: '#eab308' },
    { mode: 'ELEVATION', label: 'Terrain Slope/DEM', dotColor: '#64748b' }
  ];

  // Camera state
  cameraX = 0;
  cameraY = 0;
  cameraZoom = 1.0;
  cameraTilt = 0.55; // 3D tilt factor (isometric)
  cameraRotationDeg = 0;

  // Interaction state
  private isDragging = false;
  private dragStartX = 0;
  private dragStartY = 0;
  private animFrameId: number | null = null;

  // Measurement State
  measurePoints: Point2D[] = [];
  measureDistanceM = 0;
  measureAreaHa = 0;

  // Cursor & Hover Info
  cursorGeoCoord = { lat: 53.2307, lng: -0.5406 };
  cursorElevation = 26.4;
  hoveredField: FieldDigitalTwin | null = null;
  hoverX = 0;
  hoverY = 0;

  // Particle systems
  private rainParticles: RainParticle[] = [];
  private sprayParticles: SprayParticle[] = [];

  constructor() {
    // React to tracked machine camera lock
    effect(() => {
      const machine = this.farmData.trackedMachine();
      if (machine) {
        this.centerOnPoint(machine.position.x, machine.position.y);
      }
    });

    // React to selected field camera lock
    effect(() => {
      const field = this.farmData.selectedField();
      if (field && !this.farmData.trackedMachineId()) {
        this.centerOnPoint(field.center.x, field.center.y);
      }
    });
  }

  ngOnInit() {
    this.initCanvasSize();
    this.initParticles();
    this.startRenderLoop();
  }

  ngOnDestroy() {
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
    }
  }

  private initCanvasSize() {
    const canvas = this.canvasRef.nativeElement;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * (window.devicePixelRatio || 1);
    canvas.height = rect.height * (window.devicePixelRatio || 1);
    this.resetCamera();
  }

  private initParticles() {
    this.rainParticles = [];
    for (let i = 0; i < 180; i++) {
      this.rainParticles.push({
        x: Math.random() * 2000,
        y: Math.random() * 1200,
        speed: 12 + Math.random() * 8,
        length: 12 + Math.random() * 10,
        opacity: 0.2 + Math.random() * 0.5
      });
    }
  }

  resetCamera() {
    const canvas = this.canvasRef.nativeElement;
    this.cameraX = canvas.width / (2 * (window.devicePixelRatio || 1)) - 600;
    this.cameraY = canvas.height / (2 * (window.devicePixelRatio || 1)) - 420;
    this.cameraZoom = 0.85;
  }

  centerOnPoint(worldX: number, worldY: number) {
    const canvas = this.canvasRef.nativeElement;
    const viewMode = this.farmData.viewMode();
    const screenX = canvas.width / (2 * (window.devicePixelRatio || 1));
    const screenY = canvas.height / (2 * (window.devicePixelRatio || 1));

    if (viewMode === '3D_TWIN') {
      const isoY = worldY * this.cameraTilt;
      this.cameraX = screenX - (worldX * this.cameraZoom);
      this.cameraY = screenY - (isoY * this.cameraZoom);
    } else {
      this.cameraX = screenX - (worldX * this.cameraZoom);
      this.cameraY = screenY - (worldY * this.cameraZoom);
    }
  }

  // --- Animation & Render Loop ---
  private startRenderLoop() {
    const loop = () => {
      this.render();
      this.animFrameId = requestAnimationFrame(loop);
    };
    this.animFrameId = requestAnimationFrame(loop);
  }

  private render() {
    const canvas = this.canvasRef.nativeElement;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const width = canvas.width;
    const height = canvas.height;

    // Clear
    ctx.save();
    ctx.scale(dpr, dpr);
    ctx.fillStyle = '#020617'; // dark slate background
    ctx.fillRect(0, 0, width / dpr, height / dpr);

    // Apply Camera Transform
    ctx.translate(this.cameraX, this.cameraY);
    ctx.scale(this.cameraZoom, this.cameraZoom);

    const is3D = this.farmData.viewMode() === '3D_TWIN';

    // 1. Render Farm Terrain Base Grid
    this.drawTerrainBase(ctx, is3D);

    // 2. Render Drainage Waterways & Retention Ponds
    if (this.farmData.showDrainageWaterways()) {
      this.drawDrainage(ctx, is3D);
    }

    // 3. Render Field Digital Twins (Polygons, Textures, Heatmaps, Growth)
    this.drawFields(ctx, is3D);

    // 4. Render Roads & Tracks Network
    this.drawRoads(ctx, is3D);

    // 5. Render Irrigation Networks (Center Pivots, Water Spray particles)
    if (this.farmData.showIrrigationNetwork()) {
      this.drawIrrigation(ctx, is3D);
    }

    // 6. Render Farm Infrastructure (Barns, Silos, Solar Panels, Battery)
    this.drawInfrastructure(ctx, is3D);

    // 7. Render Livestock Pastures
    this.drawLivestock(ctx, is3D);

    // 8. Render Machinery Fleet & Swath Trails
    this.drawMachinery(ctx, is3D);

    // 9. Render GIS Measurement Tool Overlays
    if (this.farmData.isMeasureToolActive()) {
      this.drawMeasurementTool(ctx, is3D);
    }

    // 10. Render Weather Particle System (Rain, Storms, Clouds)
    if (this.farmData.showWeatherParticles()) {
      this.drawWeatherParticles(ctx);
    }

    ctx.restore();
  }

  // --- Draw Helpers ---

  private drawTerrainBase(ctx: CanvasRenderingContext2D, is3D: boolean) {
    ctx.save();
    const gridCols = 14;
    const gridRows = 10;
    const cellSize = 100;

    // Subtle GIS coordinate grid
    ctx.strokeStyle = 'rgba(30, 41, 59, 0.4)';
    ctx.lineWidth = 1;

    for (let r = 0; r <= gridRows; r++) {
      ctx.beginPath();
      const y = r * cellSize;
      const drawY = is3D ? y * this.cameraTilt : y;
      ctx.moveTo(0, drawY);
      ctx.lineTo(gridCols * cellSize, drawY);
      ctx.stroke();
    }

    for (let c = 0; c <= gridCols; c++) {
      ctx.beginPath();
      const x = c * cellSize;
      const startY = is3D ? 0 : 0;
      const endY = is3D ? gridRows * cellSize * this.cameraTilt : gridRows * cellSize;
      ctx.moveTo(x, startY);
      ctx.lineTo(x, endY);
      ctx.stroke();
    }

    // Cadastral farm boundary fence line
    ctx.strokeStyle = 'rgba(16, 185, 129, 0.25)';
    ctx.lineWidth = 2;
    ctx.setLineDash([8, 6]);
    ctx.strokeRect(60, is3D ? 40 : 60, 1140, is3D ? 800 * this.cameraTilt : 800);
    ctx.setLineDash([]);

    ctx.restore();
  }

  private drawDrainage(ctx: CanvasRenderingContext2D, is3D: boolean) {
    const drainage = this.farmData.drainageNodes();
    ctx.save();

    for (const node of drainage) {
      if (node.type === 'DITCH') {
        ctx.beginPath();
        for (let i = 0; i < node.path.length; i++) {
          const pt = node.path[i];
          const px = pt.x;
          const py = is3D ? pt.y * this.cameraTilt : pt.y;
          if (i === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        }
        ctx.strokeStyle = '#0284c7';
        ctx.lineWidth = is3D ? 5 : 6;
        ctx.lineCap = 'round';
        ctx.stroke();

        // Water flow animated dash
        const dashOffset = (Date.now() / 60) % 20;
        ctx.setLineDash([6, 6]);
        ctx.lineDashOffset = -dashOffset;
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.setLineDash([]);
      } else if (node.type === 'RETENTION_POND') {
        ctx.beginPath();
        const start = node.path[0];
        ctx.moveTo(start.x, is3D ? start.y * this.cameraTilt : start.y);
        for (let i = 1; i < node.path.length; i++) {
          const pt = node.path[i];
          ctx.lineTo(pt.x, is3D ? pt.y * this.cameraTilt : pt.y);
        }
        ctx.closePath();
        ctx.fillStyle = 'rgba(14, 116, 144, 0.6)';
        ctx.fill();
        ctx.strokeStyle = '#06b6d4';
        ctx.lineWidth = 1.5;
        ctx.stroke();
      }
    }
    ctx.restore();
  }

  private drawFields(ctx: CanvasRenderingContext2D, is3D: boolean) {
    const fields = this.farmData.fields();
    const selectedId = this.farmData.selectedFieldId();
    const heatmap = this.farmData.heatmapMode();

    for (const field of fields) {
      const isSelected = field.id === selectedId;

      ctx.save();
      ctx.beginPath();

      // Project polygon boundary
      for (let i = 0; i < field.boundary.length; i++) {
        const pt = field.boundary[i];
        const px = pt.x;
        const py = is3D ? pt.y * this.cameraTilt : pt.y;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();

      // Determine fill color based on spectral heatmap or crop stage
      const fillColor = this.getFieldFillColor(field, heatmap);
      ctx.fillStyle = fillColor;
      ctx.fill();

      // Draw procedural crop texture / stalks / furrows
      if (this.farmData.showCropTextures() && heatmap === 'RGB') {
        this.drawCropTexturePattern(ctx, field, is3D);
      }

      // Draw progressive harvest / seeding swath on the field
      if (field.growthStage === 'HARVESTING' && field.harvestProgressPct > 0) {
        this.drawHarvestCutPattern(ctx, field, is3D);
      }

      // Field Boundary Border
      if (isSelected) {
        ctx.strokeStyle = '#10b981';
        ctx.lineWidth = 3;
        ctx.shadowColor = '#10b981';
        ctx.shadowBlur = 12;
      } else {
        ctx.strokeStyle = 'rgba(74, 222, 128, 0.35)';
        ctx.lineWidth = 1.5;
        ctx.shadowBlur = 0;
      }
      ctx.stroke();

      // Field Label & Telemetry Badge in center
      if (this.farmData.showFieldLabels()) {
        const cx = field.center.x;
        const cy = is3D ? field.center.y * this.cameraTilt : field.center.y;

        ctx.shadowBlur = 0;
        ctx.fillStyle = isSelected ? 'rgba(6, 78, 59, 0.9)' : 'rgba(15, 23, 42, 0.85)';
        ctx.strokeStyle = isSelected ? '#10b981' : 'rgba(255, 255, 255, 0.15)';
        ctx.lineWidth = 1;
        
        const labelW = 92;
        const labelH = 34;
        ctx.fillRect(cx - labelW / 2, cy - labelH / 2, labelW, labelH);
        ctx.strokeRect(cx - labelW / 2, cy - labelH / 2, labelW, labelH);

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 10px "Space Grotesk", sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(`${field.code} (${field.areaHa} ha)`, cx, cy - 4);

        ctx.fillStyle = '#a7f3d0';
        ctx.font = '9px "JetBrains Mono", monospace';
        ctx.fillText(`${field.crop.split('/')[0].trim()}`, cx, cy + 9);
      }

      ctx.restore();
    }
  }

  private getFieldFillColor(field: FieldDigitalTwin, heatmap: HeatmapMode): string {
    if (heatmap === 'NDVI') {
      // 0.0 (red) to 1.0 (deep emerald)
      if (field.ndvi > 0.8) return 'rgba(22, 163, 74, 0.75)';
      if (field.ndvi > 0.65) return 'rgba(132, 204, 22, 0.75)';
      if (field.ndvi > 0.5) return 'rgba(234, 179, 8, 0.75)';
      return 'rgba(239, 68, 68, 0.75)';
    }

    if (heatmap === 'SOIL_MOISTURE') {
      // 0% to 50%+ (yellow to deep ocean blue)
      if (field.soilMoisturePct < 25) return 'rgba(245, 158, 11, 0.75)';
      if (field.soilMoisturePct < 32) return 'rgba(6, 182, 212, 0.75)';
      return 'rgba(2, 132, 199, 0.8)';
    }

    if (heatmap === 'NITROGEN') {
      return field.nitrogenKgHa > 170 ? 'rgba(59, 130, 246, 0.8)' : 'rgba(96, 165, 250, 0.6)';
    }

    if (heatmap === 'CROP_STRESS') {
      return field.cropStressPct > 20 ? 'rgba(239, 68, 68, 0.8)' : 'rgba(34, 197, 94, 0.5)';
    }

    if (heatmap === 'YIELD_PREDICTION') {
      return field.currentYieldForecastTonneHa > 8 ? 'rgba(234, 179, 8, 0.8)' : 'rgba(168, 85, 247, 0.6)';
    }

    // Default RGB Realistic Agro Texture Fill
    switch (field.growthStage) {
      case 'BARE_SOIL':
        return '#382b1d'; // dark rich loam
      case 'SEEDING':
        return '#453524';
      case 'GERMINATION':
        return '#2d4427'; // subtle green tint
      case 'EARLY_GROWTH':
        return '#1b4d24'; // fresh crop green
      case 'VEGETATIVE_GROWTH':
        return field.crop.includes('Canola') ? '#1e5428' : '#14431e';
      case 'FLOWERING':
        return field.crop.includes('Canola') ? '#b89417' : '#1e682e'; // golden canola flowers
      case 'RIPENING':
        return '#967926'; // golden wheat ripening
      case 'HARVESTING':
        return '#786221';
      case 'HARVESTED':
        return '#544626'; // wheat stubble
      default:
        return '#1e4024';
    }
  }

  private drawCropTexturePattern(ctx: CanvasRenderingContext2D, field: FieldDigitalTwin, is3D: boolean) {
    const minX = Math.min(...field.boundary.map(p => p.x));
    const maxX = Math.max(...field.boundary.map(p => p.x));
    const minY = Math.min(...field.boundary.map(p => p.y));
    const maxY = Math.max(...field.boundary.map(p => p.y));

    ctx.save();
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.lineWidth = 1;

    // Parallel crop row tracks
    const rowSpacing = is3D ? 12 : 10;
    for (let y = minY + 10; y < maxY - 10; y += rowSpacing) {
      const py = is3D ? y * this.cameraTilt : y;
      ctx.beginPath();
      ctx.moveTo(minX + 15, py);
      ctx.lineTo(maxX - 15, py);
      ctx.stroke();
    }
    ctx.restore();
  }

  private drawHarvestCutPattern(ctx: CanvasRenderingContext2D, field: FieldDigitalTwin, is3D: boolean) {
    const minX = Math.min(...field.boundary.map(p => p.x));
    const maxX = Math.max(...field.boundary.map(p => p.x));
    const minY = Math.min(...field.boundary.map(p => p.y));
    const maxY = Math.max(...field.boundary.map(p => p.y));
    
    const cutHeight = (maxY - minY) * (field.harvestProgressPct / 100);

    ctx.save();
    ctx.fillStyle = 'rgba(68, 55, 30, 0.85)'; // harvested light golden stubble
    const py = is3D ? minY * this.cameraTilt : minY;
    const ph = is3D ? cutHeight * this.cameraTilt : cutHeight;
    ctx.fillRect(minX + 5, py + 5, (maxX - minX) - 10, ph);
    ctx.restore();
  }

  private drawRoads(ctx: CanvasRenderingContext2D, is3D: boolean) {
    ctx.save();
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = is3D ? 7 : 8;
    ctx.lineCap = 'round';

    // Main Farm Central Access Arterial
    ctx.beginPath();
    ctx.moveTo(100, is3D ? 275 * this.cameraTilt : 275);
    ctx.lineTo(1080, is3D ? 275 * this.cameraTilt : 275);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(100, is3D ? 515 * this.cameraTilt : 515);
    ctx.lineTo(1080, is3D ? 515 * this.cameraTilt : 515);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(410, is3D ? 80 * this.cameraTilt : 80);
    ctx.lineTo(410, is3D ? 760 * this.cameraTilt : 760);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(750, is3D ? 80 * this.cameraTilt : 80);
    ctx.lineTo(750, is3D ? 760 * this.cameraTilt : 760);
    ctx.stroke();

    // Road dash markings
    ctx.strokeStyle = '#64748b';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([10, 10]);
    ctx.stroke();
    ctx.setLineDash([]);

    ctx.restore();
  }

  private drawIrrigation(ctx: CanvasRenderingContext2D, is3D: boolean) {
    const nodes = this.farmData.irrigationNodes();
    ctx.save();

    for (const node of nodes) {
      if (node.type === 'PIVOT') {
        const cx = node.position.x;
        const cy = is3D ? node.position.y * this.cameraTilt : node.position.y;
        const r = node.radiusM || 70;
        const radiusY = is3D ? r * this.cameraTilt : r;

        // Circular pivot coverage boundary
        ctx.beginPath();
        ctx.ellipse(cx, cy, r, radiusY, 0, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(6, 182, 212, 0.4)';
        ctx.lineWidth = 1.5;
        ctx.setLineDash([4, 4]);
        ctx.stroke();
        ctx.setLineDash([]);

        // Center base pivot station
        ctx.beginPath();
        ctx.arc(cx, cy, 5, 0, Math.PI * 2);
        ctx.fillStyle = '#06b6d4';
        ctx.fill();

        // Rotating truss arm
        const rad = ((node.angleDeg || 0) * Math.PI) / 180;
        const armEndX = cx + Math.cos(rad) * r;
        const armEndY = cy + Math.sin(rad) * radiusY;

        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.lineTo(armEndX, armEndY);
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 3;
        ctx.stroke();

        // Water droplet spray along the truss arm
        if (node.status === 'ACTIVE') {
          for (let i = 0.2; i <= 1.0; i += 0.15) {
            const sx = cx + Math.cos(rad) * (r * i);
            const sy = cy + Math.sin(rad) * (radiusY * i);
            ctx.beginPath();
            ctx.arc(sx, sy, 3 + Math.random() * 2, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(56, 189, 248, 0.7)';
            ctx.fill();
          }
        }
      }
    }
    ctx.restore();
  }

  private drawInfrastructure(ctx: CanvasRenderingContext2D, is3D: boolean) {
    const items = this.farmData.infrastructure();
    ctx.save();

    for (const item of items) {
      const px = item.position.x;
      const py = is3D ? item.position.y * this.cameraTilt : item.position.y;
      const w = item.width;
      const h = is3D ? item.height * this.cameraTilt : item.height;

      if (item.type === 'GRAIN_SILO') {
        // Round silos
        ctx.fillStyle = '#475569';
        ctx.beginPath();
        ctx.arc(px + 20, py + 20, 18, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#94a3b8';
        ctx.lineWidth = 2;
        ctx.stroke();

        ctx.beginPath();
        ctx.arc(px + 50, py + 20, 18, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      } else if (item.type === 'SOLAR_ARRAY') {
        // Blue photovoltaic panels
        ctx.fillStyle = '#1e3a8a';
        ctx.fillRect(px, py, w, h);
        ctx.strokeStyle = '#3b82f6';
        ctx.lineWidth = 1.5;
        ctx.strokeRect(px, py, w, h);

        // Panel grid cells
        ctx.strokeStyle = 'rgba(147, 197, 253, 0.4)';
        for (let x = px + 15; x < px + w; x += 20) {
          ctx.beginPath();
          ctx.moveTo(x, py);
          ctx.lineTo(x, py + h);
          ctx.stroke();
        }
      } else {
        // Barn / Workshop Building
        ctx.fillStyle = '#334155';
        ctx.fillRect(px, py, w, h);
        ctx.strokeStyle = '#64748b';
        ctx.lineWidth = 1.5;
        ctx.strokeRect(px, py, w, h);

        if (is3D) {
          // 3D extrusion roof cap
          ctx.fillStyle = '#475569';
          ctx.beginPath();
          ctx.moveTo(px, py);
          ctx.lineTo(px + 10, py - 12);
          ctx.lineTo(px + w + 10, py - 12);
          ctx.lineTo(px + w, py);
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
        }
      }

      // Infrastructure Label
      ctx.fillStyle = '#94a3b8';
      ctx.font = '8px "JetBrains Mono", monospace';
      ctx.textAlign = 'center';
      ctx.fillText(item.name.split('(')[0], px + w / 2, py + h + 12);
    }
    ctx.restore();
  }

  private drawLivestock(ctx: CanvasRenderingContext2D, is3D: boolean) {
    const zones = this.farmData.livestockZones();
    ctx.save();

    for (const zone of zones) {
      ctx.beginPath();
      for (let i = 0; i < zone.boundary.length; i++) {
        const pt = zone.boundary[i];
        const px = pt.x;
        const py = is3D ? pt.y * this.cameraTilt : pt.y;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.fillStyle = 'rgba(20, 83, 45, 0.6)'; // deep pasture green
      ctx.fill();
      ctx.strokeStyle = '#15803d';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Aggregate livestock dots roaming
      for (let i = 0; i < 14; i++) {
        const time = Date.now() / 3000 + i;
        const lx = zone.boundary[0].x + 40 + (Math.sin(time) * 35) + (i * 14);
        const ly = is3D 
          ? (zone.boundary[0].y + 40 + (Math.cos(time) * 30) + (i * 10)) * this.cameraTilt 
          : (zone.boundary[0].y + 40 + (Math.cos(time) * 30) + (i * 10));
        ctx.beginPath();
        ctx.arc(lx, ly, 3, 0, Math.PI * 2);
        ctx.fillStyle = '#f8fafc'; // cattle icon dot
        ctx.fill();
      }
    }
    ctx.restore();
  }

  private drawMachinery(ctx: CanvasRenderingContext2D, is3D: boolean) {
    const machines = this.farmData.machines();
    const trackedId = this.farmData.trackedMachineId();

    ctx.save();

    for (const machine of machines) {
      const isTracked = machine.id === trackedId;
      const px = machine.position.x;
      const py = is3D ? machine.position.y * this.cameraTilt : machine.position.y;

      // 1. Draw Swath History Working Trail
      if (this.farmData.showMachineryTrails() && machine.swathPoints.length > 1) {
        ctx.beginPath();
        for (let i = 0; i < machine.swathPoints.length; i++) {
          const pt = machine.swathPoints[i];
          const sx = pt.x;
          const sy = is3D ? pt.y * this.cameraTilt : pt.y;
          if (i === 0) ctx.moveTo(sx, sy);
          else ctx.lineTo(sx, sy);
        }

        if (machine.type === 'COMBINE') {
          ctx.strokeStyle = 'rgba(234, 179, 8, 0.4)'; // harvest grain trail
          ctx.lineWidth = machine.workingWidthM || 12;
        } else if (machine.type === 'SPRAYER') {
          ctx.strokeStyle = 'rgba(56, 189, 248, 0.35)'; // spray mist trail
          ctx.lineWidth = machine.workingWidthM || 36;
        } else {
          ctx.strokeStyle = 'rgba(74, 222, 128, 0.3)'; // seeding/tillage trail
          ctx.lineWidth = machine.workingWidthM || 12;
        }
        ctx.lineCap = 'round';
        ctx.stroke();
      }

      // 2. Draw Machine Vector Icon
      ctx.save();
      ctx.translate(px, py);
      const rad = (machine.headingDeg * Math.PI) / 180;
      ctx.rotate(rad);

      // Tracked halo aura
      if (isTracked) {
        ctx.beginPath();
        ctx.arc(0, 0, 22, 0, Math.PI * 2);
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 2;
        ctx.stroke();
      }

      // Vehicle Chassis
      if (machine.type === 'COMBINE') {
        ctx.fillStyle = '#eab308'; // Claas yellow / combine
        ctx.fillRect(-8, -14, 16, 28);
        // Header
        ctx.fillStyle = '#713f12';
        ctx.fillRect(-18, -18, 36, 6);
      } else if (machine.type === 'SPRAYER') {
        ctx.fillStyle = '#0284c7'; // Sprayer blue
        ctx.fillRect(-6, -12, 12, 24);
        // Spray boom wings
        ctx.fillStyle = '#38bdf8';
        ctx.fillRect(-28, -2, 56, 3);
      } else if (machine.type === 'DRONE') {
        ctx.fillStyle = '#f43f5e';
        ctx.beginPath();
        ctx.arc(0, 0, 6, 0, Math.PI * 2);
        ctx.fill();
        // Propellers
        ctx.strokeStyle = '#fda4af';
        ctx.lineWidth = 1.5;
        ctx.stroke();
      } else {
        // Tractor (John Deere / Fendt green)
        ctx.fillStyle = '#15803d';
        ctx.fillRect(-7, -12, 14, 24);
        // Cabin
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(-5, -4, 10, 8);
      }

      ctx.restore();

      // Machine Telemetry Badge
      ctx.fillStyle = isTracked ? '#38bdf8' : '#ffffff';
      ctx.font = 'bold 9px "JetBrains Mono", monospace';
      ctx.textAlign = 'center';
      ctx.fillText(`${machine.id} | ${machine.speedKmh.toFixed(1)} km/h`, px, py - 18);
    }

    ctx.restore();
  }

  private drawMeasurementTool(ctx: CanvasRenderingContext2D, is3D: boolean) {
    if (this.measurePoints.length === 0) return;

    ctx.save();
    ctx.strokeStyle = '#06b6d4';
    ctx.fillStyle = 'rgba(6, 182, 212, 0.2)';
    ctx.lineWidth = 2;
    ctx.setLineDash([4, 4]);

    ctx.beginPath();
    for (let i = 0; i < this.measurePoints.length; i++) {
      const pt = this.measurePoints[i];
      const px = pt.x;
      const py = is3D ? pt.y * this.cameraTilt : pt.y;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    if (this.measurePoints.length > 2) {
      ctx.closePath();
      ctx.fill();
    }
    ctx.stroke();
    ctx.setLineDash([]);

    // Draw vertex handles
    for (const pt of this.measurePoints) {
      const px = pt.x;
      const py = is3D ? pt.y * this.cameraTilt : pt.y;
      ctx.beginPath();
      ctx.arc(px, py, 5, 0, Math.PI * 2);
      ctx.fillStyle = '#06b6d4';
      ctx.fill();
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.5;
      ctx.stroke();
    }

    ctx.restore();
  }

  private drawWeatherParticles(ctx: CanvasRenderingContext2D) {
    const weather = this.farmData.weather();
    if (weather.currentType !== 'LIGHT_RAIN' && weather.currentType !== 'HEAVY_STORM') return;

    ctx.save();
    ctx.strokeStyle = 'rgba(186, 230, 253, 0.5)';
    ctx.lineWidth = 1.2;

    const windAngle = ((weather.windDirectionDeg - 90) * Math.PI) / 180;
    const dx = Math.cos(windAngle) * 4;

    for (const p of this.rainParticles) {
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      ctx.lineTo(p.x + dx, p.y + p.length);
      ctx.stroke();

      p.y += p.speed;
      p.x += dx;

      if (p.y > 1200) {
        p.y = -20;
        p.x = Math.random() * 2000;
      }
    }
    ctx.restore();
  }

  // --- Mouse & Touch Event Handlers ---

  onMouseDown(e: MouseEvent) {
    if (e.button === 0) {
      this.isDragging = true;
      this.dragStartX = e.clientX - this.cameraX;
      this.dragStartY = e.clientY - this.cameraY;
    }
  }

  onMouseMove(e: MouseEvent) {
    const canvas = this.canvasRef.nativeElement;
    const rect = canvas.getBoundingClientRect();
    const clientX = e.clientX - rect.left;
    const clientY = e.clientY - rect.top;

    if (this.isDragging) {
      this.cameraX = e.clientX - this.dragStartX;
      this.cameraY = e.clientY - this.dragStartY;
    }

    // Convert Screen to World Space
    const is3D = this.farmData.viewMode() === '3D_TWIN';
    const worldX = (clientX - this.cameraX) / this.cameraZoom;
    const worldY = is3D 
      ? ((clientY - this.cameraY) / this.cameraZoom) / this.cameraTilt 
      : (clientY - this.cameraY) / this.cameraZoom;

    // Update GPS Coordinates for HUD
    this.cursorGeoCoord = {
      lat: 53.2307 + (worldY - 400) * 0.00003,
      lng: -0.5406 + (worldX - 600) * 0.00004
    };
    this.cursorElevation = 24.0 + Math.sin(worldX * 0.005) * 8 + Math.cos(worldY * 0.005) * 6;

    // Check hovered field
    this.checkFieldHover(worldX, worldY, clientX, clientY);
  }

  onMouseUp() {
    this.isDragging = false;
  }

  onWheel(e: WheelEvent) {
    e.preventDefault();
    const zoomFactor = e.deltaY < 0 ? 1.1 : 0.9;
    const newZoom = Math.max(0.35, Math.min(3.5, this.cameraZoom * zoomFactor));

    const canvas = this.canvasRef.nativeElement;
    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    // Zoom centered on cursor
    this.cameraX = mouseX - (mouseX - this.cameraX) * (newZoom / this.cameraZoom);
    this.cameraY = mouseY - (mouseY - this.cameraY) * (newZoom / this.cameraZoom);
    this.cameraZoom = newZoom;
  }

  onCanvasClick(e: MouseEvent) {
    const canvas = this.canvasRef.nativeElement;
    const rect = canvas.getBoundingClientRect();
    const clientX = e.clientX - rect.left;
    const clientY = e.clientY - rect.top;

    const is3D = this.farmData.viewMode() === '3D_TWIN';
    const worldX = (clientX - this.cameraX) / this.cameraZoom;
    const worldY = is3D 
      ? ((clientY - this.cameraY) / this.cameraZoom) / this.cameraTilt 
      : (clientY - this.cameraY) / this.cameraZoom;

    // Measure tool active
    if (this.farmData.isMeasureToolActive()) {
      this.measurePoints.push({ x: worldX, y: worldY });
      this.calculateMeasurement();
      return;
    }

    // 1. Check if clicked a machine
    for (const machine of this.farmData.machines()) {
      const dist = Math.hypot(machine.position.x - worldX, machine.position.y - worldY);
      if (dist < 25) {
        this.farmData.trackMachine(machine.id);
        return;
      }
    }

    // 2. Check if clicked a field polygon
    const clickedField = this.findFieldAtPoint(worldX, worldY);
    if (clickedField) {
      this.farmData.selectField(clickedField.id);
    } else {
      this.farmData.selectField(null);
      this.farmData.trackMachine(null);
    }
  }

  private checkFieldHover(worldX: number, worldY: number, screenX: number, screenY: number) {
    const field = this.findFieldAtPoint(worldX, worldY);
    this.hoveredField = field;
    this.hoverX = screenX;
    this.hoverY = screenY;
  }

  private findFieldAtPoint(wx: number, wy: number): FieldDigitalTwin | null {
    const fields = this.farmData.fields();
    for (const field of fields) {
      if (this.pointInPolygon(wx, wy, field.boundary)) {
        return field;
      }
    }
    return null;
  }

  private pointInPolygon(x: number, y: number, vs: Point2D[]): boolean {
    let inside = false;
    for (let i = 0, j = vs.length - 1; i < vs.length; j = i++) {
      const xi = vs[i].x, yi = vs[i].y;
      const xj = vs[j].x, yj = vs[j].y;
      const intersect = ((yi > y) !== (yj > y)) && (x < (xj - xi) * (y - yi) / (yj - yi) + xi);
      if (intersect) inside = !inside;
    }
    return inside;
  }

  toggleMeasureTool() {
    const current = this.farmData.isMeasureToolActive();
    this.farmData.isMeasureToolActive.set(!current);
    if (current) {
      this.clearMeasurement();
    }
  }

  clearMeasurement() {
    this.measurePoints = [];
    this.measureDistanceM = 0;
    this.measureAreaHa = 0;
  }

  private calculateMeasurement() {
    if (this.measurePoints.length < 2) return;

    let totalDist = 0;
    for (let i = 0; i < this.measurePoints.length - 1; i++) {
      const p1 = this.measurePoints[i];
      const p2 = this.measurePoints[i + 1];
      // 1 canvas unit ~ 1.25 meters
      totalDist += Math.hypot(p2.x - p1.x, p2.y - p1.y) * 1.25;
    }
    this.measureDistanceM = totalDist;

    // Shoelace formula for polygon area
    if (this.measurePoints.length >= 3) {
      let area = 0;
      for (let i = 0; i < this.measurePoints.length; i++) {
        const j = (i + 1) % this.measurePoints.length;
        area += this.measurePoints[i].x * this.measurePoints[j].y;
        area -= this.measurePoints[j].x * this.measurePoints[i].y;
      }
      const areaM2 = (Math.abs(area) / 2) * (1.25 * 1.25);
      this.measureAreaHa = areaM2 / 10000;
    }
  }
}
