import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormControl } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { FarmDataService } from '../../core/services/farm-data.service';
import { GeminiAgronomistService } from '../../core/services/gemini-agronomist.service';

@Component({
  selector: 'app-ai-insights',
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full overflow-y-auto p-6 space-y-6 text-[#d1d5db] bg-[#050505] font-sans flex flex-col">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-white/10 pb-4">
        <div>
          <h1 class="text-xl font-bold font-display text-white flex items-center gap-2.5 uppercase">
            <mat-icon class="text-emerald-400">psychology</mat-icon>
            AI Agronomist & Autonomous Decision Engine
          </h1>
          <p class="text-xs text-white/50 mt-0.5">Powered by Gemini AI • Multimodal Biophysical & Met Reasoning</p>
        </div>
      </div>

      <!-- Quick Prompt Starters -->
      <div class="space-y-2">
        <div class="text-xs font-mono text-white/40 uppercase tracking-wider">Agronomic Diagnostic Prompts</div>
        <div class="flex flex-wrap gap-2">
          @for (preset of quickPrompts; track preset) {
            <button 
              type="button"
              (click)="selectPrompt(preset)"
              class="px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 hover:border-emerald-500/50 text-white/80 hover:text-white text-xs transition-all shadow-sm cursor-pointer">
              {{ preset }}
            </button>
          }
        </div>
      </div>

      <!-- Interactive Agronomist Chat / Query Input Box -->
      <div class="bg-[#080808]/90 border border-white/10 rounded-lg p-4 space-y-3 shadow-xl">
        <div class="flex items-center justify-between text-xs text-white/40">
          <label for="ai-field-select">Target Field Context:</label>
          <select 
            id="ai-field-select"
            [formControl]="selectedFieldControl"
            class="bg-black/60 border border-white/10 rounded-lg px-2.5 py-1 text-white font-mono text-xs cursor-pointer">
            <option value="ALL">All Farm Fields (Master Twin)</option>
            @for (field of farmData.fields(); track field.id) {
              <option [value]="field.id">{{ field.code }} - {{ field.name }} ({{ field.crop }})</option>
            }
          </select>
        </div>

        <div class="flex gap-2">
          <input 
            type="text" 
            [formControl]="queryControl" 
            (keyup.enter)="sendQuery()"
            placeholder="Ask the AI Agronomist about soil nitrogen, disease pressure, harvest dates, or spray windows..."
            class="flex-1 bg-black/60 border border-white/10 rounded-lg px-4 py-2.5 text-xs text-white placeholder-white/40 focus:outline-none focus:border-emerald-500 transition-all" />
          
          <button 
            type="button"
            (click)="sendQuery()"
            [disabled]="agronomist.isAnalyzing() || !queryControl.value.trim()"
            class="px-5 py-2.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-black text-xs font-bold transition-all shadow-lg flex items-center gap-1.5 cursor-pointer">
            <mat-icon class="text-base">{{ agronomist.isAnalyzing() ? 'sync' : 'send' }}</mat-icon>
            {{ agronomist.isAnalyzing() ? 'Analyzing...' : 'Consult' }}
          </button>
        </div>
      </div>

      <!-- AI Response Card -->
      @if (agronomist.lastResponse(); as response) {
        <div class="bg-[#080808]/95 border border-emerald-500/40 rounded-lg p-5 space-y-4 shadow-2xl">
          <div class="flex items-center justify-between border-b border-white/10 pb-3">
            <div class="flex items-center gap-2 text-emerald-400 font-display font-bold text-sm uppercase">
              <mat-icon class="text-base">auto_awesome</mat-icon>
              Digital Twin Agronomic Advisory & Crop Health Diagnostics
            </div>

            <div class="flex items-center gap-2 font-mono text-xs">
              <span 
                [class.bg-emerald-500/20]="response.riskLevel === 'LOW'"
                [class.text-emerald-400]="response.riskLevel === 'LOW'"
                [class.bg-amber-500/20]="response.riskLevel === 'MODERATE'"
                [class.text-amber-400]="response.riskLevel === 'MODERATE'"
                [class.bg-red-500/20]="response.riskLevel === 'HIGH' || response.riskLevel === 'CRITICAL'"
                [class.text-red-400]="response.riskLevel === 'HIGH' || response.riskLevel === 'CRITICAL'"
                class="px-2.5 py-0.5 rounded-full border border-current font-bold">
                {{ response.riskLevel }} RISK
              </span>

              <span class="text-amber-400 font-bold">
                Yield Impact: {{ response.estimatedYieldImpactPct >= 0 ? '+' : '' }}{{ response.estimatedYieldImpactPct }}%
              </span>
            </div>
          </div>

          <!-- Analysis text -->
          <div class="text-xs text-white/90 leading-relaxed bg-black/60 p-4 rounded-lg border border-white/10">
            {{ response.analysis }}
          </div>

          <!-- Recommendations Checklist -->
          <div class="space-y-2">
            <div class="text-xs font-mono text-white/40 uppercase tracking-wider font-semibold">Prescribed Agronomic Actions</div>
            <div class="space-y-2">
              @for (rec of response.recommendations; track rec) {
                <div class="p-3 bg-black/40 border border-white/10 rounded-lg flex items-start gap-2.5 text-xs text-white/80">
                  <mat-icon class="text-emerald-400 text-sm mt-0.5">check_circle</mat-icon>
                  <span class="flex-1">{{ rec }}</span>
                </div>
              }
            </div>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    :host {
      display: block;
      height: 100%;
    }
  `]
})
export class AiInsights {
  readonly farmData = inject(FarmDataService);
  readonly agronomist = inject(GeminiAgronomistService);

  readonly selectedFieldControl = new FormControl<string>('ALL', { nonNullable: true });
  readonly queryControl = new FormControl<string>('', { nonNullable: true });

  readonly quickPrompts = [
    'Assess harvest readiness for Field 07 (Winter Wheat)',
    'Recommend variable-rate Nitrogen top-dressing for Field 02',
    'Calculate drought stress mitigation strategy for Pivot 1',
    'Evaluate fungicide spray timing ahead of tomorrow rain window'
  ];

  selectPrompt(prompt: string) {
    this.queryControl.setValue(prompt);
    this.sendQuery();
  }

  sendQuery() {
    const query = this.queryControl.value.trim();
    if (!query) return;

    const selectedId = this.selectedFieldControl.value;
    let fieldContext: Record<string, unknown> | null = null;
    if (selectedId !== 'ALL') {
      const field = this.farmData.fields().find(f => f.id === selectedId);
      fieldContext = field ? (field as unknown as Record<string, unknown>) : null;
    } else {
      fieldContext = {
        totalFields: this.farmData.fields().length,
        avgNdvi: this.farmData.avgCropHealthNdvi(),
        weather: this.farmData.weather()
      };
    }

    this.agronomist.consultAgronomist(query, fieldContext);
  }
}
