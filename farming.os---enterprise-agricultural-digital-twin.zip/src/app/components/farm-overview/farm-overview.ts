import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FarmDataService } from '../../core/services/farm-data.service';

@Component({
  selector: 'app-farm-overview',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full overflow-y-auto p-6 space-y-6 text-[#d1d5db] bg-[#050505] font-sans">
      <!-- Enterprise Farm Header -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-5">
        <div>
          <div class="flex items-center gap-3">
            <h1 class="text-xl font-bold tracking-tight font-display text-white uppercase">
              {{ farmData.farms()[0].name }}
            </h1>
            <span class="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 flex items-center gap-1.5 shadow-[0_0_8px_rgba(16,185,129,0.3)]">
              <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              TWIN ONLINE
            </span>
          </div>
          <p class="text-xs text-white/50 mt-1 flex items-center gap-1.5">
            <mat-icon class="text-xs">location_on</mat-icon>
            {{ farmData.farms()[0].location }}
          </p>
        </div>

        <!-- Quick Telemetry Status Badges -->
        <div class="flex items-center gap-3 font-mono text-xs">
          <div class="bg-white/5 border border-white/10 px-3 py-1.5 rounded-lg text-white/80 flex items-center gap-2">
            <mat-icon class="text-emerald-400 text-sm">wifi_tethering</mat-icon>
            <span>Telemetry: <strong class="text-white">{{ farmData.telemetryPacketRate() }} pkts/s</strong></span>
          </div>
          <div class="bg-white/5 border border-white/10 px-3 py-1.5 rounded-lg text-white/80 flex items-center gap-2">
            <mat-icon class="text-cyan-400 text-sm">solar_power</mat-icon>
            <span>Solar: <strong class="text-cyan-300">{{ farmData.solarGenerationKw() }} kW</strong></span>
          </div>
        </div>
      </div>

      <!-- Master KPI Grid -->
      <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div class="bg-white/5 border border-white/10 rounded-lg p-4 space-y-1 shadow-lg">
          <div class="flex items-center justify-between text-xs text-white/40">
            <span class="uppercase tracking-widest text-[10px] font-bold">Total Farm Area</span>
            <mat-icon class="text-emerald-400 text-sm">landscape</mat-icon>
          </div>
          <div class="text-2xl font-bold font-display text-white">
            {{ farmData.totalFarmArea().toFixed(1) }} <span class="text-xs font-mono font-normal text-white/40">ha</span>
          </div>
          <div class="text-[11px] text-emerald-400 font-mono">18 Active Digital Fields</div>
        </div>

        <div class="bg-white/5 border border-white/10 rounded-lg p-4 space-y-1 shadow-lg">
          <div class="flex items-center justify-between text-xs text-white/40">
            <span class="uppercase tracking-widest text-[10px] font-bold">Harvest Readiness</span>
            <mat-icon class="text-amber-400 text-sm">agriculture</mat-icon>
          </div>
          <div class="text-2xl font-bold font-display text-amber-400">
            {{ farmData.readyForHarvestCount() }} <span class="text-xs font-mono font-normal text-white/40">fields</span>
          </div>
          <div class="text-[11px] text-white/40 font-mono">Field 07 & 03 in window</div>
        </div>

        <div class="bg-white/5 border border-white/10 rounded-lg p-4 space-y-1 shadow-lg">
          <div class="flex items-center justify-between text-xs text-white/40">
            <span class="uppercase tracking-widest text-[10px] font-bold">Total Forecast Yield</span>
            <mat-icon class="text-cyan-400 text-sm">trending_up</mat-icon>
          </div>
          <div class="text-2xl font-bold font-display text-cyan-300">
            {{ farmData.totalPredictedYieldTonne().toFixed(0) }} <span class="text-xs font-mono font-normal text-white/40">tonnes</span>
          </div>
          <div class="text-[11px] text-cyan-400 font-mono">+4.2% vs 5-Yr Baseline</div>
        </div>

        <div class="bg-white/5 border border-white/10 rounded-lg p-4 space-y-1 shadow-lg">
          <div class="flex items-center justify-between text-xs text-white/40">
            <span class="uppercase tracking-widest text-[10px] font-bold">Crop Health (NDVI)</span>
            <mat-icon class="text-emerald-400 text-sm">eco</mat-icon>
          </div>
          <div class="text-2xl font-bold font-display text-emerald-400">
            {{ farmData.avgCropHealthNdvi() }} <span class="text-xs font-mono font-normal text-white/40">/ 1.0</span>
          </div>
          <div class="text-[11px] text-emerald-500 font-mono">Canopy index optimal</div>
        </div>
      </div>

      <!-- Live Operations & Active Fleet Overview -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <!-- Machinery Live Telemetry Status -->
        <div class="bg-[#080808]/90 border border-white/10 rounded-lg p-4 space-y-3">
          <div class="flex items-center justify-between border-b border-white/10 pb-2.5">
            <div class="flex items-center gap-2 text-white font-display font-bold text-sm uppercase">
              <mat-icon class="text-emerald-400 text-base">precision_manufacturing</mat-icon>
              Active Autonomous & Supervised Fleet
            </div>
            <span class="text-xs font-mono text-white/40">{{ farmData.machines().length }} Units Deployed</span>
          </div>

          <div class="space-y-2">
            @for (machine of farmData.machines(); track machine.id) {
              <button 
                type="button"
                (click)="farmData.trackMachine(machine.id)"
                class="w-full text-left p-3 bg-black/60 border border-white/10 rounded-lg flex items-center justify-between hover:border-emerald-500/50 cursor-pointer transition-all">
                <div class="flex items-center gap-3">
                  <div 
                    [class.bg-emerald-500/20]="machine.state === 'WORKING'"
                    [class.text-emerald-400]="machine.state === 'WORKING'"
                    [class.bg-white/5]="machine.state !== 'WORKING'"
                    [class.text-white/40]="machine.state !== 'WORKING'"
                    class="w-9 h-9 rounded-lg flex items-center justify-center">
                    <mat-icon class="text-lg">
                      {{ machine.type === 'COMBINE' ? 'agriculture' : (machine.type === 'DRONE' ? 'flight' : 'directions_car') }}
                    </mat-icon>
                  </div>
                  <div>
                    <div class="text-xs font-bold text-white flex items-center gap-2">
                      {{ machine.name }}
                      <span class="px-1.5 py-0.2 rounded text-[9px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                        {{ machine.state }}
                      </span>
                    </div>
                    <div class="text-[11px] text-white/40">
                      Operator: <span class="text-white/80">{{ machine.operatorName }}</span> | Task: <span class="text-cyan-300">{{ machine.currentImplement }}</span>
                    </div>
                  </div>
                </div>

                <div class="text-right font-mono text-xs">
                  <div class="font-bold text-white">{{ machine.speedKmh.toFixed(1) }} km/h</div>
                  <div class="text-[10px] text-emerald-400">Fuel: {{ machine.fuelPct }}%</div>
                </div>
              </button>
            }
          </div>
        </div>

        <!-- Weather Engine & Atmosphere Telemetry -->
        <div class="bg-[#080808]/90 border border-white/10 rounded-lg p-4 space-y-3">
          <div class="flex items-center justify-between border-b border-white/10 pb-2.5">
            <div class="flex items-center gap-2 text-white font-display font-bold text-sm uppercase">
              <mat-icon class="text-cyan-400 text-base">cloud</mat-icon>
              Farm Atmosphere & Met Telemetry
            </div>
            <span class="text-xs font-mono text-white/40">IoT Met Station #1</span>
          </div>

          <div class="grid grid-cols-3 gap-2">
            <div class="bg-black/60 p-3 rounded-lg border border-white/10 text-center">
              <div class="text-[10px] text-white/40">Temperature</div>
              <div class="text-lg font-bold font-mono text-white">{{ farmData.weather().temperatureC }}°C</div>
              <div class="text-[10px] text-white/40">Feels like {{ farmData.weather().feelsLikeC }}°C</div>
            </div>
            <div class="bg-black/60 p-3 rounded-lg border border-white/10 text-center">
              <div class="text-[10px] text-white/40">Wind Velocity</div>
              <div class="text-lg font-bold font-mono text-cyan-400">{{ farmData.weather().windSpeedKmh }} km/h</div>
              <div class="text-[10px] text-white/40">Gusts {{ farmData.weather().windGustKmh }} km/h</div>
            </div>
            <div class="bg-black/60 p-3 rounded-lg border border-white/10 text-center">
              <div class="text-[10px] text-white/40">Solar Radiation</div>
              <div class="text-lg font-bold font-mono text-amber-400">{{ farmData.weather().solarRadiationWm2 }} W/m²</div>
              <div class="text-[10px] text-white/40">UV Index: 6.2</div>
            </div>
          </div>

          <!-- Forecast Timeline -->
          <div class="space-y-1 pt-1">
            <div class="text-[11px] font-mono text-white/40 uppercase tracking-wider">Met Forecast (Next 12 Hours)</div>
            <div class="grid grid-cols-6 gap-1.5">
              @for (item of farmData.weather().forecast; track item.time) {
                <div class="bg-black/60 border border-white/10 rounded-lg p-2 text-center text-xs">
                  <div class="text-[10px] text-white/40 font-mono">{{ item.time }}</div>
                  <div class="my-1">
                    <mat-icon class="text-base text-amber-300">
                      {{ item.type === 'SUNNY' ? 'wb_sunny' : (item.type === 'LIGHT_RAIN' ? 'water_drop' : 'cloud') }}
                    </mat-icon>
                  </div>
                  <div class="font-bold text-white font-mono text-[11px]">{{ item.tempC }}°</div>
                  <div class="text-[9px] text-cyan-400">{{ item.rainChancePct }}% rain</div>
                </div>
              }
            </div>
          </div>
        </div>
      </div>

      <!-- Critical Farm Alerts List -->
      <div class="bg-[#080808]/90 border border-white/10 rounded-lg p-4 space-y-3">
        <div class="flex items-center justify-between border-b border-white/10 pb-2.5">
          <div class="flex items-center gap-2 text-white font-display font-bold text-sm uppercase">
            <mat-icon class="text-red-400 text-base">notification_important</mat-icon>
            Farm Incident & Alert Center
          </div>
          <span class="text-xs font-mono text-white/40">{{ farmData.alerts().length }} Active Alerts</span>
        </div>

        <div class="space-y-2">
          @for (alert of farmData.alerts(); track alert.id) {
            <div 
              [class.border-red-500/40]="alert.severity === 'CRITICAL'"
              [class.bg-red-950/20]="alert.severity === 'CRITICAL'"
              [class.border-amber-500/40]="alert.severity === 'WARNING'"
              [class.bg-amber-950/20]="alert.severity === 'WARNING'"
              [class.border-blue-500/40]="alert.severity === 'INFO'"
              [class.bg-blue-950/20]="alert.severity === 'INFO'"
              class="p-3 rounded-lg border flex items-start justify-between gap-3 text-xs">
              <div class="flex items-start gap-2.5">
                <mat-icon 
                  [class.text-red-400]="alert.severity === 'CRITICAL'"
                  [class.text-amber-400]="alert.severity === 'WARNING'"
                  [class.text-blue-400]="alert.severity === 'INFO'"
                  class="text-base mt-0.5">
                  {{ alert.severity === 'CRITICAL' ? 'error' : (alert.severity === 'WARNING' ? 'warning' : 'info') }}
                </mat-icon>
                <div>
                  <div class="font-bold text-white flex items-center gap-2">
                    {{ alert.title }}
                    @if (alert.fieldName) {
                      <span class="text-white/40 font-normal">({{ alert.fieldName }})</span>
                    }
                  </div>
                  <p class="text-white/70 text-[11px] mt-0.5">{{ alert.message }}</p>
                  <p class="text-emerald-400 text-[11px] mt-1 font-mono font-medium">Action: {{ alert.actionRequired }}</p>
                </div>
              </div>

              <div class="flex items-center gap-2">
                @if (!alert.acknowledged) {
                  <button 
                    type="button"
                    (click)="farmData.acknowledgeAlert(alert.id)"
                    class="px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 text-white/80 text-[11px] font-medium transition-colors cursor-pointer">
                    Acknowledge
                  </button>
                }
                <button 
                  type="button"
                  (click)="farmData.resolveAlert(alert.id)"
                  class="px-2.5 py-1 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-black text-[11px] font-bold transition-colors cursor-pointer shadow-[0_0_8px_rgba(16,185,129,0.3)]">
                  Resolve
                </button>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      height: 100%;
    }
  `]
})
export class FarmOverview {
  readonly farmData = inject(FarmDataService);
}
