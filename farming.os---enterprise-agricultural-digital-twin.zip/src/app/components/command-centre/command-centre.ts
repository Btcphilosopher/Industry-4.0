import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FarmDataService } from '../../core/services/farm-data.service';
import { DigitalTwinCanvas } from '../digital-twin-canvas/digital-twin-canvas';
import { FieldHUD } from '../field-hud/field-hud';
import { FarmOverview } from '../farm-overview/farm-overview';
import { MachineryFleet } from '../machinery-fleet/machinery-fleet';
import { IrrigationDrainage } from '../irrigation-drainage/irrigation-drainage';
import { CropCalendar } from '../crop-calendar/crop-calendar';
import { OperationsBoard } from '../operations-board/operations-board';
import { EnergyWaterAnalytics } from '../energy-water-analytics/energy-water-analytics';
import { TimeMachine } from '../time-machine/time-machine';
import { AiInsights } from '../ai-insights/ai-insights';
import { KotlinArchitectureViewer } from '../kotlin-architecture-viewer/kotlin-architecture-viewer';

export type AppTab = 
  | 'COMMAND_CENTRE'
  | 'FARM_OVERVIEW'
  | 'FLEET'
  | 'IRRIGATION'
  | 'CALENDAR'
  | 'OPERATIONS'
  | 'ENERGY_CARBON'
  | 'TIME_MACHINE'
  | 'AI_AGRONOMIST'
  | 'KOTLIN_SPECS';

@Component({
  selector: 'app-command-centre',
  imports: [
    CommonModule, 
    MatIconModule, 
    DigitalTwinCanvas, 
    FieldHUD,
    FarmOverview,
    MachineryFleet,
    IrrigationDrainage,
    CropCalendar,
    OperationsBoard,
    EnergyWaterAnalytics,
    TimeMachine,
    AiInsights,
    KotlinArchitectureViewer
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-screen w-screen flex flex-col bg-[#050505] text-[#d1d5db] overflow-hidden select-none font-sans">
      <!-- Top Enterprise Navigation Header (Immersive UI) -->
      <header class="h-16 border-b border-white/10 flex items-center justify-between px-6 bg-[#080808] shrink-0 z-30">
        <!-- Logo & Farm Info -->
        <div class="flex items-center gap-4">
          <div class="w-8 h-8 bg-emerald-500 rounded flex items-center justify-center text-black font-bold italic font-mono text-base shadow-[0_0_12px_rgba(16,185,129,0.5)]">
            F
          </div>
          <div class="flex items-center">
            <h1 class="text-xl font-bold tracking-tighter text-white uppercase font-display">
              FARMING.<span class="text-emerald-500">OS</span>
            </h1>
            <div class="hidden sm:block ml-4 px-3 py-1 bg-white/5 border border-white/10 rounded-full text-[10px] uppercase tracking-widest text-emerald-400 font-semibold">
              Enterprise Edition v3.7
            </div>
          </div>
        </div>

        <!-- Navigation Tabs Bar -->
        <nav class="hidden lg:flex items-center gap-1.5 bg-black/40 p-1 rounded-xl border border-white/10 text-xs font-medium backdrop-blur-md">
          @for (tab of navigationTabs; track tab.id) {
            <button 
              type="button"
              (click)="activeTab.set(tab.id)"
              [class.bg-emerald-500]="activeTab() === tab.id"
              [class.text-black]="activeTab() === tab.id"
              [class.font-bold]="activeTab() === tab.id"
              [class.shadow-[0_0_10px_rgba(16,185,129,0.4)]]="activeTab() === tab.id"
              [class.text-white/60]="activeTab() !== tab.id"
              [class.hover:text-white]="activeTab() !== tab.id"
              [class.hover:bg-white/5]="activeTab() !== tab.id"
              class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all cursor-pointer">
              <mat-icon class="text-sm leading-none">{{ tab.icon }}</mat-icon>
              <span>{{ tab.label }}</span>
            </button>
          }
        </nav>

        <!-- Right Quick Actions & Live Stream Status -->
        <div class="flex items-center gap-6">
          <!-- Mobile Tab Dropdown for smaller screens -->
          <div class="lg:hidden">
            <select 
              [value]="activeTab()" 
              (change)="onTabSelect($event)" 
              class="bg-black border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-emerald-400 font-bold focus:outline-none">
              @for (tab of navigationTabs; track tab.id) {
                <option [value]="tab.id">{{ tab.label }}</option>
              }
            </select>
          </div>

          <!-- Current Weather Readout -->
          <div class="hidden md:flex flex-col items-end">
            <span class="text-[10px] text-white/40 uppercase font-mono tracking-wider">Current Weather</span>
            <span class="text-xs font-mono text-white tracking-wide">
              {{ farmData.weather().temperatureC }}°C / {{ farmData.weather().windSpeedKmh }}KMH {{ farmData.weather().windDirectionDeg }}° / {{ farmData.weather().currentType.replace('_', ' ') }}
            </span>
          </div>

          <!-- Live Heartbeat Indicator -->
          <div class="flex items-center gap-3 bg-white/5 border border-white/10 px-3 py-1.5 rounded-lg">
            <div class="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.8)] animate-pulse"></div>
            <span class="text-[10px] uppercase font-bold tracking-widest text-white/70">System Live</span>
          </div>

          <!-- Quick Toggle Simulation -->
          <button 
            type="button"
            (click)="farmData.isLiveMode.set(!farmData.isLiveMode())"
            [class.bg-emerald-500]="farmData.isLiveMode()"
            [class.text-black]="farmData.isLiveMode()"
            [class.bg-white/5]="!farmData.isLiveMode()"
            [class.text-white]="!farmData.isLiveMode()"
            [class.border-white/10]="!farmData.isLiveMode()"
            title="Toggle Live Simulation Stream"
            class="p-2 rounded-lg border border-transparent transition-all shadow-md cursor-pointer hover:border-emerald-500/50">
            <mat-icon class="text-base leading-none">{{ farmData.isLiveMode() ? 'pause' : 'play_arrow' }}</mat-icon>
          </button>
        </div>
      </header>

      <!-- Main Body Container -->
      <main class="flex-1 relative overflow-hidden bg-[#050505]">
        <!-- 1. COMMAND CENTRE (Master 4-Quadrant Control Room) -->
        @if (activeTab() === 'COMMAND_CENTRE') {
          <div class="w-full h-full flex flex-col">
            <!-- Central 3-Pane Work Area -->
            <div class="flex-1 flex overflow-hidden">
              <!-- LEFT PANE: Farm Hierarchy & Active Machinery (Immersive UI) -->
              <aside class="w-68 border-r border-white/10 bg-[#080808]/70 backdrop-blur-md p-4 flex flex-col gap-5 overflow-y-auto shrink-0 z-20">
                <!-- Search & Filter Filter -->
                <div class="relative">
                  <mat-icon class="absolute left-2.5 top-2.5 text-white/40 text-sm">search</mat-icon>
                  <input 
                    type="text" 
                    placeholder="Filter fields, machinery, nodes..."
                    class="w-full bg-black/60 border border-white/10 rounded-lg pl-8 pr-3 py-1.5 text-xs text-white placeholder-white/40 focus:outline-none focus:border-emerald-500 transition-colors" />
                </div>

                <!-- Farm Hierarchy Section -->
                <div>
                  <div class="flex items-center justify-between mb-2.5">
                    <h2 class="text-[10px] uppercase tracking-widest text-white/40 font-bold">Farm Hierarchy</h2>
                    <span class="text-[10px] font-mono text-emerald-400 font-semibold">{{ farmData.totalFarmArea().toFixed(0) }} HA</span>
                  </div>

                  <div class="space-y-1">
                    @for (field of farmData.fields(); track field.id) {
                      <button 
                        type="button"
                        (click)="farmData.selectField(field.id)"
                        [class.bg-emerald-500/10]="farmData.selectedFieldId() === field.id"
                        [class.border-l-2]="farmData.selectedFieldId() === field.id"
                        [class.border-emerald-500]="farmData.selectedFieldId() === field.id"
                        [class.border-white/5]="farmData.selectedFieldId() !== field.id"
                        [class.hover:bg-white/5]="farmData.selectedFieldId() !== field.id"
                        class="w-full text-left p-2.5 rounded-r-lg border-y border-r border-transparent flex justify-between items-center cursor-pointer transition-all">
                        <div class="flex items-center gap-2">
                          <span class="w-5 h-5 rounded bg-white/5 text-white/80 font-bold font-mono text-[10px] flex items-center justify-center">
                            {{ field.code }}
                          </span>
                          <div>
                            <div class="text-xs font-semibold text-white">{{ field.name }}</div>
                            <div class="text-[10px] text-white/40">{{ field.crop }}</div>
                          </div>
                        </div>

                        <div class="flex flex-col items-end">
                          @if (farmData.selectedFieldId() === field.id) {
                            <span class="text-[9px] bg-emerald-500/20 text-emerald-400 px-1.5 py-0.5 rounded font-mono font-bold">Selected</span>
                          } @else {
                            <span class="text-[10px] font-mono text-white/40">NDVI {{ field.ndvi }}</span>
                            <span class="text-[9px] font-mono text-blue-400">{{ field.soilMoisturePct }}% H₂O</span>
                          }
                        </div>
                      </button>
                    }
                  </div>
                </div>

                <!-- Active Machinery Telemetry -->
                <div>
                  <div class="flex items-center justify-between mb-2.5">
                    <h2 class="text-[10px] uppercase tracking-widest text-white/40 font-bold">Active Machinery</h2>
                    <span class="text-[10px] font-mono text-blue-400 font-semibold">{{ farmData.machines().length }} UNITS</span>
                  </div>

                  <div class="space-y-2.5 font-mono">
                    @for (machine of farmData.machines(); track machine.id) {
                      <button 
                        type="button"
                        (click)="farmData.trackMachine(machine.id)"
                        [class.border-blue-500/50]="farmData.trackedMachineId() === machine.id"
                        [class.bg-blue-950/20]="farmData.trackedMachineId() === machine.id"
                        class="w-full text-left p-2 bg-white/5 border border-white/10 rounded-lg flex items-center gap-3 hover:border-white/30 transition-all cursor-pointer">
                        <div 
                          [class.bg-blue-500]="machine.state === 'WORKING'"
                          [class.bg-emerald-500]="machine.state === 'MOVING'"
                          [class.bg-amber-500]="machine.state === 'IDLE'"
                          [class.bg-slate-600]="machine.state === 'OFFLINE'"
                          class="w-1 h-9 rounded-full shrink-0"></div>
                        <div class="flex-1 min-w-0">
                          <div class="flex items-center justify-between">
                            <span class="text-[11px] text-white font-bold truncate">{{ machine.name }}</span>
                            <span class="text-[9px] text-emerald-400">{{ machine.speedKmh.toFixed(1) }} KM/H</span>
                          </div>
                          <span class="text-[9px] text-white/40 block">COORD: {{ machine.position.x.toFixed(1) }}, {{ machine.position.y.toFixed(1) }}</span>
                          <div class="w-full h-1 bg-white/10 mt-1.5 rounded-full overflow-hidden">
                            <div 
                              class="h-full bg-blue-500 transition-all duration-300"
                              [style.width.%]="machine.fuelPct"></div>
                          </div>
                        </div>
                      </button>
                    }
                  </div>
                </div>
              </aside>

              <!-- CENTRE PANE: Live Digital Twin Canvas (2D GIS, 3D Isometric, Hybrid) -->
              <div class="flex-1 relative h-full bg-[#0a0a0a] overflow-hidden">
                <!-- Immersive Background Matrix Dot Grid -->
                <div class="absolute inset-0 opacity-20 pointer-events-none immersive-grid-bg"></div>
                <app-digital-twin-canvas></app-digital-twin-canvas>
              </div>

              <!-- RIGHT PANE: Selected Field HUD / Telemetry Stream -->
              @if (farmData.selectedFieldId()) {
                <aside class="w-80 shrink-0 z-20 h-full border-l border-white/10 bg-[#080808]/70 backdrop-blur-md">
                  <app-field-hud></app-field-hud>
                </aside>
              }
            </div>

            <!-- BOTTOM PANE: Temporal Context & Timeline Scrubber (Immersive UI) -->
            <footer class="h-16 border-t border-white/10 bg-[#080808] px-6 flex items-center justify-between shrink-0 font-mono text-xs z-20">
              <!-- Left: Temporal Context Readout -->
              <div class="w-60 shrink-0 pr-6 border-r border-white/10 flex flex-col justify-center">
                <div class="text-[10px] uppercase text-white/40 mb-0.5">Temporal Context</div>
                <div class="flex items-center gap-2">
                  <span class="px-2 py-0.5 bg-emerald-500 text-black text-[10px] font-bold rounded">LIVE</span>
                  <span class="text-xs font-mono text-white">DAY {{ farmData.timelineDay() }} • 14:32</span>
                </div>
              </div>

              <!-- Center: Phenology Cycle Progress & Scrubber -->
              <div class="flex-1 px-8 flex flex-col gap-1.5 max-w-2xl">
                <div class="flex justify-between text-[10px] text-white/30 uppercase font-bold tracking-widest px-1">
                  <span>Planting</span>
                  <span>Vegetative</span>
                  <span class="text-emerald-400">Ripening</span>
                  <span>Harvest</span>
                </div>
                <div class="flex items-center gap-3">
                  <input 
                    type="range" 
                    min="1" 
                    max="240" 
                    [value]="farmData.timelineDay()"
                    (input)="onBottomTimelineScrub($event)"
                    class="w-full h-1.5 bg-white/10 rounded-full appearance-none cursor-pointer accent-emerald-500" />
                </div>
              </div>

              <!-- Right: Speed & Telemetry Health -->
              <div class="w-72 flex items-center justify-end gap-4 shrink-0">
                <div class="flex items-center gap-1 bg-white/5 border border-white/10 p-1 rounded-lg">
                  @for (speed of [1, 5, 20]; track speed) {
                    <button 
                      type="button"
                      (click)="farmData.simulationSpeed.set(speed)"
                      [class.bg-emerald-500]="farmData.simulationSpeed() === speed"
                      [class.text-black]="farmData.simulationSpeed() === speed"
                      [class.font-bold]="farmData.simulationSpeed() === speed"
                      [class.text-white/60]="farmData.simulationSpeed() !== speed"
                      class="px-2 py-0.5 rounded text-[10px] font-mono cursor-pointer transition-all">
                      {{ speed }}x
                    </button>
                  }
                </div>

                <div class="text-right text-[10px] text-white/40">
                  <span class="text-emerald-400 font-bold">RTK FIXED</span> | CAN 250k
                </div>
              </div>
            </footer>
          </div>
        }

        <!-- 2. FARM OVERVIEW DASHBOARD -->
        @if (activeTab() === 'FARM_OVERVIEW') {
          <app-farm-overview></app-farm-overview>
        }

        <!-- 3. FLEET MANAGER -->
        @if (activeTab() === 'FLEET') {
          <app-machinery-fleet></app-machinery-fleet>
        }

        <!-- 4. HYDRO RETICULATION & DRAINAGE -->
        @if (activeTab() === 'IRRIGATION') {
          <app-irrigation-drainage></app-irrigation-drainage>
        }

        <!-- 5. CROP CALENDAR -->
        @if (activeTab() === 'CALENDAR') {
          <app-crop-calendar></app-crop-calendar>
        }

        <!-- 6. OPERATIONS KANBAN & PRESCRIPTIONS -->
        @if (activeTab() === 'OPERATIONS') {
          <app-operations-board></app-operations-board>
        }

        <!-- 7. ENERGY & CARBON BALANCES -->
        @if (activeTab() === 'ENERGY_CARBON') {
          <app-energy-water-analytics></app-energy-water-analytics>
        }

        <!-- 8. TIME MACHINE & SCENARIOS -->
        @if (activeTab() === 'TIME_MACHINE') {
          <app-time-machine></app-time-machine>
        }

        <!-- 9. AI AGRONOMIST -->
        @if (activeTab() === 'AI_AGRONOMIST') {
          <app-ai-insights></app-ai-insights>
        }

        <!-- 10. KOTLIN ARCHITECTURE SPECIFICATIONS -->
        @if (activeTab() === 'KOTLIN_SPECS') {
          <app-kotlin-architecture-viewer></app-kotlin-architecture-viewer>
        }
      </main>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      width: 100vw;
      height: 100vh;
    }
  `]
})
export class CommandCentre {
  readonly farmData = inject(FarmDataService);
  readonly activeTab = signal<AppTab>('COMMAND_CENTRE');

  readonly navigationTabs: { id: AppTab; label: string; icon: string }[] = [
    { id: 'COMMAND_CENTRE', label: 'Command Centre', icon: 'dashboard' },
    { id: 'FARM_OVERVIEW', label: 'Overview', icon: 'analytics' },
    { id: 'FLEET', label: 'Fleet Telemetry', icon: 'precision_manufacturing' },
    { id: 'IRRIGATION', label: 'Hydro & Drainage', icon: 'water_drop' },
    { id: 'CALENDAR', label: 'Crop Calendar', icon: 'calendar_month' },
    { id: 'OPERATIONS', label: 'Operations & VRA', icon: 'task_alt' },
    { id: 'ENERGY_CARBON', label: 'Energy & Carbon', icon: 'energy_savings_leaf' },
    { id: 'TIME_MACHINE', label: 'Time-Machine', icon: 'history_toggle_off' },
    { id: 'AI_AGRONOMIST', label: 'AI Agronomist', icon: 'psychology' },
    { id: 'KOTLIN_SPECS', label: 'Kotlin Architecture', icon: 'code' }
  ];

  onTabSelect(event: Event) {
    const select = event.target as HTMLSelectElement;
    this.activeTab.set(select.value as AppTab);
  }

  onBottomTimelineScrub(event: Event) {
    const input = event.target as HTMLInputElement;
    this.farmData.timelineDay.set(parseInt(input.value, 10));
  }
}
