import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { FarmDataService } from '../../core/services/farm-data.service';
import { WorkOrder } from '../../core/models/farm.model';

@Component({
  selector: 'app-operations-board',
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full overflow-y-auto p-5 space-y-6 text-slate-100 bg-slate-950/80">
      <!-- Operations Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 class="text-xl font-bold font-display text-white flex items-center gap-2.5">
            <mat-icon class="text-emerald-400">task_alt</mat-icon>
            Farm Operations & Prescription Work Orders
          </h1>
          <p class="text-xs text-slate-400 mt-0.5">Variable Rate Application (VRA) • Task Dispatch • Autonomous Mission Queue</p>
        </div>

        <button 
          type="button"
          (click)="showCreateModal.set(true)"
          class="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-lg transition-all cursor-pointer">
          <mat-icon class="text-base">add</mat-icon>
          Create Work Order
        </button>
      </div>

      <!-- Kanban Columns -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
        <!-- PLANNED -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <span class="text-xs font-bold font-display text-slate-300">PLANNED QUEUE</span>
            <span class="px-2 py-0.5 rounded-full text-[10px] font-mono bg-slate-800 text-slate-400">
              {{ plannedOrders.length }}
            </span>
          </div>

          <div class="space-y-3">
            @for (order of plannedOrders; track order.id) {
              <div class="bg-slate-950/80 border border-slate-800/80 rounded-xl p-3.5 space-y-2 text-xs hover:border-slate-700 transition-all">
                <div class="flex items-center justify-between">
                  <span class="font-bold text-white">{{ getOrderType(order) }}</span>
                  <span class="text-[10px] font-mono text-cyan-400">{{ order.fieldName }}</span>
                </div>
                <div class="text-[11px] text-slate-400">
                  Target: {{ getOrderTarget(order) }} | Assigned: {{ getOrderMachine(order) }}
                </div>
                <div class="flex items-center justify-between pt-1 border-t border-slate-800">
                  <span class="text-[10px] text-slate-500 font-mono">{{ order.scheduledStartTime || order.scheduledDate || 'Today' }}</span>
                  <button 
                    type="button"
                    (click)="updateOrderStatus(order.id, 'ACTIVE')"
                    class="text-[11px] text-emerald-400 hover:underline font-semibold flex items-center gap-1 cursor-pointer">
                    <mat-icon class="text-xs">play_arrow</mat-icon> Dispatch
                  </button>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- ACTIVE -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <span class="text-xs font-bold font-display text-emerald-400">IN PROGRESS</span>
            <span class="px-2 py-0.5 rounded-full text-[10px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
              {{ activeOrders.length }}
            </span>
          </div>

          <div class="space-y-3">
            @for (order of activeOrders; track order.id) {
              <div class="bg-slate-950/80 border border-emerald-500/30 rounded-xl p-3.5 space-y-2 text-xs">
                <div class="flex items-center justify-between">
                  <span class="font-bold text-white">{{ getOrderType(order) }}</span>
                  <span class="text-[10px] font-mono text-emerald-400">{{ getOrderProgress(order) }}%</span>
                </div>
                <div class="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div class="h-full bg-emerald-500 rounded-full" [style.width.%]="getOrderProgress(order)"></div>
                </div>
                <div class="text-[11px] text-slate-400">
                  {{ order.fieldName }} • {{ getOrderOperator(order) }}
                </div>
                <div class="flex items-center justify-between pt-1 border-t border-slate-800">
                  <span class="text-[10px] text-slate-500 font-mono">{{ getOrderMachine(order) }}</span>
                  <button 
                    type="button"
                    (click)="updateOrderStatus(order.id, 'COMPLETED')"
                    class="text-[11px] text-cyan-400 hover:underline font-semibold flex items-center gap-1 cursor-pointer">
                    <mat-icon class="text-xs">check</mat-icon> Complete
                  </button>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- COMPLETED -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <span class="text-xs font-bold font-display text-cyan-400">COMPLETED</span>
            <span class="px-2 py-0.5 rounded-full text-[10px] font-mono bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
              {{ completedOrders.length }}
            </span>
          </div>

          <div class="space-y-3">
            @for (order of completedOrders; track order.id) {
              <div class="bg-slate-950/80 border border-slate-800/80 rounded-xl p-3.5 space-y-1.5 text-xs opacity-80">
                <div class="flex items-center justify-between">
                  <span class="font-bold text-white">{{ getOrderType(order) }}</span>
                  <span class="text-[10px] font-mono text-slate-400">{{ order.fieldName }}</span>
                </div>
                <div class="text-[11px] text-slate-400">
                  Applied: {{ getOrderTarget(order) }} • {{ getOrderMachine(order) }}
                </div>
                <div class="text-[10px] text-emerald-400 font-mono pt-1">
                  Verified by GIS Telemetry Log
                </div>
              </div>
            }
          </div>
        </div>

        <!-- DELAYED / BLOCKED -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <span class="text-xs font-bold font-display text-amber-400">ON HOLD / WEATHER</span>
            <span class="px-2 py-0.5 rounded-full text-[10px] font-mono bg-amber-500/10 text-amber-400 border border-amber-500/30">
              {{ delayedOrders.length }}
            </span>
          </div>

          <div class="space-y-3">
            @for (order of delayedOrders; track order.id) {
              <div class="bg-slate-950/80 border border-amber-500/30 rounded-xl p-3.5 space-y-2 text-xs">
                <div class="flex items-center justify-between">
                  <span class="font-bold text-white">{{ getOrderType(order) }}</span>
                  <span class="text-[10px] font-mono text-amber-400">Weather Gate</span>
                </div>
                <p class="text-[11px] text-slate-300">{{ order.notes || 'Awaiting soil moisture dry-down.' }}</p>
                <div class="flex justify-end pt-1">
                  <button 
                    type="button"
                    (click)="updateOrderStatus(order.id, 'PLANNED')"
                    class="text-[11px] text-emerald-400 hover:underline cursor-pointer">
                    Re-queue
                  </button>
                </div>
              </div>
            }
          </div>
        </div>
      </div>

      <!-- Create Work Order Modal -->
      @if (showCreateModal()) {
        <div class="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
          <div class="bg-slate-900 border border-slate-700 rounded-2xl p-6 w-full max-w-lg space-y-4 shadow-2xl">
            <div class="flex items-center justify-between border-b border-slate-800 pb-3">
              <h2 class="text-base font-bold font-display text-white flex items-center gap-2">
                <mat-icon class="text-emerald-400">playlist_add</mat-icon>
                Create Prescription Work Order
              </h2>
              <button 
                type="button"
                (click)="showCreateModal.set(false)"
                class="text-slate-400 hover:text-white cursor-pointer">
                <mat-icon>close</mat-icon>
              </button>
            </div>

            <form [formGroup]="orderForm" (ngSubmit)="submitWorkOrder()" class="space-y-3 text-xs">
              <div>
                <label for="wo-target-field" class="block text-slate-400 mb-1">Target Field</label>
                <select 
                  id="wo-target-field"
                  formControlName="fieldId"
                  class="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white">
                  @for (field of farmData.fields(); track field.id) {
                    <option [value]="field.id">{{ field.code }} — {{ field.name }} ({{ field.crop }})</option>
                  }
                </select>
              </div>

              <div class="grid grid-cols-2 gap-3">
                <div>
                  <label for="wo-operation-type" class="block text-slate-400 mb-1">Operation Type</label>
                  <select 
                    id="wo-operation-type"
                    formControlName="type"
                    class="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white">
                    <option value="PLANTING">Seeding / Planting</option>
                    <option value="SPRAYING">Crop Protection Spraying</option>
                    <option value="FERTILIZING">Fertilizer Application</option>
                    <option value="TILLAGE">Cultivation / Tillage</option>
                    <option value="HARVESTING">Harvest Combine</option>
                    <option value="INSPECTION">Drone Inspection</option>
                  </select>
                </div>
                <div>
                  <label for="wo-target-rate" class="block text-slate-400 mb-1">Prescription Rate / Target</label>
                  <input 
                    id="wo-target-rate"
                    type="text" 
                    formControlName="targetRate"
                    placeholder="e.g. 140 L/ha Variable Rate"
                    class="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white" />
                </div>
              </div>

              <div class="grid grid-cols-2 gap-3">
                <div>
                  <label for="wo-assigned-machine" class="block text-slate-400 mb-1">Assigned Machine</label>
                  <select 
                    id="wo-assigned-machine"
                    formControlName="assignedMachine"
                    class="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white">
                    @for (m of farmData.machines(); track m.id) {
                      <option [value]="m.name">{{ m.name }} ({{ m.id }})</option>
                    }
                  </select>
                </div>
                <div>
                  <label for="wo-assigned-operator" class="block text-slate-400 mb-1">Operator</label>
                  <input 
                    id="wo-assigned-operator"
                    type="text" 
                    formControlName="assignedOperator"
                    class="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white" />
                </div>
              </div>

              <div>
                <label for="wo-execution-notes" class="block text-slate-400 mb-1">Execution Guidance Notes</label>
                <textarea 
                  id="wo-execution-notes"
                  formControlName="notes"
                  rows="3"
                  class="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white"></textarea>
              </div>

              <div class="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button 
                  type="button"
                  (click)="showCreateModal.set(false)"
                  class="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer">
                  Cancel
                </button>
                <button 
                  type="submit"
                  [disabled]="orderForm.invalid"
                  class="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold cursor-pointer disabled:opacity-50">
                  Publish Order
                </button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    :host {
      display: block;
      height: 100%;
    }
  `]
})
export class OperationsBoard {
  readonly farmData = inject(FarmDataService);
  private fb = inject(FormBuilder);

  readonly showCreateModal = signal<boolean>(false);

  orderForm = this.fb.group({
    fieldId: ['F-01', Validators.required],
    type: ['SPRAYING', Validators.required],
    targetRate: ['150 L/ha Micro-Nutrient', Validators.required],
    assignedMachine: ['Fendt Rogator 665', Validators.required],
    assignedOperator: ['Elena Rostova', Validators.required],
    notes: ['Maintain 50cm boom height with drift reduction nozzles.']
  });

  get plannedOrders(): WorkOrder[] {
    return this.farmData.workOrders().filter(o => o.status === 'PLANNED');
  }

  get activeOrders(): WorkOrder[] {
    return this.farmData.workOrders().filter(o => o.status === 'ACTIVE');
  }

  get completedOrders(): WorkOrder[] {
    return this.farmData.workOrders().filter(o => o.status === 'COMPLETED');
  }

  get delayedOrders(): WorkOrder[] {
    return this.farmData.workOrders().filter(o => o.status === 'DELAYED');
  }

  getOrderType(order: WorkOrder): string {
    return order.taskType || order.type || 'OPERATION';
  }

  getOrderMachine(order: WorkOrder): string {
    return order.assignedMachineName || order.assignedMachine || order.assignedMachineId || 'Machinery Unit';
  }

  getOrderOperator(order: WorkOrder): string {
    return order.operatorName || order.assignedOperator || 'Lead Operator';
  }

  getOrderTarget(order: WorkOrder): string {
    return order.prescriptionRate || order.targetRate || 'Prescription Target';
  }

  getOrderProgress(order: WorkOrder): number {
    if (order.progressPct !== undefined) return order.progressPct;
    if (order.targetAreaHa && order.completedAreaHa) {
      return Math.min(100, Math.round((order.completedAreaHa / order.targetAreaHa) * 100));
    }
    return order.status === 'COMPLETED' ? 100 : 45;
  }

  updateOrderStatus(orderId: string, status: WorkOrder['status']) {
    this.farmData.workOrders.update(orders => 
      orders.map(o => o.id === orderId ? { ...o, status, progressPct: status === 'COMPLETED' ? 100 : o.progressPct } : o)
    );
  }

  submitWorkOrder() {
    const val = this.orderForm.value;
    const field = this.farmData.fields().find(f => f.id === val.fieldId);
    const taskTypeVal = (val.type as NonNullable<WorkOrder['taskType']>) || 'SPRAYING';
    
    const newOrder: WorkOrder = {
      id: `WO-${Date.now().toString().slice(-4)}`,
      fieldId: val.fieldId || 'F-01',
      fieldName: field?.name || 'Field 01',
      taskType: taskTypeVal,
      type: taskTypeVal,
      status: 'PLANNED',
      scheduledStartTime: '08:00 Tomorrow',
      scheduledDate: new Date().toISOString().split('T')[0],
      assignedMachineId: 'M-01',
      assignedMachineName: val.assignedMachine || 'Tractor 01',
      assignedMachine: val.assignedMachine || 'Tractor 01',
      operatorName: val.assignedOperator || 'Farm Ops',
      assignedOperator: val.assignedOperator || 'Farm Ops',
      targetRate: val.targetRate || 'Standard Rate',
      prescriptionRate: val.targetRate || 'Standard Rate',
      targetAreaHa: field?.areaHa || 50,
      completedAreaHa: 0,
      progressPct: 0,
      notes: val.notes || ''
    };

    this.farmData.workOrders.update(orders => [newOrder, ...orders]);
    this.showCreateModal.set(false);
  }
}
