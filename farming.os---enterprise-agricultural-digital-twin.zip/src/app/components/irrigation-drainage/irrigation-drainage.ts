import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FarmDataService } from '../../core/services/farm-data.service';

@Component({
  selector: 'app-irrigation-drainage',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full overflow-y-auto p-5 space-y-6 text-slate-100 bg-slate-950/80">
      <!-- Water & Hydro Header -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h1 class="text-xl font-bold font-display text-white flex items-center gap-2.5">
            <mat-icon class="text-cyan-400">water_drop</mat-icon>
            Precision Hydro-Twin & Water Reticulation
          </h1>
          <p class="text-xs text-slate-400 mt-0.5">Automated Center Pivots • Drip Sectors • Sub-surface Tile Drainage • Retention Storage</p>
        </div>
        <div class="flex items-center gap-2 text-xs font-mono">
          <span class="px-3 py-1.5 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 font-semibold">
            TOTAL FLOW: {{ totalWaterFlowM3h }} m³/h
          </span>
        </div>
      </div>

      <!-- Water Metrics Grid -->
      <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-1">
          <div class="text-xs text-slate-400">Water Retention Pond Storage</div>
          <div class="text-2xl font-bold font-display text-cyan-400">
            {{ farmData.waterStorageM3().toLocaleString() }} <span class="text-xs font-mono text-slate-400">m³</span>
          </div>
          <div class="text-[11px] text-cyan-500 font-mono">82% Basin Capacity</div>
        </div>

        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-1">
          <div class="text-xs text-slate-400">Main Line Pressure</div>
          <div class="text-2xl font-bold font-display text-white">
            4.2 <span class="text-xs font-mono text-slate-400">bar</span>
          </div>
          <div class="text-[11px] text-emerald-400 font-mono">VFD Booster Pump Optimal</div>
        </div>

        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-1">
          <div class="text-xs text-slate-400">Active Irrigation Zones</div>
          <div class="text-2xl font-bold font-display text-emerald-400">
            {{ activeNodesCount }} <span class="text-xs font-mono text-slate-400">nodes</span>
          </div>
          <div class="text-[11px] text-slate-400 font-mono">2 Center Pivots Active</div>
        </div>

        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-1">
          <div class="text-xs text-slate-400">Evapotranspiration (ET0)</div>
          <div class="text-2xl font-bold font-display text-amber-300">
            3.8 <span class="text-xs font-mono text-slate-400">mm/day</span>
          </div>
          <div class="text-[11px] text-amber-400 font-mono">Moisture deficit target: 4.2mm</div>
        </div>
      </div>

      <!-- Irrigation Nodes & Pivots Control List -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-4">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3">
          <h2 class="text-sm font-bold text-white font-display flex items-center gap-2">
            <mat-icon class="text-cyan-400 text-base">rotate_right</mat-icon>
            Center Pivot & Zone Actuator Controllers
          </h2>
          <span class="text-xs font-mono text-slate-400">{{ farmData.irrigationNodes().length }} Telemetry Nodes</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
          @for (node of farmData.irrigationNodes(); track node.id) {
            <div class="bg-slate-950/70 border border-slate-800 rounded-2xl p-4 space-y-3">
              <div class="flex items-center justify-between">
                <div class="font-bold text-white text-sm font-display">{{ node.name }}</div>
                <span 
                  [class.bg-cyan-500/10]="node.status === 'ACTIVE'"
                  [class.text-cyan-400]="node.status === 'ACTIVE'"
                  [class.border-cyan-500/30]="node.status === 'ACTIVE'"
                  [class.bg-slate-800]="node.status !== 'ACTIVE'"
                  [class.text-slate-400]="node.status !== 'ACTIVE'"
                  class="px-2 py-0.5 rounded-full text-[10px] font-mono border">
                  {{ node.status }}
                </span>
              </div>

              <div class="grid grid-cols-2 gap-2 text-xs">
                <div class="bg-slate-900 p-2 rounded-xl border border-slate-800">
                  <div class="text-[10px] text-slate-400">Flow Rate</div>
                  <div class="font-mono font-bold text-cyan-300">{{ node.flowRateM3H }} m³/h</div>
                </div>
                <div class="bg-slate-900 p-2 rounded-xl border border-slate-800">
                  <div class="text-[10px] text-slate-400">Pressure</div>
                  <div class="font-mono font-bold text-white">{{ node.pressureBar }} bar</div>
                </div>
              </div>

              @if (node.type === 'PIVOT') {
                <div class="text-[11px] text-slate-400 flex justify-between font-mono bg-slate-900/60 p-2 rounded-xl">
                  <span>Pivot Azimuth Angle:</span>
                  <span class="text-white font-bold">{{ node.angleDeg?.toFixed(1) }}°</span>
                </div>
              }

              <button 
                (click)="toggleNode(node.id)"
                [class.bg-cyan-600]="node.status === 'ACTIVE'"
                [class.hover:bg-cyan-500]="node.status === 'ACTIVE'"
                [class.bg-slate-800]="node.status !== 'ACTIVE'"
                [class.hover:bg-slate-700]="node.status !== 'ACTIVE'"
                class="w-full py-2 px-3 rounded-xl text-xs font-semibold text-white transition-all shadow-md flex items-center justify-center gap-1.5 cursor-pointer">
                <mat-icon class="text-sm">{{ node.status === 'ACTIVE' ? 'power_settings_new' : 'play_arrow' }}</mat-icon>
                {{ node.status === 'ACTIVE' ? 'Halt Irrigation Line' : 'Start Scheduled Application' }}
              </button>
            </div>
          }
        </div>
      </div>

      <!-- Drainage & Retention Ponds Overview -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2.5">
          <h2 class="text-sm font-bold text-white font-display flex items-center gap-2">
            <mat-icon class="text-blue-400 text-base">waves</mat-icon>
            Subsurface Tile Drainage & Retention Swales
          </h2>
          <span class="text-xs font-mono text-slate-400">Gravity Hydrology Flow Network</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
          @for (ditch of farmData.drainageNodes(); track ditch.id) {
            <div class="bg-slate-950/70 border border-slate-800 rounded-xl p-3 flex items-center justify-between text-xs">
              <div class="flex items-center gap-2.5">
                <mat-icon class="text-blue-400 text-base">alt_route</mat-icon>
                <div>
                  <div class="font-bold text-white">{{ ditch.name }}</div>
                  <div class="text-[11px] text-slate-400 font-mono">Type: {{ ditch.type }} | Level: {{ ditch.currentWaterLevelM }}m / {{ ditch.maxCapacityM }}m</div>
                </div>
              </div>
              <div class="text-right font-mono">
                <div class="text-emerald-400 font-bold">{{ ditch.flowRateLSec }} L/s</div>
                <div class="text-[10px] text-slate-500">{{ ditch.status }}</div>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      height: 100%;
    }
  `]
})
export class IrrigationDrainage {
  readonly farmData = inject(FarmDataService);

  get activeNodesCount(): number {
    return this.farmData.irrigationNodes().filter(n => n.status === 'ACTIVE').length;
  }

  get totalWaterFlowM3h(): number {
    return this.farmData.irrigationNodes().reduce((acc, n) => acc + (n.status === 'ACTIVE' ? n.flowRateM3H : 0), 0);
  }

  toggleNode(id: string) {
    this.farmData.irrigationNodes.update(nodes => 
      nodes.map(n => n.id === id ? { ...n, status: n.status === 'ACTIVE' ? 'IDLE' : 'ACTIVE' } : n)
    );
  }
}
