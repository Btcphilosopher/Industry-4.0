import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FarmDataService } from '../../core/services/farm-data.service';

@Component({
  selector: 'app-energy-water-analytics',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full overflow-y-auto p-5 space-y-6 text-slate-100 bg-slate-950/80">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h1 class="text-xl font-bold font-display text-white flex items-center gap-2.5">
            <mat-icon class="text-amber-400">energy_savings_leaf</mat-icon>
            Energy, Water, Carbon & Economic Balances
          </h1>
          <p class="text-xs text-slate-400 mt-0.5">Microgrid Telemetry • Net-Zero Carbon Accounting • Field Profitability ($/ha)</p>
        </div>
      </div>

      <!-- Energy Microgrid Dashboard -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-2">
          <div class="flex items-center justify-between text-xs text-slate-400">
            <span>Solar PV Output</span>
            <mat-icon class="text-amber-400 text-sm">wb_sunny</mat-icon>
          </div>
          <div class="text-2xl font-bold font-display text-amber-300">
            {{ farmData.solarGenerationKw().toFixed(1) }} <span class="text-xs font-mono font-normal text-slate-400">kW</span>
          </div>
          <div class="text-[11px] text-emerald-400 font-mono">Offsetting 94% of irrigation load</div>
        </div>

        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-2">
          <div class="flex items-center justify-between text-xs text-slate-400">
            <span>BESS Battery Storage</span>
            <mat-icon class="text-cyan-400 text-sm">battery_charging_full</mat-icon>
          </div>
          <div class="text-2xl font-bold font-display text-cyan-300">
            {{ farmData.batteryStoragePct() }}% <span class="text-xs font-mono font-normal text-slate-400">State of Charge</span>
          </div>
          <div class="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
            <div class="h-full bg-cyan-400 rounded-full" [style.width.%]="farmData.batteryStoragePct()"></div>
          </div>
        </div>

        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-2">
          <div class="flex items-center justify-between text-xs text-slate-400">
            <span>Diesel Fuel Consumption</span>
            <mat-icon class="text-red-400 text-sm">local_gas_station</mat-icon>
          </div>
          <div class="text-2xl font-bold font-display text-white">
            18.4 <span class="text-xs font-mono font-normal text-slate-400">L/ha avg</span>
          </div>
          <div class="text-[11px] text-emerald-400 font-mono">-14% vs conventional tillage</div>
        </div>
      </div>

      <!-- Carbon & Soil Health -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4">
          <h2 class="text-sm font-bold text-white font-display flex items-center gap-2">
            <mat-icon class="text-emerald-400 text-base">compost</mat-icon>
            Carbon Sequestration & Soil Health Ledger
          </h2>

          <div class="space-y-3 text-xs">
            <div class="flex justify-between items-center p-3 bg-slate-950/70 rounded-xl border border-slate-800">
              <span class="text-slate-300">Net Farm Carbon Balance</span>
              <span class="font-mono font-bold text-emerald-400">+1.84 t CO₂e / ha / yr</span>
            </div>
            <div class="flex justify-between items-center p-3 bg-slate-950/70 rounded-xl border border-slate-800">
              <span class="text-slate-300">Average Soil Organic Carbon (SOC)</span>
              <span class="font-mono font-bold text-cyan-300">3.65%</span>
            </div>
            <div class="flex justify-between items-center p-3 bg-slate-950/70 rounded-xl border border-slate-800">
              <span class="text-slate-300">Nitrogen Use Efficiency (NUE)</span>
              <span class="font-mono font-bold text-amber-300">74.2%</span>
            </div>
          </div>
        </div>

        <!-- Yield Economics ($/ha) -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4">
          <h2 class="text-sm font-bold text-white font-display flex items-center gap-2">
            <mat-icon class="text-green-400 text-base">monetization_on</mat-icon>
            Crop Gross Margin Forecast ($ / ha)
          </h2>

          <div class="space-y-2 text-xs">
            @for (field of farmData.fields().slice(0, 4); track field.id) {
              <div class="p-3 bg-slate-950/70 rounded-xl border border-slate-800 flex justify-between items-center">
                <div>
                  <div class="font-bold text-white">{{ field.code }} ({{ field.crop.split('/')[0] }})</div>
                  <div class="text-[11px] text-slate-400">{{ field.currentYieldForecastTonneHa }} t/ha @ $240/t</div>
                </div>
                <div class="text-right font-mono">
                  <div class="font-bold text-emerald-400 text-sm">
                    &#36;{{ calculateGrossMargin(field.currentYieldForecastTonneHa) }} / ha
                  </div>
                  <div class="text-[10px] text-slate-500">Gross Margin</div>
                </div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      height: 100%;
    }
  `]
})
export class EnergyWaterAnalytics {
  readonly farmData = inject(FarmDataService);

  calculateGrossMargin(yieldTonneHa: number): string {
    const margin = (yieldTonneHa * 240) - 820;
    return margin.toFixed(0);
  }
}
