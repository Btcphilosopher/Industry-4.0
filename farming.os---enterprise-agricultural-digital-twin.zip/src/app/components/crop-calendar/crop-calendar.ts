import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FarmDataService } from '../../core/services/farm-data.service';

@Component({
  selector: 'app-crop-calendar',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full overflow-y-auto p-5 space-y-6 text-slate-100 bg-slate-950/80">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h1 class="text-xl font-bold font-display text-white flex items-center gap-2.5">
            <mat-icon class="text-emerald-400">calendar_month</mat-icon>
            Crop Phenology & Agronomic Calendar
          </h1>
          <p class="text-xs text-slate-400 mt-0.5">Growing Degree Days (GDD) Thermal Models • 5-Year Crop Rotation Matrices</p>
        </div>
      </div>

      <!-- Rotation & Phenology Field Timeline Matrix -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4">
        <h2 class="text-sm font-bold text-white font-display flex items-center gap-2">
          <mat-icon class="text-emerald-400 text-base">view_timeline</mat-icon>
          2026 Active Crop Growth Phases & Harvest Windows
        </h2>

        <div class="space-y-4">
          @for (field of farmData.fields(); track field.id) {
            <button 
              type="button"
              (click)="farmData.selectField(field.id)"
              class="w-full text-left bg-slate-950/70 border border-slate-800 rounded-xl p-4 space-y-2.5 hover:border-emerald-500/50 cursor-pointer transition-all">
              <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div class="flex items-center gap-2.5">
                  <span class="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 font-bold font-mono text-xs flex items-center justify-center">
                    {{ field.code }}
                  </span>
                  <div>
                    <div class="text-xs font-bold text-white">{{ field.name }} ({{ field.areaHa }} ha)</div>
                    <div class="text-[11px] text-slate-400">Crop: <span class="text-emerald-300 font-semibold">{{ field.crop }}</span> ({{ field.variety }})</div>
                  </div>
                </div>

                <div class="flex items-center gap-3 text-xs font-mono">
                  <span class="text-slate-400">Planted: <strong class="text-slate-200">{{ field.plantingDate }}</strong></span>
                  <span class="text-slate-500">•</span>
                  <span class="text-amber-400">Harvest: <strong class="text-white">{{ field.expectedHarvest }}</strong></span>
                </div>
              </div>

              <!-- Phenology Step Progress Bar -->
              <div class="space-y-1">
                <div class="flex justify-between text-[11px]">
                  <span class="text-slate-400">Stage: <strong class="text-emerald-400 uppercase">{{ field.growthStage.replace('_', ' ') }}</strong></span>
                  <span class="text-cyan-400 font-mono">GDD Index: {{ (field.growthIndex * 1450).toFixed(0) }} / 1600 °C·d</span>
                </div>

                <div class="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden flex">
                  <div 
                    class="h-full bg-gradient-to-r from-emerald-600 via-teal-500 to-amber-400 rounded-full transition-all duration-700"
                    [style.width.%]="field.growthIndex * 100">
                  </div>
                </div>
              </div>

              <!-- 4-Year Historic Rotation Tags -->
              <div class="flex items-center gap-1.5 text-[10px] font-mono pt-1 text-slate-400">
                <span>Rotation:</span>
                <span class="px-2 py-0.5 rounded bg-slate-800 text-slate-300">2023: Barley</span>
                <span>→</span>
                <span class="px-2 py-0.5 rounded bg-slate-800 text-slate-300">2024: Oilseed Rape</span>
                <span>→</span>
                <span class="px-2 py-0.5 rounded bg-slate-800 text-slate-300">2025: Winter Wheat</span>
                <span>→</span>
                <span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-500/30 font-bold">2026: {{ field.crop.split('/')[0] }}</span>
              </div>
            </button>
          }
        </div>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      height: 100%;
    }
  `]
})
export class CropCalendar {
  readonly farmData = inject(FarmDataService);
}
