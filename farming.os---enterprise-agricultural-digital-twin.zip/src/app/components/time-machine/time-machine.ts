import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FarmDataService } from '../../core/services/farm-data.service';

@Component({
  selector: 'app-time-machine',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full overflow-y-auto p-5 space-y-6 text-slate-100 bg-slate-950/80">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h1 class="text-xl font-bold font-display text-white flex items-center gap-2.5">
            <mat-icon class="text-purple-400">history_toggle_off</mat-icon>
            Farm Time-Machine & What-If Scenario Engine
          </h1>
          <p class="text-xs text-slate-400 mt-0.5">Biophysical Crop Simulation Replay • Climate Stress Inoculation</p>
        </div>

        <div class="flex items-center gap-2">
          <span 
            [class.bg-purple-500/10]="farmData.activeScenario()"
            [class.text-purple-400]="farmData.activeScenario()"
            [class.border-purple-500/30]="farmData.activeScenario()"
            [class.bg-slate-800]="!farmData.activeScenario()"
            [class.text-slate-400]="!farmData.activeScenario()"
            class="px-3 py-1.5 rounded-xl border text-xs font-mono font-semibold">
            {{ farmData.activeScenario() ? ('SCENARIO: ' + farmData.activeScenario()?.name) : 'BASELINE HISTORICAL STREAM' }}
          </span>
        </div>
      </div>

      <!-- Playback Timeline Scrub Bar -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <button 
              (click)="farmData.isLiveMode.set(!farmData.isLiveMode())"
              [class.bg-emerald-600]="farmData.isLiveMode()"
              [class.bg-slate-800]="!farmData.isLiveMode()"
              class="px-3 py-1.5 rounded-xl text-xs font-bold text-white flex items-center gap-1.5 transition-all">
              <mat-icon class="text-sm">{{ farmData.isLiveMode() ? 'pause' : 'play_arrow' }}</mat-icon>
              {{ farmData.isLiveMode() ? 'Live Sim Running' : 'Simulation Paused' }}
            </button>

            <!-- Speed Multipliers -->
            <div class="flex bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs font-mono">
              @for (speed of [1, 5, 20, 100]; track speed) {
                <button 
                  (click)="farmData.simulationSpeed.set(speed)"
                  [class.bg-purple-600]="farmData.simulationSpeed() === speed"
                  [class.text-white]="farmData.simulationSpeed() === speed"
                  [class.text-slate-400]="farmData.simulationSpeed() !== speed"
                  class="px-2.5 py-1 rounded-lg transition-all font-semibold">
                  {{ speed }}x
                </button>
              }
            </div>
          </div>

          <div class="text-xs font-mono text-cyan-400">
            Sim Timeline: <strong>Day {{ farmData.timelineDay() }} of 240 (August 14, 2026)</strong>
          </div>
        </div>

        <!-- Slider Bar -->
        <div class="space-y-1.5">
          <input 
            type="range" 
            min="1" 
            max="240" 
            [value]="farmData.timelineDay()"
            (input)="onTimelineScrub($event)"
            class="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-purple-500" />
          <div class="flex justify-between text-[10px] font-mono text-slate-500">
            <span>Mar 1 (Planting)</span>
            <span>May 15 (Canopy Close)</span>
            <span>Jul 10 (Grain Fill)</span>
            <span class="text-amber-400 font-bold">Aug 14 (Harvest Window)</span>
            <span>Oct 30 (Post-Harvest)</span>
          </div>
        </div>
      </div>

      <!-- What-If Scenario Presets -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3">
          <h2 class="text-sm font-bold text-white font-display flex items-center gap-2">
            <mat-icon class="text-purple-400 text-base">science</mat-icon>
            What-If Biophysical Stress Scenarios
          </h2>
          @if (farmData.activeScenario()) {
            <button 
              (click)="farmData.resetScenario()"
              class="text-xs text-purple-400 hover:text-white underline font-mono">
              Reset to Baseline
            </button>
          }
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3.5">
          @for (scenario of farmData.scenarios(); track scenario.id) {
            <button 
              type="button"
              (click)="farmData.applyScenario(scenario.id)"
              [class.border-purple-500]="farmData.activeScenario()?.id === scenario.id"
              [class.bg-purple-950/30]="farmData.activeScenario()?.id === scenario.id"
              [class.border-slate-800]="farmData.activeScenario()?.id !== scenario.id"
              class="bg-slate-950/70 border rounded-xl p-4 space-y-2.5 cursor-pointer hover:border-purple-500/50 transition-all text-left w-full">
              <div class="flex items-start justify-between">
                <h3 class="text-xs font-bold text-white">{{ scenario.name }}</h3>
                <span 
                  [class.text-emerald-400]="scenario.yieldImpactPct >= 0"
                  [class.text-red-400]="scenario.yieldImpactPct < 0"
                  class="text-xs font-mono font-bold">
                  {{ scenario.yieldImpactPct > 0 ? '+' : '' }}{{ scenario.yieldImpactPct }}%
                </span>
              </div>
              <p class="text-[11px] text-slate-300 line-clamp-2 leading-relaxed">{{ scenario.description }}</p>
              <div class="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] font-mono text-slate-400">
                <span>Moisture Δ: {{ scenario.moistureDeltaPct }}%</span>
                <span class="text-purple-300 font-semibold">{{ farmData.activeScenario()?.id === scenario.id ? 'ACTIVE' : 'Simulate' }}</span>
              </div>
            </button>
          }
        </div>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      height: 100%;
    }
  `]
})
export class TimeMachine {
  readonly farmData = inject(FarmDataService);

  onTimelineScrub(event: Event) {
    const input = event.target as HTMLInputElement;
    this.farmData.timelineDay.set(parseInt(input.value, 10));
  }
}
