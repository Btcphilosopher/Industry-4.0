import { ChangeDetectionStrategy, Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { KOTLIN_ARCHITECTURE_MODULES, KotlinModuleSpec } from '../../core/models/kotlin-specs.model';

@Component({
  selector: 'app-kotlin-architecture-viewer',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full overflow-y-auto p-5 space-y-6 text-slate-100 bg-slate-950/80">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h1 class="text-xl font-bold font-display text-white flex items-center gap-2.5">
            <mat-icon class="text-purple-400">code</mat-icon>
            Farming.OS Kotlin Multiplatform & Digital Twin Engine Architecture
          </h1>
          <p class="text-xs text-slate-400 mt-0.5">High-Performance Clean Architecture • Coroutines & StateFlow Reactive Pipeline</p>
        </div>

        <div class="flex items-center gap-2 text-xs font-mono">
          <span class="px-3 py-1.5 rounded-xl bg-purple-500/10 border border-purple-500/30 text-purple-400 font-semibold">
            Kotlin 2.0+ • Multiplatform
          </span>
        </div>
      </div>

      <!-- Architecture Module Selector & Viewer -->
      <div class="grid grid-cols-1 lg:grid-cols-4 gap-5">
        <!-- Module Navigation Sidebar -->
        <div class="space-y-2">
          <div class="text-xs font-mono text-slate-400 uppercase tracking-wider font-semibold">Architecture Layers</div>
          @for (mod of modules; track mod.id) {
            <button 
              (click)="selectedModule.set(mod)"
              [class.bg-purple-950/50]="selectedModule().id === mod.id"
              [class.border-purple-500/60]="selectedModule().id === mod.id"
              [class.text-white]="selectedModule().id === mod.id"
              [class.bg-slate-900/70]="selectedModule().id !== mod.id"
              [class.border-slate-800]="selectedModule().id !== mod.id"
              [class.text-slate-300]="selectedModule().id !== mod.id"
              class="w-full text-left p-3 rounded-xl border transition-all text-xs font-medium hover:border-slate-700">
              <div class="font-bold font-display flex items-center justify-between">
                <span>{{ mod.name }}</span>
                <mat-icon class="text-sm text-purple-400">chevron_right</mat-icon>
              </div>
              <p class="text-[11px] text-slate-400 mt-1 line-clamp-2">{{ mod.description }}</p>
            </button>
          }
        </div>

        <!-- Code & Details Viewer -->
        <div class="lg:col-span-3 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-2xl">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h2 class="text-sm font-bold text-white font-display">{{ selectedModule().name }}</h2>
              <p class="text-xs text-slate-400 font-mono">{{ selectedModule().package }}</p>
            </div>
            <span class="px-2.5 py-1 rounded-lg bg-slate-950 text-emerald-400 font-mono text-xs border border-slate-800">
              KOTLIN SOURCE
            </span>
          </div>

          <!-- Code Snippet Box -->
          <div class="bg-slate-950 rounded-xl p-4 border border-slate-800/90 font-mono text-xs overflow-x-auto text-emerald-300 leading-relaxed shadow-inner">
            <pre>{{ selectedModule().codeSnippet }}</pre>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      height: 100%;
    }
  `]
})
export class KotlinArchitectureViewer {
  readonly modules = KOTLIN_ARCHITECTURE_MODULES;
  readonly selectedModule = signal<KotlinModuleSpec>(KOTLIN_ARCHITECTURE_MODULES[0]);
}
