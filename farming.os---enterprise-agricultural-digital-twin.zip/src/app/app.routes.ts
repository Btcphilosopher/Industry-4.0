import { Routes } from '@angular/router';
import { CommandCentre } from './components/command-centre/command-centre';

export const routes: Routes = [
  {
    path: '',
    component: CommandCentre
  },
  {
    path: '**',
    redirectTo: ''
  }
];
