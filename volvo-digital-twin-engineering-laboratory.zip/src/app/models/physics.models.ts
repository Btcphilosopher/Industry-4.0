export type DriveMode = 'Comfort' | 'Eco' | 'Dynamic' | 'Off-road' | 'Individual';
export type RoadSurfaceType = 'Dry Asphalt' | 'Wet Asphalt' | 'Snow' | 'Ice' | 'Gravel' | 'Mud';
export type WeatherType = 'Clear' | 'Cloudy' | 'Rain' | 'Heavy Rain' | 'Snow' | 'Fog' | 'Night';
export type DynamicsModelComplexity = 'Bicycle Model' | 'Enhanced Bicycle Model' | 'Full Vehicle Model';

export interface VehicleState {
  timestamp: number; // s
  stepCount: number;
  
  // Position & Orientation
  x: number; // m
  y: number; // m
  z: number; // m
  yaw: number; // rad
  pitch: number; // rad
  roll: number; // rad
  
  // Kinematics
  velocity: number; // m/s
  speed_kmh: number; // km/h
  acceleration_mps2: number; // m/s^2
  lateralAcceleration_mps2: number; // m/s^2 (G * 9.81)
  yawRate_radps: number; // rad/s
  sideslipAngle_rad: number; // rad (beta)
  
  // Controls & Inputs
  throttleInput: number; // 0.0 - 1.0
  brakePedalInput: number; // 0.0 - 1.0
  steeringAngle_rad: number; // road wheel angle
  steeringWheelAngle_deg: number; // driver wheel angle
  driveMode: DriveMode;
  gearSelection: 'P' | 'R' | 'N' | 'D' | 'B';
  
  // Powertrain & Energy
  motorTorque_Nm: number;
  motorRpm: number;
  motorPower_kW: number;
  motorEfficiency: number; // 0.0 - 1.0
  regenPower_kW: number;
  engineRpm?: number;
  engineTorque_Nm?: number;
  fuelRate_Lph?: number;
  totalEnergyConsumed_kWh: number;
  instantaneousConsumption_kWhPer100km: number;
  averageConsumption_kWhPer100km: number;
  estimatedRemainingRange_km: number;
  
  // Battery State (Digital Twin)
  batterySoc: number; // 0.0 - 100.0 %
  batterySoh: number; // 0.0 - 100.0 %
  batteryVoltage_V: number;
  batteryCurrent_A: number;
  batteryTemp_C: number;
  batteryMaxCellTemp_C: number;
  batteryMinCellTemp_C: number;
  batteryCoolantTemp_C: number;
  cellTemperatures_C: number[]; // e.g. 12 module samples
  cellVoltages_V: number[]; // e.g. 12 module samples
  
  // Dynamics & Suspension
  wheelSpeeds_radps: [number, number, number, number]; // FL, FR, RL, RR
  wheelSlipRatios: [number, number, number, number]; // FL, FR, RL, RR
  tyreSlipAngles_deg: [number, number, number, number];
  suspensionCompression_mm: [number, number, number, number];
  wheelVerticalLoads_N: [number, number, number, number];
  brakeDiscTemps_C: [number, number, number, number];
  frictionBrakePressure_bar: number;
  absActive: boolean;
  escActive: boolean;
  
  // Thermal & Cabin
  cabinTemp_C: number;
  cabinTargetTemp_C: number;
  hvacPower_kW: number;
  seatHeatingPower_kW: number;
  outsideTemp_C: number;
  solarRadiation_Wpm2: number;
  
  // Environment & External
  roadSurface: RoadSurfaceType;
  surfaceFrictionCoeff: number; // mu
  roadGrade_percent: number; // slope
  windSpeed_mps: number;
  windDirection_deg: number;
  headwindComponent_mps: number;
  weather: WeatherType;
  
  // Status Flags
  doorState: { driver: boolean; passenger: boolean; rearLeft: boolean; rearRight: boolean; trunk: boolean; hood: boolean };
  seatOccupancy: { driver: boolean; passenger: boolean; rearLeft: boolean; rearRight: boolean; rearCenter: boolean };
  lightingState: { lowBeam: boolean; highBeam: boolean; drlThor: boolean; brakeLight: boolean; indicators: 'None' | 'Left' | 'Right' | 'Hazard' };
  wiperState: 'Off' | 'Auto' | 'Low' | 'High';
  chargingState: 'Disconnected' | 'AC Connected' | 'DC Fast Charging' | 'Complete';
}

export interface SubsystemClockRates {
  dynamics_Hz: number;    // 100 - 1000 Hz
  powertrain_Hz: number;  // 100 Hz
  battery_Hz: number;     // 50 Hz
  adas_Hz: number;        // 20 Hz
  environment_Hz: number; // 10 Hz
  ui_fps: number;         // 60 fps
}

export interface SimulationConfig {
  seed: number;
  scenarioId: string;
  vehicleId: string;
  roadType: 'Highway' | 'Urban' | 'Rural' | 'Mountain' | 'Winter Testing Track';
  surfaceType: RoadSurfaceType;
  weather: WeatherType;
  ambientTemp_C: number;
  windSpeed_kmh: number;
  windDirection_deg: number;
  initialSpeed_kmh: number;
  initialSoc_percent: number;
  dynamicsComplexity: DynamicsModelComplexity;
  solverRate_Hz: number;
  enableSensorNoise: boolean;
  enableComponentFailures: boolean;
}
