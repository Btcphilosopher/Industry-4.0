export interface SoftwareNode {
  id: string;
  name: string;
  category: 'Core Compute' | 'Perception' | 'Propulsion' | 'Chassis' | 'Body' | 'Infotainment' | 'Connectivity';
  firmwareVersion: string;
  buildHash: string;
  cpuLoadPercent: number;
  memoryUsageMb: number;
  busUtilizationPercent: number;
  healthStatus: 'HEALTHY' | 'DEGRADED' | 'FAULT' | 'REBOOTING';
  redundancyStatus: 'Primary Active' | 'Dual Lockstep Sync' | 'Standby Hot-Swap';
}

export interface OtaPackage {
  version: string;
  releaseNotes: string;
  targetSubsystems: string[];
  packageSizeMb: number;
  sha256Signature: string;
  validationStatus: 'Verified' | 'Pending' | 'Corrupt';
  efficiencyGain_percent: number;
  rangeGain_km: number;
  thermalOptimization_percent: number;
}

export interface FleetVehicleSummary {
  simVin: string;
  modelId: string;
  modelName: string;
  locationCity: string;
  latitude: number;
  longitude: number;
  soc_percent: number;
  odometer_km: number;
  speed_kmh: number;
  batteryHealth_percent: number;
  brakePadWear_percent: number;
  tyrePressure_bar: number;
  operatingStatus: 'Driving' | 'Charging' | 'Idle' | 'Maintenance' | 'OTA Updating';
  softwareVersion: string;
  alerts: string[];
}

export interface ManufacturingStage {
  id: number;
  name: string;
  cycleTimeSeconds: number;
  status: 'ACTIVE' | 'HOLD' | 'INSPECTING';
  currentVin: string;
  passRatePercent: number;
  description: string;
  qualityMetrics: { metric: string; tolerance: string; measured: string; status: 'PASS' | 'WARNING' }[];
}

export interface ScenarioTimelineEvent {
  id: string;
  timeSeconds: number;
  type: 'Obstacle' | 'Weather' | 'Surface' | 'DriverInput' | 'Failure';
  description: string;
  parameters: Record<string, unknown>;
}

export interface SafetyComparisonResult {
  scenarioName: string;
  baseline: {
    stoppingDistance_m: number;
    minTTC_s: number;
    impactSpeed_kmh: number;
    collisionOccurred: boolean;
    decelerationPeak_g: number;
  };
  modified: {
    stoppingDistance_m: number;
    minTTC_s: number;
    impactSpeed_kmh: number;
    collisionOccurred: boolean;
    decelerationPeak_g: number;
    paramChanges: string[];
  };
}
