export type PowertrainType = 'BEV' | 'PHEV' | 'MHEV' | 'ICE';
export type BodyStyle = 'SUV' | 'Crossover' | 'Saloon' | 'Estate';
export type Market = 'UK' | 'Global' | 'Sweden';
export type ConfidenceLevel = 'Official Specification' | 'Simulation Parameter' | 'Calibrated Model';

export interface DataProvenance {
  source: string;
  sourceDate: string;
  market: Market;
  modelYear: number;
  confidence: ConfidenceLevel;
  notes?: string;
}

export interface ParameterWithProvenance<T> {
  value: T;
  unit: string;
  provenance: DataProvenance;
}

export interface VehicleDimensions {
  length_mm: ParameterWithProvenance<number>;
  width_mm: ParameterWithProvenance<number>;
  height_mm: ParameterWithProvenance<number>;
  wheelbase_mm: ParameterWithProvenance<number>;
  trackFront_mm: ParameterWithProvenance<number>;
  trackRear_mm: ParameterWithProvenance<number>;
  groundClearance_mm: ParameterWithProvenance<number>;
  turningCircle_m: ParameterWithProvenance<number>;
  cargoVolume_L: ParameterWithProvenance<number>;
  frontTrunkVolume_L?: ParameterWithProvenance<number>;
}

export interface VehicleMassDynamics {
  curbMass_kg: ParameterWithProvenance<number>;
  grossMass_kg: ParameterWithProvenance<number>;
  weightDistributionFrontPercent: ParameterWithProvenance<number>;
  centerOfGravityHeight_m: ParameterWithProvenance<number>;
  yawInertia_kgm2: ParameterWithProvenance<number>;
  dragCoefficient_Cd: ParameterWithProvenance<number>;
  frontalArea_m2: ParameterWithProvenance<number>;
  rollingResistanceCoeff: ParameterWithProvenance<number>;
}

export interface BatterySpecification {
  chemistry: 'NMC' | 'LFP';
  grossCapacity_kWh: ParameterWithProvenance<number>;
  usableCapacity_kWh: ParameterWithProvenance<number>;
  nominalVoltage_V: ParameterWithProvenance<number>;
  architectureVoltage: 400 | 800;
  maxChargeRateDC_kW: ParameterWithProvenance<number>;
  maxChargeRateAC_kW: ParameterWithProvenance<number>;
  moduleCount: number;
  cellsPerModule: number;
  thermalCoolingType: 'Liquid-cooled dual-jacket' | 'Direct refrigerant plate';
  optimalTempRange_C: [number, number];
  minOperatingTemp_C: number;
  maxOperatingTemp_C: number;
}

export interface MotorSpecification {
  position: 'Front' | 'Rear' | 'Dual (AWD)' | 'ERAD (Hybrid)';
  motorType: 'Permanent Magnet Synchronous (PSM)' | 'Asynchronous Induction (ASM)';
  maxPower_kW: ParameterWithProvenance<number>;
  maxTorque_Nm: ParameterWithProvenance<number>;
  maxRpm: ParameterWithProvenance<number>;
  inverterEfficiencyPeak: ParameterWithProvenance<number>;
  gearRatio: ParameterWithProvenance<number>;
  maxRegenPower_kW: ParameterWithProvenance<number>;
}

export interface HybridEngineSpecification {
  engineType: '2.0L Turbo 4-cyl' | '2.0L Turbo+Supercharger' | '1.5L 3-cyl';
  displacement_cc: ParameterWithProvenance<number>;
  maxEnginePower_kW: ParameterWithProvenance<number>;
  maxEngineTorque_Nm: ParameterWithProvenance<number>;
  fuelTankCapacity_L: ParameterWithProvenance<number>;
  transmission: '8-Speed Geartronic' | '7-Speed Dual-Clutch';
  electricOnlyRangeWLTP_km: ParameterWithProvenance<number>;
}

export interface SuspensionSpecification {
  typeFront: 'Double Wishbone' | 'MacPherson Strut';
  typeRear: 'Integral Link Multi-link' | 'Multi-link with composite leaf spring' | 'Integral Link with composite transverse leaf spring' | 'Multi-link' | 'Torsion Beam';
  airSuspensionAvailable: boolean;
  springStiffnessFront_Npm: ParameterWithProvenance<number>;
  springStiffnessRear_Npm: ParameterWithProvenance<number>;
  dampingCoefficientFront_Nspm: ParameterWithProvenance<number>;
  dampingCoefficientRear_Nspm: ParameterWithProvenance<number>;
  antiRollBarStiffness_Nmprad: ParameterWithProvenance<number>;
}

export interface BrakeSpecification {
  discDiameterFront_mm: ParameterWithProvenance<number>;
  discDiameterRear_mm: ParameterWithProvenance<number>;
  caliperPistonsFront: number;
  caliperPistonsRear: number;
  brakeByWire: boolean;
  maxDeceleration_g: ParameterWithProvenance<number>;
  blendedRegenEfficiency: ParameterWithProvenance<number>;
}

export interface TyreSpecification {
  sizeFront: string;
  sizeRear: string;
  nominalPressure_bar: ParameterWithProvenance<number>;
  corneringStiffnessFront_Nprad: ParameterWithProvenance<number>;
  corneringStiffnessRear_Nprad: ParameterWithProvenance<number>;
  compound: 'Low Rolling Resistance Summer' | 'All-Season Nordic' | 'Winter Studless';
}

export interface SteeringSpecification {
  steeringRatio: ParameterWithProvenance<number>;
  lockToLockTurns: ParameterWithProvenance<number>;
  electricPowerSteeringAssistanceLevels: ('Low' | 'Medium' | 'High')[];
  rearWheelSteeringAvailable: boolean;
  maxRearSteerAngle_deg?: ParameterWithProvenance<number>;
  turningCircleDiameter_m?: ParameterWithProvenance<number>;
}

export interface AdasSensorSuite {
  lidar: {
    equipped: boolean;
    model: string;
    range_m: ParameterWithProvenance<number>;
    horizontalFov_deg: ParameterWithProvenance<number>;
    verticalFov_deg: ParameterWithProvenance<number>;
    wavelength_nm: number;
  };
  cameras: {
    count: number;
    description: string;
    resolutionMegapixels: number;
    frontFov_deg: number;
  };
  radars: {
    count: number;
    frontRadarRange_m: ParameterWithProvenance<number>;
    cornerRadarRange_m: ParameterWithProvenance<number>;
    frequency_GHz: number;
  };
  ultrasonics: {
    count: number;
    range_m: ParameterWithProvenance<number>;
  };
  coreComputer: {
    platform: string;
    aiOpsCapability: string;
    redundantArchitecture: boolean;
  };
}

export interface SoftwareDefinedArchitecture {
  osVersion: string;
  coreComputePartition: 'Volvo Core System SPA2/GMA' | 'SPA1 Distributed Architecture' | 'SEA Modular Platform';
  otaSupportedSubsystems: string[];
  connectivity: '5G Dual SIM eSIM' | '4G LTE Advanced';
  cybersecurityLevel: 'ISO/SAE 21434 High Assurance';
}

export interface VolvoVehicleModel {
  id: string; // e.g., 'ex60', 'ex90', 'ex30', 'xc60-phev'
  modelName: string;
  name?: string;
  modelYear: number;
  bodyStyle: BodyStyle;
  powertrainType: PowertrainType;
  trim: string;
  tagline: string;
  platform: string;
  colorHex: string;
  colorName: string;
  accentColor: string;
  dimensions: VehicleDimensions;
  massDynamics: VehicleMassDynamics;
  curbMass_kg?: ParameterWithProvenance<number>;
  battery?: BatterySpecification;
  motor?: MotorSpecification;
  hybridEngine?: HybridEngineSpecification;
  suspension: SuspensionSpecification;
  brakes: BrakeSpecification;
  tyres: TyreSpecification;
  steering: SteeringSpecification;
  sensors: AdasSensorSuite;
  software: SoftwareDefinedArchitecture;
  defaultDriveMode: 'Comfort' | 'Eco' | 'Dynamic' | 'Off-road' | 'Individual';
  wltpRange_km?: ParameterWithProvenance<number>;
  acceleration0to100_s: ParameterWithProvenance<number>;
  topSpeed_kmh: ParameterWithProvenance<number>;
  co2Emissions_gkm: ParameterWithProvenance<number>;
}
