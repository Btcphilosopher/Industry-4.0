export type DetectedObjectType = 'Vehicle' | 'Pedestrian' | 'Cyclist' | 'Large Animal' | 'Road Barrier' | 'Debris';
export type AdasInterventionLevel = 'Nominal' | 'Visual Warning' | 'Acoustic Alert' | 'Haptic Cue' | 'Active Deceleration' | 'Emergency Braking' | 'Evasive Steering';

export interface SimulatedObstacle {
  id: string;
  type: DetectedObjectType;
  x: number; // relative longitudinal distance (m) ahead
  y: number; // relative lateral distance (m) (+ left, - right)
  vx: number; // longitudinal speed m/s
  vy: number; // lateral speed m/s
  length_m: number;
  width_m: number;
  height_m: number;
  confidence: number;
  heading_deg: number;
}

export interface LidarPoint {
  x: number;
  y: number;
  z: number;
  intensity: number;
  ring: number;
}

export interface RadarTarget {
  id: number;
  range_m: number;
  azimuth_deg: number;
  rangeRate_mps: number; // doppler radial velocity
  rcs_dBsm: number;
  snr_dB: number;
  confidence: number;
}

export interface CameraDetection {
  id: string;
  class: DetectedObjectType;
  bbox: { xMin: number; yMin: number; xMax: number; yMax: number }; // normalized 0..1
  distanceEstimate_m: number;
  timeToCollision_s: number;
  confidence: number;
}

export interface FusedTrackedObject {
  trackId: number;
  type: DetectedObjectType;
  x: number; // longitudinal pos
  y: number; // lateral pos
  vx: number;
  vy: number;
  ax: number;
  timeToCollision_s: number;
  distance_m: number;
  confidence: number;
  fusionSources: ('LiDAR' | 'Radar' | 'Camera')[];
  criticalThreat: boolean;
}

export interface AdasSystemStates {
  fcwStatus: 'Standby' | 'Monitoring' | 'Alerting';
  aebStatus: 'Active' | 'Intervening' | 'Suppressed';
  accStatus: 'Off' | 'Engaged' | 'Following' | 'Override';
  accSetSpeed_kmh: number;
  accTimeGap_s: number;
  pilotAssistStatus: 'Off' | 'Steering Assist Ready' | 'Active Hands-On' | 'Takeover Request';
  laneKeepingStatus: 'Centered' | 'Drifting Left' | 'Drifting Right' | 'Correcting';
  blisLeft: boolean;
  blisRight: boolean;
  crossTrafficAlert: boolean;
  trafficSignSpeedLimit_kmh: number;
  interventionLevel: AdasInterventionLevel;
  targetBrakeDeceleration_mps2: number;
}

export interface FailureInjectionState {
  lidarDropout: boolean;
  radarBlindness: boolean;
  cameraLensOcclusion: boolean;
  gpsDegradation: boolean;
  brakeActuatorDelay_ms: number;
  motorThermalDerate: boolean;
  batteryOverheat: boolean;
  canBusLatency_ms: number;
}
