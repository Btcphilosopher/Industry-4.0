import { Component, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { HeaderBar } from './components/header-bar/header-bar';
import { VehicleSelector } from './components/vehicle-selector/vehicle-selector';
import { SimControlToolbar } from './components/sim-control-toolbar/sim-control-toolbar';
import { Vehicle3dViewer } from './components/vehicle-3d-viewer/vehicle-3d-viewer';
import { ChassisDynamicsLab } from './components/labs/chassis-dynamics-lab/chassis-dynamics-lab';
import { PowertrainBatteryLab } from './components/labs/powertrain-battery-lab/powertrain-battery-lab';
import { AdasPerceptionLab } from './components/labs/adas-perception-lab/adas-perception-lab';
import { SdvFleetLab } from './components/labs/sdv-fleet-lab/sdv-fleet-lab';
import { MonteCarloLab } from './components/labs/monte-carlo-lab/monte-carlo-lab';
import { SimulationEngineService } from './services/simulation-engine.service';
import { AdasLabService } from './services/adas-lab.service';

export type EngineeringTab =
  | 'overview'
  | 'dynamics'
  | 'powertrain'
  | 'adas'
  | 'sdv-fleet'
  | 'monte-carlo';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    MatIconModule,
    HeaderBar,
    VehicleSelector,
    SimControlToolbar,
    Vehicle3dViewer,
    ChassisDynamicsLab,
    PowertrainBatteryLab,
    AdasPerceptionLab,
    SdvFleetLab,
    MonteCarloLab
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  readonly simEngine = inject(SimulationEngineService);
  readonly adasLab = inject(AdasLabService);

  readonly activeTab = signal<EngineeringTab>('overview');

  readonly tabs: { id: EngineeringTab; name: string; icon: string }[] = [
    { id: 'overview', name: 'Digital Twin & 3D Proving Ground', icon: 'visibility' },
    { id: 'dynamics', name: 'Chassis & Dynamics Laboratory', icon: 'track_changes' },
    { id: 'powertrain', name: 'Powertrain, Battery & Thermal', icon: 'battery_charging_full' },
    { id: 'adas', name: 'ADAS & Sensor Fusion Lab', icon: 'sensors' },
    { id: 'sdv-fleet', name: 'SDV Architecture & Fleet Twin', icon: 'hub' },
    { id: 'monte-carlo', name: 'Monte Carlo & Stochastic Analytics', icon: 'casino' }
  ];

  setTab(tab: EngineeringTab) {
    this.activeTab.set(tab);
  }
}
