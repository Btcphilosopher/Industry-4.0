import { Injectable, signal } from '@angular/core';
import { VOLVO_VEHICLE_CATALOGUE } from '../data/vehicle-catalogue.data';
import { PREDEFINED_SCENARIOS, PredefinedScenario } from '../data/scenarios.data';
import { VolvoVehicleModel } from '../models/vehicle.models';
import {
  VehicleState,
  DriveMode,
  RoadSurfaceType,
  WeatherType,
  DynamicsModelComplexity
} from '../models/physics.models';

const SURFACE_FRICTION_MAP: Record<RoadSurfaceType, number> = {
  'Dry Asphalt': 1.0,
  'Wet Asphalt': 0.72,
  'Gravel': 0.55,
  'Mud': 0.40,
  'Snow': 0.28,
  'Ice': 0.14
};

@Injectable({
  providedIn: 'root'
})
export class SimulationEngineService {
  // Available models
  readonly catalogue = signal<VolvoVehicleModel[]>(VOLVO_VEHICLE_CATALOGUE);
  readonly selectedVehicle = signal<VolvoVehicleModel>(VOLVO_VEHICLE_CATALOGUE[0]); // default EX60
  
  // Available scenarios
  readonly scenarios = signal<PredefinedScenario[]>(PREDEFINED_SCENARIOS);
  readonly selectedScenario = signal<PredefinedScenario>(PREDEFINED_SCENARIOS[0]);

  // Simulation Status
  readonly isRunning = signal<boolean>(false);
  readonly isPaused = signal<boolean>(false);
  readonly isReplaying = signal<boolean>(false);
  readonly playbackRate = signal<number>(1.0); // 0.5x, 1x, 2x, 5x, 10x
  readonly simulationTime = signal<number>(0.0);
  readonly simSpeedMultiplier = signal<number>(1.0);
  readonly solverFrequency_Hz = signal<number>(100); // 100 Hz default for main physics
  readonly modelComplexity = signal<DynamicsModelComplexity>('Bicycle Model');

  // Active Vehicle State (Signal for real-time reactive components)
  readonly currentState = signal<VehicleState>(this.createInitialState(VOLVO_VEHICLE_CATALOGUE[0]));

  // Telemetry Recording Buffer for Replay & Analytics
  private telemetryBuffer: VehicleState[] = [];
  readonly recordedFramesCount = signal<number>(0);
  readonly replayIndex = signal<number>(0);

  // Failure Injection
  readonly componentFailures = signal<{
    motorDerate: boolean;
    batteryThermalSpike: boolean;
    brakeDegradation: boolean;
    sensorDropout: boolean;
  }>({
    motorDerate: false,
    batteryThermalSpike: false,
    brakeDegradation: false,
    sensorDropout: false
  });

  // Animation Loop handle
  private animationFrameId: number | null = null;
  private lastWallClockTimestamp: number | null = null;
  private accumulatorSeconds = 0;

  constructor() {
    this.resetSimulation();
  }

  selectVehicleById(id: string) {
    const found = this.catalogue().find(v => v.id === id);
    if (found) {
      this.selectedVehicle.set(found);
      this.resetSimulation();
    }
  }

  selectScenarioById(id: string) {
    const found = this.scenarios().find(s => s.id === id);
    if (found) {
      this.selectedScenario.set(found);
      // If scenario specifies vehicle, optionally auto-switch or maintain
      if (found.recommendedVehicleId) {
        this.selectVehicleById(found.recommendedVehicleId);
      } else {
        this.resetSimulation();
      }
    }
  }

  setDriveMode(mode: DriveMode) {
    this.currentState.update(s => ({ ...s, driveMode: mode }));
  }

  setSurface(surface: RoadSurfaceType) {
    const mu = SURFACE_FRICTION_MAP[surface];
    this.currentState.update(s => ({ ...s, roadSurface: surface, surfaceFrictionCoeff: mu }));
  }

  setWeather(weather: WeatherType) {
    this.currentState.update(s => ({ ...s, weather }));
  }

  setAmbientTemp(temp_C: number) {
    this.currentState.update(s => ({ ...s, outsideTemp_C: temp_C }));
  }

  setWind(speed_kmh: number, dir_deg: number) {
    this.currentState.update(s => ({
      ...s,
      windSpeed_mps: speed_kmh / 3.6,
      windDirection_deg: dir_deg,
      headwindComponent_mps: (speed_kmh / 3.6) * Math.cos((dir_deg * Math.PI) / 180)
    }));
  }

  setInputs(throttle: number, brake: number, steer_rad: number) {
    this.currentState.update(s => ({
      ...s,
      throttleInput: Math.max(0, Math.min(1, throttle)),
      brakePedalInput: Math.max(0, Math.min(1, brake)),
      steeringAngle_rad: Math.max(-0.6, Math.min(0.6, steer_rad)),
      steeringWheelAngle_deg: (steer_rad * 180 / Math.PI) * (this.selectedVehicle().steering.steeringRatio.value)
    }));
  }

  toggleComponentFailure(key: keyof ReturnType<typeof this.componentFailures>) {
    this.componentFailures.update(f => ({ ...f, [key]: !f[key] }));
  }

  startSimulation() {
    if (this.isRunning()) return;
    this.isRunning.set(true);
    this.isPaused.set(false);
    this.isReplaying.set(false);
    this.lastWallClockTimestamp = null;
    this.accumulatorSeconds = 0;
    this.runLoop();
  }

  pauseSimulation() {
    this.isPaused.set(true);
    this.isRunning.set(false);
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
  }

  resumeSimulation() {
    if (this.isRunning()) return;
    this.startSimulation();
  }

  resetSimulation() {
    this.pauseSimulation();
    const vehicle = this.selectedVehicle();
    const scenario = this.selectedScenario();
    const state = this.createInitialState(vehicle, scenario);
    this.currentState.set(state);
    this.simulationTime.set(0.0);
    this.telemetryBuffer = [state];
    this.recordedFramesCount.set(1);
    this.replayIndex.set(0);
  }

  // Step simulation forward by one fixed delta-T (e.g. 0.01s)
  stepSingle(dt = 0.01) {
    const v = this.selectedVehicle();
    const current = this.currentState();
    const next = this.computeNextPhysicsStep(current, v, dt);
    this.currentState.set(next);
    this.simulationTime.set(next.timestamp);
    this.telemetryBuffer.push(next);
    if (this.telemetryBuffer.length > 50000) this.telemetryBuffer.shift();
    this.recordedFramesCount.set(this.telemetryBuffer.length);
  }

  seekReplay(index: number) {
    if (this.telemetryBuffer.length === 0) return;
    const bounded = Math.max(0, Math.min(this.telemetryBuffer.length - 1, index));
    this.replayIndex.set(bounded);
    this.currentState.set(this.telemetryBuffer[bounded]);
    this.simulationTime.set(this.telemetryBuffer[bounded].timestamp);
  }

  getTelemetryLog(): VehicleState[] {
    return [...this.telemetryBuffer];
  }

  private runLoop = () => {
    if (!this.isRunning()) return;

    const now = performance.now();
    if (this.lastWallClockTimestamp === null) {
      this.lastWallClockTimestamp = now;
    }

    const wallDt = Math.min((now - this.lastWallClockTimestamp) / 1000, 0.1); // cap at 100ms
    this.lastWallClockTimestamp = now;

    const rate = this.playbackRate();
    const simDt = 1.0 / this.solverFrequency_Hz();
    this.accumulatorSeconds += wallDt * rate;

    // Subsystem multi-rate step loop
    const maxSubSteps = 20;
    let subSteps = 0;
    while (this.accumulatorSeconds >= simDt && subSteps < maxSubSteps) {
      this.stepSingle(simDt);
      this.accumulatorSeconds -= simDt;
      subSteps++;
    }

    this.animationFrameId = requestAnimationFrame(this.runLoop);
  };

  /**
   * Deterministic Physics Solver (SI Units)
   * Longitudinal forces + Lateral Bicycle dynamics + Non-linear Pacejka tyre slip
   * + Reduced-Order Battery Electrochemical/Thermal state + HVAC load
   */
  private computeNextPhysicsStep(state: VehicleState, vehicle: VolvoVehicleModel, dt: number): VehicleState {
    const next: VehicleState = JSON.parse(JSON.stringify(state));
    next.timestamp = +(state.timestamp + dt).toFixed(4);
    next.stepCount = state.stepCount + 1;

    const mass_kg = vehicle.massDynamics.curbMass_kg.value + 80; // + driver mass
    const g = 9.80665;
    const airDensity_rho = 1.225; // kg/m^3
    const cd = vehicle.massDynamics.dragCoefficient_Cd.value;
    const frontalArea_A = vehicle.massDynamics.frontalArea_m2.value;
    const crr = vehicle.massDynamics.rollingResistanceCoeff.value;
    const mu = state.surfaceFrictionCoeff;

    // 1. Aerodynamic Drag Force: F_drag = 0.5 * rho * Cd * A * (v + v_wind)^2
    const relativeAirspeed = Math.max(0, state.velocity + state.headwindComponent_mps);
    const f_drag = 0.5 * airDensity_rho * cd * frontalArea_A * (relativeAirspeed * relativeAirspeed);

    // 2. Rolling Resistance: F_rr = Crr * m * g * cos(theta) * mu_correction
    const f_rr = crr * mass_kg * g * Math.max(0.1, mu);

    // 3. Grade Resistance: F_grade = m * g * sin(grade_angle)
    const gradeAngle_rad = Math.atan((state.roadGrade_percent || 0) / 100);
    const f_grade = mass_kg * g * Math.sin(gradeAngle_rad);

    // 4. Drive Mode Modifiers
    let throttleGain = 1.0;
    let regenAgility = 1.0;
    if (state.driveMode === 'Eco') {
      throttleGain = 0.75;
      regenAgility = 1.25;
    } else if (state.driveMode === 'Dynamic') {
      throttleGain = 1.35;
      regenAgility = 0.85;
    }

    // 5. Powertrain Drive Force / Motor Torque
    let tractiveForce = 0;
    let motorPower_kW = 0;
    let regenPower_kW = 0;
    let motorTorque_Nm = 0;
    let motorRpm = 0;

    const isEV = vehicle.powertrainType === 'BEV';
    const isPHEV = vehicle.powertrainType === 'PHEV';
    const failures = this.componentFailures();

    if (isEV && vehicle.motor && vehicle.battery) {
      const maxMotorTorque = failures.motorDerate ? vehicle.motor.maxTorque_Nm.value * 0.5 : vehicle.motor.maxTorque_Nm.value;
      const maxMotorPower = failures.motorDerate ? vehicle.motor.maxPower_kW.value * 0.5 : vehicle.motor.maxPower_kW.value;
      const gearRatio = vehicle.motor.gearRatio.value;
      const tyreRadius_m = (vehicle.dimensions.trackFront_mm.value > 0 ? 0.365 : 0.35); // tyre nominal effective radius

      // Motor RPM = (v / tyreRadius) * gearRatio * (60 / 2pi)
      motorRpm = (state.velocity / tyreRadius_m) * gearRatio * 9.549296;
      motorRpm = Math.min(motorRpm, vehicle.motor.maxRpm.value);

      if (state.throttleInput > 0 && state.gearSelection === 'D') {
        const requestedTorque = state.throttleInput * throttleGain * maxMotorTorque;
        // Constant power curve beyond base speed
        const currentPowerCap = (motorRpm > 4000) ? (maxMotorPower * 1000 * 9.549296 / motorRpm) : maxMotorTorque;
        motorTorque_Nm = Math.min(requestedTorque, currentPowerCap);
        tractiveForce = (motorTorque_Nm * gearRatio * 0.95) / tyreRadius_m; // 95% drivetrain efficiency
        motorPower_kW = (motorTorque_Nm * motorRpm) / 9549.296;
      }

      // Regenerative Braking during coasting or brake pedal application
      if (state.throttleInput === 0 && state.velocity > 0.5) {
        const regenDemand = (state.brakePedalInput > 0)
          ? Math.min(1.0, state.brakePedalInput * 1.5)
          : (state.driveMode === 'Eco' ? 0.35 : 0.15); // One-Pedal Drive / lift-off regen
        
        const maxRegenCap_kW = vehicle.motor.maxRegenPower_kW.value * regenAgility;
        // Derate regen if battery SOC is above 95% or temp is too cold/hot
        let socRegenFactor = 1.0;
        if (state.batterySoc > 90) socRegenFactor = Math.max(0, (100 - state.batterySoc) / 10);
        if (state.batteryTemp_C < 5) socRegenFactor *= 0.5;

        regenPower_kW = regenDemand * maxRegenCap_kW * socRegenFactor;
        const regenBrakingForce = (regenPower_kW * 1000) / Math.max(1.0, state.velocity);
        tractiveForce -= regenBrakingForce;
      }
    } else if (isPHEV && vehicle.hybridEngine) {
      // Hybrid Powertrain: ICE + ERAD Electric Motor
      const maxTorque = (vehicle.hybridEngine.maxEngineTorque_Nm.value + (vehicle.motor?.maxTorque_Nm.value || 0)) * (failures.motorDerate ? 0.6 : 1.0);
      const requestedTorque = state.throttleInput * throttleGain * maxTorque;
      motorRpm = state.velocity > 0 ? (state.velocity / 0.36) * 7.5 * 9.55 : 850;
      tractiveForce = (requestedTorque * 7.8 * 0.92) / 0.36;
      motorPower_kW = (requestedTorque * motorRpm) / 9549.296;
      next.engineRpm = Math.max(850, motorRpm * 0.85);
      next.engineTorque_Nm = requestedTorque * 0.65;
    }

    // 6. Friction Braking System
    let frictionBrakingForce = 0;
    const brakePedal = state.brakePedalInput;
    if (brakePedal > 0) {
      const maxBrakeForce = mass_kg * g * (failures.brakeDegradation ? 0.55 : vehicle.brakes.maxDeceleration_g.value) * mu;
      // Linear progressive friction brake threshold after regen
      const frictionThreshold = isEV ? 0.15 : 0.05;
      if (brakePedal > frictionThreshold) {
        const brakeFactor = (brakePedal - frictionThreshold) / (1.0 - frictionThreshold);
        frictionBrakingForce = brakeFactor * maxBrakeForce;
      }
      next.frictionBrakePressure_bar = brakePedal * 95;
    } else {
      next.frictionBrakePressure_bar = 0;
    }

    // 7. Net Longitudinal Acceleration: F_net = F_drive - F_friction_brake - F_drag - F_rr - F_grade
    let f_net = tractiveForce - frictionBrakingForce - f_drag - f_rr - f_grade;

    // Prevent reverse motion from friction/drag at zero speed
    if (state.velocity <= 0.05 && f_net < 0 && state.throttleInput === 0) {
      f_net = 0;
      next.velocity = 0;
    }

    const acceleration = f_net / mass_kg;
    let nextVelocity = Math.max(0, state.velocity + acceleration * dt);
    
    // Top speed limiter (180 km/h standard Volvo limiter)
    const topSpeed_mps = vehicle.topSpeed_kmh.value / 3.6;
    if (nextVelocity > topSpeed_mps) {
      nextVelocity = topSpeed_mps;
    }

    next.acceleration_mps2 = +acceleration.toFixed(3);
    next.velocity = +nextVelocity.toFixed(3);
    next.speed_kmh = +(nextVelocity * 3.6).toFixed(1);
    next.motorPower_kW = +motorPower_kW.toFixed(2);
    next.regenPower_kW = +regenPower_kW.toFixed(2);
    next.motorTorque_Nm = +motorTorque_Nm.toFixed(1);
    next.motorRpm = +motorRpm.toFixed(0);

    // 8. Lateral Dynamics — Single-Track Bicycle Model & Non-Linear Slip
    // L = wheelbase, a = distance to front axle, b = distance to rear axle
    const wheelbase_L = vehicle.dimensions.wheelbase_mm.value / 1000;
    const frontWeightRatio = vehicle.massDynamics.weightDistributionFrontPercent.value / 100;
    const distToRear_b = wheelbase_L * frontWeightRatio;
    const distToFront_a = wheelbase_L - distToRear_b;
    const cf = vehicle.tyres.corneringStiffnessFront_Nprad.value * mu;
    const cr = vehicle.tyres.corneringStiffnessRear_Nprad.value * mu;
    const iz = vehicle.massDynamics.yawInertia_kgm2.value;

    const delta = state.steeringAngle_rad;
    const vx = Math.max(1.0, state.velocity); // avoid division by zero
    const vy = state.sideslipAngle_rad * vx;
    const r = state.yawRate_radps;

    // Slip angles
    const alpha_f = delta - Math.atan((vy + distToFront_a * r) / vx);
    const alpha_r = -Math.atan((vy - distToRear_b * r) / vx);

    // Lateral tyre forces (simplified linear Pacejka tangent)
    const fy_f = cf * Math.tan(alpha_f);
    const fy_r = cr * Math.tan(alpha_r);

    // Equations of motion
    const vy_dot = (fy_f * Math.cos(delta) + fy_r) / mass_kg - vx * r;
    const r_dot = (distToFront_a * fy_f * Math.cos(delta) - distToRear_b * fy_r) / iz;

    const nextVy = vy + vy_dot * dt;
    const nextR = r + r_dot * dt;
    const nextBeta = Math.atan(nextVy / vx);
    const lateralAccel = vx * nextR + vy_dot;

    next.yawRate_radps = +nextR.toFixed(4);
    next.sideslipAngle_rad = +nextBeta.toFixed(4);
    next.lateralAcceleration_mps2 = +lateralAccel.toFixed(3);

    // Position integration in world space
    next.yaw = +(state.yaw + nextR * dt).toFixed(4);
    next.x = +(state.x + (vx * Math.cos(next.yaw) - nextVy * Math.sin(next.yaw)) * dt).toFixed(3);
    next.y = +(state.y + (vx * Math.sin(next.yaw) + nextVy * Math.cos(next.yaw)) * dt).toFixed(3);

    // 9. Suspension & Weight Transfer Dynamics
    // Dynamic wheel load transfer during acceleration & cornering
    const h_cg = vehicle.massDynamics.centerOfGravityHeight_m.value;
    const trackWidth = vehicle.dimensions.trackFront_mm.value / 1000;
    const deltaFz_long = (mass_kg * acceleration * h_cg) / wheelbase_L;
    const deltaFz_lat = (mass_kg * lateralAccel * h_cg) / trackWidth;

    const staticFz_front = (mass_kg * g * (distToRear_b / wheelbase_L)) / 2;
    const staticFz_rear = (mass_kg * g * (distToFront_a / wheelbase_L)) / 2;

    const fz_FL = Math.max(100, staticFz_front - deltaFz_long / 2 + deltaFz_lat / 2);
    const fz_FR = Math.max(100, staticFz_front - deltaFz_long / 2 - deltaFz_lat / 2);
    const fz_RL = Math.max(100, staticFz_rear + deltaFz_long / 2 + deltaFz_lat / 2);
    const fz_RR = Math.max(100, staticFz_rear + deltaFz_long / 2 - deltaFz_lat / 2);

    next.wheelVerticalLoads_N = [Math.round(fz_FL), Math.round(fz_FR), Math.round(fz_RL), Math.round(fz_RR)];

    // Suspension travel compression (mm)
    const k_spring_front = vehicle.suspension.springStiffnessFront_Npm.value;
    const k_spring_rear = vehicle.suspension.springStiffnessRear_Npm.value;
    next.suspensionCompression_mm = [
      +((fz_FL - staticFz_front) / k_spring_front * 1000).toFixed(1),
      +((fz_FR - staticFz_front) / k_spring_front * 1000).toFixed(1),
      +((fz_RL - staticFz_rear) / k_spring_rear * 1000).toFixed(1),
      +((fz_RR - staticFz_rear) / k_spring_rear * 1000).toFixed(1)
    ];

    // Pitch & Roll angles
    next.pitch = +((-deltaFz_long * wheelbase_L) / (k_spring_front * 4)).toFixed(4);
    next.roll = +((deltaFz_lat * trackWidth) / (vehicle.suspension.antiRollBarStiffness_Nmprad.value)).toFixed(4);

    // 10. Reduced-Order Battery Electrochemical & Thermal Model
    if (vehicle.battery) {
      const batteryCapacity_kWh = vehicle.battery.usableCapacity_kWh.value;
      const nominalVoltage = vehicle.battery.nominalVoltage_V.value;

      // Net electrical power from pack (kW) = Motor Power + Auxiliaries - Regen
      const auxPower_kW = state.hvacPower_kW + state.seatHeatingPower_kW + 0.45; // 450W central compute & electronics
      const netPackPower_kW = motorPower_kW + auxPower_kW - regenPower_kW;

      const batteryCurrent_A = (netPackPower_kW * 1000) / nominalVoltage;
      next.batteryCurrent_A = +batteryCurrent_A.toFixed(1);
      next.batteryVoltage_V = +(nominalVoltage - batteryCurrent_A * 0.045).toFixed(1); // Internal resistance drop

      // Delta SOC: energy (kWh) = P (kW) * (dt / 3600)
      const energyDelta_kWh = netPackPower_kW * (dt / 3600);
      next.totalEnergyConsumed_kWh = +(state.totalEnergyConsumed_kWh + energyDelta_kWh).toFixed(4);

      const socDelta = (energyDelta_kWh / batteryCapacity_kWh) * 100;
      next.batterySoc = +Math.max(0, Math.min(100, state.batterySoc - socDelta)).toFixed(3);

      // Battery Thermal Simulation: Q_gen = I^2 * R_int, Q_cool = h * A * (T_cell - T_coolant)
      const r_internal_ohm = 0.042 * (1 + 0.015 * Math.abs(state.batteryTemp_C - 25));
      const q_jouleHeating_W = batteryCurrent_A * batteryCurrent_A * r_internal_ohm;
      const coolingPumpActive = state.batteryTemp_C > 28 || failures.batteryThermalSpike;
      const q_cooling_W = coolingPumpActive ? 2800 * (state.batteryTemp_C - 20) / 10 : 150 * (state.batteryTemp_C - state.outsideTemp_C);

      const thermalMass_JpK = 180000; // Pack heat capacity
      const deltaTemp_C = ((q_jouleHeating_W - q_cooling_W) / thermalMass_JpK) * dt;
      let nextBatteryTemp = state.batteryTemp_C + deltaTemp_C;

      if (failures.batteryThermalSpike) {
        nextBatteryTemp += 0.15; // Rapid heating fault injection
      }

      next.batteryTemp_C = +nextBatteryTemp.toFixed(2);
      next.batteryMaxCellTemp_C = +(nextBatteryTemp + 2.2).toFixed(2);
      next.batteryMinCellTemp_C = +(nextBatteryTemp - 1.8).toFixed(2);
      next.batteryCoolantTemp_C = +(Math.min(nextBatteryTemp - 4.5, 22.0)).toFixed(2);

      // Update 12 cell thermal sensors across modules
      next.cellTemperatures_C = [
        +(nextBatteryTemp - 1.2).toFixed(1), +(nextBatteryTemp - 0.8).toFixed(1),
        +(nextBatteryTemp - 0.3).toFixed(1), +(nextBatteryTemp + 0.5).toFixed(1),
        +(nextBatteryTemp + 1.2).toFixed(1), +(nextBatteryTemp + 1.8).toFixed(1),
        +(nextBatteryTemp + 2.1).toFixed(1), +(nextBatteryTemp + 1.5).toFixed(1),
        +(nextBatteryTemp + 0.9).toFixed(1), +(nextBatteryTemp + 0.2).toFixed(1),
        +(nextBatteryTemp - 0.4).toFixed(1), +(nextBatteryTemp - 0.9).toFixed(1)
      ];

      // Energy consumption rate & remaining range estimation
      if (nextVelocity > 2.0) {
        next.instantaneousConsumption_kWhPer100km = +((netPackPower_kW / (nextVelocity * 3.6)) * 100).toFixed(1);
      } else {
        next.instantaneousConsumption_kWhPer100km = 0;
      }

      const usableRemaining_kWh = (next.batterySoc / 100) * batteryCapacity_kWh;
      const nominalEfficiency = 18.5; // kWh / 100km baseline
      next.estimatedRemainingRange_km = +Math.round((usableRemaining_kWh / nominalEfficiency) * 100);
    }

    // 11. Cabin Climate & Heat Pump Thermal Simulation
    const cabinTarget = state.cabinTargetTemp_C;
    const cabinDelta = cabinTarget - state.cabinTemp_C;
    if (Math.abs(cabinDelta) > 0.5) {
      next.hvacPower_kW = +Math.min(3.5, Math.abs(cabinDelta) * 0.8).toFixed(2);
      next.cabinTemp_C = +(state.cabinTemp_C + (cabinDelta * 0.015 * dt)).toFixed(2);
    } else {
      next.hvacPower_kW = 0.45; // Maintenance mode
      next.cabinTemp_C = +(state.cabinTemp_C + (cabinDelta * 0.005 * dt)).toFixed(2);
    }

    // 12. Brake Disc Friction Temperature
    const brakeHeat_W = frictionBrakingForce * nextVelocity;
    const brakeCool_W = 120 * (state.brakeDiscTemps_C[0] - state.outsideTemp_C);
    const deltaBrakeTemp = ((brakeHeat_W - brakeCool_W) / 4500) * dt;
    const nextBrakeTemp = Math.max(state.outsideTemp_C, state.brakeDiscTemps_C[0] + deltaBrakeTemp);
    next.brakeDiscTemps_C = [
      +nextBrakeTemp.toFixed(1), +nextBrakeTemp.toFixed(1),
      +(nextBrakeTemp * 0.8).toFixed(1), +(nextBrakeTemp * 0.8).toFixed(1)
    ];

    return next;
  }

  private createInitialState(vehicle: VolvoVehicleModel, scenario?: PredefinedScenario): VehicleState {
    const sc = scenario || PREDEFINED_SCENARIOS[0];
    const initSpeed_mps = (sc.initialSpeed_kmh || 0) / 3.6;
    const surface = sc.surfaceType || 'Dry Asphalt';
    const mu = SURFACE_FRICTION_MAP[surface];

    return {
      timestamp: 0.0,
      stepCount: 0,
      x: 0,
      y: 0,
      z: 0,
      yaw: 0,
      pitch: 0,
      roll: 0,
      velocity: initSpeed_mps,
      speed_kmh: sc.initialSpeed_kmh || 0,
      acceleration_mps2: 0,
      lateralAcceleration_mps2: 0,
      yawRate_radps: 0,
      sideslipAngle_rad: 0,
      throttleInput: 0,
      brakePedalInput: 0,
      steeringAngle_rad: 0,
      steeringWheelAngle_deg: 0,
      driveMode: vehicle.defaultDriveMode || 'Comfort',
      gearSelection: 'D',
      motorTorque_Nm: 0,
      motorRpm: (initSpeed_mps / 0.36) * 9.8 * 9.55,
      motorPower_kW: 0,
      motorEfficiency: 0.96,
      regenPower_kW: 0,
      totalEnergyConsumed_kWh: 0,
      instantaneousConsumption_kWhPer100km: 0,
      averageConsumption_kWhPer100km: 17.5,
      estimatedRemainingRange_km: vehicle.wltpRange_km ? vehicle.wltpRange_km.value : 450,
      batterySoc: sc.initialSoc_percent || 85,
      batterySoh: 99.4,
      batteryVoltage_V: vehicle.battery ? vehicle.battery.nominalVoltage_V.value : 400,
      batteryCurrent_A: 0,
      batteryTemp_C: 24.5,
      batteryMaxCellTemp_C: 25.8,
      batteryMinCellTemp_C: 23.9,
      batteryCoolantTemp_C: 21.0,
      cellTemperatures_C: [24.1, 24.3, 24.5, 24.7, 25.1, 25.4, 25.8, 25.3, 24.9, 24.6, 24.2, 23.9],
      cellVoltages_V: [3.82, 3.83, 3.82, 3.84, 3.83, 3.82, 3.83, 3.84, 3.82, 3.83, 3.82, 3.83],
      wheelSpeeds_radps: [initSpeed_mps / 0.36, initSpeed_mps / 0.36, initSpeed_mps / 0.36, initSpeed_mps / 0.36],
      wheelSlipRatios: [0, 0, 0, 0],
      tyreSlipAngles_deg: [0, 0, 0, 0],
      suspensionCompression_mm: [0, 0, 0, 0],
      wheelVerticalLoads_N: [5400, 5400, 5400, 5400],
      brakeDiscTemps_C: [25.0, 25.0, 24.5, 24.5],
      frictionBrakePressure_bar: 0,
      absActive: false,
      escActive: false,
      cabinTemp_C: 21.5,
      cabinTargetTemp_C: 21.0,
      hvacPower_kW: 0.45,
      seatHeatingPower_kW: 0,
      outsideTemp_C: sc.ambientTemp_C || 18,
      solarRadiation_Wpm2: 450,
      roadSurface: surface,
      surfaceFrictionCoeff: mu,
      roadGrade_percent: 0,
      windSpeed_mps: 0,
      windDirection_deg: 0,
      headwindComponent_mps: 0,
      weather: sc.weather || 'Clear',
      doorState: { driver: false, passenger: false, rearLeft: false, rearRight: false, trunk: false, hood: false },
      seatOccupancy: { driver: true, passenger: false, rearLeft: false, rearRight: false, rearCenter: false },
      lightingState: { lowBeam: true, highBeam: false, drlThor: true, brakeLight: false, indicators: 'None' },
      wiperState: 'Auto',
      chargingState: 'Disconnected'
    };
  }
}
