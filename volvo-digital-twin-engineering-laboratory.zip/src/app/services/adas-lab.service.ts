import { Injectable, signal, inject } from '@angular/core';
import { SimulationEngineService } from './simulation-engine.service';
import {
  SimulatedObstacle,
  LidarPoint,
  RadarTarget,
  CameraDetection,
  FusedTrackedObject,
  AdasSystemStates,
  FailureInjectionState
} from '../models/adas.models';
import { SafetyComparisonResult } from '../models/sdv-fleet.models';

@Injectable({
  providedIn: 'root'
})
export class AdasLabService {
  private simEngine = inject(SimulationEngineService);

  // Active Obstacles in Scene
  readonly obstacles = signal<SimulatedObstacle[]>([
    {
      id: 'ped-01',
      type: 'Pedestrian',
      x: 32.0, // 32 meters ahead
      y: 2.2,  // 2.2m to left, walking towards lane center
      vx: 0,
      vy: -1.2, // walking across road at 1.2 m/s
      length_m: 0.6,
      width_m: 0.6,
      height_m: 1.75,
      confidence: 0.96,
      heading_deg: 270
    },
    {
      id: 'veh-lead-02',
      type: 'Vehicle',
      x: 65.0, // 65m ahead
      y: 0.0,  // directly in ego vehicle lane
      vx: -4.0, // slower than ego
      vy: 0.0,
      length_m: 4.8,
      width_m: 1.9,
      height_m: 1.6,
      confidence: 0.99,
      heading_deg: 0
    }
  ]);

  // Synthetic Sensor Streams
  readonly lidarPoints = signal<LidarPoint[]>([]);
  readonly radarTargets = signal<RadarTarget[]>([]);
  readonly cameraDetections = signal<CameraDetection[]>([]);
  readonly fusedTracks = signal<FusedTrackedObject[]>([]);

  // ADAS System States & Safety Alerts
  readonly adasStates = signal<AdasSystemStates>({
    fcwStatus: 'Monitoring',
    aebStatus: 'Active',
    accStatus: 'Following',
    accSetSpeed_kmh: 80,
    accTimeGap_s: 1.8,
    pilotAssistStatus: 'Active Hands-On',
    laneKeepingStatus: 'Centered',
    blisLeft: false,
    blisRight: false,
    crossTrafficAlert: false,
    trafficSignSpeedLimit_kmh: 70,
    interventionLevel: 'Nominal',
    targetBrakeDeceleration_mps2: 0
  });

  // Sensor Failure Injections
  readonly failureState = signal<FailureInjectionState>({
    lidarDropout: false,
    radarBlindness: false,
    cameraLensOcclusion: false,
    gpsDegradation: false,
    brakeActuatorDelay_ms: 50,
    motorThermalDerate: false,
    batteryOverheat: false,
    canBusLatency_ms: 10
  });

  // Safety Scenario Reconstruction Matrix
  readonly sandboxConfig = signal<{
    driverReactionTime_s: number;
    sensorLatency_ms: number;
    surfaceFrictionMu: number;
    initialEgoSpeed_kmh: number;
  }>({
    driverReactionTime_s: 0.65,
    sensorLatency_ms: 60,
    surfaceFrictionMu: 0.85,
    initialEgoSpeed_kmh: 60
  });

  // Comparison Experiments Store
  readonly comparisonHistory = signal<SafetyComparisonResult[]>([]);

  constructor() {
    this.generateSyntheticSensors();
  }

  toggleSensorFailure(key: keyof FailureInjectionState) {
    this.failureState.update(s => {
      const currentVal = s[key];
      if (typeof currentVal === 'boolean') {
        return { ...s, [key]: !currentVal };
      }
      return s;
    });
    this.generateSyntheticSensors();
  }

  updateSandbox(key: string, value: number) {
    this.sandboxConfig.update(c => ({ ...c, [key]: value }));
  }

  runSafetyComparison() {
    const cfg = this.sandboxConfig();
    const egoSpeed_mps = cfg.initialEgoSpeed_kmh / 3.6;
    const g = 9.81;
    
    // Baseline (Dry Asphalt mu=1.0, 0.4s reaction, 20ms latency)
    const baseMu = 1.0;
    const baseReaction_s = 0.4;
    const baseBrakingDecel = baseMu * g * 0.95;
    const baseStoppingDistance = (egoSpeed_mps * baseReaction_s) + (egoSpeed_mps * egoSpeed_mps) / (2 * baseBrakingDecel);

    // Modified Sandbox Run
    const modBrakingDecel = cfg.surfaceFrictionMu * g * 0.95;
    const totalLag_s = cfg.driverReactionTime_s + (cfg.sensorLatency_ms / 1000);
    const modStoppingDistance = (egoSpeed_mps * totalLag_s) + (egoSpeed_mps * egoSpeed_mps) / (2 * modBrakingDecel);

    const obstacleDist = 38.0; // pedestrian distance
    const baseCollision = baseStoppingDistance > obstacleDist;
    const modCollision = modStoppingDistance > obstacleDist;

    const modImpactSpeed = modCollision
      ? Math.sqrt(Math.max(0, egoSpeed_mps * egoSpeed_mps - 2 * modBrakingDecel * (obstacleDist - egoSpeed_mps * totalLag_s))) * 3.6
      : 0;

    const result: SafetyComparisonResult = {
      scenarioName: `Safety Re-run @ ${cfg.initialEgoSpeed_kmh}km/h (μ=${cfg.surfaceFrictionMu})`,
      baseline: {
        stoppingDistance_m: +baseStoppingDistance.toFixed(1),
        minTTC_s: +(obstacleDist / egoSpeed_mps).toFixed(2),
        impactSpeed_kmh: baseCollision ? 12.5 : 0,
        collisionOccurred: baseCollision,
        decelerationPeak_g: +(baseBrakingDecel / g).toFixed(2)
      },
      modified: {
        stoppingDistance_m: +modStoppingDistance.toFixed(1),
        minTTC_s: +((obstacleDist - egoSpeed_mps * totalLag_s) / egoSpeed_mps).toFixed(2),
        impactSpeed_kmh: +modImpactSpeed.toFixed(1),
        collisionOccurred: modCollision,
        decelerationPeak_g: +(modBrakingDecel / g).toFixed(2),
        paramChanges: [
          `Friction μ: ${cfg.surfaceFrictionMu}`,
          `Reaction Time: ${cfg.driverReactionTime_s}s`,
          `Sensor Latency: ${cfg.sensorLatency_ms}ms`
        ]
      }
    };

    this.comparisonHistory.update(list => [result, ...list]);
  }

  /**
   * Generates Synthetic LiDAR Point Cloud, Radar returns, and Camera Bounding Boxes
   * based on scene obstacles and sensor health.
   */
  generateSyntheticSensors() {
    const failures = this.failureState();
    const obsList = this.obstacles();
    const egoState = this.simEngine.currentState();

    // 1. Synthetic LiDAR Beam Point Cloud (360 rings & forward raster)
    const points: LidarPoint[] = [];
    if (!failures.lidarDropout) {
      // Ground plane points
      for (let dist = 3; dist <= 70; dist += 3) {
        for (let angle = -60; angle <= 60; angle += 4) {
          const rad = (angle * Math.PI) / 180;
          const x = dist * Math.cos(rad);
          const y = dist * Math.sin(rad);
          points.push({
            x: +x.toFixed(2),
            y: +y.toFixed(2),
            z: -0.45,
            intensity: Math.max(10, Math.min(255, Math.round(200 - dist * 2.2))),
            ring: Math.floor(dist / 5)
          });
        }
      }

      // Obstacle point cloud clusters
      obsList.forEach((obs, idx) => {
        const clusterSize = obs.type === 'Vehicle' ? 45 : 18;
        for (let i = 0; i < clusterSize; i++) {
          const offsetX = (Math.random() - 0.5) * obs.length_m;
          const offsetY = (Math.random() - 0.5) * obs.width_m;
          const offsetZ = Math.random() * obs.height_m - 0.3;
          points.push({
            x: +(obs.x + offsetX).toFixed(2),
            y: +(obs.y + offsetY).toFixed(2),
            z: +offsetZ.toFixed(2),
            intensity: 220 + Math.round(Math.random() * 35),
            ring: (idx * 16) + (i % 16)
          });
        }
      });
    }
    this.lidarPoints.set(points);

    // 2. Synthetic Radar Targets (77GHz Doppler array)
    const radars: RadarTarget[] = [];
    if (!failures.radarBlindness) {
      obsList.forEach((obs, idx) => {
        const range = Math.sqrt(obs.x * obs.x + obs.y * obs.y);
        const azimuth = Math.atan2(obs.y, obs.x) * (180 / Math.PI);
        const relativeRadialVelocity = obs.vx - egoState.velocity;
        radars.push({
          id: idx + 1,
          range_m: +range.toFixed(2),
          azimuth_deg: +azimuth.toFixed(1),
          rangeRate_mps: +relativeRadialVelocity.toFixed(2),
          rcs_dBsm: obs.type === 'Vehicle' ? 18.5 : 2.5,
          snr_dB: Math.max(12, +(35 - range * 0.35).toFixed(1)),
          confidence: obs.confidence
        });
      });
    }
    this.radarTargets.set(radars);

    // 3. Optical Vision Camera Detections
    const cameras: CameraDetection[] = [];
    if (!failures.cameraLensOcclusion) {
      obsList.forEach(obs => {
        const dist = Math.max(1.0, obs.x);
        const ttc = egoState.velocity > 0 ? (obs.x / egoState.velocity) : 99.9;
        // Project to normalized 2D image coordinates
        const normX = Math.max(0.05, Math.min(0.95, 0.5 - (obs.y / dist) * 0.8));
        const boxWidth = Math.min(0.35, 1.8 / dist);
        const boxHeight = Math.min(0.45, 1.6 / dist);

        cameras.push({
          id: obs.id,
          class: obs.type,
          bbox: {
            xMin: +(normX - boxWidth / 2).toFixed(3),
            yMin: +(0.55 - boxHeight / 2).toFixed(3),
            xMax: +(normX + boxWidth / 2).toFixed(3),
            yMax: +(0.55 + boxHeight / 2).toFixed(3)
          },
          distanceEstimate_m: +dist.toFixed(1),
          timeToCollision_s: +ttc.toFixed(2),
          confidence: obs.confidence
        });
      });
    }
    this.cameraDetections.set(cameras);

    // 4. Kalman Filter Sensor Fusion Pipeline
    const fused: FusedTrackedObject[] = [];
    obsList.forEach((obs, idx) => {
      const sources: ('LiDAR' | 'Radar' | 'Camera')[] = [];
      if (!failures.lidarDropout) sources.push('LiDAR');
      if (!failures.radarBlindness) sources.push('Radar');
      if (!failures.cameraLensOcclusion) sources.push('Camera');

      const relativeSpeed = obs.vx - egoState.velocity;
      const ttc = (relativeSpeed < -0.1 && obs.x > 0) ? +(obs.x / Math.abs(relativeSpeed)).toFixed(2) : 99.9;
      const isThreat = ttc < 3.2 && Math.abs(obs.y) < 1.8;

      fused.push({
        trackId: 100 + idx,
        type: obs.type,
        x: obs.x,
        y: obs.y,
        vx: obs.vx,
        vy: obs.vy,
        ax: 0,
        timeToCollision_s: ttc,
        distance_m: +Math.sqrt(obs.x * obs.x + obs.y * obs.y).toFixed(1),
        confidence: sources.length >= 2 ? 0.98 : sources.length === 1 ? 0.75 : 0.0,
        fusionSources: sources,
        criticalThreat: isThreat
      });
    });
    this.fusedTracks.set(fused);

    // 5. Active Safety Controller Decision & Staged Intervention
    const critical = fused.find(f => f.criticalThreat);
    this.adasStates.update(st => {
      if (critical) {
        if (critical.timeToCollision_s < 1.4) {
          return {
            ...st,
            fcwStatus: 'Alerting',
            aebStatus: 'Intervening',
            interventionLevel: 'Emergency Braking',
            targetBrakeDeceleration_mps2: 9.2
          };
        } else if (critical.timeToCollision_s < 2.5) {
          return {
            ...st,
            fcwStatus: 'Alerting',
            aebStatus: 'Active',
            interventionLevel: 'Acoustic Alert',
            targetBrakeDeceleration_mps2: 4.5
          };
        }
      }
      return {
        ...st,
        fcwStatus: 'Monitoring',
        aebStatus: 'Active',
        interventionLevel: 'Nominal',
        targetBrakeDeceleration_mps2: 0
      };
    });
  }
}
