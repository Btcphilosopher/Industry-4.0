import { Injectable, signal } from '@angular/core';
import {
  SoftwareNode,
  OtaPackage,
  FleetVehicleSummary,
  ManufacturingStage
} from '../models/sdv-fleet.models';

export interface AuditRecord {
  id: string;
  timestamp: string;
  userRole: 'Viewer' | 'Engineer' | 'Safety Analyst' | 'Administrator';
  action: string;
  targetModule: string;
  details: string;
}

export interface MonteCarloRunResult {
  runId: number;
  muFriction: number;
  ambientTemp_C: number;
  windSpeed_kmh: number;
  stoppingDistance_m: number;
  energyConsumption_kWh100km: number;
  maxBatteryTemp_C: number;
  collisionDetected: boolean;
}

export interface SensitivityItem {
  parameter: string;
  baseline: string;
  deltaPercent: string;
  impactOnRange: number; // % delta
  impactOnBraking: number; // % delta
  impactOnAccel: number; // % delta
}

@Injectable({
  providedIn: 'root'
})
export class FleetManufacturingService {
  // 1. Software-Defined Vehicle Architecture Graph
  readonly softwareNodes = signal<SoftwareNode[]>([
    {
      id: 'core-compute-01',
      name: 'Volvo Central Core Compute System (SPA3/GMA)',
      category: 'Core Compute',
      firmwareVersion: 'v4.2.0-RC3',
      buildHash: '0x8F4A19B2',
      cpuLoadPercent: 38,
      memoryUsageMb: 8192,
      busUtilizationPercent: 42,
      healthStatus: 'HEALTHY',
      redundancyStatus: 'Dual Lockstep Sync'
    },
    {
      id: 'perception-node-02',
      name: 'Luminar LiDAR & Vision Perception Engine',
      category: 'Perception',
      firmwareVersion: 'v2.8.4',
      buildHash: '0x3C910A4F',
      cpuLoadPercent: 64,
      memoryUsageMb: 4096,
      busUtilizationPercent: 58,
      healthStatus: 'HEALTHY',
      redundancyStatus: 'Primary Active'
    },
    {
      id: 'bms-battery-03',
      name: 'High-Voltage Battery Management System (BMS)',
      category: 'Propulsion',
      firmwareVersion: 'v5.1.1',
      buildHash: '0x992B100E',
      cpuLoadPercent: 22,
      memoryUsageMb: 512,
      busUtilizationPercent: 29,
      healthStatus: 'HEALTHY',
      redundancyStatus: 'Dual Lockstep Sync'
    },
    {
      id: 'inverter-dual-04',
      name: 'Dual SiC Inverter Gate Driver & eAWD Controller',
      category: 'Propulsion',
      firmwareVersion: 'v3.0.7',
      buildHash: '0x10A88F7B',
      cpuLoadPercent: 31,
      memoryUsageMb: 256,
      busUtilizationPercent: 45,
      healthStatus: 'HEALTHY',
      redundancyStatus: 'Primary Active'
    },
    {
      id: 'chassis-air-05',
      name: 'Active Air Suspension & Dynamic Damping Module',
      category: 'Chassis',
      firmwareVersion: 'v2.1.0',
      buildHash: '0x44A29DF0',
      cpuLoadPercent: 18,
      memoryUsageMb: 128,
      busUtilizationPercent: 19,
      healthStatus: 'HEALTHY',
      redundancyStatus: 'Primary Active'
    },
    {
      id: 'infotainment-06',
      name: 'Volvo Android Automotive OS Cockpit Platform',
      category: 'Infotainment',
      firmwareVersion: 'v14.0.2',
      buildHash: '0x7EA511B9',
      cpuLoadPercent: 45,
      memoryUsageMb: 6144,
      busUtilizationPercent: 34,
      healthStatus: 'HEALTHY',
      redundancyStatus: 'Primary Active'
    },
    {
      id: 'telematics-5g-07',
      name: 'Connected Cloud Gateway & 5G Telematics (TCAM)',
      category: 'Connectivity',
      firmwareVersion: 'v3.9.0',
      buildHash: '0xBB0134E2',
      cpuLoadPercent: 28,
      memoryUsageMb: 1024,
      busUtilizationPercent: 25,
      healthStatus: 'HEALTHY',
      redundancyStatus: 'Standby Hot-Swap'
    }
  ]);

  // OTA Update Simulator
  readonly availableOta = signal<OtaPackage>({
    version: 'OTA Package 2026.3.1-Sprint',
    releaseNotes: 'Enhanced regenerative braking efficiency (+3.8%), improved battery pre-conditioning algorithm in freezing temperatures, and updated Pilot Assist curve smoothing.',
    targetSubsystems: ['BMS Battery Controller', 'Inverter MCU', 'Perception Fusion', 'Thermal Management'],
    packageSizeMb: 1480,
    sha256Signature: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    validationStatus: 'Verified',
    efficiencyGain_percent: 3.8,
    rangeGain_km: 22,
    thermalOptimization_percent: 8.5
  });

  readonly otaStage = signal<'Idle' | 'Downloading' | 'Validating' | 'Dual-Partition Flashing' | 'Vehicle Reboot' | 'Completed'>('Idle');
  readonly otaProgressPercent = signal<number>(0);

  // 2. Simulated Volvo Fleet
  readonly fleetVehicles = signal<FleetVehicleSummary[]>(this.generateInitialFleet());

  // 3. Manufacturing Digital Twin (Torslanda & Ghent Plants)
  readonly manufacturingStages = signal<ManufacturingStage[]>([
    {
      id: 1,
      name: 'Body Shop (Framing & Megacasting)',
      cycleTimeSeconds: 48,
      status: 'ACTIVE',
      currentVin: 'SIM-VIN-YV1-EX60-2026-00481',
      passRatePercent: 99.8,
      description: 'Robotic laser welding of boron steel safety cage and aluminum front/rear megacastings.',
      qualityMetrics: [
        { metric: 'Boron Cage Dimensional Tolerance', tolerance: '±0.5 mm', measured: '+0.18 mm', status: 'PASS' },
        { metric: 'Laser Seam Weld Penetration', tolerance: '>95%', measured: '98.4%', status: 'PASS' }
      ]
    },
    {
      id: 2,
      name: 'Paint Shop (Eco-Dip & Multi-coat)',
      cycleTimeSeconds: 62,
      status: 'ACTIVE',
      currentVin: 'SIM-VIN-YV1-EX90-2026-00214',
      passRatePercent: 99.4,
      description: 'Electro-dip cathodic primer followed by robotized waterborne basecoat and high-gloss clearcoat.',
      qualityMetrics: [
        { metric: 'Paint Thickness Uniformity', tolerance: '110-130 μm', measured: '122 μm', status: 'PASS' },
        { metric: 'Surface Finish Specular Gloss', tolerance: '>92 GU', measured: '95.6 GU', status: 'PASS' }
      ]
    },
    {
      id: 3,
      name: 'Battery Pack Cleanroom Assembly',
      cycleTimeSeconds: 55,
      status: 'ACTIVE',
      currentVin: 'SIM-VIN-YV1-ES90-2026-00109',
      passRatePercent: 99.9,
      description: 'Module bonding, cooling plate laser welding, structural enclosure sealing, and high-voltage insulation check.',
      qualityMetrics: [
        { metric: 'High-Voltage Hi-Pot Insulation Check', tolerance: '>100 MΩ @ 2.5kV', measured: '480 MΩ', status: 'PASS' },
        { metric: 'Helium Leak Detection on Coolant Plate', tolerance: '<1e-5 mbar·l/s', measured: '3.2e-7', status: 'PASS' }
      ]
    },
    {
      id: 4,
      name: 'Marriage (Chassis & Powertrain Integration)',
      cycleTimeSeconds: 70,
      status: 'ACTIVE',
      currentVin: 'SIM-VIN-YV1-EX60-2026-00480',
      passRatePercent: 99.6,
      description: 'Simultaneous torque-controlled multi-spindle bolting of battery pack, e-motors, and subframes to body shell.',
      qualityMetrics: [
        { metric: 'Subframe Bolting Torque Audit', tolerance: '180±5 Nm', measured: '181.2 Nm', status: 'PASS' },
        { metric: 'Wiring Harness Click & Clamping', tolerance: '100% Locked', measured: '100% Locked', status: 'PASS' }
      ]
    },
    {
      id: 5,
      name: 'End-of-Line ADAS & Dynamic Calibration',
      cycleTimeSeconds: 90,
      status: 'INSPECTING',
      currentVin: 'SIM-VIN-YV1-EX30-2026-00892',
      passRatePercent: 99.7,
      description: 'LiDAR optical calibration tunnel, radar target alignment, multi-camera intrinsic verification, and dynamometer brake test.',
      qualityMetrics: [
        { metric: 'LiDAR Zenith Pitch Alignment', tolerance: '0.0° ± 0.05°', measured: '+0.012°', status: 'PASS' },
        { metric: 'Brake Force Dynamometer Imbalance', tolerance: '<5%', measured: '1.4%', status: 'PASS' }
      ]
    }
  ]);

  // 4. Sensitivity Matrix Data
  readonly sensitivityAnalysis = signal<SensitivityItem[]>([
    { parameter: 'Vehicle Mass (+5%)', baseline: '2,180 kg', deltaPercent: '+5.0%', impactOnRange: -3.4, impactOnBraking: +4.8, impactOnAccel: -4.6 },
    { parameter: 'Tyre Pressure (-10%)', baseline: '2.6 bar', deltaPercent: '-10.0%', impactOnRange: -4.1, impactOnBraking: +2.5, impactOnAccel: -1.2 },
    { parameter: 'Ambient Temperature (-15°C Winter)', baseline: '+20°C', deltaPercent: '-35°C', impactOnRange: -22.5, impactOnBraking: +8.2, impactOnAccel: -2.0 },
    { parameter: 'Drag Coefficient Cd (+0.02)', baseline: '0.265 Cd', deltaPercent: '+7.5%', impactOnRange: -5.8, impactOnBraking: -0.5, impactOnAccel: -1.8 },
    { parameter: 'Motor Inverter Efficiency (+1.0%)', baseline: '97.5%', deltaPercent: '+1.0%', impactOnRange: +1.6, impactOnBraking: 0.0, impactOnAccel: +1.1 },
    { parameter: 'HVAC Cabin Load (Extreme Summer +38°C)', baseline: '0.45 kW', deltaPercent: '+3.5 kW', impactOnRange: -12.4, impactOnBraking: 0.0, impactOnAccel: -0.5 }
  ]);

  // 5. Monte Carlo Experiment History
  readonly monteCarloRuns = signal<MonteCarloRunResult[]>([]);

  // 6. Audit Trail
  readonly auditLogs = signal<AuditRecord[]>([
    {
      id: 'AUD-901',
      timestamp: new Date().toLocaleTimeString(),
      userRole: 'Administrator',
      action: 'PLATFORM_INITIALIZE',
      targetModule: 'SimulationCore',
      details: 'Deterministic simulation clock synced at 100Hz with SI units.'
    }
  ]);

  triggerOtaRollout() {
    if (this.otaStage() !== 'Idle') return;
    this.otaStage.set('Downloading');
    this.otaProgressPercent.set(15);
    this.addAudit('Engineer', 'OTA_TRIGGER', 'OTA Manager', 'Initiated dual-partition staged OTA rollout to digital twin.');

    setTimeout(() => {
      this.otaStage.set('Validating');
      this.otaProgressPercent.set(45);
    }, 1200);

    setTimeout(() => {
      this.otaStage.set('Dual-Partition Flashing');
      this.otaProgressPercent.set(80);
    }, 2400);

    setTimeout(() => {
      this.otaStage.set('Vehicle Reboot');
      this.otaProgressPercent.set(95);
    }, 3600);

    setTimeout(() => {
      this.otaStage.set('Completed');
      this.otaProgressPercent.set(100);
      this.addAudit('Engineer', 'OTA_COMPLETE', 'OTA Manager', 'Software update verified and active on Partition B.');
    }, 4800);
  }

  runMonteCarloBatch(iterations = 100) {
    const results: MonteCarloRunResult[] = [];
    const baseMu = 0.85;
    const baseTemp = 18;

    for (let i = 1; i <= iterations; i++) {
      const randMu = Math.max(0.12, Math.min(1.05, baseMu + (Math.random() - 0.5) * 0.4));
      const randTemp = baseTemp + (Math.random() - 0.5) * 30;
      const randWind = Math.random() * 45;

      const speed_mps = 60 / 3.6;
      const stoppingDist = (speed_mps * 0.55) + (speed_mps * speed_mps) / (2 * randMu * 9.81);
      const energy_kwh = 16.5 + (randWind * 0.08) + (randTemp < 5 ? (5 - randTemp) * 0.35 : 0);
      const maxBattTemp = 24 + (energy_kwh * 0.45);
      const collision = stoppingDist > 38.0;

      results.push({
        runId: i,
        muFriction: +randMu.toFixed(3),
        ambientTemp_C: +randTemp.toFixed(1),
        windSpeed_kmh: +randWind.toFixed(1),
        stoppingDistance_m: +stoppingDist.toFixed(1),
        energyConsumption_kWh100km: +energy_kwh.toFixed(1),
        maxBatteryTemp_C: +maxBattTemp.toFixed(1),
        collisionDetected: collision
      });
    }

    this.monteCarloRuns.set(results);
    this.addAudit('Safety Analyst', 'MONTE_CARLO_RUN', 'Analytics Lab', `Executed ${iterations} stochastic scenario runs.`);
  }

  addAudit(userRole: AuditRecord['userRole'], action: string, targetModule: string, details: string) {
    const newLog: AuditRecord = {
      id: `AUD-${Math.floor(100 + Math.random() * 900)}`,
      timestamp: new Date().toLocaleTimeString(),
      userRole,
      action,
      targetModule,
      details
    };
    this.auditLogs.update(logs => [newLog, ...logs]);
  }

  private generateInitialFleet(): FleetVehicleSummary[] {
    const cities = [
      { name: 'Gothenburg, SE (Torslanda HQ)', lat: 57.7089, lng: 11.9746 },
      { name: 'Stockholm, SE', lat: 59.3293, lng: 18.0686 },
      { name: 'London, UK (Heathrow Hub)', lat: 51.5074, lng: -0.1278 },
      { name: 'Oslo, NO', lat: 59.9139, lng: 10.7522 },
      { name: 'Copenhagen, DK', lat: 55.6761, lng: 12.5683 },
      { name: 'Munich, DE', lat: 48.1351, lng: 11.5820 },
      { name: 'Kiruna, SE (Winter Proving Ground)', lat: 67.8558, lng: 20.2253 }
    ];

    const models = ['ex60', 'ex90', 'ex30', 'es90', 'ex40', 'ec40', 'xc60-phev', 'xc90-phev', 'v60-phev', 'v90-phev'];
    const modelNames: Record<string, string> = {
      'ex60': 'EX60 Twin Motor AWD',
      'ex90': 'EX90 Ultra AWD (LiDAR)',
      'ex30': 'EX30 Twin Motor Performance',
      'es90': 'ES90 Twin Motor Executive',
      'ex40': 'EX40 Ultra AWD',
      'ec40': 'EC40 Fastback AWD',
      'xc60-phev': 'XC60 T8 Plug-in Hybrid',
      'xc90-phev': 'XC90 T8 Plug-in Hybrid',
      'v60-phev': 'V60 T8 Plug-in Hybrid Estate',
      'v90-phev': 'V90 T8 Plug-in Hybrid Ultimate'
    };

    const fleet: FleetVehicleSummary[] = [];
    for (let i = 1; i <= 36; i++) {
      const city = cities[i % cities.length];
      const modelId = models[i % models.length];
      const statuses: FleetVehicleSummary['operatingStatus'][] = ['Driving', 'Charging', 'Idle', 'Maintenance', 'Driving'];
      const status = statuses[i % statuses.length];

      fleet.push({
        simVin: `SIM-VIN-YV1-${modelId.toUpperCase().slice(0, 4)}-${2026}-${String(1000 + i).padStart(5, '0')}`,
        modelId,
        modelName: modelNames[modelId] || 'Volvo Vehicle',
        locationCity: city.name,
        latitude: +(city.lat + (Math.random() - 0.5) * 0.35).toFixed(4),
        longitude: +(city.lng + (Math.random() - 0.5) * 0.35).toFixed(4),
        soc_percent: Math.floor(25 + Math.random() * 70),
        odometer_km: Math.floor(1200 + Math.random() * 45000),
        speed_kmh: status === 'Driving' ? Math.floor(35 + Math.random() * 85) : 0,
        batteryHealth_percent: +(97.5 + Math.random() * 2.4).toFixed(1),
        brakePadWear_percent: +(10 + Math.random() * 25).toFixed(1),
        tyrePressure_bar: +(2.4 + (Math.random() - 0.5) * 0.2).toFixed(2),
        operatingStatus: status,
        softwareVersion: i % 4 === 0 ? 'v4.1.2 (Needs OTA)' : 'v4.2.0-RC3',
        alerts: i % 8 === 0 ? ['Tyre Pressure -0.2 bar', 'Scheduled Service in 1,200 km'] : []
      });
    }

    return fleet;
  }
}
