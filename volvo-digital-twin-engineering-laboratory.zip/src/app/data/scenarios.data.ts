import { RoadSurfaceType, WeatherType } from '../models/physics.models';

export interface PredefinedScenario {
  id: string;
  name: string;
  description: string;
  category: 'Safety & ADAS' | 'Range & Energy' | 'Dynamics & Chassis' | 'Extreme Weather' | 'Fleet & Highway';
  recommendedVehicleId: string;
  roadType: 'Highway' | 'Urban' | 'Rural' | 'Mountain' | 'Winter Testing Track';
  surfaceType: RoadSurfaceType;
  weather: WeatherType;
  ambientTemp_C: number;
  initialSpeed_kmh: number;
  initialSoc_percent: number;
  trafficDensity: number; // 0..1
  obstacles: {
    type: 'Pedestrian' | 'Vehicle' | 'Cyclist' | 'Large Animal' | 'Road Barrier';
    spawnTime_s: number;
    initialDistance_m: number;
    lateralOffset_m: number;
    speed_kmh: number;
    behavior: 'Crossing' | 'Sudden Braking' | 'Cut-in' | 'Stationary';
  }[];
  duration_s: number;
}

export const PREDEFINED_SCENARIOS: PredefinedScenario[] = [
  {
    id: 'scen-aeb-pedestrian-crossing',
    name: 'City Safety: Unobstructed Pedestrian Night Crossing',
    description: 'Autonomous Emergency Braking (AEB) evaluation with pedestrian stepping onto roadway at 50 km/h in night rain condition. Validates LiDAR + Optical camera fusion trigger time.',
    category: 'Safety & ADAS',
    recommendedVehicleId: 'ex90',
    roadType: 'Urban',
    surfaceType: 'Wet Asphalt',
    weather: 'Night',
    ambientTemp_C: 8,
    initialSpeed_kmh: 50,
    initialSoc_percent: 75,
    trafficDensity: 0.2,
    obstacles: [
      {
        type: 'Pedestrian',
        spawnTime_s: 2.0,
        initialDistance_m: 38,
        lateralOffset_m: 3.2,
        speed_kmh: 5.0,
        behavior: 'Crossing',
      }
    ],
    duration_s: 15,
  },
  {
    id: 'scen-lead-vehicle-hard-brake',
    name: 'Euro NCAP: Lead Vehicle Sudden Deceleration (1.0g)',
    description: 'Lead commercial vehicle applies maximum emergency braking at 100 km/h on motorway. Tests Adaptive Cruise Control (ACC) & Forward Collision Warning (FCW) staged handoff.',
    category: 'Safety & ADAS',
    recommendedVehicleId: 'ex60',
    roadType: 'Highway',
    surfaceType: 'Dry Asphalt',
    weather: 'Clear',
    ambientTemp_C: 20,
    initialSpeed_kmh: 100,
    initialSoc_percent: 82,
    trafficDensity: 0.5,
    obstacles: [
      {
        type: 'Vehicle',
        spawnTime_s: 1.5,
        initialDistance_m: 55,
        lateralOffset_m: 0.0,
        speed_kmh: 95,
        behavior: 'Sudden Braking',
      }
    ],
    duration_s: 20,
  },
  {
    id: 'scen-winter-ice-handling',
    name: 'Kiruna Winter Proving Ground: Low-Mu Ice Split-μ Handling',
    description: 'Split-friction surface (ice on left wheels μ=0.15, packed snow on right wheels μ=0.30). Tests Electronic Stability Control (ESC), torque vectoring, and dual-motor slip regulation.',
    category: 'Dynamics & Chassis',
    recommendedVehicleId: 'ex60',
    roadType: 'Winter Testing Track',
    surfaceType: 'Ice',
    ambientTemp_C: -18,
    weather: 'Snow',
    initialSpeed_kmh: 60,
    initialSoc_percent: 65,
    trafficDensity: 0.0,
    obstacles: [],
    duration_s: 25,
  },
  {
    id: 'scen-mountain-regen-gradient',
    name: 'Alpine Pass: High-Gradient Energy Harvesting & Thermal Load',
    description: 'Long descent on a -10% mountain grade. Evaluates high-power regenerative braking capacity (up to 180 kW), battery thermal jacket rejection, and friction brake preservation.',
    category: 'Range & Energy',
    recommendedVehicleId: 'ex60',
    roadType: 'Mountain',
    surfaceType: 'Dry Asphalt',
    ambientTemp_C: 12,
    weather: 'Cloudy',
    initialSpeed_kmh: 70,
    initialSoc_percent: 45,
    trafficDensity: 0.15,
    obstacles: [],
    duration_s: 40,
  },
  {
    id: 'scen-gothenburg-stockholm-wltp',
    name: 'E4 Motorway Highway: Gothenburg to Stockholm WLTP Efficiency',
    description: 'Standard 120 km/h cruising evaluation over realistic rolling terrain with 5 m/s headwind. Simulates auxiliary HVAC loads, aerodynamic drag losses, and arrival SOC estimation.',
    category: 'Range & Energy',
    recommendedVehicleId: 'es90',
    roadType: 'Highway',
    surfaceType: 'Dry Asphalt',
    ambientTemp_C: 15,
    weather: 'Clear',
    initialSpeed_kmh: 120,
    initialSoc_percent: 90,
    trafficDensity: 0.4,
    obstacles: [],
    duration_s: 60,
  },
  {
    id: 'scen-phev-hybrid-energy-split',
    name: 'XC60 PHEV: Pure EV to Parallel Hybrid Mode Dynamic Transition',
    description: 'Urban-to-Highway drive cycle. Validates 2.0L turbocharged engine start, ERAD electric rear axle drive coordination, and 8-speed transmission power blending.',
    category: 'Range & Energy',
    recommendedVehicleId: 'xc60-phev',
    roadType: 'Rural',
    surfaceType: 'Dry Asphalt',
    ambientTemp_C: 18,
    weather: 'Clear',
    initialSpeed_kmh: 40,
    initialSoc_percent: 30,
    trafficDensity: 0.3,
    obstacles: [],
    duration_s: 30,
  }
];
