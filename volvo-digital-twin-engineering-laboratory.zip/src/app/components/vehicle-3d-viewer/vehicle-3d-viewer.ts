import {
  Component,
  ElementRef,
  ViewChild,
  OnDestroy,
  AfterViewInit,
  inject,
  signal,
  ChangeDetectionStrategy,
  effect,
  PLATFORM_ID
} from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import * as THREE from 'three';
import { SimulationEngineService } from '../../services/simulation-engine.service';
import { AdasLabService } from '../../services/adas-lab.service';
import { VolvoVehicleModel } from '../../models/vehicle.models';

export type ViewportMode = 'Full Exterior' | 'Powertrain X-Ray' | 'Battery Pack' | 'Sensor Frustums' | 'Aero Flow';

@Component({
  selector: 'app-vehicle-3d-viewer',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-full min-h-[480px] bg-[#0c1017] rounded-xl overflow-hidden border border-slate-800 flex flex-col select-none">
      <!-- 3D Canvas Container -->
      <div #canvasContainer class="relative flex-1 w-full h-full cursor-grab active:cursor-grabbing"></div>

      <!-- Top Overlay: Vehicle Badge & Model ID -->
      <div class="absolute top-3 left-3 z-10 flex items-center gap-2 bg-slate-900/85 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-700/60 shadow-lg pointer-events-auto">
        <div class="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></div>
        <div>
          <div class="text-xs font-mono font-semibold tracking-wider text-slate-200 uppercase">
            {{ simEngine.selectedVehicle().modelName }}
          </div>
          <div class="text-[10px] text-slate-400 font-mono">
            CAD TWIN • {{ simEngine.selectedVehicle().platform }} • {{ simEngine.selectedVehicle().powertrainType }}
          </div>
        </div>
      </div>

      <!-- Top Right: Viewport Layers Selector -->
      <div class="absolute top-3 right-3 z-10 flex items-center gap-1.5 bg-slate-900/90 backdrop-blur-md p-1 rounded-lg border border-slate-700/60 shadow-lg pointer-events-auto">
        @for (mode of viewportModes; track mode) {
          <button
            (click)="setViewportMode(mode)"
            [class.bg-slate-700]="activeMode() === mode"
            [class.text-white]="activeMode() === mode"
            [class.text-slate-400]="activeMode() !== mode"
            class="px-2.5 py-1 text-[11px] font-mono rounded hover:text-slate-200 transition-colors flex items-center gap-1"
          >
            @if (mode === 'Full Exterior') { <mat-icon class="!text-[14px] !w-3.5 !h-3.5">directions_car</mat-icon> }
            @if (mode === 'Powertrain X-Ray') { <mat-icon class="!text-[14px] !w-3.5 !h-3.5">electric_bolt</mat-icon> }
            @if (mode === 'Battery Pack') { <mat-icon class="!text-[14px] !w-3.5 !h-3.5">battery_charging_full</mat-icon> }
            @if (mode === 'Sensor Frustums') { <mat-icon class="!text-[14px] !w-3.5 !h-3.5">sensors</mat-icon> }
            @if (mode === 'Aero Flow') { <mat-icon class="!text-[14px] !w-3.5 !h-3.5">air</mat-icon> }
            <span>{{ mode }}</span>
          </button>
        }
      </div>

      <!-- Bottom Overlay: Camera Preset Buttons & Overlay Info -->
      <div class="absolute bottom-3 left-3 right-3 z-10 flex items-center justify-between pointer-events-none">
        <!-- Camera Angles -->
        <div class="flex items-center gap-1.5 bg-slate-900/85 backdrop-blur-md p-1 rounded-lg border border-slate-700/60 shadow-lg pointer-events-auto">
          <button (click)="setCameraPreset('iso')" class="px-2 py-1 text-[10px] font-mono text-slate-300 hover:bg-slate-800 rounded">ISO 3/4</button>
          <button (click)="setCameraPreset('side')" class="px-2 py-1 text-[10px] font-mono text-slate-300 hover:bg-slate-800 rounded">PROFILE</button>
          <button (click)="setCameraPreset('top')" class="px-2 py-1 text-[10px] font-mono text-slate-300 hover:bg-slate-800 rounded">TOP</button>
          <button (click)="setCameraPreset('front')" class="px-2 py-1 text-[10px] font-mono text-slate-300 hover:bg-slate-800 rounded">FRONT</button>
          <button (click)="setCameraPreset('sensor')" class="px-2 py-1 text-[10px] font-mono text-slate-300 hover:bg-slate-800 rounded">LIDAR ROOF</button>
        </div>

        <!-- Live Dynamics Mini Readout in 3D -->
        <div class="flex items-center gap-3 bg-slate-900/85 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-700/60 shadow-lg text-[11px] font-mono text-slate-300 pointer-events-auto">
          <div class="flex items-center gap-1">
            <span class="text-slate-500">SPEED:</span>
            <span class="font-bold text-emerald-400">{{ simEngine.currentState().speed_kmh }} km/h</span>
          </div>
          <div class="flex items-center gap-1">
            <span class="text-slate-500">STEER:</span>
            <span>{{ simEngine.currentState().steeringWheelAngle_deg.toFixed(1) }}°</span>
          </div>
          <div class="flex items-center gap-1">
            <span class="text-slate-500">LAT ACCEL:</span>
            <span>{{ simEngine.currentState().lateralAcceleration_mps2.toFixed(2) }} m/s²</span>
          </div>
          <div class="flex items-center gap-1">
            <span class="text-slate-500">BATT:</span>
            <span class="text-sky-400">{{ simEngine.currentState().batteryTemp_C }}°C</span>
          </div>
        </div>
      </div>
    </div>
  `
})
export class Vehicle3dViewer implements AfterViewInit, OnDestroy {
  @ViewChild('canvasContainer', { static: true }) canvasContainerRef!: ElementRef<HTMLDivElement>;

  readonly simEngine = inject(SimulationEngineService);
  readonly adasLab = inject(AdasLabService);
  readonly platformId = inject(PLATFORM_ID);

  readonly viewportModes: ViewportMode[] = [
    'Full Exterior',
    'Powertrain X-Ray',
    'Battery Pack',
    'Sensor Frustums',
    'Aero Flow'
  ];
  readonly activeMode = signal<ViewportMode>('Full Exterior');

  // Three.js State
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animId: number | null = null;
  private resizeObserver: ResizeObserver | null = null;

  // Scene Objects
  private vehicleGroup!: THREE.Group;
  private bodyMesh!: THREE.Mesh;
  private glassMesh!: THREE.Mesh;
  private batteryPackGroup!: THREE.Group;
  private motorFrontGroup!: THREE.Group;
  private motorRearGroup!: THREE.Group;
  private wheelMeshes: THREE.Group[] = [];
  private brakeCalipers: THREE.Mesh[] = [];
  private lidarHousing!: THREE.Group;
  private sensorFrustumsGroup!: THREE.Group;
  private aeroFlowGroup!: THREE.Group;
  private pointCloudParticles!: THREE.Points;
  private gridHelper!: THREE.GridHelper;

  // Mouse Orbit Controls (Native implementation for stability)
  private isDragging = false;
  private previousMousePosition = { x: 0, y: 0 };
  private cameraTarget = new THREE.Vector3(0, 0.6, 0);
  private spherical = { radius: 7.2, theta: Math.PI / 4, phi: Math.PI / 3 };

  constructor() {
    // Re-build 3D twin when vehicle model changes
    effect(() => {
      const v = this.simEngine.selectedVehicle();
      if (this.scene) {
        this.buildVehicleDigitalTwin(v);
      }
    });

    // Update visibility layers on mode switch
    effect(() => {
      const mode = this.activeMode();
      this.updateViewportLayers(mode);
    });
  }

  ngAfterViewInit() {
    if (!isPlatformBrowser(this.platformId)) return;
    this.initThreeScene();
    this.setupEventListeners();
    this.startRenderLoop();
  }

  ngOnDestroy() {
    if (!isPlatformBrowser(this.platformId)) return;
    if (this.animId !== null) cancelAnimationFrame(this.animId);
    if (this.resizeObserver) this.resizeObserver.disconnect();
    if (this.renderer) this.renderer.dispose();
  }

  setViewportMode(mode: ViewportMode) {
    this.activeMode.set(mode);
  }

  setCameraPreset(preset: 'iso' | 'side' | 'top' | 'front' | 'sensor') {
    switch (preset) {
      case 'iso':
        this.spherical.radius = 7.0;
        this.spherical.theta = Math.PI / 4;
        this.spherical.phi = Math.PI / 3;
        break;
      case 'side':
        this.spherical.radius = 6.5;
        this.spherical.theta = Math.PI / 2;
        this.spherical.phi = Math.PI / 2.1;
        break;
      case 'top':
        this.spherical.radius = 8.0;
        this.spherical.theta = 0;
        this.spherical.phi = 0.05;
        break;
      case 'front':
        this.spherical.radius = 6.0;
        this.spherical.theta = 0;
        this.spherical.phi = Math.PI / 2.1;
        break;
      case 'sensor':
        this.spherical.radius = 4.0;
        this.spherical.theta = Math.PI / 6;
        this.spherical.phi = Math.PI / 4;
        break;
    }
    this.updateCameraFromSpherical();
  }

  private initThreeScene() {
    const container = this.canvasContainerRef.nativeElement;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 500;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0c1017);
    this.scene.fog = new THREE.FogExp2(0x0c1017, 0.035);

    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    this.updateCameraFromSpherical();

    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(this.renderer.domElement);

    // Studio Lighting setup
    const ambientLight = new THREE.AmbientLight(0xdbe4f0, 0.7);
    this.scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xffffff, 1.4);
    keyLight.position.set(6, 12, 8);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.width = 2048;
    keyLight.shadow.mapSize.height = 2048;
    this.scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x38bdf8, 0.8);
    rimLight.position.set(-8, 6, -8);
    this.scene.add(rimLight);

    const underglowLight = new THREE.DirectionalLight(0x10b981, 0.3);
    underglowLight.position.set(0, -4, 0);
    this.scene.add(underglowLight);

    // Technical Ground Grid & Proving Ground Markings
    this.gridHelper = new THREE.GridHelper(40, 40, 0x334155, 0x1e293b);
    this.gridHelper.position.y = -0.01;
    this.scene.add(this.gridHelper);

    // Initial Vehicle Build
    this.buildVehicleDigitalTwin(this.simEngine.selectedVehicle());

    // Resize Observer
    this.resizeObserver = new ResizeObserver(entries => {
      for (const entry of entries) {
        const w = entry.contentRect.width;
        const h = entry.contentRect.height;
        if (w > 0 && h > 0) {
          this.camera.aspect = w / h;
          this.camera.updateProjectionMatrix();
          this.renderer.setSize(w, h);
        }
      }
    });
    this.resizeObserver.observe(container);
  }

  private buildVehicleDigitalTwin(vehicle: VolvoVehicleModel) {
    if (this.vehicleGroup) {
      this.scene.remove(this.vehicleGroup);
    }

    this.vehicleGroup = new THREE.Group();
    this.wheelMeshes = [];
    this.brakeCalipers = [];

    const length_m = vehicle.dimensions.length_mm.value / 1000;
    const width_m = vehicle.dimensions.width_mm.value / 1000;
    const height_m = vehicle.dimensions.height_mm.value / 1000;
    const wheelbase_m = vehicle.dimensions.wheelbase_mm.value / 1000;

    // 1. Vehicle Body Sculpted Mesh (Scandinavian Minimalist Silhouette)
    const bodyGeometry = new THREE.BoxGeometry(width_m * 0.92, height_m * 0.58, length_m * 0.94);
    const bodyMaterial = new THREE.MeshPhysicalMaterial({
      color: 0x94a3b8, // Volvo Vapor Grey / Crystal White tone
      metalness: 0.85,
      roughness: 0.22,
      clearcoat: 1.0,
      clearcoatRoughness: 0.1
    });
    this.bodyMesh = new THREE.Mesh(bodyGeometry, bodyMaterial);
    this.bodyMesh.position.y = height_m * 0.45;
    this.bodyMesh.castShadow = true;
    this.bodyMesh.receiveShadow = true;
    this.vehicleGroup.add(this.bodyMesh);

    // 2. Panoramic Glass Canopy & Greenhouse
    const glassGeometry = new THREE.BoxGeometry(width_m * 0.82, height_m * 0.42, length_m * 0.55);
    const glassMaterial = new THREE.MeshPhysicalMaterial({
      color: 0x0f172a,
      metalness: 0.1,
      roughness: 0.05,
      transmission: 0.85,
      transparent: true,
      opacity: 0.88,
      ior: 1.52
    });
    this.glassMesh = new THREE.Mesh(glassGeometry, glassMaterial);
    this.glassMesh.position.set(0, height_m * 0.82, -length_m * 0.04);
    this.vehicleGroup.add(this.glassMesh);

    // 3. Thor's Hammer LED Headlights (Volvo Signature)
    const headlightMaterial = new THREE.MeshBasicMaterial({ color: 0xecfeff });
    const headlightGeo = new THREE.BoxGeometry(0.28, 0.06, 0.05);
    
    const hlLeft = new THREE.Mesh(headlightGeo, headlightMaterial);
    hlLeft.position.set(-width_m * 0.38, height_m * 0.45, length_m * 0.47);
    this.vehicleGroup.add(hlLeft);

    const hlRight = new THREE.Mesh(headlightGeo, headlightMaterial);
    hlRight.position.set(width_m * 0.38, height_m * 0.45, length_m * 0.47);
    this.vehicleGroup.add(hlRight);

    // Vertical T-crossbar of Thor's Hammer
    const tGeo = new THREE.BoxGeometry(0.05, 0.14, 0.05);
    const tLeft = new THREE.Mesh(tGeo, headlightMaterial);
    tLeft.position.set(-width_m * 0.38, height_m * 0.45, length_m * 0.47);
    this.vehicleGroup.add(tLeft);
    const tRight = new THREE.Mesh(tGeo, headlightMaterial);
    tRight.position.set(width_m * 0.38, height_m * 0.45, length_m * 0.47);
    this.vehicleGroup.add(tRight);

    // 4. Volvo Iconic Vertical Taillights
    const tailMaterial = new THREE.MeshBasicMaterial({ color: 0xef4444 });
    const tailGeo = new THREE.BoxGeometry(0.08, height_m * 0.5, 0.05);
    const tailLeft = new THREE.Mesh(tailGeo, tailMaterial);
    tailLeft.position.set(-width_m * 0.42, height_m * 0.58, -length_m * 0.47);
    this.vehicleGroup.add(tailLeft);
    const tailRight = new THREE.Mesh(tailGeo, tailMaterial);
    tailRight.position.set(width_m * 0.42, height_m * 0.58, -length_m * 0.47);
    this.vehicleGroup.add(tailRight);

    // 5. High-Voltage Battery Pack Enclosure (Underbody Skate)
    this.batteryPackGroup = new THREE.Group();
    const battEnclosureGeo = new THREE.BoxGeometry(width_m * 0.86, 0.16, wheelbase_m * 0.78);
    const battMat = new THREE.MeshStandardMaterial({
      color: 0x0284c7, // Structural blue
      metalness: 0.9,
      roughness: 0.3,
      wireframe: false
    });
    const battMesh = new THREE.Mesh(battEnclosureGeo, battMat);
    battMesh.position.set(0, 0.18, 0);
    this.batteryPackGroup.add(battMesh);

    // 12 Battery Cell Modules visualization inside pack
    const moduleMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, roughness: 0.4 });
    for (let r = 0; r < 6; r++) {
      for (let c = 0; c < 2; c++) {
        const modGeo = new THREE.BoxGeometry(0.55, 0.11, 0.28);
        const modMesh = new THREE.Mesh(modGeo, moduleMat);
        modMesh.position.set(c === 0 ? -0.36 : 0.36, 0.19, (r - 2.5) * 0.35);
        this.batteryPackGroup.add(modMesh);
      }
    }
    this.vehicleGroup.add(this.batteryPackGroup);

    // 6. Front & Rear Electric Motors (or Hybrid Axle)
    const motorMat = new THREE.MeshStandardMaterial({ color: 0x10b981, metalness: 0.8, roughness: 0.3 });
    const motorGeo = new THREE.CylinderGeometry(0.18, 0.18, 0.45, 24);
    motorGeo.rotateZ(Math.PI / 2);

    this.motorFrontGroup = new THREE.Group();
    const frontMotorMesh = new THREE.Mesh(motorGeo, motorMat);
    this.motorFrontGroup.position.set(0, 0.35, wheelbase_m / 2);
    this.motorFrontGroup.add(frontMotorMesh);
    this.vehicleGroup.add(this.motorFrontGroup);

    this.motorRearGroup = new THREE.Group();
    const rearMotorMesh = new THREE.Mesh(motorGeo, motorMat);
    this.motorRearGroup.position.set(0, 0.35, -wheelbase_m / 2);
    this.motorRearGroup.add(rearMotorMesh);
    this.vehicleGroup.add(this.motorRearGroup);

    // 7. Wheels, Alloy Rims, & Brake Discs (4 corners: FL, FR, RL, RR)
    const tyreRadius = 0.36;
    const tyreWidth = 0.24;
    const halfTrack = (vehicle.dimensions.trackFront_mm.value / 1000) / 2;
    const halfWheelbase = wheelbase_m / 2;

    const wheelPositions = [
      { x: -halfTrack, z: halfWheelbase, isFront: true },  // Front Left
      { x: halfTrack, z: halfWheelbase, isFront: true },   // Front Right
      { x: -halfTrack, z: -halfWheelbase, isFront: false }, // Rear Left
      { x: halfTrack, z: -halfWheelbase, isFront: false }   // Rear Right
    ];

    const tyreGeo = new THREE.CylinderGeometry(tyreRadius, tyreRadius, tyreWidth, 32);
    tyreGeo.rotateZ(Math.PI / 2);
    const tyreMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.85 });

    const rimGeo = new THREE.CylinderGeometry(tyreRadius * 0.65, tyreRadius * 0.65, tyreWidth + 0.01, 16);
    rimGeo.rotateZ(Math.PI / 2);
    const rimMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.9, roughness: 0.15 });

    const discGeo = new THREE.CylinderGeometry(0.18, 0.18, 0.04, 24);
    discGeo.rotateZ(Math.PI / 2);
    const discMat = new THREE.MeshStandardMaterial({ color: 0xd1d5db, metalness: 0.95, roughness: 0.2 });

    const caliperGeo = new THREE.BoxGeometry(0.08, 0.12, 0.12);
    const caliperMat = new THREE.MeshStandardMaterial({ color: 0xe11d48 }); // Red performance caliper

    wheelPositions.forEach(pos => {
      const wheelAssembly = new THREE.Group();
      wheelAssembly.position.set(pos.x, tyreRadius, pos.z);

      const tyre = new THREE.Mesh(tyreGeo, tyreMat);
      const rim = new THREE.Mesh(rimGeo, rimMat);
      const disc = new THREE.Mesh(discGeo, discMat);
      const caliper = new THREE.Mesh(caliperGeo, caliperMat);
      caliper.position.set(pos.x < 0 ? 0.08 : -0.08, 0.1, 0);

      wheelAssembly.add(tyre);
      wheelAssembly.add(rim);
      wheelAssembly.add(disc);
      wheelAssembly.add(caliper);

      this.wheelMeshes.push(wheelAssembly);
      this.brakeCalipers.push(caliper);
      this.vehicleGroup.add(wheelAssembly);
    });

    // 8. Roof LiDAR Sensor Pod (Luminar Iris Integration on EX90/EX60)
    this.lidarHousing = new THREE.Group();
    const lidarGeo = new THREE.BoxGeometry(0.38, 0.09, 0.22);
    const lidarMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, metalness: 0.8, roughness: 0.2 });
    const lidarMesh = new THREE.Mesh(lidarGeo, lidarMat);
    this.lidarHousing.position.set(0, height_m * 1.04, length_m * 0.15);
    this.lidarHousing.add(lidarMesh);

    // Laser optical aperture glow
    const apertureGeo = new THREE.BoxGeometry(0.32, 0.03, 0.02);
    const apertureMat = new THREE.MeshBasicMaterial({ color: 0x06b6d4 });
    const apertureMesh = new THREE.Mesh(apertureGeo, apertureMat);
    apertureMesh.position.set(0, 0, 0.11);
    this.lidarHousing.add(apertureMesh);

    this.vehicleGroup.add(this.lidarHousing);

    // 9. Sensor Frustum & Cones Group
    this.sensorFrustumsGroup = new THREE.Group();

    // LiDAR forward 120-deg FOV cone
    const lidarConeGeo = new THREE.ConeGeometry(8, 25, 32, 1, true);
    lidarConeGeo.rotateX(-Math.PI / 2);
    const lidarConeMat = new THREE.MeshBasicMaterial({
      color: 0x06b6d4,
      transparent: true,
      opacity: 0.18,
      wireframe: true
    });
    const lidarCone = new THREE.Mesh(lidarConeGeo, lidarConeMat);
    lidarCone.position.set(0, height_m * 1.04, length_m * 0.15 + 12.5);
    this.sensorFrustumsGroup.add(lidarCone);

    // Forward 77GHz Radar Cone (long range 250m narrow angle)
    const radarConeGeo = new THREE.ConeGeometry(5, 35, 16, 1, true);
    radarConeGeo.rotateX(-Math.PI / 2);
    const radarConeMat = new THREE.MeshBasicMaterial({
      color: 0x10b981,
      transparent: true,
      opacity: 0.14,
      wireframe: true
    });
    const radarCone = new THREE.Mesh(radarConeGeo, radarConeMat);
    radarCone.position.set(0, height_m * 0.35, length_m * 0.5 + 17.5);
    this.sensorFrustumsGroup.add(radarCone);

    this.vehicleGroup.add(this.sensorFrustumsGroup);

    // 10. Aerodynamic Airflow Streamlines
    this.aeroFlowGroup = new THREE.Group();
    const streamCount = 20;
    for (let i = 0; i < streamCount; i++) {
      const curve = new THREE.CatmullRomCurve3([
        new THREE.Vector3((i - 10) * 0.18, height_m * 0.5 + (Math.sin(i) * 0.2), length_m * 0.8),
        new THREE.Vector3((i - 10) * 0.19, height_m * 0.9 + (Math.sin(i) * 0.1), length_m * 0.2),
        new THREE.Vector3((i - 10) * 0.20, height_m * 1.05, -length_m * 0.1),
        new THREE.Vector3((i - 10) * 0.21, height_m * 0.7, -length_m * 0.7),
        new THREE.Vector3((i - 10) * 0.22, height_m * 0.4, -length_m * 1.2)
      ]);
      const tubeGeo = new THREE.TubeGeometry(curve, 32, 0.012, 8, false);
      const tubeMat = new THREE.MeshBasicMaterial({
        color: 0x38bdf8,
        transparent: true,
        opacity: 0.45
      });
      const tubeMesh = new THREE.Mesh(tubeGeo, tubeMat);
      this.aeroFlowGroup.add(tubeMesh);
    }
    this.vehicleGroup.add(this.aeroFlowGroup);

    // 11. LiDAR Point Cloud Dynamic Particle Buffer
    const pointCloudGeo = new THREE.BufferGeometry();
    const maxPoints = 1200;
    const positions = new Float32Array(maxPoints * 3);
    const colors = new Float32Array(maxPoints * 3);
    pointCloudGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    pointCloudGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const pointCloudMat = new THREE.PointsMaterial({
      size: 0.08,
      vertexColors: true,
      transparent: true,
      opacity: 0.85
    });
    this.pointCloudParticles = new THREE.Points(pointCloudGeo, pointCloudMat);
    this.scene.add(this.pointCloudParticles);

    this.scene.add(this.vehicleGroup);
    this.updateViewportLayers(this.activeMode());
  }

  private updateViewportLayers(mode: ViewportMode) {
    if (!this.bodyMesh) return;

    switch (mode) {
      case 'Full Exterior':
        (this.bodyMesh.material as THREE.MeshStandardMaterial).wireframe = false;
        (this.bodyMesh.material as THREE.MeshStandardMaterial).opacity = 1.0;
        (this.bodyMesh.material as THREE.MeshStandardMaterial).transparent = false;
        this.batteryPackGroup.visible = false;
        this.motorFrontGroup.visible = false;
        this.motorRearGroup.visible = false;
        this.sensorFrustumsGroup.visible = false;
        this.aeroFlowGroup.visible = false;
        break;

      case 'Powertrain X-Ray':
        (this.bodyMesh.material as THREE.MeshStandardMaterial).wireframe = true;
        (this.bodyMesh.material as THREE.MeshStandardMaterial).opacity = 0.18;
        (this.bodyMesh.material as THREE.MeshStandardMaterial).transparent = true;
        this.batteryPackGroup.visible = true;
        this.motorFrontGroup.visible = true;
        this.motorRearGroup.visible = true;
        this.sensorFrustumsGroup.visible = false;
        this.aeroFlowGroup.visible = false;
        break;

      case 'Battery Pack':
        (this.bodyMesh.material as THREE.MeshStandardMaterial).wireframe = false;
        (this.bodyMesh.material as THREE.MeshStandardMaterial).opacity = 0.08;
        (this.bodyMesh.material as THREE.MeshStandardMaterial).transparent = true;
        this.batteryPackGroup.visible = true;
        this.motorFrontGroup.visible = true;
        this.motorRearGroup.visible = true;
        this.sensorFrustumsGroup.visible = false;
        this.aeroFlowGroup.visible = false;
        break;

      case 'Sensor Frustums':
        (this.bodyMesh.material as THREE.MeshStandardMaterial).wireframe = false;
        (this.bodyMesh.material as THREE.MeshStandardMaterial).opacity = 0.65;
        (this.bodyMesh.material as THREE.MeshStandardMaterial).transparent = true;
        this.batteryPackGroup.visible = false;
        this.motorFrontGroup.visible = false;
        this.motorRearGroup.visible = false;
        this.sensorFrustumsGroup.visible = true;
        this.aeroFlowGroup.visible = false;
        break;

      case 'Aero Flow':
        (this.bodyMesh.material as THREE.MeshStandardMaterial).wireframe = false;
        (this.bodyMesh.material as THREE.MeshStandardMaterial).opacity = 0.75;
        (this.bodyMesh.material as THREE.MeshStandardMaterial).transparent = true;
        this.batteryPackGroup.visible = false;
        this.motorFrontGroup.visible = false;
        this.motorRearGroup.visible = false;
        this.sensorFrustumsGroup.visible = false;
        this.aeroFlowGroup.visible = true;
        break;
    }
  }

  private startRenderLoop() {
    const render = () => {
      this.animId = requestAnimationFrame(render);
      this.updatePhysicsVisuals();
      this.renderer.render(this.scene, this.camera);
    };
    render();
  }

  private updatePhysicsVisuals() {
    const state = this.simEngine.currentState();

    if (this.vehicleGroup) {
      // 1. Vehicle pitch & roll from chassis dynamics
      this.vehicleGroup.rotation.x = state.pitch;
      this.vehicleGroup.rotation.z = -state.roll;

      // 2. Front wheel steering angle (FL, FR)
      const steer_rad = state.steeringAngle_rad;
      if (this.wheelMeshes.length >= 4) {
        this.wheelMeshes[0].rotation.y = steer_rad;
        this.wheelMeshes[1].rotation.y = steer_rad;

        // Wheel rotation proportional to velocity
        const wheelRotSpeed = (state.velocity / 0.36) * 0.016;
        this.wheelMeshes.forEach(w => {
          w.children[0].rotation.x += wheelRotSpeed;
          w.children[1].rotation.x += wheelRotSpeed;
          w.children[2].rotation.x += wheelRotSpeed;
        });

        // 3. Dynamic Suspension Travel Compression
        this.wheelMeshes[0].position.y = 0.36 + (state.suspensionCompression_mm[0] / 1000);
        this.wheelMeshes[1].position.y = 0.36 + (state.suspensionCompression_mm[1] / 1000);
        this.wheelMeshes[2].position.y = 0.36 + (state.suspensionCompression_mm[2] / 1000);
        this.wheelMeshes[3].position.y = 0.36 + (state.suspensionCompression_mm[3] / 1000);
      }

      // 4. Ground grid movement simulation (gives sense of continuous driving speed)
      if (this.gridHelper && state.velocity > 0.1) {
        this.gridHelper.position.z = (this.gridHelper.position.z - state.velocity * 0.016) % 1.0;
      }

      // 5. Dynamic LiDAR Point Cloud Ingestion from ADAS Lab
      const pts = this.adasLab.lidarPoints();
      if (this.pointCloudParticles && pts.length > 0) {
        const geo = this.pointCloudParticles.geometry as THREE.BufferGeometry;
        const posAttr = geo.getAttribute('position') as THREE.BufferAttribute;
        const colAttr = geo.getAttribute('color') as THREE.BufferAttribute;
        const positions = posAttr.array as Float32Array;
        const colors = colAttr.array as Float32Array;

        const count = Math.min(pts.length, 1200);
        for (let i = 0; i < count; i++) {
          const pt = pts[i];
          positions[i * 3] = pt.y; // lateral
          positions[i * 3 + 1] = pt.z + 0.45; // height
          positions[i * 3 + 2] = pt.x + 2.0; // longitudinal ahead

          // Intensity based color gradient (cyan to bright green)
          const normIntensity = pt.intensity / 255;
          colors[i * 3] = 0.06;
          colors[i * 3 + 1] = normIntensity;
          colors[i * 3 + 2] = 0.9;
        }
        posAttr.needsUpdate = true;
        colAttr.needsUpdate = true;
      }
    }
  }

  private setupEventListeners() {
    const el = this.canvasContainerRef.nativeElement;

    el.addEventListener('mousedown', (e) => {
      this.isDragging = true;
      this.previousMousePosition = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener('mouseup', () => {
      this.isDragging = false;
    });

    window.addEventListener('mousemove', (e) => {
      if (!this.isDragging) return;
      const deltaX = e.clientX - this.previousMousePosition.x;
      const deltaY = e.clientY - this.previousMousePosition.y;

      this.spherical.theta -= deltaX * 0.008;
      this.spherical.phi = Math.max(0.05, Math.min(Math.PI / 2 - 0.02, this.spherical.phi - deltaY * 0.008));

      this.updateCameraFromSpherical();
      this.previousMousePosition = { x: e.clientX, y: e.clientY };
    });

    el.addEventListener('wheel', (e) => {
      e.preventDefault();
      this.spherical.radius = Math.max(2.5, Math.min(18.0, this.spherical.radius + e.deltaY * 0.006));
      this.updateCameraFromSpherical();
    }, { passive: false });
  }

  private updateCameraFromSpherical() {
    const x = this.spherical.radius * Math.sin(this.spherical.phi) * Math.sin(this.spherical.theta);
    const y = this.spherical.radius * Math.cos(this.spherical.phi);
    const z = this.spherical.radius * Math.sin(this.spherical.phi) * Math.cos(this.spherical.theta);

    this.camera.position.set(x, y, z);
    this.camera.lookAt(this.cameraTarget);
  }
}
