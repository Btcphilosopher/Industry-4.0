import { Component, inject, ChangeDetectionStrategy, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FleetManufacturingService } from '../../../services/fleet-manufacturing.service';

@Component({
  selector: 'app-monte-carlo-lab',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-4 text-xs font-mono">
      <!-- Left Panel: Parameter Sensitivity Analysis (Tornado Matrix) -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col gap-3 shadow-md">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <div class="flex items-center gap-1.5 font-semibold text-slate-200">
            <mat-icon class="!text-base !w-4 !h-4 text-cyan-400">analytics</mat-icon>
            <span>PARAMETER SENSITIVITY MATRIX</span>
          </div>
          <span class="text-[10px] text-cyan-400">Tornado Analysis</span>
        </div>

        <!-- Sensitivity Items -->
        <div class="space-y-2.5">
          @for (item of fleetService.sensitivityAnalysis(); track item.parameter) {
            <div class="bg-slate-950 p-2 rounded-lg border border-slate-800 space-y-1">
              <div class="flex justify-between items-center">
                <span class="font-bold text-slate-200">{{ item.parameter }}</span>
                <span class="text-slate-400 text-[10px]">{{ item.baseline }} ({{ item.deltaPercent }})</span>
              </div>

              <!-- Bar visual of range impact -->
              <div class="flex items-center gap-2 text-[10px]">
                <span class="text-slate-500 w-14">Range:</span>
                <div class="flex-1 bg-slate-800 h-1.5 rounded-full overflow-hidden flex">
                  <div
                    [class.bg-rose-500]="item.impactOnRange < 0"
                    [class.bg-emerald-500]="item.impactOnRange > 0"
                    class="h-full"
                    [style.width.%]="Math.abs(item.impactOnRange) * 3"
                  ></div>
                </div>
                <span
                  [class.text-rose-400]="item.impactOnRange < 0"
                  [class.text-emerald-400]="item.impactOnRange > 0"
                  class="font-bold w-12 text-right"
                >
                  {{ item.impactOnRange > 0 ? '+' : '' }}{{ item.impactOnRange }}%
                </span>
              </div>

              <!-- Bar visual of braking impact -->
              <div class="flex items-center gap-2 text-[10px]">
                <span class="text-slate-500 w-14">Braking:</span>
                <div class="flex-1 bg-slate-800 h-1.5 rounded-full overflow-hidden flex">
                  <div
                    [class.bg-amber-500]="item.impactOnBraking > 0"
                    [class.bg-emerald-500]="item.impactOnBraking <= 0"
                    class="h-full"
                    [style.width.%]="Math.abs(item.impactOnBraking) * 3"
                  ></div>
                </div>
                <span class="text-slate-300 w-12 text-right">
                  {{ item.impactOnBraking > 0 ? '+' : '' }}{{ item.impactOnBraking }}%
                </span>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Center & Right Panel: Stochastic Monte Carlo Simulation Suite -->
      <div class="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col gap-3 shadow-md">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <div class="flex items-center gap-1.5 font-semibold text-slate-200">
            <mat-icon class="!text-base !w-4 !h-4 text-emerald-400">casino</mat-icon>
            <span>MONTE CARLO STOCHASTIC SAFETY & RANGE BATCH RUNNER</span>
          </div>
          <div class="flex items-center gap-2">
            <button
              (click)="fleetService.runMonteCarloBatch(100)"
              class="px-3 py-1 bg-emerald-700 hover:bg-emerald-600 text-white rounded font-bold text-xs flex items-center gap-1 shadow-sm transition-colors"
            >
              <mat-icon class="!text-sm !w-4 !h-4">play_arrow</mat-icon>
              <span>RUN 100 ITERATIONS</span>
            </button>
            <button
              (click)="fleetService.runMonteCarloBatch(500)"
              class="px-3 py-1 bg-indigo-700 hover:bg-indigo-600 text-white rounded font-bold text-xs flex items-center gap-1 shadow-sm transition-colors"
            >
              <mat-icon class="!text-sm !w-4 !h-4">fast_forward</mat-icon>
              <span>RUN 500 ITERATIONS</span>
            </button>
          </div>
        </div>

        <!-- Statistical Outcome Metrics Cards -->
        @if (fleetService.monteCarloRuns().length > 0) {
          <div class="grid grid-cols-4 gap-3">
            <div class="bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-center">
              <div class="text-[9px] text-slate-500 uppercase">BATCH SIZE</div>
              <div class="text-lg font-bold text-slate-100">{{ fleetService.monteCarloRuns().length }} Runs</div>
            </div>
            <div class="bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-center">
              <div class="text-[9px] text-slate-500 uppercase">MEAN STOPPING DIST</div>
              <div class="text-lg font-bold text-cyan-400">{{ meanStoppingDist() }} m</div>
            </div>
            <div class="bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-center">
              <div class="text-[9px] text-slate-500 uppercase">COLLISION PROBABILITY</div>
              <div
                [class.text-emerald-400]="collisionRate() < 5"
                [class.text-rose-400]="collisionRate() >= 5"
                class="text-lg font-bold"
              >
                {{ collisionRate() }}%
              </div>
            </div>
            <div class="bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-center">
              <div class="text-[9px] text-slate-500 uppercase">MEAN CONSUMPTION</div>
              <div class="text-lg font-bold text-emerald-400">{{ meanEnergy() }} kWh/100</div>
            </div>
          </div>

          <!-- Iterations Data Table -->
          <div class="bg-slate-950 rounded-lg border border-slate-800 max-h-[260px] overflow-y-auto scrollbar-thin">
            <table class="w-full text-left text-[11px]">
              <thead class="bg-slate-900 text-slate-400 sticky top-0 border-b border-slate-800">
                <tr>
                  <th class="p-2">RUN #</th>
                  <th class="p-2">SURFACE μ</th>
                  <th class="p-2">TEMP (°C)</th>
                  <th class="p-2">WIND (km/h)</th>
                  <th class="p-2">STOP DIST (m)</th>
                  <th class="p-2">CONSUMPTION</th>
                  <th class="p-2">OUTCOME</th>
                </tr>
              </thead>
              <tbody>
                @for (run of fleetService.monteCarloRuns().slice(0, 50); track run.runId) {
                  <tr class="border-b border-slate-900 hover:bg-slate-900/50 transition-colors">
                    <td class="p-2 text-slate-400">#{{ run.runId }}</td>
                    <td class="p-2 text-cyan-300">{{ run.muFriction }}</td>
                    <td class="p-2 text-slate-300">{{ run.ambientTemp_C }}°C</td>
                    <td class="p-2 text-slate-300">{{ run.windSpeed_kmh }}</td>
                    <td class="p-2 font-bold text-slate-100">{{ run.stoppingDistance_m }}m</td>
                    <td class="p-2 text-emerald-400">{{ run.energyConsumption_kWh100km }}</td>
                    <td class="p-2 font-bold" [class.text-emerald-400]="!run.collisionDetected" [class.text-rose-400]="run.collisionDetected">
                      {{ run.collisionDetected ? 'COLLISION' : 'AVOIDED' }}
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        } @else {
          <div class="flex-1 flex flex-col items-center justify-center p-8 text-center text-slate-500 bg-slate-950 rounded-lg border border-slate-800">
            <mat-icon class="!text-3xl !w-8 !h-8 text-slate-600 mb-2">science</mat-icon>
            <p>No batch runs executed yet. Click above to run 100 or 500 stochastic simulation runs across varied friction, wind, and temperatures.</p>
          </div>
        }
      </div>
    </div>
  `
})
export class MonteCarloLab {
  readonly fleetService = inject(FleetManufacturingService);
  readonly Math = Math;

  readonly meanStoppingDist = computed(() => {
    const runs = this.fleetService.monteCarloRuns();
    if (runs.length === 0) return 0;
    const sum = runs.reduce((acc, r) => acc + r.stoppingDistance_m, 0);
    return +(sum / runs.length).toFixed(1);
  });

  readonly collisionRate = computed(() => {
    const runs = this.fleetService.monteCarloRuns();
    if (runs.length === 0) return 0;
    const hits = runs.filter(r => r.collisionDetected).length;
    return +((hits / runs.length) * 100).toFixed(1);
  });

  readonly meanEnergy = computed(() => {
    const runs = this.fleetService.monteCarloRuns();
    if (runs.length === 0) return 0;
    const sum = runs.reduce((acc, r) => acc + r.energyConsumption_kWh100km, 0);
    return +(sum / runs.length).toFixed(1);
  });
}
