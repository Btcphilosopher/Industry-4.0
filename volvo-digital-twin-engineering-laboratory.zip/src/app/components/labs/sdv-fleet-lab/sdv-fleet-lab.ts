import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FleetManufacturingService } from '../../../services/fleet-manufacturing.service';

@Component({
  selector: 'app-sdv-fleet-lab',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-4 text-xs font-mono">
      <!-- Left Panel: SDV Architecture & Dual-Partition OTA Rollout -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col gap-3 shadow-md">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <div class="flex items-center gap-1.5 font-semibold text-slate-200">
            <mat-icon class="!text-base !w-4 !h-4 text-cyan-400">memory</mat-icon>
            <span>SDV CENTRAL COMPUTE & OTA MANAGER</span>
          </div>
          <span class="text-[10px] text-cyan-400">SPA3 Core OS</span>
        </div>

        <!-- ECU / Central Compute DAG Nodes -->
        <div class="space-y-1.5">
          @for (node of fleetService.softwareNodes(); track node.id) {
            <div class="p-2 rounded bg-slate-950 border border-slate-800 flex justify-between items-center text-[11px]">
              <div>
                <div class="font-bold text-slate-200">{{ node.name }}</div>
                <div class="text-[9px] text-slate-500 font-mono">
                  FW: {{ node.firmwareVersion }} • CPU: {{ node.cpuLoadPercent }}% • BUS: {{ node.busUtilizationPercent }}%
                </div>
              </div>
              <span class="px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 text-[9px] font-bold">
                {{ node.healthStatus }}
              </span>
            </div>
          }
        </div>

        <!-- Staged OTA Rollout Simulator -->
        <div class="bg-slate-950 p-2.5 rounded-lg border border-slate-800 space-y-2">
          <div class="flex justify-between items-center">
            <span class="font-bold text-slate-200">STAGED OTA PACKAGE</span>
            <span class="text-[10px] text-cyan-400">{{ fleetService.otaStage() }}</span>
          </div>
          <div class="text-[10px] text-slate-400">
            {{ fleetService.availableOta().version }} ({{ fleetService.availableOta().packageSizeMb }} MB)
          </div>
          <div class="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
            <div
              class="bg-cyan-500 h-full transition-all duration-300"
              [style.width.%]="fleetService.otaProgressPercent()"
            ></div>
          </div>
          <button
            (click)="fleetService.triggerOtaRollout()"
            [disabled]="fleetService.otaStage() !== 'Idle'"
            class="w-full py-1.5 bg-cyan-700 hover:bg-cyan-600 disabled:opacity-50 text-white rounded text-xs font-bold transition-colors"
          >
            TRIGGER DUAL-BANK OTA UPDATE
          </button>
        </div>
      </div>

      <!-- Center Panel: Connected Fleet Digital Twin (36 Active Vehicles) -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col gap-3 shadow-md">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <div class="flex items-center gap-1.5 font-semibold text-slate-200">
            <mat-icon class="!text-base !w-4 !h-4 text-emerald-400">hub</mat-icon>
            <span>EUROPE CONNECTED FLEET TELEMETRY</span>
          </div>
          <span class="text-[10px] text-emerald-400">{{ fleetService.fleetVehicles().length }} Connected</span>
        </div>

        <!-- Fleet Grid -->
        <div class="space-y-1.5 max-h-[380px] overflow-y-auto scrollbar-thin pr-1">
          @for (veh of fleetService.fleetVehicles(); track veh.simVin) {
            <div class="bg-slate-950 p-2 rounded border border-slate-800 flex flex-col gap-1 text-[10px]">
              <div class="flex justify-between items-center">
                <span class="font-bold text-slate-200">{{ veh.modelName }}</span>
                <span
                  [class.text-emerald-400]="veh.operatingStatus === 'Driving'"
                  [class.text-cyan-400]="veh.operatingStatus === 'Charging'"
                  [class.text-slate-400]="veh.operatingStatus === 'Idle'"
                  class="font-bold uppercase"
                >
                  {{ veh.operatingStatus }}
                </span>
              </div>
              <div class="flex justify-between text-slate-400 text-[9px]">
                <span>{{ veh.locationCity }}</span>
                <span>SOC: <strong class="text-slate-200">{{ veh.soc_percent }}%</strong></span>
                <span>Health: <strong class="text-slate-200">{{ veh.batteryHealth_percent }}%</strong></span>
                <span>{{ veh.softwareVersion }}</span>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Right Panel: Torslanda / Ghent Manufacturing Plant Digital Twin -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col gap-3 shadow-md">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <div class="flex items-center gap-1.5 font-semibold text-slate-200">
            <mat-icon class="!text-base !w-4 !h-4 text-amber-400">precision_manufacturing</mat-icon>
            <span>FACTORY ASSEMBLY TWIN (TORSLANDA)</span>
          </div>
          <span class="text-[10px] text-amber-400">Quality Gates</span>
        </div>

        <!-- Assembly Line Stations -->
        <div class="space-y-2">
          @for (stage of fleetService.manufacturingStages(); track stage.id) {
            <div class="bg-slate-950 p-2 rounded-lg border border-slate-800 space-y-1 text-[10px]">
              <div class="flex justify-between items-center">
                <span class="font-bold text-slate-200">{{ stage.id }}. {{ stage.name }}</span>
                <span class="text-emerald-400 font-bold">{{ stage.passRatePercent }}% Yield</span>
              </div>
              <div class="text-[9px] text-slate-400">{{ stage.description }}</div>
              <div class="flex justify-between text-[9px] text-slate-500 pt-0.5 border-t border-slate-900">
                <span>Cycle: {{ stage.cycleTimeSeconds }}s</span>
                <span class="font-mono text-cyan-400">{{ stage.currentVin }}</span>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class SdvFleetLab {
  readonly fleetService = inject(FleetManufacturingService);
}
