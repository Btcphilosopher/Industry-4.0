import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationEngineService } from '../../../services/simulation-engine.service';

@Component({
  selector: 'app-powertrain-battery-lab',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-4 text-xs font-mono">
      <!-- Left Panel: 12-Cell High-Voltage Battery Module Heatmap & Cell Spread -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col gap-3 shadow-md">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <div class="flex items-center gap-1.5 font-semibold text-slate-200">
            <mat-icon class="!text-base !w-4 !h-4 text-cyan-400">battery_charging_full</mat-icon>
            <span>HV PACK THERMAL SENSORS & CELL SPREAD</span>
          </div>
          <span class="text-[10px] text-slate-400">12 Modules</span>
        </div>

        <!-- 12 Cell Thermal Grid -->
        <div class="grid grid-cols-4 gap-2 py-2">
          @for (temp of simEngine.currentState().cellTemperatures_C; track $index) {
            <div
              [class.bg-sky-950]="temp < 25"
              [class.border-sky-800]="temp < 25"
              [class.bg-emerald-950]="temp >= 25 && temp < 35"
              [class.border-emerald-800]="temp >= 25 && temp < 35"
              [class.bg-amber-950]="temp >= 35 && temp < 45"
              [class.border-amber-800]="temp >= 35 && temp < 45"
              [class.bg-rose-950]="temp >= 45"
              [class.border-rose-800]="temp >= 45"
              class="p-2 rounded-lg border flex flex-col items-center justify-center transition-colors"
            >
              <span class="text-[9px] text-slate-400">MOD #{{ $index + 1 }}</span>
              <span class="text-xs font-bold text-slate-100">{{ temp }}°C</span>
              <span class="text-[9px] text-slate-400">{{ simEngine.currentState().cellVoltages_V[$index] || 3.82 }}V</span>
            </div>
          }
        </div>

        <!-- Battery Pack Health & Delta Metrics -->
        <div class="grid grid-cols-3 gap-2 text-center text-[11px] bg-slate-950 p-2.5 rounded-lg border border-slate-800">
          <div>
            <div class="text-[9px] text-slate-500">MAX CELL</div>
            <div class="text-amber-400 font-bold">{{ simEngine.currentState().batteryMaxCellTemp_C }}°C</div>
          </div>
          <div>
            <div class="text-[9px] text-slate-500">MIN CELL</div>
            <div class="text-sky-400 font-bold">{{ simEngine.currentState().batteryMinCellTemp_C }}°C</div>
          </div>
          <div>
            <div class="text-[9px] text-slate-500">SPREAD ΔT</div>
            <div class="text-slate-200 font-bold">
              {{ (simEngine.currentState().batteryMaxCellTemp_C - simEngine.currentState().batteryMinCellTemp_C).toFixed(1) }}°C
            </div>
          </div>
        </div>

        <!-- Fault Injection -->
        <div class="flex items-center justify-between p-2 bg-slate-950/80 rounded border border-slate-800">
          <span class="text-slate-400 text-[11px]">Inject Battery Thermal Runaway</span>
          <button
            (click)="simEngine.toggleComponentFailure('batteryThermalSpike')"
            [class.bg-rose-600]="simEngine.componentFailures().batteryThermalSpike"
            [class.bg-slate-800]="!simEngine.componentFailures().batteryThermalSpike"
            class="px-2.5 py-1 text-[10px] text-white rounded font-bold transition-colors"
          >
            {{ simEngine.componentFailures().batteryThermalSpike ? 'ACTIVE FAULT' : 'INJECT' }}
          </button>
        </div>
      </div>

      <!-- Center Panel: Dual Electric Motor & Powertrain Electrification -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col gap-3 shadow-md">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <div class="flex items-center gap-1.5 font-semibold text-slate-200">
            <mat-icon class="!text-base !w-4 !h-4 text-emerald-400">bolt</mat-icon>
            <span>POWERTRAIN & DUAL-MOTOR TORQUE</span>
          </div>
          <span class="text-[10px] text-emerald-400">SiC Inverter</span>
        </div>

        <!-- Motor Torque Split (Front vs Rear e-Axle) -->
        <div class="grid grid-cols-2 gap-3 py-1">
          <!-- Front e-Motor -->
          <div class="bg-slate-950 p-2.5 rounded-lg border border-slate-800 flex flex-col gap-1">
            <div class="text-[10px] text-slate-400 uppercase font-bold">FRONT AXLE MOTOR</div>
            <div class="text-sm font-bold text-emerald-400">
              {{ (simEngine.currentState().motorPower_kW * 0.45).toFixed(1) }} kW
            </div>
            <div class="text-[10px] text-slate-400">
              Torque: {{ (simEngine.currentState().motorTorque_Nm * 0.45).toFixed(0) }} Nm
            </div>
            <div class="text-[10px] text-slate-400">
              RPM: {{ simEngine.currentState().motorRpm }}
            </div>
          </div>

          <!-- Rear e-Motor -->
          <div class="bg-slate-950 p-2.5 rounded-lg border border-slate-800 flex flex-col gap-1">
            <div class="text-[10px] text-slate-400 uppercase font-bold">REAR AXLE MOTOR</div>
            <div class="text-sm font-bold text-emerald-400">
              {{ (simEngine.currentState().motorPower_kW * 0.55).toFixed(1) }} kW
            </div>
            <div class="text-[10px] text-slate-400">
              Torque: {{ (simEngine.currentState().motorTorque_Nm * 0.55).toFixed(0) }} Nm
            </div>
            <div class="text-[10px] text-slate-400">
              RPM: {{ simEngine.currentState().motorRpm }}
            </div>
          </div>
        </div>

        <!-- Inverter & Pack Electrical State -->
        <div class="space-y-2 bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-[11px]">
          <div class="flex justify-between">
            <span class="text-slate-400">Pack Voltage:</span>
            <span class="text-slate-100 font-bold">{{ simEngine.currentState().batteryVoltage_V }} V</span>
          </div>
          <div class="flex justify-between">
            <span class="text-slate-400">Pack Current (I):</span>
            <span class="text-slate-100 font-bold">{{ simEngine.currentState().batteryCurrent_A }} A</span>
          </div>
          <div class="flex justify-between">
            <span class="text-slate-400">Regenerative Recovery:</span>
            <span class="text-cyan-400 font-bold">{{ simEngine.currentState().regenPower_kW }} kW</span>
          </div>
          <div class="flex justify-between">
            <span class="text-slate-400">Instant Consumption:</span>
            <span class="text-emerald-400 font-bold">{{ simEngine.currentState().instantaneousConsumption_kWhPer100km }} kWh/100km</span>
          </div>
        </div>

        <!-- Motor Derate Fault -->
        <div class="flex items-center justify-between p-2 bg-slate-950/80 rounded border border-slate-800">
          <span class="text-slate-400 text-[11px]">Inject Motor Thermal Derate (50%)</span>
          <button
            (click)="simEngine.toggleComponentFailure('motorDerate')"
            [class.bg-amber-600]="simEngine.componentFailures().motorDerate"
            [class.bg-slate-800]="!simEngine.componentFailures().motorDerate"
            class="px-2.5 py-1 text-[10px] text-white rounded font-bold transition-colors"
          >
            {{ simEngine.componentFailures().motorDerate ? 'DERATED' : 'INJECT' }}
          </button>
        </div>
      </div>

      <!-- Right Panel: Thermal Management & HVAC Heat Pump -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col gap-3 shadow-md">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <div class="flex items-center gap-1.5 font-semibold text-slate-200">
            <mat-icon class="!text-base !w-4 !h-4 text-sky-400">device_thermostat</mat-icon>
            <span>THERMAL SYSTEM & CABIN HVAC</span>
          </div>
          <span class="text-[10px] text-sky-400">Heat Pump</span>
        </div>

        <div class="space-y-2.5">
          <!-- Cabin Temp -->
          <div class="bg-slate-950 p-2.5 rounded-lg border border-slate-800 flex justify-between items-center">
            <div>
              <div class="text-[10px] text-slate-500 uppercase">CABIN INTERIOR TEMP</div>
              <div class="text-base font-bold text-slate-100">{{ simEngine.currentState().cabinTemp_C }}°C</div>
            </div>
            <div class="text-right">
              <div class="text-[10px] text-slate-500 uppercase">TARGET</div>
              <div class="text-base font-bold text-cyan-400">{{ simEngine.currentState().cabinTargetTemp_C }}°C</div>
            </div>
          </div>

          <!-- Heat Pump Compressor Load -->
          <div class="bg-slate-950 p-2.5 rounded-lg border border-slate-800 space-y-1.5">
            <div class="flex justify-between text-[11px]">
              <span class="text-slate-400">HVAC Heat Pump Power</span>
              <span class="text-cyan-300 font-bold">{{ simEngine.currentState().hvacPower_kW }} kW</span>
            </div>
            <div class="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div
                class="bg-sky-500 h-full transition-all"
                [style.width.%]="(simEngine.currentState().hvacPower_kW / 4.0) * 100"
              ></div>
            </div>
          </div>

          <!-- Ambient vs Pack Cooling Loop -->
          <div class="bg-slate-950 p-2.5 rounded-lg border border-slate-800 space-y-1 text-[11px]">
            <div class="flex justify-between">
              <span class="text-slate-400">Outside Ambient:</span>
              <span class="text-slate-200">{{ simEngine.currentState().outsideTemp_C }}°C</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Coolant Loop Inlet:</span>
              <span class="text-slate-200">{{ simEngine.currentState().batteryCoolantTemp_C }}°C</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Solar Radiation:</span>
              <span class="text-amber-300">{{ simEngine.currentState().solarRadiation_Wpm2 }} W/m²</span>
            </div>
          </div>
        </div>

        <!-- Rapid DC Charging Simulator Button -->
        <button
          (click)="triggerFastCharge()"
          class="w-full py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white rounded-lg font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all"
        >
          <mat-icon class="!text-sm !w-4 !h-4">ev_station</mat-icon>
          <span>TEST 800V DC ULTRA-FAST CHARGE (10% to 80%)</span>
        </button>
      </div>
    </div>
  `
})
export class PowertrainBatteryLab {
  readonly simEngine = inject(SimulationEngineService);

  triggerFastCharge() {
    this.simEngine.pauseSimulation();
    this.simEngine.currentState.update(s => ({
      ...s,
      chargingState: 'DC Fast Charging',
      batterySoc: 10,
      batteryCurrent_A: 420,
      batteryTemp_C: 32.5
    }));

    let progress = 10;
    const interval = setInterval(() => {
      progress += 5;
      if (progress >= 80) {
        clearInterval(interval);
        this.simEngine.currentState.update(s => ({
          ...s,
          chargingState: 'Complete',
          batterySoc: 80,
          batteryCurrent_A: 0
        }));
      } else {
        this.simEngine.currentState.update(s => ({
          ...s,
          batterySoc: progress,
          batteryTemp_C: +(32.5 + (progress - 10) * 0.12).toFixed(1)
        }));
      }
    }, 150);
  }
}
