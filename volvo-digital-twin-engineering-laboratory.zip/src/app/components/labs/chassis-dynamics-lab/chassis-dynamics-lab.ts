import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationEngineService } from '../../../services/simulation-engine.service';

@Component({
  selector: 'app-chassis-dynamics-lab',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-4 text-xs font-mono">
      <!-- Left Panel: 4-Corner Wheel Loads & Suspension Travel -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col gap-3 shadow-md">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <div class="flex items-center gap-1.5 font-semibold text-slate-200">
            <mat-icon class="!text-base !w-4 !h-4 text-cyan-400">tune</mat-icon>
            <span>4-CORNER WHEEL LOADS & DAMPING</span>
          </div>
          <span class="text-[10px] text-slate-400">100Hz Real-Time</span>
        </div>

        <!-- 4-Wheel Schematic Layout -->
        <div class="grid grid-cols-2 gap-3 py-2">
          <!-- Front Left -->
          <div class="bg-slate-950 p-2.5 rounded-lg border border-slate-800 flex flex-col gap-1">
            <div class="flex justify-between text-[10px] text-slate-400">
              <span class="font-bold text-slate-300">FRONT LEFT (FL)</span>
              <span class="text-cyan-400">{{ simEngine.currentState().suspensionCompression_mm[0] }} mm</span>
            </div>
            <div class="text-sm font-bold text-slate-100">
              {{ simEngine.currentState().wheelVerticalLoads_N[0] }} N
            </div>
            <div class="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div
                class="bg-cyan-500 h-full transition-all"
                [style.width.%]="(simEngine.currentState().wheelVerticalLoads_N[0] / 9000) * 100"
              ></div>
            </div>
            <div class="flex justify-between text-[9px] text-slate-400 mt-1">
              <span>Brake Disc:</span>
              <span class="text-amber-400">{{ simEngine.currentState().brakeDiscTemps_C[0] }}°C</span>
            </div>
          </div>

          <!-- Front Right -->
          <div class="bg-slate-950 p-2.5 rounded-lg border border-slate-800 flex flex-col gap-1">
            <div class="flex justify-between text-[10px] text-slate-400">
              <span class="font-bold text-slate-300">FRONT RIGHT (FR)</span>
              <span class="text-cyan-400">{{ simEngine.currentState().suspensionCompression_mm[1] }} mm</span>
            </div>
            <div class="text-sm font-bold text-slate-100">
              {{ simEngine.currentState().wheelVerticalLoads_N[1] }} N
            </div>
            <div class="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div
                class="bg-cyan-500 h-full transition-all"
                [style.width.%]="(simEngine.currentState().wheelVerticalLoads_N[1] / 9000) * 100"
              ></div>
            </div>
            <div class="flex justify-between text-[9px] text-slate-400 mt-1">
              <span>Brake Disc:</span>
              <span class="text-amber-400">{{ simEngine.currentState().brakeDiscTemps_C[1] }}°C</span>
            </div>
          </div>

          <!-- Rear Left -->
          <div class="bg-slate-950 p-2.5 rounded-lg border border-slate-800 flex flex-col gap-1">
            <div class="flex justify-between text-[10px] text-slate-400">
              <span class="font-bold text-slate-300">REAR LEFT (RL)</span>
              <span class="text-cyan-400">{{ simEngine.currentState().suspensionCompression_mm[2] }} mm</span>
            </div>
            <div class="text-sm font-bold text-slate-100">
              {{ simEngine.currentState().wheelVerticalLoads_N[2] }} N
            </div>
            <div class="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div
                class="bg-cyan-500 h-full transition-all"
                [style.width.%]="(simEngine.currentState().wheelVerticalLoads_N[2] / 9000) * 100"
              ></div>
            </div>
            <div class="flex justify-between text-[9px] text-slate-400 mt-1">
              <span>Brake Disc:</span>
              <span class="text-amber-400">{{ simEngine.currentState().brakeDiscTemps_C[2] }}°C</span>
            </div>
          </div>

          <!-- Rear Right -->
          <div class="bg-slate-950 p-2.5 rounded-lg border border-slate-800 flex flex-col gap-1">
            <div class="flex justify-between text-[10px] text-slate-400">
              <span class="font-bold text-slate-300">REAR RIGHT (RR)</span>
              <span class="text-cyan-400">{{ simEngine.currentState().suspensionCompression_mm[3] }} mm</span>
            </div>
            <div class="text-sm font-bold text-slate-100">
              {{ simEngine.currentState().wheelVerticalLoads_N[3] }} N
            </div>
            <div class="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div
                class="bg-cyan-500 h-full transition-all"
                [style.width.%]="(simEngine.currentState().wheelVerticalLoads_N[3] / 9000) * 100"
              ></div>
            </div>
            <div class="flex justify-between text-[9px] text-slate-400 mt-1">
              <span>Brake Disc:</span>
              <span class="text-amber-400">{{ simEngine.currentState().brakeDiscTemps_C[3] }}°C</span>
            </div>
          </div>
        </div>

        <div class="text-[11px] text-slate-400 bg-slate-950/60 p-2 rounded border border-slate-800">
          <div class="flex justify-between">
            <span>Anti-Roll Bar Stiffness:</span>
            <span class="text-slate-200">{{ simEngine.selectedVehicle().suspension.antiRollBarStiffness_Nmprad.value }} Nm/rad</span>
          </div>
          <div class="flex justify-between mt-1">
            <span>Front/Rear Weight Split:</span>
            <span class="text-slate-200">{{ simEngine.selectedVehicle().massDynamics.weightDistributionFrontPercent.value }}% / {{ 100 - simEngine.selectedVehicle().massDynamics.weightDistributionFrontPercent.value }}%</span>
          </div>
        </div>
      </div>

      <!-- Center Panel: G-G Friction Circle & Pacejka Tyre Slip -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col gap-3 shadow-md">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <div class="flex items-center gap-1.5 font-semibold text-slate-200">
            <mat-icon class="!text-base !w-4 !h-4 text-emerald-400">track_changes</mat-icon>
            <span>PACEJKA TYRE & G-G DIAGRAM</span>
          </div>
          <span class="text-[10px] text-emerald-400">μ = {{ simEngine.currentState().surfaceFrictionCoeff }}</span>
        </div>

        <!-- SVG G-G Friction Circle -->
        <div class="relative flex items-center justify-center p-2 bg-slate-950 rounded-lg border border-slate-800 h-44">
          <svg class="w-40 h-40" viewBox="-1.2 -1.2 2.4 2.4">
            <!-- 1.0g Limit Circle -->
            <circle cx="0" cy="0" [attr.r]="simEngine.currentState().surfaceFrictionCoeff" fill="none" stroke="#334155" stroke-width="0.04" stroke-dasharray="0.08" />
            <!-- 0.5g Limit Circle -->
            <circle cx="0" cy="0" [attr.r]="simEngine.currentState().surfaceFrictionCoeff * 0.5" fill="none" stroke="#1e293b" stroke-width="0.03" />
            
            <!-- Center Crosshairs -->
            <line x1="-1.2" y1="0" x2="1.2" y2="0" stroke="#334155" stroke-width="0.02" />
            <line x1="0" y1="-1.2" x2="0" y2="1.2" stroke="#334155" stroke-width="0.02" />

            <!-- Dynamic G-Force Point -->
            <circle
              [attr.cx]="(simEngine.currentState().lateralAcceleration_mps2 / 9.81)"
              [attr.cy]="-(simEngine.currentState().acceleration_mps2 / 9.81)"
              r="0.09"
              fill="#06b6d4"
              stroke="#ffffff"
              stroke-width="0.02"
            />
          </svg>

          <div class="absolute top-2 left-2 text-[10px] text-slate-500">
            LAT: {{ (simEngine.currentState().lateralAcceleration_mps2 / 9.81).toFixed(2) }}g
          </div>
          <div class="absolute bottom-2 right-2 text-[10px] text-slate-500">
            LONG: {{ (simEngine.currentState().acceleration_mps2 / 9.81).toFixed(2) }}g
          </div>
        </div>

        <div class="grid grid-cols-2 gap-2 text-[11px]">
          <div class="bg-slate-950 p-2 rounded border border-slate-800">
            <div class="text-[9px] text-slate-500">YAW RATE</div>
            <div class="text-slate-100 font-bold">{{ simEngine.currentState().yawRate_radps.toFixed(3) }} rad/s</div>
          </div>
          <div class="bg-slate-950 p-2 rounded border border-slate-800">
            <div class="text-[9px] text-slate-500">SIDESLIP ANGLE (β)</div>
            <div class="text-slate-100 font-bold">{{ (simEngine.currentState().sideslipAngle_rad * 180 / 3.14159).toFixed(2) }}°</div>
          </div>
        </div>
      </div>

      <!-- Right Panel: Driver Control Inputs & Actuators -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col gap-3 shadow-md">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <div class="flex items-center gap-1.5 font-semibold text-slate-200">
            <mat-icon class="!text-base !w-4 !h-4 text-indigo-400">sports_esports</mat-icon>
            <span>DYNAMICS INPUT STIMULATOR</span>
          </div>
        </div>

        <!-- Throttle Slider -->
        <div class="flex flex-col gap-1">
          <div class="flex justify-between text-[11px]">
            <span class="text-slate-400">THROTTLE DEMAND</span>
            <span class="text-emerald-400 font-bold">{{ (simEngine.currentState().throttleInput * 100).toFixed(0) }}%</span>
          </div>
          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            [value]="simEngine.currentState().throttleInput"
            (input)="onThrottleInput($event)"
            class="accent-emerald-500 bg-slate-950 h-2 rounded cursor-pointer"
          />
        </div>

        <!-- Brake Slider -->
        <div class="flex flex-col gap-1">
          <div class="flex justify-between text-[11px]">
            <span class="text-slate-400">BRAKE PEDAL (REGEN + HYDRAULIC)</span>
            <span class="text-rose-400 font-bold">{{ (simEngine.currentState().brakePedalInput * 100).toFixed(0) }}%</span>
          </div>
          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            [value]="simEngine.currentState().brakePedalInput"
            (input)="onBrakeInput($event)"
            class="accent-rose-500 bg-slate-950 h-2 rounded cursor-pointer"
          />
        </div>

        <!-- Steering Angle Slider -->
        <div class="flex flex-col gap-1">
          <div class="flex justify-between text-[11px]">
            <span class="text-slate-400">STEERING WHEEL</span>
            <span class="text-cyan-400 font-bold">{{ simEngine.currentState().steeringWheelAngle_deg.toFixed(0) }}°</span>
          </div>
          <input
            type="range"
            min="-0.5"
            max="0.5"
            step="0.02"
            [value]="simEngine.currentState().steeringAngle_rad"
            (input)="onSteerInput($event)"
            class="accent-cyan-500 bg-slate-950 h-2 rounded cursor-pointer"
          />
        </div>

        <!-- Quick Quick Test Maneuvers -->
        <div class="flex gap-2 pt-1">
          <button
            (click)="triggerMooseTest()"
            class="flex-1 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded border border-slate-700 text-[10px] font-semibold"
          >
            MOOSE TEST (72 km/h)
          </button>
          <button
            (click)="triggerEmergencyBrake()"
            class="flex-1 py-1.5 bg-rose-950/80 hover:bg-rose-900 text-rose-200 rounded border border-rose-800 text-[10px] font-semibold"
          >
            PANIC BRAKE (1.0g)
          </button>
        </div>
      </div>
    </div>
  `
})
export class ChassisDynamicsLab {
  readonly simEngine = inject(SimulationEngineService);

  onThrottleInput(e: Event) {
    const val = +(e.target as HTMLInputElement).value;
    this.simEngine.setInputs(val, this.simEngine.currentState().brakePedalInput, this.simEngine.currentState().steeringAngle_rad);
  }

  onBrakeInput(e: Event) {
    const val = +(e.target as HTMLInputElement).value;
    this.simEngine.setInputs(this.simEngine.currentState().throttleInput, val, this.simEngine.currentState().steeringAngle_rad);
  }

  onSteerInput(e: Event) {
    const val = +(e.target as HTMLInputElement).value;
    this.simEngine.setInputs(this.simEngine.currentState().throttleInput, this.simEngine.currentState().brakePedalInput, val);
  }

  triggerMooseTest() {
    this.simEngine.setInputs(0, 0, 0.35);
    setTimeout(() => this.simEngine.setInputs(0, 0, -0.35), 450);
    setTimeout(() => this.simEngine.setInputs(0, 0, 0), 900);
  }

  triggerEmergencyBrake() {
    this.simEngine.setInputs(0, 1.0, 0);
    setTimeout(() => this.simEngine.setInputs(0, 0, 0), 2000);
  }
}
