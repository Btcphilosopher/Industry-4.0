import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AdasLabService } from '../../../services/adas-lab.service';
import { SimulationEngineService } from '../../../services/simulation-engine.service';

@Component({
  selector: 'app-adas-perception-lab',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-4 text-xs font-mono">
      <!-- Left Panel: Raw Synthetic Sensor Streams (LiDAR, Radar, Camera) -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col gap-3 shadow-md">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <div class="flex items-center gap-1.5 font-semibold text-slate-200">
            <mat-icon class="!text-base !w-4 !h-4 text-cyan-400">sensors</mat-icon>
            <span>RAW SENSOR STREAMS</span>
          </div>
          <span class="text-[10px] text-cyan-400">Multi-Modal</span>
        </div>

        <!-- Sensor Health & Failure Toggles -->
        <div class="space-y-1.5">
          <!-- LiDAR Status -->
          <div class="flex items-center justify-between p-2 rounded bg-slate-950 border border-slate-800">
            <div class="flex items-center gap-2">
              <span
                class="w-2 h-2 rounded-full"
                [class.bg-cyan-400]="!adasLab.failureState().lidarDropout"
                [class.bg-rose-500]="adasLab.failureState().lidarDropout"
              ></span>
              <span class="text-slate-200">Luminar Iris LiDAR (1550nm)</span>
            </div>
            <button
              (click)="adasLab.toggleSensorFailure('lidarDropout')"
              [class.text-rose-400]="adasLab.failureState().lidarDropout"
              [class.text-slate-400]="!adasLab.failureState().lidarDropout"
              class="hover:underline text-[10px]"
            >
              {{ adasLab.failureState().lidarDropout ? 'FAIL ACTIVE' : 'INJECT FAULT' }}
            </button>
          </div>

          <!-- Radar Status -->
          <div class="flex items-center justify-between p-2 rounded bg-slate-950 border border-slate-800">
            <div class="flex items-center gap-2">
              <span
                class="w-2 h-2 rounded-full"
                [class.bg-emerald-400]="!adasLab.failureState().radarBlindness"
                [class.bg-rose-500]="adasLab.failureState().radarBlindness"
              ></span>
              <span class="text-slate-200">77GHz Front Radar Array</span>
            </div>
            <button
              (click)="adasLab.toggleSensorFailure('radarBlindness')"
              [class.text-rose-400]="adasLab.failureState().radarBlindness"
              [class.text-slate-400]="!adasLab.failureState().radarBlindness"
              class="hover:underline text-[10px]"
            >
              {{ adasLab.failureState().radarBlindness ? 'FAIL ACTIVE' : 'INJECT FAULT' }}
            </button>
          </div>

          <!-- Camera Status -->
          <div class="flex items-center justify-between p-2 rounded bg-slate-950 border border-slate-800">
            <div class="flex items-center gap-2">
              <span
                class="w-2 h-2 rounded-full"
                [class.bg-sky-400]="!adasLab.failureState().cameraLensOcclusion"
                [class.bg-rose-500]="adasLab.failureState().cameraLensOcclusion"
              ></span>
              <span class="text-slate-200">8MP Trifocal Optical Camera</span>
            </div>
            <button
              (click)="adasLab.toggleSensorFailure('cameraLensOcclusion')"
              [class.text-rose-400]="adasLab.failureState().cameraLensOcclusion"
              [class.text-slate-400]="!adasLab.failureState().cameraLensOcclusion"
              class="hover:underline text-[10px]"
            >
              {{ adasLab.failureState().cameraLensOcclusion ? 'FAIL ACTIVE' : 'INJECT FAULT' }}
            </button>
          </div>
        </div>

        <!-- Camera Bounding Box Visualizer -->
        <div class="bg-slate-950 p-2 rounded-lg border border-slate-800">
          <div class="text-[10px] text-slate-500 mb-1">OPTICAL VISION DETECTIONS (BBOX)</div>
          <div class="space-y-1">
            @for (cam of adasLab.cameraDetections(); track cam.id) {
              <div class="flex justify-between items-center text-[10px] bg-slate-900/80 p-1.5 rounded border border-slate-800">
                <span class="text-cyan-300 font-bold">[{{ cam.class }}]</span>
                <span class="text-slate-400">Dist: {{ cam.distanceEstimate_m }}m</span>
                <span class="text-slate-400">TTC: {{ cam.timeToCollision_s }}s</span>
                <span class="text-emerald-400 font-bold">{{ (cam.confidence * 100).toFixed(0) }}%</span>
              </div>
            }
          </div>
        </div>
      </div>

      <!-- Center Panel: Sensor Fusion & Active Safety Decision Engine -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col gap-3 shadow-md">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <div class="flex items-center gap-1.5 font-semibold text-slate-200">
            <mat-icon class="!text-base !w-4 !h-4 text-emerald-400">security</mat-icon>
            <span>VOLVO SAFE SPACE & FUSION ENGINE</span>
          </div>
          <span
            [class.text-emerald-400]="adasLab.adasStates().interventionLevel === 'Nominal'"
            [class.text-rose-400]="adasLab.adasStates().interventionLevel === 'Emergency Braking'"
            class="text-[10px] font-bold uppercase"
          >
            {{ adasLab.adasStates().interventionLevel }}
          </span>
        </div>

        <!-- ADAS Systems Status Matrix -->
        <div class="grid grid-cols-2 gap-2">
          <div class="bg-slate-950 p-2 rounded border border-slate-800 flex justify-between items-center">
            <span class="text-slate-400">AEB City Safety:</span>
            <span
              [class.text-emerald-400]="adasLab.adasStates().aebStatus === 'Active'"
              [class.text-rose-400]="adasLab.adasStates().aebStatus === 'Intervening'"
              class="font-bold"
            >
              {{ adasLab.adasStates().aebStatus }}
            </span>
          </div>

          <div class="bg-slate-950 p-2 rounded border border-slate-800 flex justify-between items-center">
            <span class="text-slate-400">Pilot Assist:</span>
            <span class="text-cyan-400 font-bold">{{ adasLab.adasStates().pilotAssistStatus }}</span>
          </div>

          <div class="bg-slate-950 p-2 rounded border border-slate-800 flex justify-between items-center">
            <span class="text-slate-400">Lane Centering:</span>
            <span class="text-emerald-400 font-bold">{{ adasLab.adasStates().laneKeepingStatus }}</span>
          </div>

          <div class="bg-slate-950 p-2 rounded border border-slate-800 flex justify-between items-center">
            <span class="text-slate-400">Target Decel:</span>
            <span class="text-rose-400 font-bold">{{ adasLab.adasStates().targetBrakeDeceleration_mps2 }} m/s²</span>
          </div>
        </div>

        <!-- Fused Kalman Tracks Table -->
        <div class="bg-slate-950 p-2 rounded-lg border border-slate-800">
          <div class="text-[10px] text-slate-500 mb-1">FUSED TRACK MATRIX (KALMAN FILTER)</div>
          <div class="space-y-1.5">
            @for (track of adasLab.fusedTracks(); track track.trackId) {
              <div
                [class.border-rose-700]="track.criticalThreat"
                [class.bg-rose-950]="track.criticalThreat"
                class="p-2 rounded border border-slate-800 flex flex-col gap-1 text-[10px]"
              >
                <div class="flex justify-between items-center">
                  <span class="font-bold text-slate-200">#{{ track.trackId }} {{ track.type }}</span>
                  <span class="text-cyan-400 font-bold">TTC: {{ track.timeToCollision_s }}s</span>
                </div>
                <div class="flex justify-between text-slate-400 text-[9px]">
                  <span>Range: {{ track.distance_m }}m</span>
                  <span>Sources: {{ track.fusionSources.join(' + ') }}</span>
                  <span class="text-emerald-400 font-bold">{{ (track.confidence * 100).toFixed(0) }}% Conf</span>
                </div>
              </div>
            }
          </div>
        </div>
      </div>

      <!-- Right Panel: Safety Reconstruction Sandbox & Parameter Variation Matrix -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col gap-3 shadow-md">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <div class="flex items-center gap-1.5 font-semibold text-slate-200">
            <mat-icon class="!text-base !w-4 !h-4 text-indigo-400">compare_arrows</mat-icon>
            <span>SCENARIO RECONSTRUCTION SANDBOX</span>
          </div>
        </div>

        <!-- Sandbox Param Variations -->
        <div class="space-y-2">
          <div>
            <div class="flex justify-between text-[11px] text-slate-400">
              <span>Road Friction μ:</span>
              <span class="text-cyan-300 font-bold">{{ adasLab.sandboxConfig().surfaceFrictionMu }}</span>
            </div>
            <input
              type="range"
              min="0.15"
              max="1.0"
              step="0.05"
              [value]="adasLab.sandboxConfig().surfaceFrictionMu"
              (input)="updateParam('surfaceFrictionMu', $event)"
              class="w-full accent-cyan-500 bg-slate-950 h-1.5 rounded cursor-pointer"
            />
          </div>

          <div>
            <div class="flex justify-between text-[11px] text-slate-400">
              <span>Driver Reaction Time:</span>
              <span class="text-cyan-300 font-bold">{{ adasLab.sandboxConfig().driverReactionTime_s }}s</span>
            </div>
            <input
              type="range"
              min="0.2"
              max="1.5"
              step="0.05"
              [value]="adasLab.sandboxConfig().driverReactionTime_s"
              (input)="updateParam('driverReactionTime_s', $event)"
              class="w-full accent-cyan-500 bg-slate-950 h-1.5 rounded cursor-pointer"
            />
          </div>

          <div>
            <div class="flex justify-between text-[11px] text-slate-400">
              <span>Sensor Processing Latency:</span>
              <span class="text-cyan-300 font-bold">{{ adasLab.sandboxConfig().sensorLatency_ms }}ms</span>
            </div>
            <input
              type="range"
              min="10"
              max="200"
              step="10"
              [value]="adasLab.sandboxConfig().sensorLatency_ms"
              (input)="updateParam('sensorLatency_ms', $event)"
              class="w-full accent-cyan-500 bg-slate-950 h-1.5 rounded cursor-pointer"
            />
          </div>
        </div>

        <button
          (click)="adasLab.runSafetyComparison()"
          class="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded font-bold text-xs flex items-center justify-center gap-1 transition-colors"
        >
          <mat-icon class="!text-sm !w-4 !h-4">science</mat-icon>
          <span>EVALUATE SAFETY RE-RUN</span>
        </button>

        <!-- Comparison Result Card -->
        @if (adasLab.comparisonHistory().length > 0) {
          <div class="bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-[10px] space-y-1">
            <div class="font-bold text-slate-200">{{ adasLab.comparisonHistory()[0].scenarioName }}</div>
            <div class="flex justify-between">
              <span class="text-slate-400">Modified Stopping Dist:</span>
              <span class="text-amber-400 font-bold">{{ adasLab.comparisonHistory()[0].modified.stoppingDistance_m }}m</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Impact Speed:</span>
              <span
                [class.text-emerald-400]="adasLab.comparisonHistory()[0].modified.impactSpeed_kmh === 0"
                [class.text-rose-400]="adasLab.comparisonHistory()[0].modified.impactSpeed_kmh > 0"
                class="font-bold"
              >
                {{ adasLab.comparisonHistory()[0].modified.impactSpeed_kmh }} km/h ({{ adasLab.comparisonHistory()[0].modified.collisionOccurred ? 'COLLISION' : 'AVOIDED' }})
              </span>
            </div>
          </div>
        }
      </div>
    </div>
  `
})
export class AdasPerceptionLab {
  readonly adasLab = inject(AdasLabService);
  readonly simEngine = inject(SimulationEngineService);

  updateParam(key: string, e: Event) {
    const val = +(e.target as HTMLInputElement).value;
    this.adasLab.updateSandbox(key, val);
  }
}
