import { Component, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationEngineService } from '../../services/simulation-engine.service';
import { FleetManufacturingService, AuditRecord } from '../../services/fleet-manufacturing.service';

@Component({
  selector: 'app-header-bar',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="bg-slate-900 border-b border-slate-800 px-4 py-2.5 flex items-center justify-between select-none shadow-md">
      <!-- Left: Volvo Brand & Twin Title -->
      <div class="flex items-center gap-3">
        <!-- Volvo Iron Mark Minimal Monogram -->
        <div class="w-8 h-8 rounded-lg bg-slate-950 border border-slate-700 flex items-center justify-center font-bold text-slate-100 font-mono tracking-tighter text-sm shadow-inner">
          VOLVO
        </div>

        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-sm font-bold tracking-wide text-slate-100 uppercase font-sans">
              Digital Twin & Engineering Simulation Platform
            </h1>
            <span class="px-1.5 py-0.5 rounded bg-cyan-950 border border-cyan-800 text-[10px] font-mono text-cyan-300 font-semibold">
              R&D LAB • SPA3/GMA
            </span>
          </div>
          <div class="text-[11px] text-slate-400 font-mono flex items-center gap-2">
            <span>Torslanda Digital Proving Ground</span>
            <span>•</span>
            <span class="text-emerald-400">Deterministic Solver Sync</span>
          </div>
        </div>
      </div>

      <!-- Right: RBAC Persona Switcher, Audit Trail & System Status -->
      <div class="flex items-center gap-3">
        <!-- RBAC Role Selector -->
        <div class="flex items-center gap-1.5 bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800 text-xs font-mono">
          <span class="text-slate-500 text-[10px]">ROLE:</span>
          <select
            [value]="activeRole()"
            (change)="onRoleChange($event)"
            class="bg-transparent text-cyan-300 font-semibold focus:outline-none cursor-pointer"
          >
            <option value="Engineer">Lead Dynamics Engineer</option>
            <option value="Safety Analyst">Safety & ADAS Analyst</option>
            <option value="Administrator">Systems Architect (Admin)</option>
            <option value="Viewer">Observer / Viewer</option>
          </select>
        </div>

        <!-- Audit Log Modal Trigger -->
        <button
          (click)="showAuditModal.set(!showAuditModal())"
          class="flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 text-xs font-mono transition-colors"
        >
          <mat-icon class="!text-sm !w-4 !h-4 text-cyan-400">history</mat-icon>
          <span>AUDIT LOG</span>
        </button>
      </div>
    </header>

    <!-- Audit Log Drawer / Modal -->
    @if (showAuditModal()) {
      <div class="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
        <div class="bg-slate-900 border border-slate-700 rounded-xl w-full max-w-2xl max-h-[80vh] flex flex-col shadow-2xl overflow-hidden text-xs font-mono">
          <!-- Modal Header -->
          <div class="p-3 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
            <div class="flex items-center gap-2 font-bold text-slate-200">
              <mat-icon class="!text-base !w-4 !h-4 text-cyan-400">verified_user</mat-icon>
              <span>ENGINEERING AUDIT & TRACEABILITY TRAIL</span>
            </div>
            <button (click)="showAuditModal.set(false)" class="text-slate-400 hover:text-white">
              <mat-icon class="!text-base !w-4 !h-4">close</mat-icon>
            </button>
          </div>

          <!-- Modal Content -->
          <div class="p-3 space-y-2 overflow-y-auto flex-1 scrollbar-thin">
            @for (log of fleetService.auditLogs(); track log.id) {
              <div class="p-2 rounded bg-slate-950 border border-slate-800 space-y-0.5">
                <div class="flex justify-between items-center text-[10px]">
                  <span class="font-bold text-cyan-300">[{{ log.userRole }}] • {{ log.action }}</span>
                  <span class="text-slate-500">{{ log.timestamp }}</span>
                </div>
                <div class="text-[11px] text-slate-300">{{ log.details }}</div>
                <div class="text-[9px] text-slate-500">Module: {{ log.targetModule }} • ID: {{ log.id }}</div>
              </div>
            }
          </div>

          <!-- Modal Footer -->
          <div class="p-2.5 bg-slate-950 border-t border-slate-800 flex justify-end">
            <button
              (click)="showAuditModal.set(false)"
              class="px-4 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded font-semibold text-xs transition-colors"
            >
              CLOSE
            </button>
          </div>
        </div>
      </div>
    }
  `
})
export class HeaderBar {
  readonly simEngine = inject(SimulationEngineService);
  readonly fleetService = inject(FleetManufacturingService);

  readonly activeRole = signal<AuditRecord['userRole']>('Engineer');
  readonly showAuditModal = signal<boolean>(false);

  onRoleChange(e: Event) {
    const role = (e.target as HTMLSelectElement).value as AuditRecord['userRole'];
    this.activeRole.set(role);
    this.fleetService.addAudit(role, 'ROLE_SWITCH', 'AuthManager', `User assumed role: ${role}`);
  }
}
