import { Component, inject, signal, computed, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationEngineService } from '../../services/simulation-engine.service';
import { VolvoVehicleModel } from '../../models/vehicle.models';

@Component({
  selector: 'app-vehicle-selector',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-slate-900 border border-slate-800 rounded-xl p-3 shadow-md flex flex-col gap-3">
      <!-- Top Bar: Filter Buttons & Active Count -->
      <div class="flex items-center justify-between flex-wrap gap-2">
        <div class="flex items-center gap-2">
          <div class="flex items-center gap-1 text-xs font-mono text-slate-400">
            <mat-icon class="!text-sm !w-4 !h-4 text-cyan-400">tune</mat-icon>
            <span class="font-semibold text-slate-200">FLEET CATALOGUE</span>
            <span>({{ filteredVehicles().length }} Models)</span>
          </div>
        </div>

        <!-- Filter Chips -->
        <div class="flex items-center gap-1.5 flex-wrap text-xs font-mono">
          <button
            (click)="setPowertrainFilter('ALL')"
            [class.bg-slate-700]="selectedPowertrain() === 'ALL'"
            [class.text-white]="selectedPowertrain() === 'ALL'"
            [class.text-slate-400]="selectedPowertrain() !== 'ALL'"
            class="px-2.5 py-1 rounded bg-slate-800/80 hover:bg-slate-700 transition-colors"
          >
            ALL
          </button>
          <button
            (click)="setPowertrainFilter('BEV')"
            [class.bg-cyan-900]="selectedPowertrain() === 'BEV'"
            [class.text-cyan-200]="selectedPowertrain() === 'BEV'"
            [class.border-cyan-500]="selectedPowertrain() === 'BEV'"
            class="px-2.5 py-1 rounded bg-slate-800/80 border border-transparent text-slate-400 hover:bg-slate-700 transition-colors flex items-center gap-1"
          >
            <span class="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
            PURE ELECTRIC (BEV)
          </button>
          <button
            (click)="setPowertrainFilter('PHEV')"
            [class.bg-emerald-900]="selectedPowertrain() === 'PHEV'"
            [class.text-emerald-200]="selectedPowertrain() === 'PHEV'"
            [class.border-emerald-500]="selectedPowertrain() === 'PHEV'"
            class="px-2.5 py-1 rounded bg-slate-800/80 border border-transparent text-slate-400 hover:bg-slate-700 transition-colors flex items-center gap-1"
          >
            <span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
            PLUG-IN HYBRID (T8)
          </button>
        </div>
      </div>

      <!-- Horizontal Vehicle Carousel / Scrollable Shelf -->
      <div class="flex items-stretch gap-3 overflow-x-auto pb-2 scrollbar-thin">
        @for (vehicle of filteredVehicles(); track vehicle.id) {
          <button
            type="button"
            (click)="selectVehicle(vehicle.id)"
            [class.border-cyan-500]="simEngine.selectedVehicle().id === vehicle.id"
            [class.bg-slate-800]="simEngine.selectedVehicle().id === vehicle.id"
            [class.ring-1]="simEngine.selectedVehicle().id === vehicle.id"
            [class.ring-cyan-500]="simEngine.selectedVehicle().id === vehicle.id"
            class="min-w-[260px] max-w-[280px] p-3 rounded-lg border border-slate-800 bg-slate-900/60 hover:border-slate-700 cursor-pointer transition-all duration-150 flex flex-col justify-between shrink-0 select-none group text-left"
          >
            <!-- Card Header -->
            <div>
              <div class="flex items-start justify-between gap-2">
                <div class="font-bold text-sm text-slate-100 group-hover:text-cyan-300 transition-colors">
                  {{ vehicle.modelName }}
                </div>
                <span
                  [class.bg-cyan-950]="vehicle.powertrainType === 'BEV'"
                  [class.text-cyan-400]="vehicle.powertrainType === 'BEV'"
                  [class.border-cyan-800]="vehicle.powertrainType === 'BEV'"
                  [class.bg-emerald-950]="vehicle.powertrainType === 'PHEV'"
                  [class.text-emerald-400]="vehicle.powertrainType === 'PHEV'"
                  [class.border-emerald-800]="vehicle.powertrainType === 'PHEV'"
                  class="text-[10px] font-mono px-1.5 py-0.5 rounded border uppercase"
                >
                  {{ vehicle.powertrainType }}
                </span>
              </div>
              <div class="text-[11px] text-slate-400 mt-0.5 font-mono">
                {{ vehicle.platform }} • {{ vehicle.bodyStyle }}
              </div>
            </div>

            <!-- Key Engineering Specs Grid -->
            <div class="grid grid-cols-3 gap-1.5 py-2 my-2 border-y border-slate-800/80 text-[11px] font-mono w-full">
              <div>
                <div class="text-[9px] text-slate-500 uppercase">POWER</div>
                <div class="text-slate-200 font-semibold">{{ getVehiclePower(vehicle) }} kW</div>
              </div>
              <div>
                <div class="text-[9px] text-slate-500 uppercase">0-100</div>
                <div class="text-slate-200 font-semibold">{{ vehicle.acceleration0to100_s.value }}s</div>
              </div>
              <div>
                <div class="text-[9px] text-slate-500 uppercase">WLTP</div>
                <div class="text-cyan-300 font-semibold">
                  {{ vehicle.wltpRange_km ? vehicle.wltpRange_km.value + ' km' : '—' }}
                </div>
              </div>
            </div>

            <!-- Provenance & Architecture Badges -->
            <div class="flex items-center justify-between text-[10px] font-mono text-slate-400 w-full">
              <span class="flex items-center gap-1 text-slate-500">
                <mat-icon class="!text-[12px] !w-3 !h-3 text-slate-400">verified</mat-icon>
                <span>{{ vehicle.massDynamics.curbMass_kg.provenance.source }}</span>
              </span>
              @if (vehicle.battery) {
                <span class="text-slate-400 font-semibold">{{ vehicle.battery.architectureVoltage }}V</span>
              }
            </div>
          </button>
        }
      </div>
    </div>
  `
})
export class VehicleSelector {
  readonly simEngine = inject(SimulationEngineService);

  readonly selectedPowertrain = signal<'ALL' | 'BEV' | 'PHEV'>('ALL');

  readonly filteredVehicles = computed(() => {
    const list = this.simEngine.catalogue();
    const pt = this.selectedPowertrain();
    if (pt === 'ALL') return list;
    return list.filter(v => v.powertrainType === pt);
  });

  setPowertrainFilter(type: 'ALL' | 'BEV' | 'PHEV') {
    this.selectedPowertrain.set(type);
  }

  selectVehicle(id: string) {
    this.simEngine.selectVehicleById(id);
  }

  getVehiclePower(v: VolvoVehicleModel): number {
    if (v.motor) return v.motor.maxPower_kW.value;
    if (v.hybridEngine) return v.hybridEngine.maxEnginePower_kW.value;
    return 0;
  }
}

