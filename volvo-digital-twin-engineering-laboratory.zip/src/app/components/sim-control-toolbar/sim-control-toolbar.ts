import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationEngineService } from '../../services/simulation-engine.service';
import { DriveMode, RoadSurfaceType, WeatherType } from '../../models/physics.models';

@Component({
  selector: 'app-sim-control-toolbar',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-slate-900 border border-slate-800 rounded-xl p-3 shadow-md flex flex-col gap-3">
      <!-- Top Row: Primary Playback & Multi-rate Clock Controls -->
      <div class="flex items-center justify-between flex-wrap gap-3">
        <!-- Play / Pause / Step / Reset Cluster -->
        <div class="flex items-center gap-1.5 bg-slate-950 p-1.5 rounded-lg border border-slate-800">
          @if (!simEngine.isRunning()) {
            <button
              (click)="simEngine.startSimulation()"
              class="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-mono font-semibold rounded transition-colors shadow-sm"
              title="Run Real-Time Simulation (100Hz deterministic)"
            >
              <mat-icon class="!text-base !w-4 !h-4">play_arrow</mat-icon>
              <span>RUN</span>
            </button>
          } @else {
            <button
              (click)="simEngine.pauseSimulation()"
              class="flex items-center gap-1.5 px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white text-xs font-mono font-semibold rounded transition-colors shadow-sm"
              title="Pause Simulation"
            >
              <mat-icon class="!text-base !w-4 !h-4">pause</mat-icon>
              <span>PAUSE</span>
            </button>
          }

          <button
            (click)="simEngine.stepSingle(0.01)"
            [disabled]="simEngine.isRunning()"
            class="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            title="Single Time Step (+10ms)"
          >
            <mat-icon class="!text-base !w-4 !h-4">skip_next</mat-icon>
          </button>

          <button
            (click)="simEngine.resetSimulation()"
            class="p-1.5 text-slate-300 hover:text-rose-400 hover:bg-slate-800 rounded transition-colors"
            title="Reset to Initial State"
          >
            <mat-icon class="!text-base !w-4 !h-4">restart_alt</mat-icon>
          </button>

          <div class="h-4 w-px bg-slate-800 mx-1"></div>

          <!-- Multi-Rate Clock Speed -->
          <div class="flex items-center gap-1 text-[11px] font-mono text-slate-400">
            @for (rate of speedRates; track rate) {
              <button
                (click)="setRate(rate)"
                [class.bg-cyan-900]="simEngine.playbackRate() === rate"
                [class.text-cyan-200]="simEngine.playbackRate() === rate"
                class="px-1.5 py-0.5 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors"
              >
                {{ rate }}x
              </button>
            }
          </div>
        </div>

        <!-- Simulation Clock & Frame Telemetry Readout -->
        <div class="flex items-center gap-4 text-xs font-mono bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800">
          <div class="flex items-center gap-1.5">
            <span class="text-slate-500">SIM TIME:</span>
            <span class="font-bold text-cyan-400 text-sm">
              {{ simEngine.simulationTime().toFixed(2) }}s
            </span>
          </div>
          <div class="flex items-center gap-1.5">
            <span class="text-slate-500">SOLVER:</span>
            <span class="text-slate-300">{{ simEngine.solverFrequency_Hz() }} Hz</span>
          </div>
          <div class="flex items-center gap-1.5">
            <span class="text-slate-500">FRAMES:</span>
            <span class="text-slate-300">{{ simEngine.recordedFramesCount() }}</span>
          </div>
        </div>

        <!-- Scenario Selector Dropdown -->
        <div class="flex items-center gap-2">
          <span class="text-xs font-mono text-slate-400">SCENARIO:</span>
          <select
            [value]="simEngine.selectedScenario().id"
            (change)="onScenarioChange($event)"
            class="bg-slate-950 text-slate-200 border border-slate-700 text-xs font-mono rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-cyan-500"
          >
            @for (scen of simEngine.scenarios(); track scen.id) {
              <option [value]="scen.id">{{ scen.name }}</option>
            }
          </select>
        </div>

        <!-- Telemetry Export Buttons -->
        <div class="flex items-center gap-1.5">
          <button
            (click)="exportTelemetryJson()"
            class="flex items-center gap-1 px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono rounded border border-slate-700 transition-colors"
          >
            <mat-icon class="!text-[14px] !w-3.5 !h-3.5 text-cyan-400">file_download</mat-icon>
            <span>EXPORT JSON</span>
          </button>
          <button
            (click)="exportTelemetryCsv()"
            class="flex items-center gap-1 px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono rounded border border-slate-700 transition-colors"
          >
            <mat-icon class="!text-[14px] !w-3.5 !h-3.5 text-emerald-400">table_chart</mat-icon>
            <span>EXPORT CSV</span>
          </button>
        </div>
      </div>

      <!-- Second Row: Drive Mode, Surface Friction, Weather & Replay Timeline Slider -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-2 pt-2 border-t border-slate-800/80 text-xs font-mono">
        <!-- Drive Modes -->
        <div class="flex items-center gap-1.5">
          <span class="text-slate-500 text-[11px]">MODE:</span>
          <div class="flex items-center gap-1">
            @for (mode of driveModes; track mode) {
              <button
                (click)="simEngine.setDriveMode(mode)"
                [class.bg-cyan-900]="simEngine.currentState().driveMode === mode"
                [class.text-cyan-200]="simEngine.currentState().driveMode === mode"
                [class.border-cyan-700]="simEngine.currentState().driveMode === mode"
                class="px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-slate-400 text-[11px] hover:text-slate-200"
              >
                {{ mode }}
              </button>
            }
          </div>
        </div>

        <!-- Road Surface / Friction -->
        <div class="flex items-center gap-1.5">
          <span class="text-slate-500 text-[11px]">SURFACE:</span>
          <select
            [value]="simEngine.currentState().roadSurface"
            (change)="onSurfaceChange($event)"
            class="bg-slate-950 text-slate-300 border border-slate-800 text-[11px] rounded px-2 py-0.5 flex-1"
          >
            <option value="Dry Asphalt">Dry Asphalt (μ=1.00)</option>
            <option value="Wet Asphalt">Wet Asphalt (μ=0.72)</option>
            <option value="Gravel">Gravel (μ=0.55)</option>
            <option value="Mud">Mud (μ=0.40)</option>
            <option value="Snow">Snow (μ=0.28)</option>
            <option value="Ice">Ice (μ=0.14)</option>
          </select>
        </div>

        <!-- Weather -->
        <div class="flex items-center gap-1.5">
          <span class="text-slate-500 text-[11px]">WEATHER:</span>
          <select
            [value]="simEngine.currentState().weather"
            (change)="onWeatherChange($event)"
            class="bg-slate-950 text-slate-300 border border-slate-800 text-[11px] rounded px-2 py-0.5 flex-1"
          >
            <option value="Clear">Clear Sun (20°C)</option>
            <option value="Rain">Rain (12°C)</option>
            <option value="Snow">Heavy Snow (-18°C)</option>
            <option value="Fog">Dense Fog (8°C)</option>
            <option value="Night">Night (10°C)</option>
          </select>
        </div>

        <!-- Replay Buffer Timeline Scrub -->
        <div class="flex items-center gap-2">
          <span class="text-slate-500 text-[11px]">REPLAY:</span>
          <input
            type="range"
            min="0"
            [max]="Math.max(0, simEngine.recordedFramesCount() - 1)"
            [value]="simEngine.replayIndex()"
            (input)="onReplayScrub($event)"
            class="flex-1 accent-cyan-500 cursor-pointer h-1.5 bg-slate-950 rounded-lg"
          />
        </div>
      </div>
    </div>
  `
})
export class SimControlToolbar {
  readonly simEngine = inject(SimulationEngineService);

  readonly speedRates = [0.5, 1.0, 2.0, 5.0, 10.0];
  readonly driveModes: DriveMode[] = ['Comfort', 'Eco', 'Dynamic', 'Off-road'];
  readonly Math = Math;

  setRate(rate: number) {
    this.simEngine.playbackRate.set(rate);
  }

  onScenarioChange(e: Event) {
    const id = (e.target as HTMLSelectElement).value;
    this.simEngine.selectScenarioById(id);
  }

  onSurfaceChange(e: Event) {
    const val = (e.target as HTMLSelectElement).value as RoadSurfaceType;
    this.simEngine.setSurface(val);
  }

  onWeatherChange(e: Event) {
    const val = (e.target as HTMLSelectElement).value as WeatherType;
    this.simEngine.setWeather(val);
  }

  onReplayScrub(e: Event) {
    const idx = +(e.target as HTMLInputElement).value;
    this.simEngine.seekReplay(idx);
  }

  exportTelemetryJson() {
    const log = this.simEngine.getTelemetryLog();
    const blob = new Blob([JSON.stringify(log, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `volvo-telemetry-${this.simEngine.selectedVehicle().id}-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  exportTelemetryCsv() {
    const log = this.simEngine.getTelemetryLog();
    if (log.length === 0) return;

    const headers = [
      'timestamp_s', 'speed_kmh', 'acceleration_mps2', 'motorPower_kW',
      'regenPower_kW', 'batterySoc_percent', 'batteryTemp_C', 'lateralAccel_mps2',
      'frictionBrake_bar', 'yawRate_radps', 'cabinTemp_C'
    ];

    const rows = log.map(s => [
      s.timestamp, s.speed_kmh, s.acceleration_mps2, s.motorPower_kW,
      s.regenPower_kW, s.batterySoc, s.batteryTemp_C, s.lateralAcceleration_mps2,
      s.frictionBrakePressure_bar, s.yawRate_radps, s.cabinTemp_C
    ].join(','));

    const csvContent = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `volvo-telemetry-${this.simEngine.selectedVehicle().id}-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }
}
