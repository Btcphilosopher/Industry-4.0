"""Dynamics engine tests (section 43): gravity torque, mass matrix
symmetry/positive-definiteness, and forward/inverse dynamics consistency.
"""

import numpy as np

from roboforge.robotics.dynamics.dynamics_model import DynamicsModel


def test_gravity_torque_nonzero_when_not_vertical(robot):
    q = robot.home_position()
    tau_g = robot.gravity_torque(q)
    assert np.any(np.abs(tau_g) > 1e-3)


def test_zero_gravity_zero_velocity_zero_acceleration_gives_zero_torque(robot):
    dm = DynamicsModel(robot, gravity=np.zeros(3))
    tau = dm.inverse_dynamics(robot.home_position(), np.zeros(robot.dof), np.zeros(robot.dof))
    assert np.allclose(tau, 0, atol=1e-8)


def test_mass_matrix_symmetric_positive_definite(robot):
    dm = DynamicsModel(robot)
    M = dm.mass_matrix(robot.home_position())
    assert np.allclose(M, M.T, atol=1e-8)
    eigenvalues = np.linalg.eigvalsh(M)
    assert np.all(eigenvalues > 0)


def test_forward_dynamics_inverts_inverse_dynamics(robot):
    dm = DynamicsModel(robot)
    q = robot.home_position()
    qd = np.array([0.1, -0.2, 0.15, 0.05, -0.05, 0.02])
    qdd_true = np.array([0.5, -0.3, 0.2, 0.1, -0.1, 0.05])

    tau = dm.inverse_dynamics(q, qd, qdd_true)
    qdd_recovered = dm.forward_dynamics(q, qd, tau)

    assert np.allclose(qdd_true, qdd_recovered, atol=1e-3)


def test_payload_increases_required_torque(robot):
    q = robot.home_position()
    zeros = np.zeros(robot.dof)
    tau_no_payload = robot.inverse_dynamics(q, zeros, zeros)

    robot.set_payload(5.0, np.array([0.0, 0.0, 0.05]))
    tau_with_payload = robot.inverse_dynamics(q, zeros, zeros)

    assert np.sum(np.abs(tau_with_payload)) > np.sum(np.abs(tau_no_payload))
