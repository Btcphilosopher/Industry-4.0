"""Configuration validation tests (section 43)."""

import pytest

from roboforge.cli.context import DEFAULT_CONFIG
from roboforge.configuration.loader import build_robot_from_config, load_and_build_robot, load_robot_config
from roboforge.configuration.schema import JointConfigSchema, RobotConfigSchema
from roboforge.core.exceptions import ConfigurationError


def test_example_config_loads_and_validates():
    config = load_robot_config(DEFAULT_CONFIG)
    assert config.dof == 6
    assert len(config.joints) == 6


def test_example_config_builds_a_working_robot():
    robot = load_and_build_robot(DEFAULT_CONFIG)
    assert robot.dof == 6
    assert len(robot.joints) == 6
    assert len(robot.links) == 6


def test_missing_config_file_raises_configuration_error(tmp_path):
    with pytest.raises(ConfigurationError):
        load_robot_config(tmp_path / "does_not_exist.yaml")


def test_dof_joint_count_mismatch_is_rejected():
    with pytest.raises(Exception):
        RobotConfigSchema(
            id="bad_robot", dof=3,
            joints=[
                JointConfigSchema(name="j1", min_position=-1, max_position=1, max_velocity=1, max_acceleration=1),
            ],
        )


def test_invalid_joint_range_is_rejected():
    with pytest.raises(Exception):
        JointConfigSchema(name="j1", min_position=1.0, max_position=-1.0, max_velocity=1, max_acceleration=1)


def test_home_position_outside_range_is_rejected():
    with pytest.raises(Exception):
        JointConfigSchema(
            name="j1", min_position=-1.0, max_position=1.0, max_velocity=1, max_acceleration=1, home_position=5.0
        )
