"""Driver (section 43) tests: the simulation driver implements the full
command model behind the ``RobotDriver`` interface.
"""

import numpy as np
import pytest

from roboforge.core.enums import MotionState
from roboforge.core.exceptions import DriverConnectionError
from roboforge.drivers.command_model import CloseGripper, MoveJoint, OpenGripper, Pause, Resume, Stop
from roboforge.drivers.generic_industrial_driver import ControllerEndpoint, GenericIndustrialDriver


def test_driver_connect_enable_lifecycle(driver, robot_with_tool):
    assert driver.connected
    assert robot_with_tool.motion_state == MotionState.ENABLED


def test_move_joint_command_executes(driver, robot_with_tool):
    target = robot_with_tool.clamp_joint_positions(robot_with_tool.home_position() + 0.2)
    result = driver.send_command(MoveJoint(target_positions=target))
    assert result.accepted
    assert np.allclose(robot_with_tool.joint_state.position, target, atol=1e-3)


def test_stop_command_estops(driver):
    result = driver.send_command(Stop(reason="test"))
    assert result.accepted
    assert driver.robot.motion_state == MotionState.STOPPED


def test_pause_resume_cycle(driver):
    driver.send_command(Pause())
    assert driver.robot.motion_state == MotionState.PAUSED
    driver.send_command(Resume())
    assert driver.robot.motion_state == MotionState.MOVING


def test_gripper_commands(driver):
    result = driver.send_command(CloseGripper(object_width_m=0.03))
    assert result.accepted
    assert driver.gripper.is_object_grasped()
    result = driver.send_command(OpenGripper())
    assert result.accepted
    assert not driver.gripper.is_object_grasped()


def test_out_of_limit_move_rejected(driver, robot_with_tool):
    bad_target = np.array([j.limits.max_position + 10 for j in robot_with_tool.joints])
    result = driver.send_command(MoveJoint(target_positions=bad_target))
    assert not result.accepted


def test_generic_industrial_driver_fails_honestly_without_hardware():
    driver = GenericIndustrialDriver("robot_x", ControllerEndpoint(host="127.0.0.1", port=1, connect_timeout_s=0.2))
    with pytest.raises(DriverConnectionError):
        driver.connect()
