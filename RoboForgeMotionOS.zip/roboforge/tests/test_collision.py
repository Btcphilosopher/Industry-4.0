"""Collision engine tests (section 43): self-collision at a known
degenerate configuration is out of scope here (capsule approximations
make "guaranteed self-collision at any q" hard to assert generically);
instead we test the primitive distance queries directly and a full
integration check against a placed obstacle.
"""

import numpy as np

from roboforge.collision.collision_engine import CollisionEngine
from roboforge.collision.collision_world import CollisionObject, CollisionWorld, ObjectKind
from roboforge.collision.shapes import capsule_capsule_distance, segment_segment_distance
from roboforge.core.transforms import Pose


def test_segment_segment_distance_parallel_segments():
    d, _, _ = segment_segment_distance(
        np.array([0, 0, 0]), np.array([1, 0, 0]), np.array([0, 1, 0]), np.array([1, 1, 0])
    )
    assert np.isclose(d, 1.0)


def test_capsule_capsule_distance_touching():
    d = capsule_capsule_distance(
        np.array([0, 0, 0]), np.array([1, 0, 0]), 0.5, np.array([0, 1.0, 0]), np.array([1, 1.0, 0]), 0.5
    )
    assert np.isclose(d, 0.0, atol=1e-9)


def test_capsule_capsule_distance_penetrating():
    d = capsule_capsule_distance(
        np.array([0, 0, 0]), np.array([1, 0, 0]), 0.6, np.array([0, 0.5, 0]), np.array([1, 0.5, 0]), 0.6
    )
    assert d < 0


def test_no_collision_in_open_workspace(collision_engine, robot_with_tool):
    report = collision_engine.check(robot_with_tool.home_position())
    assert not report.in_collision


def test_collision_detected_against_close_obstacle(robot_with_tool):
    world = CollisionWorld()
    tcp = robot_with_tool.forward_kinematics(robot_with_tool.home_position())
    world.add(
        CollisionObject(
            object_id="obstacle_1", kind=ObjectKind.OBSTACLE, shape="sphere",
            pose=Pose(tcp.position, np.eye(3)), radius=0.2,
        )
    )
    engine = CollisionEngine(robot_with_tool, world)
    report = engine.check(robot_with_tool.home_position(), safety_margin=0.02)
    assert report.in_collision


def test_collision_checker_callable(collision_engine, robot_with_tool):
    checker = collision_engine.as_checker()
    assert checker(robot_with_tool.home_position()) is True


def test_check_trajectory_returns_report_per_point(collision_engine, robot_with_tool):
    from roboforge.motion.trajectory.joint_trajectory import generate_joint_trajectory

    q0 = robot_with_tool.home_position()
    q1 = robot_with_tool.clamp_joint_positions(q0 + 0.2)
    trajectory = generate_joint_trajectory(robot_with_tool, q0, q1)
    reports = collision_engine.check_trajectory(trajectory)
    assert len(reports) == len(trajectory.points)
