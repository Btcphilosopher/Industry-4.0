"""Calibration subsystem tests (section 43): robot repeatability/accuracy,
hand-eye (AX=XB), TCP pivot calibration, and camera DLT calibration.
"""

import numpy as np

from roboforge.calibration.camera.camera_calibration import CameraCalibrationEngine
from roboforge.calibration.hand_eye.hand_eye_calibration import solve_hand_eye
from roboforge.calibration.robot.robot_calibration import RobotCalibrationEngine
from roboforge.calibration.tcp.tcp_calibration import TCPCalibrationEngine
from roboforge.core.transforms import Pose, euler_to_rotation_matrix


def test_robot_repeatability_report(robot, rng):
    target = robot.forward_kinematics(robot.home_position())
    measured = [
        Pose(target.position + rng.normal(0, 1e-4, size=3), target.rotation) for _ in range(10)
    ]
    engine = RobotCalibrationEngine(robot)
    report = engine.measure_repeatability_and_accuracy(target, measured)

    assert report.repeatability_m > 0
    assert report.absolute_accuracy_m >= 0
    assert robot.calibration.calibrated


def test_joint_zero_offset_calibration(robot):
    engine = RobotCalibrationEngine(robot)
    nominal = np.zeros(robot.dof)
    measured = np.full(robot.dof, 0.01)
    offsets = engine.calibrate_joint_zero_offsets(nominal, measured)
    assert np.allclose(offsets, 0.01)
    assert np.allclose(robot.calibration.joint_zero_offsets, 0.01)


def test_hand_eye_calibration_recovers_known_transform(rng):
    X_true = Pose(np.array([0.05, 0.02, 0.03]), euler_to_rotation_matrix([0.1, 0.2, 0.3]))
    robot_motions, camera_motions = [], []
    for _ in range(8):
        A = Pose(rng.normal(0, 0.1, 3), euler_to_rotation_matrix(rng.normal(0, 0.3, 3)))
        B = X_true.inverse().compose(A).compose(X_true)
        robot_motions.append(A)
        camera_motions.append(B)

    result = solve_hand_eye(robot_motions, camera_motions)
    assert result.X.distance_to(X_true) < 1e-3
    assert result.rotation_residual_rad < 1e-3


def test_tcp_pivot_calibration_recovers_known_offset(rng):
    tool_offset_true = np.array([0.01, 0.0, 0.12])
    world_point_true = np.array([0.4, 0.1, 0.3])
    poses = []
    for _ in range(6):
        R = euler_to_rotation_matrix(rng.uniform(-1, 1, 3))
        t = world_point_true - R @ tool_offset_true
        poses.append(Pose(t, R))

    engine = TCPCalibrationEngine()
    result = engine.calibrate_pivot(poses)
    assert np.linalg.norm(result.tool_offset - tool_offset_true) < 1e-6
    assert result.residual_rms_m < 1e-6


def test_camera_dlt_calibration_recovers_intrinsics(rng):
    K_true = np.array([[800.0, 0, 320], [0, 800.0, 240], [0, 0, 1]])
    R_true = euler_to_rotation_matrix([0.1, 0.05, 0.0])
    t_true = np.array([0.0, 0.0, 1.0])

    world_points = rng.uniform(-0.5, 0.5, size=(10, 3)) + np.array([0, 0, 3.0])
    P = K_true @ np.hstack([R_true, t_true.reshape(3, 1)])
    pixel_points = []
    for wp in world_points:
        proj = P @ np.append(wp, 1.0)
        pixel_points.append((proj[0] / proj[2], proj[1] / proj[2]))

    result = CameraCalibrationEngine().calibrate(list(world_points), pixel_points, 640, 480)
    assert result.reprojection_error_rms_px < 1.0
    assert np.isclose(result.intrinsics.fx, 800.0, atol=1.0)
