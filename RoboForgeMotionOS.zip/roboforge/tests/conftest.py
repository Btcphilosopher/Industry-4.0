"""Shared pytest fixtures: a connected, enabled, non-singular simulated
robot cell built from the example configuration (section 43: deterministic
simulation tests)."""

from __future__ import annotations

import numpy as np
import pytest

from roboforge.cli.context import DEFAULT_CONFIG
from roboforge.collision.collision_engine import CollisionEngine
from roboforge.configuration.loader import load_and_build_robot
from roboforge.drivers.simulation_driver import SimulationDriver
from roboforge.events.event_bus import EventBus
from roboforge.manipulation.tools.gripper import GripperController
from roboforge.robotics.tool import Tool, ToolCentrePoint, ToolKind
from roboforge.telemetry.telemetry_recorder import TelemetryRecorder


@pytest.fixture
def robot():
    r = load_and_build_robot(DEFAULT_CONFIG)
    r.joint_state.position = r.home_position().copy()
    return r


@pytest.fixture
def robot_with_tool(robot):
    robot.attach_tool(Tool(name="precision_gripper", kind=ToolKind.PARALLEL_GRIPPER, tcp=ToolCentrePoint()))
    return robot


@pytest.fixture
def collision_engine(robot_with_tool):
    return CollisionEngine(robot_with_tool)


@pytest.fixture
def event_bus():
    return EventBus()


@pytest.fixture
def telemetry_recorder():
    return TelemetryRecorder()


@pytest.fixture
def driver(robot_with_tool, collision_engine, event_bus, telemetry_recorder):
    d = SimulationDriver(robot_with_tool, collision_engine, event_bus, telemetry_recorder)
    d.connect()
    d.enable()
    return d


@pytest.fixture
def gripper(robot_with_tool):
    return GripperController(robot_with_tool.tool)


@pytest.fixture
def rng():
    return np.random.default_rng(42)
