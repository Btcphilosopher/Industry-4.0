"""Jacobian engine and singularity-detection tests (section 43)."""

import numpy as np

from roboforge.robotics.kinematics.jacobian import (
    analytic_jacobian,
    damped_pseudoinverse,
    geometric_jacobian,
    null_space_projector,
)
from roboforge.robotics.kinematics.singularity import analyse_singularity, manipulability_index


def test_geometric_jacobian_shape(robot):
    J = geometric_jacobian(robot, robot.home_position())
    assert J.shape == (6, robot.dof)


def test_jacobian_matches_finite_difference_velocity(robot):
    q = robot.home_position()
    qd = np.array([0.1, -0.05, 0.05, 0.02, -0.02, 0.01])
    J = geometric_jacobian(robot, q)
    predicted_linear_velocity = (J @ qd)[:3]

    eps = 1e-6
    p_plus = robot.forward_kinematics(q + eps * qd)
    p_minus = robot.forward_kinematics(q - eps * qd)
    finite_diff_velocity = (p_plus.position - p_minus.position) / (2 * eps)

    assert np.allclose(predicted_linear_velocity, finite_diff_velocity, atol=1e-4)


def test_analytic_jacobian_shape(robot):
    J = analytic_jacobian(robot, robot.home_position())
    assert J.shape == (6, robot.dof)


def test_damped_pseudoinverse_well_conditioned_at_home(robot):
    J = geometric_jacobian(robot, robot.home_position())
    J_pinv = damped_pseudoinverse(J, damping=0.01)
    assert J_pinv.shape == (robot.dof, 6)
    # J * J_pinv should be close to the identity away from singularities.
    assert np.allclose(J @ J_pinv, np.eye(6), atol=0.1)


def test_null_space_projector_is_idempotent(robot):
    J = geometric_jacobian(robot, robot.home_position())
    N = null_space_projector(J)
    assert np.allclose(N @ N, N, atol=1e-6)


def test_manipulability_positive_at_well_conditioned_pose(robot):
    m = manipulability_index(robot, robot.home_position())
    assert m > 1e-4


def test_manipulability_near_zero_at_elbow_straight_singularity(robot):
    q_singular = np.zeros(robot.dof)
    report = analyse_singularity(robot, q_singular)
    assert report.manipulability < 1e-6
    assert report.near_singular
