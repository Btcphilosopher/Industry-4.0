"""Safety state machine tests (section 43)."""

import numpy as np
import pytest

from roboforge.core.enums import MotionState, SafetyLevel
from roboforge.core.exceptions import SafetyViolationError
from roboforge.safety.safety_state_machine import SafetyStateMachine
from roboforge.safety.watchdog import Watchdog


def test_legal_transition_sequence(robot):
    fsm = SafetyStateMachine(robot)
    fsm.transition_to(MotionState.INITIALISING)
    fsm.transition_to(MotionState.READY)
    fsm.transition_to(MotionState.ENABLED)
    fsm.transition_to(MotionState.MOVING)
    assert robot.motion_state == MotionState.MOVING


def test_illegal_transition_raises(robot):
    fsm = SafetyStateMachine(robot)
    with pytest.raises(SafetyViolationError):
        fsm.transition_to(MotionState.MOVING)  # can't jump straight from DISCONNECTED


def test_emergency_stop_always_reachable(robot):
    fsm = SafetyStateMachine(robot)
    fsm.transition_to(MotionState.INITIALISING)
    fsm.transition_to(MotionState.READY)
    fsm.transition_to(MotionState.ENABLED)
    fsm.transition_to(MotionState.MOVING)

    fsm.emergency_stop("test_estop")
    assert robot.motion_state == MotionState.STOPPED
    assert robot.safety_level == SafetyLevel.ESTOP


def test_cannot_command_motion_while_faulted(robot):
    fsm = SafetyStateMachine(robot)
    fsm.transition_to(MotionState.INITIALISING)
    fsm.transition_to(MotionState.READY)
    fsm.transition_to(MotionState.ENABLED)
    fsm.transition_to(MotionState.FAULT, reason="test_fault")

    with pytest.raises(SafetyViolationError):
        fsm.validate_motion_command(robot.home_position())


def test_out_of_workspace_target_rejected(robot):
    fsm = SafetyStateMachine(robot)
    fsm.transition_to(MotionState.INITIALISING)
    fsm.transition_to(MotionState.READY)
    fsm.transition_to(MotionState.ENABLED)

    from roboforge.core.exceptions import RoboForgeError

    far_joints = np.array([j.limits.max_position for j in robot.joints])
    # Not guaranteed unreachable, but validate_motion_command should not
    # silently accept a target outside the configured workspace envelope.
    try:
        fsm.validate_motion_command(far_joints)
    except RoboForgeError:
        pass  # either a workspace or joint-limit rejection is acceptable here


def test_watchdog_trips_after_timeout():
    tripped = {"flag": False}

    def on_timeout():
        tripped["flag"] = True

    wd = Watchdog(timeout_s=0.01, on_timeout=on_timeout)
    wd.kick()
    import time

    time.sleep(0.05)
    assert wd.check() is False
    assert tripped["flag"] is True


def test_validate_trajectory_flags_limit_violation(robot):
    from roboforge.motion.trajectory.joint_trajectory import JointTrajectory, JointTrajectoryPoint

    fsm = SafetyStateMachine(robot)
    bad_velocity = np.full(robot.dof, 1000.0)
    trajectory = JointTrajectory(
        joint_names=robot.joint_names,
        points=[JointTrajectoryPoint(t=0.0, position=robot.home_position(), velocity=bad_velocity, acceleration=np.zeros(robot.dof))],
    )
    report = fsm.validate_trajectory(trajectory)
    assert not report.valid
    assert len(report.violations) > 0
