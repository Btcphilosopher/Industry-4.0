"""Grasping and manipulation-tool tests (section 43)."""

import numpy as np

from roboforge.manipulation.grasping.grasp import GraspableObject, ObjectShape
from roboforge.manipulation.grasping.grasp_planner import GraspPlanner
from roboforge.manipulation.tools.gripper import GripperController


def test_grasp_planner_selects_a_feasible_grasp(robot_with_tool):
    tcp = robot_with_tool.forward_kinematics(robot_with_tool.home_position())
    obj = GraspableObject("component_42", ObjectShape.BOX, tcp, np.array([0.03, 0.03, 0.03]))
    planner = GraspPlanner(robot_with_tool, robot_with_tool.tool)
    grasp = planner.select_best(obj)

    assert grasp.reachability_score > 0
    assert grasp.collision_risk < 1.0
    assert 0 <= grasp.quality_score <= 1.0
    assert robot_with_tool.tool.jaw_min_m <= grasp.gripper_width_m <= robot_with_tool.tool.jaw_max_m


def test_grasp_candidates_generated_for_box_and_cylinder(robot_with_tool):
    tcp = robot_with_tool.forward_kinematics(robot_with_tool.home_position())
    planner = GraspPlanner(robot_with_tool, robot_with_tool.tool)

    box = GraspableObject("box1", ObjectShape.BOX, tcp, np.array([0.03, 0.03, 0.03]))
    cylinder = GraspableObject("cyl1", ObjectShape.CYLINDER, tcp, np.array([0.015, 0.05, 0.0]))

    assert len(planner.generate_candidates(box)) > 0
    assert len(planner.generate_candidates(cylinder)) > 0


def test_gripper_open_close_state_machine(gripper):
    result = gripper.open()
    assert result.state.value == "open"
    assert not gripper.is_object_grasped()

    result = gripper.close(object_width_m=0.03)
    assert gripper.is_object_grasped()
    assert np.isclose(result.jaw_position_m, 0.03)


def test_gripper_close_on_nothing_reports_no_grasp(gripper):
    gripper.close(object_width_m=None)
    assert not gripper.is_object_grasped()


def test_gripper_rejects_out_of_range_position(gripper):
    import pytest
    from roboforge.core.exceptions import RoboForgeError

    with pytest.raises(RoboForgeError):
        gripper.set_position(999.0)
