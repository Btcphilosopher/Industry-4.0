"""Sensor fusion / state estimation tests (section 43)."""

import numpy as np

from roboforge.sensors.encoder import SimulatedEncoder
from roboforge.sensors.force_torque_sensor import SimulatedForceTorqueSensor
from roboforge.state_estimation.kalman_filter import KalmanFilter
from roboforge.state_estimation.state_estimator import RobotStateEstimator, complementary_filter


def test_kalman_filter_converges_to_constant_position():
    kf = KalmanFilter.constant_acceleration_1d(dt=0.01, measurement_noise=1e-6)
    true_position = 0.5
    for _ in range(200):
        kf.predict()
        kf.update(np.array([true_position]))
    assert np.isclose(kf.x[0], true_position, atol=1e-2)


def test_encoder_quantises_and_reads_true_value():
    encoder = SimulatedEncoder("enc1", resolution_rad=1e-4, noise_std_rad=0.0)
    encoder.set_true_value(0.12345)
    reading = encoder.read()
    assert np.isclose(reading.value, 0.1235, atol=2e-4)


def test_force_torque_sensor_reads_bound_source():
    sensor = SimulatedForceTorqueSensor("ft1", force_noise_std_n=0.0, torque_noise_std_nm=0.0)
    sensor.bind_source(lambda: np.array([0, 0, 10.0, 0, 0, 0]))
    reading = sensor.read()
    assert np.allclose(reading.value, [0, 0, 10, 0, 0, 0])


def test_complementary_filter_blends_estimates():
    a = np.array([1.0, 1.0, 1.0])
    b = np.array([0.0, 0.0, 0.0])
    blended = complementary_filter(a, b, alpha=0.9)
    assert np.allclose(blended, [0.9, 0.9, 0.9])


def test_robot_state_estimator_produces_consistent_state(robot):
    estimator = RobotStateEstimator(robot, dt=0.01)
    estimator.sync_true_positions(robot.home_position())
    for _ in range(20):
        estimator.sync_true_positions(robot.home_position())
        state = estimator.estimate_robot_state()

    assert np.allclose(state.joint_state.position, robot.home_position(), atol=1e-2)
    assert state.tcp_pose.distance_to(robot.forward_kinematics(robot.home_position())) < 0.05
