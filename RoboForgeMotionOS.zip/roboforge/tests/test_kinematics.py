"""Forward/inverse kinematics tests (section 43)."""

import numpy as np

from roboforge.core.enums import IKMethod


def test_forward_kinematics_at_home_is_reproducible(robot):
    q = robot.home_position()
    pose1 = robot.forward_kinematics(q)
    pose2 = robot.forward_kinematics(q)
    assert np.allclose(pose1.position, pose2.position)
    assert np.allclose(pose1.rotation, pose2.rotation)


def test_forward_kinematics_changes_with_joints(robot):
    q0 = robot.home_position()
    q1 = q0.copy()
    q1[0] += 0.5
    p0 = robot.forward_kinematics(q0)
    p1 = robot.forward_kinematics(q1)
    assert p0.distance_to(p1) > 1e-3


def test_inverse_kinematics_converges_to_forward_kinematics(robot):
    q_true = robot.home_position() + np.array([0.1, -0.1, 0.05, 0.0, 0.05, -0.1])
    q_true = robot.clamp_joint_positions(q_true)
    target = robot.forward_kinematics(q_true)

    result = robot.inverse_kinematics(target, initial_guess=robot.home_position())
    assert result.success
    achieved = robot.forward_kinematics(result.joint_positions)
    assert achieved.distance_to(target) < 1e-3
    assert achieved.angular_distance_to(target) < 1e-2


def test_inverse_kinematics_respects_joint_limits(robot):
    target = robot.forward_kinematics(robot.home_position())
    result = robot.inverse_kinematics(target, initial_guess=robot.home_position())
    assert result.success
    for joint, q in zip(robot.joints, result.joint_positions):
        assert joint.limits.min_position - 1e-6 <= q <= joint.limits.max_position + 1e-6


def test_inverse_kinematics_jacobian_transpose_runs(robot):
    target = robot.forward_kinematics(robot.home_position())
    result = robot.inverse_kinematics(
        target, initial_guess=robot.home_position(), method=IKMethod.JACOBIAN_TRANSPOSE, max_iterations=500
    )
    # Jacobian-transpose is lower fidelity; just check it makes meaningful progress.
    assert result.position_error < 0.05


def test_unreachable_pose_reports_failure(robot):
    from roboforge.core.transforms import Pose

    far_away = Pose(np.array([100.0, 100.0, 100.0]), np.eye(3))
    result = robot.inverse_kinematics(far_away, initial_guess=robot.home_position(), max_iterations=50)
    assert not result.success
