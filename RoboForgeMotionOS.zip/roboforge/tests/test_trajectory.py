"""Trajectory generation and optimisation tests (section 43)."""

import numpy as np
import pytest

from roboforge.core.exceptions import TrajectoryError
from roboforge.motion.optimisation.trajectory_optimizer import TrajectoryOptimizer, compute_trajectory_metrics
from roboforge.motion.trajectory.cartesian_trajectory import generate_linear_cartesian_trajectory
from roboforge.motion.trajectory.joint_trajectory import generate_joint_trajectory
from roboforge.motion.trajectory.profiles import quintic_scalar_profile, trapezoidal_scalar_profile
from roboforge.core.transforms import Pose


def test_quintic_profile_boundary_conditions():
    profile = quintic_scalar_profile(0.0, 1.0, duration=2.0, dt=0.01)
    assert np.isclose(profile.q[0], 0.0, atol=1e-9)
    assert np.isclose(profile.q[-1], 1.0, atol=1e-6)
    assert np.isclose(profile.qd[0], 0.0, atol=1e-9)
    assert np.isclose(profile.qd[-1], 0.0, atol=1e-6)
    assert np.isclose(profile.qdd[0], 0.0, atol=1e-9)
    assert np.isclose(profile.qdd[-1], 0.0, atol=1e-6)


def test_trapezoidal_profile_reaches_target_distance():
    profile = trapezoidal_scalar_profile(distance=1.0, max_velocity=0.5, max_acceleration=1.0, dt=0.01)
    assert np.isclose(profile.q[-1], 1.0, atol=1e-3)
    assert profile.peak_velocity <= 0.5 + 1e-6


def test_joint_trajectory_respects_limits(robot):
    q0 = robot.home_position()
    q1 = robot.clamp_joint_positions(q0 + 0.4)
    trajectory = generate_joint_trajectory(robot, q0, q1)

    max_v = trajectory.max_velocity()
    max_a = trajectory.max_acceleration()
    for joint, v, a in zip(robot.joints, max_v, max_a):
        assert v <= joint.limits.max_velocity + 1e-6
        assert a <= joint.limits.max_acceleration + 1e-6

    assert np.allclose(trajectory.points[0].position, q0, atol=1e-6)
    assert np.allclose(trajectory.points[-1].position, q1, atol=1e-3)


def test_joint_trajectory_zero_length_move_is_trivial(robot):
    q0 = robot.home_position()
    trajectory = generate_joint_trajectory(robot, q0, q0)
    assert trajectory.duration >= 0
    assert np.allclose(trajectory.points[-1].position, q0, atol=1e-6)


def test_cartesian_linear_trajectory_endpoints(robot):
    start = robot.forward_kinematics(robot.home_position())
    end = Pose(start.position + np.array([0.05, 0.0, 0.0]), start.rotation)
    trajectory = generate_linear_cartesian_trajectory(start, end, dt=0.01)

    assert trajectory.points[0].pose.distance_to(start) < 1e-6
    assert trajectory.points[-1].pose.distance_to(end) < 1e-6


def test_trajectory_optimizer_minimum_time_prefers_shorter_duration(robot):
    q0 = robot.home_position()
    q1 = robot.clamp_joint_positions(q0 + 0.3)
    trajectory = generate_joint_trajectory(robot, q0, q1)

    optimizer = TrajectoryOptimizer(robot)
    fast_traj, fast_metrics = optimizer.optimise(trajectory, ["minimum_time"], scale_range=(0.5, 2.0), n_candidates=6)
    slow_traj, slow_metrics = optimizer.optimise(trajectory, ["minimum_jerk"], scale_range=(0.5, 2.0), n_candidates=6)

    assert fast_metrics.execution_time <= slow_metrics.execution_time + 1e-6


def test_compute_trajectory_metrics_nonnegative(robot):
    q0 = robot.home_position()
    q1 = robot.clamp_joint_positions(q0 + 0.3)
    trajectory = generate_joint_trajectory(robot, q0, q1)
    metrics = compute_trajectory_metrics(robot, trajectory)
    assert metrics.execution_time > 0
    assert metrics.peak_velocity >= 0
    assert metrics.energy_estimate_j >= 0
