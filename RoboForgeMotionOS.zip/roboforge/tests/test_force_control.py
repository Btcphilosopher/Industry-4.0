"""Force/impedance control and contact-rich manipulation tests (section 43)."""

import numpy as np

from roboforge.manipulation.contact.force_control import ForceController
from roboforge.manipulation.contact.impedance_control import AdmittanceController, ImpedanceController
from roboforge.manipulation.insertion.insertion_controller import InsertionController
from roboforge.simulation.physics_engine import PegHoleContactModel


def test_force_controller_drives_velocity_toward_target(robot):
    controller = ForceController(robot)
    controller.set_force_target(np.array([0, 0, 20.0]))
    qd = controller.compute_velocity_command(measured_force=np.zeros(3))
    assert qd.shape == (robot.dof,)
    assert np.any(np.abs(qd) > 0)


def test_force_controller_zero_error_gives_near_zero_command(robot):
    controller = ForceController(robot)
    controller.set_force_target(np.array([0, 0, 20.0]))
    qd = controller.compute_velocity_command(measured_force=np.array([0, 0, 20.0]))
    assert np.allclose(qd, 0, atol=1e-3)


def test_impedance_controller_returns_valid_command(robot):
    controller = ImpedanceController(robot)
    controller.set_impedance(stiffness=np.full(6, 500.0), damping=np.full(6, 50.0))
    target = robot.forward_kinematics(robot.home_position())
    qd = controller.compute_velocity_command(target, measured_wrench=np.array([0, 0, 5, 0, 0, 0]))
    assert qd.shape == (robot.dof,)


def test_admittance_controller_deflects_under_force(robot):
    controller = AdmittanceController(robot)
    target = robot.forward_kinematics(robot.home_position())
    deflected = controller.step(target, measured_wrench=np.array([0, 0, 10, 0, 0, 0]), dt=0.01)
    assert deflected.distance_to(target) >= 0


def test_peg_hole_contact_model_generates_resistance_when_misaligned():
    target = None
    from roboforge.core.transforms import Pose

    target = Pose(np.array([0, 0, 0]), np.eye(3))
    model = PegHoleContactModel(target, np.array([0, 0, 1.0]), hole_depth_m=0.01)

    aligned = Pose(np.array([0, 0, 0.005]), np.eye(3))
    misaligned = Pose(np.array([0.002, 0, 0.005]), np.eye(3))

    f_aligned = model.compute_force(aligned)
    f_misaligned = model.compute_force(misaligned)
    assert np.linalg.norm(f_misaligned) > np.linalg.norm(f_aligned)


def test_peg_hole_contact_model_resists_bottoming_out():
    from roboforge.core.transforms import Pose

    target = Pose(np.array([0, 0, 0]), np.eye(3))
    model = PegHoleContactModel(target, np.array([0, 0, 1.0]), hole_depth_m=0.01)
    past_bottom = Pose(np.array([0, 0, 0.02]), np.eye(3))
    force = model.compute_force(past_bottom)
    assert force[2] < 0  # resists further downward motion


def test_insertion_controller_completes_aligned_insertion(robot):
    from roboforge.core.transforms import Pose

    target = robot.forward_kinematics(robot.home_position())
    contact_model = PegHoleContactModel(target, np.array([0, 0, 1.0]), hole_depth_m=0.01)
    controller = InsertionController(robot)
    result = controller.insert(
        target, np.array([0, 0, 1.0]), insertion_depth_m=0.01,
        force_sensor_fn=contact_model.compute_force,
    )
    assert result.success
    assert np.isclose(result.depth_reached_m, 0.01, atol=1e-6)


def test_insertion_controller_aborts_on_excessive_force(robot):
    from roboforge.core.transforms import Pose

    target = robot.forward_kinematics(robot.home_position())
    controller = InsertionController(robot)
    result = controller.insert(
        target, np.array([0, 0, 1.0]), insertion_depth_m=0.01,
        force_sensor_fn=lambda pose: np.array([0, 0, 100.0]),  # jammed
        max_force_n=40.0,
    )
    assert not result.success
    assert result.aborted_reason == "max_force_exceeded"
