"""Multi-robot coordination tests (section 43)."""

import numpy as np

from roboforge.cli.context import DEFAULT_CONFIG
from roboforge.collision.collision_engine import CollisionEngine
from roboforge.configuration.loader import load_and_build_robot
from roboforge.coordination.multi_robot_coordinator import MultiRobotCoordinator, SharedObjectRegistry
from roboforge.coordination.workspace_reservation import ReservationManager
from roboforge.core.exceptions import CoordinationError
from roboforge.core.transforms import Pose


def _load_second_robot(offset_x: float, new_id: str):
    r = load_and_build_robot(DEFAULT_CONFIG)
    r.robot_id = new_id
    r.base_pose = Pose(np.array([offset_x, 0.0, 0.0]), np.eye(3))
    r.joint_state.position = r.home_position().copy()
    return r


def test_robots_far_apart_do_not_collide():
    robot_a = load_and_build_robot(DEFAULT_CONFIG)
    robot_a.joint_state.position = robot_a.home_position().copy()
    robot_b = _load_second_robot(3.0, "robot_b")

    coordinator = MultiRobotCoordinator()
    coordinator.register_robot(robot_a, CollisionEngine(robot_a))
    coordinator.register_robot(robot_b, CollisionEngine(robot_b))

    report = coordinator.check_robot_robot_collision(
        robot_a.robot_id, robot_a.home_position(), robot_b.robot_id, robot_b.home_position()
    )
    assert not report.in_collision


def test_robots_overlapping_bases_collide():
    robot_a = load_and_build_robot(DEFAULT_CONFIG)
    robot_a.joint_state.position = robot_a.home_position().copy()
    robot_b = _load_second_robot(0.0, "robot_b")  # same base position -> guaranteed overlap

    coordinator = MultiRobotCoordinator()
    coordinator.register_robot(robot_a, CollisionEngine(robot_a))
    coordinator.register_robot(robot_b, CollisionEngine(robot_b))

    report = coordinator.check_robot_robot_collision(
        robot_a.robot_id, robot_a.home_position(), robot_b.robot_id, robot_b.home_position(), safety_margin=0.02
    )
    assert report.in_collision


def test_shared_object_registry_prevents_double_ownership():
    registry = SharedObjectRegistry()
    registry.acquire("part_1", "robot_a")
    try:
        registry.acquire("part_1", "robot_b")
        assert False, "expected CoordinationError"
    except CoordinationError:
        pass
    registry.transfer("part_1", "robot_a", "robot_b")
    assert registry.owner_of("part_1") == "robot_b"


def test_workspace_reservation_conflict_detected():
    manager = ReservationManager()
    manager.request("robot_a", np.array([0, 0, 0.5]), 0.3, start_time=0.0, end_time=2.0, label="pick")
    try:
        manager.request("robot_b", np.array([0.1, 0, 0.5]), 0.3, start_time=1.0, end_time=3.0, label="place")
        assert False, "expected CoordinationError"
    except CoordinationError:
        pass


def test_workspace_reservation_no_conflict_when_disjoint_in_time():
    manager = ReservationManager()
    manager.request("robot_a", np.array([0, 0, 0.5]), 0.3, start_time=0.0, end_time=1.0)
    # Should not raise -- same region, later time window.
    manager.request("robot_b", np.array([0, 0, 0.5]), 0.3, start_time=1.5, end_time=2.5)


def test_synchronise_trajectories_equalises_duration(robot):
    from roboforge.motion.trajectory.joint_trajectory import generate_joint_trajectory

    q0 = robot.home_position()
    short_traj = generate_joint_trajectory(robot, q0, robot.clamp_joint_positions(q0 + 0.1))
    long_traj = generate_joint_trajectory(robot, q0, robot.clamp_joint_positions(q0 + 0.5))

    coordinator = MultiRobotCoordinator()
    synced = coordinator.synchronise_trajectories({"a": short_traj, "b": long_traj})
    assert np.isclose(synced["a"].duration, synced["b"].duration, atol=1e-3)
