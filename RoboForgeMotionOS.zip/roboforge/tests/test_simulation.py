"""Deterministic simulation tests (section 43-44)."""

import numpy as np

from roboforge.motion.trajectory.joint_trajectory import generate_joint_trajectory
from roboforge.robotics.dynamics.dynamics_model import DynamicsModel
from roboforge.simulation.physics_engine import PhysicsEngine
from roboforge.simulation.simulated_robot import SimulatedRobot
from roboforge.simulation.world import SimulationWorld


def test_simulated_robot_executes_trajectory_deterministically(robot):
    q0 = robot.home_position()
    q1 = robot.clamp_joint_positions(q0 + 0.2)
    trajectory = generate_joint_trajectory(robot, q0, q1)

    sim_robot = SimulatedRobot(robot, tracking_noise_std=0.0)
    result = sim_robot.execute_trajectory(trajectory)

    assert result.success
    assert np.allclose(robot.joint_state.position, q1, atol=1e-6)


def test_simulated_robot_is_reproducible_with_fixed_seed(robot):
    q0 = robot.home_position()
    q1 = robot.clamp_joint_positions(q0 + 0.3)
    trajectory = generate_joint_trajectory(robot, q0, q1)

    sim1 = SimulatedRobot(robot, tracking_noise_std=1e-4, rng=np.random.default_rng(7))
    sim1.execute_trajectory(trajectory)
    final1 = robot.joint_state.position.copy()

    robot.joint_state.position = q0.copy()
    sim2 = SimulatedRobot(robot, tracking_noise_std=1e-4, rng=np.random.default_rng(7))
    sim2.execute_trajectory(trajectory)
    final2 = robot.joint_state.position.copy()

    assert np.allclose(final1, final2)


def test_physics_engine_gravity_compensated_torque_holds_position(robot):
    world = SimulationWorld()
    engine = PhysicsEngine(robot, world, dt=0.001)
    q = robot.home_position()
    robot.joint_state.position = q.copy()
    robot.joint_state.velocity = np.zeros(robot.dof)

    dm = DynamicsModel(robot)
    tau_gravity = dm.gravity_vector(q)

    for _ in range(50):
        engine.step(tau_gravity)

    # Under exact gravity compensation the joints should barely drift.
    assert np.allclose(robot.joint_state.position, q, atol=0.05)


def test_physics_engine_respects_joint_limits(robot):
    world = SimulationWorld()
    engine = PhysicsEngine(robot, world, dt=0.01)
    huge_torque = np.full(robot.dof, 1e6)
    for _ in range(20):
        state = engine.step(huge_torque)
    for joint, q in zip(robot.joints, state.position):
        assert joint.limits.min_position - 1e-6 <= q <= joint.limits.max_position + 1e-6
