"""FastAPI service tests (section 43)."""

import pytest

fastapi_testclient = pytest.importorskip("fastapi.testclient")

from roboforge.api.main import build_default_robot_context, create_app


@pytest.fixture
def client():
    ctx = build_default_robot_context()
    app = create_app([ctx])
    return fastapi_testclient.TestClient(app), ctx


def test_list_robots(client):
    test_client, ctx = client
    r = test_client.get("/robots")
    assert r.status_code == 200
    body = r.json()
    assert body[0]["robot_id"] == ctx.robot.robot_id


def test_get_robot_state(client):
    test_client, ctx = client
    r = test_client.get(f"/robots/{ctx.robot.robot_id}/state")
    assert r.status_code == 200
    assert "tcp_pose" in r.json()


def test_get_robot_pose_and_joints(client):
    test_client, ctx = client
    r_pose = test_client.get(f"/robots/{ctx.robot.robot_id}/pose")
    r_joints = test_client.get(f"/robots/{ctx.robot.robot_id}/joints")
    assert r_pose.status_code == 200
    assert r_joints.status_code == 200
    assert len(r_joints.json()["position"]) == ctx.robot.dof


def test_move_requires_authentication(client):
    test_client, ctx = client
    r = test_client.post(
        f"/robots/{ctx.robot.robot_id}/move", json={"target_positions": ctx.robot.home_position().tolist()}
    )
    assert r.status_code == 401


def test_move_with_readonly_token_forbidden(client):
    test_client, ctx = client
    r = test_client.post(
        f"/robots/{ctx.robot.robot_id}/move",
        json={"target_positions": ctx.robot.home_position().tolist()},
        headers={"X-API-Key": "demo-readonly-token"},
    )
    assert r.status_code == 403


def test_move_with_operator_token_succeeds(client):
    test_client, ctx = client
    target = ctx.robot.clamp_joint_positions(ctx.robot.home_position() + 0.1)
    r = test_client.post(
        f"/robots/{ctx.robot.robot_id}/move",
        json={"target_positions": target.tolist()},
        headers={"X-API-Key": "demo-operator-token"},
    )
    assert r.status_code == 200
    assert r.json()["accepted"] is True


def test_unknown_robot_returns_404(client):
    test_client, _ = client
    r = test_client.get("/robots/does_not_exist/state")
    assert r.status_code == 404


def test_gripper_endpoint(client):
    test_client, ctx = client
    r = test_client.post(
        f"/robots/{ctx.robot.robot_id}/gripper",
        json={"action": "close", "object_width_m": 0.03},
        headers={"X-API-Key": "demo-operator-token"},
    )
    assert r.status_code == 200
    assert r.json()["accepted"] is True


def test_health_endpoint(client):
    test_client, _ = client
    r = test_client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"
