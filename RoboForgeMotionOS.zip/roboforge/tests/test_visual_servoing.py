"""Perception and visual-servoing tests (section 43)."""

import numpy as np

from roboforge.core.transforms import Pose, euler_to_rotation_matrix
from roboforge.perception.cameras.camera import CameraExtrinsics, CameraIntrinsics, MountingKind
from roboforge.perception.cameras.simulated_camera import SimulatedCamera, SimulatedSceneObject
from roboforge.perception.pose.pose_estimator import PoseEstimator
from roboforge.perception.tracking.object_tracker import ObjectTracker
from roboforge.perception.vision.object_detector import SimulatedObjectDetector
from roboforge.perception.visual_servoing import VisualServoController, VisualServoMode


def _downward_camera(position):
    intrinsics = CameraIntrinsics(fx=800, fy=800, cx=320, cy=240, width=640, height=480)
    pose = Pose(np.array(position), euler_to_rotation_matrix([np.pi, 0, 0]))
    extrinsics = CameraExtrinsics(pose=pose, mounting=MountingKind.EYE_TO_HAND)
    return SimulatedCamera("cam1", intrinsics, extrinsics)


def test_pose_estimator_detects_known_object():
    camera = _downward_camera([0.3, 0.0, 0.8])
    camera.add_object(SimulatedSceneObject("comp_42", "widget", Pose(np.array([0.3, 0.0, 0.2]), np.eye(3))))
    estimator = PoseEstimator(camera, SimulatedObjectDetector())

    result = estimator.detect_pose("comp_42")
    assert result is not None
    assert np.allclose(result.pose_world.position, [0.3, 0.0, 0.2], atol=0.01)
    assert 0 < result.confidence <= 1.0


def test_pose_estimator_ignores_out_of_range_objects():
    camera = _downward_camera([0.0, 0.0, 0.1])
    camera.add_object(SimulatedSceneObject("far_object", "widget", Pose(np.array([0, 0, -5.0]), np.eye(3))))
    estimator = PoseEstimator(camera, SimulatedObjectDetector())
    assert estimator.detect_pose("far_object") is None


def test_object_tracker_smooths_noisy_observations(rng):
    tracker = ObjectTracker(smoothing_alpha=0.3)
    from roboforge.perception.pose.pose_estimator import ObjectPose

    base = np.array([0.3, 0.0, 0.2])
    for _ in range(20):
        noisy = base + rng.normal(0, 0.01, size=3)
        obs = ObjectPose("obj", "widget", Pose(noisy, np.eye(3)), confidence=0.8)
        tracks = tracker.update([obs])

    tracked = tracker.get("obj")
    assert tracked is not None
    assert np.linalg.norm(tracked.pose_world.position - base) < 0.02


def test_visual_servo_step_converges_toward_object(robot_with_tool):
    tcp = robot_with_tool.forward_kinematics(robot_with_tool.home_position())
    camera = _downward_camera([tcp.position[0], tcp.position[1], tcp.position[2] + 0.5])
    slightly_off = tcp.position + np.array([0.01, 0.0, 0.0])
    camera.add_object(SimulatedSceneObject("target_obj", "widget", Pose(slightly_off, tcp.rotation)))

    estimator = PoseEstimator(camera, SimulatedObjectDetector(position_noise_std_m=1e-6, orientation_noise_std_rad=1e-6))
    servo = VisualServoController(robot_with_tool, estimator, position_tolerance_m=1e-4)

    step = servo.step("target_obj", mode=VisualServoMode.POSITION_BASED)
    assert step.joint_velocity.shape == (robot_with_tool.dof,)
    assert step.position_error_m < 0.02
