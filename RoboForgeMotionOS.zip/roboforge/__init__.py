"""
RoboForge Motion.OS
====================

A modular, production-oriented software platform for industrial robotic
arms, precision manipulators, and coordinated multi-arm manipulation.

This package is deliberately NOT a humanoid robotics platform. There is no
walking, leg, balance, or bipedal-locomotion code anywhere in this tree.
Everything here is organised around a single idea:

    Sense -> Localise -> Plan -> Move -> Manipulate -> Verify -> Correct

See ``README.md`` at the repository root for an architecture overview.
"""

__version__ = "0.1.0"
