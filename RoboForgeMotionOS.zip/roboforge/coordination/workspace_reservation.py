"""Workspace reservation (section 22): robots reserve a spherical region
of shared workspace for a time window before entering it, so two robots
never plan overlapping motions into the same volume at the same time
without an explicit conflict check.
"""

from __future__ import annotations

import time
from dataclasses import dataclass

import numpy as np

from roboforge.core.exceptions import CoordinationError


@dataclass
class WorkspaceReservation:
    robot_id: str
    centre: np.ndarray
    radius_m: float
    start_time: float
    end_time: float
    label: str = ""


class ReservationManager:
    def __init__(self) -> None:
        self._reservations: list[WorkspaceReservation] = []

    def _overlaps(self, a: WorkspaceReservation, b: WorkspaceReservation) -> bool:
        time_overlap = a.start_time < b.end_time and b.start_time < a.end_time
        if not time_overlap:
            return False
        distance = float(np.linalg.norm(a.centre - b.centre))
        return distance < (a.radius_m + b.radius_m)

    def request(
        self, robot_id: str, centre: np.ndarray, radius_m: float,
        start_time: float | None = None, end_time: float | None = None, label: str = "",
    ) -> WorkspaceReservation:
        start_time = time.time() if start_time is None else start_time
        end_time = start_time + 5.0 if end_time is None else end_time
        candidate = WorkspaceReservation(robot_id, np.asarray(centre, dtype=float), radius_m, start_time, end_time, label)

        for existing in self._reservations:
            if existing.robot_id == robot_id:
                continue
            if self._overlaps(candidate, existing):
                raise CoordinationError(
                    f"Workspace reservation conflict: {robot_id!r} request overlaps {existing.robot_id!r}'s "
                    f"reservation {existing.label or ''!r} in [{existing.start_time:.2f}, {existing.end_time:.2f}]"
                )

        self._reservations.append(candidate)
        return candidate

    def release(self, robot_id: str, label: str | None = None) -> None:
        self._reservations = [
            r for r in self._reservations
            if not (r.robot_id == robot_id and (label is None or r.label == label))
        ]

    def active_reservations(self, at_time: float | None = None) -> list[WorkspaceReservation]:
        at_time = time.time() if at_time is None else at_time
        return [r for r in self._reservations if r.start_time <= at_time <= r.end_time]
