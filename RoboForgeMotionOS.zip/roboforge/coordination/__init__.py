"""Multi-robot coordination (section 22): workspace reservation,
robot-robot collision prediction, shared-object ownership, and
synchronised multi-robot motion."""

from roboforge.coordination.workspace_reservation import ReservationManager, WorkspaceReservation
from roboforge.coordination.multi_robot_coordinator import MultiRobotCoordinator, SharedObjectRegistry

__all__ = [
    "ReservationManager",
    "WorkspaceReservation",
    "MultiRobotCoordinator",
    "SharedObjectRegistry",
]
