"""The multi-robot coordinator (section 22-23): robot-robot collision
prediction, trajectory-conflict checking, shared-object ownership, and
trajectory-duration synchronisation for coordinated multi-arm motion
(e.g. "Robot A holds, Robot B fastens, Robot C inspects").
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np

from roboforge.collision.shapes import capsule_capsule_distance
from roboforge.core.exceptions import CoordinationError
from roboforge.motion.optimisation.trajectory_optimizer import time_scale_trajectory

if TYPE_CHECKING:
    from roboforge.collision.collision_engine import CollisionEngine
    from roboforge.motion.trajectory.joint_trajectory import JointTrajectory
    from roboforge.robotics.robot import Robot


@dataclass
class RobotRobotCollisionReport:
    in_collision: bool
    min_clearance: float
    worst_pair: tuple[str, str] | None = None


class SharedObjectRegistry:
    """Tracks which robot currently "owns" (is holding/responsible for) a
    shared workpiece, so a second robot can't be commanded to grasp
    something another robot already has."""

    def __init__(self) -> None:
        self._owners: dict[str, str] = {}

    def acquire(self, object_id: str, robot_id: str) -> None:
        current = self._owners.get(object_id)
        if current is not None and current != robot_id:
            raise CoordinationError(f"Object {object_id!r} is already owned by robot {current!r}")
        self._owners[object_id] = robot_id

    def release(self, object_id: str, robot_id: str) -> None:
        current = self._owners.get(object_id)
        if current is not None and current != robot_id:
            raise CoordinationError(
                f"Robot {robot_id!r} cannot release object {object_id!r}: it is owned by {current!r}"
            )
        self._owners.pop(object_id, None)

    def transfer(self, object_id: str, from_robot_id: str, to_robot_id: str) -> None:
        self.release(object_id, from_robot_id)
        self.acquire(object_id, to_robot_id)

    def owner_of(self, object_id: str) -> str | None:
        return self._owners.get(object_id)


class MultiRobotCoordinator:
    def __init__(self) -> None:
        self.robots: dict[str, "Robot"] = {}
        self.collision_engines: dict[str, "CollisionEngine"] = {}
        self.shared_objects = SharedObjectRegistry()

    def register_robot(self, robot: "Robot", collision_engine: "CollisionEngine") -> None:
        self.robots[robot.robot_id] = robot
        self.collision_engines[robot.robot_id] = collision_engine

    def check_robot_robot_collision(
        self, robot_id_a: str, q_a: np.ndarray, robot_id_b: str, q_b: np.ndarray, safety_margin: float = 0.02
    ) -> RobotRobotCollisionReport:
        engine_a = self.collision_engines[robot_id_a]
        engine_b = self.collision_engines[robot_id_b]
        capsules_a = engine_a.link_capsules(q_a)
        capsules_b = engine_b.link_capsules(q_b)

        min_clearance = float("inf")
        worst_pair = None
        for i, (a0, a1, ra) in enumerate(capsules_a):
            for j, (b0, b1, rb) in enumerate(capsules_b):
                d = capsule_capsule_distance(a0, a1, ra, b0, b1, rb)
                if d < min_clearance:
                    min_clearance = d
                    worst_pair = (f"{robot_id_a}:link_{i}", f"{robot_id_b}:link_{j}")

        return RobotRobotCollisionReport(
            in_collision=min_clearance < safety_margin, min_clearance=min_clearance, worst_pair=worst_pair
        )

    def predict_trajectory_conflict(
        self,
        robot_id_a: str,
        trajectory_a: "JointTrajectory",
        robot_id_b: str,
        trajectory_b: "JointTrajectory",
        safety_margin: float = 0.02,
        n_samples: int = 50,
    ) -> RobotRobotCollisionReport:
        """Sample both trajectories (assumed to start simultaneously) over
        their shared time span and check for robot-robot collision at
        each sampled instant -- a discrete-time conflict check, not a
        continuous-time sweep, so very fast relative motion between two
        robots could in principle pass through a conflict between
        samples; keep ``n_samples`` generous relative to trajectory speed.
        """
        duration = min(trajectory_a.duration, trajectory_b.duration)
        worst_clearance = float("inf")
        worst_pair = None
        collided = False
        for t in np.linspace(0, duration, n_samples):
            q_a = trajectory_a.sample(t).position
            q_b = trajectory_b.sample(t).position
            report = self.check_robot_robot_collision(robot_id_a, q_a, robot_id_b, q_b, safety_margin)
            if report.min_clearance < worst_clearance:
                worst_clearance = report.min_clearance
                worst_pair = report.worst_pair
            if report.in_collision:
                collided = True

        return RobotRobotCollisionReport(in_collision=collided, min_clearance=worst_clearance, worst_pair=worst_pair)

    def synchronise_trajectories(
        self, trajectories: dict[str, "JointTrajectory"]
    ) -> dict[str, "JointTrajectory"]:
        """Time-scale every robot's trajectory to the longest one's
        duration, so a coordinated multi-arm move (e.g. simultaneous
        approach for a handoff) finishes for all robots at once."""
        if not trajectories:
            return {}
        max_duration = max(t.duration for t in trajectories.values())
        synced = {}
        for robot_id, traj in trajectories.items():
            if traj.duration < 1e-9:
                synced[robot_id] = traj
                continue
            scale = max_duration / traj.duration
            synced[robot_id] = time_scale_trajectory(traj, scale)
        return synced
