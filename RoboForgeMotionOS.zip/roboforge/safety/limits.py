"""Independent software safety limit checks (section 33): joint,
velocity, acceleration, and workspace limits. These are deliberately
kept as small, pure, exception-raising functions with no dependency on
the optimisation/planning/AI layers, so that no amount of clever
trajectory optimisation or AI suggestion can route around them --
callers (drivers, the API, the safety state machine) must call these on
every commanded motion.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from roboforge.core.exceptions import JointLimitError, WorkspaceLimitError

if TYPE_CHECKING:
    from roboforge.robotics.robot import Robot


def validate_joint_command(
    robot: "Robot",
    q: np.ndarray,
    qd: np.ndarray | None = None,
    qdd: np.ndarray | None = None,
    tau: np.ndarray | None = None,
) -> None:
    robot.validate_joint_positions(np.asarray(q, dtype=float))
    if qd is not None:
        robot.validate_joint_velocities(np.asarray(qd, dtype=float))
    if qdd is not None:
        scale = robot.motion_constraints.acceleration_scale
        for joint, a in zip(robot.joints, np.asarray(qdd, dtype=float)):
            joint.limits.validate_acceleration(a / max(scale, 1e-6), joint.name)
    if tau is not None:
        for joint, t in zip(robot.joints, np.asarray(tau, dtype=float)):
            joint.limits.validate_torque(t, joint.name)


def validate_workspace_target(robot: "Robot", position: np.ndarray) -> None:
    position = np.asarray(position, dtype=float)
    if not robot.workspace.contains(position):
        raise WorkspaceLimitError(
            f"Target position {position.tolist()} is outside robot {robot.name!r}'s configured workspace"
        )
