"""The robot motion state machine and safety supervisor (sections 32-33).

State transitions are explicit and validated -- an illegal transition
(e.g. commanding a move while ``FAULT``) raises rather than silently
proceeding. Trajectory validation runs joint/velocity/acceleration/torque
limit checks and, if a collision engine is supplied, a full-trajectory
collision sweep, before a trajectory is allowed to reach the hardware
execution pipeline (section 28: sim-to-real validation gate).

IMPORTANT: this is a *software* safety layer. It does not replace, and
must never be represented as replacing, a certified safety PLC,
emergency-stop circuit, light curtain, safety-rated scanner, physical
guarding, or the robot manufacturer's own safety controller. Those
systems are the actual protection against harm; this module is a
defence-in-depth layer for command-level correctness and must fail
closed (refuse the command) whenever it cannot verify safety.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np

from roboforge.core.enums import MotionState, SafetyLevel
from roboforge.core.exceptions import SafetyViolationError
from roboforge.safety.limits import validate_joint_command, validate_workspace_target
from roboforge.safety.watchdog import Watchdog

if TYPE_CHECKING:
    from roboforge.collision.collision_engine import CollisionEngine
    from roboforge.motion.trajectory.joint_trajectory import JointTrajectory
    from roboforge.robotics.robot import Robot

ALLOWED_TRANSITIONS: dict[MotionState, set[MotionState]] = {
    MotionState.DISCONNECTED: {MotionState.INITIALISING},
    MotionState.INITIALISING: {MotionState.READY, MotionState.FAULT, MotionState.DISCONNECTED},
    MotionState.READY: {MotionState.ENABLED, MotionState.DISCONNECTED, MotionState.MAINTENANCE, MotionState.FAULT},
    MotionState.ENABLED: {MotionState.MOVING, MotionState.PAUSED, MotionState.STOPPING, MotionState.FAULT, MotionState.READY},
    MotionState.MOVING: {MotionState.CONTACT, MotionState.PAUSED, MotionState.STOPPING, MotionState.FAULT},
    MotionState.CONTACT: {MotionState.MOVING, MotionState.STOPPING, MotionState.FAULT},
    MotionState.PAUSED: {MotionState.ENABLED, MotionState.MOVING, MotionState.STOPPING, MotionState.FAULT},
    MotionState.FAULT: {MotionState.STOPPING, MotionState.MAINTENANCE},
    MotionState.STOPPING: {MotionState.STOPPED},
    MotionState.STOPPED: {MotionState.INITIALISING, MotionState.MAINTENANCE, MotionState.DISCONNECTED},
    MotionState.MAINTENANCE: {MotionState.INITIALISING, MotionState.DISCONNECTED},
}


@dataclass
class TrajectoryValidationReport:
    valid: bool
    violations: list[str] = field(default_factory=list)
    min_collision_clearance: float | None = None


class SafetyStateMachine:
    def __init__(self, robot: "Robot", comm_timeout_s: float = 1.0) -> None:
        self.robot = robot
        self.watchdog = Watchdog(comm_timeout_s, on_timeout=self._on_comm_loss)
        self._fault_reason: str | None = None
        self.event_bus = None  # optionally wired up by higher-level orchestration

    # -- state transitions --------------------------------------------------
    def transition_to(self, new_state: MotionState, reason: str = "") -> None:
        current = self.robot.motion_state
        if new_state == current:
            return
        allowed = ALLOWED_TRANSITIONS.get(current, set())
        if new_state not in allowed:
            raise SafetyViolationError(
                f"Illegal motion-state transition: {current.value} -> {new_state.value} "
                f"(reason: {reason or 'unspecified'})"
            )
        self.robot.motion_state = new_state
        if new_state == MotionState.FAULT:
            self._fault_reason = reason

    def emergency_stop(self, reason: str = "emergency_stop") -> None:
        """Immediately drive to STOPPING/STOPPED regardless of the normal
        transition table -- an e-stop must always be reachable."""
        self.robot.safety_level = SafetyLevel.ESTOP
        self.robot.motion_state = MotionState.STOPPING
        self._fault_reason = reason
        self.robot.motion_state = MotionState.STOPPED

    def clear_fault(self) -> None:
        if self.robot.motion_state not in (MotionState.FAULT, MotionState.STOPPED):
            raise SafetyViolationError("clear_fault() is only valid from FAULT or STOPPED")
        self._fault_reason = None
        self.robot.safety_level = SafetyLevel.NORMAL
        self.transition_to(MotionState.INITIALISING, reason="fault_cleared")

    def _on_comm_loss(self) -> None:
        self.robot.safety_level = SafetyLevel.STOPPED
        try:
            self.transition_to(MotionState.FAULT, reason="communication_loss")
        except SafetyViolationError:
            pass  # already in a terminal state; nothing further to do

    # -- command validation ---------------------------------------------------
    def validate_motion_command(self, q_target: np.ndarray) -> None:
        if self.robot.motion_state in (MotionState.FAULT, MotionState.STOPPING, MotionState.STOPPED,
                                        MotionState.DISCONNECTED, MotionState.MAINTENANCE):
            raise SafetyViolationError(
                f"Cannot command motion while robot is in state {self.robot.motion_state.value}"
            )
        if self.robot.safety_level == SafetyLevel.ESTOP:
            raise SafetyViolationError("Cannot command motion: robot is in an emergency-stop state")
        validate_joint_command(self.robot, q_target)
        pose = self.robot.forward_kinematics(q_target)
        validate_workspace_target(self.robot, pose.position)

    def validate_trajectory(
        self,
        trajectory: "JointTrajectory",
        collision_engine: "CollisionEngine | None" = None,
        collision_safety_margin: float = 0.01,
    ) -> TrajectoryValidationReport:
        violations: list[str] = []
        min_clearance = None

        for point in trajectory.points:
            try:
                validate_joint_command(self.robot, point.position, point.velocity, point.acceleration)
            except Exception as exc:  # JointLimitError et al.
                violations.append(str(exc))
            try:
                pose = self.robot.forward_kinematics(point.position)
                validate_workspace_target(self.robot, pose.position)
            except Exception as exc:
                violations.append(str(exc))

        if collision_engine is not None:
            reports = collision_engine.check_trajectory(trajectory, collision_safety_margin)
            min_clearance = min((r.min_clearance for r in reports), default=None)
            for i, report in enumerate(reports):
                if report.in_collision:
                    violations.append(
                        f"Waypoint {i} violates collision safety margin (clearance={report.min_clearance:.4f} m)"
                    )

        # De-duplicate while preserving order, since limit checks repeat
        # the same violation message across many trajectory samples.
        seen = set()
        unique_violations = []
        for v in violations:
            if v not in seen:
                seen.add(v)
                unique_violations.append(v)

        return TrajectoryValidationReport(
            valid=len(unique_violations) == 0,
            violations=unique_violations,
            min_collision_clearance=min_clearance,
        )
