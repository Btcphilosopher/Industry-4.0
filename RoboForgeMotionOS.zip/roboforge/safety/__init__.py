"""Safety (section 33): independent of optimisation and AI. Implements
software-level joint/velocity/acceleration/workspace/collision limit
enforcement, watchdogs, and the motion state machine (section 32).

This module explicitly does **not** replace certified safety PLCs,
emergency-stop circuits, light curtains, safety-rated scanners, physical
guarding, or a manufacturer's own safety controller -- see
``SafetyStateMachine``'s docstring. The AI supervisory layer
(``roboforge`` has none enabled by default) must never be able to bypass
anything in this package.
"""

from roboforge.safety.limits import validate_joint_command, validate_workspace_target
from roboforge.safety.watchdog import Watchdog
from roboforge.safety.safety_state_machine import SafetyStateMachine, ALLOWED_TRANSITIONS

__all__ = [
    "validate_joint_command",
    "validate_workspace_target",
    "Watchdog",
    "SafetyStateMachine",
    "ALLOWED_TRANSITIONS",
]
