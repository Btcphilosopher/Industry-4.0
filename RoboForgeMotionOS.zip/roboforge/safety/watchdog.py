"""A communication/heartbeat watchdog (section 33): triggers a callback
(typically routed into the safety state machine's fault handling) if
``kick()`` is not called within ``timeout_s`` -- the software-level
analogue of a fieldbus/controller heartbeat timeout.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Callable


@dataclass
class Watchdog:
    timeout_s: float
    on_timeout: Callable[[], None] | None = None
    _last_kick: float = field(default_factory=time.time, init=False, repr=False)
    _tripped: bool = field(default=False, init=False)

    def kick(self) -> None:
        self._last_kick = time.time()
        self._tripped = False

    def check(self) -> bool:
        """Returns True if the watchdog is healthy (has been kicked
        within the timeout); calls ``on_timeout`` and returns False the
        first time it trips."""
        elapsed = time.time() - self._last_kick
        if elapsed > self.timeout_s:
            if not self._tripped:
                self._tripped = True
                if self.on_timeout is not None:
                    self.on_timeout()
            return False
        return True

    @property
    def tripped(self) -> bool:
        return self._tripped

    def reset(self) -> None:
        self.kick()
