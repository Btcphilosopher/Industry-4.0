"""The digital twin registry (section 26): a single place holding every
robot, tool, object, fixture, camera, and workspace the platform knows
about, plus the most recent simulated/real/planned state for each robot
so they can be compared and kept in sync."""

from roboforge.digital_twin.twin import DigitalTwin, StateComparison

__all__ = ["DigitalTwin", "StateComparison"]
