"""The digital twin (section 26): registers robots, tools, objects,
fixtures, cameras, and workspaces, and tracks the most recent
simulated/real/planned ``RobotState`` for each robot so they can be
compared -- e.g. to detect sim-to-real drift, or to show an operator
what the robot is about to do (planned) alongside where it actually is
(real/simulated).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING

import numpy as np

from roboforge.robotics.state.robot_state import RobotState

if TYPE_CHECKING:
    from roboforge.perception.cameras.camera import Camera
    from roboforge.robotics.robot import Robot
    from roboforge.robotics.tool import Tool


class StateSource(str, Enum):
    SIMULATED = "simulated"
    REAL = "real"
    PLANNED = "planned"


@dataclass
class StateComparison:
    robot_id: str
    position_deviation_m: float
    orientation_deviation_rad: float
    joint_deviation_max: float


class DigitalTwin:
    def __init__(self) -> None:
        self.robots: dict[str, "Robot"] = {}
        self.tools: dict[str, "Tool"] = {}
        self.cameras: dict[str, "Camera"] = {}
        self._states: dict[str, dict[StateSource, RobotState]] = {}

    # -- registration ---------------------------------------------------
    def register_robot(self, robot: "Robot") -> None:
        self.robots[robot.robot_id] = robot
        self._states.setdefault(robot.robot_id, {})

    def register_tool(self, tool: "Tool") -> None:
        self.tools[tool.name] = tool

    def register_camera(self, camera: "Camera") -> None:
        self.cameras[camera.name] = camera

    # -- state sync -------------------------------------------------------
    def sync_state(self, robot_id: str, source: StateSource, state: RobotState) -> None:
        self._states.setdefault(robot_id, {})[source] = state

    def get_state(self, robot_id: str, source: StateSource) -> RobotState | None:
        return self._states.get(robot_id, {}).get(source)

    def compare(self, robot_id: str, source_a: StateSource, source_b: StateSource) -> StateComparison | None:
        a = self.get_state(robot_id, source_a)
        b = self.get_state(robot_id, source_b)
        if a is None or b is None:
            return None
        position_dev = a.tcp_pose.distance_to(b.tcp_pose)
        orientation_dev = a.tcp_pose.angular_distance_to(b.tcp_pose)
        joint_dev = float(np.max(np.abs(a.joint_state.position - b.joint_state.position)))
        return StateComparison(robot_id, position_dev, orientation_dev, joint_dev)

    def all_robot_states(self, source: StateSource) -> dict[str, RobotState]:
        return {
            robot_id: states[source]
            for robot_id, states in self._states.items()
            if source in states
        }
