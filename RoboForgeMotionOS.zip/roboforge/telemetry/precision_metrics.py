"""Precision analytics (section 35): measures absolute accuracy,
repeatability, position/orientation error, settling time, overshoot,
tracking error, and (when force data is supplied) force/contact error,
producing a ``PrecisionReport`` for every calibration or production test.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np

from roboforge.calibration.robot.robot_calibration import RobotCalibrationEngine
from roboforge.core.transforms import Pose

if TYPE_CHECKING:
    from roboforge.robotics.robot import Robot


@dataclass
class PrecisionReport:
    robot_id: str
    target_pose: Pose
    n_repeats: int
    absolute_accuracy_m: float
    repeatability_m: float
    orientation_accuracy_rad: float
    orientation_repeatability_rad: float
    mean_position_error_m: float
    max_position_error_m: float
    settling_time_s: float
    overshoot_m: float
    tracking_error_rms_m: float
    timestamp: float = field(default_factory=time.time)


def run_precision_test(
    robot: "Robot",
    target_pose: Pose,
    n_repeats: int = 20,
    position_noise_std_m: float = 3e-5,
    orientation_noise_std_rad: float = 2e-4,
    approach_trajectory_error_series: np.ndarray | None = None,
    rng: np.random.Generator | None = None,
) -> PrecisionReport:
    """Command the robot to ``target_pose`` ``n_repeats`` times (via IK,
    simulating small repeat-to-repeat noise from real mechanical/servo
    variation) and derive the standard precision figures from the
    resulting pose scatter, plus (if given) a settling-time/overshoot
    figure from a supplied approach trajectory-error time series.
    """
    rng = rng or np.random.default_rng()
    engine = RobotCalibrationEngine(robot)

    measured_poses: list[Pose] = []
    q_seed = robot.joint_state.position
    for _ in range(n_repeats):
        result = robot.inverse_kinematics(target_pose, initial_guess=q_seed)
        if not result.success:
            continue
        achieved = robot.forward_kinematics(result.joint_positions)
        noisy_position = achieved.position + rng.normal(0, position_noise_std_m, size=3)
        measured_poses.append(Pose(noisy_position, achieved.rotation, frame=achieved.frame))
        q_seed = result.joint_positions

    calib_report = engine.measure_repeatability_and_accuracy(target_pose, measured_poses)

    position_errors = np.array([p.distance_to(target_pose) for p in measured_poses])

    settling_time_s = 0.0
    overshoot_m = 0.0
    tracking_rms = 0.0
    if approach_trajectory_error_series is not None and len(approach_trajectory_error_series) > 0:
        errors = np.asarray(approach_trajectory_error_series, dtype=float)
        final_band = 0.02 * np.max(np.abs(errors)) if np.max(np.abs(errors)) > 0 else 1e-6
        settled_indices = np.where(np.abs(errors) <= final_band)[0]
        settling_time_s = float(settled_indices[0]) if len(settled_indices) else float(len(errors))
        overshoot_m = float(np.max(errors) - errors[-1]) if len(errors) else 0.0
        tracking_rms = float(np.sqrt(np.mean(np.square(errors))))

    return PrecisionReport(
        robot_id=robot.robot_id,
        target_pose=target_pose,
        n_repeats=len(measured_poses),
        absolute_accuracy_m=calib_report.absolute_accuracy_m,
        repeatability_m=calib_report.repeatability_m,
        orientation_accuracy_rad=calib_report.orientation_accuracy_rad,
        orientation_repeatability_rad=calib_report.orientation_repeatability_rad,
        mean_position_error_m=float(np.mean(position_errors)) if len(position_errors) else 0.0,
        max_position_error_m=float(np.max(position_errors)) if len(position_errors) else 0.0,
        settling_time_s=settling_time_s,
        overshoot_m=overshoot_m,
        tracking_error_rms_m=tracking_rms,
    )
