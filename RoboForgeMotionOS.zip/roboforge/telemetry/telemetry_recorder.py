"""Records high-frequency robot telemetry (section 36) into a bounded
in-memory ring buffer, supporting both real-time streaming (subscribe a
callback) and historical analysis (query by time range).

A production deployment would back this with a time-series store
(``roboforge.storage``); the ring buffer here keeps the platform runnable
standalone while defining the exact interface a persistent backend would
implement.
"""

from __future__ import annotations

import time
from collections import deque
from dataclasses import dataclass, field
from typing import Callable

import numpy as np

from roboforge.robotics.state.robot_state import RobotState


@dataclass
class TelemetrySample:
    robot_id: str
    timestamp: float
    joint_position: np.ndarray
    joint_velocity: np.ndarray
    joint_acceleration: np.ndarray
    joint_torque: np.ndarray
    tcp_position: np.ndarray
    tcp_orientation_rpy: np.ndarray
    tcp_velocity: np.ndarray
    force: np.ndarray
    torque: np.ndarray
    trajectory_error: float
    motor_current: np.ndarray
    temperature: np.ndarray
    controller_state: str

    def as_dict(self) -> dict:
        return {
            "robot_id": self.robot_id,
            "timestamp": self.timestamp,
            "joint_position": self.joint_position.tolist(),
            "joint_velocity": self.joint_velocity.tolist(),
            "joint_acceleration": self.joint_acceleration.tolist(),
            "joint_torque": self.joint_torque.tolist(),
            "tcp_position": self.tcp_position.tolist(),
            "tcp_orientation_rpy": self.tcp_orientation_rpy.tolist(),
            "tcp_velocity": self.tcp_velocity.tolist(),
            "force": self.force.tolist(),
            "torque": self.torque.tolist(),
            "trajectory_error": self.trajectory_error,
            "motor_current": self.motor_current.tolist(),
            "temperature": self.temperature.tolist(),
            "controller_state": self.controller_state,
        }


class TelemetryRecorder:
    def __init__(self, max_samples: int = 20000) -> None:
        self._buffers: dict[str, deque[TelemetrySample]] = {}
        self.max_samples = max_samples
        self._subscribers: list[Callable[[TelemetrySample], None]] = []

    def subscribe(self, callback: Callable[[TelemetrySample], None]) -> None:
        self._subscribers.append(callback)

    def record_state(
        self,
        robot_state: RobotState,
        trajectory_error: float = 0.0,
        motor_current: np.ndarray | None = None,
        temperature: np.ndarray | None = None,
    ) -> TelemetrySample:
        dof = robot_state.joint_state.dof
        sample = TelemetrySample(
            robot_id=robot_state.robot_id,
            timestamp=robot_state.timestamp,
            joint_position=robot_state.joint_state.position.copy(),
            joint_velocity=robot_state.joint_state.velocity.copy(),
            joint_acceleration=robot_state.joint_state.acceleration.copy(),
            joint_torque=robot_state.joint_state.torque.copy(),
            tcp_position=robot_state.tcp_pose.position.copy(),
            tcp_orientation_rpy=np.array(robot_state.tcp_pose.as_euler()),
            tcp_velocity=robot_state.tcp_twist.as_vector(),
            force=robot_state.external_force.copy(),
            torque=robot_state.external_torque.copy(),
            trajectory_error=trajectory_error,
            motor_current=motor_current if motor_current is not None else np.zeros(dof),
            temperature=temperature if temperature is not None else np.full(dof, 25.0),
            controller_state=robot_state.motion_state.value,
        )
        buf = self._buffers.setdefault(robot_state.robot_id, deque(maxlen=self.max_samples))
        buf.append(sample)
        for sub in self._subscribers:
            try:
                sub(sample)
            except Exception:
                pass
        return sample

    def recent(self, robot_id: str, n: int = 100) -> list[TelemetrySample]:
        buf = self._buffers.get(robot_id, deque())
        return list(buf)[-n:]

    def history(self, robot_id: str, since: float | None = None, until: float | None = None) -> list[TelemetrySample]:
        buf = self._buffers.get(robot_id, deque())
        since = since or 0.0
        until = until or time.time()
        return [s for s in buf if since <= s.timestamp <= until]
