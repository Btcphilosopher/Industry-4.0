"""Summary statistics over a window of telemetry samples -- used by the
API's diagnostics endpoint and the precision/benchmark reports."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from roboforge.telemetry.telemetry_recorder import TelemetrySample


@dataclass
class TelemetrySummary:
    n_samples: int
    mean_trajectory_error_m: float
    max_trajectory_error_m: float
    mean_tcp_speed_m_s: float
    max_tcp_speed_m_s: float
    max_joint_velocity: float
    max_joint_torque: float
    mean_force_n: float
    max_force_n: float


def summarise_samples(samples: list[TelemetrySample]) -> TelemetrySummary:
    if not samples:
        return TelemetrySummary(0, 0, 0, 0, 0, 0, 0, 0, 0)

    traj_errors = np.array([s.trajectory_error for s in samples])
    tcp_speeds = np.array([np.linalg.norm(s.tcp_velocity[:3]) for s in samples])
    joint_velocities = np.array([np.max(np.abs(s.joint_velocity)) for s in samples])
    joint_torques = np.array([np.max(np.abs(s.joint_torque)) for s in samples])
    forces = np.array([np.linalg.norm(s.force) for s in samples])

    return TelemetrySummary(
        n_samples=len(samples),
        mean_trajectory_error_m=float(np.mean(traj_errors)),
        max_trajectory_error_m=float(np.max(traj_errors)),
        mean_tcp_speed_m_s=float(np.mean(tcp_speeds)),
        max_tcp_speed_m_s=float(np.max(tcp_speeds)),
        max_joint_velocity=float(np.max(joint_velocities)),
        max_joint_torque=float(np.max(joint_torques)),
        mean_force_n=float(np.mean(forces)),
        max_force_n=float(np.max(forces)),
    )
