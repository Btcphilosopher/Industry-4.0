"""Motion.OS: the precision motion engine -- trajectory generation,
motion planning, trajectory optimisation, Cartesian servoing, and
micro-motion/search primitives."""
