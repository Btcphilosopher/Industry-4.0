"""The micro-motion engine (sections 8 & 21): approach, fine alignment,
and contact/alignment search -- the precision-maneuvering primitives used
by insertion, assembly, and tool-alignment tasks.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, TYPE_CHECKING

import numpy as np

from roboforge.core.enums import IKMethod
from roboforge.core.exceptions import TrajectoryError
from roboforge.core.transforms import Pose
from roboforge.motion.micro_motion.search_patterns import raster_search_offsets, spiral_search_offsets
from roboforge.motion.trajectory.cartesian_trajectory import (
    CartesianTrajectory,
    generate_linear_cartesian_trajectory,
)
from roboforge.robotics.kinematics.inverse import IKResult

if TYPE_CHECKING:
    from roboforge.robotics.robot import Robot


@dataclass
class SearchResult:
    found: bool
    pose: Pose | None
    offset: tuple[float, float]
    iterations: int
    pattern: str


class MicroMotionEngine:
    """Precision maneuvering: coarse->fine approach, contact
    approach/withdrawal, tool/orientation alignment, and search patterns
    for connector/part registration (sections 8 and 21).

    Tolerances are configuration, not marketing: callers should set
    ``tolerance_position``/``tolerance_orientation`` no tighter than the
    robot's actual calibrated repeatability (``robot.calibration.repeatability_m``),
    since this engine cannot make the hardware more precise than it is.
    """

    def __init__(self, robot: "Robot") -> None:
        self.robot = robot

    def approach(
        self,
        target: Pose,
        approach_distance: float = 0.05,
        approach_speed: float = 0.01,
        retreat_axis_local: np.ndarray = np.array([0.0, 0.0, -1.0]),
        dt: float = 0.01,
    ) -> CartesianTrajectory:
        """Generate a slow, straight-line approach into ``target`` from a
        standoff pose offset ``approach_distance`` back along the target's
        own tool axis -- the standard "coarse position, then slow final
        approach" pattern for precision insertion/contact tasks.
        """
        retreat_world = target.rotation @ (retreat_axis_local / np.linalg.norm(retreat_axis_local))
        standoff_position = target.position + approach_distance * retreat_world
        standoff = Pose(standoff_position, target.rotation.copy(), frame=target.frame)
        return generate_linear_cartesian_trajectory(
            standoff, target, max_linear_velocity=approach_speed, max_linear_acceleration=approach_speed * 4, dt=dt
        )

    def fine_align(
        self,
        target: Pose,
        tolerance_position: float = 1e-4,
        tolerance_orientation: float = 1e-3,
        q_seed: np.ndarray | None = None,
        max_iterations: int = 300,
    ) -> IKResult:
        """Precision alignment via a tight-tolerance IK solve. Refuses to
        report success below the robot's calibrated repeatability, if
        known, since claiming sub-repeatability precision would not be
        honest about hardware limits (section 8).
        """
        repeatability = self.robot.calibration.repeatability_m
        if repeatability is not None and tolerance_position < repeatability:
            raise TrajectoryError(
                f"Requested position tolerance {tolerance_position:.2e} m is tighter than the "
                f"robot's calibrated repeatability of {repeatability:.2e} m"
            )
        q0 = self.robot.joint_state.position if q_seed is None else np.asarray(q_seed, dtype=float)
        return self.robot.inverse_kinematics(
            target,
            initial_guess=q0,
            method=IKMethod.DAMPED_LEAST_SQUARES,
            max_iterations=max_iterations,
            position_tolerance=tolerance_position,
            orientation_tolerance=tolerance_orientation,
            damping=0.005,
            step_scale=0.5,
        )

    def search(
        self,
        pattern: str,
        radius: float,
        step: float,
        centre_pose: Pose,
        contact_checker: Callable[[Pose], bool] | None = None,
        width: float | None = None,
        height: float | None = None,
    ) -> SearchResult:
        """Execute a spiral or raster search about ``centre_pose`` in its
        own local XY plane, evaluating ``contact_checker`` at each
        candidate pose until it reports success (contact/alignment found)
        or the pattern is exhausted (section 21).
        """
        if pattern == "spiral":
            offsets = spiral_search_offsets(radius, step)
        elif pattern == "raster":
            offsets = raster_search_offsets(width or 2 * radius, height or 2 * radius, step)
        else:
            raise ValueError(f"Unknown search pattern: {pattern!r}")

        x_axis = centre_pose.rotation[:, 0]
        y_axis = centre_pose.rotation[:, 1]

        checker = contact_checker or (lambda pose: True)
        for i, (dx, dy) in enumerate(offsets):
            candidate_position = centre_pose.position + dx * x_axis + dy * y_axis
            candidate = Pose(candidate_position, centre_pose.rotation.copy(), frame=centre_pose.frame)
            if checker(candidate):
                return SearchResult(found=True, pose=candidate, offset=(dx, dy), iterations=i + 1, pattern=pattern)

        return SearchResult(found=False, pose=None, offset=(0.0, 0.0), iterations=len(offsets), pattern=pattern)
