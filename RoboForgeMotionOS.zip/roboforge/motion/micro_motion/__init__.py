"""Micro-motion engine: sub-millimetre search, approach, and fine
alignment primitives (section 21)."""

from roboforge.motion.micro_motion.search_patterns import (
    spiral_search_offsets,
    raster_search_offsets,
)
from roboforge.motion.micro_motion.micro_motion_engine import MicroMotionEngine, SearchResult

__all__ = [
    "spiral_search_offsets",
    "raster_search_offsets",
    "MicroMotionEngine",
    "SearchResult",
]
