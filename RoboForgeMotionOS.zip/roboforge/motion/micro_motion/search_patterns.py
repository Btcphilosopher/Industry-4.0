"""Search-pattern generators for precision alignment (section 21):
spiral and raster patterns in a local 2D plane, returned as (dx, dy)
offsets to be applied about a nominal target pose.
"""

from __future__ import annotations

import numpy as np


def spiral_search_offsets(radius: float, step: float, points_per_turn: int = 16) -> list[tuple[float, float]]:
    """An Archimedean spiral of offsets from (0, 0) out to ``radius``,
    with successive turns separated by ``step``."""
    if step <= 0 or radius <= 0:
        return [(0.0, 0.0)]
    offsets: list[tuple[float, float]] = [(0.0, 0.0)]
    angle_step = 2 * np.pi / points_per_turn
    growth_per_point = step / points_per_turn
    r = growth_per_point
    theta = angle_step
    while r <= radius:
        offsets.append((float(r * np.cos(theta)), float(r * np.sin(theta))))
        theta += angle_step
        r += growth_per_point
    return offsets


def raster_search_offsets(width: float, height: float, step: float) -> list[tuple[float, float]]:
    """A boustrophedon (back-and-forth) raster scan of offsets covering a
    ``width`` x ``height`` rectangle centred on (0, 0) with row spacing
    ``step``."""
    if step <= 0:
        return [(0.0, 0.0)]
    offsets: list[tuple[float, float]] = []
    n_rows = max(1, int(np.ceil(height / step)) + 1)
    ys = np.linspace(-height / 2, height / 2, n_rows)
    for i, y in enumerate(ys):
        xs = np.linspace(-width / 2, width / 2, max(2, int(np.ceil(width / step)) + 1))
        if i % 2 == 1:
            xs = xs[::-1]
        for x in xs:
            offsets.append((float(x), float(y)))
    return offsets
