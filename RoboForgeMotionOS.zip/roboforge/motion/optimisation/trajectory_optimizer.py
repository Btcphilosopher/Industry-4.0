"""Trajectory optimisation: metrics computation and multi-objective
re-timing (section 19).

``compute_trajectory_metrics`` gives every subsystem (API, telemetry,
demo, benchmark) one canonical place to compute distance, velocity,
acceleration, jerk, torque, energy, execution time, and an estimated
tracking-precision figure for a generated trajectory. ``TrajectoryOptimizer``
searches over a time-scale factor to trade cycle time against smoothness
when several objectives are requested together, since minimum-time and
minimum-jerk/minimum-wear are generally in tension.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np

from roboforge.motion.trajectory.joint_trajectory import JointTrajectory, JointTrajectoryPoint

if TYPE_CHECKING:
    from roboforge.robotics.robot import Robot


@dataclass
class TrajectoryMetrics:
    execution_time: float
    total_distance: float
    peak_velocity: float
    peak_acceleration: float
    peak_jerk: float
    peak_torque: float
    energy_estimate_j: float
    estimated_precision_error_m: float


def compute_trajectory_metrics(robot: "Robot", trajectory: JointTrajectory) -> TrajectoryMetrics:
    if not trajectory.points:
        return TrajectoryMetrics(0, 0, 0, 0, 0, 0, 0, 0)

    total_distance = float(np.sum(trajectory.total_joint_distance()))
    peak_velocity = float(np.max([np.max(np.abs(p.velocity)) for p in trajectory.points]))
    peak_acceleration = float(np.max([np.max(np.abs(p.acceleration)) for p in trajectory.points]))
    peak_jerk = float(np.max([np.max(np.abs(p.jerk)) if p.jerk.size else 0.0 for p in trajectory.points]))

    torques = []
    energy = 0.0
    prev_t = trajectory.points[0].t
    for p in trajectory.points:
        try:
            tau = robot.inverse_dynamics(p.position, p.velocity, p.acceleration)
        except Exception:
            tau = np.zeros(robot.dof)
        torques.append(np.max(np.abs(tau)))
        dt = max(p.t - prev_t, 0.0)
        power = float(np.sum(np.abs(tau * p.velocity)))
        energy += power * dt
        prev_t = p.t

    peak_torque = float(np.max(torques)) if torques else 0.0

    # Rough tracking-precision proxy: higher peak acceleration/jerk under a
    # fixed-bandwidth position controller correlates with larger following
    # error; this is not a substitute for measured tracking error (see the
    # precision-metrics subsystem) but is useful for ranking candidates.
    estimated_precision_error = 1e-5 + 2e-6 * peak_acceleration + 5e-8 * peak_jerk

    return TrajectoryMetrics(
        execution_time=trajectory.duration,
        total_distance=total_distance,
        peak_velocity=peak_velocity,
        peak_acceleration=peak_acceleration,
        peak_jerk=peak_jerk,
        peak_torque=peak_torque,
        energy_estimate_j=energy,
        estimated_precision_error_m=estimated_precision_error,
    )


_OBJECTIVE_WEIGHTS = {
    "minimum_time": {"execution_time": 1.0},
    "minimum_jerk": {"peak_jerk": 1.0},
    "minimum_energy": {"energy_estimate_j": 1.0},
    "minimum_wear": {"peak_torque": 0.5, "peak_jerk": 0.5},
    "maximum_precision": {"estimated_precision_error_m": 1.0},
}


class TrajectoryOptimizer:
    """Re-times a generated trajectory to balance a set of named
    objectives by searching over a uniform time-scale factor."""

    def __init__(self, robot: "Robot") -> None:
        self.robot = robot

    def optimise(
        self,
        trajectory: JointTrajectory,
        objectives: list[str],
        scale_range: tuple[float, float] = (0.5, 2.5),
        n_candidates: int = 12,
    ) -> tuple[JointTrajectory, TrajectoryMetrics]:
        weights: dict[str, float] = {}
        for obj in objectives:
            for metric, w in _OBJECTIVE_WEIGHTS.get(obj, {}).items():
                weights[metric] = weights.get(metric, 0.0) + w
        if not weights:
            weights = {"execution_time": 1.0}

        scales = np.linspace(scale_range[0], scale_range[1], n_candidates)
        best_traj, best_metrics, best_score = trajectory, None, float("inf")
        # Precompute normalisers from the baseline (scale=1.0) candidate.
        baseline_metrics = compute_trajectory_metrics(self.robot, trajectory)
        norms = {
            "execution_time": max(baseline_metrics.execution_time, 1e-6),
            "peak_jerk": max(baseline_metrics.peak_jerk, 1e-6),
            "energy_estimate_j": max(baseline_metrics.energy_estimate_j, 1e-6),
            "peak_torque": max(baseline_metrics.peak_torque, 1e-6),
            "estimated_precision_error_m": max(baseline_metrics.estimated_precision_error_m, 1e-9),
        }

        for s in scales:
            scaled = time_scale_trajectory(trajectory, float(s))
            metrics = compute_trajectory_metrics(self.robot, scaled)
            score = 0.0
            for metric, w in weights.items():
                value = getattr(metrics, metric)
                score += w * value / norms.get(metric, 1.0)
            if score < best_score:
                best_score = score
                best_traj = scaled
                best_metrics = metrics

        return best_traj, best_metrics


def time_scale_trajectory(trajectory: JointTrajectory, scale: float) -> JointTrajectory:
    """Return a copy of ``trajectory`` with time (and hence velocity,
    acceleration, jerk) scaled by ``scale``.

    Stretching time by ``scale`` (scale > 1 = slower) reduces velocity by
    1/scale, acceleration by 1/scale^2, and jerk by 1/scale^3, since
    position as a function of the *shape* of the path is unchanged.
    """
    new_points = []
    for p in trajectory.points:
        new_points.append(
            JointTrajectoryPoint(
                t=p.t * scale,
                position=p.position.copy(),
                velocity=p.velocity / scale,
                acceleration=p.acceleration / (scale ** 2),
                jerk=p.jerk / (scale ** 3) if p.jerk.size else p.jerk,
            )
        )
    return JointTrajectory(joint_names=trajectory.joint_names, points=new_points)
