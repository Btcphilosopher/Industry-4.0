"""Rapidly-exploring Random Tree (RRT) planner in joint space (section 18).

A general-purpose sampling-based planner: does not require an explicit
obstacle representation, only a boolean ``collision_checker(q) -> bool``
(True = valid/collision-free). This lets the same planner work against
the real collision engine, a simplified proxy, or ``None`` (always
valid) for pure reachability/joint-limit planning.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, TYPE_CHECKING

import numpy as np

from roboforge.core.exceptions import MotionPlanningError

if TYPE_CHECKING:
    from roboforge.robotics.robot import Robot

CollisionChecker = Callable[[np.ndarray], bool]


@dataclass
class RRTConfig:
    max_iterations: int = 1200
    step_size: float = 0.12
    goal_bias: float = 0.10
    goal_tolerance: float = 0.02
    seed: int | None = None


@dataclass
class RRTNode:
    q: np.ndarray
    parent: "RRTNode | None" = None


def _joint_bounds(robot: "Robot") -> tuple[np.ndarray, np.ndarray]:
    low = np.array([j.limits.min_position for j in robot.joints])
    high = np.array([j.limits.max_position for j in robot.joints])
    return low, high


def _default_checker(_: np.ndarray) -> bool:
    return True


def _nearest(nodes: list[RRTNode], q: np.ndarray) -> RRTNode:
    dists = [np.linalg.norm(n.q - q) for n in nodes]
    return nodes[int(np.argmin(dists))]


def _steer(q_from: np.ndarray, q_to: np.ndarray, step_size: float) -> np.ndarray:
    delta = q_to - q_from
    dist = np.linalg.norm(delta)
    if dist <= step_size:
        return q_to
    return q_from + delta / dist * step_size


def _segment_collision_free(q0: np.ndarray, q1: np.ndarray, checker: CollisionChecker, resolution: float = 0.05) -> bool:
    dist = np.linalg.norm(q1 - q0)
    n_steps = max(1, int(np.ceil(dist / resolution)))
    for i in range(n_steps + 1):
        q = q0 + (q1 - q0) * (i / n_steps)
        if not checker(q):
            return False
    return True


def rrt_plan(
    robot: "Robot",
    q_start: np.ndarray,
    q_goal: np.ndarray,
    collision_checker: CollisionChecker | None = None,
    config: RRTConfig | None = None,
) -> list[np.ndarray]:
    """Plan a collision-free joint-space path from ``q_start`` to
    ``q_goal``. Raises ``MotionPlanningError`` if no path is found within
    ``config.max_iterations``.
    """
    config = config or RRTConfig()
    checker = collision_checker or _default_checker
    rng = np.random.default_rng(config.seed)
    low, high = _joint_bounds(robot)

    q_start = np.asarray(q_start, dtype=float)
    q_goal = np.asarray(q_goal, dtype=float)

    if not checker(q_start):
        raise MotionPlanningError("Start configuration is in collision")
    if not checker(q_goal):
        raise MotionPlanningError("Goal configuration is in collision")

    nodes = [RRTNode(q=q_start)]

    for _ in range(config.max_iterations):
        if rng.random() < config.goal_bias:
            q_rand = q_goal
        else:
            q_rand = rng.uniform(low, high)

        nearest = _nearest(nodes, q_rand)
        q_new = _steer(nearest.q, q_rand, config.step_size)
        q_new = np.clip(q_new, low, high)

        if not _segment_collision_free(nearest.q, q_new, checker):
            continue

        new_node = RRTNode(q=q_new, parent=nearest)
        nodes.append(new_node)

        if np.linalg.norm(q_new - q_goal) <= config.goal_tolerance:
            if _segment_collision_free(q_new, q_goal, checker):
                goal_node = RRTNode(q=q_goal, parent=new_node)
                return _extract_path(goal_node)

    raise MotionPlanningError(
        f"RRT failed to find a path within {config.max_iterations} iterations"
    )


def _extract_path(node: RRTNode) -> list[np.ndarray]:
    path = []
    current: RRTNode | None = node
    while current is not None:
        path.append(current.q)
        current = current.parent
    path.reverse()
    return path


def shortcut_smooth(
    path: list[np.ndarray],
    collision_checker: CollisionChecker | None = None,
    iterations: int = 100,
    seed: int | None = None,
) -> list[np.ndarray]:
    """Randomised shortcutting: repeatedly try to replace a sub-path with a
    direct segment, removing unnecessary detours from a sampling-based
    plan (a standard, cheap RRT post-processing step)."""
    checker = collision_checker or _default_checker
    rng = np.random.default_rng(seed)
    path = list(path)
    for _ in range(iterations):
        if len(path) <= 2:
            break
        i, j = sorted(rng.integers(0, len(path), size=2))
        if j - i < 2:
            continue
        if _segment_collision_free(path[i], path[j], checker):
            path = path[: i + 1] + path[j:]
    return path
