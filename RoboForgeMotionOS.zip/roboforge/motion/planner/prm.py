"""Probabilistic Roadmap (PRM) planner in joint space (section 18).

Builds a roadmap once (random collision-free samples connected to their
k-nearest neighbours when the connecting segment is collision-free), then
answers shortest-path queries against it with Dijkstra. PRM amortises
well when many start/goal pairs need to be planned against the same
(mostly static) environment -- e.g. repeated pick-and-place cycles in a
fixed cell -- whereas RRT/RRT* is better suited to one-off queries.
"""

from __future__ import annotations

import heapq
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np

from roboforge.core.exceptions import MotionPlanningError
from roboforge.motion.planner.rrt import CollisionChecker, _default_checker, _joint_bounds, _segment_collision_free

if TYPE_CHECKING:
    from roboforge.robotics.robot import Robot


@dataclass
class PRMRoadmap:
    nodes: list[np.ndarray] = field(default_factory=list)
    edges: dict[int, list[tuple[int, float]]] = field(default_factory=dict)

    def add_node(self, q: np.ndarray) -> int:
        idx = len(self.nodes)
        self.nodes.append(q)
        self.edges[idx] = []
        return idx

    def add_edge(self, i: int, j: int, cost: float) -> None:
        self.edges[i].append((j, cost))
        self.edges[j].append((i, cost))


def build_prm_roadmap(
    robot: "Robot",
    collision_checker: CollisionChecker | None = None,
    n_samples: int = 500,
    k_neighbours: int = 10,
    seed: int | None = None,
) -> PRMRoadmap:
    checker = collision_checker or _default_checker
    rng = np.random.default_rng(seed)
    low, high = _joint_bounds(robot)

    roadmap = PRMRoadmap()
    samples: list[np.ndarray] = []
    attempts = 0
    while len(samples) < n_samples and attempts < n_samples * 20:
        attempts += 1
        q = rng.uniform(low, high)
        if checker(q):
            samples.append(q)
            roadmap.add_node(q)

    for i, qi in enumerate(roadmap.nodes):
        dists = [(j, float(np.linalg.norm(qi - qj))) for j, qj in enumerate(roadmap.nodes) if j != i]
        dists.sort(key=lambda x: x[1])
        for j, d in dists[:k_neighbours]:
            if any(e[0] == j for e in roadmap.edges[i]):
                continue
            if _segment_collision_free(qi, roadmap.nodes[j], checker):
                roadmap.add_edge(i, j, d)
    return roadmap


def _dijkstra(roadmap: PRMRoadmap, start_idx: int, goal_idx: int) -> list[int]:
    dist = {start_idx: 0.0}
    prev: dict[int, int] = {}
    visited: set[int] = set()
    heap = [(0.0, start_idx)]
    while heap:
        d, u = heapq.heappop(heap)
        if u in visited:
            continue
        visited.add(u)
        if u == goal_idx:
            break
        for v, w in roadmap.edges.get(u, []):
            nd = d + w
            if nd < dist.get(v, float("inf")):
                dist[v] = nd
                prev[v] = u
                heapq.heappush(heap, (nd, v))
    if goal_idx not in dist:
        raise MotionPlanningError("PRM: no path exists between start and goal in the roadmap")
    path = [goal_idx]
    while path[-1] != start_idx:
        path.append(prev[path[-1]])
    path.reverse()
    return path


def prm_plan(
    robot: "Robot",
    q_start: np.ndarray,
    q_goal: np.ndarray,
    roadmap: PRMRoadmap | None = None,
    collision_checker: CollisionChecker | None = None,
    connect_k: int = 10,
    **build_kwargs,
) -> list[np.ndarray]:
    """Plan a path using a PRM roadmap, building one on the fly if not
    supplied (build once and reuse via ``build_prm_roadmap`` for repeated
    queries against a static scene)."""
    checker = collision_checker or _default_checker
    if roadmap is None:
        roadmap = build_prm_roadmap(robot, checker, **build_kwargs)

    q_start = np.asarray(q_start, dtype=float)
    q_goal = np.asarray(q_goal, dtype=float)
    if not checker(q_start):
        raise MotionPlanningError("Start configuration is in collision")
    if not checker(q_goal):
        raise MotionPlanningError("Goal configuration is in collision")

    start_idx = roadmap.add_node(q_start)
    goal_idx = roadmap.add_node(q_goal)

    for idx, q in ((start_idx, q_start), (goal_idx, q_goal)):
        dists = [(j, float(np.linalg.norm(q - qj))) for j, qj in enumerate(roadmap.nodes) if j != idx]
        dists.sort(key=lambda x: x[1])
        for j, d in dists[:connect_k]:
            if _segment_collision_free(q, roadmap.nodes[j], checker):
                roadmap.add_edge(idx, j, d)

    indices = _dijkstra(roadmap, start_idx, goal_idx)
    return [roadmap.nodes[i] for i in indices]
