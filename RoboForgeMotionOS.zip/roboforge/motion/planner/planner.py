"""The unified ``MotionPlanner`` (section 18-19): generates and compares
candidate trajectories against a chosen objective (minimum time, minimum
distance, minimum energy, minimum jerk, maximum clearance, ...).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np

from roboforge.core.enums import PlannerObjective
from roboforge.core.exceptions import MotionPlanningError
from roboforge.core.transforms import Pose
from roboforge.motion.planner.cartesian_planner import plan_cartesian_path
from roboforge.motion.planner.rrt import CollisionChecker, RRTConfig, rrt_plan, shortcut_smooth, _default_checker
from roboforge.motion.planner.rrt_star import rrt_star_plan
from roboforge.motion.trajectory.joint_trajectory import (
    JointTrajectory,
    JointTrajectoryPoint,
    generate_joint_trajectory,
)

if TYPE_CHECKING:
    from roboforge.robotics.robot import Robot


@dataclass
class PlanningRequest:
    start: np.ndarray  # joint-space start
    target_pose: Pose | None = None
    target_joints: np.ndarray | None = None
    objective: PlannerObjective = PlannerObjective.MINIMUM_TIME
    collision_checker: CollisionChecker | None = None
    clearance_fn: "callable | None" = None


@dataclass
class PlanningCandidate:
    name: str
    trajectory: JointTrajectory
    metrics: dict = field(default_factory=dict)


@dataclass
class PlanningResult:
    trajectory: JointTrajectory
    chosen_candidate: str
    objective: PlannerObjective
    objective_value: float
    candidates: list[PlanningCandidate]


class MotionPlanner:
    """Plans robot motions and selects the best candidate for a stated
    optimisation objective (section 18)."""

    def __init__(self, robot: "Robot") -> None:
        self.robot = robot

    # -- individual planning strategies ----------------------------------
    def plan_point_to_point(self, q_start: np.ndarray, q_target: np.ndarray) -> JointTrajectory:
        return generate_joint_trajectory(self.robot, q_start, q_target)

    def plan_via_waypoints(self, waypoints: list[np.ndarray]) -> JointTrajectory:
        """Stitch a smooth joint trajectory through multiple joint-space
        waypoints, blending segment boundary velocities (central-difference
        estimate) so the robot doesn't fully stop at each via point."""
        if len(waypoints) < 2:
            raise MotionPlanningError("plan_via_waypoints requires at least 2 waypoints")

        n = len(waypoints)
        boundary_velocities = [np.zeros(self.robot.dof) for _ in range(n)]
        for i in range(1, n - 1):
            boundary_velocities[i] = (waypoints[i + 1] - waypoints[i - 1]) / 2.0
            # Scale down to respect velocity limits conservatively.
            for j, joint in enumerate(self.robot.joints):
                max_v = joint.limits.max_velocity * self.robot.motion_constraints.velocity_scale
                boundary_velocities[i][j] = np.clip(boundary_velocities[i][j], -0.5 * max_v, 0.5 * max_v)

        all_points: list[JointTrajectoryPoint] = []
        t_offset = 0.0
        for i in range(n - 1):
            seg = generate_joint_trajectory(
                self.robot,
                waypoints[i],
                waypoints[i + 1],
                qd_start=boundary_velocities[i],
                qd_end=boundary_velocities[i + 1],
            )
            for p in seg.points:
                if i > 0 and p.t == 0.0:
                    continue  # avoid duplicate junction sample
                all_points.append(
                    JointTrajectoryPoint(
                        t=p.t + t_offset,
                        position=p.position,
                        velocity=p.velocity,
                        acceleration=p.acceleration,
                        jerk=p.jerk,
                    )
                )
            t_offset += seg.duration
        return JointTrajectory(joint_names=self.robot.joint_names, points=all_points)

    def plan_cartesian(self, start_pose: Pose, target_pose: Pose, q_seed: np.ndarray,
                        collision_checker: CollisionChecker | None = None) -> JointTrajectory:
        path = plan_cartesian_path(self.robot, start_pose, target_pose, q_seed, collision_checker)
        if len(path) == 2:
            return self.plan_point_to_point(path[0], path[1])
        return self.plan_via_waypoints(path)

    def plan_rrt(self, q_start: np.ndarray, q_target: np.ndarray,
                 collision_checker: CollisionChecker | None = None, use_star: bool = True) -> JointTrajectory:
        checker = collision_checker or _default_checker
        planner_fn = rrt_star_plan if use_star else rrt_plan
        raw_path = planner_fn(self.robot, q_start, q_target, checker)
        smoothed = shortcut_smooth(raw_path, checker)
        return self.plan_via_waypoints(smoothed)

    # -- objective evaluation ---------------------------------------------
    def _evaluate(self, trajectory: JointTrajectory, objective: PlannerObjective,
                  clearance_fn=None) -> float:
        if objective == PlannerObjective.MINIMUM_TIME:
            return trajectory.duration
        if objective in (PlannerObjective.MINIMUM_DISTANCE, PlannerObjective.MINIMUM_JOINT_MOVEMENT):
            return float(np.sum(trajectory.total_joint_distance()))
        if objective == PlannerObjective.MINIMUM_JERK:
            peaks = [float(np.max(np.abs(p.jerk))) if p.jerk.size else 0.0 for p in trajectory.points]
            return float(np.max(peaks)) if peaks else 0.0
        if objective == PlannerObjective.MINIMUM_ENERGY:
            energy = 0.0
            for p in trajectory.points:
                try:
                    tau = self.robot.inverse_dynamics(p.position, p.velocity, p.acceleration)
                    energy += float(np.sum(np.abs(tau * p.velocity)))
                except Exception:
                    continue
            return energy
        if objective == PlannerObjective.MINIMUM_WEAR:
            # Proxy for mechanical wear: integral of |torque| * |velocity| plus
            # a penalty for direction reversals (backlash-inducing).
            wear = 0.0
            prev_sign = None
            for p in trajectory.points:
                try:
                    tau = self.robot.inverse_dynamics(p.position, p.velocity, p.acceleration)
                except Exception:
                    tau = np.zeros(self.robot.dof)
                wear += float(np.sum(np.abs(tau)))
                sign = np.sign(p.velocity)
                if prev_sign is not None:
                    wear += float(np.sum(np.abs(sign - prev_sign)))
                prev_sign = sign
            return wear
        if objective == PlannerObjective.MAXIMUM_CLEARANCE:
            if clearance_fn is None:
                return 0.0
            clearances = [clearance_fn(p.position) for p in trajectory.points]
            # Larger is better -- negate so "lower objective value is better"
            # stays consistent for the selection logic below.
            return -float(np.min(clearances)) if clearances else 0.0
        if objective == PlannerObjective.MAXIMUM_PRECISION:
            # Proxy: smoother trajectories (lower peak acceleration) track
            # more precisely under a fixed-gain controller.
            return float(np.max([np.max(np.abs(p.acceleration)) for p in trajectory.points]))
        return trajectory.duration

    def optimize(
        self,
        start: np.ndarray | Pose,
        target: np.ndarray | Pose,
        objective: PlannerObjective = PlannerObjective.MINIMUM_TIME,
        collision_checker: CollisionChecker | None = None,
        clearance_fn=None,
        force_sampling_comparison: bool = False,
    ) -> PlanningResult:
        """Generate several candidate trajectories using different
        strategies and select the one that best satisfies ``objective``.
        """
        checker = collision_checker or _default_checker

        if isinstance(start, Pose):
            start_result = self.robot.inverse_kinematics(start, initial_guess=self.robot.joint_state.position)
            q_start = start_result.joint_positions
        else:
            q_start = np.asarray(start, dtype=float)

        if isinstance(target, Pose):
            target_result = self.robot.inverse_kinematics(target, initial_guess=q_start)
            if not target_result.success:
                raise MotionPlanningError("Target pose is unreachable")
            q_target = target_result.joint_positions
        else:
            q_target = np.asarray(target, dtype=float)

        candidates: list[PlanningCandidate] = []

        try:
            direct = self.plan_point_to_point(q_start, q_target)
            if all(checker(p.position) for p in direct.points):
                candidates.append(PlanningCandidate("direct_quintic", direct))
        except Exception:
            pass

        if isinstance(target, Pose) and isinstance(start, Pose):
            try:
                cart = self.plan_cartesian(start, target, q_start, checker)
                candidates.append(PlanningCandidate("cartesian_linear", cart))
            except Exception:
                pass

        # Sampling-based planning is a *fallback*, not a first resort: it is
        # far more expensive than the direct/Cartesian candidates above, so
        # only invoke it when those didn't already produce a collision-free
        # candidate (matching how industrial planners typically operate --
        # try the fast path first, fall back to RRT only when blocked),
        # unless the caller explicitly wants the full comparison anyway.
        if not candidates or force_sampling_comparison:
            try:
                rrt_traj = self.plan_rrt(q_start, q_target, checker)
                candidates.append(PlanningCandidate("rrt_star_smoothed", rrt_traj))
            except Exception:
                pass

        if not candidates:
            raise MotionPlanningError("No feasible candidate trajectory could be generated")

        for c in candidates:
            c.metrics["objective_value"] = self._evaluate(c.trajectory, objective, clearance_fn)

        best = min(candidates, key=lambda c: c.metrics["objective_value"])
        return PlanningResult(
            trajectory=best.trajectory,
            chosen_candidate=best.name,
            objective=objective,
            objective_value=best.metrics["objective_value"],
            candidates=candidates,
        )
