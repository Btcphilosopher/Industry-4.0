"""RRT* -- asymptotically-optimal variant of RRT (section 18) that rewires
the tree to progressively shorten the path as more samples are drawn."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from roboforge.core.exceptions import MotionPlanningError
from roboforge.motion.planner.rrt import (
    RRTConfig,
    RRTNode,
    _default_checker,
    _extract_path,
    _joint_bounds,
    _nearest,
    _segment_collision_free,
    _steer,
    CollisionChecker,
)

if TYPE_CHECKING:
    from roboforge.robotics.robot import Robot


def _neighbourhood(nodes: list[RRTNode], q: np.ndarray, radius: float) -> list[RRTNode]:
    return [n for n in nodes if np.linalg.norm(n.q - q) <= radius]


def _cost(node: RRTNode) -> float:
    cost = 0.0
    current = node
    while current.parent is not None:
        cost += float(np.linalg.norm(current.q - current.parent.q))
        current = current.parent
    return cost


def rrt_star_plan(
    robot: "Robot",
    q_start: np.ndarray,
    q_goal: np.ndarray,
    collision_checker: CollisionChecker | None = None,
    config: RRTConfig | None = None,
    rewire_radius: float | None = None,
) -> list[np.ndarray]:
    config = config or RRTConfig(max_iterations=800)
    checker = collision_checker or _default_checker
    rng = np.random.default_rng(config.seed)
    low, high = _joint_bounds(robot)
    rewire_radius = rewire_radius or config.step_size * 3

    q_start = np.asarray(q_start, dtype=float)
    q_goal = np.asarray(q_goal, dtype=float)

    if not checker(q_start):
        raise MotionPlanningError("Start configuration is in collision")
    if not checker(q_goal):
        raise MotionPlanningError("Goal configuration is in collision")

    nodes = [RRTNode(q=q_start)]
    best_goal_node: RRTNode | None = None
    best_goal_cost = float("inf")

    for _ in range(config.max_iterations):
        q_rand = q_goal if rng.random() < config.goal_bias else rng.uniform(low, high)
        nearest = _nearest(nodes, q_rand)
        q_new = np.clip(_steer(nearest.q, q_rand, config.step_size), low, high)

        if not _segment_collision_free(nearest.q, q_new, checker):
            continue

        neighbours = _neighbourhood(nodes, q_new, rewire_radius)
        best_parent = nearest
        best_cost = _cost(nearest) + float(np.linalg.norm(q_new - nearest.q))
        for cand in neighbours:
            if not _segment_collision_free(cand.q, q_new, checker):
                continue
            cand_cost = _cost(cand) + float(np.linalg.norm(q_new - cand.q))
            if cand_cost < best_cost:
                best_parent, best_cost = cand, cand_cost

        new_node = RRTNode(q=q_new, parent=best_parent)
        nodes.append(new_node)

        # Rewire neighbours through the new node if it offers a shorter path.
        for cand in neighbours:
            if cand is best_parent:
                continue
            if not _segment_collision_free(q_new, cand.q, checker):
                continue
            new_cost = best_cost + float(np.linalg.norm(cand.q - q_new))
            if new_cost < _cost(cand):
                cand.parent = new_node

        if np.linalg.norm(q_new - q_goal) <= config.goal_tolerance:
            if _segment_collision_free(q_new, q_goal, checker):
                goal_cost = best_cost + float(np.linalg.norm(q_goal - q_new))
                if goal_cost < best_goal_cost:
                    best_goal_cost = goal_cost
                    best_goal_node = RRTNode(q=q_goal, parent=new_node)

    if best_goal_node is None:
        raise MotionPlanningError(
            f"RRT* failed to find a path within {config.max_iterations} iterations"
        )
    return _extract_path(best_goal_node)
