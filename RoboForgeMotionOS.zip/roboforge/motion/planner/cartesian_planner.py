"""Cartesian-space path planning (section 18): interpolate a straight-line
(or waypoint) Cartesian path and IK-solve each sample, falling back to
joint-space sampling-based planning if the direct Cartesian path is
blocked or leaves the workspace/reachable set.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from roboforge.core.enums import IKMethod
from roboforge.core.exceptions import MotionPlanningError, UnreachablePoseError
from roboforge.core.transforms import Pose
from roboforge.motion.planner.rrt import CollisionChecker, _default_checker
from roboforge.motion.planner.rrt_star import rrt_star_plan

if TYPE_CHECKING:
    from roboforge.robotics.robot import Robot


def plan_cartesian_path(
    robot: "Robot",
    start_pose: Pose,
    target_pose: Pose,
    q_seed: np.ndarray,
    collision_checker: CollisionChecker | None = None,
    n_waypoints: int = 20,
    fallback_to_rrt: bool = True,
) -> list[np.ndarray]:
    """Attempt a direct Cartesian-interpolated path (IK per waypoint,
    warm-started from the previous solution). Falls back to RRT* in joint
    space if any waypoint is unreachable or in collision.
    """
    checker = collision_checker or _default_checker
    q_current = np.asarray(q_seed, dtype=float)
    joint_path: list[np.ndarray] = [q_current]
    direct_ok = True

    for i in range(1, n_waypoints + 1):
        alpha = i / n_waypoints
        waypoint = start_pose.interpolate(target_pose, alpha)
        result = robot.inverse_kinematics(
            waypoint, initial_guess=q_current, method=IKMethod.DAMPED_LEAST_SQUARES
        )
        if not result.success or not checker(result.joint_positions):
            direct_ok = False
            break
        q_current = result.joint_positions
        joint_path.append(q_current)

    if direct_ok:
        return joint_path

    if not fallback_to_rrt:
        raise MotionPlanningError("Direct Cartesian path blocked and RRT fallback disabled")

    goal_result = robot.inverse_kinematics(target_pose, initial_guess=q_seed)
    if not goal_result.success:
        raise UnreachablePoseError(f"Target pose unreachable: {target_pose}")

    return rrt_star_plan(robot, np.asarray(q_seed, dtype=float), goal_result.joint_positions, checker)
