"""Cartesian velocity control / servoing (section 9).

Converts a desired TCP twist (or a proportional pose-tracking command)
into joint velocities via the damped Jacobian pseudoinverse, with
automatic gain reduction as the manipulator approaches a singularity
(rather than letting joint velocities spike as the classic pseudoinverse
would). This is the same building block used by visual servoing
(section 14) and force/impedance control (section 10) to turn a
task-space correction into joint motion.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np

from roboforge.core.exceptions import SingularityError
from roboforge.core.transforms import Pose, Twist, rotation_matrix_to_axis_angle
from roboforge.robotics.kinematics.jacobian import geometric_jacobian, damped_pseudoinverse
from roboforge.robotics.kinematics.singularity import analyse_singularity

if TYPE_CHECKING:
    from roboforge.robotics.robot import Robot


@dataclass
class CartesianServoController:
    robot: "Robot"
    position_gain: float = 2.0
    orientation_gain: float = 2.0
    singularity_threshold: float = 0.02
    base_damping: float = 0.02
    max_damping: float = 0.35

    def _adaptive_damping(self, q: np.ndarray) -> float:
        """Increase DLS damping as manipulability drops, trading tracking
        accuracy for stability rather than commanding runaway joint
        velocities through a near-singular configuration."""
        report = analyse_singularity(self.robot, q, self.singularity_threshold)
        if report.min_singular_value >= self.singularity_threshold:
            return self.base_damping
        severity = 1.0 - (report.min_singular_value / max(self.singularity_threshold, 1e-9))
        return float(self.base_damping + severity * (self.max_damping - self.base_damping))

    def twist_to_joint_velocity(self, twist: Twist, q: np.ndarray | None = None,
                                 allow_reduced_speed: bool = True) -> np.ndarray:
        """Convert a desired Cartesian twist into joint velocities,
        respecting joint velocity limits by uniformly scaling the command
        down (never up) if it would exceed any joint's limit.
        """
        q = self.robot.joint_state.position if q is None else np.asarray(q, dtype=float)
        J = geometric_jacobian(self.robot, q)
        damping = self._adaptive_damping(q)
        J_pinv = damped_pseudoinverse(J, damping=damping)
        qd = J_pinv @ twist.as_vector()

        scale = 1.0
        for joint, v in zip(self.robot.joints, qd):
            limit = joint.limits.max_velocity * self.robot.motion_constraints.velocity_scale
            if abs(v) > limit * scale + 1e-12:
                scale = min(scale, limit / max(abs(v), 1e-12))
        if scale < 1.0:
            if not allow_reduced_speed:
                raise SingularityError(
                    "Requested Cartesian velocity exceeds joint velocity limits and "
                    "speed reduction is disabled"
                )
            qd = qd * scale
        return qd

    def set_cartesian_velocity(self, linear: np.ndarray, angular: np.ndarray,
                                q: np.ndarray | None = None) -> np.ndarray:
        """Section 9 API: ``robot.set_cartesian_velocity(linear=..., angular=...)``.
        Returns the resulting joint-velocity command (rad/s or m/s)."""
        twist = Twist(linear=np.asarray(linear, dtype=float), angular=np.asarray(angular, dtype=float))
        return self.twist_to_joint_velocity(twist, q)

    def track_pose(self, target_pose: Pose, q: np.ndarray | None = None) -> tuple[np.ndarray, Twist]:
        """Proportional Cartesian pose-tracking servo: compute the twist
        command that drives the current TCP pose toward ``target_pose``,
        then convert it to joint velocities. Returns (qd, commanded_twist).
        """
        q = self.robot.joint_state.position if q is None else np.asarray(q, dtype=float)
        current_pose = self.robot.forward_kinematics(q)

        pos_error = target_pose.position - current_pose.position
        R_err = target_pose.rotation @ current_pose.rotation.T
        axis, angle = rotation_matrix_to_axis_angle(R_err)
        rot_error = axis * angle

        linear_cmd = self.position_gain * pos_error
        angular_cmd = self.orientation_gain * rot_error
        twist = Twist(linear=linear_cmd, angular=angular_cmd)
        qd = self.twist_to_joint_velocity(twist, q)
        return qd, twist
