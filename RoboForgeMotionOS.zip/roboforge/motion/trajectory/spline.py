"""Spline and Bezier trajectory generation through a sequence of Cartesian
waypoints (section 7) -- for continuous multi-point paths (e.g. weld
seams, dispensing paths, inspection scans) where a single linear/circular
segment isn't sufficient.
"""

from __future__ import annotations

import numpy as np
from scipy.interpolate import CubicSpline
from scipy.spatial.transform import Rotation as _Rotation, Slerp

from roboforge.core.exceptions import TrajectoryError
from roboforge.core.transforms import Pose, Twist
from roboforge.motion.trajectory.cartesian_trajectory import CartesianTrajectory, CartesianTrajectoryPoint


def generate_spline_trajectory(
    waypoints: list[Pose],
    duration: float,
    dt: float = 0.01,
    boundary_condition: str = "clamped",
) -> CartesianTrajectory:
    """Fit a natural/clamped cubic spline through position waypoints and
    SLERP through their orientations, parameterised by arc-length-weighted
    time so cornering doesn't cause velocity spikes.
    """
    if len(waypoints) < 2:
        raise TrajectoryError("Spline trajectory requires at least 2 waypoints")

    positions = np.array([w.position for w in waypoints])
    # Parameterise by cumulative chord length, normalised to [0, duration].
    seg_lengths = np.linalg.norm(np.diff(positions, axis=0), axis=1)
    cumulative = np.concatenate([[0.0], np.cumsum(seg_lengths)])
    total_length = cumulative[-1] if cumulative[-1] > 1e-9 else 1.0
    knot_times = cumulative / total_length * duration

    cs = CubicSpline(knot_times, positions, axis=0, bc_type=boundary_condition)
    rotations = _Rotation.from_matrix(np.stack([w.rotation for w in waypoints]))
    slerp = Slerp(knot_times, rotations)

    n_samples = max(2, int(np.ceil(duration / dt)) + 1)
    t_samples = np.linspace(0.0, duration, n_samples)
    velocities = cs(t_samples, 1)

    points: list[CartesianTrajectoryPoint] = []
    for t, pos, vel in zip(t_samples, cs(t_samples), velocities):
        rotation = slerp([np.clip(t, knot_times[0], knot_times[-1])]).as_matrix()[0]
        points.append(
            CartesianTrajectoryPoint(
                t=float(t),
                pose=Pose(pos, rotation, frame=waypoints[0].frame),
                twist=Twist(linear=vel, angular=np.zeros(3)),
            )
        )
    return CartesianTrajectory(points=points)


def _bezier_point(control_points: np.ndarray, s: float) -> np.ndarray:
    """De Casteljau's algorithm evaluated at parameter s in [0, 1]."""
    points = control_points.copy()
    while len(points) > 1:
        points = (1 - s) * points[:-1] + s * points[1:]
    return points[0]


def generate_bezier_trajectory(
    control_points: list[np.ndarray],
    orientation_start: np.ndarray,
    orientation_end: np.ndarray,
    duration: float,
    dt: float = 0.01,
    frame: str = "world",
) -> CartesianTrajectory:
    """Generate a Bezier-curve Cartesian trajectory through the given
    control points, time-scaled with a minimum-jerk profile."""
    from roboforge.motion.trajectory.profiles import minimum_jerk_time_scaling

    cp = np.array([np.asarray(p, dtype=float) for p in control_points])
    if len(cp) < 2:
        raise TrajectoryError("Bezier trajectory requires at least 2 control points")

    key_rots = _Rotation.from_matrix(np.stack([orientation_start, orientation_end]))
    slerp = Slerp([0.0, 1.0], key_rots)

    s_profile = minimum_jerk_time_scaling(duration, dt=dt)
    points: list[CartesianTrajectoryPoint] = []
    prev_pos = None
    for i, (t, s) in enumerate(zip(s_profile.t, s_profile.q)):
        s_clamped = float(np.clip(s, 0.0, 1.0))
        pos = _bezier_point(cp, s_clamped)
        rotation = slerp([s_clamped]).as_matrix()[0]
        if prev_pos is not None and i > 0:
            velocity = (pos - prev_pos) / max(s_profile.t[i] - s_profile.t[i - 1], 1e-9)
        else:
            velocity = np.zeros(3)
        prev_pos = pos
        points.append(
            CartesianTrajectoryPoint(
                t=float(t),
                pose=Pose(pos, rotation, frame=frame),
                twist=Twist(linear=velocity, angular=np.zeros(3)),
            )
        )
    return CartesianTrajectory(points=points)
