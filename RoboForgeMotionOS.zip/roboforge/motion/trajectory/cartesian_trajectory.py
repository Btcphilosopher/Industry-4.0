"""Cartesian trajectory generation: linear and circular moves, time-scaled
by a minimum-jerk profile so the TCP accelerates and decelerates smoothly
along a fixed geometric path (section 7)."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.spatial.transform import Rotation as _Rotation, Slerp

from roboforge.core.transforms import Pose, Twist
from roboforge.motion.trajectory.profiles import estimate_quintic_duration, minimum_jerk_time_scaling


@dataclass
class CartesianTrajectoryPoint:
    t: float
    pose: Pose
    twist: Twist


@dataclass
class CartesianTrajectory:
    points: list[CartesianTrajectoryPoint]

    @property
    def duration(self) -> float:
        return self.points[-1].t if self.points else 0.0

    def path_length(self) -> float:
        return float(
            sum(
                self.points[i].pose.distance_to(self.points[i + 1].pose)
                for i in range(len(self.points) - 1)
            )
        )

    def sample(self, t: float) -> CartesianTrajectoryPoint:
        t = float(np.clip(t, 0.0, self.duration))
        times = np.array([p.t for p in self.points])
        idx = int(np.searchsorted(times, t))
        if idx <= 0:
            return self.points[0]
        if idx >= len(self.points):
            return self.points[-1]
        p0, p1 = self.points[idx - 1], self.points[idx]
        span = p1.t - p0.t
        alpha = 0.0 if span <= 1e-12 else (t - p0.t) / span
        pose = p0.pose.interpolate(p1.pose, alpha)
        twist = Twist(
            linear=p0.twist.linear + alpha * (p1.twist.linear - p0.twist.linear),
            angular=p0.twist.angular + alpha * (p1.twist.angular - p0.twist.angular),
        )
        return CartesianTrajectoryPoint(t=t, pose=pose, twist=twist)


def generate_linear_cartesian_trajectory(
    start: Pose,
    end: Pose,
    max_linear_velocity: float = 0.25,
    max_linear_acceleration: float = 1.0,
    max_angular_velocity: float = 1.0,
    dt: float = 0.01,
    duration: float | None = None,
) -> CartesianTrajectory:
    """A straight-line Cartesian move with a minimum-jerk speed profile."""
    distance = start.distance_to(end)
    angle = start.angular_distance_to(end)

    if duration is None:
        t_lin = estimate_quintic_duration(distance, max_linear_velocity, max_linear_acceleration)
        t_ang = (15.0 / 8.0) * angle / max(max_angular_velocity, 1e-9)
        duration = max(t_lin, t_ang, 0.05)

    s_profile = minimum_jerk_time_scaling(duration, dt=dt)
    key_rots = _Rotation.from_matrix(np.stack([start.rotation, end.rotation]))
    slerp = Slerp([0.0, 1.0], key_rots)

    points: list[CartesianTrajectoryPoint] = []
    for i, (t, s, sd) in enumerate(zip(s_profile.t, s_profile.q, s_profile.qd)):
        s_clamped = float(np.clip(s, 0.0, 1.0))
        position = start.position + s * (end.position - start.position)
        rotation = slerp([s_clamped]).as_matrix()[0]
        pose = Pose(position, rotation, frame=start.frame)
        linear_vel = sd * (end.position - start.position)
        # Angular velocity magnitude scales with s-dot along the fixed SLERP axis.
        from roboforge.core.transforms import rotation_matrix_to_axis_angle

        rel_axis, rel_angle = rotation_matrix_to_axis_angle(end.rotation @ start.rotation.T)
        angular_vel = sd * rel_angle * rel_axis
        points.append(
            CartesianTrajectoryPoint(
                t=float(t),
                pose=pose,
                twist=Twist(linear=linear_vel, angular=angular_vel),
            )
        )
    return CartesianTrajectory(points=points)


def generate_circular_cartesian_trajectory(
    centre: np.ndarray,
    normal: np.ndarray,
    radius: float,
    start_angle: float,
    end_angle: float,
    orientation_start: np.ndarray,
    orientation_end: np.ndarray | None = None,
    max_linear_velocity: float = 0.25,
    max_linear_acceleration: float = 1.0,
    dt: float = 0.01,
    duration: float | None = None,
    frame: str = "world",
) -> CartesianTrajectory:
    """A circular-arc Cartesian move about ``centre`` in the plane defined
    by ``normal``, from ``start_angle`` to ``end_angle`` (radians), with a
    minimum-jerk speed profile along the arc length.
    """
    centre = np.asarray(centre, dtype=float)
    normal = np.asarray(normal, dtype=float)
    normal = normal / np.linalg.norm(normal)

    # Build an orthonormal basis (u, v) spanning the arc's plane.
    arbitrary = np.array([1.0, 0.0, 0.0]) if abs(normal[0]) < 0.9 else np.array([0.0, 1.0, 0.0])
    u = arbitrary - normal * np.dot(arbitrary, normal)
    u = u / np.linalg.norm(u)
    v = np.cross(normal, u)

    arc_length = radius * abs(end_angle - start_angle)
    if duration is None:
        duration = max(estimate_quintic_duration(arc_length, max_linear_velocity, max_linear_acceleration), 0.05)

    orientation_end = orientation_start if orientation_end is None else orientation_end
    key_rots = _Rotation.from_matrix(np.stack([orientation_start, orientation_end]))
    slerp = Slerp([0.0, 1.0], key_rots)

    s_profile = minimum_jerk_time_scaling(duration, dt=dt)
    points: list[CartesianTrajectoryPoint] = []
    for t, s, sd in zip(s_profile.t, s_profile.q, s_profile.qd):
        theta = start_angle + s * (end_angle - start_angle)
        position = centre + radius * (np.cos(theta) * u + np.sin(theta) * v)
        rotation = slerp([float(np.clip(s, 0.0, 1.0))]).as_matrix()[0]
        # d(theta)/dt = sd * (end_angle - start_angle); tangential velocity:
        theta_dot = sd * (end_angle - start_angle)
        tangent = radius * theta_dot * (-np.sin(theta) * u + np.cos(theta) * v)
        pose = Pose(position, rotation, frame=frame)
        points.append(
            CartesianTrajectoryPoint(t=float(t), pose=pose, twist=Twist(linear=tangent, angular=np.zeros(3)))
        )
    return CartesianTrajectory(points=points)
