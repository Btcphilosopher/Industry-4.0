"""Trajectory generation: joint-space, Cartesian (linear/circular),
spline/Bezier, quintic, and minimum-jerk time-scaling profiles."""

from roboforge.motion.trajectory.profiles import (
    minimum_jerk_time_scaling,
    quintic_scalar_profile,
    trapezoidal_scalar_profile,
)
from roboforge.motion.trajectory.joint_trajectory import (
    JointTrajectory,
    JointTrajectoryPoint,
    generate_joint_trajectory,
)
from roboforge.motion.trajectory.cartesian_trajectory import (
    CartesianTrajectory,
    CartesianTrajectoryPoint,
    generate_linear_cartesian_trajectory,
    generate_circular_cartesian_trajectory,
)
from roboforge.motion.trajectory.spline import generate_spline_trajectory, generate_bezier_trajectory

__all__ = [
    "minimum_jerk_time_scaling",
    "quintic_scalar_profile",
    "trapezoidal_scalar_profile",
    "JointTrajectory",
    "JointTrajectoryPoint",
    "generate_joint_trajectory",
    "CartesianTrajectory",
    "CartesianTrajectoryPoint",
    "generate_linear_cartesian_trajectory",
    "generate_circular_cartesian_trajectory",
    "generate_spline_trajectory",
    "generate_bezier_trajectory",
]
