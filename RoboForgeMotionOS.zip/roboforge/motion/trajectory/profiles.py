"""Scalar time-scaling / motion profiles used to build joint-space and
Cartesian trajectories (section 7).

Two families are provided:

* A quintic (5th-order) polynomial profile with independently specifiable
  boundary position/velocity/acceleration -- the standard smooth
  point-to-point profile (continuous position, velocity, *and*
  acceleration, i.e. bounded jerk).
* A trapezoidal (bang-coast-bang acceleration) velocity profile, the
  classic time-optimal-under-velocity/acceleration-limits profile used
  when cycle time matters more than jerk continuity.

``minimum_jerk_time_scaling`` is a normalised (0 -> 1) quintic used as the
"s-curve" that Cartesian linear/circular trajectories are parameterised
by, so that position moves smoothly even though the geometric path is a
straight line or arc.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class ScalarProfile:
    """A sampled scalar motion profile: position/velocity/acceleration/jerk
    over time, for one degree of freedom (or a normalised path parameter)."""

    t: np.ndarray
    q: np.ndarray
    qd: np.ndarray
    qdd: np.ndarray
    qddd: np.ndarray
    duration: float

    @property
    def peak_velocity(self) -> float:
        return float(np.max(np.abs(self.qd))) if len(self.qd) else 0.0

    @property
    def peak_acceleration(self) -> float:
        return float(np.max(np.abs(self.qdd))) if len(self.qdd) else 0.0

    @property
    def peak_jerk(self) -> float:
        return float(np.max(np.abs(self.qddd))) if len(self.qddd) else 0.0


def _quintic_coefficients(
    q0: float, q1: float, qd0: float, qd1: float, qdd0: float, qdd1: float, T: float
) -> np.ndarray:
    """Solve for the 6 coefficients of a quintic polynomial q(t) = sum a_i t^i
    satisfying the given boundary conditions at t=0 and t=T."""
    if T <= 0:
        raise ValueError("Quintic profile duration must be positive")
    A = np.array(
        [
            [1, 0, 0, 0, 0, 0],
            [0, 1, 0, 0, 0, 0],
            [0, 0, 2, 0, 0, 0],
            [1, T, T ** 2, T ** 3, T ** 4, T ** 5],
            [0, 1, 2 * T, 3 * T ** 2, 4 * T ** 3, 5 * T ** 4],
            [0, 0, 2, 6 * T, 12 * T ** 2, 20 * T ** 3],
        ]
    )
    b = np.array([q0, qd0, qdd0, q1, qd1, qdd1])
    return np.linalg.solve(A, b)


def quintic_scalar_profile(
    q0: float,
    q1: float,
    duration: float,
    qd0: float = 0.0,
    qd1: float = 0.0,
    qdd0: float = 0.0,
    qdd1: float = 0.0,
    dt: float = 0.01,
) -> ScalarProfile:
    """Sample a quintic polynomial point-to-point profile."""
    coeffs = _quintic_coefficients(q0, q1, qd0, qd1, qdd0, qdd1, duration)
    n_samples = max(2, int(np.ceil(duration / dt)) + 1)
    t = np.linspace(0.0, duration, n_samples)
    powers = np.vstack([t ** i for i in range(6)])
    q = coeffs @ powers
    d_powers = np.vstack([np.zeros_like(t)] + [i * t ** (i - 1) for i in range(1, 6)])
    qd = coeffs @ d_powers
    dd_powers = np.vstack(
        [np.zeros_like(t), np.zeros_like(t)]
        + [i * (i - 1) * t ** (i - 2) for i in range(2, 6)]
    )
    qdd = coeffs @ dd_powers
    ddd_powers = np.vstack(
        [np.zeros_like(t)] * 3 + [i * (i - 1) * (i - 2) * t ** (i - 3) for i in range(3, 6)]
    )
    qddd = coeffs @ ddd_powers
    return ScalarProfile(t=t, q=q, qd=qd, qdd=qdd, qddd=qddd, duration=duration)


def minimum_jerk_time_scaling(duration: float, dt: float = 0.01) -> ScalarProfile:
    """Normalised (0 -> 1) minimum-jerk time-scaling s(t), used to
    parameterise a fixed geometric path (Cartesian line/arc/spline) with a
    smooth, bounded-jerk speed profile."""
    return quintic_scalar_profile(0.0, 1.0, duration, dt=dt)


def estimate_quintic_duration(
    distance: float, max_velocity: float, max_acceleration: float, max_jerk: float | None = None
) -> float:
    """Estimate a feasible duration for a zero-to-zero-velocity quintic
    move of the given distance, respecting velocity/acceleration (and
    optionally jerk) limits.

    For a quintic profile the peak velocity is (15/8)*d/T and the peak
    acceleration is (10/(3*sqrt(3)))*d/T^2 for a symmetric zero-boundary
    move; we invert both bounds and take the binding (larger) duration.
    """
    distance = abs(distance)
    if distance < 1e-12:
        return 0.0
    max_velocity = max(max_velocity, 1e-9)
    max_acceleration = max(max_acceleration, 1e-9)
    T_vel = (15.0 / 8.0) * distance / max_velocity
    # For the normalised zero-boundary quintic s(u) = 10u^3 - 15u^4 + 6u^5
    # (u = t/T), |s''(u)| peaks at 10/sqrt(3) (u = 1/2 +/- 1/(2*sqrt(3))),
    # so peak acceleration = (10/sqrt(3)) * d / T^2.
    T_acc = np.sqrt((10.0 / np.sqrt(3.0)) * distance / max_acceleration)
    T = max(T_vel, T_acc)
    if max_jerk is not None and max_jerk > 0:
        # |s'''(u)| peaks at the endpoints (u = 0, 1) with value 60, so
        # peak jerk = 60 * d / T^3.
        T_jerk = (60.0 * distance / max_jerk) ** (1.0 / 3.0)
        T = max(T, T_jerk)
    return float(T)


def trapezoidal_scalar_profile(
    distance: float, max_velocity: float, max_acceleration: float, dt: float = 0.01
) -> ScalarProfile:
    """A time-optimal trapezoidal (bang-coast-bang) velocity profile from 0
    to ``distance`` respecting velocity/acceleration limits. Falls back to
    a triangular profile automatically when the distance is too short to
    reach ``max_velocity``.
    """
    d = abs(distance)
    sign = 1.0 if distance >= 0 else -1.0
    v = max(max_velocity, 1e-9)
    a = max(max_acceleration, 1e-9)

    t_acc = v / a
    d_acc = 0.5 * a * t_acc ** 2

    if 2 * d_acc >= d:
        # Triangular profile: never reaches max velocity.
        t_acc = np.sqrt(d / a) if d > 0 else 0.0
        t_flat = 0.0
        v_peak = a * t_acc
    else:
        t_flat = (d - 2 * d_acc) / v
        v_peak = v

    T = 2 * t_acc + t_flat
    n_samples = max(2, int(np.ceil(T / dt)) + 1) if T > 0 else 2
    t = np.linspace(0.0, T, n_samples)

    q = np.zeros_like(t)
    qd = np.zeros_like(t)
    qdd = np.zeros_like(t)

    for i, ti in enumerate(t):
        if ti <= t_acc:
            qdd[i] = a
            qd[i] = a * ti
            q[i] = 0.5 * a * ti ** 2
        elif ti <= t_acc + t_flat:
            qdd[i] = 0.0
            qd[i] = v_peak
            q[i] = d_acc if 2 * d_acc < d else 0.5 * a * t_acc ** 2
            q[i] = 0.5 * a * t_acc ** 2 + v_peak * (ti - t_acc)
        else:
            t_dec = ti - (t_acc + t_flat)
            qdd[i] = -a
            qd[i] = v_peak - a * t_dec
            q_at_decel_start = 0.5 * a * t_acc ** 2 + v_peak * t_flat
            q[i] = q_at_decel_start + v_peak * t_dec - 0.5 * a * t_dec ** 2

    q = np.clip(q, 0.0, d)
    qddd = np.gradient(qdd, t) if len(t) > 1 else np.zeros_like(t)
    return ScalarProfile(t=t, q=sign * q, qd=sign * qd, qdd=sign * qdd, qddd=sign * qddd, duration=T)
