"""Joint-space trajectory generation and validation.

Generates a synchronised multi-joint quintic trajectory: every joint uses
the *same* duration (the maximum of each joint's individually-required
duration to respect its own velocity/acceleration/jerk limits), so the
robot arrives at the target configuration with all joints stopping
simultaneously -- the standard industrial "coordinated joint move".
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np

from roboforge.core.exceptions import TrajectoryError
from roboforge.motion.trajectory.profiles import estimate_quintic_duration, quintic_scalar_profile

if TYPE_CHECKING:
    from roboforge.robotics.robot import Robot


@dataclass
class JointTrajectoryPoint:
    t: float
    position: np.ndarray
    velocity: np.ndarray
    acceleration: np.ndarray
    jerk: np.ndarray = field(default_factory=lambda: np.zeros(0))


@dataclass
class JointTrajectory:
    joint_names: list[str]
    points: list[JointTrajectoryPoint]

    @property
    def duration(self) -> float:
        return self.points[-1].t if self.points else 0.0

    @property
    def dof(self) -> int:
        return len(self.joint_names)

    def sample(self, t: float) -> JointTrajectoryPoint:
        """Linearly interpolate between the two nearest samples at time t."""
        if not self.points:
            raise TrajectoryError("Cannot sample an empty trajectory")
        t = float(np.clip(t, 0.0, self.duration))
        times = np.array([p.t for p in self.points])
        idx = int(np.searchsorted(times, t))
        if idx <= 0:
            return self.points[0]
        if idx >= len(self.points):
            return self.points[-1]
        p0, p1 = self.points[idx - 1], self.points[idx]
        span = p1.t - p0.t
        alpha = 0.0 if span <= 1e-12 else (t - p0.t) / span
        return JointTrajectoryPoint(
            t=t,
            position=p0.position + alpha * (p1.position - p0.position),
            velocity=p0.velocity + alpha * (p1.velocity - p0.velocity),
            acceleration=p0.acceleration + alpha * (p1.acceleration - p0.acceleration),
        )

    def max_velocity(self) -> np.ndarray:
        return np.max(np.abs([p.velocity for p in self.points]), axis=0)

    def max_acceleration(self) -> np.ndarray:
        return np.max(np.abs([p.acceleration for p in self.points]), axis=0)

    def total_joint_distance(self) -> np.ndarray:
        positions = np.array([p.position for p in self.points])
        return np.sum(np.abs(np.diff(positions, axis=0)), axis=0)


def generate_joint_trajectory(
    robot: "Robot",
    q_start: np.ndarray,
    q_end: np.ndarray,
    qd_start: np.ndarray | None = None,
    qd_end: np.ndarray | None = None,
    dt: float = 0.01,
    duration: float | None = None,
    velocity_scale: float | None = None,
    acceleration_scale: float | None = None,
) -> JointTrajectory:
    """Generate a coordinated, jerk-continuous joint-space move from
    ``q_start`` to ``q_end`` respecting each joint's configured velocity,
    acceleration, and jerk limits (scaled by the robot's global motion
    constraints unless overridden)."""
    q_start = np.asarray(q_start, dtype=float)
    q_end = np.asarray(q_end, dtype=float)
    n = robot.dof
    qd_start = np.zeros(n) if qd_start is None else np.asarray(qd_start, dtype=float)
    qd_end = np.zeros(n) if qd_end is None else np.asarray(qd_end, dtype=float)

    v_scale = velocity_scale if velocity_scale is not None else robot.motion_constraints.velocity_scale
    a_scale = acceleration_scale if acceleration_scale is not None else robot.motion_constraints.acceleration_scale

    robot.validate_joint_positions(q_start)
    robot.validate_joint_positions(q_end)

    if duration is None:
        required = []
        for j, q0, q1 in zip(robot.joints, q_start, q_end):
            d = float(q1 - q0)
            required.append(
                estimate_quintic_duration(
                    d, j.limits.max_velocity * v_scale, j.limits.max_acceleration * a_scale, j.limits.max_jerk
                )
            )
        duration = max(required) if required else 0.0
        duration = max(duration, 0.05)  # avoid degenerate zero-length moves

    profiles = [
        quintic_scalar_profile(q0, q1, duration, qd0, qd1, dt=dt)
        for q0, q1, qd0, qd1 in zip(q_start, q_end, qd_start, qd_end)
    ]
    n_samples = len(profiles[0].t) if profiles else 0
    points: list[JointTrajectoryPoint] = []
    for i in range(n_samples):
        position = np.array([p.q[i] for p in profiles])
        velocity = np.array([p.qd[i] for p in profiles])
        acceleration = np.array([p.qdd[i] for p in profiles])
        jerk = np.array([p.qddd[i] for p in profiles])
        points.append(
            JointTrajectoryPoint(
                t=float(profiles[0].t[i]),
                position=position,
                velocity=velocity,
                acceleration=acceleration,
                jerk=jerk,
            )
        )

    trajectory = JointTrajectory(joint_names=robot.joint_names, points=points)
    _validate_joint_trajectory(robot, trajectory, v_scale, a_scale)
    return trajectory


def _validate_joint_trajectory(robot: "Robot", trajectory: JointTrajectory, v_scale: float, a_scale: float) -> None:
    max_v = trajectory.max_velocity()
    max_a = trajectory.max_acceleration()
    for j, v, a in zip(robot.joints, max_v, max_a):
        if v > j.limits.max_velocity * v_scale + 1e-6:
            raise TrajectoryError(
                f"Generated trajectory exceeds velocity limit on joint {j.name!r}: {v:.4f} > "
                f"{j.limits.max_velocity * v_scale:.4f}"
            )
        if a > j.limits.max_acceleration * a_scale + 1e-6:
            raise TrajectoryError(
                f"Generated trajectory exceeds acceleration limit on joint {j.name!r}: {a:.4f} > "
                f"{j.limits.max_acceleration * a_scale:.4f}"
            )
    for point in trajectory.points:
        robot.clamp_joint_positions(point.position)  # cheap sanity pass
