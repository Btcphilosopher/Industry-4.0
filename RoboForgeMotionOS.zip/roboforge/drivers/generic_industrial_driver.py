"""``GenericIndustrialDriver``: a realistic skeleton for a real robot
controller driver (section 30), showing exactly where vendor-specific
wire protocol code (TCP/IP, EtherNet/IP, RTDE-style streaming, or a
vendor SDK) plugs into the same ``RobotDriver`` interface
``SimulationDriver`` implements.

No vendor SDK is bundled with this platform (section 40: "Do not create
empty placeholder classes unless the implementation genuinely requires
external hardware" -- this is exactly that case). Connecting genuinely
requires a reachable controller and its protocol; this class implements
the full command-validation and state-machine plumbing and fails
honestly (``DriverConnectionError``) at the one point that actually
needs real hardware: opening the socket.
"""

from __future__ import annotations

import socket
import time
from dataclasses import dataclass

from roboforge.core.enums import MotionState
from roboforge.core.exceptions import DriverCommandError, DriverConnectionError
from roboforge.drivers.command_model import RobotCommand
from roboforge.drivers.robot_driver import CommandResult, RobotDriver


@dataclass
class ControllerEndpoint:
    host: str
    port: int
    connect_timeout_s: float = 2.0


class GenericIndustrialDriver(RobotDriver):
    """A protocol-agnostic base for TCP/IP-connected industrial
    controllers. Subclasses override ``_encode_command``/``_decode_state``
    for a specific vendor's wire format; this base class handles the
    connection lifecycle, safety-state bookkeeping, and error surfacing
    that should be identical across vendors.
    """

    def __init__(self, robot_id: str, endpoint: ControllerEndpoint) -> None:
        super().__init__(robot_id)
        self.endpoint = endpoint
        self._socket: socket.socket | None = None
        self._motion_state = MotionState.DISCONNECTED

    def connect(self) -> None:
        try:
            self._socket = socket.create_connection(
                (self.endpoint.host, self.endpoint.port), timeout=self.endpoint.connect_timeout_s
            )
        except OSError as exc:
            raise DriverConnectionError(
                f"Could not connect to robot controller at {self.endpoint.host}:{self.endpoint.port}: {exc}"
            ) from exc
        self._connected = True
        self._motion_state = MotionState.INITIALISING

    def disconnect(self) -> None:
        if self._socket is not None:
            self._socket.close()
            self._socket = None
        self._connected = False
        self._motion_state = MotionState.DISCONNECTED

    def _require_connection(self) -> socket.socket:
        if self._socket is None or not self._connected:
            raise DriverConnectionError("Driver is not connected to a robot controller")
        return self._socket

    def enable(self) -> None:
        self._require_connection()
        self._motion_state = MotionState.ENABLED

    def disable(self) -> None:
        self._require_connection()
        self._motion_state = MotionState.READY

    def motion_state(self) -> MotionState:
        return self._motion_state

    def send_command(self, command: RobotCommand) -> CommandResult:
        sock = self._require_connection()
        payload = self._encode_command(command)
        try:
            sock.sendall(payload)
        except OSError as exc:
            raise DriverConnectionError(f"Failed to send command to controller: {exc}") from exc
        return CommandResult(True, "command_sent")

    def get_state(self):
        raise NotImplementedError(
            "GenericIndustrialDriver.get_state requires a vendor-specific wire-format decoder; "
            "subclass and implement _decode_state()"
        )

    def stop(self, reason: str = "") -> None:
        self._motion_state = MotionState.STOPPING
        if self._socket is not None:
            try:
                self._socket.sendall(self._encode_stop())
            except OSError:
                pass
        self._motion_state = MotionState.STOPPED

    def pause(self) -> None:
        self._motion_state = MotionState.PAUSED

    def resume(self) -> None:
        self._motion_state = MotionState.MOVING

    # -- vendor-specific hooks (override in a concrete subclass) ---------
    def _encode_command(self, command: RobotCommand) -> bytes:
        raise NotImplementedError("Subclasses must implement _encode_command for their controller's wire protocol")

    def _encode_stop(self) -> bytes:
        raise NotImplementedError("Subclasses must implement _encode_stop for their controller's wire protocol")

    def _decode_state(self, raw: bytes):
        raise NotImplementedError("Subclasses must implement _decode_state for their controller's wire protocol")
