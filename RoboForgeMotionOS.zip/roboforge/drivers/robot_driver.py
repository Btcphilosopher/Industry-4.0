"""``RobotDriver``: the abstract universal hardware interface (section
30). Concrete drivers (simulation, a specific vendor's controller) all
implement this same interface, so nothing above the driver layer
(planning, manipulation, the API) needs to know or care which one it's
talking to.
"""

from __future__ import annotations

import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from roboforge.core.enums import MotionState
from roboforge.drivers.command_model import RobotCommand

if TYPE_CHECKING:
    from roboforge.robotics.state.robot_state import RobotState


@dataclass
class CommandResult:
    accepted: bool
    message: str = ""
    started_at: float = field(default_factory=time.time)


class RobotDriver(ABC):
    """A driver owns the connection lifecycle and command execution for
    exactly one physical (or simulated) robot controller.
    """

    def __init__(self, robot_id: str) -> None:
        self.robot_id = robot_id
        self._connected = False

    @property
    def connected(self) -> bool:
        return self._connected

    @abstractmethod
    def connect(self) -> None:
        ...

    @abstractmethod
    def disconnect(self) -> None:
        ...

    @abstractmethod
    def enable(self) -> None:
        ...

    @abstractmethod
    def disable(self) -> None:
        ...

    @abstractmethod
    def send_command(self, command: RobotCommand) -> CommandResult:
        ...

    @abstractmethod
    def get_state(self) -> "RobotState":
        ...

    @abstractmethod
    def stop(self, reason: str = "") -> None:
        ...

    @abstractmethod
    def pause(self) -> None:
        ...

    @abstractmethod
    def resume(self) -> None:
        ...

    @abstractmethod
    def motion_state(self) -> MotionState:
        ...
