"""``SimulationDriver``: a full ``RobotDriver`` implementation backed by
``SimulatedRobot`` -- every command type in the command model is
validated through the safety state machine, planned by the
``MotionPlanner``, and executed kinematically in simulation. This is the
reference implementation every real driver's behaviour (from the caller's
point of view) must match.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from roboforge.core.enums import IKMethod, MotionState
from roboforge.core.exceptions import DriverCommandError, RoboForgeError, SafetyViolationError
from roboforge.drivers.command_model import (
    CloseGripper,
    MoveCartesian,
    MoveCircular,
    MoveJoint,
    MoveLinear,
    OpenGripper,
    Pause,
    Resume,
    RobotCommand,
    SetForce,
    SetImpedance,
    SetVelocity,
    Stop,
)
from roboforge.drivers.robot_driver import CommandResult, RobotDriver
from roboforge.events.events import RobotConnected, RobotEnabled
from roboforge.manipulation.contact.force_control import ForceController
from roboforge.manipulation.contact.impedance_control import ImpedanceController
from roboforge.manipulation.tools.gripper import GripperController
from roboforge.motion.planner.planner import MotionPlanner
from roboforge.motion.servo.cartesian_servo import CartesianServoController
from roboforge.motion.trajectory.cartesian_trajectory import generate_circular_cartesian_trajectory
from roboforge.safety.safety_state_machine import SafetyStateMachine
from roboforge.simulation.simulated_robot import SimulatedRobot

if TYPE_CHECKING:
    from roboforge.collision.collision_engine import CollisionEngine
    from roboforge.events.event_bus import EventBus
    from roboforge.robotics.robot import Robot
    from roboforge.robotics.state.robot_state import RobotState
    from roboforge.telemetry.telemetry_recorder import TelemetryRecorder


class SimulationDriver(RobotDriver):
    def __init__(
        self,
        robot: "Robot",
        collision_engine: "CollisionEngine | None" = None,
        event_bus: "EventBus | None" = None,
        telemetry: "TelemetryRecorder | None" = None,
    ) -> None:
        super().__init__(robot.robot_id)
        self.robot = robot
        self.collision_engine = collision_engine
        self.event_bus = event_bus
        self.telemetry = telemetry

        self.safety = SafetyStateMachine(robot)
        self.planner = MotionPlanner(robot)
        self.sim_robot = SimulatedRobot(robot)
        self.servo = CartesianServoController(robot)
        self.force_controller = ForceController(robot)
        self.impedance_controller = ImpedanceController(robot)
        self.gripper: GripperController | None = GripperController(robot.tool) if robot.tool else None

    def connect(self) -> None:
        self.robot.motion_state = MotionState.DISCONNECTED
        self.safety.transition_to(MotionState.INITIALISING, reason="driver_connect")
        self.safety.transition_to(MotionState.READY, reason="simulation_ready")
        self.safety.watchdog.kick()
        self._connected = True
        if self.event_bus:
            self.event_bus.publish(RobotConnected(robot_id=self.robot_id, driver_name="SimulationDriver"))

    def disconnect(self) -> None:
        self._connected = False
        self.robot.motion_state = MotionState.DISCONNECTED

    def enable(self) -> None:
        self.safety.transition_to(MotionState.ENABLED, reason="driver_enable")
        if self.event_bus:
            self.event_bus.publish(RobotEnabled(robot_id=self.robot_id))

    def disable(self) -> None:
        self.safety.transition_to(MotionState.READY, reason="driver_disable")

    def motion_state(self) -> MotionState:
        return self.robot.motion_state

    def stop(self, reason: str = "") -> None:
        self.safety.emergency_stop(reason or "driver_stop")

    def pause(self) -> None:
        self.safety.transition_to(MotionState.PAUSED, reason="driver_pause")

    def resume(self) -> None:
        self.safety.transition_to(MotionState.MOVING, reason="driver_resume")

    def get_state(self) -> "RobotState":
        from roboforge.robotics.state.robot_state import RobotState

        return RobotState(
            robot_id=self.robot_id,
            joint_state=self.robot.joint_state,
            tcp_pose=self.robot.forward_kinematics(),
            motion_state=self.robot.motion_state,
            safety_level=self.robot.safety_level,
            manipulability=self.robot.manipulability(),
        )

    # -- command dispatch --------------------------------------------------
    def send_command(self, command: RobotCommand) -> CommandResult:
        self.safety.watchdog.kick()
        try:
            if isinstance(command, MoveJoint):
                return self._handle_move_joint(command)
            if isinstance(command, MoveCartesian):
                return self._handle_move_cartesian(command)
            if isinstance(command, MoveLinear):
                return self._handle_move_linear(command)
            if isinstance(command, MoveCircular):
                return self._handle_move_circular(command)
            if isinstance(command, SetVelocity):
                qd = self.servo.set_cartesian_velocity(command.linear, command.angular)
                self.robot.validate_joint_velocities(qd)
                return CommandResult(True, "cartesian_velocity_applied")
            if isinstance(command, SetForce):
                self.force_controller.set_force_target(command.force, command.torque)
                return CommandResult(True, "force_target_set")
            if isinstance(command, SetImpedance):
                self.impedance_controller.set_impedance(command.stiffness, command.damping)
                return CommandResult(True, "impedance_set")
            if isinstance(command, OpenGripper):
                if self.gripper is None:
                    raise DriverCommandError("No gripper attached")
                self.gripper.open()
                return CommandResult(True, "gripper_open")
            if isinstance(command, CloseGripper):
                if self.gripper is None:
                    raise DriverCommandError("No gripper attached")
                self.gripper.close(command.object_width_m, command.grip_force_n)
                return CommandResult(True, "gripper_close")
            if isinstance(command, Stop):
                self.stop(command.reason)
                return CommandResult(True, "stopped")
            if isinstance(command, Pause):
                self.pause()
                return CommandResult(True, "paused")
            if isinstance(command, Resume):
                self.resume()
                return CommandResult(True, "resumed")
        except SafetyViolationError as exc:
            return CommandResult(False, f"rejected_by_safety: {exc}")
        except DriverCommandError as exc:
            return CommandResult(False, str(exc))
        except RoboForgeError as exc:
            # Any other validation failure (joint-limit, trajectory,
            # workspace, kinematics, ...) is a rejected command, not an
            # unhandled exception -- section 31: "commands should be
            # validated before execution."
            return CommandResult(False, f"command_rejected: {exc}")

        raise DriverCommandError(f"Unsupported command type: {type(command).__name__}")

    def _run_trajectory(self, trajectory) -> CommandResult:
        report = self.safety.validate_trajectory(trajectory, self.collision_engine)
        if not report.valid:
            return CommandResult(False, f"trajectory_validation_failed: {report.violations[:3]}")
        self.safety.transition_to(MotionState.MOVING, reason="trajectory_execution")
        result = self.sim_robot.execute_trajectory(trajectory, event_bus=self.event_bus, telemetry=self.telemetry)
        self.safety.transition_to(MotionState.ENABLED, reason="trajectory_complete")
        return CommandResult(result.success, "trajectory_executed" if result.success else result.aborted_reason)

    def _handle_move_joint(self, command: MoveJoint) -> CommandResult:
        from roboforge.motion.trajectory.joint_trajectory import generate_joint_trajectory

        trajectory = generate_joint_trajectory(
            self.robot,
            self.robot.joint_state.position,
            np.asarray(command.target_positions, dtype=float),
            velocity_scale=command.velocity_scale,
            acceleration_scale=command.acceleration_scale,
        )
        return self._run_trajectory(trajectory)

    def _handle_move_cartesian(self, command: MoveCartesian) -> CommandResult:
        result = self.robot.inverse_kinematics(command.target_pose, initial_guess=self.robot.joint_state.position)
        if not result.success:
            return CommandResult(False, "target_pose_unreachable")
        from roboforge.motion.trajectory.joint_trajectory import generate_joint_trajectory

        trajectory = generate_joint_trajectory(
            self.robot, self.robot.joint_state.position, result.joint_positions,
            velocity_scale=command.velocity_scale, acceleration_scale=command.acceleration_scale,
        )
        return self._run_trajectory(trajectory)

    def _handle_move_linear(self, command: MoveLinear) -> CommandResult:
        checker = self.collision_engine.as_checker() if self.collision_engine else None
        joint_trajectory = self.planner.plan_cartesian(
            self.robot.forward_kinematics(), command.target_pose, self.robot.joint_state.position, checker
        )
        return self._run_trajectory(joint_trajectory)

    def _handle_move_circular(self, command: MoveCircular) -> CommandResult:
        current = self.robot.forward_kinematics()
        cart_trajectory = generate_circular_cartesian_trajectory(
            command.centre, command.normal, command.radius, command.start_angle, command.end_angle,
            current.rotation, max_linear_velocity=command.max_linear_velocity,
        )
        # Convert the Cartesian trajectory to joint space via per-sample IK.
        from roboforge.motion.trajectory.joint_trajectory import JointTrajectory, JointTrajectoryPoint

        q = self.robot.joint_state.position
        points = []
        for cp in cart_trajectory.points:
            ik = self.robot.inverse_kinematics(cp.pose, initial_guess=q, method=IKMethod.DAMPED_LEAST_SQUARES)
            if not ik.success:
                return CommandResult(False, "circular_path_unreachable")
            q = ik.joint_positions
            points.append(JointTrajectoryPoint(t=cp.t, position=q.copy(), velocity=np.zeros(self.robot.dof),
                                                acceleration=np.zeros(self.robot.dof)))
        joint_trajectory = JointTrajectory(joint_names=self.robot.joint_names, points=points)
        return self._run_trajectory(joint_trajectory)
