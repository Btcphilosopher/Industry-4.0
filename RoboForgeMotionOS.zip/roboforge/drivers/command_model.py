"""The strongly-typed robot command model (section 31). Every command a
driver executes is one of these dataclasses; ``RobotDriver.send_command``
validates the command's fields (via the safety layer) before doing
anything else, so an invalid command is rejected uniformly regardless of
which concrete driver receives it.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from roboforge.core.transforms import Pose


@dataclass
class RobotCommand:
    """Base class for all robot commands."""


@dataclass
class MoveJoint(RobotCommand):
    target_positions: np.ndarray
    velocity_scale: float = 1.0
    acceleration_scale: float = 1.0


@dataclass
class MoveCartesian(RobotCommand):
    target_pose: Pose
    velocity_scale: float = 1.0
    acceleration_scale: float = 1.0


@dataclass
class MoveLinear(RobotCommand):
    target_pose: Pose
    max_linear_velocity: float = 0.25
    max_linear_acceleration: float = 1.0


@dataclass
class MoveCircular(RobotCommand):
    centre: np.ndarray
    normal: np.ndarray
    radius: float
    start_angle: float
    end_angle: float
    max_linear_velocity: float = 0.25


@dataclass
class SetVelocity(RobotCommand):
    linear: np.ndarray = field(default_factory=lambda: np.zeros(3))
    angular: np.ndarray = field(default_factory=lambda: np.zeros(3))


@dataclass
class SetForce(RobotCommand):
    force: np.ndarray = field(default_factory=lambda: np.zeros(3))
    torque: np.ndarray = field(default_factory=lambda: np.zeros(3))


@dataclass
class SetImpedance(RobotCommand):
    stiffness: np.ndarray = field(default_factory=lambda: np.full(6, 500.0))
    damping: np.ndarray = field(default_factory=lambda: np.full(6, 50.0))


@dataclass
class OpenGripper(RobotCommand):
    pass


@dataclass
class CloseGripper(RobotCommand):
    object_width_m: float | None = None
    grip_force_n: float = 20.0


@dataclass
class Stop(RobotCommand):
    reason: str = "operator_stop"


@dataclass
class Pause(RobotCommand):
    pass


@dataclass
class Resume(RobotCommand):
    pass
