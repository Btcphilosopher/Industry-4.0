"""A standard discrete-time linear Kalman filter (section 25), used per
joint (constant-acceleration model) to fuse noisy/quantised encoder
readings into smooth position/velocity/acceleration estimates.
"""

from __future__ import annotations

import numpy as np


class KalmanFilter:
    def __init__(self, F: np.ndarray, H: np.ndarray, Q: np.ndarray, R: np.ndarray,
                 x0: np.ndarray, P0: np.ndarray) -> None:
        self.F = F  # state transition
        self.H = H  # observation model
        self.Q = Q  # process noise covariance
        self.R = R  # measurement noise covariance
        self.x = np.asarray(x0, dtype=float)
        self.P = np.asarray(P0, dtype=float)

    def predict(self, B: np.ndarray | None = None, u: np.ndarray | None = None) -> None:
        if B is not None and u is not None:
            self.x = self.F @ self.x + B @ u
        else:
            self.x = self.F @ self.x
        self.P = self.F @ self.P @ self.F.T + self.Q

    def update(self, z: np.ndarray) -> None:
        z = np.asarray(z, dtype=float)
        y = z - self.H @ self.x
        S = self.H @ self.P @ self.H.T + self.R
        K = self.P @ self.H.T @ np.linalg.inv(S)
        self.x = self.x + K @ y
        I = np.eye(self.P.shape[0])
        self.P = (I - K @ self.H) @ self.P

    @classmethod
    def constant_acceleration_1d(
        cls, dt: float, process_noise: float = 1.0, measurement_noise: float = 1e-4
    ) -> "KalmanFilter":
        """A 3-state (position, velocity, acceleration) constant-acceleration
        model observing position only -- the standard model for smoothing
        an encoder position stream into position/velocity/acceleration."""
        F = np.array([[1, dt, 0.5 * dt ** 2], [0, 1, dt], [0, 0, 1]])
        H = np.array([[1.0, 0.0, 0.0]])
        # Discretised white-noise-acceleration process noise.
        q = process_noise
        Q = q * np.array(
            [
                [dt ** 5 / 20, dt ** 4 / 8, dt ** 3 / 6],
                [dt ** 4 / 8, dt ** 3 / 3, dt ** 2 / 2],
                [dt ** 3 / 6, dt ** 2 / 2, dt],
            ]
        )
        R = np.array([[measurement_noise]])
        x0 = np.zeros(3)
        P0 = np.eye(3) * 1.0
        return cls(F, H, Q, R, x0, P0)
