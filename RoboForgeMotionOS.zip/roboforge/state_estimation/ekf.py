"""Extended and unscented Kalman filters (section 25) for nonlinear
state estimation -- e.g. tracking an object's SE(3) pose from noisy
camera detections, where the observation model (projection, or a pose
composed through a moving camera frame) is not linear in the state.
"""

from __future__ import annotations

from typing import Callable

import numpy as np


class ExtendedKalmanFilter:
    """A generic EKF: ``f`` and ``h`` are the (possibly nonlinear) process
    and observation models; their Jacobians are computed by central
    finite differences if not supplied analytically, which keeps this
    usable for arbitrary state/observation models without hand-deriving
    Jacobians for each use case.
    """

    def __init__(
        self,
        f: Callable[[np.ndarray], np.ndarray],
        h: Callable[[np.ndarray], np.ndarray],
        Q: np.ndarray,
        R: np.ndarray,
        x0: np.ndarray,
        P0: np.ndarray,
        F_jacobian: Callable[[np.ndarray], np.ndarray] | None = None,
        H_jacobian: Callable[[np.ndarray], np.ndarray] | None = None,
    ) -> None:
        self.f = f
        self.h = h
        self.Q = Q
        self.R = R
        self.x = np.asarray(x0, dtype=float)
        self.P = np.asarray(P0, dtype=float)
        self._F_jac = F_jacobian
        self._H_jac = H_jacobian

    @staticmethod
    def _numerical_jacobian(fn: Callable[[np.ndarray], np.ndarray], x: np.ndarray, eps: float = 1e-6) -> np.ndarray:
        n = len(x)
        y0 = fn(x)
        m = len(y0)
        J = np.zeros((m, n))
        for i in range(n):
            dx = np.zeros(n)
            dx[i] = eps
            J[:, i] = (fn(x + dx) - fn(x - dx)) / (2 * eps)
        return J

    def predict(self) -> None:
        F = self._F_jac(self.x) if self._F_jac else self._numerical_jacobian(self.f, self.x)
        self.x = self.f(self.x)
        self.P = F @ self.P @ F.T + self.Q

    def update(self, z: np.ndarray) -> None:
        z = np.asarray(z, dtype=float)
        H = self._H_jac(self.x) if self._H_jac else self._numerical_jacobian(self.h, self.x)
        y = z - self.h(self.x)
        S = H @ self.P @ H.T + self.R
        K = self.P @ H.T @ np.linalg.inv(S)
        self.x = self.x + K @ y
        I = np.eye(self.P.shape[0])
        self.P = (I - K @ H) @ self.P


class UnscentedKalmanFilter:
    """A minimal UKF (scaled unscented transform) for cases where the
    nonlinearity is too severe for an EKF's local linearisation to track
    reliably (e.g. large orientation changes)."""

    def __init__(
        self,
        f: Callable[[np.ndarray], np.ndarray],
        h: Callable[[np.ndarray], np.ndarray],
        Q: np.ndarray,
        R: np.ndarray,
        x0: np.ndarray,
        P0: np.ndarray,
        alpha: float = 1e-3,
        beta: float = 2.0,
        kappa: float = 0.0,
    ) -> None:
        self.f = f
        self.h = h
        self.Q = Q
        self.R = R
        self.x = np.asarray(x0, dtype=float)
        self.P = np.asarray(P0, dtype=float)
        self.n = len(x0)
        self.alpha, self.beta, self.kappa = alpha, beta, kappa
        self.lam = alpha ** 2 * (self.n + kappa) - self.n
        self._compute_weights()

    def _compute_weights(self) -> None:
        n, lam = self.n, self.lam
        self.Wm = np.full(2 * n + 1, 1.0 / (2 * (n + lam)))
        self.Wc = self.Wm.copy()
        self.Wm[0] = lam / (n + lam)
        self.Wc[0] = lam / (n + lam) + (1 - self.alpha ** 2 + self.beta)

    def _sigma_points(self, x: np.ndarray, P: np.ndarray) -> np.ndarray:
        n = self.n
        sqrt_matrix = np.linalg.cholesky((n + self.lam) * P + np.eye(n) * 1e-12)
        points = [x]
        for i in range(n):
            points.append(x + sqrt_matrix[:, i])
            points.append(x - sqrt_matrix[:, i])
        return np.array(points)

    def predict(self) -> None:
        sigmas = self._sigma_points(self.x, self.P)
        sigmas_f = np.array([self.f(s) for s in sigmas])
        x_pred = np.sum(self.Wm[:, None] * sigmas_f, axis=0)
        P_pred = self.Q.copy()
        for i in range(len(sigmas_f)):
            diff = (sigmas_f[i] - x_pred).reshape(-1, 1)
            P_pred += self.Wc[i] * (diff @ diff.T)
        self.x, self.P = x_pred, P_pred
        self._sigmas_f = sigmas_f

    def update(self, z: np.ndarray) -> None:
        z = np.asarray(z, dtype=float)
        sigmas_f = getattr(self, "_sigmas_f", self._sigma_points(self.x, self.P))
        sigmas_h = np.array([self.h(s) for s in sigmas_f])
        z_pred = np.sum(self.Wm[:, None] * sigmas_h, axis=0)

        Pzz = self.R.copy()
        Pxz = np.zeros((self.n, len(z)))
        for i in range(len(sigmas_f)):
            dz = (sigmas_h[i] - z_pred).reshape(-1, 1)
            dx = (sigmas_f[i] - self.x).reshape(-1, 1)
            Pzz += self.Wc[i] * (dz @ dz.T)
            Pxz += self.Wc[i] * (dx @ dz.T)

        K = Pxz @ np.linalg.inv(Pzz)
        self.x = self.x + K @ (z - z_pred)
        self.P = self.P - K @ Pzz @ K.T
