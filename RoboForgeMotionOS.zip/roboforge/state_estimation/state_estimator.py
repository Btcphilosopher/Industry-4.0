"""The robot state estimator (section 25): fuses per-joint encoder
streams (via constant-acceleration Kalman filters) and F/T sensor
readings into a coherent ``RobotState`` -- joint position/velocity/
acceleration, TCP pose/twist, external force/torque, and a
contact-detected flag.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from roboforge.core.enums import MotionState, SafetyLevel
from roboforge.core.transforms import Twist
from roboforge.robotics.state.joint_state import JointState
from roboforge.robotics.state.robot_state import RobotState
from roboforge.sensors.encoder import SimulatedEncoder
from roboforge.sensors.force_torque_sensor import SimulatedForceTorqueSensor
from roboforge.state_estimation.kalman_filter import KalmanFilter

if TYPE_CHECKING:
    from roboforge.robotics.robot import Robot


def complementary_filter(estimate_a: np.ndarray, estimate_b: np.ndarray, alpha: float = 0.98) -> np.ndarray:
    """Blend a low-noise/low-drift estimate (``estimate_a``, weight
    ``alpha``) with a high-noise/no-drift estimate (``estimate_b``,
    weight ``1 - alpha``) -- e.g. integrated joint velocity vs. a raw
    encoder-derived velocity, or gyro-integrated orientation vs. an
    accelerometer/vision-derived orientation."""
    return alpha * np.asarray(estimate_a, dtype=float) + (1 - alpha) * np.asarray(estimate_b, dtype=float)


class RobotStateEstimator:
    def __init__(
        self,
        robot: "Robot",
        encoders: list[SimulatedEncoder] | None = None,
        force_torque_sensor: SimulatedForceTorqueSensor | None = None,
        dt: float = 0.01,
        contact_force_threshold_n: float = 5.0,
    ) -> None:
        self.robot = robot
        self.dt = dt
        self.contact_force_threshold_n = contact_force_threshold_n
        self.encoders = encoders or [SimulatedEncoder(f"enc_{j.name}") for j in robot.joints]
        self.force_torque_sensor = force_torque_sensor
        self._filters = [KalmanFilter.constant_acceleration_1d(dt) for _ in range(robot.dof)]
        for kf, joint in zip(self._filters, robot.joints):
            kf.x[0] = joint.home_position

    def sync_true_positions(self, q: np.ndarray) -> None:
        """Feed the encoders' internal "true value" from the simulation
        (or a real driver's raw feedback would call ``read()`` directly
        instead of this)."""
        for enc, value in zip(self.encoders, q):
            enc.set_true_value(float(value))

    def estimate_joint_state(self) -> JointState:
        positions, velocities, accelerations, torques = [], [], [], []
        for kf, enc, joint in zip(self._filters, self.encoders, self.robot.joints):
            reading = enc.read()
            kf.predict()
            kf.update(np.array([reading.value]))
            positions.append(kf.x[0])
            velocities.append(kf.x[1])
            accelerations.append(kf.x[2])
            torques.append(joint.limits.max_torque * 0.0)  # torque needs a dedicated sensor/estimator
        return JointState(
            names=self.robot.joint_names,
            position=np.array(positions),
            velocity=np.array(velocities),
            acceleration=np.array(accelerations),
            torque=np.array(torques),
        )

    def estimate_robot_state(self) -> RobotState:
        joint_state = self.estimate_joint_state()
        tcp_pose = self.robot.forward_kinematics(joint_state.position)

        J = self.robot.jacobian(joint_state.position)
        twist_vec = J @ joint_state.velocity
        tcp_twist = Twist(linear=twist_vec[:3], angular=twist_vec[3:])

        external_force = np.zeros(3)
        external_torque = np.zeros(3)
        in_contact = False
        if self.force_torque_sensor is not None:
            reading = self.force_torque_sensor.read()
            wrench = reading.value
            external_force, external_torque = wrench[:3], wrench[3:]
            in_contact = float(np.linalg.norm(external_force)) > self.contact_force_threshold_n

        manipulability = self.robot.manipulability(joint_state.position)

        return RobotState(
            robot_id=self.robot.robot_id,
            joint_state=joint_state,
            tcp_pose=tcp_pose,
            tcp_twist=tcp_twist,
            motion_state=self.robot.motion_state,
            safety_level=self.robot.safety_level,
            external_force=external_force,
            external_torque=external_torque,
            in_contact=in_contact,
            gripper_state=(
                f"jaw={self.robot.tool.jaw_position_m:.4f}m" if self.robot.tool is not None else None
            ),
            manipulability=manipulability,
        )
