"""Robot-to-robot handoff engine (section 23):

    Robot A approaches -> Robot B approaches -> shared coordinate
    alignment -> force/contact verification -> Robot B grasps -> Robot A
    releases -> Robot B verifies possession

The handoff fails safely (aborts without releasing) at the first stage
whose precondition isn't met -- it never proceeds to "Robot A releases"
without both alignment and grasp confidence checks passing, since a
premature release with insufficient grip confidence would drop the part.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, TYPE_CHECKING

import numpy as np

from roboforge.core.transforms import Pose
from roboforge.manipulation.tools.gripper import GripperController

if TYPE_CHECKING:
    from roboforge.robotics.robot import Robot


class HandoffStage(str, Enum):
    APPROACH_A = "approach_a"
    APPROACH_B = "approach_b"
    ALIGNMENT_CHECK = "alignment_check"
    CONTACT_VERIFICATION = "contact_verification"
    GRASP_B = "grasp_b"
    RELEASE_A = "release_a"
    VERIFY_POSSESSION = "verify_possession"
    COMPLETE = "complete"


@dataclass
class HandoffResult:
    success: bool
    final_stage: HandoffStage
    failure_reason: str = ""
    alignment_error_m: float | None = None
    alignment_error_rad: float | None = None
    grip_confidence: float | None = None
    joints_a: np.ndarray | None = None
    joints_b: np.ndarray | None = None


class HandoffEngine:
    def __init__(self, robot_a: "Robot", robot_b: "Robot",
                 gripper_a: GripperController, gripper_b: GripperController) -> None:
        self.robot_a = robot_a
        self.robot_b = robot_b
        self.gripper_a = gripper_a
        self.gripper_b = gripper_b

    def execute(
        self,
        handoff_pose_a: Pose,
        handoff_pose_b: Pose,
        object_width_m: float,
        alignment_tolerance_m: float = 0.003,
        alignment_tolerance_rad: float = 0.02,
        min_grip_confidence: float = 0.85,
        contact_force_fn: Callable[[], np.ndarray] | None = None,
        max_contact_force_n: float = 30.0,
    ) -> HandoffResult:
        # -- 1. Robot A approaches -------------------------------------
        result_a = self.robot_a.inverse_kinematics(handoff_pose_a, initial_guess=self.robot_a.joint_state.position)
        if not result_a.success:
            return HandoffResult(False, HandoffStage.APPROACH_A, "robot_a_unreachable")

        # -- 2. Robot B approaches --------------------------------------
        result_b = self.robot_b.inverse_kinematics(handoff_pose_b, initial_guess=self.robot_b.joint_state.position)
        if not result_b.success:
            return HandoffResult(False, HandoffStage.APPROACH_B, "robot_b_unreachable", joints_a=result_a.joint_positions)

        # -- 3. Shared coordinate alignment check ------------------------
        alignment_error_m = handoff_pose_a.distance_to(handoff_pose_b)
        alignment_error_rad = handoff_pose_a.angular_distance_to(handoff_pose_b)
        if alignment_error_m > alignment_tolerance_m or alignment_error_rad > alignment_tolerance_rad:
            return HandoffResult(
                False, HandoffStage.ALIGNMENT_CHECK, "alignment_out_of_tolerance",
                alignment_error_m=alignment_error_m, alignment_error_rad=alignment_error_rad,
                joints_a=result_a.joint_positions, joints_b=result_b.joint_positions,
            )

        # -- 4. Force/contact verification (optional but recommended) ----
        if contact_force_fn is not None:
            force = contact_force_fn()
            magnitude = float(np.linalg.norm(force))
            if magnitude > max_contact_force_n:
                return HandoffResult(
                    False, HandoffStage.CONTACT_VERIFICATION, "excessive_contact_force",
                    alignment_error_m=alignment_error_m, alignment_error_rad=alignment_error_rad,
                )

        # -- 5. Robot B grasps --------------------------------------------
        grasp_result = self.gripper_b.close(object_width_m=object_width_m)
        grip_confidence = 1.0 if grasp_result.is_gripping else 0.0
        if grip_confidence < min_grip_confidence:
            return HandoffResult(
                False, HandoffStage.GRASP_B, "insufficient_grip_confidence",
                alignment_error_m=alignment_error_m, alignment_error_rad=alignment_error_rad,
                grip_confidence=grip_confidence,
            )

        # -- 6. Robot A releases (only now that B's grasp is confirmed) --
        self.gripper_a.open()

        # -- 7. Robot B verifies possession --------------------------------
        if not self.gripper_b.is_object_grasped() or self.gripper_a.is_object_grasped():
            return HandoffResult(
                False, HandoffStage.VERIFY_POSSESSION, "possession_not_confirmed",
                alignment_error_m=alignment_error_m, alignment_error_rad=alignment_error_rad,
                grip_confidence=grip_confidence,
            )

        return HandoffResult(
            True, HandoffStage.COMPLETE,
            alignment_error_m=alignment_error_m, alignment_error_rad=alignment_error_rad,
            grip_confidence=grip_confidence,
            joints_a=result_a.joint_positions, joints_b=result_b.joint_positions,
        )
