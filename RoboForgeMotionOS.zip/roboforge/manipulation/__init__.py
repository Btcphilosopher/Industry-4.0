"""Manipulation: grasping, contact/force control, insertion, robot-to-robot
handoff, and end-effector/tool control (sections 10-12, 20, 23)."""
