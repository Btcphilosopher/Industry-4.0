"""Contact-rich insertion/assembly (section 20)."""

from roboforge.manipulation.insertion.insertion_controller import InsertionController, InsertionResult

__all__ = ["InsertionController", "InsertionResult"]
