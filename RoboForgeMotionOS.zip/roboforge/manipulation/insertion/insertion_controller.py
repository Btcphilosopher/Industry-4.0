"""Contact-rich insertion/assembly (section 20): the robot transitions
between free-space motion and force-guided contact motion --

    approach (free-space) -> search (contact) -> align -> insert (contact,
    force-monitored) -> verify

using the micro-motion engine for alignment search and force feedback to
detect/limit contact during the final insertion push. Works against any
source of force/pose feedback (real F/T sensor + encoders, or a
simulation physics callback) via the injected ``force_sensor_fn``.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, TYPE_CHECKING

import numpy as np

from roboforge.core.exceptions import RoboForgeError
from roboforge.core.transforms import Pose
from roboforge.manipulation.contact.force_control import ForceController
from roboforge.motion.micro_motion.micro_motion_engine import MicroMotionEngine, SearchResult

if TYPE_CHECKING:
    from roboforge.robotics.robot import Robot

ForceSensorFn = Callable[[Pose], np.ndarray]  # pose -> measured [Fx,Fy,Fz]


@dataclass
class InsertionResult:
    success: bool
    final_pose: Pose
    depth_reached_m: float
    peak_force_n: float
    search_result: SearchResult | None
    aborted_reason: str = ""


class InsertionController:
    def __init__(self, robot: "Robot") -> None:
        self.robot = robot
        self.micro_motion = MicroMotionEngine(robot)
        self.force_controller = ForceController(robot)

    def insert(
        self,
        nominal_target: Pose,
        insertion_axis_local: np.ndarray,
        insertion_depth_m: float,
        force_sensor_fn: ForceSensorFn,
        search_radius_m: float = 0.002,
        search_step_m: float = 0.0002,
        step_size_m: float = 0.0002,
        max_force_n: float = 40.0,
        target_insertion_force_n: float = 10.0,
        contact_checker: Callable[[Pose], bool] | None = None,
    ) -> InsertionResult:
        """Run a full search -> align -> force-guided-insert sequence.

        ``force_sensor_fn`` is called with the candidate pose at each
        insertion step and must return the (simulated or real) measured
        3-axis force at that pose -- this is how the controller stays
        agnostic to whether it's driving a real F/T sensor or the
        simulation engine's physics model.
        """
        axis_world = nominal_target.rotation @ (insertion_axis_local / np.linalg.norm(insertion_axis_local))

        search_result = None
        aligned_pose = nominal_target
        if contact_checker is not None:
            search_result = self.micro_motion.search(
                "spiral", search_radius_m, search_step_m, nominal_target, contact_checker
            )
            if not search_result.found:
                return InsertionResult(
                    success=False,
                    final_pose=nominal_target,
                    depth_reached_m=0.0,
                    peak_force_n=0.0,
                    search_result=search_result,
                    aborted_reason="alignment_search_exhausted",
                )
            aligned_pose = search_result.pose

        self.force_controller.set_force_target(target_insertion_force_n * axis_world)

        depth = 0.0
        peak_force = 0.0
        current_pose = aligned_pose
        n_steps = max(1, int(np.ceil(insertion_depth_m / step_size_m)))

        for _ in range(n_steps):
            next_position = current_pose.position + step_size_m * axis_world
            next_pose = Pose(next_position, current_pose.rotation, frame=current_pose.frame)

            measured_force = force_sensor_fn(next_pose)
            axial_force = float(np.dot(measured_force, axis_world))
            peak_force = max(peak_force, abs(axial_force))

            if abs(axial_force) > max_force_n:
                return InsertionResult(
                    success=False,
                    final_pose=current_pose,
                    depth_reached_m=depth,
                    peak_force_n=peak_force,
                    search_result=search_result,
                    aborted_reason="max_force_exceeded",
                )

            current_pose = next_pose
            depth += step_size_m

        return InsertionResult(
            success=depth >= insertion_depth_m - 1e-9,
            final_pose=current_pose,
            depth_reached_m=depth,
            peak_force_n=peak_force,
            search_result=search_result,
        )
