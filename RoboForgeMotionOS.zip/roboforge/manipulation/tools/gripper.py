"""Gripper control: open/close commands, jaw-position tracking, and a
simple grasp-detection heuristic from commanded vs. achieved jaw width
(section 11).
"""

from __future__ import annotations

import time
from dataclasses import dataclass

from roboforge.core.enums import GripperState
from roboforge.core.exceptions import RoboForgeError
from roboforge.robotics.tool import Tool


@dataclass
class GripperCommandResult:
    state: GripperState
    jaw_position_m: float
    is_gripping: bool
    timestamp: float


class GripperController:
    """Drives a ``Tool``'s jaw between its configured open/closed
    positions, and infers a grasp from the point where jaw closure stalls
    against an object (i.e. the commanded position is not reached because
    an object is in the way) -- the same principle real parallel-gripper
    firmware uses for "part present" detection without a separate sensor.
    """

    def __init__(self, tool: Tool, close_speed_m_s: float = 0.05) -> None:
        self.tool = tool
        self.close_speed_m_s = close_speed_m_s
        self.state = GripperState.OPEN if tool.jaw_position_m >= tool.jaw_max_m - 1e-6 else GripperState.CLOSED

    def open(self) -> GripperCommandResult:
        self.tool.jaw_position_m = self.tool.jaw_max_m
        self.tool.is_gripping = False
        self.tool.grip_force_n = 0.0
        self.state = GripperState.OPEN
        return self._result()

    def close(self, object_width_m: float | None = None, grip_force_n: float = 20.0) -> GripperCommandResult:
        """Command the gripper closed. If ``object_width_m`` is provided
        (i.e. we know an object of that width is between the jaws), the
        gripper stalls there and reports a grasp; otherwise it fully
        closes and reports no grasp (grasped nothing)."""
        if object_width_m is not None and self.tool.jaw_min_m <= object_width_m <= self.tool.jaw_max_m:
            self.tool.jaw_position_m = object_width_m
            self.tool.is_gripping = True
            self.tool.grip_force_n = grip_force_n
            self.state = GripperState.HOLDING
        else:
            self.tool.jaw_position_m = self.tool.jaw_min_m
            self.tool.is_gripping = False
            self.tool.grip_force_n = 0.0
            self.state = GripperState.CLOSED
        return self._result()

    def set_position(self, position_m: float) -> GripperCommandResult:
        if not (self.tool.jaw_min_m <= position_m <= self.tool.jaw_max_m):
            raise RoboForgeError(
                f"Gripper position {position_m} outside jaw range "
                f"[{self.tool.jaw_min_m}, {self.tool.jaw_max_m}]"
            )
        self.tool.jaw_position_m = position_m
        self.state = GripperState.MOVING
        return self._result()

    def is_object_grasped(self) -> bool:
        return self.tool.is_gripping

    def _result(self) -> GripperCommandResult:
        return GripperCommandResult(
            state=self.state,
            jaw_position_m=self.tool.jaw_position_m,
            is_gripping=self.tool.is_gripping,
            timestamp=time.time(),
        )
