"""End-effector / tool-changer workflow: attach/detach tools with payload
validation (section 11)."""

from __future__ import annotations

from typing import TYPE_CHECKING

from roboforge.core.exceptions import SafetyViolationError
from roboforge.robotics.tool import Tool

if TYPE_CHECKING:
    from roboforge.robotics.robot import Robot


class EndEffectorManager:
    """Wraps ``Robot.attach_tool``/``detach_tool`` with the validation a
    real tool-changer workflow needs: refusing to attach a tool whose
    mass would exceed the robot's rated payload once any already-carried
    payload is accounted for."""

    def __init__(self, robot: "Robot") -> None:
        self.robot = robot

    def attach(self, tool: Tool) -> None:
        carried_payload_mass = self.robot.payload.mass if self.robot.payload else 0.0
        total_mass = tool.inertial.mass + carried_payload_mass
        if total_mass > tool.max_payload_kg:
            raise SafetyViolationError(
                f"Cannot attach tool {tool.name!r}: total mass {total_mass:.2f} kg exceeds its "
                f"rated payload {tool.max_payload_kg:.2f} kg"
            )
        self.robot.attach_tool(tool)

    def detach(self) -> Tool | None:
        tool = self.robot.tool
        self.robot.detach_tool()
        return tool
