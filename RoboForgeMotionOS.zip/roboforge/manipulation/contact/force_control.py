"""Force/torque and hybrid position/force control (section 10).

``ForceController`` implements a simple force-tracking servo: given a
measured wrench (from an F/T sensor) and a desired force target, it
outputs a Cartesian velocity correction that drives measured force
toward the target (a force-error-integrating "force servo", the
task-space analogue of the position ``CartesianServoController``).

``HybridPositionForceController`` combines position and force control
along independent axes via a selection matrix, per the classic
Raibert-Craig hybrid control formulation: axes marked "position
controlled" track a Cartesian pose target; axes marked "force
controlled" track a force target instead (e.g. Z force-controlled while
X/Y/orientation stay position-controlled, for planar contact tasks like
polishing or surface following).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np

from roboforge.core.transforms import Pose, Twist
from roboforge.motion.servo.cartesian_servo import CartesianServoController

if TYPE_CHECKING:
    from roboforge.robotics.robot import Robot


@dataclass
class ForceController:
    robot: "Robot"
    force_gain: float = 0.002       # m/s per N of force error
    torque_gain: float = 0.01       # rad/s per N*m of torque error
    integral_gain: float = 0.0005
    max_linear_velocity: float = 0.02
    max_angular_velocity: float = 0.1
    target_force: np.ndarray = field(default_factory=lambda: np.zeros(3))
    target_torque: np.ndarray = field(default_factory=lambda: np.zeros(3))
    _force_integral: np.ndarray = field(default_factory=lambda: np.zeros(3), init=False, repr=False)

    def __post_init__(self) -> None:
        self._servo = CartesianServoController(self.robot)

    def set_force_target(self, force: np.ndarray, torque: np.ndarray | None = None) -> None:
        """Section 10 API: ``controller.set_force_target(force=[0, 0, 20])``."""
        self.target_force = np.asarray(force, dtype=float)
        self.target_torque = np.zeros(3) if torque is None else np.asarray(torque, dtype=float)
        self._force_integral = np.zeros(3)

    def compute_velocity_command(self, measured_force: np.ndarray, measured_torque: np.ndarray | None = None,
                                  dt: float = 0.01) -> np.ndarray:
        """Return a joint-velocity command driving measured force/torque
        toward the configured target."""
        measured_torque = np.zeros(3) if measured_torque is None else np.asarray(measured_torque, dtype=float)
        force_error = self.target_force - np.asarray(measured_force, dtype=float)
        torque_error = self.target_torque - measured_torque

        self._force_integral += force_error * dt
        linear = self.force_gain * force_error + self.integral_gain * self._force_integral
        angular = self.torque_gain * torque_error

        linear = np.clip(linear, -self.max_linear_velocity, self.max_linear_velocity)
        angular = np.clip(angular, -self.max_angular_velocity, self.max_angular_velocity)

        return self._servo.set_cartesian_velocity(linear, angular)


@dataclass
class HybridPositionForceController:
    """Hybrid position/force control (section 10): a per-axis selection
    vector (length 6: [x, y, z, rx, ry, rz], 1 = position-controlled, 0 =
    force-controlled) blends a position-tracking twist and a
    force-tracking twist into a single joint-velocity command.
    """

    robot: "Robot"
    selection: np.ndarray = field(default_factory=lambda: np.ones(6))  # default: all position-controlled
    force_controller: ForceController | None = None
    position_gain: float = 2.0
    orientation_gain: float = 2.0

    def __post_init__(self) -> None:
        self._servo = CartesianServoController(self.robot, self.position_gain, self.orientation_gain)
        if self.force_controller is None:
            self.force_controller = ForceController(self.robot)

    def set_selection(self, selection: np.ndarray) -> None:
        self.selection = np.asarray(selection, dtype=float)

    def compute(self, target_pose: Pose, measured_force: np.ndarray, measured_torque: np.ndarray | None = None,
                dt: float = 0.01) -> np.ndarray:
        _, position_twist = self._servo.track_pose(target_pose)
        force_qd = self.force_controller.compute_velocity_command(measured_force, measured_torque, dt)

        # Recover a force-only twist by inverting the servo's mapping is
        # unnecessary: we blend at the joint-velocity level using the
        # Jacobian-transpose-consistent selection by instead blending the
        # *twists* before conversion, which is more physically meaningful.
        from roboforge.robotics.kinematics.jacobian import geometric_jacobian, damped_pseudoinverse

        q = self.robot.joint_state.position
        J = geometric_jacobian(self.robot, q)
        J_pinv = damped_pseudoinverse(J)
        force_twist_vec = J @ force_qd  # approximate achieved twist from the force servo's qd

        S = self.selection
        blended_twist_vec = S * position_twist.as_vector() + (1 - S) * force_twist_vec
        qd = J_pinv @ blended_twist_vec
        return qd
