"""Impedance and admittance control (section 10).

Impedance control renders the robot's TCP as a virtual mass-spring-damper
system reacting to external contact forces:

    F_ext = M * x_ddot + D * x_dot + K * (x - x_desired)

``ImpedanceController`` runs this "outside-in": given a desired pose and
the measured external wrench, it computes the *deviation* from the
desired pose the virtual spring-damper would settle to, and commands a
Cartesian velocity toward that compliant target -- useful for controlled
contact tasks (press-fitting, surface following, polishing) where some
compliance is safer/better than rigid position tracking.

``AdmittanceController`` instead integrates the mass-spring-damper
equation forward in time to produce a compliant *position* trajectory
correction, which is the more common structure when running underneath a
stiff, purely position-controlled robot (the typical case for
industrial arms without native torque control at the joint level --
consistent with section 29's separation of hard real-time control from
this planning-layer Python).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np

from roboforge.core.transforms import Pose, Twist
from roboforge.motion.servo.cartesian_servo import CartesianServoController

if TYPE_CHECKING:
    from roboforge.robotics.robot import Robot


@dataclass
class ImpedanceController:
    robot: "Robot"
    stiffness: np.ndarray = field(default_factory=lambda: np.array([500.0, 500.0, 500.0, 20.0, 20.0, 20.0]))
    damping: np.ndarray = field(default_factory=lambda: np.array([50.0, 50.0, 50.0, 2.0, 2.0, 2.0]))

    def __post_init__(self) -> None:
        self._servo = CartesianServoController(self.robot)
        self._prev_deviation = np.zeros(6)

    def set_impedance(self, stiffness: np.ndarray, damping: np.ndarray) -> None:
        """Section 10 API: ``controller.set_impedance(stiffness=K, damping=D)``."""
        self.stiffness = np.asarray(stiffness, dtype=float)
        self.damping = np.asarray(damping, dtype=float)

    def compute_velocity_command(
        self, target_pose: Pose, measured_wrench: np.ndarray, dt: float = 0.01
    ) -> np.ndarray:
        """Given the desired pose and the measured external wrench
        [Fx,Fy,Fz,Tx,Ty,Tz], compute the compliant velocity command."""
        current_pose = self.robot.forward_kinematics()
        from roboforge.core.transforms import rotation_matrix_to_axis_angle

        pos_error = current_pose.position - target_pose.position
        R_err = current_pose.rotation @ target_pose.rotation.T
        axis, angle = rotation_matrix_to_axis_angle(R_err)
        rot_error = axis * angle
        deviation = np.concatenate([pos_error, rot_error])

        deviation_rate = (deviation - self._prev_deviation) / max(dt, 1e-6)
        self._prev_deviation = deviation

        # Virtual spring-damper: net "restoring" velocity needed so that,
        # combined with the measured external force, the system behaves
        # like the configured (K, D) impedance.
        spring_force = self.stiffness * deviation
        damper_force = self.damping * deviation_rate
        net = np.asarray(measured_wrench, dtype=float) - spring_force - damper_force

        # Convert net generalised force into a compliant velocity command
        # using the damping gains as an admittance-like conversion factor.
        safe_damping = np.where(np.abs(self.damping) > 1e-6, self.damping, 1e-6)
        velocity_cmd = net / safe_damping

        twist = Twist(linear=velocity_cmd[:3], angular=velocity_cmd[3:])
        return self._servo.twist_to_joint_velocity(twist)


@dataclass
class AdmittanceController:
    robot: "Robot"
    mass: np.ndarray = field(default_factory=lambda: np.full(6, 1.0))
    stiffness: np.ndarray = field(default_factory=lambda: np.array([500.0, 500.0, 500.0, 20.0, 20.0, 20.0]))
    damping: np.ndarray = field(default_factory=lambda: np.array([50.0, 50.0, 50.0, 2.0, 2.0, 2.0]))

    def __post_init__(self) -> None:
        self._servo = CartesianServoController(self.robot)
        self._velocity_state = np.zeros(6)
        self._position_correction = np.zeros(6)

    def set_impedance(self, stiffness: np.ndarray, damping: np.ndarray, mass: np.ndarray | None = None) -> None:
        self.stiffness = np.asarray(stiffness, dtype=float)
        self.damping = np.asarray(damping, dtype=float)
        if mass is not None:
            self.mass = np.asarray(mass, dtype=float)

    def step(self, nominal_target_pose: Pose, measured_wrench: np.ndarray, dt: float = 0.01) -> Pose:
        """Integrate the admittance equation forward one step and return
        a compliant pose correction of ``nominal_target_pose`` -- feed the
        returned pose to a position-controlled motion command."""
        wrench = np.asarray(measured_wrench, dtype=float)
        acceleration = (wrench - self.damping * self._velocity_state - self.stiffness * self._position_correction) / self.mass
        self._velocity_state = self._velocity_state + acceleration * dt
        self._position_correction = self._position_correction + self._velocity_state * dt

        from roboforge.core.transforms import axis_angle_to_rotation_matrix

        pos_delta = self._position_correction[:3]
        rot_delta = self._position_correction[3:]
        angle = float(np.linalg.norm(rot_delta))
        R_delta = axis_angle_to_rotation_matrix(rot_delta / angle, angle) if angle > 1e-12 else np.eye(3)

        return Pose(
            nominal_target_pose.position + pos_delta,
            R_delta @ nominal_target_pose.rotation,
            frame=nominal_target_pose.frame,
        )

    def reset(self) -> None:
        self._velocity_state = np.zeros(6)
        self._position_correction = np.zeros(6)
