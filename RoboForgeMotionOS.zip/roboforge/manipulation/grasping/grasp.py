"""Grasp and graspable-object representations (section 12)."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

import numpy as np

from roboforge.core.transforms import Pose


class ObjectShape(str, Enum):
    BOX = "box"
    CYLINDER = "cylinder"


@dataclass
class GraspableObject:
    """A minimal geometric object model sufficient for heuristic grasp
    generation: a box or cylinder primitive at a known world pose (as
    produced by ``roboforge.perception.pose.ObjectPose``)."""

    object_id: str
    shape: ObjectShape
    pose: Pose
    dimensions: np.ndarray  # box: (length, width, height); cylinder: (radius, height, 0)
    mass_kg: float = 0.1

    def width_along(self, axis_index: int) -> float:
        if self.shape == ObjectShape.CYLINDER:
            return 2 * self.dimensions[0]
        return float(self.dimensions[axis_index])


@dataclass
class Grasp:
    """A candidate (or executed) grasp: the gripper pose in world
    coordinates, the jaw width to command, and a quality assessment."""

    object_id: str
    grasp_pose: Pose          # where the TCP should be to execute the grasp
    approach_axis: np.ndarray  # world-frame unit vector the gripper approaches along
    gripper_width_m: float
    quality_score: float
    stability_score: float
    reachability_score: float
    collision_risk: float
    contact_points: list[np.ndarray] = field(default_factory=list)
    label: str = ""
