"""Grasp planning (section 12): generates candidate grasps for a
graspable object, scores each by stability, reachability, and collision
risk, and selects the best one for the task.
"""

from __future__ import annotations

from typing import Callable, TYPE_CHECKING

import numpy as np

from roboforge.core.exceptions import GraspError
from roboforge.core.transforms import Pose, euler_to_rotation_matrix
from roboforge.manipulation.grasping.grasp import Grasp, GraspableObject, ObjectShape

if TYPE_CHECKING:
    from roboforge.robotics.robot import Robot
    from roboforge.robotics.tool import Tool


def _grasp_orientation(approach_axis_world: np.ndarray, wrist_yaw: float) -> np.ndarray:
    """Build a rotation matrix whose local +Z points along
    ``approach_axis_world`` (i.e. the gripper approaches "into" the
    page along its own Z), with an additional yaw about that axis for
    wrist alignment."""
    z = approach_axis_world / np.linalg.norm(approach_axis_world)
    arbitrary = np.array([1.0, 0.0, 0.0]) if abs(z[0]) < 0.9 else np.array([0.0, 1.0, 0.0])
    x = np.cross(arbitrary, z)
    x = x / np.linalg.norm(x)
    y = np.cross(z, x)
    R = np.column_stack([x, y, z])
    yaw_R = euler_to_rotation_matrix([0, 0, wrist_yaw])
    return R @ yaw_R


class GraspPlanner:
    def __init__(self, robot: "Robot", tool: "Tool") -> None:
        self.robot = robot
        self.tool = tool

    def generate_candidates(self, obj: GraspableObject, n_yaw_samples: int = 6) -> list[Grasp]:
        candidates: list[Grasp] = []
        yaws = np.linspace(0, np.pi, n_yaw_samples, endpoint=False)

        if obj.shape == ObjectShape.BOX:
            length, width, height = obj.dimensions
            # Top-down grasp across the shorter horizontal dimension.
            grasp_width = min(length, width)
            approach_axis = obj.pose.rotation @ np.array([0.0, 0.0, -1.0])
            for yaw in yaws:
                R = _grasp_orientation(approach_axis, float(yaw))
                position = obj.pose.position + obj.pose.rotation @ np.array([0, 0, height / 2])
                candidates.append(self._make_candidate(obj, Pose(position, R), approach_axis, grasp_width, "top_down"))

            # Side grasp across the object's width, gripper axis horizontal.
            side_axis = obj.pose.rotation @ np.array([1.0, 0.0, 0.0])
            for yaw in yaws:
                R = _grasp_orientation(side_axis, float(yaw))
                position = obj.pose.position
                candidates.append(self._make_candidate(obj, Pose(position, R), side_axis, min(width, height), "side"))

        elif obj.shape == ObjectShape.CYLINDER:
            radius, height, _ = obj.dimensions
            approach_axis = obj.pose.rotation @ np.array([0.0, 0.0, -1.0])
            for yaw in yaws:
                R = _grasp_orientation(approach_axis, float(yaw))
                position = obj.pose.position + obj.pose.rotation @ np.array([0, 0, height / 4])
                candidates.append(self._make_candidate(obj, Pose(position, R), approach_axis, 2 * radius, "top_down_cylindrical"))

        return candidates

    def _make_candidate(self, obj: GraspableObject, grasp_pose: Pose, approach_axis: np.ndarray,
                         object_width: float, label: str) -> Grasp:
        return Grasp(
            object_id=obj.object_id,
            grasp_pose=grasp_pose,
            approach_axis=approach_axis,
            gripper_width_m=float(np.clip(object_width + 0.005, self.tool.jaw_min_m, self.tool.jaw_max_m)),
            quality_score=0.0,
            stability_score=0.0,
            reachability_score=0.0,
            collision_risk=0.0,
            label=label,
        )

    def score(self, grasp: Grasp, obj: GraspableObject, collision_checker: Callable[[np.ndarray], bool] | None = None,
              q_seed: np.ndarray | None = None) -> Grasp:
        # Stability: prefer jaw widths comfortably within the gripper's
        # range, not pinched at either extreme.
        jaw_range = self.tool.jaw_max_m - self.tool.jaw_min_m
        if jaw_range > 1e-9:
            normalized = (grasp.gripper_width_m - self.tool.jaw_min_m) / jaw_range
            grasp.stability_score = float(1.0 - abs(normalized - 0.5) * 2)
        else:
            grasp.stability_score = 0.0
        if grasp.gripper_width_m >= self.tool.jaw_max_m - 1e-6:
            grasp.stability_score *= 0.2  # can't actually close on the object

        # Reachability: IK success + manipulability at the grasp pose.
        q0 = q_seed if q_seed is not None else self.robot.joint_state.position
        result = self.robot.inverse_kinematics(grasp.grasp_pose, initial_guess=q0)
        if result.success:
            grasp.reachability_score = float(np.clip(result.manipulability * 10, 0.0, 1.0))
        else:
            grasp.reachability_score = 0.0

        # Collision risk along a short approach standoff.
        grasp.collision_risk = 0.0
        if collision_checker is not None and result.success:
            standoff_pose = Pose(
                grasp.grasp_pose.position - 0.05 * grasp.approach_axis, grasp.grasp_pose.rotation
            )
            standoff_result = self.robot.inverse_kinematics(standoff_pose, initial_guess=result.joint_positions)
            if not standoff_result.success or not collision_checker(standoff_result.joint_positions):
                grasp.collision_risk = 1.0
            elif not collision_checker(result.joint_positions):
                grasp.collision_risk = 1.0

        grasp.quality_score = (
            0.4 * grasp.stability_score + 0.4 * grasp.reachability_score + 0.2 * (1 - grasp.collision_risk)
        )
        return grasp

    def select_best(self, obj: GraspableObject, collision_checker: Callable[[np.ndarray], bool] | None = None,
                     q_seed: np.ndarray | None = None) -> Grasp:
        candidates = self.generate_candidates(obj)
        if not candidates:
            raise GraspError(f"No grasp candidates could be generated for object {obj.object_id!r}")

        scored = [self.score(c, obj, collision_checker, q_seed) for c in candidates]
        feasible = [g for g in scored if g.reachability_score > 0 and g.collision_risk < 1.0]
        if not feasible:
            raise GraspError(f"No feasible (reachable, collision-free) grasp found for object {obj.object_id!r}")
        return max(feasible, key=lambda g: g.quality_score)
