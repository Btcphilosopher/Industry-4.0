"""Resource listing endpoints (section 38): tools, objects, workspaces,
calibration status, and simulation status.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request

from roboforge.api.app_state import AppState
from roboforge.api.schemas import (
    CalibrationSummaryResponse,
    ObjectSummary,
    SimulationStatusResponse,
    ToolSummary,
    WorkspaceSummary,
)

router = APIRouter(tags=["resources"])


def get_app_state(request: Request) -> AppState:
    return request.app.state.roboforge


@router.get("/tools", response_model=list[ToolSummary])
def list_tools(state: AppState = Depends(get_app_state)) -> list[ToolSummary]:
    tools = []
    for ctx in state.robots.values():
        if ctx.robot.tool is not None:
            tools.append(
                ToolSummary(
                    name=ctx.robot.tool.name, kind=ctx.robot.tool.kind.value, attached_to=ctx.robot.robot_id,
                    jaw_position_m=ctx.robot.tool.jaw_position_m, is_gripping=ctx.robot.tool.is_gripping,
                )
            )
    return tools


@router.get("/objects", response_model=list[ObjectSummary])
def list_objects(state: AppState = Depends(get_app_state)) -> list[ObjectSummary]:
    return [
        ObjectSummary(object_id=obj.object_id, shape=obj.shape.value, position=obj.pose.position.tolist())
        for obj in state.world.objects.values()
    ]


@router.get("/workspaces", response_model=list[WorkspaceSummary])
def list_workspaces(state: AppState = Depends(get_app_state)) -> list[WorkspaceSummary]:
    return [
        WorkspaceSummary(
            robot_id=ctx.robot.robot_id, min_corner=ctx.robot.workspace.min_corner.tolist(),
            max_corner=ctx.robot.workspace.max_corner.tolist(), max_reach_m=ctx.robot.workspace.max_reach_m,
        )
        for ctx in state.robots.values()
    ]


@router.get("/calibration", response_model=list[CalibrationSummaryResponse])
def list_calibration(state: AppState = Depends(get_app_state)) -> list[CalibrationSummaryResponse]:
    return [
        CalibrationSummaryResponse(
            robot_id=ctx.robot.robot_id, calibrated=ctx.robot.calibration.calibrated,
            repeatability_m=ctx.robot.calibration.repeatability_m,
            absolute_accuracy_m=ctx.robot.calibration.absolute_accuracy_m,
        )
        for ctx in state.robots.values()
    ]


@router.get("/simulation", response_model=SimulationStatusResponse)
def simulation_status(state: AppState = Depends(get_app_state)) -> SimulationStatusResponse:
    return SimulationStatusResponse(
        sim_time_s=state.world.sim_time_s, time_scale=state.world.time_scale,
        n_objects=len(state.world.objects), robot_ids=list(state.robots.keys()),
    )
