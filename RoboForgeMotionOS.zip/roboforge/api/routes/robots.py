"""Read-only robot introspection endpoints (section 38)."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request

from roboforge.api.app_state import AppState
from roboforge.api.auth import Principal, get_current_principal
from roboforge.api.schemas import (
    DiagnosticsResponse,
    JointStateResponse,
    PoseResponse,
    RobotStateResponse,
    RobotSummary,
    TelemetryResponse,
    TelemetrySampleResponse,
    TrajectorySummaryResponse,
)
from roboforge.robotics.kinematics.singularity import analyse_singularity

router = APIRouter(prefix="/robots", tags=["robots"])


def get_app_state(request: Request) -> AppState:
    return request.app.state.roboforge


@router.get("", response_model=list[RobotSummary])
def list_robots(state: AppState = Depends(get_app_state)) -> list[RobotSummary]:
    return [
        RobotSummary(
            robot_id=ctx.robot.robot_id,
            name=ctx.robot.name,
            dof=ctx.robot.dof,
            kinematic_family=ctx.robot.kinematic_family.value,
            motion_state=ctx.robot.motion_state.value,
            safety_level=ctx.robot.safety_level.value,
        )
        for ctx in state.robots.values()
    ]


@router.get("/{robot_id}", response_model=RobotSummary)
def get_robot(robot_id: str, state: AppState = Depends(get_app_state)) -> RobotSummary:
    ctx = state.get(robot_id)
    return RobotSummary(
        robot_id=ctx.robot.robot_id, name=ctx.robot.name, dof=ctx.robot.dof,
        kinematic_family=ctx.robot.kinematic_family.value, motion_state=ctx.robot.motion_state.value,
        safety_level=ctx.robot.safety_level.value,
    )


@router.get("/{robot_id}/state", response_model=RobotStateResponse)
def get_robot_state(robot_id: str, state: AppState = Depends(get_app_state)) -> RobotStateResponse:
    ctx = state.get(robot_id)
    robot_state = ctx.driver.get_state()
    pose = robot_state.tcp_pose
    return RobotStateResponse(
        robot_id=robot_id,
        joint_state=JointStateResponse(**robot_state.joint_state.as_dict()),
        tcp_pose=PoseResponse(
            position=pose.position.tolist(), quaternion=pose.as_quaternion().tolist(),
            rpy=[float(v) for v in pose.as_euler()],
        ),
        motion_state=robot_state.motion_state.value,
        safety_level=robot_state.safety_level.value,
        manipulability=robot_state.manipulability,
        in_contact=robot_state.in_contact,
    )


@router.get("/{robot_id}/joints", response_model=JointStateResponse)
def get_robot_joints(robot_id: str, state: AppState = Depends(get_app_state)) -> JointStateResponse:
    ctx = state.get(robot_id)
    return JointStateResponse(**ctx.robot.joint_state.as_dict())


@router.get("/{robot_id}/pose", response_model=PoseResponse)
def get_robot_pose(robot_id: str, state: AppState = Depends(get_app_state)) -> PoseResponse:
    ctx = state.get(robot_id)
    pose = ctx.robot.forward_kinematics()
    return PoseResponse(position=pose.position.tolist(), quaternion=pose.as_quaternion().tolist(),
                         rpy=[float(v) for v in pose.as_euler()])


@router.get("/{robot_id}/trajectory", response_model=TrajectorySummaryResponse)
def get_robot_trajectory(robot_id: str, state: AppState = Depends(get_app_state)) -> TrajectorySummaryResponse:
    ctx = state.get(robot_id)
    traj = ctx.last_trajectory
    if traj is None:
        return TrajectorySummaryResponse(trajectory_id=None, duration_s=0.0, n_points=0, peak_velocity=0.0, peak_acceleration=0.0)
    return TrajectorySummaryResponse(
        trajectory_id=ctx.last_trajectory_id, duration_s=traj.duration, n_points=len(traj.points),
        peak_velocity=float(max(traj.max_velocity())) if traj.points else 0.0,
        peak_acceleration=float(max(traj.max_acceleration())) if traj.points else 0.0,
    )


@router.get("/{robot_id}/diagnostics", response_model=DiagnosticsResponse)
def get_robot_diagnostics(robot_id: str, state: AppState = Depends(get_app_state)) -> DiagnosticsResponse:
    ctx = state.get(robot_id)
    robot = ctx.robot
    report = analyse_singularity(robot, robot.joint_state.position)
    return DiagnosticsResponse(
        robot_id=robot_id, motion_state=robot.motion_state.value, safety_level=robot.safety_level.value,
        manipulability=report.manipulability, condition_number=report.condition_number,
        near_singularity=report.near_singular, calibrated=robot.calibration.calibrated,
        repeatability_m=robot.calibration.repeatability_m, absolute_accuracy_m=robot.calibration.absolute_accuracy_m,
    )


@router.get("/{robot_id}/telemetry", response_model=TelemetryResponse)
def get_robot_telemetry(robot_id: str, n: int = 100, state: AppState = Depends(get_app_state)) -> TelemetryResponse:
    ctx = state.get(robot_id)
    samples = ctx.telemetry.recent(robot_id, n)
    return TelemetryResponse(
        robot_id=robot_id,
        samples=[
            TelemetrySampleResponse(
                timestamp=s.timestamp, joint_position=s.joint_position.tolist(), joint_velocity=s.joint_velocity.tolist(),
                tcp_position=s.tcp_position.tolist(), force=s.force.tolist(), trajectory_error=s.trajectory_error,
                controller_state=s.controller_state,
            )
            for s in samples
        ],
    )
