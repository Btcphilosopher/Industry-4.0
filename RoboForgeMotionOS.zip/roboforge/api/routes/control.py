"""Robot control endpoints (section 38): all require authenticated,
authorised access, and every accepted command is audit-logged.
"""

from __future__ import annotations

import uuid

import numpy as np
from fastapi import APIRouter, Depends, HTTPException, Request

from roboforge.api.app_state import AppState
from roboforge.api.auth import AuthStore, Principal, get_auth_store, require_write_access
from roboforge.api.schemas import GripperRequest, MoveCartesianRequest, MoveJointRequest, MoveResponse
from roboforge.core.transforms import Pose
from roboforge.drivers.command_model import CloseGripper, MoveCartesian, MoveJoint, MoveLinear, OpenGripper, Pause, Resume, Stop

router = APIRouter(prefix="/robots", tags=["control"])


def get_app_state(request: Request) -> AppState:
    return request.app.state.roboforge


@router.post("/{robot_id}/move", response_model=MoveResponse)
def move_joint(
    robot_id: str,
    body: MoveJointRequest,
    state: AppState = Depends(get_app_state),
    principal: Principal = Depends(require_write_access),
    auth_store: AuthStore = Depends(get_auth_store),
) -> MoveResponse:
    ctx = state.get(robot_id)
    if len(body.target_positions) != ctx.robot.dof:
        raise HTTPException(status_code=422, detail=f"target_positions must have length {ctx.robot.dof}")
    command = MoveJoint(
        target_positions=np.array(body.target_positions), velocity_scale=body.velocity_scale,
        acceleration_scale=body.acceleration_scale,
    )
    result = ctx.driver.send_command(command)
    auth_store.record(principal, "move_joint", robot_id, detail=str(body.target_positions))
    return MoveResponse(accepted=result.accepted, message=result.message)


@router.post("/{robot_id}/trajectory", response_model=MoveResponse)
def move_cartesian(
    robot_id: str,
    body: MoveCartesianRequest,
    state: AppState = Depends(get_app_state),
    principal: Principal = Depends(require_write_access),
    auth_store: AuthStore = Depends(get_auth_store),
) -> MoveResponse:
    ctx = state.get(robot_id)
    if body.quaternion is not None:
        target_pose = Pose.from_position_quaternion(body.position, body.quaternion)
    elif body.rpy is not None:
        target_pose = Pose.from_position_euler(body.position, body.rpy)
    else:
        target_pose = Pose(np.array(body.position), ctx.robot.forward_kinematics().rotation)

    command = MoveLinear(target_pose=target_pose) if body.linear else MoveCartesian(target_pose=target_pose, velocity_scale=body.velocity_scale)
    result = ctx.driver.send_command(command)
    ctx.last_trajectory_id = uuid.uuid4().hex[:12]
    auth_store.record(principal, "move_cartesian", robot_id, detail=str(body.position))
    return MoveResponse(accepted=result.accepted, message=result.message)


@router.post("/{robot_id}/stop", response_model=MoveResponse)
def stop_robot(
    robot_id: str, state: AppState = Depends(get_app_state),
    principal: Principal = Depends(require_write_access), auth_store: AuthStore = Depends(get_auth_store),
) -> MoveResponse:
    ctx = state.get(robot_id)
    result = ctx.driver.send_command(Stop(reason=f"api_stop_by_{principal.username}"))
    auth_store.record(principal, "stop", robot_id)
    return MoveResponse(accepted=result.accepted, message=result.message)


@router.post("/{robot_id}/pause", response_model=MoveResponse)
def pause_robot(
    robot_id: str, state: AppState = Depends(get_app_state),
    principal: Principal = Depends(require_write_access), auth_store: AuthStore = Depends(get_auth_store),
) -> MoveResponse:
    ctx = state.get(robot_id)
    result = ctx.driver.send_command(Pause())
    auth_store.record(principal, "pause", robot_id)
    return MoveResponse(accepted=result.accepted, message=result.message)


@router.post("/{robot_id}/resume", response_model=MoveResponse)
def resume_robot(
    robot_id: str, state: AppState = Depends(get_app_state),
    principal: Principal = Depends(require_write_access), auth_store: AuthStore = Depends(get_auth_store),
) -> MoveResponse:
    ctx = state.get(robot_id)
    result = ctx.driver.send_command(Resume())
    auth_store.record(principal, "resume", robot_id)
    return MoveResponse(accepted=result.accepted, message=result.message)


@router.post("/{robot_id}/gripper", response_model=MoveResponse)
def command_gripper(
    robot_id: str, body: GripperRequest, state: AppState = Depends(get_app_state),
    principal: Principal = Depends(require_write_access), auth_store: AuthStore = Depends(get_auth_store),
) -> MoveResponse:
    ctx = state.get(robot_id)
    if body.action == "open":
        result = ctx.driver.send_command(OpenGripper())
    elif body.action == "close":
        result = ctx.driver.send_command(CloseGripper(object_width_m=body.object_width_m, grip_force_n=body.grip_force_n))
    else:
        raise HTTPException(status_code=422, detail="action must be 'open' or 'close'")
    auth_store.record(principal, f"gripper_{body.action}", robot_id)
    return MoveResponse(accepted=result.accepted, message=result.message)
