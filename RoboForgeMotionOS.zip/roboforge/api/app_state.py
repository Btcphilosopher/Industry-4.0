"""The API's application state: a registry of robots (each with its
driver, collision engine, telemetry recorder, and event bus) plus the
shared simulation world -- assembled once at startup and reached via a
FastAPI dependency rather than globals, so tests can build an isolated
instance.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from roboforge.calibration.robot.robot_calibration import RobotCalibrationReport
from roboforge.collision.collision_engine import CollisionEngine
from roboforge.drivers.simulation_driver import SimulationDriver
from roboforge.events.event_bus import EventBus
from roboforge.manipulation.tools.gripper import GripperController
from roboforge.simulation.world import SimulationWorld
from roboforge.telemetry.telemetry_recorder import TelemetryRecorder

if TYPE_CHECKING:
    from roboforge.robotics.robot import Robot
    from roboforge.motion.trajectory.joint_trajectory import JointTrajectory


@dataclass
class RobotContext:
    robot: "Robot"
    driver: SimulationDriver
    collision_engine: CollisionEngine
    telemetry: TelemetryRecorder
    event_bus: EventBus
    gripper: GripperController | None = None
    last_trajectory: "JointTrajectory | None" = None
    last_trajectory_id: str | None = None
    calibration_report: RobotCalibrationReport | None = None


@dataclass
class AppState:
    robots: dict[str, RobotContext] = field(default_factory=dict)
    world: SimulationWorld = field(default_factory=SimulationWorld)

    def add_robot(self, ctx: RobotContext) -> None:
        self.robots[ctx.robot.robot_id] = ctx

    def get(self, robot_id: str) -> RobotContext:
        if robot_id not in self.robots:
            from fastapi import HTTPException

            raise HTTPException(status_code=404, detail=f"Unknown robot_id {robot_id!r}")
        return self.robots[robot_id]
