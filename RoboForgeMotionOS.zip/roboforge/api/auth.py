"""Authentication, authorisation, and audit logging for the API (section
48). Uses a bearer API token mapped to a role; every control endpoint
depends on ``require_role`` so an unauthenticated or under-privileged
caller is rejected before any robot code runs. Every accepted control
action is written to the audit log with the acting principal, the robot,
and the command -- "every physical robot command must be auditable".
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field

from fastapi import Depends, HTTPException, Security, status
from fastapi.security import APIKeyHeader

from roboforge.core.enums import Role

api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


@dataclass
class Principal:
    username: str
    role: Role


@dataclass
class AuditLogEntry:
    timestamp: float
    username: str
    role: str
    action: str
    robot_id: str | None
    detail: str = ""


class AuthStore:
    """An in-memory token -> principal store. A production deployment
    would back this with ``roboforge.storage.models.UserRecord`` and a
    proper password/token hashing scheme; the interface here
    (``authenticate``) is what a persistent-store-backed implementation
    would replace.
    """

    def __init__(self) -> None:
        self._tokens: dict[str, Principal] = {}
        self.audit_log: list[AuditLogEntry] = []

    def add_token(self, token: str, username: str, role: Role) -> None:
        self._tokens[token] = Principal(username, role)

    def authenticate(self, token: str | None) -> Principal:
        if token is None or token not in self._tokens:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or missing API key")
        return self._tokens[token]

    def record(self, principal: Principal, action: str, robot_id: str | None = None, detail: str = "") -> None:
        self.audit_log.append(
            AuditLogEntry(time.time(), principal.username, principal.role.value, action, robot_id, detail)
        )


default_auth_store = AuthStore()
# A demo-only default operator token so the API is exercisable out of the
# box; production deployments must replace/remove this.
default_auth_store.add_token("demo-operator-token", "demo_operator", Role.OPERATOR)
default_auth_store.add_token("demo-admin-token", "demo_admin", Role.ADMINISTRATOR)
default_auth_store.add_token("demo-readonly-token", "demo_readonly", Role.READ_ONLY)


def get_auth_store() -> AuthStore:
    return default_auth_store


def get_current_principal(
    api_key: str | None = Security(api_key_header), store: AuthStore = Depends(get_auth_store)
) -> Principal:
    return store.authenticate(api_key)


# Which roles may perform "write" (robot-commanding) actions.
_WRITE_ROLES = {Role.OPERATOR, Role.ROBOTICS_ENGINEER, Role.ADMINISTRATOR}
_MAINTENANCE_ROLES = {Role.MAINTENANCE, Role.ROBOTICS_ENGINEER, Role.ADMINISTRATOR}


def require_write_access(principal: Principal = Depends(get_current_principal)) -> Principal:
    if principal.role not in _WRITE_ROLES:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Role {principal.role.value!r} is not authorised to command robots",
        )
    return principal


def require_maintenance_access(principal: Principal = Depends(get_current_principal)) -> Principal:
    if principal.role not in _MAINTENANCE_ROLES:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Role {principal.role.value!r} is not authorised to run calibration/maintenance actions",
        )
    return principal
