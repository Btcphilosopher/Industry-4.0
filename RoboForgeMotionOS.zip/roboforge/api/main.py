"""The RoboForge Motion.OS FastAPI service (section 38).

Run with::

    uvicorn roboforge.api.main:app --reload

which builds a default single-robot demo cell (the example
``precision_arm_01`` configuration) so the API is immediately
exercisable; a real deployment should instead call ``create_app`` with
its own set of configured, connected robots.
"""

from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI

from roboforge.api.app_state import AppState, RobotContext
from roboforge.api.routes import control, resources, robots
from roboforge.collision.collision_engine import CollisionEngine
from roboforge.configuration.loader import load_and_build_robot
from roboforge.drivers.simulation_driver import SimulationDriver
from roboforge.events.event_bus import EventBus
from roboforge.manipulation.tools.gripper import GripperController
from roboforge.robotics.tool import Tool, ToolCentrePoint, ToolKind
from roboforge.telemetry.telemetry_recorder import TelemetryRecorder

EXAMPLE_CONFIG = Path(__file__).resolve().parents[1] / "configuration" / "examples" / "precision_arm_01.yaml"


def build_default_robot_context(config_path: Path = EXAMPLE_CONFIG) -> RobotContext:
    robot = load_and_build_robot(config_path)
    robot.attach_tool(
        Tool(name="precision_gripper", kind=ToolKind.PARALLEL_GRIPPER, tcp=ToolCentrePoint())
    )
    collision_engine = CollisionEngine(robot)
    event_bus = EventBus()
    telemetry = TelemetryRecorder()
    driver = SimulationDriver(robot, collision_engine, event_bus, telemetry)
    driver.connect()
    driver.enable()
    return RobotContext(
        robot=robot, driver=driver, collision_engine=collision_engine, telemetry=telemetry,
        event_bus=event_bus, gripper=GripperController(robot.tool),
    )


def create_app(robot_contexts: list[RobotContext] | None = None) -> FastAPI:
    app = FastAPI(
        title="RoboForge Motion.OS",
        description="Industrial robotic-arm precision motion & manipulation platform API",
        version="0.1.0",
    )

    state = AppState()
    for ctx in (robot_contexts or [build_default_robot_context()]):
        state.add_robot(ctx)
    app.state.roboforge = state

    app.include_router(robots.router)
    app.include_router(control.router)
    app.include_router(resources.router)

    @app.get("/health", tags=["meta"])
    def health() -> dict:
        return {"status": "ok", "robots": list(state.robots.keys())}

    return app


app = create_app()
