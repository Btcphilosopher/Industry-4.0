"""Pydantic request/response models for the FastAPI service (section 38)."""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field


class RobotSummary(BaseModel):
    robot_id: str
    name: str
    dof: int
    kinematic_family: str
    motion_state: str
    safety_level: str


class JointStateResponse(BaseModel):
    names: list[str]
    position: list[float]
    velocity: list[float]
    acceleration: list[float]
    torque: list[float]
    timestamp: float


class PoseResponse(BaseModel):
    position: list[float]
    quaternion: list[float]
    rpy: list[float]


class RobotStateResponse(BaseModel):
    robot_id: str
    joint_state: JointStateResponse
    tcp_pose: PoseResponse
    motion_state: str
    safety_level: str
    manipulability: Optional[float] = None
    in_contact: bool = False


class DiagnosticsResponse(BaseModel):
    robot_id: str
    motion_state: str
    safety_level: str
    manipulability: float
    condition_number: float
    near_singularity: bool
    calibrated: bool
    repeatability_m: Optional[float] = None
    absolute_accuracy_m: Optional[float] = None


class TelemetrySampleResponse(BaseModel):
    timestamp: float
    joint_position: list[float]
    joint_velocity: list[float]
    tcp_position: list[float]
    force: list[float]
    trajectory_error: float
    controller_state: str


class TelemetryResponse(BaseModel):
    robot_id: str
    samples: list[TelemetrySampleResponse]


class TrajectorySummaryResponse(BaseModel):
    trajectory_id: Optional[str] = None
    duration_s: float
    n_points: int
    peak_velocity: float
    peak_acceleration: float


class MoveJointRequest(BaseModel):
    target_positions: list[float]
    velocity_scale: float = Field(default=1.0, gt=0, le=1.0)
    acceleration_scale: float = Field(default=1.0, gt=0, le=1.0)


class MoveCartesianRequest(BaseModel):
    position: list[float] = Field(min_length=3, max_length=3)
    quaternion: Optional[list[float]] = None  # x, y, z, w
    rpy: Optional[list[float]] = None
    linear: bool = False
    velocity_scale: float = Field(default=1.0, gt=0, le=1.0)


class MoveResponse(BaseModel):
    accepted: bool
    message: str


class GripperRequest(BaseModel):
    action: str  # "open" | "close"
    object_width_m: Optional[float] = None
    grip_force_n: float = 20.0


class CalibrationSummaryResponse(BaseModel):
    robot_id: str
    calibrated: bool
    repeatability_m: Optional[float] = None
    absolute_accuracy_m: Optional[float] = None


class SimulationStatusResponse(BaseModel):
    sim_time_s: float
    time_scale: float
    n_objects: int
    robot_ids: list[str]


class ToolSummary(BaseModel):
    name: str
    kind: str
    attached_to: Optional[str] = None
    jaw_position_m: Optional[float] = None
    is_gripping: bool = False


class ObjectSummary(BaseModel):
    object_id: str
    shape: str
    position: list[float]


class WorkspaceSummary(BaseModel):
    robot_id: str
    min_corner: list[float]
    max_corner: list[float]
    max_reach_m: float
