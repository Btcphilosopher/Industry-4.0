"""The real-time collision engine (section 17): self-collision,
environment collision, and tool collision, using capsule/box/sphere
primitive distance queries with a configurable safety margin.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np

from roboforge.collision.collision_world import CollisionObject, CollisionWorld
from roboforge.collision.shapes import capsule_box_distance, capsule_capsule_distance, capsule_sphere_distance
from roboforge.robotics.kinematics.forward import forward_kinematics_all_frames

if TYPE_CHECKING:
    from roboforge.motion.trajectory.joint_trajectory import JointTrajectory
    from roboforge.robotics.robot import Robot


@dataclass
class CollisionPair:
    object_a: str
    object_b: str
    distance: float  # negative = penetrating; < safety_margin = warning


@dataclass
class CollisionReport:
    in_collision: bool
    min_clearance: float
    pairs: list[CollisionPair] = field(default_factory=list)
    violating_pairs: list[CollisionPair] = field(default_factory=list)


def _distance_capsule_to_object(a: np.ndarray, b: np.ndarray, r: float, obj: CollisionObject) -> float:
    if obj.shape == "capsule":
        oa, ob, orad = obj.world_capsule()
        return capsule_capsule_distance(a, b, r, oa, ob, orad)
    if obj.shape == "sphere":
        centre, radius = obj.world_sphere()
        return capsule_sphere_distance(a, b, r, centre, radius)
    if obj.shape == "box":
        centre, rotation, half_extents = obj.world_box()
        return capsule_box_distance(a, b, r, centre, rotation, half_extents)
    raise ValueError(f"Unsupported obstacle shape: {obj.shape!r}")


class CollisionEngine:
    """Checks a robot configuration (or a whole trajectory) for
    self-collision and collision against a ``CollisionWorld``.
    """

    def __init__(self, robot: "Robot", world: CollisionWorld | None = None, skip_adjacent_links: bool = True) -> None:
        self.robot = robot
        self.world = world or CollisionWorld()
        self.skip_adjacent_links = skip_adjacent_links

    def link_capsules(self, q: np.ndarray) -> list[tuple[np.ndarray, np.ndarray, float]]:
        """World-frame (point_a, point_b, radius) capsules for every link
        (and the tool, if attached) at configuration ``q`` -- exposed so
        multi-robot coordination can cross-check one robot's geometry
        against another's without duplicating the forward-kinematics-to-
        capsule logic."""
        return self._link_capsules(q)

    def _link_capsules(self, q: np.ndarray) -> list[tuple[np.ndarray, np.ndarray, float]]:
        frames = forward_kinematics_all_frames(self.robot, q)
        capsules = []
        for i, link in enumerate(self.robot.links):
            T = frames[i] if i < len(frames) else frames[-1]
            a = (T @ np.append(link.geometry.point_a, 1.0))[:3]
            b = (T @ np.append(link.geometry.point_b, 1.0))[:3]
            capsules.append((a, b, link.geometry.radius))
        if self.robot.tool is not None:
            T_flange = frames[-1] if frames else self.robot.base_pose.as_matrix()
            geo = self.robot.tool.geometry
            a = (T_flange @ np.append(geo.point_a, 1.0))[:3]
            b = (T_flange @ np.append(geo.point_b, 1.0))[:3]
            capsules.append((a, b, geo.radius))
        return capsules

    def check(self, q: np.ndarray, safety_margin: float = 0.0) -> CollisionReport:
        q = np.asarray(q, dtype=float)
        capsules = self._link_capsules(q)
        names = [link.name for link in self.robot.links] + (["tool"] if self.robot.tool else [])

        pairs: list[CollisionPair] = []

        # Self-collision: all non-adjacent link/tool pairs.
        for i in range(len(capsules)):
            for j in range(i + 1, len(capsules)):
                if self.skip_adjacent_links and (j - i) <= 1:
                    continue
                a0, a1, ra = capsules[i]
                b0, b1, rb = capsules[j]
                d = capsule_capsule_distance(a0, a1, ra, b0, b1, rb)
                pairs.append(CollisionPair(names[i], names[j], d))

        # Environment collision: every link/tool capsule vs every world object.
        for i, (a0, a1, ra) in enumerate(capsules):
            for obj in self.world.all():
                d = _distance_capsule_to_object(a0, a1, ra, obj)
                pairs.append(CollisionPair(names[i], obj.object_id, d))

        violating = [p for p in pairs if p.distance < safety_margin]
        min_clearance = min((p.distance for p in pairs), default=float("inf"))
        return CollisionReport(
            in_collision=len(violating) > 0,
            min_clearance=min_clearance,
            pairs=pairs,
            violating_pairs=violating,
        )

    def clearance(self, q: np.ndarray) -> float:
        return self.check(q).min_clearance

    def check_trajectory(self, trajectory: "JointTrajectory", safety_margin: float = 0.0) -> list[CollisionReport]:
        return [self.check(p.position, safety_margin) for p in trajectory.points]

    def as_checker(self, safety_margin: float = 0.0):
        """Return a ``q -> bool`` callable suitable for the motion planner's
        ``collision_checker`` parameter."""

        def _checker(q: np.ndarray) -> bool:
            return not self.check(q, safety_margin).in_collision

        return _checker
