"""The collision world: static/dynamic obstacles (workpieces, fixtures,
machines, other robots) the collision engine checks robot geometry
against (section 17)."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

import numpy as np

from roboforge.core.transforms import Pose


class ObjectKind(str, Enum):
    WORKPIECE = "workpiece"
    FIXTURE = "fixture"
    MACHINE = "machine"
    OBSTACLE = "obstacle"
    OTHER_ROBOT = "other_robot"


@dataclass
class CollisionObject:
    """A static or dynamic collision obstacle in the workspace, expressed
    as a convex primitive (capsule/box/sphere) in world coordinates."""

    object_id: str
    kind: ObjectKind
    shape: str  # "capsule" | "box" | "sphere"
    pose: Pose = field(default_factory=Pose.identity)
    point_a_local: np.ndarray = field(default_factory=lambda: np.zeros(3))
    point_b_local: np.ndarray = field(default_factory=lambda: np.array([0.0, 0.0, 0.1]))
    radius: float = 0.05
    half_extents: np.ndarray = field(default_factory=lambda: np.array([0.05, 0.05, 0.05]))

    def world_capsule(self) -> tuple[np.ndarray, np.ndarray, float]:
        a = self.pose.transform_point(self.point_a_local)
        b = self.pose.transform_point(self.point_b_local)
        return a, b, self.radius

    def world_sphere(self) -> tuple[np.ndarray, float]:
        return self.pose.position, self.radius

    def world_box(self) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        return self.pose.position, self.pose.rotation, self.half_extents


@dataclass
class CollisionWorld:
    """The set of obstacles a collision engine checks against."""

    objects: dict[str, CollisionObject] = field(default_factory=dict)

    def add(self, obj: CollisionObject) -> None:
        self.objects[obj.object_id] = obj

    def remove(self, object_id: str) -> None:
        self.objects.pop(object_id, None)

    def update_pose(self, object_id: str, pose: Pose) -> None:
        if object_id in self.objects:
            self.objects[object_id].pose = pose

    def get(self, object_id: str) -> CollisionObject | None:
        return self.objects.get(object_id)

    def all(self) -> list[CollisionObject]:
        return list(self.objects.values())
