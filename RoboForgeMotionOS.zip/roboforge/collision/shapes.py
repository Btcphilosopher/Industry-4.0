"""Convex-primitive distance queries used by the collision engine.

Real-time industrial motion planners overwhelmingly use capsule/box/
sphere approximations of link and tool geometry rather than exact mesh
collision, because closest-distance queries between simple primitives are
closed-form and fast enough to run inside a planning loop (and, on some
platforms, a servo loop). ``roboforge.robotics.link.LinkGeometry`` and
``roboforge.robotics.tool.Tool.geometry`` model links/tools this way.
"""

from __future__ import annotations

import numpy as np


def _closest_point_on_segment(p: np.ndarray, a: np.ndarray, b: np.ndarray) -> np.ndarray:
    ab = b - a
    denom = float(np.dot(ab, ab))
    if denom < 1e-12:
        return a.copy()
    t = float(np.clip(np.dot(p - a, ab) / denom, 0.0, 1.0))
    return a + t * ab


def segment_segment_distance(p1: np.ndarray, q1: np.ndarray, p2: np.ndarray, q2: np.ndarray) -> tuple[float, np.ndarray, np.ndarray]:
    """Closest distance between two line segments [p1,q1] and [p2,q2].
    Returns (distance, closest_point_on_seg1, closest_point_on_seg2).

    Standard closest-point-between-segments algorithm (Ericson,
    "Real-Time Collision Detection", section 5.1.9).
    """
    d1 = q1 - p1
    d2 = q2 - p2
    r = p1 - p2
    a = float(np.dot(d1, d1))
    e = float(np.dot(d2, d2))
    f = float(np.dot(d2, r))

    if a <= 1e-12 and e <= 1e-12:
        return float(np.linalg.norm(p1 - p2)), p1.copy(), p2.copy()

    if a <= 1e-12:
        s = 0.0
        t = float(np.clip(f / e, 0.0, 1.0))
    else:
        c = float(np.dot(d1, r))
        if e <= 1e-12:
            t = 0.0
            s = float(np.clip(-c / a, 0.0, 1.0))
        else:
            b = float(np.dot(d1, d2))
            denom = a * e - b * b
            s = float(np.clip((b * f - c * e) / denom, 0.0, 1.0)) if abs(denom) > 1e-12 else 0.0
            t = (b * s + f) / e
            if t < 0.0:
                t = 0.0
                s = float(np.clip(-c / a, 0.0, 1.0))
            elif t > 1.0:
                t = 1.0
                s = float(np.clip((b - c) / a, 0.0, 1.0))

    c1 = p1 + s * d1
    c2 = p2 + t * d2
    return float(np.linalg.norm(c1 - c2)), c1, c2


def capsule_capsule_distance(
    a0: np.ndarray, a1: np.ndarray, ra: float, b0: np.ndarray, b1: np.ndarray, rb: float
) -> float:
    """Surface-to-surface distance between two capsules (negative if
    penetrating)."""
    d, _, _ = segment_segment_distance(a0, a1, b0, b1)
    return d - ra - rb


def capsule_sphere_distance(a0: np.ndarray, a1: np.ndarray, ra: float, centre: np.ndarray, rs: float) -> float:
    closest = _closest_point_on_segment(centre, a0, a1)
    return float(np.linalg.norm(closest - centre)) - ra - rs


def capsule_box_distance(
    a0: np.ndarray, a1: np.ndarray, ra: float, box_centre: np.ndarray, box_rotation: np.ndarray, half_extents: np.ndarray,
    samples: int = 12,
) -> float:
    """Approximate surface distance between a capsule and an
    axis-aligned-in-its-own-frame box, by sampling points along the
    capsule axis and taking the minimum point-to-box distance. This is a
    fast, conservative approximation adequate for safety-margin checking
    at real-time rates; it is not an exact SAT solve.
    """
    min_dist = float("inf")
    for t in np.linspace(0.0, 1.0, samples):
        p = a0 + t * (a1 - a0)
        p_local = box_rotation.T @ (p - box_centre)
        closest_local = np.clip(p_local, -half_extents, half_extents)
        d = float(np.linalg.norm(p_local - closest_local))
        # Inside the box: distance is negative (penetration depth to nearest face).
        if np.all(np.abs(p_local) <= half_extents):
            penetration = float(np.min(half_extents - np.abs(p_local)))
            d = -penetration
        min_dist = min(min_dist, d)
    return min_dist - ra
