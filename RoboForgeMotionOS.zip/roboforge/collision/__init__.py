"""Real-time collision detection (section 17): self-collision,
environment collision, tool collision, and (via ``coordination``)
robot-robot collision, all using convex-primitive (capsule/box/sphere)
approximations for speed."""

from roboforge.collision.shapes import capsule_capsule_distance, capsule_box_distance, capsule_sphere_distance
from roboforge.collision.collision_world import CollisionObject, CollisionWorld
from roboforge.collision.collision_engine import CollisionEngine, CollisionReport, CollisionPair

__all__ = [
    "capsule_capsule_distance",
    "capsule_box_distance",
    "capsule_sphere_distance",
    "CollisionObject",
    "CollisionWorld",
    "CollisionEngine",
    "CollisionReport",
    "CollisionPair",
]
