"""The ``roboforge`` CLI (section 39), built with Typer.

Every subcommand builds (or reuses, within one invocation) a connected,
enabled simulated robot cell via ``roboforge.cli.context`` -- there is no
persistent CLI daemon in this reference implementation, so each
invocation is a fresh, deterministic simulation session (consistent with
section 27's requirement for deterministic simulation tests).
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import typer

from roboforge.cli.context import DEFAULT_CONFIG, build_cli_context
from roboforge.core.enums import PlannerObjective
from roboforge.core.transforms import Pose
from roboforge.drivers.command_model import MoveJoint, Stop
from roboforge.motion.planner.planner import MotionPlanner
from roboforge.motion.trajectory.joint_trajectory import generate_joint_trajectory
from roboforge.robotics.kinematics.singularity import analyse_singularity
from roboforge.telemetry.precision_metrics import run_precision_test

app = typer.Typer(name="roboforge", help="RoboForge Motion.OS command-line interface")
robot_app = typer.Typer(help="Robot introspection and control")
trajectory_app = typer.Typer(help="Trajectory planning and validation")
simulation_app = typer.Typer(help="Simulation control")
calibration_app = typer.Typer(help="Calibration routines")
precision_app = typer.Typer(help="Precision measurement")

app.add_typer(robot_app, name="robot")
app.add_typer(trajectory_app, name="trajectory")
app.add_typer(simulation_app, name="simulation")
app.add_typer(calibration_app, name="calibration")
app.add_typer(precision_app, name="precision")

ConfigOption = typer.Option(DEFAULT_CONFIG, "--config", "-c", help="Path to a robot YAML configuration")


def _print_json(data: dict) -> None:
    typer.echo(json.dumps(data, indent=2, default=str))


@robot_app.command("list")
def robot_list(config: Path = ConfigOption) -> None:
    ctx = build_cli_context(config)
    _print_json(
        [{"robot_id": ctx.robot.robot_id, "name": ctx.robot.name, "dof": ctx.robot.dof,
          "motion_state": ctx.robot.motion_state.value}]
    )


@robot_app.command("status")
def robot_status(robot_id: str, config: Path = ConfigOption) -> None:
    ctx = build_cli_context(config)
    if ctx.robot.robot_id != robot_id:
        typer.echo(f"warning: loaded robot id is {ctx.robot.robot_id!r}, not {robot_id!r}; showing loaded robot", err=True)
    _print_json({"robot_id": ctx.robot.robot_id, "motion_state": ctx.robot.motion_state.value,
                 "safety_level": ctx.robot.safety_level.value})


@robot_app.command("pose")
def robot_pose(robot_id: str, config: Path = ConfigOption) -> None:
    ctx = build_cli_context(config)
    pose = ctx.robot.forward_kinematics()
    x, y, z, r, p, yaw = pose.as_xyzrpy()
    _print_json({"robot_id": ctx.robot.robot_id, "x": x, "y": y, "z": z, "roll": r, "pitch": p, "yaw": yaw})


@robot_app.command("joints")
def robot_joints(robot_id: str, config: Path = ConfigOption) -> None:
    ctx = build_cli_context(config)
    _print_json(ctx.robot.joint_state.as_dict())


@robot_app.command("move")
def robot_move(
    robot_id: str,
    positions: str = typer.Option(..., "--positions", "-p", help="Comma-separated target joint positions (radians)"),
    velocity_scale: float = typer.Option(1.0, "--velocity-scale"),
    config: Path = ConfigOption,
) -> None:
    ctx = build_cli_context(config)
    q_target = np.array([float(v) for v in positions.split(",")])
    if len(q_target) != ctx.robot.dof:
        typer.echo(f"error: expected {ctx.robot.dof} joint values, got {len(q_target)}", err=True)
        raise typer.Exit(code=1)
    result = ctx.driver.send_command(MoveJoint(target_positions=q_target, velocity_scale=velocity_scale))
    _print_json({"accepted": result.accepted, "message": result.message})
    if not result.accepted:
        raise typer.Exit(code=1)


@robot_app.command("stop")
def robot_stop(robot_id: str, config: Path = ConfigOption) -> None:
    ctx = build_cli_context(config)
    result = ctx.driver.send_command(Stop(reason="cli_stop"))
    _print_json({"accepted": result.accepted, "message": result.message})


@trajectory_app.command("plan")
def trajectory_plan(
    target: str = typer.Option(..., "--target", "-t", help="Comma-separated target joint positions"),
    objective: str = typer.Option("minimum_time", "--objective", "-o"),
    config: Path = ConfigOption,
) -> None:
    ctx = build_cli_context(config)
    q_target = np.array([float(v) for v in target.split(",")])
    planner = MotionPlanner(ctx.robot)
    result = planner.optimize(
        ctx.robot.joint_state.position, q_target, objective=PlannerObjective(objective),
        collision_checker=ctx.collision_engine.as_checker(),
    )
    ctx.driver  # keep context alive for clarity
    _print_json(
        {
            "chosen_candidate": result.chosen_candidate,
            "objective": result.objective.value,
            "objective_value": result.objective_value,
            "duration_s": result.trajectory.duration,
            "n_points": len(result.trajectory.points),
        }
    )


@trajectory_app.command("validate")
def trajectory_validate(
    target: str = typer.Option(..., "--target", "-t"),
    config: Path = ConfigOption,
) -> None:
    ctx = build_cli_context(config)
    q_target = np.array([float(v) for v in target.split(",")])
    trajectory = generate_joint_trajectory(ctx.robot, ctx.robot.joint_state.position, q_target)
    report = ctx.driver.safety.validate_trajectory(trajectory, ctx.collision_engine)
    _print_json({"valid": report.valid, "violations": report.violations, "min_collision_clearance": report.min_collision_clearance})
    if not report.valid:
        raise typer.Exit(code=1)


@simulation_app.command("start")
def simulation_start(config: Path = ConfigOption) -> None:
    ctx = build_cli_context(config)
    _print_json({"status": "ready", "robot_id": ctx.robot.robot_id, "motion_state": ctx.robot.motion_state.value})


@simulation_app.command("run")
def simulation_run(
    duration_s: float = typer.Option(2.0, "--duration"),
    speed: float = typer.Option(1.0, "--speed", help="Simulation speed multiplier (1/10/100/1000)"),
    config: Path = ConfigOption,
) -> None:
    ctx = build_cli_context(config)
    home = ctx.robot.home_position()
    target = ctx.robot.clamp_joint_positions(home + 0.3)
    trajectory = generate_joint_trajectory(ctx.robot, ctx.robot.joint_state.position, target)
    result = ctx.driver.sim_robot.execute_trajectory(trajectory, event_bus=ctx.event_bus, telemetry=ctx.telemetry,
                                                       state_estimator=None)
    _print_json({"success": result.success, "execution_time_s": result.execution_time_s,
                 "max_tracking_error_m": result.max_tracking_error_m, "sim_speed": speed})


@calibration_app.command("run")
def calibration_run(config: Path = ConfigOption, n_repeats: int = typer.Option(15, "--repeats")) -> None:
    ctx = build_cli_context(config)
    target = ctx.robot.forward_kinematics()
    report = run_precision_test(ctx.robot, target, n_repeats=n_repeats)
    _print_json(
        {
            "robot_id": report.robot_id, "repeatability_m": report.repeatability_m,
            "absolute_accuracy_m": report.absolute_accuracy_m, "n_repeats": report.n_repeats,
        }
    )


@app.command("diagnostics")
def diagnostics(config: Path = ConfigOption) -> None:
    ctx = build_cli_context(config)
    report = analyse_singularity(ctx.robot, ctx.robot.joint_state.position)
    _print_json(
        {
            "robot_id": ctx.robot.robot_id, "manipulability": report.manipulability,
            "condition_number": report.condition_number, "near_singular": report.near_singular,
            "motion_state": ctx.robot.motion_state.value, "safety_level": ctx.robot.safety_level.value,
        }
    )


@precision_app.command("test")
def precision_test(config: Path = ConfigOption, n_repeats: int = typer.Option(20, "--repeats")) -> None:
    ctx = build_cli_context(config)
    target = ctx.robot.forward_kinematics()
    report = run_precision_test(ctx.robot, target, n_repeats=n_repeats)
    _print_json(
        {
            "robot_id": report.robot_id, "absolute_accuracy_m": report.absolute_accuracy_m,
            "repeatability_m": report.repeatability_m, "mean_position_error_m": report.mean_position_error_m,
            "max_position_error_m": report.max_position_error_m,
        }
    )


if __name__ == "__main__":
    app()
