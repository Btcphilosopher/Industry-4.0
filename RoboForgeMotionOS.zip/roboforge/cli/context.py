"""Builds a runnable, connected, enabled robot cell (robot + driver +
collision engine + telemetry + event bus) from a YAML config, for the CLI
to operate on. Kept independent of the FastAPI app so the CLI doesn't
pull in the API layer just to move a robot.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from roboforge.collision.collision_engine import CollisionEngine
from roboforge.configuration.loader import load_and_build_robot
from roboforge.drivers.simulation_driver import SimulationDriver
from roboforge.events.event_bus import EventBus
from roboforge.manipulation.tools.gripper import GripperController
from roboforge.robotics.robot import Robot
from roboforge.robotics.tool import Tool, ToolCentrePoint, ToolKind
from roboforge.telemetry.telemetry_recorder import TelemetryRecorder

DEFAULT_CONFIG = Path(__file__).resolve().parents[1] / "configuration" / "examples" / "precision_arm_01.yaml"


@dataclass
class CLIContext:
    robot: Robot
    driver: SimulationDriver
    collision_engine: CollisionEngine
    telemetry: TelemetryRecorder
    event_bus: EventBus
    gripper: GripperController | None


def build_cli_context(config_path: Path | str = DEFAULT_CONFIG, attach_gripper: bool = True) -> CLIContext:
    robot = load_and_build_robot(config_path)
    if attach_gripper:
        robot.attach_tool(Tool(name="precision_gripper", kind=ToolKind.PARALLEL_GRIPPER, tcp=ToolCentrePoint()))

    collision_engine = CollisionEngine(robot)
    event_bus = EventBus()
    telemetry = TelemetryRecorder()
    driver = SimulationDriver(robot, collision_engine, event_bus, telemetry)
    driver.connect()
    driver.enable()

    gripper = GripperController(robot.tool) if robot.tool else None
    return CLIContext(robot, driver, collision_engine, telemetry, event_bus, gripper)
