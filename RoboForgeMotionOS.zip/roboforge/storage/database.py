"""SQLAlchemy engine/session setup. Defaults to a local SQLite file so
the platform runs standalone with zero external infrastructure; point
``ROBOFORGE_DATABASE_URL`` at Postgres/etc. for a production deployment.
"""

from __future__ import annotations

import os

from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker


class Base(DeclarativeBase):
    pass


def _default_url() -> str:
    return os.environ.get("ROBOFORGE_DATABASE_URL", "sqlite:///roboforge.db")


def get_engine(url: str | None = None):
    url = url or _default_url()
    connect_args = {"check_same_thread": False} if url.startswith("sqlite") else {}
    return create_engine(url, connect_args=connect_args, future=True)


def get_session_factory(engine=None) -> sessionmaker:
    engine = engine or get_engine()
    return sessionmaker(bind=engine, expire_on_commit=False, class_=Session, future=True)


def init_db(engine=None) -> None:
    """Create all tables. Import ``roboforge.storage.models`` before
    calling this so every model is registered on ``Base.metadata``."""
    from roboforge.storage import models  # noqa: F401  (register models)

    engine = engine or get_engine()
    Base.metadata.create_all(engine)
