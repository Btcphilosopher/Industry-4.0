"""Persistent ORM models (sections 42, 48): robots, calibration
history, planned/executed trajectories, the audit-logged event stream,
and RBAC users.
"""

from __future__ import annotations

import time
import uuid

from sqlalchemy import Boolean, Float, ForeignKey, JSON, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from roboforge.storage.database import Base


def _uuid() -> str:
    return uuid.uuid4().hex


class RobotRecord(Base):
    __tablename__ = "robots"

    robot_id: Mapped[str] = mapped_column(String, primary_key=True)
    name: Mapped[str] = mapped_column(String)
    dof: Mapped[int] = mapped_column()
    kinematic_family: Mapped[str] = mapped_column(String)
    config_yaml_path: Mapped[str | None] = mapped_column(String, nullable=True)
    created_at: Mapped[float] = mapped_column(Float, default=time.time)

    calibrations: Mapped[list["CalibrationRecord"]] = relationship(back_populates="robot")
    trajectories: Mapped[list["TrajectoryRecord"]] = relationship(back_populates="robot")


class CalibrationRecord(Base):
    __tablename__ = "calibrations"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    robot_id: Mapped[str] = mapped_column(ForeignKey("robots.robot_id"))
    calibration_type: Mapped[str] = mapped_column(String)  # robot | camera | hand_eye | tcp
    repeatability_m: Mapped[float | None] = mapped_column(Float, nullable=True)
    absolute_accuracy_m: Mapped[float | None] = mapped_column(Float, nullable=True)
    result_json: Mapped[dict] = mapped_column(JSON, default=dict)
    performed_by: Mapped[str | None] = mapped_column(String, nullable=True)
    performed_at: Mapped[float] = mapped_column(Float, default=time.time)

    robot: Mapped["RobotRecord"] = relationship(back_populates="calibrations")


class TrajectoryRecord(Base):
    __tablename__ = "trajectories"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    robot_id: Mapped[str] = mapped_column(ForeignKey("robots.robot_id"))
    trajectory_type: Mapped[str] = mapped_column(String)
    objective: Mapped[str | None] = mapped_column(String, nullable=True)
    duration_s: Mapped[float] = mapped_column(Float)
    metrics_json: Mapped[dict] = mapped_column(JSON, default=dict)
    executed: Mapped[bool] = mapped_column(Boolean, default=False)
    success: Mapped[bool | None] = mapped_column(Boolean, nullable=True)
    created_at: Mapped[float] = mapped_column(Float, default=time.time)

    robot: Mapped["RobotRecord"] = relationship(back_populates="trajectories")


class EventRecord(Base):
    """An append-only audit log entry (section 48: every physical robot
    command must be auditable)."""

    __tablename__ = "events"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    robot_id: Mapped[str | None] = mapped_column(String, nullable=True)
    event_type: Mapped[str] = mapped_column(String)
    payload_json: Mapped[dict] = mapped_column(JSON, default=dict)
    actor: Mapped[str | None] = mapped_column(String, nullable=True)
    timestamp: Mapped[float] = mapped_column(Float, default=time.time)


class UserRecord(Base):
    __tablename__ = "users"

    username: Mapped[str] = mapped_column(String, primary_key=True)
    hashed_password: Mapped[str] = mapped_column(String)
    role: Mapped[str] = mapped_column(String)  # roboforge.core.enums.Role value
    api_token: Mapped[str | None] = mapped_column(String, nullable=True, unique=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[float] = mapped_column(Float, default=time.time)
