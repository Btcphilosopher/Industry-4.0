"""Camera intrinsic calibration."""
