"""Camera intrinsic + extrinsic calibration via the Direct Linear
Transform (DLT) (section 16).

Given a set of known 3D calibration-target points (world frame) and
their observed 2D pixel projections, solves for the 3x4 camera
projection matrix ``P = K [R | t]`` by SVD, then recovers the intrinsic
matrix ``K`` and camera pose ``[R | t]`` via RQ decomposition -- the
standard closed-form approach that does not require an iterative
nonlinear refinement (which could be layered on top for production use,
e.g. Levenberg-Marquardt reprojection-error minimisation, but DLT alone
is sufficient to get a working ``CameraIntrinsics``/``Pose`` for this
platform's calibration workflow).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.linalg import rq

from roboforge.core.exceptions import CalibrationError
from roboforge.core.transforms import Pose
from roboforge.perception.cameras.camera import CameraIntrinsics


@dataclass
class CameraCalibrationResult:
    intrinsics: CameraIntrinsics
    pose_camera_in_world: Pose
    reprojection_error_rms_px: float
    n_points: int


def _build_dlt_matrix(world_points: np.ndarray, pixel_points: np.ndarray) -> np.ndarray:
    n = world_points.shape[0]
    A = np.zeros((2 * n, 12))
    for i in range(n):
        X = np.append(world_points[i], 1.0)
        u, v = pixel_points[i]
        A[2 * i, 0:4] = X
        A[2 * i, 8:12] = -u * X
        A[2 * i + 1, 4:8] = X
        A[2 * i + 1, 8:12] = -v * X
    return A


def _decompose_projection_matrix(P: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Decompose P (3x4) into K (3x3 upper-triangular intrinsics), R (3x3
    rotation, world->camera), and camera centre in world coordinates."""
    M = P[:, :3]
    K, R = rq(M)

    # Fix sign ambiguity so K has a positive diagonal (a valid intrinsic
    # matrix) and R remains a proper rotation (det = +1).
    T = np.diag(np.sign(np.diag(K)))
    if np.linalg.det(T) < 0:
        T = -T
    K = K @ T
    R = T @ R
    K = K / K[2, 2]

    camera_centre = -np.linalg.inv(M) @ P[:, 3]
    return K, R, camera_centre


class CameraCalibrationEngine:
    def calibrate(
        self,
        world_points: list[np.ndarray],
        pixel_points: list[tuple[float, float]],
        image_width: int,
        image_height: int,
    ) -> CameraCalibrationResult:
        if len(world_points) < 6:
            raise CalibrationError("DLT camera calibration requires at least 6 point correspondences")
        if len(world_points) != len(pixel_points):
            raise CalibrationError("world_points and pixel_points must have equal length")

        W = np.array(world_points, dtype=float)
        U = np.array(pixel_points, dtype=float)

        A = _build_dlt_matrix(W, U)
        _, _, Vt = np.linalg.svd(A)
        P = Vt[-1].reshape(3, 4)

        K, R, camera_centre = _decompose_projection_matrix(P)

        # Reprojection error.
        W_h = np.hstack([W, np.ones((len(W), 1))])
        proj = (P @ W_h.T).T
        proj_px = proj[:, :2] / proj[:, 2:3]
        rms = float(np.sqrt(np.mean(np.sum((proj_px - U) ** 2, axis=1))))

        intrinsics = CameraIntrinsics(
            fx=float(K[0, 0]), fy=float(K[1, 1]), cx=float(K[0, 2]), cy=float(K[1, 2]),
            width=image_width, height=image_height,
        )
        # R (from RQ) is world->camera; the camera's pose in world is its
        # inverse (R^T) with translation = camera centre in world.
        pose_camera_in_world = Pose(position=camera_centre, rotation=R.T, frame="world")

        return CameraCalibrationResult(
            intrinsics=intrinsics,
            pose_camera_in_world=pose_camera_in_world,
            reprojection_error_rms_px=rms,
            n_points=len(world_points),
        )
