"""TCP (Tool Centre Point) calibration via the standard N-point pivot
method (section 16): jog the tool tip to touch the same fixed point in
space from several different orientations, and solve for the constant
tool offset (in the flange frame) that is consistent with all of them.

For each measurement ``i`` with flange pose ``(R_i, t_i)`` and unknown
tool offset ``p_tool`` (flange frame) touching a fixed but also-unknown
world point ``p_world``:

    R_i @ p_tool + t_i = p_world   for every i

Stacking ``[R_i | -I_3] [p_tool; p_world]^T = -t_i`` over all
measurements gives a linear least-squares problem solved directly (no
iteration needed), with more measurements (and more varied orientations)
improving conditioning.
"""

from __future__ import annotations

import time
from dataclasses import dataclass

import numpy as np

from roboforge.core.exceptions import CalibrationError
from roboforge.core.transforms import Pose


@dataclass
class TCPCalibrationResult:
    tool_offset: np.ndarray       # tool tip position in the flange frame
    fixed_world_point: np.ndarray
    residual_rms_m: float
    n_measurements: int
    timestamp: float


class TCPCalibrationEngine:
    def calibrate_pivot(self, flange_poses: list[Pose]) -> TCPCalibrationResult:
        if len(flange_poses) < 4:
            raise CalibrationError("TCP pivot calibration requires at least 4 flange poses at varied orientations")

        n = len(flange_poses)
        A = np.zeros((3 * n, 6))
        b = np.zeros(3 * n)
        for i, pose in enumerate(flange_poses):
            A[3 * i : 3 * i + 3, 0:3] = pose.rotation
            A[3 * i : 3 * i + 3, 3:6] = -np.eye(3)
            b[3 * i : 3 * i + 3] = -pose.position

        solution, *_ = np.linalg.lstsq(A, b, rcond=None)
        tool_offset = solution[0:3]
        world_point = solution[3:6]

        residuals = []
        for pose in flange_poses:
            predicted = pose.rotation @ tool_offset + pose.position
            residuals.append(np.linalg.norm(predicted - world_point))
        rms = float(np.sqrt(np.mean(np.square(residuals))))

        return TCPCalibrationResult(
            tool_offset=tool_offset,
            fixed_world_point=world_point,
            residual_rms_m=rms,
            n_measurements=n,
            timestamp=time.time(),
        )
