"""Tool Centre Point (TCP) calibration."""
