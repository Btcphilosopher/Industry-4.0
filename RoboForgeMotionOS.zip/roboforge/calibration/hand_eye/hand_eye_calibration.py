"""Hand-eye calibration: solves the classic ``AX = XB`` formulation
(section 15-16) for the unknown rigid transform ``X`` between the
robot flange and the camera (eye-in-hand) or between the robot base and
a stationary camera (eye-to-hand).

Uses the closed-form Park & Martin (1994) method: convert each motion
pair's rotation to a rotation vector, solve for the rotation ``R_X`` via
an orthogonal Procrustes problem, then solve for the translation with a
linear least-squares system built from the remaining ``AX = XB``
constraint. This is a standard, non-iterative, well-conditioned solver
suitable for a handful to a few dozen motion pairs (the recommended
minimum is >= 3, in general position -- not all rotating about the same
axis).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.linalg import sqrtm

from roboforge.core.exceptions import CalibrationError
from roboforge.core.transforms import Pose, rotation_matrix_to_axis_angle


@dataclass
class HandEyeResult:
    X: Pose                       # the solved flange->camera (or base->camera) transform
    rotation_residual_rad: float  # RMS rotation-consistency residual across motion pairs
    translation_residual_m: float
    n_pairs: int


def _rotvec(R: np.ndarray) -> np.ndarray:
    axis, angle = rotation_matrix_to_axis_angle(R)
    return axis * angle


def solve_hand_eye(robot_motions: list[Pose], camera_motions: list[Pose]) -> HandEyeResult:
    """Solve ``A_i X = X B_i`` for X given paired robot-frame motions
    ``A_i`` (e.g. successive flange poses' relative transforms) and the
    corresponding camera-observed motions ``B_i`` (e.g. the target's
    apparent relative transform in the camera frame, inverted as needed
    to represent the same physical motion) -- see
    ``roboforge.calibration.hand_eye.solve_hand_eye`` callers for how the
    A/B pair lists are assembled for eye-in-hand vs eye-to-hand rigs.
    """
    if len(robot_motions) != len(camera_motions):
        raise CalibrationError("robot_motions and camera_motions must have equal length")
    if len(robot_motions) < 3:
        raise CalibrationError("Hand-eye calibration requires at least 3 motion pairs")

    alphas = np.array([_rotvec(a.rotation) for a in robot_motions])
    betas = np.array([_rotvec(b.rotation) for b in camera_motions])

    M = np.zeros((3, 3))
    for alpha, beta in zip(alphas, betas):
        M += np.outer(beta, alpha)

    MtM = M.T @ M
    # Symmetric positive-definite square root, per Park & Martin.
    MtM_inv_sqrt = np.real(np.linalg.inv(sqrtm(MtM)))
    R_x = MtM_inv_sqrt @ M.T

    # Enforce a proper rotation (guard against numerical drift).
    U, _, Vt = np.linalg.svd(R_x)
    R_x = U @ Vt
    if np.linalg.det(R_x) < 0:
        U[:, -1] *= -1
        R_x = U @ Vt

    # Translation: stack (R_Ai - I) t_x = R_x t_Bi - t_Ai over all pairs.
    rows = []
    rhs = []
    for a, b in zip(robot_motions, camera_motions):
        rows.append(a.rotation - np.eye(3))
        rhs.append(R_x @ b.position - a.position)
    A_stack = np.vstack(rows)
    b_stack = np.concatenate(rhs)
    t_x, *_ = np.linalg.lstsq(A_stack, b_stack, rcond=None)

    # Residuals: how consistent each pair is with the solved X.
    rot_residuals = []
    trans_residuals = []
    for a, b in zip(robot_motions, camera_motions):
        lhs_R = a.rotation @ R_x
        rhs_R = R_x @ b.rotation
        residual_R = lhs_R.T @ rhs_R
        _, angle = rotation_matrix_to_axis_angle(residual_R)
        rot_residuals.append(angle)

        lhs_t = a.rotation @ t_x + a.position
        rhs_t = R_x @ b.position + t_x
        trans_residuals.append(np.linalg.norm(lhs_t - rhs_t))

    return HandEyeResult(
        X=Pose(t_x, R_x),
        rotation_residual_rad=float(np.sqrt(np.mean(np.square(rot_residuals)))),
        translation_residual_m=float(np.sqrt(np.mean(np.square(trans_residuals)))),
        n_pairs=len(robot_motions),
    )
