"""Hand-eye calibration (eye-in-hand and eye-to-hand)."""
