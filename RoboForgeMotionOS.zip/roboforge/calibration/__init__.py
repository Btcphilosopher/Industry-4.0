"""Calibration subsystem (sections 15-16): robot, camera, hand-eye, and
TCP calibration, all producing explicit, traceable coordinate
transforms and precision reports (repeatability vs. accuracy vs.
resolution vs. measurement uncertainty)."""

from roboforge.calibration.robot.robot_calibration import RobotCalibrationEngine, RobotCalibrationReport
from roboforge.calibration.camera.camera_calibration import CameraCalibrationEngine, CameraCalibrationResult
from roboforge.calibration.hand_eye.hand_eye_calibration import solve_hand_eye, HandEyeResult
from roboforge.calibration.tcp.tcp_calibration import TCPCalibrationEngine, TCPCalibrationResult

__all__ = [
    "RobotCalibrationEngine",
    "RobotCalibrationReport",
    "CameraCalibrationEngine",
    "CameraCalibrationResult",
    "solve_hand_eye",
    "HandEyeResult",
    "TCPCalibrationEngine",
    "TCPCalibrationResult",
]
