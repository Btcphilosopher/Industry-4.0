"""Robot (joint zero offset / repeatability / accuracy) calibration."""
