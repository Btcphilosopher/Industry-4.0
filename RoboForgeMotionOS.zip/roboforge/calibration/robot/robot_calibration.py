"""Robot calibration (section 16): joint zero-offset calibration, and
measurement of repeatability vs. absolute accuracy from repeated moves to
the same commanded target.

Follows the ISO 9283 convention for pose repeatability: for N measured
positions at a single commanded target, let ``l`` be the mean distance of
each measured position from the sample mean position, and ``S_l`` its
standard deviation; repeatability is reported as ``l + 3*S_l`` (a
statistical bound covering ~99.7% of repeat visits under a Gaussian
assumption), which is distinct from absolute accuracy (the offset of the
mean measured position from the *commanded* target).
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np

from roboforge.core.exceptions import CalibrationError
from roboforge.core.transforms import Pose

if TYPE_CHECKING:
    from roboforge.robotics.robot import Robot


@dataclass
class RobotCalibrationReport:
    n_samples: int
    target_pose: Pose
    mean_measured_pose: Pose
    repeatability_m: float
    absolute_accuracy_m: float
    orientation_repeatability_rad: float
    orientation_accuracy_rad: float
    joint_zero_offsets: np.ndarray
    timestamp: float


class RobotCalibrationEngine:
    def __init__(self, robot: "Robot") -> None:
        self.robot = robot

    def calibrate_joint_zero_offsets(
        self, nominal_reference: np.ndarray, measured_reference: np.ndarray
    ) -> np.ndarray:
        """Compute per-joint zero offsets from a reference measurement
        (e.g. joints driven to mechanical hard stops or a master fixture):
        ``offset = measured - nominal``. Forward kinematics subtracts this
        offset from commanded joint values before evaluating the DH chain
        (see ``forward_kinematics_all_frames``).
        """
        nominal_reference = np.asarray(nominal_reference, dtype=float)
        measured_reference = np.asarray(measured_reference, dtype=float)
        if nominal_reference.shape != (self.robot.dof,) or measured_reference.shape != (self.robot.dof,):
            raise CalibrationError("Reference arrays must have shape (robot.dof,)")
        offsets = measured_reference - nominal_reference
        self.robot.calibration.joint_zero_offsets = offsets
        return offsets

    def measure_repeatability_and_accuracy(
        self, target_pose: Pose, measured_poses: list[Pose]
    ) -> RobotCalibrationReport:
        if len(measured_poses) < 3:
            raise CalibrationError("At least 3 repeat measurements are required for a meaningful report")

        positions = np.array([p.position for p in measured_poses])
        mean_position = positions.mean(axis=0)
        position_deviations = np.linalg.norm(positions - mean_position, axis=1)
        l_bar = float(position_deviations.mean())
        s_l = float(position_deviations.std(ddof=1))
        repeatability = l_bar + 3 * s_l
        accuracy = float(np.linalg.norm(mean_position - target_pose.position))

        angular_deviations = []
        for p in measured_poses:
            angular_deviations.append(p.angular_distance_to(measured_poses[0]))
        orientation_repeatability = float(np.mean(angular_deviations) + 3 * np.std(angular_deviations, ddof=1)) if len(angular_deviations) > 1 else 0.0

        mean_pose = Pose(mean_position, measured_poses[0].rotation, frame=target_pose.frame)
        orientation_accuracy = mean_pose.angular_distance_to(target_pose)

        report = RobotCalibrationReport(
            n_samples=len(measured_poses),
            target_pose=target_pose,
            mean_measured_pose=mean_pose,
            repeatability_m=repeatability,
            absolute_accuracy_m=accuracy,
            orientation_repeatability_rad=orientation_repeatability,
            orientation_accuracy_rad=orientation_accuracy,
            joint_zero_offsets=self.robot.calibration.joint_zero_offsets.copy()
            if self.robot.calibration.joint_zero_offsets is not None
            else np.zeros(self.robot.dof),
            timestamp=time.time(),
        )
        self.apply_report(report)
        return report

    def apply_report(self, report: RobotCalibrationReport) -> None:
        self.robot.calibration.repeatability_m = report.repeatability_m
        self.robot.calibration.absolute_accuracy_m = report.absolute_accuracy_m
        self.robot.calibration.calibrated = True
