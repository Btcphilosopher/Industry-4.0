"""Simulated proximity sensor: reports the clearance to the nearest
collision-world obstacle from a collision engine, within a configured
range."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from roboforge.sensors.sensor import Sensor, SensorReading

if TYPE_CHECKING:
    from roboforge.collision.collision_engine import CollisionEngine


class SimulatedProximitySensor(Sensor):
    def __init__(self, sensor_id: str, collision_engine: "CollisionEngine", max_range_m: float = 0.3,
                 noise_std_m: float = 0.002, rng: np.random.Generator | None = None) -> None:
        super().__init__(sensor_id)
        self.collision_engine = collision_engine
        self.max_range_m = max_range_m
        self.noise_std_m = noise_std_m
        self.rng = rng or np.random.default_rng()

    def read(self, q: np.ndarray | None = None) -> SensorReading:
        q = self.collision_engine.robot.joint_state.position if q is None else q
        clearance = self.collision_engine.clearance(q)
        if clearance > self.max_range_m:
            return SensorReading(sensor_id=self.sensor_id, value=self.max_range_m, confidence=0.5)
        noisy = max(0.0, clearance + self.rng.normal(0, self.noise_std_m))
        return SensorReading(sensor_id=self.sensor_id, value=noisy, confidence=0.9)
