"""Simulated joint encoder: quantises a true joint position to the
encoder's resolution and adds a small amount of read noise."""

from __future__ import annotations

import numpy as np

from roboforge.sensors.sensor import Sensor, SensorReading


class SimulatedEncoder(Sensor):
    def __init__(self, sensor_id: str, resolution_rad: float = 1e-5, noise_std_rad: float = 2e-6,
                 rng: np.random.Generator | None = None) -> None:
        super().__init__(sensor_id)
        self.resolution_rad = resolution_rad
        self.noise_std_rad = noise_std_rad
        self.rng = rng or np.random.default_rng()
        self._true_value = 0.0

    def set_true_value(self, value: float) -> None:
        self._true_value = value

    def read(self) -> SensorReading:
        noisy = self._true_value + self.rng.normal(0, self.noise_std_rad)
        quantised = round(noisy / self.resolution_rad) * self.resolution_rad
        return SensorReading(sensor_id=self.sensor_id, value=quantised, confidence=0.99)
