"""Sensor framework: joint encoders, force/torque sensors, proximity
sensors, and the fusion point for external tracking systems (section 24).

All sensors in this tree are simulated (no physical I/O), since section
27/28 require a deterministic, hardware-free simulation environment; each
sensor models a realistic physical limitation (encoder quantisation,
F/T sensor noise and bandwidth, proximity sensor range) rather than
returning noiseless ground truth, so that state estimation and control
code exercised against them behaves like it would against real sensors.
"""

from roboforge.sensors.sensor import Sensor, SensorReading
from roboforge.sensors.encoder import SimulatedEncoder
from roboforge.sensors.force_torque_sensor import SimulatedForceTorqueSensor
from roboforge.sensors.proximity_sensor import SimulatedProximitySensor

__all__ = [
    "Sensor",
    "SensorReading",
    "SimulatedEncoder",
    "SimulatedForceTorqueSensor",
    "SimulatedProximitySensor",
]
