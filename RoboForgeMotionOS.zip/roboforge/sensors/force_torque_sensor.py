"""Simulated 6-axis force/torque sensor: reports a wrench with Gaussian
noise and a fixed bias, and can be driven by a contact-model callback
(used by the simulation engine to inject realistic contact forces)."""

from __future__ import annotations

from typing import Callable

import numpy as np

from roboforge.sensors.sensor import Sensor, SensorReading


class SimulatedForceTorqueSensor(Sensor):
    def __init__(
        self,
        sensor_id: str,
        force_noise_std_n: float = 0.15,
        torque_noise_std_nm: float = 0.02,
        bias: np.ndarray | None = None,
        rng: np.random.Generator | None = None,
    ) -> None:
        super().__init__(sensor_id)
        self.force_noise_std_n = force_noise_std_n
        self.torque_noise_std_nm = torque_noise_std_nm
        self.bias = np.zeros(6) if bias is None else np.asarray(bias, dtype=float)
        self.rng = rng or np.random.default_rng()
        self._true_wrench = np.zeros(6)
        self._source: Callable[[], np.ndarray] | None = None

    def set_true_wrench(self, wrench: np.ndarray) -> None:
        self._true_wrench = np.asarray(wrench, dtype=float)

    def bind_source(self, source: Callable[[], np.ndarray]) -> None:
        """Bind a callback (e.g. the simulation's contact model) that
        supplies the true wrench at read time instead of a static value."""
        self._source = source

    def read(self) -> SensorReading:
        true_wrench = self._source() if self._source is not None else self._true_wrench
        noise = np.concatenate(
            [
                self.rng.normal(0, self.force_noise_std_n, size=3),
                self.rng.normal(0, self.torque_noise_std_nm, size=3),
            ]
        )
        measured = np.asarray(true_wrench, dtype=float) + self.bias + noise
        return SensorReading(sensor_id=self.sensor_id, value=measured, confidence=0.95)
