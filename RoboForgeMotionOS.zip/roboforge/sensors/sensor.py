"""Abstract sensor interface: every sensor reports a value, a confidence
figure, and a timestamp, so state estimation can weight/fuse readings
consistently regardless of sensor type (section 24-25)."""

from __future__ import annotations

import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass
class SensorReading:
    sensor_id: str
    value: Any
    confidence: float
    timestamp: float = field(default_factory=time.time)


class Sensor(ABC):
    def __init__(self, sensor_id: str) -> None:
        self.sensor_id = sensor_id

    @abstractmethod
    def read(self) -> SensorReading:
        ...
