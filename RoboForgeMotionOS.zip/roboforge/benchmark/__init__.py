"""The precision-robotics benchmark suite (section 45)."""
