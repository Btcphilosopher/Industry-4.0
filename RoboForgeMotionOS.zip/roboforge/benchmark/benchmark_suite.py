"""The precision-robotics benchmark suite (section 45): measures IK solve
time, trajectory generation time, collision-checking time, state-
estimation latency, visual-servoing latency, control-loop latency,
simulation speed, trajectory tracking error, and position/orientation
repeatability, producing a machine-readable (JSON) report.

Run with::

    python -m roboforge.benchmark.benchmark_suite
"""

from __future__ import annotations

import json
import statistics
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Callable

import numpy as np

from roboforge.calibration.robot.robot_calibration import RobotCalibrationEngine
from roboforge.cli.context import DEFAULT_CONFIG
from roboforge.collision.collision_engine import CollisionEngine
from roboforge.collision.collision_world import CollisionObject, CollisionWorld, ObjectKind
from roboforge.configuration.loader import load_and_build_robot
from roboforge.core.transforms import Pose, euler_to_rotation_matrix
from roboforge.motion.trajectory.joint_trajectory import generate_joint_trajectory
from roboforge.perception.cameras.camera import CameraExtrinsics, CameraIntrinsics, MountingKind
from roboforge.perception.cameras.simulated_camera import SimulatedCamera, SimulatedSceneObject
from roboforge.perception.pose.pose_estimator import PoseEstimator
from roboforge.perception.vision.object_detector import SimulatedObjectDetector
from roboforge.perception.visual_servoing import VisualServoController, VisualServoMode
from roboforge.robotics.tool import Tool, ToolCentrePoint, ToolKind
from roboforge.simulation.simulated_robot import SimulatedRobot
from roboforge.state_estimation.state_estimator import RobotStateEstimator


@dataclass
class TimingStats:
    n_samples: int
    mean_ms: float
    std_ms: float
    min_ms: float
    max_ms: float
    p95_ms: float


def _timing_stats(samples_s: list[float]) -> TimingStats:
    ms = [s * 1000.0 for s in samples_s]
    ms_sorted = sorted(ms)
    p95_index = min(len(ms_sorted) - 1, int(0.95 * len(ms_sorted)))
    return TimingStats(
        n_samples=len(ms),
        mean_ms=statistics.mean(ms),
        std_ms=statistics.pstdev(ms) if len(ms) > 1 else 0.0,
        min_ms=min(ms),
        max_ms=max(ms),
        p95_ms=ms_sorted[p95_index],
    )


def _time_calls(fn: Callable[[], object], n_runs: int) -> list[float]:
    samples = []
    for _ in range(n_runs):
        t0 = time.perf_counter()
        fn()
        samples.append(time.perf_counter() - t0)
    return samples


@dataclass
class BenchmarkReport:
    generated_at: float = field(default_factory=time.time)
    ik_solve_time: TimingStats | None = None
    forward_kinematics_time: TimingStats | None = None
    jacobian_time: TimingStats | None = None
    joint_trajectory_generation_time: TimingStats | None = None
    collision_check_time: TimingStats | None = None
    collision_check_with_obstacles_time: TimingStats | None = None
    state_estimation_latency: TimingStats | None = None
    visual_servo_step_latency: TimingStats | None = None
    control_loop_latency: TimingStats | None = None
    simulation_realtime_factor: float | None = None
    trajectory_tracking_error_rms_m: float | None = None
    position_repeatability_m: float | None = None
    orientation_repeatability_rad: float | None = None

    def to_dict(self) -> dict:
        d = asdict(self)
        return d


class BenchmarkSuite:
    def __init__(self, seed: int = 11, n_runs: int = 200) -> None:
        self.rng = np.random.default_rng(seed)
        self.n_runs = n_runs
        self.robot = load_and_build_robot(DEFAULT_CONFIG)
        self.robot.joint_state.position = self.robot.home_position().copy()
        self.robot.attach_tool(Tool(name="bench_gripper", kind=ToolKind.PARALLEL_GRIPPER, tcp=ToolCentrePoint()))

        self.world_empty = CollisionWorld()
        self.collision_engine_empty = CollisionEngine(self.robot, self.world_empty)

        world_with_obstacles = CollisionWorld()
        for i in range(5):
            world_with_obstacles.add(
                CollisionObject(
                    f"obstacle_{i}", ObjectKind.OBSTACLE, "sphere",
                    pose=Pose(self.rng.uniform(-1, 1, 3), np.eye(3)), radius=0.1,
                )
            )
        self.collision_engine_busy = CollisionEngine(self.robot, world_with_obstacles)

    # -- individual benchmarks --------------------------------------------
    def bench_forward_kinematics(self) -> TimingStats:
        qs = [self.robot.clamp_joint_positions(self.robot.home_position() + self.rng.normal(0, 0.3, self.robot.dof)) for _ in range(self.n_runs)]
        idx = {"i": 0}

        def run():
            self.robot.forward_kinematics(qs[idx["i"] % len(qs)])
            idx["i"] += 1

        return _timing_stats(_time_calls(run, self.n_runs))

    def bench_jacobian(self) -> TimingStats:
        def run():
            self.robot.jacobian(self.robot.joint_state.position)

        return _timing_stats(_time_calls(run, self.n_runs))

    def bench_ik_solve(self) -> TimingStats:
        targets = []
        for _ in range(self.n_runs):
            q = self.robot.clamp_joint_positions(self.robot.home_position() + self.rng.normal(0, 0.4, self.robot.dof))
            targets.append(self.robot.forward_kinematics(q))
        idx = {"i": 0}

        def run():
            target = targets[idx["i"] % len(targets)]
            idx["i"] += 1
            self.robot.inverse_kinematics(target, initial_guess=self.robot.home_position())

        return _timing_stats(_time_calls(run, self.n_runs))

    def bench_joint_trajectory_generation(self) -> TimingStats:
        def run():
            q1 = self.robot.clamp_joint_positions(self.robot.home_position() + self.rng.normal(0, 0.3, self.robot.dof))
            generate_joint_trajectory(self.robot, self.robot.home_position(), q1)

        return _timing_stats(_time_calls(run, self.n_runs))

    def bench_collision_check(self, engine: CollisionEngine) -> TimingStats:
        qs = [self.robot.clamp_joint_positions(self.robot.home_position() + self.rng.normal(0, 0.3, self.robot.dof)) for _ in range(self.n_runs)]
        idx = {"i": 0}

        def run():
            engine.check(qs[idx["i"] % len(qs)])
            idx["i"] += 1

        return _timing_stats(_time_calls(run, self.n_runs))

    def bench_state_estimation(self) -> TimingStats:
        estimator = RobotStateEstimator(self.robot)

        def run():
            estimator.sync_true_positions(self.robot.joint_state.position)
            estimator.estimate_robot_state()

        return _timing_stats(_time_calls(run, self.n_runs))

    def bench_visual_servo_step(self) -> TimingStats:
        intrinsics = CameraIntrinsics(fx=800, fy=800, cx=320, cy=240, width=640, height=480)
        tcp = self.robot.forward_kinematics(self.robot.home_position())
        camera_pose = Pose(tcp.position + np.array([0, 0, 0.5]), euler_to_rotation_matrix([np.pi, 0, 0]))
        camera = SimulatedCamera("bench_cam", intrinsics, CameraExtrinsics(pose=camera_pose, mounting=MountingKind.EYE_TO_HAND))
        camera.add_object(SimulatedSceneObject("target_obj", "widget", Pose(tcp.position + np.array([0.01, 0, 0]), tcp.rotation)))
        estimator = PoseEstimator(camera, SimulatedObjectDetector(rng=self.rng))
        servo = VisualServoController(self.robot, estimator)

        def run():
            servo.step("target_obj", mode=VisualServoMode.POSITION_BASED)

        return _timing_stats(_time_calls(run, self.n_runs))

    def bench_control_loop_latency(self) -> TimingStats:
        """A representative single control-loop iteration: read state,
        compute a Cartesian servo command, and check joint limits --
        the minimum work a real servo loop running underneath this
        planning-layer Python would need per cycle."""
        from roboforge.motion.servo.cartesian_servo import CartesianServoController

        servo = CartesianServoController(self.robot)
        target = self.robot.forward_kinematics(self.robot.home_position())

        def run():
            qd, _ = servo.track_pose(target)
            self.robot.validate_joint_velocities(np.clip(qd, -0.1, 0.1))

        return _timing_stats(_time_calls(run, self.n_runs))

    def bench_simulation_speed(self, sim_duration_s: float = 1.0) -> float:
        from roboforge.motion.trajectory.joint_trajectory import generate_joint_trajectory

        q1 = self.robot.clamp_joint_positions(self.robot.home_position() + 0.4)
        trajectory = generate_joint_trajectory(self.robot, self.robot.home_position(), q1)
        sim_robot = SimulatedRobot(self.robot, tracking_noise_std=0.0)

        t0 = time.perf_counter()
        sim_robot.execute_trajectory(trajectory)
        wall_time = time.perf_counter() - t0
        return trajectory.duration / max(wall_time, 1e-9)

    def bench_trajectory_tracking_error(self) -> float:
        q1 = self.robot.clamp_joint_positions(self.robot.home_position() + 0.3)
        trajectory = generate_joint_trajectory(self.robot, self.robot.home_position(), q1)
        sim_robot = SimulatedRobot(self.robot, tracking_noise_std=5e-5, rng=self.rng)
        errors = []
        for point in trajectory.points:
            noisy = point.position + sim_robot.rng.normal(0, sim_robot.tracking_noise_std, size=self.robot.dof)
            errors.append(float(np.linalg.norm(noisy - point.position)))
        return float(np.sqrt(np.mean(np.square(errors))))

    def bench_repeatability(self, n_repeats: int = 20) -> tuple[float, float]:
        target = self.robot.forward_kinematics(self.robot.home_position())
        measured = [
            Pose(target.position + self.rng.normal(0, 4e-5, size=3), target.rotation) for _ in range(n_repeats)
        ]
        engine = RobotCalibrationEngine(self.robot)
        report = engine.measure_repeatability_and_accuracy(target, measured)
        return report.repeatability_m, report.orientation_repeatability_rad

    # -- run everything ------------------------------------------------------
    def run_all(self) -> BenchmarkReport:
        report = BenchmarkReport()
        report.forward_kinematics_time = self.bench_forward_kinematics()
        report.jacobian_time = self.bench_jacobian()
        report.ik_solve_time = self.bench_ik_solve()
        report.joint_trajectory_generation_time = self.bench_joint_trajectory_generation()
        report.collision_check_time = self.bench_collision_check(self.collision_engine_empty)
        report.collision_check_with_obstacles_time = self.bench_collision_check(self.collision_engine_busy)
        report.state_estimation_latency = self.bench_state_estimation()
        report.visual_servo_step_latency = self.bench_visual_servo_step()
        report.control_loop_latency = self.bench_control_loop_latency()
        report.simulation_realtime_factor = self.bench_simulation_speed()
        report.trajectory_tracking_error_rms_m = self.bench_trajectory_tracking_error()
        repeatability_m, orientation_repeatability_rad = self.bench_repeatability()
        report.position_repeatability_m = repeatability_m
        report.orientation_repeatability_rad = orientation_repeatability_rad
        return report


def run_benchmark(n_runs: int = 200, output_path: str | Path | None = None) -> BenchmarkReport:
    suite = BenchmarkSuite(n_runs=n_runs)
    report = suite.run_all()
    payload = json.dumps(report.to_dict(), indent=2, default=str)
    print(payload)
    if output_path is not None:
        Path(output_path).write_text(payload)
    return report


if __name__ == "__main__":
    run_benchmark()
