"""Loads and validates YAML robot configuration, then builds a fully
constructed ``Robot`` from it (section 42): configuration is validated by
the Pydantic schema *before* any ``Robot``/``Joint``/``Link`` object is
constructed, and a robot built this way starts in ``MotionState.DISCONNECTED``
-- it must still be explicitly connected and enabled (section 32/33)
before it can be commanded.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import yaml

from roboforge.configuration.schema import RobotConfigSchema
from roboforge.core.enums import JointType, RobotKinematicFamily
from roboforge.core.exceptions import ConfigurationError
from roboforge.core.transforms import Pose
from roboforge.robotics.joint import DHParameters, Joint, JointLimits
from roboforge.robotics.link import InertialProperties, Link, LinkGeometry
from roboforge.robotics.robot import MotionConstraints, Robot, WorkspaceEnvelope


def load_robot_config(path: str | Path) -> RobotConfigSchema:
    path = Path(path)
    if not path.exists():
        raise ConfigurationError(f"Robot configuration file not found: {path}")
    with open(path, "r") as f:
        raw = yaml.safe_load(f)
    if raw is None:
        raise ConfigurationError(f"Robot configuration file is empty: {path}")
    # Support both a bare document and a `robot:`-wrapped document (the
    # illustrative YAML in section 42 nests config under a top-level `robot:` key).
    payload = raw["robot"] if isinstance(raw, dict) and "robot" in raw else raw
    try:
        return RobotConfigSchema.model_validate(payload)
    except Exception as exc:  # pydantic.ValidationError et al.
        raise ConfigurationError(f"Invalid robot configuration in {path}: {exc}") from exc


def build_robot_from_config(config: RobotConfigSchema) -> Robot:
    joints: list[Joint] = []
    for j in config.joints:
        joints.append(
            Joint(
                name=j.name,
                joint_type=JointType(j.type),
                dh=DHParameters(a=j.dh.a, alpha=j.dh.alpha, d=j.dh.d, theta_offset=j.dh.theta_offset, d_offset=j.dh.d_offset),
                limits=JointLimits(
                    min_position=j.min_position,
                    max_position=j.max_position,
                    max_velocity=j.max_velocity,
                    max_acceleration=j.max_acceleration,
                    max_jerk=j.max_jerk,
                    max_torque=j.max_torque,
                ),
                home_position=j.home_position,
            )
        )

    links: list[Link] = []
    if config.links:
        for l in config.links:
            links.append(
                Link(
                    name=l.name,
                    inertial=InertialProperties(
                        mass=l.mass_kg,
                        centre_of_mass=np.array(l.centre_of_mass),
                        inertia_tensor=np.diag(l.inertia_diagonal),
                    ),
                    geometry=LinkGeometry(
                        shape=l.geometry.shape,
                        point_a=np.array(l.geometry.point_a),
                        point_b=np.array(l.geometry.point_b),
                        radius=l.geometry.radius,
                        half_extents=np.array(l.geometry.half_extents),
                    ),
                )
            )
    else:
        # Default: a thin capsule link per joint with modest inertia, so
        # dynamics/collision checking works out of the box even without
        # explicit link geometry in the YAML.
        for j in config.joints:
            links.append(Link(name=f"{j.name}_link"))

    robot = Robot(
        robot_id=config.id,
        name=config.name,
        dof=config.dof,
        joints=joints,
        links=links,
        kinematic_family=RobotKinematicFamily(config.kinematic_family),
        workspace=WorkspaceEnvelope(
            min_corner=np.array(config.workspace.min_corner),
            max_corner=np.array(config.workspace.max_corner),
            max_reach_m=config.workspace.max_reach_m,
        ),
        motion_constraints=MotionConstraints(),
    )
    if config.payload.mass_kg > 0:
        robot.set_payload(config.payload.mass_kg, np.array(config.payload.centre_of_mass))
    robot.calibration.tcp_offset = Pose.from_xyzrpy(
        config.tcp.x, config.tcp.y, config.tcp.z, config.tcp.roll, config.tcp.pitch, config.tcp.yaw
    )
    return robot


def load_and_build_robot(path: str | Path) -> Robot:
    return build_robot_from_config(load_robot_config(path))
