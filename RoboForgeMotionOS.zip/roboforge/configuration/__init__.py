"""Externalised, validated robot configuration (section 42): YAML in,
a validated ``RobotConfigSchema`` and a fully-built ``Robot`` out."""

from roboforge.configuration.schema import (
    RobotConfigSchema,
    JointConfigSchema,
    PayloadConfigSchema,
    TCPConfigSchema,
    WorkspaceConfigSchema,
)
from roboforge.configuration.loader import load_robot_config, build_robot_from_config

__all__ = [
    "RobotConfigSchema",
    "JointConfigSchema",
    "PayloadConfigSchema",
    "TCPConfigSchema",
    "WorkspaceConfigSchema",
    "load_robot_config",
    "build_robot_from_config",
]
