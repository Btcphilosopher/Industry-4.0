"""Pydantic configuration schema (section 42). Robot configuration is
externalised as YAML and validated *before* a robot can be enabled --
``build_robot_from_config`` (in ``loader.py``) refuses to construct a
``Robot`` from a config that fails this schema's validation.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field, field_validator, model_validator


class DHConfigSchema(BaseModel):
    a: float = 0.0
    alpha: float = 0.0
    d: float = 0.0
    theta_offset: float = 0.0
    d_offset: float = 0.0


class JointConfigSchema(BaseModel):
    name: str
    type: Literal["revolute", "prismatic", "fixed"] = "revolute"
    dh: DHConfigSchema = Field(default_factory=DHConfigSchema)
    min_position: float
    max_position: float
    max_velocity: float = Field(gt=0)
    max_acceleration: float = Field(gt=0)
    max_jerk: float = Field(default=1000.0, gt=0)
    max_torque: float = Field(default=1000.0, gt=0)
    home_position: float = 0.0

    @model_validator(mode="after")
    def _check_position_range(self) -> "JointConfigSchema":
        if self.min_position >= self.max_position:
            raise ValueError(f"Joint {self.name!r}: min_position must be < max_position")
        if not (self.min_position <= self.home_position <= self.max_position):
            raise ValueError(f"Joint {self.name!r}: home_position must lie within [min_position, max_position]")
        return self


class LinkGeometryConfigSchema(BaseModel):
    shape: Literal["capsule", "box", "sphere"] = "capsule"
    point_a: list[float] = Field(default_factory=lambda: [0.0, 0.0, 0.0])
    point_b: list[float] = Field(default_factory=lambda: [0.0, 0.0, 0.1])
    radius: float = 0.05
    half_extents: list[float] = Field(default_factory=lambda: [0.05, 0.05, 0.05])


class LinkConfigSchema(BaseModel):
    name: str
    mass_kg: float = 1.0
    centre_of_mass: list[float] = Field(default_factory=lambda: [0.0, 0.0, 0.0])
    inertia_diagonal: list[float] = Field(default_factory=lambda: [0.01, 0.01, 0.01])
    geometry: LinkGeometryConfigSchema = Field(default_factory=LinkGeometryConfigSchema)


class PayloadConfigSchema(BaseModel):
    mass_kg: float = 0.0
    centre_of_mass: list[float] = Field(default_factory=lambda: [0.0, 0.0, 0.0])


class TCPConfigSchema(BaseModel):
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0
    roll: float = 0.0
    pitch: float = 0.0
    yaw: float = 0.0


class WorkspaceConfigSchema(BaseModel):
    min_corner: list[float] = Field(default_factory=lambda: [-2.0, -2.0, 0.0])
    max_corner: list[float] = Field(default_factory=lambda: [2.0, 2.0, 2.5])
    max_reach_m: float = Field(default=1.5, gt=0)

    @field_validator("min_corner", "max_corner")
    @classmethod
    def _check_len3(cls, v: list[float]) -> list[float]:
        if len(v) != 3:
            raise ValueError("must have exactly 3 components (x, y, z)")
        return v


class RobotConfigSchema(BaseModel):
    id: str
    name: str = ""
    dof: int = Field(gt=0, le=12)
    kinematic_family: Literal[
        "articulated", "scara", "delta", "cartesian", "parallel", "custom"
    ] = "articulated"
    joints: list[JointConfigSchema]
    links: list[LinkConfigSchema] = Field(default_factory=list)
    payload: PayloadConfigSchema = Field(default_factory=PayloadConfigSchema)
    tcp: TCPConfigSchema = Field(default_factory=TCPConfigSchema)
    workspace: WorkspaceConfigSchema = Field(default_factory=WorkspaceConfigSchema)

    @model_validator(mode="after")
    def _check_joint_count(self) -> "RobotConfigSchema":
        if len(self.joints) != self.dof:
            raise ValueError(f"Robot {self.id!r} declares dof={self.dof} but lists {len(self.joints)} joints")
        if self.links and len(self.links) != self.dof:
            raise ValueError(f"Robot {self.id!r}: if links are specified, there must be exactly dof={self.dof} of them")
        if not self.name:
            self.name = self.id
        return self
