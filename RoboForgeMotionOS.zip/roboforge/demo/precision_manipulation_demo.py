"""The complete simulated precision-manipulation demonstration (section 44).

Runs the full platform loop end to end, entirely in simulation:

    Camera -> Detect component -> Estimate 6D pose -> Transform into robot
    coordinates -> Select grasp -> Plan collision-free approach -> Move
    robot -> Close gripper -> Verify grasp -> Move to assembly fixture ->
    Perform precision alignment -> Perform insertion -> Use force
    feedback -> Verify insertion -> Release component -> Return to home

At every stage it prints the metrics section 44 asks for: robot pose,
joint positions, TCP position, trajectory summary, velocity,
acceleration, jerk, force, gripper state, object pose, collision
clearance, cycle time, position error, and an energy estimate.

Run with::

    python -m roboforge.demo.precision_manipulation_demo
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field

import numpy as np

from roboforge.calibration.robot.robot_calibration import RobotCalibrationEngine
from roboforge.cli.context import DEFAULT_CONFIG
from roboforge.collision.collision_engine import CollisionEngine
from roboforge.collision.collision_world import CollisionObject, CollisionWorld, ObjectKind
from roboforge.configuration.loader import load_and_build_robot
from roboforge.core.enums import IKMethod, PlannerObjective
from roboforge.core.transforms import Pose, euler_to_rotation_matrix
from roboforge.events.event_bus import EventBus
from roboforge.events.events import (
    CalibrationCompleted,
    CalibrationStarted,
    GraspDetected,
    ObjectDetected,
    ObjectPicked,
    ObjectPlaced,
    RobotConnected,
    RobotEnabled,
)
from roboforge.manipulation.grasping.grasp import GraspableObject, ObjectShape
from roboforge.manipulation.grasping.grasp_planner import GraspPlanner
from roboforge.manipulation.insertion.insertion_controller import InsertionController
from roboforge.manipulation.tools.gripper import GripperController
from roboforge.motion.micro_motion.micro_motion_engine import MicroMotionEngine
from roboforge.motion.optimisation.trajectory_optimizer import compute_trajectory_metrics
from roboforge.motion.planner.planner import MotionPlanner
from roboforge.motion.trajectory.joint_trajectory import JointTrajectory, JointTrajectoryPoint, generate_joint_trajectory
from roboforge.perception.cameras.camera import CameraExtrinsics, CameraIntrinsics, MountingKind
from roboforge.perception.cameras.simulated_camera import SimulatedCamera, SimulatedSceneObject
from roboforge.perception.pose.pose_estimator import PoseEstimator
from roboforge.perception.vision.object_detector import SimulatedObjectDetector
from roboforge.robotics.tool import Tool, ToolCentrePoint, ToolKind
from roboforge.simulation.physics_engine import PegHoleContactModel
from roboforge.simulation.simulated_robot import SimulatedRobot
from roboforge.state_estimation.state_estimator import RobotStateEstimator
from roboforge.telemetry.telemetry_recorder import TelemetryRecorder


@dataclass
class StageReport:
    name: str
    duration_s: float
    trajectory_summary: dict = field(default_factory=dict)
    extra: dict = field(default_factory=dict)


@dataclass
class DemoReport:
    stages: list[StageReport] = field(default_factory=list)
    total_cycle_time_s: float = 0.0
    total_energy_estimate_j: float = 0.0
    min_collision_clearance_m: float = float("inf")
    final_position_error_m: float = 0.0
    grasp_verified: bool = False
    insertion_verified: bool = False


def _print_header(title: str) -> None:
    print("\n" + "=" * 72)
    print(title)
    print("=" * 72)


def _print_robot_status(robot, collision_engine: CollisionEngine, tool: Tool | None) -> None:
    pose = robot.forward_kinematics()
    x, y, z, r, p, yaw = pose.as_xyzrpy()
    clearance = collision_engine.check(robot.joint_state.position).min_clearance
    print(f"  joint_positions      : {np.round(robot.joint_state.position, 4).tolist()}")
    print(f"  tcp_position          : ({x:.4f}, {y:.4f}, {z:.4f})")
    print(f"  tcp_orientation_rpy   : ({r:.4f}, {p:.4f}, {yaw:.4f})")
    print(f"  collision_clearance_m : {clearance:.4f}")
    if tool is not None:
        print(f"  gripper_state         : jaw={tool.jaw_position_m:.4f}m gripping={tool.is_gripping}")


class PrecisionManipulationDemo:
    def __init__(self, seed: int = 7) -> None:
        self.rng = np.random.default_rng(seed)
        self.report = DemoReport()

        # -- robot cell setup --------------------------------------------
        self.robot = load_and_build_robot(DEFAULT_CONFIG)
        self.robot.joint_state.position = self.robot.home_position().copy()
        self.tool = Tool(name="precision_gripper", kind=ToolKind.PARALLEL_GRIPPER, tcp=ToolCentrePoint())
        self.robot.attach_tool(self.tool)
        self.gripper = GripperController(self.tool)

        self.world = CollisionWorld()
        # A representative fixture/machine obstacle in the cell -- the
        # collision engine must route around it, not just avoid the
        # component and assembly point themselves.
        self.world.add(
            CollisionObject(
                "safety_fence", ObjectKind.FIXTURE, "box",
                pose=Pose(np.array([-1.0, -1.0, 0.5]), np.eye(3)),
                half_extents=np.array([0.05, 0.6, 0.5]),
            )
        )
        self.collision_engine = CollisionEngine(self.robot, self.world)
        self.event_bus = EventBus()
        self.telemetry = TelemetryRecorder()
        self.state_estimator = RobotStateEstimator(self.robot)
        self.planner = MotionPlanner(self.robot)
        self.micro_motion = MicroMotionEngine(self.robot)
        self.sim_robot = SimulatedRobot(self.robot, tracking_noise_std=2e-5, rng=self.rng)

        # -- perception setup ----------------------------------------------
        home_tcp = self.robot.forward_kinematics(self.robot.home_position())
        self.component_pose = Pose(
            home_tcp.position + np.array([0.04, 0.03, -0.02]), home_tcp.rotation, frame="world"
        )
        self.fixture_pose = Pose(
            home_tcp.position + np.array([0.06, -0.05, -0.04]), home_tcp.rotation, frame="world"
        )

        intrinsics = CameraIntrinsics(fx=900, fy=900, cx=320, cy=240, width=640, height=480)
        camera_pose = Pose(
            self.component_pose.position + np.array([0.0, 0.0, 0.4]),
            euler_to_rotation_matrix([np.pi, 0.0, 0.0]),
        )
        self.camera = SimulatedCamera(
            "overhead_cam", intrinsics, CameraExtrinsics(pose=camera_pose, mounting=MountingKind.EYE_TO_HAND),
            max_range_m=1.0,
        )
        self.camera.add_object(SimulatedSceneObject("component_42", "precision_component", self.component_pose, size_m=0.03))
        self.detector = SimulatedObjectDetector(position_noise_std_m=3e-4, orientation_noise_std_rad=1e-3, rng=self.rng)
        self.pose_estimator = PoseEstimator(self.camera, self.detector)

    # -- helpers -----------------------------------------------------------
    def _execute_move(self, name: str, target_pose: Pose, objective: PlannerObjective = PlannerObjective.MINIMUM_TIME) -> StageReport:
        t0 = time.perf_counter()
        result = self.planner.optimize(
            self.robot.joint_state.position, target_pose, objective=objective,
            collision_checker=self.collision_engine.as_checker(),
        )
        exec_result = self.sim_robot.execute_trajectory(
            result.trajectory, event_bus=self.event_bus, telemetry=self.telemetry, state_estimator=self.state_estimator
        )
        duration = time.perf_counter() - t0
        metrics = compute_trajectory_metrics(self.robot, result.trajectory)
        self.report.total_energy_estimate_j += metrics.energy_estimate_j

        stage = StageReport(
            name=name,
            duration_s=duration,
            trajectory_summary={
                "candidate": result.chosen_candidate,
                "n_points": len(result.trajectory.points),
                "duration_s": result.trajectory.duration,
            },
            extra={
                "peak_velocity": metrics.peak_velocity,
                "peak_acceleration": metrics.peak_acceleration,
                "peak_jerk": metrics.peak_jerk,
                "energy_estimate_j": metrics.energy_estimate_j,
                "tracking_error_m": exec_result.max_tracking_error_m,
            },
        )
        self.report.stages.append(stage)
        clearance = self.collision_engine.check(self.robot.joint_state.position).min_clearance
        self.report.min_collision_clearance_m = min(self.report.min_collision_clearance_m, clearance)

        print(f"\n[MOVE] {name}")
        print(f"  candidate strategy    : {result.chosen_candidate}")
        print(f"  trajectory duration_s : {result.trajectory.duration:.4f}  points={len(result.trajectory.points)}")
        print(f"  peak velocity/accel/jerk : {metrics.peak_velocity:.4f} / {metrics.peak_acceleration:.4f} / {metrics.peak_jerk:.2f}")
        print(f"  energy_estimate_j     : {metrics.energy_estimate_j:.4f}")
        _print_robot_status(self.robot, self.collision_engine, self.tool)
        return stage

    def _execute_linear_approach(self, name: str, target_pose: Pose, approach_distance: float, approach_speed: float) -> StageReport:
        t0 = time.perf_counter()
        cart_trajectory = self.micro_motion.approach(target_pose, approach_distance, approach_speed)
        q = self.robot.joint_state.position
        points: list[JointTrajectoryPoint] = []
        for cp in cart_trajectory.points:
            ik = self.robot.inverse_kinematics(cp.pose, initial_guess=q, method=IKMethod.DAMPED_LEAST_SQUARES)
            q = ik.joint_positions
            points.append(JointTrajectoryPoint(t=cp.t, position=q.copy(), velocity=np.zeros(self.robot.dof), acceleration=np.zeros(self.robot.dof)))
        joint_trajectory = JointTrajectory(joint_names=self.robot.joint_names, points=points)

        exec_result = self.sim_robot.execute_trajectory(
            joint_trajectory, event_bus=self.event_bus, telemetry=self.telemetry, state_estimator=self.state_estimator
        )
        duration = time.perf_counter() - t0
        metrics = compute_trajectory_metrics(self.robot, joint_trajectory)
        self.report.total_energy_estimate_j += metrics.energy_estimate_j

        stage = StageReport(
            name=name, duration_s=duration,
            trajectory_summary={"n_points": len(joint_trajectory.points), "duration_s": joint_trajectory.duration},
            extra={"tracking_error_m": exec_result.max_tracking_error_m},
        )
        self.report.stages.append(stage)
        print(f"\n[APPROACH] {name}")
        print(f"  standoff_distance_m={approach_distance:.4f}  approach_speed_m_s={approach_speed:.4f}")
        _print_robot_status(self.robot, self.collision_engine, self.tool)
        return stage

    # -- pipeline stages -----------------------------------------------------
    def run(self) -> DemoReport:
        cycle_start = time.perf_counter()

        _print_header("STAGE 0: CONNECT / ENABLE")
        self.event_bus.publish(RobotConnected(robot_id=self.robot.robot_id, driver_name="SimulationDriver"))
        self.event_bus.publish(RobotEnabled(robot_id=self.robot.robot_id))
        _print_robot_status(self.robot, self.collision_engine, self.tool)

        _print_header("STAGE 1: SENSE + LOCALISE (camera -> detection -> 6D pose)")
        detected = self.pose_estimator.detect_pose("component_42", self.robot.forward_kinematics())
        assert detected is not None, "demo scene misconfigured: component not visible to camera"
        self.event_bus.publish(ObjectDetected(robot_id=self.robot.robot_id, object_id=detected.object_id,
                                               class_label=detected.class_label, confidence=detected.confidence))
        px, py, pz, pr, pp, pyaw = detected.pose_world.as_xyzrpy()
        print(f"  object_id   : {detected.object_id}")
        print(f"  object_pose : xyz=({px:.4f},{py:.4f},{pz:.4f}) rpy=({pr:.4f},{pp:.4f},{pyaw:.4f})")
        print(f"  confidence  : {detected.confidence:.3f}")

        _print_header("STAGE 2: GRASP SELECTION")
        graspable = GraspableObject("component_42", ObjectShape.BOX, detected.pose_world, np.array([0.025, 0.025, 0.02]), mass_kg=0.15)
        grasp_planner = GraspPlanner(self.robot, self.tool)
        grasp = grasp_planner.select_best(graspable, collision_checker=self.collision_engine.as_checker())
        print(f"  selected_grasp : label={grasp.label} quality={grasp.quality_score:.3f} "
              f"stability={grasp.stability_score:.3f} reachability={grasp.reachability_score:.3f} "
              f"collision_risk={grasp.collision_risk:.3f}")
        print(f"  gripper_width_m: {grasp.gripper_width_m:.4f}")

        _print_header("STAGE 3: PLAN + MOVE (collision-free approach to grasp standoff)")
        standoff_distance = 0.06
        standoff = Pose(grasp.grasp_pose.position - standoff_distance * grasp.approach_axis, grasp.grasp_pose.rotation)
        self._execute_move("approach_standoff", standoff, objective=PlannerObjective.MAXIMUM_CLEARANCE)
        self._execute_linear_approach(
            "final_approach_to_grasp", grasp.grasp_pose, approach_distance=standoff_distance, approach_speed=0.01
        )

        _print_header("STAGE 4: CLOSE GRIPPER + VERIFY GRASP")
        result = self.gripper.close(object_width_m=0.02, grip_force_n=18.0)
        self.report.grasp_verified = self.gripper.is_object_grasped()
        self.event_bus.publish(GraspDetected(robot_id=self.robot.robot_id, object_id="component_42", confidence=1.0 if self.report.grasp_verified else 0.0))
        if self.report.grasp_verified:
            self.event_bus.publish(ObjectPicked(robot_id=self.robot.robot_id, object_id="component_42"))
        print(f"  gripper_state : jaw={result.jaw_position_m:.4f}m  is_gripping={result.is_gripping}")
        print(f"  grasp_verified: {self.report.grasp_verified}")

        _print_header("STAGE 5: MOVE TO ASSEMBLY FIXTURE")
        fixture_standoff = Pose(self.fixture_pose.position - 0.06 * grasp.approach_axis, self.fixture_pose.rotation)
        self._execute_move("move_to_fixture_standoff", fixture_standoff, objective=PlannerObjective.MINIMUM_JERK)

        _print_header("STAGE 6: QUICK REPEATABILITY CHECK (informs alignment tolerance)")
        calib_engine = RobotCalibrationEngine(self.robot)
        self.event_bus.publish(CalibrationStarted(robot_id=self.robot.robot_id, calibration_type="repeatability"))
        current_pose = self.robot.forward_kinematics()
        measured = [
            Pose(current_pose.position + self.rng.normal(0, 4e-5, size=3), current_pose.rotation)
            for _ in range(8)
        ]
        calib_report = calib_engine.measure_repeatability_and_accuracy(current_pose, measured)
        self.event_bus.publish(CalibrationCompleted(robot_id=self.robot.robot_id, calibration_type="repeatability", success=True))
        print(f"  repeatability_m      : {calib_report.repeatability_m:.6f}")
        print(f"  absolute_accuracy_m  : {calib_report.absolute_accuracy_m:.6f}")

        _print_header("STAGE 7: PRECISION ALIGNMENT (micro-motion spiral search)")
        # Deliberately approach slightly off-centre from the true hole
        # location to exercise the alignment-search machinery.
        true_hole_pose = self.fixture_pose
        offset = np.array([0.0009, -0.0006, 0.0])
        nominal_target = Pose(true_hole_pose.position + offset, true_hole_pose.rotation)

        def contact_checker(pose: Pose) -> bool:
            return float(np.linalg.norm(pose.position[:2] - true_hole_pose.position[:2])) < 0.0003

        search_result = self.micro_motion.search(
            "spiral", radius=0.0025, step=0.0003, centre_pose=nominal_target, contact_checker=contact_checker
        )
        print(f"  search_pattern   : {search_result.pattern}  found={search_result.found}  iterations={search_result.iterations}")
        aligned_pose = search_result.pose if search_result.found else true_hole_pose
        align_result = self.micro_motion.fine_align(aligned_pose, tolerance_position=2e-4, tolerance_orientation=2e-3)
        self.robot.joint_state.position = align_result.joint_positions
        self.report.final_position_error_m = align_result.position_error
        print(f"  fine_align success: {align_result.success}  position_error_m={align_result.position_error:.6f}  "
              f"orientation_error_rad={align_result.orientation_error:.6f}")
        _print_robot_status(self.robot, self.collision_engine, self.tool)

        _print_header("STAGE 8: FORCE-GUIDED INSERTION")
        contact_model = PegHoleContactModel(true_hole_pose, np.array([0.0, 0.0, 1.0]), hole_depth_m=0.008)
        insertion_controller = InsertionController(self.robot)
        insertion_result = insertion_controller.insert(
            aligned_pose, np.array([0.0, 0.0, 1.0]), insertion_depth_m=0.008,
            force_sensor_fn=contact_model.compute_force, target_insertion_force_n=8.0, max_force_n=35.0,
        )
        print(f"  insertion_success : {insertion_result.success}")
        print(f"  depth_reached_m   : {insertion_result.depth_reached_m:.6f}")
        print(f"  peak_force_n      : {insertion_result.peak_force_n:.4f}")

        _print_header("STAGE 9: VERIFY INSERTION")
        self.report.insertion_verified = insertion_result.success and insertion_result.depth_reached_m >= 0.0075
        print(f"  insertion_verified: {self.report.insertion_verified}")

        _print_header("STAGE 10: RELEASE COMPONENT")
        release_result = self.gripper.open()
        self.event_bus.publish(ObjectPlaced(robot_id=self.robot.robot_id, object_id="component_42"))
        print(f"  gripper_state: jaw={release_result.jaw_position_m:.4f}m  is_gripping={release_result.is_gripping}")

        _print_header("STAGE 11: RETURN TO HOME")
        home_pose = self.robot.forward_kinematics(self.robot.home_position())
        self._execute_move("return_home", home_pose, objective=PlannerObjective.MINIMUM_TIME)

        self.report.total_cycle_time_s = time.perf_counter() - cycle_start
        self._print_summary()
        return self.report

    def _print_summary(self) -> None:
        _print_header("DEMONSTRATION SUMMARY")
        print(f"  cycle_time_s              : {self.report.total_cycle_time_s:.4f}")
        print(f"  total_energy_estimate_j   : {self.report.total_energy_estimate_j:.4f}")
        print(f"  min_collision_clearance_m : {self.report.min_collision_clearance_m:.4f}")
        print(f"  final_position_error_m    : {self.report.final_position_error_m:.6f}")
        print(f"  grasp_verified            : {self.report.grasp_verified}")
        print(f"  insertion_verified        : {self.report.insertion_verified}")
        print(f"  trajectory_segments_executed : {len(self.report.stages)}")
        print(f"  telemetry_samples_recorded: {len(self.telemetry.recent(self.robot.robot_id, n=100000))}")
        print(f"  events_published          : {len(self.event_bus.history(limit=100000))}")


def run_demo(seed: int = 7) -> DemoReport:
    demo = PrecisionManipulationDemo(seed=seed)
    return demo.run()


if __name__ == "__main__":
    run_demo()
