"""The precision-manipulation demonstration (section 44)."""
