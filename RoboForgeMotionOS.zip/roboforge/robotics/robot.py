"""The ``Robot`` aggregate: the central object of RoboForge Motion.OS.

As described in the platform architecture, a robot is represented as:

    Robot
     |-- Kinematic Model   (joints + links, DH chain)
     |-- Dynamic Model     (per-link inertial properties)
     |-- Joint State       (roboforge.robotics.state)
     |-- Tool Centre Point (tool.tcp)
     |-- End Effector      (tool)
     |-- Sensors           (roboforge.sensors)
     |-- Workspace         (WorkspaceEnvelope)
     |-- Motion Constraints
     |-- Calibration       (CalibrationProfile)
     |-- Controller        (attached at runtime)
     `-- Safety State      (roboforge.safety)

The class itself stays free of I/O: it is a pure data + math model that
simulation, drivers, planners, and the API layer all operate on
identically, which is what lets the same command work against a
``SimulationRobot`` or a ``HardwareRobot`` (section 26).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from roboforge.core.enums import MotionState, RobotKinematicFamily, SafetyLevel
from roboforge.core.transforms import Pose
from roboforge.robotics.joint import Joint
from roboforge.robotics.link import InertialProperties, Link
from roboforge.robotics.state.joint_state import JointState
from roboforge.robotics.tool import Tool


@dataclass
class WorkspaceEnvelope:
    """The robot's configured reachable/permitted workspace, used by IK,
    planning, and safety to reject out-of-bounds targets early."""

    min_corner: np.ndarray = field(default_factory=lambda: np.array([-2.0, -2.0, 0.0]))
    max_corner: np.ndarray = field(default_factory=lambda: np.array([2.0, 2.0, 2.5]))
    max_reach_m: float = 1.5

    def __post_init__(self) -> None:
        self.min_corner = np.asarray(self.min_corner, dtype=float)
        self.max_corner = np.asarray(self.max_corner, dtype=float)

    def contains(self, position: np.ndarray) -> bool:
        position = np.asarray(position, dtype=float)
        within_box = bool(np.all(position >= self.min_corner) and np.all(position <= self.max_corner))
        within_reach = float(np.linalg.norm(position)) <= self.max_reach_m + 1e-6
        return within_box and within_reach


@dataclass
class MotionConstraints:
    """Global motion scaling applied on top of per-joint limits."""

    velocity_scale: float = 1.0
    acceleration_scale: float = 1.0
    jerk_scale: float = 1.0

    def clamp_scale(self) -> None:
        self.velocity_scale = float(np.clip(self.velocity_scale, 0.01, 1.0))
        self.acceleration_scale = float(np.clip(self.acceleration_scale, 0.01, 1.0))
        self.jerk_scale = float(np.clip(self.jerk_scale, 0.01, 1.0))


@dataclass
class CalibrationProfile:
    """The active calibration corrections applied to this robot.

    Populated by ``roboforge.calibration``; stored here so kinematics and
    drivers can apply corrections transparently.
    """

    joint_zero_offsets: np.ndarray | None = None
    tcp_offset: Pose | None = None
    base_offset: Pose = field(default_factory=Pose.identity)
    calibrated: bool = False
    repeatability_m: Optional[float] = None
    absolute_accuracy_m: Optional[float] = None


@dataclass
class Robot:
    """A manipulator: arbitrary-DOF serial chain described by DH joints."""

    robot_id: str
    name: str
    dof: int
    joints: list[Joint]
    links: list[Link]
    kinematic_family: RobotKinematicFamily = RobotKinematicFamily.ARTICULATED
    base_pose: Pose = field(default_factory=Pose.identity)
    workspace: WorkspaceEnvelope = field(default_factory=WorkspaceEnvelope)
    motion_constraints: MotionConstraints = field(default_factory=MotionConstraints)
    calibration: CalibrationProfile = field(default_factory=CalibrationProfile)
    tool: Optional[Tool] = None
    payload: Optional[InertialProperties] = None
    joint_state: JointState = field(init=False)
    motion_state: MotionState = MotionState.DISCONNECTED
    safety_level: SafetyLevel = SafetyLevel.NORMAL

    def __post_init__(self) -> None:
        if len(self.joints) != self.dof:
            raise ValueError(
                f"Robot {self.name!r} declares dof={self.dof} but has {len(self.joints)} joints"
            )
        self.joint_state = JointState.zeros(self.dof, names=[j.name for j in self.joints])
        if self.calibration.joint_zero_offsets is None:
            self.calibration.joint_zero_offsets = np.zeros(self.dof)

    # -- convenience -------------------------------------------------
    @property
    def joint_names(self) -> list[str]:
        return [j.name for j in self.joints]

    def home_position(self) -> np.ndarray:
        return np.array([j.home_position for j in self.joints])

    def attach_tool(self, tool: Tool) -> None:
        self.tool = tool

    def detach_tool(self) -> None:
        self.tool = None

    def set_payload(self, mass_kg: float, centre_of_mass: np.ndarray | None = None) -> None:
        self.payload = InertialProperties(
            mass=mass_kg,
            centre_of_mass=np.asarray(centre_of_mass if centre_of_mass is not None else [0, 0, 0], dtype=float),
        )

    def clamp_joint_positions(self, q: np.ndarray) -> np.ndarray:
        q = np.asarray(q, dtype=float)
        return np.array([j.limits.clamp_position(v) for j, v in zip(self.joints, q)])

    def validate_joint_positions(self, q: np.ndarray) -> None:
        q = np.asarray(q, dtype=float)
        for j, v in zip(self.joints, q):
            j.limits.validate_position(v, j.name)

    def validate_joint_velocities(self, qd: np.ndarray) -> None:
        qd = np.asarray(qd, dtype=float)
        scale = self.motion_constraints.velocity_scale
        for j, v in zip(self.joints, qd):
            j.limits.validate_velocity(v / max(scale, 1e-6), j.name)

    # -- kinematics facade (delegates to roboforge.robotics.kinematics) ---
    def forward_kinematics(self, q: np.ndarray | None = None) -> Pose:
        from roboforge.robotics.kinematics.forward import forward_kinematics

        q = self.joint_state.position if q is None else np.asarray(q, dtype=float)
        return forward_kinematics(self, q)

    def jacobian(self, q: np.ndarray | None = None, analytic: bool = False) -> np.ndarray:
        from roboforge.robotics.kinematics.jacobian import geometric_jacobian, analytic_jacobian

        q = self.joint_state.position if q is None else np.asarray(q, dtype=float)
        return analytic_jacobian(self, q) if analytic else geometric_jacobian(self, q)

    def inverse_kinematics(self, target_pose: Pose, initial_guess: np.ndarray | None = None, **kwargs):
        from roboforge.robotics.kinematics.inverse import inverse_kinematics

        q0 = self.joint_state.position if initial_guess is None else np.asarray(initial_guess, dtype=float)
        return inverse_kinematics(self, target_pose, q0, **kwargs)

    def manipulability(self, q: np.ndarray | None = None) -> float:
        from roboforge.robotics.kinematics.singularity import manipulability_index

        q = self.joint_state.position if q is None else np.asarray(q, dtype=float)
        return manipulability_index(self, q)

    def inverse_dynamics(self, q: np.ndarray, qd: np.ndarray, qdd: np.ndarray) -> np.ndarray:
        from roboforge.robotics.dynamics.newton_euler import recursive_newton_euler

        return recursive_newton_euler(self, q, qd, qdd)

    def gravity_torque(self, q: np.ndarray | None = None) -> np.ndarray:
        q = self.joint_state.position if q is None else np.asarray(q, dtype=float)
        zeros = np.zeros(self.dof)
        return self.inverse_dynamics(q, zeros, zeros)

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        return f"Robot(id={self.robot_id!r}, name={self.name!r}, dof={self.dof}, state={self.motion_state.value})"
