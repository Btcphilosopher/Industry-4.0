"""End-effector / tool representation.

Section 11 treats the end effector as a first-class robotics object. A
``Tool`` carries its own kinematic offset (tool0 -> TCP), payload
inertial properties, and geometry, and is attached/detached from a
``Robot`` at runtime (e.g. tool-changer workflows).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

import numpy as np

from roboforge.core.transforms import Pose
from roboforge.robotics.link import InertialProperties, LinkGeometry


class ToolKind(str, Enum):
    PARALLEL_GRIPPER = "parallel_gripper"
    VACUUM_GRIPPER = "vacuum_gripper"
    MAGNETIC_GRIPPER = "magnetic_gripper"
    ADAPTIVE_GRIPPER = "adaptive_gripper"
    ROBOTIC_FINGERS = "robotic_fingers"
    WELDING_TORCH = "welding_torch"
    DRILL = "drill"
    SCREWDRIVER = "screwdriver"
    DISPENSING_HEAD = "dispensing_head"
    INSPECTION_PROBE = "inspection_probe"
    CUSTOM = "custom"


@dataclass
class ToolCentrePoint:
    """The Tool Centre Point (TCP): the pose, expressed relative to the
    robot's flange (tool0), that all Cartesian commands and IK targets
    refer to."""

    offset: Pose = field(default_factory=Pose.identity)
    name: str = "tcp"


@dataclass
class Tool:
    """A physical end effector attached to a robot's flange."""

    name: str
    kind: ToolKind
    tcp: ToolCentrePoint = field(default_factory=ToolCentrePoint)
    inertial: InertialProperties = field(default_factory=InertialProperties)
    geometry: LinkGeometry = field(
        default_factory=lambda: LinkGeometry(
            shape="capsule",
            point_a=np.array([0.0, 0.0, 0.01]),
            point_b=np.array([0.0, 0.0, 0.06]),
            radius=0.03,
        )
    )
    max_payload_kg: float = 5.0
    jaw_min_m: float = 0.0
    jaw_max_m: float = 0.085
    jaw_position_m: float = 0.085
    is_gripping: bool = False
    grip_force_n: float = 0.0

    def payload_ok(self, payload_kg: float) -> bool:
        return payload_kg <= self.max_payload_kg + 1e-9

    def combined_inertial(self, payload: InertialProperties | None) -> InertialProperties:
        """Combine tool + carried-payload inertial properties (simple mass
        superposition about the tool's own centre of mass; adequate for
        dynamics feed-forward at the fidelity this platform targets)."""
        if payload is None:
            return self.inertial
        total_mass = self.inertial.mass + payload.mass
        if total_mass <= 0:
            return self.inertial
        com = (
            self.inertial.mass * self.inertial.centre_of_mass
            + payload.mass * payload.centre_of_mass
        ) / total_mass
        return InertialProperties(
            mass=total_mass,
            centre_of_mass=com,
            inertia_tensor=self.inertial.inertia_tensor + payload.inertia_tensor,
        )
