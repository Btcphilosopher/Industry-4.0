"""Higher-level dynamics API built on recursive Newton-Euler: the
mass/inertia matrix, Coriolis/centrifugal matrix action, gravity vector,
and forward dynamics (for simulation integration).

The architecture deliberately keeps this as a thin composition layer over
``recursive_newton_euler`` (section 6: "the architecture should allow more
sophisticated dynamics solvers to be added later") -- a future composite
rigid-body-algorithm or spatial-vector implementation can be dropped in
behind the same ``DynamicsModel`` interface.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np

from roboforge.core.enums import JointType
from roboforge.robotics.dynamics.newton_euler import recursive_newton_euler, DEFAULT_GRAVITY
from roboforge.robotics.kinematics.forward import forward_kinematics_all_frames

if TYPE_CHECKING:
    from roboforge.robotics.robot import Robot


def _link_com_jacobians(robot: "Robot", q: np.ndarray) -> list[tuple[np.ndarray, np.ndarray]]:
    """For every link, the (3xN, 3xN) linear/angular velocity Jacobians of
    its centre of mass -- only columns for joints 0..i (proximal to link
    i in the serial chain) are nonzero, since a serial manipulator's link
    i velocity cannot depend on more distal joints.
    """
    q = np.asarray(q, dtype=float)
    n = robot.dof
    base_frame = robot.base_pose.as_matrix() @ robot.calibration.base_offset.as_matrix()
    joint_frames = forward_kinematics_all_frames(robot, q)
    all_frames = [base_frame] + joint_frames

    jacobians = []
    for i, link in enumerate(robot.links):
        T_i = all_frames[i + 1]
        com_world = T_i[:3, :3] @ link.inertial.centre_of_mass + T_i[:3, 3]

        Jv = np.zeros((3, n))
        Jw = np.zeros((3, n))
        for j in range(i + 1):
            T_prev = all_frames[j]
            z_prev = T_prev[:3, 2]
            p_prev = T_prev[:3, 3]
            joint = robot.joints[j]
            if joint.joint_type == JointType.REVOLUTE:
                Jv[:, j] = np.cross(z_prev, com_world - p_prev)
                Jw[:, j] = z_prev
            elif joint.joint_type == JointType.PRISMATIC:
                Jv[:, j] = z_prev
        jacobians.append((Jv, Jw))
    return jacobians


@dataclass
class DynamicsModel:
    """Computes the standard manipulator dynamics decomposition:

        tau = M(q) qdd + C(q, qd) qd + G(q) + F(qd)

    using finite-difference "unit response" calls into the recursive
    Newton-Euler engine.
    """

    robot: "Robot"
    gravity: np.ndarray = None  # type: ignore[assignment]
    viscous_friction: np.ndarray | None = None

    def __post_init__(self) -> None:
        if self.gravity is None:
            self.gravity = DEFAULT_GRAVITY.copy()
        if self.viscous_friction is None:
            self.viscous_friction = np.zeros(self.robot.dof)

    def gravity_vector(self, q: np.ndarray) -> np.ndarray:
        n = self.robot.dof
        return recursive_newton_euler(self.robot, q, np.zeros(n), np.zeros(n), gravity=self.gravity)

    def mass_matrix(self, q: np.ndarray) -> np.ndarray:
        """Compute M(q) via the kinetic-energy (Jacobian) formulation:

            M(q) = sum_i [ m_i * Jv_ci(q)^T Jv_ci(q) + Jw_i(q)^T I_i(q) Jw_i(q) ]

        This is symmetric and positive (semi-)definite *by construction*
        (each term is a Gram-matrix-like quadratic form), which the
        "unit joint-acceleration response via RNE" approach used
        elsewhere in this module is not guaranteed to be exactly unless
        the RNE implementation is energy-consistent to machine precision
        -- using the Jacobian formulation here avoids relying on that.
        """
        n = self.robot.dof
        M = np.zeros((n, n))
        base_frame = self.robot.base_pose.as_matrix() @ self.robot.calibration.base_offset.as_matrix()
        joint_frames = forward_kinematics_all_frames(self.robot, q)
        all_frames = [base_frame] + joint_frames

        for i, (Jv, Jw) in enumerate(_link_com_jacobians(self.robot, q)):
            link = self.robot.links[i]
            R_i = all_frames[i + 1][:3, :3]
            I_world = R_i @ link.inertial.inertia_tensor @ R_i.T
            M += link.inertial.mass * (Jv.T @ Jv) + Jw.T @ I_world @ Jw

        if self.robot.payload is not None:
            # Payload rigidly carried at the flange: treat it as an
            # additional point-ish mass whose Jacobian equals the last
            # link's Jacobian evaluated at the payload's own offset.
            T_tip = all_frames[-1]
            com_world = T_tip[:3, :3] @ self.robot.payload.centre_of_mass + T_tip[:3, 3]
            Jv = np.zeros((3, n))
            Jw = np.zeros((3, n))
            for j in range(n):
                T_prev = all_frames[j]
                z_prev = T_prev[:3, 2]
                p_prev = T_prev[:3, 3]
                if self.robot.joints[j].joint_type == JointType.REVOLUTE:
                    Jv[:, j] = np.cross(z_prev, com_world - p_prev)
                    Jw[:, j] = z_prev
                elif self.robot.joints[j].joint_type == JointType.PRISMATIC:
                    Jv[:, j] = z_prev
            I_world = T_tip[:3, :3] @ self.robot.payload.inertia_tensor @ T_tip[:3, :3].T
            M += self.robot.payload.mass * (Jv.T @ Jv) + Jw.T @ I_world @ Jw

        return M

    def coriolis_forces(self, q: np.ndarray, qd: np.ndarray) -> np.ndarray:
        """C(q, qd) qd, obtained as tau(qdd=0, qd, g=0) (gravity- and
        acceleration-independent term)."""
        n = self.robot.dof
        zero_g = np.zeros(3)
        return recursive_newton_euler(self.robot, q, qd, np.zeros(n), gravity=zero_g)

    def inverse_dynamics(self, q: np.ndarray, qd: np.ndarray, qdd: np.ndarray) -> np.ndarray:
        tau = recursive_newton_euler(self.robot, q, qd, qdd, gravity=self.gravity)
        return tau + self.viscous_friction * qd

    def forward_dynamics(self, q: np.ndarray, qd: np.ndarray, tau: np.ndarray) -> np.ndarray:
        """Solve for joint accelerations given applied torques:
        qdd = M(q)^-1 (tau - C(q,qd)qd - G(q) - friction(qd))

        Used by the simulation engine to integrate robot motion forward
        in time under commanded/estimated joint torques.
        """
        M = self.mass_matrix(q)
        C_qd = self.coriolis_forces(q, qd)
        G = self.gravity_vector(q)
        friction = self.viscous_friction * qd
        rhs = np.asarray(tau, dtype=float) - C_qd - G - friction
        try:
            qdd = np.linalg.solve(M, rhs)
        except np.linalg.LinAlgError:
            qdd = np.linalg.lstsq(M, rhs, rcond=None)[0]
        return qdd
