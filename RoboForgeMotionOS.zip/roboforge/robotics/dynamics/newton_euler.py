"""Recursive Newton-Euler inverse dynamics (section 6).

Implements the classic two-pass recursive Newton-Euler algorithm:
an outward kinematic pass (link angular/linear velocities and
accelerations) followed by an inward pass (link forces/torques,
reduced to joint torques by projecting onto each joint's axis).

For clarity and to keep the implementation generic across arbitrary
DH chains (rather than hand-deriving body-frame transforms per link),
all vector quantities (velocities, accelerations, forces, torques) are
expressed consistently in the *world* frame at each instant. This is
mathematically equivalent to the traditional body-frame recursion --
the underlying rigid-body kinematics/dynamics equations are vector
equations that hold in any single consistent frame -- at some cost in
computational efficiency versus a body-frame formulation with
precomputed constant local inertia tensors, which is an acceptable
trade for a Python planning-layer dynamics engine (section 29: hard
real-time servo loops live in the controller, not here).

Gravity is incorporated via the standard D'Alembert trick: the (fixed)
base is treated as if accelerating upward at ``-gravity``, which is
kinematically equivalent to every link in the chain experiencing
gravitational acceleration downward.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from roboforge.core.enums import JointType
from roboforge.robotics.kinematics.forward import forward_kinematics_all_frames

if TYPE_CHECKING:
    from roboforge.robotics.robot import Robot

DEFAULT_GRAVITY = np.array([0.0, 0.0, -9.80665])


def recursive_newton_euler(
    robot: "Robot",
    q: np.ndarray,
    qd: np.ndarray,
    qdd: np.ndarray,
    gravity: np.ndarray = DEFAULT_GRAVITY,
    external_tip_force: np.ndarray | None = None,
    external_tip_torque: np.ndarray | None = None,
) -> np.ndarray:
    """Compute the joint torques/forces required to produce accelerations
    ``qdd`` given joint positions ``q`` and velocities ``qd``, including
    gravity and (optionally) an external wrench applied at the flange
    (e.g. from a carried payload or a force-controlled contact task).
    """
    q = np.asarray(q, dtype=float)
    qd = np.asarray(qd, dtype=float)
    qdd = np.asarray(qdd, dtype=float)
    n = robot.dof

    base_frame = robot.base_pose.as_matrix() @ robot.calibration.base_offset.as_matrix()
    joint_frames = forward_kinematics_all_frames(robot, q)
    all_frames = [base_frame] + joint_frames  # length n + 1

    # -- outward pass: velocities and accelerations ------------------
    omega = [np.zeros(3) for _ in range(n + 1)]
    alpha = [np.zeros(3) for _ in range(n + 1)]
    a_origin = [np.zeros(3) for _ in range(n + 1)]
    a_origin[0] = -np.asarray(gravity, dtype=float)  # D'Alembert gravity trick

    link_force = [np.zeros(3) for _ in range(n)]
    link_torque = [np.zeros(3) for _ in range(n)]
    link_com_world = [np.zeros(3) for _ in range(n)]

    for i in range(n):
        joint = robot.joints[i]
        z_prev = all_frames[i][:3, 2]
        p_prev = all_frames[i][:3, 3]
        p_cur = all_frames[i + 1][:3, 3]
        r = p_cur - p_prev

        omega_prev, alpha_prev, a_prev = omega[i], alpha[i], a_origin[i]

        if joint.joint_type == JointType.REVOLUTE:
            omega_cur = omega_prev + qd[i] * z_prev
            alpha_cur = alpha_prev + qdd[i] * z_prev + np.cross(omega_prev, qd[i] * z_prev)
            a_cur = a_prev + np.cross(alpha_cur, r) + np.cross(omega_cur, np.cross(omega_cur, r))
        elif joint.joint_type == JointType.PRISMATIC:
            omega_cur = omega_prev
            alpha_cur = alpha_prev
            a_cur = (
                a_prev
                + np.cross(alpha_cur, r)
                + np.cross(omega_cur, np.cross(omega_cur, r))
                + qdd[i] * z_prev
                + 2.0 * qd[i] * np.cross(omega_prev, z_prev)
            )
        else:  # FIXED
            omega_cur = omega_prev
            alpha_cur = alpha_prev
            a_cur = a_prev + np.cross(alpha_cur, r) + np.cross(omega_cur, np.cross(omega_cur, r))

        omega[i + 1], alpha[i + 1], a_origin[i + 1] = omega_cur, alpha_cur, a_cur

        # Link i (0-indexed, physically "link i+1") inertial properties.
        link = robot.links[i] if i < len(robot.links) else None
        if link is not None:
            R_i = all_frames[i + 1][:3, :3]
            com_world = R_i @ link.inertial.centre_of_mass
            p_ci = p_cur + com_world
            a_ci = (
                a_cur
                + np.cross(alpha_cur, com_world)
                + np.cross(omega_cur, np.cross(omega_cur, com_world))
            )
            mass = link.inertial.mass
            F_i = mass * a_ci
            I_world = R_i @ link.inertial.inertia_tensor @ R_i.T
            N_i = I_world @ alpha_cur + np.cross(omega_cur, I_world @ omega_cur)
        else:
            p_ci = p_cur
            F_i = np.zeros(3)
            N_i = np.zeros(3)

        link_force[i] = F_i
        link_torque[i] = N_i
        link_com_world[i] = p_ci

    # -- payload: rigidly attached at the flange -------------------------
    # Tracked separately (own force, own torque-about-its-own-COM, own COM
    # position) rather than folded into link_force[-1]/link_torque[-1],
    # so the backward pass can apply the *payload's* moment arm
    # (COM -> proximal joint origin) rather than double-applying the last
    # link's own r_ci -- folding it in early previously caused exactly
    # that mismatch (a spurious, non-physical torque contribution that
    # broke the mass matrix's required symmetry).
    payload_force = None
    payload_torque_about_com = None
    payload_com_world = None
    if robot.payload is not None:
        R_tip = all_frames[-1][:3, :3]
        com_world = R_tip @ robot.payload.centre_of_mass
        p_flange = all_frames[-1][:3, 3]
        payload_com_world = p_flange + com_world
        a_tip = a_origin[-1]
        alpha_tip = alpha[-1]
        omega_tip = omega[-1]
        a_pc = (
            a_tip
            + np.cross(alpha_tip, com_world)
            + np.cross(omega_tip, np.cross(omega_tip, com_world))
        )
        payload_force = robot.payload.mass * a_pc
        I_world = R_tip @ robot.payload.inertia_tensor @ R_tip.T
        payload_torque_about_com = I_world @ alpha_tip + np.cross(omega_tip, I_world @ omega_tip)

    # -- inward pass: forces/torques -> joint torques ---------------------
    f_next = np.zeros(3) if external_tip_force is None else np.asarray(external_tip_force, dtype=float)
    n_next = np.zeros(3) if external_tip_torque is None else np.asarray(external_tip_torque, dtype=float)

    tau = np.zeros(n)
    for i in range(n - 1, -1, -1):
        joint = robot.joints[i]
        z = all_frames[i][:3, 2]
        p_prev = all_frames[i][:3, 3]
        p_cur = all_frames[i + 1][:3, 3]
        r_next = p_cur - p_prev
        r_ci = link_com_world[i] - p_prev

        force_i = link_force[i]
        torque_i = link_torque[i]
        if i == n - 1 and payload_force is not None:
            # Fold the payload's own force/torque into this link's
            # contribution, using its own COM (relative to this joint's
            # origin) as the moment arm -- exactly analogous to r_ci for
            # a regular link.
            r_payload = payload_com_world - p_prev
            force_i = force_i + payload_force
            torque_i = torque_i + payload_torque_about_com + np.cross(r_payload, payload_force)

        f_i = f_next + force_i
        n_i = n_next + torque_i + np.cross(r_ci, link_force[i]) + np.cross(r_next, f_next)

        if joint.joint_type == JointType.REVOLUTE:
            tau[i] = float(n_i @ z)
        elif joint.joint_type == JointType.PRISMATIC:
            tau[i] = float(f_i @ z)
        else:
            tau[i] = 0.0

        f_next, n_next = f_i, n_i

    return tau
