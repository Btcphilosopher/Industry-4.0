"""Joint model.

A ``Joint`` fully describes one degree of freedom of a manipulator: its
kinematic role in the chain (a standard Denavit-Hartenberg row), its type
(revolute/prismatic/fixed), and the motion limits that every trajectory,
IK solve, and safety check must respect.
"""

from __future__ import annotations

from dataclasses import dataclass

from roboforge.core.enums import JointType
from roboforge.core.exceptions import JointLimitError


@dataclass
class JointLimits:
    """Physical/configured limits for a single joint.

    Positions/velocities are in SI units: radians (or metres for
    prismatic joints), rad/s (or m/s), rad/s^2 (or m/s^2), rad/s^3, and N*m
    (or N) for torque/force.
    """

    min_position: float
    max_position: float
    max_velocity: float
    max_acceleration: float
    max_jerk: float = 1000.0
    max_torque: float = 1000.0

    def clamp_position(self, value: float) -> float:
        return min(max(value, self.min_position), self.max_position)

    def within_position(self, value: float, tolerance: float = 1e-9) -> bool:
        return (self.min_position - tolerance) <= value <= (self.max_position + tolerance)

    def validate_position(self, value: float, joint_name: str = "") -> None:
        if not self.within_position(value):
            raise JointLimitError(
                f"Joint {joint_name!r} position {value:.6f} outside limits "
                f"[{self.min_position:.6f}, {self.max_position:.6f}]"
            )

    def validate_velocity(self, value: float, joint_name: str = "") -> None:
        if abs(value) > self.max_velocity + 1e-9:
            raise JointLimitError(
                f"Joint {joint_name!r} velocity {value:.6f} exceeds max {self.max_velocity:.6f}"
            )

    def validate_acceleration(self, value: float, joint_name: str = "") -> None:
        if abs(value) > self.max_acceleration + 1e-9:
            raise JointLimitError(
                f"Joint {joint_name!r} acceleration {value:.6f} exceeds max "
                f"{self.max_acceleration:.6f}"
            )

    def validate_torque(self, value: float, joint_name: str = "") -> None:
        if abs(value) > self.max_torque + 1e-9:
            raise JointLimitError(
                f"Joint {joint_name!r} torque {value:.6f} exceeds max {self.max_torque:.6f}"
            )

    @property
    def range(self) -> float:
        return self.max_position - self.min_position

    @property
    def midpoint(self) -> float:
        return 0.5 * (self.max_position + self.min_position)


@dataclass
class DHParameters:
    """One row of modified/standard Denavit-Hartenberg parameters.

    We use the standard DH convention:

        T_i = Rot_z(theta_i) * Trans_z(d_i) * Trans_x(a_i) * Rot_x(alpha_i)

    For a revolute joint, ``theta_offset`` is added to the joint variable
    ``q`` to form ``theta_i``. For a prismatic joint, ``d_offset`` is added
    to ``q`` to form ``d_i``.
    """

    a: float = 0.0
    alpha: float = 0.0
    d: float = 0.0
    theta_offset: float = 0.0
    d_offset: float = 0.0


@dataclass
class Joint:
    """A single robot joint: kinematic parameters + limits + type."""

    name: str
    joint_type: JointType
    dh: DHParameters
    limits: JointLimits
    axis: tuple[float, float, float] = (0.0, 0.0, 1.0)
    gear_ratio: float = 1.0
    home_position: float = 0.0

    def theta_for(self, q: float) -> float:
        """DH theta parameter for this joint variable (revolute joints only vary theta)."""
        if self.joint_type == JointType.REVOLUTE:
            return self.dh.theta_offset + q
        return self.dh.theta_offset

    def d_for(self, q: float) -> float:
        """DH d parameter for this joint variable (prismatic joints only vary d)."""
        if self.joint_type == JointType.PRISMATIC:
            return self.dh.d_offset + q
        return self.dh.d

    def is_actuated(self) -> bool:
        return self.joint_type != JointType.FIXED
