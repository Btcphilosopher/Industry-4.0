"""Link (rigid body) model.

Each ``Link`` represents the rigid body between two joints: its inertial
properties (mass, centre of mass, inertia tensor) are used by the dynamics
engine, and its geometry (a simple convex-primitive approximation) is used
by the collision engine. Precise mesh-based collision is out of scope for
this platform; capsule/box/sphere approximations are what real-time
industrial motion planners typically use for online checking anyway.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


@dataclass
class LinkGeometry:
    """A simple convex-primitive approximation of link geometry for
    collision checking, expressed in the link's own frame.

    ``shape`` is one of "capsule", "box", "sphere". A capsule is defined by
    two end points and a radius; a box by half-extents; a sphere by a
    centre and radius.
    """

    shape: str = "capsule"
    point_a: np.ndarray = field(default_factory=lambda: np.zeros(3))
    point_b: np.ndarray = field(default_factory=lambda: np.array([0.0, 0.0, 0.1]))
    radius: float = 0.05
    half_extents: np.ndarray = field(default_factory=lambda: np.array([0.05, 0.05, 0.05]))

    def __post_init__(self) -> None:
        self.point_a = np.asarray(self.point_a, dtype=float)
        self.point_b = np.asarray(self.point_b, dtype=float)
        self.half_extents = np.asarray(self.half_extents, dtype=float)


@dataclass
class InertialProperties:
    """Rigid-body inertial parameters used by the dynamics engine."""

    mass: float = 1.0
    centre_of_mass: np.ndarray = field(default_factory=lambda: np.zeros(3))
    inertia_tensor: np.ndarray = field(default_factory=lambda: np.eye(3) * 0.01)

    def __post_init__(self) -> None:
        self.centre_of_mass = np.asarray(self.centre_of_mass, dtype=float)
        self.inertia_tensor = np.asarray(self.inertia_tensor, dtype=float).reshape(3, 3)


@dataclass
class Link:
    """A rigid body between two joints in the kinematic chain."""

    name: str
    inertial: InertialProperties = field(default_factory=InertialProperties)
    geometry: LinkGeometry = field(default_factory=LinkGeometry)
