"""Aggregate robot state: joint state + Cartesian (TCP) state + machine
state + safety state, as consumed by telemetry, the API, and the digital
twin."""

from __future__ import annotations

import time
from dataclasses import dataclass, field

import numpy as np

from roboforge.core.enums import MotionState, SafetyLevel
from roboforge.core.transforms import Pose, Twist
from roboforge.robotics.state.joint_state import JointState


@dataclass
class RobotState:
    robot_id: str
    joint_state: JointState
    tcp_pose: Pose
    tcp_twist: Twist = field(default_factory=Twist)
    motion_state: MotionState = MotionState.DISCONNECTED
    safety_level: SafetyLevel = SafetyLevel.NORMAL
    external_force: np.ndarray = field(default_factory=lambda: np.zeros(3))
    external_torque: np.ndarray = field(default_factory=lambda: np.zeros(3))
    in_contact: bool = False
    gripper_state: str | None = None
    manipulability: float | None = None
    timestamp: float = field(default_factory=time.time)

    def as_dict(self) -> dict:
        return {
            "robot_id": self.robot_id,
            "joint_state": self.joint_state.as_dict(),
            "tcp_pose": {
                "position": self.tcp_pose.position.tolist(),
                "quaternion": self.tcp_pose.as_quaternion().tolist(),
                "rpy": [float(v) for v in self.tcp_pose.as_euler()],
            },
            "tcp_twist": {
                "linear": self.tcp_twist.linear.tolist(),
                "angular": self.tcp_twist.angular.tolist(),
            },
            "motion_state": self.motion_state.value,
            "safety_level": self.safety_level.value,
            "external_force": self.external_force.tolist(),
            "external_torque": self.external_torque.tolist(),
            "in_contact": self.in_contact,
            "gripper_state": self.gripper_state,
            "manipulability": self.manipulability,
            "timestamp": self.timestamp,
        }
