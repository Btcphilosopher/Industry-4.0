"""Joint-space state: position, velocity, acceleration, torque, timestamp."""

from __future__ import annotations

import time
from dataclasses import dataclass, field

import numpy as np


@dataclass
class JointState:
    """A snapshot of joint-space state for an n-DOF manipulator."""

    names: list[str]
    position: np.ndarray
    velocity: np.ndarray
    acceleration: np.ndarray
    torque: np.ndarray
    timestamp: float = field(default_factory=time.time)

    def __post_init__(self) -> None:
        self.position = np.asarray(self.position, dtype=float)
        self.velocity = np.asarray(self.velocity, dtype=float)
        self.acceleration = np.asarray(self.acceleration, dtype=float)
        self.torque = np.asarray(self.torque, dtype=float)

    @classmethod
    def zeros(cls, dof: int, names: list[str] | None = None) -> "JointState":
        names = names or [f"joint_{i + 1}" for i in range(dof)]
        return cls(
            names=names,
            position=np.zeros(dof),
            velocity=np.zeros(dof),
            acceleration=np.zeros(dof),
            torque=np.zeros(dof),
        )

    @property
    def dof(self) -> int:
        return len(self.position)

    def as_dict(self) -> dict:
        return {
            "names": self.names,
            "position": self.position.tolist(),
            "velocity": self.velocity.tolist(),
            "acceleration": self.acceleration.tolist(),
            "torque": self.torque.tolist(),
            "timestamp": self.timestamp,
        }

    def copy(self) -> "JointState":
        return JointState(
            names=list(self.names),
            position=self.position.copy(),
            velocity=self.velocity.copy(),
            acceleration=self.acceleration.copy(),
            torque=self.torque.copy(),
            timestamp=self.timestamp,
        )
