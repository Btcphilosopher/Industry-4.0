"""Forward/inverse kinematics, Jacobians, and singularity analysis."""

from roboforge.robotics.kinematics.forward import forward_kinematics, forward_kinematics_all_frames
from roboforge.robotics.kinematics.jacobian import (
    geometric_jacobian,
    analytic_jacobian,
    damped_pseudoinverse,
)
from roboforge.robotics.kinematics.singularity import manipulability_index, is_near_singularity
from roboforge.robotics.kinematics.inverse import inverse_kinematics, IKResult

__all__ = [
    "forward_kinematics",
    "forward_kinematics_all_frames",
    "geometric_jacobian",
    "analytic_jacobian",
    "damped_pseudoinverse",
    "manipulability_index",
    "is_near_singularity",
    "inverse_kinematics",
    "IKResult",
]
