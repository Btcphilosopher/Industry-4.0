"""Forward kinematics for arbitrary-DOF serial manipulators via the
standard Denavit-Hartenberg convention.

    T_i = Rot_z(theta_i) * Trans_z(d_i) * Trans_x(a_i) * Rot_x(alpha_i)

Chaining these transforms from the robot base out to the flange, then
composing with the robot's base pose in the world and the tool's TCP
offset, gives the full "World -> Robot Base -> Joint Frames -> Tool"
chain referenced throughout the platform (section 15).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from roboforge.core.transforms import Pose

if TYPE_CHECKING:
    from roboforge.robotics.robot import Robot


def dh_transform(a: float, alpha: float, d: float, theta: float) -> np.ndarray:
    """Homogeneous transform for one standard-DH row."""
    ct, st = np.cos(theta), np.sin(theta)
    ca, sa = np.cos(alpha), np.sin(alpha)
    return np.array(
        [
            [ct, -st * ca, st * sa, a * ct],
            [st, ct * ca, -ct * sa, a * st],
            [0.0, sa, ca, d],
            [0.0, 0.0, 0.0, 1.0],
        ]
    )


def forward_kinematics_all_frames(robot: "Robot", q: np.ndarray) -> list[np.ndarray]:
    """Return the homogeneous transform of every joint frame (in world
    coordinates), from joint 1's frame through to the flange (tool0).

    Index ``i`` in the returned list is the transform of joint ``i+1``'s
    output frame. This is what the Jacobian and Newton-Euler dynamics
    engines iterate over.
    """
    q = np.asarray(q, dtype=float)
    offsets = robot.calibration.joint_zero_offsets
    if offsets is None:
        offsets = np.zeros(robot.dof)

    T = robot.base_pose.as_matrix() @ robot.calibration.base_offset.as_matrix()
    frames: list[np.ndarray] = []
    for joint, qi, offset in zip(robot.joints, q, offsets):
        qi_corrected = qi - offset
        theta = joint.theta_for(qi_corrected)
        d = joint.d_for(qi_corrected)
        T = T @ dh_transform(joint.dh.a, joint.dh.alpha, d, theta)
        frames.append(T.copy())
    return frames


def forward_kinematics(robot: "Robot", q: np.ndarray) -> Pose:
    """Compute the TCP pose in world coordinates for joint configuration ``q``."""
    frames = forward_kinematics_all_frames(robot, q)
    T_flange = frames[-1] if frames else robot.base_pose.as_matrix()
    tcp_offset = (
        robot.tool.tcp.offset.as_matrix()
        if robot.tool is not None
        else (
            robot.calibration.tcp_offset.as_matrix()
            if robot.calibration.tcp_offset is not None
            else np.eye(4)
        )
    )
    T_tcp = T_flange @ tcp_offset
    return Pose.from_matrix(T_tcp, frame="world")
