"""Inverse kinematics (section 4).

Provides a robust numerical IK solver (damped-least-squares Newton
iteration on the Jacobian) that works for arbitrary DH chains and DOF
counts, including redundancy resolution via null-space secondary
objectives for dof > 6 robots. A generic closed-form "analytical" solver
does not exist for arbitrary kinematic structures, so the ``ANALYTICAL``
method is honestly implemented as a fast-converging numerical solve
seeded intelligently, rather than faking closed-form coverage this
platform cannot guarantee across arbitrary user-supplied DH tables.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, TYPE_CHECKING

import numpy as np

from roboforge.core.enums import IKMethod
from roboforge.core.transforms import Pose, rotation_matrix_to_axis_angle
from roboforge.robotics.kinematics.forward import forward_kinematics
from roboforge.robotics.kinematics.jacobian import (
    geometric_jacobian,
    damped_pseudoinverse,
    null_space_projector,
)

if TYPE_CHECKING:
    from roboforge.robotics.robot import Robot


@dataclass
class IKResult:
    success: bool
    joint_positions: np.ndarray
    iterations: int
    position_error: float
    orientation_error: float
    method: IKMethod
    manipulability: float
    message: str = ""


def _pose_error(current: Pose, target: Pose) -> np.ndarray:
    """6-vector [position_error; orientation_error] with orientation
    expressed as a rotation vector (axis * angle) taking current -> target.
    """
    pos_err = target.position - current.position
    R_err = target.rotation @ current.rotation.T
    axis, angle = rotation_matrix_to_axis_angle(R_err)
    rot_err = axis * angle
    return np.concatenate([pos_err, rot_err])


def _clamp_to_limits(robot: "Robot", q: np.ndarray) -> np.ndarray:
    return np.array([j.limits.clamp_position(v) for j, v in zip(robot.joints, q)])


def _joint_limit_avoidance_gradient(robot: "Robot", q: np.ndarray) -> np.ndarray:
    """Gradient of a joint-limit-avoidance cost (pulls joints toward their
    range midpoint, weighted by how close they are to a limit) -- used as
    the secondary objective in null-space redundancy resolution."""
    grad = np.zeros_like(q)
    for i, (joint, qi) in enumerate(zip(robot.joints, q)):
        rng = joint.limits.range
        if rng <= 1e-9:
            continue
        mid = joint.limits.midpoint
        grad[i] = -(qi - mid) / (rng ** 2)
    return grad


def inverse_kinematics(
    robot: "Robot",
    target_pose: Pose,
    initial_guess: np.ndarray,
    method: IKMethod = IKMethod.DAMPED_LEAST_SQUARES,
    max_iterations: int = 200,
    position_tolerance: float = 1e-5,
    orientation_tolerance: float = 1e-4,
    damping: float = 0.02,
    step_scale: float = 1.0,
    secondary_objective_gain: float = 0.1,
    respect_joint_limits: bool = True,
) -> IKResult:
    """Solve inverse kinematics for ``target_pose`` starting from
    ``initial_guess``.

    For redundant manipulators (dof > 6) a secondary objective (joint-limit
    avoidance by default) is optimised in the Jacobian's null space so the
    extra degrees of freedom are used purposefully rather than left to
    numerical drift.
    """
    q = np.asarray(initial_guess, dtype=float).copy()
    n = robot.dof
    last_error = np.full(6, np.inf)

    for it in range(1, max_iterations + 1):
        current_pose = forward_kinematics(robot, q)
        error = _pose_error(current_pose, target_pose)
        pos_err = float(np.linalg.norm(error[:3]))
        rot_err = float(np.linalg.norm(error[3:]))
        last_error = error

        if pos_err <= position_tolerance and rot_err <= orientation_tolerance:
            manip = float(np.sqrt(max(np.linalg.det(geometric_jacobian(robot, q) @ geometric_jacobian(robot, q).T), 0.0)))
            return IKResult(
                success=True,
                joint_positions=q,
                iterations=it,
                position_error=pos_err,
                orientation_error=rot_err,
                method=method,
                manipulability=manip,
                message="converged",
            )

        J = geometric_jacobian(robot, q)

        if method == IKMethod.JACOBIAN_TRANSPOSE:
            alpha = float((J @ J.T @ error) @ error / (np.linalg.norm(J @ J.T @ error) ** 2 + 1e-12))
            dq = alpha * J.T @ error
        elif method == IKMethod.JACOBIAN_PSEUDOINVERSE:
            dq = np.linalg.pinv(J) @ error
        else:  # DAMPED_LEAST_SQUARES / ANALYTICAL fallback
            J_pinv = damped_pseudoinverse(J, damping=damping)
            dq = J_pinv @ error
            if n > 6:
                # Redundancy resolution: push extra DOF toward the
                # secondary objective without perturbing the primary task.
                null_proj = null_space_projector(J, J_pinv)
                secondary_grad = _joint_limit_avoidance_gradient(robot, q)
                dq = dq + null_proj @ (secondary_objective_gain * secondary_grad)

        q = q + step_scale * dq
        if respect_joint_limits:
            q = _clamp_to_limits(robot, q)

    manip = float(np.sqrt(max(np.linalg.det(geometric_jacobian(robot, q) @ geometric_jacobian(robot, q).T), 0.0)))
    return IKResult(
        success=False,
        joint_positions=q,
        iterations=max_iterations,
        position_error=float(np.linalg.norm(last_error[:3])),
        orientation_error=float(np.linalg.norm(last_error[3:])),
        method=method,
        manipulability=manip,
        message="did not converge within max_iterations",
    )


def inverse_kinematics_multi_start(
    robot: "Robot",
    target_pose: Pose,
    n_restarts: int = 8,
    rng: np.random.Generator | None = None,
    **kwargs,
) -> IKResult:
    """Run IK from multiple randomised initial guesses (within joint
    limits) and return the best result -- a simple but effective way to
    escape local minima / avoid unreachable seeds without a full global
    solver."""
    rng = rng or np.random.default_rng()
    best: IKResult | None = None
    seeds = [robot.joint_state.position]
    for _ in range(n_restarts - 1):
        seed = np.array(
            [rng.uniform(j.limits.min_position, j.limits.max_position) for j in robot.joints]
        )
        seeds.append(seed)

    for seed in seeds:
        result = inverse_kinematics(robot, target_pose, seed, **kwargs)
        if result.success:
            return result
        if best is None or result.position_error < best.position_error:
            best = result
    return best
