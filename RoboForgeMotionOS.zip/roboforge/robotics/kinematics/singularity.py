"""Singularity detection and manipulability metrics (section 5).

Uses the Yoshikawa manipulability index and the smallest singular value
of the geometric Jacobian to detect kinematic singularities *before*
motion execution, so the trajectory engine can refuse or warn rather
than commanding the robot through an ill-conditioned configuration.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np

from roboforge.robotics.kinematics.jacobian import geometric_jacobian

if TYPE_CHECKING:
    from roboforge.robotics.robot import Robot


def manipulability_index(robot: "Robot", q: np.ndarray) -> float:
    """Yoshikawa's manipulability index: sqrt(det(J J^T)).

    Zero at a singular configuration; larger values indicate the
    manipulator is further from losing a degree of freedom of motion in
    task space. Not comparable in absolute terms across robots of
    different scale/DOF -- use consistently per-robot.
    """
    J = geometric_jacobian(robot, q)
    JJt = J @ J.T
    det = np.linalg.det(JJt)
    return float(np.sqrt(max(det, 0.0)))


def singular_values(robot: "Robot", q: np.ndarray) -> np.ndarray:
    J = geometric_jacobian(robot, q)
    return np.linalg.svd(J, compute_uv=False)


def condition_number(robot: "Robot", q: np.ndarray) -> float:
    sv = singular_values(robot, q)
    sv = sv[sv > 1e-12]
    if len(sv) == 0:
        return float("inf")
    return float(sv.max() / sv.min())


@dataclass
class SingularityReport:
    manipulability: float
    min_singular_value: float
    condition_number: float
    near_singular: bool
    singular_directions: np.ndarray  # unit task-space directions of low mobility


def analyse_singularity(robot: "Robot", q: np.ndarray, threshold: float = 0.02) -> SingularityReport:
    J = geometric_jacobian(robot, q)
    U, S, Vt = np.linalg.svd(J)
    min_sv = float(S.min()) if S.size else 0.0
    near = min_sv < threshold
    # The task-space direction(s) associated with the smallest singular
    # value(s) are the directions the manipulator is losing mobility in.
    weak_directions = U[:, S < threshold] if np.any(S < threshold) else np.zeros((6, 0))
    return SingularityReport(
        manipulability=manipulability_index(robot, q),
        min_singular_value=min_sv,
        condition_number=condition_number(robot, q),
        near_singular=near,
        singular_directions=weak_directions,
    )


def is_near_singularity(robot: "Robot", q: np.ndarray, threshold: float = 0.02) -> bool:
    return analyse_singularity(robot, q, threshold).near_singular
