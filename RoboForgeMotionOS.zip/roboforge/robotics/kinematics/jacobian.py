"""The Jacobian engine (section 5).

Provides the geometric Jacobian (closed-form, from the DH chain), an
analytic Jacobian (position + rotation-vector parameterisation, via
central differences -- deliberately generic since it must work for
arbitrary DH chains including SCARA/Cartesian/delta-like serial
equivalents), and the pseudoinverse variants IK and Cartesian servoing
depend on.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from roboforge.core.enums import JointType
from roboforge.core.transforms import rotation_matrix_to_axis_angle
from roboforge.robotics.kinematics.forward import forward_kinematics, forward_kinematics_all_frames

if TYPE_CHECKING:
    from roboforge.robotics.robot import Robot


def geometric_jacobian(robot: "Robot", q: np.ndarray) -> np.ndarray:
    """The 6xN geometric Jacobian mapping joint velocities to the TCP's
    spatial velocity [linear; angular], expressed in world coordinates.
    """
    q = np.asarray(q, dtype=float)
    n = robot.dof
    base_frame = robot.base_pose.as_matrix() @ robot.calibration.base_offset.as_matrix()
    joint_frames = forward_kinematics_all_frames(robot, q)
    all_frames = [base_frame] + joint_frames

    tcp_pose = forward_kinematics(robot, q)
    p_e = tcp_pose.position

    J = np.zeros((6, n))
    for i in range(n):
        T_prev = all_frames[i]
        z_axis = T_prev[:3, 2]
        p_prev = T_prev[:3, 3]
        joint = robot.joints[i]
        if joint.joint_type == JointType.REVOLUTE:
            Jv = np.cross(z_axis, p_e - p_prev)
            Jw = z_axis
        elif joint.joint_type == JointType.PRISMATIC:
            Jv = z_axis
            Jw = np.zeros(3)
        else:  # FIXED
            Jv = np.zeros(3)
            Jw = np.zeros(3)
        J[:3, i] = Jv
        J[3:, i] = Jw
    return J


def analytic_jacobian(robot: "Robot", q: np.ndarray, eps: float = 1e-6) -> np.ndarray:
    """A 6xN analytic Jacobian mapping joint velocities to the rate of
    change of a minimal pose parameterisation [position; rotation-vector],
    obtained by central-difference numerical differentiation of forward
    kinematics.

    This is intentionally generic (works for any DH chain / DOF count)
    rather than hand-deriving Euler-angle-rate mapping matrices, which
    only make sense for a fixed Euler convention and singular at gimbal
    lock in exactly the directions users care least about controlling.
    """
    q = np.asarray(q, dtype=float)
    n = robot.dof
    J = np.zeros((6, n))
    base_pose = forward_kinematics(robot, q)
    for i in range(n):
        dq = np.zeros(n)
        dq[i] = eps
        p_plus = forward_kinematics(robot, q + dq)
        p_minus = forward_kinematics(robot, q - dq)
        J[:3, i] = (p_plus.position - p_minus.position) / (2 * eps)

        R_rel_plus = base_pose.rotation.T @ p_plus.rotation
        R_rel_minus = base_pose.rotation.T @ p_minus.rotation
        axis_p, angle_p = rotation_matrix_to_axis_angle(R_rel_plus)
        axis_m, angle_m = rotation_matrix_to_axis_angle(R_rel_minus)
        rotvec_plus = base_pose.rotation @ (axis_p * angle_p)
        rotvec_minus = base_pose.rotation @ (axis_m * angle_m)
        J[3:, i] = (rotvec_plus - rotvec_minus) / (2 * eps)
    return J


def damped_pseudoinverse(J: np.ndarray, damping: float = 0.05) -> np.ndarray:
    """Damped least-squares (Levenberg-Marquardt style) pseudoinverse.

    J_dagger = J^T (J J^T + lambda^2 I)^-1

    This stays well-conditioned near singularities, unlike the plain
    Moore-Penrose pseudoinverse, at the cost of some tracking accuracy
    (the classic accuracy/robustness trade-off of DLS IK).
    """
    m = J.shape[0]
    JJt = J @ J.T
    damped = JJt + (damping ** 2) * np.eye(m)
    return J.T @ np.linalg.inv(damped)


def jacobian_pseudoinverse(J: np.ndarray) -> np.ndarray:
    """Plain Moore-Penrose pseudoinverse (numerically robust via SVD)."""
    return np.linalg.pinv(J)


def jacobian_transpose(J: np.ndarray, gain: float = 1.0) -> np.ndarray:
    """Jacobian-transpose "pseudo-inverse" -- cheap, stable, but generally
    less accurate than the (damped) pseudoinverse; useful for
    low-precision high-rate visual servoing loops."""
    return gain * J.T


def null_space_projector(J: np.ndarray, J_pinv: np.ndarray | None = None) -> np.ndarray:
    """Return the null-space projector I - J^+ J, used for redundancy
    resolution (secondary objectives) on redundant (dof > 6) robots."""
    n = J.shape[1]
    J_pinv = jacobian_pseudoinverse(J) if J_pinv is None else J_pinv
    return np.eye(n) - J_pinv @ J
