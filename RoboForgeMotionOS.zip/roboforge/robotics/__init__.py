"""Robot modelling: joints, links, kinematics, dynamics, and state."""
