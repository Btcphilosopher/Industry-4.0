"""High-fidelity, deterministic simulation (section 27): a physics engine
(dynamics integration + a peg-in-hole-style contact model for insertion
tasks), a simulation world (objects/fixtures), and ``SimulatedRobot`` --
the same ``Robot``/kinematics/dynamics model driven by a simulated clock
instead of a hardware driver, so identical planning/control code runs
against simulation or real hardware (section 26)."""

from roboforge.simulation.world import SimulationWorld
from roboforge.simulation.physics_engine import PhysicsEngine, PegHoleContactModel
from roboforge.simulation.simulated_robot import SimulatedRobot, TrajectoryExecutionResult

__all__ = [
    "SimulationWorld",
    "PhysicsEngine",
    "PegHoleContactModel",
    "SimulatedRobot",
    "TrajectoryExecutionResult",
]
