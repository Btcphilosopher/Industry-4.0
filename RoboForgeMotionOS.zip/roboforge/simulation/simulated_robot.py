"""``SimulatedRobot``: executes joint trajectories against a ``Robot``
purely in simulation -- the same trajectory objects, the same
``robot.joint_state``, and (optionally) the same telemetry/event
plumbing a hardware driver would use (section 26: same command, sim or
real). A small tracking-error model and configurable comm latency/noise
give the platform something more realistic than "trajectory replays
exactly" to validate against (section 27: faults, latency, noise).
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np

from roboforge.core.enums import MotionState
from roboforge.events.events import TrajectoryAborted, TrajectoryCompleted, TrajectoryStarted
from roboforge.robotics.state.joint_state import JointState

if TYPE_CHECKING:
    from roboforge.events.event_bus import EventBus
    from roboforge.motion.trajectory.joint_trajectory import JointTrajectory
    from roboforge.robotics.robot import Robot
    from roboforge.state_estimation.state_estimator import RobotStateEstimator
    from roboforge.telemetry.telemetry_recorder import TelemetryRecorder


@dataclass
class TrajectoryExecutionResult:
    success: bool
    trajectory_id: str
    execution_time_s: float
    max_tracking_error_m: float
    samples_recorded: int
    aborted_reason: str = ""


class SimulatedRobot:
    def __init__(
        self,
        robot: "Robot",
        tracking_noise_std: float = 5e-5,
        rng: np.random.Generator | None = None,
        latency_s: float = 0.0,
    ) -> None:
        self.robot = robot
        self.tracking_noise_std = tracking_noise_std
        self.latency_s = latency_s
        self.rng = rng or np.random.default_rng()

    def execute_trajectory(
        self,
        trajectory: "JointTrajectory",
        event_bus: "EventBus | None" = None,
        telemetry: "TelemetryRecorder | None" = None,
        state_estimator: "RobotStateEstimator | None" = None,
        sample_stride: int = 1,
        abort_check=None,
    ) -> TrajectoryExecutionResult:
        """Play ``trajectory`` into ``robot.joint_state``. ``abort_check``,
        if given, is called with each point and may return a non-empty
        abort reason string to stop execution early (e.g. a safety
        violation detected mid-motion)."""
        trajectory_id = uuid.uuid4().hex[:12]
        if event_bus is not None:
            event_bus.publish(
                TrajectoryStarted(robot_id=self.robot.robot_id, trajectory_id=trajectory_id, duration_s=trajectory.duration)
            )
        self.robot.motion_state = MotionState.MOVING

        max_error = 0.0
        n_recorded = 0
        for i, point in enumerate(trajectory.points):
            if abort_check is not None:
                reason = abort_check(point)
                if reason:
                    self.robot.motion_state = MotionState.STOPPING
                    if event_bus is not None:
                        event_bus.publish(
                            TrajectoryAborted(robot_id=self.robot.robot_id, trajectory_id=trajectory_id, reason=reason)
                        )
                    return TrajectoryExecutionResult(
                        False, trajectory_id, point.t, max_error, n_recorded, aborted_reason=reason
                    )

            noise = self.rng.normal(0, self.tracking_noise_std, size=self.robot.dof)
            actual_position = point.position + noise
            max_error = max(max_error, float(np.max(np.abs(noise))))

            self.robot.joint_state = JointState(
                names=self.robot.joint_names,
                position=actual_position,
                velocity=point.velocity.copy(),
                acceleration=point.acceleration.copy(),
                torque=np.zeros(self.robot.dof),
                timestamp=time.time(),
            )

            if telemetry is not None and state_estimator is not None and i % sample_stride == 0:
                state_estimator.sync_true_positions(actual_position)
                state = state_estimator.estimate_robot_state()
                telemetry.record_state(state, trajectory_error=float(np.linalg.norm(noise)))
                n_recorded += 1

        self.robot.motion_state = MotionState.ENABLED
        if event_bus is not None:
            event_bus.publish(
                TrajectoryCompleted(
                    robot_id=self.robot.robot_id,
                    trajectory_id=trajectory_id,
                    execution_time_s=trajectory.duration,
                    position_error_m=max_error,
                )
            )
        return TrajectoryExecutionResult(True, trajectory_id, trajectory.duration, max_error, n_recorded)
