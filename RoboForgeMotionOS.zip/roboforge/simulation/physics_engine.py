"""The simulation physics engine (section 27): joint-space dynamics
integration (semi-implicit Euler on top of ``DynamicsModel.forward_dynamics``)
and a simple penalty-based contact model used to generate realistic
force feedback for contact-rich manipulation (insertion/assembly) without
a full rigid-body contact solver.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np

from roboforge.core.transforms import Pose
from roboforge.robotics.dynamics.dynamics_model import DynamicsModel
from roboforge.robotics.state.joint_state import JointState

if TYPE_CHECKING:
    from roboforge.robotics.robot import Robot
    from roboforge.simulation.world import SimulationWorld


class PhysicsEngine:
    """Integrates joint-space rigid-body dynamics forward in time under a
    commanded torque, respecting joint position/velocity limits (a
    velocity-limited joint is clamped and its velocity zeroed, modelling a
    mechanical/soft-stop rather than allowing non-physical overshoot).
    """

    def __init__(self, robot: "Robot", world: "SimulationWorld", dt: float = 0.002) -> None:
        self.robot = robot
        self.world = world
        self.dt = dt
        self.dynamics = DynamicsModel(robot, gravity=world.gravity)

    def step(self, tau_command: np.ndarray) -> JointState:
        js = self.robot.joint_state
        qdd = self.dynamics.forward_dynamics(js.position, js.velocity, np.asarray(tau_command, dtype=float))

        qd_new = js.velocity + qdd * self.dt
        q_new = js.position + qd_new * self.dt

        for i, joint in enumerate(self.robot.joints):
            if not joint.limits.within_position(q_new[i]):
                q_new[i] = joint.limits.clamp_position(q_new[i])
                qd_new[i] = 0.0
            max_v = joint.limits.max_velocity
            if abs(qd_new[i]) > max_v:
                qd_new[i] = np.sign(qd_new[i]) * max_v

        new_state = JointState(
            names=js.names, position=q_new, velocity=qd_new, acceleration=qdd, torque=np.asarray(tau_command, dtype=float)
        )
        self.robot.joint_state = new_state
        self.world.advance(self.dt)
        return new_state


@dataclass
class PegHoleContactModel:
    """A penalty-based contact-force simulator for a peg-in-hole-style
    insertion task: lateral misalignment from the hole's axis generates a
    resisting lateral force (proportional to offset, i.e. a stiff virtual
    chamfer/bore), and axial motion past the hole's floor generates a
    steep opposing axial force (the part has bottomed out).
    """

    target_pose: Pose               # hole entrance pose
    insertion_axis_local: np.ndarray  # unit vector, tool frame
    hole_depth_m: float
    lateral_stiffness_n_per_m: float = 8000.0
    axial_free_stiffness_n_per_m: float = 200.0
    axial_bottom_stiffness_n_per_m: float = 50000.0
    lateral_clearance_m: float = 0.0003

    def __post_init__(self) -> None:
        self._axis_world = self.target_pose.rotation @ (
            self.insertion_axis_local / np.linalg.norm(self.insertion_axis_local)
        )

    def compute_force(self, current_pose: Pose) -> np.ndarray:
        relative = current_pose.position - self.target_pose.position
        depth = float(np.dot(relative, self._axis_world))
        lateral_vec = relative - depth * self._axis_world
        lateral_offset = float(np.linalg.norm(lateral_vec))

        force = np.zeros(3)

        # Lateral resistance once past the clearance envelope.
        if lateral_offset > self.lateral_clearance_m and lateral_offset > 1e-9:
            excess = lateral_offset - self.lateral_clearance_m
            direction = lateral_vec / lateral_offset
            force -= self.lateral_stiffness_n_per_m * excess * direction

        # Axial resistance: free (light drag) while above the hole floor,
        # steep once the peg has bottomed out.
        if depth < 0:
            force += self.axial_free_stiffness_n_per_m * (-depth) * self._axis_world
        elif depth > self.hole_depth_m:
            overshoot = depth - self.hole_depth_m
            force -= self.axial_bottom_stiffness_n_per_m * overshoot * self._axis_world

        return force
