"""The simulation world: collision obstacles/fixtures, graspable objects,
gravity, and the simulated-time scale (section 27: 1x/10x/100x/1000x)."""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from roboforge.collision.collision_world import CollisionWorld
from roboforge.manipulation.grasping.grasp import GraspableObject


@dataclass
class SimulationWorld:
    collision_world: CollisionWorld = field(default_factory=CollisionWorld)
    objects: dict[str, GraspableObject] = field(default_factory=dict)
    gravity: np.ndarray = field(default_factory=lambda: np.array([0.0, 0.0, -9.80665]))
    time_scale: float = 1.0
    sim_time_s: float = 0.0

    def add_object(self, obj: GraspableObject) -> None:
        self.objects[obj.object_id] = obj

    def remove_object(self, object_id: str) -> None:
        self.objects.pop(object_id, None)

    def get_object(self, object_id: str) -> GraspableObject | None:
        return self.objects.get(object_id)

    def advance(self, dt: float) -> None:
        self.sim_time_s += dt * self.time_scale
