"""A simple synchronous, in-process publish/subscribe event bus (section
37). Subscribers register by event class (or ``Event`` itself for a
catch-all); publishing never raises due to a subscriber's own error --
subscriber exceptions are caught and logged so one bad listener (e.g. a
telemetry writer) can't take down the publishing subsystem.
"""

from __future__ import annotations

import logging
from collections import defaultdict
from typing import Callable, Type, TypeVar

from roboforge.events.events import Event

logger = logging.getLogger("roboforge.events")

E = TypeVar("E", bound=Event)
Handler = Callable[[Event], None]


class EventBus:
    def __init__(self) -> None:
        self._handlers: dict[type, list[Handler]] = defaultdict(list)
        self._history: list[Event] = []
        self._history_limit = 5000

    def subscribe(self, event_type: Type[E], handler: Callable[[E], None]) -> None:
        self._handlers[event_type].append(handler)

    def unsubscribe(self, event_type: Type[E], handler: Callable[[E], None]) -> None:
        if handler in self._handlers.get(event_type, []):
            self._handlers[event_type].remove(handler)

    def publish(self, event: Event) -> None:
        self._history.append(event)
        if len(self._history) > self._history_limit:
            self._history = self._history[-self._history_limit :]

        for event_type, handlers in self._handlers.items():
            if isinstance(event, event_type):
                for handler in handlers:
                    try:
                        handler(event)
                    except Exception:  # noqa: BLE001 - isolate subscriber failures
                        logger.exception("Event handler raised while processing %s", event.event_type)

    def history(self, event_type: Type[E] | None = None, limit: int = 100) -> list[Event]:
        events = self._history if event_type is None else [e for e in self._history if isinstance(e, event_type)]
        return events[-limit:]
