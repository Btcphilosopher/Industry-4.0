"""The platform event catalogue (section 37): every subsystem publishes
these onto the ``EventBus`` rather than calling into other subsystems
directly, keeping the platform loosely coupled (telemetry, the API's
websocket stream, and an optional AI supervisory layer can all subscribe
without the robotics/motion/manipulation code knowing they exist).
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field


@dataclass
class Event:
    robot_id: str = ""
    timestamp: float = field(default_factory=time.time)
    event_id: str = field(default_factory=lambda: uuid.uuid4().hex)

    @property
    def event_type(self) -> str:
        return type(self).__name__


@dataclass
class RobotConnected(Event):
    driver_name: str = ""


@dataclass
class RobotEnabled(Event):
    pass


@dataclass
class RobotMoved(Event):
    joint_positions: list[float] = field(default_factory=list)


@dataclass
class TrajectoryStarted(Event):
    trajectory_id: str = ""
    duration_s: float = 0.0


@dataclass
class TrajectoryCompleted(Event):
    trajectory_id: str = ""
    execution_time_s: float = 0.0
    position_error_m: float = 0.0


@dataclass
class TrajectoryAborted(Event):
    trajectory_id: str = ""
    reason: str = ""


@dataclass
class CollisionWarning(Event):
    clearance_m: float = 0.0
    pair: tuple[str, str] = ("", "")


@dataclass
class JointLimitWarning(Event):
    joint_name: str = ""
    value: float = 0.0
    limit: float = 0.0


@dataclass
class SingularityWarning(Event):
    manipulability: float = 0.0


@dataclass
class ContactDetected(Event):
    force_n: float = 0.0


@dataclass
class GraspDetected(Event):
    object_id: str = ""
    confidence: float = 0.0


@dataclass
class ObjectDetected(Event):
    object_id: str = ""
    class_label: str = ""
    confidence: float = 0.0


@dataclass
class ObjectPicked(Event):
    object_id: str = ""


@dataclass
class ObjectPlaced(Event):
    object_id: str = ""


@dataclass
class CalibrationStarted(Event):
    calibration_type: str = ""


@dataclass
class CalibrationCompleted(Event):
    calibration_type: str = ""
    success: bool = True


@dataclass
class RobotFault(Event):
    reason: str = ""


@dataclass
class EmergencyStop(Event):
    reason: str = ""
