"""The plugin base class and registry. A plugin is identified by a
``PluginKind`` (what extension point it fills) and a unique name; the
registry is a simple in-process dict -- deployments needing dynamic
discovery can populate it from Python entry points at startup without
any change to this module.
"""

from __future__ import annotations

from abc import ABC
from enum import Enum
from typing import Any


class PluginKind(str, Enum):
    DYNAMICS_SOLVER = "dynamics_solver"
    DRIVER = "driver"
    GRASP_PLANNER = "grasp_planner"
    MOTION_PLANNER = "motion_planner"
    AI_SUPERVISOR = "ai_supervisor"
    SENSOR = "sensor"


class Plugin(ABC):
    name: str
    kind: PluginKind
    version: str = "0.1.0"

    def describe(self) -> dict[str, Any]:
        return {"name": self.name, "kind": self.kind.value, "version": self.version}


class PluginRegistry:
    def __init__(self) -> None:
        self._plugins: dict[str, Plugin] = {}

    def register(self, plugin: Plugin) -> None:
        if plugin.name in self._plugins:
            raise ValueError(f"Plugin {plugin.name!r} is already registered")
        self._plugins[plugin.name] = plugin

    def unregister(self, name: str) -> None:
        self._plugins.pop(name, None)

    def get(self, name: str) -> Plugin | None:
        return self._plugins.get(name)

    def list(self, kind: PluginKind | None = None) -> list[Plugin]:
        plugins = list(self._plugins.values())
        if kind is not None:
            plugins = [p for p in plugins if p.kind == kind]
        return plugins


# A module-level default registry, convenient for simple deployments that
# don't need per-application isolation.
default_registry = PluginRegistry()
