"""The plugin system: lets a deployment register additional dynamics
solvers, drivers, grasp planners, or AI-supervisory analysers without
modifying the core platform (section 41: "do not make the entire
architecture dependent on one robotics framework")."""

from roboforge.plugins.base import Plugin, PluginRegistry, PluginKind

__all__ = ["Plugin", "PluginRegistry", "PluginKind"]
