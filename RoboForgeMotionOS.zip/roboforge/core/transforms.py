"""
Transformation mathematics for RoboForge Motion.OS.

This module is the single source of truth for SE(3) poses, rotation
representations (rotation matrices, quaternions, Euler angles, axis-angle),
homogeneous transforms, and twists (spatial velocities). Every other
subsystem in the platform (kinematics, dynamics, trajectory generation,
collision checking, perception) builds on these primitives so that
coordinate-frame handling stays explicit and traceable, per the
"World -> Robot Base -> Joint Frames -> Tool -> Camera -> Object" chain.

We deliberately build on ``scipy.spatial.transform.Rotation`` for the
underlying rotation math (it is well tested and numerically robust) rather
than re-implementing quaternion algebra from scratch.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Sequence

import numpy as np
from scipy.spatial.transform import Rotation as _Rotation

Vector3 = np.ndarray  # shape (3,)
Matrix3 = np.ndarray  # shape (3, 3)
Matrix4 = np.ndarray  # shape (4, 4)
Quaternion = np.ndarray  # shape (4,) as (x, y, z, w) -- SciPy convention


def skew(v: Sequence[float]) -> Matrix3:
    """Return the 3x3 skew-symmetric (cross-product) matrix of a vector."""
    x, y, z = v
    return np.array(
        [
            [0.0, -z, y],
            [z, 0.0, -x],
            [-y, x, 0.0],
        ]
    )


def quaternion_to_rotation_matrix(q: Quaternion) -> Matrix3:
    """Convert an (x, y, z, w) quaternion to a 3x3 rotation matrix."""
    return _Rotation.from_quat(q).as_matrix()


def rotation_matrix_to_quaternion(R: Matrix3) -> Quaternion:
    """Convert a 3x3 rotation matrix to an (x, y, z, w) quaternion."""
    return _Rotation.from_matrix(R).as_quat()


def euler_to_rotation_matrix(
    euler: Sequence[float], sequence: str = "xyz", degrees: bool = False
) -> Matrix3:
    """Convert Euler angles (roll, pitch, yaw by default) to a rotation matrix."""
    return _Rotation.from_euler(sequence, euler, degrees=degrees).as_matrix()


def rotation_matrix_to_euler(
    R: Matrix3, sequence: str = "xyz", degrees: bool = False
) -> Vector3:
    """Convert a rotation matrix to Euler angles."""
    return _Rotation.from_matrix(R).as_euler(sequence, degrees=degrees)


def axis_angle_to_rotation_matrix(axis: Sequence[float], angle: float) -> Matrix3:
    """Convert an axis-angle representation to a rotation matrix (Rodrigues)."""
    axis = np.asarray(axis, dtype=float)
    norm = np.linalg.norm(axis)
    if norm < 1e-12:
        return np.eye(3)
    axis = axis / norm
    return _Rotation.from_rotvec(axis * angle).as_matrix()


def rotation_matrix_to_axis_angle(R: Matrix3) -> tuple[Vector3, float]:
    """Convert a rotation matrix to (axis, angle)."""
    rotvec = _Rotation.from_matrix(R).as_rotvec()
    angle = float(np.linalg.norm(rotvec))
    if angle < 1e-12:
        return np.array([0.0, 0.0, 1.0]), 0.0
    return rotvec / angle, angle


def homogeneous_transform(position: Sequence[float], R: Matrix3) -> Matrix4:
    """Compose a 4x4 homogeneous transform from a position and rotation matrix."""
    T = np.eye(4)
    T[:3, :3] = R
    T[:3, 3] = position
    return T


def invert_homogeneous_transform(T: Matrix4) -> Matrix4:
    """Invert a homogeneous transform analytically (cheaper & more stable than
    a generic matrix inverse for SE(3))."""
    R = T[:3, :3]
    p = T[:3, 3]
    T_inv = np.eye(4)
    T_inv[:3, :3] = R.T
    T_inv[:3, 3] = -R.T @ p
    return T_inv


@dataclass
class Pose:
    """A rigid-body pose in SE(3): position + orientation.

    Internally orientation is stored as a rotation matrix so that repeated
    composition does not accumulate the numerical drift quaternion
    re-normalisation would otherwise require tracking manually; convenience
    accessors expose quaternion, Euler, and axis-angle representations.
    """

    position: Vector3 = field(default_factory=lambda: np.zeros(3))
    rotation: Matrix3 = field(default_factory=lambda: np.eye(3))
    frame: str = "world"

    def __post_init__(self) -> None:
        self.position = np.asarray(self.position, dtype=float).reshape(3)
        self.rotation = np.asarray(self.rotation, dtype=float).reshape(3, 3)

    # -- constructors ---------------------------------------------------
    @classmethod
    def identity(cls, frame: str = "world") -> "Pose":
        return cls(np.zeros(3), np.eye(3), frame=frame)

    @classmethod
    def from_matrix(cls, T: Matrix4, frame: str = "world") -> "Pose":
        return cls(position=T[:3, 3].copy(), rotation=T[:3, :3].copy(), frame=frame)

    @classmethod
    def from_position_quaternion(
        cls, position: Sequence[float], quat_xyzw: Sequence[float], frame: str = "world"
    ) -> "Pose":
        return cls(
            position=np.asarray(position, dtype=float),
            rotation=quaternion_to_rotation_matrix(np.asarray(quat_xyzw, dtype=float)),
            frame=frame,
        )

    @classmethod
    def from_position_euler(
        cls,
        position: Sequence[float],
        euler: Sequence[float],
        sequence: str = "xyz",
        degrees: bool = False,
        frame: str = "world",
    ) -> "Pose":
        return cls(
            position=np.asarray(position, dtype=float),
            rotation=euler_to_rotation_matrix(euler, sequence, degrees),
            frame=frame,
        )

    @classmethod
    def from_xyzrpy(cls, x: float, y: float, z: float, roll: float, pitch: float, yaw: float,
                     frame: str = "world") -> "Pose":
        """Convenience constructor matching the x/y/z/roll/pitch/yaw convention
        used at the perception <-> robot boundary (see section 13)."""
        return cls.from_position_euler([x, y, z], [roll, pitch, yaw], sequence="xyz", frame=frame)

    # -- representations --------------------------------------------------
    def as_matrix(self) -> Matrix4:
        return homogeneous_transform(self.position, self.rotation)

    def as_quaternion(self) -> Quaternion:
        return rotation_matrix_to_quaternion(self.rotation)

    def as_euler(self, sequence: str = "xyz", degrees: bool = False) -> Vector3:
        return rotation_matrix_to_euler(self.rotation, sequence, degrees)

    def as_axis_angle(self) -> tuple[Vector3, float]:
        return rotation_matrix_to_axis_angle(self.rotation)

    def as_xyzrpy(self) -> tuple[float, float, float, float, float, float]:
        r, p, y = self.as_euler("xyz")
        x, yy, z = self.position
        return float(x), float(yy), float(z), float(r), float(p), float(y)

    # -- algebra ------------------------------------------------------------
    def compose(self, other: "Pose") -> "Pose":
        """Compose two poses: self * other (apply ``other`` in self's frame)."""
        R = self.rotation @ other.rotation
        p = self.rotation @ other.position + self.position
        return Pose(p, R, frame=self.frame)

    def __mul__(self, other: "Pose") -> "Pose":
        return self.compose(other)

    def inverse(self) -> "Pose":
        R_inv = self.rotation.T
        p_inv = -R_inv @ self.position
        return Pose(p_inv, R_inv, frame=self.frame)

    def transform_point(self, point: Sequence[float]) -> Vector3:
        return self.rotation @ np.asarray(point, dtype=float) + self.position

    def relative_to(self, reference: "Pose") -> "Pose":
        """Express this pose relative to a reference pose (reference^-1 * self)."""
        return reference.inverse().compose(self)

    def distance_to(self, other: "Pose") -> float:
        """Euclidean position distance to another pose (metres)."""
        return float(np.linalg.norm(self.position - other.position))

    def angular_distance_to(self, other: "Pose") -> float:
        """Angular distance (radians) between orientations, via the relative
        rotation's rotation-vector magnitude."""
        R_rel = self.rotation.T @ other.rotation
        _, angle = rotation_matrix_to_axis_angle(R_rel)
        return float(angle)

    def interpolate(self, other: "Pose", t: float) -> "Pose":
        """Linear interpolation in position, SLERP in orientation. ``t`` in [0, 1]."""
        t = float(np.clip(t, 0.0, 1.0))
        p = (1 - t) * self.position + t * other.position
        key_times = [0, 1]
        rotations = _Rotation.from_matrix(np.stack([self.rotation, other.rotation]))
        from scipy.spatial.transform import Slerp

        slerp = Slerp(key_times, rotations)
        R = slerp([t]).as_matrix()[0]
        return Pose(p, R, frame=self.frame)

    def copy(self) -> "Pose":
        return Pose(self.position.copy(), self.rotation.copy(), frame=self.frame)

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        x, y, z, r, p, yaw = self.as_xyzrpy()
        return (
            f"Pose(frame={self.frame!r}, xyz=({x:.4f}, {y:.4f}, {z:.4f}), "
            f"rpy=({r:.4f}, {p:.4f}, {yaw:.4f}))"
        )


@dataclass
class Twist:
    """A spatial velocity: linear + angular velocity, expressed in some frame."""

    linear: Vector3 = field(default_factory=lambda: np.zeros(3))
    angular: Vector3 = field(default_factory=lambda: np.zeros(3))
    frame: str = "world"

    def __post_init__(self) -> None:
        self.linear = np.asarray(self.linear, dtype=float).reshape(3)
        self.angular = np.asarray(self.angular, dtype=float).reshape(3)

    def as_vector(self) -> np.ndarray:
        """Return the 6-vector [linear; angular]."""
        return np.concatenate([self.linear, self.angular])

    @classmethod
    def from_vector(cls, v: Sequence[float], frame: str = "world") -> "Twist":
        v = np.asarray(v, dtype=float)
        return cls(v[:3], v[3:6], frame=frame)

    def norm(self) -> float:
        return float(np.linalg.norm(self.as_vector()))

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        return f"Twist(linear={self.linear}, angular={self.angular}, frame={self.frame!r})"
