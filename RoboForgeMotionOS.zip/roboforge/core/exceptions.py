"""Exception hierarchy for RoboForge Motion.OS.

Keeping a dedicated exception hierarchy lets callers (API layer, CLI,
safety system) distinguish "this motion is invalid" from "the robot
hardware is unreachable" from "this would violate a safety limit",
which matters a great deal for a manipulation platform.
"""

from __future__ import annotations


class RoboForgeError(Exception):
    """Base class for all RoboForge Motion.OS errors."""


class ConfigurationError(RoboForgeError):
    """Raised when a robot/tool/workspace configuration fails validation."""


class KinematicsError(RoboForgeError):
    """Base class for kinematics-related errors."""


class UnreachablePoseError(KinematicsError):
    """Raised when inverse kinematics cannot find a solution."""


class SingularityError(KinematicsError):
    """Raised when a requested motion passes through/near a singularity
    and cannot be safely executed without operator override."""


class JointLimitError(RoboForgeError):
    """Raised when a commanded joint value/velocity/acceleration/torque
    would violate a configured limit."""


class WorkspaceLimitError(RoboForgeError):
    """Raised when a commanded Cartesian target lies outside the robot's
    configured workspace envelope."""


class CollisionError(RoboForgeError):
    """Raised when a planned or commanded motion would result in a
    collision."""


class TrajectoryError(RoboForgeError):
    """Raised when a trajectory cannot be generated or validated."""


class MotionPlanningError(RoboForgeError):
    """Raised when the motion planner fails to find a feasible path."""


class SafetyViolationError(RoboForgeError):
    """Raised when a command would violate an independent safety
    constraint. This exception must never be suppressed or bypassed by
    optimisation or AI-layer code."""


class DriverError(RoboForgeError):
    """Base class for hardware/driver communication errors."""


class DriverConnectionError(DriverError):
    """Raised when the driver cannot establish/maintain a connection to
    the robot controller."""


class DriverCommandError(DriverError):
    """Raised when the robot controller rejects or faults on a command."""


class CalibrationError(RoboForgeError):
    """Raised when a calibration routine fails or produces an
    out-of-tolerance result."""


class GraspError(RoboForgeError):
    """Raised when grasp planning/execution/verification fails."""


class HandoffError(RoboForgeError):
    """Raised when a robot-to-robot handoff fails or cannot be verified
    safely."""


class CoordinationError(RoboForgeError):
    """Raised for multi-robot workspace/temporal coordination conflicts."""


class AuthorizationError(RoboForgeError):
    """Raised when an authenticated principal lacks permission for a
    requested action."""


class AuthenticationError(RoboForgeError):
    """Raised when credentials/tokens cannot be verified."""
