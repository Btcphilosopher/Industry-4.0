"""Shared enumerations used across RoboForge Motion.OS."""

from __future__ import annotations

from enum import Enum, auto


class RobotKinematicFamily(str, Enum):
    ARTICULATED = "articulated"       # 4/5/6/7-axis serial arms
    SCARA = "scara"
    DELTA = "delta"
    CARTESIAN = "cartesian"           # gantry / cartesian
    PARALLEL = "parallel"
    CUSTOM = "custom"


class JointType(str, Enum):
    REVOLUTE = "revolute"
    PRISMATIC = "prismatic"
    FIXED = "fixed"


class MotionState(str, Enum):
    """The robot motion state machine (section 32)."""

    DISCONNECTED = "disconnected"
    INITIALISING = "initialising"
    READY = "ready"
    ENABLED = "enabled"
    MOVING = "moving"
    CONTACT = "contact"
    PAUSED = "paused"
    FAULT = "fault"
    STOPPING = "stopping"
    STOPPED = "stopped"
    MAINTENANCE = "maintenance"


class IKMethod(str, Enum):
    ANALYTICAL = "analytical"
    JACOBIAN_TRANSPOSE = "jacobian_transpose"
    JACOBIAN_PSEUDOINVERSE = "jacobian_pseudoinverse"
    DAMPED_LEAST_SQUARES = "damped_least_squares"


class TrajectoryType(str, Enum):
    JOINT_SPACE = "joint_space"
    CARTESIAN_LINEAR = "cartesian_linear"
    CARTESIAN_CIRCULAR = "cartesian_circular"
    SPLINE = "spline"
    BEZIER = "bezier"
    QUINTIC = "quintic"
    MINIMUM_JERK = "minimum_jerk"
    TIME_OPTIMAL = "time_optimal"


class PlannerObjective(str, Enum):
    MINIMUM_TIME = "minimum_time"
    MINIMUM_DISTANCE = "minimum_distance"
    MINIMUM_ENERGY = "minimum_energy"
    MINIMUM_JOINT_MOVEMENT = "minimum_joint_movement"
    MINIMUM_JERK = "minimum_jerk"
    MINIMUM_WEAR = "minimum_wear"
    MAXIMUM_PRECISION = "maximum_precision"
    MAXIMUM_CLEARANCE = "maximum_clearance"


class ControlMode(str, Enum):
    POSITION = "position"
    VELOCITY = "velocity"
    CARTESIAN_VELOCITY = "cartesian_velocity"
    FORCE = "force"
    IMPEDANCE = "impedance"
    ADMITTANCE = "admittance"
    HYBRID_POSITION_FORCE = "hybrid_position_force"


class GripperState(str, Enum):
    OPEN = "open"
    CLOSED = "closed"
    HOLDING = "holding"
    MOVING = "moving"
    FAULT = "fault"


class SafetyLevel(str, Enum):
    NORMAL = "normal"
    REDUCED = "reduced"
    STOPPED = "stopped"
    ESTOP = "estop"


class Role(str, Enum):
    """RBAC roles (section 48)."""

    OPERATOR = "operator"
    ROBOTICS_ENGINEER = "robotics_engineer"
    MAINTENANCE = "maintenance"
    ADMINISTRATOR = "administrator"
    READ_ONLY = "read_only"
