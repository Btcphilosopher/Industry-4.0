"""Object tracking: smooths repeated pose estimates over time."""

from roboforge.perception.tracking.object_tracker import ObjectTracker, TrackedObject

__all__ = ["ObjectTracker", "TrackedObject"]
