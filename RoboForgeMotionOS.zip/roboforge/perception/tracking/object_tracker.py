"""Simple exponential-smoothing object tracker: reduces frame-to-frame
pose jitter from noisy detections before handing a pose to the motion
planner, and ages out objects that stop being observed.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field

import numpy as np
from scipy.spatial.transform import Rotation as _Rotation, Slerp

from roboforge.core.transforms import Pose
from roboforge.perception.pose.pose_estimator import ObjectPose


@dataclass
class TrackedObject:
    object_id: str
    class_label: str
    pose_world: Pose
    confidence: float
    last_seen: float
    hits: int = 1


class ObjectTracker:
    def __init__(self, smoothing_alpha: float = 0.4, max_age_s: float = 2.0) -> None:
        self.smoothing_alpha = smoothing_alpha
        self.max_age_s = max_age_s
        self._tracks: dict[str, TrackedObject] = {}

    def update(self, observations: list[ObjectPose]) -> list[TrackedObject]:
        now = time.time()
        seen_ids = set()
        for obs in observations:
            seen_ids.add(obs.object_id)
            existing = self._tracks.get(obs.object_id)
            if existing is None:
                self._tracks[obs.object_id] = TrackedObject(
                    object_id=obs.object_id,
                    class_label=obs.class_label,
                    pose_world=obs.pose_world,
                    confidence=obs.confidence,
                    last_seen=now,
                )
                continue

            alpha = self.smoothing_alpha
            new_position = (1 - alpha) * existing.pose_world.position + alpha * obs.pose_world.position
            rots = _Rotation.from_matrix(np.stack([existing.pose_world.rotation, obs.pose_world.rotation]))
            slerp = Slerp([0.0, 1.0], rots)
            new_rotation = slerp([alpha]).as_matrix()[0]

            existing.pose_world = Pose(new_position, new_rotation, frame="world")
            existing.confidence = (1 - alpha) * existing.confidence + alpha * obs.confidence
            existing.last_seen = now
            existing.hits += 1

        self._tracks = {
            oid: t for oid, t in self._tracks.items() if (now - t.last_seen) <= self.max_age_s
        }
        return list(self._tracks.values())

    def get(self, object_id: str) -> TrackedObject | None:
        return self._tracks.get(object_id)

    def all(self) -> list[TrackedObject]:
        return list(self._tracks.values())
