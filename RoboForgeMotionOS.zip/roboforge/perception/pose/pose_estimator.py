"""6D pose estimation and the camera-frame -> world/robot-base transform
chain (sections 13, 15): ``World -> Robot Base -> ... -> Camera -> Object``.

Externally, an object pose can be summarised as x/y/z/roll/pitch/yaw plus
a confidence score (the API/telemetry-friendly form); internally the
platform always carries the full SE(3) ``Pose`` so downstream consumers
never lose precision or accumulate ambiguity re-deriving Euler angles.
"""

from __future__ import annotations

from dataclasses import dataclass

from roboforge.core.transforms import Pose
from roboforge.perception.cameras.camera import Camera, CameraFrame
from roboforge.perception.vision.object_detector import Detection, ObjectDetector


@dataclass
class ObjectPose:
    object_id: str
    class_label: str
    pose_world: Pose
    confidence: float

    def as_xyzrpy_dict(self) -> dict:
        x, y, z, r, p, yaw = self.pose_world.as_xyzrpy()
        return {"x": x, "y": y, "z": z, "roll": r, "pitch": p, "yaw": yaw, "confidence": self.confidence}


class PoseEstimator:
    """Combines a camera, a detector, and the camera's resolved world
    pose to produce object poses directly usable by the motion planner
    (section 13: "The motion planner should directly consume this
    pose.").
    """

    def __init__(self, camera: Camera, detector: ObjectDetector) -> None:
        self.camera = camera
        self.detector = detector

    def estimate_all(self, mount_pose_world: Pose | None = None) -> list[ObjectPose]:
        frame: CameraFrame = self.camera.capture(mount_pose_world)
        detections: list[Detection] = self.detector.detect(frame, self.camera)
        results = []
        for d in detections:
            pose_world = frame.camera_pose_world.compose(d.pose_camera_frame)
            pose_world.frame = "world"
            results.append(
                ObjectPose(object_id=d.object_id, class_label=d.class_label, pose_world=pose_world, confidence=d.confidence)
            )
        return results

    def detect_pose(self, object_id: str, mount_pose_world: Pose | None = None) -> ObjectPose | None:
        """Section 13 API: ``perception.detect_pose(object_id="component_42")``."""
        for p in self.estimate_all(mount_pose_world):
            if p.object_id == object_id:
                return p
        return None
