"""6D object pose estimation: transforms detections from the camera frame
into robot-usable world/base coordinates (section 13)."""

from roboforge.perception.pose.pose_estimator import ObjectPose, PoseEstimator

__all__ = ["ObjectPose", "PoseEstimator"]
