"""Visual servoing (section 14): closes the perception -> pose estimation
-> pose error -> controller -> robot motion -> camera loop, rather than
open-loop trajectory execution.

    Camera -> Object Detection -> Pose Estimation -> Pose Error
        -> Controller -> Robot Motion -> Camera (loop)

Two variants are provided:

* **Position-based visual servoing (PBVS)**: the pose error is computed
  in 3D task space (via ``PoseEstimator``) and tracked with the
  ``CartesianServoController`` -- accurate when calibration is good, but
  sensitive to calibration/pose-estimation error.
* **Image-based visual servoing (IBVS)**: the error is computed directly
  in image-feature (pixel) space and mapped to a Cartesian velocity via
  an interaction (image) Jacobian -- more robust to calibration error,
  at the cost of only converging within the image-space vicinity of the
  target view.

A ``hybrid`` mode runs PBVS for the coarse approach and switches to IBVS
for the final centring, combining PBVS's global convergence with IBVS's
local robustness.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

import numpy as np

from roboforge.core.transforms import Pose, Twist
from roboforge.motion.servo.cartesian_servo import CartesianServoController
from roboforge.perception.cameras.camera import Camera
from roboforge.perception.pose.pose_estimator import ObjectPose, PoseEstimator

if TYPE_CHECKING:
    from roboforge.robotics.robot import Robot


class VisualServoMode(str, Enum):
    POSITION_BASED = "position_based"
    IMAGE_BASED = "image_based"
    HYBRID = "hybrid"


@dataclass
class VisualServoStep:
    converged: bool
    position_error_m: float
    orientation_error_rad: float
    joint_velocity: np.ndarray
    mode_used: VisualServoMode


class VisualServoController:
    def __init__(
        self,
        robot: "Robot",
        pose_estimator: PoseEstimator,
        position_tolerance_m: float = 0.0005,
        orientation_tolerance_rad: float = 0.005,
        ibvs_switch_distance_m: float = 0.03,
        gain: float = 1.5,
    ) -> None:
        self.robot = robot
        self.pose_estimator = pose_estimator
        self.servo = CartesianServoController(robot, position_gain=gain, orientation_gain=gain)
        self.position_tolerance_m = position_tolerance_m
        self.orientation_tolerance_rad = orientation_tolerance_rad
        self.ibvs_switch_distance_m = ibvs_switch_distance_m

    def _pbvs_command(self, target_pose: Pose) -> tuple[np.ndarray, float, float]:
        qd, twist = self.servo.track_pose(target_pose)
        current = self.robot.forward_kinematics()
        pos_err = current.distance_to(target_pose)
        rot_err = current.angular_distance_to(target_pose)
        return qd, pos_err, rot_err

    def _ibvs_command(self, target_pose: Pose, camera: Camera) -> tuple[np.ndarray, float, float]:
        """A simplified image-based servo: project the current and target
        object positions into the camera's image plane and drive their
        pixel-space difference to zero via a Cartesian velocity aligned
        with the camera's viewing frame (a standard reduced-order IBVS
        used when only position, not full 6-DOF feature Jacobians, is
        needed for centring).
        """
        camera_pose = camera.resolve_world_pose(self.robot.forward_kinematics())
        current_pose = self.robot.forward_kinematics()

        target_cam = target_pose.relative_to(camera_pose)
        current_cam = current_pose.relative_to(camera_pose)

        u_t, v_t = camera.intrinsics.project(target_cam.position)
        u_c, v_c = camera.intrinsics.project(current_cam.position)
        pixel_error = np.array([u_t - u_c, v_t - v_c])

        depth = max(current_cam.position[2], 1e-3)
        # Interaction-matrix-inspired mapping from pixel error back to a
        # camera-frame lateral velocity command (image Jacobian for a pure
        # translation model: du/dX = fx/Z, dv/dY = fy/Z).
        vx_cam = pixel_error[0] * depth / camera.intrinsics.fx
        vy_cam = pixel_error[1] * depth / camera.intrinsics.fy
        vz_cam = target_cam.position[2] - current_cam.position[2]

        linear_cam = np.array([vx_cam, vy_cam, vz_cam]) * 1.0
        linear_world = camera_pose.rotation @ linear_cam

        twist = Twist(linear=linear_world, angular=np.zeros(3))
        qd = self.servo.twist_to_joint_velocity(twist)

        pos_err = current_pose.distance_to(target_pose)
        rot_err = current_pose.angular_distance_to(target_pose)
        return qd, pos_err, rot_err

    def step(
        self,
        object_id: str,
        grasp_offset: Pose | None = None,
        camera: Camera | None = None,
        mode: VisualServoMode = VisualServoMode.HYBRID,
    ) -> VisualServoStep:
        """Run one visual-servoing control cycle: re-detect the object,
        recompute the target pose, and produce a joint-velocity command."""
        observed = self.pose_estimator.detect_pose(object_id, self.robot.forward_kinematics())
        if observed is None:
            return VisualServoStep(False, float("inf"), float("inf"), np.zeros(self.robot.dof), mode)

        target_pose = observed.pose_world if grasp_offset is None else observed.pose_world.compose(grasp_offset)

        use_ibvs = mode == VisualServoMode.IMAGE_BASED
        if mode == VisualServoMode.HYBRID and camera is not None:
            current = self.robot.forward_kinematics()
            use_ibvs = current.distance_to(target_pose) < self.ibvs_switch_distance_m

        if use_ibvs and camera is not None:
            qd, pos_err, rot_err = self._ibvs_command(target_pose, camera)
            mode_used = VisualServoMode.IMAGE_BASED
        else:
            qd, pos_err, rot_err = self._pbvs_command(target_pose)
            mode_used = VisualServoMode.POSITION_BASED

        converged = pos_err <= self.position_tolerance_m and rot_err <= self.orientation_tolerance_rad
        return VisualServoStep(converged, pos_err, rot_err, qd, mode_used)
