"""A deterministic simulated camera (section 27): rather than rendering
pixels, it maintains a small scene of known objects and reports which are
within the camera's field of view/range at capture time, for the
simulated object detector to consume. This keeps the full
sense -> detect -> estimate-pose -> plan -> move loop exercisable without
any physical (or rendered) imagery.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field

import numpy as np

from roboforge.core.transforms import Pose
from roboforge.perception.cameras.camera import Camera, CameraExtrinsics, CameraFrame, CameraIntrinsics


@dataclass
class SimulatedSceneObject:
    object_id: str
    class_label: str
    pose_world: Pose
    size_m: float = 0.03


class SimulatedCamera(Camera):
    def __init__(
        self,
        name: str,
        intrinsics: CameraIntrinsics,
        extrinsics: CameraExtrinsics,
        scene_objects: list[SimulatedSceneObject] | None = None,
        max_range_m: float = 1.2,
        fov_half_angle_rad: float = 0.6,
    ) -> None:
        super().__init__(name, intrinsics, extrinsics)
        self.scene_objects: dict[str, SimulatedSceneObject] = {
            o.object_id: o for o in (scene_objects or [])
        }
        self.max_range_m = max_range_m
        self.fov_half_angle_rad = fov_half_angle_rad

    def add_object(self, obj: SimulatedSceneObject) -> None:
        self.scene_objects[obj.object_id] = obj

    def remove_object(self, object_id: str) -> None:
        self.scene_objects.pop(object_id, None)

    def capture(self, mount_pose_world: Pose | None = None) -> CameraFrame:
        camera_pose = self.resolve_world_pose(mount_pose_world)
        visible_ids = []
        for obj in self.scene_objects.values():
            relative = obj.pose_world.relative_to(camera_pose)
            distance = float(np.linalg.norm(relative.position))
            if distance > self.max_range_m or relative.position[2] <= 0:
                continue
            angle = float(np.arccos(np.clip(relative.position[2] / max(distance, 1e-9), -1.0, 1.0)))
            if angle > self.fov_half_angle_rad:
                continue
            visible_ids.append(obj.object_id)
        return CameraFrame(
            timestamp=time.time(),
            intrinsics=self.intrinsics,
            camera_pose_world=camera_pose,
            metadata={"visible_object_ids": visible_ids},
        )
