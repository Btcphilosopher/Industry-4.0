"""Camera model: intrinsics, extrinsics, and the abstract capture
interface implemented by both simulated and (future) real camera
drivers."""

from __future__ import annotations

import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum

import numpy as np

from roboforge.core.transforms import Pose


class MountingKind(str, Enum):
    EYE_IN_HAND = "eye_in_hand"
    EYE_TO_HAND = "eye_to_hand"


@dataclass
class CameraIntrinsics:
    fx: float
    fy: float
    cx: float
    cy: float
    width: int
    height: int

    def as_matrix(self) -> np.ndarray:
        return np.array([[self.fx, 0, self.cx], [0, self.fy, self.cy], [0, 0, 1]])

    def project(self, point_camera_frame: np.ndarray) -> tuple[float, float]:
        x, y, z = point_camera_frame
        if z <= 1e-9:
            raise ValueError("Point is behind or at the camera plane")
        u = self.fx * (x / z) + self.cx
        v = self.fy * (y / z) + self.cy
        return u, v


@dataclass
class CameraExtrinsics:
    """The camera's pose relative to its mounting reference frame:
    the robot flange for eye-in-hand, or the world/robot base for
    eye-to-hand (section 15)."""

    pose: Pose
    mounting: MountingKind
    parent_frame: str = "world"


@dataclass
class CameraFrame:
    timestamp: float
    intrinsics: CameraIntrinsics
    camera_pose_world: Pose  # resolved world pose at capture time
    metadata: dict = field(default_factory=dict)


class Camera(ABC):
    """Abstract camera: capture() must return a ``CameraFrame`` and the
    detections available in it are produced by a paired
    ``ObjectDetector``."""

    def __init__(self, name: str, intrinsics: CameraIntrinsics, extrinsics: CameraExtrinsics) -> None:
        self.name = name
        self.intrinsics = intrinsics
        self.extrinsics = extrinsics

    @abstractmethod
    def capture(self, mount_pose_world: Pose | None = None) -> CameraFrame:
        """Capture a frame. ``mount_pose_world`` is required for
        eye-in-hand cameras (the current flange pose)."""

    def resolve_world_pose(self, mount_pose_world: Pose | None) -> Pose:
        if self.extrinsics.mounting == MountingKind.EYE_IN_HAND:
            if mount_pose_world is None:
                raise ValueError("eye_in_hand camera requires the current flange pose to resolve world pose")
            return mount_pose_world.compose(self.extrinsics.pose)
        return self.extrinsics.pose
