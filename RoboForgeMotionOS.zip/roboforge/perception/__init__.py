"""Perception: cameras, object detection, 6D pose estimation, and
tracking (sections 13-14, 27)."""
