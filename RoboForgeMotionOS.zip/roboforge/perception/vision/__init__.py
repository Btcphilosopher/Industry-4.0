"""Object detection."""

from roboforge.perception.vision.object_detector import Detection, ObjectDetector, SimulatedObjectDetector

__all__ = ["Detection", "ObjectDetector", "SimulatedObjectDetector"]
