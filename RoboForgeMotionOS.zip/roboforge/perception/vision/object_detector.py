"""Object detection interfaces (section 13-14).

Detections carry a noisy pose estimate *in the camera frame* -- turning
that into a robot-usable world/base-frame pose is the job of
``roboforge.perception.pose.PoseEstimator``, which applies the explicit
World -> Camera -> Object transform chain (section 15).
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass

import numpy as np

from roboforge.core.transforms import Pose
from roboforge.perception.cameras.camera import Camera, CameraFrame
from roboforge.perception.cameras.simulated_camera import SimulatedCamera


@dataclass
class Detection:
    object_id: str
    class_label: str
    pose_camera_frame: Pose
    confidence: float


class ObjectDetector(ABC):
    @abstractmethod
    def detect(self, frame: CameraFrame, camera: Camera) -> list[Detection]:
        ...


class SimulatedObjectDetector(ObjectDetector):
    """Produces detections directly from a ``SimulatedCamera``'s known
    scene, adding configurable Gaussian pose noise and a
    distance-dependent confidence score -- a stand-in for a learned
    detector + 6D pose network without requiring one to be trained/run.
    """

    def __init__(
        self,
        position_noise_std_m: float = 0.001,
        orientation_noise_std_rad: float = 0.005,
        rng: np.random.Generator | None = None,
    ) -> None:
        self.position_noise_std_m = position_noise_std_m
        self.orientation_noise_std_rad = orientation_noise_std_rad
        self.rng = rng or np.random.default_rng()

    def detect(self, frame: CameraFrame, camera: Camera) -> list[Detection]:
        if not isinstance(camera, SimulatedCamera):
            raise TypeError("SimulatedObjectDetector requires a SimulatedCamera")

        detections: list[Detection] = []
        visible_ids = frame.metadata.get("visible_object_ids", [])
        for object_id in visible_ids:
            scene_obj = camera.scene_objects[object_id]
            pose_camera = scene_obj.pose_world.relative_to(frame.camera_pose_world)

            noisy_position = pose_camera.position + self.rng.normal(0, self.position_noise_std_m, size=3)
            noise_rotvec = self.rng.normal(0, self.orientation_noise_std_rad, size=3)
            from roboforge.core.transforms import axis_angle_to_rotation_matrix

            angle = float(np.linalg.norm(noise_rotvec))
            noise_R = (
                axis_angle_to_rotation_matrix(noise_rotvec / angle, angle) if angle > 1e-12 else np.eye(3)
            )
            noisy_rotation = noise_R @ pose_camera.rotation

            distance = float(np.linalg.norm(pose_camera.position))
            confidence = float(np.clip(1.0 - distance / (camera.max_range_m * 1.2), 0.05, 0.99))

            detections.append(
                Detection(
                    object_id=object_id,
                    class_label=scene_obj.class_label,
                    pose_camera_frame=Pose(noisy_position, noisy_rotation, frame=camera.name),
                    confidence=confidence,
                )
            )
        return detections
