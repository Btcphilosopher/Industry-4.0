# RoboForge Motion.OS

**An industrial robotic-arm precision motion & manipulation platform.**

RoboForge Motion.OS is a modular robotics software platform for industrial
robotic arms, precision manipulators, and coordinated multi-arm
manipulation — articulated, SCARA, delta, Cartesian/gantry, and custom
n-DOF kinematic chains. It is **not** a humanoid robotics platform: there
is no walking, leg, balance, or bipedal-locomotion code anywhere in this
tree. Every subsystem is organised around one loop:

```
SENSE -> LOCALISE -> PLAN -> VALIDATE -> MOVE -> MANIPULATE -> MEASURE -> CORRECT
```

## What's actually implemented here

This is a real, working Python codebase, not a collection of pseudocode
stubs. Every module listed below contains genuine algorithms:

- **Kinematics** (`robotics/kinematics/`): forward kinematics over
  arbitrary-DOF Denavit-Hartenberg chains, damped-least-squares /
  Jacobian-transpose / pseudoinverse inverse kinematics with null-space
  redundancy resolution for 7+ DOF arms, a full Jacobian engine, and
  singularity/manipulability analysis (Yoshikawa index, SVD-based
  condition number).
- **Dynamics** (`robotics/dynamics/`): a recursive Newton-Euler inverse
  dynamics engine (world-frame formulation, gravity via the D'Alembert
  trick, payload handling) and a mass/Coriolis/gravity decomposition
  (`DynamicsModel`) built on it, including a Jacobian/kinetic-energy mass
  matrix formulation that is symmetric and positive-definite by
  construction.
- **Motion** (`motion/`): quintic and trapezoidal time-scaling profiles,
  joint-space and Cartesian (linear/circular/spline/Bezier) trajectory
  generation, RRT / RRT* / PRM sampling-based motion planning with
  shortcut-smoothing, a `MotionPlanner` that compares candidate
  trajectories against a stated objective (minimum time / distance /
  energy / jerk / wear / precision / clearance), trajectory optimisation
  via time-scale search, Cartesian velocity servoing with
  singularity-aware damping, and a micro-motion engine (spiral/raster
  search, approach, fine alignment).
- **Manipulation** (`manipulation/`): heuristic grasp generation/scoring
  for box and cylinder primitives, force/impedance/admittance/hybrid
  position-force control, a contact-rich insertion controller (search ->
  align -> force-guided insert), a robot-to-robot handoff state machine
  that fails safely, and gripper/tool-changer control.
- **Perception** (`perception/`): a deterministic simulated camera +
  detector + 6D pose estimator (full `World -> Camera -> Object`
  transform chain), an object tracker, and position-based / image-based /
  hybrid visual servoing that closes the loop through the Cartesian
  servo.
- **Calibration** (`calibration/`): ISO-9283-style repeatability/accuracy
  measurement, hand-eye calibration (`AX = XB`, Park & Martin's
  closed-form solve), N-point TCP pivot calibration, and camera
  intrinsic/extrinsic calibration via Direct Linear Transform + RQ
  decomposition.
- **Collision** (`collision/`): capsule/box/sphere primitive distance
  queries, self-collision and environment-collision checking with
  configurable safety margins, exposed as a planner-ready
  `q -> bool` checker.
- **Sensors & state estimation** (`sensors/`, `state_estimation/`):
  simulated encoders/F-T sensors/proximity sensors with realistic
  noise/quantisation, a linear Kalman filter, an EKF and a UKF, and a
  `RobotStateEstimator` that fuses them into a `RobotState`.
- **Simulation & digital twin** (`simulation/`, `digital_twin/`): joint-space
  dynamics integration, a penalty-based peg-in-hole contact model,
  deterministic trajectory playback, and a twin registry that tracks
  simulated/real/planned state per robot for comparison.
- **Drivers** (`drivers/`): a strongly-typed command model (`MoveJoint`,
  `MoveCartesian`, `SetForce`, ...), a `RobotDriver` interface, a full
  `SimulationDriver` implementation, and a `GenericIndustrialDriver`
  skeleton that shows exactly where a vendor's wire protocol plugs in
  (it fails honestly with `DriverConnectionError` rather than faking a
  connection, since no real controller is bundled with this platform).
- **Coordination** (`coordination/`): workspace reservation, robot-robot
  collision prediction, shared-object ownership, and trajectory
  synchronisation for multi-arm cells.
- **Safety** (`safety/`): an explicit motion state machine, independent
  joint/velocity/acceleration/workspace limit checks, a communication
  watchdog, and trajectory validation — deliberately kept independent of
  the optimisation/planning layers so nothing can bypass it. **This is a
  software safety layer; it does not replace a certified safety PLC,
  e-stop circuit, light curtain, or the manufacturer's own safety
  controller.**
- **Telemetry & events** (`telemetry/`, `events/`): a bounded ring-buffer
  telemetry recorder, precision-analytics reporting, and a typed
  pub/sub event bus.
- **Configuration & storage** (`configuration/`, `storage/`): a Pydantic
  schema that validates every robot config before a `Robot` is built, and
  SQLAlchemy models for robots/calibration/trajectories/events/users.
- **API & CLI** (`api/`, `cli/`): a FastAPI service with role-based
  authentication/authorisation and audit logging, and a `roboforge`
  Typer CLI covering robot control, planning, simulation, calibration,
  diagnostics, and precision testing.
- **Tests, demo, benchmark** (`roboforge/tests/`, `demo/`, `benchmark/`):
  98 pytest tests across every subsystem above, a full simulated
  precision pick-insert-place demonstration, and a benchmarking suite
  measuring IK/collision/servo/simulation latency and precision figures.

## What's honestly out of scope

- No real hardware driver ships with this platform (`GenericIndustrialDriver`
  is a protocol-agnostic skeleton, not a working driver for any specific
  vendor's controller) — connecting to real hardware requires a concrete
  subclass speaking that controller's actual wire protocol.
- No hard real-time guarantee: Python handles planning, simulation, and
  supervision; a hard real-time servo loop belongs in the robot
  controller/driver layer, not in this codebase (section 29 of the
  design brief this platform implements).
- No AI supervisory layer is enabled by default. The architecture leaves
  room for one (`plugins/`, `roboforge.core.enums.Role`), but it would be
  strictly advisory — it can never bypass `safety/`.

## Quick start

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# Run the test suite
pytest roboforge/tests -q

# Run the full precision-manipulation demonstration
python -m roboforge.demo.precision_manipulation_demo

# Run the benchmark suite
python -m roboforge.benchmark.benchmark_suite

# Start the API (http://127.0.0.1:8000/docs)
uvicorn roboforge.api.main:app --reload

# Use the CLI
python -m roboforge.cli.main robot list
python -m roboforge.cli.main diagnostics
python -m roboforge.cli.main precision test --repeats 20
```

Demo API tokens (replace before any real deployment):
`demo-operator-token`, `demo-admin-token`, `demo-readonly-token`
(sent as the `X-API-Key` header).

## Architecture

```
                    ROBOFORGE MOTION.OS
                            |
             +--------------+--------------+
             |                             |
        PERCEPTION                     ROBOT STATE
             |                             |
             +--------------+--------------+
                            |
                     STATE ESTIMATION
                            |
                            v
                    WORLD / OBJECT MODEL
                            |
                            v
                     MOTION PLANNER
                            |
                +-----------+-----------+
                |           |           |
             IK/JACOBIAN  COLLISION   DYNAMICS
                |           |           |
                +-----------+-----------+
                            |
                            v
                    TRAJECTORY ENGINE
                            |
                            v
                    MOTION CONTROLLER
                            |
                 +----------+----------+
                 |                     |
            REAL ROBOT             SIMULATION
                 |                     |
                 +----------+----------+
                            |
                            v
                    FORCE / VISION
                      FEEDBACK LOOP
                            |
                            v
                    VERIFY / CORRECT
```

## Repository layout

```
roboforge/
  core/            SE(3) transforms, enums, exceptions
  robotics/        Robot/Joint/Link/Tool models, kinematics, dynamics, state
  motion/          Trajectory generation, planning, optimisation, servo, micro-motion
  manipulation/    Grasping, force/impedance control, insertion, handoff, tools
  perception/      Cameras, object detection, pose estimation, tracking, visual servoing
  calibration/     Robot, camera, hand-eye, TCP calibration
  collision/       Capsule/box/sphere collision engine
  sensors/         Simulated encoders, F/T sensors, proximity sensors
  state_estimation/  Kalman/EKF/UKF filtering
  simulation/      Physics engine, contact models, simulated robot
  digital_twin/    Sim/real/planned state registry
  drivers/         Command model, RobotDriver interface, simulation + generic drivers
  coordination/    Multi-robot workspace reservation & collision prediction
  safety/          Motion state machine, limits, watchdog
  telemetry/       Telemetry recorder, precision metrics
  events/          Typed event bus
  api/             FastAPI service
  cli/             Typer CLI
  configuration/   Pydantic config schema + YAML loader + example robot
  storage/         SQLAlchemy models
  plugins/         Extension-point registry
  demo/            Precision-manipulation demonstration
  benchmark/       Benchmark suite
  tests/           Pytest suite (98 tests)
```

## Technology stack

Python 3.10+, NumPy, SciPy, Pydantic v2, FastAPI, SQLAlchemy 2.0, PyYAML,
Typer, pytest. No single third-party robotics framework is load-bearing
for the core architecture.
