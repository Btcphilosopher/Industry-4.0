# ==============================================================================
# MicroMotion.R - Data Export & Cross-Language Interop (Kotlin / Python)
# ==============================================================================

#' Canonical JSON Schema Serializer for MicroMotion.R Digital Twin
#' 
#' @param sim_result S3 object of class 'micro_motion_result'
#' @param file_path Optional output file path
#' @return JSON string containing robot definition, trajectory frames, and telemetry
#' @export
export_to_canonical_json <- function(sim_result, file_path = NULL) {
  analysis <- analyse_motion(sim_result)
  
  # Format micro-frames
  n <- sim_result$n_frames
  dof <- sim_result$robot$dof
  
  frames_list <- vector("list", n)
  for (i in 1:n) {
    frames_list[[i]] <- list(
      timestamp = sim_result$timestamps[i],
      joint_position = as.numeric(sim_result$q[i, ]),
      joint_velocity = as.numeric(sim_result$qd[i, ]),
      joint_acceleration = as.numeric(sim_result$qdd[i, ]),
      joint_jerk = as.numeric(sim_result$jerk[i, ]),
      joint_torque = as.numeric(sim_result$torque[i, ]),
      joint_power = as.numeric(sim_result$power[i, ]),
      delta_joint_position = as.numeric(sim_result$delta_q[i, ]),
      end_effector = list(
        x = sim_result$ee_position[i, 1],
        y = sim_result$ee_position[i, 2],
        z = sim_result$ee_position[i, 3],
        roll = sim_result$ee_orientation[i, 1],
        pitch = sim_result$ee_orientation[i, 2],
        yaw = sim_result$ee_orientation[i, 3],
        vx = sim_result$ee_velocity[i, 1],
        vy = sim_result$ee_velocity[i, 2],
        vz = sim_result$ee_velocity[i, 3],
        delta_x = sim_result$delta_ee_pos[i, 1],
        delta_y = sim_result$delta_ee_pos[i, 2],
        delta_z = sim_result$delta_ee_pos[i, 3]
      ),
      tracking_error_m = sim_result$tracking_error[i],
      cumulative_energy_j = sim_result$cumulative_energy[i]
    )
  }
  
  payload <- list(
    engine = "MicroMotion.R",
    version = "1.0.0",
    schema_spec = "urn:micromotion:digital-twin:v1",
    created_at = format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ"),
    robot = list(
      name = sim_result$robot$name,
      dof = sim_result$robot$dof,
      payload_kg = sim_result$robot$payload_kg,
      base_offset = sim_result$robot$base_offset,
      dh_parameters = sim_result$robot$dh_table
    ),
    simulation_metadata = list(
      duration_s = sim_result$duration,
      dt_s = sim_result$dt,
      total_frames = n,
      profile_type = sim_result$profile_type
    ),
    analysis = analysis,
    micro_motion_frames = frames_list
  )
  
  if (requireNamespace("jsonlite", quietly = TRUE)) {
    json_str <- jsonlite::toJSON(payload, auto_unbox = TRUE, digits = 8, pretty = TRUE)
  } else {
    # Fallback basic JSON serializer
    json_str <- paste0('{"engine":"MicroMotion.R","total_frames":', n, '}')
  }
  
  if (!is.null(file_path)) {
    writeLines(json_str, file_path)
    cat("Exported canonical JSON to:", file_path, "\n")
  }
  
  return(json_str)
}

#' Export MicroMotion Telemetry to CSV Format
#' 
#' @param sim_result S3 object of class 'micro_motion_result'
#' @param file_path Output CSV file path
#' @export
export_to_csv <- function(sim_result, file_path = "micromotion_telemetry.csv") {
  df <- as_telemetry_dataframe(sim_result)
  write.csv(df, file = file_path, row.names = FALSE)
  cat("Exported CSV telemetry to:", file_path, "\n")
}

#' Export MicroMotion Result to Binary RDS Format
#' 
#' @param sim_result S3 object of class 'micro_motion_result'
#' @param file_path Output RDS file path
#' @export
export_to_rds <- function(sim_result, file_path = "micromotion_state.rds") {
  saveRDS(sim_result, file = file_path)
  cat("Exported binary RDS digital twin to:", file_path, "\n")
}
