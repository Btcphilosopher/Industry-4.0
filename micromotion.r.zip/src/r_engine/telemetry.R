# ==============================================================================
# MicroMotion.R - Telemetry, Diagnostics & Analysis Engine
# ==============================================================================

#' Convert Micro-Motion Simulation into a Structured Data Frame / Table
#' 
#' @param sim_result S3 object of class 'micro_motion_result'
#' @return data.frame with complete joint and Cartesian time series
#' @export
as_telemetry_dataframe <- function(sim_result) {
  dof <- sim_result$robot$dof
  n <- sim_result$n_frames
  
  df <- data.frame(
    timestamp = sim_result$timestamps,
    ee_x = sim_result$ee_position[, 1],
    ee_y = sim_result$ee_position[, 2],
    ee_z = sim_result$ee_position[, 3],
    ee_roll = sim_result$ee_orientation[, 1],
    ee_pitch = sim_result$ee_orientation[, 2],
    ee_yaw = sim_result$ee_orientation[, 3],
    ee_vx = sim_result$ee_velocity[, 1],
    ee_vy = sim_result$ee_velocity[, 2],
    ee_vz = sim_result$ee_velocity[, 3],
    tracking_error_m = sim_result$tracking_error,
    delta_energy_j = sim_result$delta_energy,
    cum_energy_j = sim_result$cumulative_energy
  )
  
  # Append each joint's position, velocity, acceleration, jerk, torque, power
  for (j in 1:dof) {
    df[[paste0("J", j, "_pos_rad")]]   <- sim_result$q[, j]
    df[[paste0("J", j, "_vel_rad_s")]] <- sim_result$qd[, j]
    df[[paste0("J", j, "_acc_rad_s2")]]<- sim_result$qdd[, j]
    df[[paste0("J", j, "_jerk_rad_s3")]]<- sim_result$jerk[, j]
    df[[paste0("J", j, "_torque_nm")]]  <- sim_result$torque[, j]
    df[[paste0("J", j, "_power_w")]]   <- sim_result$power[, j]
    df[[paste0("J", j, "_delta_pos")]] <- sim_result$delta_q[, j]
  }
  
  return(df)
}

#' Deep Telemetry Analysis: Extract Hotspots and Peak Kinematic/Dynamic Metrics
#' 
#' @param sim_result S3 object of class 'micro_motion_result'
#' @return List containing maximum jerk, torque, energy hotspots, tracking error
#' @export
analyse_motion <- function(sim_result) {
  dof <- sim_result$robot$dof
  t <- sim_result$timestamps
  
  # Peak Jerk Hotspot
  abs_jerk <- abs(sim_result$jerk)
  max_jerk_val <- max(abs_jerk)
  max_jerk_idx <- which(abs_jerk == max_jerk_val, arr.ind = TRUE)[1, ]
  jerk_joint <- paste0("J", max_jerk_idx[2])
  jerk_time <- t[max_jerk_idx[1]]
  
  # Peak Torque Hotspot
  abs_torque <- abs(sim_result$torque)
  max_torque_val <- max(abs_torque)
  max_torque_idx <- which(abs_torque == max_torque_val, arr.ind = TRUE)[1, ]
  torque_joint <- paste0("J", max_torque_idx[2])
  torque_time <- t[max_torque_idx[1]]
  
  # Peak Tracking Error Hotspot
  max_err_val <- max(sim_result$tracking_error)
  max_err_idx <- which.max(sim_result$tracking_error)
  err_time <- t[max_err_idx]
  
  # Energy Hotspots (Which joint consumed the most energy)
  dt <- sim_result$dt
  joint_total_energy <- colSums(pmax(0, sim_result$power)) * dt
  names(joint_total_energy) <- paste0("J", 1:dof)
  highest_energy_joint <- names(which.max(joint_total_energy))
  
  # Identify phase of highest power consumption
  power_sum_time <- rowSums(pmax(0, sim_result$power))
  peak_power_time <- t[which.max(power_sum_time)]
  
  phase_desc <- if (peak_power_time < sim_result$duration * 0.35) {
    "Initial Acceleration & Inertial Loading Phase"
  } else if (peak_power_time > sim_result$duration * 0.65) {
    "Deceleration & Kinetic Dissipation Phase"
  } else {
    "Mid-Cruise Dynamic Couplings Phase"
  }
  
  analysis_report <- list(
    total_duration_s = sim_result$duration,
    microstates_count = sim_result$n_frames,
    dt_ms = sim_result$dt * 1000,
    max_jerk = list(
      value_rad_s3 = max_jerk_val,
      joint = jerk_joint,
      timestamp_s = jerk_time
    ),
    max_torque = list(
      value_nm = max_torque_val,
      joint = torque_joint,
      timestamp_s = torque_time
    ),
    max_tracking_error = list(
      value_m = max_err_val,
      value_um = max_err_val * 1e6, # Microns
      timestamp_s = err_time
    ),
    energy_analysis = list(
      total_energy_j = sim_result$total_energy_joules,
      highest_energy_joint = highest_energy_joint,
      joint_energy_breakdown_j = joint_total_energy,
      peak_power_timestamp_s = peak_power_time,
      hotspot_phase = phase_desc
    ),
    micro_corrections_applied = sim_result$micro_corrections_count,
    constraint_status = if(length(sim_result$constraint_violations) == 0) "PASSED_ALL_CONSTRAINTS" else "VIOLATIONS_DETECTED"
  )
  
  return(analysis_report)
}

#' Replay Motion at Specified Micro-Time Index or Sub-Stepping Rate
#' 
#' @param sim_result S3 object of class 'micro_motion_result'
#' @param frame_index Integer index of the microstate (1 to n_frames)
#' @return S3 object representing single MicroMotionFrame
#' @export
replay_microstate <- function(sim_result, frame_index) {
  idx <- max(1, min(sim_result$n_frames, frame_index))
  
  list(
    frame_index = idx,
    timestamp = sim_result$timestamps[idx],
    joint_positions = sim_result$q[idx, ],
    joint_velocities = sim_result$qd[idx, ],
    joint_accelerations = sim_result$qdd[idx, ],
    joint_jerks = sim_result$jerk[idx, ],
    joint_torques = sim_result$torque[idx, ],
    joint_powers = sim_result$power[idx, ],
    delta_joint_positions = sim_result$delta_q[idx, ],
    ee_position = sim_result$ee_position[idx, ],
    ee_velocity = sim_result$ee_velocity[idx, ],
    ee_orientation = sim_result$ee_orientation[idx, ],
    delta_ee_position = sim_result$delta_ee_pos[idx, ],
    tracking_error = sim_result$tracking_error[idx],
    instantaneous_power = sum(sim_result$power[idx, ]),
    cumulative_energy = sim_result$cumulative_energy[idx]
  )
}
