# ==============================================================================
# MicroMotion.R - Dynamics, Torque, & Multibody Engineering Model
# ==============================================================================

#' Approximate Multibody Dynamics and Actuator Torque Model
#' Tau = M(q)*q_ddot + C(q, q_dot)*q_dot + G(q) + F_v*q_dot + F_s*sign(q_dot)
#' 
#' @param robot S3 object of class 'micro_robot'
#' @param q Joint positions vector (rad)
#' @param qd Joint velocities vector (rad/s)
#' @param qdd Joint accelerations vector (rad/s^2)
#' @return Named numeric vector of torques for each joint (N*m)
#' @export
calculate_torque <- function(robot, q, qd, qdd) {
  dof <- robot$dof
  dh <- robot$dh_table
  g <- -robot$gravity[3] # 9.81 m/s^2
  payload <- robot$payload_kg
  
  # Approximate Link Effective Masses and Inertias reflected at joints
  # Gravity Torques G(q)
  tau_g <- numeric(dof)
  
  # Forward kinematics cumulative link positions
  fk <- forward_kinematics(robot, q)
  link_positions <- fk$joint_positions
  
  # Simplified iterative gravity torques from end to base
  total_force_down <- 0
  for (i in dof:1) {
    link_m <- dh$mass[i] + (if (i == dof) payload else 0)
    total_force_down <- total_force_down + link_m * g
    
    # Moment arm in XY plane relative to joint axis
    r_arm <- if (i > 1) {
      sqrt((fk$ee_position[1] - link_positions[i, 1])^2 + (fk$ee_position[2] - link_positions[i, 2])^2)
    } else {
      0.05 # Small base offset
    }
    
    # Cosine/sine projection depending on joint orientation
    if (i %in% c(2, 3)) {
      # Shoulder and elbow lift primarily oppose gravity
      tau_g[i] <- total_force_down * r_arm * cos(q[2] + (if(i == 3) q[3] else 0))
    } else if (i == 4) {
      tau_g[i] <- (dh$mass[4] + payload) * g * 0.15 * sin(q[4])
    } else {
      tau_g[i] <- 0.1 * total_force_down * sin(q[i])
    }
  }
  
  # Inertial Torques M(q)*qdd
  tau_inertia <- numeric(dof)
  for (i in 1:dof) {
    # Reflected inertia includes motor rotor + link + gear ratio squared
    link_inertia <- dh$inertia_zz[i] + (if (i == dof) payload * 0.05^2 else 0)
    total_inertia <- link_inertia + (dh$gear_ratio[i]^2 * 0.0001)
    tau_inertia[i] <- total_inertia * qdd[i]
  }
  
  # Coriolis and Centrifugal Torques C(q, qd)*qd
  tau_coriolis <- numeric(dof)
  for (i in 1:dof) {
    # Coupled velocity effect
    cross_speed <- if (i < dof) qd[i] * qd[i+1] else qd[i]^2
    tau_coriolis[i] <- 0.05 * dh$mass[i] * cross_speed
  }
  
  # Friction Model: Viscous (F_v * qd) + Coulomb (F_s * sgn(qd))
  tau_friction <- numeric(dof)
  f_viscous <- 0.8
  f_coulomb <- 1.5
  for (i in 1:dof) {
    tau_friction[i] <- (f_viscous * qd[i]) + (f_coulomb * tanh(qd[i] / 0.01))
  }
  
  # Total Joint Torques
  tau_total <- tau_inertia + tau_coriolis + tau_g + tau_friction
  
  # Clamp against maximum motor limits
  tau_clamped <- pmax(-dh$torque_max, pmin(dh$torque_max, tau_total))
  
  names(tau_clamped) <- paste0("J", 1:dof)
  return(tau_clamped)
}

#' Calculate Instantaneous Power and Energy per Joint
#' @param robot S3 object of class 'micro_robot'
#' @param tau Joint torques (N*m)
#' @param qd Joint angular velocities (rad/s)
#' @param dt Timestep duration in seconds
#' @return List containing mechanical power, electrical power, and delta energy (Joules)
#' @export
calculate_power_energy <- function(robot, tau, qd, dt) {
  dh <- robot$dh_table
  dof <- robot$dof
  
  # Mechanical Power: P_mech = tau * qd
  p_mech <- tau * qd
  
  # Electrical Power: P_elec = P_mech + I^2 * R + P_loss
  # Motor current: I = tau / (kt * gear_ratio)
  p_elec <- numeric(dof)
  for (i in 1:dof) {
    current_i <- abs(tau[i]) / (dh$kt[i] * dh$gear_ratio[i] + 1e-6)
    p_copper <- (current_i^2) * dh$motor_resistance[i]
    p_standby <- 3.5 # Watts controller standby per actuator
    
    # If motor is regenerating (negative mechanical power), efficiency factor 0.4
    if (p_mech[i] < 0) {
      p_elec[i] <- p_copper + p_standby + 0.6 * p_mech[i]
    } else {
      p_elec[i] <- p_mech[i] + p_copper + p_standby
    }
  }
  
  # Incremental Energy in Joules for this micro-motion timestep: dE = P * dt
  d_energy_mech <- sum(abs(p_mech)) * dt
  d_energy_elec <- sum(pmax(0, p_elec)) * dt
  
  return(list(
    p_mech = p_mech,
    p_elec = p_elec,
    p_total_elec = sum(p_elec),
    d_energy_mech = d_energy_mech,
    d_energy_elec = d_energy_elec
  ))
}
