# ==============================================================================
# MicroMotion.R - High-Resolution Robotic Arm Micro-Movement Engine
# Research-Grade Digital Twin & Trajectory Optimization System
# ==============================================================================
# (c) MicroMotion.R Computational Robotics Laboratory
# Architecture: R Core Simulation -> Kotlin Visualisation / Python Orchestration
# ==============================================================================

# S3 Class Constructors & Package Entrypoint

#' Initialize MicroMotion.R Environment
#' @export
micro_motion_init <- function() {
  cat("=================================================================\n")
  cat("  MicroMotion.R: Robotic Micro-Motion Engine & Digital Twin v1.0.0\n")
  cat("  Precision Sub-Millisecond Kinematic & Dynamic Simulator\n")
  cat("=================================================================\n")
}

#' Create Canonical 6-Axis Robot Specification
#' @param name Character name of robot model
#' @param payload_kg Payload mass in kilograms
#' @param base_offset 3D offset of base [x, y, z]
#' @return S3 object of class 'micro_robot'
#' @export
create_robot <- function(name = "MicroMotion-6DOF-Cobot", payload_kg = 2.5, base_offset = c(0, 0, 0)) {
  # Standard Denavit-Hartenberg (DH) parameters: theta, d, a, alpha
  # Links: [d (m), a (m), alpha (rad)]
  dh_table <- data.frame(
    joint = 1:6,
    name = paste0("Joint_", 1:6),
    d = c(0.1625, 0.0, 0.0, 0.1333, 0.0997, 0.0996),
    a = c(0.0, -0.4250, -0.3922, 0.0, 0.0, 0.0),
    alpha = c(pi/2, 0.0, 0.0, pi/2, -pi/2, 0.0),
    mass = c(3.7, 8.4, 4.3, 1.2, 1.2, 0.4), # kg
    com_z = c(0.08, 0.21, 0.19, 0.06, 0.05, 0.04), # Center of mass offset
    inertia_zz = c(0.010, 0.140, 0.080, 0.003, 0.003, 0.001), # kg*m^2
    q_min = c(-2*pi, -pi, -pi, -2*pi, -2*pi, -2*pi),
    q_max = c(2*pi, pi, pi, 2*pi, 2*pi, 2*pi),
    v_max = c(3.14, 3.14, 3.14, 6.28, 6.28, 6.28), # rad/s
    a_max = c(10.0, 10.0, 10.0, 20.0, 20.0, 20.0), # rad/s^2
    jerk_max = c(50.0, 50.0, 50.0, 100.0, 100.0, 100.0), # rad/s^3
    torque_max = c(150.0, 150.0, 150.0, 40.0, 40.0, 40.0), # N*m
    gear_ratio = c(101, 101, 101, 81, 81, 51),
    motor_resistance = c(1.2, 1.2, 1.2, 2.1, 2.1, 3.4), # Ohm
    kt = c(0.11, 0.11, 0.11, 0.08, 0.08, 0.05) # Torque constant Nm/A
  )
  
  robot <- list(
    name = name,
    dof = 6,
    payload_kg = payload_kg,
    base_offset = base_offset,
    dh_table = dh_table,
    gravity = c(0, 0, -9.80665),
    tolerance = 1e-5 # 10 micron threshold
  )
  
  class(robot) <- c("micro_robot", "list")
  return(robot)
}

#' Forward Kinematics (FK) for DH Model
#' @param robot S3 object of class 'micro_robot'
#' @param q Numeric vector of joint angles (rad)
#' @return List containing end-effector transformation matrix T and joint Cartesian positions
#' @export
forward_kinematics <- function(robot, q) {
  dof <- robot$dof
  dh <- robot$dh_table
  
  # Homogeneous transformation matrix builder
  dh_matrix <- function(theta, d, a, alpha) {
    matrix(c(
      cos(theta), -sin(theta)*cos(alpha),  sin(theta)*sin(alpha), a*cos(theta),
      sin(theta),  cos(theta)*cos(alpha), -cos(theta)*sin(alpha), a*sin(theta),
      0,           sin(alpha),             cos(alpha),            d,
      0,           0,                      0,                     1
    ), nrow = 4, byrow = TRUE)
  }
  
  # Base transformation
  T_curr <- diag(4)
  T_curr[1:3, 4] <- robot$base_offset
  
  joint_positions <- matrix(0, nrow = dof + 1, ncol = 3)
  joint_positions[1, ] <- T_curr[1:3, 4]
  
  T_list <- vector("list", dof)
  
  for (i in 1:dof) {
    theta_i <- q[i]
    T_i <- dh_matrix(theta_i, dh$d[i], dh$a[i], dh$alpha[i])
    T_curr <- T_curr %*% T_i
    T_list[[i]] <- T_curr
    joint_positions[i + 1, ] <- T_curr[1:3, 4]
  }
  
  # End effector position and Euler angles (Roll, Pitch, Yaw - ZYX convention)
  R <- T_curr[1:3, 1:3]
  pos <- T_curr[1:3, 4]
  
  # Extract Euler angles
  sy <- sqrt(R[1,1]^2 + R[2,1]^2)
  singular <- sy < 1e-6
  
  if (!singular) {
    roll  <- atan2(R[3,2], R[3,3])
    pitch <- atan2(-R[3,1], sy)
    yaw   <- atan2(R[2,1], R[1,1])
  } else {
    roll  <- atan2(-R[2,3], R[2,2])
    pitch <- atan2(-R[3,1], sy)
    yaw   <- 0
  }
  
  return(list(
    T_final = T_curr,
    T_list = T_list,
    joint_positions = joint_positions,
    ee_position = pos,
    orientation = c(roll = roll, pitch = pitch, yaw = yaw)
  ))
}

#' Geometric Jacobian Matrix Computation
#' @param robot S3 object of class 'micro_robot'
#' @param q Numeric vector of joint angles
#' @return 6xN Jacobian matrix [J_linear; J_angular]
#' @export
compute_jacobian <- function(robot, q) {
  dof <- robot$dof
  fk <- forward_kinematics(robot, q)
  p_e <- fk$ee_position
  
  J <- matrix(0, nrow = 6, ncol = dof)
  
  # Base frame
  z_prev <- c(0, 0, 1)
  p_prev <- robot$base_offset
  
  for (i in 1:dof) {
    if (i == 1) {
      z_i <- c(0, 0, 1)
      p_i <- robot$base_offset
    } else {
      T_prev <- fk$T_list[[i - 1]]
      z_i <- T_prev[1:3, 3]
      p_i <- T_prev[1:3, 4]
    }
    
    # Cross product z_i x (p_e - p_i) for linear velocity
    r <- p_e - p_i
    J_v <- c(
      z_i[2]*r[3] - z_i[3]*r[2],
      z_i[3]*r[1] - z_i[1]*r[3],
      z_i[1]*r[2] - z_i[2]*r[1]
    )
    J_w <- z_i
    
    J[1:3, i] <- J_v
    J[4:6, i] <- J_w
  }
  
  return(J)
}

#' Inverse Kinematics via Damped Least Squares (DLS)
#' @param robot S3 object of class 'micro_robot'
#' @param target_pos 3D target position [x, y, z]
#' @param q_init Initial guess joint angles
#' @param max_iter Maximum iterations
#' @param lambda Damping parameter
#' @return Solved joint vector q
#' @export
inverse_kinematics_dls <- function(robot, target_pos, q_init, max_iter = 100, lambda = 0.05) {
  q <- q_init
  for (iter in 1:max_iter) {
    fk <- forward_kinematics(robot, q)
    error <- target_pos - fk$ee_position
    err_norm <- sqrt(sum(error^2))
    
    if (err_norm < 1e-6) break
    
    J <- compute_jacobian(robot, q)[1:3, ] # Linear part
    # DLS formula: delta_q = J^T * (J * J^T + lambda^2 * I)^(-1) * error
    J_dls <- t(J) %*% solve(J %*% t(J) + (lambda^2) * diag(3))
    delta_q <- as.vector(J_dls %*% error)
    
    # Limit step size
    step_norm <- sqrt(sum(delta_q^2))
    if (step_norm > 0.1) delta_q <- delta_q * (0.1 / step_norm)
    
    q <- q + delta_q
    
    # Clamp to joint limits
    q <- pmax(robot$dh_table$q_min, pmin(robot$dh_table$q_max, q))
  }
  return(q)
}
