# ==============================================================================
# MicroMotion.R - Trajectory Profiles & Analytical Generators
# ==============================================================================

#' Generate Analytical Trajectory Profile for a Single Joint
#' 
#' @param q0 Initial joint position (rad)
#' @param q1 Target joint position (rad)
#' @param duration Motion segment duration (seconds)
#' @param t Instantaneous time evaluated at (seconds, 0 <= t <= duration)
#' @param profile_type String: "quintic", "cubic", "septic", "min_jerk", "min_energy", "linear"
#' @param v0 Initial velocity (default 0)
#' @param v1 Target velocity (default 0)
#' @param a0 Initial acceleration (default 0)
#' @param a1 Target acceleration (default 0)
#' @return List containing position, velocity, acceleration, jerk
#' @export
evaluate_trajectory_profile <- function(q0, q1, duration, t, profile_type = "quintic",
                                       v0 = 0, v1 = 0, a0 = 0, a1 = 0) {
  # Normalize time tau in [0, 1]
  t <- pmax(0, pmin(duration, t))
  tau <- if (duration > 0) t / duration else 1
  D <- q1 - q0
  
  if (profile_type == "quintic") {
    # 5th-order polynomial with boundary constraints:
    # s(tau) = 10*tau^3 - 15*tau^4 + 6*tau^5
    # s_dot(tau) = 30*tau^2 - 60*tau^3 + 30*tau^4
    # s_ddot(tau) = 60*tau - 180*tau^2 + 120*tau^3
    # s_dddot(tau) = 60 - 360*tau + 360*tau^2
    s <- 10 * tau^3 - 15 * tau^4 + 6 * tau^5
    s_dot <- (30 * tau^2 - 60 * tau^3 + 30 * tau^4) / duration
    s_ddot <- (60 * tau - 180 * tau^2 + 120 * tau^3) / (duration^2)
    s_dddot <- (60 - 360 * tau + 360 * tau^2) / (duration^3)
    
    pos <- q0 + D * s
    vel <- D * s_dot
    acc <- D * s_ddot
    jerk <- D * s_dddot
    
  } else if (profile_type == "septic") {
    # 7th-order polynomial: zero boundary jerk
    # s(tau) = 35*tau^4 - 84*tau^5 + 70*tau^6 - 20*tau^7
    s <- 35 * tau^4 - 84 * tau^5 + 70 * tau^6 - 20 * tau^7
    s_dot <- (140 * tau^3 - 420 * tau^4 + 420 * tau^5 - 140 * tau^6) / duration
    s_ddot <- (420 * tau^2 - 1680 * tau^3 + 2100 * tau^4 - 840 * tau^5) / (duration^2)
    s_dddot <- (840 * tau - 5040 * tau^2 + 8400 * tau^3 - 4200 * tau^4) / (duration^3)
    
    pos <- q0 + D * s
    vel <- D * s_dot
    acc <- D * s_ddot
    jerk <- D * s_dddot
    
  } else if (profile_type == "cubic") {
    # 3rd-order polynomial:
    # s(tau) = 3*tau^2 - 2*tau^3
    s <- 3 * tau^2 - 2 * tau^3
    s_dot <- (6 * tau - 6 * tau^2) / duration
    s_ddot <- (6 - 12 * tau) / (duration^2)
    s_dddot <- rep(-12 / (duration^3), length(tau))
    
    pos <- q0 + D * s
    vel <- D * s_dot
    acc <- D * s_ddot
    jerk <- D * s_dddot
    
  } else if (profile_type == "min_jerk") {
    # Flash & Hogan Minimum Jerk trajectory formulation: integral(jerk^2) dt -> min
    s <- 10 * tau^3 - 15 * tau^4 + 6 * tau^5
    s_dot <- (30 * tau^2 - 60 * tau^3 + 30 * tau^4) / duration
    s_ddot <- (60 * tau - 180 * tau^2 + 120 * tau^3) / (duration^2)
    s_dddot <- (60 - 360 * tau + 360 * tau^2) / (duration^3)
    
    pos <- q0 + D * s
    vel <- D * s_dot
    acc <- D * s_ddot
    jerk <- D * s_dddot
    
  } else if (profile_type == "min_energy") {
    # Variational Euler-Lagrange smooth transition minimizing acceleration squared
    # with soft boundary ramp
    s <- 0.5 * (1 - cos(pi * tau))
    s_dot <- (0.5 * pi * sin(pi * tau)) / duration
    s_ddot <- (0.5 * (pi^2) * cos(pi * tau)) / (duration^2)
    s_dddot <- (-0.5 * (pi^3) * sin(pi * tau)) / (duration^3)
    
    pos <- q0 + D * s
    vel <- D * s_dot
    acc <- D * s_ddot
    jerk <- D * s_dddot
    
  } else { # "linear" trapezoidal
    # 1/3 ramp up, 1/3 constant, 1/3 ramp down
    if (tau < 0.333) {
      tau_sub <- tau / 0.333
      s <- 0.5 * 0.333 * (tau_sub^2) * 1.5
      s_dot <- (1.5 * tau_sub) / duration
      s_ddot <- (1.5 / 0.333) / (duration^2)
      s_dddot <- 0
    } else if (tau < 0.667) {
      s <- 0.5 * 0.333 * 1.5 + 1.5 * (tau - 0.333)
      s_dot <- 1.5 / duration
      s_ddot <- 0
      s_dddot <- 0
    } else {
      tau_sub <- (tau - 0.667) / 0.333
      s <- 1 - 0.5 * 0.333 * ((1 - tau_sub)^2) * 1.5
      s_dot <- (1.5 * (1 - tau_sub)) / duration
      s_ddot <- (-1.5 / 0.333) / (duration^2)
      s_dddot <- 0
    }
    pos <- q0 + D * s
    vel <- D * s_dot
    acc <- D * s_ddot
    jerk <- D * s_dddot
  }
  
  return(list(
    position = pos,
    velocity = vel,
    acceleration = acc,
    jerk = jerk
  ))
}
