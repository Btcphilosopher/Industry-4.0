# ==============================================================================
# MicroMotion.R - Numerical Verification & Unit Test Suite
# ==============================================================================

run_micromotion_unit_tests <- function() {
  cat("Running MicroMotion.R Computational Test Suite...\n")
  
  source("src/r_engine/MicroMotion.R")
  source("src/r_engine/dynamics_torque.R")
  source("src/r_engine/trajectory.R")
  source("src/r_engine/simulate.R")
  source("src/r_engine/optimizer.R")
  source("src/r_engine/telemetry.R")
  source("src/r_engine/export.R")
  
  # Test 1: Robot Instantiation
  robot <- create_robot("Test-Cobot-6DOF", payload_kg = 3.0)
  stopifnot(robot$dof == 6)
  stopifnot(nrow(robot$dh_table) == 6)
  cat("[PASS] Test 1: Robot Instantiation & DH Parameters\n")
  
  # Test 2: Forward Kinematics at Home
  q_home <- c(0, 0, 0, 0, 0, 0)
  fk <- forward_kinematics(robot, q_home)
  stopifnot(length(fk$ee_position) == 3)
  stopifnot(!any(is.na(fk$ee_position)))
  cat(sprintf("[PASS] Test 2: Forward Kinematics (EE at [%.3f, %.3f, %.3f])\n",
              fk$ee_position[1], fk$ee_position[2], fk$ee_position[3]))
  
  # Test 3: Jacobian Matrix Dimensions
  J <- compute_jacobian(robot, q_home)
  stopifnot(nrow(J) == 6 && ncol(J) == 6)
  cat("[PASS] Test 3: Geometric Jacobian 6x6 Matrix\n")
  
  # Test 4: Inverse Kinematics Convergence
  target_ee <- fk$ee_position + c(0.05, -0.05, 0.05)
  q_solved <- inverse_kinematics_dls(robot, target_ee, q_home)
  fk_solved <- forward_kinematics(robot, q_solved)
  pos_error <- sqrt(sum((target_ee - fk_solved$ee_position)^2))
  stopifnot(pos_error < 1e-4) # 100 micron convergence
  cat(sprintf("[PASS] Test 4: DLS Inverse Kinematics (Residual Error: %.6f m)\n", pos_error))
  
  # Test 5: Trajectory Generator Polynomial Boundary Conditions
  prof_start <- evaluate_trajectory_profile(0, 1, 2.0, 0.0, "quintic")
  prof_end   <- evaluate_trajectory_profile(0, 1, 2.0, 2.0, "quintic")
  stopifnot(abs(prof_start$position - 0) < 1e-9)
  stopifnot(abs(prof_start$velocity - 0) < 1e-9)
  stopifnot(abs(prof_end$position - 1) < 1e-9)
  stopifnot(abs(prof_end$velocity - 0) < 1e-9)
  cat("[PASS] Test 5: Quintic Polynomial C2 Boundary Conditions\n")
  
  # Test 6: Micro-Motion Simulation at 1ms resolution
  q_start <- c(0, -pi/4, pi/4, 0, pi/2, 0)
  q_end   <- c(pi/3, -pi/3, pi/2, -pi/6, pi/3, pi/4)
  sim_res <- simulate_micro_motion(robot, q_start, q_end, duration = 1.0, dt = 0.001, profile_type = "quintic")
  stopifnot(sim_res$n_frames == 1001)
  stopifnot(length(sim_res$delta_energy) == 1001)
  cat(sprintf("[PASS] Test 6: Micro-Motion Simulation (%d micro-states generated at dt=1ms)\n", sim_res$n_frames))
  
  # Test 7: Telemetry Hotspot Extraction
  analysis <- analyse_motion(sim_res)
  stopifnot(!is.null(analysis$max_jerk$joint))
  stopifnot(!is.null(analysis$max_torque$joint))
  cat(sprintf("[PASS] Test 7: Telemetry Hotspots (Max Jerk on %s @ %.3fs, Max Torque on %s @ %.3fs)\n",
              analysis$max_jerk$joint, analysis$max_jerk$timestamp_s,
              analysis$max_torque$joint, analysis$max_torque$timestamp_s))
  
  # Test 8: Trajectory Optimisation Comparison
  opt_res <- optimise_motion(robot, q_start, q_end, mode = "BALANCED", dt = 0.005)
  stopifnot(!is.null(opt_res$optimized_simulation))
  cat(sprintf("[PASS] Test 8: Trajectory Optimization (Energy reduction: %.1f%%, Jerk reduction: %.1f%%)\n",
              opt_res$improvements$energy_reduction_pct, opt_res$improvements$jerk_reduction_pct))
  
  cat("=================================================================\n")
  cat("ALL MICROMOTION.R NUMERICAL & KINEMATIC TESTS PASSED SUCCESSFULLY!\n")
  cat("=================================================================\n")
}

if (!interactive()) {
  run_micromotion_unit_tests()
}
