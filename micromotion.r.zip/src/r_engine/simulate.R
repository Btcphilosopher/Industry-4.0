# ==============================================================================
# MicroMotion.R - High-Resolution Micro-Motion State Engine
# ==============================================================================

#' Simulate Micro-Motion Trajectory Sequence
#' 
#' Generates a full high-resolution sequence of micro-motion frames where
#' each timestep captures: [t, q, q_dot, q_ddot, q_dddot, tau, power, energy,
#' ee_pos, ee_vel, ee_acc, orientation, d_pos, d_vel, d_torque, tracking_error]
#' 
#' @param robot S3 object of class 'micro_robot'
#' @param initial_state List or vector of initial joint angles (rad)
#' @param target_state List or vector of target joint angles (rad)
#' @param duration Total motion duration in seconds
#' @param dt Timestep in seconds (e.g. 0.001 for 1ms, 0.0001 for 0.1ms)
#' @param profile_type Trajectory generator profile ("quintic", "septic", "min_jerk", "cubic", "min_energy", "linear")
#' @param enable_micro_correction Logical: whether to apply digital twin closed-loop micro-corrections
#' @param disturbance_scale Scale of simulated external physical micro-disturbance (rad)
#' @return S3 object of class 'micro_motion_result'
#' @export
simulate_micro_motion <- function(robot, initial_state, target_state, duration = 2.0,
                                  dt = 0.001, profile_type = "quintic",
                                  enable_micro_correction = TRUE,
                                  disturbance_scale = 0.00005) {
  dof <- robot$dof
  dh <- robot$dh_table
  
  q0 <- as.numeric(initial_state)
  q1 <- as.numeric(target_state)
  
  # Temporal grid
  time_steps <- seq(0, duration, by = dt)
  n_steps <- length(time_steps)
  
  # Allocate matrices for optimal vector performance
  q_mat     <- matrix(0, nrow = n_steps, ncol = dof)
  qd_mat    <- matrix(0, nrow = n_steps, ncol = dof)
  qdd_mat   <- matrix(0, nrow = n_steps, ncol = dof)
  jerk_mat  <- matrix(0, nrow = n_steps, ncol = dof)
  tau_mat   <- matrix(0, nrow = n_steps, ncol = dof)
  power_mat <- matrix(0, nrow = n_steps, ncol = dof)
  
  # Cartesian end-effector states
  ee_pos_mat     <- matrix(0, nrow = n_steps, ncol = 3)
  ee_vel_mat     <- matrix(0, nrow = n_steps, ncol = 3)
  ee_acc_mat     <- matrix(0, nrow = n_steps, ncol = 3)
  ee_orient_mat  <- matrix(0, nrow = n_steps, ncol = 3) # roll, pitch, yaw
  
  # Incremental micro-deltas per timestep
  delta_q_mat    <- matrix(0, nrow = n_steps, ncol = dof)
  delta_ee_pos   <- matrix(0, nrow = n_steps, ncol = 3)
  delta_energy   <- numeric(n_steps)
  cum_energy     <- numeric(n_steps)
  tracking_error <- numeric(n_steps)
  constraint_violations <- character(0)
  
  total_energy_accum <- 0
  prev_q <- q0
  prev_ee_pos <- forward_kinematics(robot, q0)$ee_position
  
  # State tracking for closed-loop micro-corrections
  accumulated_disturbance <- numeric(dof)
  micro_corrections_count <- 0
  
  for (k in 1:n_steps) {
    t_curr <- time_steps[k]
    
    # 1. Nominal Trajectory Evaluation
    cmd_q <- numeric(dof)
    cmd_qd <- numeric(dof)
    cmd_qdd <- numeric(dof)
    cmd_jerk <- numeric(dof)
    
    for (j in 1:dof) {
      prof <- evaluate_trajectory_profile(
        q0 = q0[j], q1 = q1[j], duration = duration, t = t_curr,
        profile_type = profile_type
      )
      cmd_q[j]    <- prof$position
      cmd_qd[j]   <- prof$velocity
      cmd_qdd[j]  <- prof$acceleration
      cmd_jerk[j] <- prof$jerk
    }
    
    # 2. Digital Twin Simulated Physical Perturbation & Drift
    # Micro-scale elastic deflection and motor ripple
    if (disturbance_scale > 0) {
      ripple <- disturbance_scale * sin(2 * pi * 40 * t_curr) * (cmd_qd / (max(abs(cmd_qd)) + 1e-4))
      sim_q <- cmd_q + ripple + accumulated_disturbance
    } else {
      sim_q <- cmd_q
    }
    
    # 3. Forward Kinematics & Cartesian State
    fk_nominal <- forward_kinematics(robot, cmd_q)
    fk_sim     <- forward_kinematics(robot, sim_q)
    
    pos_err <- sqrt(sum((fk_nominal$ee_position - fk_sim$ee_position)^2))
    tracking_error[k] <- pos_err
    
    # 4. Micro-Correction Closed-Loop Feedback
    if (enable_micro_correction && pos_err > robot$tolerance) {
      # Compute DLS Jacobian correction in Cartesian space
      J <- compute_jacobian(robot, sim_q)[1:3, ]
      cart_err <- fk_nominal$ee_position - fk_sim$ee_position
      # Gain tuned for micro-damping
      lambda <- 0.02
      J_inv <- t(J) %*% solve(J %*% t(J) + (lambda^2) * diag(3))
      correction_dq <- as.vector(J_inv %*% cart_err) * 0.45
      
      sim_q <- sim_q + correction_dq
      accumulated_disturbance <- accumulated_disturbance - correction_dq * 0.3
      micro_corrections_count <- micro_corrections_count + 1
      
      # Re-evaluate FK after correction
      fk_sim <- forward_kinematics(robot, sim_q)
    }
    
    # 5. Populate Joint Micro-State
    q_mat[k, ]    <- sim_q
    qd_mat[k, ]   <- cmd_qd
    qdd_mat[k, ]  <- cmd_qdd
    jerk_mat[k, ] <- cmd_jerk
    
    # 6. Dynamics & Torque Calculation
    tau_k <- calculate_torque(robot, sim_q, cmd_qd, cmd_qdd)
    tau_mat[k, ] <- tau_k
    
    # 7. Energy & Power Calculation
    p_k <- calculate_power_energy(robot, tau_k, cmd_qd, dt)
    power_mat[k, ] <- p_k$p_elec
    delta_energy[k] <- p_k$d_energy_elec
    total_energy_accum <- total_energy_accum + p_k$d_energy_elec
    cum_energy[k] <- total_energy_accum
    
    # 8. End-Effector Cartesian Kinematics
    ee_pos_mat[k, ] <- fk_sim$ee_position
    ee_orient_mat[k, ] <- fk_sim$orientation
    
    # Jacobian-based linear velocity
    J_full <- compute_jacobian(robot, sim_q)
    ee_vel_6d <- J_full %*% cmd_qd
    ee_vel_mat[k, ] <- ee_vel_6d[1:3]
    
    # 9. Micro-Deltas
    if (k > 1) {
      delta_q_mat[k, ] <- sim_q - prev_q
      delta_ee_pos[k, ] <- fk_sim$ee_position - prev_ee_pos
      ee_acc_mat[k, ] <- (ee_vel_mat[k, ] - ee_vel_mat[k-1, ]) / dt
    }
    
    prev_q <- sim_q
    prev_ee_pos <- fk_sim$ee_position
    
    # 10. Constraint Validation Check
    for (j in 1:dof) {
      if (sim_q[j] < dh$q_min[j] || sim_q[j] > dh$q_max[j]) {
        constraint_violations <- c(constraint_violations, paste0("J", j, " Position Limit Exceeded at t=", round(t_curr, 4)))
      }
      if (abs(cmd_qd[j]) > dh$v_max[j]) {
        constraint_violations <- c(constraint_violations, paste0("J", j, " Velocity Limit Exceeded at t=", round(t_curr, 4)))
      }
      if (abs(tau_k[j]) > dh$torque_max[j]) {
        constraint_violations <- c(constraint_violations, paste0("J", j, " Torque Limit Exceeded at t=", round(t_curr, 4)))
      }
    }
  }
  
  result <- list(
    robot = robot,
    timestamps = time_steps,
    duration = duration,
    dt = dt,
    n_frames = n_steps,
    profile_type = profile_type,
    q = q_mat,
    qd = qd_mat,
    qdd = qdd_mat,
    jerk = jerk_mat,
    torque = tau_mat,
    power = power_mat,
    delta_q = delta_q_mat,
    ee_position = ee_pos_mat,
    ee_velocity = ee_vel_mat,
    ee_acceleration = ee_acc_mat,
    ee_orientation = ee_orient_mat,
    delta_ee_pos = delta_ee_pos,
    delta_energy = delta_energy,
    cumulative_energy = cum_energy,
    tracking_error = tracking_error,
    total_energy_joules = total_energy_accum,
    micro_corrections_count = micro_corrections_count,
    constraint_violations = unique(constraint_violations)
  )
  
  class(result) <- c("micro_motion_result", "list")
  return(result)
}
