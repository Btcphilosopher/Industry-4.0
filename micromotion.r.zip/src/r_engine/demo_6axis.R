# ==============================================================================
# MicroMotion.R - High-Level Task Decomposition & 6-Axis Demonstration
# ==============================================================================

#' High-Level Task Decomposition into Micro-Motion Trajectory Stages
#' 
#' PICK -> LIFT -> MOVE -> ROTATE -> PLACE -> HOME
#' 
#' @param robot S3 object of class 'micro_robot'
#' @param dt Timestep resolution in seconds (default 0.001 = 1ms)
#' @return List of trajectory stages with concatenated micro-motion sequence
#' @export
run_6axis_pick_and_place_demo <- function(robot = NULL, dt = 0.001) {
  if (is.null(robot)) {
    robot <- create_robot("MicroMotion-UR10e-Precision", payload_kg = 2.0)
  }
  
  # Waypoints in Joint Space (rad) for 6 DOF
  # Home
  q_home     <- c(0.0, -pi/2, pi/2, 0.0, pi/2, 0.0)
  # Pick Sequence Waypoints
  q_approach <- c(0.45, -pi/3, 0.65*pi, -0.32, pi/2, 0.45)
  q_slow_app <- c(0.45, -pi/3 - 0.05, 0.65*pi + 0.05, -0.32, pi/2, 0.45)
  q_pick     <- c(0.45, -0.92, 2.15, -0.35, pi/2, 0.45)
  # Lift & Transfer
  q_lift     <- c(0.45, -pi/2, pi/2, 0.0, pi/2, 0.45)
  q_move     <- c(-0.65, -0.85, 1.80, -0.20, pi/2, -0.65)
  q_rotate   <- c(-0.65, -0.85, 1.80, -0.20, pi/2, 1.20)
  # Place & Return
  q_place    <- c(-0.65, -0.95, 2.20, -0.40, pi/2, 1.20)
  
  # Stage Definitions: [Stage Name, From, To, Duration, Profile]
  stages_def <- list(
    list(name = "1. Approach to Pick Zone", from = q_home, to = q_approach, dur = 1.2, prof = "quintic"),
    list(name = "2. Slow Precision Alignment", from = q_approach, to = q_slow_app, dur = 0.6, prof = "min_jerk"),
    list(name = "3. Gripper Descend & Position", from = q_slow_app, to = q_pick, dur = 0.5, prof = "septic"),
    list(name = "4. Gripper Closure & Stabilisation", from = q_pick, to = q_pick, dur = 0.3, prof = "cubic"), # Dwell
    list(name = "5. Vertical Lift with Payload", from = q_pick, to = q_lift, dur = 0.8, prof = "quintic"),
    list(name = "6. High-Speed Workspace Transfer", from = q_lift, to = q_move, dur = 1.5, prof = "min_energy"),
    list(name = "7. Tool Rotation & Orientation", from = q_move, to = q_rotate, dur = 0.7, prof = "quintic"),
    list(name = "8. Gentle Placement", from = q_rotate, to = q_place, dur = 0.6, prof = "septic"),
    list(name = "9. Release & Retract", from = q_place, to = q_lift, dur = 0.7, prof = "quintic"),
    list(name = "10. Return to Home", from = q_lift, to = q_home, dur = 1.1, prof = "quintic")
  )
  
  cat("Running MicroMotion.R Pick-and-Place Demonstration...\n")
  stage_results <- list()
  total_microstates <- 0
  total_duration <- 0
  total_energy <- 0
  
  for (i in seq_along(stages_def)) {
    st <- stages_def[[i]]
    cat(sprintf("  -> Simulating Stage %d: %s (Duration: %.2fs, Profile: %s)\n", i, st$name, st$dur, st$prof))
    
    sim_st <- simulate_micro_motion(
      robot = robot,
      initial_state = st$from,
      target_state = st$to,
      duration = st$dur,
      dt = dt,
      profile_type = st$prof,
      enable_micro_correction = TRUE
    )
    
    stage_results[[st$name]] <- sim_st
    total_microstates <- total_microstates + sim_st$n_frames
    total_duration <- total_duration + st$dur
    total_energy <- total_energy + sim_st$total_energy_joules
  }
  
  cat("=================================================================\n")
  cat(sprintf("DEMONSTRATION COMPLETED:\n"))
  cat(sprintf("  Total Simulation Duration: %.3f s\n", total_duration))
  cat(sprintf("  Total Micro-States Generated: %d frames (dt = %.3f ms)\n", total_microstates, dt * 1000))
  cat(sprintf("  Total Electrical Energy Consumed: %.2f Joules\n", total_energy))
  cat("=================================================================\n")
  
  return(list(
    stages = stage_results,
    total_duration = total_duration,
    total_microstates = total_microstates,
    total_energy = total_energy
  ))
}

# Auto-run if executed directly via Rscript
if (!interactive()) {
  source("src/r_engine/MicroMotion.R")
  source("src/r_engine/dynamics_torque.R")
  source("src/r_engine/trajectory.R")
  source("src/r_engine/simulate.R")
  source("src/r_engine/optimizer.R")
  source("src/r_engine/telemetry.R")
  source("src/r_engine/export.R")
  
  res <- run_6axis_pick_and_place_demo()
}
