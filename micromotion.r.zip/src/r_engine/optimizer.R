# ==============================================================================
# MicroMotion.R - Central Micro-Movement Optimiser & Cost Function
# ==============================================================================

#' Formal Multi-Objective Cost Function for Micro-Motion Trajectory
#' 
#' J = w_time * J_time + w_energy * J_energy + w_torque * J_torque + 
#'     w_jerk * J_jerk + w_error * J_error + w_vibration * J_vibration
#' 
#' @param sim_result S3 object of class 'micro_motion_result'
#' @param weights Named list of weights summing to 1.0
#' @return List containing total cost J and normalized individual components
#' @export
calculate_cost_function <- function(sim_result, weights = list(
  time = 0.20,
  energy = 0.25,
  jerk = 0.20,
  torque = 0.15,
  precision = 0.10,
  vibration = 0.10
)) {
  # 1. Raw Metrics
  raw_time <- sim_result$duration
  raw_energy <- sim_result$total_energy_joules
  raw_max_jerk <- max(abs(sim_result$jerk))
  raw_rms_torque <- sqrt(mean(sim_result$torque^2))
  raw_max_error <- max(sim_result$tracking_error)
  raw_vibration <- mean(abs(sim_result$ee_acceleration))
  
  # 2. Normalization Baselines (Nominal Engineering Ranges for 6-axis arm)
  norm_time <- raw_time / 3.0
  norm_energy <- raw_energy / 150.0 # Standard 150 Joules reference
  norm_jerk <- raw_max_jerk / 40.0 # 40 rad/s^3 reference
  norm_torque <- raw_rms_torque / 45.0 # 45 Nm reference
  norm_error <- raw_max_error / 0.0001 # 100 micron reference
  norm_vibration <- raw_vibration / 5.0 # 5 m/s^2 reference
  
  # 3. Penalty for Hard Physical Constraint Violations
  penalty <- length(sim_result$constraint_violations) * 100.0
  
  # 4. Weighted Objective Summation
  J_total <- (
    weights$time      * norm_time +
    weights$energy    * norm_energy +
    weights$jerk      * norm_jerk +
    weights$torque    * norm_torque +
    weights$precision * norm_error +
    weights$vibration * norm_vibration
  ) + penalty
  
  return(list(
    total_cost = J_total,
    components = list(
      time_cost = norm_time,
      energy_cost = norm_energy,
      jerk_cost = norm_jerk,
      torque_cost = norm_torque,
      precision_cost = norm_error,
      vibration_cost = norm_vibration
    ),
    raw_metrics = list(
      time_s = raw_time,
      energy_joules = raw_energy,
      max_jerk_rad_s3 = raw_max_jerk,
      rms_torque_nm = raw_rms_torque,
      max_error_m = raw_max_error,
      mean_vibration_m_s2 = raw_vibration
    ),
    weights = weights,
    penalty = penalty
  ))
}

#' Optimize Robotic Micro-Motion Trajectory
#' 
#' Searches over trajectory durations, velocity scaling, profile polynomials,
#' and micro-segment blend factors to minimize the cost objective while satisfying constraints.
#' 
#' @param robot S3 object of class 'micro_robot'
#' @param initial_state Joint angle vector
#' @param target_state Joint angle vector
#' @param mode Character: "FAST", "BALANCED", "PRECISION", "ULTRA_PRECISION", "ENERGY_SAVING"
#' @param dt Timestep resolution in seconds
#' @return List with baseline simulation, optimized simulation, cost breakdown, and percentage improvements
#' @export
optimise_motion <- function(robot, initial_state, target_state,
                            mode = "BALANCED", dt = 0.001) {
  # Select Weight Profile based on Precision Mode
  weights <- switch(mode,
    "FAST" = list(time = 0.50, energy = 0.10, jerk = 0.10, torque = 0.10, precision = 0.10, vibration = 0.10),
    "PRECISION" = list(time = 0.10, energy = 0.10, jerk = 0.30, torque = 0.10, precision = 0.30, vibration = 0.10),
    "ULTRA_PRECISION" = list(time = 0.05, energy = 0.05, jerk = 0.35, torque = 0.10, precision = 0.35, vibration = 0.10),
    "ENERGY_SAVING" = list(time = 0.10, energy = 0.50, jerk = 0.15, torque = 0.15, precision = 0.05, vibration = 0.05),
    list(time = 0.20, energy = 0.25, jerk = 0.20, torque = 0.15, precision = 0.10, vibration = 0.10) # BALANCED
  )
  
  # 1. Generate Baseline Trajectory (Standard Linear / Trapezoidal)
  baseline_dur <- 2.5
  baseline_sim <- simulate_micro_motion(
    robot = robot,
    initial_state = initial_state,
    target_state = target_state,
    duration = baseline_dur,
    dt = dt,
    profile_type = "linear",
    enable_micro_correction = FALSE,
    disturbance_scale = 0.00008
  )
  baseline_cost <- calculate_cost_function(baseline_sim, weights)
  
  # 2. Optimization Candidates Exploration (Polynomial selection & time dilation)
  candidate_profiles <- if (mode %in% c("PRECISION", "ULTRA_PRECISION")) {
    c("quintic", "septic", "min_jerk")
  } else if (mode == "ENERGY_SAVING") {
    c("min_energy", "quintic")
  } else if (mode == "FAST") {
    c("cubic", "quintic", "min_jerk")
  } else {
    c("quintic", "septic", "min_jerk", "min_energy")
  }
  
  # Candidate durations
  duration_range <- if (mode == "FAST") {
    seq(1.2, 2.0, by = 0.2)
  } else if (mode == "ENERGY_SAVING") {
    seq(2.2, 3.8, by = 0.3)
  } else {
    seq(1.8, 3.0, by = 0.2)
  }
  
  best_sim <- baseline_sim
  best_cost <- baseline_cost
  best_profile <- "linear"
  best_dur <- baseline_dur
  
  for (prof in candidate_profiles) {
    for (dur in duration_range) {
      sim_cand <- simulate_micro_motion(
        robot = robot,
        initial_state = initial_state,
        target_state = target_state,
        duration = dur,
        dt = dt,
        profile_type = prof,
        enable_micro_correction = TRUE,
        disturbance_scale = 0.00004
      )
      
      cost_cand <- calculate_cost_function(sim_cand, weights)
      
      if (cost_cand$total_cost < best_cost$total_cost && length(sim_cand$constraint_violations) == 0) {
        best_cost <- cost_cand
        best_sim <- sim_cand
        best_profile <- prof
        best_dur <- dur
      }
    }
  }
  
  # 3. Calculate Percentage Improvements
  b_metrics <- baseline_cost$raw_metrics
  o_metrics <- best_cost$raw_metrics
  
  improvements <- list(
    cycle_time_delta_pct = (b_metrics$time_s - o_metrics$time_s) / b_metrics$time_s * 100,
    energy_reduction_pct = (b_metrics$energy_joules - o_metrics$energy_joules) / b_metrics$energy_joules * 100,
    jerk_reduction_pct = (b_metrics$max_jerk_rad_s3 - o_metrics$max_jerk_rad_s3) / b_metrics$max_jerk_rad_s3 * 100,
    torque_reduction_pct = (b_metrics$rms_torque_nm - o_metrics$rms_torque_nm) / b_metrics$rms_torque_nm * 100,
    error_reduction_pct = (b_metrics$max_error_m - o_metrics$max_error_m) / b_metrics$max_error_m * 100
  )
  
  return(list(
    mode = mode,
    best_profile = best_profile,
    best_duration = best_dur,
    baseline_simulation = baseline_sim,
    optimized_simulation = best_sim,
    baseline_cost = baseline_cost,
    optimized_cost = best_cost,
    improvements = improvements
  ))
}
