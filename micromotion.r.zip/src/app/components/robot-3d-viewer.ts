import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import * as THREE from 'three';
import { MicroMotionFrame, RobotModel } from '../core/types';

@Component({
  selector: 'app-robot-3d-viewer',
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: true,
  template: `
    <div class="relative w-full h-[460px] bg-[#0A0C10] rounded-xl overflow-hidden border border-[#1F2937] shadow-2xl select-none group">
      <!-- WebGL Canvas Container -->
      <div #canvasContainer class="w-full h-full cursor-grab active:cursor-grabbing"></div>

      <!-- Overlay HUD Info -->
      <div class="absolute top-3.5 left-4 flex flex-col gap-2 pointer-events-none">
        <div class="flex items-center gap-2.5 px-3 py-1.5 bg-[#0F1117]/95 backdrop-blur-md rounded-lg border border-[#1F2937] shadow-lg">
          <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span class="text-xs font-mono text-[#E0E2E6] font-bold tracking-wider">DIGITAL TWIN 3D VIEW</span>
          <span class="text-[10px] font-mono text-blue-400 bg-blue-500/10 border border-blue-500/20 px-2 py-0.5 rounded font-semibold">{{ activeRobot?.name || '6-Axis Arm' }}</span>
        </div>
        @if (currentFrame) {
          <div class="px-3 py-1.5 bg-[#0F1117]/90 backdrop-blur-md rounded-lg border border-[#1F2937] text-[11px] font-mono text-[#9CA3AF] flex items-center gap-2.5">
            <span class="text-blue-400 font-semibold">EE [X,Y,Z]:</span>
            <span class="text-[#E0E2E6]">[{{ currentFrame.ee_position[0].toFixed(3) }}, {{ currentFrame.ee_position[1].toFixed(3) }}, {{ currentFrame.ee_position[2].toFixed(3) }}] m</span>
            <span class="text-[#4B5563]">|</span>
            <span class="text-orange-400 font-semibold">Δd:</span>
            <span class="text-[#E0E2E6]">{{ (currentFrame.delta_ee_distance * 1000).toFixed(3) }} mm</span>
          </div>
        }
      </div>

      <!-- Controls Overlay Helper -->
      <div class="absolute bottom-3.5 left-4 text-[10px] font-mono text-[#6B7280] bg-[#0F1117]/90 px-3 py-1.5 rounded-lg border border-[#1F2937] pointer-events-none">
        Left-Drag: Rotate • Right-Drag: Pan • Wheel: Zoom
      </div>

      <!-- Reset Camera Button -->
      <button
        type="button"
        id="btn-reset-cam"
        (click)="resetCamera()"
        class="absolute bottom-3.5 right-4 px-3 py-1.5 bg-[#1F2937] hover:bg-[#374151] text-[#E0E2E6] hover:text-white rounded-lg border border-[#374151] text-xs font-mono transition-all shadow-md flex items-center gap-1.5 cursor-pointer active:scale-95"
      >
        <span class="material-icons text-sm text-blue-400">videocam</span>
        Reset View
      </button>
    </div>
  `
})
export class Robot3dViewer implements OnInit, OnDestroy, OnChanges {
  @ViewChild('canvasContainer', { static: true }) canvasContainerRef!: ElementRef<HTMLDivElement>;

  @Input() currentFrame: MicroMotionFrame | null = null;
  @Input() trajectoryFrames: MicroMotionFrame[] = [];
  @Input() activeRobot: RobotModel | null = null;

  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animationFrameId: number | null = null;

  // 3D Objects
  private robotLinksGroup = new THREE.Group();
  private trajectoryLineMesh: THREE.Line | null = null;
  private eeVectorMesh: THREE.ArrowHelper | null = null;
  private eeMarkerMesh!: THREE.Mesh;
  private targetMarkerMesh!: THREE.Mesh;

  // Orbit control interaction state
  private isMouseDown = false;
  private isRightMouseDown = false;
  private mouseX = 0;
  private mouseY = 0;
  private cameraRadius = 2.4;
  private cameraTheta = Math.PI / 4;
  private cameraPhi = Math.PI / 3.2;
  private cameraTarget = new THREE.Vector3(0, 0, 0.4);

  ngOnInit(): void {
    if (typeof window !== 'undefined') {
      this.initThree();
      this.setupEventListeners();
    }
  }

  ngOnDestroy(): void {
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['trajectoryFrames'] && this.trajectoryFrames.length > 0) {
      this.updateTrajectoryTrail();
    }
    if (changes['currentFrame'] && this.currentFrame) {
      this.updateRobotPose();
    }
  }

  private initThree(): void {
    const container = this.canvasContainerRef.nativeElement;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 480;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x070b14);

    // Grid Floor
    const grid = new THREE.GridHelper(2.5, 25, 0x1e293b, 0x0f172a);
    grid.position.y = 0;
    this.scene.add(grid);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.9);
    this.scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0x38bdf8, 2.0);
    dirLight1.position.set(3, 5, 4);
    this.scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x10b981, 1.2);
    dirLight2.position.set(-3, -2, -2);
    this.scene.add(dirLight2);

    // Robot group
    this.scene.add(this.robotLinksGroup);

    // End-Effector marker
    const eeGeo = new THREE.SphereGeometry(0.018, 16, 16);
    const eeMat = new THREE.MeshStandardMaterial({ color: 0x10b981, emissive: 0x059669, emissiveIntensity: 0.6, roughness: 0.2 });
    this.eeMarkerMesh = new THREE.Mesh(eeGeo, eeMat);
    this.scene.add(this.eeMarkerMesh);

    // Target marker
    const targetGeo = new THREE.RingGeometry(0.02, 0.035, 24);
    const targetMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b, side: THREE.DoubleSide });
    this.targetMarkerMesh = new THREE.Mesh(targetGeo, targetMat);
    this.targetMarkerMesh.rotation.x = Math.PI / 2;
    this.scene.add(this.targetMarkerMesh);

    // Camera
    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.05, 50);
    this.updateCameraPosition();

    // Renderer
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(this.renderer.domElement);

    // Animation Loop
    const animate = () => {
      this.animationFrameId = requestAnimationFrame(animate);
      this.renderer.render(this.scene, this.camera);
    };
    animate();

    if (this.currentFrame) {
      this.updateRobotPose();
    }
    if (this.trajectoryFrames.length > 0) {
      this.updateTrajectoryTrail();
    }
  }

  private updateCameraPosition(): void {
    const x = this.cameraTarget.x + this.cameraRadius * Math.sin(this.cameraPhi) * Math.sin(this.cameraTheta);
    const y = this.cameraTarget.y + this.cameraRadius * Math.cos(this.cameraPhi);
    const z = this.cameraTarget.z + this.cameraRadius * Math.sin(this.cameraPhi) * Math.cos(this.cameraTheta);
    this.camera.position.set(x, y, z);
    this.camera.lookAt(this.cameraTarget);
  }

  public resetCamera(): void {
    this.cameraRadius = 2.4;
    this.cameraTheta = Math.PI / 4;
    this.cameraPhi = Math.PI / 3.2;
    this.cameraTarget.set(0, 0, 0.4);
    this.updateCameraPosition();
  }

  private setupEventListeners(): void {
    const el = this.canvasContainerRef.nativeElement;

    el.addEventListener('mousedown', (e: MouseEvent) => {
      this.isMouseDown = e.button === 0;
      this.isRightMouseDown = e.button === 2;
      this.mouseX = e.clientX;
      this.mouseY = e.clientY;
    });

    el.addEventListener('contextmenu', (e: MouseEvent) => e.preventDefault());

    window.addEventListener('mouseup', () => {
      this.isMouseDown = false;
      this.isRightMouseDown = false;
    });

    window.addEventListener('mousemove', (e: MouseEvent) => {
      if (!this.isMouseDown && !this.isRightMouseDown) return;

      const deltaX = e.clientX - this.mouseX;
      const deltaY = e.clientY - this.mouseY;
      this.mouseX = e.clientX;
      this.mouseY = e.clientY;

      if (this.isMouseDown) {
        // Orbit rotation
        this.cameraTheta -= deltaX * 0.008;
        this.cameraPhi = Math.max(0.1, Math.min(Math.PI - 0.1, this.cameraPhi - deltaY * 0.008));
      } else if (this.isRightMouseDown) {
        // Pan
        const panSpeed = 0.0015 * this.cameraRadius;
        const forward = new THREE.Vector3().subVectors(this.cameraTarget, this.camera.position).normalize();
        const right = new THREE.Vector3().crossVectors(forward, this.camera.up).normalize();
        const up = this.camera.up;

        this.cameraTarget.addScaledVector(right, -deltaX * panSpeed);
        this.cameraTarget.addScaledVector(up, deltaY * panSpeed);
      }

      this.updateCameraPosition();
    });

    el.addEventListener('wheel', (e: WheelEvent) => {
      e.preventDefault();
      this.cameraRadius = Math.max(0.6, Math.min(6.0, this.cameraRadius + e.deltaY * 0.002));
      this.updateCameraPosition();
    });

    // Resize observer
    const ro = new ResizeObserver(() => {
      if (!this.renderer || !this.camera) return;
      const w = el.clientWidth;
      const h = el.clientHeight;
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(w, h);
    });
    ro.observe(el);
  }

  private updateRobotPose(): void {
    if (!this.currentFrame || !this.scene) return;

    // Clear old links
    while (this.robotLinksGroup.children.length > 0) {
      const obj = this.robotLinksGroup.children[0];
      this.robotLinksGroup.remove(obj);
    }

    const pts = this.currentFrame.joint_3d_positions;
    if (!pts || pts.length < 2) return;

    // Three.js coordinates: Y is up, X is right, Z is front
    // Robot kinematics: Z is up, X is front, Y is left
    // Transform mapping: threeX = -kinY, threeY = kinZ, threeZ = kinX
    const mapPoint = (p: [number, number, number]): THREE.Vector3 => {
      return new THREE.Vector3(-p[1], p[2], p[0]);
    };

    // 1. Base pedestal
    const baseGeo = new THREE.CylinderGeometry(0.12, 0.14, 0.08, 24);
    const baseMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.8, roughness: 0.3 });
    const baseMesh = new THREE.Mesh(baseGeo, baseMat);
    baseMesh.position.set(0, 0.04, 0);
    this.robotLinksGroup.add(baseMesh);

    // 2. Render each link cylinder & joint spheres
    for (let i = 0; i < pts.length - 1; i++) {
      const pA = mapPoint(pts[i]);
      const pB = mapPoint(pts[i + 1]);

      // Joint sphere
      const jRadius = 0.045 - (i * 0.004);
      const jointGeo = new THREE.SphereGeometry(Math.max(0.02, jRadius), 16, 16);
      const jointMat = new THREE.MeshStandardMaterial({
        color: i === 0 ? 0x0284c7 : (i % 2 === 0 ? 0x3b82f6 : 0x0ea5e9),
        metalness: 0.6,
        roughness: 0.3
      });
      const jointMesh = new THREE.Mesh(jointGeo, jointMat);
      jointMesh.position.copy(pA);
      this.robotLinksGroup.add(jointMesh);

      // Link Cylinder connecting pA to pB
      const dist = pA.distanceTo(pB);
      if (dist > 0.01) {
        const linkRadius = Math.max(0.018, 0.038 - (i * 0.0035));
        const linkGeo = new THREE.CylinderGeometry(linkRadius * 0.9, linkRadius, dist, 16);
        const linkMat = new THREE.MeshStandardMaterial({
          color: 0x64748b,
          metalness: 0.5,
          roughness: 0.4
        });
        const linkMesh = new THREE.Mesh(linkGeo, linkMat);

        // Position cylinder at midpoint and orient along segment
        const mid = new THREE.Vector3().addVectors(pA, pB).multiplyScalar(0.5);
        linkMesh.position.copy(mid);
        linkMesh.quaternion.setFromUnitVectors(
          new THREE.Vector3(0, 1, 0),
          new THREE.Vector3().subVectors(pB, pA).normalize()
        );
        this.robotLinksGroup.add(linkMesh);
      }
    }

    // 3. End-Effector Tool Flange & Gripper
    const lastPt = mapPoint(pts[pts.length - 1]);
    this.eeMarkerMesh.position.copy(lastPt);

    // Target marker position
    if (this.currentFrame.nominal_ee_position) {
      const targetPt = mapPoint(this.currentFrame.nominal_ee_position);
      this.targetMarkerMesh.position.copy(targetPt);
    }

    // Micro-motion velocity tangent vector
    if (this.eeVectorMesh) {
      this.scene.remove(this.eeVectorMesh);
    }
    const vel = this.currentFrame.ee_velocity;
    const vLen = Math.hypot(...vel);
    if (vLen > 0.001) {
      const dir = new THREE.Vector3(-vel[1], vel[2], vel[0]).normalize();
      const length = Math.min(0.25, vLen * 0.3);
      this.eeVectorMesh = new THREE.ArrowHelper(dir, lastPt, length, 0x10b981, 0.03, 0.02);
      this.scene.add(this.eeVectorMesh);
    }
  }

  private updateTrajectoryTrail(): void {
    if (!this.scene || this.trajectoryFrames.length === 0) return;

    if (this.trajectoryLineMesh) {
      this.scene.remove(this.trajectoryLineMesh);
    }

    const points: THREE.Vector3[] = [];
    const colors: number[] = [];

    for (const f of this.trajectoryFrames) {
      const p = f.ee_position;
      points.push(new THREE.Vector3(-p[1], p[2], p[0]));
      // Color gradient based on velocity
      const v = Math.hypot(...f.ee_velocity);
      const c = new THREE.Color();
      c.setHSL(0.55 - Math.min(0.5, v * 0.4), 0.9, 0.5);
      colors.push(c.r, c.g, c.b);
    }

    const geo = new THREE.BufferGeometry().setFromPoints(points);
    geo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    const mat = new THREE.LineBasicMaterial({ vertexColors: true, linewidth: 2 });
    this.trajectoryLineMesh = new THREE.Line(geo, mat);
    this.scene.add(this.trajectoryLineMesh);
  }
}
