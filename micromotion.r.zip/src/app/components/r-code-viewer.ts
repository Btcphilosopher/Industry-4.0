import { ChangeDetectionStrategy, Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { R_SOURCE_FILES, RSourceFile } from '../core/r-source-provider';

@Component({
  selector: 'app-r-code-viewer',
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="bg-[#0F1117] border border-[#1F2937] rounded-xl p-5 shadow-2xl flex flex-col gap-4">
      <!-- Header -->
      <div class="flex items-center justify-between flex-wrap gap-3 pb-3 border-b border-[#1F2937]">
        <div class="flex items-center gap-2.5">
          <div class="w-8 h-8 bg-blue-600 rounded flex items-center justify-center font-bold text-white italic">
            R
          </div>
          <div>
            <div class="flex items-center gap-2">
              <h3 class="text-sm font-bold text-[#E0E2E6] font-mono tracking-tight uppercase">R SOURCE CODE EXPLORER</h3>
              <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20 font-semibold">
                {{ rFiles.length }} FILES AVAILABLE
              </span>
            </div>
            <p class="text-xs text-[#6B7280]">Canonical S3/S4 R packages for robotics micro-motion simulation & optimization</p>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <button
            type="button"
            id="btn-copy-r-code"
            (click)="copyActiveCode()"
            class="px-3 py-1.5 bg-[#1F2937] hover:bg-[#374151] text-[#E0E2E6] hover:text-white rounded-lg border border-[#374151] text-xs font-mono transition-all flex items-center gap-1.5 cursor-pointer active:scale-95"
          >
            <span class="material-icons text-sm text-blue-400">{{ copied() ? 'check' : 'content_copy' }}</span>
            <span>{{ copied() ? 'Copied!' : 'Copy Script' }}</span>
          </button>
          <button
            type="button"
            id="btn-download-r-code"
            (click)="downloadActiveCode()"
            class="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-mono font-semibold transition-all flex items-center gap-1.5 cursor-pointer active:scale-95 shadow-md shadow-blue-600/20"
          >
            <span class="material-icons text-sm">download</span>
            <span>Download .R</span>
          </button>
        </div>
      </div>

      <!-- File Tabs -->
      <div class="flex items-center gap-1.5 overflow-x-auto pb-1 border-b border-[#1F2937]/50 scrollbar-thin">
        @for (file of rFiles; track file.filename) {
          <button
            type="button"
            [id]="'tab-rfile-' + file.filename"
            (click)="selectedFile.set(file)"
            [class]="selectedFile().filename === file.filename ? 'bg-blue-600 text-white font-bold' : 'bg-[#0A0C10] text-[#9CA3AF] hover:text-[#E0E2E6] hover:bg-[#1F2937] border border-[#1F2937]'"
            class="px-3 py-1.5 rounded-lg text-xs font-mono whitespace-nowrap transition-all flex items-center gap-2 cursor-pointer"
          >
            <span class="material-icons text-xs opacity-75">description</span>
            <span>{{ file.filename }}</span>
            <span class="text-[9px] px-1 py-0.2 rounded bg-black/30 font-normal opacity-80">{{ file.category }}</span>
          </button>
        }
      </div>

      <!-- File Description & Path -->
      <div class="flex items-center justify-between text-xs font-mono text-[#6B7280] bg-[#0A0C10] px-3.5 py-2 rounded-lg border border-[#1F2937]">
        <div class="flex items-center gap-2">
          <span class="text-blue-400 font-bold">R/{{ selectedFile().filename }}</span>
          <span class="text-[#4B5563]">•</span>
          <span class="text-[#9CA3AF]">{{ selectedFile().description }}</span>
        </div>
        <span class="text-[10px] text-[#6B7280]">{{ getLineCount(selectedFile().content) }} lines</span>
      </div>

      <!-- Code Viewer Block -->
      <div class="relative bg-[#0A0C10] rounded-xl border border-[#1F2937] overflow-hidden">
        <pre class="p-4 text-xs font-mono text-[#E0E2E6] leading-relaxed overflow-x-auto max-h-96 selection:bg-blue-600/30 selection:text-white"><code>{{ selectedFile().content }}</code></pre>
      </div>
    </div>
  `
})
export class RCodeViewer {
  public rFiles = R_SOURCE_FILES;
  public selectedFile = signal<RSourceFile>(R_SOURCE_FILES[0]);
  public copied = signal<boolean>(false);

  public getLineCount(code: string): number {
    return code.split('\n').length;
  }

  public copyActiveCode(): void {
    navigator.clipboard.writeText(this.selectedFile().content);
    this.copied.set(true);
    setTimeout(() => this.copied.set(false), 2000);
  }

  public downloadActiveCode(): void {
    const file = this.selectedFile();
    const blob = new Blob([file.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = file.filename;
    a.click();
    URL.revokeObjectURL(url);
  }
}
