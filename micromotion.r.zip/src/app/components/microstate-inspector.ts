import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MicroMotionFrame, RobotModel } from '../core/types';

@Component({
  selector: 'app-microstate-inspector',
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="bg-[#0F1117] border border-[#1F2937] rounded-xl p-5 shadow-2xl">
      <!-- Microscope Header & Playback Scrubbing Bar -->
      <div class="flex flex-col gap-3 pb-4 border-b border-[#1F2937]">
        <div class="flex items-center justify-between flex-wrap gap-3">
          <div class="flex items-center gap-2.5">
            <div class="p-2 bg-blue-600/10 text-blue-400 rounded-lg border border-blue-600/20">
              <span class="material-icons text-xl">biotech</span>
            </div>
            <div>
              <div class="flex items-center gap-2">
                <h3 class="text-sm font-bold text-[#E0E2E6] font-mono tracking-tight uppercase">MICRO-MOTION MICROSCOPE</h3>
                <span class="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20 font-semibold">
                  dt = {{ (dt * 1000).toFixed(3) }} ms
                </span>
              </div>
              <p class="text-xs text-[#6B7280]">Sub-millisecond state transition & instantaneous dynamics analyzer</p>
            </div>
          </div>

          <!-- Playback Controls -->
          <div class="flex items-center gap-1.5 bg-[#0A0C10] p-1.5 rounded-lg border border-[#1F2937]">
            <button
              type="button"
              id="btn-step-start"
              (click)="seekTo(0)"
              title="Jump to Start"
              class="p-1.5 hover:bg-[#1F2937] text-[#6B7280] hover:text-[#E0E2E6] rounded transition-colors"
            >
              <span class="material-icons text-base">first_page</span>
            </button>
            <button
              type="button"
              id="btn-step-prev-10"
              (click)="stepBy(-10)"
              title="Step -10 Micro-states"
              class="px-2 py-1 text-xs font-mono bg-[#0F1117] hover:bg-[#1F2937] text-[#9CA3AF] rounded border border-[#1F2937]"
            >
              -10
            </button>
            <button
              type="button"
              id="btn-step-prev-1"
              (click)="stepBy(-1)"
              title="Step -1 Micro-state (Exact dt)"
              class="p-1.5 hover:bg-[#1F2937] text-[#9CA3AF] hover:text-white rounded transition-colors bg-[#0F1117] border border-[#1F2937]"
            >
              <span class="material-icons text-base">chevron_left</span>
            </button>

            <!-- Play / Pause Toggle -->
            <button
              type="button"
              id="btn-toggle-play"
              (click)="togglePlay.emit()"
              [class]="isPlaying ? 'bg-orange-500/20 text-orange-300 border-orange-500/30' : 'bg-blue-600/20 text-blue-300 border-blue-500/30'"
              class="px-3 py-1.5 rounded font-mono text-xs font-semibold border flex items-center gap-1.5 transition-all shadow-sm cursor-pointer"
            >
              <span class="material-icons text-base">{{ isPlaying ? 'pause' : 'play_arrow' }}</span>
              <span>{{ isPlaying ? 'PAUSE' : 'PLAY' }}</span>
            </button>

            <button
              type="button"
              id="btn-step-next-1"
              (click)="stepBy(1)"
              title="Step +1 Micro-state (Exact dt)"
              class="p-1.5 hover:bg-[#1F2937] text-[#9CA3AF] hover:text-white rounded transition-colors bg-[#0F1117] border border-[#1F2937]"
            >
              <span class="material-icons text-base">chevron_right</span>
            </button>
            <button
              type="button"
              id="btn-step-next-10"
              (click)="stepBy(10)"
              title="Step +10 Micro-states"
              class="px-2 py-1 text-xs font-mono bg-[#0F1117] hover:bg-[#1F2937] text-[#9CA3AF] rounded border border-[#1F2937]"
            >
              +10
            </button>
            <button
              type="button"
              id="btn-step-end"
              (click)="seekTo(totalFrames - 1)"
              title="Jump to End"
              class="p-1.5 hover:bg-[#1F2937] text-[#6B7280] hover:text-[#E0E2E6] rounded transition-colors"
            >
              <span class="material-icons text-base">last_page</span>
            </button>

            <!-- Speed Multiplier -->
            <div class="flex items-center gap-1 pl-2 border-l border-[#1F2937]">
              <span class="text-[10px] font-mono text-[#6B7280]">SPEED:</span>
              @for (spd of [0.1, 1.0, 5.0, 20.0]; track spd) {
                <button
                  type="button"
                  [id]="'btn-speed-' + spd"
                  (click)="playbackSpeedChange.emit(spd)"
                  [class]="playbackSpeed === spd ? 'bg-blue-600 text-white font-bold' : 'text-[#6B7280] hover:bg-[#1F2937] hover:text-[#E0E2E6]'"
                  class="px-1.5 py-0.5 rounded text-[11px] font-mono transition-colors cursor-pointer"
                >
                  {{ spd }}x
                </button>
              }
            </div>
          </div>
        </div>

        <!-- Micro-State Timeline Slider -->
        <div class="flex items-center gap-3">
          <span class="text-xs font-mono text-[#6B7280] w-16 text-right">
            {{ currentFrame ? currentFrame.timestamp.toFixed(4) : '0.0000' }} s
          </span>
          <input
            type="range"
            id="input-microstate-slider"
            [min]="0"
            [max]="totalFrames - 1"
            [value]="currentIndex"
            (input)="onSliderChange($event)"
            class="flex-1 accent-blue-500 h-1.5 bg-[#1F2937] rounded-lg appearance-none cursor-pointer"
          />
          <div class="flex items-center gap-1.5 text-xs font-mono text-[#6B7280] w-28">
            <span class="text-blue-400 font-bold">#{{ currentIndex + 1 }}</span>
            <span class="text-[#4B5563]">/</span>
            <span>{{ totalFrames }}</span>
          </div>
        </div>
      </div>

      <!-- Micro-State Core Numerical Dashboard -->
      @if (currentFrame) {
        <div class="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
          <!-- Column 1: Cartesian End-Effector State -->
          <div class="bg-[#0A0C10] rounded-xl p-3.5 border border-[#1F2937] flex flex-col gap-2.5">
            <div class="flex items-center justify-between text-xs font-mono border-b border-[#1F2937] pb-1.5">
              <span class="text-[#6B7280] font-bold uppercase tracking-wider flex items-center gap-1.5 text-[10px]">
                <span class="material-icons text-sm text-blue-400">precision_manufacturing</span>
                CARTESIAN END-EFFECTOR
              </span>
              <span class="text-[10px] text-[#6B7280]">T = {{ currentFrame.timestamp.toFixed(4) }}s</span>
            </div>

            <div class="grid grid-cols-3 gap-2 text-center font-mono">
              <div class="bg-[#0F1117] p-2 rounded-lg border border-[#1F2937]">
                <div class="text-[10px] text-[#6B7280]">X (m)</div>
                <div class="text-sm font-bold text-blue-400">{{ currentFrame.ee_position[0].toFixed(4) }}</div>
                <div class="text-[10px] text-green-400">Δ {{ (currentFrame.delta_ee_position[0] * 1e6).toFixed(1) }} µm</div>
              </div>
              <div class="bg-[#0F1117] p-2 rounded-lg border border-[#1F2937]">
                <div class="text-[10px] text-[#6B7280]">Y (m)</div>
                <div class="text-sm font-bold text-blue-400">{{ currentFrame.ee_position[1].toFixed(4) }}</div>
                <div class="text-[10px] text-green-400">Δ {{ (currentFrame.delta_ee_position[1] * 1e6).toFixed(1) }} µm</div>
              </div>
              <div class="bg-[#0F1117] p-2 rounded-lg border border-[#1F2937]">
                <div class="text-[10px] text-[#6B7280]">Z (m)</div>
                <div class="text-sm font-bold text-blue-400">{{ currentFrame.ee_position[2].toFixed(4) }}</div>
                <div class="text-[10px] text-green-400">Δ {{ (currentFrame.delta_ee_position[2] * 1e6).toFixed(1) }} µm</div>
              </div>
            </div>

            <!-- Orientation Roll / Pitch / Yaw -->
            <div class="flex items-center justify-between text-xs font-mono bg-[#0F1117] p-2 rounded-lg border border-[#1F2937]">
              <span class="text-[#6B7280]">Roll/Pitch/Yaw:</span>
              <span class="text-[#E0E2E6]">
                [{{ (currentFrame.ee_orientation[0] * 180 / 3.14159).toFixed(1) }}°,
                 {{ (currentFrame.ee_orientation[1] * 180 / 3.14159).toFixed(1) }}°,
                 {{ (currentFrame.ee_orientation[2] * 180 / 3.14159).toFixed(1) }}°]
              </span>
            </div>

            <!-- Instantaneous Velocity & Step Norm -->
            <div class="flex items-center justify-between text-xs font-mono bg-[#0F1117] p-2 rounded-lg border border-[#1F2937]">
              <span class="text-[#6B7280]">Micro-Step Distance:</span>
              <span class="text-green-400 font-bold">{{ (currentFrame.delta_ee_distance * 1000).toFixed(4) }} mm</span>
            </div>
          </div>

          <!-- Column 2: Closed-Loop Digital Twin & Tracking Error -->
          <div class="bg-[#0A0C10] rounded-xl p-3.5 border border-[#1F2937] flex flex-col gap-2.5">
            <div class="flex items-center justify-between text-xs font-mono border-b border-[#1F2937] pb-1.5">
              <span class="text-[#6B7280] font-bold uppercase tracking-wider flex items-center gap-1.5 text-[10px]">
                <span class="material-icons text-sm text-orange-400">track_changes</span>
                DIGITAL TWIN TRACKING
              </span>
              @if (currentFrame.micro_correction_applied) {
                <span class="text-[10px] bg-green-500/10 text-green-400 px-2 py-0.5 rounded border border-green-500/20 font-bold">
                  CORRECTED (DLS)
                </span>
              } @else {
                <span class="text-[10px] text-[#6B7280]">NOMINAL</span>
              }
            </div>

            <div class="bg-[#0F1117] p-3 rounded-lg border border-[#1F2937] flex flex-col gap-1.5">
              <div class="flex items-center justify-between text-xs font-mono">
                <span class="text-[#6B7280]">Tracking Error:</span>
                <span [class]="currentFrame.tracking_error_um > 15 ? 'text-orange-400 font-bold' : 'text-green-400 font-bold'">
                  {{ currentFrame.tracking_error_um.toFixed(2) }} µm
                </span>
              </div>
              <!-- Error gauge bar -->
              <div class="w-full bg-[#1F2937] h-1.5 rounded-full overflow-hidden">
                <div
                  class="h-full transition-all duration-150"
                  [style.width.%]="Math.min(100, (currentFrame.tracking_error_um / 40) * 100)"
                  [class]="currentFrame.tracking_error_um > 20 ? 'bg-orange-500' : 'bg-blue-500'"
                ></div>
              </div>
              <div class="flex justify-between text-[10px] font-mono text-[#6B7280]">
                <span>0 µm</span>
                <span>Tol: 15 µm</span>
                <span>40 µm</span>
              </div>
            </div>

            <div class="grid grid-cols-2 gap-2 text-xs font-mono">
              <div class="bg-[#0F1117] p-2 rounded-lg border border-[#1F2937]">
                <div class="text-[10px] text-[#6B7280]">Cartesian Velocity</div>
                <div class="text-[#E0E2E6] font-semibold mt-0.5">
                  {{ Math.hypot(currentFrame.ee_velocity[0], currentFrame.ee_velocity[1], currentFrame.ee_velocity[2]).toFixed(3) }} m/s
                </div>
              </div>
              <div class="bg-[#0F1117] p-2 rounded-lg border border-[#1F2937]">
                <div class="text-[10px] text-[#6B7280]">Cartesian Accel</div>
                <div class="text-[#E0E2E6] font-semibold mt-0.5">
                  {{ Math.hypot(currentFrame.ee_acceleration[0], currentFrame.ee_acceleration[1], currentFrame.ee_acceleration[2]).toFixed(2) }} m/s²
                </div>
              </div>
            </div>
          </div>

          <!-- Column 3: Instantaneous Energy & Power Dynamics -->
          <div class="bg-[#0A0C10] rounded-xl p-3.5 border border-[#1F2937] flex flex-col gap-2.5">
            <div class="flex items-center justify-between text-xs font-mono border-b border-[#1F2937] pb-1.5">
              <span class="text-[#6B7280] font-bold uppercase tracking-wider flex items-center gap-1.5 text-[10px]">
                <span class="material-icons text-sm text-green-400">bolt</span>
                ENERGY & POWER
              </span>
              <span class="text-[10px] text-[#6B7280]">MICRO-STEP</span>
            </div>

            <div class="grid grid-cols-2 gap-2 font-mono">
              <div class="bg-[#0F1117] p-2.5 rounded-lg border border-[#1F2937]">
                <div class="text-[10px] text-[#6B7280]">Instantaneous Power</div>
                <div class="text-sm font-bold text-green-400 mt-0.5">
                  {{ sumArray(currentFrame.joint_powers).toFixed(1) }} W
                </div>
              </div>
              <div class="bg-[#0F1117] p-2.5 rounded-lg border border-[#1F2937]">
                <div class="text-[10px] text-[#6B7280]">Cumulative Energy</div>
                <div class="text-sm font-bold text-blue-400 mt-0.5">
                  {{ currentFrame.cumulative_energy_joules.toFixed(2) }} J
                </div>
              </div>
            </div>

            <div class="bg-[#0F1117] p-2 rounded-lg border border-[#1F2937] text-xs font-mono flex items-center justify-between">
              <span class="text-[#6B7280]">Micro-Step Energy (ΔE):</span>
              <span class="text-green-400 font-bold">
                {{ (currentFrame.delta_energy_joules * 1000).toFixed(4) }} mJ
              </span>
            </div>
          </div>
        </div>

        <!-- Micro-Motion Joint State Matrix Table -->
        <div class="mt-4 overflow-x-auto rounded-xl border border-[#1F2937] bg-[#0A0C10]">
          <table class="w-full text-left font-mono text-xs text-[#E0E2E6]">
            <thead class="bg-[#151821] text-[10px] text-[#6B7280] uppercase tracking-wider border-b border-[#1F2937]">
              <tr>
                <th class="py-2 px-3">Joint</th>
                <th class="py-2 px-3">Angle θ (rad)</th>
                <th class="py-2 px-3">Δθ (µrad)</th>
                <th class="py-2 px-3">Velocity ω (rad/s)</th>
                <th class="py-2 px-3">Accel α (rad/s²)</th>
                <th class="py-2 px-3">Jerk j (rad/s³)</th>
                <th class="py-2 px-3">Torque τ (Nm)</th>
                <th class="py-2 px-3">Power P (W)</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#1F2937]/50">
              @for (pos of currentFrame.joint_positions; track $index) {
                <tr class="hover:bg-blue-600/5 transition-colors">
                  <td class="py-2 px-3 font-bold text-blue-400">J{{ $index + 1 }}</td>
                  <td class="py-2 px-3">{{ pos.toFixed(5) }}</td>
                  <td class="py-2 px-3 text-green-400 font-semibold">
                    {{ (currentFrame.delta_positions[$index] * 1e6).toFixed(1) }}
                  </td>
                  <td class="py-2 px-3">{{ currentFrame.joint_velocities[$index].toFixed(4) }}</td>
                  <td class="py-2 px-3">{{ currentFrame.joint_accelerations[$index].toFixed(3) }}</td>
                  <td class="py-2 px-3" [class.text-orange-400]="Math.abs(currentFrame.joint_jerks[$index]) > 30">
                    {{ currentFrame.joint_jerks[$index].toFixed(2) }}
                  </td>
                  <td class="py-2 px-3" [class.text-orange-400]="Math.abs(currentFrame.joint_torques[$index]) > 50">
                    {{ currentFrame.joint_torques[$index].toFixed(2) }}
                  </td>
                  <td class="py-2 px-3 text-green-400">
                    {{ currentFrame.joint_powers[$index].toFixed(2) }}
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      }
    </div>
  `
})
export class MicrostateInspector {
  @Input() currentFrame: MicroMotionFrame | null = null;
  @Input() currentIndex = 0;
  @Input() totalFrames = 1;
  @Input() dt = 0.001;
  @Input() isPlaying = false;
  @Input() playbackSpeed = 1.0;
  @Input() activeRobot: RobotModel | null = null;

  @Output() indexChange = new EventEmitter<number>();
  @Output() togglePlay = new EventEmitter<void>();
  @Output() playbackSpeedChange = new EventEmitter<number>();

  protected Math = Math;

  public seekTo(index: number): void {
    const clamped = Math.max(0, Math.min(this.totalFrames - 1, index));
    this.indexChange.emit(clamped);
  }

  public stepBy(delta: number): void {
    this.seekTo(this.currentIndex + delta);
  }

  public onSliderChange(event: Event): void {
    const target = event.target as HTMLInputElement;
    this.seekTo(parseInt(target.value, 10));
  }

  public sumArray(arr: number[]): number {
    return arr ? arr.reduce((acc, v) => acc + Math.max(0, v), 0) : 0;
  }
}
