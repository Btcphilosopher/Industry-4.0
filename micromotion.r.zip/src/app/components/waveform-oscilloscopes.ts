import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MicroMotionFrame, MicroMotionResult } from '../core/types';

type ChannelType = 'position' | 'velocity' | 'acceleration' | 'jerk' | 'torque' | 'power' | 'tracking_error';

@Component({
  selector: 'app-waveform-oscilloscopes',
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="bg-[#0F1117] border border-[#1F2937] rounded-xl p-5 shadow-2xl flex flex-col gap-4">
      <!-- Oscilloscope Header & Channel Selector -->
      <div class="flex items-center justify-between flex-wrap gap-3 pb-3 border-b border-[#1F2937]">
        <div class="flex items-center gap-2.5">
          <div class="p-2 bg-blue-600/10 text-blue-400 rounded-lg border border-blue-600/20">
            <span class="material-icons text-xl">show_chart</span>
          </div>
          <div>
            <h3 class="text-sm font-bold text-[#E0E2E6] font-mono tracking-tight uppercase">MICRO-MOTION OSCILLOSCOPE</h3>
            <p class="text-xs text-[#6B7280]">High-temporal resolution multi-channel physical derivative inspector</p>
          </div>
        </div>

        <!-- Channel Switcher -->
        <div class="flex items-center gap-1 bg-[#0A0C10] p-1 rounded-lg border border-[#1F2937] flex-wrap">
          @for (ch of channels; track ch.id) {
            <button
              type="button"
              [id]="'btn-channel-' + ch.id"
              (click)="selectChannel(ch.id)"
              [class]="selectedChannel === ch.id ? 'bg-blue-600 text-white font-bold shadow-sm' : 'text-[#6B7280] hover:text-[#E0E2E6] hover:bg-[#1F2937]'"
              class="px-2.5 py-1 text-xs font-mono rounded transition-all cursor-pointer"
            >
              {{ ch.label }}
            </button>
          }
        </div>
      </div>

      <!-- Canvas Plot Area -->
      <div class="relative w-full h-64 bg-[#0A0C10] rounded-xl border border-[#1F2937] overflow-hidden cursor-crosshair">
        <canvas #plotCanvas class="w-full h-full block" (click)="onCanvasClick($event)"></canvas>

        <!-- Current Time Cursor Badge -->
        @if (currentFrame) {
          <div class="absolute top-2.5 right-3 bg-[#0F1117]/95 backdrop-blur-md px-2.5 py-1 rounded-lg border border-[#1F2937] text-xs font-mono text-[#E0E2E6] pointer-events-none shadow-lg">
            Cursor: <span class="text-green-400 font-bold">{{ currentFrame.timestamp.toFixed(4) }} s</span>
            <span class="text-[#6B7280] ml-1">(Frame #{{ currentIndex + 1 }})</span>
          </div>
        }
      </div>

      <!-- Joint Color Legend -->
      <div class="flex items-center justify-between flex-wrap gap-2 text-xs font-mono pt-1">
        <div class="flex items-center gap-4 flex-wrap">
          @for (j of [1,2,3,4,5,6]; track j) {
            <div class="flex items-center gap-1.5">
              <span class="w-2.5 h-2.5 rounded-full" [style.background-color]="getJointColor(j - 1)"></span>
              <span class="text-[#E0E2E6] font-semibold">J{{ j }}</span>
            </div>
          }
        </div>
        <div class="text-[11px] text-[#6B7280]">
          Click graph to seek timeline to exact microsecond
        </div>
      </div>
    </div>
  `
})
export class WaveformOscilloscopes implements OnChanges {
  @ViewChild('plotCanvas', { static: true }) plotCanvasRef!: ElementRef<HTMLCanvasElement>;

  @Input() simResult: MicroMotionResult | null = null;
  @Input() currentFrame: MicroMotionFrame | null = null;
  @Input() currentIndex = 0;

  @Output() indexChange = new EventEmitter<number>();

  public selectedChannel: ChannelType = 'jerk';

  public channels: { id: ChannelType; label: string }[] = [
    { id: 'jerk', label: 'Jerk j(t)' },
    { id: 'acceleration', label: 'Accel α(t)' },
    { id: 'velocity', label: 'Velocity ω(t)' },
    { id: 'torque', label: 'Torque τ(t)' },
    { id: 'position', label: 'Position θ(t)' },
    { id: 'power', label: 'Power P(t)' },
    { id: 'tracking_error', label: 'Tracking Error' }
  ];

  private jointColors = [
    '#38bdf8', // J1 Sky
    '#34d399', // J2 Emerald
    '#fbbf24', // J3 Amber
    '#f87171', // J4 Red
    '#a78bfa', // J5 Purple
    '#f472b6'  // J6 Pink
  ];

  public getJointColor(idx: number): string {
    return this.jointColors[idx % this.jointColors.length];
  }

  public selectChannel(ch: ChannelType): void {
    this.selectedChannel = ch;
    this.draw();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['simResult'] || changes['currentFrame'] || changes['currentIndex']) {
      this.draw();
    }
  }

  public onCanvasClick(event: MouseEvent): void {
    if (!this.simResult || this.simResult.frames.length === 0) return;
    const canvas = this.plotCanvasRef.nativeElement;
    const rect = canvas.getBoundingClientRect();
    const clickX = event.clientX - rect.left;
    const fraction = Math.max(0, Math.min(1, clickX / rect.width));
    const targetIdx = Math.floor(fraction * (this.simResult.frames.length - 1));
    this.indexChange.emit(targetIdx);
  }

  private draw(): void {
    const canvas = this.plotCanvasRef?.nativeElement;
    if (!canvas || !this.simResult || this.simResult.frames.length === 0) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = (canvas.width = canvas.parentElement?.clientWidth || 800);
    const height = (canvas.height = canvas.parentElement?.clientHeight || 256);

    ctx.clearRect(0, 0, width, height);

    const frames = this.simResult.frames;
    const n = frames.length;
    const dof = this.simResult.robot.dof;

    // Determine min and max for scaling
    let minY = Infinity;
    let maxY = -Infinity;

    if (this.selectedChannel === 'tracking_error') {
      minY = 0;
      maxY = Math.max(1e-5, Math.max(...frames.map((f) => f.tracking_error_um)));
    } else {
      for (const f of frames) {
        let vals: number[] = [];
        switch (this.selectedChannel) {
          case 'position': vals = f.joint_positions; break;
          case 'velocity': vals = f.joint_velocities; break;
          case 'acceleration': vals = f.joint_accelerations; break;
          case 'jerk': vals = f.joint_jerks; break;
          case 'torque': vals = f.joint_torques; break;
          case 'power': vals = f.joint_powers; break;
        }
        for (const v of vals) {
          if (v < minY) minY = v;
          if (v > maxY) maxY = v;
        }
      }
    }

    // Add padding to Y range
    const yRange = (maxY - minY) || 1.0;
    const yMinPad = minY - yRange * 0.1;
    const yMaxPad = maxY + yRange * 0.1;
    const totalYRange = yMaxPad - yMinPad;

    const mapX = (idx: number) => (idx / (n - 1)) * width;
    const mapY = (val: number) => height - ((val - yMinPad) / totalYRange) * height;

    // Draw Grid & Zero Line
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;
    for (let g = 0; g <= 4; g++) {
      const yLine = (height / 4) * g;
      ctx.beginPath();
      ctx.moveTo(0, yLine);
      ctx.lineTo(width, yLine);
      ctx.stroke();
    }

    // Draw Zero line if in range
    if (yMinPad < 0 && yMaxPad > 0) {
      const zeroY = mapY(0);
      ctx.strokeStyle = '#334155';
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(0, zeroY);
      ctx.lineTo(width, zeroY);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // Draw Channel Lines
    if (this.selectedChannel === 'tracking_error') {
      ctx.beginPath();
      ctx.strokeStyle = '#34d399';
      ctx.lineWidth = 2;
      for (let i = 0; i < n; i++) {
        const x = mapX(i);
        const y = mapY(frames[i].tracking_error_um);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      // Tolerance line at 15um
      const tolY = mapY(15);
      ctx.strokeStyle = '#f59e0b';
      ctx.setLineDash([6, 4]);
      ctx.beginPath();
      ctx.moveTo(0, tolY);
      ctx.lineTo(width, tolY);
      ctx.stroke();
      ctx.setLineDash([]);
    } else {
      for (let j = 0; j < dof; j++) {
        ctx.beginPath();
        ctx.strokeStyle = this.getJointColor(j);
        ctx.lineWidth = 1.8;

        for (let i = 0; i < n; i++) {
          const f = frames[i];
          let val = 0;
          switch (this.selectedChannel) {
            case 'position': val = f.joint_positions[j]; break;
            case 'velocity': val = f.joint_velocities[j]; break;
            case 'acceleration': val = f.joint_accelerations[j]; break;
            case 'jerk': val = f.joint_jerks[j]; break;
            case 'torque': val = f.joint_torques[j]; break;
            case 'power': val = f.joint_powers[j]; break;
          }
          const x = mapX(i);
          const y = mapY(val);
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.stroke();
      }
    }

    // Draw Current Time Cursor
    const cursorX = mapX(this.currentIndex);
    ctx.strokeStyle = '#10b981';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([2, 2]);
    ctx.beginPath();
    ctx.moveTo(cursorX, 0);
    ctx.lineTo(cursorX, height);
    ctx.stroke();
    ctx.setLineDash([]);
  }
}
