import { ChangeDetectionStrategy, Component, computed, inject, signal, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { AVAILABLE_ROBOT_MODELS, STANDARD_6AXIS_COBOT } from './core/robot-models';
import { SimulationEngine } from './core/simulation';
import { OptimizerEngine } from './core/optimizer';
import { DEFAULT_DEMO_TASK } from './core/task-decomposition';
import { TelemetryAnalyzer, TelemetryReport } from './core/telemetry-analysis';
import {
  DecomposedTask,
  MicroMotionFrame,
  MicroMotionResult,
  OptimizationComparison,
  OptimizationWeights,
  PrecisionMode,
  RobotModel,
  SimulationTimestep,
  TrajectoryProfileType
} from './core/types';
import { Robot3dViewer } from './components/robot-3d-viewer';
import { MicrostateInspector } from './components/microstate-inspector';
import { WaveformOscilloscopes } from './components/waveform-oscilloscopes';
import { RCodeViewer } from './components/r-code-viewer';

type AppTab = 'workspace' | 'optimizer' | 'workcell' | 'r_source';

@Component({
  selector: 'app-root',
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: true,
  imports: [
    CommonModule,
    Robot3dViewer,
    MicrostateInspector,
    WaveformOscilloscopes,
    RCodeViewer
  ],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App implements OnInit, OnDestroy {
  public Math = Math;
  private http = inject(HttpClient);

  public sumArray(arr: number[]): number {
    return arr.reduce((acc, val) => acc + val, 0);
  }

  // Available Robot Models & Active Robot
  public robotModels: RobotModel[] = AVAILABLE_ROBOT_MODELS;
  public activeRobot = signal<RobotModel>(STANDARD_6AXIS_COBOT);

  // Active View Tab
  public activeTab = signal<AppTab>('workspace');

  // Simulation Parameters & State
  public timestep = signal<SimulationTimestep>(0.001);
  public precisionMode = signal<PrecisionMode>('BALANCED');
  public profileType = signal<TrajectoryProfileType>('min_jerk');
  public disturbanceScale = signal<number>(1.0);

  // Multi-Objective Weights
  public weights = signal<OptimizationWeights>({
    time: 1.0,
    energy: 1.0,
    jerk: 2.0,
    torque: 1.0,
    precision: 3.0,
    vibration: 1.5
  });

  // Current Active Simulation
  public currentSimulation = signal<MicroMotionResult | null>(null);
  public telemetryReport = signal<TelemetryReport | null>(null);
  public isSimulating = signal<boolean>(false);

  // Playback State for Microscope & 3D Twin
  public currentFrameIndex = signal<number>(0);
  public isPlaying = signal<boolean>(false);
  public playbackSpeed = signal<number>(1.0);
  private playbackTimer: number | null = null;

  // Task & Stage Decomposition
  public activeTask = signal<DecomposedTask>(DEFAULT_DEMO_TASK);
  public activeStageIndex = signal<number>(0);

  // Optimization Result
  public optimizationResult = signal<OptimizationComparison | null>(null);
  public isOptimizing = signal<boolean>(false);

  // Computed Values
  public currentFrame = computed<MicroMotionFrame | null>(() => {
    const sim = this.currentSimulation();
    if (!sim || sim.frames.length === 0) return null;
    const idx = Math.min(sim.frames.length - 1, Math.max(0, this.currentFrameIndex()));
    return sim.frames[idx];
  });

  public activeStage = computed(() => {
    const task = this.activeTask();
    const idx = this.activeStageIndex();
    return task.stages[idx] || task.stages[0];
  });

  public jointLoads = computed<{ percent: number; torque: number }[]>(() => {
    const frame = this.currentFrame();
    const robot = this.activeRobot();
    if (!frame) return Array(6).fill({ percent: 0, torque: 0 });

    return frame.joint_torques.map((t, i) => {
      const maxT = robot.dh_parameters[i]?.torque_max || 100;
      const percent = Math.min(100, Math.round((Math.abs(t) / maxT) * 100));
      return { percent, torque: t };
    });
  });

  ngOnInit(): void {
    this.runStageSimulation(0);
  }

  ngOnDestroy(): void {
    this.stopPlayback();
  }

  // Set Robot
  public selectRobot(robotId: string): void {
    const found = this.robotModels.find((r) => r.id === robotId);
    if (found) {
      this.activeRobot.set(found);
      this.runStageSimulation(this.activeStageIndex());
    }
  }

  // Set Precision Mode
  public setPrecisionMode(mode: PrecisionMode): void {
    this.precisionMode.set(mode);
    switch (mode) {
      case 'ULTRA_PRECISION':
        this.profileType.set('septic');
        this.updateWeight('precision', 5.0);
        this.updateWeight('jerk', 3.0);
        break;
      case 'PRECISION':
        this.profileType.set('min_jerk');
        this.updateWeight('precision', 3.0);
        this.updateWeight('jerk', 2.0);
        break;
      case 'ENERGY_SAVING':
        this.profileType.set('min_energy');
        this.updateWeight('energy', 4.0);
        break;
      case 'FAST':
        this.profileType.set('quintic');
        this.updateWeight('time', 3.0);
        break;
      case 'BALANCED':
        this.profileType.set('min_jerk');
        this.updateWeight('time', 1.0);
        this.updateWeight('energy', 1.0);
        this.updateWeight('jerk', 2.0);
        this.updateWeight('precision', 3.0);
        break;
    }
    this.runStageSimulation(this.activeStageIndex());
  }

  public updateWeight(key: keyof OptimizationWeights, val: number): void {
    this.weights.update((w) => ({ ...w, [key]: val }));
  }

  public setTimestep(val: number): void {
    this.timestep.set(val as SimulationTimestep);
    this.runStageSimulation(this.activeStageIndex());
  }

  // Run Simulation for Specific Workcell Stage
  public runStageSimulation(stageIndex: number): void {
    this.activeStageIndex.set(stageIndex);
    const stage = this.activeTask().stages[stageIndex];
    if (!stage) return;

    this.isSimulating.set(true);

    // Micro-motion simulation execution
    setTimeout(() => {
      const sim = SimulationEngine.simulateMicroMotion({
        robot: this.activeRobot(),
        initialState: stage.from_joint,
        targetState: stage.to_joint,
        duration: stage.duration,
        dt: this.timestep(),
        profileType: this.profileType(),
        enableMicroCorrection: true,
        disturbanceScale: this.disturbanceScale() * 0.00004
      });

      const report = TelemetryAnalyzer.analyze(sim);

      this.currentSimulation.set(sim);
      this.telemetryReport.set(report);
      this.currentFrameIndex.set(0);
      this.isSimulating.set(false);

      if (this.isPlaying()) {
        this.startPlayback();
      }
    }, 10);
  }

  // Trigger Multi-Objective Optimization
  public runOptimization(): void {
    const stage = this.activeStage();
    this.isOptimizing.set(true);

    setTimeout(() => {
      const comparison = OptimizerEngine.optimizeTrajectory(
        this.activeRobot(),
        stage.from_joint,
        stage.to_joint,
        this.precisionMode(),
        this.timestep(),
        this.weights()
      );

      this.optimizationResult.set(comparison);
      this.isOptimizing.set(false);
      this.activeTab.set('optimizer');
    }, 20);
  }

  // Playback Engine
  public togglePlayback(): void {
    if (this.isPlaying()) {
      this.stopPlayback();
    } else {
      this.startPlayback();
    }
  }

  public startPlayback(): void {
    this.stopPlayback();
    this.isPlaying.set(true);

    const intervalMs = 25; // 40 FPS refresh
    this.playbackTimer = window.setInterval(() => {
      const sim = this.currentSimulation();
      if (!sim) return;

      const stepIncrement = Math.max(1, Math.round((this.playbackSpeed() * intervalMs) / (this.timestep() * 1000)));
      const nextIdx = this.currentFrameIndex() + stepIncrement;

      if (nextIdx >= sim.frames.length) {
        this.currentFrameIndex.set(0);
      } else {
        this.currentFrameIndex.set(nextIdx);
      }
    }, intervalMs);
  }

  public stopPlayback(): void {
    this.isPlaying.set(false);
    if (this.playbackTimer !== null) {
      clearInterval(this.playbackTimer);
      this.playbackTimer = null;
    }
  }

  public setFrameIndex(idx: number): void {
    this.currentFrameIndex.set(idx);
  }

  public setPlaybackSpeed(spd: number): void {
    this.playbackSpeed.set(spd);
  }

  // Export Telemetry
  public exportCSV(): void {
    const sim = this.currentSimulation();
    if (!sim) return;

    let csv = 'Timestamp_s,EE_X_m,EE_Y_m,EE_Z_m,Tracking_Error_um,Instant_Power_W,';
    csv += 'J1_pos_rad,J2_pos_rad,J3_pos_rad,J4_pos_rad,J5_pos_rad,J6_pos_rad,';
    csv += 'J1_vel_rad_s,J2_vel_rad_s,J3_vel_rad_s,J4_vel_rad_s,J5_vel_rad_s,J6_vel_rad_s,';
    csv += 'J1_tau_Nm,J2_tau_Nm,J3_tau_Nm,J4_tau_Nm,J5_tau_Nm,J6_tau_Nm\n';

    for (const f of sim.frames) {
      const row = [
        f.timestamp.toFixed(5),
        f.ee_position[0].toFixed(5),
        f.ee_position[1].toFixed(5),
        f.ee_position[2].toFixed(5),
        f.tracking_error_um.toFixed(3),
        f.joint_powers.reduce((a, b) => a + b, 0).toFixed(2),
        ...f.joint_positions.map((p) => p.toFixed(5)),
        ...f.joint_velocities.map((v) => v.toFixed(4)),
        ...f.joint_torques.map((t) => t.toFixed(3))
      ];
      csv += row.join(',') + '\n';
    }

    this.triggerDownload(csv, `MicroMotion_${this.activeRobot().id}_telemetry.csv`, 'text/csv');
  }

  public exportJSON(): void {
    const sim = this.currentSimulation();
    if (!sim) return;

    const data = {
      robot: sim.robot,
      metadata: {
        engine: 'MicroMotion.R v2.4.0',
        timestamp: new Date().toISOString(),
        total_frames: sim.n_frames,
        dt_seconds: sim.dt
      },
      metrics: {
        total_energy_joules: sim.total_energy_joules,
        max_jerk: sim.max_jerk,
        max_torque: sim.max_torque,
        max_tracking_error_um: sim.max_tracking_error.value_um
      },
      frames: sim.frames
    };

    this.triggerDownload(JSON.stringify(data, null, 2), `MicroMotion_${this.activeRobot().id}_states.json`, 'application/json');
  }

  private triggerDownload(content: string, filename: string, type: string): void {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }
}
