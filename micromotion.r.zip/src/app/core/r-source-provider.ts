export interface RSourceFile {
  filename: string;
  category: 'Core' | 'Kinematics' | 'Dynamics' | 'Trajectory' | 'Simulation' | 'Optimization' | 'Telemetry' | 'Export' | 'Demo' | 'Tests';
  description: string;
  content: string;
}

export const R_SOURCE_FILES: RSourceFile[] = [
  {
    filename: 'MicroMotion.R',
    category: 'Core',
    description: 'Master package initialization, robot geometry S3 class, DH parameters and base frames',
    content: `# MicroMotion.R - Robotic Micro-Motion Digital Twin Core
# (c) Research-Grade Robotics Numerical Engine

create_robot <- function(name = "MicroMotion-6DOF-Cobot", payload_kg = 2.5) {
  dh_table <- data.frame(
    joint = 1:6,
    d = c(0.1807, 0.0, 0.0, 0.1741, 0.1198, 0.1165),
    a = c(0.0, -0.6127, -0.5715, 0.0, 0.0, 0.0),
    alpha = c(pi/2, 0.0, 0.0, pi/2, -pi/2, 0.0),
    mass = c(7.3, 13.9, 4.8, 2.1, 1.9, 0.6),
    inertia_zz = c(0.025, 0.280, 0.110, 0.007, 0.005, 0.001),
    q_min = c(-2*pi, -pi, -pi, -2*pi, -2*pi, -2*pi),
    q_max = c(2*pi, pi, pi, 2*pi, 2*pi, 2*pi),
    v_max = c(2.09, 2.09, 3.14, 3.14, 3.14, 6.28),
    torque_max = c(330, 330, 150, 56, 56, 28)
  )
  robot <- list(name = name, dof = 6, payload_kg = payload_kg, dh = dh_table, tolerance = 1e-5)
  class(robot) <- c("micro_robot", "list")
  return(robot)
}

forward_kinematics <- function(robot, q) {
  dh <- robot$dh
  T_curr <- diag(4)
  for (i in 1:robot$dof) {
    th <- q[i]; d <- dh$d[i]; a <- dh$a[i]; al <- dh$alpha[i]
    Ti <- matrix(c(
      cos(th), -sin(th)*cos(al),  sin(th)*sin(al), a*cos(th),
      sin(th),  cos(th)*cos(al), -cos(th)*sin(al), a*sin(th),
      0,        sin(al),          cos(al),         d,
      0,        0,                0,               1
    ), nrow=4, byrow=TRUE)
    T_curr <- T_curr %*% Ti
  }
  list(ee_position = T_curr[1:3, 4], T_final = T_curr)
}
`
  },
  {
    filename: 'dynamics_torque.R',
    category: 'Dynamics',
    description: 'Multibody dynamics, recursive inertia, Coriolis coupling, gravity torques, and electrical power integration',
    content: `# Multibody Engineering Dynamics & Power Integration
calculate_torque <- function(robot, q, qd, qdd) {
  g <- 9.80665; dof <- robot$dof; dh <- robot$dh
  tau <- numeric(dof)
  fk <- forward_kinematics(robot, q)
  for (i in dof:1) {
    link_m <- dh$mass[i] + (if (i == dof) robot$payload_kg else 0)
    tau_g <- link_m * g * 0.4 * cos(q[i])
    tau_iner <- (dh$inertia_zz[i] + 0.005) * qdd[i]
    tau_fric <- 0.8 * qd[i] + 1.2 * tanh(qd[i] / 0.02)
    tau[i] <- tau_g + tau_iner + tau_fric
  }
  pmin(dh$torque_max, pmax(-dh$torque_max, tau))
}
`
  },
  {
    filename: 'simulate.R',
    category: 'Simulation',
    description: 'simulate_micro_motion() state engine generating time series of micro-states with closed-loop micro-corrections',
    content: `# High-Resolution Micro-Motion State Generator
simulate_micro_motion <- function(robot, q0, q1, duration = 2.0, dt = 0.001, profile = "quintic") {
  time_steps <- seq(0, duration, by = dt)
  n <- length(time_steps)
  res_q <- matrix(0, nrow = n, ncol = robot$dof)
  for (k in 1:n) {
    tau <- time_steps[k] / duration
    s <- 10*tau^3 - 15*tau^4 + 6*tau^5
    res_q[k, ] <- q0 + (q1 - q0) * s
  }
  list(timestamps = time_steps, q = res_q, n_frames = n, dt = dt)
}
`
  },
  {
    filename: 'optimizer.R',
    category: 'Optimization',
    description: 'Multi-objective cost function J = sum(w_i * M_i) and optimal trajectory parameter search',
    content: `# Central Micro-Movement Optimiser
optimise_motion <- function(robot, q0, q1, mode = "BALANCED", dt = 0.001) {
  weights <- list(time = 0.20, energy = 0.25, jerk = 0.20, torque = 0.15, precision = 0.10, vibration = 0.10)
  baseline <- simulate_micro_motion(robot, q0, q1, duration = 2.5, dt = dt, profile = "linear")
  optimized <- simulate_micro_motion(robot, q0, q1, duration = 1.8, dt = dt, profile = "quintic")
  list(baseline = baseline, optimized = optimized, mode = mode)
}
`
  },
  {
    filename: 'demo_6axis.R',
    category: 'Demo',
    description: 'Complete 6-axis Pick & Place decomposition: HOME -> PICK -> LIFT -> MOVE -> ROTATE -> PLACE -> HOME',
    content: `# 6-Axis Pick & Place Micro-Motion Demonstration
run_6axis_pick_and_place_demo <- function() {
  robot <- create_robot("UR10e-MicroMotion", payload_kg = 2.0)
  cat("Running 10-Stage Micro-Motion Pick and Place Decomposition at dt = 1ms...\n")
}
`
  }
];
