import { MicroMotionResult } from './types';

export interface TelemetryReport {
  total_movement_time_s: number;
  microstates_count: number;
  dt_ms: number;
  max_jerk: {
    value: number;
    joint: string;
    timestamp: number;
  };
  max_torque: {
    value: number;
    joint: string;
    timestamp: number;
  };
  max_tracking_error: {
    value_m: number;
    value_um: number;
    timestamp: number;
  };
  energy_hotspot: {
    joint: string;
    total_joules: number;
    peak_timestamp: number;
    phase_description: string;
  };
  joint_energy_breakdown: { joint: string; energy_joules: number; percentage: number }[];
  micro_corrections_total: number;
  constraint_compliance: string;
}

export class TelemetryAnalyzer {
  public static analyze(sim: MicroMotionResult): TelemetryReport {
    const dof = sim.robot.dof;
    const dt = sim.dt;

    // Joint energy integration
    const jointEnergies: number[] = Array(dof).fill(0);
    for (const frame of sim.frames) {
      for (let j = 0; j < dof; j++) {
        jointEnergies[j] += Math.max(0, frame.joint_powers[j]) * dt;
      }
    }

    const totalEnergy = sim.total_energy_joules || 1e-6;
    const breakdown = jointEnergies.map((val, idx) => ({
      joint: `J${idx + 1}`,
      energy_joules: val,
      percentage: (val / totalEnergy) * 100
    }));

    // Find highest energy joint
    let maxEJ = 0;
    let maxEJoint = 'J1';
    for (let j = 0; j < dof; j++) {
      if (jointEnergies[j] > maxEJ) {
        maxEJ = jointEnergies[j];
        maxEJoint = `J${j + 1}`;
      }
    }

    const peakPowerTime = sim.peak_power_watts.timestamp;
    let phase = 'Mid-Trajectory Dynamic Coupling';
    if (peakPowerTime < sim.duration * 0.35) {
      phase = `${maxEJoint} Acceleration & Inertial Acceleration Phase`;
    } else if (peakPowerTime > sim.duration * 0.65) {
      phase = `${maxEJoint} Deceleration & Kinetic Braking Phase`;
    }

    return {
      total_movement_time_s: sim.duration,
      microstates_count: sim.n_frames,
      dt_ms: sim.dt * 1000,
      max_jerk: {
        value: sim.max_jerk.value,
        joint: sim.max_jerk.joint,
        timestamp: sim.max_jerk.timestamp
      },
      max_torque: {
        value: sim.max_torque.value,
        joint: sim.max_torque.joint,
        timestamp: sim.max_torque.timestamp
      },
      max_tracking_error: {
        value_m: sim.max_tracking_error.value_m,
        value_um: sim.max_tracking_error.value_um,
        timestamp: sim.max_tracking_error.timestamp
      },
      energy_hotspot: {
        joint: maxEJoint,
        total_joules: maxEJ,
        peak_timestamp: peakPowerTime,
        phase_description: phase
      },
      joint_energy_breakdown: breakdown,
      micro_corrections_total: sim.micro_corrections_count,
      constraint_compliance: sim.constraint_violations.length === 0 ? 'COMPLIANT' : 'CONSTRAINTS_VIOLATED'
    };
  }

  public static generateCSV(sim: MicroMotionResult): string {
    const dof = sim.robot.dof;
    const headers = [
      'timestamp_s',
      'ee_x_m', 'ee_y_m', 'ee_z_m',
      'ee_roll_rad', 'ee_pitch_rad', 'ee_yaw_rad',
      'ee_vx_m_s', 'ee_vy_m_s', 'ee_vz_m_s',
      'delta_ee_dist_m',
      'tracking_error_um',
      'delta_energy_j',
      'cum_energy_j'
    ];

    for (let j = 1; j <= dof; j++) {
      headers.push(
        `j${j}_pos_rad`,
        `j${j}_vel_rad_s`,
        `j${j}_acc_rad_s2`,
        `j${j}_jerk_rad_s3`,
        `j${j}_torque_nm`,
        `j${j}_power_w`,
        `j${j}_delta_pos_rad`
      );
    }

    const rows: string[] = [headers.join(',')];

    for (const f of sim.frames) {
      const row: (string | number)[] = [
        f.timestamp.toFixed(6),
        f.ee_position[0].toFixed(6),
        f.ee_position[1].toFixed(6),
        f.ee_position[2].toFixed(6),
        f.ee_orientation[0].toFixed(6),
        f.ee_orientation[1].toFixed(6),
        f.ee_orientation[2].toFixed(6),
        f.ee_velocity[0].toFixed(6),
        f.ee_velocity[1].toFixed(6),
        f.ee_velocity[2].toFixed(6),
        f.delta_ee_distance.toExponential(4),
        f.tracking_error_um.toFixed(3),
        f.delta_energy_joules.toExponential(4),
        f.cumulative_energy_joules.toFixed(4)
      ];

      for (let j = 0; j < dof; j++) {
        row.push(
          f.joint_positions[j].toFixed(6),
          f.joint_velocities[j].toFixed(6),
          f.joint_accelerations[j].toFixed(6),
          f.joint_jerks[j].toFixed(6),
          f.joint_torques[j].toFixed(6),
          f.joint_powers[j].toFixed(4),
          f.delta_positions[j].toExponential(4)
        );
      }
      rows.push(row.join(','));
    }

    return rows.join('\n');
  }

  public static generateCanonicalJSON(sim: MicroMotionResult): string {
    const analysis = this.analyze(sim);
    const payload = {
      engine: 'MicroMotion.R',
      version: '1.0.0',
      schema: 'urn:micromotion:digital-twin:v1',
      generated_at: new Date().toISOString(),
      robot: {
        name: sim.robot.name,
        dof: sim.robot.dof,
        payload_kg: sim.robot.payload_kg,
        dh_parameters: sim.robot.dh_parameters
      },
      simulation: {
        duration_s: sim.duration,
        dt_s: sim.dt,
        total_microstates: sim.n_frames,
        profile_type: sim.profile_type,
        initial_joint_state: sim.initial_state,
        target_joint_state: sim.target_state
      },
      analysis,
      frames_sample_or_full: sim.frames.slice(0, 500) // sample if huge or complete
    };

    return JSON.stringify(payload, null, 2);
  }
}
