import { TrajectoryProfileType } from './types';

export interface TrajectoryProfilePoint {
  position: number;
  velocity: number;
  acceleration: number;
  jerk: number;
}

export class TrajectoryGenerator {
  /**
   * Evaluate analytical motion profile at time t in [0, duration]
   */
  public static evaluateProfile(
    q0: number,
    q1: number,
    duration: number,
    t: number,
    profileType: TrajectoryProfileType
  ): TrajectoryProfilePoint {
    const clampedT = Math.max(0, Math.min(duration, t));
    const tau = duration > 0 ? clampedT / duration : 1.0;
    const D = q1 - q0;

    let s = 0;
    let sDot = 0;
    let sDdot = 0;
    let sDddot = 0;

    switch (profileType) {
      case 'quintic': {
        // 5th order polynomial (C2 continuous)
        // s(tau) = 10*tau^3 - 15*tau^4 + 6*tau^5
        s = (10 * Math.pow(tau, 3)) - (15 * Math.pow(tau, 4)) + (6 * Math.pow(tau, 5));
        sDot = ((30 * Math.pow(tau, 2)) - (60 * Math.pow(tau, 3)) + (30 * Math.pow(tau, 4))) / duration;
        sDdot = ((60 * tau) - (180 * Math.pow(tau, 2)) + (120 * Math.pow(tau, 3))) / (duration * duration);
        sDddot = (60 - (360 * tau) + (360 * Math.pow(tau, 2))) / (duration * duration * duration);
        break;
      }

      case 'septic': {
        // 7th order polynomial (C3 continuous, zero jerk boundaries)
        // s(tau) = 35*tau^4 - 84*tau^5 + 70*tau^6 - 20*tau^7
        s = (35 * Math.pow(tau, 4)) - (84 * Math.pow(tau, 5)) + (70 * Math.pow(tau, 6)) - (20 * Math.pow(tau, 7));
        sDot = ((140 * Math.pow(tau, 3)) - (420 * Math.pow(tau, 4)) + (420 * Math.pow(tau, 5)) - (140 * Math.pow(tau, 6))) / duration;
        sDdot = ((420 * Math.pow(tau, 2)) - (1680 * Math.pow(tau, 3)) + (2100 * Math.pow(tau, 4)) - (840 * Math.pow(tau, 5))) / (duration * duration);
        sDddot = ((840 * tau) - (5040 * Math.pow(tau, 2)) + (8400 * Math.pow(tau, 3)) - (4200 * Math.pow(tau, 4))) / (duration * duration * duration);
        break;
      }

      case 'min_jerk': {
        // Flash & Hogan minimum-jerk formulation
        s = (10 * Math.pow(tau, 3)) - (15 * Math.pow(tau, 4)) + (6 * Math.pow(tau, 5));
        sDot = ((30 * Math.pow(tau, 2)) - (60 * Math.pow(tau, 3)) + (30 * Math.pow(tau, 4))) / duration;
        sDdot = ((60 * tau) - (180 * Math.pow(tau, 2)) + (120 * Math.pow(tau, 3))) / (duration * duration);
        sDddot = (60 - (360 * tau) + (360 * Math.pow(tau, 2))) / (duration * duration * duration);
        break;
      }

      case 'min_energy': {
        // Smooth harmonic variational profile
        s = 0.5 * (1.0 - Math.cos(Math.PI * tau));
        sDot = (0.5 * Math.PI * Math.sin(Math.PI * tau)) / duration;
        sDdot = (0.5 * Math.PI * Math.PI * Math.cos(Math.PI * tau)) / (duration * duration);
        sDddot = (-0.5 * Math.PI * Math.PI * Math.PI * Math.sin(Math.PI * tau)) / (duration * duration * duration);
        break;
      }

      case 'cubic': {
        // 3rd order polynomial
        s = (3 * Math.pow(tau, 2)) - (2 * Math.pow(tau, 3));
        sDot = ((6 * tau) - (6 * Math.pow(tau, 2))) / duration;
        sDdot = (6 - (12 * tau)) / (duration * duration);
        sDddot = -12 / (duration * duration * duration);
        break;
      }

      case 'spline': {
        // Cubic spline blend
        const sRaw = Math.sin((tau - 0.5) * Math.PI);
        s = 0.5 + (0.5 * sRaw);
        sDot = (0.5 * Math.PI * Math.cos((tau - 0.5) * Math.PI)) / duration;
        sDdot = (-0.5 * Math.PI * Math.PI * Math.sin((tau - 0.5) * Math.PI)) / (duration * duration);
        sDddot = (-0.5 * Math.pow(Math.PI, 3) * Math.cos((tau - 0.5) * Math.PI)) / Math.pow(duration, 3);
        break;
      }

      case 'linear':
      default: {
        // Trapezoidal velocity profile (1/3 accel, 1/3 cruise, 1/3 decel)
        if (tau < 0.3333) {
          const tSub = tau / 0.3333;
          s = 0.5 * 0.3333 * Math.pow(tSub, 2) * 1.5;
          sDot = (1.5 * tSub) / duration;
          sDdot = (1.5 / 0.3333) / (duration * duration);
          sDddot = 0;
        } else if (tau < 0.6667) {
          s = (0.5 * 0.3333 * 1.5) + (1.5 * (tau - 0.3333));
          sDot = 1.5 / duration;
          sDdot = 0;
          sDddot = 0;
        } else {
          const tSub = (tau - 0.6667) / 0.3333;
          s = 1.0 - (0.5 * 0.3333 * Math.pow(1.0 - tSub, 2) * 1.5);
          sDot = (1.5 * (1.0 - tSub)) / duration;
          sDdot = (-1.5 / 0.3333) / (duration * duration);
          sDddot = 0;
        }
        break;
      }
    }

    return {
      position: q0 + (D * s),
      velocity: D * sDot,
      acceleration: D * sDdot,
      jerk: D * sDddot
    };
  }
}
