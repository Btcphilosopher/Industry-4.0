import { DecomposedTask } from './types';

export const DEFAULT_DEMO_TASK: DecomposedTask = {
  name: 'Precision Pick & Place Workcell Cycle',
  total_duration: 7.0,
  stages: [
    {
      id: 'st_1',
      name: '1. Approach to Pick Zone',
      stage_type: 'APPROACH',
      from_joint: [0.0, -Math.PI / 2, Math.PI / 2, 0.0, Math.PI / 2, 0.0],
      to_joint: [0.45, -Math.PI / 3, 0.65 * Math.PI, -0.32, Math.PI / 2, 0.45],
      duration: 1.1,
      profile: 'quintic',
      description: 'Rapid transition from Home to pick approach quadrant'
    },
    {
      id: 'st_2',
      name: '2. Slow Precision Alignment',
      stage_type: 'SLOW_APPROACH',
      from_joint: [0.45, -Math.PI / 3, 0.65 * Math.PI, -0.32, Math.PI / 2, 0.45],
      to_joint: [0.45, -Math.PI / 3 - 0.06, 0.65 * Math.PI + 0.06, -0.32, Math.PI / 2, 0.45],
      duration: 0.5,
      profile: 'min_jerk',
      description: 'Sub-millimeter alignment above target object'
    },
    {
      id: 'st_3',
      name: '3. Gripper Descend & Engagement',
      stage_type: 'GRIPPER_POS',
      from_joint: [0.45, -Math.PI / 3 - 0.06, 0.65 * Math.PI + 0.06, -0.32, Math.PI / 2, 0.45],
      to_joint: [0.45, -0.92, 2.15, -0.35, Math.PI / 2, 0.45],
      duration: 0.5,
      profile: 'septic',
      description: 'Vertical plunge with zero impact jerk'
    },
    {
      id: 'st_4',
      name: '4. Gripper Closure & Stabilisation',
      stage_type: 'CLOSURE',
      from_joint: [0.45, -0.92, 2.15, -0.35, Math.PI / 2, 0.45],
      to_joint: [0.45, -0.92, 2.15, -0.35, Math.PI / 2, 0.45],
      duration: 0.3,
      profile: 'cubic',
      description: 'Dwell for pneumatic gripper closure and force stabilization'
    },
    {
      id: 'st_5',
      name: '5. Vertical Lift with Payload',
      stage_type: 'LIFT',
      from_joint: [0.45, -0.92, 2.15, -0.35, Math.PI / 2, 0.45],
      to_joint: [0.45, -Math.PI / 2, Math.PI / 2, 0.0, Math.PI / 2, 0.45],
      duration: 0.7,
      profile: 'quintic',
      description: 'Smooth vertical lift overcoming static friction'
    },
    {
      id: 'st_6',
      name: '6. High-Speed Workspace Transfer',
      stage_type: 'TRANSFER',
      from_joint: [0.45, -Math.PI / 2, Math.PI / 2, 0.0, Math.PI / 2, 0.45],
      to_joint: [-0.65, -0.85, 1.80, -0.20, Math.PI / 2, -0.65],
      duration: 1.4,
      profile: 'min_energy',
      description: 'Long-arc gross motion minimizing mechanical work'
    },
    {
      id: 'st_7',
      name: '7. Wrist Orientation & Align',
      stage_type: 'ROTATE',
      from_joint: [-0.65, -0.85, 1.80, -0.20, Math.PI / 2, -0.65],
      to_joint: [-0.65, -0.85, 1.80, -0.20, Math.PI / 2, 1.20],
      duration: 0.6,
      profile: 'quintic',
      description: 'Re-orient tool to match placement fixture'
    },
    {
      id: 'st_8',
      name: '8. Gentle Placement & Release',
      stage_type: 'PLACE',
      from_joint: [-0.65, -0.85, 1.80, -0.20, Math.PI / 2, 1.20],
      to_joint: [-0.65, -0.95, 2.20, -0.40, Math.PI / 2, 1.20],
      duration: 0.6,
      profile: 'septic',
      description: 'Precision soft descent into assembly target'
    },
    {
      id: 'st_9',
      name: '9. Return to Home Posture',
      stage_type: 'HOME',
      from_joint: [-0.65, -0.95, 2.20, -0.40, Math.PI / 2, 1.20],
      to_joint: [0.0, -Math.PI / 2, Math.PI / 2, 0.0, Math.PI / 2, 0.0],
      duration: 1.3,
      profile: 'quintic',
      description: 'Resetting arm state for next manufacturing cycle'
    }
  ]
};
