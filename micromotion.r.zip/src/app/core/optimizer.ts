import {
  RobotModel,
  PrecisionMode,
  OptimizationWeights,
  CostFunctionResult,
  MicroMotionResult,
  OptimizationComparison,
  TrajectoryProfileType
} from './types';
import { SimulationEngine } from './simulation';

export class OptimizerEngine {
  public static getModeWeights(mode: PrecisionMode): OptimizationWeights {
    switch (mode) {
      case 'FAST':
        return { time: 0.50, energy: 0.10, jerk: 0.10, torque: 0.10, precision: 0.10, vibration: 0.10 };
      case 'PRECISION':
        return { time: 0.10, energy: 0.10, jerk: 0.30, torque: 0.10, precision: 0.30, vibration: 0.10 };
      case 'ULTRA_PRECISION':
        return { time: 0.05, energy: 0.05, jerk: 0.35, torque: 0.10, precision: 0.35, vibration: 0.10 };
      case 'ENERGY_SAVING':
        return { time: 0.10, energy: 0.50, jerk: 0.15, torque: 0.15, precision: 0.05, vibration: 0.05 };
      case 'BALANCED':
      default:
        return { time: 0.20, energy: 0.25, jerk: 0.20, torque: 0.15, precision: 0.10, vibration: 0.10 };
    }
  }

  /**
   * Formal Multi-Objective Cost Function Evaluation
   * J = w1*time + w2*energy + w3*jerk + w4*torque + w5*error + w6*vibration + penalty
   */
  public static calculateCost(
    sim: MicroMotionResult,
    weights: OptimizationWeights
  ): CostFunctionResult {
    const rawTime = sim.duration;
    const rawEnergy = sim.total_energy_joules;
    const rawMaxJerk = sim.max_jerk.value;

    let sumSqTorque = 0;
    let sumVibration = 0;
    for (const f of sim.frames) {
      for (const t of f.joint_torques) {
        sumSqTorque += t * t;
      }
      sumVibration += Math.hypot(...f.ee_acceleration);
    }
    const rmsTorque = Math.sqrt(sumSqTorque / (sim.frames.length * sim.robot.dof + 1e-6));
    const meanVibration = sumVibration / sim.frames.length;
    const rawMaxErrorM = sim.max_tracking_error.value_m;
    const rawMaxErrorUm = sim.max_tracking_error.value_um;

    // Normalization factors
    const normTime = rawTime / 2.5;
    const normEnergy = rawEnergy / 180.0;
    const normJerk = rawMaxJerk / 50.0;
    const normTorque = rmsTorque / 60.0;
    const normPrecision = rawMaxErrorM / 0.0001; // 100 um baseline
    const normVibration = meanVibration / 6.0;

    const penalty = sim.constraint_violations.length * 150.0;

    const totalCost = (
      (weights.time * normTime) +
      (weights.energy * normEnergy) +
      (weights.jerk * normJerk) +
      (weights.torque * normTorque) +
      (weights.precision * normPrecision) +
      (weights.vibration * normVibration)
    ) + penalty;

    return {
      total_cost: totalCost,
      components: {
        time_cost: normTime,
        energy_cost: normEnergy,
        jerk_cost: normJerk,
        torque_cost: normTorque,
        precision_cost: normPrecision,
        vibration_cost: normVibration
      },
      raw_metrics: {
        time_s: rawTime,
        energy_joules: rawEnergy,
        max_jerk_rad_s3: rawMaxJerk,
        rms_torque_nm: rmsTorque,
        max_error_m: rawMaxErrorM,
        max_error_um: rawMaxErrorUm,
        mean_vibration_m_s2: meanVibration
      },
      weights,
      penalty
    };
  }

  /**
   * Run Multi-Objective Trajectory Optimization
   */
  public static optimizeTrajectory(
    robot: RobotModel,
    initialState: number[],
    targetState: number[],
    mode: PrecisionMode = 'BALANCED',
    dt = 0.001,
    customWeights?: OptimizationWeights
  ): OptimizationComparison {
    const weights = customWeights || this.getModeWeights(mode);

    // 1. Baseline Simulation: Linear trapezoidal profile without closed-loop micro-correction
    const baselineDur = 2.4;
    const baselineSim = SimulationEngine.simulateMicroMotion({
      robot,
      initialState,
      targetState,
      duration: baselineDur,
      dt,
      profileType: 'linear',
      enableMicroCorrection: false,
      disturbanceScale: 0.00008
    });
    const baselineCost = this.calculateCost(baselineSim, weights);

    // 2. Candidate Profiles Exploration
    let candidateProfiles: TrajectoryProfileType[];
    let candidateDurations: number[];

    if (mode === 'FAST') {
      candidateProfiles = ['quintic', 'cubic', 'min_jerk'];
      candidateDurations = [1.2, 1.4, 1.6, 1.8];
    } else if (mode === 'ENERGY_SAVING') {
      candidateProfiles = ['min_energy', 'quintic', 'septic'];
      candidateDurations = [2.2, 2.6, 3.0, 3.4];
    } else if (mode === 'PRECISION' || mode === 'ULTRA_PRECISION') {
      candidateProfiles = ['septic', 'quintic', 'min_jerk'];
      candidateDurations = [2.0, 2.4, 2.8];
    } else {
      candidateProfiles = ['quintic', 'septic', 'min_jerk', 'min_energy'];
      candidateDurations = [1.6, 2.0, 2.4];
    }

    let bestSim = baselineSim;
    let bestCost = baselineCost;
    let bestProfile: TrajectoryProfileType = 'quintic';
    let bestDur = baselineDur;

    for (const prof of candidateProfiles) {
      for (const dur of candidateDurations) {
        const candSim = SimulationEngine.simulateMicroMotion({
          robot,
          initialState,
          targetState,
          duration: dur,
          dt,
          profileType: prof,
          enableMicroCorrection: true,
          disturbanceScale: 0.00004
        });

        const candCost = this.calculateCost(candSim, weights);

        if (candCost.total_cost < bestCost.total_cost && candSim.constraint_violations.length === 0) {
          bestCost = candCost;
          bestSim = candSim;
          bestProfile = prof;
          bestDur = dur;
        }
      }
    }

    const bRaw = baselineCost.raw_metrics;
    const oRaw = bestCost.raw_metrics;

    const timePct = ((bRaw.time_s - oRaw.time_s) / bRaw.time_s) * 100;
    const energyPct = ((bRaw.energy_joules - oRaw.energy_joules) / bRaw.energy_joules) * 100;
    const jerkPct = ((bRaw.max_jerk_rad_s3 - oRaw.max_jerk_rad_s3) / bRaw.max_jerk_rad_s3) * 100;
    const torquePct = ((bRaw.rms_torque_nm - oRaw.rms_torque_nm) / bRaw.rms_torque_nm) * 100;
    const errorPct = ((bRaw.max_error_m - oRaw.max_error_m) / (bRaw.max_error_m + 1e-9)) * 100;

    return {
      mode,
      best_profile: bestProfile,
      best_duration: bestDur,
      baseline_simulation: baselineSim,
      optimized_simulation: bestSim,
      baseline_cost: baselineCost,
      optimized_cost: bestCost,
      improvements: {
        cycle_time_delta_pct: timePct,
        energy_reduction_pct: energyPct,
        jerk_reduction_pct: jerkPct,
        torque_reduction_pct: torquePct,
        error_reduction_pct: errorPct
      }
    };
  }
}
