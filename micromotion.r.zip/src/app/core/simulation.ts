import { RobotModel, TrajectoryProfileType, MicroMotionFrame, MicroMotionResult } from './types';
import { KinematicsEngine } from './kinematics';
import { DynamicsEngine } from './dynamics';
import { TrajectoryGenerator } from './trajectories';

export interface SimulationOptions {
  robot: RobotModel;
  initialState: number[];
  targetState: number[];
  duration: number;
  dt: number;
  profileType: TrajectoryProfileType;
  enableMicroCorrection?: boolean;
  disturbanceScale?: number;
}

export class SimulationEngine {
  /**
   * Run High-Resolution Micro-Motion Simulation
   */
  public static simulateMicroMotion(options: SimulationOptions): MicroMotionResult {
    const {
      robot,
      initialState,
      targetState,
      duration,
      dt,
      profileType,
      enableMicroCorrection = true,
      disturbanceScale = 0.00004
    } = options;

    const dof = robot.dof;
    const dh = robot.dh_parameters;
    const q0 = [...initialState];
    const q1 = [...targetState];

    const nSteps = Math.floor(duration / dt) + 1;
    const frames: MicroMotionFrame[] = [];
    const timestamps: number[] = [];

    let totalEnergyJoules = 0;
    let maxJerkVal = 0;
    let maxJerkJoint = 'J1';
    let maxJerkTime = 0;

    let maxTorqueVal = 0;
    let maxTorqueJoint = 'J1';
    let maxTorqueTime = 0;

    let maxErrorValM = 0;
    let maxErrorTime = 0;

    let peakPowerVal = 0;
    let peakPowerTime = 0;

    let microCorrectionsCount = 0;
    const constraintViolations = new Set<string>();

    let prevQ = [...q0];
    let prevQd = Array(dof).fill(0);
    let prevQdd = Array(dof).fill(0);
    let prevJerk = Array(dof).fill(0);
    let prevTorques = Array(dof).fill(0);

    const initialFk = KinematicsEngine.forwardKinematics(robot, q0);
    let prevEePos: [number, number, number] = [
      initialFk.ee_position[0],
      initialFk.ee_position[1],
      initialFk.ee_position[2]
    ];
    let prevEeVel: [number, number, number] = [0, 0, 0];

    const accumulatedDisturbance = Array(dof).fill(0);

    for (let k = 0; k < nSteps; k++) {
      const t = Math.min(duration, k * dt);
      timestamps.push(t);

      // 1. Commanded Trajectory Evaluation
      const cmdQ: number[] = [];
      const cmdQd: number[] = [];
      const cmdQdd: number[] = [];
      const cmdJerk: number[] = [];

      for (let j = 0; j < dof; j++) {
        const pt = TrajectoryGenerator.evaluateProfile(q0[j], q1[j], duration, t, profileType);
        cmdQ.push(pt.position);
        cmdQd.push(pt.velocity);
        cmdQdd.push(pt.acceleration);
        cmdJerk.push(pt.jerk);
      }

      // 2. Digital Twin Simulated Physical Micro-Perturbation
      const simQ = [...cmdQ];
      if (disturbanceScale > 0) {
        for (let j = 0; j < dof; j++) {
          const harmonic = Math.sin(2 * Math.PI * 35 * t + (j * 1.1));
          const ripple = disturbanceScale * harmonic * (Math.abs(cmdQd[j]) / (dh[j].v_max + 0.01) + 0.1);
          simQ[j] += ripple + accumulatedDisturbance[j];
        }
      }

      // 3. Forward Kinematics Evaluation
      const fkNominal = KinematicsEngine.forwardKinematics(robot, cmdQ);
      let fkSim = KinematicsEngine.forwardKinematics(robot, simQ);

      const errX = fkNominal.ee_position[0] - fkSim.ee_position[0];
      const errY = fkNominal.ee_position[1] - fkSim.ee_position[1];
      const errZ = fkNominal.ee_position[2] - fkSim.ee_position[2];
      const trackingErrorM = Math.hypot(errX, errY, errZ);
      const trackingErrorUm = trackingErrorM * 1e6;

      let microCorrectionApplied = false;
      let correctionVector: number[] | undefined;

      // 4. Closed-Loop Micro-Correction System
      if (enableMicroCorrection && trackingErrorM > robot.tolerance) {
        const correctedQ = KinematicsEngine.solveMicroCorrectionDLS(
          robot,
          simQ,
          fkNominal.ee_position,
          0.02
        );

        correctionVector = [];
        for (let j = 0; j < dof; j++) {
          const dqCorr = correctedQ[j] - simQ[j];
          correctionVector.push(dqCorr);
          simQ[j] = correctedQ[j];
          accumulatedDisturbance[j] -= dqCorr * 0.4;
        }

        microCorrectionApplied = true;
        microCorrectionsCount++;
        fkSim = KinematicsEngine.forwardKinematics(robot, simQ);
      }

      // 5. Calculate Dynamics & Torques
      const torques = DynamicsEngine.calculateTorques(robot, simQ, cmdQd, cmdQdd);

      // 6. Power & Energy Integration
      const powerEnergy = DynamicsEngine.calculatePowerAndEnergy(robot, torques, cmdQd, dt);
      totalEnergyJoules += powerEnergy.delta_energy_elec;

      if (powerEnergy.p_total_elec > peakPowerVal) {
        peakPowerVal = powerEnergy.p_total_elec;
        peakPowerTime = t;
      }

      // 7. Cartesian End-Effector Kinematics & Jacobians
      const J = KinematicsEngine.computeJacobian(robot, simQ);
      // ee_velocity = J * q_dot
      let vx = 0, vy = 0, vz = 0;
      for (let j = 0; j < dof; j++) {
        vx += J[0][j] * cmdQd[j];
        vy += J[1][j] * cmdQd[j];
        vz += J[2][j] * cmdQd[j];
      }
      const eeVel: [number, number, number] = [vx, vy, vz];

      let ax = 0, ay = 0, az = 0;
      if (k > 0) {
        ax = (vx - prevEeVel[0]) / dt;
        ay = (vy - prevEeVel[1]) / dt;
        az = (vz - prevEeVel[2]) / dt;
      }
      const eeAcc: [number, number, number] = [ax, ay, az];

      // 8. Micro-Deltas (The Fundamental Micro-Movement Object)
      const deltaQ: number[] = [];
      const deltaQd: number[] = [];
      const deltaQdd: number[] = [];
      const deltaJerk: number[] = [];
      const deltaTorques: number[] = [];

      for (let j = 0; j < dof; j++) {
        deltaQ.push(simQ[j] - prevQ[j]);
        deltaQd.push(cmdQd[j] - prevQd[j]);
        deltaQdd.push(cmdQdd[j] - prevQdd[j]);
        deltaJerk.push(cmdJerk[j] - prevJerk[j]);
        deltaTorques.push(torques[j] - prevTorques[j]);

        // Track Hotspots
        const absJ = Math.abs(cmdJerk[j]);
        if (absJ > maxJerkVal) {
          maxJerkVal = absJ;
          maxJerkJoint = `J${j + 1}`;
          maxJerkTime = t;
        }

        const absTau = Math.abs(torques[j]);
        if (absTau > maxTorqueVal) {
          maxTorqueVal = absTau;
          maxTorqueJoint = `J${j + 1}`;
          maxTorqueTime = t;
        }

        // Constraint Checks
        if (simQ[j] < dh[j].q_min || simQ[j] > dh[j].q_max) {
          constraintViolations.add(`Joint ${j + 1} position limit violated [${dh[j].q_min.toFixed(2)}, ${dh[j].q_max.toFixed(2)}]`);
        }
        if (Math.abs(cmdQd[j]) > dh[j].v_max) {
          constraintViolations.add(`Joint ${j + 1} velocity limit exceeded (>${dh[j].v_max.toFixed(2)} rad/s)`);
        }
        if (Math.abs(torques[j]) > dh[j].torque_max) {
          constraintViolations.add(`Joint ${j + 1} torque limit exceeded (>${dh[j].torque_max.toFixed(1)} Nm)`);
        }
      }

      if (trackingErrorM > maxErrorValM) {
        maxErrorValM = trackingErrorM;
        maxErrorTime = t;
      }

      const dEeX = fkSim.ee_position[0] - prevEePos[0];
      const dEeY = fkSim.ee_position[1] - prevEePos[1];
      const dEeZ = fkSim.ee_position[2] - prevEePos[2];
      const dEeDist = Math.hypot(dEeX, dEeY, dEeZ);

      // 9. Construct MicroMotionFrame
      const frame: MicroMotionFrame = {
        frame_index: k,
        timestamp: t,
        joint_positions: [...simQ],
        joint_velocities: [...cmdQd],
        joint_accelerations: [...cmdQdd],
        joint_jerks: [...cmdJerk],
        joint_torques: [...torques],
        joint_powers: [...powerEnergy.p_elec],
        delta_positions: deltaQ,
        delta_velocities: deltaQd,
        delta_accelerations: deltaQdd,
        delta_jerks: deltaJerk,
        delta_torques: deltaTorques,
        delta_energy_joules: powerEnergy.delta_energy_elec,
        cumulative_energy_joules: totalEnergyJoules,
        ee_position: fkSim.ee_position,
        ee_velocity: eeVel,
        ee_acceleration: eeAcc,
        ee_orientation: fkSim.orientation,
        delta_ee_position: [dEeX, dEeY, dEeZ],
        delta_ee_distance: dEeDist,
        nominal_ee_position: fkNominal.ee_position,
        tracking_error_m: trackingErrorM,
        tracking_error_um: trackingErrorUm,
        micro_correction_applied: microCorrectionApplied,
        correction_vector: correctionVector,
        joint_3d_positions: fkSim.joint_positions_3d
      };

      frames.push(frame);

      prevQ = [...simQ];
      prevQd = [...cmdQd];
      prevQdd = [...cmdQdd];
      prevJerk = [...cmdJerk];
      prevTorques = [...torques];
      prevEePos = [...fkSim.ee_position];
      prevEeVel = [...eeVel];
    }

    return {
      robot,
      timestamps,
      duration,
      dt,
      n_frames: frames.length,
      profile_type: profileType,
      initial_state: q0,
      target_state: q1,
      frames,
      total_energy_joules: totalEnergyJoules,
      max_jerk: { value: maxJerkVal, joint: maxJerkJoint, timestamp: maxJerkTime },
      max_torque: { value: maxTorqueVal, joint: maxTorqueJoint, timestamp: maxTorqueTime },
      max_tracking_error: { value_m: maxErrorValM, value_um: maxErrorValM * 1e6, timestamp: maxErrorTime },
      peak_power_watts: { value: peakPowerVal, timestamp: peakPowerTime },
      micro_corrections_count: microCorrectionsCount,
      constraint_violations: Array.from(constraintViolations)
    };
  }
}
