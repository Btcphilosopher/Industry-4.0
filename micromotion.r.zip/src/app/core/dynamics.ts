import { RobotModel } from './types';
import { KinematicsEngine } from './kinematics';

export interface PowerEnergyStepResult {
  p_mech: number[];
  p_elec: number[];
  p_total_elec: number;
  delta_energy_elec: number; // Joules for this dt
  delta_energy_mech: number;
}

export class DynamicsEngine {
  /**
   * Approximate Multibody Dynamics and Joint Torques
   * Tau = M(q)*qdd + C(q, qd)*qd + G(q) + F_viscous*qd + F_coulomb*sgn(qd)
   */
  public static calculateTorques(
    robot: RobotModel,
    q: number[],
    qd: number[],
    qdd: number[]
  ): number[] {
    const dof = robot.dof;
    const dh = robot.dh_parameters;
    const g = 9.80665;
    const payload = robot.payload_kg;

    const fk = KinematicsEngine.forwardKinematics(robot, q);
    const linkPositions = fk.joint_positions_3d;
    const eePos = fk.ee_position;

    const torques: number[] = Array(dof).fill(0);

    // Iterative link gravity torques
    let cumulativeMass = 0;
    for (let i = dof - 1; i >= 0; i--) {
      const linkM = dh[i].mass + (i === dof - 1 ? payload : 0);
      cumulativeMass += linkM;
      const forceDown = cumulativeMass * g;

      // Horizontal lever arm in XY
      let rArm = 0.05;
      if (i > 0) {
        const dx = eePos[0] - linkPositions[i][0];
        const dy = eePos[1] - linkPositions[i][1];
        rArm = Math.hypot(dx, dy);
      }

      // Gravity torque contribution
      let tauG = 0;
      if (i === 1) { // Shoulder
        tauG = forceDown * rArm * Math.cos(q[1]);
      } else if (i === 2) { // Elbow
        tauG = forceDown * rArm * Math.cos(q[1] + q[2]);
      } else if (i === 3) {
        tauG = (dh[3].mass + payload) * g * 0.15 * Math.sin(q[3]);
      } else {
        tauG = 0.08 * forceDown * Math.sin(q[i]);
      }

      // Inertial torque: M_ii * qdd_i (including rotor & gear ratio squared)
      const linkInertia = dh[i].inertia_zz + (i === dof - 1 ? payload * 0.05 * 0.05 : 0);
      const reflectedInertia = linkInertia + (dh[i].gear_ratio * dh[i].gear_ratio * 0.00008);
      const tauInertia = reflectedInertia * qdd[i];

      // Coriolis & centrifugal coupling
      const crossSpeed = i < dof - 1 ? qd[i] * qd[i + 1] : qd[i] * qd[i];
      const tauCoriolis = 0.04 * dh[i].mass * crossSpeed;

      // Friction model
      const fViscous = 0.65;
      const fCoulomb = 1.20;
      const tauFriction = (fViscous * qd[i]) + (fCoulomb * Math.tanh(qd[i] / 0.02));

      const tauTotal = tauG + tauInertia + tauCoriolis + tauFriction;
      // Clamp within motor torque limit
      torques[i] = Math.max(-dh[i].torque_max, Math.min(dh[i].torque_max, tauTotal));
    }

    return torques;
  }

  /**
   * Instantaneous Mechanical & Electrical Power and Energy Integration
   */
  public static calculatePowerAndEnergy(
    robot: RobotModel,
    torques: number[],
    qd: number[],
    dt: number
  ): PowerEnergyStepResult {
    const dof = robot.dof;
    const dh = robot.dh_parameters;

    const pMech: number[] = Array(dof).fill(0);
    const pElec: number[] = Array(dof).fill(0);
    let totalElecPower = 0;
    let totalMechPower = 0;

    for (let i = 0; i < dof; i++) {
      const pm = torques[i] * qd[i];
      pMech[i] = pm;
      totalMechPower += Math.abs(pm);

      // Motor current I = tau / (kt * gear_ratio)
      const current = Math.abs(torques[i]) / (dh[i].kt * dh[i].gear_ratio + 1e-5);
      const copperLoss = current * current * dh[i].motor_resistance;
      const standbyLoss = 3.5; // Watts per joint drive

      let pe = 0;
      if (pm < 0) {
        // Regenerative braking with 45% recovery efficiency
        pe = copperLoss + standbyLoss + (0.55 * pm);
      } else {
        pe = pm + copperLoss + standbyLoss;
      }
      pElec[i] = pe;
      totalElecPower += Math.max(0, pe);
    }

    const dEnergyElec = totalElecPower * dt;
    const dEnergyMech = totalMechPower * dt;

    return {
      p_mech: pMech,
      p_elec: pElec,
      p_total_elec: totalElecPower,
      delta_energy_elec: dEnergyElec,
      delta_energy_mech: dEnergyMech
    };
  }
}
