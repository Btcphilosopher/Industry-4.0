// ==============================================================================
// MicroMotion.R - TypeScript Core Data Structures & Interfaces
// Matching Canonical R S3 Classes: micro_robot, micro_motion_frame, micro_twin
// ==============================================================================

export type TrajectoryProfileType = 
  | 'linear'
  | 'cubic'
  | 'quintic'
  | 'septic'
  | 'min_jerk'
  | 'min_energy'
  | 'spline';

export type PrecisionMode = 
  | 'FAST'
  | 'BALANCED'
  | 'PRECISION'
  | 'ULTRA_PRECISION'
  | 'ENERGY_SAVING';

export type SimulationTimestep = 0.0001 | 0.0005 | 0.001 | 0.005 | 0.01;

export interface DHParameter {
  joint: number;
  name: string;
  d: number;      // link offset along previous z (m)
  a: number;      // link length along common normal x (m)
  alpha: number;  // link twist (rad)
  mass: number;   // link mass (kg)
  com_z: number;  // center of mass along z (m)
  inertia_zz: number; // rotational inertia kg*m^2
  q_min: number;  // min joint limit (rad)
  q_max: number;  // max joint limit (rad)
  v_max: number;  // max angular velocity (rad/s)
  a_max: number;  // max angular acceleration (rad/s^2)
  jerk_max: number; // max jerk (rad/s^3)
  torque_max: number; // max motor torque (Nm)
  gear_ratio: number;
  motor_resistance: number; // Ohm
  kt: number;     // torque constant Nm/A
}

export interface RobotModel {
  id: string;
  name: string;
  dof: number;
  payload_kg: number;
  base_offset: [number, number, number];
  dh_parameters: DHParameter[];
  gravity: [number, number, number];
  tolerance: number; // Tracking error tolerance in meters (e.g. 1e-5 = 10 um)
  description: string;
}

export interface MicroMotionFrame {
  frame_index: number;
  timestamp: number; // seconds
  
  // Joint Space Time-Series
  joint_positions: number[];     // theta(t) rad
  joint_velocities: number[];    // omega(t) rad/s
  joint_accelerations: number[]; // alpha(t) rad/s^2
  joint_jerks: number[];         // j(t) rad/s^3
  joint_torques: number[];       // tau(t) Nm
  joint_powers: number[];        // P(t) Watts
  
  // Micro-State Transitions (Deltas per single timestep)
  delta_positions: number[];     // dTheta rad
  delta_velocities: number[];    // dOmega rad/s
  delta_accelerations: number[]; // dAlpha rad/s^2
  delta_jerks: number[];         // dJerk rad/s^3
  delta_torques: number[];       // dTau Nm
  delta_energy_joules: number;   // dE Joules
  cumulative_energy_joules: number;
  
  // Cartesian End-Effector Space
  ee_position: [number, number, number];      // X, Y, Z (m)
  ee_velocity: [number, number, number];      // Vx, Vy, Vz (m/s)
  ee_acceleration: [number, number, number];  // Ax, Ay, Az (m/s^2)
  ee_orientation: [number, number, number];   // Roll, Pitch, Yaw (rad)
  delta_ee_position: [number, number, number];// dX, dY, dZ (m)
  delta_ee_distance: number;                  // norm(dX, dY, dZ) (m)
  
  // Closed-Loop Diagnostics
  nominal_ee_position: [number, number, number];
  tracking_error_m: number;
  tracking_error_um: number; // Microns
  micro_correction_applied: boolean;
  correction_vector?: number[];
  
  // Joint 3D spatial points for 3D digital twin rendering
  joint_3d_positions: [number, number, number][];
}

export interface MicroMotionResult {
  robot: RobotModel;
  timestamps: number[];
  duration: number;
  dt: number;
  n_frames: number;
  profile_type: TrajectoryProfileType;
  initial_state: number[];
  target_state: number[];
  
  frames: MicroMotionFrame[];
  
  // Global Aggregated Metrics
  total_energy_joules: number;
  max_jerk: { value: number; joint: string; timestamp: number };
  max_torque: { value: number; joint: string; timestamp: number };
  max_tracking_error: { value_m: number; value_um: number; timestamp: number };
  peak_power_watts: { value: number; timestamp: number };
  micro_corrections_count: number;
  constraint_violations: string[];
}

export interface OptimizationWeights {
  time: number;
  energy: number;
  jerk: number;
  torque: number;
  precision: number;
  vibration: number;
}

export interface CostFunctionResult {
  total_cost: number;
  components: {
    time_cost: number;
    energy_cost: number;
    jerk_cost: number;
    torque_cost: number;
    precision_cost: number;
    vibration_cost: number;
  };
  raw_metrics: {
    time_s: number;
    energy_joules: number;
    max_jerk_rad_s3: number;
    rms_torque_nm: number;
    max_error_m: number;
    max_error_um: number;
    mean_vibration_m_s2: number;
  };
  weights: OptimizationWeights;
  penalty: number;
}

export interface OptimizationComparison {
  mode: PrecisionMode;
  best_profile: TrajectoryProfileType;
  best_duration: number;
  baseline_simulation: MicroMotionResult;
  optimized_simulation: MicroMotionResult;
  baseline_cost: CostFunctionResult;
  optimized_cost: CostFunctionResult;
  improvements: {
    cycle_time_delta_pct: number;
    energy_reduction_pct: number;
    jerk_reduction_pct: number;
    torque_reduction_pct: number;
    error_reduction_pct: number;
  };
}

export interface TaskStage {
  id: string;
  name: string;
  stage_type: 'APPROACH' | 'SLOW_APPROACH' | 'ALIGNMENT' | 'GRIPPER_POS' | 'CLOSURE' | 'STABILISATION' | 'LIFT' | 'TRANSFER' | 'ROTATE' | 'PLACE' | 'RETRACT' | 'HOME';
  from_joint: number[];
  to_joint: number[];
  duration: number;
  profile: TrajectoryProfileType;
  description: string;
}

export interface DecomposedTask {
  name: string;
  stages: TaskStage[];
  total_duration: number;
}
