import { RobotModel } from './types';

export interface ForwardKinematicsResult {
  t_final: number[][]; // 4x4 matrix
  t_transforms: number[][][]; // list of 4x4 matrices
  joint_positions_3d: [number, number, number][]; // points for every joint [0..dof]
  ee_position: [number, number, number];
  orientation: [number, number, number]; // [roll, pitch, yaw] in radians
}

export class KinematicsEngine {
  /**
   * Build 4x4 Denavit-Hartenberg Transformation Matrix
   */
  public static dhMatrix(theta: number, d: number, a: number, alpha: number): number[][] {
    const ct = Math.cos(theta);
    const st = Math.sin(theta);
    const ca = Math.cos(alpha);
    const sa = Math.sin(alpha);

    return [
      [ct, -st * ca,  st * sa, a * ct],
      [st,  ct * ca, -ct * sa, a * st],
      [0,   sa,       ca,      d],
      [0,   0,        0,       1]
    ];
  }

  /**
   * 4x4 Matrix multiplication
   */
  public static multiply4x4(a: number[][], b: number[][]): number[][] {
    const result: number[][] = [
      [0, 0, 0, 0],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
      [0, 0, 0, 0]
    ];

    for (let r = 0; r < 4; r++) {
      for (let c = 0; c < 4; c++) {
        let sum = 0;
        for (let k = 0; k < 4; k++) {
          sum += a[r][k] * b[k][c];
        }
        result[r][c] = sum;
      }
    }
    return result;
  }

  /**
   * Forward Kinematics (FK) for N-DOF Robot
   */
  public static forwardKinematics(robot: RobotModel, q: number[]): ForwardKinematicsResult {
    const dof = robot.dof;
    const dh = robot.dh_parameters;

    let tCurrent: number[][] = [
      [1, 0, 0, robot.base_offset[0]],
      [0, 1, 0, robot.base_offset[1]],
      [0, 0, 1, robot.base_offset[2]],
      [0, 0, 0, 1]
    ];

    const jointPositions: [number, number, number][] = [
      [robot.base_offset[0], robot.base_offset[1], robot.base_offset[2]]
    ];

    const tTransforms: number[][][] = [];

    for (let i = 0; i < dof; i++) {
      const p = dh[i];
      const theta = q[i] ?? 0;
      const tStep = this.dhMatrix(theta, p.d, p.a, p.alpha);
      tCurrent = this.multiply4x4(tCurrent, tStep);
      tTransforms.push(tCurrent);
      jointPositions.push([tCurrent[0][3], tCurrent[1][3], tCurrent[2][3]]);
    }

    const eePos: [number, number, number] = [
      tCurrent[0][3],
      tCurrent[1][3],
      tCurrent[2][3]
    ];

    // Extract Euler angles (Roll, Pitch, Yaw - ZYX convention)
    const r = tCurrent;
    const sy = Math.sqrt(r[0][0] * r[0][0] + r[1][0] * r[1][0]);
    let roll: number;
    let pitch: number;
    let yaw: number;

    if (sy > 1e-6) {
      roll = Math.atan2(r[2][1], r[2][2]);
      pitch = Math.atan2(-r[2][0], sy);
      yaw = Math.atan2(r[1][0], r[0][0]);
    } else {
      roll = Math.atan2(-r[1][2], r[1][1]);
      pitch = Math.atan2(-r[2][0], sy);
      yaw = 0;
    }

    return {
      t_final: tCurrent,
      t_transforms: tTransforms,
      joint_positions_3d: jointPositions,
      ee_position: eePos,
      orientation: [roll, pitch, yaw]
    };
  }

  /**
   * Compute 6xN Geometric Jacobian Matrix
   */
  public static computeJacobian(robot: RobotModel, q: number[]): number[][] {
    const dof = robot.dof;
    const fk = this.forwardKinematics(robot, q);
    const pe = fk.ee_position;

    // 6 rows: 0..2 linear velocity, 3..5 angular velocity
    const J: number[][] = Array.from({ length: 6 }, () => Array(dof).fill(0));

    for (let i = 0; i < dof; i++) {
      let zi: [number, number, number];
      let pi: [number, number, number];

      if (i === 0) {
        zi = [0, 0, 1];
        pi = [robot.base_offset[0], robot.base_offset[1], robot.base_offset[2]];
      } else {
        const tPrev = fk.t_transforms[i - 1];
        zi = [tPrev[0][2], tPrev[1][2], tPrev[2][2]];
        pi = [tPrev[0][3], tPrev[1][3], tPrev[2][3]];
      }

      // Linear part: zi x (pe - pi)
      const rx = pe[0] - pi[0];
      const ry = pe[1] - pi[1];
      const rz = pe[2] - pi[2];

      const jv: [number, number, number] = [
        zi[1] * rz - zi[2] * ry,
        zi[2] * rx - zi[0] * rz,
        zi[0] * ry - zi[1] * rx
      ];

      J[0][i] = jv[0];
      J[1][i] = jv[1];
      J[2][i] = jv[2];
      J[3][i] = zi[0];
      J[4][i] = zi[1];
      J[5][i] = zi[2];
    }

    return J;
  }

  /**
   * Damped Least Squares (DLS) Cartesian Inverse Kinematics for micro-corrections
   * delta_q = J^T * (J * J^T + lambda^2 * I)^(-1) * delta_x
   */
  public static solveMicroCorrectionDLS(
    robot: RobotModel,
    qCurrent: number[],
    targetCartesian: [number, number, number],
    lambda = 0.03
  ): number[] {
    const fk = this.forwardKinematics(robot, qCurrent);
    const ex = targetCartesian[0] - fk.ee_position[0];
    const ey = targetCartesian[1] - fk.ee_position[1];
    const ez = targetCartesian[2] - fk.ee_position[2];
    const errNorm = Math.hypot(ex, ey, ez);

    if (errNorm < 1e-6) return [...qCurrent];

    const J = this.computeJacobian(robot, qCurrent);
    const J_pos = [J[0], J[1], J[2]]; // 3 x dof

    // JJ^T (3x3)
    const dof = robot.dof;
    const JJt: number[][] = [
      [0, 0, 0],
      [0, 0, 0],
      [0, 0, 0]
    ];

    for (let r = 0; r < 3; r++) {
      for (let c = 0; c < 3; c++) {
        let sum = 0;
        for (let k = 0; k < dof; k++) {
          sum += J_pos[r][k] * J_pos[c][k];
        }
        if (r === c) sum += lambda * lambda;
        JJt[r][c] = sum;
      }
    }

    // Invert 3x3 matrix JJt
    const invJJt = this.invert3x3(JJt);
    if (!invJJt) return [...qCurrent];

    // J_inv_dls = J^T * invJJt  (dof x 3)
    // delta_q = J_inv_dls * [ex, ey, ez]
    const errVec = [ex, ey, ez];
    const deltaQ: number[] = Array(dof).fill(0);

    for (let i = 0; i < dof; i++) {
      let dq_i = 0;
      for (let r = 0; r < 3; r++) {
        let JT_inv_row = 0;
        for (let c = 0; c < 3; c++) {
          JT_inv_row += J_pos[c][i] * invJJt[c][r];
        }
        dq_i += JT_inv_row * errVec[r];
      }
      deltaQ[i] = dq_i;
    }

    // Limit step size for safety
    const stepNorm = Math.hypot(...deltaQ);
    const maxStep = 0.05; // rad limit
    const scale = stepNorm > maxStep ? maxStep / stepNorm : 1.0;

    const qNext: number[] = [];
    for (let i = 0; i < dof; i++) {
      const qVal = qCurrent[i] + deltaQ[i] * scale;
      const p = robot.dh_parameters[i];
      qNext.push(Math.max(p.q_min, Math.min(p.q_max, qVal)));
    }

    return qNext;
  }

  private static invert3x3(m: number[][]): number[][] | null {
    const a = m[0][0], b = m[0][1], c = m[0][2];
    const d = m[1][0], e = m[1][1], f = m[1][2];
    const g = m[2][0], h = m[2][1], k = m[2][2];

    const det = a * (e * k - f * h) - b * (d * k - f * g) + c * (d * h - e * g);
    if (Math.abs(det) < 1e-12) return null;

    const invDet = 1.0 / det;
    return [
      [(e * k - f * h) * invDet, (c * h - b * k) * invDet, (b * f - c * e) * invDet],
      [(f * g - d * k) * invDet, (a * k - c * g) * invDet, (c * d - a * f) * invDet],
      [(d * h - e * g) * invDet, (g * b - a * h) * invDet, (a * e - b * d) * invDet]
    ];
  }
}
