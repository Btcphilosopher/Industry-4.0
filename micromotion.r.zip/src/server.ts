import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { join } from 'node:path';
import { STANDARD_6AXIS_COBOT, HIGH_SPEED_6AXIS } from './app/core/robot-models';
import { SimulationEngine } from './app/core/simulation';
import { OptimizerEngine } from './app/core/optimizer';
import { TelemetryAnalyzer } from './app/core/telemetry-analysis';
import { DEFAULT_DEMO_TASK } from './app/core/task-decomposition';
import { R_SOURCE_FILES } from './app/core/r-source-provider';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json({ limit: '50mb' }));
const angularApp = new AngularNodeAppEngine();

/**
 * MicroMotion.R REST API
 */
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    engine: 'MicroMotion.R Computational Engine & Digital Twin',
    version: '1.0.0',
    resolution_support: ['0.1ms', '0.5ms', '1.0ms', '5.0ms', '10.0ms']
  });
});

app.get('/api/robots', (req, res) => {
  res.json([STANDARD_6AXIS_COBOT, HIGH_SPEED_6AXIS]);
});

app.get('/api/demo-task', (req, res) => {
  res.json(DEFAULT_DEMO_TASK);
});

app.get('/api/r-package', (req, res) => {
  res.json(R_SOURCE_FILES);
});

app.post('/api/simulate', (req, res) => {
  try {
    const {
      robotId,
      initialState = [0, -Math.PI / 2, Math.PI / 2, 0, Math.PI / 2, 0],
      targetState = [0.45, -Math.PI / 3, 0.65 * Math.PI, -0.32, Math.PI / 2, 0.45],
      duration = 2.0,
      dt = 0.001,
      profileType = 'quintic',
      enableMicroCorrection = true,
      disturbanceScale = 0.00004
    } = req.body;

    const robot = robotId === 'fast_6dof' ? HIGH_SPEED_6AXIS : STANDARD_6AXIS_COBOT;

    const simResult = SimulationEngine.simulateMicroMotion({
      robot,
      initialState,
      targetState,
      duration,
      dt,
      profileType,
      enableMicroCorrection,
      disturbanceScale
    });

    const analysis = TelemetryAnalyzer.analyze(simResult);

    res.json({
      simResult,
      analysis
    });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});

app.post('/api/optimize', (req, res) => {
  try {
    const {
      robotId,
      initialState = [0, -Math.PI / 2, Math.PI / 2, 0, Math.PI / 2, 0],
      targetState = [0.45, -Math.PI / 3, 0.65 * Math.PI, -0.32, Math.PI / 2, 0.45],
      mode = 'BALANCED',
      dt = 0.001,
      customWeights
    } = req.body;

    const robot = robotId === 'fast_6dof' ? HIGH_SPEED_6AXIS : STANDARD_6AXIS_COBOT;

    const comparison = OptimizerEngine.optimizeTrajectory(
      robot,
      initialState,
      targetState,
      mode,
      dt,
      customWeights
    );

    res.json(comparison);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }
    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);

