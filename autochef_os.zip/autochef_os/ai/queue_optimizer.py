"""
Queue optimiser AI.

A lightweight feedback controller (not a trained model -- see the module
docstring in ``cooking_scheduler.py`` for the note on where a PyTorch
policy could be swapped in) that keeps an exponentially-weighted moving
average of wait time per channel and boosts the priority weighting of any
channel that is drifting above its service-level target, so a slow
delivery queue doesn't get starved indefinitely behind a bursty
drive-thru rush.
"""

from __future__ import annotations

from typing import Dict

from autochef_os.core.engine import SimulationEngine
from autochef_os.core.event_system import Topics
from autochef_os.orders.order_system import Order
from autochef_os.orders.queue_manager import QueueManager
from autochef_os.utils.logging import get_logger

logger = get_logger("ai.queue_optimizer")

TARGET_WAIT_S: Dict[str, float] = {"drive_thru": 180.0, "dine_in": 240.0, "delivery": 300.0}
EWMA_ALPHA = 0.25


class QueueOptimizerAI:
    def __init__(self, engine: SimulationEngine, queue_manager: QueueManager):
        self.engine = engine
        self.queue = queue_manager
        self.ewma_wait: Dict[str, float] = dict(TARGET_WAIT_S)
        self.urgency_weight: Dict[str, float] = {ch: 1.0 for ch in TARGET_WAIT_S}
        engine.bus.subscribe(Topics.ORDER_COMPLETED, self._on_order_completed)
        self.queue.set_scorer(self._score)

    def _on_order_completed(self, order: Order, **_kwargs) -> None:
        wait = order.wait_time_before_cooking()
        if wait is None:
            return
        ch = order.channel.value
        prev = self.ewma_wait.get(ch, wait)
        self.ewma_wait[ch] = (1 - EWMA_ALPHA) * prev + EWMA_ALPHA * wait

    def _score(self, order: Order, now: float) -> float:
        age = now - order.created_at
        weight = self.urgency_weight.get(order.channel.value, 1.0)
        return -(age * weight) - 0.01 * order.total_price

    def tick(self, engine: SimulationEngine) -> None:
        changed = False
        for channel, target in TARGET_WAIT_S.items():
            observed = self.ewma_wait.get(channel, target)
            ratio = observed / target if target else 1.0
            new_weight = min(3.0, max(0.5, 1.0 + 0.8 * (ratio - 1.0)))
            if abs(new_weight - self.urgency_weight.get(channel, 1.0)) > 0.02:
                self.urgency_weight[channel] = new_weight
                changed = True

        self.queue.reprioritize_all()
        if changed:
            engine.bus.publish(
                Topics.AI_QUEUE_REPRIORITIZED, weights=dict(self.urgency_weight), t=engine.now
            )
            logger.debug("t=%.0f queue urgency weights -> %s", engine.now, self.urgency_weight)
