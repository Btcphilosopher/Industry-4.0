"""
Cooking scheduler AI.

Decides, every AI tick, which station kind is currently the system's
bottleneck (highest load score = busiest relative to its own capacity)
and biases the automation layer's robot pool toward assisting that
station first. This is a simple greedy heuristic; the scoring function is
isolated in :meth:`CookingSchedulerAI.station_scores` specifically so it
can be swapped for a learned policy (e.g. a small PyTorch model trained
on historical utilisation traces) without touching the rest of the
system -- the AI layer only needs to keep producing a
``{station_name: priority}`` mapping.
"""

from __future__ import annotations

from typing import Dict

from autochef_os.automation.task_scheduler import TaskScheduler
from autochef_os.core.engine import SimulationEngine
from autochef_os.core.event_system import Topics
from autochef_os.kitchen.station_base import StationBase
from autochef_os.utils.logging import get_logger

logger = get_logger("ai.cooking_scheduler")


class CookingSchedulerAI:
    def __init__(self, engine: SimulationEngine, stations: Dict[str, StationBase], scheduler: TaskScheduler):
        self.engine = engine
        self.stations = stations
        self.scheduler = scheduler

    def station_scores(self) -> Dict[str, float]:
        return {name: st.load_score() for name, st in self.stations.items()}

    def tick(self, engine: SimulationEngine) -> None:
        if not engine.config.cooking_scheduler_enabled:
            return
        scores = self.station_scores()
        if not scores:
            return
        busiest = max(scores, key=scores.get)
        if scores[busiest] <= 0:
            self.scheduler.robot_priority_station = None
            return
        if self.scheduler.robot_priority_station != busiest:
            self.scheduler.robot_priority_station = busiest
            engine.bus.publish(Topics.AI_ROUTING_DECISION, station=busiest, scores=scores, t=engine.now)
            logger.debug("t=%.0f cooking scheduler AI: prioritising robots on %s (%s)", engine.now, busiest, scores)
