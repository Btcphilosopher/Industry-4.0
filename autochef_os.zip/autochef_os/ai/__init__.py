"""AI optimisation layer: queue prioritisation, staffing, and cooking scheduling."""
