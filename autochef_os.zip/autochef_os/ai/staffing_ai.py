"""
Staffing / robot allocation AI.

Periodically inspects each station's load and dynamically grows or
shrinks its *effective* capacity within configured bounds -- standing in
for calling extra crew to the line or pulling a robot off a quieter
station -- so throughput scales with demand instead of the plant being
sized (and paid for) at worst-case peak, all day.

Two signals feed the decision, smoothed with an EWMA so a single noisy
sampling window (short relative to a station's service time when
capacity is low) doesn't cause the controller to flip-flop:

* recent utilisation (busy fraction of the station's own capacity-time)
* queue backlog fraction (how full the station's input queue is)

Either signal alone can mislead: utilisation looks "idle" for a one-unit
station between two long jobs even while a queue is piling up behind it,
and queue depth alone doesn't distinguish a genuinely saturated station
from one that just received a burst. Combining them is what a real shift
lead actually does -- glance at both the grill and the ticket rail.
"""

from __future__ import annotations

from typing import Dict

from autochef_os.core.engine import SimulationEngine
from autochef_os.core.event_system import Topics
from autochef_os.kitchen.station_base import StationBase
from autochef_os.utils.logging import get_logger

logger = get_logger("ai.staffing_ai")

MIN_CAPACITY = 1
MAX_CAPACITY_MULTIPLIER = 2.5
EWMA_ALPHA = 0.4
QUEUE_SCALE_UP_FRACTION = 0.6
QUEUE_SCALE_DOWN_FRACTION = 0.15


class StaffingAI:
    def __init__(self, engine: SimulationEngine, stations: Dict[str, StationBase]):
        self.engine = engine
        self.stations = stations
        self._base_capacity = {name: st.resource.capacity for name, st in stations.items()}
        self._util_ewma: Dict[str, float] = {name: 0.0 for name in stations}
        self.adjustments = 0

    def tick(self, engine: SimulationEngine) -> None:
        if not engine.config.staffing_ai_enabled:
            return
        for name, station in self.stations.items():
            raw_util = station.recent_utilization()
            prev = self._util_ewma.get(name, raw_util)
            util = self._util_ewma[name] = (1 - EWMA_ALPHA) * prev + EWMA_ALPHA * raw_util

            queue_fraction = station.queue_len / max(1, station.config.queue_capacity)
            base = self._base_capacity[name]
            cap = station.resource.capacity
            max_cap = max(base, int(round(base * MAX_CAPACITY_MULTIPLIER)))

            wants_up = (util > engine.config.staffing_utilization_high) or (queue_fraction > QUEUE_SCALE_UP_FRACTION)
            wants_down = (util < engine.config.staffing_utilization_low) and (queue_fraction < QUEUE_SCALE_DOWN_FRACTION)

            new_cap = cap
            if wants_up and cap < max_cap:
                new_cap = cap + 1
            elif wants_down and cap > MIN_CAPACITY:
                new_cap = cap - 1

            if new_cap != cap:
                station.set_capacity(new_cap)
                self.adjustments += 1
                engine.metrics.incr("staffing_adjustments")
                engine.bus.publish(
                    Topics.AI_STAFFING_ADJUSTED,
                    station=name, old_capacity=cap, new_capacity=new_cap,
                    utilization=util, queue_fraction=queue_fraction, t=engine.now,
                )
                logger.debug(
                    "t=%.0f staffing AI: %s capacity %d -> %d (util=%.2f queue=%.2f)",
                    engine.now, name, cap, new_cap, util, queue_fraction,
                )
