"""
Menu definition and order-content generation.

Each :class:`MenuItem` declares which kitchen stations it needs to visit
(and for how long, nominally -- actual processing time is drawn
stochastically at the station) plus the ingredients it consumes, its
price and its food cost, so the economics layer can be driven straight
off of what customers actually ordered.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Dict, List

import numpy as np


@dataclass(frozen=True)
class MenuItem:
    sku: str
    name: str
    category: str                     # burger | chicken | fries | drink | dessert
    stations: List[str]                # ordered list of stations item must visit
    ingredients: Dict[str, float]      # ingredient name -> quantity consumed
    price: float
    food_cost: float
    popularity: float = 1.0            # relative selection weight


MENU: List[MenuItem] = [
    MenuItem("BRG-CLASSIC", "Classic Burger", "burger", ["grill", "assembly"],
             {"beef_patty": 1, "bun": 1, "lettuce": 0.3, "tomato": 0.3, "cheese": 1}, 5.49, 1.85, 1.6),
    MenuItem("BRG-DOUBLE", "Double Stack Burger", "burger", ["grill", "assembly"],
             {"beef_patty": 2, "bun": 1, "cheese": 2, "sauce": 0.2}, 7.29, 2.95, 1.1),
    MenuItem("BRG-DELUXE", "Deluxe Burger", "burger", ["grill", "assembly"],
             {"beef_patty": 1, "bun": 1, "lettuce": 0.4, "tomato": 0.4, "cheese": 1, "bacon": 1, "sauce": 0.3},
             6.99, 2.60, 0.9),
    MenuItem("CHK-NUGGETS", "Chicken Nuggets (6pc)", "chicken", ["fryer", "assembly"],
             {"chicken_nugget": 6, "sauce": 0.2}, 4.29, 1.35, 1.3),
    MenuItem("CHK-SANDWICH", "Crispy Chicken Sandwich", "chicken", ["fryer", "assembly"],
             {"chicken_fillet": 1, "bun": 1, "lettuce": 0.3, "sauce": 0.2}, 5.99, 2.05, 1.0),
    MenuItem("FRIES-REG", "Fries (Regular)", "fries", ["fryer"],
             {"potato": 1.0}, 2.49, 0.55, 1.7),
    MenuItem("FRIES-LG", "Fries (Large)", "fries", ["fryer"],
             {"potato": 1.6}, 3.29, 0.80, 0.9),
    MenuItem("DRINK-SOFT", "Soft Drink", "drink", ["drink"],
             {"syrup": 0.15, "cup": 1, "ice": 1}, 1.99, 0.25, 1.5),
    MenuItem("DRINK-SHAKE", "Milkshake", "drink", ["drink"],
             {"dairy_mix": 1, "cup": 1}, 3.49, 0.95, 0.6),
    MenuItem("DESSERT-PIE", "Fruit Pie", "dessert", ["fryer"],
             {"pie_shell": 1}, 1.79, 0.45, 0.4),
]

_BY_SKU: Dict[str, MenuItem] = {item.sku: item for item in MENU}

COMBO_ATTACH = {
    "burger": ["FRIES-REG", "FRIES-LG"],
    "chicken": ["FRIES-REG", "FRIES-LG"],
}
DRINK_SKUS = ["DRINK-SOFT", "DRINK-SHAKE"]


class MenuEngine:
    """Selects a plausible basket of :class:`MenuItem` for a new order."""

    def __init__(self, rng: np.random.Generator):
        self.rng = rng
        self._mains = [m for m in MENU if m.category in ("burger", "chicken")]
        self._main_weights = np.array([m.popularity for m in self._mains], dtype=float)
        self._main_weights /= self._main_weights.sum()

    def all_items(self) -> List[MenuItem]:
        return list(MENU)

    def by_sku(self, sku: str) -> MenuItem:
        return _BY_SKU[sku]

    def _pick_main(self) -> MenuItem:
        idx = self.rng.choice(len(self._mains), p=self._main_weights)
        return self._mains[idx]

    def _pick(self, skus: List[str]) -> MenuItem:
        return _BY_SKU[skus[int(self.rng.integers(0, len(skus)))]]

    def generate_basket(self, complexity: str) -> List[MenuItem]:
        """Build a shopping basket appropriate to the requested complexity tier."""
        basket: List[MenuItem] = [self._pick_main()]

        if complexity == "simple":
            n_extra_mains = 0
            attach_fries_p, attach_drink_p = 0.35, 0.5
        elif complexity == "regular":
            n_extra_mains = int(self.rng.random() < 0.25)
            attach_fries_p, attach_drink_p = 0.75, 0.8
        else:  # complex: family/group order
            n_extra_mains = int(self.rng.integers(1, 3))
            attach_fries_p, attach_drink_p = 0.95, 0.95

        for _ in range(n_extra_mains):
            basket.append(self._pick_main())

        n_units = max(1, len(basket))
        if self.rng.random() < attach_fries_p:
            for _ in range(n_units if complexity == "complex" else 1):
                basket.append(self._pick(COMBO_ATTACH["burger"]))
        if self.rng.random() < attach_drink_p:
            for _ in range(n_units if complexity == "complex" else 1):
                basket.append(self._pick(DRINK_SKUS))
        if complexity == "complex" and self.rng.random() < 0.3:
            basket.append(_BY_SKU["DESSERT-PIE"])

        return basket
