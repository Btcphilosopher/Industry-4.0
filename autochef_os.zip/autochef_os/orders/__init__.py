"""Menu definitions, order objects, and queue management."""
