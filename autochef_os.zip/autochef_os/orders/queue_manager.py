"""
Central order queue system sitting between order generation and kitchen
routing (Customer Demand -> Order Generation -> **Queue System** -> Kitchen
Routing -> ...).

Each channel (dine-in / drive-thru / delivery) gets its own bounded
backlog. If a channel's backlog is full, the arriving order balks (the
customer walks away / hangs up) -- this is what lets the simulation model
genuine cascading congestion instead of an infinite queue.

Orders are popped in priority order. Priority is a plain float score
(lower = served first) recomputed either at enqueue time or, periodically,
by the AI queue optimiser (see ``ai/queue_optimizer.py``) which can boost
starving orders or channels that are falling behind their SLA.
"""

from __future__ import annotations

from typing import Callable, Dict, List, Optional

from autochef_os.core.engine import SimulationEngine
from autochef_os.core.event_system import Topics
from autochef_os.orders.order_system import Order, OrderState
from autochef_os.utils.logging import get_logger

logger = get_logger("orders.queue_manager")

ScorerFn = Callable[[Order, float], float]


def default_scorer(order: Order, now: float) -> float:
    """FIFO-ish base score: earlier orders and higher-value baskets win ties."""
    age = now - order.created_at
    return -age - 0.01 * order.total_price


class QueueManager:
    def __init__(self, engine: SimulationEngine, backlog_capacity: int = 60):
        self.engine = engine
        self.backlog_capacity = backlog_capacity
        self._queues: Dict[str, List[Order]] = {}
        self._not_empty = engine.env.event()
        self._scorer: ScorerFn = default_scorer

    def channels(self) -> List[str]:
        return list(self._queues.keys())

    def _queue_for(self, channel: str) -> List[Order]:
        return self._queues.setdefault(channel, [])

    def depth(self, channel: Optional[str] = None) -> int:
        if channel:
            return len(self._queues.get(channel, []))
        return sum(len(q) for q in self._queues.values())

    def set_scorer(self, scorer: ScorerFn) -> None:
        self._scorer = scorer

    def enqueue(self, order: Order) -> bool:
        q = self._queue_for(order.channel.value)
        if len(q) >= self.backlog_capacity:
            order.set_state(OrderState.BALKED, self.engine.now)
            self.engine.bus.publish(Topics.ORDER_BALKED, order=order)
            self.engine.metrics.incr("orders_balked")
            logger.debug("Order %s balked: %s backlog full", order.id, order.channel.value)
            return False
        order.set_state(OrderState.QUEUED, self.engine.now)
        order.priority = self._scorer(order, self.engine.now)
        q.append(order)
        self.engine.bus.publish(Topics.ORDER_QUEUED, order=order)
        self._wake()
        return True

    def reprioritize_all(self) -> None:
        now = self.engine.now
        for q in self._queues.values():
            for order in q:
                order.priority = self._scorer(order, now)

    def _wake(self) -> None:
        if not self._not_empty.triggered:
            self._not_empty.succeed()

    def _pop_best_nowait(self) -> Optional[Order]:
        best_order, best_q, best_score = None, None, None
        for q in self._queues.values():
            if not q:
                continue
            candidate = min(q, key=lambda o: o.priority)
            if best_score is None or candidate.priority < best_score:
                best_order, best_q, best_score = candidate, q, candidate.priority
        if best_order is not None:
            best_q.remove(best_order)
        return best_order

    def get(self):
        """SimPy generator: yields until an order is available, then returns it."""
        while True:
            order = self._pop_best_nowait()
            if order is not None:
                return order
            self._not_empty = self.engine.env.event()
            yield self._not_empty
