"""
Order objects: the "production job" travelling through the plant.

An :class:`Order` is a job ticket carrying one or more :class:`LineItem`
work units. Each line item knows which stations it still needs to visit;
the order as a whole is only ready for assembly once every line item has
cleared its station route. A simple state machine (:class:`OrderState`)
tracks the job's lifecycle for metrics and dashboard purposes.
"""

from __future__ import annotations

import itertools
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, List, Optional

from autochef_os.orders.menu_engine import MenuItem

_order_id_counter = itertools.count(1)


class OrderState(Enum):
    CREATED = auto()
    QUEUED = auto()
    ROUTED = auto()
    COOKING = auto()
    ASSEMBLING = auto()
    QUALITY_CHECK = auto()
    REWORK = auto()
    PACKAGING = auto()
    DISPATCHED = auto()
    COMPLETED = auto()
    REJECTED = auto()
    BALKED = auto()


class Channel(Enum):
    DINE_IN = "dine_in"
    DRIVE_THRU = "drive_thru"
    DELIVERY = "delivery"


@dataclass
class LineItem:
    item: MenuItem
    stations_remaining: List[str] = field(default_factory=list)
    station_log: List[Dict] = field(default_factory=list)  # {station, start, end}
    ready: bool = False

    def __post_init__(self) -> None:
        if not self.stations_remaining:
            self.stations_remaining = list(self.item.stations)

    def next_station(self) -> Optional[str]:
        return self.stations_remaining[0] if self.stations_remaining else None

    def mark_station_done(self, station: str, start: float, end: float) -> None:
        self.station_log.append({"station": station, "start": start, "end": end})
        if self.stations_remaining and self.stations_remaining[0] == station:
            self.stations_remaining.pop(0)
        self.ready = not self.stations_remaining


@dataclass
class Order:
    channel: Channel
    complexity: str
    line_items: List[LineItem]
    created_at: float
    priority: float = 0.0             # lower = more urgent; AI-adjustable
    id: int = field(default_factory=lambda: next(_order_id_counter))
    state: OrderState = OrderState.CREATED
    rework_attempts: int = 0
    defect_reasons: List[str] = field(default_factory=list)

    # timestamps for KPI computation
    queued_at: Optional[float] = None
    routed_at: Optional[float] = None
    cooking_started_at: Optional[float] = None
    assembled_at: Optional[float] = None
    qc_at: Optional[float] = None
    packaged_at: Optional[float] = None
    dispatched_at: Optional[float] = None
    completed_at: Optional[float] = None

    @property
    def n_units(self) -> int:
        return len(self.line_items)

    @property
    def total_price(self) -> float:
        return sum(li.item.price for li in self.line_items)

    @property
    def total_food_cost(self) -> float:
        return sum(li.item.food_cost for li in self.line_items)

    @property
    def all_ready(self) -> bool:
        return all(li.ready for li in self.line_items)

    def required_stations(self) -> List[str]:
        stations = []
        for li in self.line_items:
            for s in li.item.stations:
                if s not in stations:
                    stations.append(s)
        return stations

    def set_state(self, state: OrderState, sim_time: float) -> None:
        self.state = state
        ts_field = {
            OrderState.QUEUED: "queued_at",
            OrderState.ROUTED: "routed_at",
            OrderState.COOKING: "cooking_started_at",
            OrderState.ASSEMBLING: "assembled_at",
            OrderState.QUALITY_CHECK: "qc_at",
            OrderState.PACKAGING: "packaged_at",
            OrderState.DISPATCHED: "dispatched_at",
            OrderState.COMPLETED: "completed_at",
        }.get(state)
        if ts_field is not None and getattr(self, ts_field) is None:
            setattr(self, ts_field, sim_time)

    def total_cycle_time(self) -> Optional[float]:
        if self.completed_at is None:
            return None
        return self.completed_at - self.created_at

    def wait_time_before_cooking(self) -> Optional[float]:
        if self.cooking_started_at is None:
            return None
        return self.cooking_started_at - self.created_at
