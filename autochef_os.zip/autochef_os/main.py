"""
AUTOCHEF OS command line entry point.

Examples
--------
Run a standard 4-hour shift and print the final KPI report::

    python -m autochef_os.main run

Run with a live SCADA console dashboard and export a PNG summary::

    python -m autochef_os.main run --duration-hours 6 --live --png out/run.png

Run the built-in stress-test suite and print a comparison table::

    python -m autochef_os.main stress
"""

from __future__ import annotations

import argparse
import json
import sys

from autochef_os.simulation.restaurant_sim import RestaurantSimulation
from autochef_os.simulation.stress_tests import DEFAULT_SCENARIOS, StressTestRunner
from autochef_os.ui.dashboard import SCADADashboard
from autochef_os.utils.config import SimulationConfig
from autochef_os.utils.logging import get_logger

logger = get_logger("main")


def _print_kpi_report(kpis: dict) -> None:
    print("\n" + "=" * 60)
    print(" AUTOCHEF OS -- FINAL KPI REPORT")
    print("=" * 60)
    for key, value in kpis.items():
        if isinstance(value, dict):
            print(f" {key}:")
            for k2, v2 in value.items():
                print(f"    {k2:<24}: {v2}")
        elif isinstance(value, float):
            print(f" {key:<28}: {value:,.3f}")
        else:
            print(f" {key:<28}: {value}")
    print("=" * 60 + "\n")


def cmd_run(args: argparse.Namespace) -> None:
    cfg = SimulationConfig(
        sim_duration_s=args.duration_hours * 3600.0,
        random_seed=args.seed,
    )
    sim = RestaurantSimulation(cfg)

    dashboard = SCADADashboard(sim)
    if args.live:
        dashboard.attach_live(args.dashboard_interval)

    kpis = sim.run()
    _print_kpi_report(kpis)

    if args.png:
        path = dashboard.export_png(args.png)
        logger.info("Saved dashboard summary PNG to %s", path)

    if args.csv_prefix:
        sim.engine.metrics.export_csv(args.csv_prefix)
        logger.info("Exported metrics CSV with prefix %s", args.csv_prefix)

    if args.json_out:
        with open(args.json_out, "w") as fh:
            json.dump({k: v for k, v in kpis.items()}, fh, indent=2, default=str)
        logger.info("Wrote KPI JSON report to %s", args.json_out)


def cmd_stress(args: argparse.Namespace) -> None:
    cfg = SimulationConfig(sim_duration_s=args.duration_hours * 3600.0, random_seed=args.seed)
    scenarios = DEFAULT_SCENARIOS
    if args.scenarios:
        wanted = set(args.scenarios)
        scenarios = {k: v for k, v in DEFAULT_SCENARIOS.items() if k in wanted}

    runner = StressTestRunner(cfg, scenarios)
    table = runner.run_all()
    print("\n" + "=" * 100)
    print(" AUTOCHEF OS -- STRESS TEST COMPARISON")
    print("=" * 100)
    with_options = table[
        [c for c in [
            "orders_per_minute", "avg_wait_before_cooking_s", "order_accuracy_pct",
            "waste_rate_pct", "automation_efficiency_score", "revenue_per_hour", "profit_per_hour",
        ] if c in table.columns]
    ]
    print(with_options.round(2).to_string())
    print("=" * 100 + "\n")

    if args.csv_out:
        table.to_csv(args.csv_out)
        logger.info("Wrote stress-test comparison table to %s", args.csv_out)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="autochef_os", description="AUTOCHEF OS digital-twin simulator")
    sub = parser.add_subparsers(dest="command", required=True)

    p_run = sub.add_parser("run", help="Run a single simulation")
    p_run.add_argument("--duration-hours", type=float, default=4.0)
    p_run.add_argument("--seed", type=int, default=42)
    p_run.add_argument("--live", action="store_true", help="Print a live SCADA dashboard during the run")
    p_run.add_argument("--dashboard-interval", type=float, default=120.0)
    p_run.add_argument("--png", type=str, default=None, help="Path to save a PNG run summary")
    p_run.add_argument("--csv-prefix", type=str, default=None, help="Prefix path to export events/samples CSVs")
    p_run.add_argument("--json-out", type=str, default=None, help="Path to write the KPI report as JSON")
    p_run.set_defaults(func=cmd_run)

    p_stress = sub.add_parser("stress", help="Run the built-in stress-test scenario suite")
    p_stress.add_argument("--duration-hours", type=float, default=2.0)
    p_stress.add_argument("--seed", type=int, default=42)
    p_stress.add_argument("--scenarios", nargs="*", default=None, choices=list(DEFAULT_SCENARIOS.keys()))
    p_stress.add_argument("--csv-out", type=str, default=None)
    p_stress.set_defaults(func=cmd_stress)

    return parser


def main(argv=None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    args.func(args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
