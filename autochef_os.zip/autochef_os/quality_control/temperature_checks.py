"""
Food temperature model.

Hot food is served around 68-74C and cools toward an ambient ~21C
following Newton's law of cooling. Cold items (drinks) are excluded --
only items with a "hot" station route (grill/fryer) are temperature
checked. QC (or, in the worst case, the customer) catches a cold item if
too much time elapsed between cooking and hand-off.
"""

from __future__ import annotations

import math
from typing import Iterable

from autochef_os.orders.order_system import LineItem, Order

SERVE_TEMP_C = 70.0
AMBIENT_TEMP_C = 21.0
COOLING_RATE_PER_S = 0.0016  # Newton's law of cooling exponent
HOT_STATIONS = {"grill", "fryer"}


class TemperatureModel:
    @staticmethod
    def _cooled_temp(elapsed_s: float) -> float:
        elapsed_s = max(0.0, elapsed_s)
        return AMBIENT_TEMP_C + (SERVE_TEMP_C - AMBIENT_TEMP_C) * math.exp(-COOLING_RATE_PER_S * elapsed_s)

    @classmethod
    def _hot_line_items(cls, order: Order) -> Iterable[LineItem]:
        return (li for li in order.line_items if set(li.item.stations) & HOT_STATIONS)

    @classmethod
    def worst_case_temperature(cls, order: Order, now: float) -> float:
        """Returns the coolest hot item's current estimated temperature (worst case for QC)."""
        temps = []
        for li in cls._hot_line_items(order):
            cook_done_at = li.station_log[-1]["end"] if li.station_log else now
            temps.append(cls._cooled_temp(now - cook_done_at))
        return min(temps) if temps else SERVE_TEMP_C

    @classmethod
    def passes_threshold(cls, order: Order, now: float, threshold_c: float) -> bool:
        return cls.worst_case_temperature(order, now) >= threshold_c
