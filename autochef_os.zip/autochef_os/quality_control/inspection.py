"""
Quality inspection: the automated gate between assembly and packaging.

Defect probability is not a flat constant -- it rises with order
complexity (more line items, more chances to get something wrong) and
with how much recent station downtime the kitchen has seen (a rushed,
degraded kitchen makes more mistakes). Reworkable defects loop back for a
bounded number of rework attempts before an order is written off as a
reject.
"""

from __future__ import annotations

from typing import Tuple

from autochef_os.core.engine import SimulationEngine
from autochef_os.core.event_system import Topics
from autochef_os.orders.order_system import Order, OrderState
from autochef_os.quality_control.defect_detection import DefectDetector, DefectType
from autochef_os.quality_control.temperature_checks import TemperatureModel
from autochef_os.utils.logging import get_logger

logger = get_logger("quality_control.inspection")

COMPLEXITY_DEFECT_MULTIPLIER = {"simple": 0.7, "regular": 1.0, "complex": 1.6}
INSPECTION_TIME_S = 6.0


class QualityInspector:
    def __init__(self, engine: SimulationEngine):
        self.engine = engine
        self.detector = DefectDetector(engine.rng)
        self.recent_breakdowns = 0  # decayed counter nudged by station events
        engine.bus.subscribe(Topics.STATION_BROKEN, self._on_breakdown)
        engine.spawn(self._decay_loop())

    def _on_breakdown(self, **_kwargs) -> None:
        self.recent_breakdowns += 1

    def _decay_loop(self):
        while True:
            yield self.engine.timeout(300.0)
            self.recent_breakdowns = max(0, self.recent_breakdowns - 1)

    def defect_probability(self, order: Order) -> float:
        cfg = self.engine.config
        base = cfg.base_defect_probability
        base *= COMPLEXITY_DEFECT_MULTIPLIER.get(order.complexity, 1.0)
        base *= 1.0 + 0.08 * self.recent_breakdowns
        # a fresh rework attempt is more likely to have been fixed correctly,
        # but repeated reworks signal a genuinely troublesome order
        base *= 1.0 + 0.5 * order.rework_attempts
        return min(0.9, base)

    def inspect(self, order: Order):
        """SimPy generator: yields for inspection time, mutates order state, returns bool passed."""
        yield self.engine.timeout(INSPECTION_TIME_S)
        order.set_state(OrderState.QUALITY_CHECK, self.engine.now)

        temp_ok = TemperatureModel.passes_threshold(
            order, self.engine.now, self.engine.config.temperature_fail_threshold_c
        )
        defect_roll = self.engine.rng.random() < self.defect_probability(order)

        if temp_ok and not defect_roll:
            self.engine.bus.publish(Topics.ORDER_QC_PASSED, order=order)
            self.engine.metrics.incr("orders_passed_qc")
            return True

        defect = DefectType.TEMPERATURE_FAIL if not temp_ok else self.detector.classify()
        order.defect_reasons.append(defect.value)
        self.engine.metrics.incr(f"defect_{defect.value}")
        self.engine.bus.publish(Topics.ORDER_QC_FAILED, order=order, defect=defect.value)
        return False

    def resolve_failure(self, order: Order):
        """
        SimPy generator handling a failed inspection: attempts rework up to
        the configured limit, otherwise rejects the order outright.
        Returns True if the order is now good to proceed, False if rejected.
        """
        cfg = self.engine.config
        defect = DefectType(order.defect_reasons[-1])
        if DefectDetector.is_reworkable(defect) and order.rework_attempts < cfg.max_rework_attempts:
            order.rework_attempts += 1
            order.set_state(OrderState.REWORK, self.engine.now)
            self.engine.metrics.incr("orders_reworked")
            self.engine.bus.publish(Topics.ORDER_REWORKED, order=order, defect=defect.value)
            yield self.engine.timeout(cfg.rework_time_s)
            return True

        order.set_state(OrderState.REJECTED, self.engine.now)
        self.engine.metrics.incr("orders_rejected")
        self.engine.bus.publish(Topics.ORDER_REJECTED, order=order, defect=defect.value)
        return False
