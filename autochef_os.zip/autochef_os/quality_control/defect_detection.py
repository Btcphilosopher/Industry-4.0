"""
Defect classification.

Given that an order has been flagged as defective, :class:`DefectDetector`
decides *what kind* of defect it is, which in turn determines how the
system reacts: a temperature failure or wrong item usually goes back
through rework, while a severe assembly failure on a rework order that's
already exhausted its retries gets rejected outright.
"""

from __future__ import annotations

from enum import Enum
from typing import Dict

import numpy as np

DEFECT_WEIGHTS: Dict[str, float] = {
    "wrong_item": 0.30,
    "missing_item": 0.25,
    "temperature_fail": 0.20,
    "cosmetic": 0.15,
    "timing_error": 0.10,
}


class DefectType(str, Enum):
    WRONG_ITEM = "wrong_item"
    MISSING_ITEM = "missing_item"
    TEMPERATURE_FAIL = "temperature_fail"
    COSMETIC = "cosmetic"
    TIMING_ERROR = "timing_error"


REWORKABLE = {DefectType.WRONG_ITEM, DefectType.MISSING_ITEM, DefectType.TEMPERATURE_FAIL, DefectType.COSMETIC}


class DefectDetector:
    def __init__(self, rng: np.random.Generator):
        self.rng = rng
        names = list(DEFECT_WEIGHTS.keys())
        weights = np.array([DEFECT_WEIGHTS[n] for n in names])
        self._names = names
        self._probs = weights / weights.sum()

    def classify(self) -> DefectType:
        idx = self.rng.choice(len(self._names), p=self._probs)
        return DefectType(self._names[idx])

    @staticmethod
    def is_reworkable(defect: DefectType) -> bool:
        return defect in REWORKABLE
