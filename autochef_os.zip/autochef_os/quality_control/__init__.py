"""Inspection, temperature checks, defect detection and rework loops."""
