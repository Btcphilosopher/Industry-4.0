import unittest

from autochef_os.core.engine import SimulationEngine
from autochef_os.kitchen.grill_station import GrillStation
from autochef_os.orders.menu_engine import MenuEngine
from autochef_os.orders.order_system import Channel, LineItem, Order
from autochef_os.orders.queue_manager import QueueManager
from autochef_os.utils.config import SimulationConfig


class TestStationBase(unittest.TestCase):
    def test_station_processes_jobs_and_tracks_utilization(self):
        cfg = SimulationConfig(sim_duration_s=500, random_seed=5)
        cfg.grill.count = 1
        cfg.grill.base_service_time_s = 20
        cfg.grill.failure_rate_per_hour = 0.0
        engine = SimulationEngine(cfg)
        grill = GrillStation(engine)

        def job():
            yield from grill.process_job()

        engine.spawn(job())
        engine.spawn(job())
        engine.run(until=200)

        self.assertEqual(grill.jobs_completed, 2)
        self.assertGreater(grill.busy_seconds, 0)


class TestQueueManager(unittest.TestCase):
    def test_enqueue_and_get_respects_priority(self):
        cfg = SimulationConfig(sim_duration_s=10, random_seed=6)
        engine = SimulationEngine(cfg)
        qm = QueueManager(engine, backlog_capacity=5)
        menu = MenuEngine(engine.rng)

        def make_order(price_item_sku):
            item = menu.by_sku(price_item_sku)
            return Order(
                channel=Channel.DINE_IN, complexity="simple",
                line_items=[LineItem(item=item)], created_at=engine.now,
            )

        cheap = make_order("FRIES-REG")
        pricey = make_order("BRG-DOUBLE")
        qm.enqueue(cheap)
        qm.enqueue(pricey)

        got = {}

        def consumer():
            got["first"] = yield from qm.get()
            got["second"] = yield from qm.get()

        engine.spawn(consumer())
        engine.run(until=5)

        # both were queued at the same instant -- higher value order should
        # win the tie-break in the default scorer
        self.assertEqual(got["first"], pricey)
        self.assertEqual(got["second"], cheap)

    def test_backlog_capacity_causes_balk(self):
        cfg = SimulationConfig(sim_duration_s=10, random_seed=7)
        engine = SimulationEngine(cfg)
        qm = QueueManager(engine, backlog_capacity=1)
        menu = MenuEngine(engine.rng)
        item = menu.by_sku("DRINK-SOFT")

        def make():
            return Order(channel=Channel.DELIVERY, complexity="simple",
                         line_items=[LineItem(item=item)], created_at=engine.now)

        self.assertTrue(qm.enqueue(make()))
        self.assertFalse(qm.enqueue(make()))


if __name__ == "__main__":
    unittest.main()
