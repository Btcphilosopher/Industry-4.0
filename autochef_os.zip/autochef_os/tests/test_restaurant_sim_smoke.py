import unittest

from autochef_os.simulation.restaurant_sim import RestaurantSimulation
from autochef_os.simulation.stress_tests import StressTestRunner, scenario_rush_spike
from autochef_os.utils.config import SimulationConfig


class TestRestaurantSimSmoke(unittest.TestCase):
    def test_short_run_produces_completed_orders_and_kpis(self):
        cfg = SimulationConfig(sim_duration_s=45 * 60, random_seed=11, warm_up_s=60)
        sim = RestaurantSimulation(cfg)
        kpis = sim.run()

        self.assertGreater(kpis["orders_created"], 0)
        self.assertGreaterEqual(kpis["orders_completed"], 1)
        self.assertGreaterEqual(kpis["order_accuracy_pct"], 0.0)
        self.assertLessEqual(kpis["order_accuracy_pct"], 100.0)
        self.assertIn("revenue", kpis)
        self.assertGreaterEqual(kpis["revenue"], 0.0)

    def test_stress_scenario_runs_end_to_end(self):
        cfg = SimulationConfig(sim_duration_s=20 * 60, random_seed=12)
        runner = StressTestRunner(cfg, {"rush_spike": scenario_rush_spike})
        table = runner.run_all()
        self.assertIn("rush_spike", table.index)
        self.assertGreaterEqual(table.loc["rush_spike", "orders_created"], 0)


if __name__ == "__main__":
    unittest.main()
