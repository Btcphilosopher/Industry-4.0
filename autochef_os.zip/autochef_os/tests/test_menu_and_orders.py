import unittest

import numpy as np

from autochef_os.orders.menu_engine import MenuEngine
from autochef_os.orders.order_system import Channel, LineItem, Order


class TestMenuEngine(unittest.TestCase):
    def setUp(self):
        self.menu = MenuEngine(np.random.default_rng(1))

    def test_generate_basket_nonempty(self):
        for complexity in ("simple", "regular", "complex"):
            basket = self.menu.generate_basket(complexity)
            self.assertGreaterEqual(len(basket), 1)

    def test_complex_baskets_tend_to_be_larger(self):
        rng = np.random.default_rng(7)
        menu = MenuEngine(rng)
        simple_sizes = [len(menu.generate_basket("simple")) for _ in range(200)]
        complex_sizes = [len(menu.generate_basket("complex")) for _ in range(200)]
        self.assertGreater(np.mean(complex_sizes), np.mean(simple_sizes))


class TestOrderSystem(unittest.TestCase):
    def test_line_item_progresses_through_stations(self):
        menu = MenuEngine(np.random.default_rng(3))
        item = menu.by_sku("BRG-CLASSIC")
        li = LineItem(item=item)
        self.assertEqual(li.next_station(), "grill")
        li.mark_station_done("grill", 0.0, 10.0)
        self.assertEqual(li.next_station(), "assembly")
        self.assertFalse(li.ready)
        li.mark_station_done("assembly", 10.0, 20.0)
        self.assertTrue(li.ready)

    def test_order_total_price_matches_line_items(self):
        menu = MenuEngine(np.random.default_rng(4))
        basket = [menu.by_sku("BRG-CLASSIC"), menu.by_sku("FRIES-REG")]
        order = Order(
            channel=Channel.DINE_IN,
            complexity="simple",
            line_items=[LineItem(item=i) for i in basket],
            created_at=0.0,
        )
        self.assertAlmostEqual(order.total_price, basket[0].price + basket[1].price)


if __name__ == "__main__":
    unittest.main()
