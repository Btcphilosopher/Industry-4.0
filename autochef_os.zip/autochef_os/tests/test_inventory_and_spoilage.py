import unittest

from autochef_os.core.engine import SimulationEngine
from autochef_os.ingredients.inventory_system import InventorySystem
from autochef_os.ingredients.spoilage_model import SpoilageModel
from autochef_os.utils.config import SimulationConfig


class TestInventorySystem(unittest.TestCase):
    def setUp(self):
        self.engine = SimulationEngine(SimulationConfig(sim_duration_s=10, random_seed=1))
        self.inventory = InventorySystem(self.engine)

    def test_consume_all_or_nothing(self):
        self.inventory.stock["bun"] = 1
        ok = self.inventory.consume({"bun": 1, "beef_patty": 1})
        # beef_patty likely plentiful, bun sufficient -> should succeed
        self.assertTrue(ok)
        self.assertEqual(self.inventory.stock["bun"], 0)

    def test_consume_fails_and_records_shortage(self):
        self.inventory.stock["bun"] = 0
        ok = self.inventory.consume({"bun": 5})
        self.assertFalse(ok)
        self.assertIn("bun", self.inventory.shortages)

    def test_restock_capped_at_par(self):
        par = self.inventory.par_level("bun")
        self.inventory.stock["bun"] = par
        self.inventory.restock("bun", 1000)
        self.assertEqual(self.inventory.stock["bun"], par)


class TestSpoilageModel(unittest.TestCase):
    def test_batches_expire_and_reduce_stock(self):
        engine = SimulationEngine(SimulationConfig(sim_duration_s=1, random_seed=2, spoilage_check_interval_s=1.0))
        inventory = InventorySystem(engine)
        inventory.stock["lettuce"] = 10
        spoilage = SpoilageModel(engine, inventory)
        spoilage.batches["lettuce"][0].quantity = 10
        spoilage.batches["lettuce"][0].arrived_at = -1_000_000  # force expiry

        engine.run(until=5.0)
        self.assertLess(inventory.stock["lettuce"], 10)


if __name__ == "__main__":
    unittest.main()
