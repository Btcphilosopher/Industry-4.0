"""
Task scheduler: the execution layer that physically routes a line item's
work through its station chain, opportunistically grabbing robot
assistance and moving completed sub-items across the conveyor.

This is deliberately the "dumb but fast" mechanical dispatcher -- it
always tries to make forward progress on whatever station is next. The
*intelligent* decision of which station kind currently deserves priority
robot assistance is made by :class:`ai.cooking_scheduler.CookingSchedulerAI`
and simply read here as ``robot_priority_station``.
"""

from __future__ import annotations

from typing import Dict, Optional

from autochef_os.automation.conveyor_system import ConveyorBelt
from autochef_os.automation.robot_workers import RobotWorkerPool
from autochef_os.core.engine import SimulationEngine
from autochef_os.kitchen.station_base import StationBase
from autochef_os.orders.order_system import LineItem
from autochef_os.utils.logging import get_logger

logger = get_logger("automation.task_scheduler")

STATION_FULL_BACKOFF_S = 4.0
BASE_ROBOT_REQUEST_PROBABILITY = 0.45


class TaskScheduler:
    def __init__(
        self,
        engine: SimulationEngine,
        stations: Dict[str, StationBase],
        robots: Optional[RobotWorkerPool] = None,
        conveyor: Optional[ConveyorBelt] = None,
    ):
        self.engine = engine
        self.stations = stations
        self.robots = robots
        self.conveyor = conveyor
        self.robot_priority_station: Optional[str] = None  # set live by the cooking scheduler AI

    def _wants_robot(self, station_name: str) -> bool:
        if self.robots is None or self.robots.n_robots == 0:
            return False
        if station_name == self.robot_priority_station:
            return True
        return self.engine.rng.random() < BASE_ROBOT_REQUEST_PROBABILITY

    def run_line_item(self, line_item: LineItem):
        """SimPy generator: drives a single line item through its full station route."""
        while line_item.stations_remaining:
            station_name = line_item.next_station()
            station = self.stations.get(station_name)
            if station is None:
                logger.warning("Unknown station %r requested, skipping", station_name)
                line_item.mark_station_done(station_name, self.engine.now, self.engine.now)
                continue

            if station.is_full():
                self.engine.metrics.incr(f"station_backpressure_{station_name}")
                yield self.engine.timeout(STATION_FULL_BACKOFF_S)
                continue

            got_robot = False
            robot_req = None
            if self._wants_robot(station_name):
                robot_req = yield from self.robots.acquire()
                if robot_req is not None:
                    got_robot = self.robots.roll_reliability()

            start = self.engine.now
            yield from station.process_job(robot_assist=got_robot)
            if robot_req is not None:
                self.robots.release(robot_req)

            line_item.mark_station_done(station_name, start, self.engine.now)

            if self.conveyor is not None and line_item.stations_remaining:
                yield from self.conveyor.transport()
