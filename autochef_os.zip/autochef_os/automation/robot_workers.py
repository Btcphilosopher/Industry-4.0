"""
Robotic kitchen assistants: a shared pool of automation units that can be
dispatched to any station to shorten its service time
(``StationConfig.robot_assist_speedup``). Modelled as a SimPy resource
pool with imperfect reliability -- a robot can be "acquired" for a job and
still glitch, in which case the job proceeds at unassisted speed anyway.
"""

from __future__ import annotations

from typing import Optional

import simpy

from autochef_os.core.engine import SimulationEngine


class RobotWorkerPool:
    def __init__(self, engine: SimulationEngine, n_robots: int, reliability: float):
        self.engine = engine
        self.reliability = reliability
        self._n_robots = max(0, n_robots)
        # SimPy's Resource requires capacity > 0; a zero-robot fleet is
        # modelled as capacity=1 with `available()` always False instead.
        self.resource = simpy.Resource(engine.env, capacity=max(1, self._n_robots))
        self.jobs_assisted = 0
        self.jobs_glitched = 0

    @property
    def n_robots(self) -> int:
        return self._n_robots

    def available(self) -> bool:
        if self._n_robots == 0:
            return False
        return len(self.resource.users) < self.resource.capacity

    def utilization(self) -> float:
        if self._n_robots == 0:
            return 0.0
        return len(self.resource.users) / self.resource.capacity

    def acquire(self):
        """Non-blocking-in-spirit acquire: only tries if a robot is currently free."""
        if not self.available():
            return None
        req = self.resource.request()
        yield req
        return req

    def release(self, req) -> None:
        self.resource.release(req)

    def roll_reliability(self) -> bool:
        """True if the robot performs correctly this job; False if it glitches."""
        ok = self.engine.rng.random() < self.reliability
        if ok:
            self.jobs_assisted += 1
        else:
            self.jobs_glitched += 1
        return ok
