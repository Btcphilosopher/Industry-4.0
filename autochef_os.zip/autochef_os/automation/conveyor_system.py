"""
Conveyor belt transporting in-progress items between stations.

A physically bounded transport link: only ``capacity`` items can be
in transit at once, and each transit takes a stochastic amount of time
around ``transit_time_s``. When the belt is saturated, items queue for a
slot exactly like they would for a station -- this is one of the more
realistic sources of cascading delay in a real automated kitchen.
"""

from __future__ import annotations

import numpy as np
import simpy

from autochef_os.core.engine import SimulationEngine


class ConveyorBelt:
    def __init__(self, engine: SimulationEngine, capacity: int, transit_time_s: float, cv: float = 0.2):
        self.engine = engine
        self.transit_time_s = transit_time_s
        self.cv = cv
        self.resource = simpy.Resource(engine.env, capacity=max(1, capacity))
        self.items_transported = 0
        self.total_transit_time = 0.0

    def load_fraction(self) -> float:
        return len(self.resource.users) / self.resource.capacity

    def transport(self):
        rng: np.random.Generator = self.engine.rng
        with self.resource.request() as req:
            yield req
            duration = max(1.0, rng.normal(self.transit_time_s, self.transit_time_s * self.cv))
            yield self.engine.timeout(duration)
            self.items_transported += 1
            self.total_transit_time += duration
