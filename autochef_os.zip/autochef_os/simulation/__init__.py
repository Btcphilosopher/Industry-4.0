"""Top-level restaurant simulation orchestration and stress-test scenarios."""
