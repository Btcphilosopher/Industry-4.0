"""
Stress-test scenario runner.

Runs the same base configuration through a set of adverse scenarios --
a lunch-rush demand spike, a wave of equipment breakdowns, a supply-chain
shock, and an all-complex order mix -- and tabulates the resulting KPIs
side by side so the plant's resilience (or lack of it) is visible at a
glance rather than buried in a single run's log.
"""

from __future__ import annotations

from typing import Callable, Dict, List

import pandas as pd

from autochef_os.simulation.restaurant_sim import RestaurantSimulation
from autochef_os.utils.config import SimulationConfig
from autochef_os.utils.logging import get_logger

logger = get_logger("simulation.stress_tests")

ScenarioFn = Callable[[SimulationConfig], SimulationConfig]


def scenario_baseline(cfg: SimulationConfig) -> SimulationConfig:
    return cfg


def scenario_rush_spike(cfg: SimulationConfig) -> SimulationConfig:
    cfg = cfg.clone()
    cfg.base_arrival_rate_per_min *= 2.2
    cfg.lunch_peak_multiplier *= 1.3
    cfg.dinner_peak_multiplier *= 1.3
    return cfg


def scenario_equipment_cascade(cfg: SimulationConfig) -> SimulationConfig:
    cfg = cfg.clone()
    for station in (cfg.grill, cfg.fryer, cfg.drink, cfg.assembly):
        station.failure_rate_per_hour *= 5.0
        station.mean_repair_time_s *= 2.0
    return cfg


def scenario_supply_shock(cfg: SimulationConfig) -> SimulationConfig:
    cfg = cfg.clone()
    cfg.supplier_lead_time_s *= 5.0     # trucks are badly delayed...
    cfg.par_level_multiplier *= 0.15    # ...and the walk-in started nearly empty
    return cfg


def scenario_complex_mix(cfg: SimulationConfig) -> SimulationConfig:
    cfg = cfg.clone()
    cfg.complexity_weights = {"simple": 0.15, "regular": 0.30, "complex": 0.55}
    return cfg


def scenario_no_automation(cfg: SimulationConfig) -> SimulationConfig:
    cfg = cfg.clone()
    cfg.n_robot_workers = 0
    cfg.staffing_ai_enabled = False
    cfg.cooking_scheduler_enabled = False
    return cfg


DEFAULT_SCENARIOS: Dict[str, ScenarioFn] = {
    "baseline": scenario_baseline,
    "rush_spike": scenario_rush_spike,
    "equipment_cascade": scenario_equipment_cascade,
    "supply_shock": scenario_supply_shock,
    "complex_mix": scenario_complex_mix,
    "no_automation": scenario_no_automation,
}


class StressTestRunner:
    def __init__(self, base_config: SimulationConfig, scenarios: Dict[str, ScenarioFn] = None):
        self.base_config = base_config
        self.scenarios = scenarios or DEFAULT_SCENARIOS
        self.results: Dict[str, Dict] = {}

    def run_all(self) -> pd.DataFrame:
        for name, scenario_fn in self.scenarios.items():
            logger.info("Running stress-test scenario: %s", name)
            cfg = scenario_fn(self.base_config.clone())
            sim = RestaurantSimulation(cfg)
            kpis = sim.run()
            self.results[name] = kpis
        return self.comparison_table()

    def comparison_table(self) -> pd.DataFrame:
        rows = []
        for name, kpis in self.results.items():
            row = {"scenario": name}
            for k, v in kpis.items():
                if isinstance(v, dict):
                    continue
                row[k] = v
            rows.append(row)
        return pd.DataFrame(rows).set_index("scenario")
