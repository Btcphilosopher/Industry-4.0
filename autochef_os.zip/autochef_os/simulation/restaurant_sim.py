"""
RestaurantSimulation: composition root wiring every subsystem together and
driving a single order, end to end, through the full production pipeline:

    Customer Demand -> Order Generation -> Queue System -> Kitchen Routing
    -> Parallel Cooking Stations -> Assembly Line -> Quality Control
    -> Packaging -> Delivery/Service Output

Per-order flow is a single SimPy process (:meth:`RestaurantSimulation._order_flow`);
system-wide periodic optimisation and telemetry sampling are driven by
:class:`core.simulation_loop.SimulationLoop`.
"""

from __future__ import annotations

from typing import Dict, List

import numpy as np

from autochef_os.ai.cooking_scheduler import CookingSchedulerAI
from autochef_os.ai.queue_optimizer import QueueOptimizerAI
from autochef_os.ai.staffing_ai import StaffingAI
from autochef_os.automation.conveyor_system import ConveyorBelt
from autochef_os.automation.robot_workers import RobotWorkerPool
from autochef_os.automation.task_scheduler import TaskScheduler
from autochef_os.core.engine import SimulationEngine
from autochef_os.core.event_system import Topics
from autochef_os.core.simulation_loop import SimulationLoop
from autochef_os.customers.arrival_generator import ArrivalGenerator
from autochef_os.customers.demand_model import DemandModel
from autochef_os.economics.cost_model import CostModel
from autochef_os.economics.revenue_model import RevenueModel
from autochef_os.ingredients.inventory_system import InventorySystem
from autochef_os.ingredients.spoilage_model import SpoilageModel
from autochef_os.ingredients.supply_chain import SupplyChain
from autochef_os.kitchen.assembly_line import AssemblyLine
from autochef_os.kitchen.drink_station import DrinkStation
from autochef_os.kitchen.fryer_station import FryerStation
from autochef_os.kitchen.grill_station import GrillStation
from autochef_os.kitchen.station_base import StationBase
from autochef_os.logistics.delivery_dispatch import DeliveryDispatch
from autochef_os.logistics.drive_thru import DriveThru
from autochef_os.logistics.packaging import PackagingStation
from autochef_os.orders.menu_engine import MenuEngine
from autochef_os.orders.order_system import Channel, Order, OrderState
from autochef_os.orders.queue_manager import QueueManager
from autochef_os.quality_control.inspection import QualityInspector
from autochef_os.utils.config import SimulationConfig
from autochef_os.utils.logging import get_logger

logger = get_logger("simulation.restaurant_sim")

DINE_IN_HANDOFF_S = 8.0


def combined_ingredient_requirements(order: Order) -> Dict[str, float]:
    reqs: Dict[str, float] = {}
    for li in order.line_items:
        for ing, qty in li.item.ingredients.items():
            reqs[ing] = reqs.get(ing, 0.0) + qty
    return reqs


class RestaurantSimulation:
    """Builds and runs one complete AUTOCHEF OS digital-twin simulation."""

    def __init__(self, config: SimulationConfig):
        self.config = config
        self.engine = SimulationEngine(config)
        self._wire_subsystems()
        self._wire_ai_and_monitoring()
        self._subscribe_order_tracking()

    # -- wiring ---------------------------------------------------------
    def _wire_subsystems(self) -> None:
        engine = self.engine
        cfg = self.config

        self.menu = MenuEngine(engine.rng)
        self.demand = DemandModel(cfg, engine.rng)
        self.queue = QueueManager(engine)
        self.arrivals = ArrivalGenerator(engine, self.demand, self.menu, self.queue)

        self.inventory = InventorySystem(engine)
        self.spoilage = SpoilageModel(engine, self.inventory)
        self.supply_chain = SupplyChain(engine, self.inventory)

        self.grill = GrillStation(engine)
        self.fryer = FryerStation(engine)
        self.drink = DrinkStation(engine)
        self.assembly = AssemblyLine(engine)
        self.packaging = PackagingStation(engine)
        self.drive_thru = DriveThru(engine)

        self.stations: Dict[str, StationBase] = {
            "grill": self.grill, "fryer": self.fryer, "drink": self.drink, "assembly": self.assembly,
        }

        self.robots = RobotWorkerPool(engine, cfg.n_robot_workers, cfg.robot_reliability)
        self.conveyor = ConveyorBelt(engine, cfg.conveyor_capacity, cfg.conveyor_transit_time_s)
        self.scheduler = TaskScheduler(engine, self.stations, self.robots, self.conveyor)

        self.delivery = DeliveryDispatch(engine, cfg.n_delivery_couriers, cfg.courier_trip_time_s, cfg.courier_trip_time_cv)

        self.qc = QualityInspector(engine)

        self.cost_model = CostModel(engine, {**self.stations, "packaging": self.packaging, "drive_thru": self.drive_thru}, self.robots)
        self.revenue_model = RevenueModel(engine)

        for name, obj in [
            ("menu", self.menu), ("demand", self.demand), ("queue", self.queue),
            ("inventory", self.inventory), ("spoilage", self.spoilage), ("supply_chain", self.supply_chain),
            ("robots", self.robots), ("conveyor", self.conveyor), ("scheduler", self.scheduler),
            ("delivery", self.delivery), ("qc", self.qc), ("cost_model", self.cost_model),
            ("revenue_model", self.revenue_model),
        ]:
            engine.register(name, obj)

    def _wire_ai_and_monitoring(self) -> None:
        engine = self.engine
        self.queue_ai = QueueOptimizerAI(engine, self.queue)
        self.staffing_ai = StaffingAI(engine, self.stations)
        self.cooking_ai = CookingSchedulerAI(engine, self.stations, self.scheduler)

        self.loop = SimulationLoop(engine)
        self.loop.on_ai_tick(lambda e: self.queue_ai.tick(e))
        self.loop.on_ai_tick(lambda e: self.staffing_ai.tick(e))
        self.loop.on_ai_tick(lambda e: self.cooking_ai.tick(e))
        self.loop.on_monitor_tick(lambda e: self.cost_model.tick(e))
        self.loop.on_monitor_tick(lambda e: self._sample_metrics(e))

    def _subscribe_order_tracking(self) -> None:
        self.completed_orders: List[Order] = []
        self.rejected_orders: List[Order] = []
        self.balked_orders: List[Order] = []
        self.engine.bus.subscribe(Topics.ORDER_COMPLETED, lambda order, **_: self.completed_orders.append(order))
        self.engine.bus.subscribe(Topics.ORDER_REJECTED, lambda order, **_: self.rejected_orders.append(order))
        self.engine.bus.subscribe(Topics.ORDER_BALKED, lambda order, **_: self.balked_orders.append(order))

    # -- metrics sampling -------------------------------------------------
    def _sample_metrics(self, engine: SimulationEngine) -> None:
        util = {name: st.utilization() for name, st in self.stations.items()}
        station_backlog = sum(st.queue_len for st in self.stations.values())
        engine.metrics.log_sample(
            engine.now,
            queue_depth=self.queue.depth(),
            station_backlog=station_backlog,
            revenue_per_hour=self.revenue_model.revenue_per_hour(),
            profit_per_hour=self.revenue_model.profit_per_hour(self.cost_model),
            robot_utilization=self.robots.utilization(),
            orders_completed=len(self.completed_orders),
            orders_rejected=len(self.rejected_orders),
            orders_balked=len(self.balked_orders),
            **{f"util_{k}": v for k, v in util.items()},
        )

    # -- per-order production pipeline -------------------------------------------------
    def _consume_ingredients(self, order: Order, max_wait_s: float = 240.0, retry_interval_s: float = 15.0):
        reqs = combined_ingredient_requirements(order)
        waited = 0.0
        while not self.inventory.consume(reqs):
            if waited >= max_wait_s:
                return False
            yield self.engine.timeout(retry_interval_s)
            waited += retry_interval_s
        return True

    def _order_flow(self, order: Order):
        engine = self.engine

        ok = yield from self._consume_ingredients(order)
        if not ok:
            order.defect_reasons.append("ingredient_shortage")
            order.set_state(OrderState.REJECTED, engine.now)
            engine.metrics.incr("orders_rejected_shortage")
            engine.bus.publish(Topics.ORDER_REJECTED, order=order, defect="ingredient_shortage")
            self.rejected_orders.append(order)
            return

        order.set_state(OrderState.COOKING, engine.now)
        procs = [engine.env.process(self.scheduler.run_line_item(li)) for li in order.line_items]
        yield engine.env.all_of(procs)

        order.set_state(OrderState.ASSEMBLING, engine.now)
        yield from self.assembly.process_job()
        engine.bus.publish(Topics.ORDER_ASSEMBLED, order=order)

        while True:
            passed = yield from self.qc.inspect(order)
            if passed:
                break
            ok = yield from self.qc.resolve_failure(order)
            if not ok:
                return  # rejected -- terminal, already recorded by _subscribe_order_tracking

        order.set_state(OrderState.PACKAGING, engine.now)
        yield from self.packaging.process_job()
        engine.bus.publish(Topics.ORDER_PACKAGED, order=order)

        if order.channel == Channel.DRIVE_THRU:
            yield from self.drive_thru.process_job()
        elif order.channel == Channel.DELIVERY:
            yield from self.delivery.deliver(order)
        else:  # dine-in: quick counter hand-off
            yield engine.timeout(max(1.0, engine.rng.normal(DINE_IN_HANDOFF_S, 2.0)))

        order.set_state(OrderState.DISPATCHED, engine.now)
        order.set_state(OrderState.COMPLETED, engine.now)
        engine.metrics.incr("orders_completed")
        engine.bus.publish(Topics.ORDER_COMPLETED, order=order)

    def _router(self):
        engine = self.engine
        while True:
            order = yield from self.queue.get()
            engine.bus.publish(Topics.ORDER_ROUTED, order=order)
            engine.spawn(self._order_flow(order))

    # -- run --------------------------------------------------------------
    def run(self) -> Dict:
        self.engine.spawn(self.arrivals.run())
        self.engine.spawn(self._router())
        self.loop.start()
        self.engine.run()
        return self.report()

    # -- reporting ----------------------------------------------------------
    def report(self) -> Dict:
        cfg = self.config
        engine = self.engine
        warm = cfg.warm_up_s
        settled = [o for o in self.completed_orders if (o.completed_at or 0) >= warm]
        n = len(settled)
        elapsed_min = max(1e-9, (engine.now - warm) / 60.0) if engine.now > warm else max(1e-9, engine.now / 60.0)

        def _mean(vals: List[float]) -> float:
            vals = [v for v in vals if v is not None]
            return float(np.mean(vals)) if vals else 0.0

        avg_wait = _mean([o.wait_time_before_cooking() for o in settled])
        avg_cycle = _mean([o.total_cycle_time() for o in settled])
        util = {name: st.utilization() for name, st in self.stations.items()}
        terminal_total = len(self.completed_orders) + len(self.rejected_orders)
        accuracy_pct = 100.0 * len(self.completed_orders) / terminal_total if terminal_total else 100.0
        waste_rate_pct = (
            100.0 * self.cost_model.cumulative_waste_cost / max(1e-9, self.revenue_model.cumulative_revenue)
        )
        total_station_jobs = sum(st.jobs_completed for st in self.stations.values()) or 1
        robot_assist_rate = self.robots.jobs_assisted / total_station_jobs
        avg_util = float(np.mean(list(util.values()))) if util else 0.0
        fulfilment_rate = len(self.completed_orders) / max(1, engine.metrics.get("orders_created"))
        automation_efficiency = 100.0 * (0.4 * avg_util + 0.3 * fulfilment_rate + 0.3 * robot_assist_rate)

        kpis = {
            "orders_per_minute": n / elapsed_min,
            "avg_wait_before_cooking_s": avg_wait,
            "avg_total_cycle_time_s": avg_cycle,
            "station_utilization_pct": {k: round(100 * v, 1) for k, v in util.items()},
            "order_accuracy_pct": accuracy_pct,
            "waste_rate_pct": waste_rate_pct,
            "automation_efficiency_score": automation_efficiency,
            "orders_created": engine.metrics.get("orders_created"),
            "orders_completed": len(self.completed_orders),
            "orders_rejected": len(self.rejected_orders),
            "orders_balked": len(self.balked_orders),
            "orders_reworked": engine.metrics.get("orders_reworked"),
            "supplier_disruptions": self.supply_chain.total_disruptions,
            "units_spoiled": engine.metrics.get("units_spoiled"),
            "staffing_adjustments": self.staffing_ai.adjustments,
        }
        kpis.update(self.revenue_model.summary(self.cost_model))
        kpis["cost_breakdown"] = self.cost_model.cost_breakdown()
        logger.info("Final KPIs: %s", {k: v for k, v in kpis.items() if not isinstance(v, dict)})
        return kpis
