"""
AUTOCHEF OS
===========

Industry 4.0 fast-food automation & restaurant digital twin simulator.

This package is a discrete-event simulation platform that models a fully
automated quick-service restaurant as a manufacturing system: stochastic
customer demand drives a production pipeline of parallel cooking stations,
robotic/automation assist, conveyor logistics, quality control, inventory
and supply chain management, an AI optimisation layer, and an economic
model -- all coordinated by a SimPy-driven simulation engine.

Sub-packages
------------
core            simulation engine, event bus, main loop orchestration
customers       stochastic demand modelling and arrival generation
orders          menu, order objects, queue management
kitchen         cooking stations (grill/fryer/drink) and assembly line
ingredients     inventory, spoilage and supply-chain restocking
automation      robot workers, conveyors, task scheduling
logistics       drive-thru, delivery dispatch, packaging
quality_control inspection, temperature checks, defect detection & rework
ai              queue optimisation, staffing AI, cooking scheduling AI
economics       cost and revenue modelling / profitability
simulation      top level restaurant simulation + stress test scenarios
ui              SCADA-style console dashboard and kitchen floor view
utils           configuration and structured logging/metrics
"""

__version__ = "1.0.0"
