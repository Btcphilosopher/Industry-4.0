"""Drive-thru, delivery dispatch, and final packaging."""
