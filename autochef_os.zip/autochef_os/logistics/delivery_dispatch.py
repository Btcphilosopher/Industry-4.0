"""
Delivery dispatch: assigns packaged delivery orders to a bounded courier
pool and simulates the round trip. A courier will wait briefly to try to
batch a second nearby order before setting off, trading a little latency
for materially better delivery throughput per courier-hour -- a standard
last-mile batching strategy.
"""

from __future__ import annotations

from typing import List

import numpy as np
import simpy

from autochef_os.core.engine import SimulationEngine
from autochef_os.core.event_system import Topics
from autochef_os.orders.order_system import Order
from autochef_os.utils.logging import get_logger

logger = get_logger("logistics.delivery_dispatch")

BATCH_WAIT_S = 45.0
MAX_BATCH_SIZE = 3


class DeliveryDispatch:
    def __init__(self, engine: SimulationEngine, n_couriers: int, trip_time_s: float, trip_time_cv: float):
        self.engine = engine
        self.trip_time_s = trip_time_s
        self.trip_time_cv = trip_time_cv
        self.resource = simpy.Resource(engine.env, capacity=max(1, n_couriers))
        self._pending: List[Order] = []
        self._ready_event = engine.env.event()
        self._completion_events: dict = {}
        self.trips_completed = 0
        self.orders_delivered = 0
        engine.spawn(self._dispatch_loop())

    def submit(self, order: Order) -> None:
        self._pending.append(order)
        self._completion_events[order.id] = self.engine.env.event()
        if not self._ready_event.triggered:
            self._ready_event.succeed()

    def deliver(self, order: Order):
        """SimPy generator: submits the order for delivery and waits for the courier trip to finish."""
        self.submit(order)
        yield self._completion_events[order.id]
        del self._completion_events[order.id]

    def utilization(self) -> float:
        return len(self.resource.users) / self.resource.capacity

    def _dispatch_loop(self):
        while True:
            if not self._pending:
                self._ready_event = self.engine.env.event()
                yield self._ready_event
                continue
            batch = self._pending[:MAX_BATCH_SIZE]
            if len(batch) < MAX_BATCH_SIZE:
                # brief courtesy wait to see if another order lands, to batch trips
                self._ready_event = self.engine.env.event()
                yield self.engine.timeout(BATCH_WAIT_S) | self._ready_event
                batch = self._pending[:MAX_BATCH_SIZE]
            del self._pending[: len(batch)]
            self.engine.spawn(self._run_trip(batch))

    def _run_trip(self, batch: List[Order]):
        # the courier resource is held for the *entire* trip duration, so
        # capacity genuinely bounds how many trips run concurrently
        with self.resource.request() as req:
            yield req
            rng: np.random.Generator = self.engine.rng
            duration = max(120.0, rng.normal(self.trip_time_s, self.trip_time_s * self.trip_time_cv))
            # batching more than one order stretches the trip a little but is
            # still far more efficient per-order than a dedicated single trip
            duration *= 1.0 + 0.25 * (len(batch) - 1)
            yield self.engine.timeout(duration)
        self.trips_completed += 1
        self.orders_delivered += len(batch)
        for order in batch:
            self.engine.bus.publish(Topics.ORDER_DISPATCHED, order=order, channel="delivery")
            ev = self._completion_events.get(order.id)
            if ev is not None and not ev.triggered:
                ev.succeed()
