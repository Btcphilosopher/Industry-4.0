"""
Drive-thru pickup window.

Order taking is already handled upstream by the generic order/queue
system; :class:`DriveThru` models the physical bottleneck that is unique
to this channel -- a bounded number of car slots at the pickup window
that a packaged order must pass through before being handed over.
"""

from __future__ import annotations

from autochef_os.core.engine import SimulationEngine
from autochef_os.kitchen.station_base import StationBase
from autochef_os.utils.config import StationConfig


class DriveThru(StationBase):
    kind = "drive_thru_window"

    def __init__(self, engine: SimulationEngine):
        cfg = engine.config
        station_cfg = StationConfig(
            name="drive_thru_window",
            count=cfg.drive_thru_window_capacity,
            base_service_time_s=18.0,
            service_time_cv=0.3,
            queue_capacity=cfg.drive_thru_window_capacity * 3,
            failure_rate_per_hour=0.05,
            mean_repair_time_s=90.0,
        )
        super().__init__(engine, station_cfg)
        self.lanes = cfg.drive_thru_lanes
