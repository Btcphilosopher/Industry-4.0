"""Packaging: the last capacity-limited resource before an order can leave the building."""

from __future__ import annotations

from autochef_os.core.engine import SimulationEngine
from autochef_os.kitchen.station_base import StationBase
from autochef_os.utils.config import StationConfig


class PackagingStation(StationBase):
    kind = "packaging"

    def __init__(self, engine: SimulationEngine):
        cfg = engine.config
        station_cfg = StationConfig(
            name="packaging",
            count=cfg.packaging_capacity,
            base_service_time_s=cfg.packaging_time_s,
            service_time_cv=0.2,
            queue_capacity=max(8, cfg.packaging_capacity * 4),
            failure_rate_per_hour=0.05,
            mean_repair_time_s=60.0,
        )
        super().__init__(engine, station_cfg)
