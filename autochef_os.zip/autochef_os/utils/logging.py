"""
Structured logging and metrics collection.

AUTOCHEF OS treats telemetry as a first class citizen: every subsystem
pushes discrete events and periodic samples into a single
:class:`MetricsRecorder`, which is the backing store for the dashboard,
the stress-test comparison reports and CSV export.
"""

from __future__ import annotations

import logging
import sys
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import pandas as pd

_LOG_FORMAT = "%(asctime)s | %(levelname)-7s | %(name)-22s | %(message)s"
_configured = False


def get_logger(name: str, level: int = logging.INFO) -> logging.Logger:
    """Return a module-scoped logger, configuring the root handler once."""
    global _configured
    if not _configured:
        logging.basicConfig(
            level=level,
            format=_LOG_FORMAT,
            datefmt="%H:%M:%S",
            stream=sys.stdout,
        )
        _configured = True
    logger = logging.getLogger(f"autochef.{name}")
    logger.setLevel(level)
    return logger


@dataclass
class MetricsRecorder:
    """
    Central telemetry sink for a single simulation run.

    ``events``  -- discrete, timestamped occurrences (order completed,
                   station broke down, stockout, defect detected, ...)
    ``samples`` -- periodic scalar time-series samples (queue length,
                   utilisation %, revenue/hr, ...) recorded by the monitor
                   process on a fixed cadence.
    """

    events: List[Dict[str, Any]] = field(default_factory=list)
    samples: List[Dict[str, Any]] = field(default_factory=list)
    counters: Dict[str, float] = field(default_factory=dict)

    # -- discrete events ---------------------------------------------------
    def log_event(self, sim_time: float, category: str, **fields: Any) -> None:
        record = {"t": sim_time, "category": category}
        record.update(fields)
        self.events.append(record)

    # -- periodic samples ----------------------------------------------------
    def log_sample(self, sim_time: float, **fields: Any) -> None:
        record = {"t": sim_time}
        record.update(fields)
        self.samples.append(record)

    # -- monotonic counters -------------------------------------------------
    def incr(self, name: str, amount: float = 1.0) -> None:
        self.counters[name] = self.counters.get(name, 0.0) + amount

    def get(self, name: str, default: float = 0.0) -> float:
        return self.counters.get(name, default)

    # -- export ---------------------------------------------------------
    def events_df(self) -> pd.DataFrame:
        return pd.DataFrame(self.events)

    def samples_df(self) -> pd.DataFrame:
        return pd.DataFrame(self.samples)

    def events_of(self, category: str) -> pd.DataFrame:
        df = self.events_df()
        if df.empty or "category" not in df:
            return df
        return df[df["category"] == category]

    def export_csv(self, prefix: str) -> None:
        self.events_df().to_csv(f"{prefix}_events.csv", index=False)
        self.samples_df().to_csv(f"{prefix}_samples.csv", index=False)

    def summary(self) -> Dict[str, float]:
        return dict(self.counters)
