"""Configuration and structured logging/metrics utilities."""
