"""
Central configuration for AUTOCHEF OS.

Every tunable knob in the simulation is exposed here as a dataclass field
with an industrially-plausible default. Nothing in the rest of the codebase
should hard-code a magic number that a plant engineer would reasonably want
to tune -- it belongs in :class:`SimulationConfig` instead.
"""

from __future__ import annotations

import copy
import json
import random
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, Optional

import numpy as np


@dataclass
class StationConfig:
    """Configuration for a single class of kitchen station."""

    name: str
    count: int = 2
    base_service_time_s: float = 45.0
    service_time_cv: float = 0.25  # coefficient of variation (lognormal)
    queue_capacity: int = 8
    failure_rate_per_hour: float = 0.4
    mean_repair_time_s: float = 180.0
    robot_assist_speedup: float = 0.7  # multiplier on service time when robot-assisted


@dataclass
class SimulationConfig:
    """Top level configuration object for a single AUTOCHEF OS run."""

    # --- run control -----------------------------------------------------
    sim_duration_s: float = 4 * 3600.0          # 4 simulated hours
    random_seed: Optional[int] = 42
    warm_up_s: float = 300.0                    # excluded from KPI aggregation
    ai_tick_interval_s: float = 30.0
    monitor_interval_s: float = 60.0
    dashboard_refresh_s: float = 120.0

    # --- demand ------------------------------------------------------------
    base_arrival_rate_per_min: float = 0.5
    lunch_peak_center_h: float = 12.25
    dinner_peak_center_h: float = 18.5
    peak_width_h: float = 0.9
    lunch_peak_multiplier: float = 2.6
    dinner_peak_multiplier: float = 2.2
    channel_weights: Dict[str, float] = field(
        default_factory=lambda: {"dine_in": 0.30, "drive_thru": 0.50, "delivery": 0.20}
    )
    complexity_weights: Dict[str, float] = field(
        default_factory=lambda: {"simple": 0.45, "regular": 0.40, "complex": 0.15}
    )

    # --- kitchen stations ----------------------------------------------------
    grill: StationConfig = field(
        default_factory=lambda: StationConfig("grill", count=2, base_service_time_s=70, queue_capacity=6)
    )
    fryer: StationConfig = field(
        default_factory=lambda: StationConfig("fryer", count=3, base_service_time_s=150, queue_capacity=10)
    )
    drink: StationConfig = field(
        default_factory=lambda: StationConfig("drink", count=1, base_service_time_s=20, queue_capacity=10)
    )
    assembly: StationConfig = field(
        default_factory=lambda: StationConfig("assembly", count=2, base_service_time_s=35, queue_capacity=10)
    )

    # --- automation -----------------------------------------------------
    n_robot_workers: int = 3
    robot_reliability: float = 0.985
    conveyor_transit_time_s: float = 12.0
    conveyor_capacity: int = 24

    # --- inventory / supply chain -----------------------------------------
    reorder_point_fraction: float = 0.30
    reorder_up_to_fraction: float = 1.0
    par_level_multiplier: float = 1.0
    supplier_lead_time_s: float = 900.0
    supplier_lead_time_cv: float = 0.3
    spoilage_check_interval_s: float = 120.0
    shortage_stockout_probability_penalty: float = 0.6

    # --- logistics -----------------------------------------------------
    drive_thru_lanes: int = 1
    drive_thru_window_capacity: int = 4
    n_delivery_couriers: int = 3
    courier_trip_time_s: float = 900.0
    courier_trip_time_cv: float = 0.4
    packaging_capacity: int = 3
    packaging_time_s: float = 15.0

    # --- quality control -----------------------------------------------------
    base_defect_probability: float = 0.04
    temperature_fail_threshold_c: float = 55.0
    rework_time_s: float = 40.0
    max_rework_attempts: int = 2

    # --- AI optimisation --------------------------------------------------
    staffing_ai_enabled: bool = True
    queue_optimizer_enabled: bool = True
    cooking_scheduler_enabled: bool = True
    staffing_utilization_high: float = 0.85
    staffing_utilization_low: float = 0.35

    # --- economics -----------------------------------------------------
    labor_cost_per_worker_hour: float = 16.5
    robot_cost_per_hour: float = 9.0
    energy_cost_per_station_hour: float = 1.8
    waste_cost_multiplier: float = 1.0

    def rng(self) -> np.random.Generator:
        return np.random.default_rng(self.random_seed)

    def seed_everything(self) -> None:
        if self.random_seed is not None:
            random.seed(self.random_seed)
            np.random.seed(self.random_seed)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)

    def clone(self) -> "SimulationConfig":
        return copy.deepcopy(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SimulationConfig":
        data = dict(data)
        for key in ("grill", "fryer", "drink", "assembly"):
            if key in data and isinstance(data[key], dict):
                data[key] = StationConfig(**data[key])
        return cls(**data)

    @classmethod
    def from_json(cls, text: str) -> "SimulationConfig":
        return cls.from_dict(json.loads(text))


DEFAULT_CONFIG = SimulationConfig()
