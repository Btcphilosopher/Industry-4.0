"""
Cost model: labour/robot staffing cost, station energy draw, and waste
cost from spoilage and rejected orders. Accumulated continuously so the
economics layer can report true cost-per-order and labour-vs-automation
ROI rather than a static per-order estimate.
"""

from __future__ import annotations

from typing import Dict, Optional

from autochef_os.automation.robot_workers import RobotWorkerPool
from autochef_os.core.engine import SimulationEngine
from autochef_os.core.event_system import Topics
from autochef_os.kitchen.station_base import StationBase

DEFAULT_INGREDIENT_UNIT_COST = 0.40


class CostModel:
    def __init__(
        self,
        engine: SimulationEngine,
        stations: Dict[str, StationBase],
        robots: Optional[RobotWorkerPool] = None,
    ):
        self.engine = engine
        self.stations = stations
        self.robots = robots
        self.cumulative_labor_cost = 0.0
        self.cumulative_energy_cost = 0.0
        self.cumulative_waste_cost = 0.0
        self._last_tick_t = 0.0
        engine.bus.subscribe(Topics.INGREDIENT_SPOILED, self._on_spoiled)
        engine.bus.subscribe(Topics.ORDER_REJECTED, self._on_rejected)

    def _on_spoiled(self, ingredient: str, quantity: float, t: float) -> None:
        cost = quantity * DEFAULT_INGREDIENT_UNIT_COST * self.engine.config.waste_cost_multiplier
        self.cumulative_waste_cost += cost
        self.engine.metrics.incr("waste_cost", cost)

    def _on_rejected(self, order, defect: str, **_kwargs) -> None:
        cost = order.total_food_cost * self.engine.config.waste_cost_multiplier
        self.cumulative_waste_cost += cost
        self.engine.metrics.incr("waste_cost", cost)

    def tick(self, engine: SimulationEngine) -> None:
        dt_hours = max(0.0, (engine.now - self._last_tick_t) / 3600.0)
        self._last_tick_t = engine.now
        if dt_hours <= 0:
            return

        labor_units = sum(st.resource.capacity for st in self.stations.values())
        labor_cost = labor_units * engine.config.labor_cost_per_worker_hour * dt_hours
        robot_cost = (self.robots.n_robots if self.robots else 0) * engine.config.robot_cost_per_hour * dt_hours
        energy_cost = sum(
            st.resource.capacity * engine.config.energy_cost_per_station_hour * dt_hours
            for st in self.stations.values()
        )

        self.cumulative_labor_cost += labor_cost + robot_cost
        self.cumulative_energy_cost += energy_cost
        engine.metrics.incr("labor_cost", labor_cost + robot_cost)
        engine.metrics.incr("energy_cost", energy_cost)

    def total_cost(self) -> float:
        return self.cumulative_labor_cost + self.cumulative_energy_cost + self.cumulative_waste_cost

    def cost_breakdown(self) -> Dict[str, float]:
        return {
            "labor_and_robot_cost": self.cumulative_labor_cost,
            "energy_cost": self.cumulative_energy_cost,
            "waste_cost": self.cumulative_waste_cost,
            "total_cost": self.total_cost(),
        }
