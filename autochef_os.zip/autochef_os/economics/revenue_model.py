"""Revenue model: tracks realised revenue and gross profit from completed orders."""

from __future__ import annotations

from typing import Dict

from autochef_os.core.engine import SimulationEngine
from autochef_os.core.event_system import Topics
from autochef_os.economics.cost_model import CostModel
from autochef_os.orders.order_system import Order


class RevenueModel:
    def __init__(self, engine: SimulationEngine):
        self.engine = engine
        self.cumulative_revenue = 0.0
        self.cumulative_food_cost = 0.0
        self.orders_completed = 0
        engine.bus.subscribe(Topics.ORDER_COMPLETED, self._on_completed)

    def _on_completed(self, order: Order, **_kwargs) -> None:
        self.cumulative_revenue += order.total_price
        self.cumulative_food_cost += order.total_food_cost
        self.orders_completed += 1
        self.engine.metrics.incr("revenue", order.total_price)
        self.engine.metrics.incr("food_cost_realised", order.total_food_cost)

    def revenue_per_hour(self) -> float:
        hours = max(1e-9, self.engine.now / 3600.0)
        return self.cumulative_revenue / hours

    def average_order_value(self) -> float:
        return self.cumulative_revenue / self.orders_completed if self.orders_completed else 0.0

    def gross_profit(self, cost_model: CostModel) -> float:
        return self.cumulative_revenue - self.cumulative_food_cost - cost_model.total_cost()

    def profit_per_hour(self, cost_model: CostModel) -> float:
        hours = max(1e-9, self.engine.now / 3600.0)
        return self.gross_profit(cost_model) / hours

    def summary(self, cost_model: CostModel) -> Dict[str, float]:
        return {
            "revenue": self.cumulative_revenue,
            "food_cost": self.cumulative_food_cost,
            "gross_profit": self.gross_profit(cost_model),
            "revenue_per_hour": self.revenue_per_hour(),
            "profit_per_hour": self.profit_per_hour(cost_model),
            "average_order_value": self.average_order_value(),
        }
