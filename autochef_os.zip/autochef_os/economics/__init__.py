"""Cost and revenue modelling: profitability under varying load and automation mix."""
