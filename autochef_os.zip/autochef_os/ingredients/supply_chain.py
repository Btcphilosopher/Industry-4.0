"""
Supply chain: reorder-point restocking with stochastic lead times.

Each ingredient is monitored independently. When on-hand stock (minus
what's already on order) drops below ``reorder_point_fraction`` of par,
a purchase order is placed for enough to bring stock back up to
``reorder_up_to_fraction`` of par. Delivery arrives after a stochastic
lead time; a small probability of supplier disruption stretches that lead
time further, letting the simulation exercise genuine stockout cascades.
"""

from __future__ import annotations

from autochef_os.core.engine import SimulationEngine
from autochef_os.ingredients.inventory_system import InventorySystem, all_ingredient_names
from autochef_os.utils.logging import get_logger

logger = get_logger("ingredients.supply_chain")

DISRUPTION_PROBABILITY = 0.06
DISRUPTION_EXTRA_LEAD_MULTIPLIER = 2.5


class SupplyChain:
    def __init__(self, engine: SimulationEngine, inventory: InventorySystem, check_interval_s: float = 90.0):
        self.engine = engine
        self.inventory = inventory
        self.check_interval_s = check_interval_s
        self.deliveries_in_flight = 0
        self.total_deliveries = 0
        self.total_disruptions = 0
        for ingredient in all_ingredient_names():
            self.engine.spawn(self._monitor_ingredient(ingredient))

    def _monitor_ingredient(self, ingredient: str):
        cfg = self.engine.config
        rng = self.engine.rng
        while True:
            yield self.engine.timeout(self.check_interval_s)
            par = self.inventory.par_level(ingredient)
            on_hand = self.inventory.stock.get(ingredient, 0.0)
            on_order = self.inventory.on_order.get(ingredient, 0.0)
            effective = on_hand + on_order
            if effective < cfg.reorder_point_fraction * par:
                target = cfg.reorder_up_to_fraction * par
                order_qty = max(0.0, target - effective)
                if order_qty <= 1e-6:
                    continue
                self.inventory.on_order[ingredient] = on_order + order_qty
                self.engine.spawn(self._deliver(ingredient, order_qty))

    def _deliver(self, ingredient: str, quantity: float):
        cfg = self.engine.config
        rng = self.engine.rng
        self.deliveries_in_flight += 1

        lead_time = max(60.0, rng.normal(cfg.supplier_lead_time_s, cfg.supplier_lead_time_s * cfg.supplier_lead_time_cv))
        if rng.random() < DISRUPTION_PROBABILITY:
            lead_time *= DISRUPTION_EXTRA_LEAD_MULTIPLIER
            self.total_disruptions += 1
            self.engine.metrics.incr("supplier_disruptions")
            logger.debug(
                "t=%.0f supplier disruption on %s, lead time now %.0fs",
                self.engine.now, ingredient, lead_time,
            )

        yield self.engine.timeout(lead_time)

        self.inventory.on_order[ingredient] = max(0.0, self.inventory.on_order.get(ingredient, 0.0) - quantity)
        self.inventory.restock(ingredient, quantity)
        self.deliveries_in_flight -= 1
        self.total_deliveries += 1
        self.engine.metrics.incr("supply_deliveries")
        self.engine.metrics.incr("units_delivered", quantity)
