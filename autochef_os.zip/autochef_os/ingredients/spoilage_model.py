"""
Freshness decay / spoilage.

Stock is tracked as FIFO batches per ingredient (arrival time + quantity).
A periodic housekeeping process discards any batch that has aged past its
shelf life, removing that quantity from the live inventory and recording
the loss as waste for the economics layer. Consumption draws down the
oldest batches first, exactly like a real walk-in fridge should be
rotated (FIFO / "first expired, first out").
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Deque, Dict, Tuple

from autochef_os.core.engine import SimulationEngine
from autochef_os.core.event_system import Topics
from autochef_os.ingredients.inventory_system import SHELF_LIFE_S, InventorySystem
from autochef_os.utils.logging import get_logger

logger = get_logger("ingredients.spoilage")


@dataclass
class Batch:
    quantity: float
    arrived_at: float


class SpoilageModel:
    def __init__(self, engine: SimulationEngine, inventory: InventorySystem):
        self.engine = engine
        self.inventory = inventory
        self.batches: Dict[str, Deque[Batch]] = {
            name: deque([Batch(qty, 0.0)]) for name, qty in inventory.stock.items()
        }
        inventory.on_consume = self._on_consume
        self.engine.bus.subscribe(Topics.INVENTORY_RESTOCKED, self._on_restock)
        self.engine.spawn(self._decay_loop())

    # -- FIFO batch bookkeeping ----------------------------------------------
    def _on_restock(self, ingredient: str, quantity: float, t: float) -> None:
        self.batches.setdefault(ingredient, deque()).append(Batch(quantity, t))

    def _on_consume(self, ingredient: str, quantity: float) -> None:
        remaining = quantity
        q = self.batches.setdefault(ingredient, deque())
        while remaining > 1e-9 and q:
            batch = q[0]
            take = min(batch.quantity, remaining)
            batch.quantity -= take
            remaining -= take
            if batch.quantity <= 1e-9:
                q.popleft()
        # if consumption outran tracked batches (shouldn't normally happen),
        # nothing further to do -- inventory scalar is still authoritative

    def shelf_life(self, ingredient: str) -> float:
        return SHELF_LIFE_S.get(ingredient, 48 * 3600.0)

    # -- periodic decay check ------------------------------------------------
    def _decay_loop(self):
        cfg = self.engine.config
        while True:
            yield self.engine.timeout(cfg.spoilage_check_interval_s)
            now = self.engine.now
            for ingredient, q in self.batches.items():
                life = self.shelf_life(ingredient)
                spoiled_qty = 0.0
                while q and (now - q[0].arrived_at) > life:
                    batch = q.popleft()
                    spoiled_qty += batch.quantity
                if spoiled_qty > 1e-9:
                    self.inventory.discard(ingredient, spoiled_qty)
                    self.engine.metrics.incr("units_spoiled", spoiled_qty)
                    self.engine.bus.publish(
                        Topics.INGREDIENT_SPOILED, ingredient=ingredient, quantity=spoiled_qty, t=now
                    )
                    logger.debug(
                        "t=%.0f spoiled %.1f units of %s", now, spoiled_qty, ingredient
                    )

    def average_freshness(self, ingredient: str) -> float:
        """0..1 score: 1.0 = all stock freshly delivered, 0.0 = at end of shelf life."""
        q = self.batches.get(ingredient)
        if not q:
            return 1.0
        life = self.shelf_life(ingredient)
        now = self.engine.now
        total_qty = sum(b.quantity for b in q) or 1.0
        weighted_age = sum(b.quantity * (now - b.arrived_at) for b in q) / total_qty
        return max(0.0, 1.0 - weighted_age / life)
