"""
Ingredient inventory: the supply-chain half of the production system.

Every menu item declares the ingredients (and quantities) it consumes;
:class:`InventorySystem` is the single source of truth for on-hand stock.
Consumption is atomic and all-or-nothing per line item -- if any
ingredient required is short, the whole item fails to be claimed and the
caller (the cooking scheduler) must treat it as a shortage rather than
partially cooking a burger with no bun.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

from autochef_os.core.engine import SimulationEngine
from autochef_os.core.event_system import Topics
from autochef_os.orders.menu_engine import MENU
from autochef_os.utils.logging import get_logger

logger = get_logger("ingredients.inventory")

# par (max shelf) stock levels, plausible for a single high-volume store
PAR_LEVELS: Dict[str, float] = {
    "beef_patty": 400, "bun": 500, "lettuce": 150, "tomato": 150, "cheese": 400,
    "sauce": 200, "bacon": 150, "chicken_nugget": 1200, "chicken_fillet": 300,
    "potato": 500, "syrup": 100, "cup": 600, "ice": 600, "dairy_mix": 150,
    "pie_shell": 120,
}

# shelf-life in seconds, used by the spoilage model -- perishables decay fast
SHELF_LIFE_S: Dict[str, float] = {
    "lettuce": 6 * 3600, "tomato": 8 * 3600, "cheese": 24 * 3600, "bacon": 18 * 3600,
    "beef_patty": 30 * 3600, "chicken_fillet": 30 * 3600, "chicken_nugget": 36 * 3600,
    "dairy_mix": 20 * 3600, "pie_shell": 48 * 3600, "potato": 60 * 3600,
    "bun": 24 * 3600, "sauce": 120 * 3600, "syrup": 400 * 3600, "cup": 1e9, "ice": 6 * 3600,
}


def all_ingredient_names() -> List[str]:
    names = set()
    for item in MENU:
        names.update(item.ingredients.keys())
    return sorted(names)


@dataclass
class InventorySystem:
    engine: SimulationEngine
    stock: Dict[str, float] = field(default_factory=dict)
    on_order: Dict[str, float] = field(default_factory=dict)
    shortages: Dict[str, int] = field(default_factory=dict)
    on_consume: Optional[Callable[[str, float], None]] = None

    def __post_init__(self) -> None:
        for name in all_ingredient_names():
            self.stock.setdefault(name, self.par_level(name))

    def par_level(self, ingredient: str) -> float:
        return PAR_LEVELS.get(ingredient, 200.0) * self.engine.config.par_level_multiplier

    def level_fraction(self, ingredient: str) -> float:
        par = self.par_level(ingredient)
        return self.stock.get(ingredient, 0.0) / par if par else 0.0

    def can_fulfill(self, requirements: Dict[str, float]) -> bool:
        return all(self.stock.get(ing, 0.0) >= qty for ing, qty in requirements.items())

    def consume(self, requirements: Dict[str, float]) -> bool:
        """All-or-nothing consumption. Returns False (and records a shortage) if short."""
        if not self.can_fulfill(requirements):
            for ing, qty in requirements.items():
                if self.stock.get(ing, 0.0) < qty:
                    self.shortages[ing] = self.shortages.get(ing, 0) + 1
                    self.engine.metrics.incr("ingredient_shortages")
                    self.engine.bus.publish(
                        Topics.INVENTORY_LOW, ingredient=ing, level=self.stock.get(ing, 0.0)
                    )
            return False
        for ing, qty in requirements.items():
            self.stock[ing] -= qty
            if self.stock[ing] <= 0:
                self.stock[ing] = 0.0
                self.engine.bus.publish(Topics.INVENTORY_STOCKOUT, ingredient=ing)
            if self.on_consume is not None:
                self.on_consume(ing, qty)
        return True

    def restock(self, ingredient: str, quantity: float) -> None:
        par = self.par_level(ingredient)
        self.stock[ingredient] = min(par, self.stock.get(ingredient, 0.0) + quantity)
        self.engine.bus.publish(
            Topics.INVENTORY_RESTOCKED, ingredient=ingredient, quantity=quantity, t=self.engine.now
        )

    def discard(self, ingredient: str, quantity: float) -> None:
        self.stock[ingredient] = max(0.0, self.stock.get(ingredient, 0.0) - quantity)

    def snapshot(self) -> Dict[str, float]:
        return dict(self.stock)
