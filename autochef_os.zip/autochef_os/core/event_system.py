"""
Lightweight publish/subscribe event bus.

SimPy already gives us a discrete-event scheduler; what it does not give
us is a decoupled way for, say, the quality-control subsystem to notify
the AI staffing layer that a defect just happened without the two modules
importing each other directly. :class:`EventBus` fills that gap and also
funnels every notable occurrence into the :class:`MetricsRecorder`.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Any, Callable, DefaultDict, List

Handler = Callable[..., None]


class EventBus:
    """Simple synchronous topic -> subscribers dispatcher."""

    def __init__(self) -> None:
        self._subscribers: DefaultDict[str, List[Handler]] = defaultdict(list)

    def subscribe(self, topic: str, handler: Handler) -> None:
        self._subscribers[topic].append(handler)

    def unsubscribe(self, topic: str, handler: Handler) -> None:
        if handler in self._subscribers.get(topic, []):
            self._subscribers[topic].remove(handler)

    def publish(self, topic: str, /, **payload: Any) -> None:
        for handler in list(self._subscribers.get(topic, ())):
            handler(**payload)
        for handler in list(self._subscribers.get("*", ())):
            handler(topic=topic, **payload)


# well-known topic names, centralised so subsystems don't need magic strings
class Topics:
    CUSTOMER_ARRIVED = "customer.arrived"
    ORDER_CREATED = "order.created"
    ORDER_QUEUED = "order.queued"
    ORDER_ROUTED = "order.routed"
    ORDER_STATION_START = "order.station_start"
    ORDER_STATION_DONE = "order.station_done"
    ORDER_ASSEMBLED = "order.assembled"
    ORDER_QC_PASSED = "order.qc_passed"
    ORDER_QC_FAILED = "order.qc_failed"
    ORDER_REWORKED = "order.reworked"
    ORDER_REJECTED = "order.rejected"
    ORDER_PACKAGED = "order.packaged"
    ORDER_DISPATCHED = "order.dispatched"
    ORDER_COMPLETED = "order.completed"
    ORDER_BALKED = "order.balked"

    STATION_BROKEN = "station.broken"
    STATION_REPAIRED = "station.repaired"
    STATION_UTILIZATION = "station.utilization"

    INVENTORY_LOW = "inventory.low"
    INVENTORY_STOCKOUT = "inventory.stockout"
    INVENTORY_RESTOCKED = "inventory.restocked"
    INGREDIENT_SPOILED = "inventory.spoiled"

    AI_STAFFING_ADJUSTED = "ai.staffing_adjusted"
    AI_QUEUE_REPRIORITIZED = "ai.queue_reprioritized"
    AI_ROUTING_DECISION = "ai.routing_decision"
