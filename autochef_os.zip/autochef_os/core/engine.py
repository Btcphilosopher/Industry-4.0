"""
SimulationEngine -- the single object every subsystem is built around.

It owns the SimPy environment (the clock + event scheduler), the RNG, the
event bus, and the metrics recorder, plus a small service-locator registry
so subsystems can find each other by name at wiring time without a tangle
of constructor arguments.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

import numpy as np
import simpy

from autochef_os.core.event_system import EventBus
from autochef_os.utils.config import SimulationConfig
from autochef_os.utils.logging import MetricsRecorder, get_logger

logger = get_logger("core.engine")


class SimulationEngine:
    """
    Composition root for a single simulation run.

    Usage::

        engine = SimulationEngine(config)
        engine.register("inventory", inventory_system)
        ...
        engine.run()
    """

    def __init__(self, config: SimulationConfig):
        config.seed_everything()
        self.config = config
        self.env = simpy.Environment()
        self.rng: np.random.Generator = config.rng()
        self.bus = EventBus()
        self.metrics = MetricsRecorder()
        self._registry: Dict[str, Any] = {}
        self._processes = []

    # -- service locator -----------------------------------------------------
    def register(self, name: str, obj: Any) -> Any:
        self._registry[name] = obj
        return obj

    def get(self, name: str) -> Any:
        return self._registry[name]

    def has(self, name: str) -> bool:
        return name in self._registry

    # -- process management -------------------------------------------------
    def spawn(self, generator) -> simpy.Process:
        """Register a SimPy process generator with the environment."""
        proc = self.env.process(generator)
        self._processes.append(proc)
        return proc

    # -- convenience ----------------------------------------------------
    @property
    def now(self) -> float:
        return self.env.now

    def now_hours(self) -> float:
        return self.env.now / 3600.0

    def timeout(self, delay: float):
        return self.env.timeout(max(0.0, delay))

    def run(self, until: Optional[float] = None) -> None:
        until = self.config.sim_duration_s if until is None else until
        logger.info(
            "Starting simulation run: duration=%.0fs seed=%s stations(g/f/d/a)=%d/%d/%d/%d",
            until,
            self.config.random_seed,
            self.config.grill.count,
            self.config.fryer.count,
            self.config.drink.count,
            self.config.assembly.count,
        )
        self.env.run(until=until)
        logger.info("Simulation run complete at t=%.1fs", self.env.now)
