"""Simulation engine, event bus, and top-level loop orchestration."""
