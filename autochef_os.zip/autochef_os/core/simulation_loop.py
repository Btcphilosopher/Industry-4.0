"""
The periodic "heartbeat" of the plant.

Individual production events (an order arriving, a grill finishing a
patty) are each their own SimPy process and fire asynchronously the
moment they are ready -- that is the whole point of discrete-event
simulation instead of a fixed timestep loop.

However the specification also calls for a conceptual fixed-cadence loop:

    generate_customer_demand()
    create_orders()
    route_orders_to_kitchen()
    process_kitchen_stations()
    run_automation_system()
    perform_quality_checks()
    update_inventory()
    dispatch_completed_orders()
    optimise_system_performance()
    log_metrics()

:class:`SimulationLoop` provides exactly that: a periodic monitor tick
(default every ``ai_tick_interval_s``) which polls every registered
subsystem for outstanding periodic work (AI re-optimisation, inventory
housekeeping, dashboard sampling) that doesn't need its own dedicated
SimPy process. Per-order production flow itself is still event-driven and
lives inside the kitchen/orders/logistics packages.
"""

from __future__ import annotations

from typing import Callable, List

from autochef_os.core.engine import SimulationEngine
from autochef_os.utils.logging import get_logger

logger = get_logger("core.simulation_loop")

TickFn = Callable[[SimulationEngine], None]


class SimulationLoop:
    """Drives all periodic (as opposed to event-triggered) subsystem work."""

    def __init__(self, engine: SimulationEngine):
        self.engine = engine
        self._ai_ticks: List[TickFn] = []
        self._monitor_ticks: List[TickFn] = []

    def on_ai_tick(self, fn: TickFn) -> None:
        """Register a callback invoked every ``ai_tick_interval_s``."""
        self._ai_ticks.append(fn)

    def on_monitor_tick(self, fn: TickFn) -> None:
        """Register a callback invoked every ``monitor_interval_s``."""
        self._monitor_ticks.append(fn)

    def start(self) -> None:
        self.engine.spawn(self._ai_loop())
        self.engine.spawn(self._monitor_loop())

    # -- internal SimPy processes -------------------------------------------
    def _ai_loop(self):
        cfg = self.engine.config
        # Optimisation logic mirrors:
        #   route_orders_to_kitchen() / run_automation_system() /
        #   optimise_system_performance()
        while True:
            yield self.engine.timeout(cfg.ai_tick_interval_s)
            for fn in self._ai_ticks:
                try:
                    fn(self.engine)
                except Exception:  # pragma: no cover - defensive, keep sim alive
                    logger.exception("AI tick handler raised")

    def _monitor_loop(self):
        cfg = self.engine.config
        # Mirrors: update_inventory() / log_metrics() / dashboard sampling
        while True:
            yield self.engine.timeout(cfg.monitor_interval_s)
            for fn in self._monitor_ticks:
                try:
                    fn(self.engine)
                except Exception:  # pragma: no cover
                    logger.exception("Monitor tick handler raised")
