"""
Kitchen floor visualisation.

Renders the current state of every station as a dense, text-mode
operational panel -- utilisation bar, active/queued job counts, and
breakdown status -- in the spirit of a SCADA HMI screen rather than a
consumer-facing UI. No colour, no icons, just the numbers an operator
needs.
"""

from __future__ import annotations

from typing import Dict

from autochef_os.kitchen.station_base import StationBase

BAR_WIDTH = 24


def _bar(fraction: float, width: int = BAR_WIDTH) -> str:
    fraction = max(0.0, min(1.0, fraction))
    filled = int(round(fraction * width))
    return "[" + "#" * filled + "-" * (width - filled) + f"] {fraction * 100:5.1f}%"


class KitchenFloorView:
    def __init__(self, stations: Dict[str, StationBase]):
        self.stations = stations

    def render(self) -> str:
        lines = ["STATION            UTIL                            ACTIVE/CAP  QUEUE  DOWN  FAILS"]
        lines.append("-" * len(lines[0]))
        for name, st in sorted(self.stations.items()):
            active = len(st.resource.users)
            cap = st.resource.capacity
            lines.append(
                f"{name.upper():<18} {_bar(st.utilization())}  {active:>3}/{cap:<6} {st.queue_len:>5}  "
                f"{st.units_down:>4}  {st.breakdowns:>5}"
            )
        return "\n".join(lines)

    def render_heatmap(self, history: Dict[str, list]) -> str:
        """
        ``history`` maps station name -> list of utilisation samples
        (0..1) over time buckets; renders a coarse ASCII heatmap using
        density characters, oldest sample first.
        """
        shades = " .:-=+*#%@"
        lines = ["UTILISATION HEATMAP (oldest -> newest)"]
        for name, samples in sorted(history.items()):
            row = "".join(shades[min(len(shades) - 1, int(s * (len(shades) - 1)))] for s in samples)
            lines.append(f"{name.upper():<12} |{row}|")
        return "\n".join(lines)
