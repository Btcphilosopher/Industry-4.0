"""SCADA-style console dashboard and kitchen floor visualisation."""
