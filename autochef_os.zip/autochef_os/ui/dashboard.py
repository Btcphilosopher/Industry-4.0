"""
SCADA-style operational dashboard.

Two output modes:

* :meth:`SCADADashboard.render_frame` -- a dense plain-text control-room
  snapshot (KPIs + kitchen floor view), suitable for printing to a
  terminal on a fixed cadence during a live run.
* :meth:`SCADADashboard.export_png` -- a static multi-panel Matplotlib
  figure summarising the whole run (throughput, queueing, utilisation,
  revenue/profit) for post-run analysis, saved to disk.
"""

from __future__ import annotations

import os
import sys
from typing import TYPE_CHECKING

from autochef_os.ui.kitchen_view import KitchenFloorView

if TYPE_CHECKING:
    from autochef_os.simulation.restaurant_sim import RestaurantSimulation

ANSI_CLEAR = "\x1b[2J\x1b[H"


class SCADADashboard:
    def __init__(self, sim: "RestaurantSimulation"):
        self.sim = sim
        self.kitchen_view = KitchenFloorView(sim.stations)

    def render_frame(self) -> str:
        engine = self.sim.engine
        rev_hr = self.sim.revenue_model.revenue_per_hour()
        profit_hr = self.sim.revenue_model.profit_per_hour(self.sim.cost_model)
        hour = self.sim.demand.hour_of_day(engine.now)

        lines = [
            "=" * 78,
            f" AUTOCHEF OS -- LIVE PLANT STATUS   t={engine.now:9.0f}s   clock={hour:5.2f}h",
            "=" * 78,
            f" Backlog queue depth : {self.sim.queue.depth():>6d}      "
            f" Station queues   : {sum(st.queue_len for st in self.sim.stations.values()):>6d}",
            f" Orders completed    : {len(self.sim.completed_orders):>6d}      "
            f" Orders reworked  : {int(engine.metrics.get('orders_reworked')):>6d}",
            f" Orders rejected     : {len(self.sim.rejected_orders):>6d}      "
            f" Orders balked    : {len(self.sim.balked_orders):>6d}",
            f" Revenue / hour      : ${rev_hr:>9,.2f}   "
            f" Profit / hour    : ${profit_hr:>9,.2f}",
            f" Robot utilisation   : {self.sim.robots.utilization() * 100:>6.1f}%     "
            f" Robots assisted  : {self.sim.robots.jobs_assisted:>6d}",
            "-" * 78,
            self.kitchen_view.render(),
            "-" * 78,
        ]
        return "\n".join(lines)

    def print_frame(self, clear: bool = True) -> None:
        if clear:
            sys.stdout.write(ANSI_CLEAR)
        print(self.render_frame())
        sys.stdout.flush()

    def attach_live(self, interval_s: float = None) -> None:
        """Registers a periodic monitor tick that prints the dashboard live."""
        interval_s = interval_s or self.sim.config.dashboard_refresh_s
        state = {"next": 0.0}

        def _tick(engine):
            if engine.now >= state["next"]:
                self.print_frame()
                state["next"] = engine.now + interval_s

        self.sim.loop.on_monitor_tick(_tick)

    # -- post-run static export --------------------------------------------
    def export_png(self, path: str) -> str:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        df = self.sim.engine.metrics.samples_df()
        fig, axes = plt.subplots(2, 2, figsize=(13, 9))
        fig.suptitle("AUTOCHEF OS -- Run Summary", fontsize=14, fontweight="bold")

        ax = axes[0, 0]
        if not df.empty:
            ax.plot(df["t"] / 60.0, df["queue_depth"], label="pre-kitchen backlog", color="tab:orange")
            ax.plot(df["t"] / 60.0, df["station_backlog"], label="station queues", color="tab:purple")
            ax.legend(fontsize=8)
        ax.set_title("Queueing depth")
        ax.set_xlabel("sim time (min)")
        ax.set_ylabel("orders / line items queued")

        ax = axes[0, 1]
        if not df.empty:
            ax.plot(df["t"] / 60.0, df["revenue_per_hour"], label="revenue/hr", color="tab:green")
            ax.plot(df["t"] / 60.0, df["profit_per_hour"], label="profit/hr", color="tab:blue")
            ax.legend()
        ax.set_title("Revenue & profit rate")
        ax.set_xlabel("sim time (min)")
        ax.set_ylabel("$ / hour")

        ax = axes[1, 0]
        util_cols = [c for c in df.columns if c.startswith("util_")]
        if not df.empty:
            for c in util_cols:
                ax.plot(df["t"] / 60.0, df[c] * 100, label=c.replace("util_", ""))
            ax.legend(fontsize=8)
        ax.set_title("Station utilisation over time")
        ax.set_xlabel("sim time (min)")
        ax.set_ylabel("utilisation %")
        ax.set_ylim(0, 105)

        ax = axes[1, 1]
        names = list(self.sim.stations.keys())
        finals = [self.sim.stations[n].utilization() * 100 for n in names]
        ax.bar(names, finals, color="tab:red")
        ax.set_title("Final station utilisation")
        ax.set_ylabel("utilisation %")
        ax.set_ylim(0, 105)

        fig.tight_layout(rect=[0, 0, 1, 0.96])
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        fig.savefig(path, dpi=130)
        plt.close(fig)
        return path
