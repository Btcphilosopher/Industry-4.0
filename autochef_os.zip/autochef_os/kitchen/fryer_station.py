"""Fryer station: fries, nuggets, crispy chicken, hand pies -- anything fried."""

from __future__ import annotations

from autochef_os.core.engine import SimulationEngine
from autochef_os.kitchen.station_base import StationBase


class FryerStation(StationBase):
    kind = "fryer"

    def __init__(self, engine: SimulationEngine):
        super().__init__(engine, engine.config.fryer)
