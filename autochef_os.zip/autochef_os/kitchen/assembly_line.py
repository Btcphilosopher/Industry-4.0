"""
Final assembly line: combines an order's finished line items (patties off
the grill, fries out of the fryer, drinks poured) into a single completed
order ready for quality control. Modelled as one more station -- capacity
limited, stochastic service time -- but consumed once per *order* rather
than once per line item.
"""

from __future__ import annotations

from autochef_os.core.engine import SimulationEngine
from autochef_os.kitchen.station_base import StationBase


class AssemblyLine(StationBase):
    kind = "assembly"

    def __init__(self, engine: SimulationEngine):
        super().__init__(engine, engine.config.assembly)
