"""Drink station: soft drink and milkshake dispensing."""

from __future__ import annotations

from autochef_os.core.engine import SimulationEngine
from autochef_os.kitchen.station_base import StationBase


class DrinkStation(StationBase):
    kind = "drink"

    def __init__(self, engine: SimulationEngine):
        super().__init__(engine, engine.config.drink)
