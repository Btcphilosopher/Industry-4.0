"""Parallel cooking stations and the final assembly line."""
