"""
Generic manufacturing-unit abstraction shared by every kitchen station.

Modelled deliberately like a real production cell:

* ``capacity`` parallel machines (a SimPy Resource)
* stochastic (lognormal) processing time around a configured mean
* bounded input queue -- a station that is "full" causes callers to balk
  or reroute rather than growing an unbounded queue
* an independent breakdown/repair process reducing effective throughput
* running counters for utilisation, throughput and failure statistics
"""

from __future__ import annotations

from typing import Optional

import numpy as np
import simpy

from autochef_os.core.engine import SimulationEngine
from autochef_os.core.event_system import Topics
from autochef_os.utils.config import StationConfig
from autochef_os.utils.logging import get_logger

logger = get_logger("kitchen.station")


class ResizableResource(simpy.Resource):
    """
    A :class:`simpy.Resource` whose capacity can be changed at runtime.

    Stock SimPy resources expose ``capacity`` as a read-only property.
    The staffing AI needs to grow/shrink a station's effective headcount
    live (extra crew called in, a robot reassigned elsewhere), so this
    subclass adds a real setter that also re-evaluates any requests
    already waiting in the queue -- growing capacity should immediately
    let queued jobs start, not just affect future requests.
    """

    @property
    def capacity(self) -> int:
        return self._capacity

    @capacity.setter
    def capacity(self, value: int) -> None:
        self._capacity = value
        self._trigger_put(None)


class StationBase:
    """Base class for grill / fryer / drink / assembly stations."""

    kind = "generic"

    def __init__(self, engine: SimulationEngine, config: StationConfig):
        self.engine = engine
        self.config = config
        self.resource = ResizableResource(engine.env, capacity=config.count)
        self.rng: np.random.Generator = engine.rng
        self.busy_seconds = 0.0
        self.jobs_completed = 0
        self.jobs_rejected = 0
        self.breakdowns = 0
        self.units_down = 0
        self._service_time_multiplier = 1.0  # AI/robot assist can adjust this live

        # capacity-time integral (sum of capacity * dt) -- lets utilisation be
        # computed correctly even though capacity changes live at arbitrary
        # times under the staffing AI; a naive busy_seconds / (elapsed *
        # current_capacity) would be badly distorted by any past resize.
        self._cap_integral = 0.0
        self._cap_integral_t = engine.now
        self._window_start_busy = 0.0
        self._window_start_cap_integral = 0.0

        self.engine.spawn(self._breakdown_process())

    # -- capacity / load introspection ---------------------------------------
    @property
    def queue_len(self) -> int:
        return len(self.resource.queue)

    @property
    def in_service(self) -> int:
        return len(self.resource.users)

    def is_full(self) -> bool:
        return self.queue_len >= self.config.queue_capacity

    def load_score(self) -> float:
        """Lower is better: used by the cooking scheduler AI to pick a station."""
        active = len(self.resource.users)
        return (active + self.queue_len) / max(1, self.resource.capacity)

    def _accrue_capacity_integral(self) -> None:
        now = self.engine.now
        dt = now - self._cap_integral_t
        if dt > 0:
            self._cap_integral += self.resource.capacity * dt
            self._cap_integral_t = now

    def set_capacity(self, new_capacity: int) -> None:
        """The only correct way to change a station's live capacity -- accrues
        the capacity-time integral under the *old* capacity first, then
        resizes (and wakes any queued requests via ``ResizableResource``)."""
        self._accrue_capacity_integral()
        self.resource.capacity = new_capacity

    def utilization(self) -> float:
        """Lifetime-average utilisation: busy time / integral(capacity dt).

        Correctly accounts for the station's capacity having changed one or
        more times over the run (see :meth:`set_capacity`), unlike a naive
        ``busy_seconds / (elapsed * current_capacity)`` which would be badly
        distorted by any past resize.
        """
        self._accrue_capacity_integral()
        return min(1.0, self.busy_seconds / max(1e-9, self._cap_integral))

    def recent_utilization(self) -> float:
        """
        Windowed utilisation since the last call, used by the staffing AI to
        make live scale-up/scale-down decisions. Stateful by design -- call
        it from exactly one periodic consumer (see ``ai/staffing_ai.py``).
        """
        self._accrue_capacity_integral()
        cap_time = self._cap_integral - self._window_start_cap_integral
        busy_delta = self.busy_seconds - self._window_start_busy
        util = min(1.0, busy_delta / max(1e-9, cap_time))
        self._window_start_busy = self.busy_seconds
        self._window_start_cap_integral = self._cap_integral
        return util

    def set_capacity_multiplier(self, multiplier: float) -> None:
        """Used by the staffing AI to speed up / slow down effective service time."""
        self._service_time_multiplier = max(0.4, multiplier)

    # -- stochastic service time ---------------------------------------
    def _sample_service_time(self, robot_assist: bool = False) -> float:
        mean = self.config.base_service_time_s * self._service_time_multiplier
        if robot_assist:
            mean *= self.config.robot_assist_speedup
        cv = max(0.01, self.config.service_time_cv)
        sigma = np.sqrt(np.log(1 + cv ** 2))
        mu = np.log(mean) - 0.5 * sigma ** 2
        return float(np.clip(self.rng.lognormal(mu, sigma), mean * 0.25, mean * 4))

    # -- breakdown / repair ---------------------------------------------------
    def _breakdown_process(self):
        cfg = self.config
        while True:
            if cfg.failure_rate_per_hour <= 0:
                return
            mtbf_s = 3600.0 / cfg.failure_rate_per_hour
            yield self.engine.timeout(self.rng.exponential(mtbf_s))
            with self.resource.request() as req:
                yield req
                self.breakdowns += 1
                self.units_down += 1
                repair_time = self.rng.exponential(cfg.mean_repair_time_s)
                self.engine.bus.publish(
                    Topics.STATION_BROKEN, station=cfg.name, t=self.engine.now, repair_time=repair_time
                )
                logger.debug(
                    "t=%.0f %s station unit down for %.0fs", self.engine.now, cfg.name, repair_time
                )
                yield self.engine.timeout(repair_time)
                self.units_down -= 1
                self.engine.bus.publish(Topics.STATION_REPAIRED, station=cfg.name, t=self.engine.now)

    # -- main processing entry point -----------------------------------------
    def process_job(self, robot_assist: bool = False):
        """
        SimPy generator: waits for a free machine (unless the queue is
        already at capacity, in which case the caller should check
        ``is_full()`` *before* calling this), processes for a stochastic
        service time, and returns the realised duration.
        """
        start_wait = self.engine.now
        with self.resource.request() as req:
            yield req
            wait = self.engine.now - start_wait
            duration = self._sample_service_time(robot_assist=robot_assist)
            self.engine.bus.publish(
                Topics.ORDER_STATION_START, station=self.config.name, t=self.engine.now
            )
            yield self.engine.timeout(duration)
            self.busy_seconds += duration
            self.jobs_completed += 1
            self.engine.bus.publish(
                Topics.ORDER_STATION_DONE,
                station=self.config.name,
                t=self.engine.now,
                duration=duration,
                wait=wait,
            )
            return duration
