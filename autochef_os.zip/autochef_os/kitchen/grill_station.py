"""Grill station: cooks burger patties. A thin, named specialisation of StationBase."""

from __future__ import annotations

from autochef_os.core.engine import SimulationEngine
from autochef_os.kitchen.station_base import StationBase


class GrillStation(StationBase):
    kind = "grill"

    def __init__(self, engine: SimulationEngine):
        super().__init__(engine, engine.config.grill)
