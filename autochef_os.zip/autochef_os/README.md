# AUTOCHEF OS

**Industry 4.0 fast-food automation & restaurant digital twin simulator.**

AUTOCHEF OS is not a restaurant management game. It is a discrete-event
manufacturing + logistics + automation-optimisation simulator disguised as
a quick-service kitchen: stochastic customer demand drives a production
line of parallel cooking stations, robotic assist, conveyor logistics,
quality control, ingredient supply chain, an AI optimisation layer, and an
economic model, all coordinated by a [SimPy](https://simpy.readthedocs.io/)
event-driven engine.

```
Customer Demand -> Order Generation -> Queue System -> Kitchen Routing
  -> Parallel Cooking Stations -> Assembly Line -> Quality Control
  -> Packaging -> Delivery / Drive-Thru / Dine-In Service Output
```

## Install

```bash
pip install -r requirements.txt
```

Requires Python 3.11+.

## Run

From the repository root:

```bash
# a single 4-hour shift, printed KPI report at the end
python -m autochef_os.main run

# a 6-hour shift with a live SCADA console dashboard + PNG summary
python -m autochef_os.main run --duration-hours 6 --live --png out/run.png

# built-in stress-test suite (rush spike, equipment cascade, supply shock,
# high-complexity mix, no-automation baseline) compared side by side
python -m autochef_os.main stress
```

## Run the tests

```bash
python -m unittest discover -s autochef_os/tests -v
```

## Architecture

| Package             | Responsibility                                                        |
|---------------------|-------------------------------------------------------------------------|
| `core/`              | SimPy-backed engine, event bus, periodic AI/monitor loop               |
| `customers/`         | Non-homogeneous Poisson demand model + arrival generator               |
| `orders/`            | Menu, order/line-item objects, priority queue backlog                  |
| `kitchen/`           | Grill / fryer / drink stations, assembly line (all `StationBase`)      |
| `ingredients/`       | Inventory, FIFO spoilage/freshness decay, reorder-point supply chain   |
| `automation/`        | Robot worker pool, conveyor belt, low-level task dispatcher            |
| `logistics/`         | Drive-thru window, courier delivery batching, packaging                |
| `quality_control/`   | Inspection, temperature-decay model, defect classification & rework    |
| `ai/`                | Queue urgency optimiser, staffing auto-scaler, cooking scheduler AI    |
| `economics/`         | Cost model (labour/robot/energy/waste) and revenue/profit model        |
| `simulation/`        | `RestaurantSimulation` composition root + stress-test scenario runner  |
| `ui/`                | SCADA-style text dashboard, kitchen floor view, Matplotlib PNG export  |
| `utils/`             | `SimulationConfig` (every tunable knob) and structured metrics logging |

Every subsystem publishes/consumes events through `core.event_system.EventBus`
and every notable occurrence lands in `utils.logging.MetricsRecorder`, which
backs both the live dashboard and the final KPI report:

* orders per minute (OPM)
* average wait time / total cycle time
* per-station kitchen utilisation %
* order accuracy % (completed vs. rejected)
* waste rate % (spoilage + rejected-order food cost vs. revenue)
* revenue / profit per hour
* an automation efficiency score blending utilisation, fulfilment rate and
  robot-assist rate

## Design notes

* **Nothing is fixed-timing.** Arrivals are a true non-homogeneous Poisson
  process (thinning method); every service time is drawn from a lognormal
  distribution around a configured mean; station breakdowns follow an
  exponential MTBF/MTTR process; supplier lead times are noisy and
  occasionally disrupted.
* **The AI layer changes system behaviour live**, not just cosmetics: the
  staffing AI grows/shrinks a station's effective SimPy `Resource` capacity
  within bounds, the cooking scheduler AI steers the shared robot pool
  toward whichever station is currently the bottleneck, and the queue
  optimiser AI re-weights channel urgency from an EWMA of observed wait
  times.
* **Backpressure is real.** Bounded queue backlogs balk customers, bounded
  station queues force the task scheduler to back off and retry, and a
  bounded conveyor and courier pool can each become the binding constraint
  -- so the simulation genuinely produces cascading, load-dependent delays
  instead of an idealised pipeline.
