"""
Non-homogeneous Poisson arrival process.

Uses the standard thinning algorithm: sample candidate inter-arrival
times from an Exp(lambda_max) process, then accept each candidate arrival
with probability lambda(t)/lambda_max. This produces a true NHPP for an
arbitrary (bounded) rate function without needing to invert its integral.
"""

from __future__ import annotations

from typing import List

import numpy as np

from autochef_os.core.engine import SimulationEngine
from autochef_os.core.event_system import Topics
from autochef_os.customers.demand_model import DemandModel
from autochef_os.orders.menu_engine import MenuEngine
from autochef_os.orders.order_system import Channel, LineItem, Order
from autochef_os.orders.queue_manager import QueueManager
from autochef_os.utils.logging import get_logger

logger = get_logger("customers.arrival_generator")


class ArrivalGenerator:
    def __init__(
        self,
        engine: SimulationEngine,
        demand_model: DemandModel,
        menu_engine: MenuEngine,
        queue_manager: QueueManager,
        lambda_max_multiplier: float = 1.6,
    ):
        self.engine = engine
        self.demand = demand_model
        self.menu = menu_engine
        self.queue = queue_manager
        self.lambda_max_multiplier = lambda_max_multiplier
        self.rng: np.random.Generator = engine.rng

    def _sample_channel(self, weights) -> Channel:
        names = list(weights.keys())
        probs = np.array([weights[n] for n in names])
        probs = probs / probs.sum()
        idx = self.rng.choice(len(names), p=probs)
        return Channel(names[idx])

    def _sample_complexity(self, weights) -> str:
        names = list(weights.keys())
        probs = np.array([weights[n] for n in names])
        probs = probs / probs.sum()
        idx = self.rng.choice(len(names), p=probs)
        return names[idx]

    def _build_order(self) -> Order:
        snap = self.demand.snapshot(self.engine.now)
        channel = self._sample_channel(snap.channel_weights)
        complexity = self._sample_complexity(snap.complexity_weights)
        basket = self.menu.generate_basket(complexity)
        line_items: List[LineItem] = [LineItem(item=mi) for mi in basket]
        order = Order(
            channel=channel,
            complexity=complexity,
            line_items=line_items,
            created_at=self.engine.now,
        )
        return order

    def run(self):
        """SimPy process: thinning-based NHPP customer arrivals."""
        cfg = self.engine.config
        peak_rate_guess = cfg.base_arrival_rate_per_min * max(
            cfg.lunch_peak_multiplier, cfg.dinner_peak_multiplier
        )
        lambda_max_per_s = (peak_rate_guess * self.lambda_max_multiplier) / 60.0

        while True:
            dt = self.rng.exponential(1.0 / lambda_max_per_s)
            yield self.engine.timeout(dt)

            current_rate_per_s = self.demand.arrival_rate_per_min(self.engine.now) / 60.0
            accept_prob = min(1.0, current_rate_per_s / lambda_max_per_s)
            if self.rng.random() > accept_prob:
                continue  # thinned out -- not a real arrival

            order = self._build_order()
            self.engine.metrics.incr("orders_created")
            self.engine.bus.publish(Topics.CUSTOMER_ARRIVED, order=order)
            self.engine.bus.publish(Topics.ORDER_CREATED, order=order)
            accepted = self.queue.enqueue(order)
            if not accepted:
                logger.debug("t=%.0f order %s balked (queue full)", self.engine.now, order.id)
