"""Stochastic customer demand modelling and arrival generation."""
