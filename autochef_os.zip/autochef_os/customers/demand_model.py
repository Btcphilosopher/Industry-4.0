"""
Time-varying demand model.

Customer arrival intensity is modelled as a non-homogeneous Poisson
process whose rate lambda(t) is a base rate plus two Gaussian "rush"
bumps (lunch and dinner), each with independent day-to-day multiplicative
noise so no two simulated days look identical. Order channel mix
(dine-in / drive-thru / delivery) and complexity mix also drift with the
time of day: drive-thru share rises during rush, and complexity rises
slightly in the evening (bigger dinner orders).
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict

import numpy as np

from autochef_os.utils.config import SimulationConfig


def _gaussian_bump(hour: float, center: float, width: float, amplitude: float) -> float:
    return amplitude * math.exp(-0.5 * ((hour - center) / width) ** 2)


@dataclass
class DemandSnapshot:
    hour_of_day: float
    rate_per_min: float
    channel_weights: Dict[str, float]
    complexity_weights: Dict[str, float]


class DemandModel:
    """Computes instantaneous arrival rate and order mix as a function of time."""

    def __init__(self, config: SimulationConfig, rng: np.random.Generator, day_start_hour: float = 10.0):
        self.config = config
        self.rng = rng
        self.day_start_hour = day_start_hour
        # per-run stochastic perturbation so repeated runs with different
        # seeds produce genuinely different daily demand shapes
        self._lunch_jitter = float(self.rng.normal(1.0, 0.08))
        self._dinner_jitter = float(self.rng.normal(1.0, 0.08))
        self._noise_state = 1.0

    def hour_of_day(self, sim_time_s: float) -> float:
        return (self.day_start_hour + sim_time_s / 3600.0) % 24.0

    def _short_term_noise(self) -> float:
        # slow mean-reverting multiplicative noise (Ornstein-Uhlenbeck-ish)
        shock = self.rng.normal(0, 0.05)
        self._noise_state = 0.9 * self._noise_state + 0.1 * 1.0 + shock
        return max(0.4, self._noise_state)

    def arrival_rate_per_min(self, sim_time_s: float) -> float:
        hour = self.hour_of_day(sim_time_s)
        cfg = self.config
        base = cfg.base_arrival_rate_per_min
        lunch = _gaussian_bump(
            hour, cfg.lunch_peak_center_h, cfg.peak_width_h,
            base * (cfg.lunch_peak_multiplier - 1.0) * self._lunch_jitter,
        )
        dinner = _gaussian_bump(
            hour, cfg.dinner_peak_center_h, cfg.peak_width_h,
            base * (cfg.dinner_peak_multiplier - 1.0) * self._dinner_jitter,
        )
        rate = (base + lunch + dinner) * self._short_term_noise()
        return max(0.02, rate)

    def channel_weights(self, sim_time_s: float) -> Dict[str, float]:
        hour = self.hour_of_day(sim_time_s)
        w = dict(self.config.channel_weights)
        # drive-thru share increases during rush hours
        rush = _gaussian_bump(hour, self.config.lunch_peak_center_h, self.config.peak_width_h, 1.0)
        rush += _gaussian_bump(hour, self.config.dinner_peak_center_h, self.config.peak_width_h, 1.0)
        rush = min(1.0, rush)
        w["drive_thru"] = w["drive_thru"] * (1.0 + 0.5 * rush)
        total = sum(w.values())
        return {k: v / total for k, v in w.items()}

    def complexity_weights(self, sim_time_s: float) -> Dict[str, float]:
        hour = self.hour_of_day(sim_time_s)
        w = dict(self.config.complexity_weights)
        if 17.5 <= hour <= 20.5:  # dinner orders trend larger/combo-heavy
            w["complex"] *= 1.6
            w["simple"] *= 0.8
        total = sum(w.values())
        return {k: v / total for k, v in w.items()}

    def snapshot(self, sim_time_s: float) -> DemandSnapshot:
        return DemandSnapshot(
            hour_of_day=self.hour_of_day(sim_time_s),
            rate_per_min=self.arrival_rate_per_min(sim_time_s),
            channel_weights=self.channel_weights(sim_time_s),
            complexity_weights=self.complexity_weights(sim_time_s),
        )
