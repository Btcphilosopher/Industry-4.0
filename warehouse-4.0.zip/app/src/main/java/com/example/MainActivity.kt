package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.WarehouseTheme
import com.example.warehouse4.ui.NavigationScreen
import com.example.warehouse4.ui.WarehouseViewModel
import com.example.warehouse4.ui.components.CommandPaletteDialog
import com.example.warehouse4.ui.components.ConveyorDetailDialog
import com.example.warehouse4.ui.components.RobotDetailDialog
import com.example.warehouse4.ui.components.SidebarNav
import com.example.warehouse4.ui.components.SkuDetailDialog
import com.example.warehouse4.ui.components.TopHeaderBar
import com.example.warehouse4.ui.screens.AiAssistantScreen
import com.example.warehouse4.ui.screens.AnalyticsScreen
import com.example.warehouse4.ui.screens.AuditSecurityScreen
import com.example.warehouse4.ui.screens.ConveyorsScreen
import com.example.warehouse4.ui.screens.DigitalTwinScreen
import com.example.warehouse4.ui.screens.DocksScreen
import com.example.warehouse4.ui.screens.InventoryScreen
import com.example.warehouse4.ui.screens.OptimisationScreen
import com.example.warehouse4.ui.screens.OrdersScreen
import com.example.warehouse4.ui.screens.OverviewDashboardScreen
import com.example.warehouse4.ui.screens.PackingScreen
import com.example.warehouse4.ui.screens.RoboticsScreen
import com.example.warehouse4.ui.screens.SimulationScreen
import com.example.warehouse4.ui.screens.WorkforceScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            WarehouseTheme {
                val viewModel: WarehouseViewModel = viewModel()
                val uiState by viewModel.uiState.collectAsState()

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = DarkBackground
                ) { innerPadding ->
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        // Top Enterprise Command Header
                        TopHeaderBar(
                            uiState = uiState,
                            onOpenCommandPalette = { viewModel.openCommandPalette(true) },
                            onOpenAiAssistant = { viewModel.setScreen(NavigationScreen.AI_ASSISTANT) },
                            onOpenAdmin = { viewModel.setScreen(NavigationScreen.ADMIN_AUDIT) }
                        )

                        // Main Body: Left Sidebar + Screen Router
                        Row(modifier = Modifier.fillMaxSize()) {
                            SidebarNav(
                                currentScreen = uiState.currentScreen,
                                onNavigate = { viewModel.setScreen(it) }
                            )

                            Box(modifier = Modifier.fillMaxSize().background(DarkBackground)) {
                                when (uiState.currentScreen) {
                                    NavigationScreen.OVERVIEW, NavigationScreen.OPERATIONS -> {
                                        OverviewDashboardScreen(uiState = uiState, viewModel = viewModel)
                                    }
                                    NavigationScreen.DIGITAL_TWIN -> {
                                        DigitalTwinScreen(uiState = uiState, viewModel = viewModel)
                                    }
                                    NavigationScreen.ROBOTICS -> {
                                        RoboticsScreen(uiState = uiState, viewModel = viewModel)
                                    }
                                    NavigationScreen.INVENTORY -> {
                                        InventoryScreen(uiState = uiState, viewModel = viewModel)
                                    }
                                    NavigationScreen.ORDERS -> {
                                        OrdersScreen(uiState = uiState, viewModel = viewModel)
                                    }
                                    NavigationScreen.CONVEYORS -> {
                                        ConveyorsScreen(uiState = uiState, viewModel = viewModel)
                                    }
                                    NavigationScreen.PACKING -> {
                                        PackingScreen(uiState = uiState, viewModel = viewModel)
                                    }
                                    NavigationScreen.SHIPPING -> {
                                        DocksScreen(uiState = uiState, viewModel = viewModel)
                                    }
                                    NavigationScreen.WORKFORCE -> {
                                        WorkforceScreen(uiState = uiState, viewModel = viewModel)
                                    }
                                    NavigationScreen.SIMULATION -> {
                                        SimulationScreen(uiState = uiState, viewModel = viewModel)
                                    }
                                    NavigationScreen.OPTIMISATION -> {
                                        OptimisationScreen(uiState = uiState, viewModel = viewModel)
                                    }
                                    NavigationScreen.AI_ASSISTANT -> {
                                        AiAssistantScreen(uiState = uiState, viewModel = viewModel)
                                    }
                                    NavigationScreen.ANALYTICS -> {
                                        AnalyticsScreen(uiState = uiState, viewModel = viewModel)
                                    }
                                    NavigationScreen.ADMIN_AUDIT -> {
                                        AuditSecurityScreen(uiState = uiState, viewModel = viewModel)
                                    }
                                }
                            }
                        }
                    }

                    // MODAL DIALOGS & OVERLAYS
                    if (uiState.isCommandPaletteOpen) {
                        CommandPaletteDialog(
                            query = uiState.commandQuery,
                            onQueryChange = { viewModel.setCommandQuery(it) },
                            onExecuteCommand = { viewModel.executeQuickCommand(it) },
                            onDismiss = { viewModel.openCommandPalette(false) }
                        )
                    }

                    uiState.selectedRobot?.let { robot ->
                        RobotDetailDialog(
                            robot = robot,
                            onDismiss = { viewModel.selectRobot(null) }
                        )
                    }

                    uiState.selectedSku?.let { sku ->
                        SkuDetailDialog(
                            sku = sku,
                            onDismiss = { viewModel.selectSku(null) }
                        )
                    }

                    uiState.selectedConveyor?.let { conveyor ->
                        ConveyorDetailDialog(
                            conveyor = conveyor,
                            onDismiss = { viewModel.selectConveyor(null) }
                        )
                    }
                }
            }
        }
    }
}
