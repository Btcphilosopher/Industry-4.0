package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Technical Dashboard / Data Grid Industrial Operations Theme
val DarkBackground = Color(0xFF090D16)
val DarkSurface = Color(0xFF0F172A)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkSurfaceElevated = Color(0xFF172033)
val DarkBorder = Color(0xFF334155)
val DarkBorderSubtle = Color(0xFF1E293B)
val DarkGridDivider = Color(0xFF1E293B)

val PrimaryOrange = Color(0xFFFF9900)
val PrimaryOrangeDark = Color(0xFFCC7A00)
val PrimaryOrangeLight = Color(0xFFFFB84D)

val AccentTeal = Color(0xFF06B6D4)
val AccentGreen = Color(0xFF10B981)
val AccentAmber = Color(0xFFF59E0B)
val AccentRed = Color(0xFFEF4444)
val AccentPurple = Color(0xFF8B5CF6)
val AccentBlue = Color(0xFF3B82F6)
val AccentCyan = Color(0xFF22D3EE)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)
val TextMuted = Color(0xFF475569)

val ZonePick = Color(0xFFF97316)
val ZoneStorage = Color(0xFF3B82F6)
val ZonePack = Color(0xFF10B981)
val ZoneSort = Color(0xFF8B5CF6)
val ZoneCharging = Color(0xFFEAB308)
val ZoneDock = Color(0xFF06B6D4)

