package com.example.warehouse4.core

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

enum class OperationalMode {
    LIVE_OPERATIONS,
    DIGITAL_TWIN_SIMULATION
}

enum class UserRole {
    ADMIN,
    OPERATIONS_MANAGER,
    WAREHOUSE_MANAGER,
    INVENTORY_MANAGER,
    MAINTENANCE,
    ANALYST,
    VIEWER
}

data class UserProfile(
    val id: String = "EMP-8842",
    val name: String = "Alex Morgan",
    val title: String = "Operations Manager",
    val role: UserRole = UserRole.OPERATIONS_MANAGER,
    val shift: String = "Day Shift (Alpha)"
)

data class WarehouseConfig(
    val siteCode: String = "LGB8 - Phoenix",
    val siteName: String = "Phoenix Global Fulfilment Centre",
    val widthMeters: Int = 1000,
    val lengthMeters: Int = 600,
    val levels: Int = 4,
    val totalZones: Int = 10,
    val totalStorageLocations: Int = 50000,
    val targetThroughputUph: Int = 85000
)

enum class EventSeverity {
    INFO,
    NORMAL,
    WARNING,
    DEGRADED,
    CRITICAL
}

enum class EventType {
    ORDER_CREATED,
    ORDER_CANCELLED,
    SKU_RECEIVED,
    ITEM_PICKED,
    ITEM_PACKED,
    ROBOT_MOVED,
    ROBOT_BLOCKED,
    ROBOT_CHARGING,
    CONVEYOR_STARTED,
    CONVEYOR_STOPPED,
    CONVEYOR_FAULT,
    TRUCK_ARRIVED,
    TRUCK_DEPARTED,
    DOCK_ASSIGNED,
    INVENTORY_MOVED,
    ALERT_CREATED,
    OPTIMIZATION_TRIGGERED,
    SAFETY_INTERLOCK_VERIFIED
}

data class WarehouseEvent(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val eventType: EventType,
    val sourceId: String,
    val description: String,
    val severity: EventSeverity = EventSeverity.INFO,
    val metadata: Map<String, String> = emptyMap()
) {
    val formattedTime: String
        get() {
            val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
            return sdf.format(Date(timestamp))
        }
}

data class WarehouseAlert(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val message: String,
    val severity: EventSeverity,
    val timestamp: Long = System.currentTimeMillis(),
    val sourceModule: String,
    val isAcknowledged: Boolean = false,
    val confidence: Float = 0.94f,
    val estimatedTimeToImpactMin: Int = 15
) {
    val formattedTime: String
        get() {
            val sdf = SimpleDateFormat("HH:mm a", Locale.getDefault())
            return sdf.format(Date(timestamp))
        }
}

data class AuditRecord(
    val id: String = UUID.randomUUID().toString(),
    val who: String,
    val role: UserRole,
    val what: String,
    val whenTimestamp: Long = System.currentTimeMillis(),
    val why: String,
    val sourceData: String,
    val modelVersion: String = "v4.2.1-prod",
    val action: String,
    val result: String,
    val isAiGenerated: Boolean = false
) {
    val formattedTime: String
        get() {
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
            return sdf.format(Date(whenTimestamp))
        }
}
