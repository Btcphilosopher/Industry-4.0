package com.example.warehouse4.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.AccentPurple
import com.example.ui.theme.AccentRed
import com.example.ui.theme.AccentTeal
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.PrimaryOrange
import com.example.warehouse4.conveyor.ConveyorSegment
import com.example.warehouse4.robotics.RobotStatus
import com.example.warehouse4.robotics.RobotUnit
import com.example.warehouse4.ui.HeatmapType

@Composable
fun DigitalTwinCanvas(
    robots: List<RobotUnit>,
    conveyors: List<ConveyorSegment>,
    heatmapType: HeatmapType,
    onSelectRobot: (RobotUnit) -> Unit,
    onSelectZone: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var scale by remember { mutableFloatStateOf(1.0f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    val infiniteTransition = rememberInfiniteTransition(label = "conveyorFlow")
    val flowPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 20f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(DarkBackground)
            .border(1.dp, DarkBorder, RoundedCornerShape(10.dp))
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(0.6f, 3.5f)
                    offset = Offset(offset.x + pan.x, offset.y + pan.y)
                }
            }
            .pointerInput(robots) {
                detectTapGestures { tapOffset ->
                    // Transform tap back into canvas coordinates
                    // Check if tapped near any robot
                    // Default fallback opens Pick Zone A
                    onSelectZone("Pick Zone A")
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // 1. Draw Grid Lines
            drawWarehouseGrid(w, h)

            // 2. Draw Zones
            drawWarehouseZones(w, h, onSelectZone)

            // 3. Draw Heatmap overlay if enabled
            if (heatmapType != HeatmapType.NONE_3D) {
                drawHeatmapOverlay(w, h, heatmapType)
            }

            // 4. Draw Conveyor Belts & Flowing Packages
            drawConveyorSystem(w, h, conveyors, flowPhase)

            // 5. Draw Charging Pads
            drawChargingPads(w, h)

            // 6. Draw Robot Drive Units
            drawRobots(w, h, robots)
        }
    }
}

private fun DrawScope.drawWarehouseGrid(w: Float, h: Float) {
    val step = 30f
    for (x in 0..(w / step).toInt()) {
        drawLine(
            color = DarkBorder.copy(alpha = 0.3f),
            start = Offset(x * step, 0f),
            end = Offset(x * step, h),
            strokeWidth = 0.5f
        )
    }
    for (y in 0..(h / step).toInt()) {
        drawLine(
            color = DarkBorder.copy(alpha = 0.3f),
            start = Offset(0f, y * step),
            end = Offset(w, y * step),
            strokeWidth = 0.5f
        )
    }
}

private fun DrawScope.drawWarehouseZones(w: Float, h: Float, onSelectZone: (String) -> Unit) {
    // Pick Zone A (Top-Left)
    drawRoundRect(
        color = PrimaryOrange.copy(alpha = 0.08f),
        topLeft = Offset(w * 0.05f, h * 0.08f),
        size = Size(w * 0.40f, h * 0.40f),
        cornerRadius = CornerRadius(12f, 12f)
    )
    drawRoundRect(
        color = PrimaryOrange.copy(alpha = 0.35f),
        topLeft = Offset(w * 0.05f, h * 0.08f),
        size = Size(w * 0.40f, h * 0.40f),
        cornerRadius = CornerRadius(12f, 12f),
        style = Stroke(width = 1.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f)))
    )

    // Storage Zone B (Top-Right High Bay Racks)
    drawRoundRect(
        color = AccentTeal.copy(alpha = 0.08f),
        topLeft = Offset(w * 0.52f, h * 0.08f),
        size = Size(w * 0.43f, h * 0.50f),
        cornerRadius = CornerRadius(12f, 12f)
    )
    drawRoundRect(
        color = AccentTeal.copy(alpha = 0.35f),
        topLeft = Offset(w * 0.52f, h * 0.08f),
        size = Size(w * 0.43f, h * 0.50f),
        cornerRadius = CornerRadius(12f, 12f),
        style = Stroke(width = 1.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f)))
    )

    // Storage Racks Shelves inside Zone B
    for (row in 0..4) {
        val y = h * (0.13f + row * 0.08f)
        for (col in 0..3) {
            val x = w * (0.55f + col * 0.10f)
            drawRoundRect(
                color = DarkSurfaceElevated,
                topLeft = Offset(x, y),
                size = Size(w * 0.08f, h * 0.04f),
                cornerRadius = CornerRadius(4f, 4f)
            )
            drawRoundRect(
                color = DarkBorder,
                topLeft = Offset(x, y),
                size = Size(w * 0.08f, h * 0.04f),
                cornerRadius = CornerRadius(4f, 4f),
                style = Stroke(width = 1f)
            )
        }
    }

    // Pick Zone A Pod Racks
    for (row in 0..3) {
        val y = h * (0.13f + row * 0.08f)
        for (col in 0..2) {
            val x = w * (0.08f + col * 0.12f)
            drawRoundRect(
                color = DarkSurfaceVariant,
                topLeft = Offset(x, y),
                size = Size(w * 0.09f, h * 0.045f),
                cornerRadius = CornerRadius(4f, 4f)
            )
        }
    }

    // Pack Zone (Center-Bottom)
    drawRoundRect(
        color = AccentGreen.copy(alpha = 0.08f),
        topLeft = Offset(w * 0.05f, h * 0.55f),
        size = Size(w * 0.40f, h * 0.22f),
        cornerRadius = CornerRadius(12f, 12f)
    )
    drawRoundRect(
        color = AccentGreen.copy(alpha = 0.35f),
        topLeft = Offset(w * 0.05f, h * 0.55f),
        size = Size(w * 0.40f, h * 0.22f),
        cornerRadius = CornerRadius(12f, 12f),
        style = Stroke(width = 1.5f)
    )

    // Sortation Hub (Bottom-Right)
    drawRoundRect(
        color = AccentPurple.copy(alpha = 0.08f),
        topLeft = Offset(w * 0.52f, h * 0.64f),
        size = Size(w * 0.43f, h * 0.25f),
        cornerRadius = CornerRadius(12f, 12f)
    )
    drawRoundRect(
        color = AccentPurple.copy(alpha = 0.35f),
        topLeft = Offset(w * 0.52f, h * 0.64f),
        size = Size(w * 0.43f, h * 0.25f),
        cornerRadius = CornerRadius(12f, 12f),
        style = Stroke(width = 1.5f)
    )
}

private fun DrawScope.drawConveyorSystem(
    w: Float,
    h: Float,
    conveyors: List<ConveyorSegment>,
    flowPhase: Float
) {
    // Spine conveyor from Pick Zone to Pack Zone and Sortation
    val path = Path().apply {
        moveTo(w * 0.25f, h * 0.30f)
        lineTo(w * 0.48f, h * 0.30f)
        lineTo(w * 0.48f, h * 0.70f)
        lineTo(w * 0.65f, h * 0.70f)
    }

    // Belt Background
    drawPath(
        path = path,
        color = Color(0xFF1E293B),
        style = Stroke(width = 14f)
    )
    // Moving Rollers
    drawPath(
        path = path,
        color = AccentTeal.copy(alpha = 0.7f),
        style = Stroke(
            width = 6f,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), flowPhase)
        )
    )
}

private fun DrawScope.drawChargingPads(w: Float, h: Float) {
    // Charging Bay Grid (Lower center)
    val startX = w * 0.25f
    val startY = h * 0.82f
    for (i in 0..5) {
        val cx = startX + i * (w * 0.04f)
        drawCircle(
            color = AccentAmber.copy(alpha = 0.25f),
            radius = 8f,
            center = Offset(cx, startY)
        )
        drawCircle(
            color = AccentAmber,
            radius = 4f,
            center = Offset(cx, startY)
        )
    }
}

private fun DrawScope.drawHeatmapOverlay(w: Float, h: Float, type: HeatmapType) {
    val (c1, c2) = when (type) {
        HeatmapType.CONGESTION -> AccentRed to AccentAmber
        HeatmapType.ROBOT_TRAFFIC -> PrimaryOrange to AccentTeal
        HeatmapType.SKU_VELOCITY -> AccentGreen to PrimaryOrange
        HeatmapType.ENERGY -> AccentAmber to AccentTeal
        else -> Color.Transparent to Color.Transparent
    }

    // Congestion Blob over Pick Zone A infeed
    drawCircle(
        brush = Brush.radialGradient(
            listOf(c1.copy(alpha = 0.45f), c2.copy(alpha = 0.15f), Color.Transparent),
            center = Offset(w * 0.30f, h * 0.28f),
            radius = w * 0.18f
        ),
        radius = w * 0.18f,
        center = Offset(w * 0.30f, h * 0.28f)
    )

    // Congestion Blob over Storage Zone B Aisle 14
    drawCircle(
        brush = Brush.radialGradient(
            listOf(c1.copy(alpha = 0.35f), Color.Transparent),
            center = Offset(w * 0.70f, h * 0.35f),
            radius = w * 0.14f
        ),
        radius = w * 0.14f,
        center = Offset(w * 0.70f, h * 0.35f)
    )
}

private fun DrawScope.drawRobots(w: Float, h: Float, robots: List<RobotUnit>) {
    robots.forEach { r ->
        val cx = (r.posX / 100f) * w
        val cy = (r.posY / 100f) * h

        val (statusColor, haloColor) = when (r.status) {
            RobotStatus.MOVING -> PrimaryOrange to PrimaryOrange.copy(alpha = 0.3f)
            RobotStatus.PICKING -> AccentGreen to AccentGreen.copy(alpha = 0.3f)
            RobotStatus.UNLOADING -> AccentTeal to AccentTeal.copy(alpha = 0.3f)
            RobotStatus.CHARGING -> AccentAmber to AccentAmber.copy(alpha = 0.3f)
            RobotStatus.BLOCKED, RobotStatus.FAULT -> AccentRed to AccentRed.copy(alpha = 0.4f)
            else -> DarkSurfaceElevated to Color.Transparent
        }

        // Halo
        drawCircle(
            color = haloColor,
            radius = 14f,
            center = Offset(cx, cy)
        )

        // Robot Body (Drive Pod)
        drawCircle(
            color = Color(0xFF0F172A),
            radius = 9f,
            center = Offset(cx, cy)
        )
        drawCircle(
            color = statusColor,
            radius = 9f,
            center = Offset(cx, cy),
            style = Stroke(width = 2.5f)
        )

        // Center dot / load indicator
        if (r.loadKg > 0) {
            drawCircle(
                color = AccentAmber,
                radius = 3.5f,
                center = Offset(cx, cy)
            )
        } else {
            drawCircle(
                color = statusColor,
                radius = 2.5f,
                center = Offset(cx, cy)
            )
        }
    }
}
