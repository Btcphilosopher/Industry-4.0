package com.example.warehouse4.analytics

data class HourlyThroughputPoint(
    val hourLabel: String,
    val ordersProcessed: Int,
    val unitsShipped: Int,
    val tasksCompleted: Int
)

data class WarehouseKpiSummary(
    val ordersToday: Int = 182347,
    val ordersTodayDeltaPct: Float = 12.4f,
    val unitsShipped: String = "1.2M",
    val unitsShippedDeltaPct: Float = 8.7f,
    val onTimeShipPct: Float = 98.6f,
    val onTimeShipDeltaPct: Float = 2.1f,
    val robotsActive: Int = 1204,
    val fleetUtilizationPct: Int = 89,
    val inventoryAccuracyPct: Float = 99.72f,
    val inventoryAccuracyDeltaPct: Float = 0.15f,
    val safetyIncidents: Int = 0,
    val avgTaskTimeMinutes: Float = 2.4f,
    val tasksCompletedToday: Int = 45892,
    val totalSkus: String = "2.1M",
    val skusInStock: String = "1.98M",
    val lowStockSkus: Int = 3456,
    val outOfStockSkus: Int = 1234,
    val energyUsedKwh: Int = 156782,
    val energySavingsPct: Float = 6.3f,
    val carbonEmissionsMt: Float = 72.4f,
    val carbonSavingsPct: Float = 8.1f,
    val ambientTempC: Float = 21.6f
)

class AnalyticsEngine {
    fun getKpiSummary(): WarehouseKpiSummary = WarehouseKpiSummary()

    fun getHourlyPerformanceTrend(): List<HourlyThroughputPoint> {
        return listOf(
            HourlyThroughputPoint("12 AM", 8200, 15400, 21000),
            HourlyThroughputPoint("3 AM", 14500, 26800, 36200),
            HourlyThroughputPoint("6 AM", 12800, 23900, 32100),
            HourlyThroughputPoint("9 AM", 24500, 45200, 61400),
            HourlyThroughputPoint("12 PM", 22100, 41000, 56200),
            HourlyThroughputPoint("3 PM", 26800, 49800, 67400),
            HourlyThroughputPoint("6 PM", 25400, 47100, 64200),
            HourlyThroughputPoint("9 PM", 28900, 53600, 72800)
        )
    }
}
