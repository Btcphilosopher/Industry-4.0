package com.example.warehouse4.ml

data class MlPrediction<T>(
    val modelName: String,
    val modelVersion: String = "v3.8.4-prod",
    val prediction: T,
    val confidencePct: Int, // 0-100
    val topFeatures: List<Pair<String, Float>>, // Feature name & importance
    val generatedTimestamp: Long = System.currentTimeMillis()
)

data class DemandForecast(
    val nextHourOrders: Int,
    val peakHourTimestamp: String,
    val topTrendingCategory: String,
    val expectedSpikePct: Float
)

data class MaintenancePrediction(
    val assetId: String,
    val assetType: String,
    val remainingUsefulLifeHours: Float,
    val failureProbabilityPct: Int,
    val recommendedAction: String
)

data class CongestionHotspot(
    val zoneName: String,
    val severityScore: Float, // 0.0 to 1.0
    val expectedClearTimeMin: Int,
    val primaryContributingFactor: String
)

class MachineLearningEngine {
    fun getDemandForecast(): MlPrediction<DemandForecast> {
        return MlPrediction(
            modelName = "TransformerDemandForecaster-v4",
            prediction = DemandForecast(
                nextHourOrders = 18450,
                peakHourTimestamp = "14:00 - 16:00 MST",
                topTrendingCategory = "Consumer Electronics & Prime Fast-Ship",
                expectedSpikePct = 24.5f
            ),
            confidencePct = 94,
            topFeatures = listOf(
                "Historical Day-of-Week Order Flow" to 0.42f,
                "Promotional Campaign Flash Deals" to 0.28f,
                "Regional Weather / Transit Conditions" to 0.18f,
                "Recent 15-Minute Web Traffic Velocity" to 0.12f
            )
        )
    }

    fun getPredictiveMaintenance(): List<MlPrediction<MaintenancePrediction>> {
        return listOf(
            MlPrediction(
                modelName = "VibrationAcousticPredictor",
                prediction = MaintenancePrediction(
                    assetId = "R2D2-8842 (AGV R-110)",
                    assetType = "Drive Pod Unit",
                    remainingUsefulLifeHours = 18.5f,
                    failureProbabilityPct = 78,
                    recommendedAction = "Inspect right drive wheel gear meshing and replace traction bearing during upcoming 14:00 maintenance window."
                ),
                confidencePct = 92,
                topFeatures = listOf("RMS Vibration mm/s" to 0.55f, "Motor Winding Temp °C" to 0.30f, "Current Draw Spikes" to 0.15f)
            ),
            MlPrediction(
                modelName = "ConveyorTensionPredictor",
                prediction = MaintenancePrediction(
                    assetId = "C-104 (Sortation Loop Diverter 14)",
                    assetType = "Roller Conveyor Motor",
                    remainingUsefulLifeHours = 36.0f,
                    failureProbabilityPct = 64,
                    recommendedAction = "Check belt tensioning cylinder pressure and clean optical diversion photocell."
                ),
                confidencePct = 88,
                topFeatures = listOf("Belt Slippage Metric" to 0.48f, "Thermal Dissipation Rate" to 0.32f, "Package Jam Count" to 0.20f)
            )
        )
    }

    fun getCongestionPredictions(): List<CongestionHotspot> {
        return listOf(
            CongestionHotspot("Pick Zone A (Aisles 02-06)", 0.82f, 14, "Concurrent AGV route intersection at main infeed conveyor chute"),
            CongestionHotspot("Storage Zone B (Aisle 14)", 0.65f, 22, "Temporary manual pallet jack clearance protocol"),
            CongestionHotspot("Outbound Dock 12 Apron", 0.74f, 18, "Trailer backing maneuver delay")
        )
    }
}
