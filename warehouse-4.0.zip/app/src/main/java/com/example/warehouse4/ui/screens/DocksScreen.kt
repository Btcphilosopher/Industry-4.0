package com.example.warehouse4.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.AccentRed
import com.example.ui.theme.AccentTeal
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.PrimaryOrange
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.warehouse4.shipping.DockBay
import com.example.warehouse4.shipping.DockStatus
import com.example.warehouse4.ui.WarehouseUiState
import com.example.warehouse4.ui.WarehouseViewModel

@Composable
fun DocksScreen(
    uiState: WarehouseUiState,
    viewModel: WarehouseViewModel,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Surface(
            color = DarkSurface,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, DarkBorder, RoundedCornerShape(10.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.LocalShipping, contentDescription = null, tint = PrimaryOrange)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("Inbound / Outbound Loading Dock Scheduling", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text("Turnaround Time Optimization & Carrier Linehaul Management", color = TextTertiary, fontSize = 11.sp)
                    }
                }
            }
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(uiState.docks) { dock ->
                DockDetailCard(dock = dock)
            }
        }
    }
}

@Composable
private fun DockDetailCard(dock: DockBay) {
    val statusColor = when (dock.status) {
        DockStatus.IN_PROGRESS -> AccentTeal
        DockStatus.DELAYED -> AccentRed
        DockStatus.SCHEDULED -> AccentGreen
        else -> TextTertiary
    }

    Surface(
        color = DarkSurface,
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, if (dock.status == DockStatus.DELAYED) AccentRed else DarkBorder, RoundedCornerShape(10.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "${dock.id} — ${dock.carrier}", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text(text = dock.status.name, color = statusColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "Scheduled: ${dock.scheduledTime} • Type: ${dock.type.name} • Truck ID: ${dock.currentTruckId ?: "N/A"}", color = TextSecondary, fontSize = 11.sp)

            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Pallets Loaded / Staged", color = TextTertiary, fontSize = 10.sp)
                Text("${dock.palletsLoaded} / ${dock.totalPallets} (${dock.progressPct}%)", color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(4.dp))
            LinearProgressIndicator(
                progress = { dock.progressPct / 100f },
                color = AccentTeal,
                trackColor = DarkBorder,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
            )

            Spacer(modifier = Modifier.height(8.dp))
            Text(text = "Est. Turnaround: ${dock.estimatedTurnaroundMin} minutes", color = TextTertiary, fontSize = 11.sp)
        }
    }
}
