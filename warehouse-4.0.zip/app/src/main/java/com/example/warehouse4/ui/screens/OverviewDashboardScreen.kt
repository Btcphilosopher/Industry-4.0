package com.example.warehouse4.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.AccentPurple
import com.example.ui.theme.AccentRed
import com.example.ui.theme.AccentTeal
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkBorderSubtle
import com.example.ui.theme.DarkGridDivider
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.PrimaryOrange
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.warehouse4.core.EventSeverity
import com.example.warehouse4.shipping.DockStatus
import com.example.warehouse4.ui.HeatmapType
import com.example.warehouse4.ui.NavigationScreen
import com.example.warehouse4.ui.WarehouseUiState
import com.example.warehouse4.ui.WarehouseViewModel
import com.example.warehouse4.ui.components.DigitalTwinCanvas
import com.example.warehouse4.ui.components.DonutSegment
import com.example.warehouse4.ui.components.MetricKpiCard
import com.example.warehouse4.ui.components.MultiLineTrendChart
import com.example.warehouse4.ui.components.OrdersDonutChart
import com.example.warehouse4.ui.components.StatusBadge

@Composable
fun OverviewDashboardScreen(
    uiState: WarehouseUiState,
    viewModel: WarehouseViewModel,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // TOP 6 METRIC CARDS ROW
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricKpiCard("Orders Today", "182,347", "12.4%", true, PrimaryOrange, Modifier.weight(1f))
            MetricKpiCard("Units Shipped", "1,204,500", "8.7%", true, AccentCyan, Modifier.weight(1f))
            MetricKpiCard("On-Time Ship", "98.6%", "2.1%", true, AccentGreen, Modifier.weight(1f))
            MetricKpiCard("Robots Active", "1,204", "89% fleet", true, PrimaryOrange, Modifier.weight(1f))
            MetricKpiCard("Inventory Acc.", "99.72%", "0.15%", true, AccentTeal, Modifier.weight(1f))
            MetricKpiCard("Safety Incidents", "0", "100%", true, AccentGreen, Modifier.weight(1f))
        }

        // MIDDLE ROW: Warehouse Activity (Digital Twin) & Right Panels (Orders by Status, Alerts)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // LEFT COLUMN: Warehouse Activity Card (Digital Twin Visualizer)
            Surface(
                color = DarkSurface,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1.8f)
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    // Header with 3D / Heat Map Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "WAREHOUSE ACTIVITY (DIGITAL TWIN)",
                                color = TextPrimary,
                                fontSize = 13.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = "REAL-TIME MULTI-AGENT SPATIAL GRID",
                                color = TextTertiary,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(DarkSurfaceElevated)
                                .border(1.dp, DarkBorderSubtle, RoundedCornerShape(4.dp))
                                .padding(2.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(if (uiState.heatmapType == HeatmapType.NONE_3D) PrimaryOrange else Color.Transparent)
                                    .clickable { viewModel.setHeatmapType(HeatmapType.NONE_3D) }
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = "3D VIEW",
                                    color = if (uiState.heatmapType == HeatmapType.NONE_3D) Color.Black else TextSecondary,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(if (uiState.heatmapType != HeatmapType.NONE_3D) PrimaryOrange else Color.Transparent)
                                    .clickable { viewModel.setHeatmapType(HeatmapType.CONGESTION) }
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = "HEAT MAP",
                                    color = if (uiState.heatmapType != HeatmapType.NONE_3D) Color.Black else TextSecondary,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Activity Sub-counts
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        ActivitySubTag("PICKING", "312", AccentGreen)
                        ActivitySubTag("TRANSPORTING", "478", PrimaryOrange)
                        ActivitySubTag("PACKING", "189", AccentCyan)
                        ActivitySubTag("CHARGING", "225", AccentAmber)
                        ActivitySubTag("IDLE", "48", TextTertiary)
                    }

                    // Interactive Digital Twin Canvas
                    Spacer(modifier = Modifier.height(10.dp))
                    DigitalTwinCanvas(
                        robots = uiState.robots,
                        conveyors = uiState.conveyors,
                        heatmapType = uiState.heatmapType,
                        onSelectRobot = { viewModel.selectRobot(it) },
                        onSelectZone = { viewModel.selectZone(it) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(260.dp)
                    )

                    // Bottom Mini-Metrics inside Digital Twin Card
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Fleet Utilization
                        Surface(
                            color = DarkSurfaceElevated,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .weight(1f)
                                .border(1.dp, DarkBorderSubtle, RoundedCornerShape(6.dp))
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("FLEET UTILIZATION", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                    Text("89.0%", color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.height(5.dp))
                                LinearProgressIndicator(
                                    progress = { 0.89f },
                                    color = PrimaryOrange,
                                    trackColor = DarkBorder,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(5.dp)
                                        .clip(RoundedCornerShape(2.dp))
                                )
                            }
                        }

                        // Avg Task Time
                        Surface(
                            color = DarkSurfaceElevated,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .weight(1f)
                                .border(1.dp, DarkBorderSubtle, RoundedCornerShape(6.dp))
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("AVG TASK CYCLE", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text("2.4 min", color = TextPrimary, fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            }
                        }

                        // Tasks Completed
                        Surface(
                            color = DarkSurfaceElevated,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .weight(1f)
                                .border(1.dp, DarkBorderSubtle, RoundedCornerShape(6.dp))
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("TASKS COMPLETED", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text("45,892", color = TextPrimary, fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // RIGHT COLUMN: Orders by Status & Recent Alerts
            Column(
                modifier = Modifier.weight(1.2f),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Orders by Status (Donut Chart)
                Surface(
                    color = DarkSurface,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, DarkBorder, RoundedCornerShape(8.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("ORDERS BY STATUS", color = TextPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            Text(
                                text = "VIEW DATA GRID →",
                                color = PrimaryOrange,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.clickable { viewModel.setScreen(NavigationScreen.ORDERS) }
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            val donutSegments = listOf(
                                DonutSegment("Processing", 45678, AccentCyan),
                                DonutSegment("Picking", 67892, AccentGreen),
                                DonutSegment("Packing", 28347, AccentPurple),
                                DonutSegment("Shipped", 40430, PrimaryOrange)
                            )
                            OrdersDonutChart(
                                segments = donutSegments,
                                totalCount = "182,347",
                                modifier = Modifier.size(120.dp)
                            )

                            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                OrderStatusLegendRow("PROCESSING", "45,678", "25%", AccentCyan)
                                OrderStatusLegendRow("PICKING", "67,892", "37%", AccentGreen)
                                OrderStatusLegendRow("PACKING", "28,347", "16%", AccentPurple)
                                OrderStatusLegendRow("SHIPPED", "40,430", "22%", PrimaryOrange)
                            }
                        }
                    }
                }

                // Recent Alerts Queue
                Surface(
                    color = DarkSurface,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, DarkBorder, RoundedCornerShape(8.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("INCIDENT & TELEMETRY ALERTS", color = TextPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(PrimaryOrange.copy(alpha = 0.2f))
                                    .border(1.dp, PrimaryOrange.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("${uiState.alerts.count { !it.isAcknowledged }} UNACK", color = PrimaryOrange, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            uiState.alerts.take(4).forEach { alert ->
                                AlertRowItem(
                                    alert = alert,
                                    onAcknowledge = { viewModel.acknowledgeAlert(alert.id) }
                                )
                            }
                        }
                    }
                }
            }
        }

        // THIRD ROW: Inventory Health, Dock Schedule & Sustainability
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Inventory Health Card
            Surface(
                color = DarkSurface,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("INVENTORY HEALTH", color = TextPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Accuracy: 99.72%", color = AccentTeal, fontSize = 16.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    InventoryStatLine("Total SKUs", "2.10M")
                    InventoryStatLine("In Stock", "1.98M")
                    InventoryStatLine("Low Stock", "3,456")
                    InventoryStatLine("Out of Stock", "1,234")
                }
            }

            // Dock Schedule Card (Data Grid style)
            Surface(
                color = DarkSurface,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1.3f)
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("DOCK LOGISTICS SCHEDULE", color = TextPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        Text("5 BAYS ONLINE", color = AccentCyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    uiState.docks.forEach { dock ->
                        DockRowItem(dock = dock)
                    }
                }
            }

            // Sustainability & Energy Card
            Surface(
                color = DarkSurface,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, DarkBorder, RoundedCornerShape(8.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Eco, contentDescription = "Eco", tint = AccentGreen, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("SUSTAINABILITY & POWER", color = TextPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("ENERGY CONSUMPTION", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    Text("156,782 kWh", color = TextPrimary, fontSize = 16.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    Text("▲ -6.3% vs T-1d", color = AccentGreen, fontSize = 10.sp, fontFamily = FontFamily.Monospace)

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("CARBON EQUIVALENT", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    Text("72.4 MT CO2e", color = TextPrimary, fontSize = 16.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    Text("▲ -8.1% vs T-1d", color = AccentGreen, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }

        // BOTTOM ROW: Performance Over Time (Multi-line trend chart)
        Surface(
            color = DarkSurface,
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, DarkBorder, RoundedCornerShape(8.dp))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "PERFORMANCE THROUGHPUT TRENDS (HOURLY)",
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "SAMPLING RATE: 100ms",
                        color = TextTertiary,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                MultiLineTrendChart(
                    points = com.example.warehouse4.analytics.AnalyticsEngine().getHourlyPerformanceTrend(),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun ActivitySubTag(label: String, count: String, color: Color) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(DarkSurfaceElevated)
            .border(1.dp, DarkBorderSubtle, RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 3.dp)
    ) {
        Box(
            modifier = Modifier
                .size(5.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = label, color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.width(3.dp))
        Text(text = count, color = TextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun OrderStatusLegendRow(label: String, count: String, pct: String, color: Color) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(color)
        )
        Text(text = label, color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(75.dp))
        Text(text = count, color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        Text(text = pct, color = TextTertiary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun AlertRowItem(
    alert: com.example.warehouse4.core.WarehouseAlert,
    onAcknowledge: () -> Unit
) {
    val (badgeBg, badgeText) = when (alert.severity) {
        EventSeverity.CRITICAL -> AccentRed.copy(alpha = 0.2f) to AccentRed
        EventSeverity.DEGRADED -> AccentAmber.copy(alpha = 0.2f) to AccentAmber
        EventSeverity.WARNING -> PrimaryOrange.copy(alpha = 0.2f) to PrimaryOrange
        else -> DarkSurfaceElevated to TextSecondary
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(DarkSurfaceElevated)
            .border(1.dp, DarkBorderSubtle, RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(3.dp))
                .background(badgeBg)
                .padding(horizontal = 5.dp, vertical = 1.dp)
        ) {
            Text(
                text = alert.severity.name,
                color = badgeText,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = alert.title,
                color = TextPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1
            )
            Text(
                text = alert.formattedTime,
                color = TextTertiary,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )
        }
        if (!alert.isAcknowledged) {
            Text(
                text = "ACK",
                color = AccentCyan,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clip(RoundedCornerShape(3.dp))
                    .background(AccentCyan.copy(alpha = 0.1f))
                    .clickable { onAcknowledge() }
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }
    }
}

@Composable
private fun InventoryStatLine(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label.uppercase(), color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        Text(text = value, color = TextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun DockRowItem(dock: com.example.warehouse4.shipping.DockBay) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(DarkSurfaceElevated)
            .padding(horizontal = 6.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = dock.id, color = TextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        Text(text = dock.type.name, color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Text(text = dock.scheduledTime, color = TextTertiary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        val statusColor = when (dock.status) {
            DockStatus.IN_PROGRESS -> AccentCyan
            DockStatus.DELAYED -> AccentRed
            DockStatus.SCHEDULED -> AccentGreen
            else -> TextTertiary
        }
        Text(text = dock.status.name, color = statusColor, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    }
}

