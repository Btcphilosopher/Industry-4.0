package com.example.warehouse4.shipping

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class DockType {
    INBOUND,
    OUTBOUND
}

enum class DockStatus {
    AVAILABLE,
    IN_PROGRESS,
    DELAYED,
    SCHEDULED,
    MAINTENANCE
}

data class DockBay(
    val id: String, // e.g. Dock 11
    val bayNumber: Int,
    val type: DockType,
    val carrier: String,
    val scheduledTime: String,
    val currentTruckId: String?,
    val status: DockStatus,
    val palletsLoaded: Int = 18,
    val totalPallets: Int = 26,
    val estimatedTurnaroundMin: Int = 22
) {
    val progressPct: Int get() = if (totalPallets > 0) ((palletsLoaded.toFloat() / totalPallets) * 100).toInt() else 0
}

class DockManager {
    private val _docks = mutableListOf<DockBay>()

    init {
        seedDocks()
    }

    fun getAllDocks(): List<DockBay> = _docks.toList()

    fun getDock(id: String): DockBay? = _docks.find { it.id == id }

    fun getDockUtilization(): Int {
        val occupied = _docks.count { it.status == DockStatus.IN_PROGRESS || it.status == DockStatus.DELAYED }
        return if (_docks.isNotEmpty()) ((occupied.toFloat() / _docks.size) * 100).toInt() else 0
    }

    fun stepSimulation() {
        for (i in _docks.indices) {
            val d = _docks[i]
            if (d.status == DockStatus.IN_PROGRESS && d.palletsLoaded < d.totalPallets) {
                val nextLoaded = (d.palletsLoaded + 1).coerceAtMost(d.totalPallets)
                val nextStatus = if (nextLoaded >= d.totalPallets) DockStatus.AVAILABLE else DockStatus.IN_PROGRESS
                val nextTurnaround = (d.estimatedTurnaroundMin - 1).coerceAtLeast(0)
                _docks[i] = d.copy(palletsLoaded = nextLoaded, status = nextStatus, estimatedTurnaroundMin = nextTurnaround)
            }
        }
    }

    private fun seedDocks() {
        val sample = listOf(
            DockBay("Dock 11", 11, DockType.INBOUND, "Prime Logistics Fleet", "09:00 AM", "TRK-7782", DockStatus.IN_PROGRESS, 22, 26, 8),
            DockBay("Dock 12", 12, DockType.OUTBOUND, "FedEx Freight #401", "10:00 AM", "TRK-9120", DockStatus.DELAYED, 14, 28, 35),
            DockBay("Dock 13", 13, DockType.INBOUND, "UPS Ground Linehaul", "11:00 AM", "TRK-5510", DockStatus.SCHEDULED, 0, 24, 45),
            DockBay("Dock 14", 14, DockType.OUTBOUND, "Amazon Freight Trailer", "11:30 AM", "TRK-6048", DockStatus.SCHEDULED, 0, 30, 50),
            DockBay("Dock 15", 15, DockType.INBOUND, "DHL Global Forwarding", "01:00 PM", "TRK-3391", DockStatus.SCHEDULED, 0, 20, 40)
        )
        _docks.addAll(sample)
    }
}
