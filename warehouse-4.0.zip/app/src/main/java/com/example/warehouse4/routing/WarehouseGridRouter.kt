package com.example.warehouse4.routing

import java.util.PriorityQueue

data class GridPoint(val x: Int, val y: Int)

data class RouteNode(
    val point: GridPoint,
    val gCost: Float,
    val hCost: Float,
    val parent: RouteNode? = null
) : Comparable<RouteNode> {
    val fCost: Float get() = gCost + hCost
    override fun compareTo(other: RouteNode): Int = fCost.compareTo(other.fCost)
}

class WarehouseGridRouter(
    val gridWidth: Int = 100,
    val gridHeight: Int = 100
) {
    // Dynamic congestion weights (0.0 to 10.0 extra cost)
    private val congestionGrid = Array(gridWidth) { FloatArray(gridHeight) { 1.0f } }
    // Blocked obstacles (aisles closed, restricted zones)
    private val blockedGrid = Array(gridWidth) { BooleanArray(gridHeight) { false } }

    init {
        // Sample layout obstacles (pillars, fixed sorting structure)
        for (x in 48..52) {
            for (y in 10..90) {
                if (y !in 25..30 && y !in 50..55 && y !in 75..80) { // conveyor crossing points
                    blockedGrid[x][y] = true
                }
            }
        }
    }

    fun setObstacle(x: Int, y: Int, isBlocked: Boolean) {
        if (x in 0 until gridWidth && y in 0 until gridHeight) {
            blockedGrid[x][y] = isBlocked
        }
    }

    fun setCongestion(x: Int, y: Int, weight: Float) {
        if (x in 0 until gridWidth && y in 0 until gridHeight) {
            congestionGrid[x][y] = weight
        }
    }

    fun findPath(start: GridPoint, target: GridPoint): List<GridPoint> {
        val openSet = PriorityQueue<RouteNode>()
        val closedSet = mutableSetOf<GridPoint>()

        openSet.add(RouteNode(start, 0f, heuristic(start, target)))

        val visitedCosts = mutableMapOf<GridPoint, Float>()
        visitedCosts[start] = 0f

        val directions = listOf(
            GridPoint(0, 1), GridPoint(1, 0), GridPoint(0, -1), GridPoint(-1, 0)
        )

        while (openSet.isNotEmpty()) {
            val current = openSet.poll() ?: break

            if (current.point == target) {
                return reconstructPath(current)
            }

            closedSet.add(current.point)

            for (dir in directions) {
                val nextPt = GridPoint(current.point.x + dir.x, current.point.y + dir.y)

                if (nextPt.x !in 0 until gridWidth || nextPt.y !in 0 until gridHeight) continue
                if (blockedGrid[nextPt.x][nextPt.y] || nextPt in closedSet) continue

                val moveCost = 1.0f * congestionGrid[nextPt.x][nextPt.y]
                val tentativeG = current.gCost + moveCost

                if (tentativeG < (visitedCosts[nextPt] ?: Float.MAX_VALUE)) {
                    visitedCosts[nextPt] = tentativeG
                    val h = heuristic(nextPt, target)
                    openSet.add(RouteNode(nextPt, tentativeG, h, current))
                }
            }
        }

        // Direct fallback line if blocked
        return listOf(start, target)
    }

    private fun heuristic(a: GridPoint, b: GridPoint): Float {
        // Manhattan distance
        return (kotlin.math.abs(a.x - b.x) + kotlin.math.abs(a.y - b.y)).toFloat()
    }

    private fun reconstructPath(endNode: RouteNode): List<GridPoint> {
        val path = mutableListOf<GridPoint>()
        var curr: RouteNode? = endNode
        while (curr != null) {
            path.add(curr.point)
            curr = curr.parent
        }
        return path.reversed()
    }
}
