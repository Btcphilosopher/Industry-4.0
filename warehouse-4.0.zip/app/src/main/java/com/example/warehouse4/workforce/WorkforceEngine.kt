package com.example.warehouse4.workforce

data class WorkstationZone(
    val zoneId: String,
    val name: String,
    val assignedWorkers: Int,
    val targetPaceUph: Int,
    val actualPaceUph: Int,
    val ergonomicsScore: Int = 94, // 0-100
    val workloadBalancingPct: Int = 88
) {
    val efficiencyPct: Int get() = if (targetPaceUph > 0) ((actualPaceUph.toFloat() / targetPaceUph) * 100).toInt() else 0
}

class WorkforceEngine {
    private val _stations = mutableListOf<WorkstationZone>()

    init {
        _stations.addAll(listOf(
            WorkstationZone("STA-PICK-A", "Pick Stations A (Decant & Pick)", 48, 12000, 11850, 96, 92),
            WorkstationZone("STA-PACK-MAIN", "Pack Stations Main Mezzanine", 62, 14000, 13600, 93, 89),
            WorkstationZone("STA-SORT", "High Speed Sortation & Induct", 24, 18000, 18200, 91, 95),
            WorkstationZone("STA-DOCKS", "Inbound/Outbound Dock Operations", 36, 8000, 7400, 88, 82),
            WorkstationZone("STA-ICQA", "Quality Assurance & Cycle Count", 18, 3000, 3100, 98, 96)
        ))
    }

    fun getAllZones(): List<WorkstationZone> = _stations.toList()

    fun getTotalActiveWorkers(): Int = _stations.sumOf { it.assignedWorkers }

    fun getAverageProductivityPct(): Int {
        if (_stations.isEmpty()) return 0
        return _stations.map { it.efficiencyPct }.average().toInt()
    }
}
