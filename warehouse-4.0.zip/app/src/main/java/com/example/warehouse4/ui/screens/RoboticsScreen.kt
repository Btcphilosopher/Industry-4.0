package com.example.warehouse4.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PrecisionManufacturing
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.AccentRed
import com.example.ui.theme.AccentTeal
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.PrimaryOrange
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.warehouse4.robotics.RobotStatus
import com.example.warehouse4.robotics.RobotUnit
import com.example.warehouse4.ui.WarehouseUiState
import com.example.warehouse4.ui.WarehouseViewModel

@Composable
fun RoboticsScreen(
    uiState: WarehouseUiState,
    viewModel: WarehouseViewModel,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Summary Header
        Surface(
            color = DarkSurface,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, DarkBorder, RoundedCornerShape(10.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.PrecisionManufacturing, contentDescription = null, tint = PrimaryOrange)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("Autonomous Drive Units & Fleet Telemetry", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text("1,204 Registered Drive Pods | Real-Time Sub-Centimeter Kinematics", color = TextTertiary, fontSize = 11.sp)
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { viewModel.runStorageOptimisation(false) },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated, contentColor = PrimaryOrange),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Smart Charge Balancer", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Fleet Grid
        LazyVerticalGrid(
            columns = GridCells.Adaptive(260.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(uiState.robots) { robot ->
                RobotCard(robot = robot, onClick = { viewModel.selectRobot(robot) })
            }
        }
    }
}

@Composable
private fun RobotCard(
    robot: RobotUnit,
    onClick: () -> Unit
) {
    val (statusBg, statusColor) = when (robot.status) {
        RobotStatus.MOVING -> PrimaryOrange.copy(alpha = 0.15f) to PrimaryOrange
        RobotStatus.PICKING -> AccentGreen.copy(alpha = 0.15f) to AccentGreen
        RobotStatus.CHARGING -> AccentAmber.copy(alpha = 0.15f) to AccentAmber
        RobotStatus.BLOCKED, RobotStatus.FAULT -> AccentRed.copy(alpha = 0.15f) to AccentRed
        else -> DarkSurfaceElevated to TextSecondary
    }

    Surface(
        color = DarkSurface,
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, if (robot.isNeedsMaintenance) AccentRed else DarkBorder, RoundedCornerShape(10.dp))
            .clickable { onClick() }
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = robot.id,
                    color = TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(statusBg)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = robot.status.name,
                        color = statusColor,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(text = robot.name, color = TextSecondary, fontSize = 11.sp)

            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Battery", color = TextTertiary, fontSize = 10.sp)
                Text("${robot.batteryPct}%", color = if (robot.isLowBattery) AccentRed else AccentGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(4.dp))
            LinearProgressIndicator(
                progress = { robot.batteryPct / 100f },
                color = if (robot.isLowBattery) AccentRed else AccentGreen,
                trackColor = DarkBorder,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
            )

            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Dest: ${robot.currentDestination}", color = TextTertiary, fontSize = 10.sp, maxLines = 1)
                Text("${robot.loadKg} kg", color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
