package com.example.warehouse4.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.AccentRed
import com.example.ui.theme.AccentTeal
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.PrimaryOrange
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.warehouse4.simulation.SimulationParameters
import com.example.warehouse4.ui.WarehouseUiState
import com.example.warehouse4.ui.WarehouseViewModel

@Composable
fun SimulationScreen(
    uiState: WarehouseUiState,
    viewModel: WarehouseViewModel,
    modifier: Modifier = Modifier
) {
    var orderVolume by remember { mutableIntStateOf(18000) }
    var robotCount by remember { mutableIntStateOf(500) }
    var workerCount by remember { mutableIntStateOf(188) }
    var isAisle14Blocked by remember { mutableStateOf(false) }
    var isHighVelocityRelocated by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Simulator Controls Header
        Surface(
            color = DarkSurface,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, DarkBorder, RoundedCornerShape(10.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Gamepad, contentDescription = null, tint = PrimaryOrange)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("Discrete-Event Simulation & What-If Studio", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text("Simulate capacity limits without affecting live hardware interlocks", color = TextTertiary, fontSize = 11.sp)
                    }
                }

                // Speed buttons
                Row(
                    modifier = Modifier
                        .background(DarkSurfaceElevated, RoundedCornerShape(8.dp))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = { viewModel.toggleSimulation() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (uiState.isSimulationRunning) PrimaryOrange else DarkSurfaceVariant,
                            contentColor = if (uiState.isSimulationRunning) Color.Black else TextPrimary
                        ),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Icon(
                            imageVector = if (uiState.isSimulationRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (uiState.isSimulationRunning) "Pause" else "Run", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    SpeedChip("1x", uiState.simulationSpeed == 1.0f) { viewModel.setSimulationSpeed(1.0f) }
                    SpeedChip("2x", uiState.simulationSpeed == 2.0f) { viewModel.setSimulationSpeed(2.0f) }
                    SpeedChip("5x", uiState.simulationSpeed == 5.0f) { viewModel.setSimulationSpeed(5.0f) }
                    SpeedChip("10x", uiState.simulationSpeed == 10.0f) { viewModel.setSimulationSpeed(10.0f) }
                }
            }
        }

        // Scenario Preset Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            PresetScenarioChip("+30% Order Surge", Modifier.weight(1f)) {
                orderVolume = 23400
                viewModel.runWhatIfScenario(
                    "+30% Order Surge",
                    SimulationParameters(orderVolumePerHour = 23400),
                    "Simulates sudden 30% inbound flash sale wave."
                )
            }
            PresetScenarioChip("Add 100 Robots", Modifier.weight(1f)) {
                robotCount = 600
                viewModel.runWhatIfScenario(
                    "Fleet Expansion (+100 AGVs)",
                    SimulationParameters(totalRobots = 600),
                    "Adds 100 extra drive pods to forward pick zones."
                )
            }
            PresetScenarioChip("Aisle 14 Obstacle Blocked", Modifier.weight(1f)) {
                isAisle14Blocked = true
                viewModel.runWhatIfScenario(
                    "Aisle 14 Maintenance Blockade",
                    SimulationParameters(isAisle14Blocked = true),
                    "Simulates impact of closing primary travel corridor."
                )
            }
            PresetScenarioChip("Fast-Moving Relocation Applied", Modifier.weight(1f)) {
                isHighVelocityRelocated = true
                viewModel.runWhatIfScenario(
                    "Top 5% SKU Relocation Active",
                    SimulationParameters(isHighVelocityRelocated = true),
                    "Evaluates throughput with optimized slotting topology."
                )
            }
        }

        // Parameter Sliders & Toggles Card
        Surface(
            color = DarkSurface,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, DarkBorder, RoundedCornerShape(10.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Scenario Parameter Configuration", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(14.dp))

                // Order Volume Slider
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Inbound Order Volume / Hour", color = TextSecondary, fontSize = 12.sp)
                    Text("$orderVolume orders/hr", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = orderVolume.toFloat(),
                    onValueChange = { orderVolume = it.toInt() },
                    valueRange = 8000f..35000f,
                    colors = SliderDefaults.colors(thumbColor = PrimaryOrange, activeTrackColor = PrimaryOrange)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Robot Count Slider
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total Active Robots (AGV / AMR)", color = TextSecondary, fontSize = 12.sp)
                    Text("$robotCount drive units", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = robotCount.toFloat(),
                    onValueChange = { robotCount = it.toInt() },
                    valueRange = 200f..1000f,
                    colors = SliderDefaults.colors(thumbColor = AccentTeal, activeTrackColor = AccentTeal)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Toggles Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(
                            checked = isAisle14Blocked,
                            onCheckedChange = { isAisle14Blocked = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = AccentRed, checkedTrackColor = AccentRed.copy(alpha = 0.5f))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Simulate Aisle 14 Obstacle", color = TextSecondary, fontSize = 12.sp)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(
                            checked = isHighVelocityRelocated,
                            onCheckedChange = { isHighVelocityRelocated = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = AccentGreen, checkedTrackColor = AccentGreen.copy(alpha = 0.5f))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Apply Fast-Moving SKU Relocation", color = TextSecondary, fontSize = 12.sp)
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    Button(
                        onClick = {
                            viewModel.runWhatIfScenario(
                                "Custom Scenario (${orderVolume} ord/hr, ${robotCount} AGVs)",
                                SimulationParameters(
                                    orderVolumePerHour = orderVolume,
                                    totalRobots = robotCount,
                                    isAisle14Blocked = isAisle14Blocked,
                                    isHighVelocityRelocated = isHighVelocityRelocated
                                ),
                                "Custom parameters calculated against baseline state."
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryOrange, contentColor = Color.Black),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Execute Custom Simulation", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Side-by-Side Comparison Table Card
        uiState.scenarioComparison?.let { comp ->
            Surface(
                color = DarkSurface,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, DarkBorder, RoundedCornerShape(10.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Simulation Results: ${comp.scenarioName}",
                        color = PrimaryOrange,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(text = comp.description, color = TextSecondary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(14.dp))
                    Divider(color = DarkBorder)
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        Text("KPI Metric", color = TextTertiary, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.5f))
                        Text("Baseline", color = TextTertiary, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text("Scenario", color = TextTertiary, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text("Delta Change", color = TextTertiary, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    ComparisonRow("Throughput (Orders/hr)", "${comp.baseline.ordersPerHour}", "${comp.scenario.ordersPerHour}", "${if (comp.throughputDelta >= 0) "+" else ""}${comp.throughputDelta} (${String.format("%.1f", comp.throughputPctChange)}%)", comp.throughputDelta >= 0)
                    ComparisonRow("Avg Pick Cycle Time", "${comp.baseline.avgPickTimeMinutes} min", "${comp.scenario.avgPickTimeMinutes} min", "${if (comp.pickTimeDelta <= 0) "" else "+"}${String.format("%.1f", comp.pickTimeDelta)} min", comp.pickTimeDelta <= 0)
                    ComparisonRow("Robot Fleet Utilisation", "${comp.baseline.robotUtilisationPct}%", "${comp.scenario.robotUtilisationPct}%", "${if (comp.robotUtilDelta >= 0) "+" else ""}${comp.robotUtilDelta}%", comp.robotUtilDelta <= 0)
                    ComparisonRow("Missed Order SLAs / hr", "${comp.baseline.missedDeadlinesPerHour}", "${comp.scenario.missedDeadlinesPerHour}", "${if (comp.missedDeadlinesDelta <= 0) "" else "+"}${comp.missedDeadlinesDelta}", comp.missedDeadlinesDelta <= 0)
                    ComparisonRow("Energy Draw / hr", "${comp.baseline.energyKwhPerHour.toInt()} kWh", "${comp.scenario.energyKwhPerHour.toInt()} kWh", "${(comp.scenario.energyKwhPerHour - comp.baseline.energyKwhPerHour).toInt()} kWh", comp.scenario.energyKwhPerHour <= comp.baseline.energyKwhPerHour)
                }
            }
        }
    }
}

@Composable
private fun SpeedChip(label: String, isSelected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(if (isSelected) PrimaryOrange else Color.Transparent)
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Text(text = label, color = if (isSelected) Color.Black else TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun PresetScenarioChip(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(
        color = DarkSurfaceElevated,
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
            .border(1.dp, DarkBorder, RoundedCornerShape(8.dp))
            .clickable { onClick() }
    ) {
        Box(modifier = Modifier.padding(12.dp), contentAlignment = Alignment.Center) {
            Text(text = label, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun ComparisonRow(metric: String, baseline: String, scenario: String, delta: String, isPositive: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(metric, color = TextPrimary, fontSize = 12.sp, modifier = Modifier.weight(1.5f))
        Text(baseline, color = TextSecondary, fontSize = 12.sp, modifier = Modifier.weight(1f))
        Text(scenario, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Text(delta, color = if (isPositive) AccentGreen else AccentRed, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
    }
}
