package com.example.warehouse4.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.AccentTeal
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.PrimaryOrange
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.warehouse4.ui.HeatmapType
import com.example.warehouse4.ui.WarehouseUiState
import com.example.warehouse4.ui.WarehouseViewModel
import com.example.warehouse4.ui.components.DigitalTwinCanvas

@Composable
fun DigitalTwinScreen(
    uiState: WarehouseUiState,
    viewModel: WarehouseViewModel,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Controls Header
        Surface(
            color = DarkSurface,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, DarkBorder, RoundedCornerShape(10.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.GridView, contentDescription = null, tint = PrimaryOrange)
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text("Interactive Digital Twin Explorer", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text("Real-Time Spatial Grid: 1000m x 600m | 4 Mezzanine Levels", color = TextTertiary, fontSize = 11.sp)
                    }
                }

                // Heatmap selector chips
                Row(
                    modifier = Modifier
                        .background(DarkSurfaceElevated, RoundedCornerShape(8.dp))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    HeatmapChip("3D Standard", uiState.heatmapType == HeatmapType.NONE_3D) {
                        viewModel.setHeatmapType(HeatmapType.NONE_3D)
                    }
                    HeatmapChip("Traffic Heat", uiState.heatmapType == HeatmapType.ROBOT_TRAFFIC) {
                        viewModel.setHeatmapType(HeatmapType.ROBOT_TRAFFIC)
                    }
                    HeatmapChip("Congestion Heat", uiState.heatmapType == HeatmapType.CONGESTION) {
                        viewModel.setHeatmapType(HeatmapType.CONGESTION)
                    }
                    HeatmapChip("SKU Velocity Heat", uiState.heatmapType == HeatmapType.SKU_VELOCITY) {
                        viewModel.setHeatmapType(HeatmapType.SKU_VELOCITY)
                    }
                    HeatmapChip("Energy Heat", uiState.heatmapType == HeatmapType.ENERGY) {
                        viewModel.setHeatmapType(HeatmapType.ENERGY)
                    }
                }
            }
        }

        // Main Full Screen Canvas
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            DigitalTwinCanvas(
                robots = uiState.robots,
                conveyors = uiState.conveyors,
                heatmapType = uiState.heatmapType,
                onSelectRobot = { viewModel.selectRobot(it) },
                onSelectZone = { viewModel.selectZone(it) },
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@Composable
private fun HeatmapChip(label: String, isSelected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (isSelected) PrimaryOrange else Color.Transparent)
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            color = if (isSelected) Color.Black else TextSecondary,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
        )
    }
}
