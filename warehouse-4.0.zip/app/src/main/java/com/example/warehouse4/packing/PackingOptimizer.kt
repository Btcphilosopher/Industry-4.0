package com.example.warehouse4.packing

data class CartonType(
    val id: String, // e.g. T1, T2, T3, M1, L1
    val name: String,
    val lengthCm: Float,
    val widthCm: Float,
    val heightCm: Float,
    val maxWeightKg: Float,
    val tareWeightKg: Float
) {
    val volumeCc: Float get() = lengthCm * widthCm * heightCm
}

data class PackingResult(
    val orderId: String,
    val selectedCarton: CartonType,
    val itemVolumeCc: Float,
    val cartonVolumeCc: Float,
    val voidSpacePct: Float,
    val totalWeightKg: Float,
    val arrangement: String,
    val dunnageRequired: String,
    val fragileHandling: Boolean
)

class PackingOptimizer {
    val standardCartons = listOf(
        CartonType("T1", "Mailers Pad #1", 20f, 15f, 3f, 1.5f, 0.05f),
        CartonType("T2", "Small Carton A1", 25f, 20f, 12f, 5.0f, 0.15f),
        CartonType("M1", "Medium Carton B2", 35f, 28f, 20f, 12.0f, 0.35f),
        CartonType("L1", "Large Heavy Carton C3", 50f, 40f, 35f, 25.0f, 0.75f),
        CartonType("XL", "Bulk Oversized D4", 75f, 55f, 45f, 40.0f, 1.20f)
    )

    fun calculateOptimalCarton(
        orderId: String,
        itemLengths: List<Float>,
        itemWidths: List<Float>,
        itemHeights: List<Float>,
        itemWeights: List<Float>,
        isFragile: Boolean
    ): PackingResult {
        var totalItemVolume = 0f
        var totalWeight = 0f
        var maxL = 0f
        var maxW = 0f
        var maxH = 0f

        for (i in itemLengths.indices) {
            val l = itemLengths[i]
            val w = itemWidths[i]
            val h = itemHeights[i]
            val wt = itemWeights.getOrElse(i) { 0.5f }
            totalItemVolume += (l * w * h)
            totalWeight += wt
            maxL = maxL.coerceAtLeast(l)
            maxW = maxW.coerceAtLeast(w)
            maxH = maxH.coerceAtLeast(h)
        }

        val suitable = standardCartons.filter { carton ->
            carton.lengthCm >= maxL &&
            carton.widthCm >= maxW &&
            carton.heightCm >= maxH &&
            carton.volumeCc >= totalItemVolume &&
            carton.maxWeightKg >= totalWeight
        }.minByOrNull { it.volumeCc } ?: standardCartons.last()

        val voidSpace = (((suitable.volumeCc - totalItemVolume) / suitable.volumeCc) * 100f).coerceIn(4f, 80f)
        val dunnage = when {
            isFragile -> "Air Pillows + Fragile Wrap"
            voidSpace > 25f -> "Recycled Kraft Paper"
            else -> "Minimal (Eco-Fit)"
        }

        return PackingResult(
            orderId = orderId,
            selectedCarton = suitable,
            itemVolumeCc = totalItemVolume,
            cartonVolumeCc = suitable.volumeCc,
            voidSpacePct = voidSpace,
            totalWeightKg = totalWeight + suitable.tareWeightKg,
            arrangement = "Layered Flat (Center of Gravity Centered)",
            dunnageRequired = dunnage,
            fragileHandling = isFragile
        )
    }
}
