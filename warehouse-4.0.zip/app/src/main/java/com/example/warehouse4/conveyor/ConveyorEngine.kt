package com.example.warehouse4.conveyor

import java.util.UUID

enum class ConveyorState {
    RUNNING,
    STOPPED,
    JAMMED,
    MAINTENANCE,
    DEGRADED
}

data class ConveyorSegment(
    val id: String, // e.g. C-101, C-102
    val name: String,
    val zone: String,
    val speedMps: Float = 2.4f,
    val direction: String = "Inbound to Sortation",
    val capacity: Int = 120,
    val currentPackages: Int = 74,
    val motorTempC: Float = 42.1f,
    val status: ConveyorState = ConveyorState.RUNNING,
    val itemsPerMinute: Int = 85,
    val utilisationPct: Int = 78,
    val vibrationMmS: Float = 1.2f,
    val totalPackagesShift: Int = 42890
) {
    val isAlert: Boolean get() = status != ConveyorState.RUNNING || motorTempC > 55f || utilisationPct > 92
}

class ConveyorEngine {
    private val _conveyors = mutableListOf<ConveyorSegment>()

    init {
        seedConveyors()
    }

    fun getAllConveyors(): List<ConveyorSegment> = _conveyors.toList()

    fun getConveyor(id: String): ConveyorSegment? = _conveyors.find { it.id == id }

    fun updateStatus(id: String, state: ConveyorState, speed: Float? = null) {
        val idx = _conveyors.indexOfFirst { it.id == id }
        if (idx != -1) {
            val c = _conveyors[idx]
            _conveyors[idx] = c.copy(
                status = state,
                speedMps = speed ?: c.speedMps
            )
        }
    }

    fun getAverageUtilisation(): Int {
        if (_conveyors.isEmpty()) return 0
        return _conveyors.map { it.utilisationPct }.average().toInt()
    }

    fun stepSimulation() {
        for (i in _conveyors.indices) {
            val c = _conveyors[i]
            if (c.status == ConveyorState.RUNNING) {
                val variation = (-3..3).random()
                val newPackages = (c.currentPackages + variation).coerceIn(10, c.capacity)
                val newUtil = ((newPackages.toFloat() / c.capacity) * 100).toInt()
                val newItemsPerMin = (c.itemsPerMinute + (-2..2).random()).coerceIn(40, 140)
                _conveyors[i] = c.copy(
                    currentPackages = newPackages,
                    utilisationPct = newUtil,
                    itemsPerMinute = newItemsPerMin,
                    totalPackagesShift = c.totalPackagesShift + 2
                )
            }
        }
    }

    private fun seedConveyors() {
        val sample = listOf(
            ConveyorSegment("C-101", "Main Infeed Line 1", "Pick Zone A", 2.5f, "North-South", 150, 95, 41.5f, ConveyorState.RUNNING, 110, 82),
            ConveyorSegment("C-102", "Cross-Dock Trunk A", "Central Spine", 2.8f, "East-West", 200, 160, 48.2f, ConveyorState.RUNNING, 145, 88),
            ConveyorSegment("C-103", "Pack Sorter Merge", "Pack Zone", 2.2f, "West-East", 120, 85, 43.0f, ConveyorState.RUNNING, 92, 79),
            ConveyorSegment("C-104", "Sortation Loop Diverter 14", "Sortation Hub", 3.0f, "Loop Divert", 100, 96, 56.4f, ConveyorState.DEGRADED, 75, 96),
            ConveyorSegment("C-105", "Outbound Dock Spur 11-15", "Outbound Docks", 2.4f, "South to Dock", 180, 110, 39.8f, ConveyorState.RUNNING, 105, 68),
            ConveyorSegment("C-106", "Returns Inspection Infeed", "Inbound Returns", 1.8f, "Inbound", 80, 24, 36.2f, ConveyorState.RUNNING, 35, 30)
        )
        _conveyors.addAll(sample)
    }
}
