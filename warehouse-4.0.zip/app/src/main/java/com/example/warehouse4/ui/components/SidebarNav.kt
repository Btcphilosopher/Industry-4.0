package com.example.warehouse4.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Inbox
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PrecisionManufacturing
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkBorderSubtle
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.PrimaryOrange
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.warehouse4.ui.NavigationScreen

data class NavItem(
    val screen: NavigationScreen,
    val label: String,
    val icon: ImageVector,
    val badge: String? = null
)

@Composable
fun SidebarNav(
    currentScreen: NavigationScreen,
    onNavigate: (NavigationScreen) -> Unit,
    modifier: Modifier = Modifier
) {
    val navItems = listOf(
        NavItem(NavigationScreen.OVERVIEW, "Overview", Icons.Default.Dashboard),
        NavItem(NavigationScreen.OPERATIONS, "Operations", Icons.Default.Speed),
        NavItem(NavigationScreen.DIGITAL_TWIN, "Digital Twin", Icons.Default.GridView),
        NavItem(NavigationScreen.INVENTORY, "Inventory", Icons.Default.Category),
        NavItem(NavigationScreen.ROBOTICS, "Robotics", Icons.Default.PrecisionManufacturing, "1,204"),
        NavItem(NavigationScreen.CONVEYORS, "Conveyors", Icons.Default.Engineering),
        NavItem(NavigationScreen.ORDERS, "Orders", Icons.Default.Inbox, "182k"),
        NavItem(NavigationScreen.PACKING, "Packing", Icons.Default.FactCheck),
        NavItem(NavigationScreen.SHIPPING, "Shipments", Icons.Default.LocalShipping),
        NavItem(NavigationScreen.WORKFORCE, "Workforce", Icons.Default.People),
        NavItem(NavigationScreen.SIMULATION, "Simulation", Icons.Default.Gamepad),
        NavItem(NavigationScreen.OPTIMISATION, "Optimisation", Icons.Default.Tune),
        NavItem(NavigationScreen.AI_ASSISTANT, "AI Operations", Icons.Default.AutoAwesome, "AI"),
        NavItem(NavigationScreen.ANALYTICS, "Analytics", Icons.Default.ShowChart),
        NavItem(NavigationScreen.ADMIN_AUDIT, "Security & Audit", Icons.Default.Shield)
    )

    Surface(
        color = DarkSurface,
        modifier = modifier
            .width(190.dp)
            .fillMaxHeight()
            .border(1.dp, DarkBorder, RoundedCornerShape(0.dp))
    ) {
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .padding(vertical = 10.dp, horizontal = 8.dp)
        ) {
            Text(
                text = "SYSTEM MODULES",
                color = TextTertiary,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
            )

            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                navItems.forEach { item ->
                    val isSelected = item.screen == currentScreen
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(34.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(
                                if (isSelected) DarkSurfaceElevated else Color.Transparent
                            )
                            .then(
                                if (isSelected) Modifier.border(1.dp, PrimaryOrange.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                                else Modifier
                            )
                            .clickable { onNavigate(item.screen) }
                            .padding(horizontal = 8.dp)
                            .testTag("nav_item_${item.screen.name.lowercase()}")
                    ) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.label,
                            tint = if (isSelected) PrimaryOrange else TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = item.label,
                            color = if (isSelected) TextPrimary else TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                            modifier = Modifier.weight(1f)
                        )
                        if (item.badge != null) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(
                                        if (isSelected) PrimaryOrange.copy(alpha = 0.2f) else DarkSurfaceVariant
                                    )
                                    .padding(horizontal = 5.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = item.badge,
                                    color = if (isSelected) PrimaryOrange else TextTertiary,
                                    fontSize = 8.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // Bottom Warehouse site info card
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                color = DarkSurfaceElevated,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, DarkBorderSubtle, RoundedCornerShape(6.dp))
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "NODE STATUS",
                            color = TextTertiary,
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Box(
                            modifier = Modifier
                                .size(5.dp)
                                .clip(CircleShape)
                                .background(AccentGreen)
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "LGB8 • AWS US-WEST-2",
                        color = TextPrimary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "UPTIME: 99.998%",
                        color = AccentCyan,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

