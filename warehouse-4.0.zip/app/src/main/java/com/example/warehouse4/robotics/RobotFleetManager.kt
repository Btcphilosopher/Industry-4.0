package com.example.warehouse4.robotics

import java.util.UUID

enum class RobotStatus {
    IDLE,
    MOVING,
    PICKING,
    LOADING,
    UNLOADING,
    CHARGING,
    WAITING,
    BLOCKED,
    FAULT,
    MAINTENANCE
}

data class RobotUnit(
    val id: String, // e.g. R-101
    val name: String,
    val posX: Float, // 0.0 to 100.0 relative grid coordinate
    val posY: Float,
    val posZ: Float = 0f,
    val targetX: Float,
    val targetY: Float,
    val velocityMps: Float = 1.6f, // meters per second
    val batteryPct: Int = 92,
    val loadKg: Float = 0f,
    val maxLoadKg: Float = 500f,
    val currentTaskId: String? = null,
    val currentDestination: String = "Pick Zone A",
    val status: RobotStatus = RobotStatus.MOVING,
    val temperatureC: Float = 34.5f,
    val errorState: String? = null,
    val healthScorePct: Int = 98,
    val travelHistoryMeters: Float = 1420f,
    val hoursInService: Float = 412.5f
) {
    val isLowBattery: Boolean get() = batteryPct <= 25
    val isNeedsMaintenance: Boolean get() = healthScorePct < 80 || temperatureC > 48f || status == RobotStatus.FAULT
}

class RobotFleetManager {
    private val _robots = mutableListOf<RobotUnit>()

    init {
        seedInitialFleet()
    }

    fun getAllRobots(): List<RobotUnit> = _robots.toList()

    fun getRobot(id: String): RobotUnit? = _robots.find { it.id == id }

    fun getActiveCount(): Int = _robots.count { it.status != RobotStatus.FAULT && it.status != RobotStatus.MAINTENANCE }

    fun getFleetUtilization(): Int {
        val total = _robots.size
        if (total == 0) return 0
        val working = _robots.count { it.status == RobotStatus.MOVING || it.status == RobotStatus.PICKING || it.status == RobotStatus.LOADING || it.status == RobotStatus.UNLOADING }
        return ((working.toFloat() / total) * 100).toInt()
    }

    fun updateRobotStatus(id: String, status: RobotStatus, task: String? = null, dest: String? = null) {
        val index = _robots.indexOfFirst { it.id == id }
        if (index != -1) {
            val r = _robots[index]
            _robots[index] = r.copy(
                status = status,
                currentTaskId = task ?: r.currentTaskId,
                currentDestination = dest ?: r.currentDestination
            )
        }
    }

    fun stepSimulation(deltaSec: Float = 1.0f) {
        for (i in _robots.indices) {
            val r = _robots[i]
            when (r.status) {
                RobotStatus.MOVING -> {
                    val dx = r.targetX - r.posX
                    val dy = r.targetY - r.posY
                    val dist = kotlin.math.sqrt(dx * dx + dy * dy)
                    if (dist < 1.0f) {
                        // Reached target -> transition to picking, unloading, or idle
                        val nextStatus = if (r.loadKg > 0) RobotStatus.UNLOADING else RobotStatus.PICKING
                        _robots[i] = r.copy(posX = r.targetX, posY = r.targetY, status = nextStatus)
                    } else {
                        val step = (r.velocityMps * 0.4f * deltaSec).coerceAtMost(dist)
                        val nx = r.posX + (dx / dist) * step
                        val ny = r.posY + (dy / dist) * step
                        val newBattery = (r.batteryPct - (if (r.loadKg > 0) 1 else 0)).coerceAtLeast(1)
                        _robots[i] = r.copy(posX = nx, posY = ny, batteryPct = newBattery)
                    }
                }
                RobotStatus.PICKING -> {
                    // simulate picking action complete -> transition to moving to pack zone
                    _robots[i] = r.copy(
                        status = RobotStatus.MOVING,
                        loadKg = 45f,
                        targetX = (55..85).random().toFloat(),
                        targetY = (20..40).random().toFloat(),
                        currentDestination = "Pack Zone"
                    )
                }
                RobotStatus.UNLOADING -> {
                    _robots[i] = r.copy(
                        status = RobotStatus.IDLE,
                        loadKg = 0f,
                        targetX = (15..45).random().toFloat(),
                        targetY = (50..80).random().toFloat(),
                        currentDestination = "Storage Zone B"
                    )
                }
                RobotStatus.IDLE -> {
                    // assign new task
                    if (r.isLowBattery) {
                        _robots[i] = r.copy(
                            status = RobotStatus.MOVING,
                            targetX = (55..75).random().toFloat(),
                            targetY = (70..85).random().toFloat(),
                            currentDestination = "Charging Station"
                        )
                    } else {
                        _robots[i] = r.copy(
                            status = RobotStatus.MOVING,
                            targetX = (15..40).random().toFloat(),
                            targetY = (15..45).random().toFloat(),
                            currentDestination = "Pick Zone A"
                        )
                    }
                }
                RobotStatus.CHARGING -> {
                    val charged = (r.batteryPct + 5).coerceAtMost(100)
                    val nextStatus = if (charged >= 95) RobotStatus.IDLE else RobotStatus.CHARGING
                    _robots[i] = r.copy(batteryPct = charged, status = nextStatus)
                }
                else -> {}
            }
        }
    }

    private fun seedInitialFleet() {
        val sampleRobots = listOf(
            RobotUnit("R-101", "Titan Drive 101", 22f, 28f, 0f, 25f, 30f, 1.8f, 94, 0f, 500f, "TASK-P102", "Pick Zone A", RobotStatus.MOVING, 33.2f, null, 99, 1540f, 320f),
            RobotUnit("R-102", "Hercules Pod 102", 28f, 32f, 0f, 65f, 25f, 1.6f, 88, 75f, 500f, "TASK-T204", "Pack Zone", RobotStatus.MOVING, 36.4f, null, 98, 2180f, 410f),
            RobotUnit("R-103", "Titan Drive 103", 35f, 22f, 0f, 35f, 22f, 0.0f, 96, 0f, 500f, "TASK-P105", "Pick Zone A", RobotStatus.PICKING, 32.1f, null, 100, 940f, 180f),
            RobotUnit("R-104", "Hercules Pod 104", 62f, 26f, 0f, 62f, 26f, 0.0f, 82, 60f, 500f, "TASK-U301", "Pack Zone", RobotStatus.UNLOADING, 38.0f, null, 96, 3100f, 580f),
            RobotUnit("R-105", "Titan Drive 105", 68f, 78f, 0f, 68f, 78f, 0.0f, 24, 0f, 500f, "TASK-C004", "Charging Station", RobotStatus.CHARGING, 35.8f, null, 95, 4200f, 810f),
            RobotUnit("R-106", "Hercules Pod 106", 42f, 65f, 0f, 20f, 25f, 1.7f, 91, 0f, 500f, "TASK-P110", "Pick Zone A", RobotStatus.MOVING, 33.0f, null, 99, 1820f, 340f),
            RobotUnit("R-107", "Titan Drive 107", 30f, 72f, 0f, 70f, 30f, 1.5f, 85, 120f, 500f, "TASK-T212", "Pack Zone", RobotStatus.MOVING, 37.1f, null, 97, 2650f, 490f),
            RobotUnit("R-108", "Hercules Pod 108", 25f, 60f, 0f, 25f, 60f, 0.0f, 78, 0f, 500f, "TASK-P118", "Storage Zone B", RobotStatus.PICKING, 34.2f, null, 98, 1950f, 360f),
            RobotUnit("R-109", "Titan Drive 109", 58f, 75f, 0f, 58f, 75f, 0.0f, 18, 0f, 500f, "TASK-C008", "Charging Station", RobotStatus.CHARGING, 36.5f, null, 92, 4800f, 920f),
            RobotUnit("R-110", "Atlas Carrier 110", 38f, 38f, 0f, 40f, 40f, 0.0f, 64, 0f, 500f, null, "Storage Zone B", RobotStatus.BLOCKED, 39.8f, "Obstacle Aisle 14", 84, 3890f, 740f),
            RobotUnit("R-111", "Titan Drive 111", 18f, 35f, 0f, 25f, 20f, 1.6f, 95, 0f, 500f, "TASK-P124", "Pick Zone A", RobotStatus.MOVING, 31.9f, null, 100, 820f, 150f),
            RobotUnit("R-112", "Atlas Carrier 112", 72f, 32f, 0f, 72f, 32f, 0.0f, 89, 40f, 500f, "TASK-U315", "Pack Zone", RobotStatus.UNLOADING, 35.1f, null, 99, 1400f, 260f)
        )
        _robots.addAll(sampleRobots)
    }
}
