package com.example.warehouse4.inventory

import java.util.UUID

enum class VelocityGrade {
    A, // Fast moving (Top 20% volume)
    B, // Medium moving
    C  // Slow moving
}

enum class SkuStatus {
    IN_STOCK,
    LOW_STOCK,
    OUT_OF_STOCK,
    DAMAGED_HOLD,
    RETURNS_INSPECT
}

data class SkuItem(
    val sku: String, // ASIN or SKU code
    val title: String,
    val category: String,
    val quantity: Int,
    val locationCode: String, // e.g. Z1-A14-S03-B02
    val zone: String,
    val binId: String,
    val toteId: String? = null,
    val palletId: String? = null,
    val batchNumber: String,
    val reorderPoint: Int,
    val safetyStock: Int,
    val velocityGrade: VelocityGrade,
    val demandRatePerDay: Int,
    val unitWeightKg: Float,
    val lengthCm: Float,
    val widthCm: Float,
    val heightCm: Float,
    val ageDays: Int,
    val status: SkuStatus = SkuStatus.IN_STOCK
) {
    val isLowStock: Boolean get() = quantity <= reorderPoint
}

class InventoryEngine {
    private val _inventory = mutableMapOf<String, SkuItem>()

    init {
        seedInitialInventory()
    }

    fun getAllSkus(): List<SkuItem> = _inventory.values.toList()

    fun getSku(sku: String): SkuItem? = _inventory[sku]

    fun updateQuantity(sku: String, delta: Int): SkuItem? {
        val current = _inventory[sku] ?: return null
        val newQty = (current.quantity + delta).coerceAtLeast(0)
        val newStatus = when {
            newQty == 0 -> SkuStatus.OUT_OF_STOCK
            newQty <= current.reorderPoint -> SkuStatus.LOW_STOCK
            else -> SkuStatus.IN_STOCK
        }
        val updated = current.copy(quantity = newQty, status = newStatus)
        _inventory[sku] = updated
        return updated
    }

    fun relocateSku(sku: String, newLocation: String, newZone: String): SkuItem? {
        val current = _inventory[sku] ?: return null
        val updated = current.copy(locationCode = newLocation, zone = newZone)
        _inventory[sku] = updated
        return updated
    }

    fun getFastMovingSkus(topN: Int = 10): List<SkuItem> {
        return _inventory.values
            .sortedByDescending { it.demandRatePerDay }
            .take(topN)
    }

    private fun seedInitialInventory() {
        val sampleSkus = listOf(
            SkuItem("B08XYZ101", "Echo Smart Hub Gen 5", "Electronics", 1450, "Z1-A02-S01-B04", "Pick Zone A", "BIN-102", null, "PLT-401", "BAT-2026-A", 300, 150, VelocityGrade.A, 420, 0.45f, 15f, 15f, 10f, 12),
            SkuItem("B09KLP204", "Kindle Paperwhite 16GB", "Electronics", 2890, "Z1-A03-S02-B01", "Pick Zone A", "BIN-108", null, "PLT-402", "BAT-2026-B", 400, 200, VelocityGrade.A, 580, 0.22f, 17f, 12f, 2f, 8),
            SkuItem("B07MRW339", "Ergonomic Mechanical Keyboard", "Computing", 620, "Z2-B05-S03-B02", "Storage Zone B", "BIN-214", null, "PLT-408", "BAT-2026-C", 150, 80, VelocityGrade.B, 110, 1.10f, 45f, 16f, 4f, 25),
            SkuItem("B01N2V875", "Robotic Vacuum HEPA Filter 4PK", "Home Care", 185, "Z2-B08-S01-B03", "Storage Zone B", "BIN-220", null, "PLT-410", "BAT-2026-D", 250, 100, VelocityGrade.A, 310, 0.18f, 12f, 10f, 3f, 40, SkuStatus.LOW_STOCK),
            SkuItem("B03QRT991", "Industrial Grade Barcode Scanner", "Logistics Tech", 45, "Z2-B12-S04-B01", "Storage Zone B", "BIN-235", null, "PLT-415", "BAT-2026-E", 50, 25, VelocityGrade.C, 15, 0.65f, 20f, 10f, 8f, 60, SkuStatus.LOW_STOCK),
            SkuItem("B08VBB401", "Ultra Soft Cotton Bath Towels", "Home & Living", 3400, "Z3-C01-S01-B01", "Storage Zone B", "BIN-302", null, "PLT-422", "BAT-2026-F", 500, 250, VelocityGrade.A, 490, 0.85f, 35f, 25f, 15f, 5),
            SkuItem("B04KSS712", "Wireless ANC Headphones Pro", "Electronics", 1980, "Z1-A01-S01-B02", "Pick Zone A", "BIN-101", null, "PLT-403", "BAT-2026-G", 350, 180, VelocityGrade.A, 620, 0.35f, 22f, 18f, 7f, 3),
            SkuItem("B06PLM882", "Cast Iron Skillet Pre-Seasoned 12in", "Kitchen", 410, "Z3-C07-S02-B04", "Storage Zone B", "BIN-318", null, "PLT-430", "BAT-2026-H", 120, 60, VelocityGrade.B, 85, 3.40f, 48f, 32f, 8f, 30),
            SkuItem("B02WWX554", "Thermal Shipping Label Rolls 6PK", "Packaging Supplies", 5200, "Z1-A04-S04-B01", "Pick Zone A", "BIN-115", null, "PLT-404", "BAT-2026-I", 800, 400, VelocityGrade.A, 890, 1.20f, 20f, 15f, 12f, 2),
            SkuItem("B05ZZK118", "Precision Screwdriver Toolkit 64pc", "Tools & Hardware", 870, "Z2-B09-S02-B02", "Storage Zone B", "BIN-224", null, "PLT-418", "BAT-2026-J", 200, 100, VelocityGrade.B, 140, 0.55f, 22f, 12f, 5f, 18)
        )
        sampleSkus.forEach { _inventory[it.sku] = it }
    }
}
