package com.example.warehouse4.simulation

data class SimulationParameters(
    val totalRobots: Int = 500,
    val totalWorkers: Int = 188,
    val orderVolumePerHour: Int = 18000,
    val conveyorSpeedMps: Float = 2.5f,
    val packingStationsActive: Int = 40,
    val loadingDocksActive: Int = 5,
    val isAisle14Blocked: Boolean = false,
    val isHighVelocityRelocated: Boolean = false
)

data class SimulationKpiResult(
    val ordersPerHour: Int,
    val unitsShippedPerHour: Int,
    val avgPickTimeMinutes: Float,
    val robotUtilisationPct: Int,
    val workerUtilisationPct: Int,
    val conveyorUtilisationPct: Int,
    val packingUtilisationPct: Int,
    val dockUtilisationPct: Int,
    val energyKwhPerHour: Float,
    val missedDeadlinesPerHour: Int
)

data class ScenarioComparison(
    val scenarioName: String,
    val description: String,
    val baseline: SimulationKpiResult,
    val scenario: SimulationKpiResult
) {
    val throughputDelta: Int get() = scenario.ordersPerHour - baseline.ordersPerHour
    val throughputPctChange: Float get() = ((throughputDelta.toFloat() / baseline.ordersPerHour) * 100f)

    val robotUtilDelta: Int get() = scenario.robotUtilisationPct - baseline.robotUtilisationPct
    val pickTimeDelta: Float get() = scenario.avgPickTimeMinutes - baseline.avgPickTimeMinutes
    val missedDeadlinesDelta: Int get() = scenario.missedDeadlinesPerHour - baseline.missedDeadlinesPerHour
}

class SimulationEngine {
    fun runDiscreteEventSimulation(params: SimulationParameters): SimulationKpiResult {
        // Deterministic simulation model calculations
        val robotFactor = (params.totalRobots.toFloat() / 500f).coerceIn(0.5f, 2.5f)
        val workerFactor = (params.totalWorkers.toFloat() / 188f).coerceIn(0.5f, 2.0f)
        val conveyorFactor = (params.conveyorSpeedMps / 2.5f).coerceIn(0.6f, 1.6f)
        val packFactor = (params.packingStationsActive.toFloat() / 40f).coerceIn(0.5f, 2.0f)
        val dockFactor = (params.loadingDocksActive.toFloat() / 5f).coerceIn(0.4f, 2.0f)
        val slottingBonus = if (params.isHighVelocityRelocated) 1.15f else 1.0f
        val obstaclePenalty = if (params.isAisle14Blocked) 0.88f else 1.0f

        // System bottleneck calculation
        val effectiveCapacity = (18000f * kotlin.math.min(
            robotFactor * slottingBonus * obstaclePenalty,
            kotlin.math.min(workerFactor * packFactor, conveyorFactor * dockFactor)
        )).toInt()

        val demand = params.orderVolumePerHour
        val actualOrders = kotlin.math.min(effectiveCapacity, demand)
        val unitsShipped = (actualOrders * 1.85f).toInt()
        val pickTime = ((2.4f / (slottingBonus * obstaclePenalty)) * (1.0f + (demand.toFloat() / 25000f) * 0.3f)).coerceIn(1.2f, 6.5f)

        val robotUtil = ((actualOrders.toFloat() / (params.totalRobots * 38f)) * 100f).toInt().coerceIn(20, 99)
        val workerUtil = ((actualOrders.toFloat() / (params.totalWorkers * 100f)) * 100f).toInt().coerceIn(30, 98)
        val conveyorUtil = ((actualOrders.toFloat() / (conveyorFactor * 22000f)) * 100f).toInt().coerceIn(25, 99)
        val packingUtil = ((actualOrders.toFloat() / (packFactor * 20000f)) * 100f).toInt().coerceIn(30, 99)
        val dockUtil = ((actualOrders.toFloat() / (dockFactor * 21000f)) * 100f).toInt().coerceIn(20, 99)

        val missedDeadlines = if (actualOrders < demand) ((demand - actualOrders) * 0.12f).toInt() else 0
        val energyKwh = (params.totalRobots * 1.2f + params.totalWorkers * 0.4f + params.conveyorSpeedMps * 80f + 320f)

        return SimulationKpiResult(
            ordersPerHour = actualOrders,
            unitsShippedPerHour = unitsShipped,
            avgPickTimeMinutes = ((pickTime * 10).toInt() / 10f),
            robotUtilisationPct = robotUtil,
            workerUtilisationPct = workerUtil,
            conveyorUtilisationPct = conveyorUtil,
            packingUtilisationPct = packingUtil,
            dockUtilisationPct = dockUtil,
            energyKwhPerHour = energyKwh,
            missedDeadlinesPerHour = missedDeadlines
        )
    }

    fun compareScenarios(baselineParams: SimulationParameters, scenarioParams: SimulationParameters, scenarioName: String, description: String): ScenarioComparison {
        val baseline = runDiscreteEventSimulation(baselineParams)
        val scenario = runDiscreteEventSimulation(scenarioParams)
        return ScenarioComparison(scenarioName, description, baseline, scenario)
    }
}
