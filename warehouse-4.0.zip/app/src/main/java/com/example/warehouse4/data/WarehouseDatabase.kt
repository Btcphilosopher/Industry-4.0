package com.example.warehouse4.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "events")
data class EventEntity(
    @PrimaryKey val id: String,
    val timestamp: Long,
    val eventType: String,
    val sourceId: String,
    val description: String,
    val severity: String
)

@Entity(tableName = "audit_records")
data class AuditEntity(
    @PrimaryKey val id: String,
    val who: String,
    val role: String,
    val what: String,
    val timestamp: Long,
    val why: String,
    val sourceData: String,
    val modelVersion: String,
    val action: String,
    val result: String,
    val isAiGenerated: Boolean
)

@Dao
interface WarehouseDao {
    @Query("SELECT * FROM events ORDER BY timestamp DESC LIMIT 200")
    fun getAllEvents(): Flow<List<EventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvent(event: EventEntity)

    @Query("SELECT * FROM audit_records ORDER BY timestamp DESC LIMIT 200")
    fun getAllAuditRecords(): Flow<List<AuditEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditRecord(record: AuditEntity)
}

@Database(entities = [EventEntity::class, AuditEntity::class], version = 1, exportSchema = false)
abstract class WarehouseDatabase : RoomDatabase() {
    abstract fun warehouseDao(): WarehouseDao

    companion object {
        @Volatile
        private var INSTANCE: WarehouseDatabase? = null

        fun getDatabase(context: Context): WarehouseDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    WarehouseDatabase::class.java,
                    "warehouse4_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
