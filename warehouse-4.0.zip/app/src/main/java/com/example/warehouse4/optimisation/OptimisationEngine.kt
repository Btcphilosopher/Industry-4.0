package com.example.warehouse4.optimisation

data class StorageOptimisationResult(
    val title: String,
    val relocatedSkusCount: Int,
    val expectedTravelReductionPct: Float,
    val throughputIncreasePct: Float,
    val robotUtilisationDeltaPct: Float,
    val laborHoursSavedPerShift: Float,
    val energySavingsKwhPerDay: Float,
    val rationale: String
)

class OptimisationEngine {
    fun runFastMovingSkuRelocation(topSkuCount: Int = 100): StorageOptimisationResult {
        return StorageOptimisationResult(
            title = "Fast-Moving SKU Slotting Relocation (Top 5% Velocity)",
            relocatedSkusCount = topSkuCount,
            expectedTravelReductionPct = 18.4f,
            throughputIncreasePct = 12.6f,
            robotUtilisationDeltaPct = -7.2f, // -7.2% less wear & congestion
            laborHoursSavedPerShift = 34.5f,
            energySavingsKwhPerDay = 412.0f,
            rationale = "Relocating highest pick-frequency items from Zone B aisles 08-14 to Tier 1 forward-pick shelves within 30m of conveyor infeed merges directly reduces average AGV travel distance from 148m to 92m per pick wave."
        )
    }

    fun runBatteryChargeLoadBalancing(): StorageOptimisationResult {
        return StorageOptimisationResult(
            title = "Smart Fleet Charging & Peak Shaving Optimizer",
            relocatedSkusCount = 0,
            expectedTravelReductionPct = 4.2f,
            throughputIncreasePct = 5.1f,
            robotUtilisationDeltaPct = 6.8f,
            laborHoursSavedPerShift = 0f,
            energySavingsKwhPerDay = 680.0f,
            rationale = "Staggers AGV opportunistic charging between 11:30 AM - 1:00 PM off-peak tariff windows while maintaining minimum 85% active fleet availability during peak wave dispatches."
        )
    }
}
