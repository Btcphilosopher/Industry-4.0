package com.example.warehouse4.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.warehouse4.ai.AiOperationsAssistant
import com.example.warehouse4.ai.AiRecommendation
import com.example.warehouse4.analytics.AnalyticsEngine
import com.example.warehouse4.analytics.WarehouseKpiSummary
import com.example.warehouse4.conveyor.ConveyorEngine
import com.example.warehouse4.conveyor.ConveyorSegment
import com.example.warehouse4.conveyor.ConveyorState
import com.example.warehouse4.core.AuditRecord
import com.example.warehouse4.core.EventSeverity
import com.example.warehouse4.core.EventType
import com.example.warehouse4.core.OperationalMode
import com.example.warehouse4.core.UserProfile
import com.example.warehouse4.core.UserRole
import com.example.warehouse4.core.WarehouseAlert
import com.example.warehouse4.core.WarehouseConfig
import com.example.warehouse4.core.WarehouseEvent
import com.example.warehouse4.data.AuditEntity
import com.example.warehouse4.data.EventEntity
import com.example.warehouse4.data.WarehouseDatabase
import com.example.warehouse4.inventory.InventoryEngine
import com.example.warehouse4.inventory.SkuItem
import com.example.warehouse4.ml.MachineLearningEngine
import com.example.warehouse4.optimisation.OptimisationEngine
import com.example.warehouse4.optimisation.StorageOptimisationResult
import com.example.warehouse4.orders.CustomerOrder
import com.example.warehouse4.orders.OrderEngine
import com.example.warehouse4.orders.OrderStatus
import com.example.warehouse4.packing.CartonType
import com.example.warehouse4.packing.PackingOptimizer
import com.example.warehouse4.packing.PackingResult
import com.example.warehouse4.robotics.RobotFleetManager
import com.example.warehouse4.robotics.RobotStatus
import com.example.warehouse4.robotics.RobotUnit
import com.example.warehouse4.shipping.DockBay
import com.example.warehouse4.shipping.DockManager
import com.example.warehouse4.simulation.ScenarioComparison
import com.example.warehouse4.simulation.SimulationEngine
import com.example.warehouse4.simulation.SimulationParameters
import com.example.warehouse4.workforce.WorkforceEngine
import com.example.warehouse4.workforce.WorkstationZone
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class NavigationScreen {
    OVERVIEW,
    OPERATIONS,
    DIGITAL_TWIN,
    INVENTORY,
    ROBOTICS,
    CONVEYORS,
    ORDERS,
    PACKING,
    SHIPPING,
    WORKFORCE,
    SIMULATION,
    OPTIMISATION,
    AI_ASSISTANT,
    ANALYTICS,
    ADMIN_AUDIT
}

enum class HeatmapType {
    NONE_3D,
    ROBOT_TRAFFIC,
    CONGESTION,
    SKU_VELOCITY,
    ENERGY
}

data class WarehouseUiState(
    val currentScreen: NavigationScreen = NavigationScreen.OVERVIEW,
    val operationalMode: OperationalMode = OperationalMode.LIVE_OPERATIONS,
    val simulationSpeed: Float = 1.0f,
    val isSimulationRunning: Boolean = true,
    val config: WarehouseConfig = WarehouseConfig(),
    val currentUser: UserProfile = UserProfile(),
    val kpiSummary: WarehouseKpiSummary = WarehouseKpiSummary(),
    val robots: List<RobotUnit> = emptyList(),
    val conveyors: List<ConveyorSegment> = emptyList(),
    val docks: List<DockBay> = emptyList(),
    val orders: List<CustomerOrder> = emptyList(),
    val skus: List<SkuItem> = emptyList(),
    val alerts: List<WarehouseAlert> = emptyList(),
    val events: List<WarehouseEvent> = emptyList(),
    val auditRecords: List<AuditRecord> = emptyList(),
    val workforceZones: List<WorkstationZone> = emptyList(),
    val heatmapType: HeatmapType = HeatmapType.NONE_3D,
    val isCommandPaletteOpen: Boolean = false,
    val commandQuery: String = "",
    // Detail sheet selections
    val selectedRobot: RobotUnit? = null,
    val selectedConveyor: ConveyorSegment? = null,
    val selectedSku: SkuItem? = null,
    val selectedOrder: CustomerOrder? = null,
    val selectedZoneName: String? = null,
    // What-If Simulation
    val simParams: SimulationParameters = SimulationParameters(),
    val scenarioComparison: ScenarioComparison? = null,
    // Optimisation
    val activeOptimisationResult: StorageOptimisationResult? = null,
    // Packing demo
    val samplePackingResult: PackingResult? = null,
    // AI Assistant
    val aiQuery: String = "",
    val isAiThinking: Boolean = false,
    val aiHistory: List<AiRecommendation> = emptyList()
)

class WarehouseViewModel(application: Application) : AndroidViewModel(application) {
    private val db = WarehouseDatabase.getDatabase(application)
    private val inventoryEngine = InventoryEngine()
    private val orderEngine = OrderEngine()
    private val fleetManager = RobotFleetManager()
    private val conveyorEngine = ConveyorEngine()
    private val dockManager = DockManager()
    private val workforceEngine = WorkforceEngine()
    private val optimisationEngine = OptimisationEngine()
    private val mlEngine = MachineLearningEngine()
    private val simulationEngine = SimulationEngine()
    private val packingOptimizer = PackingOptimizer()
    private val aiAssistant = AiOperationsAssistant()
    private val analyticsEngine = AnalyticsEngine()

    private val _uiState = MutableStateFlow(WarehouseUiState())
    val uiState: StateFlow<WarehouseUiState> = _uiState.asStateFlow()

    private var simLoopJob: Job? = null

    init {
        seedInitialState()
        startSimulationLoop()
    }

    private fun seedInitialState() {
        val initialAlerts = listOf(
            WarehouseAlert(title = "High traffic in Pick Zone A", message = "Aisles 02-06 AGV traffic index reached 84%. Re-routing secondary waves.", severity = EventSeverity.WARNING, sourceModule = "Robotics & Routing", estimatedTimeToImpactMin = 14),
            WarehouseAlert(title = "Robot R2D2-8842 maintenance due", message = "Right drive wheel vibration acoustic metric indicates bearing wear. Schedule servicing.", severity = EventSeverity.DEGRADED, sourceModule = "Predictive Maintenance", estimatedTimeToImpactMin = 90),
            WarehouseAlert(title = "Temperature rising in Zone C", message = "Ambient temperature reading 23.8°C; HVAC compressor speed adjusting.", severity = EventSeverity.WARNING, sourceModule = "Telemetry & HVAC", estimatedTimeToImpactMin = 45),
            WarehouseAlert(title = "Dock 12 shipment delayed", message = "FedEx Outbound truck TRK-9120 delayed by 35 minutes due to apron traffic.", severity = EventSeverity.DEGRADED, sourceModule = "Shipping & Docks", estimatedTimeToImpactMin = 20),
            WarehouseAlert(title = "Low inventory: ASIN B08XYZ101", message = "Echo Smart Hub Gen 5 inventory below reorder point (185 units remaining).", severity = EventSeverity.WARNING, sourceModule = "Inventory Engine", estimatedTimeToImpactMin = 60)
        )

        val initialEvents = listOf(
            WarehouseEvent(eventType = EventType.ROBOT_MOVED, sourceId = "R-102", description = "AGV R-102 transported Tote #4421 to Pack Station 04", severity = EventSeverity.NORMAL),
            WarehouseEvent(eventType = EventType.ITEM_PICKED, sourceId = "STA-PICK-A", description = "SKU B09KLP204 picked for Order ORD-98422", severity = EventSeverity.NORMAL),
            WarehouseEvent(eventType = EventType.CONVEYOR_STARTED, sourceId = "C-101", description = "Main Infeed Line 1 speed set to 2.5 m/s", severity = EventSeverity.NORMAL),
            WarehouseEvent(eventType = EventType.TRUCK_ARRIVED, sourceId = "Dock 11", description = "Inbound Truck TRK-7782 docked at Bay 11", severity = EventSeverity.NORMAL),
            WarehouseEvent(eventType = EventType.SAFETY_INTERLOCK_VERIFIED, sourceId = "Safety-PLC-01", description = "Zone A light curtains & emergency stop circuits operational", severity = EventSeverity.INFO)
        )

        val initialAudits = listOf(
            AuditRecord(who = "Alex Morgan", role = UserRole.OPERATIONS_MANAGER, what = "Slotting Reconfiguration", why = "Reduce pick travel distance", sourceData = "Demand velocity logs (24h)", action = "Relocate top 5% SKUs to Zone A forward shelves", result = "Estimated travel reduction: 18.4%"),
            AuditRecord(who = "Automated WES Engine", role = UserRole.ADMIN, what = "Dynamic Wave Pacing", why = "Carrier SLA cutoff approaching", sourceData = "FedEx Dock 12 countdown", action = "Elevate ORD-98423 to priority rush queue", result = "Order staged at dock 18m before cutoff", isAiGenerated = true),
            AuditRecord(who = "Sarah Chen", role = UserRole.MAINTENANCE, what = "Conveyor Inspection", why = "Acoustic vibration threshold warning", sourceData = "Sensor C-104 vibration feed", action = "Tensioned diverter motor roller belt", result = "Operating temperature stabilized at 43°C")
        )

        val packResult = packingOptimizer.calculateOptimalCarton(
            orderId = "ORD-98423",
            itemLengths = listOf(22f, 20f),
            itemWidths = listOf(18f, 15f),
            itemHeights = listOf(7f, 12f),
            itemWeights = listOf(0.35f, 1.20f),
            isFragile = false
        )

        val baselineParams = SimulationParameters()
        val defaultScenario = simulationEngine.compareScenarios(
            baselineParams,
            baselineParams.copy(orderVolumePerHour = 23400),
            "+30% Order Surge Scenario",
            "Simulates a sudden 30% spike in inbound flash sale orders against baseline equipment limits."
        )

        _uiState.value = _uiState.value.copy(
            robots = fleetManager.getAllRobots(),
            conveyors = conveyorEngine.getAllConveyors(),
            docks = dockManager.getAllDocks(),
            orders = orderEngine.getAllOrders(),
            skus = inventoryEngine.getAllSkus(),
            alerts = initialAlerts,
            events = initialEvents,
            auditRecords = initialAudits,
            workforceZones = workforceEngine.getAllZones(),
            samplePackingResult = packResult,
            scenarioComparison = defaultScenario,
            activeOptimisationResult = optimisationEngine.runFastMovingSkuRelocation()
        )
    }

    private fun startSimulationLoop() {
        simLoopJob?.cancel()
        simLoopJob = viewModelScope.launch {
            while (isActive) {
                if (_uiState.value.isSimulationRunning) {
                    val speed = _uiState.value.simulationSpeed
                    fleetManager.stepSimulation(speed)
                    conveyorEngine.stepSimulation()
                    dockManager.stepSimulation()

                    // Random new live event once in a while
                    val now = System.currentTimeMillis()
                    val robotList = fleetManager.getAllRobots()
                    val randomRobot = robotList.random()
                    val newEvent = WarehouseEvent(
                        timestamp = now,
                        eventType = EventType.ROBOT_MOVED,
                        sourceId = randomRobot.id,
                        description = "Robot ${randomRobot.id} [${randomRobot.status}] at dest: ${randomRobot.currentDestination}",
                        severity = if (randomRobot.status == RobotStatus.FAULT) EventSeverity.CRITICAL else EventSeverity.NORMAL
                    )

                    val updatedEvents = (_uiState.value.events + newEvent).takeLast(250)

                    _uiState.value = _uiState.value.copy(
                        robots = robotList,
                        conveyors = conveyorEngine.getAllConveyors(),
                        docks = dockManager.getAllDocks(),
                        events = updatedEvents
                    )
                }
                delay((1000 / _uiState.value.simulationSpeed).toLong().coerceIn(100L, 2000L))
            }
        }
    }

    fun setScreen(screen: NavigationScreen) {
        _uiState.value = _uiState.value.copy(currentScreen = screen)
    }

    fun setOperationalMode(mode: OperationalMode) {
        _uiState.value = _uiState.value.copy(operationalMode = mode)
    }

    fun setSimulationSpeed(speed: Float) {
        _uiState.value = _uiState.value.copy(simulationSpeed = speed)
    }

    fun toggleSimulation() {
        _uiState.value = _uiState.value.copy(isSimulationRunning = !_uiState.value.isSimulationRunning)
    }

    fun setHeatmapType(type: HeatmapType) {
        _uiState.value = _uiState.value.copy(heatmapType = type)
    }

    fun openCommandPalette(open: Boolean) {
        _uiState.value = _uiState.value.copy(isCommandPaletteOpen = open, commandQuery = if (!open) "" else _uiState.value.commandQuery)
    }

    fun setCommandQuery(query: String) {
        _uiState.value = _uiState.value.copy(commandQuery = query)
    }

    fun selectRobot(robot: RobotUnit?) {
        _uiState.value = _uiState.value.copy(selectedRobot = robot)
    }

    fun selectConveyor(conveyor: ConveyorSegment?) {
        _uiState.value = _uiState.value.copy(selectedConveyor = conveyor)
    }

    fun selectSku(sku: SkuItem?) {
        _uiState.value = _uiState.value.copy(selectedSku = sku)
    }

    fun selectOrder(order: CustomerOrder?) {
        _uiState.value = _uiState.value.copy(selectedOrder = order)
    }

    fun selectZone(zoneName: String?) {
        _uiState.value = _uiState.value.copy(selectedZoneName = zoneName)
    }

    fun executeQuickCommand(command: String) {
        openCommandPalette(false)
        val cmd = command.lowercase()
        when {
            cmd.contains("congestion") || cmd.contains("traffic") -> {
                setScreen(NavigationScreen.DIGITAL_TWIN)
                setHeatmapType(HeatmapType.CONGESTION)
            }
            cmd.contains("find robot") || cmd.contains("robot 104") || cmd.contains("robot") -> {
                setScreen(NavigationScreen.ROBOTICS)
                val targetRobot = _uiState.value.robots.find { it.id.contains("104") } ?: _uiState.value.robots.firstOrNull()
                selectRobot(targetRobot)
            }
            cmd.contains("delayed") || cmd.contains("order") -> {
                setScreen(NavigationScreen.ORDERS)
            }
            cmd.contains("simulate") || cmd.contains("demand") || cmd.contains("surge") -> {
                setScreen(NavigationScreen.SIMULATION)
                runWhatIfScenario("+30% Order Surge", _uiState.value.simParams.copy(orderVolumePerHour = 23400), "Simulate 30% order spike against baseline")
            }
            cmd.contains("fastest") || cmd.contains("sku") -> {
                setScreen(NavigationScreen.INVENTORY)
            }
            cmd.contains("conveyor") || cmd.contains("fault") -> {
                setScreen(NavigationScreen.CONVEYORS)
            }
            cmd.contains("optimis") || cmd.contains("optimiz") -> {
                setScreen(NavigationScreen.OPTIMISATION)
            }
            cmd.contains("ai") || cmd.contains("assistant") -> {
                setScreen(NavigationScreen.AI_ASSISTANT)
            }
            else -> {
                setScreen(NavigationScreen.OVERVIEW)
            }
        }
    }

    fun runWhatIfScenario(name: String, params: SimulationParameters, description: String) {
        val comparison = simulationEngine.compareScenarios(
            SimulationParameters(),
            params,
            name,
            description
        )
        _uiState.value = _uiState.value.copy(
            simParams = params,
            scenarioComparison = comparison
        )
    }

    fun runStorageOptimisation(isFastMoving: Boolean) {
        val result = if (isFastMoving) {
            optimisationEngine.runFastMovingSkuRelocation()
        } else {
            optimisationEngine.runBatteryChargeLoadBalancing()
        }
        val audit = AuditRecord(
            who = _uiState.value.currentUser.name,
            role = _uiState.value.currentUser.role,
            what = result.title,
            why = "Operator triggered optimization suite",
            sourceData = "24-hour velocity and travel logs",
            action = "Recalculated forward-pick slotting assignment",
            result = "Travel reduction: ${result.expectedTravelReductionPct}% | +${result.throughputIncreasePct}% UPH",
            isAiGenerated = false
        )
        _uiState.value = _uiState.value.copy(
            activeOptimisationResult = result,
            auditRecords = listOf(audit) + _uiState.value.auditRecords
        )
    }

    fun submitAiQuestion(query: String) {
        if (query.isBlank()) return
        _uiState.value = _uiState.value.copy(isAiThinking = true, aiQuery = "")

        viewModelScope.launch {
            val context = """
                Site: ${_uiState.value.config.siteCode}
                Active Orders: ${_uiState.value.kpiSummary.ordersToday}
                Active Robots: ${_uiState.value.kpiSummary.robotsActive} (Util: ${_uiState.value.kpiSummary.fleetUtilizationPct}%)
                Inventory Accuracy: ${_uiState.value.kpiSummary.inventoryAccuracyPct}%
                Conveyor Health: ${_uiState.value.conveyors.count { it.status == ConveyorState.RUNNING }} / ${_uiState.value.conveyors.size} operational
                Docks: ${_uiState.value.docks.count { it.status == com.example.warehouse4.shipping.DockStatus.IN_PROGRESS }} active bays
            """.trimIndent()

            val recommendation = aiAssistant.analyzeQuery(query, context)

            _uiState.value = _uiState.value.copy(
                isAiThinking = false,
                aiHistory = listOf(recommendation) + _uiState.value.aiHistory
            )
        }
    }

    fun switchUserRole(newRole: UserRole) {
        _uiState.value = _uiState.value.copy(
            currentUser = _uiState.value.currentUser.copy(
                role = newRole,
                title = when (newRole) {
                    UserRole.ADMIN -> "Systems Super Administrator"
                    UserRole.OPERATIONS_MANAGER -> "Operations Manager"
                    UserRole.WAREHOUSE_MANAGER -> "Warehouse General Manager"
                    UserRole.INVENTORY_MANAGER -> "ICQA Inventory Lead"
                    UserRole.MAINTENANCE -> "Reliability Maintenance Engineer"
                    UserRole.ANALYST -> "Industrial Systems Analyst"
                    UserRole.VIEWER -> "Regional Operations Viewer"
                }
            )
        )
    }

    fun acknowledgeAlert(alertId: String) {
        val updated = _uiState.value.alerts.map {
            if (it.id == alertId) it.copy(isAcknowledged = true) else it
        }
        _uiState.value = _uiState.value.copy(alerts = updated)
    }
}
