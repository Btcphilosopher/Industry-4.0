package com.example.warehouse4.orders

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

enum class OrderPriority {
    SAME_DAY,
    ONE_DAY,
    STANDARD,
    BACKORDER
}

enum class OrderStatus {
    RECEIVED,
    QUEUED,
    WAVE_ASSIGNED,
    PICKING,
    PACKING,
    SORTING,
    STAGED_AT_DOCK,
    SHIPPED,
    CANCELLED
}

data class OrderLine(
    val sku: String,
    val quantity: Int,
    val itemDescription: String,
    val unitPrice: Double
)

data class CustomerOrder(
    val orderId: String,
    val customerRegion: String,
    val lines: List<OrderLine>,
    val priority: OrderPriority,
    val promisedShipTime: Long,
    val carrier: String, // e.g. Amazon Logistics, FedEx Express, UPS Ground, DHL
    val serviceLevel: String, // Next-Day Air, Standard, Prime Same-Day
    val status: OrderStatus = OrderStatus.QUEUED,
    val assignedRobotId: String? = null,
    val assignedPackStation: String? = null,
    val assignedDock: String? = null,
    val waveId: String = "WAVE-2026-09",
    val createdAt: Long = System.currentTimeMillis()
) {
    val totalItems: Int get() = lines.sumOf { it.quantity }
    val isSlaAtRisk: Boolean get() = (promisedShipTime - System.currentTimeMillis()) in 1..(30 * 60 * 1000) // under 30m
    val isDelayed: Boolean get() = (promisedShipTime < System.currentTimeMillis()) && status != OrderStatus.SHIPPED
    val formattedPromisedTime: String
        get() {
            val sdf = SimpleDateFormat("HH:mm a", Locale.getDefault())
            return sdf.format(Date(promisedShipTime))
        }
}

class OrderEngine {
    private val _orders = mutableListOf<CustomerOrder>()

    init {
        seedInitialOrders()
    }

    fun getAllOrders(): List<CustomerOrder> = _orders.toList()

    fun getOrder(orderId: String): CustomerOrder? = _orders.find { it.orderId == orderId }

    fun addOrder(order: CustomerOrder) {
        _orders.add(0, order)
    }

    fun updateOrderStatus(orderId: String, newStatus: OrderStatus, robotId: String? = null, packStation: String? = null, dock: String? = null): CustomerOrder? {
        val index = _orders.indexOfFirst { it.orderId == orderId }
        if (index != -1) {
            val current = _orders[index]
            val updated = current.copy(
                status = newStatus,
                assignedRobotId = robotId ?: current.assignedRobotId,
                assignedPackStation = packStation ?: current.assignedPackStation,
                assignedDock = dock ?: current.assignedDock
            )
            _orders[index] = updated
            return updated
        }
        return null
    }

    fun getOrdersByStatus(): Map<OrderStatus, Int> {
        return _orders.groupBy { it.status }.mapValues { it.value.size }
    }

    fun getDelayedOrdersCount(): Int = _orders.count { it.isDelayed }

    private fun seedInitialOrders() {
        val now = System.currentTimeMillis()
        val sampleOrders = listOf(
            CustomerOrder("ORD-98421", "US-WEST (AZ-PHX)", listOf(OrderLine("B08XYZ101", 1, "Echo Smart Hub Gen 5", 99.99)), OrderPriority.SAME_DAY, now + 45 * 60 * 1000, "Amazon Logistics", "Prime Same-Day", OrderStatus.PICKING, "R-102", "PACK-04", "Dock 12"),
            CustomerOrder("ORD-98422", "US-WEST (CA-LAX)", listOf(OrderLine("B09KLP204", 2, "Kindle Paperwhite 16GB", 149.99)), OrderPriority.ONE_DAY, now + 120 * 60 * 1000, "UPS Ground", "Next-Day Air", OrderStatus.PACKING, "R-108", "PACK-02", "Dock 11"),
            CustomerOrder("ORD-98423", "US-SW (TX-DFW)", listOf(OrderLine("B04KSS712", 1, "Wireless ANC Headphones Pro", 249.00), OrderLine("B02WWX554", 1, "Thermal Shipping Label Rolls 6PK", 24.50)), OrderPriority.SAME_DAY, now + 25 * 60 * 1000, "FedEx Express", "Priority Overnight", OrderStatus.SORTING, "R-115", "PACK-06", "Dock 14"),
            CustomerOrder("ORD-98424", "US-WEST (NV-LAS)", listOf(OrderLine("B07MRW339", 1, "Ergonomic Mechanical Keyboard", 129.99)), OrderPriority.STANDARD, now + 240 * 60 * 1000, "Amazon Logistics", "Standard 2-Day", OrderStatus.QUEUED, null, null, "Dock 15"),
            CustomerOrder("ORD-98425", "US-NW (WA-SEA)", listOf(OrderLine("B08VBB401", 3, "Ultra Soft Cotton Bath Towels", 39.99)), OrderPriority.ONE_DAY, now + 90 * 60 * 1000, "DHL Express", "Express Domestic", OrderStatus.WAVE_ASSIGNED, "R-122", null, "Dock 11"),
            CustomerOrder("ORD-98426", "US-WEST (AZ-TUS)", listOf(OrderLine("B01N2V875", 2, "Robotic Vacuum HEPA Filter 4PK", 19.99)), OrderPriority.SAME_DAY, now + 15 * 60 * 1000, "Amazon Logistics", "Prime Same-Day", OrderStatus.STAGED_AT_DOCK, "R-104", "PACK-01", "Dock 12"),
            CustomerOrder("ORD-98427", "US-SW (NM-ABQ)", listOf(OrderLine("B06PLM882", 1, "Cast Iron Skillet Pre-Seasoned 12in", 45.00)), OrderPriority.STANDARD, now + 360 * 60 * 1000, "UPS Ground", "Standard Ground", OrderStatus.SHIPPED, "R-110", "PACK-05", "Dock 13"),
            CustomerOrder("ORD-98428", "US-WEST (UT-SLC)", listOf(OrderLine("B05ZZK118", 1, "Precision Screwdriver Toolkit 64pc", 34.50)), OrderPriority.ONE_DAY, now + 150 * 60 * 1000, "FedEx Express", "2-Day Express", OrderStatus.QUEUED, null, null, "Dock 14")
        )
        _orders.addAll(sampleOrders)
    }
}
