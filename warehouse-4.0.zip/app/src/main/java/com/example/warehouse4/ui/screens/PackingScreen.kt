package com.example.warehouse4.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.AccentTeal
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.PrimaryOrange
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.warehouse4.ui.WarehouseUiState
import com.example.warehouse4.ui.WarehouseViewModel

@Composable
fun PackingScreen(
    uiState: WarehouseUiState,
    viewModel: WarehouseViewModel,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Surface(
            color = DarkSurface,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, DarkBorder, RoundedCornerShape(10.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.FactCheck, contentDescription = null, tint = PrimaryOrange)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("3D Packing Optimization & Box Selection Engine", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text("Volumetric Efficiency • Dunnage Minimization • Fragility Protection", color = TextTertiary, fontSize = 11.sp)
                    }
                }
            }
        }

        uiState.samplePackingResult?.let { res ->
            Surface(
                color = DarkSurface,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, DarkBorder, RoundedCornerShape(10.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = AccentGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Optimal Packaging Selected for Order ${res.orderId}", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Divider(color = DarkBorder)
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Recommended Carton Box", color = TextTertiary, fontSize = 11.sp)
                            Text("${res.selectedCarton.name} (${res.selectedCarton.id})", color = PrimaryOrange, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("Dimensions: ${res.selectedCarton.lengthCm} x ${res.selectedCarton.widthCm} x ${res.selectedCarton.heightCm} cm", color = TextSecondary, fontSize = 12.sp)
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text("Void Space Efficiency", color = TextTertiary, fontSize = 11.sp)
                            Text("${String.format("%.1f", res.voidSpacePct)}% Void Ratio", color = AccentTeal, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("Dunnage: ${res.dunnageRequired}", color = TextSecondary, fontSize = 12.sp)
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text("Total Shipping Weight", color = TextTertiary, fontSize = 11.sp)
                            Text("${String.format("%.2f", res.totalWeightKg)} kg", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("Arrangement: ${res.arrangement}", color = TextSecondary, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
