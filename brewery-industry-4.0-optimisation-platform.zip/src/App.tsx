import React, { useState, useEffect } from "react";
import { Header } from "./components/Header";
import { DigitalBreweryMap } from "./components/DigitalBreweryMap";
import { PlantOverviewView } from "./components/views/PlantOverviewView";
import { BrewingProcessView } from "./components/views/BrewingProcessView";
import { FermentationTwinView } from "./components/views/FermentationTwinView";
import { TanksScheduleView } from "./components/views/TanksScheduleView";
import { EnergyMicrogridView } from "./components/views/EnergyMicrogridView";
import { PackagingOeeView } from "./components/views/PackagingOeeView";
import { CipOptimizationView } from "./components/views/CipOptimizationView";
import { PredictiveMaintenanceView } from "./components/views/PredictiveMaintenanceView";
import { SpcAnalyticsView } from "./components/views/SpcAnalyticsView";
import { MultiObjectiveOptimizerView } from "./components/views/MultiObjectiveOptimizerView";
import { SimulationSandboxView } from "./components/views/SimulationSandboxView";
import { ArchitectureInspectorView } from "./components/views/ArchitectureInspectorView";
import { AiCopilotView } from "./components/views/AiCopilotView";
import { RecommendationModal } from "./components/RecommendationModal";

import {
  initialVessels,
  initialBatches,
  initialEnergyGrid,
  initialSpcMetrics,
  initialEquipment,
  initialPackagingLines,
  initialCipCircuits,
  initialProposals,
  initialArchitectureMetrics,
} from "./data/mockPlantState";
import { Vessel, ActiveBatch, EnergyGridState, OptimizationProposal } from "./types/brewery";

export default function App() {
  const [activeTab, setActiveTab] = useState<string>("overview");
  const [vessels, setVessels] = useState<Vessel[]>(initialVessels);
  const [batches, setBatches] = useState<ActiveBatch[]>(initialBatches);
  const [energyState, setEnergyState] = useState<EnergyGridState>(initialEnergyGrid);
  const [proposals, setProposals] = useState<OptimizationProposal[]>(initialProposals);
  const [activeProposalModal, setActiveProposalModal] = useState<OptimizationProposal | null>(null);
  const [simulationActive, setSimulationActive] = useState<boolean>(false);

  // Background subtle micro-fluctuations simulating 100Hz real-time telemetry
  useEffect(() => {
    const interval = setInterval(() => {
      setVessels((prevVessels) =>
        prevVessels.map((v) => {
          if (v.state === "BOILING") {
            const jitter = (Math.random() - 0.5) * 0.1;
            return { ...v, temperature: Number((100.2 + jitter).toFixed(1)) };
          }
          if (v.state === "HEATING") {
            const jitter = (Math.random() - 0.5) * 0.15;
            return { ...v, temperature: Number((65.4 + jitter).toFixed(1)) };
          }
          return v;
        })
      );
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const handleApproveProposal = (proposalId: string) => {
    setProposals((prev) =>
      prev.map((p) => (p.id === proposalId ? { ...p, status: "APPROVED" as const } : p))
    );

    // Apply real-time physical effects
    if (proposalId === "OPT-2026-101") {
      // Wort cooling PHE optimization
      setEnergyState((prev) => ({
        ...prev,
        specificEnergyKwhPerHl: Number((prev.specificEnergyKwhPerHl - 0.2).toFixed(1)),
        heatRecoveryThermalKw: prev.heatRecoveryThermalKw + 42,
      }));
    } else if (proposalId === "OPT-2026-102") {
      // F-04 Diacetyl rest advancement
      setVessels((prev) =>
        prev.map((v) => (v.id === "F-04" ? { ...v, state: "CRASH_COOLING" as const, temperature: 1.0 } : v))
      );
    } else if (proposalId === "OPT-2026-103") {
      // Battery peak shaving
      setEnergyState((prev) => ({
        ...prev,
        batteryPowerFlowKw: -150,
        gridImportKw: Math.max(0, prev.gridImportKw - 60),
      }));
    }
  };

  const handleRejectProposal = (proposalId: string) => {
    setProposals((prev) =>
      prev.map((p) => (p.id === proposalId ? { ...p, status: "REJECTED" as const } : p))
    );
  };

  const handleSelectVesselFromMap = (vessel: Vessel) => {
    if (vessel.type === "FERMENTER") {
      setActiveTab("fermentation");
    } else if (vessel.type === "BRITE_TANK") {
      setActiveTab("tanks");
    } else if (vessel.type === "HOT_LIQUOR_TANK" || vessel.type === "COLD_LIQUOR_TANK") {
      setActiveTab("energy");
    } else {
      setActiveTab("brewing");
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0B0D] text-[#E0E2E6] flex flex-col font-sans selection:bg-[#FF6B00] selection:text-black">
      {/* Industrial Header & Navigation */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        energyState={energyState}
        simulationActive={simulationActive}
        setSimulationActive={setSimulationActive}
        pendingProposalsCount={proposals.filter((p) => p.status === "PENDING_REVIEW").length}
        onOpenOptimizer={() => setActiveTab("optimizer")}
        onRefreshTelemetry={() => {
          setEnergyState((prev) => ({ ...prev, specificEnergyKwhPerHl: 8.3 }));
        }}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-[1750px] w-full mx-auto p-4 sm:p-6 space-y-6">
        {activeTab === "overview" && (
          <PlantOverviewView
            vessels={vessels}
            batches={batches}
            energyState={energyState}
            proposals={proposals}
            onOpenProposal={(p) => setActiveProposalModal(p)}
            onNavigateToTab={(t) => setActiveTab(t)}
          />
        )}

        {activeTab === "map" && (
          <DigitalBreweryMap
            vessels={vessels}
            batches={batches}
            onSelectVessel={handleSelectVesselFromMap}
            onNavigateToTab={(t) => setActiveTab(t)}
          />
        )}

        {activeTab === "brewing" && <BrewingProcessView />}

        {activeTab === "fermentation" && <FermentationTwinView vessels={vessels} />}

        {activeTab === "tanks" && (
          <TanksScheduleView vessels={vessels} batches={batches} onNavigateToTab={(t) => setActiveTab(t)} />
        )}

        {activeTab === "energy" && <EnergyMicrogridView energyState={energyState} />}

        {activeTab === "packaging" && <PackagingOeeView lines={initialPackagingLines} />}

        {activeTab === "cip" && <CipOptimizationView circuits={initialCipCircuits} />}

        {activeTab === "maintenance" && <PredictiveMaintenanceView assets={initialEquipment} />}

        {activeTab === "spc" && <SpcAnalyticsView metrics={initialSpcMetrics} />}

        {activeTab === "optimizer" && (
          <MultiObjectiveOptimizerView
            proposals={proposals}
            onOpenProposal={(p) => setActiveProposalModal(p)}
            onApproveProposal={handleApproveProposal}
            onRejectProposal={handleRejectProposal}
          />
        )}

        {activeTab === "simulation" && <SimulationSandboxView />}

        {activeTab === "architecture" && <ArchitectureInspectorView metrics={initialArchitectureMetrics} />}

        {activeTab === "copilot" && (
          <AiCopilotView vessels={vessels} batches={batches} energyState={energyState} />
        )}
      </main>

      {/* Recommendation Details & Approval Modal */}
      <RecommendationModal
        proposal={activeProposalModal}
        onClose={() => setActiveProposalModal(null)}
        onApprove={handleApproveProposal}
        onReject={handleRejectProposal}
      />

      {/* Bento Grid SCADA Telemetry Footer */}
      <footer className="px-6 py-3 border-t border-[#2D3035] bg-[#121417] flex flex-wrap justify-between items-center text-[10px] font-mono text-[#70757E] gap-2">
        <div className="flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-[#00FF41]"></span>
          <span>&copy; 2026 BREWERY OPTIMISATION CORE — BUILD 4.0.2-RELEASE</span>
        </div>
        <div className="flex items-center gap-4 sm:gap-6">
          <span>LATENCY: <strong className="text-[#00FF41]">12ms</strong></span>
          <span>TELEMETRY: <strong className="text-[#00D1FF]">4.8k msg/s</strong></span>
          <span>PHYSICS DRIFT: <strong className="text-[#00FF41]">0.02%</strong></span>
          <span className="hidden md:inline text-[#FF6B00]">DETERMINISTIC ODE SOLVER</span>
        </div>
      </footer>
    </div>
  );
}
