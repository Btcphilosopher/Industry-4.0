import React from "react";
import {
  Gauge,
  Zap,
  Droplets,
  ShieldCheck,
  Activity,
  Layers,
  Sparkles,
  Sliders,
  Flame,
  AlertTriangle,
  Play,
  RotateCw,
} from "lucide-react";
import { EnergyGridState } from "../types/brewery";

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  energyState: EnergyGridState;
  simulationActive: boolean;
  setSimulationActive: (active: boolean) => void;
  pendingProposalsCount: number;
  onOpenOptimizer: () => void;
  onRefreshTelemetry: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  energyState,
  simulationActive,
  setSimulationActive,
  pendingProposalsCount,
  onOpenOptimizer,
  onRefreshTelemetry,
}) => {
  const tabs = [
    { id: "overview", label: "Plant Overview", icon: Activity },
    { id: "map", label: "Digital Twin P&ID", icon: Layers },
    { id: "brewing", label: "Brewhouse Physics", icon: Flame },
    { id: "fermentation", label: "Fermentation ODE", icon: RotateCw },
    { id: "tanks", label: "Tank Schedule", icon: Sliders },
    { id: "energy", label: "Energy & Microgrid", icon: Zap },
    { id: "packaging", label: "Packaging & OEE", icon: Gauge },
    { id: "cip", label: "CIP Sinner's Circle", icon: Droplets },
    { id: "maintenance", label: "Predictive Health", icon: AlertTriangle },
    { id: "spc", label: "R Analytics & SPC", icon: Activity },
    { id: "optimizer", label: "Pareto Optimizer", icon: Sliders },
    { id: "simulation", label: "What-If Sandbox", icon: Play },
    { id: "architecture", label: "3-Layer Architecture", icon: Layers },
    { id: "copilot", label: "AI Copilot", icon: Sparkles },
  ];

  return (
    <header className="bg-[#121417] border-b border-[#2D3035] text-[#E0E2E6] sticky top-0 z-40 shadow-2xl">
      {/* Top SCADA Status Bar */}
      <div className="max-w-[1750px] mx-auto px-4 sm:px-6 py-3.5 flex flex-wrap items-center justify-between gap-4 border-b border-[#2D3035]">
        {/* Left Branding */}
        <div className="flex items-center gap-3 sm:gap-4">
          <div className="w-10 h-10 bg-[#FF6B00] rounded-sm flex items-center justify-center font-bold text-black text-xl italic shadow-lg shadow-[#FF6B00]/20 select-none">
            B
          </div>
          <div>
            <h1 className="text-sm sm:text-base font-semibold tracking-tight uppercase flex items-center gap-1 sm:gap-2 text-[#E0E2E6]">
              Brewery Industry 4.0
              <span className="text-[#70757E] font-normal hidden sm:inline">
                / Industrial Optimization Platform
              </span>
            </h1>
            <div className="flex items-center gap-3 text-[10px] font-mono text-[#70757E] mt-0.5">
              <span>HARD-SCIENCE DIGITAL TWIN</span>
              <span className="text-[#2D3035]">|</span>
              <span className="text-[#00D1FF]">100Hz TELEMETRY STREAM</span>
            </div>
          </div>
        </div>

        {/* Core Engine Status Indicators (Rust / Python / R / Mode) */}
        <div className="flex items-center flex-wrap gap-3 sm:gap-6">
          <div className="flex items-center gap-2 bg-[#1A1C1E] border border-[#2D3035] px-2.5 py-1 rounded">
            <span className="w-2 h-2 rounded-full bg-[#00FF41] animate-pulse"></span>
            <span className="text-[11px] font-mono uppercase text-[#70757E]">
              Rust Core: <strong className="text-[#00FF41]">Active</strong>
            </span>
          </div>

          <div className="flex items-center gap-2 bg-[#1A1C1E] border border-[#2D3035] px-2.5 py-1 rounded">
            <span className="w-2 h-2 rounded-full bg-[#00FF41]"></span>
            <span className="text-[11px] font-mono uppercase text-[#70757E]">
              Python Engine: <strong className="text-[#00FF41]">Sync</strong>
            </span>
          </div>

          <div className="flex items-center gap-2 bg-[#1A1C1E] border border-[#2D3035] px-2.5 py-1 rounded">
            <span className="w-2 h-2 rounded-full bg-[#00D1FF]"></span>
            <span className="text-[11px] font-mono uppercase text-[#70757E]">
              R Analytics: <strong className="text-[#00D1FF]">Optimizing</strong>
            </span>
          </div>

          <button
            onClick={() => setSimulationActive(!simulationActive)}
            className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest transition cursor-pointer border ${
              simulationActive
                ? "bg-[#FF6B00]/20 text-[#FF6B00] border-[#FF6B00]/50"
                : "bg-[#2D3035] text-[#E0E2E6] border-[#2D3035] hover:border-[#70757E]"
            }`}
          >
            {simulationActive ? "● Sim Active" : "Simulation Mode"}
          </button>
        </div>

        {/* Live Top KPIs Bar */}
        <div className="flex items-center flex-wrap gap-2 text-xs font-mono">
          <div className="flex items-center gap-1.5 bg-[#1A1C1E] border border-[#2D3035] px-2.5 py-1 rounded">
            <span className="text-[#70757E] text-[10px] uppercase">OEE</span>
            <span className="text-[#00FF41] font-bold">91.4%</span>
          </div>

          <div className="flex items-center gap-1.5 bg-[#1A1C1E] border border-[#2D3035] px-2.5 py-1 rounded">
            <Zap className="w-3.5 h-3.5 text-[#FF6B00]" />
            <span className="text-[#70757E] text-[10px] uppercase">Energy</span>
            <span className="text-[#FF6B00] font-bold">
              {energyState.specificEnergyKwhPerHl.toFixed(1)} <span className="text-[10px] text-[#70757E]">kWh/hl</span>
            </span>
          </div>

          <div className="flex items-center gap-1.5 bg-[#1A1C1E] border border-[#2D3035] px-2.5 py-1 rounded">
            <Droplets className="w-3.5 h-3.5 text-[#00D1FF]" />
            <span className="text-[#70757E] text-[10px] uppercase">Water</span>
            <span className="text-[#00D1FF] font-bold">
              {energyState.specificWaterHlPerHl.toFixed(1)} <span className="text-[10px] text-[#70757E]">hl/hl</span>
            </span>
          </div>

          {pendingProposalsCount > 0 && (
            <button
              onClick={onOpenOptimizer}
              className="flex items-center gap-1.5 bg-[#FF6B00] hover:bg-[#FF6B00]/90 text-black px-3 py-1 rounded font-bold uppercase tracking-wider text-[10px] transition cursor-pointer shadow-md shadow-[#FF6B00]/20"
            >
              <Sparkles className="w-3 h-3" />
              <span>{pendingProposalsCount} Recommendations</span>
            </button>
          )}

          <button
            onClick={onRefreshTelemetry}
            title="Sync live telemetry"
            className="p-1.5 text-[#70757E] hover:text-[#E0E2E6] hover:bg-[#1A1C1E] rounded border border-transparent hover:border-[#2D3035] transition cursor-pointer"
          >
            <RotateCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Navigation Tabs in Bento Style */}
      <div className="max-w-[1750px] mx-auto px-4 sm:px-6 overflow-x-auto scrollbar-thin flex items-center gap-1.5 py-2">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded text-xs font-mono tracking-tight whitespace-nowrap transition-all cursor-pointer border ${
                isActive
                  ? "bg-[#1A1C1E] text-[#FF6B00] border-[#FF6B00] font-bold shadow-md shadow-[#FF6B00]/10"
                  : "bg-transparent text-[#70757E] hover:text-[#E0E2E6] hover:bg-[#1A1C1E]/60 border-transparent hover:border-[#2D3035]"
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? "text-[#FF6B00]" : "text-[#70757E]"}`} />
              <span>{tab.label}</span>
              {tab.id === "optimizer" && pendingProposalsCount > 0 && (
                <span className="ml-1 px-1.5 py-0.2 text-[9px] bg-[#FF6B00] text-black font-bold rounded-full">
                  {pendingProposalsCount}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </header>
  );
};
