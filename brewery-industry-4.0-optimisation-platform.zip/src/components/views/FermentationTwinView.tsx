import React, { useState, useMemo } from "react";
import {
  RotateCw,
  Activity,
  Sliders,
  CheckCircle2,
  AlertTriangle,
  Zap,
  Droplets,
  Layers,
  Sparkles,
} from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine,
} from "recharts";
import { Vessel } from "../../types/brewery";
import { simulateFermentationTrajectory } from "../../physics/fermentationModel";

interface FermentationTwinViewProps {
  vessels: Vessel[];
}

export const FermentationTwinView: React.FC<FermentationTwinViewProps> = ({ vessels }) => {
  const fermenters = vessels.filter((v) => v.type === "FERMENTER");
  const [selectedTankId, setSelectedTankId] = useState<string>("F-01");

  // Simulation controls
  const [initialPlato, setInitialPlato] = useState<number>(12.5);
  const [targetFg, setTargetFg] = useState<number>(2.4);
  const [pitchingTempC, setPitchingTempC] = useState<number>(18.0);
  const [strainType, setStrainType] = useState<"LAGER" | "ALE">("ALE");

  const selectedTank = fermenters.find((f) => f.id === selectedTankId) || fermenters[0];

  // ODE Simulation Output
  const simOutput = useMemo(() => {
    return simulateFermentationTrajectory(
      initialPlato,
      pitchingTempC,
      targetFg,
      strainType,
      selectedTank.currentVolumeHl || 250
    );
  }, [initialPlato, pitchingTempC, targetFg, strainType, selectedTank.currentVolumeHl]);

  // Downsample data for chart clarity (every 3 hours)
  const chartData = useMemo(() => {
    return simOutput.trajectory
      .filter((_, idx) => idx % 3 === 0 || idx === simOutput.trajectory.length - 1)
      .map((pt) => ({
        hour: pt.hour,
        gravity: pt.plato,
        abv: pt.ethanolPctAbv,
        yeastBiomass: pt.biomassGramsPerLiter,
        diacetyl: Number((pt.diacetylPpm * 100).toFixed(2)), // Scale for visual visibility
        coolingDutyKw: pt.coolingDutyKw,
        co2RateKgH: pt.co2RateKgPerH,
      }));
  }, [simOutput]);

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <RotateCw className="w-5 h-5 text-purple-400" />
            <h1 className="text-base font-bold font-mono text-slate-100 uppercase tracking-wide">
              FERMENTATION DIGITAL TWIN & KINETIC ODE PREDICTOR
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Coupled non-linear differential equations for biomass growth, substrate consumption, ethanol synthesis,
            diacetyl precursor kinetics, and biological heat generation.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-slate-400">Model Solver:</span>
          <span className="text-purple-400 font-bold bg-slate-950 border border-slate-800 px-3 py-1.5 rounded">
            Runge-Kutta 4th Order ODE
          </span>
        </div>
      </div>

      {/* Fermenter Selector Chips */}
      <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-8 gap-2">
        {fermenters.map((tank) => {
          const isSelected = tank.id === selectedTankId;
          return (
            <button
              key={tank.id}
              onClick={() => setSelectedTankId(tank.id)}
              className={`p-2.5 rounded text-left font-mono text-xs transition cursor-pointer border flex flex-col justify-between ${
                isSelected
                  ? "bg-slate-900 border-purple-400 shadow-md shadow-purple-500/10"
                  : "bg-slate-950 border-slate-800 hover:border-slate-700"
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-200">{tank.id}</span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
              </div>
              <span className="text-[10px] text-slate-400 truncate">{tank.assignedRecipe || "Active"}</span>
              <span className="text-[11px] font-bold text-purple-300">{tank.temperature}°C</span>
            </button>
          );
        })}
      </div>

      {/* Chart & ODE Controls Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Left 2 Cols: Dynamic Kinetic Trajectory Chart */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
            <div>
              <h2 className="text-xs font-mono font-bold text-slate-100 uppercase">
                ODE Kinetic State Trajectory: {selectedTank.id} ({selectedTank.assignedRecipe || "American IPA"})
              </h2>
              <p className="text-[11px] font-mono text-slate-400">
                Tracking dS/dt (Substrate), dX/dt (Yeast Biomass), dE/dt (Ethanol), and Diacetyl Reabsorption
              </p>
            </div>

            <span className="text-xs font-mono text-emerald-400 font-bold bg-slate-950 px-2.5 py-1 rounded border border-slate-800">
              {simOutput.estimatedRemainingHours}h Until Target Attenuation
            </span>
          </div>

          <div className="h-80 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData} margin={{ top: 10, right: 30, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="hour" stroke="#94a3b8" tick={{ fontSize: 11 }} label={{ value: "Hours into Fermentation", position: "insideBottom", offset: -5, fill: "#64748b", fontSize: 10 }} />
                <YAxis stroke="#94a3b8" tick={{ fontSize: 11 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#020617",
                    borderColor: "#334155",
                    fontSize: "12px",
                    fontFamily: "monospace",
                  }}
                />
                <Legend wrapperStyle={{ fontSize: "11px", fontFamily: "monospace", paddingTop: "8px" }} />
                <ReferenceLine x={simOutput.optimalDiacetylRestHour} stroke="#a855f7" strokeDasharray="3 3" label="Diacetyl Rest" />
                <Line type="monotone" dataKey="gravity" stroke="#f59e0b" name="Extract (°Plato)" strokeWidth={2.5} dot={false} />
                <Line type="monotone" dataKey="abv" stroke="#10b981" name="Ethanol (% ABV)" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="yeastBiomass" stroke="#06b6d4" name="Yeast Biomass (g/L)" strokeWidth={1.5} dot={false} />
                <Line type="monotone" dataKey="coolingDutyKw" stroke="#3b82f6" name="Cooling Load (kW)" strokeWidth={1.5} strokeDasharray="4 4" dot={false} />
                <Line type="monotone" dataKey="diacetyl" stroke="#ef4444" name="Diacetyl x100 (ppm)" strokeWidth={1.5} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* ODE Physical Insights */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-[10px] text-slate-500">FINAL FG PREDICTION</span>
              <div className="text-base font-bold text-amber-300">{simOutput.predictedFinalPlato}°P</div>
              <span className="text-[10px] text-emerald-400">Target: {targetFg}°P</span>
            </div>

            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-[10px] text-slate-500">COOLING ENERGY TOTAL</span>
              <div className="text-base font-bold text-cyan-300">{simOutput.coolingEnergyTotalKwh} kWh</div>
              <span className="text-[10px] text-slate-400">Glycol jacket load</span>
            </div>

            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-[10px] text-slate-500">ESTIMATED ABV</span>
              <div className="text-base font-bold text-emerald-400">{simOutput.predictedFinalAbv}%</div>
              <span className="text-[10px] text-slate-400">Apparent: 80.8%</span>
            </div>

            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-[10px] text-slate-500">CO2 RECOVERABLE</span>
              <div className="text-base font-bold text-purple-300">{simOutput.co2RecoverableKg} kg</div>
              <span className="text-[10px] text-emerald-400">Captured for Packaging</span>
            </div>
          </div>
        </div>

        {/* Right Col: ODE Controls & Tank Invariants */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-4 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="border-b border-slate-800 pb-2">
              <h3 className="text-xs font-mono font-bold text-slate-100 uppercase">
                ODE Model Calibration Parameters
              </h3>
              <p className="text-[11px] text-slate-400">Adjust strain kinetics and observe impact in real time</p>
            </div>

            {/* Strain Selector */}
            <div className="space-y-1.5 font-mono text-xs">
              <label className="text-slate-400 text-[11px]">Yeast Strain Kinetics:</label>
              <div className="grid grid-cols-2 gap-1.5">
                {(["ALE", "LAGER"] as const).map((strain) => (
                  <button
                    key={strain}
                    onClick={() => setStrainType(strain)}
                    className={`py-1.5 px-2 rounded text-center text-xs font-bold transition cursor-pointer ${
                      strainType === strain
                        ? "bg-purple-600 text-white shadow-sm"
                        : "bg-slate-950 text-slate-400 border border-slate-800 hover:border-slate-700"
                    }`}
                  >
                    {strain}
                  </button>
                ))}
              </div>
            </div>

            {/* Slider 1: OG */}
            <div className="space-y-1 font-mono text-xs">
              <div className="flex justify-between text-slate-400">
                <span>Original Gravity (OG):</span>
                <span className="text-amber-300 font-bold">{initialPlato}°P</span>
              </div>
              <input
                type="range"
                min={10.0}
                max={20.0}
                step={0.2}
                value={initialPlato}
                onChange={(e) => setInitialPlato(parseFloat(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>

            {/* Slider 2: Pitching Temp */}
            <div className="space-y-1 font-mono text-xs">
              <div className="flex justify-between text-slate-400">
                <span>Pitching Temperature:</span>
                <span className="text-purple-300 font-bold">{pitchingTempC}°C</span>
              </div>
              <input
                type="range"
                min={10}
                max={24}
                step={0.5}
                value={pitchingTempC}
                onChange={(e) => setPitchingTempC(parseFloat(e.target.value))}
                className="w-full accent-purple-500 cursor-pointer"
              />
            </div>

            {/* Selected Tank Valve Status */}
            <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2 font-mono text-xs">
              <div className="text-slate-300 font-bold border-b border-slate-800 pb-1 flex justify-between">
                <span>{selectedTank.id} SCADA ACTUATORS:</span>
                <span className="text-emerald-400">ONLINE</span>
              </div>

              <div className="flex justify-between text-[11px]">
                <span className="text-slate-400">Top/Cone Glycol Valve:</span>
                <span className="text-cyan-300 font-bold">{selectedTank.glycolDutyPct}% DUTY</span>
              </div>
              <div className="flex justify-between text-[11px]">
                <span className="text-slate-400">Spunding Valve Setpoint:</span>
                <span className="text-slate-200 font-bold">{selectedTank.pressureBar} bar</span>
              </div>
              <div className="flex justify-between text-[11px]">
                <span className="text-slate-400">CO2 Recovery Compressor:</span>
                <span className={selectedTank.co2RecoveryActive ? "text-emerald-400 font-bold" : "text-slate-500"}>
                  {selectedTank.co2RecoveryActive ? "CAPTURING (99.98%)" : "VENTED"}
                </span>
              </div>
            </div>
          </div>

          <div className="bg-purple-950/20 border border-purple-500/30 rounded p-2.5 text-xs font-mono text-purple-300">
            <span className="font-bold flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5" /> Tank Turn-Around Advisor:
            </span>
            <p className="text-[11px] text-slate-400 mt-1">{simOutput.tankReleaseRecommendation}</p>
          </div>
        </div>
      </div>
    </div>
  );
};
