import React, { useState } from "react";
import {
  Gauge,
  CheckCircle2,
  AlertTriangle,
  Layers,
  ArrowRight,
  TrendingUp,
  Clock,
  ShieldCheck,
} from "lucide-react";
import { PackagingLineState } from "../../types/brewery";

interface PackagingOeeViewProps {
  lines: PackagingLineState[];
}

export const PackagingOeeView: React.FC<PackagingOeeViewProps> = ({ lines }) => {
  const [selectedLineId, setSelectedLineId] = useState<string>("LINE-CAN-01");
  const selectedLine = lines.find((l) => l.id === selectedLineId) || lines[0];

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Gauge className="w-5 h-5 text-cyan-400" />
            <h1 className="text-base font-bold font-mono text-slate-100 uppercase tracking-wide">
              PACKAGING LINE OPERATIONS & ISO 22400 OEE INTELLIGENCE
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Real-time Overall Equipment Effectiveness (Availability × Performance × Quality), dissolved oxygen (TPO/DO)
            preservation, and micro-stoppage root cause analysis.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-slate-400">Total Plant Packaging OEE:</span>
          <span className="text-emerald-400 font-bold bg-slate-950 border border-slate-800 px-3 py-1.5 rounded">
            91.4% (World-Class)
          </span>
        </div>
      </div>

      {/* Line Selectors */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
        {lines.map((line) => {
          const isSelected = line.id === selectedLineId;
          return (
            <button
              key={line.id}
              onClick={() => setSelectedLineId(line.id)}
              className={`p-4 rounded-lg text-left font-mono transition cursor-pointer border flex flex-col justify-between space-y-3 ${
                isSelected
                  ? "bg-slate-900 border-cyan-400 shadow-md shadow-cyan-500/10"
                  : "bg-slate-950 border-slate-800 hover:border-slate-700"
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-200 text-sm">{line.name}</span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">
                  {line.type}
                </span>
              </div>

              <div>
                <div className="text-xs text-slate-400">{line.currentProduct}</div>
                <div className="text-2xl font-bold text-cyan-300 mt-1">{line.oeePct}% OEE</div>
              </div>

              <div className="grid grid-cols-3 gap-1 text-[11px] text-slate-400 bg-slate-950 p-2 rounded border border-slate-800/80">
                <div>
                  <span className="text-[9px] text-slate-500 block">AVAIL</span>
                  <span className="text-slate-200 font-bold">{line.availabilityPct}%</span>
                </div>
                <div>
                  <span className="text-[9px] text-slate-500 block">PERF</span>
                  <span className="text-slate-200 font-bold">{line.performancePct}%</span>
                </div>
                <div>
                  <span className="text-[9px] text-slate-500 block">QUAL</span>
                  <span className="text-emerald-400 font-bold">{line.qualityPct}%</span>
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Selected Line Deep OEE Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Left 2 Cols: OEE Waterfall & Production Counter */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
            <div>
              <h2 className="text-xs font-mono font-bold text-slate-100 uppercase">
                {selectedLine.name} OEE Waterfall Loss Tree
              </h2>
              <p className="text-[11px] font-mono text-slate-400">
                Target Speed: {selectedLine.targetSpeedUnitsPerHour.toLocaleString()} units/h | Actual:{" "}
                {selectedLine.actualSpeedUnitsPerHour.toLocaleString()} units/h
              </p>
            </div>
            <span className="text-xs font-mono text-emerald-400 font-bold">
              {selectedLine.totalProducedUnits.toLocaleString()} Units Packaged Today
            </span>
          </div>

          {/* 3 Pillars Visual */}
          <div className="space-y-3 font-mono text-xs">
            {/* Availability */}
            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-300">1. Operational Availability (Uptime vs Planned):</span>
                <span className="text-cyan-300 font-bold">{selectedLine.availabilityPct}%</span>
              </div>
              <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden">
                <div
                  className="h-full bg-cyan-500 rounded-full"
                  style={{ width: `${selectedLine.availabilityPct}%` }}
                ></div>
              </div>
            </div>

            {/* Performance */}
            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-300">2. Speed Performance (Actual / Nameplate):</span>
                <span className="text-amber-300 font-bold">{selectedLine.performancePct}%</span>
              </div>
              <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden">
                <div
                  className="h-full bg-amber-500 rounded-full"
                  style={{ width: `${selectedLine.performancePct}%` }}
                ></div>
              </div>
            </div>

            {/* Quality */}
            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-300">3. First-Pass Quality (Good Units / Total Filled):</span>
                <span className="text-emerald-400 font-bold">{selectedLine.qualityPct}%</span>
              </div>
              <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-500 rounded-full"
                  style={{ width: `${selectedLine.qualityPct}%` }}
                ></div>
              </div>
            </div>
          </div>

          {/* Micro-stoppages Table */}
          <div className="pt-2">
            <span className="text-xs font-mono font-bold text-slate-300 uppercase block mb-2">
              Recent Micro-stoppages & Downtime Events
            </span>
            <div className="space-y-1.5 font-mono text-xs">
              {selectedLine.stoppages.map((s, idx) => (
                <div
                  key={idx}
                  className="bg-slate-950 p-2.5 rounded border border-slate-800 flex items-center justify-between text-[11px]"
                >
                  <span className="text-slate-300">{s.reason}</span>
                  <span className="text-red-400 font-bold">{s.durationMin} min duration</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Col: Quality, Gas Purity & TPO Invariants */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-4 font-mono text-xs flex flex-col justify-between">
          <div className="space-y-3">
            <div className="border-b border-slate-800 pb-2">
              <h3 className="font-bold text-slate-100 uppercase">Packaging Quality & DO Preserver</h3>
              <p className="text-[11px] text-slate-400">Strict physical limit: Package DO &lt; 15.0 ppb</p>
            </div>

            <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2">
              <div className="flex justify-between text-slate-400">
                <span>Package Dissolved O2 (DO):</span>
                <span className="text-emerald-400 font-bold">{selectedLine.dissolvedOxygenInPackagePpb} ppb</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>CO2 Purge Gas Purity:</span>
                <span className="text-slate-200 font-bold">{selectedLine.co2PurityPct}%</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Rejects / Defect Count:</span>
                <span className="text-amber-300 font-bold">{selectedLine.rejectedUnits} units</span>
              </div>
            </div>

            <div className="bg-emerald-950/20 border border-emerald-500/30 rounded p-3 text-emerald-300 space-y-1">
              <span className="font-bold flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" /> Quality Invariants Satisfied:
              </span>
              <p className="text-[11px] text-slate-400">
                Dissolved oxygen in finished cans is 4.2 ppb (well below 15 ppb threshold). Zero risk of staling or
                trans-2-nonenal cardboard off-flavors over 12-month shelf life.
              </p>
            </div>
          </div>

          <div className="bg-slate-950 p-2.5 rounded border border-slate-800 text-[11px] text-slate-400">
            <span className="text-cyan-400 font-bold">CIP Turnaround: </span>
            Automatic sanitization cycle scheduled at 22:00 following batch completion.
          </div>
        </div>
      </div>
    </div>
  );
};
