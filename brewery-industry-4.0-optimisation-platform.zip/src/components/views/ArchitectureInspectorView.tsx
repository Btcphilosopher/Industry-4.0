import React, { useState } from "react";
import {
  Layers,
  Cpu,
  Terminal,
  Activity,
  CheckCircle2,
  Zap,
  ArrowRight,
  Code,
  ShieldCheck,
  RotateCw,
} from "lucide-react";
import { ArchitectureLayerMetric } from "../../types/brewery";

interface ArchitectureInspectorViewProps {
  metrics: ArchitectureLayerMetric[];
}

export const ArchitectureInspectorView: React.FC<ArchitectureInspectorViewProps> = ({ metrics }) => {
  const [selectedLayerKey, setSelectedLayerKey] = useState<string>("RUST_CORE");

  const selectedMetric = metrics.find((m) => m.layer === selectedLayerKey) || metrics[0];

  const codeSnippets: Record<string, { lang: string; title: string; code: string }> = {
    RUST_CORE: {
      lang: "rust",
      title: "rust-core/src/telemetry/darcy_simd.rs",
      code: `// Deterministic SIMD Darcy's Law & Bed Compaction Evaluator
pub struct LauterTunState {
    pub bed_permeability_darcy: f64,
    pub differential_pressure_mbar: f64,
    pub bed_height_m: f64,
    pub wort_viscosity_pa_s: f64,
}

impl LauterTunState {
    #[inline(always)]
    pub fn compute_darcy_flow_rate_simd(&self, area_m2: f64) -> f64 {
        // Q = (K * A * delta_P) / (mu * L)
        let delta_p_pa = self.differential_pressure_mbar * 100.0;
        let k_m2 = self.bed_permeability_darcy * 9.869233e-13;
        (k_m2 * area_m2 * delta_p_pa) / (self.wort_viscosity_pa_s * self.bed_height_m)
    }
}`,
    },
    PYTHON_TWIN: {
      lang: "python",
      title: "python-engine/models/fermentation_ode.py",
      code: `import numpy as np
from scipy.integrate import odeint

def fermentation_ode(state, t, T_celsius, kinetic_params):
    """
    Coupled differential state equations for yeast biomass (X),
    substrate extract (S), ethanol (E), and diacetyl precursor (AAL).
    """
    S, X, E, AAL, Diacetyl = state
    mu_max = kinetic_params['mu_max'] * np.exp(-kinetic_params['E_a'] / (8.314 * (T_celsius + 273.15)))
    
    # Monod specific growth rate with ethanol inhibition
    mu = mu_max * (S / (kinetic_params['K_s'] + S)) * (1.0 - (E / kinetic_params['E_max']))
    
    dS_dt = -(1.0 / kinetic_params['Y_xs']) * mu * X
    dX_dt = mu * X - kinetic_params['k_d'] * X
    dE_dt = kinetic_params['Y_es'] * (-dS_dt)
    dAAL_dt = kinetic_params['k_aal_synth'] * (-dS_dt) - kinetic_params['k_aal_decay'] * AAL
    dDiacetyl_dt = kinetic_params['k_aal_decay'] * AAL - kinetic_params['k_reduct'] * Diacetyl * X
    
    return [dS_dt, dX_dt, dE_dt, dAAL_dt, dDiacetyl_dt]`,
    },
    R_ANALYTICS: {
      lang: "r",
      title: "r-analytics/spc/shewhart_rules.R",
      code: `# Western Electric Rules & Process Capability (Cpk)
library(qcc)

evaluate_brewery_spc <- function(data_vector, target, usl, lsl) {
  # 1. Fit Shewhart X-bar model
  spc_chart <- qcc(data_vector, type = "xbar.one", plot = FALSE)
  
  # 2. Western Electric 4-Rule Violations
  violations <- spc_chart$violations
  
  # 3. Six-Sigma Process Capability
  mean_val <- mean(data_vector)
  std_dev  <- sd(data_vector)
  cp       <- (usl - lsl) / (6 * std_dev)
  cpk      <- min((usl - mean_val) / (3 * std_dev), (mean_val - lsl) / (3 * std_dev))
  
  return(list(
    cp = round(cp, 2),
    cpk = round(cpk, 2),
    is_in_control = length(violations) == 0,
    ucl = round(spc_chart$limits[2], 3),
    lcl = round(spc_chart$limits[1], 3)
  ))
}`,
    },
    KOTLIN_UI: {
      lang: "kotlin",
      title: "kotlin-ui/src/main/kotlin/scada/SynopticView.kt",
      code: `package com.brewery.scada.ui

import androidx.compose.runtime.*
import kotlinx.coroutines.flow.StateFlow

@Composable
fun SynopticVesselNode(
    vesselState: StateFlow<VesselTelemetry>,
    onCommandDispatched: (ScadaCommand) -> Unit
) {
    val telemetry by vesselState.collectAsState()
    
    Card(
        modifier = Modifier.padding(8.dp),
        border = BorderStroke(1.dp, if (telemetry.invariantsLocked) Color(0xFF10B981) else Color(0xFFEF4444))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(text = telemetry.vesselId, style = MaterialTheme.typography.titleMedium)
            Text(text = "\${telemetry.tempCelsius}°C | \${telemetry.pressureBar} bar")
            LinearProgressIndicator(progress = telemetry.volumeHl / telemetry.capacityHl)
        }
    }
}`,
    },
  };

  const currentSnippet = codeSnippets[selectedLayerKey] || codeSnippets.RUST_CORE;

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-amber-400" />
            <h1 className="text-base font-bold font-mono text-slate-100 uppercase tracking-wide">
              THREE-LAYER ARCHITECTURE & INDUSTRIAL SYSTEMS BENCHMARK
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Separation of concerns across Rust (Performance Core & Deterministic Telemetry), Python (Thermodynamics &
            ODEs), R (Analytics & SPC), and Kotlin (SCADA Command Centre).
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-slate-400">Total Telemetry Ingestion:</span>
          <span className="text-emerald-400 font-bold bg-slate-950 border border-slate-800 px-3 py-1.5 rounded">
            14,200 Events / sec @ 0.85ms
          </span>
        </div>
      </div>

      {/* Layer Tabs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3.5 font-mono text-xs">
        {metrics.map((metric) => {
          const isSelected = metric.layer === selectedLayerKey;
          return (
            <button
              key={metric.layer}
              onClick={() => setSelectedLayerKey(metric.layer)}
              className={`p-3.5 rounded-lg text-left transition cursor-pointer border flex flex-col justify-between space-y-2 ${
                isSelected
                  ? "bg-slate-900 border-amber-400 shadow-md shadow-amber-500/10"
                  : "bg-slate-950 border-slate-800 hover:border-slate-700"
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-100">{metric.title}</span>
                <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 font-bold">
                  {metric.healthStatus}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 line-clamp-2">{metric.role}</p>

              <div className="grid grid-cols-3 gap-1 text-[10px] text-slate-400 bg-slate-950 p-2 rounded border border-slate-800/80">
                <div>
                  <span className="text-slate-500 block">CYCLE</span>
                  <span className="text-amber-300 font-bold">{metric.cycleTimeMs} ms</span>
                </div>
                <div>
                  <span className="text-slate-500 block">THROUGHPUT</span>
                  <span className="text-cyan-300 font-bold">{metric.throughputEventsSec}/s</span>
                </div>
                <div>
                  <span className="text-slate-500 block">RAM</span>
                  <span className="text-slate-200 font-bold">{metric.memoryMb} MB</span>
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Deep Layer Inspection & Source Code Snippet */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 font-mono text-xs">
        {/* Left: Active Micro-Modules Status */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="font-bold text-slate-100 uppercase">{selectedMetric.title} Modules</span>
            <span className="text-[10px] text-emerald-400">Zero Allocation Heap</span>
          </div>

          <div className="space-y-2">
            {selectedMetric.modules.map((mod, idx) => (
              <div
                key={idx}
                className="bg-slate-950 p-2.5 rounded border border-slate-800 flex items-center justify-between"
              >
                <div>
                  <div className="font-bold text-slate-200">{mod.name}</div>
                  <div className="text-[10px] text-slate-400">{mod.status}</div>
                </div>
                <div className="text-right">
                  <span className="text-cyan-400 font-bold">{mod.latencyUs} µs</span>
                  <span className="text-[10px] text-slate-500 block">latency</span>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
            <span className="text-amber-400 font-bold flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4" /> Hard Architectural Constraint:
            </span>
            <p className="text-[11px] text-slate-400">
              The Rust performance core acts as the safety boundary. No high-level Python or R optimization proposal can
              override Rust-locked ASME boiler limits or minimum pasteurization unit thresholds.
            </p>
          </div>
        </div>

        {/* Right: Code Contract Viewer */}
        <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="font-bold text-amber-300">{currentSnippet.title}</span>
            <span className="text-[10px] text-slate-500 uppercase">{currentSnippet.lang}</span>
          </div>

          <pre className="text-[11px] text-slate-300 font-mono overflow-x-auto bg-slate-900/90 p-3 rounded border border-slate-800 leading-relaxed max-h-96">
            <code>{currentSnippet.code}</code>
          </pre>
        </div>
      </div>
    </div>
  );
};
