import React, { useState, useMemo } from "react";
import {
  Sliders,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  Zap,
  Droplets,
  TrendingUp,
  RotateCw,
} from "lucide-react";
import { OptimizationObjectiveWeights, OptimizationProposal } from "../../types/brewery";
import { generateParetoCandidates } from "../../analytics/multiObjectiveOptimizer";

interface MultiObjectiveOptimizerViewProps {
  proposals: OptimizationProposal[];
  onOpenProposal: (proposal: OptimizationProposal) => void;
  onApproveProposal: (id: string) => void;
  onRejectProposal: (id: string) => void;
}

export const MultiObjectiveOptimizerView: React.FC<MultiObjectiveOptimizerViewProps> = ({
  proposals,
  onOpenProposal,
  onApproveProposal,
  onRejectProposal,
}) => {
  // Weights state
  const [weights, setWeights] = useState<OptimizationObjectiveWeights>({
    quality: 0.35,
    throughput: 0.2,
    energyEfficiency: 0.2,
    waterEfficiency: 0.15,
    costMinimization: 0.1,
  });

  const [selectedCandidateId, setSelectedCandidateId] = useState<string>("state_balanced_opt");

  const candidates = useMemo(() => {
    return generateParetoCandidates(weights);
  }, [weights]);

  const selectedCandidate = candidates.find((c) => c.id === selectedCandidateId) || candidates[0];

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <h1 className="text-base font-bold font-mono text-slate-100 uppercase tracking-wide">
              MULTI-OBJECTIVE PARETO OPTIMIZER & CONSTRAINED GLOBAL SOLVER
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Simultaneous multi-variable optimization searching for non-dominated Pareto frontier points across Quality,
            Throughput, Energy, Water, and Cost under hard thermodynamic and food-safety invariants.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-slate-400">Hard Safety Invariants:</span>
          <span className="text-emerald-400 font-bold bg-slate-950 border border-slate-800 px-3 py-1.5 rounded flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" /> STRICTLY ENFORCED
          </span>
        </div>
      </div>

      {/* 5-Dimensional Weight Sliders */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3 font-mono text-xs">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <span className="font-bold text-slate-200 uppercase">Optimization Objective Preference Weights</span>
          <span className="text-[11px] text-slate-400">Adjust sliders to dynamically re-score Pareto candidates</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5 pt-1">
          {/* Quality */}
          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1.5">
            <div className="flex justify-between text-purple-300">
              <span>Quality Index:</span>
              <span className="font-bold">{Math.round(weights.quality * 100)}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={weights.quality}
              onChange={(e) => setWeights({ ...weights, quality: parseFloat(e.target.value) })}
              className="w-full accent-purple-500 cursor-pointer"
            />
          </div>

          {/* Throughput */}
          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1.5">
            <div className="flex justify-between text-emerald-300">
              <span>Throughput:</span>
              <span className="font-bold">{Math.round(weights.throughput * 100)}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={weights.throughput}
              onChange={(e) => setWeights({ ...weights, throughput: parseFloat(e.target.value) })}
              className="w-full accent-emerald-500 cursor-pointer"
            />
          </div>

          {/* Energy */}
          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1.5">
            <div className="flex justify-between text-amber-300">
              <span>Energy Eff.:</span>
              <span className="font-bold">{Math.round(weights.energyEfficiency * 100)}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={weights.energyEfficiency}
              onChange={(e) => setWeights({ ...weights, energyEfficiency: parseFloat(e.target.value) })}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          {/* Water */}
          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1.5">
            <div className="flex justify-between text-blue-300">
              <span>Water Eff.:</span>
              <span className="font-bold">{Math.round(weights.waterEfficiency * 100)}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={weights.waterEfficiency}
              onChange={(e) => setWeights({ ...weights, waterEfficiency: parseFloat(e.target.value) })}
              className="w-full accent-blue-500 cursor-pointer"
            />
          </div>

          {/* Cost */}
          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1.5">
            <div className="flex justify-between text-cyan-300">
              <span>Cost Minimization:</span>
              <span className="font-bold">{Math.round(weights.costMinimization * 100)}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={weights.costMinimization}
              onChange={(e) => setWeights({ ...weights, costMinimization: parseFloat(e.target.value) })}
              className="w-full accent-cyan-500 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* Pareto Frontier Comparison Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3 font-mono text-xs">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
          <div>
            <h2 className="font-bold text-slate-100 uppercase">Pareto Efficient Plant Operating Candidates</h2>
            <p className="text-[11px] text-slate-400">Select an operating profile to evaluate physical feasibility</p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-[11px] text-slate-400">
                <th className="py-2 px-3">OPERATING CANDIDATE</th>
                <th className="py-2 px-3">COMPOSITE SCORE</th>
                <th className="py-2 px-3">THROUGHPUT</th>
                <th className="py-2 px-3">ENERGY</th>
                <th className="py-2 px-3">WATER</th>
                <th className="py-2 px-3">COST</th>
                <th className="py-2 px-3">QUALITY</th>
                <th className="py-2 px-3">CONSTRAINTS</th>
              </tr>
            </thead>
            <tbody>
              {candidates.map((c) => {
                const isSelected = c.id === selectedCandidateId;
                return (
                  <tr
                    key={c.id}
                    onClick={() => setSelectedCandidateId(c.id)}
                    className={`border-b border-slate-800/60 cursor-pointer transition ${
                      isSelected
                        ? "bg-amber-500/10 text-amber-300 font-bold"
                        : "hover:bg-slate-950 text-slate-300"
                    }`}
                  >
                    <td className="py-2.5 px-3">
                      <div>{c.name}</div>
                      <div className="text-[10px] text-slate-400 font-normal">{c.description}</div>
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="text-sm font-bold text-amber-400">{c.scores.compositeObjectiveScore} / 100</span>
                    </td>
                    <td className="py-2.5 px-3">{c.metrics.weeklyThroughputHl} hl/wk</td>
                    <td className="py-2.5 px-3">{c.metrics.energyKwhPerHl} kWh/hl</td>
                    <td className="py-2.5 px-3">{c.metrics.waterHlPerHl} hl/hl</td>
                    <td className="py-2.5 px-3">£{c.metrics.costGbpPerHl} / hl</td>
                    <td className="py-2.5 px-3 text-emerald-400">{c.metrics.qualityIndexPct}%</td>
                    <td className="py-2.5 px-3">
                      {c.hardConstraintsSatisfied ? (
                        <span className="text-emerald-400 text-[10px] bg-emerald-500/20 px-2 py-0.5 rounded">
                          SATISFIED
                        </span>
                      ) : (
                        <span className="text-red-400 text-[10px] bg-red-500/20 px-2 py-0.5 rounded animate-pulse">
                          VIOLATION
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Selected Operating Candidate Action Console & Active Proposals */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 font-mono text-xs">
        {/* Left: Selected Candidate Invariant Check */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="font-bold text-slate-100 uppercase">{selectedCandidate.name}</span>
              <span
                className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                  selectedCandidate.hardConstraintsSatisfied
                    ? "bg-emerald-500/20 text-emerald-300"
                    : "bg-red-500/20 text-red-300"
                }`}
              >
                {selectedCandidate.hardConstraintsSatisfied ? "SAFE TO DEPLOY" : "SAFETY INTERLOCK LOCKED"}
              </span>
            </div>

            <p className="text-slate-400 text-[11px]">{selectedCandidate.description}</p>

            {selectedCandidate.violations.length > 0 && (
              <div className="bg-red-950/30 border border-red-500/40 rounded p-3 text-red-300 space-y-1">
                <span className="font-bold flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-red-400" /> Hard Invariant Interlock Violations:
                </span>
                <ul className="list-disc list-inside text-[11px] text-red-200">
                  {selectedCandidate.violations.map((v, i) => (
                    <li key={i}>{v}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          <div className="pt-3 border-t border-slate-800 flex gap-2">
            <button
              disabled={!selectedCandidate.hardConstraintsSatisfied}
              className={`w-full py-2.5 rounded font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer ${
                selectedCandidate.hardConstraintsSatisfied
                  ? "bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-lg shadow-amber-500/10"
                  : "bg-slate-800 text-slate-500 cursor-not-allowed"
              }`}
            >
              <Sparkles className="w-4 h-4" />
              <span>Deploy Operating Profile to Plant SCADA</span>
            </button>
          </div>
        </div>

        {/* Right: Active Micro-Proposals Review */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="font-bold text-slate-100 uppercase">Pending Optimization Proposals</span>
            <span className="text-[10px] text-slate-400">{proposals.length} Proposals Total</span>
          </div>

          <div className="space-y-2.5">
            {proposals.map((p) => (
              <div
                key={p.id}
                className="bg-slate-950 border border-slate-800 rounded p-3 space-y-2 hover:border-slate-700 transition"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-200">{p.title}</span>
                  <span
                    className={`text-[9px] px-1.5 py-0.2 rounded font-bold uppercase ${
                      p.status === "APPROVED"
                        ? "bg-emerald-500/20 text-emerald-300"
                        : p.status === "REJECTED"
                        ? "bg-red-500/20 text-red-300"
                        : "bg-amber-500/20 text-amber-300"
                    }`}
                  >
                    {p.status}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">{p.impactSummary}</p>

                <div className="flex items-center justify-between pt-1 text-[11px]">
                  <button
                    onClick={() => onOpenProposal(p)}
                    className="text-cyan-400 hover:underline cursor-pointer flex items-center gap-1"
                  >
                    <span>View Physics Proof</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>

                  {p.status === "PENDING_REVIEW" && (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onRejectProposal(p.id)}
                        className="px-2 py-1 rounded bg-slate-800 text-slate-400 hover:text-slate-200 transition cursor-pointer"
                      >
                        Reject
                      </button>
                      <button
                        onClick={() => onApproveProposal(p.id)}
                        className="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition cursor-pointer"
                      >
                        Approve & Execute
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
