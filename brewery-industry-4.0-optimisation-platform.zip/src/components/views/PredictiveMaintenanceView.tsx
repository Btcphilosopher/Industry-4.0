import React, { useState } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  Activity,
  Layers,
  ArrowRight,
  TrendingDown,
  Wrench,
  ShieldAlert,
  ShieldCheck,
} from "lucide-react";
import { EquipmentAsset } from "../../types/brewery";
import { evaluateAssetHealth } from "../../analytics/predictiveMaintenance";

interface PredictiveMaintenanceViewProps {
  assets: EquipmentAsset[];
}

export const PredictiveMaintenanceView: React.FC<PredictiveMaintenanceViewProps> = ({ assets }) => {
  const [selectedAssetId, setSelectedAssetId] = useState<string>("CF-01");
  const selectedAsset = assets.find((a) => a.id === selectedAssetId) || assets[0];

  // Prognostics evaluation
  const healthEvaluation = evaluateAssetHealth(selectedAsset);

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-400" />
            <h1 className="text-base font-bold font-mono text-slate-100 uppercase tracking-wide">
              PREDICTIVE EQUIPMENT RELIABILITY & WEIBULL PROGNOSTICS
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Continuous vibration spectrometry (ISO 10816), thermal bearing monitoring, and Weibull Remaining Useful
            Life (RUL) estimation to eliminate catastrophic brewhouse downtime.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-slate-400">Plant Fleet Reliability:</span>
          <span className="text-emerald-400 font-bold bg-slate-950 border border-slate-800 px-3 py-1.5 rounded">
            96.8% Availability
          </span>
        </div>
      </div>

      {/* Asset Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-3.5">
        {assets.map((asset) => {
          const isSelected = asset.id === selectedAssetId;
          return (
            <button
              key={asset.id}
              onClick={() => setSelectedAssetId(asset.id)}
              className={`p-3.5 rounded-lg text-left font-mono transition cursor-pointer border flex flex-col justify-between space-y-2 ${
                isSelected
                  ? "bg-slate-900 border-amber-400 shadow-md shadow-amber-500/10"
                  : "bg-slate-950 border-slate-800 hover:border-slate-700"
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-200 text-xs">{asset.id}</span>
                <span
                  className={`text-[9px] px-1.5 py-0.2 rounded font-bold uppercase ${
                    asset.maintenancePriority === "HIGH"
                      ? "bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse"
                      : "bg-emerald-500/20 text-emerald-300"
                  }`}
                >
                  {asset.maintenancePriority}
                </span>
              </div>

              <div>
                <div className="text-xs font-semibold text-slate-100 truncate">{asset.name}</div>
                <div className="text-lg font-bold text-amber-300 mt-1">{asset.healthScorePct}% Health</div>
              </div>

              <div className="text-[10px] text-slate-400 space-y-0.5 border-t border-slate-800 pt-1.5">
                <div className="flex justify-between">
                  <span>Vib RMS:</span>
                  <span className="text-slate-200 font-bold">{asset.vibrationRmsMmS} mm/s</span>
                </div>
                <div className="flex justify-between">
                  <span>RUL:</span>
                  <span className="text-cyan-300 font-bold">{asset.remainingUsefulLifeHours.toLocaleString()}h</span>
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Selected Asset Deep Diagnostics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Left 2 Cols: ISO 10816 Vibration & Spectral State */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
            <div>
              <h2 className="font-bold text-slate-100 uppercase">{selectedAsset.name} Detailed Prognostics</h2>
              <p className="text-[11px] text-slate-400">
                Operating Runtime: {selectedAsset.runtimeHours.toLocaleString()} hours | Location:{" "}
                {selectedAsset.location}
              </p>
            </div>
            <span
              className={`px-2.5 py-0.5 rounded font-bold ${
                healthEvaluation.isoVibrationSeverity === "GOOD" || healthEvaluation.isoVibrationSeverity === "ACCEPTABLE"
                  ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                  : "bg-amber-500/20 text-amber-300 border border-amber-500/40"
              }`}
            >
              ISO 10816: {healthEvaluation.isoVibrationSeverity}
            </span>
          </div>

          {/* Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-[10px] text-slate-500 block">VIBRATION RMS</span>
              <div className="text-lg font-bold text-amber-300">{selectedAsset.vibrationRmsMmS} mm/s</div>
              <span className="text-[10px] text-slate-400">Peak: {selectedAsset.vibrationPeakG} G</span>
            </div>

            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-[10px] text-slate-500 block">BEARING TEMP</span>
              <div className="text-lg font-bold text-slate-200">{selectedAsset.bearingTempC}°C</div>
              <span className="text-[10px] text-slate-400">Max limit: 85°C</span>
            </div>

            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-[10px] text-slate-500 block">MOTOR CURRENT</span>
              <div className="text-lg font-bold text-cyan-300">{selectedAsset.motorCurrentAmps} A</div>
              <span className="text-[10px] text-slate-400">Full load rated</span>
            </div>

            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-[10px] text-slate-500 block">FAILURE RISK</span>
              <div
                className={`text-lg font-bold ${
                  healthEvaluation.failureRiskPct > 10 ? "text-amber-400" : "text-emerald-400"
                }`}
              >
                {healthEvaluation.failureRiskPct}%
              </div>
              <span className="text-[10px] text-slate-400">Weibull cumulative</span>
            </div>
          </div>

          {/* Prescriptive Recommendation */}
          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1.5">
            <span className="text-amber-400 font-bold flex items-center gap-1.5">
              <Wrench className="w-4 h-4" /> Prescriptive Maintenance Action:
            </span>
            <p className="text-slate-300">
              {healthEvaluation.recommendedIntervention ||
                selectedAsset.recommendedTask ||
                "Asset operating within nominal ISO baseline envelope. Routine dynamic lubrication scheduled for next planned stop."}
            </p>
          </div>
        </div>

        {/* Right: Weibull Distribution Parameters */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-4 font-mono text-xs flex flex-col justify-between">
          <div className="space-y-3">
            <div className="border-b border-slate-800 pb-2">
              <h3 className="font-bold text-slate-100 uppercase">2-Parameter Weibull Model</h3>
              <p className="text-[11px] text-slate-400">f(t) = (β/η)(t/η)^(β-1) e^(-(t/η)^β)</p>
            </div>

            <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2">
              <div className="flex justify-between text-slate-400">
                <span>Shape Parameter (β):</span>
                <span className="text-amber-300 font-bold">2.40 (Wearout Phase)</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Scale Parameter (η):</span>
                <span className="text-slate-200 font-bold">18,000 hours</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Remaining Useful Life (RUL):</span>
                <span className="text-cyan-300 font-bold">
                  {healthEvaluation.rulHours.toLocaleString()} hours
                </span>
              </div>
            </div>

            <div className="bg-amber-950/20 border border-amber-500/30 rounded p-3 text-amber-300 space-y-1">
              <span className="font-bold">Failure Prevention:</span>
              <p className="text-[11px] text-slate-400">
                Predictive maintenance prevents unplanned centrifuge shutdown during active boil transfer, avoiding
                spoilage of 160 hl wort valued at £3,800.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
