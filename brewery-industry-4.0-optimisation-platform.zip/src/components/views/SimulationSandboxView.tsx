import React, { useState } from "react";
import {
  Play,
  RotateCw,
  Zap,
  Droplets,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  Sliders,
  Sparkles,
  Layers,
} from "lucide-react";
import { SimulationScenario } from "../../types/brewery";
import { simulationScenarios } from "../../data/mockPlantState";

export const SimulationSandboxView: React.FC = () => {
  const [scenarios, setScenarios] = useState<SimulationScenario[]>(simulationScenarios);
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>("SCENARIO-BASELINE");

  // Custom overrides
  const [tariffMultiplier, setTariffMultiplier] = useState<number>(1.0);
  const [solarIrradiancePct, setSolarIrradiancePct] = useState<number>(100);
  const [waterRestrictionPct, setWaterRestrictionPct] = useState<number>(0);
  const [demandSurgePct, setDemandSurgePct] = useState<number>(0);

  const selectedScenario = scenarios.find((s) => s.id === selectedScenarioId) || scenarios[0];

  const handleSelectScenario = (id: string) => {
    setSelectedScenarioId(id);
    const scen = scenarios.find((s) => s.id === id);
    if (scen) {
      setTariffMultiplier(scen.parameters.energyPriceSpikeMultiplier);
      setSolarIrradiancePct(scen.parameters.solarIrradiancePct);
      setWaterRestrictionPct(scen.parameters.waterRestrictionPct);
      setDemandSurgePct(scen.parameters.demandSurgePct);
    }
  };

  // Simulated metrics outcome
  const simThroughputHl = Math.round(1840 * (1 + demandSurgePct / 100));
  const simEnergyKwhHl = Number((8.4 * (tariffMultiplier > 1.5 ? 0.92 : 1.0)).toFixed(1));
  const simCostPerHl = Number((14.2 * tariffMultiplier * (1 - (solarIrradiancePct / 100) * 0.25)).toFixed(1));
  const simWaterHlHl = Number((3.1 * (1 - (waterRestrictionPct / 100) * 0.22)).toFixed(1));

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Play className="w-5 h-5 text-amber-400" />
            <h1 className="text-base font-bold font-mono text-slate-100 uppercase tracking-wide">
              WHAT-IF DIGITAL TWIN SIMULATION SANDBOX
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Stress-test plant resiliency under extreme operational constraints (energy price spikes, water shortages,
            equipment degradation, demand shocks) before executing changes on the physical SCADA.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-slate-400">Sandbox Environment:</span>
          <span className="text-amber-400 font-bold bg-slate-950 border border-slate-800 px-3 py-1.5 rounded">
            ISOLATED PHYSICS TWIN
          </span>
        </div>
      </div>

      {/* Preset Scenarios Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-3 font-mono text-xs">
        {scenarios.map((scenario) => {
          const isSelected = scenario.id === selectedScenarioId;
          return (
            <button
              key={scenario.id}
              onClick={() => handleSelectScenario(scenario.id)}
              className={`p-3.5 rounded-lg text-left transition cursor-pointer border flex flex-col justify-between space-y-2 ${
                isSelected
                  ? "bg-slate-900 border-amber-400 shadow-md shadow-amber-500/10"
                  : "bg-slate-950 border-slate-800 hover:border-slate-700"
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-200">{scenario.name}</span>
              </div>
              <p className="text-[11px] text-slate-400 line-clamp-3">{scenario.description}</p>
              <div className="text-[10px] text-amber-300 font-semibold border-t border-slate-800 pt-1.5">
                {isSelected ? "ACTIVE SCENARIO" : "Select Scenario →"}
              </div>
            </button>
          );
        })}
      </div>

      {/* Interactive Sliders & Live Impact Results */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 font-mono text-xs">
        {/* Left: Override Controls */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-4">
          <div className="border-b border-slate-800 pb-2 flex items-center justify-between">
            <span className="font-bold text-slate-100 uppercase">Interactive Constraint Overrides</span>
            <button
              onClick={() => handleSelectScenario("SCENARIO-BASELINE")}
              className="text-slate-400 hover:text-slate-200 text-[10px] cursor-pointer"
            >
              Reset to Baseline
            </button>
          </div>

          {/* Slider 1: Tariff */}
          <div className="space-y-1.5 bg-slate-950 p-3 rounded border border-slate-800">
            <div className="flex justify-between text-slate-300">
              <span>Grid Energy Tariff Multiplier:</span>
              <span className="text-amber-300 font-bold">{tariffMultiplier.toFixed(1)}x (£{(0.24 * tariffMultiplier).toFixed(2)}/kWh)</span>
            </div>
            <input
              type="range"
              min={0.5}
              max={4.0}
              step={0.1}
              value={tariffMultiplier}
              onChange={(e) => setTariffMultiplier(parseFloat(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          {/* Slider 2: Solar Irradiance */}
          <div className="space-y-1.5 bg-slate-950 p-3 rounded border border-slate-800">
            <div className="flex justify-between text-slate-300">
              <span>Solar PV Irradiance (% of nominal):</span>
              <span className="text-yellow-300 font-bold">{solarIrradiancePct}% ({Math.round(3.5 * solarIrradiancePct)} kW)</span>
            </div>
            <input
              type="range"
              min={0}
              max={120}
              step={5}
              value={solarIrradiancePct}
              onChange={(e) => setSolarIrradiancePct(parseInt(e.target.value))}
              className="w-full accent-yellow-500 cursor-pointer"
            />
          </div>

          {/* Slider 3: Water Restriction */}
          <div className="space-y-1.5 bg-slate-950 p-3 rounded border border-slate-800">
            <div className="flex justify-between text-slate-300">
              <span>Municipal Water Curtailment:</span>
              <span className="text-blue-300 font-bold">{waterRestrictionPct}% Restriction</span>
            </div>
            <input
              type="range"
              min={0}
              max={60}
              step={5}
              value={waterRestrictionPct}
              onChange={(e) => setWaterRestrictionPct(parseInt(e.target.value))}
              className="w-full accent-blue-500 cursor-pointer"
            />
          </div>

          {/* Slider 4: Demand Surge */}
          <div className="space-y-1.5 bg-slate-950 p-3 rounded border border-slate-800">
            <div className="flex justify-between text-slate-300">
              <span>Production Order Surge:</span>
              <span className="text-emerald-300 font-bold">+{demandSurgePct}% Volume</span>
            </div>
            <input
              type="range"
              min={0}
              max={50}
              step={5}
              value={demandSurgePct}
              onChange={(e) => setDemandSurgePct(parseInt(e.target.value))}
              className="w-full accent-emerald-500 cursor-pointer"
            />
          </div>
        </div>

        {/* Right: Before vs After Impact Results */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-4 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="border-b border-slate-800 pb-2">
              <h3 className="font-bold text-slate-100 uppercase">Simulated Digital Twin Response</h3>
              <p className="text-[11px] text-slate-400">Comparative performance under simulated stress</p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
                <span className="text-slate-500 text-[10px]">THROUGHPUT OUTCOME</span>
                <div className="text-xl font-bold text-slate-100">{simThroughputHl} hl / wk</div>
                <div className="text-[11px] text-emerald-400">
                  {demandSurgePct > 0 ? `+${demandSurgePct}% surge satisfied` : "Nominal plan"}
                </div>
              </div>

              <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
                <span className="text-slate-500 text-[10px]">ENERGY INTENSITY</span>
                <div className="text-xl font-bold text-amber-300">{simEnergyKwhHl} kWh / hl</div>
                <div className="text-[11px] text-slate-400">Target &lt; 8.7 kWh/hl</div>
              </div>

              <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
                <span className="text-slate-500 text-[10px]">WATER INTENSITY</span>
                <div className="text-xl font-bold text-blue-300">{simWaterHlHl} hl / hl</div>
                <div className="text-[11px] text-cyan-400">CIP Recovery active</div>
              </div>

              <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
                <span className="text-slate-500 text-[10px]">ESTIMATED UNIT COST</span>
                <div className="text-xl font-bold text-emerald-400">£{simCostPerHl} / hl</div>
                <div className="text-[11px] text-slate-400">Including tariff & PV</div>
              </div>
            </div>

            <div className="bg-emerald-950/20 border border-emerald-500/30 rounded p-3 text-emerald-300 space-y-1">
              <span className="font-bold flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Digital Twin Adaptation Verdict:
              </span>
              <p className="text-[11px] text-slate-400">
                The multi-objective optimizer successfully dispatched the BESS battery, shifted thermal loads to the
                HLT, and recycled CIP rinse water, preventing any safety constraint violations or production halts.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
