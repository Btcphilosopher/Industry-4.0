import React from "react";
import {
  Activity,
  Zap,
  Droplets,
  ShieldCheck,
  RotateCw,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Clock,
  Flame,
  CheckCircle,
  AlertCircle,
  AlertTriangle,
} from "lucide-react";
import { Vessel, ActiveBatch, EnergyGridState, OptimizationProposal } from "../../types/brewery";

interface PlantOverviewViewProps {
  vessels: Vessel[];
  batches: ActiveBatch[];
  energyState: EnergyGridState;
  proposals: OptimizationProposal[];
  onOpenProposal: (proposal: OptimizationProposal) => void;
  onNavigateToTab: (tab: string) => void;
}

export const PlantOverviewView: React.FC<PlantOverviewViewProps> = ({
  vessels,
  batches,
  energyState,
  proposals,
  onOpenProposal,
  onNavigateToTab,
}) => {
  const pendingProposals = proposals.filter((p) => p.status === "PENDING_REVIEW");

  return (
    <div className="space-y-4">
      {/* Primary Bento Grid Dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
        {/* Bento 1: OEE Card (col-span-3) */}
        <div className="col-span-1 md:col-span-3 bg-[#1A1C1E] border border-[#2D3035] p-5 rounded-lg flex flex-col justify-between shadow-lg">
          <div>
            <h3 className="text-[10px] uppercase tracking-widest text-[#70757E] font-bold mb-1">
              Overall Equipment Effectiveness
            </h3>
            <div className="text-5xl font-light text-[#00FF41] font-mono tracking-tight flex items-baseline">
              91.4<span className="text-2xl ml-0.5">%</span>
            </div>
          </div>

          <div className="flex gap-2 items-end my-4">
            <div className="flex-1 h-12 bg-[#2D3035] rounded-sm relative overflow-hidden">
              <div
                className="absolute bottom-0 left-0 w-full bg-[#00FF41] opacity-75 transition-all duration-500"
                style={{ height: "85%" }}
                title="Availability: 98%"
              ></div>
            </div>
            <div className="flex-1 h-16 bg-[#2D3035] rounded-sm relative overflow-hidden">
              <div
                className="absolute bottom-0 left-0 w-full bg-[#00FF41] opacity-90 transition-all duration-500"
                style={{ height: "92%" }}
                title="Performance: 93%"
              ></div>
            </div>
            <div className="flex-1 h-14 bg-[#2D3035] rounded-sm relative overflow-hidden">
              <div
                className="absolute bottom-0 left-0 w-full bg-[#00FF41] opacity-80 transition-all duration-500"
                style={{ height: "90%" }}
                title="Quality: 99%"
              ></div>
            </div>
          </div>

          <div className="flex justify-between text-[10px] uppercase font-mono text-[#70757E] border-t border-[#2D3035] pt-2">
            <span>Availability: <strong className="text-[#E0E2E6]">98%</strong></span>
            <span>Quality: <strong className="text-[#00FF41]">99%</strong></span>
          </div>
        </div>

        {/* Bento 2: Brewery Digital Twin — Live Process Map (col-span-6) */}
        <div className="col-span-1 md:col-span-6 bg-[#1A1C1E] border border-[#2D3035] p-5 sm:p-6 rounded-lg relative flex flex-col justify-between shadow-lg">
          <div className="flex items-center justify-between">
            <h3 className="text-[10px] uppercase tracking-widest text-[#70757E] font-bold">
              Brewery Digital Twin — Live Process Map
            </h3>
            <button
              onClick={() => onNavigateToTab("map")}
              className="text-[10px] font-mono text-[#FF6B00] hover:underline flex items-center gap-1 cursor-pointer"
            >
              Interactive P&ID &rarr;
            </button>
          </div>

          {/* Synoptic Horizontal Flow */}
          <div className="flex items-center justify-between my-8 sm:my-10 relative px-2 sm:px-6">
            <div className="absolute h-[2px] w-[90%] left-[5%] bg-[#2D3035] top-1/2 -translate-y-1/2 z-0"></div>

            <button
              onClick={() => onNavigateToTab("brewing")}
              className="z-10 flex flex-col items-center gap-2 cursor-pointer group"
            >
              <div className="w-12 h-12 rounded-full border-2 border-[#FF6B00] bg-[#0A0B0D] flex items-center justify-center text-[10px] font-bold font-mono text-[#FF6B00] group-hover:scale-105 transition shadow-lg shadow-[#FF6B00]/10">
                MILL
              </div>
              <span className="text-[9px] font-mono text-[#FF6B00]">Active</span>
            </button>

            <button
              onClick={() => onNavigateToTab("brewing")}
              className="z-10 flex flex-col items-center gap-2 cursor-pointer group"
            >
              <div className="w-14 h-14 rounded-lg border-2 border-[#00FF41] bg-[#0A0B0D] flex items-center justify-center text-[10px] font-bold font-mono text-[#00FF41] group-hover:scale-105 transition shadow-lg shadow-[#00FF41]/10">
                MASH
              </div>
              <span className="text-[9px] text-[#00FF41] font-mono">65.2°C</span>
            </button>

            <button
              onClick={() => onNavigateToTab("brewing")}
              className="z-10 flex flex-col items-center gap-2 cursor-pointer group"
            >
              <div className="w-14 h-14 rounded-lg border-2 border-[#2D3035] bg-[#0A0B0D] flex items-center justify-center text-[10px] font-bold font-mono text-[#70757E] group-hover:border-[#70757E] transition">
                LAUTER
              </div>
              <span className="text-[9px] text-[#70757E] font-mono">Wait</span>
            </button>

            <button
              onClick={() => onNavigateToTab("brewing")}
              className="z-10 flex flex-col items-center gap-2 cursor-pointer group"
            >
              <div className="w-14 h-14 rounded-lg border-2 border-[#2D3035] bg-[#0A0B0D] flex items-center justify-center text-[10px] font-bold font-mono text-[#70757E] group-hover:border-[#70757E] transition">
                BOIL
              </div>
              <span className="text-[9px] text-[#70757E] font-mono">Ready</span>
            </button>

            <button
              onClick={() => onNavigateToTab("fermentation")}
              className="z-10 flex flex-col items-center gap-2 cursor-pointer group"
            >
              <div className="w-12 h-16 rounded-t-full border-2 border-[#00D1FF] bg-[#0A0B0D] flex items-center justify-center text-[10px] font-bold font-mono text-[#00D1FF] group-hover:scale-105 transition shadow-lg shadow-[#00D1FF]/10">
                FERM
              </div>
              <span className="text-[9px] text-[#00D1FF] font-mono">12 Units</span>
            </button>
          </div>

          {/* Advice Banner */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-[#121417] p-3.5 border border-[#2D3035] rounded gap-2">
            <div>
              <p className="text-[10px] text-[#70757E] uppercase font-bold tracking-wider">Current Objective</p>
              <p className="text-xs sm:text-sm text-[#FF6B00] font-semibold">Maximize Yield / Minimize Thermal Waste</p>
            </div>
            <div className="sm:text-right">
              <p className="text-[10px] text-[#70757E] uppercase font-bold tracking-wider">System Advice</p>
              <p className="text-xs sm:text-sm italic text-[#E0E2E6]">"Defer Boiling Phase: Energy Peak (+£0.12/kWh)"</p>
            </div>
          </div>
        </div>

        {/* Bento 3: Efficiency Matrix (col-span-3) */}
        <div className="col-span-1 md:col-span-3 bg-[#1A1C1E] border border-[#2D3035] p-5 rounded-lg flex flex-col justify-between shadow-lg">
          <h3 className="text-[10px] uppercase tracking-widest text-[#70757E] font-bold mb-3">
            Efficiency Matrix
          </h3>

          <div className="space-y-4 font-mono">
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs text-[#E0E2E6]">Energy Efficiency</span>
                <span className="text-xs font-bold text-[#00FF41]">8.7 kWh/hl</span>
              </div>
              <div className="w-full h-1.5 bg-[#2D3035] rounded-full overflow-hidden">
                <div className="w-[82%] h-full bg-[#00FF41] rounded-full"></div>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs text-[#E0E2E6]">Water Usage</span>
                <span className="text-xs font-bold text-[#FF6B00]">3.2 hl/hl</span>
              </div>
              <div className="w-full h-1.5 bg-[#2D3035] rounded-full overflow-hidden">
                <div className="w-[65%] h-full bg-[#FF6B00] rounded-full"></div>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs text-[#E0E2E6]">Extract Recovery</span>
                <span className="text-xs font-bold text-[#00FF41]">98.2%</span>
              </div>
              <div className="w-full h-1.5 bg-[#2D3035] rounded-full overflow-hidden">
                <div className="w-[98%] h-full bg-[#00FF41] rounded-full"></div>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs text-[#E0E2E6]">Thermal Recovery</span>
                <span className="text-xs font-bold text-[#00D1FF]">42.1%</span>
              </div>
              <div className="w-full h-1.5 bg-[#2D3035] rounded-full overflow-hidden">
                <div className="w-[42%] h-full bg-[#00D1FF] rounded-full"></div>
              </div>
            </div>
          </div>

          <div className="text-[10px] text-[#70757E] font-mono border-t border-[#2D3035] pt-2 flex justify-between">
            <span>SPECIFIC METRICS</span>
            <span className="text-[#00FF41]">ALL CONSTRAINTS PASSED</span>
          </div>
        </div>

        {/* Bento 4: Anomaly Detection (col-span-3) */}
        <div className="col-span-1 md:col-span-3 bg-[#1A1C1E] border border-[#2D3035] p-5 rounded-lg flex flex-col justify-between shadow-lg">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-[10px] uppercase tracking-widest text-[#70757E] font-bold">
              Anomaly Detection
            </h3>
            <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-red-950 text-red-400 border border-red-900">
              2 ACTIVE
            </span>
          </div>

          <div className="space-y-3 font-mono">
            <div className="p-3 bg-[#2D1A1A] border border-red-900 rounded flex gap-3">
              <div className="w-1 bg-red-600 rounded-full shrink-0"></div>
              <div>
                <p className="text-[10px] text-red-400 font-bold uppercase tracking-wider">Critical Spike</p>
                <p className="text-xs text-[#E0E2E6] font-sans">Pump P-04 Pressure Anomaly (High Vibr.)</p>
                <span className="text-[9px] text-[#70757E] font-mono">ISO 10816: 4.8 mm/s</span>
              </div>
            </div>

            <div className="p-3 bg-[#1A262D] border border-blue-900/60 rounded flex gap-3">
              <div className="w-1 bg-[#00D1FF] rounded-full shrink-0"></div>
              <div>
                <p className="text-[10px] text-[#00D1FF] font-bold uppercase tracking-wider">Observation</p>
                <p className="text-xs text-[#E0E2E6] font-sans">Heat Exchanger HE-02 Fouling Trend (+4%)</p>
                <span className="text-[9px] text-[#70757E] font-mono">CIP thermal degradation</span>
              </div>
            </div>
          </div>

          <button
            onClick={() => onNavigateToTab("maintenance")}
            className="w-full mt-3 text-center text-[10px] font-mono text-[#70757E] hover:text-[#E0E2E6] py-1 border border-dashed border-[#2D3035] rounded hover:border-[#70757E] transition cursor-pointer"
          >
            Open Reliability Diagnostics &rarr;
          </button>
        </div>

        {/* Bento 5: Active Batches (col-span-3) */}
        <div className="col-span-1 md:col-span-3 bg-[#1A1C1E] border border-[#2D3035] p-5 rounded-lg flex flex-col justify-between shadow-lg">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-[10px] uppercase tracking-widest text-[#70757E] font-bold">
              Active Batches
            </h3>
            <span className="text-[10px] font-mono text-[#00D1FF]">4 In Flight</span>
          </div>

          <div className="space-y-2.5 font-mono text-[11px]">
            <div className="flex justify-between items-center border-b border-[#2D3035] pb-2">
              <span className="text-[#00D1FF] font-bold">#IPA-942</span>
              <span className="text-[#E0E2E6]">F-12 (Citra IPA)</span>
              <span className="text-[#70757E]">P: 1.2 bar</span>
            </div>
            <div className="flex justify-between items-center border-b border-[#2D3035] pb-2">
              <span className="text-[#00D1FF] font-bold">#LGR-108</span>
              <span className="text-[#E0E2E6]">F-04 (Pilsner)</span>
              <span className="text-[#70757E]">T: 12.1°C</span>
            </div>
            <div className="flex justify-between items-center border-b border-[#2D3035] pb-2">
              <span className="text-[#00D1FF] font-bold">#STT-221</span>
              <span className="text-[#E0E2E6]">F-09 (Oat Stout)</span>
              <span className="text-[#00FF41] font-bold">Ready</span>
            </div>
            <div className="flex justify-between items-center border-b border-[#2D3035] pb-2">
              <span className="text-[#00D1FF] font-bold">#IPA-943</span>
              <span className="text-[#E0E2E6]">Kettle (Hazy)</span>
              <span className="text-[#FF6B00] font-bold">Boil</span>
            </div>
          </div>

          <button
            onClick={() => onNavigateToTab("tanks")}
            className="w-full mt-2 text-center text-[10px] font-mono text-[#70757E] hover:text-[#E0E2E6] py-1 border border-dashed border-[#2D3035] rounded hover:border-[#70757E] transition cursor-pointer"
          >
            View Full Cellar Gantt &rarr;
          </button>
        </div>

        {/* Bento 6: Industrial Optimization Recommendation (col-span-6) */}
        <div className="col-span-1 md:col-span-6 bg-[#1A1C1E] border border-[#2D3035] p-5 rounded-lg flex flex-col justify-between shadow-lg overflow-hidden">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-[10px] uppercase tracking-widest text-[#70757E] font-bold flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-[#FF6B00]" />
              Industrial Optimization Recommendation
            </h3>
            <span className="text-[10px] font-mono bg-[#FF6B00]/20 text-[#FF6B00] px-2 py-0.5 rounded border border-[#FF6B00]/40">
              R-Analytics Solved
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 my-2">
            <div>
              <p className="text-base sm:text-lg font-light text-[#E0E2E6] mb-1">
                {pendingProposals[0]?.title || "Adjust Mash Temp Profile"}
              </p>
              <p className="text-xs text-[#70757E] mb-4 font-sans line-clamp-3">
                {pendingProposals[0]?.impactSummary ||
                  "The R analytics layer predicts a 2.1% increase in fermentable extract based on current malt moisture analysis (Batch M-22)."}
              </p>
              <button
                onClick={() => {
                  if (pendingProposals[0]) {
                    onOpenProposal(pendingProposals[0]);
                  } else {
                    onNavigateToTab("optimizer");
                  }
                }}
                className="bg-[#FF6B00] hover:bg-[#FF6B00]/90 text-black text-[11px] font-bold uppercase tracking-wider py-2 px-4 rounded-sm transition cursor-pointer shadow-md shadow-[#FF6B00]/20"
              >
                Apply Optimization
              </button>
            </div>

            <div className="bg-[#121417] p-4 border border-[#2D3035] rounded font-mono text-[10px] space-y-1.5">
              <div className="flex justify-between">
                <span className="text-[#70757E]">Input:</span>
                <span className="text-[#E0E2E6]">Malt Moisture 12%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#70757E]">Model:</span>
                <span className="text-[#E0E2E6]">Diffusion-Physics v2</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#70757E]">Confidence:</span>
                <span className="text-[#00FF41] font-bold">96.4%</span>
              </div>
              <div className="flex justify-between pt-2 mt-2 border-t border-[#2D3035]">
                <span className="text-[#FF6B00] font-bold">Expected Gain:</span>
                <span className="text-[#FF6B00] font-bold">+£142.50/batch</span>
              </div>
            </div>
          </div>

          <div className="text-[10px] font-mono text-[#70757E] border-t border-[#2D3035] pt-2 flex justify-between">
            <span>SAFETY INTERLOCK: VALIDATED</span>
            <span>SUPERVISORY CONTROL ACTIVE</span>
          </div>
        </div>

        {/* Bento 7: Current Energy Market & Dynamic Tariff (col-span-3) */}
        <div className="col-span-1 md:col-span-3 bg-[#1A1C1E] border border-[#2D3035] p-5 rounded-lg flex items-center justify-between shadow-lg">
          <div>
            <h3 className="text-[10px] uppercase tracking-widest text-[#70757E] font-bold">Current Energy</h3>
            <p className="text-3xl font-mono font-bold text-[#E0E2E6] mt-1">
              £0.14<span className="text-xs text-[#70757E] ml-1 font-normal">/kWh</span>
            </p>
            <span className="text-[10px] text-[#70757E] font-mono">BESS Battery: 76% SoC</span>
          </div>
          <div className="text-right">
            <p className="text-xs text-[#00FF41] font-bold font-mono uppercase bg-[#00FF41]/10 px-2 py-0.5 rounded border border-[#00FF41]/30">
              LOW PEAK
            </p>
            <p className="text-[10px] text-[#70757E] font-mono mt-1">Next spike in 4h</p>
          </div>
        </div>

        {/* Bento 8: Multi-Objective Engine Banner (col-span-9) */}
        <div className="col-span-1 md:col-span-9 bg-[#1A1C1E] border border-[#2D3035] p-4 rounded-lg flex flex-wrap items-center justify-between gap-3 shadow-lg">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded bg-[#FF6B00]/10 border border-[#FF6B00]/30 flex items-center justify-center text-[#FF6B00]">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-bold font-mono text-[#E0E2E6] uppercase">
                Pareto Multi-Objective Engine Online
              </div>
              <p className="text-[11px] text-[#70757E]">
                {pendingProposals.length} pending physical recommendations ready for supervisory operator sign-off.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onNavigateToTab("optimizer")}
              className="bg-[#2D3035] hover:bg-[#FF6B00] hover:text-black text-[#E0E2E6] font-mono text-xs font-bold px-3 py-1.5 rounded transition cursor-pointer"
            >
              Open Pareto Frontier &rarr;
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
