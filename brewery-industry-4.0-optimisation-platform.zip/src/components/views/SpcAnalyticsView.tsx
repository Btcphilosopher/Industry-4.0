import React, { useState } from "react";
import {
  Activity,
  CheckCircle2,
  AlertTriangle,
  Layers,
  ArrowRight,
  TrendingUp,
  ShieldCheck,
  RotateCw,
} from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine,
} from "recharts";
import { SpcMetric } from "../../types/brewery";

interface SpcAnalyticsViewProps {
  metrics: SpcMetric[];
}

export const SpcAnalyticsView: React.FC<SpcAnalyticsViewProps> = ({ metrics }) => {
  const [selectedMetricId, setSelectedMetricId] = useState<string>("original_gravity");
  const selectedMetric = metrics.find((m) => m.id === selectedMetricId) || metrics[0];

  const chartData = selectedMetric.recentValues.map((v) => ({
    batch: v.batchId,
    value: v.value,
    target: selectedMetric.target,
    ucl: selectedMetric.ucl,
    lcl: selectedMetric.lcl,
    usl: selectedMetric.usl,
    lsl: selectedMetric.lsl,
  }));

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-purple-400" />
            <h1 className="text-base font-bold font-mono text-slate-100 uppercase tracking-wide">
              R INDUSTRIAL ANALYTICS & STATISTICAL PROCESS CONTROL (SPC)
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Shewhart X-bar & R-charts evaluating Western Electric rules, 3-sigma control limits, and process capability
            indices (Cp / Cpk) for quality invariants.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="text-slate-400">Global Process Capability:</span>
          <span className="text-emerald-400 font-bold bg-slate-950 border border-slate-800 px-3 py-1.5 rounded">
            Cpk = 1.49 (Six-Sigma Capable)
          </span>
        </div>
      </div>

      {/* Metric Tabs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {metrics.map((m) => {
          const isSelected = m.id === selectedMetricId;
          return (
            <button
              key={m.id}
              onClick={() => setSelectedMetricId(m.id)}
              className={`p-3 rounded-lg text-left font-mono transition cursor-pointer border flex flex-col justify-between space-y-1.5 ${
                isSelected
                  ? "bg-slate-900 border-purple-400 shadow-md shadow-purple-500/10"
                  : "bg-slate-950 border-slate-800 hover:border-slate-700"
              }`}
            >
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-200">{m.parameterName}</span>
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300">
                  {m.status}
                </span>
              </div>
              <div className="text-lg font-bold text-purple-300">
                {m.mean.toFixed(2)} {m.unit}
              </div>
              <div className="flex justify-between text-[11px] text-slate-400 border-t border-slate-800 pt-1">
                <span>Cp: {m.cp.toFixed(2)}</span>
                <span className="text-emerald-400 font-bold">Cpk: {m.cpk.toFixed(2)}</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Control Chart & Shewhart Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Chart (2 Cols) */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
            <div>
              <h2 className="text-xs font-mono font-bold text-slate-100 uppercase">
                Shewhart Control Chart: {selectedMetric.parameterName}
              </h2>
              <p className="text-[11px] font-mono text-slate-400">
                Target: {selectedMetric.target} | UCL: {selectedMetric.ucl} | LCL: {selectedMetric.lcl} | σ ={" "}
                {selectedMetric.stdDev.toFixed(3)}
              </p>
            </div>
            <span className="text-xs font-mono text-emerald-400 font-bold">Western Electric Rules: All In Control</span>
          </div>

          <div className="h-80 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData} margin={{ top: 10, right: 30, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="batch" stroke="#94a3b8" tick={{ fontSize: 11 }} />
                <YAxis stroke="#94a3b8" tick={{ fontSize: 11 }} domain={["auto", "auto"]} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#020617",
                    borderColor: "#334155",
                    fontSize: "12px",
                    fontFamily: "monospace",
                  }}
                />
                <Legend wrapperStyle={{ fontSize: "11px", fontFamily: "monospace", paddingTop: "8px" }} />
                {/* Specification Limits */}
                <ReferenceLine y={selectedMetric.usl} stroke="#ef4444" strokeDasharray="4 4" label="USL" />
                <ReferenceLine y={selectedMetric.lsl} stroke="#ef4444" strokeDasharray="4 4" label="LSL" />
                {/* 3-Sigma Control Limits */}
                <ReferenceLine y={selectedMetric.ucl} stroke="#f59e0b" strokeDasharray="2 2" label="UCL (+3σ)" />
                <ReferenceLine y={selectedMetric.lcl} stroke="#f59e0b" strokeDasharray="2 2" label="LCL (-3σ)" />
                <ReferenceLine y={selectedMetric.target} stroke="#10b981" label="Mean / Target" />
                <Line
                  type="monotone"
                  dataKey="value"
                  stroke="#a855f7"
                  strokeWidth={2.5}
                  name="Sample Value"
                  dot={{ r: 4, fill: "#a855f7" }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Right Col: Process Capability Breakdown */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-4 font-mono text-xs flex flex-col justify-between">
          <div className="space-y-3">
            <div className="border-b border-slate-800 pb-2">
              <h3 className="font-bold text-slate-100 uppercase">Process Capability Indices</h3>
              <p className="text-[11px] text-slate-400">Cp = (USL - LSL) / 6σ | Cpk = min((USL-μ)/3σ, (μ-LSL)/3σ)</p>
            </div>

            <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2">
              <div className="flex justify-between text-slate-400">
                <span>Process Potential (Cp):</span>
                <span className="text-purple-300 font-bold">{selectedMetric.cp.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Process Capability (Cpk):</span>
                <span className="text-emerald-400 font-bold">{selectedMetric.cpk.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Standard Deviation (σ):</span>
                <span className="text-slate-200 font-bold">{selectedMetric.stdDev.toFixed(4)}</span>
              </div>
            </div>

            <div className="space-y-1.5">
              <span className="font-bold text-slate-300 uppercase block">Western Electric Rules Check:</span>
              <div className="space-y-1 text-[11px]">
                <div className="flex items-center gap-2 text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Rule 1: 1 point beyond 3-sigma (PASSED)</span>
                </div>
                <div className="flex items-center gap-2 text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Rule 2: 2 of 3 points in Zone A (PASSED)</span>
                </div>
                <div className="flex items-center gap-2 text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Rule 3: 4 of 5 points in Zone B (PASSED)</span>
                </div>
                <div className="flex items-center gap-2 text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Rule 4: 8 consecutive on one side (PASSED)</span>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-emerald-950/20 border border-emerald-500/30 rounded p-2.5 text-emerald-300">
            <span className="font-bold flex items-center gap-1">
              <ShieldCheck className="w-4 h-4" /> Quality Guarantee:
            </span>
            <p className="text-[11px] text-slate-400 mt-0.5">
              With Cpk = {selectedMetric.cpk.toFixed(2)}, the defect probability is &lt; 3.4 parts per million, ensuring
              absolute brand consistency.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
