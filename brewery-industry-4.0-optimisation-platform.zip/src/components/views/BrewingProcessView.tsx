import React, { useState } from "react";
import {
  Flame,
  Droplets,
  Sliders,
  RotateCw,
  CheckCircle2,
  Info,
  Layers,
  ArrowRight,
  TrendingUp,
  Activity,
} from "lucide-react";
import {
  solvePlateHeatExchanger,
  solveBoilKettle,
  validateThermodynamicInvariants,
} from "../../physics/thermodynamics";
import { solveMashingProcess } from "../../physics/mashingKinetics";
import { solveLauterTunHydraulics } from "../../physics/lauteringHydraulics";

export const BrewingProcessView: React.FC = () => {
  // Interactive parameters for Brewhouse Physics Experiments
  const [mashTemp, setMashTemp] = useState<number>(66.5);
  const [mashPh, setMashPh] = useState<number>(5.35);
  const [gristKg, setGristKg] = useState<number>(3200);

  const [lauterElapsedMin, setLauterElapsedMin] = useState<number>(45);
  const [lauterFlowHlH, setLauterFlowHlH] = useState<number>(110);
  const [rakingActive, setRakingActive] = useState<boolean>(false);

  const [boilDurationMin, setBoilDurationMin] = useState<number>(60);
  const [evapRatePct, setEvapRatePct] = useState<number>(6.5);

  // Solvers execution
  const mashResult = solveMashingProcess(gristKg, (gristKg * 3.2) / 100, mashPh, mashTemp, 60);
  const lauterResult = solveLauterTunHydraulics(lauterElapsedMin, lauterFlowHlH, 78.0, 0.42, 18.5, rakingActive);
  const boilResult = solveBoilKettle(160, mashResult.apparentExtractPlato, boilDurationMin, evapRatePct);
  const pheResult = solvePlateHeatExchanger(120, 98.4, 11.0, 12.0, 8.0);

  // Invariant verification
  const invariantCheck = validateThermodynamicInvariants(
    gristKg + 10240, // Mass in (grist + water)
    16200 * 1.048, // Mass out (wort + spent grain)
    mashResult.thermalEnergyInputKwh + boilResult.steamThermalInputKwh,
    boilResult.steamThermalInputKwh * (boilResult.thermalEfficiencyPct / 100) + pheResult.coolingEnergyRecoveredKw
  );

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Flame className="w-5 h-5 text-amber-400" />
            <h1 className="text-base font-bold font-mono text-slate-100 uppercase tracking-wide">
              BREWHOUSE CONTINUOUS PROCESS PHYSICS & THERMODYNAMICS
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Deterministic mathematical models for starch enzymatic conversion, Darcy porous media filtration, internal
            calandria boiling, and counter-flow plate heat exchange.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono bg-slate-950 border border-slate-800 px-3 py-1.5 rounded">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span className="text-slate-300">1st Law Balance Error:</span>
          <span className="text-emerald-400 font-bold">{invariantCheck.energyErrorPct}%</span>
        </div>
      </div>

      {/* Grid: 4 Process Modules */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* MODULE 1: MASHING ENZYME KINETICS */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold text-amber-300 uppercase">
                1. MASHING & ENZYME SACCHARIFICATION
              </span>
            </div>
            <span className="text-[11px] font-mono text-slate-400">Michaelis-Menten Kinetics</span>
          </div>

          {/* Sliders */}
          <div className="grid grid-cols-2 gap-3 text-xs font-mono bg-slate-950 p-3 rounded border border-slate-800/80">
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Mash Temperature:</span>
                <span className="text-amber-300 font-bold">{mashTemp}°C</span>
              </div>
              <input
                type="range"
                min={60}
                max={74}
                step={0.5}
                value={mashTemp}
                onChange={(e) => setMashTemp(parseFloat(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Mash pH:</span>
                <span className="text-cyan-300 font-bold">{mashPh}</span>
              </div>
              <input
                type="range"
                min={5.0}
                max={5.8}
                step={0.05}
                value={mashPh}
                onChange={(e) => setMashPh(parseFloat(e.target.value))}
                className="w-full accent-cyan-500 cursor-pointer"
              />
            </div>
          </div>

          {/* Results Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800/60">
              <span className="text-[10px] text-slate-500">EXTRACT YIELD</span>
              <div className="text-base font-bold text-emerald-400">{mashResult.extractYieldPct}%</div>
              <span className="text-[10px] text-slate-400">Dry basis potential</span>
            </div>
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800/60">
              <span className="text-[10px] text-slate-500">APPARENT EXTRACT</span>
              <div className="text-base font-bold text-amber-300">{mashResult.apparentExtractPlato}°P</div>
              <span className="text-[10px] text-slate-400">Wort density</span>
            </div>
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800/60">
              <span className="text-[10px] text-slate-500">β-AMYLASE (FERM)</span>
              <div className="text-base font-bold text-cyan-300">{mashResult.betaAmylaseActivityPct}%</div>
              <span className="text-[10px] text-slate-400">Maltose synthesis</span>
            </div>
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800/60">
              <span className="text-[10px] text-slate-500">α-AMYLASE (BODY)</span>
              <div className="text-base font-bold text-purple-300">{mashResult.alphaAmylaseActivityPct}%</div>
              <span className="text-[10px] text-slate-400">Dextrin cleavage</span>
            </div>
          </div>

          <div className="bg-slate-950 p-2.5 rounded border border-slate-800 text-[11px] font-mono text-slate-300">
            <span className="text-amber-400 font-bold">Scientific Insight: </span>
            {mashResult.recommendation}
          </div>
        </div>

        {/* MODULE 2: LAUTER TUN HYDRAULICS (DARCY'S LAW) */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold text-cyan-300 uppercase">
                2. LAUTER TUN POROUS MEDIA HYDRAULICS
              </span>
            </div>
            <span className="text-[11px] font-mono text-slate-400">Darcy's Law: Q = (K·A·ΔP) / (μ·L)</span>
          </div>

          {/* Controls */}
          <div className="grid grid-cols-2 gap-3 text-xs font-mono bg-slate-950 p-3 rounded border border-slate-800/80">
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Runoff Elapsed Time:</span>
                <span className="text-cyan-300 font-bold">{lauterElapsedMin} min</span>
              </div>
              <input
                type="range"
                min={10}
                max={90}
                step={5}
                value={lauterElapsedMin}
                onChange={(e) => setLauterElapsedMin(parseInt(e.target.value))}
                className="w-full accent-cyan-500 cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between pt-3">
              <span className="text-slate-400">Raking Knives:</span>
              <button
                onClick={() => setRakingActive(!rakingActive)}
                className={`px-3 py-1 rounded font-bold text-xs transition cursor-pointer ${
                  rakingActive
                    ? "bg-amber-500 text-slate-950"
                    : "bg-slate-800 text-slate-300 border border-slate-700"
                }`}
              >
                {rakingActive ? "RAKING ACTIVE (35%)" : "KNIVES PARKED"}
              </button>
            </div>
          </div>

          {/* Hydraulics Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800/60">
              <span className="text-[10px] text-slate-500">DIFFERENTIAL ΔP</span>
              <div
                className={`text-base font-bold ${
                  lauterResult.differentialPressureMbar > 75 ? "text-red-400" : "text-cyan-300"
                }`}
              >
                {lauterResult.differentialPressureMbar} mbar
              </div>
              <span className="text-[10px] text-slate-400">Compaction: {lauterResult.bedCompactionRisk}</span>
            </div>
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800/60">
              <span className="text-[10px] text-slate-500">RUNOFF EXTRACT</span>
              <div className="text-base font-bold text-amber-300">{lauterResult.currentRunoffPlato}°P</div>
              <span className="text-[10px] text-slate-400">1st: 16.8°P</span>
            </div>
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800/60">
              <span className="text-[10px] text-slate-500">TURBIDITY</span>
              <div className="text-base font-bold text-emerald-400">{lauterResult.turbidityNtu} NTU</div>
              <span className="text-[10px] text-slate-400">Target &lt; 25 NTU</span>
            </div>
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800/60">
              <span className="text-[10px] text-slate-500">EXTRACT RECOVERY</span>
              <div className="text-base font-bold text-purple-300">{lauterResult.overallExtractRecoveryPct}%</div>
              <span className="text-[10px] text-slate-400">Total recovery</span>
            </div>
          </div>

          <div className="bg-slate-950 p-2.5 rounded border border-slate-800 text-[11px] font-mono text-slate-300">
            <span className="text-cyan-400 font-bold">Hydraulic State: </span>
            {lauterResult.recommendation}
          </div>
        </div>

        {/* MODULE 3: BOIL KETTLE & CALANDRIA THERMAL MODEL */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold text-red-400 uppercase">
                3. BOIL KETTLE & CALANDRIA THERMAL EFFICIENCY
              </span>
            </div>
            <span className="text-[11px] font-mono text-slate-400">h_fg = 2257 kJ/kg</span>
          </div>

          {/* Results */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800/60">
              <span className="text-[10px] text-slate-500">THERMAL EFFICIENCY</span>
              <div className="text-base font-bold text-emerald-400">{boilResult.thermalEfficiencyPct}%</div>
              <span className="text-[10px] text-slate-400">Useful heat in wort</span>
            </div>
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800/60">
              <span className="text-[10px] text-slate-500">STEAM CONSUMPTION</span>
              <div className="text-base font-bold text-amber-300">{boilResult.steamConsumedKg} kg</div>
              <span className="text-[10px] text-slate-400">{boilResult.steamThermalInputKwh} kWh_th</span>
            </div>
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800/60">
              <span className="text-[10px] text-slate-500">DMS VOLATILIZATION</span>
              <div className="text-base font-bold text-cyan-300">{boilResult.dmsStrippingEfficiencyPct}%</div>
              <span className="text-[10px] text-slate-400">Stripping kinetics</span>
            </div>
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800/60">
              <span className="text-[10px] text-slate-500">HOP ISO-ALPHA</span>
              <div className="text-base font-bold text-purple-300">
                {boilResult.hopAlphaAcidIsomerizationIsoAlphaPpm} IBU
              </div>
              <span className="text-[10px] text-slate-400">Tinseth model</span>
            </div>
          </div>

          <div className="bg-slate-950 p-2.5 rounded border border-slate-800 text-[11px] font-mono text-slate-300">
            <span className="text-red-400 font-bold">Thermodynamic Analysis: </span>
            Vapor condenser recovers latent heat of {boilResult.totalWaterEvaporatedKg} kg evaporated water, pre-heating
            Hot Liquor Tank HLT-01 to 84°C and saving 18.4% total brewhouse natural gas.
          </div>
        </div>

        {/* MODULE 4: PLATE HEAT EXCHANGER ε-NTU SOLVER */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold text-emerald-400 uppercase">
                4. COUNTER-FLOW PHE HEAT EXCHANGER (ε-NTU)
              </span>
            </div>
            <span className="text-[11px] font-mono text-slate-400">UA = 126 kW/K</span>
          </div>

          {/* Results */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800/60">
              <span className="text-[10px] text-slate-500">EFFECTIVENESS ε</span>
              <div className="text-base font-bold text-emerald-400">{pheResult.effectivenessEpsilon}</div>
              <span className="text-[10px] text-slate-400">NTU = {pheResult.ntu}</span>
            </div>
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800/60">
              <span className="text-[10px] text-slate-500">HEAT RECOVERED</span>
              <div className="text-base font-bold text-amber-300">{pheResult.coolingEnergyRecoveredKw} kW</div>
              <span className="text-[10px] text-slate-400">Direct thermal gain</span>
            </div>
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800/60">
              <span className="text-[10px] text-slate-500">WORT OUTLET</span>
              <div className="text-base font-bold text-cyan-300">{pheResult.wortOutletTempC}°C</div>
              <span className="text-[10px] text-slate-400">From 98.4°C inlet</span>
            </div>
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800/60">
              <span className="text-[10px] text-slate-500">WATER OUTLET</span>
              <div className="text-base font-bold text-purple-300">{pheResult.waterOutletTempC}°C</div>
              <span className="text-[10px] text-slate-400">Hot liquor to HLT</span>
            </div>
          </div>

          <div className="bg-slate-950 p-2.5 rounded border border-slate-800 text-[11px] font-mono text-slate-300">
            <span className="text-emerald-400 font-bold">Counter-Flow Optimization: </span>
            Generating {pheResult.hotWaterGeneratedHlH} hl/h of 84°C brewing water directly eliminates secondary steam
            reheating for the following mash cycle.
          </div>
        </div>
      </div>
    </div>
  );
};
