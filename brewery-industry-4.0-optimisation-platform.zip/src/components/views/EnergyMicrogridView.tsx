import React, { useState, useMemo } from "react";
import {
  Zap,
  Flame,
  Sun,
  Battery,
  TrendingDown,
  Sparkles,
  CheckCircle2,
  Layers,
  ArrowRight,
  ShieldCheck,
} from "lucide-react";
import {
  AreaChart,
  Area,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { EnergyGridState } from "../../types/brewery";
import { generateDayAheadTariffProfile, solveEnergyDispatch } from "../../physics/energyArbitrage";

interface EnergyMicrogridViewProps {
  energyState: EnergyGridState;
}

export const EnergyMicrogridView: React.FC<EnergyMicrogridViewProps> = ({ energyState }) => {
  const [batteryCapacityKwh, setBatteryCapacityKwh] = useState<number>(500);
  const [solarPeakKw, setSolarPeakKw] = useState<number>(350);

  // Hourly profile simulation
  const hourlyData = useMemo(() => {
    const tariffProfiles = generateDayAheadTariffProfile();
    let currentSoc = 65;

    return tariffProfiles.map((tp) => {
      const decision = solveEnergyDispatch(
        tp.hour,
        currentSoc,
        batteryCapacityKwh,
        150,
        tp.solarExpectedKw * (solarPeakKw / 350),
        tp.demandForecastKw,
        tp.tariffGbpKwh,
        true
      );

      // update soc
      if (decision.batteryAction === "CHARGE") {
        currentSoc = Math.min(95, currentSoc + (decision.batteryPowerKw / batteryCapacityKwh) * 100);
      } else if (decision.batteryAction === "DISCHARGE") {
        currentSoc = Math.max(15, currentSoc - (decision.batteryPowerKw / batteryCapacityKwh) * 100);
      }

      return {
        hour: `${tp.hour}:00`,
        tariffGbp: tp.tariffGbpKwh,
        solarKw: tp.solarExpectedKw,
        loadKw: tp.demandForecastKw,
        batteryKw: decision.batteryAction === "DISCHARGE" ? decision.batteryPowerKw : -decision.batteryPowerKw,
        gridImportKw: Math.round(decision.netGridImportKw),
        batterySoc: Math.round(decision.batterySocPct),
      };
    });
  }, [batteryCapacityKwh, solarPeakKw]);

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-amber-400" />
            <h1 className="text-base font-bold font-mono text-slate-100 uppercase tracking-wide">
              BREWERY MICROGRID, BESS ARBITRAGE & THERMAL CASCADE
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Predictive dispatch optimizing 500 kWh battery storage, 350 kWp solar PV array, and 1.12 MWth vapor
            condenser heat recovery.
          </p>
        </div>

        <div className="flex items-center gap-3 font-mono text-xs">
          <div className="bg-slate-950 border border-slate-800 px-3 py-1.5 rounded flex items-center gap-2">
            <span className="text-slate-400">Current Tariff:</span>
            <span className="text-amber-400 font-bold">£{energyState.currentGridTariffGbpKwh.toFixed(2)} / kWh</span>
          </div>
          <div className="bg-slate-950 border border-slate-800 px-3 py-1.5 rounded flex items-center gap-2">
            <span className="text-slate-400">Solar PV Live:</span>
            <span className="text-emerald-400 font-bold">{energyState.solarGenerationKw} kW</span>
          </div>
        </div>
      </div>

      {/* 4 Energy Asset Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 font-mono text-xs">
        {/* Solar PV */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3.5 space-y-1.5">
          <div className="flex items-center justify-between text-slate-400">
            <span>SOLAR PV ARRAY</span>
            <Sun className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-xl font-bold text-amber-300">245 kW <span className="text-xs font-normal text-slate-400">/ 350 kWp</span></div>
          <div className="text-[11px] text-emerald-400">64.5% Plant Offset Now</div>
        </div>

        {/* BESS Battery */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3.5 space-y-1.5">
          <div className="flex items-center justify-between text-slate-400">
            <span>BESS BATTERY STORAGE</span>
            <Battery className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl font-bold text-emerald-300">68% SOC <span className="text-xs font-normal text-slate-400">(340 kWh)</span></div>
          <div className="text-[11px] text-cyan-400">Discharging 45 kW (Peak Shave)</div>
        </div>

        {/* Thermal Recovery */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3.5 space-y-1.5">
          <div className="flex items-center justify-between text-slate-400">
            <span>VAPOR CONDENSER RECOVERY</span>
            <Flame className="w-4 h-4 text-red-400" />
          </div>
          <div className="text-xl font-bold text-red-300">1,120 kWth</div>
          <div className="text-[11px] text-emerald-400">88.4% Thermal Efficiency</div>
        </div>

        {/* Chiller COP */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-3.5 space-y-1.5">
          <div className="flex items-center justify-between text-slate-400">
            <span>GLYCOL CHILLER COP</span>
            <Zap className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-xl font-bold text-cyan-300">4.25 COP</div>
          <div className="text-[11px] text-slate-400">-2.0°C Loop Supply</div>
        </div>
      </div>

      {/* 24-Hour Day Ahead Dispatch Chart */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
          <div>
            <h2 className="text-xs font-mono font-bold text-slate-100 uppercase">
              24-Hour Predictive Microgrid Dispatch & Price Arbitrage
            </h2>
            <p className="text-[11px] font-mono text-slate-400">
              Grid price (£/kWh) vs Solar Generation, Battery Dispatch (kW), and Net Grid Draw (kW)
            </p>
          </div>
          <span className="text-xs font-mono bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded border border-emerald-500/40">
            Est. Daily Arbitrage Savings: £148.50
          </span>
        </div>

        <div className="h-80 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={hourlyData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="hour" stroke="#94a3b8" tick={{ fontSize: 11 }} />
              <YAxis stroke="#94a3b8" tick={{ fontSize: 11 }} unit="kW" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#020617",
                  borderColor: "#334155",
                  fontSize: "12px",
                  fontFamily: "monospace",
                }}
              />
              <Legend wrapperStyle={{ fontSize: "11px", fontFamily: "monospace", paddingTop: "8px" }} />
              <Area type="monotone" dataKey="solarKw" stroke="#f59e0b" fill="#f59e0b" fillOpacity={0.25} name="Solar PV (kW)" />
              <Area type="monotone" dataKey="loadKw" stroke="#94a3b8" fill="#94a3b8" fillOpacity={0.1} name="Brewery Load (kW)" />
              <Area type="monotone" dataKey="batteryKw" stroke="#10b981" fill="#10b981" fillOpacity={0.3} name="Battery Discharge (kW)" />
              <Area type="monotone" dataKey="gridImportKw" stroke="#06b6d4" fill="#06b6d4" fillOpacity={0.2} name="Net Grid Import (kW)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Thermal Cascade Diagram / Sankey Narrative */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3 font-mono text-xs">
        <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
          <Flame className="w-4 h-4 text-amber-400" />
          <h3 className="font-bold text-slate-100 uppercase">Thermodynamic Heat Cascade Closed-Loop Balance</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-center">
          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
            <span className="text-slate-500 text-[10px]">1. STEAM BOILER</span>
            <div className="font-bold text-amber-300">1,620 kWth In</div>
            <p className="text-[10px] text-slate-400">91.5% ASME efficiency natural gas</p>
          </div>
          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
            <span className="text-slate-500 text-[10px]">2. WORT BOIL & CALANDRIA</span>
            <div className="font-bold text-red-400">1,482 kWth In Wort</div>
            <p className="text-[10px] text-slate-400">6.5% evaporation rate (DMS stripped)</p>
          </div>
          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
            <span className="text-slate-500 text-[10px]">3. VAPOR CONDENSER</span>
            <div className="font-bold text-cyan-300">1,120 kWth Recovered</div>
            <p className="text-[10px] text-slate-400">Latent heat condensation to liquor</p>
          </div>
          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
            <span className="text-slate-500 text-[10px]">4. HOT LIQUOR TANK (HLT)</span>
            <div className="font-bold text-emerald-400">84°C Preheated Strike Water</div>
            <p className="text-[10px] text-slate-400">Zero virgin gas reheating needed for next mash</p>
          </div>
        </div>
      </div>
    </div>
  );
};
