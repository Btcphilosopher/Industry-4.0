import React, { useState } from "react";
import {
  Droplets,
  CheckCircle2,
  AlertTriangle,
  RotateCw,
  Sparkles,
  Sliders,
  ShieldCheck,
  Flame,
} from "lucide-react";
import { CipCircuitState } from "../../types/brewery";
import { optimizeCipCycle } from "../../physics/cipOptimizer";

interface CipOptimizationViewProps {
  circuits: CipCircuitState[];
}

export const CipOptimizationView: React.FC<CipOptimizationViewProps> = ({ circuits }) => {
  // Interactive Sinner's Circle controls
  const [causticTemp, setCausticTemp] = useState<number>(75.0);
  const [causticConcPct, setCausticConcPct] = useState<number>(2.0);
  const [flowVelocity, setFlowVelocity] = useState<number>(2.0);
  const [circuitType, setCircuitType] = useState<"FERMENTER" | "BREWHOUSE_LINE" | "BRITE_TANK" | "CENTRIFUGE">("FERMENTER");

  // Optimizer solver
  const cipOpt = optimizeCipCycle({
    circuitType,
    vesselVolumeHl: 300,
    causticConcPct,
    causticTempC: causticTemp,
    flowVelocityMS: flowVelocity,
    contactTimeMinutes: 25,
    waterRecoveryEnabled: true,
  });

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Droplets className="w-5 h-5 text-blue-400" />
            <h1 className="text-base font-bold font-mono text-slate-100 uppercase tracking-wide">
              CIP HYGIENE OPTIMIZATION & SINNER'S CIRCLE SOLVER
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            4-Factor physical optimization (Chemical, Thermal, Kinetic Mechanical Action, and Contact Time) proving
            strict statutory Log-6 sterility while minimizing water, thermal energy, and cycle times.
          </p>
        </div>

        <div className="flex items-center gap-3 font-mono text-xs">
          <div className="bg-slate-950 border border-slate-800 px-3 py-1.5 rounded flex items-center gap-2">
            <Droplets className="w-4 h-4 text-blue-400" />
            <span className="text-slate-400">Water Saved Today:</span>
            <span className="text-blue-300 font-bold">110.5 hl ({cipOpt.waterSavingsPct}%)</span>
          </div>
        </div>
      </div>

      {/* Active CIP Circuits Tracking */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {circuits.map((circuit) => {
          const progressPct = Math.round((circuit.elapsedSeconds / circuit.totalDurationSeconds) * 100);
          return (
            <div
              key={circuit.id}
              className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono text-xs space-y-3"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-100 text-sm">{circuit.name}</span>
                  <span className="text-[10px] text-slate-400">({circuit.activeVesselId})</span>
                </div>
                <span
                  className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase ${
                    circuit.currentStep === "IDLE"
                      ? "bg-slate-800 text-slate-400"
                      : "bg-red-500/20 text-red-300 border border-red-500/40 animate-pulse"
                  }`}
                >
                  {circuit.currentStep}
                </span>
              </div>

              <div className="grid grid-cols-3 gap-2 text-[11px] bg-slate-950 p-2.5 rounded border border-slate-800/80">
                <div>
                  <span className="text-[9px] text-slate-500 block">CAUSTIC TEMP</span>
                  <span className="text-amber-300 font-bold">{circuit.causticTempC}°C</span>
                </div>
                <div>
                  <span className="text-[9px] text-slate-500 block">FLOW VELOCITY</span>
                  <span className="text-cyan-300 font-bold">{circuit.flowVelocityMS} m/s</span>
                </div>
                <div>
                  <span className="text-[9px] text-slate-500 block">WATER RECOVERY</span>
                  <span className="text-blue-300 font-bold">{circuit.waterRecoveryTankPct}% TANK</span>
                </div>
              </div>

              {/* Progress */}
              <div className="space-y-1">
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>Elapsed Time: {Math.round(circuit.elapsedSeconds / 60)} min / {Math.round(circuit.totalDurationSeconds / 60)} min</span>
                  <span>{progressPct}% Completed</span>
                </div>
                <div className="h-1.5 w-full bg-slate-950 rounded-full overflow-hidden">
                  <div className="h-full bg-blue-500 rounded-full" style={{ width: `${progressPct}%` }}></div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Sinner's Circle Interactive Physical Optimizer */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Left: Parameter Sliders */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-4 font-mono text-xs">
          <div className="border-b border-slate-800 pb-2">
            <h3 className="font-bold text-slate-100 uppercase">Sinner's Circle Parameter Tuning</h3>
            <p className="text-[11px] text-slate-400">Rebalance the 4 interdependent cleaning factors</p>
          </div>

          {/* Circuit Type */}
          <div className="space-y-1.5">
            <label className="text-slate-400 text-[11px]">Target Vessel Circuit:</label>
            <div className="grid grid-cols-2 gap-1.5">
              {(["BREWHOUSE_LINE", "FERMENTER", "BRITE_TANK", "CENTRIFUGE"] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => setCircuitType(t)}
                  className={`py-1.5 px-2 rounded text-center text-[10px] font-bold transition cursor-pointer ${
                    circuitType === t
                      ? "bg-blue-600 text-white"
                      : "bg-slate-950 text-slate-400 border border-slate-800 hover:border-slate-700"
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* Temp */}
          <div className="space-y-1">
            <div className="flex justify-between text-slate-400">
              <span>Wash Temperature:</span>
              <span className="text-amber-300 font-bold">{causticTemp}°C</span>
            </div>
            <input
              type="range"
              min={50}
              max={85}
              step={1}
              value={causticTemp}
              onChange={(e) => setCausticTemp(parseFloat(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          {/* Concentration */}
          <div className="space-y-1">
            <div className="flex justify-between text-slate-400">
              <span>Caustic Concentration:</span>
              <span className="text-purple-300 font-bold">{causticConcPct}% NaOH</span>
            </div>
            <input
              type="range"
              min={1.0}
              max={3.5}
              step={0.1}
              value={causticConcPct}
              onChange={(e) => setCausticConcPct(parseFloat(e.target.value))}
              className="w-full accent-purple-500 cursor-pointer"
            />
          </div>

          {/* Flow Velocity */}
          <div className="space-y-1">
            <div className="flex justify-between text-slate-400">
              <span>Mechanical Flow Velocity:</span>
              <span className="text-cyan-300 font-bold">{flowVelocity} m/s</span>
            </div>
            <input
              type="range"
              min={1.2}
              max={2.6}
              step={0.1}
              value={flowVelocity}
              onChange={(e) => setFlowVelocity(parseFloat(e.target.value))}
              className="w-full accent-cyan-500 cursor-pointer"
            />
          </div>
        </div>

        {/* Right 2 Cols: Sinner's Circle Validation & Savings */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
            <h3 className="font-bold text-slate-100 uppercase">Sinner's Factor Contribution & Sterility Proof</h3>
            <span
              className={`text-xs px-2.5 py-0.5 rounded font-bold ${
                cipOpt.hygieneValidationPassed
                  ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                  : "bg-red-500/20 text-red-300 border border-red-500/40"
              }`}
            >
              {cipOpt.hygieneValidationPassed
                ? `LOG-${cipOpt.logReductionFactor} STERILITY CERTIFIED`
                : "INSUFFICIENT LOG REDUCTION"}
            </span>
          </div>

          {/* 4 Factor Visual Bars */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-[10px] text-slate-500 block">CHEMICAL POTENCY</span>
              <div className="text-lg font-bold text-purple-300">{cipOpt.sinnersCircleScores.chemicalScore}</div>
              <span className="text-[10px] text-slate-400">Saponification</span>
            </div>

            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-[10px] text-slate-500 block">THERMAL ENERGY</span>
              <div className="text-lg font-bold text-amber-300">{cipOpt.sinnersCircleScores.temperatureScore}</div>
              <span className="text-[10px] text-slate-400">Solubility rate</span>
            </div>

            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-[10px] text-slate-500 block">MECHANICAL ACTION</span>
              <div className="text-lg font-bold text-cyan-300">{cipOpt.sinnersCircleScores.mechanicalScore}</div>
              <span className="text-[10px] text-slate-400">Wall shear stress</span>
            </div>

            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-[10px] text-slate-500 block">CONTACT TIME</span>
              <div className="text-lg font-bold text-emerald-400">{cipOpt.sinnersCircleScores.timeScore}</div>
              <span className="text-[10px] text-slate-400">Log-6 Inactivation</span>
            </div>
          </div>

          {/* Savings Matrix */}
          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2">
            <div className="text-slate-300 font-bold flex items-center justify-between">
              <span>Optimized Resource Footprint vs Conventional Fixed Timer:</span>
              <span className="text-emerald-400">28.5% Net Chemical Savings</span>
            </div>

            <div className="grid grid-cols-3 gap-2 text-[11px] pt-1">
              <div>
                <span className="text-slate-500">Water Usage:</span>
                <div className="text-blue-300 font-bold">{cipOpt.optimizedWaterUsageHl} hl / cycle</div>
              </div>
              <div>
                <span className="text-slate-500">Thermal Energy:</span>
                <div className="text-amber-300 font-bold">{cipOpt.optimizedEnergyKwh} kWh</div>
              </div>
              <div>
                <span className="text-slate-500">Chemical Mass:</span>
                <div className="text-purple-300 font-bold">{cipOpt.optimizedChemicalKg} kg NaOH</div>
              </div>
            </div>
          </div>

          <div className="bg-blue-950/20 border border-blue-500/30 rounded p-2.5 text-blue-300">
            <span className="font-bold flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-blue-400" /> Food Safety Invariant:
            </span>
            <p className="text-[11px] text-slate-400 mt-0.5">{cipOpt.recommendation}</p>
          </div>
        </div>
      </div>
    </div>
  );
};
