import React, { useState } from "react";
import {
  Sliders,
  RotateCw,
  Clock,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Sparkles,
  Layers,
} from "lucide-react";
import { Vessel, ActiveBatch } from "../../types/brewery";

interface TanksScheduleViewProps {
  vessels: Vessel[];
  batches: ActiveBatch[];
  onNavigateToTab: (tab: string) => void;
}

export const TanksScheduleView: React.FC<TanksScheduleViewProps> = ({
  vessels,
  batches,
  onNavigateToTab,
}) => {
  const [filterType, setFilterType] = useState<"ALL" | "FERMENTER" | "BRITE_TANK">("ALL");

  const filteredVessels = vessels.filter((v) => {
    if (filterType === "ALL") return v.type === "FERMENTER" || v.type === "BRITE_TANK";
    return v.type === filterType;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-amber-400" />
            <h1 className="text-base font-bold font-mono text-slate-100 uppercase tracking-wide">
              CELLAR VESSEL SCHEDULE & TURNAROUND OPTIMIZATION
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Dynamic scheduling matrix balancing fermenter residence times, centrifuge throughput, brite tank
            availability, and CIP turnaround windows.
          </p>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-2 font-mono text-xs">
          {(["ALL", "FERMENTER", "BRITE_TANK"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setFilterType(t)}
              className={`px-3 py-1.5 rounded transition cursor-pointer font-bold ${
                filterType === t
                  ? "bg-amber-500 text-slate-950 shadow-sm"
                  : "bg-slate-950 text-slate-400 border border-slate-800 hover:border-slate-700"
              }`}
            >
              {t === "ALL" ? "ALL CELLAR VESSELS" : t === "FERMENTER" ? "FERMENTERS (16)" : "BRITE TANKS (6)"}
            </button>
          ))}
        </div>
      </div>

      {/* Optimization Callout */}
      <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4 font-mono text-xs flex items-start gap-3">
        <Sparkles className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <div className="font-bold text-amber-300">
            Cellar Optimization Advisor: Potential +14.2 Hours Weekly Throughput Gain
          </div>
          <p className="text-slate-300">
            By shifting Fermenter F-04 crash cooling to begin 3.5 hours earlier (supported by ODE diacetyl clearance
            proof), BBT-03 can be filled during low-tariff hours, freeing F-04 for tomorrow's double Czech Pilsner brew
            day.
          </p>
        </div>
      </div>

      {/* Tanks Matrix Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3.5">
        {filteredVessels.map((vessel) => {
          const batch = batches.find((b) => b.currentVesselId === vessel.id);
          const progressPct =
            vessel.totalCycleHours > 0
              ? Math.min(100, Math.round((vessel.hoursInCurrentState / vessel.totalCycleHours) * 100))
              : 0;

          return (
            <div
              key={vessel.id}
              className="bg-slate-900 border border-slate-800 rounded-lg p-3.5 flex flex-col justify-between font-mono text-xs hover:border-slate-700 transition space-y-3"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-100 text-sm">{vessel.id}</span>
                  <span className="text-[10px] text-slate-400">{vessel.type === "FERMENTER" ? "Unitank" : "Brite"}</span>
                </div>
                <span
                  className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase ${
                    vessel.state === "ACTIVE_FERMENTATION"
                      ? "bg-purple-500/20 text-purple-300 border border-purple-500/40"
                      : vessel.state === "DIACETYL_REST"
                      ? "bg-amber-500/20 text-amber-300 border border-amber-500/40"
                      : vessel.state === "CRASH_COOLING"
                      ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40"
                      : vessel.state === "PACKAGING" || vessel.state === "READY_FOR_PACKAGING"
                      ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                      : vessel.state === "CIP_CAUSTIC"
                      ? "bg-red-500/20 text-red-300 border border-red-500/40 animate-pulse"
                      : "bg-slate-800 text-slate-400 border border-slate-700"
                  }`}
                >
                  {vessel.state.replace("_", " ")}
                </span>
              </div>

              {/* Middle Tank State */}
              <div className="space-y-1.5">
                <div className="text-slate-200 font-semibold truncate">
                  {vessel.recipeName || (vessel.currentVolumeHl > 0 ? "In Process Batch" : "Ready for CIP / Filling")}
                </div>

                <div className="grid grid-cols-3 gap-1 text-[11px] text-slate-400 bg-slate-950 p-2 rounded border border-slate-800/80">
                  <div>
                    <span className="text-[9px] text-slate-500 block">TEMP</span>
                    <span className="text-amber-300 font-bold">{vessel.temperature}°C</span>
                  </div>
                  <div>
                    <span className="text-[9px] text-slate-500 block">VOLUME</span>
                    <span className="text-slate-200 font-bold">{vessel.currentVolumeHl} hl</span>
                  </div>
                  <div>
                    <span className="text-[9px] text-slate-500 block">GRAVITY</span>
                    <span className="text-purple-300 font-bold">
                      {vessel.gravityPlato > 0 ? `${vessel.gravityPlato}°P` : "—"}
                    </span>
                  </div>
                </div>
              </div>

              {/* Progress & Time */}
              <div className="space-y-1 pt-1 border-t border-slate-800">
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>Cycle Progress:</span>
                  <span>
                    {vessel.hoursInCurrentState}h / {vessel.totalCycleHours}h ({progressPct}%)
                  </span>
                </div>
                <div className="h-1.5 w-full bg-slate-950 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all ${
                      progressPct > 90 ? "bg-emerald-500" : "bg-purple-500"
                    }`}
                    style={{ width: `${progressPct}%` }}
                  ></div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
