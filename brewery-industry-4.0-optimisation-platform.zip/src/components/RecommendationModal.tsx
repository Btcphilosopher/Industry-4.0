import React from "react";
import {
  X,
  Sparkles,
  CheckCircle2,
  ShieldCheck,
  Zap,
  Droplets,
  TrendingUp,
  Clock,
  ArrowRight,
} from "lucide-react";
import { OptimizationProposal } from "../types/brewery";

interface RecommendationModalProps {
  proposal: OptimizationProposal | null;
  onClose: () => void;
  onApprove: (id: string) => void;
  onReject: (id: string) => void;
}

export const RecommendationModal: React.FC<RecommendationModalProps> = ({
  proposal,
  onClose,
  onApprove,
  onReject,
}) => {
  if (!proposal) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-amber-500/40 rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto font-mono text-xs shadow-2xl shadow-amber-500/10 space-y-4 p-5">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <div>
              <span className="text-[10px] text-amber-400 font-bold uppercase">{proposal.category} OPTIMIZATION PROPOSAL</span>
              <h2 className="text-sm font-bold text-slate-100">{proposal.title}</h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded bg-slate-800 text-slate-400 hover:text-slate-200 transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Confidence & Summary */}
        <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-slate-400">Confidence Rating:</span>
            <span className="text-emerald-400 font-bold text-sm">{proposal.confidencePct}% Mathematically Verified</span>
          </div>
          <p className="text-slate-300 text-xs leading-relaxed">{proposal.impactSummary}</p>
        </div>

        {/* Action Description */}
        <div className="space-y-1.5">
          <span className="font-bold text-slate-200 uppercase block">Recommended Supervisory Action:</span>
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-amber-300 leading-relaxed">
            {proposal.recommendedAction}
          </div>
        </div>

        {/* Physical Basis & Equations */}
        <div className="space-y-1.5">
          <span className="font-bold text-slate-200 uppercase block">Underlying Process Physics & First-Principles Proof:</span>
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-slate-300 text-[11px] leading-relaxed">
            {proposal.physicalBasis}
          </div>
        </div>

        {/* Hard Constraints Verification Checklist */}
        <div className="space-y-2">
          <span className="font-bold text-slate-200 uppercase block">Hard Constraints & Food Safety Checks:</span>
          <div className="bg-emerald-950/20 border border-emerald-500/30 rounded-lg p-3 space-y-1.5 text-emerald-300">
            {proposal.hardConstraintsVerified.map((constraint, i) => (
              <div key={i} className="flex items-start gap-2 text-[11px]">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>{constraint}</span>
              </div>
            ))}
          </div>
        </div>

        {/* KPI Gains */}
        <div className="grid grid-cols-3 gap-2 text-center pt-1">
          {proposal.kpis.energySavingsKwh && (
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-[10px] text-slate-500 block">ENERGY GAIN</span>
              <div className="text-base font-bold text-amber-300">-{proposal.kpis.energySavingsKwh} kWh</div>
            </div>
          )}
          {proposal.kpis.costSavingsGbp && (
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-[10px] text-slate-500 block">COST SAVINGS</span>
              <div className="text-base font-bold text-emerald-400">+£{proposal.kpis.costSavingsGbp}</div>
            </div>
          )}
          {proposal.kpis.timeGainHours && (
            <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
              <span className="text-[10px] text-slate-500 block">TIME GAIN</span>
              <div className="text-base font-bold text-purple-300">+{proposal.kpis.timeGainHours}h</div>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
          <button
            onClick={() => {
              onReject(proposal.id);
              onClose();
            }}
            className="px-4 py-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold transition cursor-pointer"
          >
            Reject Proposal
          </button>
          <button
            onClick={() => {
              onApprove(proposal.id);
              onClose();
            }}
            className="px-5 py-2 rounded bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold flex items-center gap-1.5 transition cursor-pointer shadow-lg shadow-amber-500/10"
          >
            <Sparkles className="w-4 h-4" />
            <span>Approve & Dispatch to SCADA</span>
          </button>
        </div>
      </div>
    </div>
  );
};
