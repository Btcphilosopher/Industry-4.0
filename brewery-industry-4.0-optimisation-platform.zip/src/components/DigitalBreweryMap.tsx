import React, { useState } from "react";
import {
  Flame,
  Droplets,
  Zap,
  RotateCw,
  Gauge,
  Info,
  CheckCircle2,
  AlertTriangle,
  Play,
  ArrowRight,
} from "lucide-react";
import { Vessel, ActiveBatch } from "../types/brewery";

interface DigitalBreweryMapProps {
  vessels: Vessel[];
  batches: ActiveBatch[];
  onSelectVessel: (vessel: Vessel) => void;
  onNavigateToTab: (tab: string) => void;
}

export const DigitalBreweryMap: React.FC<DigitalBreweryMapProps> = ({
  vessels,
  batches,
  onSelectVessel,
  onNavigateToTab,
}) => {
  const [selectedVesselId, setSelectedVesselId] = useState<string>("BK-01");

  const selectedVessel = vessels.find((v) => v.id === selectedVesselId) || vessels[0];
  const activeBatchForVessel = batches.find((b) => b.currentVesselId === selectedVessel?.id);

  return (
    <div className="space-y-4">
      {/* Top Banner & Control Legend */}
      <div className="bg-[#1A1C1E] border border-[#2D3035] rounded-lg p-4 flex flex-wrap items-center justify-between gap-4 shadow-lg">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-[#E0E2E6] uppercase tracking-wide flex items-center gap-2">
              <span className="h-2.5 w-2.5 rounded-full bg-[#00FF41]"></span>
              Digital Twin Synoptic Process Flow (P&ID)
            </h2>
            <span className="text-[10px] bg-[#121417] text-[#00D1FF] font-mono px-2 py-0.5 rounded border border-[#2D3035]">
              PHYSICS & TELEMETRY STREAM
            </span>
          </div>
          <p className="text-xs text-[#70757E] mt-1">
            Real-time mass and thermal energy balances across continuous brewhouse, fermentation cellars, and packaging.
            Click any unit to inspect state variables, differential pressures, and kinetic ODEs.
          </p>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-4 text-xs font-mono text-[#E0E2E6]">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded bg-[#FF6B00] inline-block"></span>
            <span>Hot Wort / Steam</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded bg-[#00D1FF] inline-block"></span>
            <span>Cold Water / Glycol</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded bg-[#A855F7] inline-block"></span>
            <span>Active Fermenter</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded bg-[#00FF41] inline-block"></span>
            <span>Brite Beer</span>
          </div>
        </div>
      </div>

      {/* Main Interactive Synoptic Canvas */}
      <div className="grid grid-cols-1 xl:grid-cols-4 gap-4">
        {/* Visual Map (3 columns on large screens) */}
        <div className="xl:col-span-3 bg-[#0A0B0D] border border-[#2D3035] rounded-lg p-5 overflow-x-auto shadow-lg">
          <div className="min-w-[960px] space-y-6">
            {/* STAGE 1: RAW MATERIALS & BREWHOUSE */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-mono font-bold text-[#FF6B00] tracking-wider">
                  STAGE 1: HOT BREWHOUSE & THERMODYNAMIC EXTRACTION
                </span>
                <span className="text-[11px] font-mono text-[#70757E]">
                  STEAM HEAT RECOVERY: 1.12 MWth | PHE EFFECTIVENESS: ε = 0.88
                </span>
              </div>

              <div className="grid grid-cols-5 gap-3">
                {/* 1. SILOS & MILL */}
                <div className="bg-[#1A1C1E] border border-[#2D3035] rounded-lg p-3 relative flex flex-col justify-between hover:border-[#70757E] transition">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-[#E0E2E6]">SILO & MILL</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#00FF41]/20 text-[#00FF41] font-mono">
                      READY
                    </span>
                  </div>
                  <div className="my-3 text-center">
                    <div className="inline-block p-2 rounded-lg bg-[#121417] border border-[#2D3035]">
                      <div className="w-12 h-14 border-2 border-dashed border-[#FF6B00]/40 rounded flex items-center justify-center text-[#FF6B00] font-mono text-xs">
                        4-ROLL
                      </div>
                    </div>
                  </div>
                  <div className="text-[11px] font-mono text-[#70757E] space-y-0.5">
                    <div className="flex justify-between">
                      <span>Grist Flow:</span>
                      <span className="text-[#E0E2E6]">3,200 kg</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Moisture:</span>
                      <span className="text-[#00FF41]">4.2%</span>
                    </div>
                  </div>
                </div>

                {/* 2. MASH TUN MT-01 */}
                <div
                  onClick={() => setSelectedVesselId("MT-01")}
                  className={`bg-[#1A1C1E] border rounded-lg p-3 relative flex flex-col justify-between cursor-pointer transition ${
                    selectedVesselId === "MT-01"
                      ? "border-[#FF6B00] bg-[#1A1C1E] shadow-md shadow-[#FF6B00]/10"
                      : "border-[#2D3035] hover:border-[#70757E]"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-[#FF6B00]">MASH TUN (MT-01)</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#FF6B00]/20 text-[#FF6B00] font-mono animate-pulse">
                      HEATING
                    </span>
                  </div>
                  <div className="my-2 text-center">
                    <div className="text-lg font-bold font-mono text-[#E0E2E6]">65.4°C</div>
                    <div className="text-[10px] text-[#70757E] font-mono">Target: 67.0°C | α-Amylase</div>
                  </div>
                  <div className="text-[11px] font-mono text-[#70757E] space-y-0.5 border-t border-[#2D3035] pt-1.5">
                    <div className="flex justify-between">
                      <span>Liquor:Grist:</span>
                      <span className="text-[#E0E2E6]">3.2 L/kg</span>
                    </div>
                    <div className="flex justify-between">
                      <span>pH:</span>
                      <span className="text-[#00FF41]">5.35</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Steam Duty:</span>
                      <span className="text-[#FF6B00]">62%</span>
                    </div>
                  </div>
                </div>

                {/* 3. LAUTER TUN LT-01 */}
                <div
                  onClick={() => setSelectedVesselId("LT-01")}
                  className={`bg-[#1A1C1E] border rounded-lg p-3 relative flex flex-col justify-between cursor-pointer transition ${
                    selectedVesselId === "LT-01"
                      ? "border-[#FF6B00] bg-[#1A1C1E] shadow-md shadow-[#FF6B00]/10"
                      : "border-[#2D3035] hover:border-[#70757E]"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-[#FF6B00]">LAUTER TUN (LT-01)</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#00D1FF]/20 text-[#00D1FF] font-mono">
                      RUNOFF
                    </span>
                  </div>
                  <div className="my-2 text-center">
                    <div className="text-lg font-bold font-mono text-[#00D1FF]">110 hl/h</div>
                    <div className="text-[10px] text-[#70757E] font-mono">ΔP: 42 mbar (Darcy OK)</div>
                  </div>
                  <div className="text-[11px] font-mono text-[#70757E] space-y-0.5 border-t border-[#2D3035] pt-1.5">
                    <div className="flex justify-between">
                      <span>Turbidity:</span>
                      <span className="text-[#00FF41]">18.5 NTU</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Sparge Temp:</span>
                      <span className="text-[#E0E2E6]">78.0°C</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Runoff Plato:</span>
                      <span className="text-[#FF6B00]">16.4°P</span>
                    </div>
                  </div>
                </div>

                {/* 4. BREW KETTLE & CALANDRIA BK-01 */}
                <div
                  onClick={() => setSelectedVesselId("BK-01")}
                  className={`bg-[#1A1C1E] border rounded-lg p-3 relative flex flex-col justify-between cursor-pointer transition ${
                    selectedVesselId === "BK-01"
                      ? "border-[#FF6B00] bg-[#1A1C1E] shadow-md shadow-[#FF6B00]/10"
                      : "border-[#2D3035] hover:border-[#70757E]"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-[#FF6B00]">CALANDRIA (BK-01)</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-red-500/20 text-red-300 font-mono animate-pulse">
                      BOILING
                    </span>
                  </div>
                  <div className="my-2 text-center">
                    <div className="text-lg font-bold font-mono text-red-400">100.2°C</div>
                    <div className="text-[10px] text-[#70757E] font-mono">Evap Rate: 6.5%/h</div>
                  </div>
                  <div className="text-[11px] font-mono text-[#70757E] space-y-0.5 border-t border-[#2D3035] pt-1.5">
                    <div className="flex justify-between">
                      <span>Steam Press:</span>
                      <span className="text-[#E0E2E6]">2.5 bar</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Thermal Eff:</span>
                      <span className="text-[#00FF41]">91.2%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>DMS Strip:</span>
                      <span className="text-[#00FF41]">98.5%</span>
                    </div>
                  </div>
                </div>

                {/* 5. WHIRLPOOL & PHE CHILLER */}
                <div
                  onClick={() => setSelectedVesselId("PHE-01")}
                  className={`bg-[#1A1C1E] border rounded-lg p-3 relative flex flex-col justify-between cursor-pointer transition ${
                    selectedVesselId === "PHE-01"
                      ? "border-[#FF6B00] bg-[#1A1C1E] shadow-md shadow-[#FF6B00]/10"
                      : "border-[#2D3035] hover:border-[#70757E]"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-[#00D1FF]">PHE CHILLER</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#00D1FF]/20 text-[#00D1FF] font-mono">
                      HEAT RECOV
                    </span>
                  </div>
                  <div className="my-2 text-center">
                    <div className="text-lg font-bold font-mono text-[#00D1FF]">11.4°C</div>
                    <div className="text-[10px] text-[#70757E] font-mono">Hot Water Gen: 84°C</div>
                  </div>
                  <div className="text-[11px] font-mono text-[#70757E] space-y-0.5 border-t border-[#2D3035] pt-1.5">
                    <div className="flex justify-between">
                      <span>Wort In/Out:</span>
                      <span className="text-[#E0E2E6]">98° → 11°C</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Recovered:</span>
                      <span className="text-[#00FF41]">1,063 kW</span>
                    </div>
                    <div className="flex justify-between">
                      <span>DO Injected:</span>
                      <span className="text-[#00D1FF]">10.0 ppm</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* STAGE 2: CELLAR FERMENTATION (16 UNITANKS) */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-mono font-bold text-[#A855F7] tracking-wider">
                  STAGE 2: FERMENTATION CELLAR & KINETIC ODE TWIN (16 UNITANKS)
                </span>
                <span className="text-[11px] font-mono text-[#70757E]">
                  CO2 RECOVERY ACTIVE: 145 kg/h | GLYCOL LOOP: -2.0°C
                </span>
              </div>

              <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
                {vessels
                  .filter((v) => v.type === "FERMENTER")
                  .map((v) => {
                    const isSelected = selectedVesselId === v.id;
                    return (
                      <div
                        key={v.id}
                        onClick={() => setSelectedVesselId(v.id)}
                        className={`bg-[#1A1C1E] border rounded p-2.5 cursor-pointer transition text-xs font-mono relative flex flex-col justify-between ${
                          isSelected
                            ? "border-[#A855F7] bg-[#1A1C1E] shadow-md shadow-[#A855F7]/10"
                            : "border-[#2D3035] hover:border-[#70757E]"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-[#E0E2E6]">{v.id}</span>
                          <span
                            className={`text-[9px] px-1 py-0.2 rounded font-mono ${
                              v.state === "ACTIVE_FERMENTATION"
                                ? "bg-[#A855F7]/20 text-[#A855F7]"
                                : v.state === "DIACETYL_REST"
                                ? "bg-[#FF6B00]/20 text-[#FF6B00]"
                                : v.state === "CRASH_COOLING"
                                ? "bg-[#00D1FF]/20 text-[#00D1FF]"
                                : v.state === "CIP_CAUSTIC"
                                ? "bg-red-500/20 text-red-300 animate-pulse"
                                : "bg-[#121417] text-[#70757E]"
                            }`}
                          >
                            {v.state === "ACTIVE_FERMENTATION"
                              ? "FERM"
                              : v.state === "DIACETYL_REST"
                              ? "REST"
                              : v.state === "CRASH_COOLING"
                              ? "CRASH"
                              : v.state === "CIP_CAUSTIC"
                              ? "CIP"
                              : "CLEAN"}
                          </span>
                        </div>

                        {/* Tank Graphic Level */}
                        <div className="my-2 relative h-14 bg-[#0A0B0D] rounded border border-[#2D3035] overflow-hidden flex flex-col justify-end">
                          <div
                            className={`w-full transition-all ${
                              v.state === "ACTIVE_FERMENTATION"
                                ? "bg-purple-600/50"
                                : v.state === "DIACETYL_REST"
                                ? "bg-amber-600/50"
                                : v.state === "CRASH_COOLING"
                                ? "bg-cyan-600/50"
                                : v.state === "CIP_CAUSTIC"
                                ? "bg-red-600/50"
                                : "bg-[#2D3035]/40"
                            }`}
                            style={{ height: `${v.currentVolumeHl > 0 ? (v.currentVolumeHl / v.capacityHl) * 100 : 8}%` }}
                          ></div>
                          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                            <span className="text-[11px] font-bold text-[#E0E2E6]">{v.temperature}°C</span>
                            {v.gravityPlato > 0 && (
                              <span className="text-[9px] text-[#FF6B00]">{v.gravityPlato}°P</span>
                            )}
                          </div>
                        </div>

                        <div className="text-[10px] text-[#70757E] truncate">
                          {v.recipeName || "Empty / Sterile"}
                        </div>
                      </div>
                    );
                  })}
              </div>
            </div>

            {/* STAGE 3: BRITE TANKS & PACKAGING */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-mono font-bold text-[#00FF41] tracking-wider">
                  STAGE 3: CONDITIONING, BRITE BEER TANKS & PACKAGING LINES
                </span>
                <span className="text-[11px] font-mono text-[#70757E]">
                  TOTAL CANNING OEE: 92.2% | DO IN PACKAGE: 4.2 ppb
                </span>
              </div>

              <div className="grid grid-cols-4 gap-3">
                {/* BBT-01 */}
                <div
                  onClick={() => setSelectedVesselId("BBT-01")}
                  className={`bg-[#1A1C1E] border rounded-lg p-3 relative flex flex-col justify-between cursor-pointer transition ${
                    selectedVesselId === "BBT-01"
                      ? "border-[#00FF41] bg-[#1A1C1E] shadow-md shadow-[#00FF41]/10"
                      : "border-[#2D3035] hover:border-[#70757E]"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-[#00FF41]">BBT-01 (BRITE)</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#00FF41]/20 text-[#00FF41] font-mono">
                      PACKAGING
                    </span>
                  </div>
                  <div className="my-2">
                    <div className="text-sm font-bold font-mono text-[#E0E2E6]">Heritage Pilsner</div>
                    <div className="text-[10px] text-[#70757E] font-mono">Vol: 290 / 300 hl | 0.8°C</div>
                  </div>
                  <div className="text-[11px] font-mono text-[#70757E] space-y-0.5 border-t border-[#2D3035] pt-1.5">
                    <div className="flex justify-between">
                      <span>Dissolved O2:</span>
                      <span className="text-[#00FF41]">4.2 ppb</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Carbonation:</span>
                      <span className="text-[#E0E2E6]">5.2 g/L</span>
                    </div>
                  </div>
                </div>

                {/* LINE-CAN-01 */}
                <div
                  onClick={() => onNavigateToTab("packaging")}
                  className="bg-[#1A1C1E] border border-[#2D3035] rounded-lg p-3 relative flex flex-col justify-between hover:border-[#70757E] transition cursor-pointer"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-[#E0E2E6]">CAN LINE 1</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#00FF41]/20 text-[#00FF41] font-mono">
                      RUNNING
                    </span>
                  </div>
                  <div className="my-2">
                    <div className="text-base font-bold font-mono text-[#00FF41]">14,420 cph</div>
                    <div className="text-[10px] text-[#70757E] font-mono">OEE: 92.2% | Rejects: 0.29%</div>
                  </div>
                  <div className="text-[11px] font-mono text-[#70757E] space-y-0.5 border-t border-[#2D3035] pt-1.5">
                    <div className="flex justify-between">
                      <span>Product:</span>
                      <span className="text-[#E0E2E6]">Pilsner 330ml</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Headspace DO:</span>
                      <span className="text-[#00FF41]">&lt; 15 ppb</span>
                    </div>
                  </div>
                </div>

                {/* LINE-BTL-02 */}
                <div
                  onClick={() => onNavigateToTab("packaging")}
                  className="bg-[#1A1C1E] border border-[#2D3035] rounded-lg p-3 relative flex flex-col justify-between hover:border-[#70757E] transition cursor-pointer"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-[#E0E2E6]">BOTTLE LINE 2</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#00FF41]/20 text-[#00FF41] font-mono">
                      RUNNING
                    </span>
                  </div>
                  <div className="my-2">
                    <div className="text-base font-bold font-mono text-[#00FF41]">9,250 bph</div>
                    <div className="text-[10px] text-[#70757E] font-mono">OEE: 86.4% | Crown Capper OK</div>
                  </div>
                  <div className="text-[11px] font-mono text-[#70757E] space-y-0.5 border-t border-[#2D3035] pt-1.5">
                    <div className="flex justify-between">
                      <span>Product:</span>
                      <span className="text-[#E0E2E6]">Helles 500ml</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Pasteurization:</span>
                      <span className="text-[#00FF41]">14.8 PU</span>
                    </div>
                  </div>
                </div>

                {/* LINE-KEG-03 */}
                <div
                  onClick={() => onNavigateToTab("packaging")}
                  className="bg-[#1A1C1E] border border-[#2D3035] rounded-lg p-3 relative flex flex-col justify-between hover:border-[#70757E] transition cursor-pointer"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-[#E0E2E6]">KEG RACKER 3</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#00FF41]/20 text-[#00FF41] font-mono">
                      RUNNING
                    </span>
                  </div>
                  <div className="my-2">
                    <div className="text-base font-bold font-mono text-[#00FF41]">118 kegs/h</div>
                    <div className="text-[10px] text-[#70757E] font-mono">OEE: 96.3% | Zero Rejects</div>
                  </div>
                  <div className="text-[11px] font-mono text-[#70757E] space-y-0.5 border-t border-[#2D3035] pt-1.5">
                    <div className="flex justify-between">
                      <span>Product:</span>
                      <span className="text-[#E0E2E6]">DIPA 30L</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Counterpressure:</span>
                      <span className="text-[#00D1FF]">2.1 bar</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Selected Vessel Deep Telemetry & Equations Inspector (Right Sidebar) */}
        <div className="bg-[#1A1C1E] border border-[#2D3035] rounded-lg p-4 flex flex-col justify-between space-y-4 shadow-lg">
          <div className="space-y-3">
            <div className="flex items-center justify-between border-b border-[#2D3035] pb-2">
              <div>
                <span className="text-[10px] font-mono text-[#FF6B00] uppercase">INSPECTOR</span>
                <h3 className="text-sm font-bold font-mono text-[#E0E2E6]">{selectedVessel.name}</h3>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded bg-[#121417] text-[#00FF41] font-mono border border-[#2D3035]">
                {selectedVessel.state}
              </span>
            </div>

            {/* Live Measurements Grid */}
            <div className="grid grid-cols-2 gap-2 text-xs font-mono">
              <div className="bg-[#121417] p-2 rounded border border-[#2D3035]">
                <span className="text-[#70757E] text-[10px]">TEMPERATURE</span>
                <div className="text-base font-bold text-[#FF6B00]">{selectedVessel.temperature}°C</div>
                <span className="text-[10px] text-[#70757E]">Tgt: {selectedVessel.targetTemperature}°C</span>
              </div>

              <div className="bg-[#121417] p-2 rounded border border-[#2D3035]">
                <span className="text-[#70757E] text-[10px]">PRESSURE</span>
                <div className="text-base font-bold text-[#00D1FF]">{selectedVessel.pressureBar} bar</div>
                <span className="text-[10px] text-[#70757E]">Safety max: 3.0 bar</span>
              </div>

              <div className="bg-[#121417] p-2 rounded border border-[#2D3035]">
                <span className="text-[#70757E] text-[10px]">VOLUME / LEVEL</span>
                <div className="text-base font-bold text-[#E0E2E6]">{selectedVessel.currentVolumeHl} hl</div>
                <span className="text-[10px] text-[#70757E]">Cap: {selectedVessel.capacityHl} hl</span>
              </div>

              <div className="bg-[#121417] p-2 rounded border border-[#2D3035]">
                <span className="text-[#70757E] text-[10px]">GRAVITY / EXTRACT</span>
                <div className="text-base font-bold text-[#A855F7]">
                  {selectedVessel.gravityPlato > 0 ? `${selectedVessel.gravityPlato}°P` : "—"}
                </div>
                <span className="text-[10px] text-[#70757E]">pH: {selectedVessel.pH}</span>
              </div>
            </div>

            {/* Active Batch Info if present */}
            {activeBatchForVessel && (
              <div className="bg-[#121417] p-2.5 rounded border border-[#2D3035] space-y-1 font-mono text-xs">
                <div className="flex justify-between text-[#70757E] text-[11px]">
                  <span>Active Batch:</span>
                  <span className="text-[#E0E2E6] font-bold">{activeBatchForVessel.id}</span>
                </div>
                <div className="text-[#E0E2E6] font-semibold">{activeBatchForVessel.recipeName}</div>
                <div className="flex justify-between text-[11px] text-[#70757E] pt-1">
                  <span>Target FG: {activeBatchForVessel.targetFG}°P</span>
                  <span className="text-[#00FF41] font-bold">Qual: {activeBatchForVessel.qualityScorePct}%</span>
                </div>
              </div>
            )}

            {/* Physics Equation Applied */}
            <div className="bg-[#121417] p-2.5 rounded border border-[#2D3035] space-y-1.5">
              <span className="text-[10px] font-mono text-[#70757E] font-semibold flex items-center gap-1">
                <Info className="w-3 h-3 text-[#00D1FF]" /> DIGITAL TWIN PHYSICS MODEL:
              </span>
              <div className="text-[11px] font-mono text-[#00D1FF] bg-[#0A0B0D] p-1.5 rounded border border-[#2D3035]">
                {selectedVessel.type === "MASH_TUN" && "Arrhenius Starch Kinetics: v = v_max * [S] / (K_m + [S])"}
                {selectedVessel.type === "LAUTER_TUN" && "Darcy's Law: ΔP = (Q * μ * L) / (K * A)"}
                {selectedVessel.type === "BREW_KETTLE" && "Enthalpy Balance: Q_boil = m_wort * cp * ΔT + m_evap * h_fg"}
                {selectedVessel.type === "PLATE_HEAT_EXCHANGER" && "Counter-Flow ε-NTU: ε = (1 - e^(-NTU(1-c))) / (1 - c*e^(-NTU(1-c)))"}
                {selectedVessel.type === "FERMENTER" && "Monod ODE: dS/dt = -(1/Y_xs) * μ(S,E) * X; Q_ferm = -ΔH * dS/dt"}
                {selectedVessel.type === "BRITE_TANK" && "Henry's Law Carbonation: P_CO2 = k_H(T) * [CO2]"}
                {selectedVessel.type === "HOT_LIQUOR_TANK" && "Thermal Storage: Q_stored = m * cp * (T_hlt - T_amb)"}
                {selectedVessel.type === "COLD_LIQUOR_TANK" && "Refrigeration COP: W_in = Q_chill / COP"}
              </div>
            </div>

            {/* Invariant Health Check */}
            <div className="bg-[#00FF41]/10 border border-[#00FF41]/30 rounded p-2 text-xs font-mono text-[#00FF41] flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#00FF41] shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">Physical Invariants Satisfied:</span>
                <p className="text-[11px] text-[#70757E] mt-0.5">
                  Mass balance, pressure envelope, and ASME safety interlocks verified within ±0.05% margin.
                </p>
              </div>
            </div>
          </div>

          <div className="pt-2 border-t border-[#2D3035] flex gap-2">
            <button
              onClick={() => {
                if (selectedVessel.type === "FERMENTER") onNavigateToTab("fermentation");
                else if (selectedVessel.type === "BRITE_TANK") onNavigateToTab("tanks");
                else if (selectedVessel.type === "HOT_LIQUOR_TANK" || selectedVessel.type === "COLD_LIQUOR_TANK")
                  onNavigateToTab("energy");
                else onNavigateToTab("brewing");
              }}
              className="w-full bg-[#FF6B00] hover:bg-[#FF6B00]/90 text-black font-mono font-bold text-xs py-2 px-3 rounded flex items-center justify-center gap-1.5 transition cursor-pointer"
            >
              <span>Drilldown Module View</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
