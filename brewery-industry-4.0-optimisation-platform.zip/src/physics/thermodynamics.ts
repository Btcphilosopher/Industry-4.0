/**
 * Hard-Science Brewery Thermodynamics & Heat Transfer Module
 * Mirrors the Python Digital Twin & Rust Industrial Performance Calculations.
 */

export interface HeatExchangerResult {
  wortInletTempC: number;
  wortOutletTempC: number;
  waterInletTempC: number;
  waterOutletTempC: number;
  effectivenessEpsilon: number; // 0..1
  heatTransferRateKw: number;
  coolingEnergyRecoveredKw: number;
  hotWaterGeneratedHlH: number;
  ntu: number;
}

export interface BoilThermodynamicsResult {
  wortVolumeHl: number;
  wortPlato: number;
  boilDurationMinutes: number;
  evaporationRatePctPerHour: number;
  totalWaterEvaporatedKg: number;
  latentHeatVaporizationKj: number;
  steamConsumedKg: number;
  steamThermalInputKwh: number;
  heatLossesKwh: number;
  thermalEfficiencyPct: number;
  dmsStrippingEfficiencyPct: number; // Dimethyl sulfide volatilization
  hopAlphaAcidIsomerizationIsoAlphaPpm: number; // IBU contribution
}

/**
 * Calculates specific heat capacity of wort given Plato gravity.
 * Standard brewing equation: cp = 4.187 - 0.026 * Plato (kJ/kg·K)
 */
export function calculateWortSpecificHeat(plato: number): number {
  return Math.max(3.6, 4.187 - 0.026 * plato);
}

/**
 * Calculates wort density in kg/m³ based on Plato gravity.
 * Standard ASBC polynomial formula.
 */
export function calculateWortDensity(plato: number): number {
  const sg = 1 + plato / (258.6 - (plato / 258.2) * 227.1);
  return sg * 1000;
}

/**
 * Plate Heat Exchanger (PHE) Counter-Flow ε-NTU Thermal Solver
 * Calculates wort cooling and hot brewing liquor generation.
 */
export function solvePlateHeatExchanger(
  wortFlowHlH: number,
  wortInletTempC: number,
  wortTargetTempC: number,
  wortPlato: number,
  waterInletTempC: number,
  heatTransferAreaM2: number = 45.0,
  overallHeatTransferCoeffU: number = 2800 // W/(m²·K)
): HeatExchangerResult {
  // Convert flow to kg/s
  const wortDensity = calculateWortDensity(wortPlato); // kg/m³
  const wortMassFlowKgS = (wortFlowHlH * 0.1 * wortDensity) / 3600; // hl -> m³ -> kg/s
  const cpWort = calculateWortSpecificHeat(wortPlato) * 1000; // J/(kg·K)

  const cWort = wortMassFlowKgS * cpWort; // Heat capacity rate W/K

  // Water capacity rate (assuming 1.1x - 1.2x water-to-wort ratio)
  const waterFlowRatio = 1.15;
  const cpWater = 4184; // J/(kg·K)
  const waterMassFlowKgS = (wortFlowHlH * 0.1 * 1000 * waterFlowRatio) / 3600;
  const cWater = waterMassFlowKgS * cpWater;

  const cMin = Math.min(cWort, cWater);
  const cMax = Math.max(cWort, cWater);
  const cRatio = cMin / cMax;

  // Number of Transfer Units (NTU)
  const UA = overallHeatTransferCoeffU * heatTransferAreaM2;
  const ntu = UA / cMin;

  // Counter-flow effectiveness formula
  let epsilon: number;
  if (cRatio === 1) {
    epsilon = ntu / (1 + ntu);
  } else {
    epsilon = (1 - Math.exp(-ntu * (1 - cRatio))) / (1 - cRatio * Math.exp(-ntu * (1 - cRatio)));
  }
  epsilon = Math.min(0.96, Math.max(0.6, epsilon));

  // Max possible heat transfer
  const qMax = cMin * (wortInletTempC - waterInletTempC); // Watts
  const qActual = epsilon * qMax; // Watts

  // Temperatures
  const wortOutletTempC = wortInletTempC - qActual / cWort;
  const waterOutletTempC = waterInletTempC + qActual / cWater;

  return {
    wortInletTempC,
    wortOutletTempC: Number(wortOutletTempC.toFixed(1)),
    waterInletTempC,
    waterOutletTempC: Number(waterOutletTempC.toFixed(1)),
    effectivenessEpsilon: Number(epsilon.toFixed(3)),
    heatTransferRateKw: Number((qActual / 1000).toFixed(1)),
    coolingEnergyRecoveredKw: Number(((qActual * 0.94) / 1000).toFixed(1)),
    hotWaterGeneratedHlH: Number((wortFlowHlH * waterFlowRatio).toFixed(1)),
    ntu: Number(ntu.toFixed(2)),
  };
}

/**
 * Boil Kettle / Internal Calandria Thermodynamics Solver
 * Calculates evaporation rate, steam energy requirement, DMS stripping, and thermal recovery.
 */
export function solveBoilKettle(
  wortVolumeHl: number,
  wortPlato: number,
  boilDurationMinutes: number = 60,
  targetEvaporationPct: number = 6.5, // 6.5% standard modern kettle
  hopAlphaGrams: number = 1200,
  calandriaSteamPressureBar: number = 2.5
): BoilThermodynamicsResult {
  const wortDensity = calculateWortDensity(wortPlato);
  const wortMassKg = wortVolumeHl * 0.1 * wortDensity;
  const cpWort = calculateWortSpecificHeat(wortPlato);

  const waterEvaporatedKg = wortMassKg * (targetEvaporationPct / 100);
  const latentHeatHfg = 2257; // kJ/kg at 100°C
  const latentEnergyKj = waterEvaporatedKg * latentHeatHfg;

  // Sensible heat (raising from 94°C pre-boil to 100°C)
  const sensibleEnergyKj = wortMassKg * cpWort * (100 - 94);
  const totalProcessHeatKj = sensibleEnergyKj + latentEnergyKj;

  // Kettle insulation heat losses (approx 5-8% in modern insulated copper/SS kettles)
  const heatLossesPct = 6.0;
  const totalHeatSuppliedKj = totalProcessHeatKj / (1 - heatLossesPct / 100);
  const totalHeatKwh = totalHeatSuppliedKj / 3600;

  // Saturated steam enthalpy at 2.5 bar (~127°C, h_fg ≈ 2181 kJ/kg)
  const steamLatentHeat = 2181;
  const steamConsumedKg = totalHeatSuppliedKj / steamLatentHeat;

  // Thermal efficiency calculation
  const usefulThermalEnergyKj = latentEnergyKj + sensibleEnergyKj;
  const thermalEfficiencyPct = (usefulThermalEnergyKj / totalHeatSuppliedKj) * 100;

  // DMS (Dimethyl sulfide) volatilization follows 1st-order reaction kinetics: C(t) = C_0 * exp(-k * t)
  // At 100°C, k ≈ 0.021 min⁻¹
  const kDms = 0.021;
  const dmsStrippedFraction = 1 - Math.exp(-kDms * boilDurationMinutes);
  const dmsStrippingEfficiencyPct = dmsStrippedFraction * 100;

  // Alpha acid isomerization kinetics: Tinseth / Garetz formula approximation
  const boilTimeFactor = (1 - Math.exp(-0.04 * boilDurationMinutes)) / 4.15;
  const gravityFactor = 1.65 * Math.pow(0.000125, wortPlato / 4.0 - 1);
  const utilization = boilTimeFactor * gravityFactor;
  const ibuCalculated = (hopAlphaGrams * (utilization * 10)) / wortVolumeHl;

  return {
    wortVolumeHl,
    wortPlato,
    boilDurationMinutes,
    evaporationRatePctPerHour: targetEvaporationPct * (60 / boilDurationMinutes),
    totalWaterEvaporatedKg: Number(waterEvaporatedKg.toFixed(1)),
    latentHeatVaporizationKj: Number(latentEnergyKj.toFixed(0)),
    steamConsumedKg: Number(steamConsumedKg.toFixed(1)),
    steamThermalInputKwh: Number(totalHeatKwh.toFixed(1)),
    heatLossesKwh: Number(((totalHeatSuppliedKj * (heatLossesPct / 100)) / 3600).toFixed(1)),
    thermalEfficiencyPct: Number(thermalEfficiencyPct.toFixed(1)),
    dmsStrippingEfficiencyPct: Number(dmsStrippingEfficiencyPct.toFixed(1)),
    hopAlphaAcidIsomerizationIsoAlphaPpm: Number(ibuCalculated.toFixed(1)),
  };
}

/**
 * Validates Conservation of Mass and Energy Invariants.
 * Hard constraint enforcement.
 */
export function validateThermodynamicInvariants(
  massInKg: number,
  massOutKg: number,
  energyInKwh: number,
  energyOutKwh: number,
  tolerancePct: number = 1.5
): { valid: boolean; massErrorPct: number; energyErrorPct: number; message: string } {
  const massErrorPct = (Math.abs(massInKg - massOutKg) / massInKg) * 100;
  const energyErrorPct = (Math.abs(energyInKwh - energyOutKwh) / energyInKwh) * 100;

  const valid = massErrorPct <= tolerancePct && energyErrorPct <= tolerancePct;

  return {
    valid,
    massErrorPct: Number(massErrorPct.toFixed(2)),
    energyErrorPct: Number(energyErrorPct.toFixed(2)),
    message: valid
      ? "Physical Invariants Satisfied: 1st Law of Thermodynamics closed within allowable industrial envelope."
      : `Physical Violation Detected: Mass balance error ${massErrorPct.toFixed(1)}% or Energy balance error ${energyErrorPct.toFixed(1)}% exceeds tolerance (${tolerancePct}%).`,
  };
}
