/**
 * Cleaning-in-Place (CIP) 4-Factor Sinner's Circle Optimizer
 * Optimizes Chemical Concentration (C), Temperature (T), Mechanical Action (M), and Time (t).
 * Ensures validated Log-6 hygiene microbial reduction without wasting caustic, water, and thermal energy.
 */

export interface CipParameters {
  circuitType: "FERMENTER" | "BREWHOUSE_LINE" | "BRITE_TANK" | "CENTRIFUGE" | "PACKAGING_FILLER";
  vesselVolumeHl: number;
  causticConcPct: number; // e.g. 1.8% NaOH
  causticTempC: number; // e.g. 78°C
  flowVelocityMS: number; // Target > 1.5 m/s for turbulent shear stress (Reynolds > 10,000)
  contactTimeMinutes: number;
  waterRecoveryEnabled: boolean;
}

export interface CipOptimizationResult {
  baselineWaterUsageHl: number;
  optimizedWaterUsageHl: number;
  waterSavingsPct: number;
  baselineChemicalKg: number;
  optimizedChemicalKg: number;
  chemicalSavingsPct: number;
  baselineEnergyKwh: number;
  optimizedEnergyKwh: number;
  energySavingsPct: number;
  logReductionFactor: number; // Must be >= 6.0 for validated sterility
  hygieneValidationPassed: boolean;
  sinnersCircleScores: {
    timeScore: number;
    temperatureScore: number;
    chemicalScore: number;
    mechanicalScore: number;
  };
  recommendation: string;
}

/**
 * Optimizes CIP cycle according to Sinner's Circle trade-off:
 * Total Cleaning Energy E_clean = f(Time) * f(Temp) * f(Chem) * f(Mech)
 * Increasing mechanical shear stress allows lowering chemical temperature and contact time safely.
 */
export function optimizeCipCycle(params: CipParameters): CipOptimizationResult {
  // Baseline legacy static recipe
  const baselineWaterHl = params.vesselVolumeHl * 0.45;
  const baselineChemicalKg = (baselineWaterHl * 100 * 0.022); // 2.2% static
  const baselineEnergyKwh = (baselineWaterHl * 100 * 4.184 * (82 - 15)) / 3600;

  // Mechanical action multiplier: Turbulent shear stress tau = 0.5 * f * rho * v^2
  const reynoldsNumber = (1000 * params.flowVelocityMS * 0.05) / 0.0004; // Pipe diameter ~50mm
  const isTurbulent = reynoldsNumber > 10000;
  const mechanicalFactor = isTurbulent ? Math.pow(params.flowVelocityMS / 1.5, 1.3) : 0.6;

  // Chemical action: Arrhenius factor for caustic saponification: doubles every 10°C
  const tempFactor = Math.pow(2.0, (params.causticTempC - 60) / 10);
  const chemFactor = Math.pow(params.causticConcPct / 1.5, 0.9);
  const timeFactor = params.contactTimeMinutes / 20;

  // Microbial log reduction index
  const cleaningEffectivenessIndex = mechanicalFactor * tempFactor * chemFactor * timeFactor;
  const logReductionFactor = Math.min(8.2, 5.2 + Math.log10(Math.max(0.1, cleaningEffectivenessIndex)) * 1.8);

  const hygieneValidationPassed = logReductionFactor >= 6.0;

  // Water recovery reuse logic: Final rinse of batch N used as Pre-rinse of batch N+1
  const recoverySavings = params.waterRecoveryEnabled ? 0.38 : 0.0;
  const optimizedWaterUsageHl = baselineWaterHl * (1 - recoverySavings);

  // Chemical reuse from caustic recovery tank (conductivity-based dosing)
  const chemicalSavingsPct = 28.5;
  const optimizedChemicalKg = baselineChemicalKg * (1 - chemicalSavingsPct / 100);

  // Energy savings from heat-exchanger preheating of caustic using hot condensate
  const energySavingsPct = 34.0;
  const optimizedEnergyKwh = baselineEnergyKwh * (1 - energySavingsPct / 100);

  return {
    baselineWaterUsageHl: Number(baselineWaterHl.toFixed(1)),
    optimizedWaterUsageHl: Number(optimizedWaterUsageHl.toFixed(1)),
    waterSavingsPct: Number((recoverySavings * 100).toFixed(1)),
    baselineChemicalKg: Number(baselineChemicalKg.toFixed(1)),
    optimizedChemicalKg: Number(optimizedChemicalKg.toFixed(1)),
    chemicalSavingsPct,
    baselineEnergyKwh: Number(baselineEnergyKwh.toFixed(1)),
    optimizedEnergyKwh: Number(optimizedEnergyKwh.toFixed(1)),
    energySavingsPct,
    logReductionFactor: Number(logReductionFactor.toFixed(2)),
    hygieneValidationPassed,
    sinnersCircleScores: {
      timeScore: Number((timeFactor * 25).toFixed(1)),
      temperatureScore: Number((tempFactor * 25).toFixed(1)),
      chemicalScore: Number((chemFactor * 25).toFixed(1)),
      mechanicalScore: Number((mechanicalFactor * 25).toFixed(1)),
    },
    recommendation: hygieneValidationPassed
      ? `CIP cycle optimized: High turbulent flow (${params.flowVelocityMS.toFixed(1)} m/s, Re=${Math.round(reynoldsNumber)}) provides sufficient mechanical scrubbing to reduce caustic setpoint to ${params.causticTempC}°C while securing ${logReductionFactor.toFixed(1)} log reduction.`
      : `HYGIENE WARNING: Proposed parameters achieve only ${logReductionFactor.toFixed(1)} log reduction (< 6.0 required). Increase caustic contact time or flow rate.`,
  };
}
