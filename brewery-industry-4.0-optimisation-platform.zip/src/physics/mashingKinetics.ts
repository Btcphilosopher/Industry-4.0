/**
 * Mashing Process & Enzymatic Conversion Model
 * Calculates alpha-amylase and beta-amylase kinetics, starch gelatinization,
 * extract yield, wort fermentability, and thermal energy input.
 */

export interface MashStepConfig {
  name: string;
  targetTempC: number;
  durationMin: number;
  rampRateDegPerMin: number;
}

export interface MashingResult {
  gristWeightKg: number;
  strikeWaterHl: number;
  liquorToGristRatio: number; // e.g. 3.2 L/kg
  mashPh: number;
  extractYieldPct: number; // e.g. 81.4% of dry basis
  apparentExtractPlato: number; // e.g. 14.8 °P
  alphaAmylaseActivityPct: number;
  betaAmylaseActivityPct: number;
  fermentableSugarsPct: number; // Glucose + Maltose + Maltotriose fraction
  unfermentableDextrinsPct: number;
  thermalEnergyInputKwh: number;
  mashEfficiencyPct: number;
  recommendation: string;
}

/**
 * Evaluates enzymatic reaction rates based on empirical Arrhenius curves and thermal denaturation.
 * Alpha-amylase: Optimum 68-72°C, denatures rapidly >78°C.
 * Beta-amylase: Optimum 60-65°C, denatures rapidly >68°C.
 */
export function solveMashingProcess(
  gristWeightKg: number = 3200,
  strikeWaterHl: number = 102.4, // 3.2 L/kg
  mashPh: number = 5.35,
  restTempC: number = 66.5,
  restDurationMin: number = 60
): MashingResult {
  const liquorToGristRatio = (strikeWaterHl * 100) / gristWeightKg;

  // Beta-amylase activity curve (Gaussian peak around 63°C, pH optimum 5.3-5.5)
  const betaTempOpt = 63.0;
  const betaTempWidth = 4.5;
  const betaTempFactor = Math.exp(-Math.pow((restTempC - betaTempOpt) / betaTempWidth, 2));
  const betaDenaturation = restTempC > 67 ? Math.exp(-(restTempC - 67) * 0.45 * (restDurationMin / 30)) : 1.0;
  const betaPhFactor = Math.max(0.4, 1.0 - Math.abs(mashPh - 5.4) * 0.8);
  const betaActivityPct = Math.min(100, Math.max(5, betaTempFactor * betaDenaturation * betaPhFactor * 100));

  // Alpha-amylase activity curve (Gaussian peak around 70°C, pH optimum 5.5-5.8)
  const alphaTempOpt = 70.5;
  const alphaTempWidth = 6.0;
  const alphaTempFactor = Math.exp(-Math.pow((restTempC - alphaTempOpt) / alphaTempWidth, 2));
  const alphaDenaturation = restTempC > 76 ? Math.exp(-(restTempC - 76) * 0.35 * (restDurationMin / 30)) : 1.0;
  const alphaPhFactor = Math.max(0.5, 1.0 - Math.abs(mashPh - 5.6) * 0.6);
  const alphaActivityPct = Math.min(100, Math.max(10, alphaTempFactor * alphaDenaturation * alphaPhFactor * 100));

  // Extract Yield & Fermentability
  const baseExtractPotential = 0.82; // 82% fine-grind dry basis typical for 2-row pale malt
  const gelatinizationCompletion = 1 / (1 + Math.exp(-(restTempC - 61.5) * 0.8));
  const conversionFactor = 0.94 + 0.05 * gelatinizationCompletion;
  const actualExtractYield = baseExtractPotential * conversionFactor * (1 - 0.03 * Math.abs(liquorToGristRatio - 3.2));
  const extractYieldPct = actualExtractYield * 100;

  // Fermentable sugar spectrum
  const fermentableSugarsPct = Math.min(84, Math.max(58, 62 + (betaActivityPct - 50) * 0.22 - (restTempC - 65) * 1.4));
  const unfermentableDextrinsPct = 100 - fermentableSugarsPct;

  // Total extract dissolved in wort
  const totalDissolvedExtractKg = gristWeightKg * actualExtractYield;
  const totalMashVolumeL = gristWeightKg * 0.7 + strikeWaterHl * 100; // Grain displaces ~0.7 L/kg
  const apparentExtractPlato = (totalDissolvedExtractKg / (totalMashVolumeL * 1.04)) * 100 * 0.145; // Approximate °P

  // Thermal energy calculation
  // Mash heat capacity ~ 3.8 kJ/kg·K. Heat from 15°C strike to restTempC
  const mashMassKg = gristWeightKg + strikeWaterHl * 100;
  const cpMash = 3.85; // kJ/kg·K
  const energyKj = mashMassKg * cpMash * (restTempC - 15);
  const thermalEnergyInputKwh = energyKj / 3600;

  const mashEfficiencyPct = (extractYieldPct / (baseExtractPotential * 100)) * 100;

  let recommendation = "Enzymatic conversion is on target. High fermentability profile established.";
  if (restTempC > 68 && betaActivityPct < 30) {
    recommendation = "Higher mash temperature favours alpha-amylase: wort will have higher dextrin content and fuller body.";
  } else if (restTempC < 64) {
    recommendation = "Lower mash temperature maximises beta-amylase for high attenuation (dryer finish, crisp profile).";
  }

  return {
    gristWeightKg,
    strikeWaterHl,
    liquorToGristRatio: Number(liquorToGristRatio.toFixed(2)),
    mashPh,
    extractYieldPct: Number(extractYieldPct.toFixed(1)),
    apparentExtractPlato: Number(apparentExtractPlato.toFixed(2)),
    alphaAmylaseActivityPct: Number(alphaActivityPct.toFixed(1)),
    betaAmylaseActivityPct: Number(betaActivityPct.toFixed(1)),
    fermentableSugarsPct: Number(fermentableSugarsPct.toFixed(1)),
    unfermentableDextrinsPct: Number(unfermentableDextrinsPct.toFixed(1)),
    thermalEnergyInputKwh: Number(thermalEnergyInputKwh.toFixed(1)),
    mashEfficiencyPct: Number(mashEfficiencyPct.toFixed(1)),
    recommendation,
  };
}
