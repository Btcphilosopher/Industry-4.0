/**
 * Lauter Tun Hydraulics & Porous Media Filtration Model
 * Uses Darcy's Law to model differential pressure (ΔP), bed permeability,
 * raking frequency, sparge liquor efficiency, and turbidity breakthrough.
 */

export interface LauteringState {
  lauteringTimeMinutes: number;
  wortFlowRateHlH: number;
  differentialPressureMbar: number; // ΔP across false bottom
  bedHeightMeters: number;
  apparentPermeabilityM2: number; // K in Darcy's law
  wortViscosityCp: number; // Centipoise (function of temperature & °Plato)
  turbidityNtu: number;
  spargeVolumeAppliedHl: number;
  spargeWaterTempC: number;
  firstWortPlato: number;
  currentRunoffPlato: number;
  overallExtractRecoveryPct: number;
  rakeHeightPct: number;
  bedCompactionRisk: "LOW" | "MODERATE" | "HIGH" | "CRITICAL";
  recommendation: string;
}

/**
 * Darcy's Law for liquid filtration through spent grain bed:
 * Q = (K * A * ΔP) / (μ * L)
 * where:
 * Q = volumetric flow rate (m³/s)
 * K = permeability of grain cake (m²)
 * A = surface area of lauter false bottom (m²)
 * ΔP = differential pressure across the bed (Pa)
 * μ = dynamic viscosity of wort (Pa·s)
 * L = grain bed depth (m)
 */
export function solveLauterTunHydraulics(
  elapsedMinutes: number = 45,
  targetWortFlowHlH: number = 110,
  spargeTempC: number = 78.0,
  grainBedDepthM: number = 0.42,
  lauterAreaM2: number = 18.5,
  rakingActive: boolean = false
): LauteringState {
  // Viscosity decreases with temperature and increases with extract density
  // μ_water(78°C) ≈ 0.36 cP; Wort (14°P at 78°C) ≈ 0.65 cP
  const wortViscosityCp = Math.max(0.45, 0.36 * (1 + 0.045 * (16 - elapsedMinutes * 0.15)));

  // Spent grain bed permeability (decreases over time due to compaction)
  let basePermeability = 3.5e-11; // m²
  if (rakingActive) {
    basePermeability *= 1.6; // Raking cuts channels and loosens bed
  } else {
    // Bed compacts as volume passes through
    const compactionFactor = Math.max(0.4, 1.0 - (elapsedMinutes / 120) * 0.5);
    basePermeability *= compactionFactor;
  }

  // Calculate required ΔP using Darcy's Law: ΔP = (Q * μ * L) / (K * A)
  const qM3S = (targetWortFlowHlH * 0.1) / 3600; // hl/h -> m³/s
  const muPaS = wortViscosityCp * 0.001; // cP -> Pa·s
  const deltaPPa = (qM3S * muPaS * grainBedDepthM) / (basePermeability * lauterAreaM2);
  const deltaPMbar = deltaPPa / 100;

  // Runoff Plato dilution curve (First wort ~17°P decaying to ~1.8°P at cut-off)
  const firstWortPlato = 16.8;
  const currentRunoffPlato = Math.max(1.5, firstWortPlato * Math.exp(-0.024 * elapsedMinutes));

  // Turbidity curve (Vorlauf settles to <25 NTU, late sparge may increase slightly)
  const turbidityNtu = elapsedMinutes < 15 ? 180 - elapsedMinutes * 10 : Math.min(38, 14 + (deltaPMbar / 80) * 12);

  // Compaction risk evaluation
  let bedCompactionRisk: "LOW" | "MODERATE" | "HIGH" | "CRITICAL" = "LOW";
  let recommendation = "Lautering hydraulics within optimal window. Flow resistance is stable.";

  if (deltaPMbar > 95) {
    bedCompactionRisk = "CRITICAL";
    recommendation = "CRITICAL: Grain bed compaction detected (ΔP > 95 mbar). Immediate deep raking cycle and flow throttling recommended to prevent stuck mash.";
  } else if (deltaPMbar > 70) {
    bedCompactionRisk = "HIGH";
    recommendation = "High differential pressure. Initiate gentle raking at 15% knife depth to restore bed permeability without disturbing bottom filter layer.";
  } else if (deltaPMbar > 50) {
    bedCompactionRisk = "MODERATE";
    recommendation = "Bed resistance increasing normally. Maintain steady sparge temperature at 78°C to minimize wort viscosity.";
  }

  // Extract recovery percentage
  const overallExtractRecoveryPct = Math.min(98.2, 70 + elapsedMinutes * 0.32);

  return {
    lauteringTimeMinutes: elapsedMinutes,
    wortFlowRateHlH: targetWortFlowHlH,
    differentialPressureMbar: Number(deltaPMbar.toFixed(1)),
    bedHeightMeters: grainBedDepthM,
    apparentPermeabilityM2: basePermeability,
    wortViscosityCp: Number(wortViscosityCp.toFixed(2)),
    turbidityNtu: Number(turbidityNtu.toFixed(1)),
    spargeVolumeAppliedHl: Number((elapsedMinutes * (targetWortFlowHlH / 60) * 0.9).toFixed(1)),
    spargeWaterTempC: spargeTempC,
    firstWortPlato,
    currentRunoffPlato: Number(currentRunoffPlato.toFixed(1)),
    overallExtractRecoveryPct: Number(overallExtractRecoveryPct.toFixed(1)),
    rakeHeightPct: rakingActive ? 35 : 0,
    bedCompactionRisk,
    recommendation,
  };
}
