/**
 * Overall Equipment Effectiveness (OEE) Engine
 * Calculates Availability, Performance, Quality, and Six Big Losses breakdown
 * according to ISO 22400 industrial manufacturing metrics.
 */

export interface OeeCalculation {
  plannedProductionTimeMin: number;
  operatingTimeMin: number;
  idealCycleTimeSecPerUnit: number;
  totalCountUnits: number;
  goodCountUnits: number;
  rejectCountUnits: number;
  unplannedDowntimeMin: number;
  availabilityPct: number;
  performancePct: number;
  qualityPct: number;
  oeePct: number;
  sixBigLosses: {
    equipmentFailureMin: number;
    setupAndAdjustmentsMin: number;
    idlingAndMinorStoppagesMin: number;
    reducedSpeedMin: number;
    processDefectsUnits: number;
    reducedYieldUnits: number;
  };
  oeeWorldClassComparisonPct: number; // 85% is World-Class Benchmark
}

export function calculateOee(
  plannedTimeMin: number = 480, // 8 hour shift
  unplannedDowntimeMin: number = 28,
  idealSpeedUnitsPerHour: number = 12000,
  totalProducedUnits: number = 88400,
  rejectedUnits: number = 320
): OeeCalculation {
  const operatingTimeMin = Math.max(1, plannedTimeMin - unplannedDowntimeMin);
  const goodCountUnits = Math.max(0, totalProducedUnits - rejectedUnits);

  // 1. Availability = Operating Time / Planned Production Time
  const availability = operatingTimeMin / plannedTimeMin;

  // 2. Performance = (Total Count / Operating Time) / Ideal Run Rate
  const idealRateUnitsPerMin = idealSpeedUnitsPerHour / 60;
  const actualRateUnitsPerMin = totalProducedUnits / operatingTimeMin;
  const performance = Math.min(1.0, actualRateUnitsPerMin / idealRateUnitsPerMin);

  // 3. Quality = Good Count / Total Count
  const quality = totalProducedUnits > 0 ? goodCountUnits / totalProducedUnits : 1.0;

  // Total OEE = A * P * Q
  const oee = availability * performance * quality;

  return {
    plannedProductionTimeMin: plannedTimeMin,
    operatingTimeMin,
    idealCycleTimeSecPerUnit: 3600 / idealSpeedUnitsPerHour,
    totalCountUnits: totalProducedUnits,
    goodCountUnits,
    rejectCountUnits: rejectedUnits,
    unplannedDowntimeMin,
    availabilityPct: Number((availability * 100).toFixed(1)),
    performancePct: Number((performance * 100).toFixed(1)),
    qualityPct: Number((quality * 100).toFixed(1)),
    oeePct: Number((oee * 100).toFixed(1)),
    sixBigLosses: {
      equipmentFailureMin: Number((unplannedDowntimeMin * 0.65).toFixed(1)),
      setupAndAdjustmentsMin: Number((unplannedDowntimeMin * 0.35).toFixed(1)),
      idlingAndMinorStoppagesMin: 14.5,
      reducedSpeedMin: 8.2,
      processDefectsUnits: rejectedUnits,
      reducedYieldUnits: 45,
    },
    oeeWorldClassComparisonPct: Number(((oee / 0.85) * 100).toFixed(1)),
  };
}
