/**
 * Dynamic Electricity Price Arbitrage, Solar PV & Battery BESS Dispatch Engine
 * Calculates optimal charge/discharge schedules, peak load shaving,
 * and deferred non-critical thermal/pumping loads without violating food safety.
 */

export interface EnergyDispatchDecision {
  currentHour: number;
  gridTariffGbpKwh: number;
  solarGenerationKw: number;
  breweryBaselineLoadKw: number;
  batteryAction: "CHARGE" | "HOLD" | "DISCHARGE";
  batteryPowerKw: number;
  batterySocPct: number;
  netGridImportKw: number;
  costPerHourGbp: number;
  optimalThermalStorageAction: "PRE_HEAT_HLT" | "PRE_CHILL_CLT" | "DEFER_BOIL" | "NORMAL_OPERATION";
  deferredLoadSavingsGbp: number;
  safetyOverrideEngaged: boolean;
  recommendation: string;
}

export interface HourlyTariffProfile {
  hour: number;
  tariffGbpKwh: number;
  solarExpectedKw: number;
  demandForecastKw: number;
}

/**
 * Generates 24-hour day-ahead market price profile (e.g. Octopus Agile / Half-Hourly NordPool style)
 */
export function generateDayAheadTariffProfile(): HourlyTariffProfile[] {
  const profile: HourlyTariffProfile[] = [];
  // Typical UK/EU industrial price shape: cheap overnight, spike 07:00-09:00, solar dip 12:00-14:00, super-peak 16:30-19:30
  const basePrices = [
    0.09, 0.08, 0.08, 0.09, 0.11, 0.16, 0.24, 0.29, 0.26, 0.21, 0.17, 0.14, 0.11, 0.12, 0.15, 0.22,
    0.34, 0.38, 0.35, 0.28, 0.22, 0.18, 0.14, 0.11,
  ];

  for (let h = 0; h < 24; h++) {
    // Solar curve: bell curve around 13:00
    const solarFactor = Math.max(0, Math.sin(((h - 6) / 14) * Math.PI));
    const solarKw = h >= 6 && h <= 20 ? 320 * Math.pow(solarFactor, 1.4) : 0;

    // Brewery load: brew shifts active 06:00 to 22:00
    let loadKw = 140; // baseline refrigeration & standby
    if (h >= 6 && h <= 20) {
      loadKw = 420 + Math.sin(h * 0.8) * 80;
    }

    profile.push({
      hour: h,
      tariffGbpKwh: basePrices[h],
      solarExpectedKw: Number(solarKw.toFixed(1)),
      demandForecastKw: Number(loadKw.toFixed(1)),
    });
  }

  return profile;
}

/**
 * Solves real-time battery and flexible load dispatch
 */
export function solveEnergyDispatch(
  currentHour: number,
  currentSocPct: number = 65,
  batteryMaxCapacityKwh: number = 500,
  batteryMaxPowerKw: number = 150,
  solarActualKw: number = 240,
  breweryLoadKw: number = 410,
  tariffGbpKwh: number = 0.34,
  criticalFermentationTempOk: boolean = true
): EnergyDispatchDecision {
  let batteryAction: "CHARGE" | "HOLD" | "DISCHARGE" = "HOLD";
  let batteryPowerKw = 0;
  let optimalThermalStorageAction: "PRE_HEAT_HLT" | "PRE_CHILL_CLT" | "DEFER_BOIL" | "NORMAL_OPERATION" =
    "NORMAL_OPERATION";
  let deferredSavings = 0;
  let recommendation = "Standard grid operation.";

  // High price threshold: £0.25/kWh, Low price threshold: £0.12/kWh
  if (tariffGbpKwh >= 0.28) {
    // Peak tariff period -> Maximize Battery Discharge to offset plant load
    if (currentSocPct > 15) {
      batteryAction = "DISCHARGE";
      batteryPowerKw = Math.min(batteryMaxPowerKw, breweryLoadKw - solarActualKw);
      recommendation = `Peak electricity tariff active (£${tariffGbpKwh.toFixed(2)}/kWh). BESS Battery discharging ${batteryPowerKw.toFixed(0)} kW to shave grid import. Non-critical CIP cycles deferred.`;
      optimalThermalStorageAction = "DEFER_BOIL";
      deferredSavings = batteryPowerKw * tariffGbpKwh * 0.85;
    } else {
      recommendation = `Peak tariff active but Battery SOC is low (${currentSocPct.toFixed(0)}%). Non-critical pumping deferred.`;
    }
  } else if (tariffGbpKwh <= 0.12 || solarActualKw > breweryLoadKw + 50) {
    // Off-peak or solar surplus -> Charge Battery & pre-chill/pre-heat thermal storage
    if (currentSocPct < 95) {
      batteryAction = "CHARGE";
      batteryPowerKw = Math.min(batteryMaxPowerKw, batteryMaxCapacityKwh * (1 - currentSocPct / 100));
      optimalThermalStorageAction = "PRE_CHILL_CLT";
      recommendation = `Low green energy tariff (£${tariffGbpKwh.toFixed(2)}/kWh) + Solar generation surplus (${solarActualKw.toFixed(0)} kW). Charging battery at ${batteryPowerKw.toFixed(0)} kW and sub-cooling CLT to -2°C glycol storage.`;
    }
  }

  // Net grid flow
  const netGridImportKw = Math.max(0, breweryLoadKw - solarActualKw - (batteryAction === "DISCHARGE" ? batteryPowerKw : -batteryPowerKw));
  const costPerHourGbp = (netGridImportKw * tariffGbpKwh);

  return {
    currentHour,
    gridTariffGbpKwh: tariffGbpKwh,
    solarGenerationKw: solarActualKw,
    breweryBaselineLoadKw: breweryLoadKw,
    batteryAction,
    batteryPowerKw,
    batterySocPct: currentSocPct,
    netGridImportKw: Number(netGridImportKw.toFixed(1)),
    costPerHourGbp: Number(costPerHourGbp.toFixed(2)),
    optimalThermalStorageAction,
    deferredLoadSavingsGbp: Number(deferredSavings.toFixed(2)),
    safetyOverrideEngaged: !criticalFermentationTempOk,
    recommendation,
  };
}
