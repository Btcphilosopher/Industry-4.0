export type PlantStageId =
  | "raw_materials"
  | "milling"
  | "mashing"
  | "lautering"
  | "boiling"
  | "whirlpool"
  | "cooling"
  | "fermentation"
  | "maturation"
  | "filtration"
  | "packaging"
  | "warehouse"
  | "cip"
  | "energy_center";

export type VesselType =
  | "MASH_TUN"
  | "LAUTER_TUN"
  | "BREW_KETTLE"
  | "WHIRLPOOL"
  | "PLATE_HEAT_EXCHANGER"
  | "FERMENTER"
  | "BRITE_TANK"
  | "HOT_LIQUOR_TANK"
  | "COLD_LIQUOR_TANK"
  | "CIP_SET"
  | "BOILER"
  | "CHILLER"
  | "BATTERY_BESS";

export type VesselState =
  | "IDLE"
  | "FILLING"
  | "HEATING"
  | "RESTING"
  | "LAUTERING"
  | "BOILING"
  | "WHIRLPOOLING"
  | "CHILLING"
  | "PITCHING"
  | "ACTIVE_FERMENTATION"
  | "DIACETYL_REST"
  | "CRASH_COOLING"
  | "CONDITIONING"
  | "FILTRATION"
  | "READY_FOR_PACKAGING"
  | "PACKAGING"
  | "CIP_PRE_RINSE"
  | "CIP_CAUSTIC"
  | "CIP_INTER_RINSE"
  | "CIP_ACID"
  | "CIP_SANITIZATION"
  | "CLEAN_STERILE"
  | "MAINTENANCE_LOCKED";

export interface TelemetryPoint {
  timestamp: number;
  temperature: number; // °C
  pressure: number; // bar
  flowRate: number; // hl/h or m³/h
  volume: number; // hl
  gravityPlato: number; // °Plato
  pH: number;
  dissolvedOxygenPpb: number; // ppb
  turbidityNtu: number; // NTU
  powerKw: number; // kW
  steamFlowKgH: number; // kg/h
  co2RateKgH: number; // kg/h
  glycolValveOpenPct: number; // %
  steamValveOpenPct: number; // %
}

export interface Vessel {
  id: string;
  name: string;
  type: VesselType;
  capacityHl: number;
  currentVolumeHl: number;
  state: VesselState;
  batchId?: string;
  recipeName?: string;
  temperature: number; // °C
  targetTemperature: number; // °C
  pressureBar: number; // bar
  gravityPlato: number; // °P
  targetPlato?: number;
  pH: number;
  dissolvedOxygenPpb: number;
  turbidityNtu: number;
  cipStatus: "DIRTY" | "IN_PROGRESS" | "CLEAN" | "STERILE";
  lastCipTimestamp: number;
  hoursInCurrentState: number;
  totalCycleHours: number;
  glycolDutyPct: number;
  steamDutyPct: number;
  co2RecoveryActive: boolean;
  coolingJacketZoneActive: [boolean, boolean, boolean]; // Top, Middle, Cone
  healthScorePct: number;
  anomalyDetected: boolean;
  anomalyDescription?: string;
}

export interface ActiveBatch {
  id: string;
  recipeId: string;
  recipeName: string;
  style: string;
  targetVolumeHl: number;
  actualVolumeHl: number;
  currentStage: PlantStageId;
  targetOG: number; // °P (Original Gravity)
  actualOG: number; // °P
  currentPlato: number; // °P
  targetFG: number; // °P (Final Gravity)
  predictedFG: number; // °P
  targetAbv: number; // %
  currentAbv: number; // %
  targetIbu: number;
  actualIbu: number;
  targetEbcColor: number;
  startTime: number;
  expectedCompletionTime: number;
  primaryFermenterId: string;
  currentVesselId: string;
  attenuationPct: number;
  diacetylPpm: number;
  thermalEfficiencyPct: number;
  energyKwhPerHl: number;
  waterHlPerHl: number;
  qualityScorePct: number;
}

export interface OptimizationObjectiveWeights {
  quality: number; // 0..1
  throughput: number; // 0..1
  energyEfficiency: number; // 0..1
  waterEfficiency: number; // 0..1
  costMinimization: number; // 0..1
}

export interface OptimizationProposal {
  id: string;
  timestamp: number;
  title: string;
  targetArea: PlantStageId | "energy" | "tanks" | "cip" | "packaging";
  category: "ENERGY" | "THROUGHPUT" | "QUALITY" | "WATER" | "COST" | "MAINTENANCE";
  impactSummary: string;
  confidencePct: number;
  kpis: {
    energySavingsKwh?: number;
    waterSavingsHl?: number;
    costSavingsGbp?: number;
    timeGainHours?: number;
    qualityImpact: "Positive" | "Neutral" | "Negligible";
    throughputGainBatches?: number;
  };
  recommendedAction: string;
  physicalBasis: string;
  hardConstraintsVerified: string[];
  safetyEnvelopeStatus: "VALIDATED" | "NEEDS_CONFIRMATION";
  status: "PENDING_REVIEW" | "APPROVED" | "REJECTED" | "SHADOW_EXECUTED";
  executedBy?: string;
  executedTimestamp?: number;
}

export interface EnergyGridState {
  currentGridTariffGbpKwh: number; // £/kWh
  predictedGridTariff24h: { hour: number; price: number }[];
  solarGenerationKw: number; // kW
  solarPeakCapacityKw: number;
  batterySocPct: number; // State of Charge %
  batteryCapacityKwh: number;
  batteryPowerFlowKw: number; // + charging, - discharging
  breweryTotalLoadKw: number;
  gridImportKw: number;
  gridExportKw: number;
  steamBoilerEfficiencyPct: number;
  chillerCop: number; // Coefficient of Performance
  heatRecoveryThermalKw: number;
  heatRecoveryEfficiencyPct: number;
  specificEnergyKwhPerHl: number; // Target: < 8.5 kWh/hl
  specificWaterHlPerHl: number; // Target: < 3.0 hl/hl
}

export interface SpcMetric {
  id: string;
  parameterName: string;
  unit: string;
  target: number;
  usl: number; // Upper Spec Limit
  lsl: number; // Lower Spec Limit
  ucl: number; // Upper Control Limit (3-sigma)
  lcl: number; // Lower Control Limit (3-sigma)
  mean: number;
  stdDev: number;
  cp: number;
  cpk: number;
  recentValues: { batchId: string; value: number; timestamp: number }[];
  status: "IN_CONTROL" | "WARNING" | "OUT_OF_CONTROL";
  violations: string[];
}

export interface EquipmentAsset {
  id: string;
  name: string;
  category: "PUMP" | "MOTOR" | "COMPRESSOR" | "CHILLER" | "BOILER" | "VALVE_MANIFOLD" | "CONVEYOR" | "FILLER";
  location: PlantStageId;
  runtimeHours: number;
  vibrationRmsMmS: number; // ISO 10816 threshold ~ 4.5 mm/s
  vibrationPeakG: number;
  bearingTempC: number;
  motorCurrentAmps: number;
  healthScorePct: number; // 0..100
  failureProbabilityNext30d: number; // 0..1
  remainingUsefulLifeHours: number; // RUL
  maintenancePriority: "CRITICAL" | "HIGH" | "MEDIUM" | "LOW" | "NORMAL";
  lastMaintenanceDate: string;
  recommendedTask?: string;
}

export interface PackagingLineState {
  id: string;
  name: string;
  type: "BOTTLE" | "CAN" | "KEG";
  targetSpeedUnitsPerHour: number;
  actualSpeedUnitsPerHour: number;
  currentProduct: string;
  batchId: string;
  availabilityPct: number;
  performancePct: number;
  qualityPct: number;
  oeePct: number;
  totalProducedUnits: number;
  rejectedUnits: number;
  dissolvedOxygenInPackagePpb: number;
  co2PurityPct: number;
  downtimeMinutes: number;
  stoppages: { reason: string; durationMin: number }[];
}

export interface CipCircuitState {
  id: string;
  name: string;
  activeVesselId?: string;
  currentStep: "IDLE" | "PRE_RINSE" | "CAUSTIC_WASH" | "INTER_RINSE" | "ACID_WASH" | "FINAL_RINSE" | "SANITISER";
  elapsedSeconds: number;
  totalDurationSeconds: number;
  waterRecoveryTankPct: number;
  causticConductivityMsCm: number; // Target: 65-80 mS/cm
  causticTempC: number; // Target: 75-80°C
  acidConductivityMsCm: number;
  flowVelocityMS: number; // Mechanical action target: > 1.5 m/s
  waterSavedTodayHl: number;
  chemicalOptimisationPct: number;
}

export interface SimulationScenario {
  id: string;
  name: string;
  description: string;
  active: boolean;
  parameters: {
    energyPriceSpikeMultiplier: number;
    solarIrradiancePct: number;
    chillerDegradationCopPct: number;
    grainMoistureDeltaPct: number;
    waterRestrictionPct: number;
    demandSurgePct: number;
    fermentationTemperatureOffsetC: number;
    fermenterOutageId?: string;
  };
}

export interface ArchitectureLayerMetric {
  layer: "RUST_CORE" | "PYTHON_TWIN" | "R_ANALYTICS" | "KOTLIN_UI";
  title: string;
  role: string;
  cycleTimeMs: number;
  throughputEventsSec: number;
  memoryMb: number;
  healthStatus: "HEALTHY" | "DEGRADED" | "STANDBY";
  modules: { name: string; status: string; latencyUs: number }[];
}
