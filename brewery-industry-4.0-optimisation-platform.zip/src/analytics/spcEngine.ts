/**
 * Statistical Process Control (SPC) & Quality Analytics Engine
 * Mirrors R industrial quality packages (qcc, SixSigma, SPC).
 * Calculates Shewhart X-bar, R-charts, Western Electric rule violations, and Cp/Cpk indices.
 */

import { SpcMetric } from "../types/brewery";

export function calculateSpcMetrics(
  parameterName: string,
  unit: string,
  target: number,
  usl: number,
  lsl: number,
  values: { batchId: string; value: number; timestamp: number }[]
): SpcMetric {
  if (values.length === 0) {
    return {
      id: parameterName.toLowerCase().replace(/\s+/g, "_"),
      parameterName,
      unit,
      target,
      usl,
      lsl,
      ucl: target * 1.05,
      lcl: target * 0.95,
      mean: target,
      stdDev: 0.01,
      cp: 1.33,
      cpk: 1.33,
      recentValues: [],
      status: "IN_CONTROL",
      violations: [],
    };
  }

  const rawNums = values.map((v) => v.value);
  const n = rawNums.length;
  const mean = rawNums.reduce((a, b) => a + b, 0) / n;

  const variance = rawNums.reduce((acc, v) => acc + Math.pow(v - mean, 2), 0) / Math.max(1, n - 1);
  const stdDev = Math.sqrt(variance);

  // 3-Sigma Control Limits
  const ucl = mean + 3 * stdDev;
  const lcl = mean - 3 * stdDev;

  // Process Capability Indices
  const cp = (usl - lsl) / (6 * Math.max(0.0001, stdDev));
  const cpu = (usl - mean) / (3 * Math.max(0.0001, stdDev));
  const cpl = (mean - lsl) / (3 * Math.max(0.0001, stdDev));
  const cpk = Math.min(cpu, cpl);

  // Western Electric Rules Checking
  const violations: string[] = [];

  // Rule 1: Point beyond 3-sigma
  const outOfLimitCount = rawNums.filter((x) => x > ucl || x < lcl).length;
  if (outOfLimitCount > 0) {
    violations.push(`Rule 1: ${outOfLimitCount} sample(s) beyond 3-sigma control limits`);
  }

  // Rule 2: 7 or more points in a row on same side of center line
  let runLength = 0;
  let lastSide = 0;
  for (const v of rawNums) {
    const side = v > mean ? 1 : -1;
    if (side === lastSide) {
      runLength++;
      if (runLength >= 7 && !violations.some((v) => v.includes("Rule 2"))) {
        violations.push("Rule 2: 7 consecutive points on the same side of the mean (Process Shift)");
      }
    } else {
      lastSide = side;
      runLength = 1;
    }
  }

  // Rule 3: 6 consecutive points trending strictly up or down
  let trendCount = 0;
  for (let i = 1; i < rawNums.length; i++) {
    if (rawNums[i] > rawNums[i - 1]) {
      trendCount = trendCount >= 0 ? trendCount + 1 : 1;
    } else if (rawNums[i] < rawNums[i - 1]) {
      trendCount = trendCount <= 0 ? trendCount - 1 : -1;
    }
    if (Math.abs(trendCount) >= 6 && !violations.some((v) => v.includes("Rule 3"))) {
      violations.push("Rule 3: 6 consecutive points trending continuously in one direction");
    }
  }

  let status: "IN_CONTROL" | "WARNING" | "OUT_OF_CONTROL" = "IN_CONTROL";
  if (violations.length > 0 || cpk < 1.0) {
    status = "OUT_OF_CONTROL";
  } else if (cpk < 1.33) {
    status = "WARNING";
  }

  return {
    id: parameterName.toLowerCase().replace(/\s+/g, "_"),
    parameterName,
    unit,
    target,
    usl,
    lsl,
    ucl: Number(ucl.toFixed(2)),
    lcl: Number(lcl.toFixed(2)),
    mean: Number(mean.toFixed(2)),
    stdDev: Number(stdDev.toFixed(3)),
    cp: Number(cp.toFixed(2)),
    cpk: Number(cpk.toFixed(2)),
    recentValues: values,
    status,
    violations,
  };
}
