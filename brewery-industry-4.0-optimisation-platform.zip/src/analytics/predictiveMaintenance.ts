/**
 * Predictive Maintenance & Reliability Analytics Engine
 * Mirrors R survival analysis (survival, fitdistrplus) and ISO 10816 machinery vibration standards.
 * Computes Weibull hazard rate, Remaining Useful Life (RUL), and bearing degradation.
 */

import { EquipmentAsset } from "../types/brewery";

export function evaluateAssetHealth(asset: EquipmentAsset): {
  assetId: string;
  healthScorePct: number;
  rulHours: number;
  failureRiskPct: number;
  isoVibrationSeverity: "GOOD" | "ACCEPTABLE" | "UNSATISFACTORY" | "UNACCEPTABLE";
  recommendedIntervention?: string;
} {
  // ISO 10816-3 Vibration Severity classification for medium pumps/motors (Class II)
  let isoVibrationSeverity: "GOOD" | "ACCEPTABLE" | "UNSATISFACTORY" | "UNACCEPTABLE" = "GOOD";
  if (asset.vibrationRmsMmS > 4.5) {
    isoVibrationSeverity = "UNACCEPTABLE";
  } else if (asset.vibrationRmsMmS > 2.8) {
    isoVibrationSeverity = "UNSATISFACTORY";
  } else if (asset.vibrationRmsMmS > 1.8) {
    isoVibrationSeverity = "ACCEPTABLE";
  }

  // Weibull reliability model parameters: beta = 2.4 (wear-out phase), eta = characteristic life in hours
  const beta = 2.4;
  const eta = 18000; // 18,000 hours MTBF baseline
  const t = asset.runtimeHours;

  // Cumulative failure probability F(t) = 1 - exp(-(t/eta)^beta)
  const baseFailureProb = 1 - Math.exp(-Math.pow(t / eta, beta));

  // Stress acceleration factors (temperature and vibration penalties)
  const tempPenalty = asset.bearingTempC > 65 ? (asset.bearingTempC - 65) * 0.015 : 0;
  const vibPenalty = asset.vibrationRmsMmS > 2.5 ? (asset.vibrationRmsMmS - 2.5) * 0.12 : 0;

  const totalRiskPct = Math.min(99.9, Math.max(0.1, (baseFailureProb + tempPenalty + vibPenalty) * 100));
  const healthScorePct = Math.max(5, 100 - totalRiskPct);

  // RUL calculation
  const rulHours = Math.max(24, Math.round(asset.remainingUsefulLifeHours * (healthScorePct / 100)));

  let recommendedIntervention: string | undefined;
  if (isoVibrationSeverity === "UNACCEPTABLE" || healthScorePct < 40) {
    recommendedIntervention = "Schedule urgent bearing replacement during next changeover. High 2X harmonics indicate outer race spalling.";
  } else if (asset.bearingTempC > 70) {
    recommendedIntervention = "High bearing temperature. Inspect lubrication level and thermal dissipation shroud.";
  }

  return {
    assetId: asset.id,
    healthScorePct: Number(healthScorePct.toFixed(1)),
    rulHours,
    failureRiskPct: Number(totalRiskPct.toFixed(1)),
    isoVibrationSeverity,
    recommendedIntervention,
  };
}
