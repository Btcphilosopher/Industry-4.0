import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './components/header/header';
import { NavBarComponent } from './components/navigation/nav-bar';
import { DashboardComponent } from './components/dashboard/dashboard';
import { PartsCatalogComponent } from './components/parts-catalog/parts-catalog';
import { BomTreeComponent } from './components/bom-tree/bom-tree';
import { MachineToolsViewComponent } from './components/machine-tools-view/machine-tools-view';
import { ManufacturingRouteComponent } from './components/manufacturing-route/manufacturing-route';
import { QualityPanelComponent } from './components/quality-panel/quality-panel';
import { FeaSimulationComponent } from './components/fea-simulation/fea-simulation';
import { InventoryViewComponent } from './components/inventory-view/inventory-view';
import { SupplyChainComponent } from './components/supply-chain/supply-chain';
import { DocumentViewerComponent } from './components/document-viewer/document-viewer';
import { AnalyticsViewComponent } from './components/analytics-view/analytics-view';
import { PartTwinService } from './services/part-twin.service';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    HeaderComponent,
    NavBarComponent,
    DashboardComponent,
    PartsCatalogComponent,
    BomTreeComponent,
    MachineToolsViewComponent,
    ManufacturingRouteComponent,
    QualityPanelComponent,
    FeaSimulationComponent,
    InventoryViewComponent,
    SupplyChainComponent,
    DocumentViewerComponent,
    AnalyticsViewComponent
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex flex-col h-screen w-screen overflow-hidden bg-[#0a0d14] text-neutral-100 font-sans selection:bg-red-600 selection:text-white">
      <!-- TEILWERK Main Engineering Top Header -->
      <app-header class="flex-shrink-0"></app-header>

      <!-- Main Navigation Tabs Bar -->
      <app-nav-bar class="flex-shrink-0"></app-nav-bar>

      <!-- Main Application Content Routing Viewport -->
      <main class="flex-1 overflow-hidden relative flex flex-col">
        @switch (activeMainTab()) {
          @case ('DASHBOARD') {
            <app-dashboard class="h-full"></app-dashboard>
          }
          @case ('PARTS') {
            <app-parts-catalog class="h-full"></app-parts-catalog>
          }
          @case ('ASSEMBLIES') {
            <app-bom-tree class="h-full"></app-bom-tree>
          }
          @case ('MACHINES') {
            <app-machine-tools-view class="h-full"></app-machine-tools-view>
          }
          @case ('MANUFACTURING') {
            <app-manufacturing-route class="h-full"></app-manufacturing-route>
          }
          @case ('QUALITY') {
            <app-quality-panel class="h-full"></app-quality-panel>
          }
          @case ('SIMULATION') {
            <app-fea-simulation class="h-full"></app-fea-simulation>
          }
          @case ('INVENTORY') {
            <app-inventory-view class="h-full"></app-inventory-view>
          }
          @case ('SUPPLY_CHAIN') {
            <app-supply-chain class="h-full"></app-supply-chain>
          }
          @case ('DOCUMENTS') {
            <app-document-viewer class="h-full"></app-document-viewer>
          }
          @case ('ANALYTICS') {
            <app-analytics-view class="h-full"></app-analytics-view>
          }
        }
      </main>
    </div>
  `
})
export class App {
  readonly partService = inject(PartTwinService);
  readonly activeMainTab = computed(() => this.partService.activeMainTab());
}
