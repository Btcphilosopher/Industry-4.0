import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PartTwinService } from '../../services/part-twin.service';

@Component({
  selector: 'app-machine-tools-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0f1218] border border-white/10 text-neutral-200 overflow-y-auto font-mono text-xs">
      <!-- Title Bar -->
      <div class="p-3 bg-[#141822] border-b border-white/10 flex flex-wrap items-center justify-between gap-2">
        <div class="flex items-center gap-2">
          <mat-icon class="text-red-500 !w-4 !h-4 !text-[16px]">precision_manufacturing</mat-icon>
          <span class="font-bold text-white tracking-wider">WERKZEUGMASCHINEN-ZWILLINGE // MACHINE SHOP TELEMETRY</span>
        </div>
        <div class="text-[10px] px-2 py-0.5 bg-emerald-950 text-emerald-400 border border-emerald-800">
          ALLE MASCHINEN ONLINE (OPC UA / MQTT)
        </div>
      </div>

      <div class="p-4 space-y-6">
        <!-- Machine Cards Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          @for (machine of machineTools(); track machine.id) {
            <div class="bg-[#151a24] border border-white/10 p-4 hover:border-red-500/40 transition-colors">
              <div class="flex flex-wrap items-start justify-between gap-2 border-b border-white/10 pb-3 mb-3">
                <div>
                  <div class="text-[10px] text-red-400 uppercase font-bold">{{ machine.code }} // {{ machine.type }}</div>
                  <h3 class="text-sm font-bold text-white">{{ machine.name }}</h3>
                  <div class="text-[10px] text-neutral-400">{{ machine.facility }}</div>
                </div>
                <div class="flex items-center gap-2">
                  <span class="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  <span class="px-2 py-0.5 text-[9px] bg-emerald-950 text-emerald-400 border border-emerald-800 font-bold">
                    {{ machine.status }}
                  </span>
                </div>
              </div>

              <!-- Live Telemetry Matrix -->
              <div class="grid grid-cols-3 gap-2 text-[10px] mb-3">
                <div class="bg-[#0f1218] border border-white/10 p-2">
                  <div class="text-neutral-500 text-[9px]">SPINDELDREHZAHL</div>
                  <div class="font-bold text-white text-xs mt-0.5">{{ machine.spindleRpm }} <span class="text-[9px] text-neutral-400 font-normal">RPM</span></div>
                </div>
                <div class="bg-[#0f1218] border border-white/10 p-2">
                  <div class="text-neutral-500 text-[9px]">LEISTUNG (P_e)</div>
                  <div class="font-bold text-yellow-400 text-xs mt-0.5">{{ machine.powerKw }} <span class="text-[9px] text-neutral-400 font-normal">kW</span></div>
                </div>
                <div class="bg-[#0f1218] border border-white/10 p-2">
                  <div class="text-neutral-500 text-[9px]">TEMPERATUR</div>
                  <div class="font-bold text-sky-400 text-xs mt-0.5">{{ machine.temperatureC }} <span class="text-[9px] text-neutral-400 font-normal">°C</span></div>
                </div>
                <div class="bg-[#0f1218] border border-white/10 p-2">
                  <div class="text-neutral-500 text-[9px]">OEE-GESAMTWIRKUNGSGRAD</div>
                  <div class="font-bold text-emerald-400 text-xs mt-0.5">{{ machine.oeePercent }}%</div>
                </div>
                <div class="bg-[#0f1218] border border-white/10 p-2">
                  <div class="text-neutral-500 text-[9px]">SCHWINGUNG (RMS)</div>
                  <div class="font-bold text-white text-xs mt-0.5">{{ machine.vibrationMmS }} <span class="text-[9px] text-neutral-400 font-normal">mm/s</span></div>
                </div>
                <div class="bg-[#0f1218] border border-white/10 p-2">
                  <div class="text-neutral-500 text-[9px]">WERKZEUGVERSCHLEISS</div>
                  <div class="font-bold text-yellow-400 text-xs mt-0.5">VB {{ machine.toolWearPercent }}%</div>
                </div>
              </div>

              <!-- Active Part In Production -->
              <div class="pt-2 border-t border-white/10 flex items-center justify-between text-[10px]">
                <div class="flex items-center gap-1.5">
                  <span class="text-neutral-500">Aktuelles Bauteil:</span>
                  <span class="font-bold text-white">{{ machine.currentPartName }}</span>
                </div>
                <button 
                  (click)="partService.selectPart(machine.currentPartId)"
                  class="px-2 py-0.5 bg-white/5 hover:bg-white/15 text-neutral-200 border border-white/10 transition-colors">
                  Teil ansehen
                </button>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class MachineToolsViewComponent {
  readonly partService = inject(PartTwinService);
  readonly machineTools = computed(() => this.partService.machineTools());
}
