import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PartTwinService } from '../../services/part-twin.service';

@Component({
  selector: 'app-traceability-graph',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0f1218] border border-white/10 text-neutral-200 overflow-y-auto font-mono text-xs">
      <!-- Title Bar -->
      <div class="p-3 bg-[#141822] border-b border-white/10 flex flex-wrap items-center justify-between gap-2">
        <div class="flex items-center gap-2">
          <mat-icon class="text-red-500 !w-4 !h-4 !text-[16px]">fingerprint</mat-icon>
          <span class="font-bold text-white tracking-wider">RÜCKVERFOLGBARKEIT & DIGITALER PRODUKTPASS // DPP TRACEABILITY</span>
        </div>
        <div class="flex items-center gap-2">
          <span class="text-[10px] px-2 py-0.5 bg-sky-950 text-sky-400 border border-sky-800">
            DMC: {{ part().serialRange }}
          </span>
          <span class="text-[10px] px-2 py-0.5 bg-white/5 text-neutral-300 border border-white/10">
            CHARGE: {{ part().batch }}
          </span>
        </div>
      </div>

      <div class="p-4 space-y-6">
        <!-- Digital Product Passport (DPP) Overview Card -->
        <div class="bg-[#151a24] border border-white/10 p-4">
          <div class="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-3 mb-3">
            <div>
              <div class="text-[10px] text-neutral-400 uppercase">DIGITAL PRODUCT PASSPORT (EU DPP / DIN SPEC 91406)</div>
              <h2 class="text-sm font-bold text-white">{{ part().name }}</h2>
              <div class="text-[11px] text-red-400 font-mono mt-0.5">UID: {{ part().id }} // DMC 2D-DataMatrix eingelasert</div>
            </div>
            <div class="flex items-center gap-3">
              <!-- Simulated DataMatrix 2D Code Box -->
              <div class="w-12 h-12 bg-white p-1 flex items-center justify-center border border-white">
                <div class="w-full h-full bg-black grid grid-cols-4 grid-rows-4 gap-0.5 p-0.5">
                  <div class="bg-white"></div><div class="bg-black"></div><div class="bg-white"></div><div class="bg-white"></div>
                  <div class="bg-white"></div><div class="bg-white"></div><div class="bg-black"></div><div class="bg-white"></div>
                  <div class="bg-black"></div><div class="bg-white"></div><div class="bg-white"></div><div class="bg-black"></div>
                  <div class="bg-white"></div><div class="bg-black"></div><div class="bg-white"></div><div class="bg-white"></div>
                </div>
              </div>
              <div class="text-[10px] text-neutral-400">
                <div>SCANNBARER 2D-CODE</div>
                <div class="text-emerald-400 font-bold">KRYPTOGRAFISCH VERIFIZIERT</div>
              </div>
            </div>
          </div>

          <div class="grid grid-cols-2 md:grid-cols-4 gap-3 text-[10px]">
            <div>
              <span class="text-neutral-500">Hersteller-Werk:</span>
              <div class="font-bold text-white">{{ part().manufacturer }}</div>
            </div>
            <div>
              <span class="text-neutral-500">Erstzulassung / Produktion:</span>
              <div class="font-bold text-white">2026-03-15 (Kalenderwoche 11)</div>
            </div>
            <div>
              <span class="text-neutral-500">Kreislauffähigkeit / Recycling:</span>
              <div class="font-bold text-emerald-400">{{ part().recyclabilityPercent }}% ({{ part().material.name }})</div>
            </div>
            <div>
              <span class="text-neutral-500">REACH / RoHS Status:</span>
              <div class="font-bold text-emerald-400">KONFORM (Keine SVHC-Stoffe)</div>
            </div>
          </div>
        </div>

        <!-- Traceability Lifecycle Timeline -->
        <div>
          <div class="text-[11px] font-bold text-neutral-300 uppercase mb-3 flex items-center gap-1.5">
            <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">history</mat-icon>
            LÜCKENLOSE LEBENSLAUFAKTE // AUDIT-TRAIL
          </div>

          <div class="space-y-3 relative before:absolute before:left-5 before:top-3 before:bottom-3 before:w-0.5 before:bg-white/10">
            @for (event of part().traceability; track event.id) {
              <div class="relative pl-10 bg-[#151a24] border border-white/10 p-3 hover:border-red-500/40 transition-colors">
                <!-- Status Dot -->
                <div class="absolute left-3.5 top-3.5 w-3.5 h-3.5 rounded-full border-2 border-[#151a24] flex items-center justify-center shadow"
                  [class.bg-emerald-500]="event.status === 'ERFOLG'"
                  [class.bg-sky-500]="event.status === 'INFO'"
                  [class.bg-yellow-500]="event.status === 'WARNUNG'"
                  [class.bg-red-500]="event.status === 'ALARM'">
                </div>

                <div class="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-1.5 mb-1.5">
                  <div class="flex items-center gap-2">
                    <span class="font-bold text-white text-xs">{{ event.title }}</span>
                    <span class="text-[9px] px-1.5 py-0.2 bg-white/5 text-neutral-300 border border-white/10 font-mono">{{ event.eventType }}</span>
                  </div>
                  <div class="text-[10px] text-neutral-400 font-mono">{{ event.timestamp }}</div>
                </div>

                <div class="text-[11px] text-neutral-400 mb-2">
                  <span class="text-neutral-500">Ort / System:</span> {{ event.location }} // <span class="text-neutral-500">Bediener:</span> {{ event.operatorOrSystem }}
                </div>

                <!-- Parameters Key-Value tags -->
                <div class="flex flex-wrap gap-2 text-[9px]">
                  @for (param of getEventParamsList(event.parameters); track param.key) {
                    <div class="bg-white/5 border border-white/10 px-2 py-0.5 text-neutral-300">
                      <span class="text-neutral-500">{{ param.key }}:</span> <strong class="text-sky-300">{{ param.value }}</strong>
                    </div>
                  }
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Failure History & Root Cause Analysis (RCA) -->
        <div class="bg-[#151a24] border border-white/10 p-4">
          <div class="text-[11px] font-bold text-neutral-300 uppercase mb-3 flex items-center justify-between">
            <span class="flex items-center gap-1.5">
              <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">troubleshoot</mat-icon>
              FEHLER- & SCHADENSANALYSE // FIELD RELIABILITY (RCA)
            </span>
            <span class="text-[10px] text-neutral-400">MTBF: {{ (part().simulationResult.remainingUsefulLifeHours * 2.5).toFixed(0) }} h</span>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div class="space-y-2 bg-[#0f1218] border border-white/10 p-3">
              <div class="text-[10px] text-neutral-400 uppercase">HAUPT-VERSAGENSMODUS (FMEA)</div>
              <div class="text-sm font-bold text-red-400">Oberflächenermüdung & Pittings (Wälzkontakt)</div>
              <div class="text-[11px] text-neutral-300 font-sans mt-1">
                Mikrorisse unterhalb der Lauffläche bei Überschreitung der Hertz'schen Pressung unter Mangelschmierung.
              </div>
            </div>

            <div class="space-y-2 bg-[#0f1218] border border-white/10 p-3">
              <div class="text-[10px] text-neutral-400 uppercase">PRÄVENTIVE WARTUNGSEMPFEHLUNG</div>
              <div class="text-sm font-bold text-emerald-400">Schwingungsanalyse & Schmierstoffintervall 15.000 h</div>
              <div class="text-[11px] text-neutral-400 font-sans mt-1">
                Garantierte Mindestlaufzeit: 10 Jahre oder 300.000 km bei Einhaltung der Schmierstoffspezifikation ISO VG 68.
              </div>
            </div>
          </div>
        </div>

        <!-- Direct Replacement & Compatibility Graph -->
        <div class="bg-[#151a24] border border-white/10 p-4">
          <div class="text-[11px] font-bold text-neutral-300 uppercase mb-3 flex items-center gap-1.5">
            <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">swap_horiz</mat-icon>
            ERSATZTEIL- & KOMPATIBILITÄTSBEZIEHUNGEN // INTERCHANGEABILITY
          </div>

          <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
            @for (comp of part().compatibilities; track comp.relatedPartId) {
              <div class="bg-[#0f1218] border border-white/10 p-3">
                <div class="text-[10px] text-neutral-400 uppercase">{{ comp.relationshipType }}</div>
                <div class="font-bold text-white mt-1">{{ comp.relatedPartNumber }} ({{ comp.relatedPartName }})</div>
                <div class="text-[10px] text-emerald-400 mt-0.5">{{ comp.notes }}</div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `
})
export class TraceabilityGraphComponent {
  readonly partService = inject(PartTwinService);
  readonly part = computed(() => this.partService.activePart());

  getEventParamsList(params?: Record<string, string | number>): { key: string; value: string }[] {
    if (!params) return [];
    return Object.entries(params).map(([key, value]) => ({ key, value: String(value) }));
  }
}
