import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PartTwinService, UserRole } from '../../services/part-twin.service';

@Component({
  selector: 'app-header',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="bg-[#0b0e14] border-b border-white/10 text-neutral-200 select-none px-4 py-2 flex flex-wrap items-center justify-between gap-3 font-mono">
      <!-- Brand & Product Title -->
      <div class="flex items-center gap-4">
        <button type="button" class="flex items-center gap-2.5 cursor-pointer bg-transparent border-none text-left p-0" (click)="partService.setMainTab('DASHBOARD')">
          <!-- Industrial Technical Logo Mark -->
          <div class="w-8 h-8 bg-red-600 border border-white/20 flex items-center justify-center text-white font-black text-sm tracking-tighter shadow-md">
            TW
          </div>
          <div>
            <div class="flex items-center gap-2">
              <span class="text-base font-black tracking-widest text-white uppercase font-mono">TEILWERK</span>
              <span class="text-[9px] px-1.5 py-0.2 bg-red-950 text-red-400 border border-red-800/80 font-bold">PLM V26.4</span>
            </div>
            <div class="text-[9px] tracking-wider text-neutral-400 font-sans">
              DAS DIGITALE ORIGINAL. <span class="text-neutral-500">// German Industrial Parts Digital Twin</span>
            </div>
          </div>
        </button>

        <!-- Divider -->
        <div class="hidden md:block h-6 w-px bg-white/15"></div>

        <!-- Active Part Twin Breadcrumb / Quick Status -->
        <div class="hidden lg:flex items-center gap-2 text-xs">
          <span class="text-neutral-500">AKTIVES TEIL:</span>
          <span class="text-red-400 font-bold font-mono">{{ activePart().partNumber }}</span>
          <span class="text-white truncate max-w-[200px] font-medium">{{ activePart().name }}</span>
          <span class="text-[9px] px-1.5 py-0.2 bg-white/5 border border-white/10 text-neutral-300">
            Rev. {{ activePart().currentRevision }}
          </span>
        </div>
      </div>

      <!-- Right Action Bar: Simulation Clock, Role Switcher, Standards Badge -->
      <div class="flex items-center gap-3">
        <!-- Simulation Clock Quick Status -->
        <div class="flex items-center gap-1.5 bg-[#131720] border border-white/10 px-2 py-1">
          <span class="w-2 h-2 rounded-full" [class.bg-emerald-500]="partService.isSimulating()" [class.bg-neutral-600]="!partService.isSimulating()" [class.animate-pulse]="partService.isSimulating()"></span>
          <span class="text-[10px] text-neutral-300">SIM-UHR:</span>
          <button 
            (click)="partService.toggleSimulation()"
            [class.text-emerald-400]="partService.isSimulating()"
            [class.text-neutral-400]="!partService.isSimulating()"
            class="hover:text-white flex items-center">
            <mat-icon class="!w-3.5 !h-3.5 !text-[14px]">{{ partService.isSimulating() ? 'pause' : 'play_arrow' }}</mat-icon>
          </button>
          <span class="text-[10px] text-red-400 font-bold">{{ partService.simulationSpeed() }}x</span>
        </div>

        <!-- User Role Switcher -->
        <div class="flex items-center gap-1 bg-[#131720] border border-white/10 px-2 py-1">
          <mat-icon class="text-neutral-400 !w-3.5 !h-3.5 !text-[14px]">badge</mat-icon>
          <select 
            [value]="partService.activeUserRole()" 
            (change)="onRoleChange($event)"
            class="bg-transparent text-white text-[11px] font-mono focus:outline-none border-none cursor-pointer">
            <option value="INGENIEUR" class="bg-[#141822]">Rolle: Ingenieur (CAD/FEM)</option>
            <option value="QUALITÄT" class="bg-[#141822]">Rolle: Qualitätssicherung (CMM)</option>
            <option value="FERTIGUNG" class="bg-[#141822]">Rolle: Fertigungsleiter (CNC/MES)</option>
            <option value="DISPONENT" class="bg-[#141822]">Rolle: Disposition (ERP/Lager)</option>
            <option value="ADMIN" class="bg-[#141822]">Rolle: Systemadministrator</option>
          </select>
        </div>

        <!-- DIN / IATF Certification Stamp -->
        <div class="hidden sm:flex items-center gap-1 text-[9px] text-neutral-400 bg-white/5 border border-white/10 px-2 py-1">
          <mat-icon class="text-emerald-400 !w-3 !h-3 !text-[12px]">verified</mat-icon>
          <span>IATF 16949 // DIN ISO 9001</span>
        </div>
      </div>
    </header>
  `
})
export class HeaderComponent {
  readonly partService = inject(PartTwinService);
  readonly activePart = computed(() => this.partService.activePart());

  onRoleChange(event: Event) {
    const val = (event.target as HTMLSelectElement).value as UserRole;
    this.partService.setRole(val);
  }
}
