import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PartTwinService } from '../../services/part-twin.service';

@Component({
  selector: 'app-technical-drawing',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full h-full bg-[#0b121e] border border-white/10 flex flex-col select-none overflow-hidden font-mono">
      <!-- Drawing Controls Top Toolbar -->
      <div class="h-10 bg-[#131b29] border-b border-white/10 px-3 flex items-center justify-between">
        <div class="flex items-center gap-3">
          <span class="text-xs font-bold text-sky-400 tracking-wider flex items-center gap-1.5">
            <mat-icon class="text-xs !w-4 !h-4 !text-[16px]">architecture</mat-icon>
            DIN ISO 7200 // TECHNISCHE FERTIGUNGSZEICHNUNG
          </span>
          <span class="text-[11px] text-neutral-400 px-2 py-0.5 bg-white/5 border border-white/10">
            PROJEKTIONSMETHODE 1 (EUROPÄISCH)
          </span>
        </div>

        <div class="flex items-center gap-2">
          <!-- Drawing Style Toggle -->
          <button 
            (click)="toggleTheme()"
            class="px-2.5 py-1 text-xs bg-white/5 hover:bg-white/10 text-neutral-300 border border-white/10 flex items-center gap-1.5 transition-colors">
            <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">palette</mat-icon>
            {{ isBlueprint() ? 'BLUEPRINT-MODUS' : 'DIN-SCHWARZ/WEISS' }}
          </button>
          
          <button 
            (click)="zoomIn()" 
            class="px-2 py-1 text-xs bg-white/5 hover:bg-white/10 text-neutral-300 border border-white/10">
            +
          </button>
          <span class="text-xs text-neutral-400 min-w-[40px] text-center">{{ (zoom() * 100).toFixed(0) }}%</span>
          <button 
            (click)="zoomOut()" 
            class="px-2 py-1 text-xs bg-white/5 hover:bg-white/10 text-neutral-300 border border-white/10">
            -
          </button>
          <button 
            (click)="resetZoom()" 
            class="px-2 py-1 text-xs bg-white/5 hover:bg-white/10 text-neutral-300 border border-white/10">
            1:1
          </button>
        </div>
      </div>

      <!-- DIN Drawing Sheet Canvas Container -->
      <div class="flex-1 overflow-auto p-4 flex items-center justify-center" [class.bg-[#070b12]]="!isBlueprint()" [class.bg-blueprint]="isBlueprint()">
        <!-- Outer DIN Drawing Sheet Border (A2 / A3 Aspect) -->
        <div 
          [style.transform]="'scale(' + zoom() + ')'"
          [style.transform-origin]="'center center'"
          class="w-[980px] h-[640px] border-2 border-sky-400/80 p-4 relative flex flex-col justify-between transition-transform shadow-2xl"
          [class.bg-[#0b1424]]="isBlueprint()"
          [class.bg-[#0a0d14]]="!isBlueprint()">
          
          <!-- Inner Drawing Limit Frame -->
          <div class="absolute inset-2 border border-sky-500/40 pointer-events-none"></div>

          <!-- Drawing Grid Numbers & Reference Letters on Margins -->
          <div class="absolute top-0.5 left-0 right-0 flex justify-around text-[9px] text-sky-400/60 font-mono pointer-events-none">
            <span>1</span><span>2</span><span>3</span><span>4</span><span>5</span><span>6</span><span>7</span><span>8</span>
          </div>
          <div class="absolute top-0 bottom-0 left-0.5 flex flex-col justify-around text-[9px] text-sky-400/60 font-mono pointer-events-none">
            <span>A</span><span>B</span><span>C</span><span>D</span><span>E</span><span>F</span>
          </div>

          <!-- Main 2D CAD Projections (SVG Render) -->
          <div class="flex-1 w-full h-full relative">
            <svg class="w-full h-full" viewBox="0 0 940 540">
              <defs>
                <!-- Hatching pattern for DIN section cuts -->
                <pattern id="sectionHatch" width="8" height="8" patternTransform="rotate(45 0 0)" patternUnits="userSpaceOnUse">
                  <line x1="0" y1="0" x2="0" y2="8" stroke="rgba(56, 189, 248, 0.4)" stroke-width="1" />
                </pattern>
                <!-- Datum Marker symbol -->
                <marker id="arrow" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                  <path d="M 0 1.5 L 10 5 L 0 8.5 z" fill="#38bdf8" />
                </marker>
              </defs>

              <!-- Center Lines (Dash-Dot-Dash Red/Cyan) -->
              <line x1="80" y1="240" x2="420" y2="240" stroke="#ef4444" stroke-width="0.75" stroke-dasharray="14,3,3,3" />
              <line x1="250" y1="60" x2="250" y2="420" stroke="#ef4444" stroke-width="0.75" stroke-dasharray="14,3,3,3" />

              <line x1="520" y1="240" x2="840" y2="240" stroke="#ef4444" stroke-width="0.75" stroke-dasharray="14,3,3,3" />
              <line x1="680" y1="60" x2="680" y2="420" stroke="#ef4444" stroke-width="0.75" stroke-dasharray="14,3,3,3" />

              <!-- VIEW 1: FRONT VIEW (VORDERANSICHT) -->
              <g transform="translate(100, 90)">
                <text x="150" y="-30" text-anchor="middle" fill="#93c5fd" font-size="12" font-weight="bold">ANSICHT VORDERSEITE (1:1)</text>
                
                @if (part().geometryType === 'BEARING_6208') {
                  <!-- Bearing Concentric Circles Front View -->
                  <circle cx="150" cy="150" r="120" fill="none" stroke="#38bdf8" stroke-width="2.5" />
                  <circle cx="150" cy="150" r="96" fill="none" stroke="#38bdf8" stroke-width="1.5" stroke-dasharray="4,2" />
                  <circle cx="150" cy="150" r="84" fill="none" stroke="#38bdf8" stroke-width="1.5" />
                  <circle cx="150" cy="150" r="60" fill="none" stroke="#38bdf8" stroke-width="2.5" />
                  
                  <!-- Pitch circle & 9 balls -->
                  <circle cx="150" cy="150" r="90" fill="none" stroke="#ef4444" stroke-width="0.75" stroke-dasharray="8,2,2,2" />
                  @for (ball of [0, 40, 80, 120, 160, 200, 240, 280, 320]; track $index) {
                    <circle 
                      [attr.cx]="150 + 90 * getCos(ball)" 
                      [attr.cy]="150 + 90 * getSin(ball)" 
                      r="17" 
                      fill="none" 
                      stroke="#38bdf8" 
                      stroke-width="1.5" />
                  }
                } @else if (part().geometryType === 'BRAKE_DISC_VENTED') {
                  <!-- Brake Disc 5-Hole Front View -->
                  <circle cx="150" cy="150" r="130" fill="none" stroke="#38bdf8" stroke-width="2.5" />
                  <circle cx="150" cy="150" r="85" fill="none" stroke="#38bdf8" stroke-width="1.5" />
                  <circle cx="150" cy="150" r="45" fill="none" stroke="#38bdf8" stroke-width="2.5" />
                  
                  <!-- 5x Bolt Holes on 112mm Pitch Circle -->
                  <circle cx="150" cy="150" r="65" fill="none" stroke="#ef4444" stroke-width="0.75" stroke-dasharray="8,2,2,2" />
                  @for (bolt of [0, 72, 144, 216, 288]; track $index) {
                    <circle 
                      [attr.cx]="150 + 65 * getCos(bolt)" 
                      [attr.cy]="150 + 65 * getSin(bolt)" 
                      r="8" 
                      fill="none" 
                      stroke="#38bdf8" 
                      stroke-width="1.5" />
                  }
                } @else if (part().geometryType === 'HELICAL_GEAR_Z48') {
                  <!-- Gear Front View with Involute Teeth outline -->
                  <circle cx="150" cy="150" r="125" fill="none" stroke="#38bdf8" stroke-width="2" />
                  <circle cx="150" cy="150" r="120" fill="none" stroke="#ef4444" stroke-width="1" stroke-dasharray="10,2,2,2" />
                  <circle cx="150" cy="150" r="105" fill="none" stroke="#38bdf8" stroke-width="1.5" />
                  <circle cx="150" cy="150" r="35" fill="none" stroke="#38bdf8" stroke-width="2.5" />
                  <!-- Keyway DIN 6885 -->
                  <rect x="145" y="105" width="10" height="15" fill="none" stroke="#38bdf8" stroke-width="1.5" />
                } @else {
                  <!-- Generic Mechanical Front Projection -->
                  <rect x="50" y="50" width="200" height="200" rx="10" fill="none" stroke="#38bdf8" stroke-width="2" />
                  <circle cx="150" cy="150" r="40" fill="none" stroke="#38bdf8" stroke-width="2" />
                }

                <!-- Dimension Callout Outer Diameter D -->
                <line x1="30" y1="20" x2="30" y2="280" stroke="#38bdf8" stroke-width="1" marker-start="url(#arrow)" marker-end="url(#arrow)" />
                <line x1="30" y1="20" x2="150" y2="20" stroke="#38bdf8" stroke-width="0.5" stroke-dasharray="2,2" />
                <line x1="30" y1="280" x2="150" y2="280" stroke="#38bdf8" stroke-width="0.5" stroke-dasharray="2,2" />
                <text x="18" y="155" fill="#38bdf8" font-size="11" font-weight="bold" transform="rotate(-90 18 155)">
                  Ø {{ part().dimensionsMm.outerDiameter || 80 }}.000 {{ part().toleranceClass.includes('P5') ? 'h5' : '±0.02' }}
                </text>
              </g>

              <!-- VIEW 2: SECTION A-A (SCHNITT A-A) -->
              <g transform="translate(560, 90)">
                <text x="120" y="-30" text-anchor="middle" fill="#93c5fd" font-size="12" font-weight="bold">SCHNITT A-A (DIN ISO 128)</text>

                @if (part().geometryType === 'BEARING_6208') {
                  <!-- Top Cross Section (Outer & Inner Ring & Ball) -->
                  <rect x="80" y="30" width="80" height="30" fill="url(#sectionHatch)" stroke="#38bdf8" stroke-width="2" />
                  <path d="M 120 60 A 17 17 0 0 1 120 60" fill="none" stroke="#38bdf8" stroke-width="1.5" />
                  
                  <circle cx="120" cy="90" r="17" fill="none" stroke="#38bdf8" stroke-width="2" />

                  <rect x="80" y="120" width="80" height="30" fill="url(#sectionHatch)" stroke="#38bdf8" stroke-width="2" />

                  <!-- Bottom Cross Section Symmetry -->
                  <rect x="80" y="210" width="80" height="30" fill="url(#sectionHatch)" stroke="#38bdf8" stroke-width="2" />
                  <circle cx="120" cy="270" r="17" fill="none" stroke="#38bdf8" stroke-width="2" />
                  <rect x="80" y="300" width="80" height="30" fill="url(#sectionHatch)" stroke="#38bdf8" stroke-width="2" />
                } @else if (part().geometryType === 'BRAKE_DISC_VENTED') {
                  <!-- Disc Section A-A -->
                  <rect x="70" y="20" width="100" height="15" fill="url(#sectionHatch)" stroke="#38bdf8" stroke-width="2" />
                  <rect x="70" y="45" width="100" height="15" fill="url(#sectionHatch)" stroke="#38bdf8" stroke-width="2" />
                  <rect x="130" y="60" width="40" height="90" fill="url(#sectionHatch)" stroke="#38bdf8" stroke-width="2" />
                  <!-- Symmetrical lower part -->
                  <rect x="70" y="240" width="100" height="15" fill="url(#sectionHatch)" stroke="#38bdf8" stroke-width="2" />
                  <rect x="70" y="265" width="100" height="15" fill="url(#sectionHatch)" stroke="#38bdf8" stroke-width="2" />
                  <rect x="130" y="150" width="40" height="90" fill="url(#sectionHatch)" stroke="#38bdf8" stroke-width="2" />
                } @else {
                  <rect x="70" y="40" width="100" height="260" fill="url(#sectionHatch)" stroke="#38bdf8" stroke-width="2" />
                  <rect x="70" y="120" width="100" height="100" fill="#0b1424" stroke="#38bdf8" stroke-width="1.5" />
                }

                <!-- Width Dimension B Callout -->
                <line x1="80" y1="355" x2="160" y2="355" stroke="#38bdf8" stroke-width="1" marker-start="url(#arrow)" marker-end="url(#arrow)" />
                <line x1="80" y1="330" x2="80" y2="365" stroke="#38bdf8" stroke-width="0.5" stroke-dasharray="2,2" />
                <line x1="160" y1="330" x2="160" y2="365" stroke="#38bdf8" stroke-width="0.5" stroke-dasharray="2,2" />
                <text x="120" y="375" text-anchor="middle" fill="#38bdf8" font-size="11" font-weight="bold">
                  B = {{ part().dimensionsMm.width || 18 }}.000 -0.120
                </text>

                <!-- Surface Roughness Symbol Ra 0.08 / Ra 0.8 -->
                <g transform="translate(170, 45)">
                  <path d="M 0 0 L 10 15 L 20 0 L 35 0" fill="none" stroke="#f59e0b" stroke-width="1.5" />
                  <text x="12" y="-3" fill="#f59e0b" font-size="9" font-weight="bold">{{ part().surfaceFinish.substring(0, 7) }}</text>
                </g>

                <!-- Datum A & B References -->
                <g transform="translate(50, 45)">
                  <rect x="0" y="0" width="18" height="18" fill="#131b29" stroke="#ef4444" stroke-width="1.5" />
                  <text x="9" y="13" text-anchor="middle" fill="#ef4444" font-size="10" font-weight="bold">A</text>
                </g>
                <g transform="translate(50, 135)">
                  <rect x="0" y="0" width="18" height="18" fill="#131b29" stroke="#ef4444" stroke-width="1.5" />
                  <text x="9" y="13" text-anchor="middle" fill="#ef4444" font-size="10" font-weight="bold">B</text>
                </g>
              </g>

              <!-- Geometric Tolerances Control Frame (Form- & Lagetoleranzen) -->
              <g transform="translate(400, 390)">
                <rect x="0" y="0" width="160" height="24" fill="#0b1424" stroke="#38bdf8" stroke-width="1.5" />
                <line x1="30" y1="0" x2="30" y2="24" stroke="#38bdf8" stroke-width="1" />
                <line x1="110" y1="0" x2="110" y2="24" stroke="#38bdf8" stroke-width="1" />
                <!-- Runout / Coaxiality symbol -->
                <circle cx="15" cy="12" r="6" fill="none" stroke="#38bdf8" stroke-width="1.5" />
                <text x="70" y="16" text-anchor="middle" fill="#38bdf8" font-size="10" font-weight="bold">0.002 mm</text>
                <text x="135" y="16" text-anchor="middle" fill="#ef4444" font-size="10" font-weight="bold">A - B</text>
              </g>
            </svg>
          </div>

          <!-- Official DIN ISO 7200 Title Block (Schriftfeld) Bottom Right -->
          <div class="self-end w-[440px] bg-[#0c1524] border-2 border-sky-400 text-sky-200 text-[10px] leading-tight font-mono shadow-lg">
            <div class="grid grid-cols-4 border-b border-sky-400/50">
              <div class="col-span-2 p-1.5 border-r border-sky-400/50">
                <div class="text-[8px] text-sky-400/60 uppercase">HERSTELLER / FIRMA</div>
                <div class="font-bold text-white text-xs">{{ part().manufacturer }}</div>
              </div>
              <div class="p-1.5 border-r border-sky-400/50">
                <div class="text-[8px] text-sky-400/60 uppercase">MASSSTAB</div>
                <div class="font-bold text-white">1 : 1 (METRISCH)</div>
              </div>
              <div class="p-1.5">
                <div class="text-[8px] text-sky-400/60 uppercase">GEWICHT</div>
                <div class="font-bold text-white">{{ part().massKg }} kg</div>
              </div>
            </div>

            <div class="grid grid-cols-4 border-b border-sky-400/50">
              <div class="col-span-3 p-1.5 border-r border-sky-400/50">
                <div class="text-[8px] text-sky-400/60 uppercase">BENENNUNG / BAUTEILBEZEICHNUNG</div>
                <div class="font-bold text-white text-xs truncate">{{ part().name }}</div>
              </div>
              <div class="p-1.5">
                <div class="text-[8px] text-sky-400/60 uppercase">REVISION</div>
                <div class="font-bold text-red-400 text-xs">{{ part().currentRevision }}</div>
              </div>
            </div>

            <div class="grid grid-cols-4 border-b border-sky-400/50">
              <div class="col-span-2 p-1.5 border-r border-sky-400/50">
                <div class="text-[8px] text-sky-400/60 uppercase">ZEICHNUNGS- / TEILENUMMER</div>
                <div class="font-bold text-sky-400 font-mono text-xs">{{ part().partNumber }}</div>
              </div>
              <div class="col-span-2 p-1.5">
                <div class="text-[8px] text-sky-400/60 uppercase">WERKSTOFF / NORM</div>
                <div class="font-bold text-white truncate">{{ part().material.name }}</div>
              </div>
            </div>

            <div class="grid grid-cols-3 p-1 text-[8px] text-sky-400/70">
              <div>GEZ: 2026-04-12 // M. Schultheiss</div>
              <div>GEPR: 2026-04-13 // K. Weiss</div>
              <div class="text-right">TOLERANZ: {{ part().toleranceClass }}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class TechnicalDrawingComponent {
  readonly partService = inject(PartTwinService);
  readonly part = computed(() => this.partService.activePart());

  readonly isBlueprint = signal<boolean>(true);
  readonly zoom = signal<number>(1.0);

  toggleTheme() {
    this.isBlueprint.update(v => !v);
  }

  zoomIn() {
    this.zoom.update(z => Math.min(2.0, +(z + 0.15).toFixed(2)));
  }

  zoomOut() {
    this.zoom.update(z => Math.max(0.5, +(z - 0.15).toFixed(2)));
  }

  resetZoom() {
    this.zoom.set(1.0);
  }

  getCos(deg: number): number {
    return Math.cos((deg * Math.PI) / 180);
  }

  getSin(deg: number): number {
    return Math.sin((deg * Math.PI) / 180);
  }
}
