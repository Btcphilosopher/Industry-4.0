import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PartTwinService } from '../../services/part-twin.service';

@Component({
  selector: 'app-inventory-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0f1218] border border-white/10 text-neutral-200 overflow-y-auto font-mono text-xs">
      <!-- Title Bar -->
      <div class="p-3 bg-[#141822] border-b border-white/10 flex flex-wrap items-center justify-between gap-2">
        <div class="flex items-center gap-2">
          <mat-icon class="text-red-500 !w-4 !h-4 !text-[16px]">warehouse</mat-icon>
          <span class="font-bold text-white tracking-wider">LAGER- & DISPOSITIONSMANAGEMENT // WAREHOUSE TWIN</span>
        </div>
        <div class="flex items-center gap-2">
          <span class="text-[10px] px-2 py-0.5 bg-sky-950 text-sky-400 border border-sky-800">
            LAGERSTANDORT: {{ part().warehouseLocation }}
          </span>
        </div>
      </div>

      <div class="p-4 space-y-6">
        <!-- Stock KPI Banner -->
        <div class="grid grid-cols-2 md:grid-cols-4 gap-2">
          <div class="bg-[#151a24] border border-white/10 p-3">
            <div class="text-[10px] text-neutral-400 uppercase">AKTUELLES LAGERBESTAND</div>
            <div class="text-lg font-bold text-white mt-1">{{ part().stockQuantity }} <span class="text-xs text-neutral-400 font-normal">Stück</span></div>
            <div class="text-[9px] text-neutral-500 mt-0.5">Mindestbestand: {{ part().minStockThreshold }} Stk.</div>
          </div>

          <div class="bg-[#151a24] border border-white/10 p-3">
            <div class="text-[10px] text-neutral-400 uppercase">LAGERWERT DIESES TEILS</div>
            <div class="text-lg font-bold text-emerald-400 mt-1">{{ (part().stockQuantity * part().unitCostEur).toLocaleString('de-DE', { minimumFractionDigits: 2 }) }} <span class="text-xs text-neutral-400 font-normal">€</span></div>
            <div class="text-[9px] text-neutral-500 mt-0.5">Einzelpreis: {{ part().unitCostEur.toFixed(2) }} €</div>
          </div>

          <div class="bg-[#151a24] border border-white/10 p-3">
            <div class="text-[10px] text-neutral-400 uppercase">BESTELLVORLAUFZEIT (LEAD TIME)</div>
            <div class="text-lg font-bold text-yellow-400 mt-1">{{ part().leadTimeDays }} <span class="text-xs text-neutral-400 font-normal">Tage</span></div>
            <div class="text-[9px] text-neutral-500 mt-0.5">Lieferant: {{ part().supplier }}</div>
          </div>

          <div class="bg-[#151a24] border border-white/10 p-3">
            <div class="text-[10px] text-neutral-400 uppercase">DISPOSITION-STATUS</div>
            <div class="text-sm font-bold mt-1"
              [class.text-emerald-400]="part().inventoryStatus === 'VERFÜGBAR'"
              [class.text-yellow-400]="part().inventoryStatus === 'REORDER_TRIGGER'"
              [class.text-red-500]="part().inventoryStatus === 'KRITISCH_GERING'">
              {{ part().inventoryStatus }}
            </div>
            <div class="text-[9px] text-neutral-500 mt-0.5">Automatische Nachbestellung aktiv</div>
          </div>
        </div>

        <!-- Interactive Stock Operations (Materialwirtschaft) -->
        <div class="bg-[#151a24] border border-white/10 p-4">
          <div class="text-[11px] font-bold text-neutral-300 uppercase mb-3 flex items-center gap-1.5">
            <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">swap_vert</mat-icon>
            MATERIALBUCHUNGEN // LAGERBEWEGUNGEN (SAP ERP INTEGRATION)
          </div>

          <div class="flex flex-wrap items-center gap-3">
            <button 
              (click)="adjustStock(-50)"
              class="px-3 py-2 bg-red-950/60 hover:bg-red-900 border border-red-800 text-red-300 text-xs flex items-center gap-1.5 transition-colors">
              <mat-icon class="text-xs !w-4 !h-4 !text-[16px]">remove_circle_outline</mat-icon>
              WARENAUSGANG FERTIGUNG (-50 STK)
            </button>
            <button 
              (click)="adjustStock(-10)"
              class="px-3 py-2 bg-red-950/60 hover:bg-red-900 border border-red-800 text-red-300 text-xs flex items-center gap-1.5 transition-colors">
              <mat-icon class="text-xs !w-4 !h-4 !text-[16px]">remove</mat-icon>
              ENTNAHME (-10 STK)
            </button>
            <button 
              (click)="adjustStock(100)"
              class="px-3 py-2 bg-emerald-950/60 hover:bg-emerald-900 border border-emerald-800 text-emerald-300 text-xs flex items-center gap-1.5 transition-colors">
              <mat-icon class="text-xs !w-4 !h-4 !text-[16px]">add</mat-icon>
              WARENEINGANG LIEFERANT (+100 STK)
            </button>
            <button 
              (click)="adjustStock(500)"
              class="px-3 py-2 bg-emerald-950/60 hover:bg-emerald-900 border border-emerald-800 text-emerald-300 text-xs flex items-center gap-1.5 transition-colors">
              <mat-icon class="text-xs !w-4 !h-4 !text-[16px]">add_circle_outline</mat-icon>
              GROSSBESTELLUNG EINLAGERN (+500 STK)
            </button>
          </div>
        </div>

        <!-- 2D High-Bay Warehouse Grid Layout (Hochregallager) -->
        <div class="bg-[#151a24] border border-white/10 p-4">
          <div class="text-[11px] font-bold text-neutral-300 uppercase mb-3 flex items-center justify-between">
            <span class="flex items-center gap-1.5">
              <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">grid_view</mat-icon>
              HOCHREGALLAGER BELEGUNGSPLAN (HALLE 4 - ZONE B)
            </span>
            <span class="text-[10px] text-emerald-400">FAHRWEG FTS-ROBOTER: FREI</span>
          </div>

          <div class="grid grid-cols-6 sm:grid-cols-8 md:grid-cols-12 gap-1.5 p-3 bg-[#0d1017] border border-white/10">
            @for (bin of warehouseBins; track bin.id) {
              <div 
                [class.border-red-500]="bin.id === 'B-14-02'"
                [class.bg-red-600/30]="bin.id === 'B-14-02'"
                [class.border-white/10]="bin.id !== 'B-14-02'"
                [class.bg-[#151a24]]="bin.id !== 'B-14-02' && bin.occupied"
                [class.bg-[#0a0c10]]="!bin.occupied"
                class="aspect-square border p-1 flex flex-col justify-between text-[8px] transition-all hover:border-white/40">
                <span class="font-bold text-neutral-400">{{ bin.id }}</span>
                @if (bin.id === 'B-14-02') {
                  <span class="text-red-400 font-bold leading-none">AKTIV</span>
                } @else if (bin.occupied) {
                  <span class="text-neutral-500 leading-none">BELEGT</span>
                } @else {
                  <span class="text-neutral-700 leading-none">FREI</span>
                }
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `
})
export class InventoryViewComponent {
  readonly partService = inject(PartTwinService);
  readonly part = computed(() => this.partService.activePart());

  readonly warehouseBins = Array.from({ length: 36 }, (_, i) => {
    const row = String.fromCharCode(65 + Math.floor(i / 12));
    const bay = String((i % 12) + 1).padStart(2, '0');
    const id = `${row}-${bay}-02`;
    return {
      id,
      occupied: i % 3 !== 0 || id === 'B-14-02'
    };
  });

  adjustStock(delta: number) {
    this.partService.adjustStock(this.part().id, delta);
  }
}
