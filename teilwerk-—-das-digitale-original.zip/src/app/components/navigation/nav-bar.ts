import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PartTwinService, MainNavTab } from '../../services/part-twin.service';

@Component({
  selector: 'app-nav-bar',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <nav class="bg-[#0e121a] border-b border-white/10 select-none overflow-x-auto no-scrollbar font-mono text-xs">
      <div class="flex items-center px-2 space-x-1 min-w-max">
        @for (item of navItems; track item.tab) {
          <button 
            (click)="partService.setMainTab(item.tab)"
            [class.bg-red-600]="activeTab() === item.tab"
            [class.text-white]="activeTab() === item.tab"
            [class.font-bold]="activeTab() === item.tab"
            [class.text-neutral-400]="activeTab() !== item.tab"
            [class.hover:text-neutral-200]="activeTab() !== item.tab"
            [class.hover:bg-white/5]="activeTab() !== item.tab"
            class="px-3 py-2.5 flex items-center gap-1.5 transition-colors border-b-2"
            [class.border-red-400]="activeTab() === item.tab"
            [class.border-transparent]="activeTab() !== item.tab">
            <mat-icon class="!w-4 !h-4 !text-[16px]">{{ item.icon }}</mat-icon>
            <span>{{ item.label }}</span>
            @if (item.badge) {
              <span 
                [class.bg-white/20]="activeTab() === item.tab"
                [class.bg-white/10]="activeTab() !== item.tab"
                [class.text-white]="activeTab() === item.tab"
                [class.text-neutral-300]="activeTab() !== item.tab"
                class="px-1.5 py-0.2 rounded-none text-[9px] font-mono">
                {{ item.badge() }}
              </span>
            }
          </button>
        }
      </div>
    </nav>
  `
})
export class NavBarComponent {
  readonly partService = inject(PartTwinService);
  readonly activeTab = computed(() => this.partService.activeMainTab());

  readonly navItems: { tab: MainNavTab; label: string; icon: string; badge?: () => string | number }[] = [
    {
      tab: 'DASHBOARD',
      label: 'ÜBERSICHT // TWIN COCKPIT',
      icon: 'dashboard'
    },
    {
      tab: 'PARTS',
      label: 'TEILEKATALOG',
      icon: 'layers',
      badge: () => this.partService.totalPartsCount()
    },
    {
      tab: 'ASSEMBLIES',
      label: 'BAUGRUPPEN (BOM)',
      icon: 'account_tree',
      badge: () => this.partService.assemblies().length
    },
    {
      tab: 'MACHINES',
      label: 'WERKZEUGMASCHINEN',
      icon: 'precision_manufacturing',
      badge: () => this.partService.machineTools().length
    },
    {
      tab: 'MANUFACTURING',
      label: 'FERTIGUNG & CNC',
      icon: 'settings_input_component'
    },
    {
      tab: 'QUALITY',
      label: 'QUALITÄT & SPC',
      icon: 'verified',
      badge: () => `${this.partService.avgQualityPassRate()}%`
    },
    {
      tab: 'SIMULATION',
      label: 'FEA & THERMOSIMULATION',
      icon: 'speed'
    },
    {
      tab: 'INVENTORY',
      label: 'LAGER & DISPOSITION',
      icon: 'warehouse'
    },
    {
      tab: 'SUPPLY_CHAIN',
      label: 'LIEFERKETTE',
      icon: 'local_shipping'
    },
    {
      tab: 'DOCUMENTS',
      label: 'PLM DOKUMENTE',
      icon: 'folder'
    },
    {
      tab: 'ANALYTICS',
      label: 'WERKSANALYTIK',
      icon: 'analytics'
    }
  ];
}
