import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PartTwinService } from '../../services/part-twin.service';

@Component({
  selector: 'app-quality-panel',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0f1218] border border-white/10 text-neutral-200 overflow-y-auto font-mono text-xs">
      <!-- Title Bar -->
      <div class="p-3 bg-[#141822] border-b border-white/10 flex flex-wrap items-center justify-between gap-2">
        <div class="flex items-center gap-2">
          <mat-icon class="text-red-500 !w-4 !h-4 !text-[16px]">verified</mat-icon>
          <span class="font-bold text-white tracking-wider">STATISTISCHE PROZESSKONTROLLE (SPC) & KMG-PRÜFPROTOKOLL</span>
        </div>
        <div class="flex items-center gap-2">
          <span class="text-[10px] px-2 py-0.5 bg-emerald-950 text-emerald-400 border border-emerald-800">
            PRÜFSTATUS: {{ part().inspectionStatus }}
          </span>
          <span class="text-[10px] px-2 py-0.5 bg-white/5 text-neutral-300 border border-white/10">
            MESSGERÄT: ZEISS PRISMO 3D-KMG
          </span>
        </div>
      </div>

      <div class="p-4 space-y-6">
        <!-- SPC Top Metrics Cards -->
        <div class="grid grid-cols-2 md:grid-cols-5 gap-2">
          <div class="bg-[#151a24] border border-white/10 p-3">
            <div class="text-[10px] text-neutral-400 uppercase">PROZESSPOTENZIAL (Cp)</div>
            <div class="text-lg font-bold text-emerald-400 mt-1">{{ part().spcData.cp }}</div>
            <div class="text-[9px] text-neutral-500 mt-0.5">Soll: &ge; 1.67 (Automotive)</div>
          </div>

          <div class="bg-[#151a24] border border-white/10 p-3">
            <div class="text-[10px] text-neutral-400 uppercase">PROZESSFÄHIGKEIT (Cpk)</div>
            <div class="text-lg font-bold text-emerald-400 mt-1">{{ part().spcData.cpk }}</div>
            <div class="text-[9px] text-neutral-500 mt-0.5">6-Sigma Qualitätsniveau</div>
          </div>

          <div class="bg-[#151a24] border border-white/10 p-3">
            <div class="text-[10px] text-neutral-400 uppercase">MITTELWERT (µ)</div>
            <div class="text-lg font-bold text-white mt-1">{{ part().spcData.mean }} <span class="text-xs font-normal text-neutral-400">mm</span></div>
            <div class="text-[9px] text-neutral-500 mt-0.5">Nennmaß: {{ part().spcData.target }} mm</div>
          </div>

          <div class="bg-[#151a24] border border-white/10 p-3">
            <div class="text-[10px] text-neutral-400 uppercase">STANDARDABWEICHUNG (σ)</div>
            <div class="text-lg font-bold text-sky-400 mt-1">{{ part().spcData.stdDev }} <span class="text-xs font-normal text-neutral-400">mm</span></div>
            <div class="text-[9px] text-neutral-500 mt-0.5">3σ = &plusmn;0.0036 mm</div>
          </div>

          <div class="bg-[#151a24] border border-white/10 p-3">
            <div class="text-[10px] text-neutral-400 uppercase">FEHLERRATE (PPM)</div>
            <div class="text-lg font-bold text-emerald-400 mt-1">{{ part().spcData.defectRatePpm }} <span class="text-xs font-normal text-neutral-400">ppm</span></div>
            <div class="text-[9px] text-neutral-500 mt-0.5">&lt; 1 Teil pro 1 Mio.</div>
          </div>
        </div>

        <!-- Gaussian Normal Distribution Curve (Histogram & SPC Graph) -->
        <div class="bg-[#151a24] border border-white/10 p-4">
          <div class="text-[11px] font-bold text-neutral-300 uppercase mb-3 flex items-center justify-between">
            <span class="flex items-center gap-1.5">
              <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">show_chart</mat-icon>
              GAUSS'SCHE NORMALVERTEILUNG (MESSREIHE N=500 STÜCK)
            </span>
            <span class="text-[10px] text-neutral-400">LSL: {{ part().spcData.lsl }} mm | USL: {{ part().spcData.usl }} mm</span>
          </div>

          <div class="w-full h-44 bg-[#0d1017] border border-white/10 relative p-2 flex items-center justify-center">
            <svg class="w-full h-full" viewBox="0 0 500 120" preserveAspectRatio="none">
              <!-- Tolerance Limit Lines (USL / LSL) -->
              <line x1="80" y1="0" x2="80" y2="110" stroke="#ef4444" stroke-width="1.5" stroke-dasharray="3 3" />
              <text x="85" y="20" fill="#ef4444" font-size="8" font-family="monospace">LSL ({{ part().spcData.lsl }} mm)</text>

              <line x1="420" y1="0" x2="420" y2="110" stroke="#ef4444" stroke-width="1.5" stroke-dasharray="3 3" />
              <text x="350" y="20" fill="#ef4444" font-size="8" font-family="monospace">USL ({{ part().spcData.usl }} mm)</text>

              <!-- Target Center Nominal -->
              <line x1="250" y1="0" x2="250" y2="110" stroke="#38bdf8" stroke-width="1" stroke-dasharray="2 2" />
              <text x="255" y="20" fill="#38bdf8" font-size="8" font-family="monospace" font-weight="bold">µ = {{ part().spcData.mean }} mm</text>

              <!-- Histogram bars -->
              <rect x="130" y="90" width="20" height="20" fill="#22c55e" opacity="0.3" />
              <rect x="160" y="70" width="20" height="40" fill="#22c55e" opacity="0.4" />
              <rect x="190" y="45" width="20" height="65" fill="#22c55e" opacity="0.6" />
              <rect x="220" y="25" width="20" height="85" fill="#22c55e" opacity="0.8" />
              <rect x="250" y="20" width="20" height="90" fill="#22c55e" opacity="0.9" />
              <rect x="280" y="30" width="20" height="80" fill="#22c55e" opacity="0.8" />
              <rect x="310" y="50" width="20" height="60" fill="#22c55e" opacity="0.6" />
              <rect x="340" y="75" width="20" height="35" fill="#22c55e" opacity="0.4" />
              <rect x="370" y="95" width="20" height="15" fill="#22c55e" opacity="0.3" />

              <!-- Smooth Gaussian Bell Curve -->
              <path d="M 50 110 Q 180 110 220 50 T 250 15 T 280 50 T 450 110" fill="none" stroke="#22c55e" stroke-width="2.5" />
            </svg>
          </div>
        </div>

        <!-- 3D CMM Inspection Points Table -->
        <div class="bg-[#151a24] border border-white/10 p-4">
          <div class="text-[11px] font-bold text-neutral-300 uppercase mb-3 flex items-center justify-between">
            <span class="flex items-center gap-1.5">
              <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">format_list_numbered</mat-icon>
              3D-KMG EINZELMESSSTELLEN & ABWEICHUNGEN (ZEISS PRISMO VAST XT)
            </span>
            <span class="text-[10px] text-emerald-400">100% IN TOLERANZ</span>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left text-[11px]">
              <thead class="bg-[#0d1017] text-neutral-400 uppercase text-[9px] border-b border-white/10">
                <tr>
                  <th class="p-2">Merkmal / Prüfort</th>
                  <th class="p-2">Sollmaß</th>
                  <th class="p-2">Istmaß</th>
                  <th class="p-2">Tol. (-)</th>
                  <th class="p-2">Tol. (+)</th>
                  <th class="p-2">Abweichung</th>
                  <th class="p-2">Status</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-white/5 font-mono">
                @for (point of part().cmmPoints; track point.id) {
                  <tr class="hover:bg-white/5">
                    <td class="p-2 font-bold text-white">{{ point.feature }}</td>
                    <td class="p-2 text-neutral-300">{{ point.nominal.toFixed(4) }} {{ point.unit }}</td>
                    <td class="p-2 text-sky-400">{{ point.actual.toFixed(4) }} {{ point.unit }}</td>
                    <td class="p-2 text-neutral-400">{{ point.toleranceLower }} {{ point.unit }}</td>
                    <td class="p-2 text-neutral-400">{{ point.toleranceUpper }} {{ point.unit }}</td>
                    <td class="p-2 font-bold" [class.text-emerald-400]="point.deviation >= 0" [class.text-sky-400]="point.deviation < 0">
                      {{ point.deviation > 0 ? '+' : '' }}{{ point.deviation.toFixed(4) }} {{ point.unit }}
                    </td>
                    <td class="p-2">
                      <span 
                        [class.bg-emerald-950]="point.status === 'PASS'"
                        [class.text-emerald-400]="point.status === 'PASS'"
                        [class.border-emerald-800]="point.status === 'PASS'"
                        [class.bg-yellow-950]="point.status === 'WARN'"
                        [class.text-yellow-400]="point.status === 'WARN'"
                        [class.border-yellow-800]="point.status === 'WARN'"
                        class="px-1.5 py-0.5 text-[9px] font-bold border">
                        {{ point.status }}
                      </span>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>

        <!-- 3.1 Inspection Certificate Footnote -->
        <div class="p-3 bg-[#11141c] border border-white/10 flex items-center justify-between text-[10px] text-neutral-400">
          <div class="flex items-center gap-2">
            <mat-icon class="text-red-500 !w-4 !h-4 !text-[16px]">description</mat-icon>
            <span>Prüfprotokoll nach DIN EN 10204 3.1 digital signiert von QMB Dr.-Ing. H. Lindemann</span>
          </div>
          <button class="px-2 py-1 bg-white/5 hover:bg-white/15 text-white border border-white/10 transition-colors">
            APZ 3.1 PDF herunterladen
          </button>
        </div>
      </div>
    </div>
  `
})
export class QualityPanelComponent {
  readonly partService = inject(PartTwinService);
  readonly part = computed(() => this.partService.activePart());
}
