import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PartTwinService } from '../../services/part-twin.service';

@Component({
  selector: 'app-manufacturing-route',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0f1218] border border-white/10 text-neutral-200 overflow-y-auto font-mono text-xs">
      <!-- Top Title Bar -->
      <div class="p-3 bg-[#141822] border-b border-white/10 flex items-center justify-between">
        <div class="flex items-center gap-2">
          <mat-icon class="text-red-500 !w-4 !h-4 !text-[16px]">precision_manufacturing</mat-icon>
          <span class="font-bold text-white tracking-wider">FERTIGUNGSZWILLING & ARBEITSPLAN // MES ROUTE</span>
        </div>
        <div class="flex items-center gap-2">
          <button 
            (click)="activeTab.set('ROUTE')"
            [class.bg-red-600]="activeTab() === 'ROUTE'"
            [class.text-white]="activeTab() === 'ROUTE'"
            [class.bg-white/5]="activeTab() !== 'ROUTE'"
            class="px-2.5 py-1 text-xs border border-white/10 transition-colors">
            ARBEITSPLAN (GRAPH)
          </button>
          <button 
            (click)="activeTab.set('CNC_SIM')"
            [class.bg-red-600]="activeTab() === 'CNC_SIM'"
            [class.text-white]="activeTab() === 'CNC_SIM'"
            [class.bg-white/5]="activeTab() !== 'CNC_SIM'"
            class="px-2.5 py-1 text-xs border border-white/10 transition-colors flex items-center gap-1">
            <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">settings_input_component</mat-icon>
            CNC-PROZESSSIMULATOR
          </button>
        </div>
      </div>

      <div class="p-4 space-y-6 flex-1">
        @if (activeTab() === 'ROUTE') {
          <!-- Process KPI Summary Bar -->
          <div class="grid grid-cols-2 md:grid-cols-4 gap-2">
            <div class="bg-[#151a24] border border-white/10 p-3">
              <div class="text-[10px] text-neutral-400 uppercase">GESAMT-DURCHLAUFZEIT</div>
              <div class="text-sm font-bold text-white mt-1">{{ totalCycleTimeSec() }} s <span class="text-xs text-neutral-400 font-normal">({{ (totalCycleTimeSec() / 60).toFixed(1) }} min)</span></div>
            </div>
            <div class="bg-[#151a24] border border-white/10 p-3">
              <div class="text-[10px] text-neutral-400 uppercase">ENERGIEVERBRAUCH PRO STÜCK</div>
              <div class="text-sm font-bold text-yellow-400 mt-1">{{ totalEnergyKwh() }} <span class="text-xs text-neutral-400 font-normal">kWh</span></div>
            </div>
            <div class="bg-[#151a24] border border-white/10 p-3">
              <div class="text-[10px] text-neutral-400 uppercase">AKKUMULIERTE AUSSCHUSSRATE</div>
              <div class="text-sm font-bold text-emerald-400 mt-1">{{ totalScrapRate() }} <span class="text-xs text-neutral-400 font-normal">%</span></div>
            </div>
            <div class="bg-[#151a24] border border-white/10 p-3">
              <div class="text-[10px] text-neutral-400 uppercase">PROZESS-AUTOMATISIERUNGSGRAD</div>
              <div class="text-sm font-bold text-sky-400 mt-1">94.8% <span class="text-xs text-neutral-400 font-normal">(CNC / Roboter)</span></div>
            </div>
          </div>

          <!-- Manufacturing Route Process Flow Timeline / Graph -->
          <div>
            <div class="text-[11px] font-bold text-neutral-300 uppercase mb-3 flex items-center gap-1.5">
              <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">account_tree</mat-icon>
              PROZESSABLAUFPLAN // DIGITALER ROUTENGRAPH (DIN EN ISO 9001)
            </div>

            <div class="space-y-3 relative before:absolute before:left-6 before:top-4 before:bottom-4 before:w-0.5 before:bg-white/10">
              @for (step of part().manufacturingRoute; track step.stepNumber) {
                <div class="relative pl-12 bg-[#151a24] border border-white/10 p-3 hover:border-red-500/40 transition-colors">
                  <!-- Step Number Badge Circle -->
                  <div class="absolute left-3 top-3 w-7 h-7 rounded-none bg-neutral-900 border border-red-500 flex items-center justify-center font-bold text-red-400 text-xs shadow">
                    {{ step.stepNumber }}
                  </div>

                  <div class="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-2 mb-2">
                    <div>
                      <div class="font-bold text-white text-xs">{{ step.name }}</div>
                      <div class="text-[10px] text-neutral-400">{{ step.facility }} // {{ step.machine }} (ID: {{ step.machineId }})</div>
                    </div>
                    <div class="flex items-center gap-2">
                      <span class="px-2 py-0.5 text-[9px] bg-sky-950 text-sky-400 border border-sky-800">
                        {{ step.operatorStatus }}
                      </span>
                      <span class="px-2 py-0.5 text-[9px] bg-emerald-950 text-emerald-400 border border-emerald-800">
                        STATUS: {{ step.status }} ({{ step.qualityResult }})
                      </span>
                    </div>
                  </div>

                  <!-- Step Technical Parameters -->
                  <div class="grid grid-cols-2 md:grid-cols-5 gap-2 text-[10px]">
                    <div>
                      <span class="text-neutral-500">Taktzeit:</span>
                      <div class="font-bold text-neutral-200">{{ step.cycleTimeSec }} s</div>
                    </div>
                    <div>
                      <span class="text-neutral-500">Werkzeug:</span>
                      <div class="font-bold text-neutral-200 truncate" [title]="step.tool">{{ step.tool }}</div>
                    </div>
                    <div>
                      <span class="text-neutral-500">Werkzeugverschleiß:</span>
                      <div class="font-bold text-yellow-400">VB {{ step.toolWearPercent }}%</div>
                    </div>
                    <div>
                      <span class="text-neutral-500">Prozesstemperatur:</span>
                      <div class="font-bold text-neutral-200">{{ step.temperatureC }} °C</div>
                    </div>
                    <div>
                      <span class="text-neutral-500">Energieeinsatz:</span>
                      <div class="font-bold text-neutral-200">{{ step.energyKWh }} kWh</div>
                    </div>
                  </div>
                </div>
              }
            </div>
          </div>
        } @else {
          <!-- INTERACTIVE CNC MACHINING SIMULATOR -->
          <div class="space-y-4">
            <div class="bg-[#151a24] border border-white/10 p-4">
              <div class="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-3 mb-4">
                <div>
                  <h3 class="text-sm font-bold text-white">INTERAKTIVER CNC-ZERSPANUNGSSIMULATOR (HARTDREHEN / WÄLZFRÄSEN)</h3>
                  <div class="text-[10px] text-neutral-400">Echtzeit-Berechnung von Schnittkraft, Zeitspanvolumen, Werkzeugstandzeit & Oberflächengüte</div>
                </div>
                <div class="text-[10px] px-2 py-1 bg-yellow-950 text-yellow-400 border border-yellow-800">
                  DEMO-MODELL: Kienzle-Schnittkraftberechnung & Taylor-Standzeit
                </div>
              </div>

              <!-- Simulator Controls Sliders Grid -->
              <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <!-- Spindle Speed Slider -->
                <div class="bg-[#0f1218] border border-white/10 p-3">
                  <div class="flex justify-between items-center mb-1">
                    <span class="text-[10px] text-neutral-400">SPINDELDREHZAHL (n)</span>
                    <span class="font-bold text-red-400">{{ spindleRpm() }} min⁻¹</span>
                  </div>
                  <input 
                    type="range" 
                    min="500" 
                    max="16000" 
                    step="100" 
                    [value]="spindleRpm()" 
                    (input)="onSpindleChange($event)"
                    class="w-full accent-red-600 cursor-pointer" />
                  <div class="flex justify-between text-[9px] text-neutral-500 mt-1">
                    <span>500 RPM</span>
                    <span>Schnittgeschw. v_c: {{ cuttingSpeedMMin() }} m/min</span>
                    <span>16.000 RPM</span>
                  </div>
                </div>

                <!-- Feed Rate Slider -->
                <div class="bg-[#0f1218] border border-white/10 p-3">
                  <div class="flex justify-between items-center mb-1">
                    <span class="text-[10px] text-neutral-400">VORSCHUBGESCHWINDIGKEIT (v_f)</span>
                    <span class="font-bold text-red-400">{{ feedRateMmRev() }} mm/U</span>
                  </div>
                  <input 
                    type="range" 
                    min="0.02" 
                    max="0.40" 
                    step="0.01" 
                    [value]="feedRateMmRev()" 
                    (input)="onFeedChange($event)"
                    class="w-full accent-red-600 cursor-pointer" />
                  <div class="flex justify-between text-[9px] text-neutral-500 mt-1">
                    <span>0.02 mm/U (Feinschlichten)</span>
                    <span>0.40 mm/U (Schruppen)</span>
                  </div>
                </div>

                <!-- Depth of Cut Slider -->
                <div class="bg-[#0f1218] border border-white/10 p-3">
                  <div class="flex justify-between items-center mb-1">
                    <span class="text-[10px] text-neutral-400">SCHNITT-TIEFE (a_p)</span>
                    <span class="font-bold text-red-400">{{ cutDepthMm() }} mm</span>
                  </div>
                  <input 
                    type="range" 
                    min="0.1" 
                    max="4.0" 
                    step="0.1" 
                    [value]="cutDepthMm()" 
                    (input)="onDepthChange($event)"
                    class="w-full accent-red-600 cursor-pointer" />
                  <div class="flex justify-between text-[9px] text-neutral-500 mt-1">
                    <span>0.1 mm</span>
                    <span>4.0 mm</span>
                  </div>
                </div>
              </div>

              <!-- Computed Real-Time Effects Dashboard -->
              <div class="grid grid-cols-2 md:grid-cols-4 gap-2 mt-4">
                <div class="bg-[#0f1218] border border-white/10 p-2.5">
                  <div class="text-[10px] text-neutral-400">BERECHNETE RAUHEIT (Ra)</div>
                  <div class="text-sm font-bold text-white mt-0.5" [class.text-red-400]="surfaceRoughnessRa() > 1.6" [class.text-emerald-400]="surfaceRoughnessRa() <= 0.8">
                    {{ surfaceRoughnessRa() }} µm
                  </div>
                  <div class="text-[9px] text-neutral-500">Soll-Grenze: Ra 0.80 µm</div>
                </div>

                <div class="bg-[#0f1218] border border-white/10 p-2.5">
                  <div class="text-[10px] text-neutral-400">ZEITSPANVOLUMEN (Q)</div>
                  <div class="text-sm font-bold text-sky-400 mt-0.5">{{ materialRemovalRate() }} cm³/min</div>
                  <div class="text-[9px] text-neutral-500">Spanvolumen / Zeit</div>
                </div>

                <div class="bg-[#0f1218] border border-white/10 p-2.5">
                  <div class="text-[10px] text-neutral-400">SPINDELLEISTUNG (P_e)</div>
                  <div class="text-sm font-bold text-yellow-400 mt-0.5">{{ requiredPowerKw() }} kW</div>
                  <div class="text-[9px] text-neutral-500">Hauptspindel-Auslastung</div>
                </div>

                <div class="bg-[#0f1218] border border-white/10 p-2.5">
                  <div class="text-[10px] text-neutral-400">WERKZEUG-STANDZEIT (T)</div>
                  <div class="text-sm font-bold text-white mt-0.5" [class.text-red-400]="toolLifeMinutes() < 30" [class.text-emerald-400]="toolLifeMinutes() >= 60">
                    {{ toolLifeMinutes() }} min
                  </div>
                  <div class="text-[9px] text-neutral-500">CBN-Wendeschneidplatte</div>
                </div>
              </div>
            </div>

            <!-- CNC Machine G-Code Block Preview -->
            <div class="bg-[#0d1017] border border-white/10 p-3 font-mono text-[11px] text-neutral-300">
              <div class="text-[9px] text-neutral-500 uppercase mb-1">GENERIERTER SIEMENS SINUMERIK 840D NC-SATZBLOCK</div>
              <div class="text-emerald-400">
                N100 G90 G95 G96 S{{ cuttingSpeedMMin() }} LIMS={{ spindleRpm() }} M03 M08<br/>
                N110 T="COROTURN_CBN_08" D1 M06<br/>
                N120 G00 X{{ (part().dimensionsMm.outerDiameter || 80) + 5 }} Z2.0<br/>
                N130 G01 X{{ part().dimensionsMm.outerDiameter || 80 }} F{{ feedRateMmRev() }}<br/>
                N140 G01 Z-{{ (part().dimensionsMm.width || 18) + 1 }} F{{ feedRateMmRev() }} (AP={{ cutDepthMm() }}mm)<br/>
                N150 G00 X{{ (part().dimensionsMm.outerDiameter || 80) + 10 }} Z50.0 M09
              </div>
            </div>
          </div>
        }
      </div>
    </div>
  `
})
export class ManufacturingRouteComponent {
  readonly partService = inject(PartTwinService);
  readonly part = computed(() => this.partService.activePart());

  readonly activeTab = signal<'ROUTE' | 'CNC_SIM'>('ROUTE');

  // Simulator Signals
  readonly spindleRpm = signal<number>(3400);
  readonly feedRateMmRev = signal<number>(0.08);
  readonly cutDepthMm = signal<number>(0.8);

  readonly totalCycleTimeSec = computed(() => {
    return this.part().manufacturingRoute.reduce((sum, s) => sum + s.cycleTimeSec, 0);
  });

  readonly totalEnergyKwh = computed(() => {
    return +(this.part().manufacturingRoute.reduce((sum, s) => sum + s.energyKWh, 0)).toFixed(2);
  });

  readonly totalScrapRate = computed(() => {
    return +(this.part().manufacturingRoute.reduce((sum, s) => sum + s.scrapRatePercent, 0)).toFixed(2);
  });

  // Physical formulas for CNC simulation
  readonly cuttingSpeedMMin = computed(() => {
    const d = this.part().dimensionsMm.outerDiameter || 80;
    return Math.round((Math.PI * d * this.spindleRpm()) / 1000);
  });

  readonly surfaceRoughnessRa = computed(() => {
    // Ra = (f^2) / (32 * r_epsilon) approximated
    const f = this.feedRateMmRev();
    const rEps = 0.8; // tool corner radius 0.8mm
    const theoreticalRa = ((f * f * 1000) / (32 * rEps)) * 1.6;
    return +theoreticalRa.toFixed(2);
  });

  readonly materialRemovalRate = computed(() => {
    const vc = this.cuttingSpeedMMin();
    const f = this.feedRateMmRev();
    const ap = this.cutDepthMm();
    const mrr = vc * f * ap;
    return +mrr.toFixed(1);
  });

  readonly requiredPowerKw = computed(() => {
    // P = (kc * Q) / 60000
    const kc = this.part().material.yieldStrength * 3.5; // Specific cutting force
    const mrr = this.materialRemovalRate();
    const power = (kc * mrr) / 60000;
    return +(Math.max(1.5, power * 1.8)).toFixed(2);
  });

  readonly toolLifeMinutes = computed(() => {
    // Taylor equation T = (C / v_c)^(1/k)
    const vc = this.cuttingSpeedMMin();
    const f = this.feedRateMmRev();
    const factor = Math.max(1, (vc * 0.4 + f * 400));
    const life = Math.round(18000 / factor);
    return Math.max(8, life);
  });

  onSpindleChange(event: Event) {
    const val = parseInt((event.target as HTMLInputElement).value, 10);
    this.spindleRpm.set(val);
  }

  onFeedChange(event: Event) {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.feedRateMmRev.set(val);
  }

  onDepthChange(event: Event) {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.cutDepthMm.set(val);
  }
}
