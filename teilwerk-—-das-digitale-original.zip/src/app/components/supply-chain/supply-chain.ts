import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PartTwinService } from '../../services/part-twin.service';

@Component({
  selector: 'app-supply-chain',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0f1218] border border-white/10 text-neutral-200 overflow-y-auto font-mono text-xs">
      <!-- Header -->
      <div class="p-3 bg-[#141822] border-b border-white/10 flex flex-wrap items-center justify-between gap-2">
        <div class="flex items-center gap-2">
          <mat-icon class="text-red-500 !w-4 !h-4 !text-[16px]">local_shipping</mat-icon>
          <span class="font-bold text-white tracking-wider">MULTI-TIER LIEFERKETTE & BESCHAFFUNG // SUPPLY NETWORK</span>
        </div>
        <div class="flex items-center gap-2">
          <span class="text-[10px] px-2 py-0.5 bg-emerald-950 text-emerald-400 border border-emerald-800">
            LIEFERANTENBEWERTUNG: A-LIEFERANT (99.2% ON-TIME)
          </span>
        </div>
      </div>

      <div class="p-4 space-y-6">
        <!-- Supply Chain Tier Architecture Visual Graph -->
        <div>
          <div class="text-[11px] font-bold text-neutral-300 uppercase mb-3 flex items-center gap-1.5">
            <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">hub</mat-icon>
            LIEFERKETTEN-KASKADE // TIER 3 &rarr; TIER 2 &rarr; TIER 1 &rarr; OEM
          </div>

          <div class="grid grid-cols-1 md:grid-cols-4 gap-3 relative">
            <!-- Tier 3: Raw Material -->
            <div class="bg-[#151a24] border border-white/10 p-3.5 flex flex-col justify-between">
              <div>
                <div class="flex items-center justify-between mb-2">
                  <span class="text-[9px] font-bold text-sky-400 px-1.5 py-0.2 bg-sky-950 border border-sky-800">TIER 3: ROHSTOFF</span>
                  <mat-icon class="text-neutral-500 !w-4 !h-4 !text-[16px]">terrain</mat-icon>
                </div>
                <h4 class="font-bold text-white">Saarstahl AG</h4>
                <div class="text-[10px] text-neutral-400">Völklingen, Deutschland</div>
                <div class="mt-2 text-[10px] text-neutral-300">
                  Schmelzcharge & Walzdraht 100Cr6 (Vakuum-entgast)
                </div>
              </div>
              <div class="mt-3 pt-2 border-t border-white/10 text-[9px] text-neutral-500">
                Vorlaufzeit: 14 Tage // CO₂: 1.4 kg/kg
              </div>
            </div>

            <!-- Tier 2: Forging / Blank -->
            <div class="bg-[#151a24] border border-white/10 p-3.5 flex flex-col justify-between">
              <div>
                <div class="flex items-center justify-between mb-2">
                  <span class="text-[9px] font-bold text-yellow-400 px-1.5 py-0.2 bg-yellow-950 border border-yellow-800">TIER 2: ROHLING</span>
                  <mat-icon class="text-neutral-500 !w-4 !h-4 !text-[16px]">hardware</mat-icon>
                </div>
                <h4 class="font-bold text-white">Thyssenkrupp Forging</h4>
                <div class="text-[10px] text-neutral-400">Homburg (Saar), Deutschland</div>
                <div class="mt-2 text-[10px] text-neutral-300">
                  Warmpräzisionsschmieden Ringrohling Ø 82mm
                </div>
              </div>
              <div class="mt-3 pt-2 border-t border-white/10 text-[9px] text-neutral-500">
                Vorlaufzeit: 8 Tage // Losgröße: 5.000 Stk.
              </div>
            </div>

            <!-- Tier 1: Precision Machining & Assembly -->
            <div class="bg-[#151a24] border-2 border-red-500/60 p-3.5 flex flex-col justify-between">
              <div>
                <div class="flex items-center justify-between mb-2">
                  <span class="text-[9px] font-bold text-red-400 px-1.5 py-0.2 bg-red-950 border border-red-800">TIER 1: TEILWERK</span>
                  <mat-icon class="text-red-400 !w-4 !h-4 !text-[16px]">factory</mat-icon>
                </div>
                <h4 class="font-bold text-white">TEILWERK Präzision Werk 1</h4>
                <div class="text-[10px] text-neutral-400">Pfronten / Allgäu, Deutschland</div>
                <div class="mt-2 text-[10px] text-neutral-300">
                  CNC-Hartdrehen, Superfinish, 100% CMM-Endkontrolle
                </div>
              </div>
              <div class="mt-3 pt-2 border-t border-white/10 text-[9px] text-emerald-400">
                Taktzeit: 260s // OEE: 91.2%
              </div>
            </div>

            <!-- OEM Integration -->
            <div class="bg-[#151a24] border border-white/10 p-3.5 flex flex-col justify-between">
              <div>
                <div class="flex items-center justify-between mb-2">
                  <span class="text-[9px] font-bold text-emerald-400 px-1.5 py-0.2 bg-emerald-950 border border-emerald-800">OEM KUNDE</span>
                  <mat-icon class="text-emerald-400 !w-4 !h-4 !text-[16px]">business</mat-icon>
                </div>
                <h4 class="font-bold text-white">Automotive OEM & Maschinenbau</h4>
                <div class="text-[10px] text-neutral-400">Sindelfingen / Pfronten</div>
                <div class="mt-2 text-[10px] text-neutral-300">
                  Just-in-Sequence (JIS) Montage in Radträger & Spindel
                </div>
              </div>
              <div class="mt-3 pt-2 border-t border-white/10 text-[9px] text-neutral-500">
                Sicherheitsbestand: 48h Produktion
              </div>
            </div>
          </div>
        </div>

        <!-- Procurement Lead Time & Vendor Risk Matrix -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div class="bg-[#151a24] border border-white/10 p-4">
            <div class="text-[11px] font-bold text-neutral-300 uppercase mb-3 flex items-center gap-1.5">
              <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">shield</mat-icon>
              RISIKOBEWERTUNG & DUAL-SOURCING
            </div>
            <div class="space-y-2 text-[10px]">
              <div class="flex justify-between p-2 bg-[#0f1218] border border-white/10">
                <span class="text-neutral-400">Geopolitisches Lieferrisiko:</span>
                <span class="text-emerald-400 font-bold">NIEDRIG (100% EU-Lieferkette)</span>
              </div>
              <div class="flex justify-between p-2 bg-[#0f1218] border border-white/10">
                <span class="text-neutral-400">Dual-Sourcing Absicherung:</span>
                <span class="text-sky-400 font-bold">Zweitwerk Schweinfurt qualifiziert</span>
              </div>
              <div class="flex justify-between p-2 bg-[#0f1218] border border-white/10">
                <span class="text-neutral-400">Transport-Emissionen (CO₂e):</span>
                <span class="text-white font-bold">0.08 kg CO₂e pro Teil (LKW Euro 6)</span>
              </div>
            </div>
          </div>

          <div class="bg-[#151a24] border border-white/10 p-4">
            <div class="text-[11px] font-bold text-neutral-300 uppercase mb-3 flex items-center gap-1.5">
              <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">request_quote</mat-icon>
              BESTELLKONDITIONEN & VERTRAGSDATEN
            </div>
            <div class="space-y-2 text-[10px]">
              <div class="flex justify-between p-2 bg-[#0f1218] border border-white/10">
                <span class="text-neutral-400">Rahmenvertragsnummer:</span>
                <span class="text-white font-mono">RV-2026-AUT-88412</span>
              </div>
              <div class="flex justify-between p-2 bg-[#0f1218] border border-white/10">
                <span class="text-neutral-400">Staffelpreis ab 1.000 Stk:</span>
                <span class="text-emerald-400 font-bold">{{ (part().unitCostEur * 0.88).toFixed(2) }} € (-12%)</span>
              </div>
              <div class="flex justify-between p-2 bg-[#0f1218] border border-white/10">
                <span class="text-neutral-400">Zahlungsziel:</span>
                <span class="text-white font-mono">30 Tage netto (VDA 4905 EDI)</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class SupplyChainComponent {
  readonly partService = inject(PartTwinService);
  readonly part = computed(() => this.partService.activePart());
}
