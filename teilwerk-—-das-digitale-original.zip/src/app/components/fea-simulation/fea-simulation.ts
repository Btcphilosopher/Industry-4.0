import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PartTwinService } from '../../services/part-twin.service';

@Component({
  selector: 'app-fea-simulation',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0f1218] border border-white/10 text-neutral-200 overflow-y-auto font-mono text-xs">
      <!-- Title Bar -->
      <div class="p-3 bg-[#141822] border-b border-white/10 flex flex-wrap items-center justify-between gap-2">
        <div class="flex items-center gap-2">
          <mat-icon class="text-red-500 !w-4 !h-4 !text-[16px]">speed</mat-icon>
          <span class="font-bold text-white tracking-wider">MULTI-PHYSIK SIMULATION // FEA-SPANNUNG & THERMODYNAMIK</span>
        </div>
        <div class="flex items-center gap-2">
          <span class="text-[10px] px-2 py-0.5 bg-sky-950 text-sky-400 border border-sky-800">
            SOLVER: HERTZIAN CONTACT & VON MISES FEA ENGINE
          </span>
        </div>
      </div>

      <div class="p-4 space-y-6">
        <!-- Simulation KPIs Banner -->
        <div class="grid grid-cols-2 md:grid-cols-4 gap-2">
          <div class="bg-[#151a24] border border-white/10 p-3">
            <div class="text-[10px] text-neutral-400 uppercase">MAX. VERGLEICHSSPANNUNG (σ_vM)</div>
            <div class="text-lg font-bold text-red-400 mt-1">{{ sim().vonMisesStressMaxMPa }} <span class="text-xs font-normal text-neutral-400">MPa</span></div>
            <div class="text-[9px] text-neutral-500 mt-0.5">Streckgrenze R_p0.2: {{ part().material.yieldStrength }} MPa</div>
          </div>

          <div class="bg-[#151a24] border border-white/10 p-3">
            <div class="text-[10px] text-neutral-400 uppercase">SICHERHEITSBEIWERT (S_F)</div>
            <div class="text-lg font-bold mt-1" [class.text-emerald-400]="sim().factorOfSafety >= 1.5" [class.text-yellow-400]="sim().factorOfSafety < 1.5 && sim().factorOfSafety >= 1.0" [class.text-red-500]="sim().factorOfSafety < 1.0">
              {{ sim().factorOfSafety }}
            </div>
            <div class="text-[9px] text-neutral-500 mt-0.5">Soll: &ge; 1.50 (DIN 743)</div>
          </div>

          <div class="bg-[#151a24] border border-white/10 p-3">
            <div class="text-[10px] text-neutral-400 uppercase">MAX. BETRIEBSTEMPERATUR</div>
            <div class="text-lg font-bold text-yellow-400 mt-1">{{ sim().operatingTempMaxC }} <span class="text-xs font-normal text-neutral-400">°C</span></div>
            <div class="text-[9px] text-neutral-500 mt-0.5">Zulässig: &le; {{ part().operatingTemperatureRange.maxC }} °C</div>
          </div>

          <div class="bg-[#151a24] border border-white/10 p-3">
            <div class="text-[10px] text-neutral-400 uppercase">RESTLEBENSDAUER (L10h)</div>
            <div class="text-lg font-bold text-sky-400 mt-1">{{ sim().remainingUsefulLifeHours.toLocaleString('de-DE') }} <span class="text-xs font-normal text-neutral-400">h</span></div>
            <div class="text-[9px] text-neutral-500 mt-0.5">Verschleißtiefe: {{ sim().wearDepthMicrons }} µm</div>
          </div>
        </div>

        <!-- Interactive Physics Input Sliders -->
        <div class="bg-[#151a24] border border-white/10 p-4">
          <div class="text-[11px] font-bold text-neutral-300 uppercase mb-4 flex items-center justify-between">
            <span class="flex items-center gap-1.5">
              <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">tune</mat-icon>
              LASTKOLLEKTIV & BETRIEBSPARAMETER STEUERUNG
            </span>
            <span class="text-[10px] text-neutral-400">ECHTZEIT-NEUBERECHNUNG AKTIV</span>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <!-- Parameter 1: Applied Load -->
            <div class="space-y-2">
              <div class="flex justify-between text-[11px]">
                <span class="text-neutral-400">Betriebslast F_rad (kN):</span>
                <span class="font-bold text-white">{{ params().appliedLoadKN }} kN</span>
              </div>
              <input 
                type="range" 
                min="1" 
                max="80" 
                step="1"
                [value]="params().appliedLoadKN" 
                (input)="onLoadChange($event)"
                class="w-full accent-red-500 cursor-pointer h-1.5 bg-neutral-800 rounded-none" />
              <div class="flex justify-between text-[9px] text-neutral-500">
                <span>1 kN</span>
                <span>Stat. Tragzahl C_0: {{ part().maxStaticLoadKN || 19 }} kN</span>
                <span>80 kN</span>
              </div>
            </div>

            <!-- Parameter 2: Operating RPM -->
            <div class="space-y-2">
              <div class="flex justify-between text-[11px]">
                <span class="text-neutral-400">Drehzahl n (RPM):</span>
                <span class="font-bold text-white">{{ params().operatingRpm }} RPM</span>
              </div>
              <input 
                type="range" 
                min="0" 
                max="18000" 
                step="500"
                [value]="params().operatingRpm" 
                (input)="onRpmChange($event)"
                class="w-full accent-red-500 cursor-pointer h-1.5 bg-neutral-800 rounded-none" />
              <div class="flex justify-between text-[9px] text-neutral-500">
                <span>0 RPM</span>
                <span>Grenzdrehzahl: {{ part().maxOperatingRpm || 14000 }} RPM</span>
                <span>18.000 RPM</span>
              </div>
            </div>

            <!-- Parameter 3: Ambient Temperature -->
            <div class="space-y-2">
              <div class="flex justify-between text-[11px]">
                <span class="text-neutral-400">Umgebungstemperatur T_amb (°C):</span>
                <span class="font-bold text-white">{{ params().ambientTempC }} °C</span>
              </div>
              <input 
                type="range" 
                min="-20" 
                max="140" 
                step="5"
                [value]="params().ambientTempC" 
                (input)="onTempChange($event)"
                class="w-full accent-red-500 cursor-pointer h-1.5 bg-neutral-800 rounded-none" />
              <div class="flex justify-between text-[9px] text-neutral-500">
                <span>-20 °C</span>
                <span>Max T: {{ part().operatingTemperatureRange.maxC }} °C</span>
                <span>140 °C</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Stress Distribution Map & Heat Gradient Display -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <!-- Hertzian Contact Stress Graph -->
          <div class="bg-[#151a24] border border-white/10 p-4">
            <div class="text-[11px] font-bold text-neutral-300 uppercase mb-3 flex items-center justify-between">
              <span class="flex items-center gap-1.5">
                <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">grain</mat-icon>
                HERTZ'SCHE PRESSUNG // DRUCKVERTEILUNG
              </span>
              <span class="text-[10px] text-red-400 font-bold">p_max: {{ sim().contactPressureMaxMPa }} MPa</span>
            </div>

            <div class="w-full h-32 bg-[#0d1017] border border-white/10 relative flex items-center justify-center p-2">
              <svg class="w-full h-full" viewBox="0 0 300 80">
                <!-- Elliptical pressure distribution -->
                <path d="M 20 70 Q 150 -10 280 70 Z" fill="url(#stressGradient)" stroke="#ef4444" stroke-width="1.5" />
                <defs>
                  <linearGradient id="stressGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stop-color="#ef4444" stop-opacity="0.8" />
                    <stop offset="50%" stop-color="#eab308" stop-opacity="0.5" />
                    <stop offset="100%" stop-color="#3b82f6" stop-opacity="0.2" />
                  </linearGradient>
                </defs>
                <text x="110" y="25" fill="#ffffff" font-size="8" font-family="monospace">p_0 = {{ sim().contactPressureMaxMPa }} MPa</text>
                <line x1="150" y1="30" x2="150" y2="70" stroke="#ffffff" stroke-width="1" stroke-dasharray="2 2" />
              </svg>
            </div>
          </div>

          <!-- Dynamic Wear and Vibration Telemetry -->
          <div class="bg-[#151a24] border border-white/10 p-4">
            <div class="text-[11px] font-bold text-neutral-300 uppercase mb-3 flex items-center justify-between">
              <span class="flex items-center gap-1.5">
                <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">graphic_eq</mat-icon>
                SCHWINGUNGSANALYSE & VERSCHLEISS
              </span>
              <span class="text-[10px] text-emerald-400 font-bold">RMS: {{ sim().vibrationRmsMmS }} mm/s</span>
            </div>

            <div class="w-full h-32 bg-[#0d1017] border border-white/10 relative p-3 flex flex-col justify-between">
              <div class="flex justify-between items-center text-[10px]">
                <span class="text-neutral-400">Kumulierte Lastzyklen:</span>
                <span class="font-bold text-white font-mono">{{ sim().accumulatedCycles.toExponential(2) }} Zyklen</span>
              </div>
              <div class="flex justify-between items-center text-[10px]">
                <span class="text-neutral-400">Ermüdungsschädigung D:</span>
                <span class="font-bold text-yellow-400 font-mono">{{ sim().fatigueDamagePercent }}%</span>
              </div>
              <div class="w-full bg-white/10 h-2">
                <div class="bg-yellow-500 h-full" [style.width.%]="sim().fatigueDamagePercent"></div>
              </div>
              <div class="flex justify-between items-center text-[9px] text-neutral-500">
                <span>0% Neuwertig</span>
                <span>100% Wöhler-Bruchgrenze</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class FeaSimulationComponent {
  readonly partService = inject(PartTwinService);
  readonly part = computed(() => this.partService.activePart());
  readonly params = computed(() => this.part().simulationParams);
  readonly sim = computed(() => this.part().simulationResult);

  onLoadChange(event: Event) {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.partService.updateActivePartSimulationParams({ appliedLoadKN: val });
  }

  onRpmChange(event: Event) {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.partService.updateActivePartSimulationParams({ operatingRpm: val });
  }

  onTempChange(event: Event) {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.partService.updateActivePartSimulationParams({ ambientTempC: val });
  }
}
