import { 
  ChangeDetectionStrategy, 
  Component, 
  ElementRef, 
  OnDestroy, 
  AfterViewInit, 
  ViewChild, 
  inject, 
  effect, 
  signal,
  computed,
  PLATFORM_ID
} from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import * as THREE from 'three';
import { PartTwin } from '../../models/part-twin.model';
import { PartTwinService } from '../../services/part-twin.service';

export type ViewMode = 'CAD' | 'STRESS' | 'THERMAL' | 'CMM_DEVIATION' | 'WIREFRAME' | 'XRAY';

@Component({
  selector: 'app-part-twin-viewer-3d',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-full min-h-[480px] bg-[#0d1017] border border-white/10 flex flex-col select-none overflow-hidden group">
      <!-- 3D Viewport Controls Top Bar -->
      <div class="absolute top-2 left-2 right-2 z-10 flex flex-wrap items-center justify-between gap-2 pointer-events-none">
        <!-- View Mode Selector -->
        <div class="flex items-center bg-[#131720]/90 backdrop-blur border border-white/10 p-1 pointer-events-auto shadow-md">
          <button 
            (click)="setViewMode('CAD')"
            [class.bg-red-600]="viewMode() === 'CAD'"
            [class.text-white]="viewMode() === 'CAD'"
            [class.text-neutral-400]="viewMode() !== 'CAD'"
            class="px-2.5 py-1 text-xs font-mono font-medium hover:text-white transition-colors flex items-center gap-1">
            <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">view_in_ar</mat-icon>
            CAD
          </button>
          <button 
            (click)="setViewMode('STRESS')"
            [class.bg-red-600]="viewMode() === 'STRESS'"
            [class.text-white]="viewMode() === 'STRESS'"
            [class.text-neutral-400]="viewMode() !== 'STRESS'"
            class="px-2.5 py-1 text-xs font-mono font-medium hover:text-white transition-colors flex items-center gap-1">
            <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">speed</mat-icon>
            FEA SPANNUNG
          </button>
          <button 
            (click)="setViewMode('THERMAL')"
            [class.bg-red-600]="viewMode() === 'THERMAL'"
            [class.text-white]="viewMode() === 'THERMAL'"
            [class.text-neutral-400]="viewMode() !== 'THERMAL'"
            class="px-2.5 py-1 text-xs font-mono font-medium hover:text-white transition-colors flex items-center gap-1">
            <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">thermostat</mat-icon>
            THERMISCH
          </button>
          <button 
            (click)="setViewMode('CMM_DEVIATION')"
            [class.bg-red-600]="viewMode() === 'CMM_DEVIATION'"
            [class.text-white]="viewMode() === 'CMM_DEVIATION'"
            [class.text-neutral-400]="viewMode() !== 'CMM_DEVIATION'"
            class="px-2.5 py-1 text-xs font-mono font-medium hover:text-white transition-colors flex items-center gap-1">
            <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">my_location</mat-icon>
            CMM ABWEICHUNG
          </button>
          <button 
            (click)="setViewMode('WIREFRAME')"
            [class.bg-red-600]="viewMode() === 'WIREFRAME'"
            [class.text-white]="viewMode() === 'WIREFRAME'"
            [class.text-neutral-400]="viewMode() !== 'WIREFRAME'"
            class="px-2.5 py-1 text-xs font-mono font-medium hover:text-white transition-colors flex items-center gap-1">
            <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">grid_4x4</mat-icon>
            DRAHTMODELL
          </button>
          <button 
            (click)="setViewMode('XRAY')"
            [class.bg-red-600]="viewMode() === 'XRAY'"
            [class.text-white]="viewMode() === 'XRAY'"
            [class.text-neutral-400]="viewMode() !== 'XRAY'"
            class="px-2.5 py-1 text-xs font-mono font-medium hover:text-white transition-colors flex items-center gap-1">
            <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">opacity</mat-icon>
            RÖNTGEN / X-RAY
          </button>
        </div>

        <!-- Tool Action Buttons -->
        <div class="flex items-center gap-1 bg-[#131720]/90 backdrop-blur border border-white/10 p-1 pointer-events-auto shadow-md">
          <button 
            (click)="toggleExplode()"
            [class.text-red-400]="isExploded()"
            [class.border-red-600]="isExploded()"
            title="Explosionsdarstellung"
            class="px-2 py-1 text-xs font-mono text-neutral-300 hover:text-white border border-transparent hover:border-white/20 flex items-center gap-1 transition-colors">
            <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">open_in_full</mat-icon>
            EXPLODE
          </button>
          <button 
            (click)="toggleSectionCut()"
            [class.text-red-400]="isSectionCut()"
            [class.border-red-600]="isSectionCut()"
            title="Schnittansicht (DIN Schnitt A-A)"
            class="px-2 py-1 text-xs font-mono text-neutral-300 hover:text-white border border-transparent hover:border-white/20 flex items-center gap-1 transition-colors">
            <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">content_cut</mat-icon>
            SCHNITT
          </button>
          <button 
            (click)="toggleAutoRotate()"
            [class.text-red-400]="autoRotate()"
            title="Automatische Drehung"
            class="px-2 py-1 text-xs font-mono text-neutral-300 hover:text-white border border-transparent hover:border-white/20 flex items-center gap-1 transition-colors">
            <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">360</mat-icon>
            ROTATION
          </button>
          <button 
            (click)="resetCameraView()"
            title="Kamera zurücksetzen (DIN ISO)"
            class="px-2 py-1 text-xs font-mono text-neutral-300 hover:text-white border border-transparent hover:border-white/20 flex items-center gap-1 transition-colors">
            <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">center_focus_strong</mat-icon>
            RESET
          </button>
        </div>
      </div>

      <!-- 3D Canvas Container -->
      <div #canvasContainer class="w-full h-full flex-1 cursor-grab active:cursor-grabbing relative"></div>

      <!-- Explode Slider Bar (when Explode active) -->
      @if (isExploded()) {
        <div class="absolute bottom-14 left-4 right-4 z-10 flex items-center justify-center pointer-events-none">
          <div class="bg-[#131720]/95 backdrop-blur border border-red-600/40 px-4 py-2 flex items-center gap-3 pointer-events-auto shadow-xl">
            <span class="text-xs font-mono text-neutral-300 font-medium">EXPLOSIONSWEG:</span>
            <input 
              type="range" 
              min="0" 
              max="1" 
              step="0.01" 
              [value]="explodeFactor()" 
              (input)="onExplodeChange($event)"
              class="w-48 accent-red-600 cursor-pointer" />
            <span class="text-xs font-mono text-red-400">{{ (explodeFactor() * 100).toFixed(0) }}%</span>
          </div>
        </div>
      }

      <!-- Color Scale Legend for FEA & Thermal Modes -->
      @if (viewMode() === 'STRESS') {
        <div class="absolute left-4 bottom-4 z-10 bg-[#131720]/90 backdrop-blur border border-white/10 p-2 pointer-events-auto">
          <div class="text-[10px] font-mono text-neutral-400 font-bold uppercase mb-1">von Mises Spannung [MPa]</div>
          <div class="flex items-center gap-2">
            <div class="h-28 w-4 rounded-none bg-gradient-to-t from-blue-600 via-green-500 via-yellow-400 to-red-600 border border-white/20"></div>
            <div class="h-28 flex flex-col justify-between text-[9px] font-mono text-neutral-300">
              <span class="text-red-400 font-bold">Max: {{ part().simulationResult.vonMisesStressMaxMPa }} MPa</span>
              <span>{{ (part().simulationResult.vonMisesStressMaxMPa * 0.75).toFixed(0) }} MPa</span>
              <span>{{ (part().simulationResult.vonMisesStressMaxMPa * 0.5).toFixed(0) }} MPa</span>
              <span>{{ (part().simulationResult.vonMisesStressMaxMPa * 0.25).toFixed(0) }} MPa</span>
              <span class="text-blue-400">0.0 MPa</span>
            </div>
          </div>
        </div>
      } @else if (viewMode() === 'THERMAL') {
        <div class="absolute left-4 bottom-4 z-10 bg-[#131720]/90 backdrop-blur border border-white/10 p-2 pointer-events-auto">
          <div class="text-[10px] font-mono text-neutral-400 font-bold uppercase mb-1">Temperaturfeld [°C]</div>
          <div class="flex items-center gap-2">
            <div class="h-28 w-4 rounded-none bg-gradient-to-t from-blue-700 via-yellow-500 to-red-600 border border-white/20"></div>
            <div class="h-28 flex flex-col justify-between text-[9px] font-mono text-neutral-300">
              <span class="text-red-400 font-bold">Max: {{ part().simulationResult.operatingTempMaxC }} °C</span>
              <span>{{ (part().simulationResult.operatingTempMaxC * 0.75).toFixed(1) }} °C</span>
              <span>{{ (part().simulationResult.operatingTempMaxC * 0.5).toFixed(1) }} °C</span>
              <span>{{ (part().simulationResult.operatingTempMaxC * 0.25).toFixed(1) }} °C</span>
              <span class="text-blue-400">Amb: {{ part().simulationParams.ambientTempC }} °C</span>
            </div>
          </div>
        </div>
      } @else if (viewMode() === 'CMM_DEVIATION') {
        <div class="absolute left-4 bottom-4 z-10 bg-[#131720]/90 backdrop-blur border border-white/10 p-2 pointer-events-auto">
          <div class="text-[10px] font-mono text-neutral-400 font-bold uppercase mb-1">CMM Abweichung [µm]</div>
          <div class="flex items-center gap-2">
            <div class="h-24 w-4 rounded-none bg-gradient-to-t from-red-600 via-emerald-500 to-red-600 border border-white/20"></div>
            <div class="h-24 flex flex-col justify-between text-[9px] font-mono text-neutral-300">
              <span class="text-red-400">+15 µm (USL)</span>
              <span class="text-emerald-400 font-bold">0.0 µm (SOLL)</span>
              <span class="text-red-400">-15 µm (LSL)</span>
            </div>
          </div>
        </div>
      }

      <!-- Bottom Info Overlay (DIN Metadata & Live Coordinates) -->
      <div class="absolute bottom-2 right-2 z-10 flex items-center gap-3 bg-[#131720]/90 backdrop-blur border border-white/10 px-3 py-1.5 pointer-events-none">
        <div class="text-right">
          <div class="text-[10px] font-mono text-neutral-400 uppercase">3D-ZWILLINGS-GEOMETRIE</div>
          <div class="text-xs font-mono font-bold text-white tracking-wider">{{ part().partNumber }} // {{ part().currentRevision }}</div>
        </div>
        <div class="h-6 w-px bg-white/20"></div>
        <div class="text-right text-[10px] font-mono text-neutral-400">
          <div>SCALE: 1:1 METRIC</div>
          <div class="text-red-400">FPS: 60 // WEBGL 2.0</div>
        </div>
      </div>

      <!-- Selected Component Tooltip -->
      @if (hoveredMeshName()) {
        <div class="absolute top-16 left-4 z-10 bg-black/90 border border-red-500 px-3 py-1.5 font-mono text-xs text-white shadow-lg pointer-events-none flex items-center gap-2">
          <span class="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
          <span>KOMPONENTE: <strong class="text-red-400">{{ hoveredMeshName() }}</strong></span>
        </div>
      }
    </div>
  `
})
export class PartTwinViewer3dComponent implements AfterViewInit, OnDestroy {
  @ViewChild('canvasContainer', { static: false }) containerRef!: ElementRef<HTMLDivElement>;

  readonly platformId = inject(PLATFORM_ID);
  readonly isBrowser = isPlatformBrowser(this.platformId);
  readonly partService = inject(PartTwinService);
  readonly part = computed(() => this.partService.activePart());

  readonly viewMode = signal<ViewMode>('CAD');
  readonly isExploded = signal<boolean>(false);
  readonly explodeFactor = signal<number>(0.5);
  readonly isSectionCut = signal<boolean>(false);
  readonly autoRotate = signal<boolean>(false);
  readonly hoveredMeshName = signal<string | null>(null);

  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private currentModelGroup!: THREE.Group;
  private animFrameId: number | null = null;
  private raycaster = new THREE.Raycaster();
  private mouse = new THREE.Vector2();

  // Mouse Orbit Controls
  private isMouseDown = false;
  private mousePrevX = 0;
  private mousePrevY = 0;
  private targetRotationX = 0.4;
  private targetRotationY = 0.6;
  private targetDistance = 140;
  private currentDistance = 140;

  // Clipping Plane for Section Cut
  private clippingPlane = new THREE.Plane(new THREE.Vector3(0, 0, -1), 0);

  constructor() {
    // Effect to rebuild 3D model when active part changes
    effect(() => {
      const p = this.part();
      if (this.isBrowser && this.scene) {
        this.rebuildPartGeometry(p);
      }
    });

    // Effect to re-render materials when view mode changes
    effect(() => {
      const mode = this.viewMode();
      if (this.isBrowser && this.currentModelGroup) {
        this.updateModelMaterials(mode);
      }
    });
  }

  ngAfterViewInit() {
    if (this.isBrowser && this.containerRef?.nativeElement) {
      this.initThree();
      this.setupEventListeners();
      this.rebuildPartGeometry(this.part());
      this.animate();
    }
  }

  ngOnDestroy() {
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
    if (this.isBrowser) {
      this.removeEventListeners();
    }
  }

  setViewMode(mode: ViewMode) {
    this.viewMode.set(mode);
  }

  toggleExplode() {
    this.isExploded.update(v => !v);
    this.applyExplosion();
  }

  onExplodeChange(event: Event) {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.explodeFactor.set(val);
    this.applyExplosion();
  }

  toggleSectionCut() {
    this.isSectionCut.update(v => !v);
    if (this.renderer) {
      this.renderer.clippingPlanes = this.isSectionCut() ? [this.clippingPlane] : [];
    }
  }

  toggleAutoRotate() {
    this.autoRotate.update(v => !v);
  }

  resetCameraView() {
    this.targetRotationX = 0.4;
    this.targetRotationY = 0.6;
    this.targetDistance = 140;
    this.currentDistance = 140;
    this.explodeFactor.set(0);
    this.isExploded.set(false);
    this.applyExplosion();
  }

  private initThree() {
    const container = this.containerRef.nativeElement;
    const width = container.clientWidth || 600;
    const height = container.clientHeight || 450;

    // Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0c0f16);

    // Camera
    this.camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 2000);
    this.camera.position.set(0, 0, this.currentDistance);

    // Renderer
    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.localClippingEnabled = true;
    container.appendChild(this.renderer.domElement);

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
    this.scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xffffff, 1.4);
    keyLight.position.set(100, 150, 100);
    keyLight.castShadow = true;
    this.scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0x90a4ae, 0.8);
    fillLight.position.set(-100, -50, -80);
    this.scene.add(fillLight);

    const rimLight = new THREE.DirectionalLight(0xef4444, 0.4);
    rimLight.position.set(0, 100, -100);
    this.scene.add(rimLight);

    // Technical Coordinate Grid (DIN Ground Grid)
    const gridHelper = new THREE.GridHelper(200, 20, 0xdc2626, 0x222938);
    gridHelper.position.y = -40;
    this.scene.add(gridHelper);

    // Model Group
    this.currentModelGroup = new THREE.Group();
    this.scene.add(this.currentModelGroup);
  }

  private rebuildPartGeometry(part: PartTwin) {
    // Clear old children
    while (this.currentModelGroup.children.length > 0) {
      const child = this.currentModelGroup.children[0] as THREE.Mesh;
      this.currentModelGroup.remove(child);
      if (child.geometry) child.geometry.dispose();
      if (Array.isArray(child.material)) {
        child.material.forEach(m => m.dispose());
      } else if (child.material) {
        child.material.dispose();
      }
    }

    const type = part.geometryType || 'GENERIC_MECHANICAL';

    if (type === 'BEARING_6208') {
      this.createBearingGeometry();
    } else if (type === 'BRAKE_DISC_VENTED') {
      this.createBrakeDiscGeometry();
    } else if (type === 'HELICAL_GEAR_Z48') {
      this.createHelicalGearGeometry();
    } else if (type === 'CONNECTING_ROD') {
      this.createConnectingRodGeometry();
    } else if (type === 'HYDRAULIC_VALVE') {
      this.createHydraulicValveGeometry();
    } else if (type === 'ELECTRIC_MOTOR') {
      this.createElectricMotorGeometry();
    } else if (type === 'DRIVE_SHAFT') {
      this.createDriveShaftGeometry();
    } else {
      this.createGenericPartGeometry(part);
    }

    this.updateModelMaterials(this.viewMode());
    this.applyExplosion();
  }

  // 1. Procedural 6208 Deep Groove Ball Bearing
  private createBearingGeometry() {
    // Outer Ring
    const outerRadius = 40;
    const outerInnerRadius = 32;
    const ringWidth = 18;

    const outerShape = new THREE.Shape();
    outerShape.absarc(0, 0, outerRadius, 0, Math.PI * 2, false);
    const outerHole = new THREE.Path();
    outerHole.absarc(0, 0, outerInnerRadius, 0, Math.PI * 2, true);
    outerShape.holes.push(outerHole);

    const outerExtrudeSettings = { depth: ringWidth, bevelEnabled: true, bevelSegments: 3, steps: 1, bevelSize: 0.8, bevelThickness: 0.8 };
    const outerGeom = new THREE.ExtrudeGeometry(outerShape, outerExtrudeSettings);
    outerGeom.center();
    const outerMesh = new THREE.Mesh(outerGeom);
    outerMesh.name = 'Außenring 100Cr6 (D=80mm)';
    outerMesh.userData = { explodeOffset: new THREE.Vector3(0, 0, 25), baseZ: 0 };
    this.currentModelGroup.add(outerMesh);

    // Inner Ring
    const innerRadius = 28;
    const boreRadius = 20;
    const innerShape = new THREE.Shape();
    innerShape.absarc(0, 0, innerRadius, 0, Math.PI * 2, false);
    const innerHole = new THREE.Path();
    innerHole.absarc(0, 0, boreRadius, 0, Math.PI * 2, true);
    innerShape.holes.push(innerHole);

    const innerGeom = new THREE.ExtrudeGeometry(innerShape, outerExtrudeSettings);
    innerGeom.center();
    const innerMesh = new THREE.Mesh(innerGeom);
    innerMesh.name = 'Innenring 100Cr6 (d=40mm)';
    innerMesh.userData = { explodeOffset: new THREE.Vector3(0, 0, -25), baseZ: 0 };
    this.currentModelGroup.add(innerMesh);

    // Balls & Cage
    const ballPitchRadius = (outerInnerRadius + innerRadius) / 2; // 30mm
    const ballRadius = 5.95;
    const ballCount = 9;

    const ballGeom = new THREE.SphereGeometry(ballRadius, 24, 24);

    for (let i = 0; i < ballCount; i++) {
      const angle = (i / ballCount) * Math.PI * 2;
      const x = Math.cos(angle) * ballPitchRadius;
      const y = Math.sin(angle) * ballPitchRadius;
      const ballMesh = new THREE.Mesh(ballGeom);
      ballMesh.position.set(x, y, 0);
      ballMesh.name = `Präzisions-Kugel #${i + 1} (Ø 11.9mm)`;
      ballMesh.userData = { 
        explodeOffset: new THREE.Vector3(Math.cos(angle) * 15, Math.sin(angle) * 15, 0),
        baseX: x,
        baseY: y,
        baseZ: 0
      };
      this.currentModelGroup.add(ballMesh);
    }

    // Retainer / Cage
    const cageTorus = new THREE.TorusGeometry(ballPitchRadius, 2.2, 16, 48);
    const cageMesh = new THREE.Mesh(cageTorus);
    cageMesh.name = 'Stahlblech-Lagerkäfig DIN 625';
    cageMesh.userData = { explodeOffset: new THREE.Vector3(0, 0, 0), baseZ: 0 };
    this.currentModelGroup.add(cageMesh);
  }

  // 2. Procedural Ventilated Brake Disc
  private createBrakeDiscGeometry() {
    const discRadius = 55;
    const centerRadius = 22;
    const discThickness = 12;

    // Disc Rotor (Outer)
    const rotorShape = new THREE.Shape();
    rotorShape.absarc(0, 0, discRadius, 0, Math.PI * 2, false);
    const rotorHole = new THREE.Path();
    rotorHole.absarc(0, 0, 32, 0, Math.PI * 2, true);
    rotorShape.holes.push(rotorHole);

    const rotorGeom = new THREE.ExtrudeGeometry(rotorShape, { depth: discThickness, bevelEnabled: true, bevelSize: 0.5, bevelThickness: 0.5 });
    rotorGeom.center();
    const rotorMesh = new THREE.Mesh(rotorGeom);
    rotorMesh.name = 'Reibring EN-GJL-250 (Ø 340mm)';
    rotorMesh.userData = { explodeOffset: new THREE.Vector3(0, 0, 20), baseZ: 0 };
    this.currentModelGroup.add(rotorMesh);

    // Center Bell / Topf
    const bellGeom = new THREE.CylinderGeometry(centerRadius, 28, 18, 36);
    bellGeom.rotateX(Math.PI / 2);
    const bellMesh = new THREE.Mesh(bellGeom);
    bellMesh.position.z = -12;
    bellMesh.name = 'Aluminium-Topf EN AW-7075 (5-Loch 112mm)';
    bellMesh.userData = { explodeOffset: new THREE.Vector3(0, 0, -35), baseZ: -12 };
    this.currentModelGroup.add(bellMesh);

    // Internal Vane Fins (16 internal cooling vanes)
    for (let i = 0; i < 16; i++) {
      const angle = (i / 16) * Math.PI * 2;
      const vaneGeom = new THREE.BoxGeometry(2, 18, 8);
      const vaneMesh = new THREE.Mesh(vaneGeom);
      vaneMesh.position.set(Math.cos(angle) * 42, Math.sin(angle) * 42, 0);
      vaneMesh.rotation.z = angle + 0.5; // Curved vane
      vaneMesh.name = `Kühlschaufel #${i + 1}`;
      vaneMesh.userData = { explodeOffset: new THREE.Vector3(Math.cos(angle) * 10, Math.sin(angle) * 10, 0), baseZ: 0 };
      this.currentModelGroup.add(vaneMesh);
    }
  }

  // 3. Procedural Helical Gear Z=48
  private createHelicalGearGeometry() {
    const rootRadius = 38;
    const teethCount = 32; // visually dense
    const gearWidth = 24;

    const gearShape = new THREE.Shape();
    gearShape.absarc(0, 0, rootRadius, 0, Math.PI * 2, false);
    const boreHole = new THREE.Path();
    boreHole.absarc(0, 0, 16, 0, Math.PI * 2, true);
    gearShape.holes.push(boreHole);

    const gearGeom = new THREE.ExtrudeGeometry(gearShape, { depth: gearWidth, bevelEnabled: true, bevelSize: 0.5, bevelThickness: 0.5 });
    gearGeom.center();
    const gearBody = new THREE.Mesh(gearGeom);
    gearBody.name = 'Zahnradgrundkörper 16MnCr5 (d=120mm)';
    gearBody.userData = { explodeOffset: new THREE.Vector3(0, 0, 0), baseZ: 0 };
    this.currentModelGroup.add(gearBody);

    // Helical Teeth
    for (let i = 0; i < teethCount; i++) {
      const angle = (i / teethCount) * Math.PI * 2;
      const toothGeom = new THREE.BoxGeometry(3.5, 8, gearWidth);
      const toothMesh = new THREE.Mesh(toothGeom);
      toothMesh.position.set(Math.cos(angle) * (rootRadius + 3), Math.sin(angle) * (rootRadius + 3), 0);
      toothMesh.rotation.z = angle;
      toothMesh.rotation.x = 0.25; // 17.5° helix angle
      toothMesh.name = `Schrägzahn #${i + 1} (DIN 3962 Q5)`;
      toothMesh.userData = { explodeOffset: new THREE.Vector3(Math.cos(angle) * 12, Math.sin(angle) * 12, 0), baseZ: 0 };
      this.currentModelGroup.add(toothMesh);
    }
  }

  // 4. Connecting Rod
  private createConnectingRodGeometry() {
    // Big End
    const bigEndGeom = new THREE.CylinderGeometry(20, 20, 16, 32);
    bigEndGeom.rotateX(Math.PI / 2);
    const bigEndMesh = new THREE.Mesh(bigEndGeom);
    bigEndMesh.position.y = -35;
    bigEndMesh.name = 'Pleuelfuß (Kurbelwellenzapfen Ø 48mm)';
    bigEndMesh.userData = { explodeOffset: new THREE.Vector3(0, -20, 0), baseZ: 0 };
    this.currentModelGroup.add(bigEndMesh);

    // Small End
    const smallEndGeom = new THREE.CylinderGeometry(12, 12, 14, 32);
    smallEndGeom.rotateX(Math.PI / 2);
    const smallEndMesh = new THREE.Mesh(smallEndGeom);
    smallEndMesh.position.y = 35;
    smallEndMesh.name = 'Pleuelauge (Kolbenbolzen Ø 22mm)';
    smallEndMesh.userData = { explodeOffset: new THREE.Vector3(0, 20, 0), baseZ: 0 };
    this.currentModelGroup.add(smallEndMesh);

    // I-Beam Shank
    const shankGeom = new THREE.BoxGeometry(10, 55, 12);
    const shankMesh = new THREE.Mesh(shankGeom);
    shankMesh.position.y = 0;
    shankMesh.name = 'H-Schaft Doppel-T-Träger 42CrMo4';
    shankMesh.userData = { explodeOffset: new THREE.Vector3(0, 0, 0), baseZ: 0 };
    this.currentModelGroup.add(shankMesh);
  }

  // 5. Hydraulic Spool Valve
  private createHydraulicValveGeometry() {
    const blockGeom = new THREE.BoxGeometry(45, 60, 35);
    const blockMesh = new THREE.Mesh(blockGeom);
    blockMesh.name = 'Ventilblockgehäuse 1.4404 Edelstahl (315 bar)';
    blockMesh.userData = { explodeOffset: new THREE.Vector3(0, 0, 0), baseZ: 0 };
    this.currentModelGroup.add(blockMesh);

    // Spool Cylinder
    const spoolGeom = new THREE.CylinderGeometry(8, 8, 75, 24);
    const spoolMesh = new THREE.Mesh(spoolGeom);
    spoolMesh.position.set(0, 0, 0);
    spoolMesh.name = 'Steuerschieber 100Cr6 feinläppt';
    spoolMesh.userData = { explodeOffset: new THREE.Vector3(0, 35, 0), baseZ: 0 };
    this.currentModelGroup.add(spoolMesh);
  }

  // 6. Electric Motor
  private createElectricMotorGeometry() {
    const statorGeom = new THREE.CylinderGeometry(30, 30, 60, 32);
    statorGeom.rotateX(Math.PI / 2);
    const statorMesh = new THREE.Mesh(statorGeom);
    statorMesh.name = 'Statorblechpaket M270-35A mit Wasserkühlung';
    statorMesh.userData = { explodeOffset: new THREE.Vector3(0, 0, 0), baseZ: 0 };
    this.currentModelGroup.add(statorMesh);

    const shaftGeom = new THREE.CylinderGeometry(8, 8, 95, 24);
    shaftGeom.rotateX(Math.PI / 2);
    const shaftMesh = new THREE.Mesh(shaftGeom);
    shaftMesh.name = 'Rotorwelle 42CrMo4 mit NdFeB-Magnetmatrix';
    shaftMesh.userData = { explodeOffset: new THREE.Vector3(0, 0, 40), baseZ: 0 };
    this.currentModelGroup.add(shaftMesh);
  }

  // 7. Stepped Drive Shaft
  private createDriveShaftGeometry() {
    const shaftPart1 = new THREE.CylinderGeometry(14, 14, 30, 24);
    shaftPart1.rotateX(Math.PI / 2);
    const mesh1 = new THREE.Mesh(shaftPart1);
    mesh1.position.z = -35;
    mesh1.name = 'Passfedersitz Ø 28mm DIN 6885';
    mesh1.userData = { explodeOffset: new THREE.Vector3(0, 0, -25), baseZ: -35 };
    this.currentModelGroup.add(mesh1);

    const shaftPart2 = new THREE.CylinderGeometry(20, 20, 40, 24);
    shaftPart2.rotateX(Math.PI / 2);
    const mesh2 = new THREE.Mesh(shaftPart2);
    mesh2.position.z = 0;
    mesh2.name = 'Hauptlagersitz Ø 40mm k5 42CrMo4';
    mesh2.userData = { explodeOffset: new THREE.Vector3(0, 0, 0), baseZ: 0 };
    this.currentModelGroup.add(mesh2);

    const shaftPart3 = new THREE.CylinderGeometry(16, 16, 30, 24);
    shaftPart3.rotateX(Math.PI / 2);
    const mesh3 = new THREE.Mesh(shaftPart3);
    mesh3.position.z = 35;
    mesh3.name = 'Keilwellenprofil DIN ISO 14';
    mesh3.userData = { explodeOffset: new THREE.Vector3(0, 0, 25), baseZ: 35 };
    this.currentModelGroup.add(mesh3);
  }

  // 8. Generic Mechanical
  private createGenericPartGeometry(part: PartTwin) {
    const geom = new THREE.CylinderGeometry(25, 25, 45, 32);
    geom.rotateX(Math.PI / 2);
    const mesh = new THREE.Mesh(geom);
    mesh.name = `${part.name} (${part.material.name})`;
    mesh.userData = { explodeOffset: new THREE.Vector3(0, 0, 0), baseZ: 0 };
    this.currentModelGroup.add(mesh);
  }

  // Update materials based on viewMode
  private updateModelMaterials(mode: ViewMode) {
    const part = this.part();
    const sim = part.simulationResult;

    this.currentModelGroup.traverse((child) => {
      if (child instanceof THREE.Mesh) {
        if (mode === 'CAD') {
          // Photorealistic brushed metallic CAD material
          child.material = new THREE.MeshStandardMaterial({
            color: 0xc4c9d4,
            metalness: 0.88,
            roughness: 0.28,
            envMapIntensity: 1.2
          });
        } else if (mode === 'STRESS') {
          // FEA Von Mises Stress Heatmap Shader Simulation
          const stressRatio = sim.yieldStrengthRatio;
          const stressColor = new THREE.Color();
          if (stressRatio < 0.4) {
            stressColor.setRGB(0.1, 0.4, 0.9); // Safe blue
          } else if (stressRatio < 0.75) {
            stressColor.setRGB(0.2, 0.85, 0.3); // Safe green/yellow
          } else if (stressRatio < 0.95) {
            stressColor.setRGB(0.95, 0.75, 0.1); // High warning yellow
          } else {
            stressColor.setRGB(0.95, 0.15, 0.15); // Critical red
          }
          child.material = new THREE.MeshStandardMaterial({
            color: stressColor,
            roughness: 0.4,
            metalness: 0.3
          });
        } else if (mode === 'THERMAL') {
          // Thermal Gradient Simulation
          const temp = sim.operatingTempMaxC;
          const thermalColor = new THREE.Color();
          if (temp < 40) {
            thermalColor.setRGB(0.2, 0.5, 0.9);
          } else if (temp < 85) {
            thermalColor.setRGB(0.9, 0.6, 0.1);
          } else {
            thermalColor.setRGB(0.95, 0.2, 0.1);
          }
          child.material = new THREE.MeshStandardMaterial({
            color: thermalColor,
            emissive: thermalColor.clone().multiplyScalar(0.25),
            roughness: 0.5
          });
        } else if (mode === 'CMM_DEVIATION') {
          // CMM Quality In-Tolerance (Green / Amber)
          const pass = part.inspectionStatus === 'PASS';
          child.material = new THREE.MeshStandardMaterial({
            color: pass ? 0x10b981 : 0xf59e0b,
            roughness: 0.3,
            metalness: 0.5
          });
        } else if (mode === 'WIREFRAME') {
          child.material = new THREE.MeshBasicMaterial({
            color: 0xdc2626,
            wireframe: true
          });
        } else if (mode === 'XRAY') {
          child.material = new THREE.MeshPhysicalMaterial({
            color: 0x38bdf8,
            transparent: true,
            opacity: 0.35,
            roughness: 0.1,
            metalness: 0.1,
            transmission: 0.85,
            ior: 1.5
          });
        }
      }
    });
  }

  private applyExplosion() {
    const factor = this.isExploded() ? this.explodeFactor() : 0;
    this.currentModelGroup.children.forEach((child) => {
      const offset = child.userData['explodeOffset'] as THREE.Vector3 | undefined;
      const baseZ = (child.userData['baseZ'] as number) || 0;
      const baseX = (child.userData['baseX'] as number) || 0;
      const baseY = (child.userData['baseY'] as number) || 0;

      if (offset) {
        child.position.x = baseX + offset.x * factor;
        child.position.y = baseY + offset.y * factor;
        child.position.z = baseZ + offset.z * factor;
      }
    });
  }

  private animate = () => {
    this.animFrameId = requestAnimationFrame(this.animate);

    // Auto rotate if active
    if (this.autoRotate()) {
      this.targetRotationY += 0.008;
    }

    // Smooth Orbit Damping
    if (this.currentModelGroup) {
      this.currentModelGroup.rotation.x += (this.targetRotationX - this.currentModelGroup.rotation.x) * 0.1;
      this.currentModelGroup.rotation.y += (this.targetRotationY - this.currentModelGroup.rotation.y) * 0.1;
    }

    this.currentDistance += (this.targetDistance - this.currentDistance) * 0.1;
    this.camera.position.z = this.currentDistance;

    this.renderer.render(this.scene, this.camera);
  };

  private setupEventListeners() {
    const el = this.containerRef.nativeElement;

    el.addEventListener('mousedown', this.onMouseDown);
    window.addEventListener('mousemove', this.onMouseMove);
    window.addEventListener('mouseup', this.onMouseUp);
    el.addEventListener('wheel', this.onWheel, { passive: false });
    window.addEventListener('resize', this.onWindowResize);
  }

  private removeEventListeners() {
    const el = this.containerRef.nativeElement;
    el.removeEventListener('mousedown', this.onMouseDown);
    window.removeEventListener('mousemove', this.onMouseMove);
    window.removeEventListener('mouseup', this.onMouseUp);
    el.removeEventListener('wheel', this.onWheel);
    window.removeEventListener('resize', this.onWindowResize);
  }

  private onMouseDown = (e: MouseEvent) => {
    this.isMouseDown = true;
    this.mousePrevX = e.clientX;
    this.mousePrevY = e.clientY;
  };

  private onMouseMove = (e: MouseEvent) => {
    const rect = this.containerRef.nativeElement.getBoundingClientRect();
    this.mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    // Raycast hover mesh
    this.raycaster.setFromCamera(this.mouse, this.camera);
    const intersects = this.raycaster.intersectObjects(this.currentModelGroup.children);
    if (intersects.length > 0 && intersects[0].object.name) {
      this.hoveredMeshName.set(intersects[0].object.name);
    } else {
      this.hoveredMeshName.set(null);
    }

    if (!this.isMouseDown) return;
    const deltaX = e.clientX - this.mousePrevX;
    const deltaY = e.clientY - this.mousePrevY;
    this.mousePrevX = e.clientX;
    this.mousePrevY = e.clientY;

    this.targetRotationY += deltaX * 0.01;
    this.targetRotationX += deltaY * 0.01;
  };

  private onMouseUp = () => {
    this.isMouseDown = false;
  };

  private onWheel = (e: WheelEvent) => {
    e.preventDefault();
    this.targetDistance += e.deltaY * 0.15;
    this.targetDistance = Math.max(40, Math.min(400, this.targetDistance));
  };

  private onWindowResize = () => {
    if (!this.containerRef || !this.renderer) return;
    const container = this.containerRef.nativeElement;
    const width = container.clientWidth;
    const height = container.clientHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  };
}
