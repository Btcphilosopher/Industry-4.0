import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PartTwinService } from '../../services/part-twin.service';
import { MATERIALS_CATALOG } from '../../data/materials.data';

@Component({
  selector: 'app-material-panel',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0f1218] border border-white/10 text-neutral-200 overflow-y-auto font-mono text-xs">
      <!-- Header Bar -->
      <div class="p-3 bg-[#141822] border-b border-white/10 flex items-center justify-between">
        <div class="flex items-center gap-2">
          <mat-icon class="text-red-500 !w-4 !h-4 !text-[16px]">science</mat-icon>
          <span class="font-bold text-white tracking-wider">WERKSTOFF-ZWILLING // MATERIAL DIGITAL TWIN</span>
        </div>
        <span class="text-[10px] px-2 py-0.5 bg-red-900/40 text-red-400 border border-red-700/50">
          NORM: {{ part().material.standard }}
        </span>
      </div>

      <div class="p-4 space-y-6">
        <!-- Active Material Overview Card -->
        <div class="bg-[#151a24] border border-white/10 p-4">
          <div class="flex flex-wrap items-start justify-between gap-4 mb-3">
            <div>
              <div class="text-[10px] text-neutral-400 uppercase">AKTIV ZUGEWIESENER WERKSTOFF</div>
              <h2 class="text-base font-bold text-white">{{ part().material.name }}</h2>
              <div class="text-[11px] text-sky-400 font-sans mt-0.5">{{ part().material.description }}</div>
            </div>
            <div class="text-right">
              <div class="text-[10px] text-neutral-400 uppercase">RECHNERISCHE BAUTEILMASSE</div>
              <div class="text-lg font-bold text-red-400">{{ part().massKg }} kg</div>
              <div class="text-[10px] text-neutral-500">Dichte: {{ part().material.density }} kg/m³</div>
            </div>
          </div>

          <!-- Material Selector Dropdown / Pills -->
          <div class="pt-3 border-t border-white/10">
            <div class="text-[10px] text-neutral-400 uppercase mb-2">WERKSTOFFSUBSTITUTION (DIGITAL TWIN SIMULATION):</div>
            <div class="flex flex-wrap gap-1.5">
              @for (matKey of availableMaterialKeys; track matKey) {
                <button 
                  (click)="selectMaterial(matKey)"
                  [class.bg-red-600]="part().material.name.includes(matKey)"
                  [class.text-white]="part().material.name.includes(matKey)"
                  [class.border-red-500]="part().material.name.includes(matKey)"
                  [class.bg-white/5]="!part().material.name.includes(matKey)"
                  [class.text-neutral-300]="!part().material.name.includes(matKey)"
                  class="px-2.5 py-1 text-xs border border-white/10 hover:border-white/30 transition-colors">
                  {{ matKey }}
                </button>
              }
            </div>
          </div>
        </div>

        <!-- Material Mechanical & Physical Properties Grid -->
        <div>
          <div class="text-[11px] font-bold text-neutral-300 uppercase mb-2 flex items-center gap-1.5">
            <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">tune</mat-icon>
            MECHANISCHE & THERMISCHE KENNWERTE (DIN EN ISO)
          </div>
          <div class="grid grid-cols-2 md:grid-cols-4 gap-2">
            <div class="bg-[#151a24] border border-white/10 p-2.5">
              <div class="text-[10px] text-neutral-400">E-MODUL (YOUNG)</div>
              <div class="text-sm font-bold text-white mt-1">{{ part().material.youngsModulus }} <span class="text-xs text-neutral-400 font-normal">GPa</span></div>
              <div class="text-[9px] text-neutral-500 mt-0.5">Querkontraktion: ν = {{ part().material.poissonsRatio }}</div>
            </div>

            <div class="bg-[#151a24] border border-white/10 p-2.5">
              <div class="text-[10px] text-neutral-400">STRECKGRENZE (R_e / R_p0.2)</div>
              <div class="text-sm font-bold text-white mt-1">{{ part().material.yieldStrength }} <span class="text-xs text-neutral-400 font-normal">MPa</span></div>
              <div class="text-[9px] text-neutral-500 mt-0.5">Elastische Grenze</div>
            </div>

            <div class="bg-[#151a24] border border-white/10 p-2.5">
              <div class="text-[10px] text-neutral-400">ZUGFESTIGKEIT (R_m)</div>
              <div class="text-sm font-bold text-white mt-1">{{ part().material.tensileStrength }} <span class="text-xs text-neutral-400 font-normal">MPa</span></div>
              <div class="text-[9px] text-neutral-500 mt-0.5">Bruchspannung</div>
            </div>

            <div class="bg-[#151a24] border border-white/10 p-2.5">
              <div class="text-[10px] text-neutral-400">DAUERFESTIGKEIT (σ_w)</div>
              <div class="text-sm font-bold text-white mt-1">{{ part().material.fatigueLimit }} <span class="text-xs text-neutral-400 font-normal">MPa</span></div>
              <div class="text-[9px] text-neutral-500 mt-0.5">Wöhlergrenze 10⁷ Zyklen</div>
            </div>

            <div class="bg-[#151a24] border border-white/10 p-2.5">
              <div class="text-[10px] text-neutral-400">HÄRTE</div>
              <div class="text-sm font-bold text-white mt-1">{{ part().material.hardness }}</div>
              <div class="text-[9px] text-neutral-500 mt-0.5">HRC / HB</div>
            </div>

            <div class="bg-[#151a24] border border-white/10 p-2.5">
              <div class="text-[10px] text-neutral-400">WÄRMELEITFÄHIGKEIT (λ)</div>
              <div class="text-sm font-bold text-white mt-1">{{ part().material.thermalConductivity }} <span class="text-xs text-neutral-400 font-normal">W/(m·K)</span></div>
              <div class="text-[9px] text-neutral-500 mt-0.5">Spez. Wärme: {{ part().material.specificHeat }} J/(kg·K)</div>
            </div>

            <div class="bg-[#151a24] border border-white/10 p-2.5">
              <div class="text-[10px] text-neutral-400">THERM. AUSDEHNUNG (α)</div>
              <div class="text-sm font-bold text-white mt-1">{{ part().material.thermalExpansion }} <span class="text-xs text-neutral-400 font-normal">10⁻⁶/K</span></div>
              <div class="text-[9px] text-neutral-500 mt-0.5">Längenausdehnungskoeff.</div>
            </div>

            <div class="bg-[#151a24] border border-white/10 p-2.5">
              <div class="text-[10px] text-neutral-400">CO₂-FUSSABDRUCK & ENERGIE</div>
              <div class="text-sm font-bold text-emerald-400 mt-1">{{ part().embodiedCO2Kg }} <span class="text-xs text-neutral-400 font-normal">kg CO₂e</span></div>
              <div class="text-[9px] text-neutral-500 mt-0.5">{{ part().material.embodiedEnergy }} MJ/kg Grauenergie</div>
            </div>
          </div>
        </div>

        <!-- Stress-Strain (Spannungs-Dehnungs-Diagramm) & Wöhler S-N Visualizer -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <!-- Diagram 1: Stress Strain Curve -->
          <div class="bg-[#151a24] border border-white/10 p-3">
            <div class="text-[10px] font-bold text-neutral-300 uppercase mb-2 flex items-center justify-between">
              <span>SPANNUNGS-DEHNUNGS-DIAGRAMM (σ-ε)</span>
              <span class="text-sky-400">DIN EN ISO 6892-1</span>
            </div>
            <div class="h-44 w-full bg-[#0d1017] border border-white/10 p-2 relative">
              <svg class="w-full h-full" viewBox="0 0 300 150">
                <!-- Axes -->
                <line x1="30" y1="130" x2="290" y2="130" stroke="#4b5563" stroke-width="1" />
                <line x1="30" y1="130" x2="30" y2="10" stroke="#4b5563" stroke-width="1" />
                <text x="280" y="145" fill="#9ca3af" font-size="9">ε [%]</text>
                <text x="5" y="15" fill="#9ca3af" font-size="9">σ [MPa]</text>

                <!-- Elastic line + Plastic curve -->
                <path 
                  [attr.d]="getStressStrainPath()" 
                  fill="none" 
                  stroke="#ef4444" 
                  stroke-width="2" />

                <!-- Operating Stress Point Marker -->
                <circle 
                  [attr.cx]="getOperatingPointX()" 
                  [attr.cy]="getOperatingPointY()" 
                  r="4" 
                  fill="#38bdf8" 
                  stroke="#ffffff" 
                  stroke-width="1.5" />
                <text 
                  [attr.x]="getOperatingPointX() + 6" 
                  [attr.y]="getOperatingPointY() - 4" 
                  fill="#38bdf8" 
                  font-size="8" 
                  font-weight="bold">
                  {{ part().simulationResult.vonMisesStressMaxMPa }} MPa (Ist)
                </text>

                <!-- Yield Point Label -->
                <line x1="30" [attr.y1]="getYieldY()" x2="280" [attr.y2]="getYieldY()" stroke="#eab308" stroke-width="0.75" stroke-dasharray="3,3" />
                <text x="35" [attr.y]="getYieldY() - 3" fill="#eab308" font-size="8">R_e = {{ part().material.yieldStrength }} MPa</text>
              </svg>
            </div>
          </div>

          <!-- Diagram 2: Wöhler Fatigue Curve (S-N Curve) -->
          <div class="bg-[#151a24] border border-white/10 p-3">
            <div class="text-[10px] font-bold text-neutral-300 uppercase mb-2 flex items-center justify-between">
              <span>WÖHLER-SCHWINGFESTIGKEITSLINIE (S-N)</span>
              <span class="text-sky-400">DIN 50100</span>
            </div>
            <div class="h-44 w-full bg-[#0d1017] border border-white/10 p-2 relative">
              <svg class="w-full h-full" viewBox="0 0 300 150">
                <!-- Axes -->
                <line x1="30" y1="130" x2="290" y2="130" stroke="#4b5563" stroke-width="1" />
                <line x1="30" y1="130" x2="30" y2="10" stroke="#4b5563" stroke-width="1" />
                <text x="260" y="145" fill="#9ca3af" font-size="9">log(N)</text>
                <text x="5" y="15" fill="#9ca3af" font-size="9">σ_a</text>

                <!-- Wöhler curve (High cycle -> fatigue limit plateau) -->
                <path d="M 35 25 Q 120 70, 200 95 L 285 95" fill="none" stroke="#38bdf8" stroke-width="2" />

                <!-- Fatigue Limit Line -->
                <line x1="30" y1="95" x2="290" y2="95" stroke="#10b981" stroke-width="0.75" stroke-dasharray="3,3" />
                <text x="35" y="90" fill="#10b981" font-size="8">Dauerfestigkeit σ_w = {{ part().material.fatigueLimit }} MPa</text>

                <!-- Current Cycle Count Marker -->
                <circle cx="160" cy="80" r="4" fill="#ef4444" stroke="#ffffff" stroke-width="1.5" />
                <text x="170" y="78" fill="#ef4444" font-size="8" font-weight="bold">
                  {{ (part().simulationResult.accumulatedCycles / 1000000).toFixed(1) }}M Zyklen
                </text>
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class MaterialPanelComponent {
  readonly partService = inject(PartTwinService);
  readonly part = computed(() => this.partService.activePart());

  readonly availableMaterialKeys = Object.keys(MATERIALS_CATALOG);

  selectMaterial(matKey: string) {
    this.partService.setPartMaterial(matKey);
  }

  getStressStrainPath(): string {
    const yieldMpa = this.part().material.yieldStrength;
    const tensileMpa = this.part().material.tensileStrength;

    // Scale to SVG 300x150
    const elasticEndX = 90;
    const elasticEndY = 130 - (yieldMpa / 2200) * 110;
    const plasticPeakX = 220;
    const plasticPeakY = 130 - (tensileMpa / 2200) * 110;
    const fractureX = 260;
    const fractureY = plasticPeakY + 15;

    return `M 30 130 L ${elasticEndX} ${elasticEndY} Q 150 ${plasticPeakY - 5}, ${plasticPeakX} ${plasticPeakY} Q 240 ${plasticPeakY + 5}, ${fractureX} ${fractureY}`;
  }

  getYieldY(): number {
    const yieldMpa = this.part().material.yieldStrength;
    return 130 - (yieldMpa / 2200) * 110;
  }

  getOperatingPointX(): number {
    const stress = this.part().simulationResult.vonMisesStressMaxMPa;
    const yieldMpa = this.part().material.yieldStrength;
    if (stress <= yieldMpa) {
      return 30 + (stress / yieldMpa) * 60;
    }
    return Math.min(250, 90 + ((stress - yieldMpa) / 500) * 120);
  }

  getOperatingPointY(): number {
    const stress = this.part().simulationResult.vonMisesStressMaxMPa;
    return Math.max(15, 130 - (stress / 2200) * 110);
  }
}
