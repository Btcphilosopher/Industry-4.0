import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PartTwinService } from '../../services/part-twin.service';

@Component({
  selector: 'app-bom-tree',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0f1218] border border-white/10 text-neutral-200 overflow-y-auto font-mono text-xs">
      <!-- Title Bar -->
      <div class="p-3 bg-[#141822] border-b border-white/10 flex flex-wrap items-center justify-between gap-2">
        <div class="flex items-center gap-2">
          <mat-icon class="text-red-500 !w-4 !h-4 !text-[16px]">account_tree</mat-icon>
          <span class="font-bold text-white tracking-wider">BAUGRUPPEN-HIERARCHIE & STÜCKLISTE // PLM BOM</span>
        </div>
        <div class="text-[10px] text-neutral-400">
          HIERARCHIE-EBENEN: 0 (GESAMTSYSTEM) &rarr; 1 (BAUGRUPPE) &rarr; 2 (EINZELTEIL)
        </div>
      </div>

      <div class="p-4 space-y-4">
        <!-- Assembly Roots (Vehicles & Machines) Selector -->
        <div class="flex flex-wrap gap-2">
          @for (root of assemblies(); track root.id) {
            <button 
              (click)="selectedRootId.set(root.id)"
              [class.bg-red-600]="selectedRootId() === root.id"
              [class.text-white]="selectedRootId() === root.id"
              [class.border-red-500]="selectedRootId() === root.id"
              [class.bg-white/5]="selectedRootId() !== root.id"
              [class.text-neutral-300]="selectedRootId() !== root.id"
              class="px-3 py-1.5 border border-white/10 flex items-center gap-2 transition-colors">
              <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">{{ root.category === 'VEHICLE' ? 'directions_car' : 'precision_manufacturing' }}</mat-icon>
              {{ root.name }}
            </button>
          }
        </div>

        <!-- Selected System Header Stats -->
        @if (currentSystem(); as sys) {
          <div class="bg-[#151a24] border border-white/10 p-3.5 flex flex-wrap items-center justify-between gap-4">
            <div>
              <div class="text-[10px] text-neutral-400 uppercase">{{ sys.category }} SYSTEM-TWIN</div>
              <h2 class="text-sm font-bold text-white">{{ sys.name }}</h2>
              <div class="text-[11px] text-sky-400 font-mono mt-0.5">{{ sys.code }} // {{ sys.supplier }}</div>
            </div>
            <div class="flex items-center gap-6">
              <div>
                <div class="text-[10px] text-neutral-400 uppercase">GESAMTMASSE</div>
                <div class="text-sm font-bold text-white">{{ sys.massTotalKg.toLocaleString('de-DE') }} kg</div>
              </div>
              <div>
                <div class="text-[10px] text-neutral-400 uppercase">HERSTELLKOSTEN (BOM)</div>
                <div class="text-sm font-bold text-emerald-400">{{ sys.costTotalEur.toLocaleString('de-DE') }} €</div>
              </div>
            </div>
          </div>

          <!-- Interactive Hierarchical Tree / Table -->
          <div class="bg-[#151a24] border border-white/10 overflow-x-auto">
            <table class="w-full text-left text-[11px]">
              <thead class="bg-[#10141d] text-neutral-400 uppercase text-[9px] border-b border-white/10">
                <tr>
                  <th class="p-2.5">Struktur / Baugruppenelement</th>
                  <th class="p-2.5">Sachnummer / Teilenr.</th>
                  <th class="p-2.5">Menge</th>
                  <th class="p-2.5">Masse (kg)</th>
                  <th class="p-2.5">Kosten (€)</th>
                  <th class="p-2.5">Lieferant / Werk</th>
                  <th class="p-2.5">Aktion</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-white/5">
                <!-- Root Row -->
                <tr class="bg-white/5 font-bold">
                  <td class="p-2.5 text-white flex items-center gap-2">
                    <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px] text-red-500">folder</mat-icon>
                    {{ sys.name }}
                  </td>
                  <td class="p-2.5 text-neutral-400">{{ sys.code }}</td>
                  <td class="p-2.5">1x</td>
                  <td class="p-2.5">{{ sys.massTotalKg }} kg</td>
                  <td class="p-2.5 text-emerald-400">{{ sys.costTotalEur }} €</td>
                  <td class="p-2.5 text-neutral-400">{{ sys.supplier }}</td>
                  <td class="p-2.5">
                    <span class="px-2 py-0.5 text-[9px] bg-sky-950 text-sky-400 border border-sky-800">SYSTEM</span>
                  </td>
                </tr>

                <!-- Level 1 Assemblies -->
                @for (sub of sys.children || []; track sub.id) {
                  <tr class="hover:bg-white/5 bg-[#121620]">
                    <td class="p-2.5 pl-8 text-neutral-200 flex items-center gap-2 font-bold">
                      <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px] text-sky-400">subdirectory_arrow_right</mat-icon>
                      {{ sub.name }}
                    </td>
                    <td class="p-2.5 text-sky-400 font-mono">{{ sub.code }}</td>
                    <td class="p-2.5">{{ sub.quantity }}x</td>
                    <td class="p-2.5">{{ sub.massTotalKg }} kg</td>
                    <td class="p-2.5 text-emerald-400">{{ sub.costTotalEur }} €</td>
                    <td class="p-2.5 text-neutral-400">{{ sub.supplier }}</td>
                    <td class="p-2.5">
                      <span class="px-2 py-0.5 text-[9px] bg-neutral-800 text-neutral-300">BAUGRUPPE</span>
                    </td>
                  </tr>

                  <!-- Level 2 Individual Parts -->
                  @for (partNode of sub.children || []; track partNode.id) {
                    <tr class="hover:bg-red-950/20 transition-colors" [class.bg-red-950/30]="partNode.partRefId === activePartId()">
                      <td class="p-2.5 pl-14 text-neutral-300 flex items-center gap-2">
                        <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]" [class.text-red-400]="partNode.partRefId === activePartId()" [class.text-neutral-500]="partNode.partRefId !== activePartId()">lens</mat-icon>
                        <span [class.font-bold]="partNode.partRefId === activePartId()" [class.text-white]="partNode.partRefId === activePartId()">
                          {{ partNode.name }}
                        </span>
                      </td>
                      <td class="p-2.5 font-mono text-red-400 font-bold">{{ partNode.code }}</td>
                      <td class="p-2.5">{{ partNode.quantity }}x</td>
                      <td class="p-2.5">{{ partNode.massTotalKg }} kg</td>
                      <td class="p-2.5 text-emerald-400">{{ partNode.costTotalEur }} €</td>
                      <td class="p-2.5 text-neutral-400">{{ partNode.supplier }}</td>
                      <td class="p-2.5">
                        @if (partNode.partRefId) {
                          <button 
                            (click)="selectPart(partNode.partRefId)"
                            class="px-2 py-0.5 text-[10px] bg-red-600/30 hover:bg-red-600 text-red-200 hover:text-white border border-red-500/40 flex items-center gap-1 transition-colors">
                            <mat-icon class="text-xs !w-3 !h-3 !text-[12px]">visibility</mat-icon>
                            ZWILLING ÖFFNEN
                          </button>
                        }
                      </td>
                    </tr>
                  }
                }
              </tbody>
            </table>
          </div>
        }
      </div>
    </div>
  `
})
export class BomTreeComponent {
  readonly partService = inject(PartTwinService);
  readonly assemblies = computed(() => this.partService.assemblies());
  readonly activePartId = computed(() => this.partService.activePartId());

  readonly selectedRootId = signal<string>('NODE-VEHICLE-01');

  readonly currentSystem = computed(() => {
    return this.assemblies().find(a => a.id === this.selectedRootId()) || this.assemblies()[0];
  });

  selectPart(partRefId: string) {
    this.partService.selectPart(partRefId);
    this.partService.setPartTab('IDENTITY');
  }
}
