import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PartTwinService } from '../../services/part-twin.service';

@Component({
  selector: 'app-analytics-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0f1218] border border-white/10 text-neutral-200 overflow-y-auto font-mono text-xs">
      <!-- Title Bar -->
      <div class="p-3 bg-[#141822] border-b border-white/10 flex flex-wrap items-center justify-between gap-2">
        <div class="flex items-center gap-2">
          <mat-icon class="text-red-500 !w-4 !h-4 !text-[16px]">analytics</mat-icon>
          <span class="font-bold text-white tracking-wider">WERKSANALYTIK & DIGITAL-TWIN-KENNZAHLEN // EXECUTIVE COCKPIT</span>
        </div>
        <div class="text-[10px] text-neutral-400">
          BERICHTSZEITRAUM: ECHTZEIT-AGGREGATION (WERKE PFRONTEN / SINDELFINGEN / FRIEDRICHSHAFEN)
        </div>
      </div>

      <div class="p-4 space-y-6">
        <!-- Top Executive KPIs -->
        <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div class="bg-[#151a24] border border-white/10 p-3.5">
            <div class="text-[10px] text-neutral-400 uppercase">GESAMTBESTAND DIGITALE ZWILLINGE</div>
            <div class="text-xl font-bold text-white mt-1">{{ totalParts() }} <span class="text-xs text-neutral-400 font-normal">Bauteile</span></div>
            <div class="text-[10px] text-emerald-400 mt-0.5">100% CAD/PLM synchronisiert</div>
          </div>

          <div class="bg-[#151a24] border border-white/10 p-3.5">
            <div class="text-[10px] text-neutral-400 uppercase">QUALITÄTS-ERSTRATE (FIRST PASS YIELD)</div>
            <div class="text-xl font-bold text-emerald-400 mt-1">{{ passRate() }}%</div>
            <div class="text-[10px] text-neutral-500 mt-0.5">Automotive Standard VDA 6.1</div>
          </div>

          <div class="bg-[#151a24] border border-white/10 p-3.5">
            <div class="text-[10px] text-neutral-400 uppercase">KAPITALBINDUNG LAGER (UMLAUFVERMÖGEN)</div>
            <div class="text-xl font-bold text-yellow-400 mt-1">{{ totalStockValue().toLocaleString('de-DE') }} <span class="text-xs font-normal">€</span></div>
            <div class="text-[10px] text-neutral-500 mt-0.5">Optimiert nach Kanban / Just-in-Time</div>
          </div>

          <div class="bg-[#151a24] border border-white/10 p-3.5">
            <div class="text-[10px] text-neutral-400 uppercase">AKKUMULIERTE CO₂-EMISSIONEN (GRAUENERGIE)</div>
            <div class="text-xl font-bold text-sky-400 mt-1">428.6 <span class="text-xs font-normal">t CO₂e</span></div>
            <div class="text-[10px] text-emerald-400 mt-0.5">-14.2% ggü. Vorjahr durch Leichtbau</div>
          </div>
        </div>

        <!-- Fleet Lifecycle Distribution Chart -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div class="bg-[#151a24] border border-white/10 p-4">
            <div class="text-[11px] font-bold text-neutral-300 uppercase mb-3 flex items-center gap-1.5">
              <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">donut_large</mat-icon>
              LEBENSZYKLUS-VERTEILUNG (PLM STATUS)
            </div>
            <div class="space-y-3">
              <div>
                <div class="flex justify-between text-[10px] mb-1">
                  <span class="text-white">SERIE (LAUFENDE PRODUKTION)</span>
                  <span class="text-emerald-400 font-bold">84% (87 Teile)</span>
                </div>
                <div class="h-2 w-full bg-white/10">
                  <div class="h-full bg-emerald-500 w-[84%]"></div>
                </div>
              </div>
              <div>
                <div class="flex justify-between text-[10px] mb-1">
                  <span class="text-white">PROTOTYP / PRÜFFELD (VORSCHAU)</span>
                  <span class="text-sky-400 font-bold">11% (11 Teile)</span>
                </div>
                <div class="h-2 w-full bg-white/10">
                  <div class="h-full bg-sky-500 w-[11%]"></div>
                </div>
              </div>
              <div>
                <div class="flex justify-between text-[10px] mb-1">
                  <span class="text-white">END-OF-LIFE (ERSATZTEILE)</span>
                  <span class="text-neutral-400 font-bold">5% (5 Teile)</span>
                </div>
                <div class="h-2 w-full bg-white/10">
                  <div class="h-full bg-neutral-500 w-[5%]"></div>
                </div>
              </div>
            </div>
          </div>

          <!-- OEE Machining Efficiency -->
          <div class="bg-[#151a24] border border-white/10 p-4">
            <div class="text-[11px] font-bold text-neutral-300 uppercase mb-3 flex items-center gap-1.5">
              <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">bar_chart</mat-icon>
              FERTIGUNGSEFFIZIENZ // OEE-AUFSCHLÜSSELUNG
            </div>
            <div class="grid grid-cols-3 gap-2 text-center">
              <div class="bg-[#0f1218] border border-white/10 p-2.5">
                <div class="text-[9px] text-neutral-400">VERFÜGBARKEIT</div>
                <div class="text-base font-bold text-white mt-1">94.2%</div>
                <div class="text-[8px] text-neutral-500 mt-0.5">Planmäßige Rüstzeit</div>
              </div>
              <div class="bg-[#0f1218] border border-white/10 p-2.5">
                <div class="text-[9px] text-neutral-400">LEISTUNGSGRAD</div>
                <div class="text-base font-bold text-white mt-1">92.8%</div>
                <div class="text-[8px] text-neutral-500 mt-0.5">Taktzeit-Einhaltung</div>
              </div>
              <div class="bg-[#0f1218] border border-white/10 p-2.5">
                <div class="text-[9px] text-neutral-400">QUALITÄTSQUOTIENT</div>
                <div class="text-base font-bold text-emerald-400 mt-1">99.4%</div>
                <div class="text-[8px] text-neutral-500 mt-0.5">Ausschuss &lt;0.6%</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class AnalyticsViewComponent {
  readonly partService = inject(PartTwinService);
  readonly totalParts = computed(() => this.partService.totalPartsCount());
  readonly passRate = computed(() => this.partService.avgQualityPassRate());
  readonly totalStockValue = computed(() => this.partService.totalStockValueEur());
}
