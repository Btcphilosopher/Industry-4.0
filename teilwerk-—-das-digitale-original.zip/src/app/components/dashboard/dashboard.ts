import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PartTwinService, PartDetailTab } from '../../services/part-twin.service';
import { PartTwinViewer3dComponent } from '../part-twin-viewer-3d/part-twin-viewer-3d';
import { TechnicalDrawingComponent } from '../technical-drawing/technical-drawing';
import { MaterialPanelComponent } from '../material-panel/material-panel';
import { ManufacturingRouteComponent } from '../manufacturing-route/manufacturing-route';
import { FeaSimulationComponent } from '../fea-simulation/fea-simulation';
import { QualityPanelComponent } from '../quality-panel/quality-panel';
import { BomTreeComponent } from '../bom-tree/bom-tree';
import { TraceabilityGraphComponent } from '../traceability-graph/traceability-graph';
import { DocumentViewerComponent } from '../document-viewer/document-viewer';

@Component({
  selector: 'app-dashboard',
  imports: [
    CommonModule, 
    MatIconModule,
    PartTwinViewer3dComponent,
    TechnicalDrawingComponent,
    MaterialPanelComponent,
    ManufacturingRouteComponent,
    FeaSimulationComponent,
    QualityPanelComponent,
    BomTreeComponent,
    TraceabilityGraphComponent,
    DocumentViewerComponent
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex-1 flex flex-col h-full bg-[#0a0d13] text-neutral-200 overflow-y-auto font-mono select-none">
      <!-- 1. Top Industrial KPI Cockpit Bar (Active Teile, In Produktion, Qualität, Lager, Simulationen) -->
      <section class="p-3 bg-[#0d1017] border-b border-white/10">
        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
          <!-- KPI 1: Active Teile -->
          <button 
            type="button"
            (click)="partService.setMainTab('PARTS')"
            class="w-full text-left bg-[#131722] border border-white/10 p-2.5 hover:border-red-500/50 cursor-pointer transition-colors">
            <div class="flex items-center justify-between">
              <span class="text-[9px] text-neutral-400 font-bold uppercase">AKTIVE TEILE</span>
              <mat-icon class="text-neutral-500 !w-3.5 !h-3.5 !text-[14px]">layers</mat-icon>
            </div>
            <div class="text-base font-bold text-white mt-1">{{ totalParts() }} <span class="text-xs text-neutral-400 font-normal">Zwillinge</span></div>
            <div class="text-[9px] text-emerald-400 mt-0.5 flex items-center gap-1">
              <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
              100% CAD/PLM aktiv
            </div>
          </button>

          <!-- KPI 2: In Produktion -->
          <button 
            type="button"
            (click)="partService.setMainTab('MACHINES')"
            class="w-full text-left bg-[#131722] border border-white/10 p-2.5 hover:border-red-500/50 cursor-pointer transition-colors">
            <div class="flex items-center justify-between">
              <span class="text-[9px] text-neutral-400 font-bold uppercase">IN PRODUKTION</span>
              <mat-icon class="text-neutral-500 !w-3.5 !h-3.5 !text-[14px]">precision_manufacturing</mat-icon>
            </div>
            <div class="text-base font-bold text-white mt-1">{{ inProductionCount() }} <span class="text-xs text-neutral-400 font-normal">Serienteile</span></div>
            <div class="text-[9px] text-sky-400 mt-0.5">4 CNC-Zentren aktiv</div>
          </button>

          <!-- KPI 3: Qualität -->
          <button 
            type="button"
            (click)="partService.setMainTab('QUALITY')"
            class="w-full text-left bg-[#131722] border border-white/10 p-2.5 hover:border-red-500/50 cursor-pointer transition-colors">
            <div class="flex items-center justify-between">
              <span class="text-[9px] text-neutral-400 font-bold uppercase">QUALITÄTSQUOTE</span>
              <mat-icon class="text-emerald-500 !w-3.5 !h-3.5 !text-[14px]">verified</mat-icon>
            </div>
            <div class="text-base font-bold text-emerald-400 mt-1">{{ passRate() }}% <span class="text-xs text-neutral-400 font-normal">PASS</span></div>
            <div class="text-[9px] text-neutral-400 mt-0.5">Cpk = {{ activePart().spcData.cpk }} (6σ)</div>
          </button>

          <!-- KPI 4: Lagerwert -->
          <button 
            type="button"
            (click)="partService.setMainTab('INVENTORY')"
            class="w-full text-left bg-[#131722] border border-white/10 p-2.5 hover:border-red-500/50 cursor-pointer transition-colors">
            <div class="flex items-center justify-between">
              <span class="text-[9px] text-neutral-400 font-bold uppercase">LAGERWERT</span>
              <mat-icon class="text-neutral-500 !w-3.5 !h-3.5 !text-[14px]">warehouse</mat-icon>
            </div>
            <div class="text-base font-bold text-yellow-400 mt-1">{{ totalStockValue().toLocaleString('de-DE') }} <span class="text-xs text-neutral-400 font-normal">€</span></div>
            <div class="text-[9px] text-neutral-400 mt-0.5">Halle 4 Hochregallager</div>
          </button>

          <!-- KPI 5: Simulationen -->
          <button 
            type="button"
            (click)="partService.setMainTab('SIMULATION')"
            class="w-full text-left bg-[#131722] border border-white/10 p-2.5 hover:border-red-500/50 cursor-pointer transition-colors col-span-2 sm:col-span-1">
            <div class="flex items-center justify-between">
              <span class="text-[9px] text-neutral-400 font-bold uppercase">SIMULATION</span>
              <mat-icon class="text-red-500 !w-3.5 !h-3.5 !text-[14px]">speed</mat-icon>
            </div>
            <div class="text-base font-bold text-white mt-1">S_f = {{ activePart().simulationResult.factorOfSafety }}</div>
            <div class="text-[9px] text-emerald-400 mt-0.5">FEA / Thermal normal</div>
          </button>
        </div>
      </section>

      <!-- 2. Featured Showcase Quick Selector Bar -->
      <section class="px-4 py-2 bg-[#10141d] border-b border-white/10 flex flex-wrap items-center justify-between gap-2 text-xs">
        <div class="flex items-center gap-2">
          <span class="text-[10px] text-neutral-400 font-bold uppercase">SCHNELLZUGRIFF DEMO-OBJEKTE:</span>
          <button 
            (click)="selectPart('tw-part-de-004812')"
            [class.bg-red-600]="activePart().id === 'tw-part-de-004812'"
            [class.text-white]="activePart().id === 'tw-part-de-004812'"
            [class.bg-white/5]="activePart().id !== 'tw-part-de-004812'"
            class="px-2.5 py-1 text-[11px] border border-white/10 flex items-center gap-1.5 transition-colors">
            <mat-icon class="!w-3.5 !h-3.5 !text-[14px]">trip_origin</mat-icon>
            6208 Rillenkugellager (DIN 625 P5)
          </button>
          <button 
            (click)="selectPart('tw-part-de-002173')"
            [class.bg-red-600]="activePart().id === 'tw-part-de-002173'"
            [class.text-white]="activePart().id === 'tw-part-de-002173'"
            [class.bg-white/5]="activePart().id !== 'tw-part-de-002173'"
            class="px-2.5 py-1 text-[11px] border border-white/10 flex items-center gap-1.5 transition-colors">
            <mat-icon class="!w-3.5 !h-3.5 !text-[14px]">adjust</mat-icon>
            Bremsscheibe Ø 340mm (EN-GJL-250)
          </button>
          <button 
            (click)="selectPart('tw-part-de-008921')"
            [class.bg-red-600]="activePart().id === 'tw-part-de-008921'"
            [class.text-white]="activePart().id === 'tw-part-de-008921'"
            [class.bg-white/5]="activePart().id !== 'tw-part-de-008921'"
            class="px-2.5 py-1 text-[11px] border border-white/10 flex items-center gap-1.5 transition-colors">
            <mat-icon class="!w-3.5 !h-3.5 !text-[14px]">settings</mat-icon>
            Schrägzahnrad Z=48 (16MnCr5)
          </button>
        </div>

        <button 
          (click)="partService.setMainTab('PARTS')"
          class="text-neutral-400 hover:text-white flex items-center gap-1 text-[11px] underline underline-offset-4">
          Alle {{ totalParts() }} Teile im Katalog anzeigen &rarr;
        </button>
      </section>

      <!-- 3. Main Part Twin Stage: Top Header Identity & Sub-Navigation Tabs -->
      <section class="p-4 flex-1 flex flex-col min-h-0">
        <!-- Active Part Header Identity Strip -->
        <div class="bg-[#141822] border border-white/10 p-3.5 mb-3 flex flex-wrap items-center justify-between gap-4">
          <div>
            <div class="flex items-center gap-2">
              <span class="text-xs font-bold text-red-500 font-mono tracking-wider">{{ activePart().partNumber }}</span>
              <span class="text-[10px] px-2 py-0.5 bg-white/5 border border-white/10 text-neutral-300">
                NORM: {{ activePart().toleranceClass }}
              </span>
              <span class="text-[10px] px-2 py-0.5 bg-emerald-950 text-emerald-400 border border-emerald-800">
                STATUS: {{ activePart().lifecycleStatus }}
              </span>
            </div>
            <h1 class="text-base font-bold text-white mt-1">{{ activePart().name }}</h1>
            <div class="text-[11px] text-neutral-400 font-sans mt-0.5">{{ activePart().description }}</div>
          </div>

          <!-- Quick Spec Tags -->
          <div class="flex flex-wrap items-center gap-3 text-right">
            <div>
              <div class="text-[9px] text-neutral-400 uppercase">WERKSTOFF</div>
              <div class="text-xs font-bold text-sky-400">{{ activePart().material.name }}</div>
            </div>
            <div class="h-6 w-px bg-white/15"></div>
            <div>
              <div class="text-[9px] text-neutral-400 uppercase">MASSE</div>
              <div class="text-xs font-bold text-white">{{ activePart().massKg }} kg</div>
            </div>
            <div class="h-6 w-px bg-white/15"></div>
            <div>
              <div class="text-[9px] text-neutral-400 uppercase">STÜCKPREIS</div>
              <div class="text-xs font-bold text-emerald-400">{{ activePart().unitCostEur.toFixed(2) }} €</div>
            </div>
            <div class="h-6 w-px bg-white/15"></div>
            <div>
              <div class="text-[9px] text-neutral-400 uppercase">TOLERANZKLASSE</div>
              <div class="text-xs font-bold text-yellow-400">{{ activePart().toleranceClass }}</div>
            </div>
          </div>
        </div>

        <!-- Part Twin Engineering Module Navigation Tabs -->
        <div class="bg-[#10141d] border-x border-t border-white/10 px-2 flex items-center space-x-1 overflow-x-auto no-scrollbar text-xs">
          @for (tab of partTabs; track tab.id) {
            <button 
              (click)="partService.setPartTab(tab.id)"
              [class.bg-[#151a24]]="activePartTab() === tab.id"
              [class.text-white]="activePartTab() === tab.id"
              [class.border-t-2]="activePartTab() === tab.id"
              [class.border-t-red-500]="activePartTab() === tab.id"
              [class.font-bold]="activePartTab() === tab.id"
              [class.text-neutral-400]="activePartTab() !== tab.id"
              [class.hover:text-neutral-200]="activePartTab() !== tab.id"
              class="px-3 py-2 flex items-center gap-1.5 transition-colors border-r border-white/5">
              <mat-icon class="!w-3.5 !h-3.5 !text-[14px]">{{ tab.icon }}</mat-icon>
              <span>{{ tab.label }}</span>
            </button>
          }
        </div>

        <!-- Part Twin Stage Active View Port -->
        <div class="flex-1 min-h-[500px] border border-white/10 bg-[#0f1218] relative flex flex-col">
          @switch (activePartTab()) {
            @case ('IDENTITY') {
              <!-- Part Technical Identity & Dimensional Blueprint Specification -->
              <div class="p-4 space-y-6 overflow-y-auto h-full text-xs">
                <!-- 3D Preview in Identity Tab -->
                <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
                  <div class="lg:col-span-7 h-[360px]">
                    <app-part-twin-viewer-3d></app-part-twin-viewer-3d>
                  </div>
                  <div class="lg:col-span-5 flex flex-col justify-between space-y-3">
                    <div class="bg-[#151a24] border border-white/10 p-3.5">
                      <div class="text-[10px] font-bold text-red-400 uppercase mb-2">ABMESSUNGEN & GEOMETRIEPARAMETER (METRISCH)</div>
                      <div class="space-y-1.5 text-[11px]">
                        <div class="flex justify-between py-1 border-b border-white/5">
                          <span class="text-neutral-400">Außendurchmesser (D):</span>
                          <span class="font-bold text-white font-mono">{{ activePart().dimensionsMm.outerDiameter || '-' }} mm</span>
                        </div>
                        <div class="flex justify-between py-1 border-b border-white/5">
                          <span class="text-neutral-400">Innendurchmesser / Bohrung (d):</span>
                          <span class="font-bold text-white font-mono">{{ activePart().dimensionsMm.innerDiameter || '-' }} mm</span>
                        </div>
                        <div class="flex justify-between py-1 border-b border-white/5">
                          <span class="text-neutral-400">Breite / Höhe (B):</span>
                          <span class="font-bold text-white font-mono">{{ activePart().dimensionsMm.width || activePart().dimensionsMm.height || '-' }} mm</span>
                        </div>
                        <div class="flex justify-between py-1 border-b border-white/5">
                          <span class="text-neutral-400">Oberflächenrauheit:</span>
                          <span class="font-bold text-yellow-400 font-mono">{{ activePart().surfaceFinish }}</span>
                        </div>
                        <div class="flex justify-between py-1">
                          <span class="text-neutral-400">Beschichtung / Schutz:</span>
                          <span class="font-bold text-sky-400">{{ activePart().coating }}</span>
                        </div>
                      </div>
                    </div>

                    <div class="bg-[#151a24] border border-white/10 p-3.5">
                      <div class="text-[10px] font-bold text-neutral-400 uppercase mb-2">TRAGZAHLEN & BETRIEBSGRENZEN (DIN ISO 281)</div>
                      <div class="grid grid-cols-2 gap-2 text-[10px]">
                        <div class="bg-[#0f1218] p-2 border border-white/10">
                          <span class="text-neutral-500">Dyn. Tragzahl C:</span>
                          <div class="text-xs font-bold text-white">{{ activePart().maxDynamicLoadKN || 31.8 }} kN</div>
                        </div>
                        <div class="bg-[#0f1218] p-2 border border-white/10">
                          <span class="text-neutral-500">Stat. Tragzahl C_0:</span>
                          <div class="text-xs font-bold text-white">{{ activePart().maxStaticLoadKN || 19.0 }} kN</div>
                        </div>
                        <div class="bg-[#0f1218] p-2 border border-white/10">
                          <span class="text-neutral-500">Grenzdrehzahl:</span>
                          <div class="text-xs font-bold text-yellow-400">{{ (activePart().maxOperatingRpm || 14000).toLocaleString('de-DE') }} RPM</div>
                        </div>
                        <div class="bg-[#0f1218] p-2 border border-white/10">
                          <span class="text-neutral-500">Temperaturbereich:</span>
                          <div class="text-xs font-bold text-sky-400">{{ activePart().operatingTemperatureRange.minC }} bis +{{ activePart().operatingTemperatureRange.maxC }} °C</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Compatible Assemblies & Applications -->
                <div class="bg-[#151a24] border border-white/10 p-4">
                  <div class="text-[11px] font-bold text-neutral-300 uppercase mb-3 flex items-center gap-1.5">
                    <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">account_tree</mat-icon>
                    KOMPATIBLE BAUGRUPPEN & MASCHINEN // SYSTEMINTEGRATION
                  </div>
                  <div class="flex flex-wrap gap-2">
                    @for (app of activePart().compatibleAssemblies; track app) {
                      <span class="px-2.5 py-1 bg-[#0f1218] border border-white/10 text-neutral-300 flex items-center gap-1">
                        <mat-icon class="text-red-500 !w-3 !h-3 !text-[12px]">check</mat-icon>
                        {{ app }}
                      </span>
                    }
                  </div>
                </div>
              </div>
            }
            @case ('VIEW_3D') {
              <app-part-twin-viewer-3d class="h-full"></app-part-twin-viewer-3d>
            }
            @case ('DRAWING') {
              <app-technical-drawing class="h-full"></app-technical-drawing>
            }
            @case ('MATERIAL') {
              <app-material-panel class="h-full"></app-material-panel>
            }
            @case ('MANUFACTURING') {
              <app-manufacturing-route class="h-full"></app-manufacturing-route>
            }
            @case ('QUALITY') {
              <app-quality-panel class="h-full"></app-quality-panel>
            }
            @case ('SIMULATION') {
              <app-fea-simulation class="h-full"></app-fea-simulation>
            }
            @case ('BOM') {
              <app-bom-tree class="h-full"></app-bom-tree>
            }
            @case ('TRACE') {
              <app-traceability-graph class="h-full"></app-traceability-graph>
            }
            @case ('DOCUMENTS') {
              <app-document-viewer class="h-full"></app-document-viewer>
            }
          }
        </div>
      </section>
    </div>
  `
})
export class DashboardComponent {
  readonly partService = inject(PartTwinService);
  readonly activePart = computed(() => this.partService.activePart());
  readonly activePartTab = computed(() => this.partService.activePartTab());
  readonly totalParts = computed(() => this.partService.totalPartsCount());
  readonly inProductionCount = computed(() => this.partService.partsInProduction());
  readonly passRate = computed(() => this.partService.avgQualityPassRate());
  readonly totalStockValue = computed(() => this.partService.totalStockValueEur());

  readonly partTabs: { id: PartDetailTab; label: string; icon: string }[] = [
    { id: 'IDENTITY', label: 'IDENTITÄT & SPEZIFIKATION', icon: 'badge' },
    { id: 'VIEW_3D', label: '3D-ZWILLING (WEBGL)', icon: 'view_in_ar' },
    { id: 'DRAWING', label: 'DIN 7200 ZEICHNUNG', icon: 'architecture' },
    { id: 'MATERIAL', label: 'WERKSTOFF-TWIN', icon: 'science' },
    { id: 'MANUFACTURING', label: 'FERTIGUNG & CNC', icon: 'precision_manufacturing' },
    { id: 'QUALITY', label: 'CMM & SPC QUALITÄT', icon: 'verified' },
    { id: 'SIMULATION', label: 'FEA & THERMOSIMULATION', icon: 'speed' },
    { id: 'BOM', label: 'BAUGRUPPEN (BOM)', icon: 'account_tree' },
    { id: 'TRACE', label: 'RÜCKVERFOLGBARKEIT (DPP)', icon: 'fingerprint' },
    { id: 'DOCUMENTS', label: 'PLM DOKUMENTE & CAD', icon: 'folder' }
  ];

  selectPart(partId: string) {
    this.partService.selectPart(partId);
  }
}
