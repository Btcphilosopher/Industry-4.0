import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PartTwinService } from '../../services/part-twin.service';

@Component({
  selector: 'app-parts-catalog',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0f1218] border border-white/10 text-neutral-200 overflow-hidden font-mono text-xs">
      <!-- Search & Filter Controls Toolbar -->
      <div class="p-3 bg-[#141822] border-b border-white/10 flex flex-wrap items-center justify-between gap-3">
        <!-- Search Input -->
        <div class="flex items-center bg-[#0d1017] border border-white/10 px-2.5 py-1.5 w-72 focus-within:border-red-500 transition-colors">
          <mat-icon class="text-neutral-400 !w-4 !h-4 !text-[16px] mr-2">search</mat-icon>
          <input 
            type="text" 
            [value]="partService.searchQuery()" 
            (input)="onSearchInput($event)"
            placeholder="Teilenr., Name, Werkstoff, DIN..." 
            class="bg-transparent border-none text-white text-xs focus:outline-none w-full placeholder:text-neutral-500 font-mono" />
          @if (partService.searchQuery()) {
            <button (click)="clearSearch()" class="text-neutral-400 hover:text-white">
              <mat-icon class="!w-3.5 !h-3.5 !text-[14px]">close</mat-icon>
            </button>
          }
        </div>

        <!-- Filter Dropdowns -->
        <div class="flex flex-wrap items-center gap-2">
          <!-- Category Filter -->
          <div class="flex items-center gap-1 bg-[#0d1017] border border-white/10 px-2 py-1">
            <span class="text-[10px] text-neutral-500">SPARTE:</span>
            <select 
              [value]="partService.filterCategory()" 
              (change)="onCategoryChange($event)"
              class="bg-transparent text-neutral-200 text-xs focus:outline-none border-none cursor-pointer">
              <option value="ALL" class="bg-[#141822]">Alle Sparten</option>
              <option value="AUTOMOTIVE" class="bg-[#141822]">Automobilindustrie</option>
              <option value="INDUSTRIAL" class="bg-[#141822]">Industrie & Maschinenbau</option>
            </select>
          </div>

          <!-- Lifecycle Filter -->
          <div class="flex items-center gap-1 bg-[#0d1017] border border-white/10 px-2 py-1">
            <span class="text-[10px] text-neutral-500">STATUS:</span>
            <select 
              [value]="partService.filterLifecycle()" 
              (change)="onLifecycleChange($event)"
              class="bg-transparent text-neutral-200 text-xs focus:outline-none border-none cursor-pointer">
              <option value="ALL" class="bg-[#141822]">Alle Status</option>
              <option value="SERIE" class="bg-[#141822]">Serie (Produktion)</option>
              <option value="ANLAUF" class="bg-[#141822]">Anlauf / Validierung</option>
              <option value="ERSATZTEIL" class="bg-[#141822]">Ersatzteil (Aftermarket)</option>
              <option value="AUSLAUFEND" class="bg-[#141822]">Auslaufend</option>
            </select>
          </div>

          <!-- Total results counter -->
          <span class="px-2.5 py-1 bg-white/5 border border-white/10 text-[10px] text-neutral-300">
            GEFUNDEN: <strong class="text-red-400">{{ filteredParts().length }}</strong> / {{ totalCount() }}
          </span>
        </div>
      </div>

      <!-- Parts Data Table -->
      <div class="flex-1 overflow-auto bg-[#0d1017]">
        <table class="w-full text-left text-[11px]">
          <thead class="bg-[#10141d] text-neutral-400 uppercase text-[9px] border-b border-white/10 sticky top-0 z-10">
            <tr>
              <th class="p-2.5">Teilenummer</th>
              <th class="p-2.5">Bauteilname & Spezifikation</th>
              <th class="p-2.5">Kategorie / Sparte</th>
              <th class="p-2.5">Werkstoff (DIN EN)</th>
              <th class="p-2.5">Masse</th>
              <th class="p-2.5">Qualität</th>
              <th class="p-2.5">Bestand</th>
              <th class="p-2.5">Preis</th>
              <th class="p-2.5">Status</th>
              <th class="p-2.5 text-right">Aktion</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-white/5">
            @for (part of filteredParts(); track part.id) {
              <tr 
                (click)="selectPart(part.id)"
                [class.bg-red-950/25]="part.id === activePartId()"
                [class.border-l-2]="part.id === activePartId()"
                [class.border-l-red-500]="part.id === activePartId()"
                class="hover:bg-white/5 cursor-pointer transition-colors">
                <td class="p-2.5 font-bold font-mono text-red-400 whitespace-nowrap">
                  {{ part.partNumber }}
                </td>
                <td class="p-2.5">
                  <div class="font-bold text-white">{{ part.name }}</div>
                  <div class="text-[10px] text-neutral-400 truncate max-w-xs">{{ part.description }}</div>
                </td>
                <td class="p-2.5 text-neutral-300">
                  <span class="px-1.5 py-0.2 text-[9px] bg-white/5 border border-white/10 text-neutral-300">
                    {{ part.subCategory }}
                  </span>
                </td>
                <td class="p-2.5 text-sky-400 font-mono">
                  {{ part.material.name }}
                </td>
                <td class="p-2.5 text-neutral-300 font-mono">
                  {{ part.massKg }} kg
                </td>
                <td class="p-2.5">
                  <span 
                    [class.text-emerald-400]="part.inspectionStatus === 'PASS'"
                    [class.text-yellow-400]="part.inspectionStatus === 'WARNUNG'"
                    [class.text-sky-400]="part.inspectionStatus === 'IN_PRUEFUNG'"
                    [class.text-red-400]="part.inspectionStatus === 'GESPERRT'"
                    class="font-bold flex items-center gap-1">
                    <mat-icon class="!w-3 !h-3 !text-[12px]">{{ part.inspectionStatus === 'PASS' ? 'check_circle' : 'info' }}</mat-icon>
                    {{ part.inspectionStatus }}
                  </span>
                </td>
                <td class="p-2.5 font-mono">
                  <span [class.text-red-400]="part.stockQuantity <= part.minStockThreshold" [class.text-neutral-200]="part.stockQuantity > part.minStockThreshold">
                    {{ part.stockQuantity }} Stk.
                  </span>
                </td>
                <td class="p-2.5 text-emerald-400 font-mono font-bold">
                  {{ part.unitCostEur.toFixed(2) }} €
                </td>
                <td class="p-2.5">
                  <span 
                    [class.bg-emerald-950]="part.lifecycleStatus === 'SERIE'"
                    [class.text-emerald-400]="part.lifecycleStatus === 'SERIE'"
                    [class.border-emerald-800]="part.lifecycleStatus === 'SERIE'"
                    [class.bg-sky-950]="part.lifecycleStatus === 'ANLAUF'"
                    [class.text-sky-400]="part.lifecycleStatus === 'ANLAUF'"
                    [class.border-sky-800]="part.lifecycleStatus === 'ANLAUF'"
                    [class.bg-neutral-800]="part.lifecycleStatus === 'AUSLAUFEND' || part.lifecycleStatus === 'OBSOLET'"
                    [class.text-neutral-400]="part.lifecycleStatus === 'AUSLAUFEND' || part.lifecycleStatus === 'OBSOLET'"
                    [class.border-neutral-700]="part.lifecycleStatus === 'AUSLAUFEND' || part.lifecycleStatus === 'OBSOLET'"
                    class="px-1.5 py-0.5 text-[8px] font-bold border">
                    {{ part.lifecycleStatus }}
                  </span>
                </td>
                <td class="p-2.5 text-right">
                  <button 
                    (click)="openTwin(part.id, $event)"
                    class="px-2 py-1 bg-red-600/30 hover:bg-red-600 text-red-200 hover:text-white border border-red-500/40 text-[10px] inline-flex items-center gap-1 transition-colors">
                    <mat-icon class="!w-3 !h-3 !text-[12px]">visibility</mat-icon>
                    ZWILLING
                  </button>
                </td>
              </tr>
            }
          </tbody>
        </table>
      </div>
    </div>
  `
})
export class PartsCatalogComponent {
  readonly partService = inject(PartTwinService);
  readonly filteredParts = computed(() => this.partService.filteredParts());
  readonly totalCount = computed(() => this.partService.totalPartsCount());
  readonly activePartId = computed(() => this.partService.activePartId());

  onSearchInput(event: Event) {
    const val = (event.target as HTMLInputElement).value;
    this.partService.searchQuery.set(val);
  }

  clearSearch() {
    this.partService.searchQuery.set('');
  }

  onCategoryChange(event: Event) {
    const val = (event.target as HTMLSelectElement).value;
    this.partService.filterCategory.set(val);
  }

  onLifecycleChange(event: Event) {
    const val = (event.target as HTMLSelectElement).value;
    this.partService.filterLifecycle.set(val);
  }

  selectPart(partId: string) {
    this.partService.selectPart(partId);
  }

  openTwin(partId: string, event: MouseEvent) {
    event.stopPropagation();
    this.partService.selectPart(partId);
    this.partService.setMainTab('DASHBOARD');
    this.partService.setPartTab('IDENTITY');
  }
}
