import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PartTwinService } from '../../services/part-twin.service';

@Component({
  selector: 'app-document-viewer',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0f1218] border border-white/10 text-neutral-200 overflow-y-auto font-mono text-xs">
      <!-- Title Bar -->
      <div class="p-3 bg-[#141822] border-b border-white/10 flex flex-wrap items-center justify-between gap-2">
        <div class="flex items-center gap-2">
          <mat-icon class="text-red-500 !w-4 !h-4 !text-[16px]">folder_open</mat-icon>
          <span class="font-bold text-white tracking-wider">PLM DOKUMENTENVERWALTUNG & CAD-DATEN // ENGINEERING VAULT</span>
        </div>
        <div class="text-[10px] text-neutral-400">
          COMPLIANCE: DIN ISO 11442 // VERSIONIERUNG: REVISION {{ part().currentRevision }}
        </div>
      </div>

      <div class="p-4 space-y-6">
        <!-- Document Files List Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
          @for (doc of documentList; track doc.id) {
            <div class="bg-[#151a24] border border-white/10 p-3.5 hover:border-red-500/40 transition-colors flex flex-col justify-between">
              <div>
                <div class="flex items-start justify-between gap-2 mb-2">
                  <div class="flex items-center gap-2.5">
                    <div class="w-8 h-8 bg-neutral-900 border border-white/10 flex items-center justify-center text-red-400">
                      <mat-icon class="!w-4 !h-4 !text-[18px]">{{ doc.icon }}</mat-icon>
                    </div>
                    <div>
                      <h4 class="font-bold text-white text-xs">{{ doc.name }}</h4>
                      <div class="text-[10px] text-neutral-400">{{ doc.type }} // {{ doc.fileSize }}</div>
                    </div>
                  </div>
                  <span class="px-2 py-0.5 text-[9px] bg-emerald-950 text-emerald-400 border border-emerald-800">
                    FREIGEGEBEN
                  </span>
                </div>
                <div class="text-[10px] text-neutral-300 mb-3">
                  {{ doc.description }}
                </div>
              </div>

              <div class="pt-2 border-t border-white/10 flex items-center justify-between">
                <div class="text-[9px] text-neutral-500 font-mono">
                  SHA-256: <span class="text-neutral-400">{{ doc.checksum }}</span>
                </div>
                <button 
                  (click)="downloadDoc(doc.name)"
                  class="px-2.5 py-1 bg-white/5 hover:bg-white/15 text-white border border-white/10 flex items-center gap-1 text-[10px] transition-colors">
                  <mat-icon class="!w-3.5 !h-3.5 !text-[14px]">download</mat-icon>
                  EXPORT
                </button>
              </div>
            </div>
          }
        </div>

        <!-- CAD Neutral File Formats Export Box -->
        <div class="bg-[#151a24] border border-white/10 p-4">
          <div class="text-[11px] font-bold text-neutral-300 uppercase mb-3 flex items-center gap-1.5">
            <mat-icon class="text-xs !w-3.5 !h-3.5 !text-[14px]">extension</mat-icon>
            CAD-DATENFORMAT EXPORT (PLM / CAM / FEM SCHNITTSTELLEN)
          </div>

          <div class="flex flex-wrap gap-2">
            <button class="px-3 py-1.5 bg-[#0f1218] hover:bg-red-600 hover:text-white border border-white/10 text-neutral-300 text-xs flex items-center gap-2 transition-colors">
              <mat-icon class="!w-3.5 !h-3.5 !text-[14px]">code</mat-icon>
              STEP AP242 (Semantic PMI / GD&T)
            </button>
            <button class="px-3 py-1.5 bg-[#0f1218] hover:bg-red-600 hover:text-white border border-white/10 text-neutral-300 text-xs flex items-center gap-2 transition-colors">
              <mat-icon class="!w-3.5 !h-3.5 !text-[14px]">code</mat-icon>
              JT Open DirectModel (ISO 14306)
            </button>
            <button class="px-3 py-1.5 bg-[#0f1218] hover:bg-red-600 hover:text-white border border-white/10 text-neutral-300 text-xs flex items-center gap-2 transition-colors">
              <mat-icon class="!w-3.5 !h-3.5 !text-[14px]">code</mat-icon>
              IGES 5.3 Surface Geometry
            </button>
            <button class="px-3 py-1.5 bg-[#0f1218] hover:bg-red-600 hover:text-white border border-white/10 text-neutral-300 text-xs flex items-center gap-2 transition-colors">
              <mat-icon class="!w-3.5 !h-3.5 !text-[14px]">code</mat-icon>
              DXF 2D Konturdaten (Laser / CNC)
            </button>
            <button class="px-3 py-1.5 bg-[#0f1218] hover:bg-red-600 hover:text-white border border-white/10 text-neutral-300 text-xs flex items-center gap-2 transition-colors">
              <mat-icon class="!w-3.5 !h-3.5 !text-[14px]">code</mat-icon>
              JSON Digital Twin Schema (ISO/IEC 21823)
            </button>
          </div>
        </div>
      </div>
    </div>
  `
})
export class DocumentViewerComponent {
  readonly partService = inject(PartTwinService);
  readonly part = computed(() => this.partService.activePart());

  readonly documentList = [
    {
      id: 'DOC-CAD-01',
      name: '3D CAD-Mastermodell (STEP AP242)',
      type: 'STEP (.stp) ISO 10303-242',
      fileSize: '4.8 MB',
      icon: 'view_in_ar',
      checksum: 'e3b0c442...98f1',
      description: 'Präzises parametrisches CAD-Volumenmodell inklusive vollständiger Form- und Lagetoleranzen (Semantic PMI).'
    },
    {
      id: 'DOC-DWG-02',
      name: 'DIN ISO 7200 Fertigungszeichnung',
      type: 'Vektor-PDF (.pdf) DIN A2',
      fileSize: '1.2 MB',
      icon: 'picture_as_pdf',
      checksum: 'a8f4c112...12cb',
      description: 'Offizielle freigegebene Zeichnung mit allen Schnittansichten, Passungsmaßen (P5) und Oberflächenangaben Ra 0.08.'
    },
    {
      id: 'DOC-APZ-03',
      name: 'DIN EN 10204 3.1 Abnahmeprüfzeugnis',
      type: 'Prüfzertifikat (.pdf)',
      fileSize: '650 KB',
      icon: 'verified_user',
      checksum: '7d32bb54...88a1',
      description: 'Chemische Spektralanalyse der Schmelze und Härteprüfprotokoll 64 HRC vom Werkssachverständigen.'
    },
    {
      id: 'DOC-SPC-04',
      name: 'CMM 3D-Messprotokoll & SPC-Datensatz',
      type: 'Messdaten (.csv / .qdas)',
      fileSize: '890 KB',
      icon: 'table_chart',
      checksum: '49f012aa...90ef',
      description: '500-Punkte KMG-Tastprotokoll der Zeiss Prismo mit Gauß-Verteilung und Fähigkeitskennzahlen Cp/Cpk.'
    },
    {
      id: 'DOC-ENV-05',
      name: 'EU REACH / RoHS Konformitätserklärung',
      type: 'Umwelterklärung (.pdf)',
      fileSize: '420 KB',
      icon: 'eco',
      checksum: '99bc4511...43da',
      description: 'Zertifizierter Nachweis über das Fehlen von SVHC-Substanzen und RoHS-III Richtlinienkonformität.'
    }
  ];

  downloadDoc(name: string) {
    // Show technical confirmation or download file
    const blob = new Blob([JSON.stringify(this.part(), null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${this.part().partNumber}_${name.replace(/[^a-zA-Z0-9]/g, '_')}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }
}
