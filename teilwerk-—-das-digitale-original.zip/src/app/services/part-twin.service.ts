import { Injectable, signal, computed } from '@angular/core';
import { PartTwin, AssemblyNode, MachineToolTwin, TraceabilityEvent } from '../models/part-twin.model';
import { SYNTHETIC_PARTS_DATABASE, SHOWCASE_PART_BEARING } from '../data/parts.data';
import { MATERIALS_CATALOG } from '../data/materials.data';
import { ASSEMBLY_HIERARCHIES, MACHINE_TOOLS_DATA } from '../data/assemblies.data';

export type MainNavTab = 
  | 'DASHBOARD'
  | 'PARTS'
  | 'ASSEMBLIES'
  | 'MACHINES'
  | 'MANUFACTURING'
  | 'QUALITY'
  | 'SIMULATION'
  | 'INVENTORY'
  | 'SUPPLY_CHAIN'
  | 'DOCUMENTS'
  | 'ANALYTICS';

export type PartDetailTab =
  | 'IDENTITY'
  | 'VIEW_3D'
  | 'DRAWING'
  | 'MATERIAL'
  | 'MANUFACTURING'
  | 'QUALITY'
  | 'SIMULATION'
  | 'BOM'
  | 'TRACE'
  | 'DOCUMENTS';

export type UserRole = 'INGENIEUR' | 'QUALITÄT' | 'FERTIGUNG' | 'DISPONENT' | 'ADMIN';

@Injectable({
  providedIn: 'root'
})
export class PartTwinService {
  // All Parts Repository
  readonly parts = signal<PartTwin[]>(SYNTHETIC_PARTS_DATABASE);
  
  // Active Selected Part Twin
  readonly activePartId = signal<string>(SHOWCASE_PART_BEARING.id);
  
  // Navigation State
  readonly activeMainTab = signal<MainNavTab>('DASHBOARD');
  readonly activePartTab = signal<PartDetailTab>('IDENTITY');
  readonly activeUserRole = signal<UserRole>('INGENIEUR');

  // Search & Filters
  readonly searchQuery = signal<string>('');
  readonly filterCategory = signal<string>('ALL');
  readonly filterLifecycle = signal<string>('ALL');
  readonly filterMaterial = signal<string>('ALL');

  // Assemblies & Machines
  readonly assemblies = signal<AssemblyNode[]>(ASSEMBLY_HIERARCHIES);
  readonly machineTools = signal<MachineToolTwin[]>(MACHINE_TOOLS_DATA);

  // Real-Time Simulation Clock
  readonly isSimulating = signal<boolean>(false);
  readonly simulationSpeed = signal<number>(1); // 1x, 10x, 100x
  readonly simulationTick = signal<number>(0);

  // Computed Active Part Twin
  readonly activePart = computed<PartTwin>(() => {
    const id = this.activePartId();
    const found = this.parts().find(p => p.id === id);
    return found || this.parts()[0] || SHOWCASE_PART_BEARING;
  });

  // Filtered Parts
  readonly filteredParts = computed<PartTwin[]>(() => {
    const query = this.searchQuery().toLowerCase().trim();
    const cat = this.filterCategory();
    const life = this.filterLifecycle();
    const mat = this.filterMaterial();

    return this.parts().filter(part => {
      // Category match
      if (cat !== 'ALL' && part.category !== cat && part.germanCategory !== cat) {
        return false;
      }
      // Lifecycle match
      if (life !== 'ALL' && part.lifecycleStatus !== life) {
        return false;
      }
      // Material match
      if (mat !== 'ALL' && !part.material.name.toLowerCase().includes(mat.toLowerCase())) {
        return false;
      }
      // Text search
      if (!query) return true;
      const combined = `${part.partNumber} ${part.name} ${part.description} ${part.material.name} ${part.manufacturer} ${part.supplier} ${part.subCategory} ${part.germanCategory} ${part.warehouseLocation}`.toLowerCase();
      return combined.includes(query);
    });
  });

  // KPIs
  readonly totalPartsCount = computed(() => this.parts().length);
  readonly partsInProduction = computed(() => this.parts().filter(p => p.lifecycleStatus === 'SERIE').length);
  readonly avgQualityPassRate = computed(() => {
    const passCount = this.parts().filter(p => p.inspectionStatus === 'PASS').length;
    return +((passCount / this.parts().length) * 100).toFixed(1);
  });
  readonly totalStockValueEur = computed(() => {
    return Math.round(this.parts().reduce((sum, p) => sum + p.stockQuantity * p.unitCostEur, 0));
  });

  private simIntervalId: ReturnType<typeof setInterval> | null = null;

  constructor() {
    // Setup interval for simulation clock
    this.startSimulationClockLoop();
  }

  selectPart(partId: string) {
    const part = this.parts().find(p => p.id === partId);
    if (part) {
      this.activePartId.set(partId);
    }
  }

  setMainTab(tab: MainNavTab) {
    this.activeMainTab.set(tab);
  }

  setPartTab(tab: PartDetailTab) {
    this.activePartTab.set(tab);
  }

  setRole(role: UserRole) {
    this.activeUserRole.set(role);
  }

  toggleSimulation() {
    this.isSimulating.update(v => !v);
  }

  setSimulationSpeed(speed: number) {
    this.simulationSpeed.set(speed);
  }

  resetSimulation() {
    this.isSimulating.set(false);
    this.simulationTick.set(0);
    const curr = this.activePart();
    
    // Reset simulation numbers to baseline
    this.updateActivePartSimulationParams({
      appliedLoadKN: curr.category === 'AUTOMOTIVE' ? 25.0 : 12.4,
      operatingRpm: 3200,
      ambientTempC: 22,
      operatingHours: 0,
      lubricationCondition: 'Optimal (ISO VG 68)',
      coolingFlowLMin: 2.0
    });
  }

  stepSimulation() {
    this.runSingleSimulationStep(1);
  }

  // Update simulation parameters dynamically
  updateActivePartSimulationParams(params: Partial<PartTwin['simulationParams']>) {
    const current = this.activePart();
    const updatedParams = { ...current.simulationParams, ...params };
    
    // Calculate new engineering simulation results based on physical laws
    const mat = current.material;
    const load = updatedParams.appliedLoadKN;
    const rpm = updatedParams.operatingRpm;
    const cooling = updatedParams.coolingFlowLMin;
    const ambTemp = updatedParams.ambientTempC;

    // Contact & von Mises Stress (approximated Hertzian / bending model)
    const baselineStress = (load * 1000) / (current.massKg * 80 + 10);
    const vonMises = Math.min(mat.tensileStrength * 1.3, Math.round(baselineStress * 1.8 + (rpm / 1000) * 15));
    const yieldRatio = +(vonMises / mat.yieldStrength).toFixed(2);
    const factorOfSafety = +(mat.yieldStrength / Math.max(vonMises, 1)).toFixed(2);

    // Thermal Equilibrium Calculation (Q_in = f(friction, load, rpm), Q_out = f(cooling, ambient))
    const frictionHeatWatts = (load * 12) * (rpm / 1000) * (updatedParams.lubricationCondition === 'Trocken' ? 4.5 : 0.85);
    const coolingCapacity = cooling * 85 + 20;
    const steadyStateDeltaT = frictionHeatWatts / coolingCapacity;
    const operatingTemp = +(ambTemp + steadyStateDeltaT).toFixed(1);

    // Wear & Fatigue (Wöhler S-N curve power law)
    const stressRatio = Math.max(0.2, vonMises / mat.fatigueLimit);
    const damageRatePerHour = Math.pow(stressRatio, 3.8) * 0.0025;
    const accumulatedDamage = Math.min(100, +(current.simulationResult.fatigueDamagePercent + damageRatePerHour * 0.2).toFixed(2));
    const rulHours = Math.max(100, Math.round((100 - accumulatedDamage) / Math.max(0.0001, damageRatePerHour)));
    const wearRate = (load / 10) * (rpm / 1000) * 0.0008;

    const newResult: PartTwin['simulationResult'] = {
      vonMisesStressMaxMPa: vonMises,
      yieldStrengthRatio: yieldRatio,
      factorOfSafety: factorOfSafety,
      displacementMaxMm: +(vonMises / (mat.youngsModulus * 100)).toFixed(4),
      operatingTempMaxC: operatingTemp,
      thermalGradientCPerMm: +(steadyStateDeltaT / 15).toFixed(2),
      contactPressureMaxMPa: Math.round(vonMises * 1.4),
      accumulatedCycles: current.simulationResult.accumulatedCycles + Math.round((rpm / 60) * 5),
      fatigueDamagePercent: accumulatedDamage,
      remainingUsefulLifeHours: rulHours,
      wearDepthMicrons: +(current.simulationResult.wearDepthMicrons + wearRate).toFixed(3),
      vibrationRmsMmS: +(0.4 + (rpm / 5000) * 0.6 + (accumulatedDamage > 50 ? 0.8 : 0.0)).toFixed(2),
      status: factorOfSafety < 1.05 || operatingTemp > current.operatingTemperatureRange.maxC ? 'KRITISCH' : (factorOfSafety < 1.25 ? 'WARNUNG' : 'NORMAL')
    };

    this.parts.update(list => list.map(p => {
      if (p.id === current.id) {
        return {
          ...p,
          simulationParams: updatedParams,
          simulationResult: newResult
        };
      }
      return p;
    }));
  }

  // Update Part Material and automatically recalibrate mass, stress, carbon footprint
  setPartMaterial(materialKey: string) {
    const mat = MATERIALS_CATALOG[materialKey];
    if (!mat) return;
    const current = this.activePart();

    // Calculate new mass based on density ratio
    const densityRatio = mat.density / current.material.density;
    const newMass = +(current.massKg * densityRatio).toFixed(3);
    const newEmbodiedCO2 = +(newMass * mat.carbonFootprint).toFixed(2);

    this.parts.update(list => list.map(p => {
      if (p.id === current.id) {
        return {
          ...p,
          material: mat,
          massKg: newMass,
          embodiedCO2Kg: newEmbodiedCO2
        };
      }
      return p;
    }));

    // Trigger simulation update with new material
    this.updateActivePartSimulationParams({});
    
    // Add Traceability Event
    this.addTraceabilityEvent(current.id, {
      id: `EVT-MAT-CHG-${Date.now()}`,
      partId: current.id,
      batch: current.batch,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      eventType: 'WAERMEBEHANDLUNG',
      title: `Werkstoffsubstitution zu ${mat.name}`,
      location: 'Konstruktionsbüro & Werkstofflabor',
      operatorOrSystem: `${this.activeUserRole()} — Digital Twin Change Management`,
      parameters: { 'Alter Werkstoff': current.material.name, 'Neuer Werkstoff': mat.name, 'Neue Masse (kg)': newMass },
      status: 'INFO'
    });
  }

  // Add traceability event
  addTraceabilityEvent(partId: string, event: TraceabilityEvent) {
    this.parts.update(list => list.map(p => {
      if (p.id === partId) {
        return {
          ...p,
          traceability: [event, ...p.traceability]
        };
      }
      return p;
    }));
  }

  // Update inventory stock
  adjustStock(partId: string, delta: number) {
    this.parts.update(list => list.map(p => {
      if (p.id === partId) {
        const newQty = Math.max(0, p.stockQuantity + delta);
        const newStatus: PartTwin['inventoryStatus'] = 
          newQty === 0 ? 'KRITISCH_GERING' :
          newQty <= p.minStockThreshold ? 'REORDER_TRIGGER' : 'VERFÜGBAR';
        return {
          ...p,
          stockQuantity: newQty,
          inventoryStatus: newStatus
        };
      }
      return p;
    }));
  }

  private startSimulationClockLoop() {
    if (typeof window === 'undefined') return;
    setInterval(() => {
      if (this.isSimulating()) {
        this.runSingleSimulationStep(this.simulationSpeed());
      }
    }, 400);
  }

  private runSingleSimulationStep(multiplier: number) {
    this.simulationTick.update(t => t + 1);
    const curr = this.activePart();
    const currentParams = curr.simulationParams;
    
    // Random micro-fluctuations simulating real factory sensor telemetry
    const rpmJitter = (Math.random() - 0.5) * 12 * multiplier;
    const loadJitter = (Math.random() - 0.5) * 0.15 * multiplier;

    this.updateActivePartSimulationParams({
      operatingRpm: Math.max(0, Math.round(currentParams.operatingRpm + rpmJitter)),
      appliedLoadKN: Math.max(0.1, +(currentParams.appliedLoadKN + loadJitter).toFixed(2)),
      operatingHours: +(currentParams.operatingHours + 0.1 * multiplier).toFixed(1)
    });
  }
}
