export interface DimensionRecord {
  nominal: number;
  toleranceUpper: number;
  toleranceLower: number;
  unit: 'mm' | 'µm' | 'deg' | 'Nm' | 'MPa' | 'bar' | '°C' | 'kg';
  label: string;
  measured?: number;
  datum?: string;
}

export interface MaterialProperties {
  id: string;
  name: string;
  grade: string;
  standard: string; // e.g. DIN EN ISO 683-17
  density: number; // kg/m³
  youngsModulus: number; // GPa
  poissonsRatio: number;
  yieldStrength: number; // MPa
  tensileStrength: number; // MPa
  hardness: string; // e.g. "60-64 HRC" or "210 HB"
  thermalConductivity: number; // W/(m·K)
  specificHeat: number; // J/(kg·K)
  thermalExpansion: number; // 10^-6 / K
  fatigueLimit: number; // MPa
  corrosionResistance: 'Hoch' | 'Mittel' | 'Gering' | 'Sehr Hoch';
  electricalConductivity: number; // MS/m
  carbonFootprint: number; // kg CO2e / kg
  embodiedEnergy: number; // MJ / kg
  description: string;
}

export interface RevisionDiff {
  field: string;
  oldValue: string;
  newValue: string;
  changeReason: string;
  author: string;
  date: string;
}

export interface PartRevision {
  revision: string; // 'REV A', 'REV B', 'REV C'
  releaseDate: string;
  status: 'In Prüfung' | 'Freigegeben' | 'Gesperrt' | 'Veraltet';
  author: string;
  approvedBy: string;
  changeSummary: string;
  diffs: RevisionDiff[];
}

export interface ManufacturingStep {
  stepNumber: number;
  name: string;
  processType: 'Zuschnitt' | 'Drehen' | 'Fräsen' | 'Härten' | 'Schleifen' | 'Superfinishen' | 'Beschichten' | 'Montage' | 'Prüfung' | 'Konservierung';
  machine: string;
  machineId: string;
  facility: string; // e.g. "Werk 1 — Stuttgart-Untertürkheim"
  cycleTimeSec: number;
  operatorStatus: 'Automatisiert (CNC)' | 'Roboterzelle' | 'Manuell überwacht' | 'Autonom';
  energyKWh: number;
  tool: string;
  toolWearPercent: number;
  temperatureC: number;
  pressureBar?: number;
  scrapRatePercent: number;
  status: 'Abgeschlossen' | 'In Bearbeitung' | 'Geplant' | 'Wartung';
  qualityResult: 'OK' | 'NOK' | 'Nacharbeit' | 'Ausstehend';
  timestamp: string;
}

export interface CMMMeasurementPoint {
  id: string;
  feature: string; // e.g. "Laufbahn Außendurchmesser D1"
  nominal: number;
  actual: number;
  toleranceUpper: number;
  toleranceLower: number;
  deviation: number;
  unit: string;
  status: 'PASS' | 'WARN' | 'FAIL';
  coordinates: { x: number; y: number; z: number };
}

export interface SPCBatchData {
  batchId: string;
  sampleSize: number;
  characteristic: string;
  unit: string;
  target: number;
  usl: number; // Upper Spec Limit
  lsl: number; // Lower Spec Limit
  mean: number;
  stdDev: number;
  cp: number;
  cpk: number;
  defectRatePpm: number;
  measurements: number[];
  inspectionDate: string;
  inspector: string;
  status: 'FREIGEGEBEN' | 'GESPERRT' | 'SONDERFREIGABE';
}

export interface SimulationParameters {
  appliedLoadKN: number;
  loadType: 'Radial' | 'Axial' | 'Torsion' | 'Biegung' | 'Kombiniert';
  operatingRpm: number;
  ambientTempC: number;
  operatingHours: number;
  lubricationCondition: 'Optimal (ISO VG 68)' | 'Grenzschmierung' | 'Mangelschmierung' | 'Trocken';
  coolingFlowLMin: number;
}

export interface SimulationResult {
  vonMisesStressMaxMPa: number;
  yieldStrengthRatio: number;
  factorOfSafety: number; // Sicherheitsbeiwert
  displacementMaxMm: number;
  operatingTempMaxC: number;
  thermalGradientCPerMm: number;
  contactPressureMaxMPa: number;
  accumulatedCycles: number;
  fatigueDamagePercent: number;
  remainingUsefulLifeHours: number;
  wearDepthMicrons: number;
  vibrationRmsMmS: number;
  status: 'NORMAL' | 'WARNUNG' | 'KRITISCH';
}

export interface TraceabilityEvent {
  id: string;
  partId: string;
  serialNumber?: string;
  batch: string;
  timestamp: string;
  eventType: 
    | 'MATERIAL_WEG'
    | 'ROHLING_GESCHMIEDET'
    | 'CNC_DREHEN_FERTIG'
    | 'WAERMEBEHANDLUNG'
    | 'CMM_PRUEFUNG_BESTANDEN'
    | 'LASER_SIGNIERUNG'
    | 'LAGER_EINGELAGERT'
    | 'MONTAGE_RADTRAEGER'
    | 'ENDABNAHME_FAHRZEUG'
    | 'INSPEKTION_80TKM'
    | 'SCHADENSANALYSE'
    | 'RECYCELT';
  title: string;
  location: string;
  operatorOrSystem: string;
  parameters: Record<string, string | number>;
  status: 'ERFOLG' | 'INFO' | 'WARNUNG' | 'ALARM';
  documentRef?: string;
}

export interface PartDocument {
  id: string;
  title: string;
  documentType: 'CAD_STEP' | 'ZEICHNUNG_PDF' | 'WERKSZEUGNIS_3_1' | 'PRUEFPROTOKOLL' | 'FMEA' | 'ROHS_REACH' | 'MONTAGEANLEITUNG';
  format: 'STEP / IGES' | 'PDF / DIN' | 'XML / QIF' | 'CSV / SPC';
  sizeBytes: number;
  version: string;
  date: string;
  author: string;
  classification: 'INTERN' | 'LIEFERANT' | 'KUNDE' | 'OEFFENTLICH';
  hash: string;
}

export interface CompatibilityRelation {
  relatedPartId: string;
  relatedPartNumber: string;
  relatedPartName: string;
  relationshipType: 'DIREKTER_ERSATZ' | 'UPGRADE_REVISION' | 'ALTERNATIVE' | 'KOMPATIBLE_BAUGRUPPE' | 'INVALIDE';
  notes: string;
}

export interface PartTwin {
  id: string;
  partNumber: string; // e.g. "TW-BRG-004812"
  name: string; // e.g. "6208 Rillenkugellager DIN 625"
  germanCategory: 'Antriebsstrang' | 'Fahrwerk & Bremsen' | 'Hydraulik & Pneumatik' | 'Maschinenelemente' | 'Elektrik & Sensorik' | 'Struktur & Karosserie';
  category: 'AUTOMOTIVE' | 'INDUSTRIAL' | 'ELECTRICAL';
  subCategory: string;
  description: string;
  manufacturer: string;
  manufacturingSite: string;
  supplier: string;
  supplierLocation: string;
  batch: string;
  serialRange: string;
  currentRevision: string;
  revisions: PartRevision[];
  
  // Dimensions & Weight
  massKg: number;
  dimensionsMm: {
    outerDiameter?: number;
    innerDiameter?: number;
    width?: number;
    length?: number;
    height?: number;
    threadSize?: string;
    boreCount?: number;
  };
  keyDimensions: DimensionRecord[];
  
  // Materials & Surface
  material: MaterialProperties;
  toleranceClass: string; // e.g. "ISO 2768-mK / DIN 620 P5"
  surfaceFinish: string; // e.g. "Ra 0.2 µm (Laufbahnen), Ra 0.8 µm (Mantel)"
  coating: string; // e.g. "Phosphatiert / Geölt / DLC Beschichtung"
  
  // Operating Limits
  operatingTemperatureRange: { minC: number; maxC: number };
  maxOperatingRpm?: number;
  maxPressureBar?: number;
  maxDynamicLoadKN?: number;
  maxStaticLoadKN?: number;
  
  // Statuses
  inspectionStatus: 'PASS' | 'WARNUNG' | 'IN_PRUEFUNG' | 'GESPERRT';
  qualityStatus: '100% OK' | 'SPC Toleranzgrenze' | 'Nachprüfung';
  lifecycleStatus: 'SERIE' | 'ANLAUF' | 'AUSLAUFEND' | 'ERSATZTEIL' | 'OBSOLET';
  inventoryStatus: 'VERFÜGBAR' | 'REORDER_TRIGGER' | 'KRITISCH_GERING' | 'IM_ZULAUF';
  
  // Storage & Inventory
  stockQuantity: number;
  reservedQuantity: number;
  minStockThreshold: number;
  reorderQuantity: number;
  warehouseLocation: string; // e.g. "Halle 4, Gang B, Fach 14-02"
  unitCostEur: number;
  leadTimeDays: number;
  
  // Sustainability
  embodiedCO2Kg: number;
  recyclabilityPercent: number;
  
  // Linked Engineering Modules
  manufacturingRoute: ManufacturingStep[];
  spcData: SPCBatchData;
  cmmPoints: CMMMeasurementPoint[];
  simulationParams: SimulationParameters;
  simulationResult: SimulationResult;
  traceability: TraceabilityEvent[];
  documents: PartDocument[];
  compatibilities: CompatibilityRelation[];
  compatibleAssemblies: string[];
  compatibleMachinesOrVehicles: string[];
  
  // 3D Geometry Identifier
  geometryType: 'BEARING_6208' | 'BRAKE_DISC_VENTED' | 'HELICAL_GEAR_Z48' | 'CONNECTING_ROD' | 'HYDRAULIC_VALVE' | 'ELECTRIC_MOTOR' | 'DRIVE_SHAFT' | 'CYLINDER_PISTON' | 'GENERIC_MECHANICAL';
}

export interface AssemblyNode {
  id: string;
  code: string;
  name: string;
  level: number;
  category: 'VEHICLE' | 'MACHINE' | 'ASSEMBLY' | 'SUB_ASSEMBLY' | 'PART';
  partRefId?: string;
  quantity: number;
  massTotalKg: number;
  costTotalEur: number;
  supplier: string;
  status: 'SERIENREIF' | 'IN_PROTOTYP' | 'PRÜFUNG';
  children?: AssemblyNode[];
  explodedOffset?: { x: number; y: number; z: number };
}

export interface MachineToolTwin {
  id: string;
  name: string;
  code: string;
  type: '5-ACHS_FRAESEN' | 'CNC_DREHEN' | 'SCHLEIFZELLE' | 'ROBOTERZELLE' | 'CMM_MESSRAUM';
  facility: string;
  status: 'IN_BETRIEB' | 'RÜSTEN' | 'WARTUNG' | 'STOPP';
  spindleRpm: number;
  feedRateMMin: number;
  cutDepthMm: number;
  powerKw: number;
  temperatureC: number;
  toolWearPercent: number;
  currentPartId: string;
  currentPartName: string;
  oeePercent: number; // Gesamtanlageneffektivität
  vibrationMmS: number;
  utilizationTodayPercent: number;
}
