import { PartTwin } from '../models/part-twin.model';
import { MATERIALS_CATALOG } from './materials.data';

// Primary Reference Showcase Part 1: 6208 Deep Groove Ball Bearing
export const SHOWCASE_PART_BEARING: PartTwin = {
  id: 'tw-part-de-004812',
  partNumber: 'TW-BRG-004812',
  name: '6208 Rillenkugellager DIN 625-1 (P5)',
  germanCategory: 'Maschinenelemente',
  category: 'INDUSTRIAL',
  subCategory: 'Wälzlager & Führungselemente',
  description: 'Einreihiges Hochpräzisions-Rillenkugellager nach DIN 625-1 mit optimierter Wälzkörpergeometrie, gehärtetem Stahlblechkäfig und beidseitigen berührungslosen 2Z-Deckscheiben für extrem vibrationsarmen Lauf bei Drehzahlen bis 12.000 min⁻¹.',
  manufacturer: 'TEILWERK Präzision GmbH',
  manufacturingSite: 'Werk Untertürkheim — Fertigungslinie WL-4',
  supplier: 'Saarstahl AG (Rohmaterial) / SKF Motion DE',
  supplierLocation: 'Völklingen / Schweinfurt, Deutschland',
  batch: 'CH-2026-0814-B',
  serialRange: 'SN-6208-884000 ... 884999',
  currentRevision: 'REV C',
  revisions: [
    {
      revision: 'REV C',
      releaseDate: '2026-04-12',
      status: 'Freigegeben',
      author: 'Dr.-Ing. M. Schultheiss',
      approvedBy: 'Prof. K. Weiss (QMS)',
      changeSummary: 'Laufbahn-Rauheit durch Feinziehschleifen auf Ra 0.08 µm reduziert; Lebensdauerbeiwert a_iso um +18% gesteigert.',
      diffs: [
        { field: 'surfaceFinish', oldValue: 'Ra 0.20 µm', newValue: 'Ra 0.08 µm', changeReason: 'Reduktion Reibungswert & Akustik', author: 'M. Schultheiss', date: '2026-04-10' },
        { field: 'dynamicLoadRating', oldValue: '32.5 kN', newValue: '34.2 kN', changeReason: 'Verstärkte Kugelmatrix 100Cr6-QT', author: 'M. Schultheiss', date: '2026-04-11' }
      ]
    },
    {
      revision: 'REV B',
      releaseDate: '2025-09-18',
      status: 'Freigegeben',
      author: 'Dipl.-Ing. R. Brandt',
      approvedBy: 'Dr.-Ing. M. Schultheiss',
      changeSummary: 'Umstellung auf PEEK-Käfigoption für Hochtemperaturanwendungen bis 180°C.',
      diffs: [
        { field: 'cageMaterial', oldValue: 'Stahlblech tiefgezogen', newValue: 'PEEK-CF30 Leichtbau', changeReason: 'Drehzahlgrenze +25%', author: 'R. Brandt', date: '2025-09-15' }
      ]
    },
    {
      revision: 'REV A',
      releaseDate: '2024-02-01',
      status: 'Veraltet',
      author: 'Dipl.-Ing. R. Brandt',
      approvedBy: 'H. Weber',
      changeSummary: 'Erstfreigabe Serienfertigung DIN 625.',
      diffs: []
    }
  ],
  massKg: 0.365,
  dimensionsMm: {
    outerDiameter: 80.000,
    innerDiameter: 40.000,
    width: 18.000,
    boreCount: 9 // 9 balls
  },
  keyDimensions: [
    { label: 'Außendurchmesser D', nominal: 80.000, toleranceUpper: 0.000, toleranceLower: -0.009, unit: 'mm', measured: 79.996, datum: 'A' },
    { label: 'Bohrungsdurchmesser d', nominal: 40.000, toleranceUpper: 0.000, toleranceLower: -0.008, unit: 'mm', measured: 39.998, datum: 'B' },
    { label: 'Breite B', nominal: 18.000, toleranceUpper: 0.000, toleranceLower: -0.120, unit: 'mm', measured: 17.965 },
    { label: 'Laufbahnrundheit', nominal: 0.000, toleranceUpper: 0.002, toleranceLower: 0.000, unit: 'µm', measured: 0.0014, datum: 'A-B' },
    { label: 'Kugeldurchmesser D_w (9x)', nominal: 11.906, toleranceUpper: 0.001, toleranceLower: -0.001, unit: 'mm', measured: 11.906 }
  ],
  material: MATERIALS_CATALOG['100Cr6'],
  toleranceClass: 'DIN 620 Toleranzklasse P5 / ISO 492 Class 5',
  surfaceFinish: 'Ra 0.08 µm (Laufbahnen Superfinish) / Ra 0.8 µm (Außenmantel)',
  coating: 'Phosphatiert nach DIN 50942 & Korrosionsschutzöl VCI-330',
  operatingTemperatureRange: { minC: -40, maxC: 150 },
  maxOperatingRpm: 12000,
  maxDynamicLoadKN: 34.2,
  maxStaticLoadKN: 19.8,
  inspectionStatus: 'PASS',
  qualityStatus: '100% OK',
  lifecycleStatus: 'SERIE',
  inventoryStatus: 'VERFÜGBAR',
  stockQuantity: 1420,
  reservedQuantity: 380,
  minStockThreshold: 400,
  reorderQuantity: 1000,
  warehouseLocation: 'Zentrallager Halle 4, Hochregal B-14, Fach 02',
  unitCostEur: 14.85,
  leadTimeDays: 4,
  embodiedCO2Kg: 1.04,
  recyclabilityPercent: 99.4,
  geometryType: 'BEARING_6208',
  manufacturingRoute: [
    {
      stepNumber: 10,
      name: 'Rohmaterialprüfung & 3.1 Zeugnisabgleich',
      processType: 'Prüfung',
      machine: 'Spektrometer OES SpectroMAXx',
      machineId: 'QC-MAT-01',
      facility: 'Werk 1 — Werkstofflabor',
      cycleTimeSec: 45,
      operatorStatus: 'Automatisiert (CNC)',
      energyKWh: 0.08,
      tool: 'Optischer Funken-Emissionssensor',
      toolWearPercent: 2,
      temperatureC: 22,
      scrapRatePercent: 0.05,
      status: 'Abgeschlossen',
      qualityResult: 'OK',
      timestamp: '2026-09-23 06:15'
    },
    {
      stepNumber: 20,
      name: 'CNC-Drehen Innen-/Außenring (Hard Turning)',
      processType: 'Drehen',
      machine: 'EMAG VL 4 Drehzentrum',
      machineId: 'CNC-TURN-04',
      facility: 'Halle 2 — Dreherei',
      cycleTimeSec: 28,
      operatorStatus: 'Roboterzelle',
      energyKWh: 0.42,
      tool: 'CBN-Wendeschneidplatte Sandvik CoroTurn',
      toolWearPercent: 24,
      temperatureC: 38,
      scrapRatePercent: 0.12,
      status: 'Abgeschlossen',
      qualityResult: 'OK',
      timestamp: '2026-09-23 07:30'
    },
    {
      stepNumber: 30,
      name: 'Vakuumhärten & Tiefkühlen (-80°C)',
      processType: 'Härten',
      machine: 'Ipsen TurboTreater Vakuumofen',
      machineId: 'HT-VAC-02',
      facility: 'Halle 1 — Härterei',
      cycleTimeSec: 240,
      operatorStatus: 'Autonom',
      energyKWh: 1.85,
      tool: 'N2-Hochdruckabschreckung 10 bar',
      toolWearPercent: 0,
      temperatureC: 860,
      pressureBar: 10,
      scrapRatePercent: 0.08,
      status: 'Abgeschlossen',
      qualityResult: 'OK',
      timestamp: '2026-09-23 10:45'
    },
    {
      stepNumber: 40,
      name: 'Präzisions-Spitzenlosschleifen',
      processType: 'Schleifen',
      machine: 'Studer S33 Rundschleifmaschine',
      machineId: 'GRIND-ST-09',
      facility: 'Halle 3 — Schleiferei',
      cycleTimeSec: 36,
      operatorStatus: 'Automatisiert (CNC)',
      energyKWh: 0.65,
      tool: 'CBN-Schleifscheibe keramisch gebunden',
      toolWearPercent: 18,
      temperatureC: 24,
      scrapRatePercent: 0.15,
      status: 'Abgeschlossen',
      qualityResult: 'OK',
      timestamp: '2026-09-23 13:10'
    },
    {
      stepNumber: 50,
      name: 'Superfinishen der Wälzkörperlaufbahn',
      processType: 'Superfinishen',
      machine: 'Thielenhaus Microfinish Sphero',
      machineId: 'FIN-TH-03',
      facility: 'Halle 3 — Feinbearbeitung',
      cycleTimeSec: 16,
      operatorStatus: 'Automatisiert (CNC)',
      energyKWh: 0.18,
      tool: 'Korund-Honstein Korn 1200',
      toolWearPercent: 12,
      temperatureC: 21,
      scrapRatePercent: 0.02,
      status: 'Abgeschlossen',
      qualityResult: 'OK',
      timestamp: '2026-09-23 14:00'
    },
    {
      stepNumber: 60,
      name: '100% CMM-Messung & Wirbelstromprüfung',
      processType: 'Prüfung',
      machine: 'Zeiss PRISMO Navigator CMM',
      machineId: 'QC-CMM-01',
      facility: 'Messraum Klasse 1 (20°C ±0.2K)',
      cycleTimeSec: 22,
      operatorStatus: 'Autonom',
      energyKWh: 0.12,
      tool: 'VAST Gold Tastkopf mit Rubinkugel 1.5mm',
      toolWearPercent: 1,
      temperatureC: 20.0,
      scrapRatePercent: 0.01,
      status: 'Abgeschlossen',
      qualityResult: 'OK',
      timestamp: '2026-09-23 15:20'
    }
  ],
  spcData: {
    batchId: 'CH-2026-0814-B',
    sampleSize: 50,
    characteristic: 'Außendurchmesser D (80.000 mm h5)',
    unit: 'mm',
    target: 79.995,
    usl: 80.000,
    lsl: 79.991,
    mean: 79.9962,
    stdDev: 0.00078,
    cp: 1.92,
    cpk: 1.63,
    defectRatePpm: 0.48,
    measurements: [
      79.9961, 79.9958, 79.9964, 79.9970, 79.9955, 79.9962, 79.9968, 79.9959, 79.9963, 79.9960,
      79.9957, 79.9966, 79.9961, 79.9954, 79.9965, 79.9969, 79.9958, 79.9962, 79.9967, 79.9960,
      79.9959, 79.9963, 79.9956, 79.9968, 79.9964, 79.9958, 79.9961, 79.9965, 79.9957, 79.9962,
      79.9960, 79.9966, 79.9959, 79.9963, 79.9955, 79.9967, 79.9961, 79.9958, 79.9964, 79.9962,
      79.9957, 79.9965, 79.9960, 79.9968, 79.9959, 79.9963, 79.9956, 79.9966, 79.9961, 79.9964
    ],
    inspectionDate: '2026-09-23',
    inspector: 'Prüfingenieur Dipl.-Ing. H. Bachmann',
    status: 'FREIGEGEBEN'
  },
  cmmPoints: [
    { id: 'CMM-P01', feature: 'Außenmantel Zylinder 0°', nominal: 80.000, actual: 79.996, toleranceUpper: 0.000, toleranceLower: -0.009, deviation: -0.004, unit: 'mm', status: 'PASS', coordinates: { x: 40, y: 0, z: 0 } },
    { id: 'CMM-P02', feature: 'Außenmantel Zylinder 90°', nominal: 80.000, actual: 79.997, toleranceUpper: 0.000, toleranceLower: -0.009, deviation: -0.003, unit: 'mm', status: 'PASS', coordinates: { x: 0, y: 40, z: 0 } },
    { id: 'CMM-P03', feature: 'Außenmantel Zylinder 180°', nominal: 80.000, actual: 79.996, toleranceUpper: 0.000, toleranceLower: -0.009, deviation: -0.004, unit: 'mm', status: 'PASS', coordinates: { x: -40, y: 0, z: 0 } },
    { id: 'CMM-P04', feature: 'Außenmantel Zylinder 270°', nominal: 80.000, actual: 79.995, toleranceUpper: 0.000, toleranceLower: -0.009, deviation: -0.005, unit: 'mm', status: 'PASS', coordinates: { x: 0, y: -40, z: 0 } },
    { id: 'CMM-P05', feature: 'Innenbohrung Zylinder 0°', nominal: 40.000, actual: 39.998, toleranceUpper: 0.000, toleranceLower: -0.008, deviation: -0.002, unit: 'mm', status: 'PASS', coordinates: { x: 20, y: 0, z: 0 } },
    { id: 'CMM-P06', feature: 'Innenbohrung Zylinder 90°', nominal: 40.000, actual: 39.997, toleranceUpper: 0.000, toleranceLower: -0.008, deviation: -0.003, unit: 'mm', status: 'PASS', coordinates: { x: 0, y: 20, z: 0 } },
    { id: 'CMM-P07', feature: 'Laufbahn Einstichtiefe Rille', nominal: 6.800, actual: 6.802, toleranceUpper: 0.010, toleranceLower: -0.010, deviation: 0.002, unit: 'mm', status: 'PASS', coordinates: { x: 28, y: 0, z: 0 } },
    { id: 'CMM-P08', feature: 'Planlauf Stirnfläche Seite A', nominal: 0.000, actual: 0.0018, toleranceUpper: 0.004, toleranceLower: 0.000, deviation: 0.0018, unit: 'mm', status: 'PASS', coordinates: { x: 35, y: 0, z: 9 } }
  ],
  simulationParams: {
    appliedLoadKN: 12.4,
    loadType: 'Radial',
    operatingRpm: 3200,
    ambientTempC: 22,
    operatingHours: 4200,
    lubricationCondition: 'Optimal (ISO VG 68)',
    coolingFlowLMin: 1.5
  },
  simulationResult: {
    vonMisesStressMaxMPa: 1420.0,
    yieldStrengthRatio: 0.78,
    factorOfSafety: 1.27,
    displacementMaxMm: 0.014,
    operatingTempMaxC: 68.4,
    thermalGradientCPerMm: 1.85,
    contactPressureMaxMPa: 1980.0,
    accumulatedCycles: 806400000,
    fatigueDamagePercent: 14.8,
    remainingUsefulLifeHours: 24500,
    wearDepthMicrons: 0.42,
    vibrationRmsMmS: 0.65,
    status: 'NORMAL'
  },
  traceability: [
    {
      id: 'EVT-01',
      partId: 'tw-part-de-004812',
      batch: 'CH-2026-0814-B',
      timestamp: '2026-09-20 08:30:14',
      eventType: 'MATERIAL_WEG',
      title: 'Rohmaterial-Wareneingang Schmelze #8812',
      location: 'Saarstahl Völklingen → TEILWERK Wareneingang',
      operatorOrSystem: 'SAP S/4HANA EWM — Prüflos 4001928',
      parameters: { 'Schmelzennummer': 'SCH-8812-100Cr6', 'Reinheitsgrad': 'K4 <= 10 DIN 50602', 'Härte': '207 HB' },
      status: 'ERFOLG'
    },
    {
      id: 'EVT-02',
      partId: 'tw-part-de-004812',
      batch: 'CH-2026-0814-B',
      timestamp: '2026-09-21 14:15:00',
      eventType: 'ROHLING_GESCHMIEDET',
      title: 'Warmwalzen Ringrohling & Weichglühen (+AC)',
      location: 'Schmiedewerkstatt Schuler 1600t',
      operatorOrSystem: 'Liniensteuerung Beckhoff TwinCAT 3',
      parameters: { 'Walztemperatur': '1080 °C', 'Gefüge': 'Feinstreifiges Perlit', 'Kornfeinung': 'ASTM 9' },
      status: 'ERFOLG'
    },
    {
      id: 'EVT-03',
      partId: 'tw-part-de-004812',
      batch: 'CH-2026-0814-B',
      timestamp: '2026-09-23 07:30:22',
      eventType: 'CNC_DREHEN_FERTIG',
      title: 'Hartdrehen Laufbahngeometrie & Einstiche',
      location: 'Halle 2 — EMAG VL 4 #04',
      operatorOrSystem: 'Siemens Sinumerik 840D sl',
      parameters: { 'Schnittgeschwindigkeit': '180 m/min', 'Vorschub': '0.08 mm/U', 'Werkzeugverschleiß': 'VB 0.08 mm' },
      status: 'ERFOLG'
    },
    {
      id: 'EVT-04',
      partId: 'tw-part-de-004812',
      batch: 'CH-2026-0814-B',
      timestamp: '2026-09-23 10:45:00',
      eventType: 'WAERMEBEHANDLUNG',
      title: 'Vakuumhärten 860°C & Anlassen auf 63 HRC',
      location: 'Halle 1 — Ipsen TurboTreater',
      operatorOrSystem: 'SCADA Honeywell ProCyc',
      parameters: { 'Härtetemperatur': '862 °C', 'Abschreckdruck': '9.8 bar N2', 'Rest-Austenit': '< 2.5%' },
      status: 'ERFOLG'
    },
    {
      id: 'EVT-05',
      partId: 'tw-part-de-004812',
      batch: 'CH-2026-0814-B',
      timestamp: '2026-09-23 15:20:10',
      eventType: 'CMM_PRUEFUNG_BESTANDEN',
      title: '100% CMM-3D-Koordinatenmessung bestanden',
      location: 'Messlabor Zeiss Prismo Navigator',
      operatorOrSystem: 'Zeiss CALYPSO 7.2 Automation',
      parameters: { 'Cpk-Index': '1.63', 'Max-Rauheit': 'Ra 0.078 µm', 'Rundheitsabweichung': '1.4 µm' },
      status: 'ERFOLG',
      documentRef: 'DOC-QC-2026-0814'
    },
    {
      id: 'EVT-06',
      partId: 'tw-part-de-004812',
      serialNumber: 'SN-6208-884012',
      batch: 'CH-2026-0814-B',
      timestamp: '2026-09-23 16:00:00',
      eventType: 'LASER_SIGNIERUNG',
      title: 'DMC-2D-Matrix DataMatrix Codierung & Signierung',
      location: 'Laserbeschriftungsstation Trumpf TruMark',
      operatorOrSystem: 'Trumpf Marking Engine — DIN SPEC 91406',
      parameters: { 'UID': 'DE-TW-BRG-004812-884012', 'ECC200': '16x16 Matrix' },
      status: 'ERFOLG'
    },
    {
      id: 'EVT-07',
      partId: 'tw-part-de-004812',
      batch: 'CH-2026-0814-B',
      timestamp: '2026-09-23 17:10:00',
      eventType: 'LAGER_EINGELAGERT',
      title: 'Konservierung & Einlagerung Hochregallager',
      location: 'Zentrallager Halle 4, Fach B-14-02',
      operatorOrSystem: 'Dematic FTS Shuttle System',
      parameters: { 'Gebindegröße': '50 Stk/Karton', 'VCI-Folie': 'Dauer 24 Monate' },
      status: 'INFO'
    },
    {
      id: 'EVT-08',
      partId: 'tw-part-de-004812',
      serialNumber: 'SN-6208-884012',
      batch: 'CH-2026-0814-B',
      timestamp: '2026-09-24 01:12:00',
      eventType: 'MONTAGE_RADTRAEGER',
      title: 'Einpressen in Radträger-Baugruppe VA Links',
      location: 'Montagelinie Achsmodule Halle 6',
      operatorOrSystem: 'KUKA Roboterzelle KR Quantec (Kraft-Weg-Überwacht)',
      parameters: { 'Einpresskraft': '18.2 kN (Soll: 16-22 kN)', 'Setzweg': '18.02 mm', 'Fügespannung': 'OK' },
      status: 'ERFOLG'
    }
  ],
  documents: [
    {
      id: 'DOC-STEP-004812',
      title: '3D-CAD-Modell STEP AP242 (Semantic PMI / Form & Lage)',
      documentType: 'CAD_STEP',
      format: 'STEP / IGES',
      sizeBytes: 4208000,
      version: '3.2',
      date: '2026-04-12',
      author: 'CAD-Konstruktion TEILWERK',
      classification: 'INTERN',
      hash: 'sha256:7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3571d79'
    },
    {
      id: 'DOC-DIN-004812',
      title: 'Fertigungszeichnung DIN 625-1 (A1 Vektorgrafik)',
      documentType: 'ZEICHNUNG_PDF',
      format: 'PDF / DIN',
      sizeBytes: 1840000,
      version: 'REV C',
      date: '2026-04-12',
      author: 'Dr.-Ing. M. Schultheiss',
      classification: 'INTERN',
      hash: 'sha256:4a098816c149d8a3915bc6719dc180029b9f71c4c1122a68'
    },
    {
      id: 'DOC-3_1-004812',
      title: 'Abnahmeprüfzeugnis 3.1 nach DIN EN 10204',
      documentType: 'WERKSZEUGNIS_3_1',
      format: 'PDF / DIN',
      sizeBytes: 520000,
      version: '1.0',
      date: '2026-09-23',
      author: 'Werkstoffprüfstelle Saarstahl / TEILWERK QMS',
      classification: 'KUNDE',
      hash: 'sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
    },
    {
      id: 'DOC-SPC-004812',
      title: 'Statistisches Prozessregel-Protokoll (SPC Cpk 1.63)',
      documentType: 'PRUEFPROTOKOLL',
      format: 'CSV / SPC',
      sizeBytes: 88000,
      version: 'Batch-0814-B',
      date: '2026-09-23',
      author: 'Qualitätssicherung Halle 3',
      classification: 'INTERN',
      hash: 'sha256:8812c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b991'
    }
  ],
  compatibilities: [
    {
      relatedPartId: 'tw-part-de-004813',
      relatedPartNumber: 'TW-BRG-004813',
      relatedPartName: '6208-2RS Rillenkugellager (NBR-Schleifdichtung)',
      relationshipType: 'ALTERNATIVE',
      notes: 'Höherer Spritzwasserschutz (IP65), Grenzdrehzahl 7.500 min⁻¹'
    },
    {
      relatedPartId: 'tw-part-de-004810',
      relatedPartNumber: 'TW-BRG-004810',
      relatedPartName: '6208-C3 Rillenkugellager (Erhöhte Radialluft)',
      relationshipType: 'ALTERNATIVE',
      notes: 'Für Hochtemperaturanwendungen > 120°C thermische Ausdehnung'
    },
    {
      relatedPartId: 'tw-part-de-001928',
      relatedPartNumber: 'TW-HUB-001928',
      relatedPartName: 'Leichtbau-Radnabe 5-Loch Aluminium EN AW-7075',
      relationshipType: 'KOMPATIBLE_BAUGRUPPE',
      notes: 'Passungstoleranz H6/p5 mit Übermaß 0.012 mm'
    }
  ],
  compatibleAssemblies: [
    'Radträger- & Achsbaugruppe Vorne (TW-ASY-VA-01)',
    'Elektro-Antriebseinheit 180kW Hinterachse (TW-ASY-ED-02)',
    'Hauptspindel 12.000 RPM Bearbeitungszentrum (TW-ASY-SP-04)'
  ],
  compatibleMachinesOrVehicles: [
    'TW-EV-PLATFORM-2026 (Elektro-Sportlimousine)',
    'TW-CNC-HSC800 (5-Achs-HSC-Fräszentrum)',
    'TW-AGV-4000 (Fahrerloses Transportsystem 4.0t)'
  ]
};

// Primary Reference Showcase Part 2: Ventilated Brake Disc
export const SHOWCASE_PART_BRAKE_DISC: PartTwin = {
  id: 'tw-part-de-002173',
  partNumber: 'TW-BRK-002173',
  name: 'Innenbelüftete Hochleistungs-Bremsscheibe Ø 340mm',
  germanCategory: 'Fahrwerk & Bremsen',
  category: 'AUTOMOTIVE',
  subCategory: 'Bremsanlagen & Reibsysteme',
  description: 'Zweiteilige hochgekohlte Grauguss-Bremsscheibe mit gerichteten Strömungskanälen (Turbinenbelüftung) und schwimmend gelagertem Aluminium-Topf zur thermischen Entkopplung und Vermeidung von Heißrubbeln unter extremen Verzögerungswerten bis 1.4g.',
  manufacturer: 'TEILWERK Bremsensysteme AG',
  manufacturingSite: 'Werk 2 — Gießerei & Zerspanungszentrum Schweinfurt',
  supplier: 'Eisenwerk Brühl / TEILWERK Foundry',
  supplierLocation: 'Brühl / Schweinfurt, Deutschland',
  batch: 'CH-2026-0720-BRK',
  serialRange: 'SN-340BRK-44000 ... 44999',
  currentRevision: 'REV B',
  revisions: [
    {
      revision: 'REV B',
      releaseDate: '2025-11-20',
      status: 'Freigegeben',
      author: 'Dr.-Ing. K. Obermeier',
      approvedBy: 'Dipl.-Ing. F. Richter',
      changeSummary: 'Kühlluftkanäle auf Schaufelwinkel 32° strömungsoptimiert (-45K Scheibenspitzentemperatur im Fade-Test).',
      diffs: [
        { field: 'thermalConductivity', oldValue: '48 W/(m·K)', newValue: '52 W/(m·K)', changeReason: 'Optimierte Molybdänlegierung', author: 'K. Obermeier', date: '2025-11-18' }
      ]
    },
    {
      revision: 'REV A',
      releaseDate: '2024-06-10',
      status: 'Veraltet',
      author: 'Dipl.-Ing. F. Richter',
      approvedBy: 'H. Weber',
      changeSummary: 'Serienanlauf Basisversion 340x30mm.',
      diffs: []
    }
  ],
  massKg: 8.70,
  dimensionsMm: {
    outerDiameter: 340.000,
    innerDiameter: 68.000,
    width: 30.000,
    height: 52.000,
    boreCount: 5
  },
  keyDimensions: [
    { label: 'Außendurchmesser Reibring Ø D', nominal: 340.000, toleranceUpper: 0.200, toleranceLower: -0.200, unit: 'mm', measured: 340.040, datum: 'A' },
    { label: 'Reibringdicke neu / min', nominal: 30.000, toleranceUpper: 0.050, toleranceLower: -0.050, unit: 'mm', measured: 30.012 },
    { label: 'Planlaufabweichung Reibfläche', nominal: 0.000, toleranceUpper: 0.015, toleranceLower: 0.000, unit: 'mm', measured: 0.007, datum: 'A-B' },
    { label: 'Dickenvariation DTV (360°)', nominal: 0.000, toleranceUpper: 0.008, toleranceLower: 0.000, unit: 'mm', measured: 0.0035 },
    { label: 'Zentrierbohrung Ø d', nominal: 68.000, toleranceUpper: 0.020, toleranceLower: 0.000, unit: 'mm', measured: 68.011, datum: 'B' }
  ],
  material: MATERIALS_CATALOG['EN-GJL-250'],
  toleranceClass: 'DIN ISO 2768-mK / ECE R90',
  surfaceFinish: 'Ra 1.2 µm (Reibflächen kreuzgeschliffen) / Geomet-Beschichtung (Topf)',
  coating: 'Zinklamellen-Korrosionsschutz (Silber / 480h Salzsprühtest DIN EN ISO 9227)',
  operatingTemperatureRange: { minC: -30, maxC: 750 },
  maxOperatingRpm: 3500,
  maxDynamicLoadKN: 48.0,
  inspectionStatus: 'PASS',
  qualityStatus: '100% OK',
  lifecycleStatus: 'SERIE',
  inventoryStatus: 'VERFÜGBAR',
  stockQuantity: 620,
  reservedQuantity: 140,
  minStockThreshold: 150,
  reorderQuantity: 500,
  warehouseLocation: 'Halle 5, Schwerlastregal S-08, Ebene 1',
  unitCostEur: 68.40,
  leadTimeDays: 7,
  embodiedCO2Kg: 16.96,
  recyclabilityPercent: 98.8,
  geometryType: 'BRAKE_DISC_VENTED',
  manufacturingRoute: [
    {
      stepNumber: 10,
      name: 'Formguss im Sandgussverfahren (Disamatic)',
      processType: 'Zuschnitt',
      machine: 'Disamatic 2110 Vertikalformanlage',
      machineId: 'CAST-DISA-01',
      facility: 'Gießerei Schweinfurt',
      cycleTimeSec: 42,
      operatorStatus: 'Automatisiert (CNC)',
      energyKWh: 4.80,
      tool: 'Harzgebundener Sandkern Belüftung',
      toolWearPercent: 5,
      temperatureC: 1380,
      scrapRatePercent: 1.20,
      status: 'Abgeschlossen',
      qualityResult: 'OK',
      timestamp: '2026-09-22 04:00'
    },
    {
      stepNumber: 20,
      name: 'Spannungsarmglühen bei 580°C',
      processType: 'Härten',
      machine: 'Durchlauf-Glühofen Mahler',
      machineId: 'HT-ANNEAL-01',
      facility: 'Halle 1 — Wärmebehandlung',
      cycleTimeSec: 360,
      operatorStatus: 'Autonom',
      energyKWh: 5.40,
      tool: 'Schutzgasatmosphäre N2/CO2',
      toolWearPercent: 0,
      temperatureC: 580,
      scrapRatePercent: 0.10,
      status: 'Abgeschlossen',
      qualityResult: 'OK',
      timestamp: '2026-09-22 08:30'
    },
    {
      stepNumber: 30,
      name: 'Doppelseiten-CNC-Plandrehen der Reibflächen',
      processType: 'Drehen',
      machine: 'Chiron FZ 16 W Doppelspindel',
      machineId: 'CNC-MILL-02',
      facility: 'Halle 4 — Zerspanung',
      cycleTimeSec: 54,
      operatorStatus: 'Roboterzelle',
      energyKWh: 1.25,
      tool: 'Keramik-Schneidstoff Walter Tiger-tec',
      toolWearPercent: 28,
      temperatureC: 65,
      scrapRatePercent: 0.25,
      status: 'Abgeschlossen',
      qualityResult: 'OK',
      timestamp: '2026-09-22 11:20'
    },
    {
      stepNumber: 40,
      name: 'Dynamisches Auswuchten & Fräsen von Ausgleichskerben',
      processType: 'Fräsen',
      machine: 'Schenck RoTec Auswuchtzentrum',
      machineId: 'BAL-SCH-01',
      facility: 'Halle 4 — Wuchtstation',
      cycleTimeSec: 24,
      operatorStatus: 'Automatisiert (CNC)',
      energyKWh: 0.35,
      tool: 'Hartmetallfräser Schaft Ø 12mm',
      toolWearPercent: 15,
      temperatureC: 22,
      scrapRatePercent: 0.05,
      status: 'Abgeschlossen',
      qualityResult: 'OK',
      timestamp: '2026-09-22 13:40'
    },
    {
      stepNumber: 50,
      name: 'Zinklamellenbeschichtung & Einbrennen',
      processType: 'Beschichten',
      machine: 'Geomet Tauch-Schleuderanlage',
      machineId: 'COAT-GEO-01',
      facility: 'Halle 7 — Oberflächentechnik',
      cycleTimeSec: 180,
      operatorStatus: 'Automatisiert (CNC)',
      energyKWh: 2.10,
      tool: 'Infrarot-Trocknungsstrecke 300°C',
      toolWearPercent: 2,
      temperatureC: 300,
      scrapRatePercent: 0.05,
      status: 'Abgeschlossen',
      qualityResult: 'OK',
      timestamp: '2026-09-22 16:00'
    }
  ],
  spcData: {
    batchId: 'CH-2026-0720-BRK',
    sampleSize: 30,
    characteristic: 'Reibringdicke (30.000 mm ±0.050)',
    unit: 'mm',
    target: 30.000,
    usl: 30.050,
    lsl: 29.950,
    mean: 30.011,
    stdDev: 0.0084,
    cp: 1.98,
    cpk: 1.54,
    defectRatePpm: 1.85,
    measurements: [
      30.012, 30.008, 30.015, 30.004, 30.018, 30.009, 30.011, 30.014, 30.007, 30.016,
      30.010, 30.013, 30.006, 30.019, 30.008, 30.012, 30.015, 30.005, 30.017, 30.011,
      30.009, 30.014, 30.008, 30.016, 30.010, 30.013, 30.007, 30.018, 30.012, 30.015
    ],
    inspectionDate: '2026-09-22',
    inspector: 'Qualitätsmanager Dipl.-Ing. T. Gruber',
    status: 'FREIGEGEBEN'
  },
  cmmPoints: [
    { id: 'CMM-BRK-01', feature: 'Reibring Außendurchmesser 0°', nominal: 340.00, actual: 340.04, toleranceUpper: 0.20, toleranceLower: -0.20, deviation: 0.04, unit: 'mm', status: 'PASS', coordinates: { x: 170, y: 0, z: 0 } },
    { id: 'CMM-BRK-02', feature: 'Topfhöhe Gesamttiefe', nominal: 52.00, actual: 52.03, toleranceUpper: 0.10, toleranceLower: -0.10, deviation: 0.03, unit: 'mm', status: 'PASS', coordinates: { x: 0, y: 0, z: 52 } },
    { id: 'CMM-BRK-03', feature: 'Lochkreis 5x112mm Teilung', nominal: 112.00, actual: 112.008, toleranceUpper: 0.05, toleranceLower: -0.05, deviation: 0.008, unit: 'mm', status: 'PASS', coordinates: { x: 56, y: 0, z: 25 } },
    { id: 'CMM-BRK-04', feature: 'Reibflächenparallelität', nominal: 0.00, actual: 0.004, toleranceUpper: 0.010, toleranceLower: 0.00, deviation: 0.004, unit: 'mm', status: 'PASS', coordinates: { x: 120, y: 50, z: 0 } }
  ],
  simulationParams: {
    appliedLoadKN: 38.5,
    loadType: 'Torsion',
    operatingRpm: 1200,
    ambientTempC: 25,
    operatingHours: 850,
    lubricationCondition: 'Trocken',
    coolingFlowLMin: 45.0 // Luftdurchsatz m³/h
  },
  simulationResult: {
    vonMisesStressMaxMPa: 185.0,
    yieldStrengthRatio: 0.74,
    factorOfSafety: 1.35,
    displacementMaxMm: 0.048,
    operatingTempMaxC: 485.0,
    thermalGradientCPerMm: 12.4,
    contactPressureMaxMPa: 4.8,
    accumulatedCycles: 145000,
    fatigueDamagePercent: 22.1,
    remainingUsefulLifeHours: 3200,
    wearDepthMicrons: 142.0,
    vibrationRmsMmS: 1.15,
    status: 'NORMAL'
  },
  traceability: [
    {
      id: 'EVT-BRK-01',
      partId: 'tw-part-de-002173',
      batch: 'CH-2026-0720-BRK',
      timestamp: '2026-09-21 04:00:00',
      eventType: 'MATERIAL_WEG',
      title: 'Eisenguss-Schmelze Chargenanalyse GG-25',
      location: 'Eisenwerk Brühl Schmelzofen 4',
      operatorOrSystem: 'Q-Control Spektrometrie',
      parameters: { 'C-Gehalt': '3.25%', 'Si-Gehalt': '1.85%', 'Zugfestigkeit': '265 MPa' },
      status: 'ERFOLG'
    },
    {
      id: 'EVT-BRK-02',
      partId: 'tw-part-de-002173',
      batch: 'CH-2026-0720-BRK',
      timestamp: '2026-09-22 13:40:00',
      eventType: 'CNC_DREHEN_FERTIG',
      title: 'Präzisionsdrehen & Dynamische Wuchtung 1.2g mm',
      location: 'TEILWERK Werk 2 Schweinfurt',
      operatorOrSystem: 'Schenck RoTec System',
      parameters: { 'Restunwucht': '0.85 g·cm (Soll < 2.0 g·cm)', 'Planlauf': '0.007 mm' },
      status: 'ERFOLG'
    },
    {
      id: 'EVT-BRK-03',
      partId: 'tw-part-de-002173',
      batch: 'CH-2026-0720-BRK',
      timestamp: '2026-09-23 09:15:00',
      eventType: 'CMM_PRUEFUNG_BESTANDEN',
      title: 'ECE R90 Bremsprüfstand Heißtest bestanden',
      location: 'TÜV Süd Prüflabor Garching',
      operatorOrSystem: 'Dyno Inertia Brake Bench 450kW',
      parameters: { 'Reibwert µ': '0.41', 'Fadingverlust': '< 4.5%', 'Rissbildung': 'Keine' },
      status: 'ERFOLG',
      documentRef: 'DOC-ECE-R90-340'
    }
  ],
  documents: [
    {
      id: 'DOC-BRK-CAD',
      title: '3D-Solid STEP AP242 Bremsscheibe belüftet',
      documentType: 'CAD_STEP',
      format: 'STEP / IGES',
      sizeBytes: 8900000,
      version: '2.1',
      date: '2025-11-20',
      author: 'Abt. Fahrwerkssysteme',
      classification: 'INTERN',
      hash: 'sha256:398c14890184b912a77810dfc99182a47710bcf19a84'
    },
    {
      id: 'DOC-BRK-ECE',
      title: 'ECE R90 Typgenehmigungs-Gutachten E1-90R-02173',
      documentType: 'WERKSZEUGNIS_3_1',
      format: 'PDF / DIN',
      sizeBytes: 1450000,
      version: '1.0',
      date: '2026-01-15',
      author: 'Kraftfahrt-Bundesamt Flensburg',
      classification: 'OEFFENTLICH',
      hash: 'sha256:7729910bf992147acb891823490182390141bcde'
    }
  ],
  compatibilities: [
    {
      relatedPartId: 'tw-part-de-003310',
      relatedPartNumber: 'TW-CAL-003310',
      relatedPartName: '4-Kolben Monoblock Bremssattel EN-GJS-500',
      relationshipType: 'KOMPATIBLE_BAUGRUPPE',
      notes: 'Passend für Reibringhöhe 64mm'
    }
  ],
  compatibleAssemblies: [
    'Radträger- & Achsbaugruppe Vorne (TW-ASY-VA-01)',
    'Hochleistungs-Bremsmodul 340mm (TW-ASY-BRK-02)'
  ],
  compatibleMachinesOrVehicles: [
    'TW-EV-PLATFORM-2026 (Elektro-Sportlimousine)',
    'TW-GT-COUPE-2025 (Hochleistungs-Coupé)'
  ]
};

// Primary Reference Showcase Part 3: Precision Helical Gear Z=48
export const SHOWCASE_PART_HELICAL_GEAR: PartTwin = {
  id: 'tw-part-de-008921',
  partNumber: 'TW-GRB-008921',
  name: 'Präzisions-Schrägzahnrad Z=48 Modul 2.5 DIN 3962 (Q5)',
  germanCategory: 'Antriebsstrang',
  category: 'INDUSTRIAL',
  subCategory: 'Getriebebau & Verzahnungstechnik',
  description: 'Hochleistungs-Schrägzahnrad mit Schrägungswinkel β = 17.5° rechtssteigend, einsatzgehärteter Verzahnungsqualität 5 nach DIN 3962 mit profil- und längskorrigierter Zahnflanke zur Optimierung des Tragbildes unter Volllast im Industriegetriebebau.',
  manufacturer: 'TEILWERK Antriebstechnik GmbH',
  manufacturingSite: 'Werk 3 — Verzahnungszentrum Friedrichshafen',
  supplier: 'Georgsmarienhütte (Stahl) / Klingelnberg',
  supplierLocation: 'Georgsmarienhütte / Hückeswagen, Deutschland',
  batch: 'CH-2026-0901-Z48',
  serialRange: 'SN-Z48-12000 ... 12499',
  currentRevision: 'REV C',
  revisions: [
    {
      revision: 'REV C',
      releaseDate: '2026-03-05',
      status: 'Freigegeben',
      author: 'Dr.-Ing. W. Kienzle',
      approvedBy: 'Prof. Dr. H. Winter',
      changeSummary: 'Kopf- und Fußrücknahme (Tip/Root Relief) um 6 µm optimiert zur Vermeidung von Kantenträgern bei Achsverschränkung.',
      diffs: [
        { field: 'surfaceHardness', oldValue: '58 HRC', newValue: '61 HRC', changeReason: 'Verlängerung Grübchenlebensdauer', author: 'W. Kienzle', date: '2026-03-01' }
      ]
    }
  ],
  massKg: 2.15,
  dimensionsMm: {
    outerDiameter: 125.600,
    innerDiameter: 35.000,
    width: 32.000,
    length: 32.000,
    boreCount: 1 // Passfedernut DIN 6885
  },
  keyDimensions: [
    { label: 'Kopfkreisdurchmesser d_a', nominal: 125.600, toleranceUpper: 0.000, toleranceLower: -0.050, unit: 'mm', measured: 125.578, datum: 'A' },
    { label: 'Teilkreisdurchmesser d', nominal: 120.000, toleranceUpper: 0.020, toleranceLower: -0.020, unit: 'mm', measured: 120.005 },
    { label: 'Passbohrung Ø d_i (H7)', nominal: 35.000, toleranceUpper: 0.025, toleranceLower: 0.000, unit: 'mm', measured: 35.012, datum: 'B' },
    { label: 'Profil-Gesamtabweichung F_alpha', nominal: 0.000, toleranceUpper: 0.006, toleranceLower: 0.000, unit: 'µm', measured: 0.0042, datum: 'A-B' },
    { label: 'Zahnweitenmaß W_k (k=7)', nominal: 48.825, toleranceUpper: 0.000, toleranceLower: -0.022, unit: 'mm', measured: 48.814 }
  ],
  material: MATERIALS_CATALOG['16MnCr5'],
  toleranceClass: 'DIN 3962 / ISO 1328 Verzahnungsqualität 5',
  surfaceFinish: 'Ra 0.3 µm (Zahnflanken geschliffen) / Rz 1.8 µm',
  coating: 'Kugelgestrahlt zur Druckeigenspannungserhöhung (Shot Peening)',
  operatingTemperatureRange: { minC: -20, maxC: 130 },
  maxOperatingRpm: 6500,
  maxDynamicLoadKN: 28.5,
  inspectionStatus: 'PASS',
  qualityStatus: '100% OK',
  lifecycleStatus: 'SERIE',
  inventoryStatus: 'VERFÜGBAR',
  stockQuantity: 340,
  reservedQuantity: 85,
  minStockThreshold: 100,
  reorderQuantity: 300,
  warehouseLocation: 'Halle 4, Gang D, Fach 22-04',
  unitCostEur: 94.50,
  leadTimeDays: 12,
  embodiedCO2Kg: 5.70,
  recyclabilityPercent: 99.8,
  geometryType: 'HELICAL_GEAR_Z48',
  manufacturingRoute: [
    {
      stepNumber: 10,
      name: 'Gesenkschmieden & Normalglühen (+N)',
      processType: 'Zuschnitt',
      machine: 'Lasco 2500t Hydraulik-Gesenkpresse',
      machineId: 'FORG-LAS-01',
      facility: 'Halle 1 — Schmiede',
      cycleTimeSec: 65,
      operatorStatus: 'Automatisiert (CNC)',
      energyKWh: 3.20,
      tool: 'Warmarbeitsstahl 1.2344 Gesenk',
      toolWearPercent: 12,
      temperatureC: 1150,
      scrapRatePercent: 0.40,
      status: 'Abgeschlossen',
      qualityResult: 'OK',
      timestamp: '2026-09-20 06:00'
    },
    {
      stepNumber: 20,
      name: 'CNC-Wälzfräsen der Schrägverzahnung',
      processType: 'Fräsen',
      machine: 'Liebherr LC 180 Verzahnungszentrum',
      machineId: 'GEAR-LIEB-01',
      facility: 'Halle 3 — Verzahnung',
      cycleTimeSec: 110,
      operatorStatus: 'Roboterzelle',
      energyKWh: 1.85,
      tool: 'PM-HSS Wälzfräser TiAlN beschichtet',
      toolWearPercent: 22,
      temperatureC: 45,
      scrapRatePercent: 0.15,
      status: 'Abgeschlossen',
      qualityResult: 'OK',
      timestamp: '2026-09-20 09:30'
    },
    {
      stepNumber: 30,
      name: 'Einsatzhärten (Aufkohlen 930°C / CHD 0.8mm)',
      processType: 'Härten',
      machine: 'Aichelin Mehrzweck-Kammerofen',
      machineId: 'HT-CARB-01',
      facility: 'Halle 1 — Härterei',
      cycleTimeSec: 480,
      operatorStatus: 'Autonom',
      energyKWh: 6.20,
      tool: 'Endogas C-Pegel 0.95% Überwachung',
      toolWearPercent: 0,
      temperatureC: 930,
      scrapRatePercent: 0.20,
      status: 'Abgeschlossen',
      qualityResult: 'OK',
      timestamp: '2026-09-20 18:00'
    },
    {
      stepNumber: 40,
      name: 'Klingelnberg Wälzschleifen der Zahnflanken',
      processType: 'Schleifen',
      machine: 'Klingelnberg Höfler Viper 500',
      machineId: 'GRIND-KLING-01',
      facility: 'Halle 3 — Feinschleiferei',
      cycleTimeSec: 85,
      operatorStatus: 'Automatisiert (CNC)',
      energyKWh: 1.45,
      tool: 'Galvanisch belegte CBN-Schnecke',
      toolWearPercent: 14,
      temperatureC: 22,
      scrapRatePercent: 0.08,
      status: 'Abgeschlossen',
      qualityResult: 'OK',
      timestamp: '2026-09-21 11:00'
    },
    {
      stepNumber: 50,
      name: 'Verzahnungs-Messzentrum 100% DIN 3962',
      processType: 'Prüfung',
      machine: 'Klingelnberg P 26 Präzisionsmesszentrum',
      machineId: 'QC-GEAR-01',
      facility: 'Messraum Klasse 1',
      cycleTimeSec: 40,
      operatorStatus: 'Autonom',
      energyKWh: 0.18,
      tool: '3D Scanning Tastkopf 3D-SP',
      toolWearPercent: 1,
      temperatureC: 20.0,
      scrapRatePercent: 0.02,
      status: 'Abgeschlossen',
      qualityResult: 'OK',
      timestamp: '2026-09-21 14:30'
    }
  ],
  spcData: {
    batchId: 'CH-2026-0901-Z48',
    sampleSize: 25,
    characteristic: 'Zahnweitenmaß W_k (48.825 mm -0.022)',
    unit: 'mm',
    target: 48.814,
    usl: 48.825,
    lsl: 48.803,
    mean: 48.8142,
    stdDev: 0.0018,
    cp: 2.04,
    cpk: 1.82,
    defectRatePpm: 0.12,
    measurements: [
      48.814, 48.816, 48.813, 48.815, 48.812, 48.816, 48.814, 48.815, 48.813, 48.817,
      48.814, 48.815, 48.812, 48.816, 48.814, 48.815, 48.813, 48.816, 48.814, 48.815,
      48.813, 48.816, 48.814, 48.815, 48.813
    ],
    inspectionDate: '2026-09-21',
    inspector: 'Verzahnungsprüfer Dr.-Ing. W. Kienzle',
    status: 'FREIGEGEBEN'
  },
  cmmPoints: [
    { id: 'CMM-GRB-01', feature: 'Teilkreisdurchmesser', nominal: 120.00, actual: 120.005, toleranceUpper: 0.020, toleranceLower: -0.020, deviation: 0.005, unit: 'mm', status: 'PASS', coordinates: { x: 60, y: 0, z: 16 } },
    { id: 'CMM-GRB-02', feature: 'Passungsbohrung Ø 35 H7', nominal: 35.00, actual: 35.012, toleranceUpper: 0.025, toleranceLower: 0.000, deviation: 0.012, unit: 'mm', status: 'PASS', coordinates: { x: 17.5, y: 0, z: 16 } },
    { id: 'CMM-GRB-03', feature: 'Planlauf Stirnfläche', nominal: 0.00, actual: 0.003, toleranceUpper: 0.008, toleranceLower: 0.00, deviation: 0.003, unit: 'mm', status: 'PASS', coordinates: { x: 50, y: 20, z: 32 } }
  ],
  simulationParams: {
    appliedLoadKN: 24.0,
    loadType: 'Torsion',
    operatingRpm: 2800,
    ambientTempC: 30,
    operatingHours: 6400,
    lubricationCondition: 'Optimal (ISO VG 68)',
    coolingFlowLMin: 8.0
  },
  simulationResult: {
    vonMisesStressMaxMPa: 520.0,
    yieldStrengthRatio: 0.76,
    factorOfSafety: 1.31,
    displacementMaxMm: 0.022,
    operatingTempMaxC: 78.5,
    thermalGradientCPerMm: 2.1,
    contactPressureMaxMPa: 1180.0,
    accumulatedCycles: 1075200000,
    fatigueDamagePercent: 18.4,
    remainingUsefulLifeHours: 28400,
    wearDepthMicrons: 1.25,
    vibrationRmsMmS: 0.82,
    status: 'NORMAL'
  },
  traceability: [
    {
      id: 'EVT-GRB-01',
      partId: 'tw-part-de-008921',
      batch: 'CH-2026-0901-Z48',
      timestamp: '2026-09-19 09:00:00',
      eventType: 'MATERIAL_WEG',
      title: 'Stahl-Einsatzqualität 16MnCr5 Schmelze GMH-4410',
      location: 'Georgsmarienhütte → TEILWERK Werk 3',
      operatorOrSystem: 'Qualitätsstelle GMH',
      parameters: { 'CHD-Eignung': '0.9 mm', 'Reinheit': 'DIN 50602 K1 <= 5' },
      status: 'ERFOLG'
    },
    {
      id: 'EVT-GRB-02',
      partId: 'tw-part-de-008921',
      batch: 'CH-2026-0901-Z48',
      timestamp: '2026-09-21 14:30:00',
      eventType: 'CMM_PRUEFUNG_BESTANDEN',
      title: 'Verzahnungs-Prüfprotokoll DIN 3962 Qualität 5',
      location: 'Klingelnberg P26 Messzentrum',
      operatorOrSystem: 'Klingelnberg Gear Software 6.1',
      parameters: { 'F_p Gesamtabweichung': '5.2 µm', 'f_f Profilform': '2.1 µm' },
      status: 'ERFOLG',
      documentRef: 'DOC-GEAR-QC-0901'
    }
  ],
  documents: [
    {
      id: 'DOC-GRB-CAD',
      title: '3D-STEP Schrägzahnrad Z=48 Modul 2.5',
      documentType: 'CAD_STEP',
      format: 'STEP / IGES',
      sizeBytes: 5400000,
      version: '3.0',
      date: '2026-03-05',
      author: 'Konstruktion Getriebebau',
      classification: 'INTERN',
      hash: 'sha256:8891acbe89124a991823901bcdae890184b912a77'
    }
  ],
  compatibilities: [
    {
      relatedPartId: 'tw-part-de-008922',
      relatedPartNumber: 'TW-GRB-008922',
      relatedPartName: 'Ritzelwelle Z=16 Modul 2.5 Gegenrad',
      relationshipType: 'KOMPATIBLE_BAUGRUPPE',
      notes: 'Übersetzungsverhältnis i = 3.00, Achsabstand a = 80.00 mm'
    }
  ],
  compatibleAssemblies: [
    '2-Stufen Stirnrad-Industriegetriebe 45kW (TW-ASY-GB-01)',
    'Hauptspindel 12.000 RPM Bearbeitungszentrum (TW-ASY-SP-04)'
  ],
  compatibleMachinesOrVehicles: [
    'TW-CNC-HSC800 (5-Achs-HSC-Fräszentrum)',
    'TW-ROBOT-6AXIS-300 (Schwerlast-Industrieroboter 300kg)'
  ]
};

// Synthetic generator for 100+ comprehensive parts
function generateSyntheticPartsCatalog(): PartTwin[] {
  const parts: PartTwin[] = [
    SHOWCASE_PART_BEARING,
    SHOWCASE_PART_BRAKE_DISC,
    SHOWCASE_PART_HELICAL_GEAR
  ];

  const categoriesConfig: {
    cat: 'AUTOMOTIVE' | 'INDUSTRIAL' | 'ELECTRICAL';
    germanCat: PartTwin['germanCategory'];
    subCats: string[];
    materialKeys: string[];
    geometryTypes: PartTwin['geometryType'][];
    prefix: string;
    items: { name: string; desc: string; mass: number; cost: number }[];
  }[] = [
    {
      cat: 'AUTOMOTIVE',
      germanCat: 'Antriebsstrang',
      subCats: ['Kurbeltrieb', 'Ventilsteuerung', 'Getriebe', 'Kühlsystem', 'E-Traktion'],
      materialKeys: ['42CrMo4', '16MnCr5', 'EN AW-7075', 'EN-GJL-250'],
      geometryTypes: ['CONNECTING_ROD', 'DRIVE_SHAFT', 'HELICAL_GEAR_Z48', 'ELECTRIC_MOTOR'],
      prefix: 'TW-AUT',
      items: [
        { name: 'Geschmiedete Pleuelstange H-Schaft 144mm', desc: 'Hochfeste H-Schaft Pleuelstange für Turbomotoren mit gecracktem Pleuelauge.', mass: 0.540, cost: 72.00 },
        { name: 'Schmiedekurbelwelle 4-Zylinder 82mm Hub', desc: 'Induktiv gehärtete Kurbelwelle mit 8 Ausgleichsgewichten.', mass: 14.80, cost: 340.00 },
        { name: 'Einlass-Nockenwelle Hohlbauweise', desc: 'Gebaute Nockenwelle mit gefügten Nocken aus 100Cr6 auf Präzisionsstahlrohr.', mass: 2.30, cost: 115.00 },
        { name: 'Auslassventil Bimetall Natriumgekühlt', desc: 'Hohlventil mit Natriumfüllung zur Temperaturreduktion am Ventilteller bis 800°C.', mass: 0.085, cost: 28.50 },
        { name: 'Schmiedekolben Ø 84.0mm mit Ringträger', desc: 'Hochtemperaturfester Aluminiumkolben mit graphitbeschichtetem Kolbenhemd.', mass: 0.380, cost: 84.00 },
        { name: 'Zweimassen-Schwungrad (ZMS) 240mm', desc: 'Torsionsdämpfendes ZMS mit Bogenfedern zur Reduktion von Drehungleichförmigkeiten.', mass: 11.20, cost: 260.00 },
        { name: 'Synchronkörper 3./4. Gang mit Molybdänbelag', desc: 'Präzisions-Synchronring für Doppelkupplungsgetriebe.', mass: 0.420, cost: 45.00 },
        { name: 'Differential-Ausgleichsgehäuse EN-GJS-500', desc: 'Sphärogussgehäuse für Kegelraddifferential der Hinterachse.', mass: 4.60, cost: 98.00 },
        { name: 'Antriebswelle Hohlwelle 42CrMo4 mit Gleichlaufgelenk', desc: 'Drehsteife Gelenkwelle für Drehmomente bis 3.200 Nm.', mass: 5.80, cost: 165.00 },
        { name: 'Permanenterregter Synchronmotor Rotor 150kW', desc: 'Rotor mit vergrabenen NdFeB-Magneten in V-Anordnung für 16.000 RPM.', mass: 18.50, cost: 680.00 },
        { name: 'Statorgehäuse mit integriertem Kühlmantel', desc: 'Aluminium-Stranggussprofil mit schraubenförmigem Wassermantel.', mass: 12.40, cost: 290.00 },
        { name: 'Siliziumkarbid (SiC) 800V Inverter-Modul', desc: 'Hochfrequente Leistungselektronik für 450A Dauerstrom mit Direktkühlung.', mass: 3.20, cost: 890.00 },
        { name: 'Elektrische Hochvolt-Kühlmittelpumpe 12V/400W', desc: 'Bürstenlose Magnetkupplungspumpe für Batteriethermomanagement.', mass: 1.45, cost: 140.00 },
        { name: 'Kurbelgehäuse Alu-Druckguss mit Graugussbuchsen', desc: 'Closed-Deck Zylinderkurbelgehäuse für 2.0L Reihenvierzylinder.', mass: 32.00, cost: 820.00 },
        { name: 'Turbolader-Turbinenrad Inconel 713C', desc: 'Hochtemperatur-Feingussrad für Abgastemperaturen bis 1050°C.', mass: 0.220, cost: 135.00 },
        { name: 'Ölpumpen-Rotorpaar Durox Sinterstahl', desc: 'Zykloiden-Rotorsatz für variable Öldruckregelung.', mass: 0.180, cost: 19.50 },
        { name: 'Hochdruck-Einspritzventil 350 bar Benzin', desc: 'Piezo-Mehrlocheinspritzventil mit Schaltzeiten unter 0.1 ms.', mass: 0.110, cost: 78.00 },
        { name: 'Zahnriemen-Spannrolle mit Exzenterlager', desc: 'Automatisches Spannsystem mit gedämpfter Drehfeder.', mass: 0.410, cost: 32.00 },
        { name: 'Abgaskrümmer Edelstahl 1.4828 hydrogeformt', desc: 'Luftspaltisolierter Blechkrümmer für schnelles Katalysatoransprechverhalten.', mass: 2.80, cost: 185.00 },
        { name: 'Katalysator-Monolith Metallträger 600 cpsi', desc: 'Edelmetallbeschichteter Edelstahl-Wabenkörper Pt/Rh.', mass: 1.95, cost: 290.00 },
        { name: 'Schaltgabel 1./2. Gang Aluminium geschmiedet', desc: 'Gewichtsoptimierte Schaltgabel mit verschleißfesten Gleitschuhen.', mass: 0.280, cost: 38.00 },
        { name: 'Achsträger Vorne Aluminium-Schweißbaugruppe', desc: 'Leichtbau-Fahrschemel mit Anbindungspunkten für Doppelquerlenker.', mass: 14.20, cost: 420.00 },
        { name: 'Stabisatorstange Hohlrohr Ø 28x4mm 34Cr4', desc: 'Vergüteter Torsionsstabilisator für Wankabstützung.', mass: 3.40, cost: 56.00 },
        { name: 'Lenkgetriebe-Zahnstange 42CrMo4 induktivgehärtet', desc: 'Präzisionszahnstange mit variabler Übersetzung.', mass: 2.10, cost: 89.00 },
        { name: 'Radbolzen M14x1.5 Festigkeitsklasse 10.9 DIN 74361', desc: 'Phosphatierte Radschraube mit Kugelbund.', mass: 0.095, cost: 3.80 }
      ]
    },
    {
      cat: 'AUTOMOTIVE',
      germanCat: 'Fahrwerk & Bremsen',
      subCats: ['Radaufhängung', 'Bremsen', 'Lenkung', 'Dämpfung'],
      materialKeys: ['EN AW-7075', 'EN-GJS-500-7', '100Cr6', '42CrMo4'],
      geometryTypes: ['BRAKE_DISC_VENTED', 'CONNECTING_ROD', 'BEARING_6208', 'DRIVE_SHAFT'],
      prefix: 'TW-CHS',
      items: [
        { name: 'Querlenker Oben Aluminium-Schmiedeteil EN AW-7075', desc: 'Leichtbau-Fahrwerkslenker mit integrierten Hydrobuchsen.', mass: 1.85, cost: 110.00 },
        { name: 'Radträger Schwenklager Vorne EN-GJS-500', desc: 'Duktiler Sphäroguss-Radträger für Fünflenker-Vorderachse.', mass: 4.80, cost: 145.00 },
        { name: 'Radnabe 5-Loch Aluminium geschmiedet', desc: 'Präzisions-Radnabe mit integrierter ABS-Inkrementverzahnung.', mass: 1.65, cost: 85.00 },
        { name: '4-Kolben Festsattel Aluminium Monoblock', desc: 'Aus einem Block gefräster Bremssattel für 340-380mm Scheiben.', mass: 3.20, cost: 240.00 },
        { name: 'Bremsbelagsatz Keramik-Reibbelag ECE-R90', desc: 'Staubreduzierter Hochtemperatur-Bremsbelagsatz mit Shims.', mass: 1.10, cost: 65.00 },
        { name: 'Luftfederbein Dämpfermodul adaptiv CDC', desc: 'Elektronisch verstellbarer Einrohr-Stoßdämpfer mit Luftbalg.', mass: 7.40, cost: 480.00 },
        { name: 'Spurstange mit Kugelgelenk wartungsfrei', desc: 'Vergüteter Spurstangenkopf mit Dichtbalg aus Polyurethan.', mass: 0.720, cost: 34.00 },
        { name: 'Elektrische Parkbremse (EPB) Aktuator 12V', desc: 'Motor-on-Caliper Getriebemotor mit Planetenstufe.', mass: 0.680, cost: 58.00 },
        { name: 'Torsionslenker Hinterachse Verbundlenker', desc: 'U-Profil Achskörper aus hochfestem Stahlrohr CP-W 800.', mass: 16.50, cost: 210.00 },
        { name: 'Bremsschlauch Stahlflex PTFE DIN ISO 3996', desc: 'Druckfester Edelstahldraht-umflochtener Bremsschlauch 400 bar.', mass: 0.140, cost: 22.00 }
      ]
    },
    {
      cat: 'INDUSTRIAL',
      germanCat: 'Hydraulik & Pneumatik',
      subCats: ['Ventile', 'Zylinder', 'Pumpen', 'Dichtungen'],
      materialKeys: ['1.4404', '42CrMo4', 'EN AW-7075', 'PEEK-CF30'],
      geometryTypes: ['HYDRAULIC_VALVE', 'CYLINDER_PISTON', 'DRIVE_SHAFT', 'GENERIC_MECHANICAL'],
      prefix: 'TW-HYD',
      items: [
        { name: '4/3-Wege-Proportional-Hydraulikventil NG6', desc: 'Direktgesteuertes Schieberventil mit digitaler On-Board-Elektronik bis 315 bar.', mass: 2.40, cost: 420.00 },
        { name: 'Hydraulik-Differentialzylinder 80/45 Hub 300mm', desc: 'Industriezylinder nach ISO 6022 für 250 bar Betriebsdruck.', mass: 12.80, cost: 360.00 },
        { name: 'Axialkolbenpumpe Schrägscheibe 71 cm³/U', desc: 'Verstellpumpe für offene Kreisläufe im Maschinenbau bis 350 bar.', mass: 34.00, cost: 1450.00 },
        { name: 'Hochdruck-Filterblock 400 bar mit Differenzdruckanzeige', desc: 'Leitungsfilter mit Glasfaservlies-Element 3 µm absolut.', mass: 4.20, cost: 180.00 },
        { name: 'Pneumatikzylinder ISO 15552 Profilrohr Ø 63 Hub 160', desc: 'Pneumatischer Doppelwirkungszylinder mit Endlagendämpfung.', mass: 2.10, cost: 95.00 },
        { name: 'Druckregelventil vorgesteuert NG10 350 bar', desc: 'Schraubpatronen-Druckbegrenzungsventil mit interner Dämpfung.', mass: 0.950, cost: 145.00 },
        { name: 'Hydraulik-Speicherblase 4.0L 330 bar N2', desc: 'Blasenspeicher zur Druckstoßdämpfung und Energiereserve.', mass: 9.80, cost: 280.00 },
        { name: 'Hydraulik-Flansch SAE 6000 PSI 1-1/4" 1.4404', desc: 'Hochdruck-Schweißflansch nach ISO 6162-2 aus Edelstahl.', mass: 1.35, cost: 64.00 },
        { name: 'Stangendichtung PTFE/Bronze mit O-Ring Vorspannelement', desc: 'Reibungsarme Tandemdichtung für Geschwindigkeiten bis 5 m/s.', mass: 0.025, cost: 18.00 },
        { name: 'Pneumatische Ventilinsel 8-fach EtherCAT', desc: 'Kompakte Ventilbaugruppe mit IP65 Busknoten für Industrie 4.0.', mass: 1.85, cost: 560.00 },
        { name: 'Hydraulischer Drehantrieb Schwenkmotor 180°', desc: 'Kompakter Zahnstangen-Schwenkantrieb für 1.200 Nm Drehmoment.', mass: 14.50, cost: 790.00 },
        { name: 'Kompakt-Hydraulikaggregat 3.0 kW 210 bar 10L', desc: 'Steckerfertiges Unterölaggregat für Werkzeugmaschinen-Spannsysteme.', mass: 28.00, cost: 1120.00 },
        { name: 'Proportional-Druckminderventil NG6 Sandwichplatte', desc: 'Zwischenplattenventil zur sekundären Druckabsicherung.', mass: 1.90, cost: 310.00 },
        { name: 'Drosselrückschlagventil Rohrleitungsmontage G 1/2"', desc: 'Feinfühlig einstellbares Drosselventil mit Mikrometerskala.', mass: 0.480, cost: 42.00 },
        { name: 'Hydraulikschlauch 4-Spiralig EN 856 4SP DN16 400 bar', desc: 'Hochflexibler Höchstdruckschlauch mit verpressten Armaturen.', mass: 1.15, cost: 48.00 }
      ]
    },
    {
      cat: 'INDUSTRIAL',
      germanCat: 'Maschinenelemente',
      subCats: ['Wälzlager', 'Lineartechnik', 'Kupplungen', 'Spindeln', 'Robotik'],
      materialKeys: ['100Cr6', '16MnCr5', '42CrMo4', 'EN AW-7075'],
      geometryTypes: ['BEARING_6208', 'HELICAL_GEAR_Z48', 'DRIVE_SHAFT', 'GENERIC_MECHANICAL'],
      prefix: 'TW-MEC',
      items: [
        { name: 'Zylinderrollenlager N308 ECP DIN 5412', desc: 'Hochbelastbares Radiallager mit glasfaserverstärktem PA66-Käfig.', mass: 0.480, cost: 38.00 },
        { name: 'Kegelrollenlager 32008 X DIN 720', desc: 'Kombiniertes Radial-/Axiallager für Getriebe-Vorgelegewellen.', mass: 0.390, cost: 26.50 },
        { name: 'Kugelgewindetrieb Ø 32 Steigung 10 Hub 600mm', desc: 'Geschliffener Kugelgewindetrieb Toleranzklasse IT3 mit Doppelmutter.', mass: 5.40, cost: 580.00 },
        { name: 'Profilschienenführung Baubreite 25 Präzision P', desc: 'Vierreihige Kugelumlaufführung mit vorgespanntem Führungswagen.', mass: 3.80, cost: 195.00 },
        { name: 'Balgkupplung spielfrei Drehmoment 200 Nm', desc: 'Torsionssteife Metallbalgkupplung mit Klemmnaben für Servomotoren.', mass: 0.920, cost: 145.00 },
        { name: 'Klauenkupplung elastisch Rotex 38 mit 98 ShA Zahnkranz', desc: 'Dämpfende Wellenkupplung für Hauptantriebe bis 600 Nm.', mass: 1.75, cost: 68.00 },
        { name: 'Robotergelenk Harmonic Drive Getriebesatz CSG-25-100', desc: 'Spielfreies Wellgetriebe für Roboterachse mit Untersetzung 1:100.', mass: 1.10, cost: 740.00 },
        { name: '2-Backen-Parallelgreifer pneumatisch Hub 20mm', desc: 'Präzisionsgreifer mit T-Nutenführung und Sensorabfrage.', mass: 0.850, cost: 230.00 },
        { name: 'Magnetspannfutter Ø 250mm Feinstpolteilung', desc: 'Permanentspannplatte für Flachschleifmaschinen.', mass: 18.00, cost: 890.00 },
        { name: 'Drehstrom-Asynchronmotor 7.5kW IE4 Effizienzklasse', desc: 'Graugussmotor 4-polig 1475 RPM für Dauerbetrieb S1.', mass: 64.00, cost: 720.00 },
        { name: 'Gleitringdichtung Cartridge 1.4404 SiC/SiC Ø 45mm', desc: 'Wartungsfreie Patronendichtung für Chemie-Kreiselpumpen.', mass: 1.80, cost: 310.00 },
        { name: 'Pendelrollenlager 22210 E DIN 635-2', desc: 'Selbsteinstellendes Wälzlager für Schiefstellungen bis 2°.', mass: 0.620, cost: 46.00 },
        { name: 'Spannsatz RCK 40 selbstzentrierend Ø 35x60', desc: 'Spielfreie Welle-Nabe-Verbindung für hohe Drehmomente.', mass: 0.440, cost: 39.00 },
        { name: 'Schneckenradsatz i=30 Achsabstand 63mm CuSn12Ni2', desc: 'Verschleißarmer Bronze-Schneckenradsatz mit geschliffener Schnecke.', mass: 3.10, cost: 210.00 },
        { name: 'Spindellager-Satz HCB7010-C-T-P4S Hybrid-Keramik', desc: 'Präzisions-Schrägkugellager mit Si3N4 Keramikkugeln bis 24.000 RPM.', mass: 0.280, cost: 340.00 },
        { name: 'Kegelradpaar spiralförmig Palloid-Verzahnung i=2', desc: 'Gepaart geläppter Spiralkegelradsatz aus 18CrNiMo7-6.', mass: 4.20, cost: 380.00 },
        { name: 'Schwingungsdämpfer Parabelpuffer Gummi-Metall M10', desc: 'Maschinenfuß zur Isolierung von Körperschall und Vibrationen.', mass: 0.320, cost: 16.50 },
        { name: 'Passfeder DIN 6885 Form A 10x8x56 42CrMo4', desc: 'Vergütete Antriebspassfeder mit gerundeten Stirnseiten.', mass: 0.035, cost: 2.10 },
        { name: 'Wellendichtring DIN 3760 Form AS 40x62x8 FKM', desc: 'Fluorkautschuk-Simmerring mit Staublippe für Temperaturen bis 200°C.', mass: 0.028, cost: 8.90 },
        { name: 'Präzisions-Stellmutter M35x1.5 mit Sicherungsstiften', desc: 'Feingewindemutter zum axialen Vorspannen von Spindellagern.', mass: 0.160, cost: 24.00 }
      ]
    },
    {
      cat: 'ELECTRICAL',
      germanCat: 'Elektrik & Sensorik',
      subCats: ['Sensoren', 'Leistungselektronik', 'Schaltgeräte', 'Verbindungstechnik'],
      materialKeys: ['1.4404', 'EN AW-7075', 'PEEK-CF30'],
      geometryTypes: ['ELECTRIC_MOTOR', 'GENERIC_MECHANICAL', 'HYDRAULIC_VALVE'],
      prefix: 'TW-ELC',
      items: [
        { name: 'Induktiver Näherungsschalter M18 Schaltabstand 8mm', desc: 'Vollmetall-Edelstahlsensor IP68/IP69K mit IO-Link Schnittstelle.', mass: 0.085, cost: 68.00 },
        { name: 'Optischer Distanzsensor Laser Time-of-Flight 10m', desc: 'Messender Lasersensor mit Millimetergenauigkeit und 1 kHz Messrate.', mass: 0.160, cost: 240.00 },
        { name: 'Schwingungssensor IEPE 3-Achsen Beschleunigungsaufnehmer', desc: 'Piezoelektrischer Schwingungswächter für Condition Monitoring.', mass: 0.065, cost: 310.00 },
        { name: 'Sicherheits-Schaltrelais 24V DC 3 Schließer SIL 3', desc: 'Zwangsgeführtes Sicherheitsrelais nach DIN EN ISO 13849-1 PLe.', mass: 0.220, cost: 95.00 },
        { name: 'Leistungsschütz 3-polig 45kW / 90A 400V AC3', desc: 'Robustes Hauptschütz mit elektronischer Spulenansteuerung.', mass: 0.980, cost: 135.00 },
        { name: 'Motorschutzschalter thermomagnetisch 16-25A 100kA', desc: 'Kurzschlussfester Leistungsschalter nach DIN EN 60947-2.', mass: 0.440, cost: 72.00 },
        { name: 'Industrie-Steckverbinder Han-Modular 6-fach Gehäuse', desc: 'Schwerer Alu-Druckguss-Steckverbinder für Energie & Feldbus.', mass: 0.380, cost: 54.00 },
        { name: 'Durchgangs-Reihenklemme Federkraft Push-In 2.5mm²', desc: 'Vibrationssichere Klemmenleiste nach DIN rail TS 35.', mass: 0.009, cost: 1.20 },
        { name: 'Absolut-Drehgeber Multiturn 22 Bit SSI/BiSS-C', desc: 'Optischer Hohlwellen-Encoder für Servomotoren-Lagerückführung.', mass: 0.310, cost: 380.00 },
        { name: 'Schaltnetzteil 24V DC / 20A 480W Wirkungsgrad 95.5%', desc: 'Hutschienen-Stromversorgung mit Weitbereichseingang 3AC 400V.', mass: 1.35, cost: 185.00 },
        { name: 'Temperatursensor PT1000 Klasse A Tauchhülse G 1/2"', desc: 'Platin-Widerstandsthermometer im Edelstahl-Schutzrohr 1.4571.', mass: 0.120, cost: 48.00 },
        { name: 'Drucktransmitter 0-250 bar 4-20mA 2-Leiter', desc: 'Dünnfilm-Messzelle auf Edelstahl ohne Elastomerdichtung.', mass: 0.145, cost: 125.00 },
        { name: 'Frequenzumrichter 15kW 3AC 400V IP55 Vektorregelung', desc: 'Kompakter Umrichter mit integriertem Brems-Chopper und STO.', mass: 9.20, cost: 890.00 },
        { name: 'Sicherheits-Lichtvorhang Schutzfeldhöhe 600mm Typ 4', desc: 'Optoelektronische Schutzeinrichtung mit Fingerschutz 14mm.', mass: 2.40, cost: 760.00 },
        { name: 'RFID-Schreib-/Lesekopf HF 13.56 MHz ISO 15693', desc: 'Robuster RFID-Sensor für Werkstückträger-Identifikation.', mass: 0.190, cost: 165.00 }
      ]
    },
    {
      cat: 'AUTOMOTIVE',
      germanCat: 'Struktur & Karosserie',
      subCats: ['Strukturteile', 'Verbindungselemente', 'Leichtbau'],
      materialKeys: ['EN AW-7075', '42CrMo4', '1.4404'],
      geometryTypes: ['CONNECTING_ROD', 'GENERIC_MECHANICAL'],
      prefix: 'TW-STR',
      items: [
        { name: 'Crash-Längsträger Vorne Aluminium-Mehrkammerprofil', desc: 'Extrudiertes Deformationsprofil mit definierter Faltungszone.', mass: 3.40, cost: 95.00 },
        { name: 'Federbeindom Aluminium-Druckguss Großstrukturteil', desc: 'Strukturgussteil mit hoher Steifigkeit zur Schwingungsdämpfung.', mass: 4.10, cost: 160.00 },
        { name: 'B-Säule Warmumgeformter Vergütungsstahl 22MnB5 1500MPa', desc: 'Tailored-Tempered Blechprofil mit gezielten Festigkeitszonen.', mass: 6.80, cost: 135.00 },
        { name: 'Batteriegehäuse-Bodenplatte mit integrierten Kühlkanälen', desc: 'Rollbond-Aluminium-Wärmetauscherplatte für HV-Traktionsbatterie.', mass: 22.00, cost: 580.00 },
        { name: 'Blindnietmutter M8 Sechskantschaft A4 Edelstahl', desc: 'Korrosionsfester hochfester Gewindeträger im Dünnblech.', mass: 0.012, cost: 0.85 },
        { name: 'Strukturklebstoff 2K-Epoxidharz Crash-beständig', desc: 'Hochmoduliger Fügeklebstoff für Mischbauweisen (Alu-Stahl-CFK).', mass: 0.400, cost: 24.00 },
        { name: 'Türscharnier 2-Achs geschmiedet mit Messingbuchse', desc: 'Spielfreies Scharnier für schwere Fahrzeugtüren.', mass: 0.850, cost: 32.00 },
        { name: 'Frontend-Träger Organoblech CFK/PA6 Hybrid', desc: 'Faserverstärktes thermoplastisches Trägerteil mit Anspritzgeometrie.', mass: 2.10, cost: 110.00 },
        { name: 'Schlossträger Stahlblech verzinkt HX220BD', desc: 'Lasergeschnittenes und tiefgezogenes Strukturblech.', mass: 1.70, cost: 28.00 },
        { name: 'Unterbodenschutzverkleidung GMT Glasmatten-Polypropylen', desc: 'Aerodynamische Akustik-Abdeckplatte mit Schnellverschlüssen.', mass: 2.90, cost: 45.00 }
      ]
    }
  ];

  let partCounter = 100;

  for (const catConf of categoriesConfig) {
    for (const item of catConf.items) {
      partCounter++;
      const idCode = `00${partCounter}`.slice(-6);
      const partId = `tw-part-de-${idCode}`;
      const partNumber = `${catConf.prefix}-${idCode}`;
      const matKey = catConf.materialKeys[partCounter % catConf.materialKeys.length];
      const mat = MATERIALS_CATALOG[matKey] || MATERIALS_CATALOG['100Cr6'];
      const geom = catConf.geometryTypes[partCounter % catConf.geometryTypes.length];
      const subCat = catConf.subCats[partCounter % catConf.subCats.length];

      const syntheticPart: PartTwin = {
        id: partId,
        partNumber: partNumber,
        name: item.name,
        germanCategory: catConf.germanCat,
        category: catConf.cat,
        subCategory: subCat,
        description: item.desc,
        manufacturer: 'TEILWERK Engineering & Fertigung GmbH',
        manufacturingSite: 'Werk Stuttgart / Werk Friedrichshafen',
        supplier: 'ThyssenKrupp Materials / TEILWERK Components',
        supplierLocation: 'Duisburg / Stuttgart, Deutschland',
        batch: `CH-2026-${(partCounter * 7) % 899 + 100}-S`,
        serialRange: `SN-${idCode}-001000 ... 001999`,
        currentRevision: 'REV A',
        revisions: [
          {
            revision: 'REV A',
            releaseDate: '2025-06-15',
            status: 'Freigegeben',
            author: 'Ingenieurbüro TEILWERK',
            approvedBy: 'QMS Leitung',
            changeSummary: 'Erstserienfreigabe nach PPAP Level 3 / VDA Band 2.',
            diffs: []
          }
        ],
        massKg: item.mass,
        dimensionsMm: {
          length: Math.round(item.mass * 40 + 20),
          width: Math.round(item.mass * 20 + 15),
          height: Math.round(item.mass * 15 + 10),
          outerDiameter: Math.round(item.mass * 30 + 30)
        },
        keyDimensions: [
          { label: 'Hauptabmessung L/D', nominal: Math.round(item.mass * 40 + 20), toleranceUpper: 0.05, toleranceLower: -0.05, unit: 'mm', measured: Math.round(item.mass * 40 + 20) + 0.012 },
          { label: 'Referenzpassung Ø', nominal: 25.000, toleranceUpper: 0.015, toleranceLower: 0.000, unit: 'mm', measured: 25.006, datum: 'A' },
          { label: 'Oberflächenrauheit Ra', nominal: 0.8, toleranceUpper: 0.2, toleranceLower: 0.0, unit: 'µm', measured: 0.74 }
        ],
        material: mat,
        toleranceClass: 'DIN ISO 2768-mK',
        surfaceFinish: 'Ra 0.8 µm geschliffen / feingedreht',
        coating: 'Gereinigt, passiviert & konserviert',
        operatingTemperatureRange: { minC: -40, maxC: 140 },
        maxDynamicLoadKN: Math.round(item.mass * 12 + 5),
        inspectionStatus: 'PASS',
        qualityStatus: '100% OK',
        lifecycleStatus: 'SERIE',
        inventoryStatus: 'VERFÜGBAR',
        stockQuantity: Math.round(200 + (partCounter % 15) * 50),
        reservedQuantity: Math.round(30 + (partCounter % 8) * 12),
        minStockThreshold: 50,
        reorderQuantity: 200,
        warehouseLocation: `Halle ${(partCounter % 5) + 1}, Gang ${String.fromCharCode(65 + (partCounter % 6))}, Fach ${(partCounter % 20) + 1}-0${(partCounter % 4) + 1}`,
        unitCostEur: item.cost,
        leadTimeDays: (partCounter % 10) + 3,
        embodiedCO2Kg: +(item.mass * mat.carbonFootprint).toFixed(2),
        recyclabilityPercent: 96.5,
        geometryType: geom,
        manufacturingRoute: [
          {
            stepNumber: 10,
            name: 'CNC-Zerspanung & Fräsen',
            processType: 'Fräsen',
            machine: 'DMG MORI DMU 50 5-Achs',
            machineId: 'CNC-DMG-08',
            facility: 'Zerspanungszentrum',
            cycleTimeSec: 45 + (partCounter % 30),
            operatorStatus: 'Automatisiert (CNC)',
            energyKWh: 0.65,
            tool: 'Vollhartmetall-Fräser Ø 16mm',
            toolWearPercent: 15,
            temperatureC: 24,
            scrapRatePercent: 0.1,
            status: 'Abgeschlossen',
            qualityResult: 'OK',
            timestamp: '2026-09-23 08:00'
          },
          {
            stepNumber: 20,
            name: '100% Endprüfung & Kennzeichnung',
            processType: 'Prüfung',
            machine: 'Messzentrum Zeiss DuraMax',
            machineId: 'QC-ZEISS-03',
            facility: 'Messraum',
            cycleTimeSec: 20,
            operatorStatus: 'Autonom',
            energyKWh: 0.08,
            tool: '3D Tastsystem',
            toolWearPercent: 1,
            temperatureC: 20,
            scrapRatePercent: 0.01,
            status: 'Abgeschlossen',
            qualityResult: 'OK',
            timestamp: '2026-09-23 09:30'
          }
        ],
        spcData: {
          batchId: `CH-2026-${partCounter}-S`,
          sampleSize: 20,
          characteristic: 'Hauptfunktionsmaß',
          unit: 'mm',
          target: 25.000,
          usl: 25.015,
          lsl: 24.985,
          mean: 25.004,
          stdDev: 0.0022,
          cp: 1.88,
          cpk: 1.62,
          defectRatePpm: 0.8,
          measurements: [25.003, 25.005, 25.002, 25.006, 25.004, 25.003, 25.005, 25.004, 25.002, 25.006],
          inspectionDate: '2026-09-23',
          inspector: 'Qualitätsprüfer TEILWERK',
          status: 'FREIGEGEBEN'
        },
        cmmPoints: [
          { id: 'P01', feature: 'Funktionsmaß A', nominal: 25.00, actual: 25.004, toleranceUpper: 0.015, toleranceLower: -0.015, deviation: 0.004, unit: 'mm', status: 'PASS', coordinates: { x: 12.5, y: 0, z: 0 } },
          { id: 'P02', feature: 'Planlauf B', nominal: 0.00, actual: 0.003, toleranceUpper: 0.010, toleranceLower: 0.00, deviation: 0.003, unit: 'mm', status: 'PASS', coordinates: { x: 0, y: 12.5, z: 5 } }
        ],
        simulationParams: {
          appliedLoadKN: Math.round(item.mass * 8 + 4),
          loadType: 'Radial',
          operatingRpm: 1500,
          ambientTempC: 22,
          operatingHours: 2500,
          lubricationCondition: 'Optimal (ISO VG 68)',
          coolingFlowLMin: 2.0
        },
        simulationResult: {
          vonMisesStressMaxMPa: Math.round(mat.yieldStrength * 0.45),
          yieldStrengthRatio: 0.45,
          factorOfSafety: 1.65,
          displacementMaxMm: 0.018,
          operatingTempMaxC: 52.0,
          thermalGradientCPerMm: 1.2,
          contactPressureMaxMPa: 420.0,
          accumulatedCycles: 35000000,
          fatigueDamagePercent: 8.5,
          remainingUsefulLifeHours: 35000,
          wearDepthMicrons: 0.35,
          vibrationRmsMmS: 0.45,
          status: 'NORMAL'
        },
        traceability: [
          {
            id: `EVT-${partCounter}-01`,
            partId: partId,
            batch: `CH-2026-${partCounter}-S`,
            timestamp: '2026-09-22 08:00:00',
            eventType: 'MATERIAL_WEG',
            title: `Materialeingang ${mat.name}`,
            location: 'TEILWERK Wareneingang',
            operatorOrSystem: 'SAP S/4HANA',
            parameters: { 'Werkstoff': mat.name, 'Zeugnis': '3.1 nach EN 10204' },
            status: 'ERFOLG'
          },
          {
            id: `EVT-${partCounter}-02`,
            partId: partId,
            batch: `CH-2026-${partCounter}-S`,
            timestamp: '2026-09-23 09:30:00',
            eventType: 'CMM_PRUEFUNG_BESTANDEN',
            title: 'Serienprüfung CMM freigegeben',
            location: 'Messraum TEILWERK',
            operatorOrSystem: 'Zeiss CALYPSO',
            parameters: { 'Ergebnis': '100% I.O.' },
            status: 'ERFOLG'
          }
        ],
        documents: [
          {
            id: `DOC-CAD-${idCode}`,
            title: `3D-CAD-Modell STEP ${item.name}`,
            documentType: 'CAD_STEP',
            format: 'STEP / IGES',
            sizeBytes: 3200000,
            version: '1.0',
            date: '2025-06-15',
            author: 'TEILWERK CAD',
            classification: 'INTERN',
            hash: 'sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
          }
        ],
        compatibilities: [],
        compatibleAssemblies: ['Industrie-Hauptbaugruppe A1', 'Fahrwerk-Systemmodul M4'],
        compatibleMachinesOrVehicles: ['TW-EV-PLATFORM-2026', 'TW-CNC-HSC800']
      };

      parts.push(syntheticPart);
    }
  }

  return parts;
}

export const SYNTHETIC_PARTS_DATABASE: PartTwin[] = generateSyntheticPartsCatalog();
