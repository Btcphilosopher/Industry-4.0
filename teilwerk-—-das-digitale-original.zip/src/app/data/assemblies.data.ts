import { AssemblyNode, MachineToolTwin } from '../models/part-twin.model';

export const ASSEMBLY_HIERARCHIES: AssemblyNode[] = [
  {
    id: 'NODE-VEHICLE-01',
    code: 'TW-EV-PLATFORM-2026',
    name: 'Elektro-Sportlimousine Plattform 800V',
    level: 0,
    category: 'VEHICLE',
    quantity: 1,
    massTotalKg: 2150.0,
    costTotalEur: 42500.0,
    supplier: 'TEILWERK Automotive Werk Sindelfingen',
    status: 'SERIENREIF',
    children: [
      {
        id: 'NODE-AXLE-01',
        code: 'TW-ASY-VA-01',
        name: 'Vorderachse Fünflenker-Radträgerbaugruppe Links',
        level: 1,
        category: 'ASSEMBLY',
        quantity: 1,
        massTotalKg: 38.5,
        costTotalEur: 1480.0,
        supplier: 'TEILWERK Fahrwerkssysteme Untertürkheim',
        status: 'SERIENREIF',
        children: [
          {
            id: 'NODE-PART-HUB',
            code: 'TW-CHS-000103',
            name: 'Radnabe 5-Loch Aluminium geschmiedet',
            level: 2,
            category: 'PART',
            partRefId: 'tw-part-de-000103',
            quantity: 1,
            massTotalKg: 1.65,
            costTotalEur: 85.0,
            supplier: 'TEILWERK Components',
            status: 'SERIENREIF',
            explodedOffset: { x: 0, y: 0, z: -40 }
          },
          {
            id: 'NODE-PART-BRG',
            code: 'TW-BRG-004812',
            name: '6208 Rillenkugellager DIN 625 (P5)',
            level: 2,
            category: 'PART',
            partRefId: 'tw-part-de-004812',
            quantity: 2,
            massTotalKg: 0.73,
            costTotalEur: 29.70,
            supplier: 'TEILWERK Präzision GmbH',
            status: 'SERIENREIF',
            explodedOffset: { x: 0, y: 0, z: 0 }
          },
          {
            id: 'NODE-PART-BRK',
            code: 'TW-BRK-002173',
            name: 'Innenbelüftete Bremsscheibe Ø 340mm',
            level: 2,
            category: 'PART',
            partRefId: 'tw-part-de-002173',
            quantity: 1,
            massTotalKg: 8.70,
            costTotalEur: 68.40,
            supplier: 'TEILWERK Bremsensysteme AG',
            status: 'SERIENREIF',
            explodedOffset: { x: 0, y: 0, z: 50 }
          },
          {
            id: 'NODE-PART-CAL',
            code: 'TW-CHS-000104',
            name: '4-Kolben Festsattel Aluminium Monoblock',
            level: 2,
            category: 'PART',
            partRefId: 'tw-part-de-000104',
            quantity: 1,
            massTotalKg: 3.20,
            costTotalEur: 240.0,
            supplier: 'TEILWERK Bremsensysteme AG',
            status: 'SERIENREIF',
            explodedOffset: { x: 60, y: 20, z: 50 }
          },
          {
            id: 'NODE-PART-BOLT',
            code: 'TW-AUT-000125',
            name: 'Radbolzen M14x1.5 DIN 74361 (5x)',
            level: 2,
            category: 'PART',
            partRefId: 'tw-part-de-000125',
            quantity: 5,
            massTotalKg: 0.475,
            costTotalEur: 19.0,
            supplier: 'Böllhoff Verbindungstechnik',
            status: 'SERIENREIF',
            explodedOffset: { x: 0, y: 0, z: -80 }
          }
        ]
      },
      {
        id: 'NODE-EDRIVE-01',
        code: 'TW-ASY-ED-02',
        name: 'Elektrische Antriebseinheit 180kW Hinterachse',
        level: 1,
        category: 'ASSEMBLY',
        quantity: 1,
        massTotalKg: 78.0,
        costTotalEur: 4200.0,
        supplier: 'TEILWERK E-Mobility Friedrichshafen',
        status: 'SERIENREIF',
        children: [
          {
            id: 'NODE-MOTOR-ROTOR',
            code: 'TW-AUT-000110',
            name: 'PSM-Rotor 150kW mit NdFeB-Magneten',
            level: 2,
            category: 'PART',
            partRefId: 'tw-part-de-000110',
            quantity: 1,
            massTotalKg: 18.5,
            costTotalEur: 680.0,
            supplier: 'TEILWERK Magnetics',
            status: 'SERIENREIF'
          },
          {
            id: 'NODE-MOTOR-GEAR',
            code: 'TW-GRB-008921',
            name: 'Präzisions-Schrägzahnrad Z=48 Modul 2.5',
            level: 2,
            category: 'PART',
            partRefId: 'tw-part-de-008921',
            quantity: 1,
            massTotalKg: 2.15,
            costTotalEur: 94.50,
            supplier: 'TEILWERK Antriebstechnik GmbH',
            status: 'SERIENREIF'
          }
        ]
      }
    ]
  },
  {
    id: 'NODE-MACHINE-01',
    code: 'TW-CNC-HSC800',
    name: '5-Achs-HSC-Bearbeitungszentrum TW-CNC-HSC800',
    level: 0,
    category: 'MACHINE',
    quantity: 1,
    massTotalKg: 8500.0,
    costTotalEur: 385000.0,
    supplier: 'TEILWERK Werkzeugmaschinenbau Pfronten',
    status: 'SERIENREIF',
    children: [
      {
        id: 'NODE-SPINDLE-01',
        code: 'TW-ASY-SP-04',
        name: 'Motorspindel HSK-A63 24.000 RPM Synchron',
        level: 1,
        category: 'ASSEMBLY',
        quantity: 1,
        massTotalKg: 42.0,
        costTotalEur: 18500.0,
        supplier: 'Kessler Spindles / TEILWERK',
        status: 'SERIENREIF',
        children: [
          {
            id: 'NODE-SPINDLE-BRG-1',
            code: 'TW-BRG-004812',
            name: 'Spindellager 6208 DIN 625 P5 Tandem',
            level: 2,
            category: 'PART',
            partRefId: 'tw-part-de-004812',
            quantity: 4,
            massTotalKg: 1.46,
            costTotalEur: 59.40,
            supplier: 'TEILWERK Präzision GmbH',
            status: 'SERIENREIF'
          },
          {
            id: 'NODE-SPINDLE-GEAR',
            code: 'TW-GRB-008921',
            name: 'Schrägzahnrad Z=48 Spindel-Nebentrieb',
            level: 2,
            category: 'PART',
            partRefId: 'tw-part-de-008921',
            quantity: 1,
            massTotalKg: 2.15,
            costTotalEur: 94.50,
            supplier: 'TEILWERK Antriebstechnik GmbH',
            status: 'SERIENREIF'
          }
        ]
      },
      {
        id: 'NODE-HYD-BLOCK',
        code: 'TW-ASY-HYD-01',
        name: 'Hydrostatisches Spannventil-Modul 250 bar',
        level: 1,
        category: 'ASSEMBLY',
        quantity: 1,
        massTotalKg: 14.5,
        costTotalEur: 1650.0,
        supplier: 'TEILWERK Hydrauliksysteme',
        status: 'SERIENREIF',
        children: [
          {
            id: 'NODE-PROP-VALVE',
            code: 'TW-HYD-000126',
            name: '4/3-Wege-Proportional-Hydraulikventil NG6',
            level: 2,
            category: 'PART',
            partRefId: 'tw-part-de-000126',
            quantity: 2,
            massTotalKg: 4.80,
            costTotalEur: 840.0,
            supplier: 'TEILWERK Hydraulik',
            status: 'SERIENREIF'
          }
        ]
      }
    ]
  }
];

export const MACHINE_TOOLS_DATA: MachineToolTwin[] = [
  {
    id: 'CNC-DMG-08',
    name: 'DMG MORI DMU 50 5-Achs Simultan',
    code: 'MC-5AXIS-DMG50',
    type: '5-ACHS_FRAESEN',
    facility: 'Werk 1 — Zerspanungszentrum Halle 3',
    status: 'IN_BETRIEB',
    spindleRpm: 14200,
    feedRateMMin: 18.5,
    cutDepthMm: 2.5,
    powerKw: 18.4,
    temperatureC: 28.5,
    toolWearPercent: 24.0,
    currentPartId: 'tw-part-de-004812',
    currentPartName: '6208 Rillenkugellager Außenring',
    oeePercent: 88.4,
    vibrationMmS: 0.45,
    utilizationTodayPercent: 92.1
  },
  {
    id: 'CNC-TURN-04',
    name: 'EMAG VL 4 Vertikal-Drehzentrum',
    code: 'MC-TURN-EMAG-VL4',
    type: 'CNC_DREHEN',
    facility: 'Werk 1 — Dreherei Halle 2',
    status: 'IN_BETRIEB',
    spindleRpm: 3400,
    feedRateMMin: 4.2,
    cutDepthMm: 1.8,
    powerKw: 22.0,
    temperatureC: 38.0,
    toolWearPercent: 32.5,
    currentPartId: 'tw-part-de-004812',
    currentPartName: '100Cr6 Lagerinnenring',
    oeePercent: 91.2,
    vibrationMmS: 0.38,
    utilizationTodayPercent: 94.6
  },
  {
    id: 'GRIND-KLING-01',
    name: 'Klingelnberg Höfler Viper 500 Wälzschleifmaschine',
    code: 'MC-GRIND-VIPER500',
    type: 'SCHLEIFZELLE',
    facility: 'Werk 3 — Verzahnung Friedrichshafen',
    status: 'IN_BETRIEB',
    spindleRpm: 4500,
    feedRateMMin: 2.8,
    cutDepthMm: 0.08,
    powerKw: 14.5,
    temperatureC: 22.4,
    toolWearPercent: 14.0,
    currentPartId: 'tw-part-de-008921',
    currentPartName: 'Präzisions-Schrägzahnrad Z=48',
    oeePercent: 86.8,
    vibrationMmS: 0.22,
    utilizationTodayPercent: 89.0
  },
  {
    id: 'QC-CMM-01',
    name: 'Zeiss PRISMO Navigator 3D-KMG',
    code: 'QC-CMM-ZEISS-01',
    type: 'CMM_MESSRAUM',
    facility: 'Messraum Klasse 1 (20.0°C ±0.2K)',
    status: 'IN_BETRIEB',
    spindleRpm: 0,
    feedRateMMin: 0.5,
    cutDepthMm: 0.0,
    powerKw: 1.8,
    temperatureC: 20.05,
    toolWearPercent: 1.0,
    currentPartId: 'tw-part-de-004812',
    currentPartName: '100% CMM-Form- & Lagetoleranzprüfung',
    oeePercent: 96.5,
    vibrationMmS: 0.02,
    utilizationTodayPercent: 98.2
  }
];
