"""
machines/maintenance_model.py

Predictive & scheduled maintenance planning for the factory's machine
fleet. Wraps `Machine.health` signals into a maintenance priority queue
so `factory/factory_floor.py` and `ai/scheduling_ai.py` can decide which
machine gets serviced next when maintenance crew capacity is limited.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from machines.machine_base import Machine, MachineState
from utils.logging import GLOBAL_METRICS, get_logger

logger = get_logger("machines.maintenance")


@dataclass
class MaintenanceTicket:
    machine_id: str
    priority: float
    reason: str
    predicted_failure_risk: float


class MaintenancePlanner:
    """
    Predictive maintenance scheduler.

    Ranks machines by a composite risk score derived from health,
    calibration drift and time since last service, and dispatches a
    limited number of maintenance crews per tick to the highest risk
    assets -- classic condition-based maintenance (CBM) logic.
    """

    def __init__(self, crew_capacity: int = 1,
                 risk_threshold: float = 0.55) -> None:
        self.crew_capacity = crew_capacity
        self.risk_threshold = risk_threshold
        self.history: List[MaintenanceTicket] = []

    @staticmethod
    def failure_risk(machine: Machine) -> float:
        health_risk = 1.0 - machine.health.health
        drift_risk = machine.health.calibration_error
        overdue_ratio = min(
            2.0,
            machine.health.minutes_since_maintenance
            / max(machine.config.maintenance_interval_minutes, 1e-6),
        )
        overdue_risk = max(0.0, overdue_ratio - 1.0)
        return min(1.0, 0.5 * health_risk + 0.3 * drift_risk + 0.2 * overdue_risk)

    def build_queue(self, machines: List[Machine]) -> List[MaintenanceTicket]:
        tickets = []
        for m in machines:
            if m.state in (MachineState.MAINTENANCE,):
                continue
            risk = self.failure_risk(m)
            if risk >= self.risk_threshold or m.state == MachineState.FAILED:
                reason = "failed" if m.state == MachineState.FAILED else "predictive-risk"
                tickets.append(MaintenanceTicket(m.machine_id, priority=risk, reason=reason,
                                                  predicted_failure_risk=risk))
        tickets.sort(key=lambda t: -t.priority)
        return tickets

    def dispatch(self, machines: List[Machine]) -> List[MaintenanceTicket]:
        """
        Dispatch maintenance crews to the top-priority machines this tick,
        respecting crew capacity. Returns the tickets actually serviced.
        """
        by_id: Dict[str, Machine] = {m.machine_id: m for m in machines}
        queue = self.build_queue(machines)
        dispatched: List[MaintenanceTicket] = []
        for ticket in queue[: self.crew_capacity]:
            machine = by_id[ticket.machine_id]
            if machine.state == MachineState.FAILED:
                machine.repair()
                machine.enter_maintenance()
            else:
                machine.enter_maintenance()
            dispatched.append(ticket)
            self.history.append(ticket)
            logger.info("Dispatched maintenance crew to %s (risk=%.2f, reason=%s)",
                        ticket.machine_id, ticket.priority, ticket.reason)
            GLOBAL_METRICS.record("maintenance_dispatch", ticket.machine_id,
                                   priority=ticket.priority, reason=ticket.reason)
        return dispatched

    def fleet_health_report(self, machines: List[Machine]) -> Dict[str, float]:
        if not machines:
            return {}
        healths = [m.health.health for m in machines]
        return {
            "mean_health": sum(healths) / len(healths),
            "min_health": min(healths),
            "machines_at_risk": sum(1 for m in machines if self.failure_risk(m) >= self.risk_threshold),
            "machines_failed": sum(1 for m in machines if m.state == MachineState.FAILED),
            "machines_in_maintenance": sum(1 for m in machines if m.state == MachineState.MAINTENANCE),
        }
