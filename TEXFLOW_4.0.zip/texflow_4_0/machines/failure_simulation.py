"""
machines/failure_simulation.py

Stochastic failure-mode library. Rather than every machine failing in the
same generic way, this module assigns each failure event a mode (e.g.
bearing wear, sensor fault, thread breakage jam) with its own downtime
distribution and downstream quality impact, giving the digital twin
more realistic, differentiated failure behaviour.
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from enum import Enum
from typing import Dict, List

from machines.machine_base import Machine
from utils.logging import GLOBAL_METRICS, get_logger

logger = get_logger("machines.failure")


class FailureMode(str, Enum):
    MECHANICAL_WEAR = "mechanical_wear"
    SENSOR_FAULT = "sensor_fault"
    JAM = "jam"
    ELECTRICAL_FAULT = "electrical_fault"
    THERMAL_OVERLOAD = "thermal_overload"


@dataclass(frozen=True)
class FailureModeProfile:
    mode: FailureMode
    weight: float                 # relative likelihood among failure modes
    mean_downtime_minutes: float
    downtime_stdev_minutes: float
    quality_impact: float         # 0..1, quality multiplier applied post-repair until next service


FAILURE_PROFILES: List[FailureModeProfile] = [
    FailureModeProfile(FailureMode.MECHANICAL_WEAR, weight=0.30,
                        mean_downtime_minutes=90, downtime_stdev_minutes=25, quality_impact=0.10),
    FailureModeProfile(FailureMode.SENSOR_FAULT, weight=0.20,
                        mean_downtime_minutes=30, downtime_stdev_minutes=10, quality_impact=0.20),
    FailureModeProfile(FailureMode.JAM, weight=0.25,
                        mean_downtime_minutes=15, downtime_stdev_minutes=5, quality_impact=0.05),
    FailureModeProfile(FailureMode.ELECTRICAL_FAULT, weight=0.15,
                        mean_downtime_minutes=120, downtime_stdev_minutes=40, quality_impact=0.15),
    FailureModeProfile(FailureMode.THERMAL_OVERLOAD, weight=0.10,
                        mean_downtime_minutes=60, downtime_stdev_minutes=20, quality_impact=0.25),
]


@dataclass
class FailureEvent:
    machine_id: str
    mode: FailureMode
    downtime_minutes: float
    quality_impact: float
    timestamp: float


class FailureSimulator:
    """Samples a failure mode/downtime whenever a Machine.trigger_failure() fires."""

    def __init__(self, rng: random.Random | None = None) -> None:
        self.rng = rng or random.Random()
        self.events: List[FailureEvent] = []
        total_weight = sum(p.weight for p in FAILURE_PROFILES)
        self._weights = [p.weight / total_weight for p in FAILURE_PROFILES]

    def sample_failure(self, machine: Machine, timestamp: float) -> FailureEvent:
        profile = self.rng.choices(FAILURE_PROFILES, weights=self._weights, k=1)[0]
        downtime = max(2.0, self.rng.gauss(profile.mean_downtime_minutes,
                                            profile.downtime_stdev_minutes))
        event = FailureEvent(
            machine_id=machine.machine_id,
            mode=profile.mode,
            downtime_minutes=downtime,
            quality_impact=profile.quality_impact,
            timestamp=timestamp,
        )
        self.events.append(event)
        logger.warning("%s failure mode=%s downtime=%.1fmin quality_impact=%.2f",
                        machine.machine_id, profile.mode.value, downtime, profile.quality_impact)
        GLOBAL_METRICS.record("failure_mode", machine.machine_id, mode=profile.mode.value,
                               downtime_minutes=downtime, quality_impact=profile.quality_impact)
        return event

    def mtbf_minutes(self, machine_id: str, total_runtime_minutes: float) -> float:
        """Mean time between failures for a given machine, in minutes."""
        failures = [e for e in self.events if e.machine_id == machine_id]
        if not failures:
            return float("inf")
        return total_runtime_minutes / len(failures)

    def mode_distribution(self) -> Dict[str, int]:
        counts: Dict[str, int] = {}
        for e in self.events:
            counts[e.mode.value] = counts.get(e.mode.value, 0) + 1
        return counts

    def total_downtime_minutes(self, machine_id: str | None = None) -> float:
        events = self.events if machine_id is None else [
            e for e in self.events if e.machine_id == machine_id
        ]
        return sum(e.downtime_minutes for e in events)
