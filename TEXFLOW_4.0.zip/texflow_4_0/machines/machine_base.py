"""
machines/machine_base.py

Industry 4.0 machine base class. Every physical asset on the factory
floor (spinning frame, loom, knitting machine, dye bath, finishing line,
QC station) extends `Machine` and inherits throughput limiting, wear and
degradation, calibration drift, failure probability and maintenance
cycles -- the shared behaviour the architecture spec calls out under
"MACHINE SYSTEM (INDUSTRY 4.0 CORE)".
"""

from __future__ import annotations

import random
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, Optional

from utils.config import MachineConfig
from utils.logging import GLOBAL_METRICS, get_logger

logger = get_logger("machines.base")


class MachineState(str, Enum):
    IDLE = "idle"
    RUNNING = "running"
    MAINTENANCE = "maintenance"
    FAILED = "failed"
    BLOCKED = "blocked"  # starved of input or downstream congestion


@dataclass
class MachineHealth:
    """Tracks the wear state of a single machine over its operating life."""

    health: float = 1.0                 # 1.0 = brand new / freshly serviced
    calibration_error: float = 0.0      # 0..1, 0 = perfectly calibrated
    minutes_since_maintenance: float = 0.0
    total_units_produced: float = 0.0
    total_runtime_minutes: float = 0.0
    total_downtime_minutes: float = 0.0
    failure_count: int = 0

    @property
    def uptime_pct(self) -> float:
        total = self.total_runtime_minutes + self.total_downtime_minutes
        if total <= 0:
            return 100.0
        return 100.0 * self.total_runtime_minutes / total


class Machine:
    """
    Base class for all production machines.

    Subclasses implement `process(rng, dt_minutes, **kwargs)` to perform
    stage-specific work; this base class handles the shared Industry 4.0
    machine lifecycle: throughput limiting, wear, calibration drift,
    stochastic failure, and scheduled maintenance.
    """

    kind: str = "generic"

    def __init__(self, machine_id: Optional[str] = None, config: Optional[MachineConfig] = None):
        self.machine_id = machine_id or f"{self.kind.upper()}-{uuid.uuid4().hex[:6]}"
        self.config = config or MachineConfig()
        self.health = MachineHealth()
        self.state = MachineState.IDLE
        self._maintenance_remaining_minutes = 0.0

    # -- lifecycle -----------------------------------------------------

    def tick(self, rng: random.Random, dt_minutes: float) -> None:
        """Advance machine state by one simulation timestep."""
        if self.state == MachineState.MAINTENANCE:
            self._advance_maintenance(dt_minutes)
            return

        if self.state == MachineState.FAILED:
            self.health.total_downtime_minutes += dt_minutes
            return

        self.health.minutes_since_maintenance += dt_minutes

        if self._should_enter_maintenance():
            self.enter_maintenance()
            return

        if self.state == MachineState.RUNNING:
            if self._sample_failure(rng, dt_minutes):
                self.trigger_failure()
                return
            self._apply_wear(dt_minutes)
            self.health.total_runtime_minutes += dt_minutes
        else:
            self.health.total_downtime_minutes += dt_minutes

    def _should_enter_maintenance(self) -> bool:
        return self.health.minutes_since_maintenance >= self.config.maintenance_interval_minutes

    def enter_maintenance(self) -> None:
        self.state = MachineState.MAINTENANCE
        self._maintenance_remaining_minutes = self.config.maintenance_duration_minutes
        logger.info("%s entering scheduled maintenance", self.machine_id)
        GLOBAL_METRICS.record("maintenance_start", self.machine_id, health=self.health.health)

    def _advance_maintenance(self, dt_minutes: float) -> None:
        self._maintenance_remaining_minutes -= dt_minutes
        self.health.total_downtime_minutes += dt_minutes
        if self._maintenance_remaining_minutes <= 0:
            self.complete_maintenance()

    def complete_maintenance(self) -> None:
        restored = self.config.repair_health_restore
        self.health.health = min(1.0, self.health.health + (1.0 - self.health.health) * restored)
        self.health.calibration_error = max(0.0, self.health.calibration_error * 0.1)
        self.health.minutes_since_maintenance = 0.0
        self.state = MachineState.IDLE
        logger.info("%s maintenance complete, health=%.3f", self.machine_id, self.health.health)
        GLOBAL_METRICS.record("maintenance_end", self.machine_id, health=self.health.health)

    def _sample_failure(self, rng: random.Random, dt_minutes: float) -> bool:
        # Failure probability rises as health degrades and calibration drifts.
        degradation_multiplier = 1.0 + (1.0 - self.health.health) * 4.0
        drift_multiplier = 1.0 + self.health.calibration_error * 2.0
        p = self.config.base_failure_rate * degradation_multiplier * drift_multiplier * dt_minutes
        return rng.random() < min(0.95, p)

    def trigger_failure(self) -> None:
        self.state = MachineState.FAILED
        self.health.failure_count += 1
        logger.warning("%s FAILURE #%d (health=%.3f)", self.machine_id,
                        self.health.failure_count, self.health.health)
        GLOBAL_METRICS.record("machine_failure", self.machine_id,
                               failure_count=self.health.failure_count,
                               health=self.health.health)

    def repair(self) -> None:
        """Manual/emergency repair triggered by maintenance crew dispatch."""
        self.health.health = min(1.0, self.health.health + 0.6)
        self.health.calibration_error = max(0.0, self.health.calibration_error - 0.3)
        self.state = MachineState.IDLE
        logger.info("%s repaired, health=%.3f", self.machine_id, self.health.health)

    def _apply_wear(self, dt_minutes: float) -> None:
        throughput = self.current_throughput()
        units = throughput * dt_minutes
        self.health.total_units_produced += units
        wear = self.config.wear_rate * units
        drift = self.config.calibration_drift_rate * dt_minutes
        self.health.health = max(0.0, self.health.health - wear)
        self.health.calibration_error = min(1.0, self.health.calibration_error + drift)

    def start(self) -> None:
        if self.state in (MachineState.IDLE, MachineState.BLOCKED):
            self.state = MachineState.RUNNING

    def stop(self) -> None:
        if self.state == MachineState.RUNNING:
            self.state = MachineState.IDLE

    def block(self) -> None:
        if self.state == MachineState.RUNNING:
            self.state = MachineState.BLOCKED

    def current_throughput(self) -> float:
        """Throughput derated by health and calibration error."""
        health_factor = 0.4 + 0.6 * self.health.health
        calibration_factor = 1.0 - 0.5 * self.health.calibration_error
        return self.config.base_throughput * health_factor * max(0.1, calibration_factor)

    def quality_multiplier(self) -> float:
        """
        0..1 multiplier applied to downstream quality scores; degrades with
        both wear and calibration drift, independent of raw throughput.
        """
        return max(0.0, 1.0 - 0.5 * (1.0 - self.health.health) - 0.5 * self.health.calibration_error)

    def status(self) -> Dict[str, object]:
        return {
            "machine_id": self.machine_id,
            "kind": self.kind,
            "state": self.state.value,
            "health": round(self.health.health, 4),
            "calibration_error": round(self.health.calibration_error, 4),
            "uptime_pct": round(self.health.uptime_pct, 2),
            "units_produced": round(self.health.total_units_produced, 2),
            "failure_count": self.health.failure_count,
            "throughput": round(self.current_throughput(), 4),
        }

    def __repr__(self) -> str:  # pragma: no cover - debugging helper
        return f"<{self.__class__.__name__} {self.machine_id} state={self.state.value} health={self.health.health:.2f}>"
