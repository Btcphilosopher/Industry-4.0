"""
materials/fabric_properties.py

Represents fabric rolls as they move through weaving/knitting, dyeing,
finishing and quality control. Carries the density map and structural
integrity score referenced throughout the architecture spec, plus the
defect ledger that accumulates as the roll travels the factory floor.
"""

from __future__ import annotations

import statistics
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional

import numpy as np


class FabricConstruction(str, Enum):
    WOVEN = "woven"
    KNITTED = "knitted"


@dataclass
class DefectRecord:
    stage: str
    defect_type: str
    severity: float  # 0..1
    position_m: float
    position_cm_across: float = 0.0
    timestamp: float = 0.0


@dataclass
class FabricRoll:
    """A single roll of fabric moving through the production pipeline."""

    roll_id: str
    construction: FabricConstruction
    length_m: float
    width_cm: float
    source_yarn_lot_id: str
    yarn_quality_score: float
    density_map: np.ndarray = field(default_factory=lambda: np.ones((1, 1)))
    defects: List[DefectRecord] = field(default_factory=list)
    dye_color: Optional[str] = None
    dye_uniformity: float = 1.0
    finish_applied: List[str] = field(default_factory=list)
    shrinkage_pct: float = 0.0
    reworked_count: int = 0
    rejected: bool = False

    @staticmethod
    def new_id() -> str:
        return f"ROLL-{uuid.uuid4().hex[:10].upper()}"

    def add_defect(self, stage: str, defect_type: str, severity: float,
                    position_m: float, position_cm_across: float = 0.0,
                    timestamp: float = 0.0) -> None:
        self.defects.append(
            DefectRecord(
                stage=stage,
                defect_type=defect_type,
                severity=severity,
                position_m=position_m,
                position_cm_across=position_cm_across,
                timestamp=timestamp,
            )
        )

    @property
    def defect_count(self) -> int:
        return len(self.defects)

    @property
    def defect_density_per_m(self) -> float:
        if self.length_m <= 0:
            return 0.0
        return self.defect_count / self.length_m

    @property
    def mean_defect_severity(self) -> float:
        if not self.defects:
            return 0.0
        return statistics.fmean(d.severity for d in self.defects)

    def structural_integrity_score(self) -> float:
        """
        0..100 composite score combining density uniformity, defect load
        and yarn quality -- the number quality control uses as its
        primary accept/reject signal.
        """
        density_std = float(np.std(self.density_map)) if self.density_map.size > 1 else 0.0
        density_mean = float(np.mean(self.density_map)) if self.density_map.size else 1.0
        uniformity = max(0.0, 1.0 - (density_std / max(density_mean, 1e-6)))

        defect_penalty = min(60.0, self.defect_density_per_m * 8.0 * (1 + self.mean_defect_severity))
        yarn_component = self.yarn_quality_score * 0.35
        uniformity_component = uniformity * 40.0
        dye_component = self.dye_uniformity * 15.0

        score = yarn_component + uniformity_component + dye_component - defect_penalty
        return max(0.0, min(100.0, score))

    def apply_shrinkage(self, pct: float) -> None:
        self.shrinkage_pct += pct
        self.length_m *= (1.0 - pct / 100.0)
        self.width_cm *= (1.0 - pct / 100.0)

    def density_heatmap_normalized(self) -> np.ndarray:
        arr = self.density_map
        if arr.size == 0:
            return arr
        lo, hi = float(arr.min()), float(arr.max())
        if hi - lo < 1e-9:
            return np.zeros_like(arr)
        return (arr - lo) / (hi - lo)

    def summary(self) -> dict:
        return {
            "roll_id": self.roll_id,
            "construction": self.construction.value,
            "length_m": round(self.length_m, 2),
            "width_cm": round(self.width_cm, 1),
            "defects": self.defect_count,
            "defect_density_per_m": round(self.defect_density_per_m, 4),
            "structural_integrity": round(self.structural_integrity_score(), 2),
            "dye_color": self.dye_color,
            "dye_uniformity": round(self.dye_uniformity, 3),
            "shrinkage_pct": round(self.shrinkage_pct, 2),
            "rejected": self.rejected,
            "reworked_count": self.reworked_count,
        }
