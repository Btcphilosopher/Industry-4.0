"""
materials/fiber_models.py

Physical models for raw textile fibres. Each fibre type carries the
physical properties that ripple downstream through spinning, weaving,
dyeing and finishing: tensile strength, elasticity, dye affinity,
breakage probability and thermal sensitivity.

Blended fibres are modelled as a weighted linear combination of their
constituents for the linear properties, with a small non-linearity
penalty applied to strength (blends are rarely as strong as a pure
naive weighted average would suggest).
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Tuple


class FiberType(str, Enum):
    COTTON = "cotton"
    POLYESTER = "polyester"
    WOOL = "wool"
    NYLON = "nylon"


@dataclass(frozen=True)
class FiberProperties:
    """Static physical properties of a pure fibre type."""

    name: str
    tensile_strength_cn_tex: float     # centinewtons per tex
    elasticity_pct: float              # elastic recovery, %
    dye_absorption_rate: float         # 0..1, relative affinity
    break_probability: float           # baseline probability per stress event
    thermal_sensitivity: float         # 0..1, higher = more heat sensitive
    moisture_regain_pct: float         # % moisture regain at standard conditions
    density_g_cm3: float

    def blended_with(self, other: "FiberProperties", self_ratio: float) -> "FiberProperties":
        """Linearly blend two fibre property sets by mass ratio."""
        other_ratio = 1.0 - self_ratio
        blended_strength = (
            self.tensile_strength_cn_tex * self_ratio
            + other.tensile_strength_cn_tex * other_ratio
        ) * 0.96  # blending non-linearity penalty
        return FiberProperties(
            name=f"{self.name}/{other.name} {int(self_ratio * 100)}/{int(other_ratio * 100)}",
            tensile_strength_cn_tex=blended_strength,
            elasticity_pct=self.elasticity_pct * self_ratio + other.elasticity_pct * other_ratio,
            dye_absorption_rate=self.dye_absorption_rate * self_ratio
            + other.dye_absorption_rate * other_ratio,
            break_probability=self.break_probability * self_ratio
            + other.break_probability * other_ratio,
            thermal_sensitivity=self.thermal_sensitivity * self_ratio
            + other.thermal_sensitivity * other_ratio,
            moisture_regain_pct=self.moisture_regain_pct * self_ratio
            + other.moisture_regain_pct * other_ratio,
            density_g_cm3=self.density_g_cm3 * self_ratio + other.density_g_cm3 * other_ratio,
        )


FIBER_LIBRARY: Dict[FiberType, FiberProperties] = {
    FiberType.COTTON: FiberProperties(
        name="cotton",
        tensile_strength_cn_tex=28.0,
        elasticity_pct=6.0,
        dye_absorption_rate=0.82,
        break_probability=0.012,
        thermal_sensitivity=0.35,
        moisture_regain_pct=8.5,
        density_g_cm3=1.54,
    ),
    FiberType.POLYESTER: FiberProperties(
        name="polyester",
        tensile_strength_cn_tex=48.0,
        elasticity_pct=25.0,
        dye_absorption_rate=0.35,
        break_probability=0.004,
        thermal_sensitivity=0.75,
        moisture_regain_pct=0.4,
        density_g_cm3=1.38,
    ),
    FiberType.WOOL: FiberProperties(
        name="wool",
        tensile_strength_cn_tex=13.0,
        elasticity_pct=35.0,
        dye_absorption_rate=0.95,
        break_probability=0.018,
        thermal_sensitivity=0.55,
        moisture_regain_pct=16.0,
        density_g_cm3=1.31,
    ),
    FiberType.NYLON: FiberProperties(
        name="nylon",
        tensile_strength_cn_tex=52.0,
        elasticity_pct=30.0,
        dye_absorption_rate=0.55,
        break_probability=0.003,
        thermal_sensitivity=0.85,
        moisture_regain_pct=4.2,
        density_g_cm3=1.14,
    ),
}


@dataclass
class FiberBlend:
    """
    A mixture of one or more fibre types by mass fraction, e.g.
    {'cotton': 0.65, 'polyester': 0.35} for a classic poly-cotton blend.
    """

    composition: Dict[FiberType, float]

    def __post_init__(self) -> None:
        total = sum(self.composition.values())
        if total <= 0:
            raise ValueError("FiberBlend composition must sum to a positive value")
        if abs(total - 1.0) > 1e-6:
            self.composition = {k: v / total for k, v in self.composition.items()}

    def resolved_properties(self) -> FiberProperties:
        items: List[Tuple[FiberType, float]] = sorted(
            self.composition.items(), key=lambda kv: -kv[1]
        )
        props = FIBER_LIBRARY[items[0][0]]
        cumulative_ratio = items[0][1]
        for fiber_type, ratio in items[1:]:
            other = FIBER_LIBRARY[fiber_type]
            combined_total = cumulative_ratio + ratio
            self_share = cumulative_ratio / combined_total if combined_total else 0.0
            props = props.blended_with(other, self_share)
            cumulative_ratio = combined_total
        return props

    def label(self) -> str:
        parts = [f"{v * 100:.0f}% {k.value}" for k, v in
                 sorted(self.composition.items(), key=lambda kv: -kv[1])]
        return " / ".join(parts)


@dataclass
class FiberBatch:
    """A physical lot of fibre stock entering the factory."""

    batch_id: str
    blend: FiberBlend
    mass_kg: float
    moisture_pct: float = 8.0
    contamination_level: float = 0.0  # 0..1 trash/foreign matter fraction
    _rng: random.Random = field(default_factory=random.Random, repr=False, compare=False)

    def properties(self) -> FiberProperties:
        return self.blend.resolved_properties()

    def effective_strength(self) -> float:
        """Strength derated by contamination and excess moisture."""
        props = self.properties()
        contamination_penalty = 1.0 - 0.4 * self.contamination_level
        moisture_penalty = 1.0 - max(0.0, self.moisture_pct - props.moisture_regain_pct) * 0.01
        return props.tensile_strength_cn_tex * contamination_penalty * max(0.5, moisture_penalty)

    def sample_break_event(self, rng: random.Random | None = None) -> bool:
        """Stochastically determine whether this batch suffers a break event."""
        rng = rng or self._rng
        props = self.properties()
        probability = props.break_probability * (1.0 + self.contamination_level)
        return rng.random() < probability

    def consume(self, mass_kg: float) -> "FiberBatch":
        """Split off `mass_kg` from this batch, returning the consumed portion."""
        if mass_kg > self.mass_kg:
            raise ValueError("Cannot consume more mass than available in batch")
        self.mass_kg -= mass_kg
        return FiberBatch(
            batch_id=f"{self.batch_id}-split",
            blend=self.blend,
            mass_kg=mass_kg,
            moisture_pct=self.moisture_pct,
            contamination_level=self.contamination_level,
        )
