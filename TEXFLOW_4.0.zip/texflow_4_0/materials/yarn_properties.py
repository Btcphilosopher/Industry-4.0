"""
materials/yarn_properties.py

Represents spun yarn as it exists between the spinning frame and the
weaving/knitting stage, including the quality and consistency scoring
used throughout downstream subsystems.
"""

from __future__ import annotations

import statistics
from dataclasses import dataclass, field
from typing import List

from materials.fiber_models import FiberBatch, FiberProperties


@dataclass
class YarnSegment:
    """A short length of yarn with locally-sampled thickness/tension."""

    length_m: float
    linear_density_tex: float  # grams per 1000m
    tension_cn: float
    twist_per_m: float


@dataclass
class YarnLot:
    """
    A finished yarn lot produced from a fibre batch, made of many sampled
    segments used to compute a quality/consistency score analogous to a
    real Uster evenness test.
    """

    lot_id: str
    source_batch_id: str
    fiber_properties: FiberProperties
    target_count_ne: float
    segments: List[YarnSegment] = field(default_factory=list)

    @property
    def total_length_m(self) -> float:
        return sum(s.length_m for s in self.segments)

    @property
    def mean_linear_density(self) -> float:
        if not self.segments:
            return 0.0
        return statistics.fmean(s.linear_density_tex for s in self.segments)

    @property
    def count_variation_cv_pct(self) -> float:
        """Coefficient of variation of linear density -- lower is better."""
        if len(self.segments) < 2:
            return 0.0
        densities = [s.linear_density_tex for s in self.segments]
        mean = statistics.fmean(densities)
        if mean == 0:
            return 0.0
        stdev = statistics.pstdev(densities)
        return 100.0 * stdev / mean

    @property
    def mean_tension_cn(self) -> float:
        if not self.segments:
            return 0.0
        return statistics.fmean(s.tension_cn for s in self.segments)

    @property
    def thin_places_per_km(self) -> float:
        """Segments with density < 70% of mean, normalised per km."""
        if not self.segments:
            return 0.0
        mean = self.mean_linear_density
        threshold = mean * 0.70
        thin_count = sum(1 for s in self.segments if s.linear_density_tex < threshold)
        km = max(self.total_length_m / 1000.0, 1e-9)
        return thin_count / km

    @property
    def thick_places_per_km(self) -> float:
        if not self.segments:
            return 0.0
        mean = self.mean_linear_density
        threshold = mean * 1.35
        thick_count = sum(1 for s in self.segments if s.linear_density_tex > threshold)
        km = max(self.total_length_m / 1000.0, 1e-9)
        return thick_count / km

    def quality_score(self) -> float:
        """
        Composite 0..100 quality score combining evenness, strength margin
        and defect density -- the number handed to weaving/knitting to
        decide whether this lot is fit for high-spec fabric.
        """
        cv = self.count_variation_cv_pct
        evenness_score = max(0.0, 100.0 - cv * 6.0)
        defect_penalty = min(40.0, (self.thin_places_per_km + self.thick_places_per_km) * 2.0)
        strength_bonus = min(10.0, self.fiber_properties.tensile_strength_cn_tex / 6.0)
        score = evenness_score - defect_penalty + strength_bonus
        return max(0.0, min(100.0, score))

    def consistency_index(self) -> float:
        """0..1 index; 1.0 means perfectly uniform yarn."""
        return max(0.0, 1.0 - self.count_variation_cv_pct / 30.0)

    def grade(self) -> str:
        score = self.quality_score()
        if score >= 90:
            return "A"
        if score >= 75:
            return "B"
        if score >= 60:
            return "C"
        return "D"
