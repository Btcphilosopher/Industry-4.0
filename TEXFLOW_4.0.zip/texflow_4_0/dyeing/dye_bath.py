"""
dyeing/dye_bath.py

The dye bath machine: applies chemical diffusion + temperature control
to a FabricRoll, updating its dye_color, dye_uniformity and adding
dye-related defects (uneven absorption, thermal damage).
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Optional

import numpy as np

from dyeing.chemical_diffusion import DiffusionField
from dyeing.temperature_control import TemperatureController, PIDGains
from machines.machine_base import Machine, MachineState
from materials.fabric_properties import FabricRoll
from materials.fiber_models import FiberProperties
from utils.config import DyeingConfig, MachineConfig
from utils.logging import GLOBAL_METRICS, get_logger

logger = get_logger("dyeing.bath")


@dataclass
class DyeingRunResult:
    fabric_roll: FabricRoll
    duration_minutes: float
    final_uniformity: float
    mean_concentration: float


class DyeBath(Machine):
    """A batch dye bath (exhaust dyeing) machine."""

    kind = "dye_bath"

    def __init__(self, machine_id: Optional[str] = None,
                 dyeing_config: Optional[DyeingConfig] = None,
                 machine_config: Optional[MachineConfig] = None):
        super().__init__(machine_id=machine_id, config=machine_config)
        self.dyeing_config = dyeing_config or DyeingConfig()
        self.temperature = TemperatureController(setpoint_c=self.dyeing_config.bath_temperature_c)

    def dye_roll(self, rng: random.Random, roll: FabricRoll, fiber_props: FiberProperties,
                  color: str, cycle_minutes: float = 60.0) -> DyeingRunResult:
        if self.state == MachineState.FAILED:
            raise RuntimeError(f"{self.machine_id} cannot dye while FAILED")
        self.start()

        width_cells = max(4, int(roll.width_cm / 5))
        field = DiffusionField(width_cells=width_cells,
                                diffusion_coefficient=self.dyeing_config.diffusion_coefficient
                                * fiber_props.dye_absorption_rate)

        steps = max(1, int(cycle_minutes))
        dt = cycle_minutes / steps
        thermal_damage_events = 0

        for _ in range(steps):
            self.temperature.step(rng, dt_minutes=dt, calibration_error=self.health.calibration_error)
            uptake_rate = 0.05 * self.temperature.uptake_rate_multiplier() * fiber_props.dye_absorption_rate
            field.apply_boundary_source(self.dyeing_config.target_concentration, uptake_rate, dt)
            field.step(dt)

            damage_risk = self.temperature.thermal_damage_risk(fiber_props.thermal_sensitivity)
            if rng.random() < damage_risk:
                thermal_damage_events += 1

        uniformity = field.uniformity()
        mean_concentration = field.mean_concentration()
        target = self.dyeing_config.target_concentration
        concentration_accuracy = max(0.0, 1.0 - abs(mean_concentration - target) / max(target, 1e-6))

        roll.dye_color = color
        roll.dye_uniformity = min(1.0, uniformity * 0.7 + concentration_accuracy * 0.3)
        roll.dye_uniformity *= self.quality_multiplier()

        if roll.dye_uniformity < 0.75:
            severity = min(1.0, (0.75 - roll.dye_uniformity) * 2.0)
            roll.add_defect("dyeing", "uneven_absorption", severity, position_m=roll.length_m / 2,
                             timestamp=cycle_minutes)

        for _ in range(thermal_damage_events):
            roll.add_defect("dyeing", "thermal_damage", rng.uniform(0.3, 0.8),
                             position_m=rng.uniform(0, roll.length_m), timestamp=cycle_minutes)

        self.health.total_units_produced += roll.length_m
        duration_minutes = cycle_minutes

        logger.debug("%s dyed roll %s color=%s uniformity=%.3f", self.machine_id,
                     roll.roll_id, color, roll.dye_uniformity)
        GLOBAL_METRICS.record("dyeing_run", self.machine_id, roll_id=roll.roll_id,
                               color=color, uniformity=roll.dye_uniformity,
                               thermal_events=thermal_damage_events)

        return DyeingRunResult(fabric_roll=roll, duration_minutes=duration_minutes,
                                final_uniformity=roll.dye_uniformity,
                                mean_concentration=mean_concentration)
