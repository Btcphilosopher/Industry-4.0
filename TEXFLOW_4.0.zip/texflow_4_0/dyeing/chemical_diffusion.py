"""
dyeing/chemical_diffusion.py

Simplified 1-D Fickian diffusion model for dye penetration across fabric
thickness/width. Used by dye_bath.py to compute concentration gradients
that drive uneven-absorption defects.
"""

from __future__ import annotations

import numpy as np


class DiffusionField:
    """
    A discretised concentration field solved with an explicit finite
    difference scheme for Fick's second law:  dC/dt = D * d2C/dx2
    """

    def __init__(self, width_cells: int, diffusion_coefficient: float,
                 initial_concentration: float = 0.0):
        self.width_cells = width_cells
        self.diffusion_coefficient = diffusion_coefficient
        self.concentration = np.full(width_cells, initial_concentration, dtype=np.float64)

    def apply_boundary_source(self, bath_concentration: float, uptake_rate: float,
                                dt: float) -> None:
        """Dye enters from both fabric edges (bath contact) each timestep."""
        edge_gain = uptake_rate * (bath_concentration - self.concentration[[0, -1]]) * dt
        self.concentration[0] += edge_gain[0]
        self.concentration[-1] += edge_gain[1]

    def step(self, dt: float, dx: float = 1.0) -> None:
        c = self.concentration
        laplacian = np.zeros_like(c)
        laplacian[1:-1] = c[2:] - 2 * c[1:-1] + c[:-2]
        laplacian[0] = c[1] - c[0]
        laplacian[-1] = c[-2] - c[-1]
        stability_limit = 0.5 * dx * dx / max(self.diffusion_coefficient, 1e-9)
        dt = min(dt, stability_limit)
        self.concentration = np.clip(c + self.diffusion_coefficient * laplacian / (dx * dx) * dt, 0.0, None)

    def uniformity(self) -> float:
        """0..1, 1.0 = perfectly uniform dye concentration across the field."""
        mean = float(np.mean(self.concentration))
        if mean <= 1e-9:
            return 1.0
        std = float(np.std(self.concentration))
        return max(0.0, 1.0 - std / mean)

    def mean_concentration(self) -> float:
        return float(np.mean(self.concentration))
