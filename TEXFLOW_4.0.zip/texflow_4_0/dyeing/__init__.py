"""dyeing package for TEXFLOW 4.0."""
