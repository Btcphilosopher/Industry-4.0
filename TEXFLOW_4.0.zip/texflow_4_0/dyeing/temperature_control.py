"""
dyeing/temperature_control.py

PID-style temperature controller for the dye bath, plus the temperature
sensitivity model that translates thermal excursions into dye uptake
rate changes and fibre thermal-damage risk.
"""

from __future__ import annotations

import random
from dataclasses import dataclass


@dataclass
class PIDGains:
    kp: float = 0.8
    ki: float = 0.02
    kd: float = 0.15


class TemperatureController:
    """Simple discrete PID controller driving bath temperature to setpoint."""

    def __init__(self, setpoint_c: float, gains: PIDGains | None = None,
                 current_c: float = 20.0):
        self.setpoint_c = setpoint_c
        self.gains = gains or PIDGains()
        self.current_c = current_c
        self._integral = 0.0
        self._prev_error = 0.0

    def step(self, rng: random.Random, dt_minutes: float, calibration_error: float = 0.0) -> float:
        error = self.setpoint_c - self.current_c
        self._integral += error * dt_minutes
        derivative = (error - self._prev_error) / max(dt_minutes, 1e-6)
        control_signal = (self.gains.kp * error + self.gains.ki * self._integral
                           + self.gains.kd * derivative)
        self._prev_error = error

        noise = rng.gauss(0.0, 0.3 + calibration_error * 1.5)
        heat_loss = 0.02 * (self.current_c - 20.0)  # ambient heat loss
        self.current_c += (control_signal * 0.1 - heat_loss) * dt_minutes + noise * (dt_minutes ** 0.5)
        return self.current_c

    def deviation_c(self) -> float:
        return abs(self.current_c - self.setpoint_c)

    def thermal_damage_risk(self, fibre_thermal_sensitivity: float, max_safe_c: float = 95.0) -> float:
        if self.current_c <= max_safe_c:
            return 0.0
        overshoot = (self.current_c - max_safe_c) / max_safe_c
        return min(1.0, overshoot * fibre_thermal_sensitivity * 3.0)

    def uptake_rate_multiplier(self) -> float:
        """
        Dye uptake rate roughly follows an Arrhenius-like relationship with
        temperature over the practical dyeing range; approximated here with
        a smooth monotonic curve normalised around the setpoint.
        """
        ratio = self.current_c / max(self.setpoint_c, 1e-6)
        return max(0.2, min(2.0, ratio ** 1.8))
