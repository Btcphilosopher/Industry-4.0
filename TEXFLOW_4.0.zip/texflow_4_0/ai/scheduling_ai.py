"""
ai/scheduling_ai.py

AI-driven scheduling layer. Reads bottleneck reports and fleet health
from the routing system / factory floor and emits actionable scheduling
recommendations: which stage needs more machines pulled online, which
machine should be pulled offline for preventive maintenance ahead of
its predicted failure, and how aggressively new orders should be
launched given current warehouse/queue pressure.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import List

from factory.routing_system import BottleneckReport, ProductionStage, RoutingSystem
from machines.machine_base import Machine
from machines.maintenance_model import MaintenancePlanner
from utils.logging import GLOBAL_METRICS, get_logger

logger = get_logger("ai.scheduling")


class RecommendationType(str, Enum):
    THROTTLE_ORDER_INTAKE = "throttle_order_intake"
    ACCELERATE_ORDER_INTAKE = "accelerate_order_intake"
    PRIORITISE_MAINTENANCE = "prioritise_maintenance"
    REBALANCE_STAGE = "rebalance_stage"
    HOLD_STEADY = "hold_steady"


@dataclass
class SchedulingRecommendation:
    rec_type: RecommendationType
    target: str
    rationale: str
    confidence: float


class SchedulingAI:
    """
    Rule-based expert-system scheduler (a lightweight stand-in for a
    full RL/MPC controller) that turns bottleneck + fleet-health signals
    into concrete recommendations. `order_intake_multiplier` is the
    number `factory_floor` should scale `orders_this_tick` by.
    """

    def __init__(self, routing: RoutingSystem, maintenance_planner: MaintenancePlanner):
        self.routing = routing
        self.maintenance_planner = maintenance_planner
        self.order_intake_multiplier: float = 1.0
        self.recommendation_log: List[SchedulingRecommendation] = []

    def evaluate(self, all_machines: List[Machine], warehouse_utilisation_pct: float) -> List[SchedulingRecommendation]:
        recs: List[SchedulingRecommendation] = []

        bottlenecks = self.routing.detect_bottlenecks()
        worst = bottlenecks[0] if bottlenecks else None

        if worst is not None and worst.severity > 0.7:
            recs.append(SchedulingRecommendation(
                rec_type=RecommendationType.THROTTLE_ORDER_INTAKE,
                target=worst.stage.value,
                rationale=f"{worst.stage.value} utilisation={worst.utilisation:.0%} "
                          f"queue={worst.queue_length} -- throttling upstream intake to prevent pile-up",
                confidence=min(0.95, worst.severity),
            ))
            self.order_intake_multiplier = 0.6
        elif worst is not None and worst.severity < 0.2 and warehouse_utilisation_pct < 60.0:
            recs.append(SchedulingRecommendation(
                rec_type=RecommendationType.ACCELERATE_ORDER_INTAKE,
                target="factory_floor",
                rationale="All stages under-utilised and warehouse has headroom -- ramping order intake",
                confidence=0.6,
            ))
            self.order_intake_multiplier = 1.3
        else:
            self.order_intake_multiplier = 1.0
            recs.append(SchedulingRecommendation(
                rec_type=RecommendationType.HOLD_STEADY, target="factory_floor",
                rationale="Throughput and utilisation within normal operating band",
                confidence=0.5,
            ))

        if warehouse_utilisation_pct > 90.0:
            recs.append(SchedulingRecommendation(
                rec_type=RecommendationType.THROTTLE_ORDER_INTAKE, target="warehouse",
                rationale=f"Warehouse at {warehouse_utilisation_pct:.0f}% capacity -- forcing intake throttle",
                confidence=0.9,
            ))
            self.order_intake_multiplier = min(self.order_intake_multiplier, 0.4)

        at_risk = [m for m in all_machines
                   if self.maintenance_planner.failure_risk(m) >= self.maintenance_planner.risk_threshold]
        if at_risk:
            worst_machine = max(at_risk, key=self.maintenance_planner.failure_risk)
            recs.append(SchedulingRecommendation(
                rec_type=RecommendationType.PRIORITISE_MAINTENANCE, target=worst_machine.machine_id,
                rationale=f"Predicted failure risk={self.maintenance_planner.failure_risk(worst_machine):.0%} "
                          f"-- schedule preventive maintenance before next batch",
                confidence=self.maintenance_planner.failure_risk(worst_machine),
            ))

        for rec in recs:
            GLOBAL_METRICS.record("scheduling_recommendation", rec.target, type=rec.rec_type.value,
                                   rationale=rec.rationale, confidence=rec.confidence)
        self.recommendation_log.extend(recs)
        if len(self.recommendation_log) > 500:
            self.recommendation_log = self.recommendation_log[-500:]
        return recs
