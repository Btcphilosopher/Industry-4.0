"""
ai/quality_ai.py

Quality prediction model. Given machine/process telemetry (health,
calibration error, tension deviation, pattern complexity, etc.) predicts
the probability a resulting roll will be rejected, so the scheduler can
intervene *before* defective fabric is produced rather than only
detecting it after the fact at QC.

Ships two interchangeable backends:
  * `LinearQualityModel`   -- pure NumPy logistic regression, always available.
  * `TorchQualityModel`    -- small PyTorch MLP, used automatically when
                               torch is importable, falling back silently
                               to the NumPy model otherwise.

Both implement the same `QualityPredictor` interface so the rest of the
system never needs to know which backend is active.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Protocol, Sequence

import numpy as np

from utils.logging import get_logger

logger = get_logger("ai.quality")

FEATURE_NAMES = [
    "machine_health",
    "calibration_error",
    "tension_deviation",
    "process_complexity",
    "fibre_contamination",
    "prior_defect_rate",
]


@dataclass
class QualityFeatures:
    machine_health: float
    calibration_error: float
    tension_deviation: float
    process_complexity: float
    fibre_contamination: float
    prior_defect_rate: float

    def as_array(self) -> np.ndarray:
        return np.array([
            self.machine_health, self.calibration_error, self.tension_deviation,
            self.process_complexity, self.fibre_contamination, self.prior_defect_rate,
        ], dtype=np.float64)


class QualityPredictor(Protocol):
    def predict_reject_probability(self, features: QualityFeatures) -> float: ...
    def fit(self, X: np.ndarray, y: np.ndarray) -> None: ...


class LinearQualityModel:
    """Hand-tuned + online-trainable logistic regression over QualityFeatures."""

    def __init__(self):
        # Hand-tuned priors reflecting domain knowledge: low health, high
        # calibration error, high tension deviation and complexity all
        # increase reject risk; contamination and historical defect rate too.
        self.weights = np.array([-3.0, 4.0, 3.0, 1.5, 2.5, 2.0])
        self.bias = -1.5
        self._fitted_samples = 0

    def predict_reject_probability(self, features: QualityFeatures) -> float:
        x = features.as_array()
        # health is "good when high" so invert its contribution
        z = self.bias + self.weights[0] * (1.0 - x[0]) + np.dot(self.weights[1:], x[1:])
        return float(1.0 / (1.0 + np.exp(-z)))

    def fit(self, X: np.ndarray, y: np.ndarray, lr: float = 0.05, epochs: int = 200) -> None:
        """Simple batch gradient descent, callable periodically with observed outcomes."""
        if len(X) == 0:
            return
        X_adj = X.copy()
        X_adj[:, 0] = 1.0 - X_adj[:, 0]
        n = len(X)
        w = self.weights.copy()
        b = self.bias
        for _ in range(epochs):
            z = b + X_adj @ w
            preds = 1.0 / (1.0 + np.exp(-z))
            error = preds - y
            grad_w = X_adj.T @ error / n
            grad_b = float(np.mean(error))
            w -= lr * grad_w
            b -= lr * grad_b
        self.weights, self.bias = w, b
        self._fitted_samples += n
        logger.info("LinearQualityModel refit on %d samples (total seen=%d)", n, self._fitted_samples)


def _try_build_torch_model():
    try:
        import torch
        import torch.nn as nn
    except ImportError:
        return None

    class _TorchNet(nn.Module):
        def __init__(self, n_features: int):
            super().__init__()
            self.net = nn.Sequential(
                nn.Linear(n_features, 16), nn.ReLU(),
                nn.Linear(16, 8), nn.ReLU(),
                nn.Linear(8, 1), nn.Sigmoid(),
            )

        def forward(self, x):
            return self.net(x)

    class TorchQualityModel:
        def __init__(self):
            self.torch = torch
            self.model = _TorchNet(len(FEATURE_NAMES))
            self.optimizer = torch.optim.Adam(self.model.parameters(), lr=1e-2)
            self.loss_fn = nn.BCELoss()

        def predict_reject_probability(self, features: QualityFeatures) -> float:
            x = torch.tensor(features.as_array(), dtype=torch.float32).unsqueeze(0)
            with torch.no_grad():
                return float(self.model(x).item())

        def fit(self, X: np.ndarray, y: np.ndarray, epochs: int = 50) -> None:
            if len(X) == 0:
                return
            xt = torch.tensor(X, dtype=torch.float32)
            yt = torch.tensor(y, dtype=torch.float32).unsqueeze(1)
            for _ in range(epochs):
                self.optimizer.zero_grad()
                preds = self.model(xt)
                loss = self.loss_fn(preds, yt)
                loss.backward()
                self.optimizer.step()
            logger.info("TorchQualityModel refit on %d samples, final_loss=%.4f", len(X), float(loss.item()))

    return TorchQualityModel()


def build_quality_predictor(prefer_torch: bool = True) -> QualityPredictor:
    if prefer_torch:
        torch_model = _try_build_torch_model()
        if torch_model is not None:
            logger.info("Using PyTorch quality predictor backend")
            return torch_model
    logger.info("Using NumPy linear quality predictor backend")
    return LinearQualityModel()


class QualityRiskMonitor:
    """
    Keeps a rolling buffer of (features, actual_reject) samples and
    periodically retrains the active predictor, exposing a simple
    `assess` call used by the scheduling AI to flag at-risk machines
    before their output reaches QC.
    """

    def __init__(self, predictor: QualityPredictor | None = None, retrain_every: int = 200):
        self.predictor = predictor or build_quality_predictor()
        self.retrain_every = retrain_every
        self._buffer_X: List[np.ndarray] = []
        self._buffer_y: List[float] = []

    def observe(self, features: QualityFeatures, was_rejected: bool) -> None:
        self._buffer_X.append(features.as_array())
        self._buffer_y.append(1.0 if was_rejected else 0.0)
        if len(self._buffer_X) >= self.retrain_every:
            self.predictor.fit(np.array(self._buffer_X), np.array(self._buffer_y))
            self._buffer_X.clear()
            self._buffer_y.clear()

    def assess(self, features: QualityFeatures) -> float:
        return self.predictor.predict_reject_probability(features)

    def high_risk(self, features: QualityFeatures, threshold: float = 0.5) -> bool:
        return self.assess(features) >= threshold
