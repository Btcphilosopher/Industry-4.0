"""
core/engine.py

TEXFLOW 4.0 simulation engine. Owns the FactoryFloor and every AI
subsystem (scheduling, production optimisation, quality risk
monitoring), and aggregates the per-tick output metrics the spec calls
for: metres of fabric produced, defect rate, machine uptime, energy
usage per metre, production cost per unit, quality consistency index
and waste rate.
"""

from __future__ import annotations

import statistics
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from ai.production_optimizer import Knob, ObjectiveWeights, ProductionOptimizer
from ai.quality_ai import QualityFeatures, QualityRiskMonitor
from ai.scheduling_ai import SchedulingAI, SchedulingRecommendation
from factory.factory_floor import FactoryFloor, TickReport
from utils.config import SimulationConfig
from utils.logging import GLOBAL_METRICS, get_logger

logger = get_logger("core.engine")


@dataclass
class ProductionMetricsSnapshot:
    tick: int
    sim_time: str
    metres_produced_total: float
    defect_rate_pct: float
    machine_uptime_pct: float
    energy_per_metre_kwh: float
    cost_per_metre: float
    quality_consistency_index: float
    waste_rate_pct: float
    revenue_total: float
    bottleneck_stage: Optional[str]


class SimulationEngine:
    """
    The single object main.py / the dashboard / batch simulator interact
    with. Wraps FactoryFloor with the AI decision layers and produces a
    clean metrics snapshot every tick.
    """

    def __init__(self, config: Optional[SimulationConfig] = None):
        self.config = config or SimulationConfig()
        self.floor = FactoryFloor(self.config)
        self.scheduler = SchedulingAI(self.floor.routing, self.floor.maintenance_planner)
        self.optimizer = ProductionOptimizer(weights=ObjectiveWeights())
        self.quality_monitor = QualityRiskMonitor()

        self._register_knobs()
        self.history: List[ProductionMetricsSnapshot] = []
        self.recommendations_log: List[SchedulingRecommendation] = []

    def _register_knobs(self) -> None:
        spinning = self.config.spinning
        weaving = self.config.weaving
        dyeing = self.config.dyeing

        self.optimizer.register_knob(Knob(
            name="spinning_tension_setpoint",
            get=lambda: spinning.tension_setpoint,
            set=lambda v: setattr(spinning, "tension_setpoint", v),
            lower=0.6, upper=1.6, step=0.05,
        ))
        self.optimizer.register_knob(Knob(
            name="loom_speed_rpm",
            get=lambda: weaving.loom_speed_rpm,
            set=lambda v: setattr(weaving, "loom_speed_rpm", v),
            lower=350.0, upper=900.0, step=20.0,
        ))
        self.optimizer.register_knob(Knob(
            name="dye_bath_temperature_c",
            get=lambda: dyeing.bath_temperature_c,
            set=lambda v: setattr(dyeing, "bath_temperature_c", v),
            lower=40.0, upper=95.0, step=2.5,
        ))

    def _quality_consistency_index(self, window: int = 100) -> float:
        recent = [r.yarn_quality for r in self.floor.results_log[-window:]]
        if len(recent) < 2:
            return 1.0
        mean = statistics.fmean(recent)
        if mean == 0:
            return 0.0
        stdev = statistics.pstdev(recent)
        return max(0.0, 1.0 - (stdev / mean))

    def step(self) -> ProductionMetricsSnapshot:
        tick_report: TickReport = self.floor.tick()

        recs = self.scheduler.evaluate(self.floor.all_machines, self.floor.warehouse.utilisation_pct)
        self.recommendations_log.extend(recs)
        if len(self.recommendations_log) > 500:
            self.recommendations_log = self.recommendations_log[-500:]

        recent_results = self.floor.results_log[-50:]
        for result in recent_results[-5:]:
            if result.roll is None:
                continue
            features = QualityFeatures(
                machine_health=self.floor.all_machines[0].health.health if self.floor.all_machines else 1.0,
                calibration_error=self.floor.all_machines[0].health.calibration_error if self.floor.all_machines else 0.0,
                tension_deviation=abs(1.0 - result.yarn_quality / 100.0),
                process_complexity=0.3,
                fibre_contamination=0.02,
                prior_defect_rate=result.roll.defect_density_per_m,
            )
            self.quality_monitor.observe(features, result.rejected)

        total_metres = self.floor.total_metres_produced
        defect_rate = 0.0
        if recent_results:
            total_defects = sum(r.roll.defect_count for r in recent_results if r.roll is not None)
            total_len = sum(r.roll.length_m for r in recent_results if r.roll is not None) or 1.0
            defect_rate = 100.0 * total_defects / total_len

        uptime_values = [m.health.uptime_pct for m in self.floor.all_machines]
        mean_uptime = statistics.fmean(uptime_values) if uptime_values else 100.0

        energy_per_metre = self.floor.energy_model.energy_per_metre(max(total_metres, 1.0))
        cost_per_metre = (self.floor.cost_model.total_production_cost() / max(total_metres, 1.0))
        waste_rate = self.floor.value_tracker.waste_rate_pct()
        revenue_total = self.floor.value_tracker.total_revenue()

        optimizer_step = self.optimizer.step(
            quality_score=self._quality_consistency_index() * 100.0,
            throughput_m_per_min=tick_report.metres_produced / max(self.floor.clock.minutes_per_tick, 1e-6),
            cost_per_metre=cost_per_metre,
            energy_per_metre=energy_per_metre,
        )
        if optimizer_step:
            GLOBAL_METRICS.record("engine_optimizer_step", optimizer_step.knob_name,
                                   accepted=optimizer_step.accepted)

        snapshot = ProductionMetricsSnapshot(
            tick=tick_report.tick,
            sim_time=self.floor.clock.formatted(),
            metres_produced_total=total_metres,
            defect_rate_pct=defect_rate,
            machine_uptime_pct=mean_uptime,
            energy_per_metre_kwh=energy_per_metre,
            cost_per_metre=cost_per_metre,
            quality_consistency_index=self._quality_consistency_index(),
            waste_rate_pct=waste_rate,
            revenue_total=revenue_total,
            bottleneck_stage=tick_report.bottleneck_stage,
        )
        self.history.append(snapshot)
        if len(self.history) > 5000:
            self.history = self.history[-5000:]
        return snapshot

    def run(self, ticks: Optional[int] = None) -> List[ProductionMetricsSnapshot]:
        n = ticks if ticks is not None else self.config.total_ticks
        snapshots = []
        for _ in range(n):
            snapshots.append(self.step())
        return snapshots

    def latest_snapshot(self) -> Optional[ProductionMetricsSnapshot]:
        return self.history[-1] if self.history else None
