"""
core/simulation_loop.py

The canonical TEXFLOW simulation loop, written to mirror the architecture
spec's reference loop exactly:

    for timestep in factory_simulation:
        process_fibres()
        spin_yarn_batch()
        weave_or_knit_fabric()
        dye_fabric_batches()
        apply_finishing_process()
        run_quality_inspection()
        update_machine_health()
        simulate_failures()
        optimise_factory_schedule()
        log_production_metrics()

Each of those named steps is implemented here as a thin, documented
delegation into `SimulationEngine` / `FactoryFloor`, so the mapping from
the spec's pseudocode to real code is explicit and traceable. Also
exposes a generator form (`stream_ticks`) so the dashboard can consume
snapshots incrementally without blocking on a full run.
"""

from __future__ import annotations

from typing import Iterator, Optional

from core.engine import ProductionMetricsSnapshot, SimulationEngine
from utils.logging import get_logger

logger = get_logger("core.simulation_loop")


class SimulationLoopStep:
    """
    Decomposes one SimulationEngine.step() call into the named phases
    from the architecture spec's reference loop, purely for readability
    and traceability -- the actual heavy lifting still happens inside
    FactoryFloor.tick(), which performs these phases in the same order
    for every in-flight production order each tick.
    """

    def __init__(self, engine: SimulationEngine):
        self.engine = engine

    def process_fibres(self) -> None:
        """Restock/condition raw fibre inventory ahead of spinning."""
        self.engine.floor._restock_if_needed()

    def spin_yarn_batch(self) -> None:
        """Handled inside FactoryFloor._launch_orders -> ProductionLine.run_order (stage 1)."""

    def weave_or_knit_fabric(self) -> None:
        """Handled inside ProductionLine.run_order (stage 2)."""

    def dye_fabric_batches(self) -> None:
        """Handled inside ProductionLine.run_order (stage 3)."""

    def apply_finishing_process(self) -> None:
        """Handled inside ProductionLine.run_order (stage 4)."""

    def run_quality_inspection(self) -> None:
        """Handled inside ProductionLine.run_order (stage 5)."""

    def update_machine_health(self) -> None:
        """Handled by Machine.tick() for every machine at the top of FactoryFloor.tick()."""

    def simulate_failures(self) -> None:
        """Handled by FailureSimulator.sample_failure() inside FactoryFloor.tick()."""

    def optimise_factory_schedule(self) -> None:
        """SchedulingAI.evaluate() + ProductionOptimizer.step(), run in SimulationEngine.step()."""

    def log_production_metrics(self) -> ProductionMetricsSnapshot:
        """The actual tick execution + metrics aggregation."""
        return self.engine.step()

    def run_timestep(self) -> ProductionMetricsSnapshot:
        """
        Execute one full timestep in the documented phase order. Most
        phases are no-ops here (the real work happens transactionally
        inside FactoryFloor.tick() for correctness/atomicity per order),
        but the explicit call sequence keeps this module a faithful,
        readable mirror of the architecture spec's loop.
        """
        self.process_fibres()
        self.spin_yarn_batch()
        self.weave_or_knit_fabric()
        self.dye_fabric_batches()
        self.apply_finishing_process()
        self.run_quality_inspection()
        self.update_machine_health()
        self.simulate_failures()
        self.optimise_factory_schedule()
        return self.log_production_metrics()


def run_simulation(engine: SimulationEngine, total_ticks: Optional[int] = None) -> list[ProductionMetricsSnapshot]:
    """Blocking run of `total_ticks` timesteps (defaults to engine.config.total_ticks)."""
    n = total_ticks if total_ticks is not None else engine.config.total_ticks
    loop = SimulationLoopStep(engine)
    snapshots = []
    for timestep in range(n):
        snapshot = loop.run_timestep()
        snapshots.append(snapshot)
        if timestep % 100 == 0:
            logger.info("t=%d %s | metres=%.0f defect_rate=%.2f%% uptime=%.1f%% cost/m=$%.2f",
                        timestep, snapshot.sim_time, snapshot.metres_produced_total,
                        snapshot.defect_rate_pct, snapshot.machine_uptime_pct, snapshot.cost_per_metre)
    return snapshots


def stream_ticks(engine: SimulationEngine, total_ticks: Optional[int] = None) -> Iterator[ProductionMetricsSnapshot]:
    """Generator form of run_simulation, for live dashboards / notebooks."""
    n = total_ticks if total_ticks is not None else engine.config.total_ticks
    loop = SimulationLoopStep(engine)
    for _ in range(n):
        yield loop.run_timestep()
