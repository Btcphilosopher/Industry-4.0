"""
core/time_system.py

Simulation clock. Decouples "how many minutes pass per tick" from the
rest of the system and provides shift/calendar helpers (day/night
shift, weekday) that the AI scheduling layer and economics module use
for time-of-day energy pricing and labour cost.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class Shift(str, Enum):
    DAY = "day"          # 06:00 - 14:00
    SWING = "swing"       # 14:00 - 22:00
    NIGHT = "night"        # 22:00 - 06:00


@dataclass
class SimulationClock:
    """Tracks simulated minutes elapsed and derives shift/day-of-week state."""

    tick: int = 0
    minutes_per_tick: float = 1.0
    start_minute_of_day: float = 0.0

    def advance(self) -> None:
        self.tick += 1

    @property
    def total_minutes(self) -> float:
        return self.start_minute_of_day + self.tick * self.minutes_per_tick

    @property
    def minute_of_day(self) -> float:
        return self.total_minutes % 1440.0

    @property
    def hour_of_day(self) -> float:
        return self.minute_of_day / 60.0

    @property
    def day_index(self) -> int:
        return int(self.total_minutes // 1440)

    @property
    def day_of_week(self) -> int:
        return self.day_index % 7

    @property
    def is_weekend(self) -> bool:
        return self.day_of_week >= 5

    @property
    def shift(self) -> Shift:
        hour = self.hour_of_day
        if 6.0 <= hour < 14.0:
            return Shift.DAY
        if 14.0 <= hour < 22.0:
            return Shift.SWING
        return Shift.NIGHT

    def formatted(self) -> str:
        h = int(self.hour_of_day)
        m = int(self.minute_of_day % 60)
        return f"Day {self.day_index + 1} {h:02d}:{m:02d} ({self.shift.value})"
