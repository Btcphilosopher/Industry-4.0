"""
factory/routing_system.py

Dynamic routing of work orders to machines. Implements load-balanced
machine selection (least-busy / health-weighted) across a pool of
same-kind machines, and bottleneck detection across pipeline stages --
the "factory is a living system" requirement from the architecture spec.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Sequence, TypeVar

from machines.machine_base import Machine, MachineState
from utils.logging import GLOBAL_METRICS, get_logger

logger = get_logger("factory.routing")

M = TypeVar("M", bound=Machine)


class ProductionStage(str, Enum):
    SPINNING = "spinning"
    WEAVING = "weaving"
    KNITTING = "knitting"
    DYEING = "dyeing"
    FINISHING = "finishing"
    QUALITY_CONTROL = "quality_control"
    PACKAGING = "packaging"


@dataclass
class WorkOrder:
    order_id: str
    stage: ProductionStage
    payload: dict = field(default_factory=dict)
    created_at_tick: int = 0
    priority: float = 1.0


class MachinePool:
    """A pool of interchangeable machines for one production stage."""

    def __init__(self, stage: ProductionStage, machines: Sequence[Machine]):
        self.stage = stage
        self.machines: List[Machine] = list(machines)
        self.queue: List[WorkOrder] = []

    def available_machines(self) -> List[Machine]:
        return [m for m in self.machines
                if m.state in (MachineState.IDLE, MachineState.RUNNING, MachineState.BLOCKED)
                and m.state != MachineState.FAILED]

    def select_machine(self) -> Optional[Machine]:
        """
        Health-weighted least-loaded selection: prefer machines that are
        idle, then rank by health (healthier machine produces better
        quality output), then by lowest cumulative units produced (load
        balancing).
        """
        candidates = [m for m in self.machines if m.state != MachineState.FAILED
                      and m.state != MachineState.MAINTENANCE]
        if not candidates:
            return None
        idle = [m for m in candidates if m.state == MachineState.IDLE]
        pool = idle or candidates
        pool.sort(key=lambda m: (-m.health.health, m.health.total_units_produced))
        return pool[0]

    def enqueue(self, order: WorkOrder) -> None:
        self.queue.append(order)
        self.queue.sort(key=lambda o: -o.priority)

    def dequeue(self) -> Optional[WorkOrder]:
        if not self.queue:
            return None
        return self.queue.pop(0)

    def utilisation(self) -> float:
        if not self.machines:
            return 0.0
        running = sum(1 for m in self.machines if m.state == MachineState.RUNNING)
        return running / len(self.machines)

    def queue_length(self) -> int:
        return len(self.queue)

    def healthy_capacity_fraction(self) -> float:
        if not self.machines:
            return 0.0
        return sum(m.current_throughput() for m in self.machines) / max(
            len(self.machines) * self.machines[0].config.base_throughput, 1e-9)


@dataclass
class BottleneckReport:
    stage: ProductionStage
    queue_length: int
    utilisation: float
    severity: float  # 0..1, higher = worse bottleneck


class RoutingSystem:
    """
    Coordinates multiple MachinePools across the factory, exposing
    bottleneck detection so the AI scheduler / dashboard can flag which
    stage is currently limiting throughput.
    """

    def __init__(self):
        self.pools: Dict[ProductionStage, MachinePool] = {}

    def register_pool(self, pool: MachinePool) -> None:
        self.pools[pool.stage] = pool

    def route(self, order: WorkOrder) -> None:
        pool = self.pools.get(order.stage)
        if pool is None:
            raise ValueError(f"No machine pool registered for stage {order.stage}")
        pool.enqueue(order)
        GLOBAL_METRICS.record("work_order_routed", order.order_id, stage=order.stage.value)

    def detect_bottlenecks(self) -> List[BottleneckReport]:
        reports = []
        for stage, pool in self.pools.items():
            queue_len = pool.queue_length()
            utilisation = pool.utilisation()
            # A bottleneck is a stage with a growing queue AND high utilisation.
            severity = min(1.0, (queue_len / 10.0) * 0.5 + utilisation * 0.5)
            reports.append(BottleneckReport(stage=stage, queue_length=queue_len,
                                              utilisation=utilisation, severity=severity))
        reports.sort(key=lambda r: -r.severity)
        return reports

    def worst_bottleneck(self) -> Optional[BottleneckReport]:
        reports = self.detect_bottlenecks()
        return reports[0] if reports else None
