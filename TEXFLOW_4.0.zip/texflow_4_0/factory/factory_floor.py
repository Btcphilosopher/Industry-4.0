"""
factory/factory_floor.py

Top-level factory orchestrator. Owns every machine pool, the fibre
stockroom, the logistics chain, and the economics trackers; exposes a
single `tick()` entry point that the core simulation loop calls once per
timestep. This is where the architecture spec's "factory is a living
system, not a static pipeline" principle is realised: machine selection,
scheduling and maintenance dispatch all happen dynamically here.
"""

from __future__ import annotations

import random
import uuid
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from core.time_system import SimulationClock
from dyeing.dye_bath import DyeBath
from economics.cost_model import CostModel
from economics.energy_model import EnergyModel
from economics.throughput_value import ThroughputValueTracker
from factory.production_line import ProductionLine, ProductionOrderResult
from factory.routing_system import MachinePool, ProductionStage, RoutingSystem
from finishing.finishing_line import FinishingLine
from knitting.knitting_machine import KnittingMachine
from logistics.distribution import DistributionCenter
from logistics.packaging import PackagingSystem
from logistics.warehouse import Warehouse
from machines.failure_simulation import FailureSimulator
from machines.machine_base import Machine, MachineState
from machines.maintenance_model import MaintenancePlanner
from materials.fiber_models import FiberBatch, FiberBlend, FiberType
from quality_control.vision_inspection import VisionInspectionStation
from spinning.spinning_machine import SpinningMachine
from utils.config import SimulationConfig
from utils.logging import GLOBAL_METRICS, get_logger
from weaving.loom_engine import Loom

logger = get_logger("factory.floor")


@dataclass
class TickReport:
    tick: int
    orders_completed: int
    metres_produced: float
    defects_found: int
    rejections: int
    reworks: int
    revenue: float
    cost: float
    bottleneck_stage: Optional[str]
    fleet_mean_health: float


class FactoryFloor:
    """
    Builds and owns the full machine fleet described by `FactoryConfig`
    and coordinates one simulation tick across every subsystem.
    """

    def __init__(self, config: SimulationConfig):
        self.config = config
        self.clock = SimulationClock(minutes_per_tick=config.timestep_minutes)
        self.rng = config.seed_rng()

        fc = config.factory
        self.spinning_machines = [SpinningMachine(spinning_config=config.spinning,
                                                    machine_config=config.machine)
                                   for _ in range(fc.n_spinning_machines)]
        self.looms = [Loom(weaving_config=config.weaving, machine_config=config.machine)
                      for _ in range(fc.n_looms)]
        self.knitting_machines = [KnittingMachine(knitting_config=config.knitting,
                                                    machine_config=config.machine)
                                   for _ in range(fc.n_knitting_machines)]
        self.dye_baths = [DyeBath(dyeing_config=config.dyeing, machine_config=config.machine)
                          for _ in range(fc.n_dye_baths)]
        self.finishing_lines = [FinishingLine(finishing_config=config.finishing,
                                                machine_config=config.machine)
                                 for _ in range(fc.n_finishing_lines)]
        self.vision_stations = [VisionInspectionStation(quality_config=config.quality,
                                                          machine_config=config.machine)
                                 for _ in range(fc.n_qc_stations)]

        self.all_machines: List[Machine] = (
            self.spinning_machines + self.looms + self.knitting_machines
            + self.dye_baths + self.finishing_lines + self.vision_stations
        )

        self.routing = RoutingSystem()
        self.routing.register_pool(MachinePool(ProductionStage.SPINNING, self.spinning_machines))
        self.routing.register_pool(MachinePool(ProductionStage.WEAVING, self.looms))
        self.routing.register_pool(MachinePool(ProductionStage.KNITTING, self.knitting_machines))
        self.routing.register_pool(MachinePool(ProductionStage.DYEING, self.dye_baths))
        self.routing.register_pool(MachinePool(ProductionStage.FINISHING, self.finishing_lines))
        self.routing.register_pool(MachinePool(ProductionStage.QUALITY_CONTROL, self.vision_stations))

        self.maintenance_planner = MaintenancePlanner(crew_capacity=2)
        self.failure_simulator = FailureSimulator(rng=self.rng)

        self.cost_model = CostModel(config.economics)
        self.energy_model = EnergyModel(cost_per_kwh=config.economics.energy_cost_per_kwh)
        self.value_tracker = ThroughputValueTracker()
        self.packaging = PackagingSystem()
        self.warehouse = Warehouse(capacity_m=fc.warehouse_capacity_m)
        self.distribution = DistributionCenter()

        self.production_line = ProductionLine(self.cost_model, self.energy_model,
                                                self.value_tracker, self.packaging, self.warehouse)

        self.fibre_stockroom: List[FiberBatch] = self._initial_stock()

        self.orders_completed: int = 0
        self.total_metres_produced: float = 0.0
        self.results_log: List[ProductionOrderResult] = []
        self.colors = ["undyed", "navy", "charcoal", "crimson", "forest_green", "sand"]

    def _initial_stock(self) -> List[FiberBatch]:
        blends = [
            FiberBlend({FiberType.COTTON: 1.0}),
            FiberBlend({FiberType.COTTON: 0.65, FiberType.POLYESTER: 0.35}),
            FiberBlend({FiberType.POLYESTER: 1.0}),
            FiberBlend({FiberType.WOOL: 0.8, FiberType.NYLON: 0.2}),
        ]
        return [
            FiberBatch(batch_id=f"STOCK-{i}", blend=blends[i % len(blends)], mass_kg=5000.0,
                       moisture_pct=8.0, contamination_level=0.02)
            for i in range(8)
        ]

    def _restock_if_needed(self) -> None:
        total_mass = sum(b.mass_kg for b in self.fibre_stockroom)
        if total_mass < 1000.0:
            blend = FiberBlend({FiberType.COTTON: 0.7, FiberType.POLYESTER: 0.3})
            self.fibre_stockroom.append(
                FiberBatch(batch_id=f"RESTOCK-{uuid.uuid4().hex[:6]}", blend=blend, mass_kg=5000.0)
            )
            logger.info("Restocked fibre: +5000kg")

    def _pick_batch(self) -> Optional[FiberBatch]:
        candidates = [b for b in self.fibre_stockroom if b.mass_kg > 50.0]
        if not candidates:
            return None
        return self.rng.choice(candidates)

    def _launch_orders(self, n_orders: int) -> None:
        for _ in range(n_orders):
            batch = self._pick_batch()
            if batch is None:
                continue

            spin_pool = self.routing.pools[ProductionStage.SPINNING]
            spinning_machine = spin_pool.select_machine()
            if spinning_machine is None or spinning_machine.state == MachineState.FAILED:
                continue

            construction = "woven" if self.rng.random() < 0.6 else "knitted"
            if construction == "woven":
                fabric_pool = self.routing.pools[ProductionStage.WEAVING]
                fabric_machine = fabric_pool.select_machine()
            else:
                fabric_pool = self.routing.pools[ProductionStage.KNITTING]
                fabric_machine = fabric_pool.select_machine()
            if fabric_machine is None or fabric_machine.state == MachineState.FAILED:
                continue

            dye_pool = self.routing.pools[ProductionStage.DYEING]
            dye_bath = dye_pool.select_machine()
            finishing_pool = self.routing.pools[ProductionStage.FINISHING]
            finishing_line = finishing_pool.select_machine()
            qc_pool = self.routing.pools[ProductionStage.QUALITY_CONTROL]
            vision_station = qc_pool.select_machine()

            color = self.rng.choice(self.colors)
            mass_kg = self.rng.uniform(40.0, 120.0)
            order_id = f"ORD-{uuid.uuid4().hex[:8].upper()}"

            try:
                result = self.production_line.run_order(
                    self.rng, self.clock, order_id, batch, mass_kg, construction,
                    spinning_machine, fabric_machine, dye_bath, finishing_line,
                    vision_station, dye_color=color,
                )
            except RuntimeError as exc:
                logger.warning("Order %s failed to run: %s", order_id, exc)
                continue

            self.orders_completed += 1
            if result.roll is not None and not result.rejected:
                self.total_metres_produced += result.roll.length_m
            self.results_log.append(result)
            if len(self.results_log) > 2000:
                self.results_log = self.results_log[-2000:]

    def tick(self) -> TickReport:
        self._restock_if_needed()

        # Advance every machine's wear/failure/maintenance state.
        for m in self.all_machines:
            m.tick(self.rng, self.clock.minutes_per_tick)
            if m.state == MachineState.FAILED and not any(
                e.machine_id == m.machine_id and e.timestamp == self.clock.total_minutes
                for e in self.failure_simulator.events[-5:]
            ):
                self.failure_simulator.sample_failure(m, self.clock.total_minutes)

        self.maintenance_planner.dispatch(self.all_machines)

        orders_this_tick = max(1, int(3 * (self.clock.minutes_per_tick / 1.0)))
        before = len(self.results_log)
        self._launch_orders(orders_this_tick)
        new_results = self.results_log[before:] if before <= len(self.results_log) else self.results_log

        if self.warehouse.is_near_capacity(85.0):
            self.distribution.dispatch_from_warehouse(self.warehouse, self.clock.tick, max_trucks=2)

        defects_found = sum(r.roll.defect_count for r in new_results if r.roll is not None)
        rejections = sum(1 for r in new_results if r.rejected)
        reworks = sum(1 for r in new_results if r.reworked)
        revenue = sum(r.revenue for r in new_results)
        cost = sum(r.total_cost for r in new_results)
        metres = sum(r.roll.length_m for r in new_results if r.roll is not None and not r.rejected)

        bottleneck = self.routing.worst_bottleneck()
        healths = [m.health.health for m in self.all_machines]
        mean_health = sum(healths) / len(healths) if healths else 0.0

        report = TickReport(
            tick=self.clock.tick, orders_completed=len(new_results), metres_produced=metres,
            defects_found=defects_found, rejections=rejections, reworks=reworks,
            revenue=revenue, cost=cost,
            bottleneck_stage=(bottleneck.stage.value if bottleneck and bottleneck.severity > 0.4 else None),
            fleet_mean_health=mean_health,
        )
        GLOBAL_METRICS.record("tick_report", "factory_floor", **report.__dict__)
        self.clock.advance()
        return report

    def fleet_status(self) -> List[dict]:
        return [m.status() for m in self.all_machines]
