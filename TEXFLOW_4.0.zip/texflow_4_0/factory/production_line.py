"""
factory/production_line.py

The end-to-end production "recipe": fibre batch -> yarn -> fabric ->
dyed -> finished -> inspected -> packaged. This module wires together
every subsystem module (spinning, weaving/knitting, dyeing, finishing,
quality_control, logistics, economics) for a single work order, given a
concrete set of machines already selected by the routing system.

`factory_floor.py` is the orchestrator that decides *which* machines and
*when*; this module is the *how* -- the physical recipe itself.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Literal, Optional

from core.time_system import SimulationClock
from dyeing.dye_bath import DyeBath
from economics.cost_model import CostModel
from economics.energy_model import EnergyModel
from economics.throughput_value import ThroughputValueTracker
from finishing.finishing_line import FinishingLine
from knitting.knitting_machine import KnittingMachine
from logistics.packaging import Package, PackagingSystem
from logistics.warehouse import Warehouse
from materials.fabric_properties import FabricRoll
from materials.fiber_models import FiberBatch
from materials.yarn_properties import YarnLot
from quality_control.rejection_system import Disposition, InspectionResult
from quality_control.vision_inspection import VisionInspectionStation
from spinning.spinning_machine import SpinningMachine
from utils.logging import GLOBAL_METRICS, get_logger
from weaving.loom_engine import Loom

logger = get_logger("factory.production_line")

Construction = Literal["woven", "knitted"]


@dataclass
class ProductionOrderResult:
    order_id: str
    roll: Optional[FabricRoll]
    disposition: Optional[Disposition]
    yarn_quality: float
    total_cost: float
    revenue: float
    reworked: bool = False
    rejected: bool = False


class ProductionLine:
    """
    Stateless recipe executor -- holds shared trackers (cost, energy,
    value, packaging, warehouse) that persist across many orders, but no
    per-order state of its own.
    """

    def __init__(self, cost_model: CostModel, energy_model: EnergyModel,
                 value_tracker: ThroughputValueTracker, packaging: PackagingSystem,
                 warehouse: Warehouse):
        self.cost_model = cost_model
        self.energy_model = energy_model
        self.value_tracker = value_tracker
        self.packaging = packaging
        self.warehouse = warehouse

    def run_order(self, rng: random.Random, clock: SimulationClock, order_id: str,
                   fibre_batch: FiberBatch, mass_kg: float, construction: Construction,
                   spinning_machine: SpinningMachine,
                   fabric_machine: "Loom | KnittingMachine",
                   dye_bath: Optional[DyeBath],
                   finishing_line: Optional[FinishingLine],
                   vision_station: Optional[VisionInspectionStation],
                   dye_color: str = "undyed",
                   length_m: Optional[float] = None) -> ProductionOrderResult:

        props = fibre_batch.properties()
        energy_cost_before = self.energy_model.total_cost

        # 1. Spinning
        spin_result = spinning_machine.run_batch(rng, fibre_batch, mass_kg)
        yarn_lot: YarnLot = spin_result.yarn_lot
        self.energy_model.record_consumption(clock, spinning_machine.kind, spinning_machine.machine_id,
                                               throughput_fraction=1.0, dt_minutes=spin_result.duration_minutes,
                                               is_running=True)

        # A production order cuts a realistic single roll (tens to a few
        # hundred metres) out of the yarn lot just spun -- not the entire
        # (potentially many-kilometre) lot at once.
        target_length_m = length_m or max(10.0, min(300.0, yarn_lot.total_length_m / 400.0))

        # 2. Weaving or Knitting
        if construction == "woven" and isinstance(fabric_machine, Loom):
            weave_result = fabric_machine.weave_roll(rng, yarn_lot, yarn_lot, target_length_m)
            roll = weave_result.fabric_roll
            duration = weave_result.duration_minutes
        elif construction == "knitted" and isinstance(fabric_machine, KnittingMachine):
            knit_result = fabric_machine.knit_roll(rng, yarn_lot, target_length_m)
            roll = knit_result.fabric_roll
            duration = knit_result.duration_minutes
        else:
            raise ValueError("fabric_machine type does not match requested construction")

        self.energy_model.record_consumption(clock, fabric_machine.kind, fabric_machine.machine_id,
                                               throughput_fraction=1.0, dt_minutes=duration, is_running=True)

        # 3. Dyeing (optional -- undyed greige goods skip this stage)
        if dye_bath is not None and dye_color != "undyed":
            dye_result = dye_bath.dye_roll(rng, roll, props, dye_color)
            self.energy_model.record_consumption(clock, dye_bath.kind, dye_bath.machine_id,
                                                   throughput_fraction=1.0,
                                                   dt_minutes=dye_result.duration_minutes, is_running=True)

        # 4. Finishing (optional)
        if finishing_line is not None:
            finish_result = finishing_line.finish_roll(rng, roll, props)
            self.energy_model.record_consumption(clock, finishing_line.kind, finishing_line.machine_id,
                                                   throughput_fraction=1.0,
                                                   dt_minutes=finish_result.duration_minutes, is_running=True)

        # 5. Quality Control
        disposition: Optional[Disposition] = None
        if vision_station is not None:
            inspection: Optional[InspectionResult] = vision_station.inspect_roll(rng, roll)
            if inspection is not None:
                disposition = inspection.disposition

        reworked = False
        rejected = False
        if disposition == Disposition.REWORK:
            vision_station.rejection_system.send_to_rework(roll)
            reworked = True
        elif disposition == Disposition.REJECT:
            rejected = True
            self.value_tracker.record_rejection(roll)

        # 6. Costing -- only this order's *own* share of energy cost, not
        # the whole factory's cumulative total to date.
        waste_kg = 0.0 if not rejected else mass_kg * 0.15
        energy_cost_for_order = self.energy_model.total_cost - energy_cost_before
        breakdown = self.cost_model.record_roll_cost(
            roll, fibre_batch.blend, mass_kg, processing_minutes=duration,
            energy_cost=energy_cost_for_order, waste_kg=waste_kg,
        )

        # 7. Packaging + warehousing (only accepted goods)
        revenue = 0.0
        if not rejected:
            self.value_tracker.value_accepted_roll(roll)
            revenue = self.value_tracker.records[-1].revenue if self.value_tracker.records else 0.0
            package = self.packaging.wrap_roll(roll)
            self.warehouse.store(package, tick=clock.tick)

        GLOBAL_METRICS.record("production_order_complete", order_id, roll_id=roll.roll_id,
                               disposition=(disposition.value if disposition else "not_inspected"),
                               integrity=roll.structural_integrity_score())

        return ProductionOrderResult(
            order_id=order_id, roll=roll, disposition=disposition,
            yarn_quality=yarn_lot.quality_score(), total_cost=breakdown.total_cost,
            revenue=revenue, reworked=reworked, rejected=rejected,
        )
