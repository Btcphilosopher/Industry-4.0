"""
ui/dashboard.py

Assembles every visualisation module (factory_view, quality_heatmaps)
plus production-trend charts and the AI optimisation/scheduling
recommendation feed into a single self-contained HTML SCADA-style
dashboard -- "dense, functional, real-time, non-decorative" per the
spec. Designed to be regenerated every N ticks and written to disk, so
it works equally well from a live run or a batch report.
"""

from __future__ import annotations

from pathlib import Path
from typing import List, Optional

import plotly.graph_objects as go
from plotly.subplots import make_subplots

from core.engine import ProductionMetricsSnapshot, SimulationEngine
from materials.fabric_properties import FabricRoll
from ui.factory_view import build_fleet_health_gauge, build_machine_network_graph, build_stage_utilisation_chart
from ui.quality_heatmaps import build_defect_heatmap, build_fleet_defect_summary, build_grade_distribution
from utils.logging import get_logger

logger = get_logger("ui.dashboard")

_DARK_CSS = """
body { background:#0d1117; color:#e6edf3; font-family: 'Segoe UI', Consolas, monospace; margin:0; padding:16px; }
h1 { font-size:20px; border-bottom:1px solid #30363d; padding-bottom:8px; }
h2 { font-size:15px; color:#9da5b4; margin-top:28px; }
.grid { display:grid; grid-template-columns: repeat(2, 1fr); gap:12px; }
.grid3 { display:grid; grid-template-columns: repeat(3, 1fr); gap:12px; }
.kpi { background:#161b22; border:1px solid #30363d; border-radius:6px; padding:10px 14px; }
.kpi .label { font-size:11px; color:#8b949e; text-transform:uppercase; letter-spacing:0.05em; }
.kpi .value { font-size:22px; font-weight:600; }
.recs { background:#161b22; border:1px solid #30363d; border-radius:6px; padding:10px 14px; margin-top:10px; }
.recs li { margin-bottom:6px; font-size:13px; }
.rec-throttle { color:#f9a825; } .rec-accelerate { color:#66bb6a; }
.rec-maintenance { color:#ef5350; } .rec-steady { color:#90a4ae; }
"""


def _kpi_block(label: str, value: str) -> str:
    return f'<div class="kpi"><div class="label">{label}</div><div class="value">{value}</div></div>'


def build_throughput_trend(history: List[ProductionMetricsSnapshot]) -> go.Figure:
    ticks = [s.tick for s in history]
    fig = make_subplots(specs=[[{"secondary_y": True}]])
    fig.add_trace(go.Scatter(x=ticks, y=[s.metres_produced_total for s in history],
                              name="Cumulative Metres", line=dict(color="#42a5f5")), secondary_y=False)
    fig.add_trace(go.Scatter(x=ticks, y=[s.defect_rate_pct for s in history],
                              name="Defect Rate %", line=dict(color="#ef5350")), secondary_y=True)
    fig.update_layout(title="Production Throughput vs Defect Rate", template="plotly_dark",
                       height=360, margin=dict(l=40, r=40, t=50, b=40), legend=dict(orientation="h"))
    fig.update_yaxes(title_text="Metres Produced", secondary_y=False)
    fig.update_yaxes(title_text="Defect Rate %", secondary_y=True)
    return fig


def build_quality_trend(history: List[ProductionMetricsSnapshot]) -> go.Figure:
    ticks = [s.tick for s in history]
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=ticks, y=[s.quality_consistency_index * 100 for s in history],
                              name="Quality Consistency Index", line=dict(color="#66bb6a")))
    fig.add_trace(go.Scatter(x=ticks, y=[s.machine_uptime_pct for s in history],
                              name="Machine Uptime %", line=dict(color="#ab47bc")))
    fig.update_layout(title="Quality & Uptime Trend", template="plotly_dark", height=340,
                       margin=dict(l=40, r=40, t=50, b=40), legend=dict(orientation="h"))
    return fig


def build_economics_trend(history: List[ProductionMetricsSnapshot]) -> go.Figure:
    ticks = [s.tick for s in history]
    fig = make_subplots(specs=[[{"secondary_y": True}]])
    fig.add_trace(go.Scatter(x=ticks, y=[s.cost_per_metre for s in history],
                              name="Cost / metre ($)", line=dict(color="#ffa726")), secondary_y=False)
    fig.add_trace(go.Scatter(x=ticks, y=[s.energy_per_metre_kwh for s in history],
                              name="Energy / metre (kWh)", line=dict(color="#26c6da")), secondary_y=True)
    fig.update_layout(title="Cost & Energy Efficiency", template="plotly_dark", height=340,
                       margin=dict(l=40, r=40, t=50, b=40), legend=dict(orientation="h"))
    return fig


class Dashboard:
    """Builds and writes the full TEXFLOW SCADA-style HTML dashboard."""

    def __init__(self, engine: SimulationEngine):
        self.engine = engine

    def _recommendations_html(self, max_items: int = 12) -> str:
        recs = self.engine.recommendations_log[-max_items:][::-1]
        css_map = {
            "throttle_order_intake": "rec-throttle",
            "accelerate_order_intake": "rec-accelerate",
            "prioritise_maintenance": "rec-maintenance",
            "rebalance_stage": "rec-throttle",
            "hold_steady": "rec-steady",
        }
        items = "".join(
            f'<li class="{css_map.get(r.rec_type.value, "")}">'
            f'<b>[{r.rec_type.value}]</b> {r.target} -- {r.rationale} (confidence={r.confidence:.0%})</li>'
            for r in recs
        )
        return f'<div class="recs"><h2>AI Scheduling Recommendations</h2><ul>{items or "<li>No recommendations yet.</li>"}</ul></div>'

    def render_html(self, sample_roll: Optional[FabricRoll] = None) -> str:
        engine = self.engine
        floor = engine.floor
        snapshot = engine.latest_snapshot()

        figs = []
        figs.append(("throughput", build_throughput_trend(engine.history)))
        figs.append(("quality", build_quality_trend(engine.history)))
        figs.append(("economics", build_economics_trend(engine.history)))
        figs.append(("network", build_machine_network_graph(floor)))
        figs.append(("utilisation", build_stage_utilisation_chart(floor)))
        figs.append(("health_gauge", build_fleet_health_gauge(floor)))
        figs.append(("grades", build_grade_distribution(floor.value_tracker.grade_distribution())))

        recent_rolls = [r.roll for r in floor.results_log[-200:] if r.roll is not None]
        figs.append(("defects_summary", build_fleet_defect_summary(recent_rolls)))

        chosen_roll = sample_roll or next((r for r in reversed(recent_rolls) if r.defects), None)
        if chosen_roll is not None:
            figs.append(("defect_heatmap", build_defect_heatmap(chosen_roll)))

        fig_html = {
            name: fig.to_html(full_html=False, include_plotlyjs=(i == 0), div_id=f"fig-{name}")
            for i, (name, fig) in enumerate(figs)
        }

        kpis = "".join([
            _kpi_block("Metres Produced", f"{snapshot.metres_produced_total:,.0f} m" if snapshot else "n/a"),
            _kpi_block("Defect Rate", f"{snapshot.defect_rate_pct:.2f}%" if snapshot else "n/a"),
            _kpi_block("Machine Uptime", f"{snapshot.machine_uptime_pct:.1f}%" if snapshot else "n/a"),
            _kpi_block("Cost / metre", f"${snapshot.cost_per_metre:.2f}" if snapshot else "n/a"),
            _kpi_block("Energy / metre", f"{snapshot.energy_per_metre_kwh:.3f} kWh" if snapshot else "n/a"),
            _kpi_block("Waste Rate", f"{snapshot.waste_rate_pct:.2f}%" if snapshot else "n/a"),
            _kpi_block("Quality Index", f"{snapshot.quality_consistency_index * 100:.1f}" if snapshot else "n/a"),
            _kpi_block("Revenue", f"${snapshot.revenue_total:,.0f}" if snapshot else "n/a"),
        ])

        bottleneck_note = (
            f'<p style="color:#f9a825">⚠ Current bottleneck stage: <b>{snapshot.bottleneck_stage}</b></p>'
            if snapshot and snapshot.bottleneck_stage else
            '<p style="color:#66bb6a">✓ No significant bottleneck detected</p>'
        )

        html = f"""<!doctype html>
<html><head><meta charset="utf-8"><title>TEXFLOW 4.0 -- Digital Twin Dashboard</title>
<style>{_DARK_CSS}</style></head>
<body>
<h1>TEXFLOW 4.0 -- Textile Manufacturing Digital Twin</h1>
<p>{floor.clock.formatted()} | Tick {floor.clock.tick} | Orders completed: {floor.orders_completed}</p>
{bottleneck_note}
<div class="grid3">{kpis}</div>

<h2>Production Trends</h2>
<div class="grid">
  <div>{fig_html.get('throughput', '')}</div>
  <div>{fig_html.get('quality', '')}</div>
  <div>{fig_html.get('economics', '')}</div>
  <div>{fig_html.get('grades', '')}</div>
</div>

<h2>Factory Floor</h2>
<div class="grid">
  <div>{fig_html.get('network', '')}</div>
  <div>{fig_html.get('utilisation', '')}</div>
  <div>{fig_html.get('health_gauge', '')}</div>
  <div>{fig_html.get('defects_summary', '')}</div>
</div>

<h2>Quality Control -- Sample Roll Defect Map</h2>
<div>{fig_html.get('defect_heatmap', '<p>No defective rolls sampled yet.</p>')}</div>

{self._recommendations_html()}

</body></html>"""
        return html

    def save(self, path: str | Path, sample_roll: Optional[FabricRoll] = None) -> Path:
        html = self.render_html(sample_roll=sample_roll)
        out_path = Path(path)
        out_path.write_text(html, encoding="utf-8")
        logger.info("Dashboard written to %s", out_path)
        return out_path
