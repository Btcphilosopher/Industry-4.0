"""
ui/quality_heatmaps.py

Defect heatmap rendering for individual fabric rolls: overlays the
FabricRoll density map with defect markers, coloured by severity, in the
dense "industrial SCADA" style called for in the spec.
"""

from __future__ import annotations

from typing import List, Optional

import numpy as np
import plotly.graph_objects as go

from materials.fabric_properties import FabricRoll

_SEVERITY_COLORSCALE = [
    [0.0, "#1b5e20"],
    [0.3, "#f9a825"],
    [0.6, "#ef6c00"],
    [1.0, "#b71c1c"],
]


def build_defect_heatmap(roll: FabricRoll) -> go.Figure:
    """
    A density heatmap of the fabric roll with defect markers scattered on
    top, sized/coloured by severity -- mirrors what a real automated
    vision-inspection HMI shows an operator for a flagged roll.
    """
    density = roll.density_heatmap_normalized()
    fig = go.Figure()

    fig.add_trace(go.Heatmap(
        z=density.T if density.size else np.zeros((1, 1)),
        colorscale="Greys", showscale=False, opacity=0.6, name="density",
    ))

    if roll.defects:
        rows = [d.position_m / max(roll.length_m, 1e-9) * density.shape[0] for d in roll.defects]
        cols = [d.position_cm_across / max(roll.width_cm, 1e-9) * density.shape[1] for d in roll.defects]
        severities = [d.severity for d in roll.defects]
        texts = [f"{d.defect_type} (sev={d.severity:.2f}) @ {d.position_m:.1f}m" for d in roll.defects]

        fig.add_trace(go.Scatter(
            x=rows, y=cols, mode="markers",
            marker=dict(
                size=[6 + s * 14 for s in severities],
                color=severities, colorscale=_SEVERITY_COLORSCALE,
                cmin=0, cmax=1, showscale=True,
                colorbar=dict(title="Severity"),
                line=dict(width=1, color="black"),
            ),
            text=texts, hoverinfo="text", name="defects",
        ))

    fig.update_layout(
        title=f"Defect Map -- {roll.roll_id} ({roll.construction.value}, "
              f"integrity={roll.structural_integrity_score():.1f})",
        xaxis_title="Length (roll position)", yaxis_title="Width (across roll)",
        template="plotly_dark", height=420, margin=dict(l=40, r=20, t=50, b=40),
    )
    return fig


def build_fleet_defect_summary(rolls: List[FabricRoll]) -> go.Figure:
    """Bar chart of defect-type frequency across a batch of inspected rolls."""
    from collections import Counter
    counter: Counter = Counter()
    for roll in rolls:
        for d in roll.defects:
            counter[d.defect_type] += 1

    types = list(counter.keys())
    counts = [counter[t] for t in types]

    fig = go.Figure(go.Bar(x=types, y=counts, marker_color="#ef6c00"))
    fig.update_layout(
        title="Defect Type Frequency (fleet-wide)",
        xaxis_title="Defect Type", yaxis_title="Occurrences",
        template="plotly_dark", height=360, margin=dict(l=40, r=20, t=50, b=80),
    )
    return fig


def build_grade_distribution(grade_counts: dict) -> go.Figure:
    colors = {"A": "#2e7d32", "B": "#9e9d24", "C": "#f57f17", "D": "#b71c1c"}
    grades = ["A", "B", "C", "D"]
    values = [grade_counts.get(g, 0) for g in grades]
    fig = go.Figure(go.Bar(x=grades, y=values, marker_color=[colors[g] for g in grades]))
    fig.update_layout(title="Output Grade Distribution", xaxis_title="Grade", yaxis_title="Rolls",
                       template="plotly_dark", height=320, margin=dict(l=40, r=20, t=50, b=40))
    return fig
