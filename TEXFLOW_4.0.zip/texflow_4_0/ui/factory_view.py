"""
ui/factory_view.py

Live factory-floor visualisations: a machine-status network graph
(nodes coloured by health/state, edges representing the production flow
between stages) and per-stage utilisation/queue charts, in the dense
SCADA-style called for by the spec.
"""

from __future__ import annotations

import math
from typing import Dict, List

import plotly.graph_objects as go

from factory.factory_floor import FactoryFloor
from factory.routing_system import ProductionStage
from machines.machine_base import Machine, MachineState

_STATE_COLORS = {
    MachineState.IDLE: "#607d8b",
    MachineState.RUNNING: "#2e7d32",
    MachineState.MAINTENANCE: "#f9a825",
    MachineState.FAILED: "#c62828",
    MachineState.BLOCKED: "#6a1b9a",
}

_STAGE_ORDER = [
    ProductionStage.SPINNING, ProductionStage.WEAVING, ProductionStage.KNITTING,
    ProductionStage.DYEING, ProductionStage.FINISHING, ProductionStage.QUALITY_CONTROL,
]


def build_machine_network_graph(floor: FactoryFloor) -> go.Figure:
    """
    Positions machines in vertical lanes per production stage (a simple
    deterministic layout, not a physics simulation) with node colour =
    machine state and node size = health, connected by faint flow lines
    between adjacent stage lanes.
    """
    stage_machines: Dict[ProductionStage, List[Machine]] = {
        ProductionStage.SPINNING: floor.spinning_machines,
        ProductionStage.WEAVING: floor.looms,
        ProductionStage.KNITTING: floor.knitting_machines,
        ProductionStage.DYEING: floor.dye_baths,
        ProductionStage.FINISHING: floor.finishing_lines,
        ProductionStage.QUALITY_CONTROL: floor.vision_stations,
    }

    node_x, node_y, node_color, node_size, node_text = [], [], [], [], []
    positions: Dict[str, tuple] = {}

    for lane_idx, stage in enumerate(_STAGE_ORDER):
        machines = stage_machines[stage]
        for row_idx, m in enumerate(machines):
            x, y = float(lane_idx), float(row_idx) - len(machines) / 2.0
            positions[m.machine_id] = (x, y)
            node_x.append(x)
            node_y.append(y)
            node_color.append(_STATE_COLORS.get(m.state, "#999999"))
            node_size.append(14 + m.health.health * 20)
            node_text.append(f"{m.machine_id}<br>state={m.state.value}<br>"
                              f"health={m.health.health:.2f}<br>throughput={m.current_throughput():.2f}")

    edge_x, edge_y = [], []
    for lane_idx in range(len(_STAGE_ORDER) - 1):
        left = stage_machines[_STAGE_ORDER[lane_idx]]
        right = stage_machines[_STAGE_ORDER[lane_idx + 1]]
        for lm in left:
            for rm in right:
                x0, y0 = positions[lm.machine_id]
                x1, y1 = positions[rm.machine_id]
                edge_x += [x0, x1, None]
                edge_y += [y0, y1, None]

    fig = go.Figure()
    fig.add_trace(go.Scatter(x=edge_x, y=edge_y, mode="lines",
                              line=dict(width=0.4, color="rgba(150,150,150,0.25)"),
                              hoverinfo="none", showlegend=False))
    fig.add_trace(go.Scatter(x=node_x, y=node_y, mode="markers", text=node_text, hoverinfo="text",
                              marker=dict(size=node_size, color=node_color, line=dict(width=1, color="white")),
                              showlegend=False))

    fig.update_layout(
        title="Factory Floor -- Machine Status Network",
        xaxis=dict(tickmode="array", tickvals=list(range(len(_STAGE_ORDER))),
                   ticktext=[s.value for s in _STAGE_ORDER], showgrid=False, zeroline=False),
        yaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        template="plotly_dark", height=460, margin=dict(l=40, r=20, t=50, b=40),
    )
    return fig


def build_stage_utilisation_chart(floor: FactoryFloor) -> go.Figure:
    reports = floor.routing.detect_bottlenecks()
    reports.sort(key=lambda r: _STAGE_ORDER.index(r.stage) if r.stage in _STAGE_ORDER else 99)
    stages = [r.stage.value for r in reports]
    utilisation = [r.utilisation * 100 for r in reports]
    queue = [r.queue_length for r in reports]

    fig = go.Figure()
    fig.add_trace(go.Bar(x=stages, y=utilisation, name="Utilisation %", marker_color="#1976d2"))
    fig.add_trace(go.Scatter(x=stages, y=queue, name="Queue Length", yaxis="y2",
                              mode="lines+markers", line=dict(color="#f9a825")))

    fig.update_layout(
        title="Stage Utilisation & Queue Depth",
        yaxis=dict(title="Utilisation %", range=[0, 100]),
        yaxis2=dict(title="Queue Length", overlaying="y", side="right"),
        template="plotly_dark", height=360, margin=dict(l=40, r=40, t=50, b=40),
        legend=dict(orientation="h"),
    )
    return fig


def build_fleet_health_gauge(floor: FactoryFloor) -> go.Figure:
    healths = [m.health.health for m in floor.all_machines]
    mean_health = (sum(healths) / len(healths)) * 100 if healths else 100.0

    fig = go.Figure(go.Indicator(
        mode="gauge+number", value=mean_health,
        title={"text": "Fleet Mean Health %"},
        gauge={
            "axis": {"range": [0, 100]},
            "bar": {"color": "#2e7d32"},
            "steps": [
                {"range": [0, 40], "color": "#b71c1c"},
                {"range": [40, 70], "color": "#f9a825"},
                {"range": [70, 100], "color": "#1b5e20"},
            ],
        },
    ))
    fig.update_layout(template="plotly_dark", height=280, margin=dict(l=20, r=20, t=50, b=20))
    return fig
