"""
weaving/loom_engine.py

The weaving loom: consumes YarnLot(s) as warp/weft supply and produces a
FabricRoll. Builds the fabric density map cell-by-cell as the loom beats
each pick, and injects defects via WeaveDefectSimulator.
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Optional

import numpy as np

from machines.machine_base import Machine, MachineState
from materials.fabric_properties import FabricConstruction, FabricRoll
from materials.yarn_properties import YarnLot
from spinning.tension_model import TensionController, TensionState
from utils.config import WeavingConfig, MachineConfig
from utils.logging import GLOBAL_METRICS, get_logger
from weaving.defect_sim import WeaveDefectSimulator
from weaving.pattern_generator import WeavePattern, generate_pattern, WeaveType

logger = get_logger("weaving.loom")


@dataclass
class WeavingRunResult:
    fabric_roll: FabricRoll
    duration_minutes: float
    yarn_consumed_m: float


class Loom(Machine):
    """A shuttleless weaving loom producing woven FabricRolls."""

    kind = "loom"

    def __init__(self, machine_id: Optional[str] = None,
                 weaving_config: Optional[WeavingConfig] = None,
                 machine_config: Optional[MachineConfig] = None,
                 weave_type: WeaveType = WeaveType.PLAIN):
        super().__init__(machine_id=machine_id, config=machine_config)
        self.weaving_config = weaving_config or WeavingConfig()
        self.pattern: WeavePattern = generate_pattern(weave_type)
        self.warp_tension = TensionController(TensionState(setpoint=1.0))
        self.defect_sim = WeaveDefectSimulator()

    def weave_roll(self, rng: random.Random, warp_yarn: YarnLot, weft_yarn: YarnLot,
                    length_m: float, width_cm: Optional[float] = None) -> WeavingRunResult:
        if self.state == MachineState.FAILED:
            raise RuntimeError(f"{self.machine_id} cannot weave while FAILED")
        self.start()

        width_cm = width_cm or (self.weaving_config.warp_ends / max(
            self.weaving_config.weft_density_picks_per_cm, 1e-6))

        # Sample the roll at a bounded resolution: each simulated "row"
        # represents an equal share of the roll's length, so a 5m sample
        # roll and a 5000m production roll cost the same to simulate.
        max_sample_rows = 600
        rows = max(1, min(int(length_m * 100), max_sample_rows))  # up to 1 row per cm
        row_length_m = length_m / rows
        cols = max(1, int(width_cm / 5))    # coarse density grid: 5cm cells across width
        density_map = np.zeros((rows, cols), dtype=np.float64)

        combined_quality = (warp_yarn.quality_score() + weft_yarn.quality_score()) / 2.0

        roll = FabricRoll(
            roll_id=FabricRoll.new_id(),
            construction=FabricConstruction.WOVEN,
            length_m=length_m,
            width_cm=width_cm,
            source_yarn_lot_id=f"{warp_yarn.lot_id}+{weft_yarn.lot_id}",
            yarn_quality_score=combined_quality,
            density_map=density_map,
        )

        loom_speed_fraction = self.current_throughput() / max(self.weaving_config.loom_speed_rpm / 600.0, 1e-6)
        base_density = self.weaving_config.weft_density_picks_per_cm

        for row in range(rows):
            position_m = row * row_length_m
            tension_value = self.warp_tension.step(rng, dt_minutes=0.02,
                                                     calibration_error=self.health.calibration_error)
            deviation = self.warp_tension.tension_deviation()

            row_density_noise = rng.gauss(0.0, 0.03 + deviation * 0.05)
            density_map[row, :] = base_density * (1.0 + row_density_noise)

            defects = self.defect_sim.sample_defects_for_metre(
                position_m=position_m,
                tension_deviation=deviation,
                loom_speed_fraction=loom_speed_fraction,
                pattern_complexity=self.pattern.complexity_score,
                calibration_error=self.health.calibration_error,
                fabric_width_cm=width_cm,
                segment_length_m=row_length_m,
            )
            for d in defects:
                roll.add_defect("weaving", d.defect_type.value, d.severity,
                                 d.position_m, d.position_cm_across, timestamp=position_m)
                # A severe defect locally disturbs the density map around it.
                col = min(cols - 1, int(d.position_cm_across / 5))
                density_map[row, col] *= (1.0 - 0.4 * d.severity)

        duration_minutes = length_m / max(self.current_throughput(), 1e-6)
        yarn_consumed_m = length_m * (self.weaving_config.warp_ends / 100.0)
        self.health.total_units_produced += length_m

        logger.debug("%s wove %.1fm roll %s, defects=%d, integrity=%.1f",
                     self.machine_id, length_m, roll.roll_id, roll.defect_count,
                     roll.structural_integrity_score())
        GLOBAL_METRICS.record("weaving_run", self.machine_id, length_m=length_m,
                               defects=roll.defect_count, integrity=roll.structural_integrity_score())

        return WeavingRunResult(fabric_roll=roll, duration_minutes=duration_minutes,
                                 yarn_consumed_m=yarn_consumed_m)
