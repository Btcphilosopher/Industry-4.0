"""
weaving/pattern_generator.py

Generates weave patterns (plain, twill, satin, and custom dobby-style
patterns) as binary interlacement matrices, and scores their relative
production complexity -- more complex patterns run slower and are more
defect prone, which downstream modules use to derate loom speed.
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from enum import Enum
from typing import List

import numpy as np


class WeaveType(str, Enum):
    PLAIN = "plain"
    TWILL_2X1 = "twill_2x1"
    TWILL_3X1 = "twill_3x1"
    SATIN_4 = "satin_4"
    DOBBY_CUSTOM = "dobby_custom"


@dataclass
class WeavePattern:
    weave_type: WeaveType
    repeat_matrix: np.ndarray  # binary matrix, 1 = warp over weft

    @property
    def complexity_score(self) -> float:
        """0..1, higher means slower loom speed and higher defect risk."""
        size = self.repeat_matrix.size
        transitions = np.sum(np.abs(np.diff(self.repeat_matrix.astype(int), axis=1)))
        transitions += np.sum(np.abs(np.diff(self.repeat_matrix.astype(int), axis=0)))
        density = transitions / max(size, 1)
        base = {
            WeaveType.PLAIN: 0.15,
            WeaveType.TWILL_2X1: 0.30,
            WeaveType.TWILL_3X1: 0.35,
            WeaveType.SATIN_4: 0.45,
            WeaveType.DOBBY_CUSTOM: 0.65,
        }[self.weave_type]
        return max(0.0, min(1.0, base + density * 0.2))


def _plain_weave() -> np.ndarray:
    return np.array([[1, 0], [0, 1]], dtype=np.uint8)


def _twill(over: int, under: int) -> np.ndarray:
    size = over + under
    matrix = np.zeros((size, size), dtype=np.uint8)
    for row in range(size):
        for col in range(size):
            matrix[row, col] = 1 if ((col - row) % size) < over else 0
    return matrix


def _satin(size: int, step: int) -> np.ndarray:
    matrix = np.zeros((size, size), dtype=np.uint8)
    for row in range(size):
        interlace_col = (row * step) % size
        matrix[row, interlace_col] = 1
    return matrix


def generate_pattern(weave_type: WeaveType, rng: random.Random | None = None,
                      custom_size: int = 8) -> WeavePattern:
    if weave_type == WeaveType.PLAIN:
        matrix = _plain_weave()
    elif weave_type == WeaveType.TWILL_2X1:
        matrix = _twill(2, 1)
    elif weave_type == WeaveType.TWILL_3X1:
        matrix = _twill(3, 1)
    elif weave_type == WeaveType.SATIN_4:
        matrix = _satin(4, 3)
    elif weave_type == WeaveType.DOBBY_CUSTOM:
        rng = rng or random.Random()
        matrix = np.array(
            [[1 if rng.random() > 0.5 else 0 for _ in range(custom_size)] for _ in range(custom_size)],
            dtype=np.uint8,
        )
    else:  # pragma: no cover - defensive
        raise ValueError(f"Unknown weave type: {weave_type}")
    return WeavePattern(weave_type=weave_type, repeat_matrix=matrix)


def tile_pattern(pattern: WeavePattern, warp_ends: int, picks: int) -> np.ndarray:
    """Tile a weave repeat matrix across the full warp/weft grid."""
    reps_y = int(np.ceil(picks / pattern.repeat_matrix.shape[0]))
    reps_x = int(np.ceil(warp_ends / pattern.repeat_matrix.shape[1]))
    tiled = np.tile(pattern.repeat_matrix, (reps_y, reps_x))
    return tiled[:picks, :warp_ends]
