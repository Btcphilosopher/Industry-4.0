"""
weaving/defect_sim.py

Stochastic defect injection for woven fabric: broken picks, warp floats,
reed marks, and weft bars. Each defect type has its own trigger
probability model driven by tension variance, loom speed, pattern
complexity and machine calibration -- this is what populates
`FabricRoll.defects` during weaving.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass
from enum import Enum
from typing import List, Tuple


class WeaveDefectType(str, Enum):
    BROKEN_PICK = "broken_pick"
    WARP_FLOAT = "warp_float"
    REED_MARK = "reed_mark"
    WEFT_BAR = "weft_bar"
    OIL_STAIN = "oil_stain"


@dataclass(frozen=True)
class WeaveDefectRisk:
    defect_type: WeaveDefectType
    base_rate: float
    tension_sensitivity: float
    speed_sensitivity: float
    complexity_sensitivity: float
    calibration_sensitivity: float
    severity_range: Tuple[float, float]


DEFECT_RISK_MODEL: List[WeaveDefectRisk] = [
    WeaveDefectRisk(WeaveDefectType.BROKEN_PICK, base_rate=0.004,
                     tension_sensitivity=0.55, speed_sensitivity=0.25,
                     complexity_sensitivity=0.10, calibration_sensitivity=0.20,
                     severity_range=(0.3, 0.8)),
    WeaveDefectRisk(WeaveDefectType.WARP_FLOAT, base_rate=0.002,
                     tension_sensitivity=0.30, speed_sensitivity=0.10,
                     complexity_sensitivity=0.45, calibration_sensitivity=0.15,
                     severity_range=(0.2, 0.6)),
    WeaveDefectRisk(WeaveDefectType.REED_MARK, base_rate=0.0015,
                     tension_sensitivity=0.20, speed_sensitivity=0.15,
                     complexity_sensitivity=0.05, calibration_sensitivity=0.40,
                     severity_range=(0.1, 0.4)),
    WeaveDefectRisk(WeaveDefectType.WEFT_BAR, base_rate=0.0025,
                     tension_sensitivity=0.40, speed_sensitivity=0.05,
                     complexity_sensitivity=0.10, calibration_sensitivity=0.25,
                     severity_range=(0.15, 0.5)),
    WeaveDefectRisk(WeaveDefectType.OIL_STAIN, base_rate=0.0008,
                     tension_sensitivity=0.0, speed_sensitivity=0.0,
                     complexity_sensitivity=0.0, calibration_sensitivity=0.6,
                     severity_range=(0.4, 0.9)),
]


@dataclass
class DefectOccurrence:
    defect_type: WeaveDefectType
    severity: float
    position_m: float
    position_cm_across: float


class WeaveDefectSimulator:
    """Rolls defect events per metre of fabric woven, given process conditions."""

    def __init__(self, rng: random.Random | None = None):
        self.rng = rng or random.Random()

    def sample_defects_for_metre(self, position_m: float, tension_deviation: float,
                                   loom_speed_fraction: float, pattern_complexity: float,
                                   calibration_error: float, fabric_width_cm: float,
                                   segment_length_m: float = 1.0) -> List[DefectOccurrence]:
        """
        `segment_length_m` is the real fabric length this single call
        represents (normally ~1m; larger when the caller is sampling a
        long roll at reduced resolution), and linearly scales each
        defect's per-metre base rate so total expected defects per real
        metre of fabric stays constant regardless of sampling resolution.
        """
        occurrences: List[DefectOccurrence] = []
        for risk in DEFECT_RISK_MODEL:
            rate_per_metre = risk.base_rate * (
                1.0
                + risk.tension_sensitivity * tension_deviation
                + risk.speed_sensitivity * max(0.0, loom_speed_fraction - 1.0)
                + risk.complexity_sensitivity * pattern_complexity
                + risk.calibration_sensitivity * calibration_error
            )
            # Poisson-style "at least one event" probability over the real
            # length this sample represents -- unlike a plain linear scale,
            # this saturates smoothly toward 1.0 instead of overshooting it
            # when segment_length_m is large (coarse sampling of long rolls).
            probability = 1.0 - math.exp(-rate_per_metre * segment_length_m)
            if self.rng.random() < probability:
                severity = self.rng.uniform(*risk.severity_range)
                occurrences.append(
                    DefectOccurrence(
                        defect_type=risk.defect_type,
                        severity=severity,
                        position_m=position_m,
                        position_cm_across=self.rng.uniform(0, fabric_width_cm),
                    )
                )
        return occurrences
