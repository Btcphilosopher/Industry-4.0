# TEXFLOW 4.0 — Textile Manufacturing Digital Twin & Industry Simulation Engine

A production-grade, modular simulation platform modelling a fully automated
Industry 4.0 textile factory end-to-end: **raw fibre → spinning → weaving /
knitting → dyeing → finishing → quality control → packaging → logistics
output.**

This is not a factory game. It's a real-time digital twin used for
production optimisation, defect simulation, and automated factory control —
a stochastic, machine-networked, continuous-flow production system, with an
AI layer that continuously tunes process setpoints and scheduling to
balance quality, throughput, energy and cost.

## Core production flow

```
Raw Fibres → Spinning → Yarn Conditioning → Weaving/Knitting → Dyeing
           → Finishing → Quality Control → Packaging → Logistics Output
```

Every stage is dynamic, stochastic, machine-dependent and quality-sensitive.

## Architecture

```
texflow_4_0/
├── core/            simulation clock, engine, main tick loop
├── materials/        fibre / yarn / fabric physical property models
├── spinning/         spinning frame, tension control, fibre alignment
├── weaving/          loom engine, weave patterns, defect injection
├── knitting/         knitting machine, stitch/loop models
├── dyeing/           dye bath, chemical diffusion, temperature control
├── finishing/         heat treatment, shrink control, coatings
├── quality_control/  vision inspection, defect classification, rejection
├── machines/         shared Machine base class, maintenance, failures
├── factory/          factory floor orchestrator, routing, production line
├── logistics/        packaging, warehouse, distribution
├── ai/               production optimiser, scheduling AI, quality AI
├── economics/        cost, energy, throughput-value models
├── simulation/        scenario runner, multi-scenario batch simulator
├── ui/                SCADA-style HTML dashboard, factory view, heatmaps
├── utils/             config, structured logging
├── tests/            pytest suite covering every subsystem
└── main.py           CLI entry point
```

## Quick start

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# Run a one-day simulation (1440 simulated minutes) and render a dashboard
python main.py run --ticks 1440 --dashboard out/dashboard.html

# Sweep the number of looms and compare throughput/quality outcomes
python main.py sweep --param factory.n_looms=2,3,4 --ticks 480 --out out/sweep.csv

# Print (or save) the default tunable configuration
python main.py config --save out/config.json
```

Then open `out/dashboard.html` in a browser for the live-style SCADA
dashboard: throughput/defect trends, quality & uptime trends, cost/energy
efficiency, a machine-status network graph, stage utilisation & queue
depth, a fleet health gauge, output grade distribution, fleet-wide defect
frequency, a sample roll defect heatmap, and the AI scheduling
recommendation feed.

## Running the test suite

```bash
pip install -r requirements.txt
pytest -q
```

## Key subsystems

- **Materials** (`materials/`): cotton, polyester, wool, nylon and
  arbitrary blends, each with tensile strength, elasticity, dye
  absorption, break probability and thermal sensitivity; yarn evenness
  (Uster-style CV%) and quality scoring; fabric structural integrity
  scoring built from density-map uniformity, defect load, yarn quality
  and dye uniformity.
- **Machines** (`machines/`): every physical asset shares a common
  `Machine` base class with throughput limiting, wear, calibration
  drift, stochastic failure (with differentiated failure modes and
  downtime distributions), and scheduled/predictive maintenance
  dispatch under limited crew capacity.
- **Factory floor** (`factory/`): dynamic health-weighted machine
  selection, per-stage work queues, bottleneck detection, and the
  fibre → yarn → fabric → dyed → finished → inspected → packaged
  production recipe (`production_line.py`).
- **AI layer** (`ai/`): a transparent simulated-annealing production
  optimiser that tunes process setpoints (tension, loom speed, dye
  temperature) against a composite quality/throughput/cost/energy
  objective; a rule-based scheduling AI that throttles/accelerates
  order intake and prioritises preventive maintenance from bottleneck
  + failure-risk signals; a quality-risk predictor with a NumPy
  logistic-regression backend that upgrades automatically to a small
  PyTorch MLP when `torch` is installed.
- **Economics** (`economics/`): per-roll cost breakdown (material,
  energy, labour, waste, amortised maintenance), time-of-day energy
  pricing, and grade-based revenue/value tracking.
- **Simulation** (`simulation/`): single-scenario runner and a
  multi-parameter, multi-seed batch simulator producing a tidy
  `pandas.DataFrame` for factory-design comparisons.

## Output metrics

Every tick the engine reports: metres of fabric produced, defect rate
(%), machine uptime (%), energy usage per metre, production cost per
metre, quality consistency index, waste rate (%), total revenue, and
the current bottleneck stage (if any).

## Tech stack

Python 3.11+, NumPy, SciPy, Pandas, SimPy, Plotly. PyTorch is optional —
the quality-prediction AI detects it at import time and falls back
seamlessly to a pure-NumPy model when it isn't installed.
