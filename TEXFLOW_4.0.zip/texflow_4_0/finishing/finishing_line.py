"""
finishing/finishing_line.py

Wraps heat_treatment, shrink_control and coating_system into a single
Machine-derived finishing line, the way a real finishing range chains
heat-setting, compressive shrinkage and a coating pad in sequence.
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Optional

from finishing.coating_system import CoatingType, apply_coating
from finishing.heat_treatment import apply_heat_treatment
from finishing.shrink_control import apply_shrink_control
from machines.machine_base import Machine, MachineState
from materials.fabric_properties import FabricRoll
from materials.fiber_models import FiberProperties
from utils.config import FinishingConfig, MachineConfig
from utils.logging import GLOBAL_METRICS, get_logger

logger = get_logger("finishing.line")


@dataclass
class FinishingRunResult:
    fabric_roll: FabricRoll
    duration_minutes: float
    stabilisation_index: float
    applied_shrinkage_pct: float


class FinishingLine(Machine):
    """A finishing range: heat-set -> compressive shrink -> coating pad."""

    kind = "finishing_line"

    def __init__(self, machine_id: Optional[str] = None,
                 finishing_config: Optional[FinishingConfig] = None,
                 machine_config: Optional[MachineConfig] = None,
                 coating_type: CoatingType = CoatingType.SOFTENER):
        super().__init__(machine_id=machine_id, config=machine_config)
        self.finishing_config = finishing_config or FinishingConfig()
        self.coating_type = coating_type

    def finish_roll(self, rng: random.Random, roll: FabricRoll,
                      fiber_props: FiberProperties, dwell_minutes: float = 20.0) -> FinishingRunResult:
        if self.state == MachineState.FAILED:
            raise RuntimeError(f"{self.machine_id} cannot finish while FAILED")
        self.start()

        heat_result = apply_heat_treatment(
            rng, roll, fiber_props,
            target_temp_c=self.finishing_config.heat_setting_temp_c,
            dwell_minutes=dwell_minutes,
            calibration_error=self.health.calibration_error,
        )

        shrink_result = apply_shrink_control(
            rng, roll, fiber_props,
            target_shrinkage_pct=self.finishing_config.target_shrinkage_pct,
            stabilisation_index=heat_result.stabilisation_index,
            calibration_error=self.health.calibration_error,
        )

        apply_coating(
            rng, roll, self.coating_type,
            target_add_on_pct=self.finishing_config.coating_add_on_pct,
            machine_quality_multiplier=self.quality_multiplier(),
            calibration_error=self.health.calibration_error,
        )

        self.health.total_units_produced += roll.length_m
        duration_minutes = dwell_minutes * 1.5

        logger.debug("%s finished roll %s stabilisation=%.2f shrinkage=%.2f%%",
                     self.machine_id, roll.roll_id, heat_result.stabilisation_index,
                     shrink_result.applied_shrinkage_pct)
        GLOBAL_METRICS.record("finishing_run", self.machine_id, roll_id=roll.roll_id,
                               stabilisation=heat_result.stabilisation_index,
                               shrinkage_pct=shrink_result.applied_shrinkage_pct)

        return FinishingRunResult(fabric_roll=roll, duration_minutes=duration_minutes,
                                   stabilisation_index=heat_result.stabilisation_index,
                                   applied_shrinkage_pct=shrink_result.applied_shrinkage_pct)
