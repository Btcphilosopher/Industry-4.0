"""
finishing/heat_treatment.py

Heat-setting / thermal finishing process model. Stabilises synthetic
fibres and relieves internal stresses, but risks scorching or excess
shrinkage if temperature drifts too high relative to fibre thermal
sensitivity.
"""

from __future__ import annotations

import random
from dataclasses import dataclass

from materials.fabric_properties import FabricRoll
from materials.fiber_models import FiberProperties


@dataclass
class HeatTreatmentResult:
    achieved_temp_c: float
    scorch_risk_events: int
    stabilisation_index: float  # 0..1, higher = fibres better heat-set


def apply_heat_treatment(rng: random.Random, roll: FabricRoll, fiber_props: FiberProperties,
                           target_temp_c: float, dwell_minutes: float,
                           calibration_error: float = 0.0) -> HeatTreatmentResult:
    temp_noise = rng.gauss(0.0, 2.0 + calibration_error * 8.0)
    achieved_temp_c = target_temp_c + temp_noise

    max_safe_c = 150.0 + (1.0 - fiber_props.thermal_sensitivity) * 60.0
    scorch_events = 0
    n_checks = max(1, int(dwell_minutes / 5))
    for _ in range(n_checks):
        local_temp = achieved_temp_c + rng.gauss(0.0, 1.5)
        if local_temp > max_safe_c:
            scorch_probability = min(1.0, (local_temp - max_safe_c) / max_safe_c * fiber_props.thermal_sensitivity)
            if rng.random() < scorch_probability:
                scorch_events += 1
                severity = min(1.0, (local_temp - max_safe_c) / max_safe_c)
                roll.add_defect("finishing", "scorch_mark", severity,
                                 position_m=rng.uniform(0, roll.length_m), timestamp=dwell_minutes)

    temp_ratio = achieved_temp_c / max(target_temp_c, 1e-6)
    stabilisation_index = max(0.0, min(1.0, 1.0 - abs(1.0 - temp_ratio) * 1.5))
    roll.finish_applied.append("heat_set")

    return HeatTreatmentResult(achieved_temp_c=achieved_temp_c, scorch_risk_events=scorch_events,
                                stabilisation_index=stabilisation_index)
