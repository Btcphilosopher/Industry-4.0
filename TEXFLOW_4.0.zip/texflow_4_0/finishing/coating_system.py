"""
finishing/coating_system.py

Surface finishing / coating application model (e.g. durable water
repellent, softener, anti-pilling treatments). Simulates coating
add-on percentage and coverage uniformity across the roll.
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from enum import Enum

from materials.fabric_properties import FabricRoll


class CoatingType(str, Enum):
    DWR = "durable_water_repellent"
    SOFTENER = "softener"
    ANTI_PILL = "anti_pilling"
    FLAME_RETARDANT = "flame_retardant"


@dataclass
class CoatingResult:
    coating_type: CoatingType
    add_on_pct: float
    coverage_uniformity: float  # 0..1


def apply_coating(rng: random.Random, roll: FabricRoll, coating_type: CoatingType,
                    target_add_on_pct: float, machine_quality_multiplier: float = 1.0,
                    calibration_error: float = 0.0) -> CoatingResult:
    noise = rng.gauss(0.0, 0.3 + calibration_error * 1.0)
    add_on_pct = max(0.0, target_add_on_pct + noise)

    coverage_uniformity = max(0.0, min(1.0, machine_quality_multiplier
                                        - calibration_error * 0.3
                                        + rng.gauss(0.0, 0.03)))
    roll.finish_applied.append(coating_type.value)

    if coverage_uniformity < 0.7:
        severity = min(1.0, (0.7 - coverage_uniformity) * 2.0)
        roll.add_defect("finishing", f"uneven_{coating_type.value}", severity,
                         position_m=roll.length_m / 2, timestamp=0.0)

    return CoatingResult(coating_type=coating_type, add_on_pct=add_on_pct,
                          coverage_uniformity=coverage_uniformity)
