"""
finishing/shrink_control.py

Compressive shrinkage / relaxation control model, applied after heat
treatment to bring the fabric roll's residual shrinkage under the
target specification before it reaches quality control.
"""

from __future__ import annotations

import random
from dataclasses import dataclass

from materials.fabric_properties import FabricRoll
from materials.fiber_models import FiberProperties


@dataclass
class ShrinkageResult:
    applied_shrinkage_pct: float
    residual_shrinkage_risk_pct: float  # shrinkage the customer might still see in wash


def apply_shrink_control(rng: random.Random, roll: FabricRoll, fiber_props: FiberProperties,
                           target_shrinkage_pct: float, stabilisation_index: float,
                           calibration_error: float = 0.0) -> ShrinkageResult:
    """
    Compressive shrinkage machines physically pre-shrink the fabric to
    hit a target so downstream washing shrinks it minimally. Poor
    stabilisation from heat treatment (low stabilisation_index) leaves
    more "residual" shrinkage risk after this stage.
    """
    control_noise = rng.gauss(0.0, 0.4 + calibration_error * 1.2)
    applied = max(0.0, target_shrinkage_pct + control_noise)
    roll.apply_shrinkage(applied)
    roll.finish_applied.append("compressive_shrink")

    fibre_elastic_recovery_penalty = fiber_props.elasticity_pct / 200.0
    residual_risk = max(
        0.0,
        (1.0 - stabilisation_index) * 4.0 + fibre_elastic_recovery_penalty - applied * 0.05,
    )

    if residual_risk > 3.0:
        severity = min(1.0, residual_risk / 8.0)
        roll.add_defect("finishing", "residual_shrinkage_risk", severity,
                         position_m=roll.length_m / 2, timestamp=0.0)

    return ShrinkageResult(applied_shrinkage_pct=applied, residual_shrinkage_risk_pct=residual_risk)
