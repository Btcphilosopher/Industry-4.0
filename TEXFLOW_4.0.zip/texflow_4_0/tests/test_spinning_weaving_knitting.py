"""Integration-style tests for spinning -> weaving/knitting production paths."""

import random

from knitting.knitting_machine import KnittingMachine
from materials.fiber_models import FiberBatch, FiberBlend, FiberType
from spinning.spinning_machine import SpinningMachine
from weaving.loom_engine import Loom


def _make_batch(mass_kg: float = 50.0) -> FiberBatch:
    blend = FiberBlend({FiberType.COTTON: 0.65, FiberType.POLYESTER: 0.35})
    return FiberBatch(batch_id="TEST-BATCH", blend=blend, mass_kg=mass_kg, contamination_level=0.01)


def test_spinning_machine_produces_yarn_lot():
    machine = SpinningMachine()
    batch = _make_batch()
    rng = random.Random(7)
    result = machine.run_batch(rng, batch, mass_to_spin_kg=10.0)

    assert result.yarn_lot.total_length_m > 0
    assert 0.0 <= result.yarn_lot.quality_score() <= 100.0
    assert batch.mass_kg == 40.0


def test_loom_weaves_fabric_roll_with_density_map():
    spin = SpinningMachine()
    batch = _make_batch()
    rng = random.Random(3)
    spin_result = spin.run_batch(rng, batch, mass_to_spin_kg=5.0)

    loom = Loom()
    weave_result = loom.weave_roll(rng, spin_result.yarn_lot, spin_result.yarn_lot, length_m=5.0)

    roll = weave_result.fabric_roll
    assert roll.length_m == 5.0
    assert roll.density_map.shape[0] > 0
    assert 0.0 <= roll.structural_integrity_score() <= 100.0


def test_knitting_machine_produces_fabric_roll():
    spin = SpinningMachine()
    batch = _make_batch()
    rng = random.Random(11)
    spin_result = spin.run_batch(rng, batch, mass_to_spin_kg=5.0)

    knit = KnittingMachine()
    knit_result = knit.knit_roll(rng, spin_result.yarn_lot, length_m=3.0)

    roll = knit_result.fabric_roll
    assert roll.length_m == 3.0
    assert roll.construction.value == "knitted"


def test_repeated_spinning_runs_degrade_machine_health():
    machine = SpinningMachine()
    batch = _make_batch(mass_kg=500.0)
    rng = random.Random(5)
    initial_health = machine.health.health
    for _ in range(20):
        machine.run_batch(rng, batch, mass_to_spin_kg=10.0)
        machine.tick(rng, dt_minutes=5.0)
    assert machine.health.total_units_produced > 0
