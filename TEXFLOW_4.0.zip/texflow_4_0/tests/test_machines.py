"""Unit tests for machines/ (base machine lifecycle, maintenance, failures)."""

import random

from machines.failure_simulation import FailureSimulator
from machines.machine_base import Machine, MachineState
from machines.maintenance_model import MaintenancePlanner
from utils.config import MachineConfig


def test_machine_starts_idle():
    m = Machine()
    assert m.state == MachineState.IDLE
    assert m.health.health == 1.0


def test_machine_wear_reduces_health_when_running():
    config = MachineConfig(wear_rate=0.01, base_failure_rate=0.0, calibration_drift_rate=0.0)
    m = Machine(config=config)
    m.start()
    rng = random.Random(0)
    for _ in range(50):
        m.tick(rng, dt_minutes=1.0)
    assert m.health.health < 1.0
    assert m.health.total_units_produced > 0


def test_machine_enters_maintenance_after_interval():
    config = MachineConfig(maintenance_interval_minutes=10.0, maintenance_duration_minutes=5.0,
                            base_failure_rate=0.0)
    m = Machine(config=config)
    m.start()
    rng = random.Random(0)
    for _ in range(10):
        m.tick(rng, dt_minutes=1.0)
    assert m.state == MachineState.MAINTENANCE


def test_machine_maintenance_restores_health():
    config = MachineConfig(maintenance_interval_minutes=5.0, maintenance_duration_minutes=3.0,
                            wear_rate=0.05, base_failure_rate=0.0, repair_health_restore=1.0)
    m = Machine(config=config)
    m.start()
    rng = random.Random(0)
    for _ in range(30):
        m.tick(rng, dt_minutes=1.0)
    assert m.health.health > 0.5


def test_repair_restores_from_failed_state():
    m = Machine()
    m.trigger_failure()
    assert m.state == MachineState.FAILED
    m.repair()
    assert m.state == MachineState.IDLE
    assert m.health.health > 0.0


def test_failure_simulator_samples_valid_mode():
    m = Machine()
    sim = FailureSimulator(rng=random.Random(2))
    event = sim.sample_failure(m, timestamp=100.0)
    assert event.downtime_minutes > 0
    assert 0.0 <= event.quality_impact <= 1.0


def test_maintenance_planner_dispatches_within_capacity():
    machines = [Machine(config=MachineConfig(base_failure_rate=0.0)) for _ in range(5)]
    for m in machines:
        m.health.health = 0.2  # force high risk
    planner = MaintenancePlanner(crew_capacity=2, risk_threshold=0.1)
    dispatched = planner.dispatch(machines)
    assert len(dispatched) == 2
    assert sum(1 for m in machines if m.state == MachineState.MAINTENANCE) == 2
