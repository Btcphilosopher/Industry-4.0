"""Tests for dyeing, finishing and quality control stages."""

import random

import numpy as np

from dyeing.dye_bath import DyeBath
from finishing.finishing_line import FinishingLine
from materials.fabric_properties import FabricConstruction, FabricRoll
from materials.fiber_models import FiberBlend, FiberType
from quality_control.defect_classifier import DefectClassifier
from quality_control.rejection_system import Disposition, RejectionSystem
from quality_control.vision_inspection import VisionInspectionStation
from utils.config import QualityConfig


def _sample_roll(length_m: float = 20.0, width_cm: float = 150.0) -> FabricRoll:
    return FabricRoll(roll_id="R-TEST", construction=FabricConstruction.WOVEN, length_m=length_m,
                       width_cm=width_cm, source_yarn_lot_id="Y-TEST", yarn_quality_score=80.0,
                       density_map=np.random.default_rng(0).normal(24.0, 1.0, size=(int(length_m * 100), 30)))


def test_dye_bath_sets_color_and_uniformity():
    bath = DyeBath()
    roll = _sample_roll()
    props = FiberBlend({FiberType.COTTON: 1.0}).resolved_properties()
    rng = random.Random(1)
    result = bath.dye_roll(rng, roll, props, color="navy", cycle_minutes=20.0)
    assert roll.dye_color == "navy"
    assert 0.0 <= result.final_uniformity <= 1.0


def test_finishing_line_applies_finishes_and_shrinkage():
    line = FinishingLine()
    roll = _sample_roll()
    props = FiberBlend({FiberType.POLYESTER: 1.0}).resolved_properties()
    rng = random.Random(2)
    original_length = roll.length_m
    line.finish_roll(rng, roll, props, dwell_minutes=10.0)
    assert "heat_set" in roll.finish_applied
    assert "compressive_shrink" in roll.finish_applied
    assert roll.length_m <= original_length


def test_defect_classifier_produces_weighted_score():
    roll = _sample_roll()
    roll.add_defect("weaving", "broken_pick", 0.9, position_m=1.0)
    roll.add_defect("dyeing", "uneven_absorption", 0.4, position_m=2.0)
    classifier = DefectClassifier()
    profile = classifier.classify_roll(roll)
    assert profile.total_defects == 2
    assert profile.weighted_score > 0


def test_rejection_system_rejects_heavily_defective_roll():
    roll = _sample_roll(length_m=2.0)
    for _ in range(10):
        roll.add_defect("weaving", "broken_pick", 0.95, position_m=1.0)
    config = QualityConfig(inspection_sample_rate=1.0, rejection_defect_threshold=0.1)
    system = RejectionSystem(config)
    result = system.inspect(roll)
    assert result.disposition == Disposition.REJECT
    assert roll.rejected is True


def test_vision_station_inspects_and_returns_result():
    station = VisionInspectionStation(quality_config=QualityConfig(inspection_sample_rate=1.0))
    roll = _sample_roll()
    rng = random.Random(4)
    result = station.inspect_roll(rng, roll)
    assert result is not None
    assert result.disposition in {Disposition.ACCEPT, Disposition.REWORK, Disposition.REJECT}
