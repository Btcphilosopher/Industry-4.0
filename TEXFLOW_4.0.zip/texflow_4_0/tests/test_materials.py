"""Unit tests for materials/ (fibre, yarn, fabric models)."""

import random

import numpy as np
import pytest

from materials.fabric_properties import FabricConstruction, FabricRoll
from materials.fiber_models import FiberBatch, FiberBlend, FiberType
from materials.yarn_properties import YarnLot, YarnSegment


def test_fiber_blend_normalises_ratios():
    blend = FiberBlend({FiberType.COTTON: 2.0, FiberType.POLYESTER: 2.0})
    assert pytest.approx(sum(blend.composition.values()), rel=1e-6) == 1.0
    assert pytest.approx(blend.composition[FiberType.COTTON], rel=1e-6) == 0.5


def test_fiber_blend_rejects_zero_total():
    with pytest.raises(ValueError):
        FiberBlend({FiberType.COTTON: 0.0})


def test_blended_properties_between_pure_extremes():
    cotton = FiberBlend({FiberType.COTTON: 1.0}).resolved_properties()
    polyester = FiberBlend({FiberType.POLYESTER: 1.0}).resolved_properties()
    blend = FiberBlend({FiberType.COTTON: 0.5, FiberType.POLYESTER: 0.5}).resolved_properties()

    lo = min(cotton.tensile_strength_cn_tex, polyester.tensile_strength_cn_tex)
    hi = max(cotton.tensile_strength_cn_tex, polyester.tensile_strength_cn_tex)
    assert lo * 0.9 <= blend.tensile_strength_cn_tex <= hi  # blending penalty allows slight undershoot


def test_fiber_batch_consume_splits_mass():
    blend = FiberBlend({FiberType.COTTON: 1.0})
    batch = FiberBatch(batch_id="B1", blend=blend, mass_kg=100.0)
    split = batch.consume(30.0)
    assert split.mass_kg == 30.0
    assert batch.mass_kg == 70.0


def test_fiber_batch_consume_too_much_raises():
    blend = FiberBlend({FiberType.COTTON: 1.0})
    batch = FiberBatch(batch_id="B1", blend=blend, mass_kg=10.0)
    with pytest.raises(ValueError):
        batch.consume(20.0)


def test_yarn_lot_quality_score_bounds():
    props = FiberBlend({FiberType.COTTON: 1.0}).resolved_properties()
    lot = YarnLot(lot_id="Y1", source_batch_id="B1", fiber_properties=props, target_count_ne=30.0)
    rng = random.Random(1)
    for _ in range(200):
        lot.segments.append(YarnSegment(length_m=5.0, linear_density_tex=rng.gauss(20.0, 1.0),
                                         tension_cn=1.0, twist_per_m=90.0))
    score = lot.quality_score()
    assert 0.0 <= score <= 100.0
    assert lot.grade() in {"A", "B", "C", "D"}


def test_fabric_roll_structural_integrity_and_defects():
    roll = FabricRoll(roll_id="R1", construction=FabricConstruction.WOVEN, length_m=100.0,
                       width_cm=150.0, source_yarn_lot_id="Y1", yarn_quality_score=80.0,
                       density_map=np.ones((100, 30)) * 24.0)
    baseline_score = roll.structural_integrity_score()
    roll.add_defect("weaving", "broken_pick", 0.9, position_m=10.0)
    roll.add_defect("weaving", "broken_pick", 0.9, position_m=20.0)
    degraded_score = roll.structural_integrity_score()
    assert degraded_score < baseline_score


def test_fabric_roll_shrinkage_reduces_dimensions():
    roll = FabricRoll(roll_id="R2", construction=FabricConstruction.KNITTED, length_m=50.0,
                       width_cm=100.0, source_yarn_lot_id="Y1", yarn_quality_score=70.0)
    roll.apply_shrinkage(5.0)
    assert roll.length_m == pytest.approx(47.5)
    assert roll.width_cm == pytest.approx(95.0)
