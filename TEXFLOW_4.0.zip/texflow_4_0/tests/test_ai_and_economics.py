"""Tests for the AI optimisation layer and the economics/logistics modules."""

import random

from ai.production_optimizer import Knob, ProductionOptimizer
from ai.quality_ai import LinearQualityModel, QualityFeatures, QualityRiskMonitor
from economics.cost_model import CostModel
from economics.energy_model import EnergyModel
from economics.throughput_value import ThroughputValueTracker, grade_from_integrity
from logistics.packaging import PackagingSystem
from logistics.warehouse import Warehouse
from materials.fabric_properties import FabricConstruction, FabricRoll
from materials.fiber_models import FiberBlend, FiberType
from core.time_system import SimulationClock


def test_production_optimizer_step_moves_a_knob():
    state = {"speed": 500.0}
    optimizer = ProductionOptimizer(rng=random.Random(0))
    optimizer.register_knob(Knob(name="speed", get=lambda: state["speed"],
                                  set=lambda v: state.__setitem__("speed", v),
                                  lower=300.0, upper=800.0, step=50.0))
    step = optimizer.step(quality_score=80.0, throughput_m_per_min=10.0,
                           cost_per_metre=3.0, energy_per_metre=1.0)
    assert step is not None
    assert step.knob_name == "speed"


def test_quality_predictor_returns_probability_in_range():
    model = LinearQualityModel()
    features = QualityFeatures(machine_health=0.9, calibration_error=0.1, tension_deviation=0.05,
                                process_complexity=0.3, fibre_contamination=0.02, prior_defect_rate=0.01)
    p = model.predict_reject_probability(features)
    assert 0.0 <= p <= 1.0


def test_quality_risk_monitor_retrains_after_buffer_fills():
    monitor = QualityRiskMonitor(retrain_every=5)
    features = QualityFeatures(0.5, 0.5, 0.5, 0.5, 0.5, 0.5)
    for _ in range(5):
        monitor.observe(features, was_rejected=True)
    assert len(monitor._buffer_X) == 0  # buffer flushed after retrain


def test_cost_model_records_roll_cost():
    cost_model = CostModel()
    blend = FiberBlend({FiberType.COTTON: 1.0})
    roll = FabricRoll(roll_id="R1", construction=FabricConstruction.WOVEN, length_m=10.0,
                       width_cm=150.0, source_yarn_lot_id="Y1", yarn_quality_score=80.0)
    breakdown = cost_model.record_roll_cost(roll, blend, fibre_mass_kg=5.0, processing_minutes=30.0,
                                              energy_cost=2.5)
    assert breakdown.total_cost > 0
    assert breakdown.cost_per_metre(roll.length_m) > 0


def test_energy_model_accumulates_cost():
    energy = EnergyModel(cost_per_kwh=0.20)
    clock = SimulationClock()
    reading = energy.record_consumption(clock, "loom", "LOOM-1", throughput_fraction=1.0,
                                          dt_minutes=60.0, is_running=True)
    assert reading.kwh > 0
    assert energy.total_kwh == reading.kwh


def test_grade_from_integrity_thresholds():
    assert grade_from_integrity(95) == "A"
    assert grade_from_integrity(80) == "B"
    assert grade_from_integrity(60) == "C"
    assert grade_from_integrity(10) == "D"


def test_throughput_value_tracker_records_revenue():
    tracker = ThroughputValueTracker()
    roll = FabricRoll(roll_id="R1", construction=FabricConstruction.WOVEN, length_m=10.0,
                       width_cm=150.0, source_yarn_lot_id="Y1", yarn_quality_score=95.0)
    record = tracker.value_accepted_roll(roll)
    assert record.revenue > 0
    assert tracker.total_revenue() == record.revenue


def test_warehouse_capacity_and_packaging_flow():
    warehouse = Warehouse(capacity_m=100.0)
    packaging = PackagingSystem()
    roll = FabricRoll(roll_id="R1", construction=FabricConstruction.WOVEN, length_m=50.0,
                       width_cm=150.0, source_yarn_lot_id="Y1", yarn_quality_score=90.0)
    package = packaging.wrap_roll(roll)
    stored = warehouse.store(package, tick=0)
    assert stored is True
    assert warehouse.occupied_m == 50.0
    assert warehouse.has_capacity_for(40.0) is True
    assert warehouse.has_capacity_for(60.0) is False
