"""End-to-end smoke tests for the full factory floor and simulation engine."""

from core.engine import SimulationEngine
from core.simulation_loop import run_simulation
from factory.factory_floor import FactoryFloor
from utils.config import FactoryConfig, SimulationConfig


def _small_config(ticks: int = 20) -> SimulationConfig:
    config = SimulationConfig()
    config.total_ticks = ticks
    config.random_seed = 123
    config.factory = FactoryConfig(
        n_spinning_machines=1, n_looms=1, n_knitting_machines=1,
        n_dye_baths=1, n_finishing_lines=1, n_qc_stations=1,
        warehouse_capacity_m=5000.0,
    )
    return config


def test_factory_floor_tick_produces_report():
    floor = FactoryFloor(_small_config())
    report = floor.tick()
    assert report.tick == 0
    assert floor.clock.tick == 1


def test_factory_floor_runs_multiple_ticks_without_crashing():
    floor = FactoryFloor(_small_config())
    for _ in range(15):
        floor.tick()
    assert floor.clock.tick == 15
    assert len(floor.all_machines) == 6


def test_simulation_engine_step_produces_snapshot():
    engine = SimulationEngine(_small_config())
    snapshot = engine.step()
    assert snapshot.tick == 0
    assert snapshot.metres_produced_total >= 0.0


def test_run_simulation_accumulates_history():
    config = _small_config(ticks=25)
    engine = SimulationEngine(config)
    snapshots = run_simulation(engine)
    assert len(snapshots) == 25
    assert len(engine.history) == 25
    final = snapshots[-1]
    assert 0.0 <= final.machine_uptime_pct <= 100.0
    assert 0.0 <= final.waste_rate_pct <= 100.0


def test_engine_generates_scheduling_recommendations():
    config = _small_config(ticks=10)
    engine = SimulationEngine(config)
    run_simulation(engine)
    assert isinstance(engine.recommendations_log, list)
