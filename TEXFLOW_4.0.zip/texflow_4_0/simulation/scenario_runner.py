"""
simulation/scenario_runner.py

Runs a single named scenario (a SimulationConfig variant) end-to-end and
returns a structured result summary -- the building block used by
`batch_simulator.py` for multi-scenario sweeps (e.g. comparing factory
layouts, machine counts, or quality thresholds).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from core.engine import ProductionMetricsSnapshot, SimulationEngine
from core.simulation_loop import run_simulation
from utils.config import SimulationConfig
from utils.logging import get_logger

logger = get_logger("simulation.scenario_runner")


@dataclass
class ScenarioResult:
    scenario_name: str
    config: SimulationConfig
    snapshots: List[ProductionMetricsSnapshot]

    def final_snapshot(self) -> Optional[ProductionMetricsSnapshot]:
        return self.snapshots[-1] if self.snapshots else None

    def summary(self) -> Dict[str, float]:
        final = self.final_snapshot()
        if final is None:
            return {}
        return {
            "metres_produced_total": final.metres_produced_total,
            "defect_rate_pct": final.defect_rate_pct,
            "machine_uptime_pct": final.machine_uptime_pct,
            "energy_per_metre_kwh": final.energy_per_metre_kwh,
            "cost_per_metre": final.cost_per_metre,
            "quality_consistency_index": final.quality_consistency_index,
            "waste_rate_pct": final.waste_rate_pct,
            "revenue_total": final.revenue_total,
        }


class ScenarioRunner:
    def __init__(self):
        self.results: List[ScenarioResult] = []

    def run_scenario(self, scenario_name: str, config: SimulationConfig,
                       ticks: Optional[int] = None) -> ScenarioResult:
        logger.info("Running scenario '%s' for %d ticks", scenario_name,
                    ticks or config.total_ticks)
        engine = SimulationEngine(config)
        snapshots = run_simulation(engine, ticks)
        result = ScenarioResult(scenario_name=scenario_name, config=config, snapshots=snapshots)
        self.results.append(result)
        return result

    def compare(self) -> Dict[str, Dict[str, float]]:
        return {r.scenario_name: r.summary() for r in self.results}
