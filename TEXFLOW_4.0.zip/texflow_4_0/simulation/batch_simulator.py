"""
simulation/batch_simulator.py

Multi-scenario / multi-seed batch simulation driver. Runs a matrix of
SimulationConfig variants (e.g. different factory sizes, different
random seeds for Monte-Carlo confidence bands) and aggregates results
into a Pandas DataFrame for factory design / capacity planning analysis.
"""

from __future__ import annotations

import copy
import dataclasses
from dataclasses import dataclass
from typing import Callable, Dict, Iterable, List, Optional

import pandas as pd

from simulation.scenario_runner import ScenarioResult, ScenarioRunner
from utils.config import SimulationConfig
from utils.logging import get_logger

logger = get_logger("simulation.batch_simulator")


@dataclass
class SweepParameter:
    name: str                       # dotted path, e.g. "factory.n_looms"
    values: List[float]


def _apply_dotted(config: SimulationConfig, dotted_name: str, value) -> None:
    parts = dotted_name.split(".")
    target = config
    for p in parts[:-1]:
        target = getattr(target, p)
    # Sweep values arrive as floats (they come from a parsed numeric list);
    # coerce back to the field's existing type (e.g. int machine counts)
    # so we don't hand FactoryFloor a float where it expects a range() bound.
    existing = getattr(target, parts[-1], None)
    if isinstance(existing, int) and not isinstance(existing, bool):
        value = int(value)
    setattr(target, parts[-1], value)


class BatchSimulator:
    """
    Sweeps one or more parameters across a base SimulationConfig and
    across multiple random seeds, running a full scenario for each
    combination and collecting results into a tidy DataFrame.
    """

    def __init__(self, base_config: Optional[SimulationConfig] = None):
        self.base_config = base_config or SimulationConfig()
        self.runner = ScenarioRunner()

    def _build_config(self, overrides: Dict[str, float], seed: int) -> SimulationConfig:
        config = copy.deepcopy(self.base_config)
        config.random_seed = seed
        for name, value in overrides.items():
            _apply_dotted(config, name, value)
        return config

    def run_sweep(self, parameters: List[SweepParameter], seeds: Iterable[int] = (42,),
                   ticks: Optional[int] = None) -> pd.DataFrame:
        rows = []
        combos = self._cartesian(parameters)
        for combo in combos:
            for seed in seeds:
                config = self._build_config(combo, seed)
                label = ", ".join(f"{k}={v}" for k, v in combo.items()) or "baseline"
                scenario_name = f"{label} | seed={seed}"
                result = self.runner.run_scenario(scenario_name, config, ticks)
                row = {"scenario": scenario_name, "seed": seed, **combo, **result.summary()}
                rows.append(row)
                logger.info("Completed %s", scenario_name)
        return pd.DataFrame(rows)

    @staticmethod
    def _cartesian(parameters: List[SweepParameter]) -> List[Dict[str, float]]:
        if not parameters:
            return [{}]
        combos: List[Dict[str, float]] = [{}]
        for param in parameters:
            new_combos = []
            for combo in combos:
                for value in param.values:
                    new_combos.append({**combo, param.name: value})
            combos = new_combos
        return combos

    def best_scenario_by(self, df: pd.DataFrame, metric: str, minimise: bool = False) -> pd.Series:
        if df.empty:
            raise ValueError("No scenarios have been run yet")
        idx = df[metric].idxmin() if minimise else df[metric].idxmax()
        return df.loc[idx]
