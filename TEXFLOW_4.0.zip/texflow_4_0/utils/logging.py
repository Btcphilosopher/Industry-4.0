"""
utils/logging.py

Centralised structured logging for TEXFLOW 4.0.

Provides a single `get_logger` factory used across every subsystem so that
log records carry a consistent format, and a lightweight in-memory
`MetricsLog` used by the dashboard / batch simulator to pull structured
production events without re-parsing text logs.
"""

from __future__ import annotations

import logging
import sys
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Deque, Dict, List, Optional

_CONFIGURED = False
_LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)-28s | %(message)s"
_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


def _configure_root(level: int = logging.INFO) -> None:
    global _CONFIGURED
    if _CONFIGURED:
        return
    root = logging.getLogger("texflow")
    root.setLevel(level)
    handler = logging.StreamHandler(stream=sys.stdout)
    handler.setFormatter(logging.Formatter(_LOG_FORMAT, datefmt=_DATE_FORMAT))
    root.addHandler(handler)
    root.propagate = False
    _CONFIGURED = True


def get_logger(name: str, level: int = logging.INFO) -> logging.Logger:
    """Return a namespaced logger, e.g. get_logger('spinning.machine')."""
    _configure_root(level)
    logger = logging.getLogger(f"texflow.{name}")
    logger.setLevel(level)
    return logger


@dataclass
class MetricEvent:
    """A single structured production/quality/economic event."""

    timestamp: float
    category: str
    source: str
    payload: Dict[str, Any] = field(default_factory=dict)


class MetricsLog:
    """
    Bounded, thread-agnostic ring buffer of MetricEvent records.

    Every subsystem that wants to surface a number to the dashboard
    (throughput, defect, machine health, cost, ...) pushes an event here
    instead of writing ad-hoc globals. The UI layer and batch simulator
    both read from the same log.
    """

    def __init__(self, maxlen: int = 200_000) -> None:
        self._events: Deque[MetricEvent] = deque(maxlen=maxlen)
        self._counters: Dict[str, float] = {}

    def record(self, category: str, source: str, **payload: Any) -> None:
        self._events.append(
            MetricEvent(timestamp=time.time(), category=category, source=source, payload=payload)
        )

    def increment(self, counter: str, amount: float = 1.0) -> float:
        self._counters[counter] = self._counters.get(counter, 0.0) + amount
        return self._counters[counter]

    def counter(self, counter: str) -> float:
        return self._counters.get(counter, 0.0)

    def events_by_category(self, category: str) -> List[MetricEvent]:
        return [e for e in self._events if e.category == category]

    def recent(self, n: int = 50) -> List[MetricEvent]:
        return list(self._events)[-n:]

    def snapshot_counters(self) -> Dict[str, float]:
        return dict(self._counters)

    def __len__(self) -> int:
        return len(self._events)


# Process-wide default log, imported by most subsystems for convenience.
GLOBAL_METRICS = MetricsLog()
