"""
utils/config.py

Central configuration objects for TEXFLOW 4.0.

All tunable simulation constants live here (or in a JSON/YAML file loaded
through `SimulationConfig.from_file`) instead of being scattered as magic
numbers through the subsystem modules. Every dataclass is intentionally
flat and serialisable so it can be dumped to disk for reproducible runs.
"""

from __future__ import annotations

import dataclasses
import json
import random
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, Optional


@dataclass
class MachineConfig:
    base_throughput: float = 1.0          # units / minute at 100% health
    wear_rate: float = 0.00025            # health lost per unit produced
    calibration_drift_rate: float = 0.0004
    base_failure_rate: float = 0.0006     # probability of failure per tick
    maintenance_interval_minutes: float = 480.0
    maintenance_duration_minutes: float = 45.0
    repair_health_restore: float = 0.85


@dataclass
class SpinningConfig:
    target_yarn_count: float = 30.0       # Ne (English cotton count)
    tension_setpoint: float = 1.0
    max_draft_ratio: float = 40.0
    breakage_base_probability: float = 0.0015


@dataclass
class WeavingConfig:
    loom_speed_rpm: float = 600.0
    warp_ends: int = 4000
    weft_density_picks_per_cm: float = 24.0
    defect_base_rate: float = 0.01


@dataclass
class KnittingConfig:
    needle_count: int = 2400
    machine_rpm: float = 28.0
    stitch_density_courses_per_cm: float = 14.0
    drop_stitch_base_rate: float = 0.006


@dataclass
class DyeingConfig:
    bath_temperature_c: float = 60.0
    target_concentration: float = 2.5     # % owf (on weight of fibre)
    diffusion_coefficient: float = 0.08
    liquor_ratio: float = 10.0            # litres liquor : kg fabric


@dataclass
class FinishingConfig:
    heat_setting_temp_c: float = 180.0
    target_shrinkage_pct: float = 3.0
    coating_add_on_pct: float = 4.0


@dataclass
class QualityConfig:
    inspection_sample_rate: float = 1.0   # fraction of rolls inspected
    rejection_defect_threshold: float = 0.35
    rework_allowed: bool = True
    max_rework_cycles: int = 2


@dataclass
class EconomicsConfig:
    fibre_cost_per_kg: Dict[str, float] = field(
        default_factory=lambda: {
            "cotton": 1.85,
            "polyester": 1.10,
            "wool": 9.40,
            "nylon": 2.60,
        }
    )
    energy_cost_per_kwh: float = 0.19
    labor_cost_per_hour: float = 24.0
    waste_disposal_cost_per_kg: float = 0.35


@dataclass
class FactoryConfig:
    n_spinning_machines: int = 4
    n_looms: int = 3
    n_knitting_machines: int = 2
    n_dye_baths: int = 2
    n_finishing_lines: int = 2
    n_qc_stations: int = 2
    warehouse_capacity_m: float = 50_000.0


@dataclass
class SimulationConfig:
    """Top level configuration object bundling every subsystem config."""

    random_seed: int = 42
    timestep_minutes: float = 1.0
    total_ticks: int = 1440  # one simulated day by default

    machine: MachineConfig = field(default_factory=MachineConfig)
    spinning: SpinningConfig = field(default_factory=SpinningConfig)
    weaving: WeavingConfig = field(default_factory=WeavingConfig)
    knitting: KnittingConfig = field(default_factory=KnittingConfig)
    dyeing: DyeingConfig = field(default_factory=DyeingConfig)
    finishing: FinishingConfig = field(default_factory=FinishingConfig)
    quality: QualityConfig = field(default_factory=QualityConfig)
    economics: EconomicsConfig = field(default_factory=EconomicsConfig)
    factory: FactoryConfig = field(default_factory=FactoryConfig)

    def seed_rng(self) -> random.Random:
        return random.Random(self.random_seed)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)

    def save(self, path: str | Path) -> None:
        Path(path).write_text(self.to_json())

    @classmethod
    def from_file(cls, path: str | Path) -> "SimulationConfig":
        data = json.loads(Path(path).read_text())
        return cls.from_dict(data)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SimulationConfig":
        kwargs: Dict[str, Any] = {}
        field_types = {f.name: f.type for f in dataclasses.fields(cls)}
        sub_dataclasses = {
            "machine": MachineConfig,
            "spinning": SpinningConfig,
            "weaving": WeavingConfig,
            "knitting": KnittingConfig,
            "dyeing": DyeingConfig,
            "finishing": FinishingConfig,
            "quality": QualityConfig,
            "economics": EconomicsConfig,
            "factory": FactoryConfig,
        }
        for key, value in data.items():
            if key in sub_dataclasses and isinstance(value, dict):
                kwargs[key] = sub_dataclasses[key](**value)
            elif key in field_types:
                kwargs[key] = value
        return cls(**kwargs)


DEFAULT_CONFIG = SimulationConfig()
