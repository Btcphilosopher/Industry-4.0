"""
knitting/stitch_models.py

Stitch-level models for circular/flat knitting: loop length variation,
course density and drop-stitch (needle failure) defect generation.

Needle wear is tracked as a vectorised NumPy boolean array rather than a
per-needle Python loop -- with needle counts in the thousands and many
courses simulated per roll, a pure-Python per-needle loop would dominate
runtime; NumPy's vectorised RNG draws make each course's wear step a
single C-level call regardless of needle count.

A broken needle is reported exactly once, at the row it breaks -- it
produces one continuous "needle_line" defect running down the fabric
(the real-world failure mode: an unrepaired needle drops every
subsequent course, which reads as a single visible line, not hundreds
of independent point defects) rather than a fresh DefectRecord on every
row it stays broken.
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from enum import Enum
from typing import List

import numpy as np


class KnitDefectType(str, Enum):
    DROP_STITCH = "drop_stitch"
    NEEDLE_LINE = "needle_line"
    HOLE = "hole"
    PILLING_RISK = "pilling_risk"


@dataclass
class StitchState:
    loop_length_mm: float = 3.2
    course_density_per_cm: float = 14.0
    active_needles_fraction: float = 1.0  # fraction of needles currently functional


class StitchModel:
    """Tracks loop formation quality across a knitting cycle."""

    def __init__(self, target_loop_length_mm: float = 3.2, needle_count: int = 2400):
        self.state = StitchState(loop_length_mm=target_loop_length_mm)
        self.needle_count = needle_count
        self._broken = np.zeros(needle_count, dtype=bool)

    def step_needle_wear(self, rng: random.Random, calibration_error: float) -> List[int]:
        """Advance needle wear by one sampled row; returns indices of needles newly broken this step."""
        break_probability = 0.00002 * (1.0 + calibration_error * 5.0)
        np_rng = np.random.default_rng(rng.randrange(2**32))
        newly_broken_mask = (np_rng.random(self.needle_count) < break_probability) & ~self._broken
        self._broken |= newly_broken_mask
        self.state.active_needles_fraction = 1.0 - float(self._broken.sum()) / max(self.needle_count, 1)
        return np.flatnonzero(newly_broken_mask).tolist()

    def replace_needles(self) -> int:
        replaced = int(self._broken.sum())
        self._broken[:] = False
        self.state.active_needles_fraction = 1.0
        return replaced

    def sample_hole_risk(self, rng: random.Random, course_index: float,
                           width_needles: int) -> List[dict]:
        """Generic hole risk, independent of needle breakage (yarn snag, tension spike, etc.)."""
        if rng.random() < 0.0006:
            return [{
                "defect_type": KnitDefectType.HOLE.value,
                "severity": rng.uniform(0.4, 1.0),
                "needle_index": rng.randrange(width_needles),
                "course_index": course_index,
            }]
        return []

    def loop_length_sample(self, rng: random.Random, tension_deviation: float) -> float:
        noise = rng.gauss(0.0, 0.02 + tension_deviation * 0.04)
        return max(0.5, self.state.loop_length_mm * (1.0 + noise))
