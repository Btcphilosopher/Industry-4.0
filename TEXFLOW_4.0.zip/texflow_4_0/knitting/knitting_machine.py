"""
knitting/knitting_machine.py

Circular knitting machine: consumes a single YarnLot as feed and
produces a knitted FabricRoll, using StitchModel for loop-level
simulation and needle wear/failure.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass
from typing import Optional

import numpy as np

from knitting.stitch_models import StitchModel
from machines.machine_base import Machine, MachineState
from materials.fabric_properties import FabricConstruction, FabricRoll
from materials.yarn_properties import YarnLot
from spinning.tension_model import TensionController, TensionState
from utils.config import KnittingConfig, MachineConfig
from utils.logging import GLOBAL_METRICS, get_logger

logger = get_logger("knitting.machine")


@dataclass
class KnittingRunResult:
    fabric_roll: FabricRoll
    duration_minutes: float
    yarn_consumed_m: float
    needles_replaced: int


class KnittingMachine(Machine):
    """A circular/flat knitting machine producing knitted FabricRolls."""

    kind = "knitting_machine"

    def __init__(self, machine_id: Optional[str] = None,
                 knitting_config: Optional[KnittingConfig] = None,
                 machine_config: Optional[MachineConfig] = None):
        super().__init__(machine_id=machine_id, config=machine_config)
        self.knitting_config = knitting_config or KnittingConfig()
        self.stitch_model = StitchModel(needle_count=self.knitting_config.needle_count)
        self.yarn_tension = TensionController(TensionState(setpoint=1.0))

    def knit_roll(self, rng: random.Random, yarn: YarnLot, length_m: float,
                   width_cm: Optional[float] = None) -> KnittingRunResult:
        if self.state == MachineState.FAILED:
            raise RuntimeError(f"{self.machine_id} cannot knit while FAILED")
        self.start()

        width_cm = width_cm or (self.knitting_config.needle_count / max(
            self.knitting_config.stitch_density_courses_per_cm, 1e-6) * 2.0)

        # Sample at a bounded number of rows regardless of roll length --
        # each simulated row represents an equal share of the roll and its
        # per-row event rates are rescaled accordingly (see below).
        # `rows_nominal` intentionally tracks courses at a per-centimetre
        # (not literal per-course) granularity, matching the resolution
        # `drop_stitch_base_rate` and friends were calibrated against.
        rows_nominal = max(1, int(length_m * self.knitting_config.stitch_density_courses_per_cm))
        max_sample_rows = 600
        rows = min(rows_nominal, max_sample_rows)
        courses_per_sample = rows_nominal / rows
        row_length_m = length_m / rows
        cols = max(1, int(width_cm / 5))
        density_map = np.zeros((rows, cols), dtype=np.float64)

        roll = FabricRoll(
            roll_id=FabricRoll.new_id(),
            construction=FabricConstruction.KNITTED,
            length_m=length_m,
            width_cm=width_cm,
            source_yarn_lot_id=yarn.lot_id,
            yarn_quality_score=yarn.quality_score(),
            density_map=density_map,
        )

        needles_replaced_total = 0
        # base_drop_prob is calibrated per course; scale by how many real
        # courses each sampled row stands in for using a Poisson-style "at
        # least one event" probability so it saturates smoothly instead of
        # overshooting 1.0 for large courses_per_sample.
        drop_rate = self.knitting_config.drop_stitch_base_rate * (
            1.0 + self.health.calibration_error * 2.0
        )
        base_drop_prob = 1.0 - math.exp(-drop_rate * courses_per_sample)

        for row in range(rows):
            position_m = row * row_length_m

            newly_broken = self.stitch_model.step_needle_wear(rng, self.health.calibration_error)
            if self.stitch_model.state.active_needles_fraction < 0.9:
                needles_replaced_total += self.stitch_model.replace_needles()

            tension_value = self.yarn_tension.step(rng, dt_minutes=0.01,
                                                     calibration_error=self.health.calibration_error)
            deviation = self.yarn_tension.tension_deviation()
            loop_length = self.stitch_model.loop_length_sample(rng, deviation)
            density_map[row, :] = self.knitting_config.stitch_density_courses_per_cm * (
                self.stitch_model.state.loop_length_mm / max(loop_length, 1e-6)
            )

            # Each newly-broken needle registers exactly one defect (a
            # "needle line" running down the roll from this point) rather
            # than re-flagging on every subsequent row it stays broken.
            for needle in newly_broken:
                if needle >= self.knitting_config.needle_count:
                    continue
                col = min(cols - 1, int((needle / max(self.knitting_config.needle_count, 1)) * cols))
                severity = rng.uniform(0.3, 0.9)
                roll.add_defect("knitting", "needle_line", severity,
                                 position_m=position_m, position_cm_across=col * 5.0,
                                 timestamp=position_m)
                density_map[row, col] *= (1.0 - 0.5 * severity)

            if rng.random() < base_drop_prob:
                col = rng.randrange(cols)
                severity = rng.uniform(0.2, 0.7)
                roll.add_defect("knitting", "drop_stitch", severity,
                                 position_m=position_m, position_cm_across=col * 5.0,
                                 timestamp=position_m)
                density_map[row, col] *= (1.0 - 0.5 * severity)

            for d in self.stitch_model.sample_hole_risk(rng, course_index=row,
                                                          width_needles=self.knitting_config.needle_count):
                col = min(cols - 1, int((d["needle_index"] / max(self.knitting_config.needle_count, 1)) * cols))
                roll.add_defect("knitting", d["defect_type"], d["severity"],
                                 position_m=position_m, position_cm_across=col * 5.0,
                                 timestamp=position_m)
                density_map[row, col] *= (1.0 - 0.4 * d["severity"])

        duration_minutes = length_m / max(self.current_throughput(), 1e-6)
        yarn_consumed_m = length_m * (width_cm / 2.0)
        self.health.total_units_produced += length_m

        logger.debug("%s knitted %.1fm roll %s, defects=%d, needles_replaced=%d",
                     self.machine_id, length_m, roll.roll_id, roll.defect_count, needles_replaced_total)
        GLOBAL_METRICS.record("knitting_run", self.machine_id, length_m=length_m,
                               defects=roll.defect_count, needles_replaced=needles_replaced_total)

        return KnittingRunResult(fabric_roll=roll, duration_minutes=duration_minutes,
                                  yarn_consumed_m=yarn_consumed_m,
                                  needles_replaced=needles_replaced_total)
