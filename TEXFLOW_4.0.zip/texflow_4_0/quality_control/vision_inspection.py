"""
quality_control/vision_inspection.py

Machine-vision inspection station: a Machine-derived QC station that
scans FabricRoll density maps for anomalies using a simple statistical
anomaly detector (a stand-in for a real CNN-based defect detector),
adding any anomalies it finds as additional DefectRecords before handing
the roll to the RejectionSystem.
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Optional

import numpy as np

from machines.machine_base import Machine, MachineState
from materials.fabric_properties import FabricRoll
from quality_control.rejection_system import InspectionResult, RejectionSystem
from utils.config import MachineConfig, QualityConfig
from utils.logging import GLOBAL_METRICS, get_logger

logger = get_logger("quality_control.vision")


@dataclass
class VisionScanResult:
    anomalies_found: int
    false_negative_risk: float  # 0..1, chance the scan missed something


class VisionInspectionStation(Machine):
    """Automated optical inspection line camera + defect detector."""

    kind = "qc_vision_station"

    def __init__(self, machine_id: Optional[str] = None,
                 quality_config: Optional[QualityConfig] = None,
                 machine_config: Optional[MachineConfig] = None,
                 anomaly_zscore_threshold: float = 3.5,
                 max_anomalies_per_scan: int = 15):
        super().__init__(machine_id=machine_id, config=machine_config)
        self.quality_config = quality_config or QualityConfig()
        self.rejection_system = RejectionSystem(self.quality_config)
        self.anomaly_zscore_threshold = anomaly_zscore_threshold
        self.max_anomalies_per_scan = max_anomalies_per_scan

    def scan_density_map(self, rng: random.Random, roll: FabricRoll) -> VisionScanResult:
        """
        Statistical z-score anomaly scan over the fabric density map.

        Flags at most one anomaly per row (its worst-offending column),
        then keeps only the `max_anomalies_per_scan` most severe rows --
        mirroring how a real line-scan camera reports a bounded number of
        flagged *locations*, not every individual outlier pixel, and
        keeping the false-positive rate from scaling with grid resolution.
        """
        arr = roll.density_map
        if arr.size < 4:
            return VisionScanResult(anomalies_found=0, false_negative_risk=0.5)

        mean = float(np.mean(arr))
        std = float(np.std(arr)) or 1e-9
        zscores = np.abs((arr - mean) / std)

        # Camera detection reliability derates with machine calibration error.
        detection_reliability = self.quality_multiplier()

        worst_col_per_row = np.argmax(zscores, axis=1)
        worst_z_per_row = zscores[np.arange(zscores.shape[0]), worst_col_per_row]
        flagged_rows = np.argwhere(worst_z_per_row > self.anomaly_zscore_threshold).flatten()

        if flagged_rows.size > self.max_anomalies_per_scan:
            top = np.argpartition(-worst_z_per_row[flagged_rows], self.max_anomalies_per_scan - 1)
            flagged_rows = flagged_rows[top[: self.max_anomalies_per_scan]]

        anomalies_found = 0
        for row in flagged_rows.tolist():
            col = int(worst_col_per_row[row])
            if rng.random() < detection_reliability:
                severity = min(1.0, float(zscores[row, col]) / (self.anomaly_zscore_threshold * 2))
                position_m = row / max(arr.shape[0], 1) * roll.length_m
                position_cm = col / max(arr.shape[1], 1) * roll.width_cm
                roll.add_defect("quality_control", "density_anomaly", severity,
                                 position_m=position_m, position_cm_across=position_cm)
                anomalies_found += 1

        false_negative_risk = max(0.0, 1.0 - detection_reliability)
        return VisionScanResult(anomalies_found=anomalies_found, false_negative_risk=false_negative_risk)

    def inspect_roll(self, rng: random.Random, roll: FabricRoll) -> Optional[InspectionResult]:
        if self.state == MachineState.FAILED:
            raise RuntimeError(f"{self.machine_id} cannot inspect while FAILED")
        self.start()

        if not self.rejection_system.should_inspect(rng):
            GLOBAL_METRICS.record("qc_skipped_sampling", roll.roll_id)
            return None

        scan_result = self.scan_density_map(rng, roll)
        result = self.rejection_system.inspect(roll)

        self.health.total_units_produced += roll.length_m
        logger.debug("%s scanned %s: anomalies=%d, disposition=%s", self.machine_id,
                     roll.roll_id, scan_result.anomalies_found, result.disposition.value)
        GLOBAL_METRICS.record("vision_scan", self.machine_id, roll_id=roll.roll_id,
                               anomalies=scan_result.anomalies_found)
        return result
