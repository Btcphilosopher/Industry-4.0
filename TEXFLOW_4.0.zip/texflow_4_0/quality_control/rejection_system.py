"""
quality_control/rejection_system.py

Accept/reject/rework decision logic. Combines the roll's structural
integrity score and DefectProfile.weighted_score against configured
thresholds to decide the roll's disposition, and manages the automated
reprocessing (rework) loop referenced in the architecture spec.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Optional

from materials.fabric_properties import FabricRoll
from quality_control.defect_classifier import DefectClassifier, DefectProfile
from utils.config import QualityConfig
from utils.logging import GLOBAL_METRICS, get_logger

logger = get_logger("quality_control.rejection")


class Disposition(str, Enum):
    ACCEPT = "accept"
    REWORK = "rework"
    REJECT = "reject"


@dataclass
class InspectionResult:
    roll_id: str
    disposition: Disposition
    integrity_score: float
    defect_profile: DefectProfile


class RejectionSystem:
    """
    Statistical-sampling + rule-based accept/rework/reject engine.

    A roll is only actually inspected with probability
    `quality.inspection_sample_rate` (uninspected rolls pass through,
    modelling AQL sampling plans on very high-volume lines). Inspected
    rolls are scored and classified into ACCEPT / REWORK / REJECT.
    """

    def __init__(self, config: Optional[QualityConfig] = None):
        self.config = config or QualityConfig()
        self.classifier = DefectClassifier()

    def should_inspect(self, rng) -> bool:
        return rng.random() < self.config.inspection_sample_rate

    def inspect(self, roll: FabricRoll) -> InspectionResult:
        profile = self.classifier.classify_roll(roll)
        integrity = roll.structural_integrity_score()

        if profile.weighted_score >= self.config.rejection_defect_threshold * 100.0 or integrity < 35.0:
            disposition = Disposition.REJECT
        elif (profile.weighted_score >= self.config.rejection_defect_threshold * 40.0
              or integrity < 65.0) and self.config.rework_allowed and roll.reworked_count < self.config.max_rework_cycles:
            disposition = Disposition.REWORK
        else:
            disposition = Disposition.ACCEPT

        if disposition == Disposition.REJECT:
            roll.rejected = True

        logger.info("Inspected %s -> %s (integrity=%.1f, weighted_defect=%.2f)",
                    roll.roll_id, disposition.value, integrity, profile.weighted_score)
        GLOBAL_METRICS.record("qc_inspection", roll.roll_id, disposition=disposition.value,
                               integrity=integrity, weighted_defect=profile.weighted_score)

        return InspectionResult(roll_id=roll.roll_id, disposition=disposition,
                                 integrity_score=integrity, defect_profile=profile)

    def send_to_rework(self, roll: FabricRoll) -> FabricRoll:
        roll.reworked_count += 1
        # Rework partially clears cosmetic/minor defects but rarely fixes
        # majors/criticals introduced upstream.
        roll.defects = [d for d in roll.defects if d.severity >= 0.6]
        logger.info("%s sent to rework cycle #%d", roll.roll_id, roll.reworked_count)
        GLOBAL_METRICS.record("rework_cycle", roll.roll_id, cycle=roll.reworked_count)
        return roll
