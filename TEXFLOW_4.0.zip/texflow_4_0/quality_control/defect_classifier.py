"""
quality_control/defect_classifier.py

Classifies raw DefectRecord entries into a small set of severity classes
and produces a per-roll defect profile used both by rejection_system.py
and by the AI quality-optimisation layer.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from enum import Enum
from typing import Dict, List

from materials.fabric_properties import DefectRecord, FabricRoll


class DefectSeverityClass(str, Enum):
    COSMETIC = "cosmetic"       # severity < 0.3
    MINOR = "minor"             # 0.3 <= severity < 0.6
    MAJOR = "major"             # 0.6 <= severity < 0.85
    CRITICAL = "critical"       # severity >= 0.85


def classify_severity(severity: float) -> DefectSeverityClass:
    if severity >= 0.85:
        return DefectSeverityClass.CRITICAL
    if severity >= 0.6:
        return DefectSeverityClass.MAJOR
    if severity >= 0.3:
        return DefectSeverityClass.MINOR
    return DefectSeverityClass.COSMETIC


@dataclass
class DefectProfile:
    roll_id: str
    total_defects: int
    by_class: Dict[str, int]
    by_type: Dict[str, int]
    by_stage: Dict[str, int]
    weighted_score: float  # higher = worse; used by rejection threshold


_CLASS_WEIGHTS = {
    DefectSeverityClass.COSMETIC: 0.5,
    DefectSeverityClass.MINOR: 1.5,
    DefectSeverityClass.MAJOR: 4.0,
    DefectSeverityClass.CRITICAL: 10.0,
}


class DefectClassifier:
    """Machine-vision-style defect classification pipeline (rule-based stand-in for a CNN)."""

    def classify_roll(self, roll: FabricRoll) -> DefectProfile:
        by_class: Counter = Counter()
        by_type: Counter = Counter()
        by_stage: Counter = Counter()
        weighted_score = 0.0

        for d in roll.defects:
            sev_class = classify_severity(d.severity)
            by_class[sev_class.value] += 1
            by_type[d.defect_type] += 1
            by_stage[d.stage] += 1
            weighted_score += _CLASS_WEIGHTS[sev_class]

        # Normalise by roll length so a 500m roll isn't unfairly penalised
        # relative to a 5m sample.
        weighted_score = weighted_score / max(roll.length_m, 1.0) * 100.0

        return DefectProfile(
            roll_id=roll.roll_id,
            total_defects=len(roll.defects),
            by_class=dict(by_class),
            by_type=dict(by_type),
            by_stage=dict(by_stage),
            weighted_score=weighted_score,
        )

    def most_common_defect_type(self, rolls: List[FabricRoll]) -> str | None:
        counter: Counter = Counter()
        for roll in rolls:
            for d in roll.defects:
                counter[d.defect_type] += 1
        if not counter:
            return None
        return counter.most_common(1)[0][0]
