"""
spinning/tension_model.py

Models yarn tension dynamics through the spinning frame draft zone.
Tension excursions are the primary driver of end-breaks and count
variation, so this module is deliberately isolated from
`spinning_machine.py` so it can be unit tested and reused by the
weaving loom's warp tension system too.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass


@dataclass
class TensionState:
    setpoint: float = 1.0        # normalised target tension
    current: float = 1.0
    variance: float = 0.02       # process noise variance
    damping: float = 0.35        # how quickly tension reverts to setpoint


class TensionController:
    """
    Simple stochastic PID-like controller for yarn/warp tension.

    The tension signal follows an Ornstein-Uhlenbeck-style mean reverting
    random walk around the setpoint, perturbed by machine calibration
    error (bigger drift error => noisier, more biased tension).
    """

    def __init__(self, state: TensionState | None = None):
        self.state = state or TensionState()

    def step(self, rng: random.Random, dt_minutes: float, calibration_error: float = 0.0) -> float:
        s = self.state
        bias = calibration_error * 0.3
        reversion = s.damping * (s.setpoint - s.current) * dt_minutes
        noise_scale = math.sqrt(max(dt_minutes, 1e-6)) * (s.variance + calibration_error * 0.05)
        noise = rng.gauss(0.0, noise_scale)
        s.current = max(0.0, s.current + reversion + noise + bias * dt_minutes)
        return s.current

    def is_break_risk(self, threshold_high: float = 1.6, threshold_low: float = 0.35) -> bool:
        return self.state.current >= threshold_high or self.state.current <= threshold_low

    def tension_deviation(self) -> float:
        """Absolute normalised deviation from setpoint, used for quality scoring."""
        return abs(self.state.current - self.state.setpoint)

    def set_setpoint(self, setpoint: float) -> None:
        self.state.setpoint = max(0.0, setpoint)
