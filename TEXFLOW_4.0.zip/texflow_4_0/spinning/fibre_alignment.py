"""
spinning/fibre_alignment.py

Models fibre alignment (parallelisation) through the drafting zone,
which governs yarn strength and evenness independently of tension.
Poorly aligned fibres produce "neps" and localised weak points even
when tension is nominally within range.
"""

from __future__ import annotations

import random
from dataclasses import dataclass

from materials.fiber_models import FiberProperties


@dataclass
class AlignmentState:
    alignment_index: float = 0.85   # 0..1, 1.0 = perfect parallel alignment
    nep_rate_per_km: float = 5.0    # entangled fibre clusters per km of yarn


class FibreAlignmentModel:
    """
    Simulates fibre parallelisation through drafting rollers.

    Draft ratio, roller speed mismatch and fibre elasticity all affect
    how well fibres align; low alignment raises nep rate and lowers the
    strength realised from the raw fibre's tensile properties.
    """

    def __init__(self, draft_ratio: float, state: AlignmentState | None = None):
        self.draft_ratio = draft_ratio
        self.state = state or AlignmentState()

    def step(self, rng: random.Random, fiber_props: FiberProperties,
              roller_speed_variation: float, calibration_error: float) -> AlignmentState:
        # Higher draft ratios and elastic fibres are harder to keep aligned.
        elasticity_penalty = fiber_props.elasticity_pct / 400.0
        draft_penalty = max(0.0, (self.draft_ratio - 20.0) / 200.0)
        drift_penalty = calibration_error * 0.15
        noise = rng.gauss(0.0, 0.01 + roller_speed_variation * 0.05)

        target = 0.95 - elasticity_penalty - draft_penalty - drift_penalty
        self.state.alignment_index = max(0.2, min(1.0, self.state.alignment_index * 0.7
                                                    + target * 0.3 + noise))
        self.state.nep_rate_per_km = max(
            0.0, (1.0 - self.state.alignment_index) * 60.0 + rng.gauss(0.0, 1.5)
        )
        return self.state

    def realised_strength_fraction(self) -> float:
        """
        Fraction (0..1) of the raw fibre's theoretical tensile strength
        that is actually realised in the spun yarn given alignment quality.
        """
        return 0.55 + 0.45 * self.state.alignment_index
