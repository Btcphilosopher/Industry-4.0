"""
spinning/spinning_machine.py

The spinning frame: converts a FiberBatch into a YarnLot. Wires together
the tension controller and fibre alignment model on top of the shared
Machine base class, and simulates breakage events stochastically as
fibre feeds through the draft zone.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from typing import List, Optional

from machines.machine_base import Machine, MachineState
from materials.fiber_models import FiberBatch
from materials.yarn_properties import YarnLot, YarnSegment
from spinning.fibre_alignment import FibreAlignmentModel
from spinning.tension_model import TensionController, TensionState
from utils.config import SpinningConfig, MachineConfig
from utils.logging import GLOBAL_METRICS, get_logger

logger = get_logger("spinning.machine")


@dataclass
class SpinningRunResult:
    yarn_lot: YarnLot
    breakages: int
    mass_consumed_kg: float
    duration_minutes: float


class SpinningMachine(Machine):
    """
    A ring-spinning frame. `run_batch` spins a FiberBatch into a YarnLot,
    sampling per-segment thickness/tension and breakage events as it goes.
    """

    kind = "spinning_frame"

    def __init__(self, machine_id: Optional[str] = None,
                 spinning_config: Optional[SpinningConfig] = None,
                 machine_config: Optional[MachineConfig] = None):
        super().__init__(machine_id=machine_id, config=machine_config)
        self.spinning_config = spinning_config or SpinningConfig()
        self.tension = TensionController(TensionState(setpoint=self.spinning_config.tension_setpoint))
        self.alignment = FibreAlignmentModel(draft_ratio=self.spinning_config.max_draft_ratio)

    def run_batch(self, rng: random.Random, batch: FiberBatch, mass_to_spin_kg: float,
                   segment_length_m: float = 5.0, max_sample_segments: int = 300) -> SpinningRunResult:
        """
        Spin `mass_to_spin_kg` of fibre into yarn.

        A real spinning run at typical yarn counts produces many
        kilometres of yarn per kilogram of fibre, so rather than looping
        once per literal `segment_length_m` stretch (which would mean
        hundreds of thousands of iterations for a routine batch), this
        samples at most `max_sample_segments` statistically
        representative points along the run -- the same principle a real
        Uster evenness tester uses (a bounded test length standing in for
        the whole lot) -- and scales each sample to represent an equal
        share of the total spun length.
        """
        if self.state == MachineState.FAILED:
            raise RuntimeError(f"{self.machine_id} cannot spin while FAILED")
        self.start()

        props = batch.properties()
        target_count = self.spinning_config.target_yarn_count
        # tex = 590.5 / Ne (English cotton count conversion), used as target linear density
        target_tex = 590.5 / max(target_count, 1e-6)

        mass_to_spin_kg = min(mass_to_spin_kg, batch.mass_kg)
        total_length_m = (mass_to_spin_kg * 1000.0) / max(target_tex / 1000.0, 1e-9) if target_tex else 0.0
        n_segments_nominal = max(1, int(total_length_m / max(segment_length_m, 1e-6)))
        n_segments = min(n_segments_nominal, max_sample_segments)
        # Each sampled segment now represents this share of the total length,
        # which may be >= the nominal segment_length_m for long runs.
        represented_length_m = total_length_m / n_segments if n_segments else 0.0
        # Breakage probability was calibrated per `segment_length_m` of yarn;
        # rescale linearly so the expected breakage count over the whole run
        # stays consistent regardless of how coarsely we sample it.
        breakage_scale = represented_length_m / max(segment_length_m, 1e-6)

        yarn_lot = YarnLot(
            lot_id=f"YARN-{self.machine_id}-{rng.randrange(10**6):06d}",
            source_batch_id=batch.batch_id,
            fiber_properties=props,
            target_count_ne=target_count,
        )

        breakages = 0
        roller_speed_variation = 0.02 + self.health.calibration_error * 0.1

        for _ in range(n_segments):
            tension_value = self.tension.step(rng, dt_minutes=segment_length_m / 100.0,
                                                calibration_error=self.health.calibration_error)
            alignment_state = self.alignment.step(rng, props, roller_speed_variation,
                                                    self.health.calibration_error)

            # Local density noise scales inversely with alignment quality and
            # increases with tension deviation.
            noise_std = (0.06 + (1.0 - alignment_state.alignment_index) * 0.15
                         + self.tension.tension_deviation() * 0.05)
            local_density = max(0.05, rng.gauss(target_tex, target_tex * noise_std))
            twist = max(0.0, rng.gauss(target_count * 3.2, target_count * 0.15))

            yarn_lot.segments.append(
                YarnSegment(length_m=represented_length_m, linear_density_tex=local_density,
                            tension_cn=tension_value, twist_per_m=twist)
            )

            break_rate = (
                self.spinning_config.breakage_base_probability
                * (1.0 + (1.0 - alignment_state.alignment_index))
                * (1.0 + batch.contamination_level)
                * (1.5 if self.tension.is_break_risk() else 1.0)
            )
            # Poisson-style "at least one break" probability over the length
            # this sample represents, so it saturates smoothly rather than
            # overshooting 1.0 when one sample stands in for a long stretch.
            break_probability = 1.0 - math.exp(-break_rate * breakage_scale)
            if rng.random() < break_probability:
                breakages += 1

        # current_throughput() is a mass rate (kg/min) for the spinning
        # frame -- using the (potentially many-kilometre) yarn length here
        # instead of mass would wildly overstate run duration for fine
        # yarn counts, since a small mass can spin out to a huge length.
        duration_minutes = mass_to_spin_kg / max(self.current_throughput(), 1e-6)
        self.health.total_units_produced += mass_to_spin_kg
        batch.consume(mass_to_spin_kg)

        logger.debug("%s spun %.2fkg -> %.0fm yarn, breakages=%d, quality=%.1f",
                     self.machine_id, mass_to_spin_kg, total_length_m, breakages,
                     yarn_lot.quality_score())
        GLOBAL_METRICS.record("spinning_run", self.machine_id, mass_kg=mass_to_spin_kg,
                               length_m=total_length_m, breakages=breakages,
                               quality=yarn_lot.quality_score())

        return SpinningRunResult(yarn_lot=yarn_lot, breakages=breakages,
                                  mass_consumed_kg=mass_to_spin_kg,
                                  duration_minutes=duration_minutes)
