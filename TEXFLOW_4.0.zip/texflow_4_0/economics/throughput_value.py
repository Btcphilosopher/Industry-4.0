"""
economics/throughput_value.py

Translates production throughput and quality grade into revenue, and
computes the margin/value metrics the AI optimiser and dashboard use to
express "is the factory making money right now".
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

from materials.fabric_properties import FabricRoll


# Base sale price per metre by grade -- premium fabric commands a premium price.
GRADE_PRICE_PER_METRE: Dict[str, float] = {
    "A": 8.50,
    "B": 6.75,
    "C": 4.90,
    "D": 2.10,   # off-spec / seconds market
}


def grade_from_integrity(integrity_score: float) -> str:
    if integrity_score >= 90:
        return "A"
    if integrity_score >= 75:
        return "B"
    if integrity_score >= 55:
        return "C"
    return "D"


@dataclass
class RollValue:
    roll_id: str
    grade: str
    revenue: float
    length_m: float


class ThroughputValueTracker:
    def __init__(self):
        self.records: List[RollValue] = []
        self.rejected_length_m: float = 0.0

    def value_accepted_roll(self, roll: FabricRoll) -> RollValue:
        grade = grade_from_integrity(roll.structural_integrity_score())
        price = GRADE_PRICE_PER_METRE[grade]
        revenue = price * roll.length_m
        record = RollValue(roll_id=roll.roll_id, grade=grade, revenue=revenue, length_m=roll.length_m)
        self.records.append(record)
        return record

    def record_rejection(self, roll: FabricRoll) -> None:
        self.rejected_length_m += roll.length_m

    def total_revenue(self) -> float:
        return sum(r.revenue for r in self.records)

    def total_accepted_length_m(self) -> float:
        return sum(r.length_m for r in self.records)

    def waste_rate_pct(self) -> float:
        total = self.total_accepted_length_m() + self.rejected_length_m
        if total <= 0:
            return 0.0
        return 100.0 * self.rejected_length_m / total

    def revenue_per_metre(self) -> float:
        length = self.total_accepted_length_m()
        if length <= 0:
            return 0.0
        return self.total_revenue() / length

    def grade_distribution(self) -> Dict[str, int]:
        dist: Dict[str, int] = {}
        for r in self.records:
            dist[r.grade] = dist.get(r.grade, 0) + 1
        return dist
