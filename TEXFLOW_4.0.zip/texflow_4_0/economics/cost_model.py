"""
economics/cost_model.py

Rolls up material, energy, labour, waste and maintenance costs into a
per-roll and per-metre production cost -- the figure the AI production
optimiser ultimately tries to minimise subject to quality constraints.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

from economics.energy_model import EnergyModel
from materials.fabric_properties import FabricRoll
from materials.fiber_models import FiberBlend
from utils.config import EconomicsConfig


@dataclass
class CostBreakdown:
    roll_id: str
    material_cost: float
    energy_cost: float
    labor_cost: float
    waste_cost: float
    maintenance_amortised_cost: float

    @property
    def total_cost(self) -> float:
        return (self.material_cost + self.energy_cost + self.labor_cost
                + self.waste_cost + self.maintenance_amortised_cost)

    def cost_per_metre(self, length_m: float) -> float:
        if length_m <= 0:
            return 0.0
        return self.total_cost / length_m


class CostModel:
    def __init__(self, config: EconomicsConfig | None = None):
        self.config = config or EconomicsConfig()
        self.breakdowns: List[CostBreakdown] = []
        self.total_maintenance_cost: float = 0.0

    def fibre_cost(self, blend: FiberBlend, mass_kg: float) -> float:
        cost_per_kg = sum(
            self.config.fibre_cost_per_kg.get(fiber.value, 2.0) * ratio
            for fiber, ratio in blend.composition.items()
        )
        return cost_per_kg * mass_kg

    def labor_cost_for_duration(self, minutes: float, workers: float = 1.0) -> float:
        return self.config.labor_cost_per_hour * (minutes / 60.0) * workers

    def waste_cost(self, waste_kg: float) -> float:
        return waste_kg * self.config.waste_disposal_cost_per_kg

    def record_roll_cost(self, roll: FabricRoll, blend: FiberBlend, fibre_mass_kg: float,
                           processing_minutes: float, energy_cost: float,
                           waste_kg: float = 0.0, maintenance_share: float = 0.0) -> CostBreakdown:
        breakdown = CostBreakdown(
            roll_id=roll.roll_id,
            material_cost=self.fibre_cost(blend, fibre_mass_kg),
            energy_cost=energy_cost,
            labor_cost=self.labor_cost_for_duration(processing_minutes),
            waste_cost=self.waste_cost(waste_kg),
            maintenance_amortised_cost=maintenance_share,
        )
        self.breakdowns.append(breakdown)
        return breakdown

    def total_production_cost(self) -> float:
        return sum(b.total_cost for b in self.breakdowns)

    def average_cost_per_metre(self, rolls_by_id: Dict[str, FabricRoll]) -> float:
        total_cost = 0.0
        total_length = 0.0
        for b in self.breakdowns:
            roll = rolls_by_id.get(b.roll_id)
            if roll is None:
                continue
            total_cost += b.total_cost
            total_length += roll.length_m
        if total_length <= 0:
            return 0.0
        return total_cost / total_length
