"""
economics/energy_model.py

Energy consumption model per machine type and time-of-day pricing,
feeding both the cost model and the AI production optimiser's
energy-vs-throughput objective.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict

from core.time_system import SimulationClock, Shift

# Baseline power draw (kW) at 100% throughput, by machine kind.
BASE_POWER_KW: Dict[str, float] = {
    "spinning_frame": 18.0,
    "loom": 22.0,
    "knitting_machine": 15.0,
    "dye_bath": 45.0,          # heating dominates
    "finishing_line": 38.0,
    "qc_vision_station": 3.0,
}

# Time-of-day electricity price multiplier (peak/off-peak tariff).
_SHIFT_PRICE_MULTIPLIER: Dict[Shift, float] = {
    Shift.DAY: 1.15,
    Shift.SWING: 1.30,   # peak demand window
    Shift.NIGHT: 0.75,   # off-peak discount
}


@dataclass
class EnergyReading:
    machine_kind: str
    machine_id: str
    kwh: float
    cost: float


class EnergyModel:
    def __init__(self, cost_per_kwh: float = 0.19):
        self.base_cost_per_kwh = cost_per_kwh
        self.total_kwh: float = 0.0
        self.total_cost: float = 0.0
        self.readings: list[EnergyReading] = []

    def price_multiplier(self, clock: SimulationClock) -> float:
        return _SHIFT_PRICE_MULTIPLIER[clock.shift]

    def record_consumption(self, clock: SimulationClock, machine_kind: str, machine_id: str,
                             throughput_fraction: float, dt_minutes: float,
                             is_running: bool) -> EnergyReading:
        base_kw = BASE_POWER_KW.get(machine_kind, 10.0)
        idle_draw_fraction = 0.15  # machines still sip power when idle/blocked
        load_fraction = throughput_fraction if is_running else idle_draw_fraction
        kw = base_kw * load_fraction
        kwh = kw * (dt_minutes / 60.0)
        price = self.base_cost_per_kwh * self.price_multiplier(clock)
        cost = kwh * price

        self.total_kwh += kwh
        self.total_cost += cost
        reading = EnergyReading(machine_kind=machine_kind, machine_id=machine_id, kwh=kwh, cost=cost)
        self.readings.append(reading)
        return reading

    def energy_per_metre(self, total_metres_produced: float) -> float:
        if total_metres_produced <= 0:
            return 0.0
        return self.total_kwh / total_metres_produced

    def reset_readings(self, keep_last: int = 5000) -> None:
        if len(self.readings) > keep_last:
            self.readings = self.readings[-keep_last:]
