"""
logistics/packaging.py

Converts accepted FabricRolls into shippable packages (roll wrapping,
palletising) and tracks packaging material consumption/cost.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import List

from materials.fabric_properties import FabricRoll

ROLLS_PER_PALLET = 6
WRAP_COST_PER_ROLL = 1.35
PALLET_COST = 9.50


@dataclass
class Package:
    package_id: str
    roll_ids: List[str] = field(default_factory=list)
    total_length_m: float = 0.0
    is_pallet: bool = False

    def add_roll(self, roll: FabricRoll) -> None:
        self.roll_ids.append(roll.roll_id)
        self.total_length_m += roll.length_m


class PackagingSystem:
    def __init__(self):
        self.packages: List[Package] = []
        self._open_pallet: Package | None = None
        self.total_packaging_cost: float = 0.0

    def wrap_roll(self, roll: FabricRoll) -> Package:
        pkg = Package(package_id=f"PKG-{uuid.uuid4().hex[:8].upper()}")
        pkg.add_roll(roll)
        self.total_packaging_cost += WRAP_COST_PER_ROLL
        self.packages.append(pkg)
        self._add_to_pallet(pkg)
        return pkg

    def _add_to_pallet(self, pkg: Package) -> None:
        if self._open_pallet is None or len(self._open_pallet.roll_ids) >= ROLLS_PER_PALLET:
            self._open_pallet = Package(package_id=f"PLT-{uuid.uuid4().hex[:8].upper()}", is_pallet=True)
            self.total_packaging_cost += PALLET_COST
        self._open_pallet.roll_ids.extend(pkg.roll_ids)
        self._open_pallet.total_length_m += pkg.total_length_m

    def pallets(self) -> List[Package]:
        seen = {p.package_id for p in self.packages if p.is_pallet}
        return [p for p in self.packages if p.is_pallet] + (
            [self._open_pallet] if self._open_pallet and self._open_pallet.package_id not in seen else []
        )

    def total_packaged_length_m(self) -> float:
        return sum(p.total_length_m for p in self.packages)
