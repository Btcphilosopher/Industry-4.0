"""
logistics/distribution.py

Outbound logistics: batches warehouse packages into shipments and
simulates simple truck-load dispatch economics.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import List

from logistics.packaging import Package
from logistics.warehouse import Warehouse
from utils.logging import GLOBAL_METRICS, get_logger

logger = get_logger("logistics.distribution")

TRUCK_CAPACITY_M = 4_000.0
COST_PER_SHIPMENT = 280.0


@dataclass
class Shipment:
    shipment_id: str
    packages: List[Package] = field(default_factory=list)
    total_length_m: float = 0.0
    dispatched_at_tick: int = 0

    def add(self, package: Package) -> None:
        self.packages.append(package)
        self.total_length_m += package.total_length_m


class DistributionCenter:
    def __init__(self):
        self.shipments: List[Shipment] = []
        self.total_shipping_cost: float = 0.0

    def dispatch_from_warehouse(self, warehouse: Warehouse, tick: int,
                                  max_trucks: int = 1) -> List[Shipment]:
        shipments = []
        for _ in range(max_trucks):
            if warehouse.occupied_m <= 0:
                break
            shipment = Shipment(shipment_id=f"SHIP-{uuid.uuid4().hex[:8].upper()}",
                                 dispatched_at_tick=tick)
            while shipment.total_length_m < TRUCK_CAPACITY_M and warehouse.slots:
                packages = warehouse.dispatch_oldest(1)
                if not packages:
                    break
                shipment.add(packages[0])
            if shipment.packages:
                self.shipments.append(shipment)
                self.total_shipping_cost += COST_PER_SHIPMENT
                shipments.append(shipment)
                logger.info("Dispatched %s with %d packages (%.0fm)", shipment.shipment_id,
                            len(shipment.packages), shipment.total_length_m)
                GLOBAL_METRICS.record("shipment_dispatched", shipment.shipment_id,
                                       length_m=shipment.total_length_m)
        return shipments

    def total_shipped_length_m(self) -> float:
        return sum(s.total_length_m for s in self.shipments)
