"""
logistics/warehouse.py

Finite-capacity finished-goods warehouse. Provides backpressure into the
factory floor: once the warehouse nears capacity, `factory_floor.py`
should slow packaging intake / trigger distribution dispatch.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

from logistics.packaging import Package
from utils.logging import GLOBAL_METRICS, get_logger

logger = get_logger("logistics.warehouse")


@dataclass
class WarehouseSlot:
    package: Package
    stored_at_tick: int


class Warehouse:
    def __init__(self, capacity_m: float = 50_000.0):
        self.capacity_m = capacity_m
        self.slots: List[WarehouseSlot] = []

    @property
    def occupied_m(self) -> float:
        return sum(s.package.total_length_m for s in self.slots)

    @property
    def utilisation_pct(self) -> float:
        if self.capacity_m <= 0:
            return 0.0
        return 100.0 * self.occupied_m / self.capacity_m

    def has_capacity_for(self, length_m: float) -> bool:
        return self.occupied_m + length_m <= self.capacity_m

    def store(self, package: Package, tick: int) -> bool:
        if not self.has_capacity_for(package.total_length_m):
            logger.warning("Warehouse full (%.0f/%.0fm) -- cannot store %s",
                            self.occupied_m, self.capacity_m, package.package_id)
            GLOBAL_METRICS.record("warehouse_full", package.package_id, occupied_m=self.occupied_m)
            return False
        self.slots.append(WarehouseSlot(package=package, stored_at_tick=tick))
        GLOBAL_METRICS.record("warehouse_store", package.package_id, length_m=package.total_length_m)
        return True

    def dispatch_oldest(self, n: int = 1) -> List[Package]:
        dispatched = []
        self.slots.sort(key=lambda s: s.stored_at_tick)
        for _ in range(min(n, len(self.slots))):
            slot = self.slots.pop(0)
            dispatched.append(slot.package)
        return dispatched

    def is_near_capacity(self, threshold_pct: float = 90.0) -> bool:
        return self.utilisation_pct >= threshold_pct
