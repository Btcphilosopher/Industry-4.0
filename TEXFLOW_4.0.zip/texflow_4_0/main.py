#!/usr/bin/env python3
"""
main.py

TEXFLOW 4.0 -- Textile Manufacturing Digital Twin & Industry Simulation
Engine. Command-line entry point.

Usage:
    python main.py run --ticks 1440 --dashboard out/dashboard.html
    python main.py sweep --param factory.n_looms=2,3,4 --ticks 480
    python main.py config --save out/config.json
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from core.engine import SimulationEngine
from core.simulation_loop import run_simulation
from simulation.batch_simulator import BatchSimulator, SweepParameter
from ui.dashboard import Dashboard
from utils.config import SimulationConfig
from utils.logging import get_logger

logger = get_logger("main")


def _print_summary(engine: SimulationEngine) -> None:
    snap = engine.latest_snapshot()
    if snap is None:
        print("No ticks were run.")
        return
    print("\n" + "=" * 60)
    print(" TEXFLOW 4.0 -- SIMULATION SUMMARY")
    print("=" * 60)
    print(f" Sim time             : {snap.sim_time}")
    print(f" Metres produced      : {snap.metres_produced_total:,.1f} m")
    print(f" Defect rate          : {snap.defect_rate_pct:.2f} %")
    print(f" Machine uptime       : {snap.machine_uptime_pct:.2f} %")
    print(f" Energy / metre       : {snap.energy_per_metre_kwh:.4f} kWh")
    print(f" Cost / metre         : ${snap.cost_per_metre:.2f}")
    print(f" Quality consistency  : {snap.quality_consistency_index * 100:.1f} / 100")
    print(f" Waste rate           : {snap.waste_rate_pct:.2f} %")
    print(f" Total revenue        : ${snap.revenue_total:,.2f}")
    print(f" Bottleneck stage     : {snap.bottleneck_stage or 'none'}")
    print("=" * 60 + "\n")


def cmd_run(args: argparse.Namespace) -> None:
    config = SimulationConfig.from_file(args.config) if args.config else SimulationConfig()
    if args.ticks:
        config.total_ticks = args.ticks
    if args.seed is not None:
        config.random_seed = args.seed

    engine = SimulationEngine(config)
    logger.info("Starting TEXFLOW 4.0 simulation: %d ticks, seed=%d", config.total_ticks, config.random_seed)
    run_simulation(engine)
    _print_summary(engine)

    if args.dashboard:
        out_path = Path(args.dashboard)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        Dashboard(engine).save(out_path)
        print(f"Dashboard written to: {out_path.resolve()}")

    if args.save_config:
        config.save(args.save_config)
        print(f"Config saved to: {args.save_config}")


def cmd_sweep(args: argparse.Namespace) -> None:
    base_config = SimulationConfig.from_file(args.config) if args.config else SimulationConfig()
    if args.ticks:
        base_config.total_ticks = args.ticks

    parameters = []
    for spec in args.param:
        name, raw_values = spec.split("=")
        values = [float(v) for v in raw_values.split(",")]
        parameters.append(SweepParameter(name=name, values=values))

    simulator = BatchSimulator(base_config)
    df = simulator.run_sweep(parameters, seeds=[base_config.random_seed], ticks=args.ticks)
    print(df.to_string(index=False))

    if args.out:
        df.to_csv(args.out, index=False)
        print(f"\nResults saved to: {args.out}")


def cmd_config(args: argparse.Namespace) -> None:
    config = SimulationConfig()
    if args.save:
        config.save(args.save)
        print(f"Default config saved to: {args.save}")
    else:
        print(config.to_json())


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="texflow", description="TEXFLOW 4.0 digital twin CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    run_p = sub.add_parser("run", help="Run a single simulation")
    run_p.add_argument("--ticks", type=int, default=None, help="Number of simulated minutes to run")
    run_p.add_argument("--seed", type=int, default=None, help="Random seed override")
    run_p.add_argument("--config", type=str, default=None, help="Path to a SimulationConfig JSON file")
    run_p.add_argument("--dashboard", type=str, default=None, help="Write an HTML dashboard to this path")
    run_p.add_argument("--save-config", type=str, default=None, help="Save the resolved config used for this run")
    run_p.set_defaults(func=cmd_run)

    sweep_p = sub.add_parser("sweep", help="Run a parameter sweep across scenarios")
    sweep_p.add_argument("--param", action="append", required=True,
                          help="dotted.path=v1,v2,v3 (repeatable)")
    sweep_p.add_argument("--ticks", type=int, default=480, help="Ticks per scenario")
    sweep_p.add_argument("--config", type=str, default=None, help="Base config JSON file")
    sweep_p.add_argument("--out", type=str, default=None, help="Write results CSV to this path")
    sweep_p.set_defaults(func=cmd_sweep)

    config_p = sub.add_parser("config", help="Print or save the default configuration")
    config_p.add_argument("--save", type=str, default=None, help="Save default config to this path")
    config_p.set_defaults(func=cmd_config)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    args.func(args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
