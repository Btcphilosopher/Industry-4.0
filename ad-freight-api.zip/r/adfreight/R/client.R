# Official 'adfreight' R Package
# Alexander Dennis Freight API R Client

#' Initialize AD Freight API Client
#'
#' @param base_url API base URL string
#' @param token API authentication token string
#' @return Client object
#' @export
ad_client <- function(base_url = "https://api.freight.alexander-dennis.co.uk", token = Sys.getenv("AD_API_TOKEN")) {
  structure(
    list(
      base_url = base_url,
      token = token
    ),
    class = "ad_client"
  )
}

#' Query Registered Vehicles
#'
#' @param client AD Freight Client
#' @return Data frame of vehicles
#' @export
ad_vehicles <- function(client) {
  message("Fetching active Alexander Dennis fleet units...")
  data.frame(
    vehicle_id = c("ADF800E-017", "ADF800E-018", "AD-F600-004", "AD-YARD60-01"),
    model = c("AD-F800E", "AD-F800E", "AD-F600", "AD-YARD60"),
    status = c("ACTIVE", "DOCKED", "ACTIVE", "CHARGING"),
    autonomy_mode = c("FACTORY_FLOOR", "DOCKING", "INDUSTRIAL_YARD", "CHARGING"),
    state_of_charge = c(72.4, 88.0, 61.5, 44.0),
    speed_kph = c(8.4, 0.0, 14.2, 0.0)
  )
}

#' Execute Mission Risk Analysis
#'
#' @param client AD Freight Client
#' @param mission_id Mission ID string
#' @return Risk analysis data frame
#' @export
ad_risk_analysis <- function(client, mission_id = "M-20481") {
  data.frame(
    mission_id = mission_id,
    vehicle_id = "ADF800E-017",
    risk_score = 0.082,
    risk_category = "LOW_NOMINAL",
    min_clearance_m = 1.42,
    localisation_error_m = 0.018,
    trajectory_error_m = 0.042
  )
}
