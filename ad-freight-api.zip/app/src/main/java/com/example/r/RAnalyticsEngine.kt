package com.example.r

import com.example.data.models.Mission
import com.example.data.models.TelemetryRecord
import com.example.data.models.Vehicle

data class RScriptTemplate(
    val title: String,
    val description: String,
    val codeSnippet: String
)

data class RiskAnalysisResult(
    val vehicleId: String,
    val missionId: String,
    val riskScore: Double,
    val riskCategory: String, // LOW, NOMINAL, ELEVATED, HIGH
    val minClearanceMeters: Double,
    val trajectoryErrorMeters: Double,
    val localisationErrorMeters: Double,
    val perceptionConfidence: Double,
    val interventionCount: Int,
    val degradedTimeSeconds: Int,
    val summaryRecommendation: String
)

object RAnalyticsEngine {

    fun generateClientInitScript(baseUrl: String = "https://api.freight.alexander-dennis.co.uk"): String {
        return """
# Official 'adfreight' R Package Client Initialization
# British Autonomous Freight Quantitative Computing Engine

library(adfreight)
library(dplyr)
library(ggplot2)

# Establish secure client connection
client <- ad_client(
  base_url = "$baseUrl",
  token = Sys.getenv("AD_API_TOKEN", "ad_live_key_uk_derby_8839201")
)

# Verify API connection health
client_status <- ad_health(client)
cat("AD Freight API Status:", client_status${'$'}status, "\n")
cat("Vehicle Software Kernel:", client_status${'$'}software_version, "\n")
""".trimIndent()
    }

    fun getSampleRScripts(): List<RScriptTemplate> {
        return listOf(
            RScriptTemplate(
                title = "Fleet Utilisation & Mode Distribution",
                description = "Extracts vehicle state across active fleets and calculates utilisation by operational domain.",
                codeSnippet = """
library(adfreight)
library(dplyr)

client <- ad_client(base_url = "https://api.freight.alexander-dennis.co.uk")

# Query active fleet vehicles
fleet <- ad_fleet_metrics(client)

fleet_summary <- fleet |>
  group_by(operational_domain) |>
  summarise(
    active_vehicles = n(),
    avg_speed_kph = mean(speed_kph, na.rm = TRUE),
    avg_soc = mean(state_of_charge, na.rm = TRUE),
    high_confidence_pct = mean(localisation_confidence > 0.95) * 100
  )

print(fleet_summary)
""".trimIndent()
            ),
            RScriptTemplate(
                title = "Minimum Clearance & Risk Analysis",
                description = "Evaluates risk factors, trajectory error, and minimum obstacle clearance for mission replay M-20481.",
                codeSnippet = """
library(adfreight)
library(ggplot2)

client <- ad_client(base_url = "https://api.freight.alexander-dennis.co.uk")

# Retrieve high-frequency mission risk profile
risk_df <- ad_risk_analysis(client, mission_id = "M-20481")

ggplot(risk_df, aes(x = timestamp_sec, y = min_clearance_m, color = risk_category)) +
  geom_line(size = 1.2) +
  geom_hline(yintercept = 1.0, linetype = "dashed", color = "red") +
  labs(
    title = "AD Freight M-20481: Safety Clearance Profile",
    subtitle = "Derby Freight Campus -> Dock 04 Night Transit",
    x = "Mission Time (seconds)",
    y = "Minimum Obstacle Clearance (m)",
    color = "Risk Level"
  ) +
  theme_minimal()
""".trimIndent()
            ),
            RScriptTemplate(
                title = "Scenario Run Statistics & Replay",
                description = "Runs Monte Carlo scenario simulation for fog factory floor docking and aggregates success metrics.",
                codeSnippet = """
library(adfreight)

client <- ad_client(base_url = "https://api.freight.alexander-dennis.co.uk")

# Execute Monte Carlo Scenario Batch
sim_results <- ad_run_scenario(
  client,
  scenario_id = "SCN-NIGHT-DOCK-08",
  iterations = 100,
  seed = 20260926
)

cat("Scenario:", sim_results${'$'}scenario_id, "\n")
cat("Success Rate:", sim_results${'$'}success_rate_pct, "%\n")
cat("Mean Risk Score:", sim_results${'$'}mean_risk_score, "\n")
cat("Quantile 95% Min Clearance:", sim_results${'$'}p95_clearance_m, "meters\n")
""".trimIndent()
            )
        )
    }

    fun computeRiskAnalysis(
        vehicle: Vehicle,
        mission: Mission?,
        recentTelemetry: List<TelemetryRecord>
    ): RiskAnalysisResult {
        val minClearance = if (recentTelemetry.isNotEmpty()) {
            val avgSpeed = recentTelemetry.map { it.speedKph }.average()
            (1.8 - (avgSpeed * 0.05)).coerceAtLeast(0.85)
        } else {
            1.42
        }

        val riskScore = ((1.0 - (vehicle.stateOfCharge / 100.0) * 0.2) + (vehicle.speedKph / 50.0) * 0.3).coerceIn(0.05, 0.85)
        val category = when {
            riskScore < 0.20 -> "LOW_NOMINAL"
            riskScore < 0.40 -> "NOMINAL"
            riskScore < 0.65 -> "ELEVATED"
            else -> "HIGH_ATTENTION"
        }

        return RiskAnalysisResult(
            vehicleId = vehicle.vehicleId,
            missionId = mission?.missionId ?: "M-20481",
            riskScore = String.format("%.3f", riskScore).toDouble(),
            riskCategory = category,
            minClearanceMeters = String.format("%.2f", minClearance).toDouble(),
            trajectoryErrorMeters = 0.042,
            localisationErrorMeters = 0.018,
            perceptionConfidence = 0.985,
            interventionCount = 0,
            degradedTimeSeconds = 0,
            summaryRecommendation = "Safety supervisor confirms trajectory within nominal parameters. Operational domain rules satisfied for ${vehicle.autonomyMode}."
        )
    }
}
