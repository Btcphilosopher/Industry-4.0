package com.example.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey

// --- Core Domain Data Models ---

enum class VehicleStatus {
    ACTIVE, IDLE, DOCKED, CHARGING, MAINTENANCE, DEGRADED, EMERGENCY_STOP
}

enum class AutonomyMode {
    MANUAL, ASSISTED, AUTONOMOUS_ROAD, AUTONOMOUS_MOTORWAY,
    AUTONOMOUS_URBAN, INDUSTRIAL_YARD, FACTORY_FLOOR,
    DEPOT_MANOEUVRE, DOCKING, CHARGING, DEGRADED, MINIMUM_RISK
}

enum class CargoStatus {
    CREATED, READY, LOADING, LOADED, IN_TRANSIT, AT_DEPOT, UNLOADING, DELIVERED, EXCEPTION, RETURNED
}

enum class MissionStatus {
    PLANNED, SCHEDULED, IN_PROGRESS, PAUSED, DOCK_APPROACH, COMPLETED, CANCELLED, ABORTED
}

enum class DockStatus {
    AVAILABLE, RESERVED, APPROACHING, ALIGNING, DOCKED, LOADING, UNLOADING, BLOCKED, MAINTENANCE
}

enum class SafetyLevel {
    NOMINAL, ADVISORY, WARNING, CRITICAL, EMERGENCY
}

@Entity(tableName = "vehicles")
data class Vehicle(
    @PrimaryKey val vehicleId: String,
    val model: String,
    val fleetId: String,
    val status: VehicleStatus,
    val autonomyMode: AutonomyMode,
    val speedKph: Double,
    val headingDeg: Double,
    val payloadKg: Int,
    val maxPayloadKg: Int,
    val stateOfCharge: Double, // %
    val estimatedRangeKm: Double,
    val latitude: Double,
    val longitude: Double,
    val locationName: String,
    val currentMissionId: String?,
    val assignedTrailerId: String?,
    val softwareVersion: String,
    val lastTelemetryTime: Long = System.currentTimeMillis()
)

data class AutonomyStateInfo(
    val vehicleId: String,
    val mode: AutonomyMode,
    val operationalDomain: String,
    val localisationConfidence: Double, // 0.0 - 1.0
    val perceptionConfidence: Double,
    val planningConfidence: Double,
    val worldModelAgeMs: Long,
    val sensorHealth: String,
    val computeHealth: String,
    val safetyState: String,
    val activeGeofence: String
)

@Entity(tableName = "missions")
data class Mission(
    @PrimaryKey val missionId: String,
    val vehicleId: String,
    val status: MissionStatus,
    val origin: String,
    val destination: String,
    val cargoId: String,
    val priority: String,
    val deliveryWindowStart: String,
    val deliveryWindowEnd: String,
    val progressPct: Double,
    val distanceRemainingKm: Double,
    val etaMinutes: Int,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "cargo_units")
data class CargoUnit(
    @PrimaryKey val cargoId: String,
    val cargoType: String,
    val weightKg: Int,
    val dimensionsMeters: String,
    val origin: String,
    val destination: String,
    val customer: String,
    val handlingRequirements: String,
    val status: CargoStatus,
    val vehicleId: String?,
    val trailerId: String?
)

data class Trailer(
    val trailerId: String,
    val type: String,
    val tareWeightKg: Int,
    val payloadCapacityKg: Int,
    val currentPayloadKg: Int,
    val vehicleConnection: String?,
    val status: String
)

data class Facility(
    val id: String,
    val name: String,
    val type: String, // FACTORY, DEPOT, PORT
    val totalDocks: Int,
    val availableDocks: Int,
    val totalChargers: Int,
    val activeChargers: Int,
    val activeVehiclesCount: Int,
    val zones: List<String>
)

data class DockInfo(
    val dockId: String,
    val facilityId: String,
    val name: String,
    val status: DockStatus,
    val assignedVehicleId: String?,
    val activeCargoOp: String
)

data class ChargerInfo(
    val chargerId: String,
    val facilityId: String,
    val maxKwPower: Int,
    val currentKwPower: Int,
    val status: String,
    val connectedVehicleId: String?,
    val energyDeliveredKwh: Double
)

@Entity(tableName = "telemetry")
data class TelemetryRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val vehicleId: String,
    val timestamp: Long,
    val speedKph: Double,
    val accelerationMps2: Double,
    val headingDeg: Double,
    val socPercent: Double,
    val latitude: Double,
    val longitude: Double,
    val steeringAngleDeg: Double,
    val brakePressureBar: Double,
    val lidarStatus: String,
    val radarStatus: String,
    val cameraStatus: String,
    val autonomyMode: String
)

@Entity(tableName = "safety_events")
data class SafetyEventRecord(
    @PrimaryKey val eventId: String,
    val vehicleId: String,
    val missionId: String,
    val operationalDomain: String,
    val level: SafetyLevel,
    val softwareVersion: String,
    val timestamp: Long,
    val cause: String,
    val systemResponse: String,
    val result: String,
    val location: String
)

data class IncidentRecorderSession(
    val incidentId: String,
    val vehicleId: String,
    val softwareVersion: String,
    val timestampStr: String,
    val preBufferSeconds: Int,
    val postBufferSeconds: Int,
    val triggerCause: String,
    val recordedPointsCount: Int,
    val hazardsDetected: List<String>
)

data class WorldObjectTrack(
    val trackId: String,
    val objectClass: String, // PEDESTRIAN, FORKLIFT, BARRIER, PALLET, TRUCK
    val positionX: Double,
    val positionY: Double,
    val velocityMps: Double,
    val confidence: Double,
    val ageMs: Long,
    val sensorSources: List<String>
)

data class ScenarioInfo(
    val scenarioId: String,
    val title: String,
    val environment: String,
    val weather: String,
    val trafficDensity: String,
    val successRatePct: Double,
    val avgClearanceMeters: Double,
    val riskCategory: String,
    val lastRunTime: String
)

@Entity(tableName = "api_logs")
data class ApiLogRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val method: String,
    val path: String,
    val statusCode: Int,
    val requestHeadersJson: String,
    val requestBodyJson: String,
    val responseBodyJson: String,
    val latencyMs: Long,
    val timestamp: Long = System.currentTimeMillis()
)
