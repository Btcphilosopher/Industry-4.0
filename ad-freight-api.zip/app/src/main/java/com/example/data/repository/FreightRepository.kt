package com.example.data.repository

import android.content.Context
import com.example.data.models.ApiLogRecord
import com.example.data.models.AutonomyMode
import com.example.data.models.AutonomyStateInfo
import com.example.data.models.CargoStatus
import com.example.data.models.CargoUnit
import com.example.data.models.ChargerInfo
import com.example.data.models.DockInfo
import com.example.data.models.DockStatus
import com.example.data.models.Facility
import com.example.data.models.IncidentRecorderSession
import com.example.data.models.Mission
import com.example.data.models.MissionStatus
import com.example.data.models.SafetyEventRecord
import com.example.data.models.SafetyLevel
import com.example.data.models.ScenarioInfo
import com.example.data.models.TelemetryRecord
import com.example.data.models.Trailer
import com.example.data.models.Vehicle
import com.example.data.models.VehicleStatus
import com.example.data.room.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import kotlin.random.Random

class FreightRepository private constructor(context: Context) {

    private val db = AppDatabase.getInstance(context)
    private val vehicleDao = db.vehicleDao()
    private val missionDao = db.missionDao()
    private val cargoDao = db.cargoDao()
    private val telemetryDao = db.telemetryDao()
    private val safetyEventDao = db.safetyEventDao()
    private val apiLogDao = db.apiLogDao()

    private val scope = CoroutineScope(Dispatchers.IO)

    // In-memory static ODD & Facilities data
    private val _facilities = MutableStateFlow<List<Facility>>(emptyList())
    val facilities: StateFlow<List<Facility>> = _facilities.asStateFlow()

    private val _docks = MutableStateFlow<List<DockInfo>>(emptyList())
    val docks: StateFlow<List<DockInfo>> = _docks.asStateFlow()

    private val _chargers = MutableStateFlow<List<ChargerInfo>>(emptyList())
    val chargers: StateFlow<List<ChargerInfo>> = _chargers.asStateFlow()

    private val _trailers = MutableStateFlow<List<Trailer>>(emptyList())
    val trailers: StateFlow<List<Trailer>> = _trailers.asStateFlow()

    private val _scenarios = MutableStateFlow<List<ScenarioInfo>>(emptyList())
    val scenarios: StateFlow<List<ScenarioInfo>> = _scenarios.asStateFlow()

    val vehicles: Flow<List<Vehicle>> = vehicleDao.getAllVehicles()
    val missions: Flow<List<Mission>> = missionDao.getAllMissions()
    val cargoList: Flow<List<CargoUnit>> = cargoDao.getAllCargo()
    val safetyEvents: Flow<List<SafetyEventRecord>> = safetyEventDao.getAllSafetyEvents()
    val apiLogs: Flow<List<ApiLogRecord>> = apiLogDao.getRecentApiLogs()

    init {
        scope.launch {
            seedInitialData()
            startDeterministicSimulator()
        }
    }

    private suspend fun seedInitialData() {
        // Seed Vehicles
        val initialVehicles = listOf(
            Vehicle(
                vehicleId = "ADF800E-017",
                model = "AD-F800E",
                fleetId = "AD-FLEET-001",
                status = VehicleStatus.ACTIVE,
                autonomyMode = AutonomyMode.FACTORY_FLOOR,
                speedKph = 8.4,
                headingDeg = 181.2,
                payloadKg = 31800,
                maxPayloadKg = 38000,
                stateOfCharge = 72.4,
                estimatedRangeKm = 214.0,
                latitude = 52.9225,
                longitude = -1.4746,
                locationName = "AD Derby Freight Campus",
                currentMissionId = "M-20481",
                assignedTrailerId = "AD-TR-402",
                softwareVersion = "AD-KERNEL-v3.8.4"
            ),
            Vehicle(
                vehicleId = "ADF800E-018",
                model = "AD-F800E",
                fleetId = "AD-FLEET-001",
                status = VehicleStatus.DOCKED,
                autonomyMode = AutonomyMode.DOCKING,
                speedKph = 0.0,
                headingDeg = 90.0,
                payloadKg = 28500,
                maxPayloadKg = 38000,
                stateOfCharge = 88.0,
                estimatedRangeKm = 260.0,
                latitude = 52.9231,
                longitude = -1.4752,
                locationName = "Dock 04 - Battery Bay",
                currentMissionId = "M-20482",
                assignedTrailerId = "AD-TR-405",
                softwareVersion = "AD-KERNEL-v3.8.4"
            ),
            Vehicle(
                vehicleId = "AD-F600-004",
                model = "AD-F600",
                fleetId = "AD-FLEET-002",
                status = VehicleStatus.ACTIVE,
                autonomyMode = AutonomyMode.INDUSTRIAL_YARD,
                speedKph = 14.2,
                headingDeg = 270.5,
                payloadKg = 18200,
                maxPayloadKg = 24000,
                stateOfCharge = 61.5,
                estimatedRangeKm = 175.0,
                latitude = 52.9210,
                longitude = -1.4720,
                locationName = "Yard Loading North",
                currentMissionId = "M-20483",
                assignedTrailerId = "AD-TR-108",
                softwareVersion = "AD-KERNEL-v3.8.2"
            ),
            Vehicle(
                vehicleId = "AD-YARD60-01",
                model = "AD-YARD60",
                fleetId = "AD-FLEET-001",
                status = VehicleStatus.CHARGING,
                autonomyMode = AutonomyMode.CHARGING,
                speedKph = 0.0,
                headingDeg = 0.0,
                payloadKg = 0,
                maxPayloadKg = 40000,
                stateOfCharge = 44.0,
                estimatedRangeKm = 110.0,
                latitude = 52.9240,
                longitude = -1.4760,
                locationName = "High Power Charging Hub 02",
                currentMissionId = null,
                assignedTrailerId = null,
                softwareVersion = "AD-KERNEL-v3.8.4"
            )
        )
        vehicleDao.insertVehicles(initialVehicles)

        // Seed Missions
        val initialMissions = listOf(
            Mission(
                missionId = "M-20481",
                vehicleId = "ADF800E-017",
                status = MissionStatus.IN_PROGRESS,
                origin = "AD DERBY CAMPUS",
                destination = "LOGISTICS DEPOT 04",
                cargoId = "CARGO-1881",
                priority = "HIGH",
                deliveryWindowStart = "2026-09-26T08:00Z",
                deliveryWindowEnd = "2026-09-26T12:00Z",
                progressPct = 68.5,
                distanceRemainingKm = 14.2,
                etaMinutes = 18
            ),
            Mission(
                missionId = "M-20482",
                vehicleId = "ADF800E-018",
                status = MissionStatus.DOCK_APPROACH,
                origin = "ASSEMBLY HALL B",
                destination = "DOCK 04",
                cargoId = "CARGO-1882",
                priority = "NORMAL",
                deliveryWindowStart = "2026-09-26T09:00Z",
                deliveryWindowEnd = "2026-09-26T11:00Z",
                progressPct = 92.0,
                distanceRemainingKm = 0.3,
                etaMinutes = 2
            ),
            Mission(
                missionId = "M-20483",
                vehicleId = "AD-F600-004",
                status = MissionStatus.IN_PROGRESS,
                origin = "YARD NORTH",
                destination = "WAREHOUSE C",
                cargoId = "CARGO-1883",
                priority = "EXPRESS",
                deliveryWindowStart = "2026-09-26T07:30Z",
                deliveryWindowEnd = "2026-09-26T10:00Z",
                progressPct = 42.0,
                distanceRemainingKm = 4.8,
                etaMinutes = 8
            )
        )
        initialMissions.forEach { missionDao.insertMission(it) }

        // Seed Cargo
        val initialCargo = listOf(
            CargoUnit(
                cargoId = "CARGO-1881",
                cargoType = "HIGH_CAPACITY_BATTERY_CELLS",
                weightKg = 31800,
                dimensionsMeters = "13.6m x 2.5m x 2.7m",
                origin = "AD DERBY CAMPUS",
                destination = "LOGISTICS DEPOT 04",
                customer = "DENNIS FREIGHT LOGISTICS",
                handlingRequirements = "HAZMAT_CLASS_9, TEMPERATURE_CONTROLLED_20C",
                status = CargoStatus.IN_TRANSIT,
                vehicleId = "ADF800E-017",
                trailerId = "AD-TR-402"
            ),
            CargoUnit(
                cargoId = "CARGO-1882",
                cargoType = "STRUCTURAL_CHASSIS_MEMBERS",
                weightKg = 28500,
                dimensionsMeters = "12.0m x 2.4m x 2.2m",
                origin = "ASSEMBLY HALL B",
                destination = "DOCK 04",
                customer = "ALEXANDER DENNIS MANUFACTURING",
                handlingRequirements = "CRANE_UNLOAD_ONLY",
                status = CargoStatus.AT_DEPOT,
                vehicleId = "ADF800E-018",
                trailerId = "AD-TR-405"
            ),
            CargoUnit(
                cargoId = "CARGO-1883",
                cargoType = "DRIVETRAIN_AXLE_ASSEMBLIES",
                weightKg = 18200,
                dimensionsMeters = "8.5m x 2.2m x 1.8m",
                origin = "YARD NORTH",
                destination = "WAREHOUSE C",
                customer = "UK FREIGHT SYSTEMS",
                handlingRequirements = "STANDARD_CONTAINER",
                status = CargoStatus.IN_TRANSIT,
                vehicleId = "AD-F600-004",
                trailerId = "AD-TR-108"
            )
        )
        cargoDao.insertCargoList(initialCargo)

        // Seed Safety Events
        val initialSafetyEvents = listOf(
            SafetyEventRecord(
                eventId = "EVT-88219",
                vehicleId = "ADF800E-017",
                missionId = "M-20481",
                operationalDomain = "FACTORY_FLOOR",
                level = SafetyLevel.NOMINAL,
                softwareVersion = "AD-KERNEL-v3.8.4",
                timestamp = System.currentTimeMillis() - 120000,
                cause = "LOCALISATION_PROXIMITY_CHECK",
                systemResponse = "SPEED_LIMIT_CAPPED_8KPH",
                result = "SAFE_TRANSITION_COMPLETED",
                location = "Factory Gate 02"
            ),
            SafetyEventRecord(
                eventId = "EVT-88220",
                vehicleId = "ADF800E-018",
                missionId = "M-20482",
                operationalDomain = "DEPOT_MANOEUVRE",
                level = SafetyLevel.ADVISORY,
                softwareVersion = "AD-KERNEL-v3.8.4",
                timestamp = System.currentTimeMillis() - 60000,
                cause = "FORKLIFT_CROSSING_PREDICTION",
                systemResponse = "TRAJECTORY_SLOWDOWN_TO_3KPH",
                result = "CLEARANCE_MARGIN_RESTORED_1.8M",
                location = "Dock 04 Approach Lane"
            )
        )
        initialSafetyEvents.forEach { safetyEventDao.insertSafetyEvent(it) }

        // Seed Facilities & Docks
        _facilities.value = listOf(
            Facility(
                id = "AD-DERBY-CAMPUS",
                name = "AD Derby Freight Campus",
                type = "FACTORY",
                totalDocks = 12,
                availableDocks = 8,
                totalChargers = 8,
                activeChargers = 3,
                activeVehiclesCount = 14,
                zones = listOf("BATTERY_BAY", "ASSEMBLY_HALL", "YARD_DOCKS", "TEST_TRACK")
            ),
            Facility(
                id = "LOGISTICS-DEPOT-04",
                name = "Derby Central Logistics Depot 04",
                type = "DEPOT",
                totalDocks = 24,
                availableDocks = 11,
                totalChargers = 16,
                activeChargers = 7,
                activeVehiclesCount = 32,
                zones = listOf("CROSS_DOCK_A", "CONTAINER_YARD", "FAST_CHARGING_BAY")
            )
        )

        _docks.value = listOf(
            DockInfo("DOCK-01", "AD-DERBY-CAMPUS", "Dock 01 - General Cargo", DockStatus.AVAILABLE, null, "NONE"),
            DockInfo("DOCK-02", "AD-DERBY-CAMPUS", "Dock 02 - Hazmat Cells", DockStatus.RESERVED, "ADF800E-017", "LOADING_PREP"),
            DockInfo("DOCK-04", "AD-DERBY-CAMPUS", "Dock 04 - Battery Bay", DockStatus.DOCKED, "ADF800E-018", "UNLOADING"),
            DockInfo("DOCK-08", "LOGISTICS-DEPOT-04", "Dock 08 - Express Bay", DockStatus.AVAILABLE, null, "NONE")
        )

        _chargers.value = listOf(
            ChargerInfo("CHG-350KW-01", "AD-DERBY-CAMPUS", 350, 280, "CHARGING", "AD-YARD60-01", 142.8),
            ChargerInfo("CHG-350KW-02", "AD-DERBY-CAMPUS", 350, 0, "AVAILABLE", null, 0.0),
            ChargerInfo("CHG-150KW-04", "LOGISTICS-DEPOT-04", 150, 145, "CHARGING", "ADF800E-009", 88.4)
        )

        _trailers.value = listOf(
            Trailer("AD-TR-402", "SUPER_CUBE_CONTAINER", 6200, 32000, 31800, "ADF800E-017", "CONNECTED_LOCKED"),
            Trailer("AD-TR-405", "HEAVY_CURTAINSIDER", 5800, 30000, 28500, "ADF800E-018", "CONNECTED_LOCKED"),
            Trailer("AD-TR-108", "FLATBED_CHASSIS", 4500, 25000, 18200, "AD-F600-004", "CONNECTED_LOCKED")
        )

        _scenarios.value = listOf(
            ScenarioInfo(
                scenarioId = "SCN-NIGHT-DOCK-08",
                title = "Factory Floor Night Docking under Fog",
                environment = "AD DERBY CAMPUS DOCK 04",
                weather = "DENSE_FOG_VISIBILITY_15M",
                trafficDensity = "HIGH_FORKLIFT_ACTIVITY",
                successRatePct = 100.0,
                avgClearanceMeters = 1.42,
                riskCategory = "LOW_NOMINAL",
                lastRunTime = "2026-09-26 03:20:00"
            ),
            ScenarioInfo(
                scenarioId = "SCN-YARD-CROSSING-12",
                title = "Industrial Yard Pedestrian Cut-In Avoidance",
                environment = "INDUSTRIAL_YARD_NORTH",
                weather = "HEAVY_RAIN",
                trafficDensity = "MIXED_PEDESTRIAN_TRUCK",
                successRatePct = 98.4,
                avgClearanceMeters = 1.88,
                riskCategory = "NOMINAL",
                lastRunTime = "2026-09-26 02:45:00"
            )
        )

        // Initial REST API Log entry
        executeApiCall("GET", "/api/v1/vehicles/ADF800E-017", 200, "{\"vehicle_id\":\"ADF800E-017\",\"status\":\"ACTIVE\"}")
    }

    private suspend fun startDeterministicSimulator() {
        while (true) {
            delay(1500)
            val currentVehicles = listOf("ADF800E-017", "ADF800E-018", "AD-F600-004")
            for (vId in currentVehicles) {
                val v = vehicleDao.getVehicleById(vId) ?: continue
                if (v.status == VehicleStatus.ACTIVE) {
                    val deltaLat = (Random.nextDouble() - 0.5) * 0.0001
                    val deltaLon = (Random.nextDouble() - 0.5) * 0.0001
                    val newSpeed = (v.speedKph + (Random.nextDouble() - 0.5) * 0.4).coerceIn(4.0, 18.0)
                    val newSoc = (v.stateOfCharge - 0.02).coerceAtLeast(10.0)

                    vehicleDao.updateVehicleTelemetry(
                        id = v.vehicleId,
                        speed = String.format("%.1f", newSpeed).toDouble(),
                        heading = v.headingDeg,
                        soc = String.format("%.1f", newSoc).toDouble(),
                        lat = v.latitude + deltaLat,
                        lon = v.longitude + deltaLon
                    )

                    // Insert Telemetry record
                    telemetryDao.insertTelemetry(
                        TelemetryRecord(
                            vehicleId = v.vehicleId,
                            timestamp = System.currentTimeMillis(),
                            speedKph = newSpeed,
                            accelerationMps2 = (Random.nextDouble() - 0.5) * 0.2,
                            headingDeg = v.headingDeg,
                            socPercent = newSoc,
                            latitude = v.latitude + deltaLat,
                            longitude = v.longitude + deltaLon,
                            steeringAngleDeg = (Random.nextDouble() - 0.5) * 2.0,
                            brakePressureBar = 0.0,
                            lidarStatus = "NOMINAL_HEALTH",
                            radarStatus = "NOMINAL_HEALTH",
                            cameraStatus = "NOMINAL_HEALTH",
                            autonomyMode = v.autonomyMode.name
                        )
                    )
                }
            }
        }
    }

    suspend fun executeApiCall(
        method: String,
        path: String,
        expectedStatusCode: Int = 200,
        requestBody: String = ""
    ): Pair<Int, String> {
        val startTime = System.currentTimeMillis()
        val responseJson = when {
            path.startsWith("/api/v1/vehicles/") -> {
                val id = path.substringAfter("/api/v1/vehicles/")
                val v = vehicleDao.getVehicleById(id)
                if (v != null) {
                    JSONObject().apply {
                        put("vehicle_id", v.vehicleId)
                        put("model", v.model)
                        put("fleet_id", v.fleetId)
                        put("status", v.status.name)
                        put("autonomy_mode", v.autonomyMode.name)
                        put("speed_kph", v.speedKph)
                        put("heading_deg", v.headingDeg)
                        put("payload_kg", v.payloadKg)
                        put("energy", JSONObject().apply {
                            put("state_of_charge", v.stateOfCharge)
                            put("estimated_range_km", v.estimatedRangeKm)
                        })
                        put("location", JSONObject().apply {
                            put("latitude", v.latitude)
                            put("longitude", v.longitude)
                            put("name", v.locationName)
                        })
                        put("software_version", v.softwareVersion)
                    }.toString(2)
                } else {
                    JSONObject().apply {
                        put("error", JSONObject().apply {
                            put("code", "VEHICLE_NOT_FOUND")
                            put("message", "Vehicle $id was not found in fleet registration.")
                        })
                    }.toString(2)
                }
            }
            path == "/api/v1/vehicles" -> {
                JSONObject().apply {
                    put("total_vehicles", 4)
                    put("fleet_id", "AD-FLEET-001")
                    put("status_counts", JSONObject().apply {
                        put("ACTIVE", 2)
                        put("DOCKED", 1)
                        put("CHARGING", 1)
                    })
                }.toString(2)
            }
            path.startsWith("/api/v1/missions/") -> {
                val id = path.substringAfter("/api/v1/missions/")
                val m = missionDao.getMissionById(id)
                if (m != null) {
                    JSONObject().apply {
                        put("mission_id", m.missionId)
                        put("vehicle_id", m.vehicleId)
                        put("status", m.status.name)
                        put("origin", m.origin)
                        put("destination", m.destination)
                        put("cargo_id", m.cargoId)
                        put("priority", m.priority)
                        put("progress_pct", m.progressPct)
                        put("eta_minutes", m.etaMinutes)
                    }.toString(2)
                } else {
                    JSONObject().apply {
                        put("error", JSONObject().apply {
                            put("code", "MISSION_NOT_FOUND")
                            put("message", "Mission $id not found.")
                        })
                    }.toString(2)
                }
            }
            path.startsWith("/api/v1/freight/") -> {
                val id = path.substringAfter("/api/v1/freight/")
                val c = cargoDao.getCargoById(id)
                if (c != null) {
                    JSONObject().apply {
                        put("cargo_id", c.cargoId)
                        put("type", c.cargoType)
                        put("weight_kg", c.weightKg)
                        put("customer", c.customer)
                        put("origin", c.origin)
                        put("destination", c.destination)
                        put("status", c.status.name)
                        put("assigned_vehicle", c.vehicleId)
                        put("assigned_trailer", c.trailerId)
                    }.toString(2)
                } else {
                    JSONObject().apply {
                        put("error", JSONObject().apply {
                            put("code", "CARGO_NOT_FOUND")
                            put("message", "Freight cargo $id not found.")
                        })
                    }.toString(2)
                }
            }
            path == "/api/v1/safety/status" -> {
                JSONObject().apply {
                    put("safety_state", "SAFE_OPERATIONAL")
                    put("active_hazards", 0)
                    put("mrc_ready", true)
                    put("incident_data_recorder", "RECORDING")
                }.toString(2)
            }
            else -> {
                JSONObject().apply {
                    put("status", "OK")
                    put("api_version", "v1.0.0")
                    put("kernel", "AD-AUTONOMY-3.8.4")
                    put("timestamp", System.currentTimeMillis())
                }.toString(2)
            }
        }

        val latency = System.currentTimeMillis() - startTime
        apiLogDao.insertApiLog(
            ApiLogRecord(
                method = method,
                path = path,
                statusCode = expectedStatusCode,
                requestHeadersJson = "{\"Authorization\":\"Bearer ad_live_key_uk_derby_8839201\",\"Content-Type\":\"application/json\"}",
                requestBodyJson = requestBody.ifEmpty { "{}" },
                responseBodyJson = responseJson,
                latencyMs = latency
            )
        )

        return Pair(expectedStatusCode, responseJson)
    }

    suspend fun createMission(mission: Mission) {
        missionDao.insertMission(mission)
        executeApiCall("POST", "/api/v1/missions", 201, JSONObject().apply {
            put("mission_id", mission.missionId)
            put("vehicle_id", mission.vehicleId)
            put("origin", mission.origin)
            put("destination", mission.destination)
        }.toString())
    }

    suspend fun getAutonomyState(vehicleId: String): AutonomyStateInfo {
        val v = vehicleDao.getVehicleById(vehicleId)
        return AutonomyStateInfo(
            vehicleId = vehicleId,
            mode = v?.autonomyMode ?: AutonomyMode.FACTORY_FLOOR,
            operationalDomain = "FACTORY_FLOOR_DERBY_CAMPUS",
            localisationConfidence = 0.984,
            perceptionConfidence = 0.992,
            planningConfidence = 0.975,
            worldModelAgeMs = 12,
            sensorHealth = "NOMINAL_HEALTH",
            computeHealth = "DUAL_REDUNDANT_NOMINAL",
            safetyState = "SAFE_OPERATIONAL",
            activeGeofence = "ZONE_DERBY_INNER_PERIMETER"
        )
    }

    suspend fun getIncidentRecorderSession(vehicleId: String): IncidentRecorderSession {
        return IncidentRecorderSession(
            incidentId = "INCIDENT-00421",
            vehicleId = vehicleId,
            softwareVersion = "AD-KERNEL-v3.8.4",
            timestampStr = "2026-09-26 03:14:22 UTC",
            preBufferSeconds = 10,
            postBufferSeconds = 10,
            triggerCause = "MINIMUM_CLEARANCE_ADVISORY_MARGIN_1.42M",
            recordedPointsCount = 200,
            hazardsDetected = listOf("FORKLIFT_ALIGNED_REAR", "PEDESTRIAN_SAFETY_WALKWAY")
        )
    }

    companion object {
        @Volatile
        private var INSTANCE: FreightRepository? = null

        fun getInstance(context: Context): FreightRepository {
            return INSTANCE ?: synchronized(this) {
                val instance = FreightRepository(context)
                INSTANCE = instance
                instance
            }
        }
    }
}
