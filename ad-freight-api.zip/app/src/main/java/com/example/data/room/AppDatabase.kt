package com.example.data.room

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.models.ApiLogRecord
import com.example.data.models.CargoUnit
import com.example.data.models.Mission
import com.example.data.models.SafetyEventRecord
import com.example.data.models.TelemetryRecord
import com.example.data.models.Vehicle

@Database(
    entities = [
        Vehicle::class,
        Mission::class,
        CargoUnit::class,
        TelemetryRecord::class,
        SafetyEventRecord::class,
        ApiLogRecord::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun vehicleDao(): VehicleDao
    abstract fun missionDao(): MissionDao
    abstract fun cargoDao(): CargoDao
    abstract fun telemetryDao(): TelemetryDao
    abstract fun safetyEventDao(): SafetyEventDao
    abstract fun apiLogDao(): ApiLogDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ad_freight_database.db"
                ).fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
