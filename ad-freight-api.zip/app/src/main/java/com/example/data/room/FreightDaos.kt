package com.example.data.room

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.models.ApiLogRecord
import com.example.data.models.CargoUnit
import com.example.data.models.Mission
import com.example.data.models.SafetyEventRecord
import com.example.data.models.TelemetryRecord
import com.example.data.models.Vehicle
import kotlinx.coroutines.flow.Flow

@Dao
interface VehicleDao {
    @Query("SELECT * FROM vehicles ORDER BY vehicleId ASC")
    fun getAllVehicles(): Flow<List<Vehicle>>

    @Query("SELECT * FROM vehicles WHERE vehicleId = :id")
    suspend fun getVehicleById(id: String): Vehicle?

    @Query("SELECT * FROM vehicles WHERE vehicleId = :id")
    fun observeVehicleById(id: String): Flow<Vehicle?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateVehicle(vehicle: Vehicle)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVehicles(vehicles: List<Vehicle>)

    @Query("UPDATE vehicles SET speedKph = :speed, headingDeg = :heading, stateOfCharge = :soc, latitude = :lat, longitude = :lon WHERE vehicleId = :id")
    suspend fun updateVehicleTelemetry(id: String, speed: Double, heading: Double, soc: Double, lat: Double, lon: Double)
}

@Dao
interface MissionDao {
    @Query("SELECT * FROM missions ORDER BY createdAt DESC")
    fun getAllMissions(): Flow<List<Mission>>

    @Query("SELECT * FROM missions WHERE missionId = :id")
    suspend fun getMissionById(id: String): Mission?

    @Query("SELECT * FROM missions WHERE vehicleId = :vehicleId")
    fun getMissionsForVehicle(vehicleId: String): Flow<List<Mission>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMission(mission: Mission)

    @Update
    suspend fun updateMission(mission: Mission)

    @Query("DELETE FROM missions WHERE missionId = :id")
    suspend fun deleteMission(id: String)
}

@Dao
interface CargoDao {
    @Query("SELECT * FROM cargo_units ORDER BY cargoId ASC")
    fun getAllCargo(): Flow<List<CargoUnit>>

    @Query("SELECT * FROM cargo_units WHERE cargoId = :id")
    suspend fun getCargoById(id: String): CargoUnit?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCargo(cargo: CargoUnit)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCargoList(cargoList: List<CargoUnit>)
}

@Dao
interface TelemetryDao {
    @Query("SELECT * FROM telemetry WHERE vehicleId = :vehicleId ORDER BY timestamp DESC LIMIT 50")
    fun getRecentTelemetry(vehicleId: String): Flow<List<TelemetryRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTelemetry(telemetry: TelemetryRecord)

    @Query("DELETE FROM telemetry WHERE timestamp < :cutoffTime")
    suspend fun purgeOldTelemetry(cutoffTime: Long)
}

@Dao
interface SafetyEventDao {
    @Query("SELECT * FROM safety_events ORDER BY timestamp DESC")
    fun getAllSafetyEvents(): Flow<List<SafetyEventRecord>>

    @Query("SELECT * FROM safety_events WHERE vehicleId = :vehicleId ORDER BY timestamp DESC")
    fun getSafetyEventsForVehicle(vehicleId: String): Flow<List<SafetyEventRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSafetyEvent(event: SafetyEventRecord)
}

@Dao
interface ApiLogDao {
    @Query("SELECT * FROM api_logs ORDER BY timestamp DESC LIMIT 100")
    fun getRecentApiLogs(): Flow<List<ApiLogRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertApiLog(log: ApiLogRecord)

    @Query("DELETE FROM api_logs")
    suspend fun clearLogs()
}
