package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.FiberSmartRecord
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.IncidentRecorderSession
import com.example.data.models.SafetyEventRecord
import com.example.data.models.SafetyLevel
import com.example.ui.theme.ADAmber
import com.example.ui.theme.ADBlue
import com.example.ui.theme.ADCyan
import com.example.ui.theme.ADDarkBackground
import com.example.ui.theme.ADGreenBright
import com.example.ui.theme.ADNavy
import com.example.ui.theme.ADRed
import com.example.ui.theme.ADSurfaceNavy
import com.example.ui.theme.EngineeringPaper
import com.example.ui.theme.Steel

@Composable
fun SafetyScreen(
    safetyEvents: List<SafetyEventRecord>,
    incidentSession: IncidentRecorderSession
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ADDarkBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "SAFETY ARCHITECTURE & INCIDENT RECORDER",
                    style = MaterialTheme.typography.displayMedium,
                    color = EngineeringPaper
                )
                Text(
                    text = "UK Automated Vehicle Trial Safety Framework & Event Recording System",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Steel
                )
            }
        }

        item {
            // Incident Data Recorder Card
            Card(
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = ADSurfaceNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, ADCyan)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.FiberSmartRecord, contentDescription = null, tint = ADRed)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "AD EVENT RECORDER (BLACK BOX)",
                                style = MaterialTheme.typography.titleMedium,
                                color = EngineeringPaper,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(ADRed.copy(alpha = 0.2f))
                                .border(1.dp, ADRed, RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(text = "RECORDING ACTIVE", color = ADRed, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(text = "Trigger Cause: ${incidentSession.triggerCause}", style = MaterialTheme.typography.titleMedium, color = ADAmber)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Session ID: ${incidentSession.incidentId} | Vehicle: ${incidentSession.vehicleId} | Kernel: ${incidentSession.softwareVersion}",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Steel
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "PRE-EVENT BUFFER: ${incidentSession.preBufferSeconds}s", fontSize = 10.sp, color = Steel, fontFamily = FontFamily.Monospace)
                        Text(text = "POST-EVENT BUFFER: ${incidentSession.postBufferSeconds}s", fontSize = 10.sp, color = Steel, fontFamily = FontFamily.Monospace)
                        Text(text = "POINTS RECORDED: ${incidentSession.recordedPointsCount}", fontSize = 10.sp, color = ADCyan, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        item {
            Text(
                text = "IMMUTABLE SAFETY EVENTS AUDIT LOG",
                style = MaterialTheme.typography.titleLarge,
                color = EngineeringPaper
            )
        }

        items(safetyEvents) { event ->
            SafetyEventCardItem(event = event)
        }
    }
}

@Composable
fun SafetyEventCardItem(event: SafetyEventRecord) {
    val levelColor = when (event.level) {
        SafetyLevel.NOMINAL -> ADGreenBright
        SafetyLevel.ADVISORY -> ADCyan
        SafetyLevel.WARNING -> ADAmber
        SafetyLevel.CRITICAL, SafetyLevel.EMERGENCY -> ADRed
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("safety_event_${event.eventId}"),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = ADSurfaceNavy),
        border = androidx.compose.foundation.BorderStroke(1.dp, ADBlue)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = levelColor)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = event.eventId, style = MaterialTheme.typography.titleMedium, color = EngineeringPaper, fontWeight = FontWeight.Bold)
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(levelColor.copy(alpha = 0.2f))
                        .border(1.dp, levelColor, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(text = event.level.name, color = levelColor, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(text = "CAUSE: ${event.cause}", style = MaterialTheme.typography.titleMedium, color = ADAmber)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "RESPONSE: ${event.systemResponse}", style = MaterialTheme.typography.bodyMedium, color = EngineeringPaper)

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "Vehicle: ${event.vehicleId}", fontSize = 10.sp, color = Steel, fontFamily = FontFamily.Monospace)
                Text(text = "Domain: ${event.operationalDomain}", fontSize = 10.sp, color = Steel, fontFamily = FontFamily.Monospace)
                Text(text = "Location: ${event.location}", fontSize = 10.sp, color = Steel, fontFamily = FontFamily.Monospace)
            }
        }
    }
}
