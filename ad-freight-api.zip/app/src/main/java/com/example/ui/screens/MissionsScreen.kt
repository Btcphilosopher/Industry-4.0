package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AltRoute
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.Mission
import com.example.data.models.MissionStatus
import com.example.ui.theme.ADAmber
import com.example.ui.theme.ADBlue
import com.example.ui.theme.ADCyan
import com.example.ui.theme.ADDarkBackground
import com.example.ui.theme.ADGreenBright
import com.example.ui.theme.ADNavy
import com.example.ui.theme.ADSurfaceNavy
import com.example.ui.theme.EngineeringPaper
import com.example.ui.theme.Steel

@Composable
fun MissionsScreen(
    missions: List<Mission>,
    onCreateMission: (Mission) -> Unit
) {
    var showCreateDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ADDarkBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "AUTONOMOUS MISSION ENGINE",
                        style = MaterialTheme.typography.displayMedium,
                        color = EngineeringPaper
                    )
                    Text(
                        text = "Real-time trajectory planner and dispatch queue",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Steel
                    )
                }

                Button(
                    onClick = { showCreateDialog = true },
                    modifier = Modifier.testTag("create_mission_button"),
                    shape = RoundedCornerShape(6.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ADCyan, contentColor = ADNavy)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Create")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "DISPATCH MISSION", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }

        items(missions) { mission ->
            MissionCardItem(mission = mission)
        }
    }

    if (showCreateDialog) {
        CreateMissionDialog(
            onDismiss = { showCreateDialog = false },
            onCreate = { newMission ->
                onCreateMission(newMission)
                showCreateDialog = false
            }
        )
    }
}

@Composable
fun MissionCardItem(mission: Mission) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("mission_card_${mission.missionId}"),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = ADSurfaceNavy),
        border = androidx.compose.foundation.BorderStroke(1.dp, ADBlue)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.AltRoute, contentDescription = null, tint = ADCyan)
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = mission.missionId,
                            style = MaterialTheme.typography.titleLarge,
                            color = EngineeringPaper,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Assigned Vehicle: ${mission.vehicleId}",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Steel
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(ADBlue)
                        .border(1.dp, ADCyan, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = mission.status.name,
                        color = ADCyan,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Origin -> Destination
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(imageVector = Icons.Default.Navigation, contentDescription = null, tint = ADAmber, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = mission.origin, style = MaterialTheme.typography.titleMedium, color = EngineeringPaper)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "➜", color = Steel, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.width(8.dp))
                Icon(imageVector = Icons.Default.Flag, contentDescription = null, tint = ADGreenBright, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = mission.destination, style = MaterialTheme.typography.titleMedium, color = EngineeringPaper)
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Progress Bar
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "PROGRESS: ${mission.progressPct}%",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = EngineeringPaper,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${mission.distanceRemainingKm} km remaining | ETA ${mission.etaMinutes} mins",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Steel
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { (mission.progressPct / 100.0).toFloat() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = ADCyan,
                    trackColor = ADNavy
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "CARGO: ${mission.cargoId}", fontSize = 10.sp, color = Steel, fontFamily = FontFamily.Monospace)
                Text(text = "WINDOW: ${mission.deliveryWindowStart} - ${mission.deliveryWindowEnd}", fontSize = 10.sp, color = Steel, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
fun CreateMissionDialog(
    onDismiss: () -> Unit,
    onCreate: (Mission) -> Unit
) {
    var vehicleId by remember { mutableStateOf("ADF800E-017") }
    var origin by remember { mutableStateOf("AD DERBY CAMPUS") }
    var destination by remember { mutableStateOf("WAREHOUSE D - COVENTRY") }
    var cargoId by remember { mutableStateOf("CARGO-1884") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ADSurfaceNavy,
        title = {
            Text(text = "DISPATCH NEW AUTONOMOUS MISSION", color = EngineeringPaper, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = vehicleId,
                    onValueChange = { vehicleId = it },
                    label = { Text("Vehicle ID", color = Steel) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_vehicle_id")
                )
                OutlinedTextField(
                    value = origin,
                    onValueChange = { origin = it },
                    label = { Text("Origin Facility", color = Steel) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_origin")
                )
                OutlinedTextField(
                    value = destination,
                    onValueChange = { destination = it },
                    label = { Text("Destination Facility", color = Steel) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_destination")
                )
                OutlinedTextField(
                    value = cargoId,
                    onValueChange = { cargoId = it },
                    label = { Text("Freight Cargo ID", color = Steel) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_cargo_id")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val newM = Mission(
                        missionId = "M-${(20484..20999).random()}",
                        vehicleId = vehicleId,
                        status = MissionStatus.IN_PROGRESS,
                        origin = origin,
                        destination = destination,
                        cargoId = cargoId,
                        priority = "HIGH",
                        deliveryWindowStart = "2026-09-26T10:00Z",
                        deliveryWindowEnd = "2026-09-26T14:00Z",
                        progressPct = 5.0,
                        distanceRemainingKm = 24.5,
                        etaMinutes = 32
                    )
                    onCreate(newM)
                },
                modifier = Modifier.testTag("submit_mission_button"),
                colors = ButtonDefaults.buttonColors(containerColor = ADCyan, contentColor = ADNavy)
            ) {
                Text("DISPATCH", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("CANCEL", color = Steel)
            }
        }
    )
}
