package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ADNavy = Color(0xFF102A36)
val ADBlue = Color(0xFF1F4A5A)
val ADCyan = Color(0xFF4AB3D6)
val Graphite = Color(0xFF24282A)
val ADDarkBackground = Color(0xFF0B1317)
val ADSurfaceNavy = Color(0xFF16222A)
val ADCardSurface = Color(0xFF1C2B35)

val EngineeringPaper = Color(0xFFF1F0EA)
val Steel = Color(0xFF71797B)
val Aluminium = Color(0xFFAEB3B2)
val Concrete = Color(0xFFC9C7C0)

val ADAmber = Color(0xFFC48D35)
val ADRed = Color(0xFFA8423B)
val ADGreen = Color(0xFF3E6250)
val ADGreenBright = Color(0xFF4CAF50)
