package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Functions
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.r.RAnalyticsEngine
import com.example.r.RScriptTemplate
import com.example.r.RiskAnalysisResult
import com.example.ui.theme.ADAmber
import com.example.ui.theme.ADBlue
import com.example.ui.theme.ADCyan
import com.example.ui.theme.ADDarkBackground
import com.example.ui.theme.ADGreenBright
import com.example.ui.theme.ADNavy
import com.example.ui.theme.ADSurfaceNavy
import com.example.ui.theme.EngineeringPaper
import com.example.ui.theme.Steel

@Composable
fun RAnalyticsScreen(
    riskResult: RiskAnalysisResult
) {
    val templates = remember { RAnalyticsEngine.getSampleRScripts() }
    var selectedTemplate by remember { mutableStateOf(templates.first()) }
    var rConsoleOutput by remember { mutableStateOf("""
> library(adfreight)
> client <- ad_client(base_url = "https://api.freight.alexander-dennis.co.uk")
> risk_df <- ad_risk_analysis(client, mission_id = "M-20481")
AD FREIGHT R QUANTITATIVE ENGINE v1.2.0
Vehicle: ADF800E-017 | Mission: M-20481
Calculated Risk Score: ${riskResult.riskScore} [${riskResult.riskCategory}]
Min Obstacle Clearance: ${riskResult.minClearanceMeters} meters
Localisation Precision: 98.4%
Trajectory Errors: 0.042m (std_dev: 0.008)
""".trimIndent()) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ADDarkBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "R QUANTITATIVE COMPUTING ENGINE",
                    style = MaterialTheme.typography.displayMedium,
                    color = EngineeringPaper
                )
                Text(
                    text = "First-class 'adfreight' R package integration for statistical risk and fleet analysis",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Steel
                )
            }
        }

        item {
            // Computed Risk Summary Card
            Card(
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = ADSurfaceNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, ADBlue)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Analytics, contentDescription = null, tint = ADCyan)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = "R RISK ANALYSIS (M-20481)", style = MaterialTheme.typography.titleMedium, color = EngineeringPaper, fontWeight = FontWeight.Bold)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(ADBlue)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(text = riskResult.riskCategory, color = ADCyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "RISK SCORE", style = MaterialTheme.typography.labelSmall, color = Steel)
                            Text(text = "${riskResult.riskScore}", style = MaterialTheme.typography.titleLarge, color = ADAmber)
                        }
                        Column {
                            Text(text = "MIN CLEARANCE", style = MaterialTheme.typography.labelSmall, color = Steel)
                            Text(text = "${riskResult.minClearanceMeters} m", style = MaterialTheme.typography.titleLarge, color = ADGreenBright)
                        }
                        Column {
                            Text(text = "TRAJECTORY ERROR", style = MaterialTheme.typography.labelSmall, color = Steel)
                            Text(text = "${riskResult.trajectoryErrorMeters} m", style = MaterialTheme.typography.titleLarge, color = EngineeringPaper)
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "R SCRIPT TEMPLATES",
                style = MaterialTheme.typography.titleLarge,
                color = EngineeringPaper
            )
        }

        items(templates) { template ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        selectedTemplate = template
                        rConsoleOutput = """
> ${template.codeSnippet.lines().take(4).joinToString("\n> ")}
EXECUTING 'adfreight' R COMPUTATION ENGINE...
--------------------------------------------------
Task Completed in 14ms.
Data Frame Output: 100 rows x 8 variables.
Summary Stats: Mean clearance = 1.42m, Risk category = ${riskResult.riskCategory}.
""".trimIndent()
                    }
                    .testTag("r_script_card_${template.title.take(10)}"),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = ADSurfaceNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (selectedTemplate == template) ADCyan else ADBlue)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(text = template.title, style = MaterialTheme.typography.titleMedium, color = EngineeringPaper, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = template.description, style = MaterialTheme.typography.bodyMedium, color = Steel)
                }
            }
        }

        item {
            // R Execution Terminal Output
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(ADDarkBackground)
                    .border(1.dp, ADBlue, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "R CONSOLE OUTPUT", style = MaterialTheme.typography.labelSmall, color = ADCyan)
                        Text(text = "R v4.4.1 (adfreight v1.2)", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Steel)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = rConsoleOutput,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = EngineeringPaper,
                        lineHeight = 16.sp
                    )
                }
            }
        }
    }
}
