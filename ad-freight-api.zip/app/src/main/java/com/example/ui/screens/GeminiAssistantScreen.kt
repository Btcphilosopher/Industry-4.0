package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.Mission
import com.example.data.models.SafetyEventRecord
import com.example.data.models.Vehicle
import com.example.gemini.GeminiRiskAnalyzer
import com.example.ui.theme.ADAmber
import com.example.ui.theme.ADBlue
import com.example.ui.theme.ADCyan
import com.example.ui.theme.ADDarkBackground
import com.example.ui.theme.ADGreenBright
import com.example.ui.theme.ADNavy
import com.example.ui.theme.ADSurfaceNavy
import com.example.ui.theme.EngineeringPaper
import com.example.ui.theme.Steel
import kotlinx.coroutines.launch

@Composable
fun GeminiAssistantScreen(
    vehicle: Vehicle?,
    mission: Mission?,
    safetyEvents: List<SafetyEventRecord>
) {
    var promptInput by remember { mutableStateOf("Audit vehicle safety case for ADF800E-017 under Factory Floor ODD") }
    var analysisResult by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()

    val quickPrompts = listOf(
        "Audit Safety Case M-20481",
        "Evaluate ODD Speed Limiters",
        "Forensic Incident INCIDENT-00421"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ADDarkBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "AI SAFETY SUPERVISOR (GEMINI AI)",
                    style = MaterialTheme.typography.displayMedium,
                    color = EngineeringPaper
                )
                Text(
                    text = "Server-side Gemini AI for autonomous safety case evaluation and incident forensics",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Steel
                )
            }
        }

        item {
            // Quick Prompts
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                quickPrompts.forEach { q ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(ADSurfaceNavy)
                            .border(1.dp, ADBlue, RoundedCornerShape(4.dp))
                            .clickable { promptInput = q }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = q,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = ADCyan,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        item {
            Card(
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = ADSurfaceNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, ADBlue)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "SAFETY QUERY CONSOLE",
                        style = MaterialTheme.typography.titleMedium,
                        color = EngineeringPaper,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = promptInput,
                        onValueChange = { promptInput = it },
                        modifier = Modifier.fillMaxWidth().testTag("ai_prompt_input"),
                        minLines = 2
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            if (vehicle != null) {
                                isLoading = true
                                scope.launch {
                                    val report = GeminiRiskAnalyzer.analyzeSafetyCase(vehicle, mission, safetyEvents)
                                    analysisResult = report
                                    isLoading = false
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth().testTag("ai_analyze_button"),
                        shape = RoundedCornerShape(6.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ADCyan, contentColor = ADNavy)
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = ADNavy)
                        } else {
                            Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "GENERATE GEMINI SAFETY AUDIT", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            if (analysisResult != null) {
                Card(
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = ADSurfaceNavy),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ADGreenBright)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Psychology, contentDescription = null, tint = ADGreenBright)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "GEMINI AI SAFETY AUDIT REPORT",
                                style = MaterialTheme.typography.titleMedium,
                                color = EngineeringPaper,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = analysisResult ?: "",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp,
                            color = EngineeringPaper,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        }
    }
}
