package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ADAmber
import com.example.ui.theme.ADBlue
import com.example.ui.theme.ADCyan
import com.example.ui.theme.ADDarkBackground
import com.example.ui.theme.ADGreenBright
import com.example.ui.theme.ADNavy
import com.example.ui.theme.EngineeringPaper
import com.example.ui.theme.Steel

@Composable
fun TerminalJsonViewer(
    endpointPath: String,
    statusCode: Int,
    jsonBody: String,
    modifier: Modifier = Modifier,
    onShowBlueprint: (() -> Unit)? = null
) {
    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val tabs = listOf("JSON RESPONSE", "cURL", "R CLIENT", "RUST SDK")
    val context = LocalContext.current

    val curlSnippet = """
curl -X GET "https://api.freight.alexander-dennis.co.uk$endpointPath" \
  -H "Authorization: Bearer ad_live_key_uk_derby_8839201" \
  -H "Accept: application/json"
""".trimIndent()

    val rSnippet = """
library(adfreight)

client <- ad_client(
  base_url = "https://api.freight.alexander-dennis.co.uk",
  token = Sys.getenv("AD_API_TOKEN")
)

res <- ad_get(client, path = "$endpointPath")
print(res)
""".trimIndent()

    val rustSnippet = """
use ad_api::Client;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let client = Client::new("https://api.freight.alexander-dennis.co.uk")?;
    let res = client.get("$endpointPath").await?;
    println!("{:#?}", res);
    Ok(())
}
""".trimIndent()

    val currentContent = when (selectedTabIndex) {
        0 -> jsonBody
        1 -> curlSnippet
        2 -> rSnippet
        3 -> rustSnippet
        else -> jsonBody
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(ADDarkBackground)
            .border(1.dp, ADBlue, RoundedCornerShape(8.dp))
            .testTag("terminal_json_viewer")
    ) {
        Column {
            // Terminal Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ADNavy)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(ADGreenBright)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "HTTP $statusCode OK - $endpointPath",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = ADCyan,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (onShowBlueprint != null) {
                        Button(
                            onClick = onShowBlueprint,
                            modifier = Modifier
                                .height(28.dp)
                                .testTag("blueprint_toggle_button"),
                            shape = RoundedCornerShape(4.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ADAmber,
                                contentColor = ADNavy
                            )
                        ) {
                            Text(
                                text = "DATA → MACHINE",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                    }

                    IconButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("AD Freight API Code", currentContent)
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "Copied snippet to clipboard", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy code",
                            tint = Steel,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // Tabs
            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = ADNavy,
                contentColor = ADCyan
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = {
                            Text(
                                text = title,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTabIndex == index) ADCyan else Steel
                            )
                        }
                    )
                }
            }

            // Terminal Content Display
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .background(ADDarkBackground)
                    .padding(12.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = currentContent,
                    color = EngineeringPaper,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
            }
        }
    }
}
