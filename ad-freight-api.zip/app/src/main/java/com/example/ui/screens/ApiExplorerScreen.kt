package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.ApiLogRecord
import com.example.ui.components.TerminalJsonViewer
import com.example.ui.theme.ADAmber
import com.example.ui.theme.ADBlue
import com.example.ui.theme.ADCyan
import com.example.ui.theme.ADDarkBackground
import com.example.ui.theme.ADGreenBright
import com.example.ui.theme.ADNavy
import com.example.ui.theme.ADSurfaceNavy
import com.example.ui.theme.EngineeringPaper
import com.example.ui.theme.Steel
import kotlinx.coroutines.launch

@Composable
fun ApiExplorerScreen(
    apiLogs: List<ApiLogRecord>,
    onExecuteApi: suspend (String, String, String) -> Pair<Int, String>
) {
    var selectedMethod by remember { mutableStateOf("GET") }
    var inputPath by remember { mutableStateOf("/api/v1/vehicles/ADF800E-017") }
    var inputBody by remember { mutableStateOf("") }
    var currentResponseCode by remember { mutableIntStateOf(200) }
    var currentResponseBody by remember { mutableStateOf("{\n  \"status\": \"READY\",\n  \"message\": \"Execute an API endpoint above to test the AD Freight API sandbox.\"\n}") }

    val scope = rememberCoroutineScope()

    val quickEndpoints = listOf(
        Pair("GET", "/api/v1/vehicles"),
        Pair("GET", "/api/v1/vehicles/ADF800E-017"),
        Pair("GET", "/api/v1/missions/M-20481"),
        Pair("GET", "/api/v1/freight/CARGO-1881"),
        Pair("GET", "/api/v1/safety/status")
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ADDarkBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "OPENAPI 3 DEVELOPER CONSOLE & SANDBOX",
                    style = MaterialTheme.typography.displayMedium,
                    color = EngineeringPaper
                )
                Text(
                    text = "Interactive HTTP query engine and client SDK generator",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Steel
                )
            }
        }

        item {
            // Quick Endpoints
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                quickEndpoints.forEach { ep ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(ADSurfaceNavy)
                            .border(1.dp, ADBlue, RoundedCornerShape(4.dp))
                            .clickable {
                                selectedMethod = ep.first
                                inputPath = ep.second
                                scope.launch {
                                    val res = onExecuteApi(ep.first, ep.second, "")
                                    currentResponseCode = res.first
                                    currentResponseBody = res.second
                                }
                            }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "${ep.first} ${ep.second.substringAfter("/v1")}",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = ADCyan,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        item {
            // Endpoint Sandbox Input Card
            Card(
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = ADSurfaceNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, ADBlue)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "ENDPOINT RUNNER",
                        style = MaterialTheme.typography.titleMedium,
                        color = EngineeringPaper,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(ADNavy)
                                .border(1.dp, ADCyan, RoundedCornerShape(4.dp))
                                .padding(horizontal = 12.dp, vertical = 12.dp)
                        ) {
                            Text(text = selectedMethod, color = ADCyan, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        OutlinedTextField(
                            value = inputPath,
                            onValueChange = { inputPath = it },
                            modifier = Modifier.weight(1f).testTag("api_path_input"),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        Button(
                            onClick = {
                                scope.launch {
                                    val res = onExecuteApi(selectedMethod, inputPath, inputBody)
                                    currentResponseCode = res.first
                                    currentResponseBody = res.second
                                }
                            },
                            modifier = Modifier.testTag("execute_api_button"),
                            shape = RoundedCornerShape(4.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = ADCyan, contentColor = ADNavy)
                        ) {
                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = "Run")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "RUN", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            TerminalJsonViewer(
                endpointPath = inputPath,
                statusCode = currentResponseCode,
                jsonBody = currentResponseBody
            )
        }

        item {
            Text(
                text = "RECENT EXECUTED API CALLS LOG",
                style = MaterialTheme.typography.titleLarge,
                color = EngineeringPaper
            )
        }

        items(apiLogs) { log ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = ADSurfaceNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, ADBlue)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = log.method, color = ADCyan, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = log.path, color = EngineeringPaper, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "${log.latencyMs} ms", color = Steel, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "${log.statusCode} OK", color = ADGreenBright, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
