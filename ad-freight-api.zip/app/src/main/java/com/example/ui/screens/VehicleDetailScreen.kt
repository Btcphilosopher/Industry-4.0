package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.DeveloperBoard
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.models.AutonomyStateInfo
import com.example.data.models.Vehicle
import com.example.ui.components.TerminalJsonViewer
import com.example.ui.theme.ADAmber
import com.example.ui.theme.ADBlue
import com.example.ui.theme.ADCyan
import com.example.ui.theme.ADDarkBackground
import com.example.ui.theme.ADGreenBright
import com.example.ui.theme.ADNavy
import com.example.ui.theme.ADSurfaceNavy
import com.example.ui.theme.EngineeringPaper
import com.example.ui.theme.Steel

@Composable
fun VehicleDetailScreen(
    vehicle: Vehicle,
    autonomyInfo: AutonomyStateInfo,
    onBack: () -> Unit
) {
    var showBlueprint by remember { mutableStateOf(false) }

    val vehicleJson = """
{
  "vehicle_id": "${vehicle.vehicleId}",
  "model": "${vehicle.model}",
  "fleet_id": "${vehicle.fleetId}",
  "status": "${vehicle.status}",
  "autonomy_mode": "${vehicle.autonomyMode}",
  "speed_kph": ${vehicle.speedKph},
  "heading_deg": ${vehicle.headingDeg},
  "payload_kg": ${vehicle.payloadKg},
  "energy": {
    "state_of_charge": ${vehicle.stateOfCharge},
    "estimated_range_km": ${vehicle.estimatedRangeKm}
  },
  "location": {
    "latitude": ${vehicle.latitude},
    "longitude": ${vehicle.longitude},
    "name": "${vehicle.locationName}"
  },
  "autonomy_confidence": {
    "localisation": ${autonomyInfo.localisationConfidence},
    "perception": ${autonomyInfo.perceptionConfidence},
    "planning": ${autonomyInfo.planningConfidence}
  },
  "software_kernel": "${vehicle.softwareVersion}"
}
""".trimIndent()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ADDarkBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = ADCyan
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = vehicle.vehicleId,
                        style = MaterialTheme.typography.displayMedium,
                        color = EngineeringPaper
                    )
                    Text(
                        text = "${vehicle.model} • Kernel ${vehicle.softwareVersion}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Steel
                    )
                }
            }
        }

        item {
            // DATA -> MACHINE Signature Visual Blueprint Mode Toggle
            if (showBlueprint) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(ADNavy)
                        .border(1.dp, ADCyan, RoundedCornerShape(8.dp))
                        .padding(12.dp)
                        .testTag("blueprint_mode_container")
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.DeveloperBoard,
                                    contentDescription = "Blueprint",
                                    tint = ADCyan
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "TECHNICAL MACHINE BLUEPRINT",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = EngineeringPaper,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = "DIMENSIONS: 12.2m x 2.55m x 3.85m",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                color = ADAmber
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Image(
                            painter = painterResource(id = R.drawable.ad_hgv_blueprint_1790419642129),
                            contentDescription = "HGV Technical Drawing Schematic",
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(16f / 9f)
                                .clip(RoundedCornerShape(6.dp)),
                            contentScale = ContentScale.Crop
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "SPEC: Dual 400kW Axle Motor", fontSize = 10.sp, color = Steel, fontFamily = FontFamily.Monospace)
                            Text(text = "BATTERY: 600 kWh NMC 800V", fontSize = 10.sp, color = Steel, fontFamily = FontFamily.Monospace)
                            Text(text = "GVM: 38,000 kg", fontSize = 10.sp, color = Steel, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        item {
            // Autonomy System Confidence Cards
            Card(
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = ADSurfaceNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, ADBlue)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Memory, contentDescription = null, tint = ADCyan)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "AUTONOMY SUBSYSTEM CONFIDENCE",
                                style = MaterialTheme.typography.titleMedium,
                                color = EngineeringPaper,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "MODE: ${vehicle.autonomyMode.name}",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = ADAmber,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    ConfidenceBar("Localisation Confidence (GNSS + LiDAR Match)", (autonomyInfo.localisationConfidence * 100).toInt(), ADGreenBright)
                    Spacer(modifier = Modifier.height(8.dp))
                    ConfidenceBar("Perception Confidence (360° Camera + Radar Fusion)", (autonomyInfo.perceptionConfidence * 100).toInt(), ADCyan)
                    Spacer(modifier = Modifier.height(8.dp))
                    ConfidenceBar("Trajectory Planning Confidence (MPC Clearance)", (autonomyInfo.planningConfidence * 100).toInt(), ADAmber)
                }
            }
        }

        item {
            // Live Telemetry & Location
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = ADSurfaceNavy),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ADBlue)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Speed, contentDescription = null, tint = ADCyan, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "KINEMATICS", style = MaterialTheme.typography.labelSmall, color = Steel)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = "${vehicle.speedKph} km/h", style = MaterialTheme.typography.titleLarge, color = EngineeringPaper)
                        Text(text = "Heading: ${vehicle.headingDeg}°", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Steel)
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = ADSurfaceNavy),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ADBlue)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.LocationOn, contentDescription = null, tint = ADAmber, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "GEOLOCATION", style = MaterialTheme.typography.labelSmall, color = Steel)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = vehicle.locationName, style = MaterialTheme.typography.titleMedium, color = EngineeringPaper)
                        Text(
                            text = "${vehicle.latitude}, ${vehicle.longitude}",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Steel
                        )
                    }
                }
            }
        }

        item {
            // Sensor Health Grid
            Card(
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = ADSurfaceNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, ADBlue)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Sensors, contentDescription = null, tint = ADCyan)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "SENSOR SUITE DIAGNOSTICS",
                            style = MaterialTheme.typography.titleMedium,
                            color = EngineeringPaper,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        SensorStatusPill("LiDAR 128-Beam", "ONLINE")
                        SensorStatusPill("Radar 77GHz", "ONLINE")
                        SensorStatusPill("Camera 8K HD", "ONLINE")
                        SensorStatusPill("IMU / GNSS RTK", "FIXED_3CM")
                    }
                }
            }
        }

        item {
            // Live REST API JSON Response Inspector
            TerminalJsonViewer(
                endpointPath = "/api/v1/vehicles/${vehicle.vehicleId}",
                statusCode = 200,
                jsonBody = vehicleJson,
                onShowBlueprint = { showBlueprint = !showBlueprint }
            )
        }
    }
}

@Composable
fun ConfidenceBar(label: String, pct: Int, color: androidx.compose.ui.graphics.Color) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, style = MaterialTheme.typography.bodyMedium, color = EngineeringPaper)
            Text(text = "$pct%", fontFamily = FontFamily.Monospace, color = color, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { pct / 100f },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = color,
            trackColor = ADNavy
        )
    }
}

@Composable
fun SensorStatusPill(sensorName: String, status: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(ADNavy)
            .border(1.dp, ADBlue, RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = sensorName, fontSize = 9.sp, color = Steel, fontFamily = FontFamily.Monospace)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = status, fontSize = 10.sp, color = ADGreenBright, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }
    }
}
