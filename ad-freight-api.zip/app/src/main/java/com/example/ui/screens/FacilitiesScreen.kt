package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Domain
import androidx.compose.material.icons.filled.EvStation
import androidx.compose.material.icons.filled.PrecisionManufacturing
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.ChargerInfo
import com.example.data.models.DockInfo
import com.example.data.models.DockStatus
import com.example.data.models.Facility
import com.example.ui.theme.ADAmber
import com.example.ui.theme.ADBlue
import com.example.ui.theme.ADCyan
import com.example.ui.theme.ADDarkBackground
import com.example.ui.theme.ADGreenBright
import com.example.ui.theme.ADSurfaceNavy
import com.example.ui.theme.EngineeringPaper
import com.example.ui.theme.Steel

@Composable
fun FacilitiesScreen(
    facilities: List<Facility>,
    docks: List<DockInfo>,
    chargers: List<ChargerInfo>
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ADDarkBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "AD DERBY FREIGHT CAMPUS & FACILITIES",
                    style = MaterialTheme.typography.displayMedium,
                    color = EngineeringPaper
                )
                Text(
                    text = "Factory floor, loading docks grid, and high-power charging hub",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Steel
                )
            }
        }

        item {
            // Facilities Overview Cards
            facilities.forEach { facility ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = ADSurfaceNavy),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ADBlue)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.Domain, contentDescription = null, tint = ADCyan)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = facility.name,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = EngineeringPaper,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(text = facility.type, color = ADAmber, fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "DOCKS: ${facility.availableDocks} / ${facility.totalDocks} Available", fontSize = 11.sp, color = Steel, fontFamily = FontFamily.Monospace)
                            Text(text = "CHARGERS: ${facility.activeChargers} / ${facility.totalChargers} Active", fontSize = 11.sp, color = Steel, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "REAL-TIME DOCKING GRID",
                style = MaterialTheme.typography.titleLarge,
                color = EngineeringPaper
            )
        }

        items(docks) { dock ->
            DockGridCard(dock = dock)
        }

        item {
            Text(
                text = "HIGH-POWER CHARGING HUB (350kW MCS)",
                style = MaterialTheme.typography.titleLarge,
                color = EngineeringPaper,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        items(chargers) { charger ->
            ChargerCardItem(charger = charger)
        }
    }
}

@Composable
fun DockGridCard(dock: DockInfo) {
    val statusColor = when (dock.status) {
        DockStatus.AVAILABLE -> ADGreenBright
        DockStatus.RESERVED -> ADAmber
        DockStatus.DOCKED, DockStatus.ALIGNING -> ADCyan
        else -> Steel
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("dock_card_${dock.dockId}"),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = ADSurfaceNavy),
        border = androidx.compose.foundation.BorderStroke(1.dp, ADBlue)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.PrecisionManufacturing, contentDescription = null, tint = statusColor)
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(text = dock.name, style = MaterialTheme.typography.titleMedium, color = EngineeringPaper, fontWeight = FontWeight.Bold)
                    Text(
                        text = "Assigned Unit: ${dock.assignedVehicleId ?: "NONE"}",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Steel
                    )
                }
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(statusColor.copy(alpha = 0.2f))
                    .border(1.dp, statusColor, RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = dock.status.name,
                    color = statusColor,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun ChargerCardItem(charger: ChargerInfo) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = ADSurfaceNavy),
        border = androidx.compose.foundation.BorderStroke(1.dp, ADBlue)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.EvStation, contentDescription = null, tint = ADAmber)
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(text = charger.chargerId, style = MaterialTheme.typography.titleMedium, color = EngineeringPaper, fontWeight = FontWeight.Bold)
                    Text(text = "Power: ${charger.currentKwPower} kW / ${charger.maxKwPower} kW", fontSize = 11.sp, color = Steel, fontFamily = FontFamily.Monospace)
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(text = charger.status, color = ADCyan, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                Text(text = "Delivered: ${charger.energyDeliveredKwh} kWh", fontSize = 10.sp, color = Steel, fontFamily = FontFamily.Monospace)
            }
        }
    }
}
