package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = ADCyan,
    onPrimary = ADNavy,
    primaryContainer = ADBlue,
    onPrimaryContainer = EngineeringPaper,
    secondary = ADAmber,
    onSecondary = ADNavy,
    tertiary = Steel,
    onTertiary = EngineeringPaper,
    background = ADDarkBackground,
    onBackground = EngineeringPaper,
    surface = ADSurfaceNavy,
    onSurface = EngineeringPaper,
    surfaceVariant = ADCardSurface,
    onSurfaceVariant = Aluminium,
    outline = Steel,
    outlineVariant = Graphite,
    error = ADRed,
    onError = Color.White
)

@Composable
fun ADFreightTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
