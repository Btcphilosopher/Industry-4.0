package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.PrecisionManufacturing
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.Vehicle
import com.example.data.models.VehicleStatus
import com.example.ui.theme.ADAmber
import com.example.ui.theme.ADBlue
import com.example.ui.theme.ADCyan
import com.example.ui.theme.ADDarkBackground
import com.example.ui.theme.ADGreenBright
import com.example.ui.theme.ADNavy
import com.example.ui.theme.ADRed
import com.example.ui.theme.ADSurfaceNavy
import com.example.ui.theme.EngineeringPaper
import com.example.ui.theme.Steel

@Composable
fun FleetDashboardScreen(
    vehicles: List<Vehicle>,
    onSelectVehicle: (String) -> Unit
) {
    val activeCount = vehicles.count { it.status == VehicleStatus.ACTIVE }
    val dockedCount = vehicles.count { it.status == VehicleStatus.DOCKED }
    val avgSoc = if (vehicles.isNotEmpty()) vehicles.map { it.stateOfCharge }.average() else 0.0

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ADDarkBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            // Fleet Operational KPI Summary
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                KpiMetricCard(
                    title = "FLEET VEHICLES",
                    value = "${vehicles.size}",
                    subtext = "$activeCount Active | $dockedCount Docked",
                    icon = Icons.Default.LocalShipping,
                    modifier = Modifier.weight(1f)
                )
                KpiMetricCard(
                    title = "AVG ENERGY SOC",
                    value = "${String.format("%.1f", avgSoc)}%",
                    subtext = "High Power Grid 800V",
                    icon = Icons.Default.BatteryChargingFull,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            // Operational Domain Distribution Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(ADSurfaceNavy)
                    .border(1.dp, ADBlue, RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.PrecisionManufacturing,
                                contentDescription = "Domain",
                                tint = ADAmber,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "ACTIVE OPERATIONAL DOMAIN (ODD)",
                                style = MaterialTheme.typography.titleMedium,
                                color = EngineeringPaper,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "SAFETY CASE VERIFIED",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = ADGreenBright,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OddBadge("FACTORY_FLOOR", "Max 8 km/h", ADCyan)
                        OddBadge("INDUSTRIAL_YARD", "Max 15 km/h", ADAmber)
                        OddBadge("DEPOT_DOCKING", "Precision Align", ADGreenBright)
                    }
                }
            }
        }

        item {
            Text(
                text = "REGISTERED FLEET UNITS",
                style = MaterialTheme.typography.titleLarge,
                color = EngineeringPaper,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }

        items(vehicles) { vehicle ->
            VehicleCardItem(
                vehicle = vehicle,
                onClick = { onSelectVehicle(vehicle.vehicleId) }
            )
        }
    }
}

@Composable
fun KpiMetricCard(
    title: String,
    value: String,
    subtext: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = ADSurfaceNavy),
        border = androidx.compose.foundation.BorderStroke(1.dp, ADBlue)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall,
                    color = Steel
                )
                Icon(imageVector = icon, contentDescription = null, tint = ADCyan, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.displayLarge,
                color = EngineeringPaper
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtext,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                color = Steel
            )
        }
    }
}

@Composable
fun VehicleCardItem(
    vehicle: Vehicle,
    onClick: () -> Unit
) {
    val statusColor = when (vehicle.status) {
        VehicleStatus.ACTIVE -> ADGreenBright
        VehicleStatus.DOCKED -> ADCyan
        VehicleStatus.CHARGING -> ADAmber
        VehicleStatus.DEGRADED, VehicleStatus.EMERGENCY_STOP -> ADRed
        else -> Steel
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("vehicle_card_${vehicle.vehicleId}"),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = ADSurfaceNavy),
        border = androidx.compose.foundation.BorderStroke(1.dp, ADBlue)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocalShipping,
                        contentDescription = "Vehicle",
                        tint = ADCyan,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = vehicle.vehicleId,
                            style = MaterialTheme.typography.titleLarge,
                            color = EngineeringPaper,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${vehicle.model} | Fleet: ${vehicle.fleetId}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Steel
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(statusColor.copy(alpha = 0.2f))
                        .border(1.dp, statusColor, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = vehicle.status.name,
                        color = statusColor,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Telemetry & Autonomy Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "AUTONOMY MODE", style = MaterialTheme.typography.labelSmall, color = Steel)
                    Text(
                        text = vehicle.autonomyMode.name,
                        fontFamily = FontFamily.Monospace,
                        color = ADCyan,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }

                Column {
                    Text(text = "SPEED / HEADING", style = MaterialTheme.typography.labelSmall, color = Steel)
                    Text(
                        text = "${vehicle.speedKph} km/h @ ${vehicle.headingDeg}°",
                        fontFamily = FontFamily.Monospace,
                        color = EngineeringPaper,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }

                Column {
                    Text(text = "PAYLOAD", style = MaterialTheme.typography.labelSmall, color = Steel)
                    Text(
                        text = "${vehicle.payloadKg} / ${vehicle.maxPayloadKg} kg",
                        fontFamily = FontFamily.Monospace,
                        color = EngineeringPaper,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Battery Progress
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "STATE OF CHARGE", style = MaterialTheme.typography.labelSmall, color = Steel)
                    Text(
                        text = "${vehicle.stateOfCharge}% (${vehicle.estimatedRangeKm.toInt()} km range)",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = ADAmber,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { (vehicle.stateOfCharge / 100.0).toFloat() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = ADAmber,
                    trackColor = ADNavy
                )
            }
        }
    }
}

@Composable
fun OddBadge(domainName: String, speedLimit: String, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(color.copy(alpha = 0.15f))
            .border(1.dp, color, RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = "$domainName ($speedLimit)",
            color = color,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
    }
}
