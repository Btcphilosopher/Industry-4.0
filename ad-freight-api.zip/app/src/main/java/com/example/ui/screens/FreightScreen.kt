package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Pin
import androidx.compose.material.icons.filled.Scale
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.CargoUnit
import com.example.data.models.Trailer
import com.example.ui.theme.ADAmber
import com.example.ui.theme.ADBlue
import com.example.ui.theme.ADCyan
import com.example.ui.theme.ADDarkBackground
import com.example.ui.theme.ADGreenBright
import com.example.ui.theme.ADSurfaceNavy
import com.example.ui.theme.EngineeringPaper
import com.example.ui.theme.Steel

@Composable
fun FreightScreen(
    cargoList: List<CargoUnit>,
    trailers: List<Trailer>
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ADDarkBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "FREIGHT & CARGO MANAGEMENT",
                    style = MaterialTheme.typography.displayMedium,
                    color = EngineeringPaper
                )
                Text(
                    text = "Tracked industrial freight units, trailers, and handling specifications",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Steel
                )
            }
        }

        item {
            Text(
                text = "TRAILER CONNECTIVITY STATE",
                style = MaterialTheme.typography.titleLarge,
                color = EngineeringPaper
            )
        }

        items(trailers) { trailer ->
            TrailerCardItem(trailer = trailer)
        }

        item {
            Text(
                text = "REGISTERED CARGO UNITS",
                style = MaterialTheme.typography.titleLarge,
                color = EngineeringPaper,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        items(cargoList) { cargo ->
            CargoCardItem(cargo = cargo)
        }
    }
}

@Composable
fun CargoCardItem(cargo: CargoUnit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("cargo_card_${cargo.cargoId}"),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = ADSurfaceNavy),
        border = androidx.compose.foundation.BorderStroke(1.dp, ADBlue)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Inventory2, contentDescription = null, tint = ADAmber)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = cargo.cargoId,
                            style = MaterialTheme.typography.titleLarge,
                            color = EngineeringPaper,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = cargo.customer,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Steel
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(ADBlue)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = cargo.status.name,
                        color = ADCyan,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = cargo.cargoType,
                style = MaterialTheme.typography.titleMedium,
                color = ADCyan,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "WEIGHT & DIMENSIONS", style = MaterialTheme.typography.labelSmall, color = Steel)
                    Text(text = "${cargo.weightKg} kg | ${cargo.dimensionsMeters}", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = EngineeringPaper)
                }

                Column {
                    Text(text = "ASSIGNED VEHICLE & TRAILER", style = MaterialTheme.typography.labelSmall, color = Steel)
                    Text(text = "${cargo.vehicleId ?: "UNASSIGNED"} / ${cargo.trailerId ?: "N/A"}", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = EngineeringPaper)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(ADDarkBackground)
                    .border(1.dp, ADBlue, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = ADAmber, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "HANDLING: ${cargo.handlingRequirements}",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = ADAmber
                    )
                }
            }
        }
    }
}

@Composable
fun TrailerCardItem(trailer: Trailer) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = ADSurfaceNavy),
        border = androidx.compose.foundation.BorderStroke(1.dp, ADBlue)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.LocalShipping, contentDescription = null, tint = ADCyan)
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(text = trailer.trailerId, style = MaterialTheme.typography.titleMedium, color = EngineeringPaper, fontWeight = FontWeight.Bold)
                    Text(text = "${trailer.type} • Tare: ${trailer.tareWeightKg}kg", fontSize = 11.sp, color = Steel)
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = trailer.status,
                    color = ADGreenBright,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Payload: ${trailer.currentPayloadKg} / ${trailer.payloadCapacityKg} kg",
                    fontSize = 10.sp,
                    color = Steel,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
