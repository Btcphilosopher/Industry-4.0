package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.AltRoute
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Domain
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.AutonomyMode
import com.example.data.models.AutonomyStateInfo
import com.example.data.models.Vehicle
import com.example.data.repository.FreightRepository
import com.example.r.RAnalyticsEngine
import com.example.ui.components.HeaderBanner
import com.example.ui.screens.ApiExplorerScreen
import com.example.ui.screens.FacilitiesScreen
import com.example.ui.screens.FleetDashboardScreen
import com.example.ui.screens.FreightScreen
import com.example.ui.screens.GeminiAssistantScreen
import com.example.ui.screens.MissionsScreen
import com.example.ui.screens.RAnalyticsScreen
import com.example.ui.screens.SafetyScreen
import com.example.ui.screens.VehicleDetailScreen
import com.example.ui.theme.ADAmber
import com.example.ui.theme.ADBlue
import com.example.ui.theme.ADCyan
import com.example.ui.theme.ADDarkBackground
import com.example.ui.theme.ADFreightTheme
import com.example.ui.theme.ADNavy
import com.example.ui.theme.EngineeringPaper
import com.example.ui.theme.Steel
import kotlinx.coroutines.launch

enum class Screen {
    FLEET, VEHICLE_DETAIL, MISSIONS, FREIGHT, FACILITIES, SAFETY, API_EXPLORER, R_ANALYTICS, GEMINI_AI
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ADFreightTheme {
                MainApp()
            }
        }
    }
}

@Composable
fun MainApp() {
    val context = LocalContext.current
    val repository = remember(context) { FreightRepository.getInstance(context) }
    val scope = rememberCoroutineScope()

    val vehicles by repository.vehicles.collectAsState(initial = emptyList())
    val missions by repository.missions.collectAsState(initial = emptyList())
    val cargoList by repository.cargoList.collectAsState(initial = emptyList())
    val safetyEvents by repository.safetyEvents.collectAsState(initial = emptyList())
    val apiLogs by repository.apiLogs.collectAsState(initial = emptyList())

    val facilities by repository.facilities.collectAsState()
    val docks by repository.docks.collectAsState()
    val chargers by repository.chargers.collectAsState()
    val trailers by repository.trailers.collectAsState()

    var currentScreen by remember { mutableStateOf(Screen.FLEET) }
    var selectedVehicleId by remember { mutableStateOf("ADF800E-017") }

    val selectedVehicle = vehicles.find { it.vehicleId == selectedVehicleId } ?: vehicles.firstOrNull() ?: Vehicle(
        vehicleId = "ADF800E-017",
        model = "AD-F800E",
        fleetId = "AD-FLEET-001",
        status = com.example.data.models.VehicleStatus.ACTIVE,
        autonomyMode = AutonomyMode.FACTORY_FLOOR,
        speedKph = 8.4,
        headingDeg = 181.2,
        payloadKg = 31800,
        maxPayloadKg = 38000,
        stateOfCharge = 72.4,
        estimatedRangeKm = 214.0,
        latitude = 52.9225,
        longitude = -1.4746,
        locationName = "AD Derby Freight Campus",
        currentMissionId = "M-20481",
        assignedTrailerId = "AD-TR-402",
        softwareVersion = "AD-KERNEL-v3.8.4"
    )

    val currentMission = missions.find { it.vehicleId == selectedVehicle.vehicleId } ?: missions.firstOrNull()

    val autonomyState = remember(selectedVehicle) {
        AutonomyStateInfo(
            vehicleId = selectedVehicle.vehicleId,
            mode = selectedVehicle.autonomyMode,
            operationalDomain = "FACTORY_FLOOR_DERBY_CAMPUS",
            localisationConfidence = 0.984,
            perceptionConfidence = 0.992,
            planningConfidence = 0.975,
            worldModelAgeMs = 12,
            sensorHealth = "NOMINAL_HEALTH",
            computeHealth = "DUAL_REDUNDANT_NOMINAL",
            safetyState = "SAFE_OPERATIONAL",
            activeGeofence = "ZONE_DERBY_INNER_PERIMETER"
        )
    }

    val incidentSession = remember {
        com.example.data.models.IncidentRecorderSession(
            incidentId = "INCIDENT-00421",
            vehicleId = selectedVehicle.vehicleId,
            softwareVersion = "AD-KERNEL-v3.8.4",
            timestampStr = "2026-09-26 03:14:22 UTC",
            preBufferSeconds = 10,
            postBufferSeconds = 10,
            triggerCause = "MINIMUM_CLEARANCE_ADVISORY_MARGIN_1.42M",
            recordedPointsCount = 200,
            hazardsDetected = listOf("FORKLIFT_ALIGNED_REAR", "PEDESTRIAN_SAFETY_WALKWAY")
        )
    }

    val riskResult = remember(selectedVehicle) {
        RAnalyticsEngine.computeRiskAnalysis(selectedVehicle, currentMission, emptyList())
    }

    // Handle Back Press when on secondary screens
    if (currentScreen != Screen.FLEET) {
        BackHandler {
            currentScreen = Screen.FLEET
        }
    }

    Scaffold(
        topBar = {
            HeaderBanner(
                activeScreenName = currentScreen.name,
                onOpenApiExplorer = { currentScreen = Screen.API_EXPLORER }
            )
        },
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("bottom_navigation_bar"),
                containerColor = ADNavy,
                contentColor = ADCyan
            ) {
                NavTabItem(
                    title = "FLEET",
                    icon = Icons.Default.LocalShipping,
                    isSelected = currentScreen == Screen.FLEET,
                    onClick = { currentScreen = Screen.FLEET }
                )
                NavTabItem(
                    title = "VEHICLE",
                    icon = Icons.Default.LocalShipping,
                    isSelected = currentScreen == Screen.VEHICLE_DETAIL,
                    onClick = { currentScreen = Screen.VEHICLE_DETAIL }
                )
                NavTabItem(
                    title = "MISSION",
                    icon = Icons.Default.AltRoute,
                    isSelected = currentScreen == Screen.MISSIONS,
                    onClick = { currentScreen = Screen.MISSIONS }
                )
                NavTabItem(
                    title = "FREIGHT",
                    icon = Icons.Default.Inventory2,
                    isSelected = currentScreen == Screen.FREIGHT,
                    onClick = { currentScreen = Screen.FREIGHT }
                )
                NavTabItem(
                    title = "FACILITIES",
                    icon = Icons.Default.Domain,
                    isSelected = currentScreen == Screen.FACILITIES,
                    onClick = { currentScreen = Screen.FACILITIES }
                )
                NavTabItem(
                    title = "SAFETY",
                    icon = Icons.Default.Shield,
                    isSelected = currentScreen == Screen.SAFETY,
                    onClick = { currentScreen = Screen.SAFETY }
                )
                NavTabItem(
                    title = "API",
                    icon = Icons.Default.Terminal,
                    isSelected = currentScreen == Screen.API_EXPLORER,
                    onClick = { currentScreen = Screen.API_EXPLORER }
                )
                NavTabItem(
                    title = "R",
                    icon = Icons.Default.Analytics,
                    isSelected = currentScreen == Screen.R_ANALYTICS,
                    onClick = { currentScreen = Screen.R_ANALYTICS }
                )
                NavTabItem(
                    title = "AI",
                    icon = Icons.Default.AutoAwesome,
                    isSelected = currentScreen == Screen.GEMINI_AI,
                    onClick = { currentScreen = Screen.GEMINI_AI }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(ADDarkBackground)
        ) {
            when (currentScreen) {
                Screen.FLEET -> FleetDashboardScreen(
                    vehicles = vehicles,
                    onSelectVehicle = { id ->
                        selectedVehicleId = id
                        currentScreen = Screen.VEHICLE_DETAIL
                    }
                )
                Screen.VEHICLE_DETAIL -> VehicleDetailScreen(
                    vehicle = selectedVehicle,
                    autonomyInfo = autonomyState,
                    onBack = { currentScreen = Screen.FLEET }
                )
                Screen.MISSIONS -> MissionsScreen(
                    missions = missions,
                    onCreateMission = { newM ->
                        scope.launch {
                            repository.createMission(newM)
                        }
                    }
                )
                Screen.FREIGHT -> FreightScreen(
                    cargoList = cargoList,
                    trailers = trailers
                )
                Screen.FACILITIES -> FacilitiesScreen(
                    facilities = facilities,
                    docks = docks,
                    chargers = chargers
                )
                Screen.SAFETY -> SafetyScreen(
                    safetyEvents = safetyEvents,
                    incidentSession = incidentSession
                )
                Screen.API_EXPLORER -> ApiExplorerScreen(
                    apiLogs = apiLogs,
                    onExecuteApi = { method, path, body ->
                        repository.executeApiCall(method, path, 200, body)
                    }
                )
                Screen.R_ANALYTICS -> RAnalyticsScreen(
                    riskResult = riskResult
                )
                Screen.GEMINI_AI -> GeminiAssistantScreen(
                    vehicle = selectedVehicle,
                    mission = currentMission,
                    safetyEvents = safetyEvents
                )
            }
        }
    }
}

@Composable
fun androidx.compose.foundation.layout.RowScope.NavTabItem(
    title: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    NavigationBarItem(
        selected = isSelected,
        onClick = onClick,
        icon = {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (isSelected) ADCyan else Steel
            )
        },
        label = {
            Text(
                text = title,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) ADCyan else Steel
            )
        },
        colors = NavigationBarItemDefaults.colors(
            indicatorColor = ADBlue
        ),
        modifier = Modifier.testTag("nav_item_$title")
    )
}
