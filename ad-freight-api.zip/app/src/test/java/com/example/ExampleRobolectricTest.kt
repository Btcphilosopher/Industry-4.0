package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.models.AutonomyMode
import com.example.data.models.Vehicle
import com.example.data.models.VehicleStatus
import com.example.r.RAnalyticsEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("AD Freight API", appName)
    }

    @Test
    fun `test R risk analysis computation`() {
        val testVehicle = Vehicle(
            vehicleId = "ADF800E-017",
            model = "AD-F800E",
            fleetId = "AD-FLEET-001",
            status = VehicleStatus.ACTIVE,
            autonomyMode = AutonomyMode.FACTORY_FLOOR,
            speedKph = 8.4,
            headingDeg = 181.2,
            payloadKg = 31800,
            maxPayloadKg = 38000,
            stateOfCharge = 72.4,
            estimatedRangeKm = 214.0,
            latitude = 52.9225,
            longitude = -1.4746,
            locationName = "AD Derby Freight Campus",
            currentMissionId = "M-20481",
            assignedTrailerId = "AD-TR-402",
            softwareVersion = "AD-KERNEL-v3.8.4"
        )

        val riskResult = RAnalyticsEngine.computeRiskAnalysis(testVehicle, null, emptyList())

        assertNotNull(riskResult)
        assertEquals("ADF800E-017", riskResult.vehicleId)
        assert(riskResult.minClearanceMeters > 0.5)
    }
}
