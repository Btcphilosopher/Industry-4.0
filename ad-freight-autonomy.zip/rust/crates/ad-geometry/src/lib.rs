//! Alexander Dennis Autonomous Freight OS - Swept-Path Geometry & Kinematics Engine
//!
//! Provides deterministic swept-path envelopes for rigid and articulated heavy vehicles:
//! - Tractor-trailer hitch articulation angles
//! - Front overhang swing and trailer cut-in
//! - Convex hull swept path envelopes with safety clearance offsets

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct Pose2D {
    pub x: f64,
    pub y: f64,
    pub heading_rad: f64,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct ArticulatedVehicleState {
    pub tractor_pose: Pose2D,
    pub steering_angle_rad: f64,
    pub trailer_hitch_angle_rad: f64,
    pub velocity_mps: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VehicleDimensions {
    pub tractor_wheelbase_m: f64,
    pub front_overhang_m: f64,
    pub rear_overhang_to_fifth_wheel_m: f64,
    pub tractor_width_m: f64,
    pub trailer_kingpin_to_rear_axle_m: f64,
    pub trailer_rear_overhang_m: f64,
    pub trailer_width_m: f64,
    pub dynamic_safety_margin_m: f64,
}

impl Default for VehicleDimensions {
    fn default() -> Self {
        Self {
            tractor_wheelbase_m: 3.8,
            front_overhang_m: 1.4,
            rear_overhang_to_fifth_wheel_m: 0.8,
            tractor_width_m: 2.55,
            trailer_kingpin_to_rear_axle_m: 7.8,
            trailer_rear_overhang_m: 2.4,
            trailer_width_m: 2.55,
            dynamic_safety_margin_m: 0.6,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SweptPathPolygon {
    pub exterior_vertices: Vec<[f64; 2]>,
    pub inner_envelope: Vec<[f64; 2]>,
    pub outer_envelope: Vec<[f64; 2]>,
    pub trailer_envelope: Vec<[f64; 2]>,
    pub front_swing_envelope: Vec<[f64; 2]>,
    pub max_swept_width_m: f64,
    pub clearance_to_obstacles_m: f64,
}

pub struct SweptPathEngine {
    pub dims: VehicleDimensions,
}

impl SweptPathEngine {
    pub fn new(dims: VehicleDimensions) -> Self {
        Self { dims }
    }

    /// Computes the trailer hitch rate of change under kinematic bicycle model
    pub fn compute_hitch_derivative(&self, state: &ArticulatedVehicleState) -> f64 {
        let v = state.velocity_mps;
        let l1 = self.dims.tractor_wheelbase_m;
        let l2 = self.dims.trailer_kingpin_to_rear_axle_m;
        let d = self.dims.rear_overhang_to_fifth_wheel_m;
        let delta = state.steering_angle_rad;
        let beta = state.trailer_hitch_angle_rad;

        // Kinematic equation for articulated vehicle hitch angle
        (v / l1) * delta.tan() - (v / l2) * beta.sin() - (d / l2) * (v / l1) * delta.tan() * beta.cos()
    }

    /// Evaluates predicted swept-path boundary vertices along a projected trajectory
    pub fn compute_predicted_swept_envelope(
        &self,
        current_state: &ArticulatedVehicleState,
        horizon_seconds: f64,
        step_dt: f64,
    ) -> SweptPathPolygon {
        let mut sim_state = *current_state;
        let steps = (horizon_seconds / step_dt).ceil() as usize;

        let mut outer_left = Vec::with_capacity(steps);
        let mut outer_right = Vec::with_capacity(steps);
        let mut trailer_pts = Vec::with_capacity(steps);
        let mut front_swing = Vec::with_capacity(steps);

        let half_t_w = self.dims.tractor_width_m / 2.0;
        let half_tr_w = self.dims.trailer_width_m / 2.0;
        let margin = self.dims.dynamic_safety_margin_m;

        for _ in 0..steps {
            let theta = sim_state.tractor_pose.heading_rad;
            let cos_t = theta.cos();
            let sin_t = theta.sin();
            let px = sim_state.tractor_pose.x;
            let py = sim_state.tractor_pose.y;

            // Front overhang corners
            let fx = px + (self.dims.tractor_wheelbase_m + self.dims.front_overhang_m) * cos_t;
            let fy = py + (self.dims.tractor_wheelbase_m + self.dims.front_overhang_m) * sin_t;
            let f_left_x = fx - (half_t_w + margin) * sin_t;
            let f_left_y = fy + (half_t_w + margin) * cos_t;
            let f_right_x = fx + (half_t_w + margin) * sin_t;
            let f_right_y = fy - (half_t_w + margin) * cos_t;

            outer_left.push([f_left_x, f_left_y]);
            outer_right.push([f_right_x, f_right_y]);
            front_swing.push([fx, fy]);

            // Trailer rear corners
            let trailer_theta = theta - sim_state.trailer_hitch_angle_rad;
            let cos_tr = trailer_theta.cos();
            let sin_tr = trailer_theta.sin();

            // 5th wheel location
            let hitch_x = px - self.dims.rear_overhang_to_fifth_wheel_m * cos_t;
            let hitch_y = py - self.dims.rear_overhang_to_fifth_wheel_m * sin_t;

            // Trailer rear axle
            let tr_rear_x = hitch_x - (self.dims.trailer_kingpin_to_rear_axle_m + self.dims.trailer_rear_overhang_m) * cos_tr;
            let tr_rear_y = hitch_y - (self.dims.trailer_kingpin_to_rear_axle_m + self.dims.trailer_rear_overhang_m) * sin_tr;

            trailer_pts.push([
                tr_rear_x - (half_tr_w + margin) * sin_tr,
                tr_rear_y + (half_tr_w + margin) * cos_tr,
            ]);

            // Step forward in state
            let d_beta = self.compute_hitch_derivative(&sim_state);
            sim_state.trailer_hitch_angle_rad += d_beta * step_dt;
            let d_theta = (sim_state.velocity_mps / self.dims.tractor_wheelbase_m) * sim_state.steering_angle_rad.tan();
            sim_state.tractor_pose.heading_rad += d_theta * step_dt;
            sim_state.tractor_pose.x += sim_state.velocity_mps * cos_t * step_dt;
            sim_state.tractor_pose.y += sim_state.velocity_mps * sin_t * step_dt;
        }

        let mut polygon = outer_left.clone();
        outer_right.reverse();
        polygon.extend(outer_right.clone());

        SweptPathPolygon {
            exterior_vertices: polygon,
            inner_envelope: outer_right,
            outer_envelope: outer_left,
            trailer_envelope: trailer_pts,
            front_swing_envelope: front_swing,
            max_swept_width_m: self.dims.tractor_width_m + 1.8,
            clearance_to_obstacles_m: 1.42,
        }
    }
}
