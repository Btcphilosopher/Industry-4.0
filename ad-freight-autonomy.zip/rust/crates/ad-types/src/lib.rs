//! Alexander Dennis Autonomous Freight OS - Core Types & Domain Model
//!
//! Strongly typed primitives for heavy freight autonomy:
//! - Operational domains (Road vs Industrial)
//! - Autonomy & degradation states
//! - Sensor modalities and health
//! - Freight manifests and vehicles

use serde::{Deserialize, Serialize};
use chrono::{DateTime, Utc};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum OperationalDomain {
    /// Domain A: Motorways, dual carriageways, A-roads, urban logistics corridors
    RoadFreight,
    /// Domain B: Manufacturing campus, steel works, tight factory floors, loading docks
    IndustrialAutonomy,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum AutonomyMode {
    ManualIntervention,
    TeleoperationStandby,
    AutonomousRoadCruising,
    AutonomousUrbanCorridor,
    AutonomousIndustrialYard,
    AutonomousPrecisionDocking,
    DegradedOperationalDomain,
    MinimumRiskManoeuvre,
    EmergencyStopSafeHalt,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum VehicleModelSeries {
    ADF450Rigid,
    ADF600HeavyRigid,
    ADF800Tractor,
    ADF800EBatteryElectric,
    ADF900EHighCapacityElectric,
    ADYARD60LowSpeedTug,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum LocalisationStrategy {
    GnssRtk,
    GnssImuCoupled,
    LidarOdometrySlam,
    VisualMapMatching,
    DepotUwbBeacons,
    DegradedDeadReckoning,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum SafetySupervisorState {
    NominalEnvelope,
    CautionProximityAlert,
    DegradedSensorDropout,
    PathReplanningActive,
    MinimumRiskDeceleration,
    HardwareSafetyBraking,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VehicleIdentification {
    pub vehicle_id: String,
    pub model: VehicleModelSeries,
    pub registration_uk: String,
    pub unladen_mass_kg: f64,
    pub max_gross_weight_kg: f64,
    pub overall_length_m: f64,
    pub overall_width_m: f64,
    pub wheelbase_m: f64,
    pub max_steering_angle_rad: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FreightManifest {
    pub cargo_id: String,
    pub cargo_type: String,
    pub weight_kg: f64,
    pub origin_facility: String,
    pub destination_facility: String,
    pub priority_level: u8,
    pub hazardous: bool,
    pub required_temp_celsius: Option<f32>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TelemetrySnapshot {
    pub vehicle_id: String,
    pub timestamp: DateTime<Utc>,
    pub domain: OperationalDomain,
    pub autonomy_mode: AutonomyMode,
    pub speed_kph: f64,
    pub acceleration_mps2: f64,
    pub heading_rad: f64,
    pub steering_angle_rad: f64,
    pub hitch_angle_rad: f64,
    pub state_of_charge_pct: f32,
    pub payload_kg: f64,
    pub localisation_confidence: f32,
    pub perception_confidence: f32,
    pub min_clearance_m: f64,
    pub safety_state: SafetySupervisorState,
}
