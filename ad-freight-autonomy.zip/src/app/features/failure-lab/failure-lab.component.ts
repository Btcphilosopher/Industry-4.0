import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FreightStateService } from '../../core/services/freight-state.service';

@Component({
  selector: 'app-failure-lab',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#111415] text-[#F1F0EA] overflow-y-auto">
      <!-- Header -->
      <div class="border-b border-[#24282A] px-6 py-4 bg-[#102A36]">
        <div class="flex items-center space-x-2 text-xs font-mono text-[#A8423B] uppercase">
          <mat-icon class="text-sm">bug_report</mat-icon>
          <span>AUTONOMY VALIDATION // STRESS & FAULT INJECTION LABORATORY</span>
        </div>
        <h1 class="text-xl font-heading font-bold text-white tracking-tight mt-1">
          FAILURE INJECTION & MINIMUM-RISK MANOEUVRE (MRM) STACK
        </h1>
        <p class="text-xs text-[#AEB3B2] font-mono mt-1">
          Simulate severe operational faults and verify fail-operational fallback states, ISO 26262 ASIL-D supervisor clamps, and SOTIF edge-case mitigations.
        </p>
      </div>

      <div class="p-6 space-y-6 flex-1 bg-cad-grid">
        <!-- Interactive Fault Injection Switchboard -->
        <div class="bg-[#102A36]/60 border border-[#24282A] p-5 shadow-lg">
          <div class="flex items-center justify-between border-b border-[#1F4A5A] pb-3 mb-4 font-mono">
            <span class="text-sm font-bold text-white">HARDWARE & SENSOR FAULT INJECTION SWITCHBOARD</span>
            <button (click)="state.resetAllFaults()" 
                    class="px-3 py-1 bg-[#3E6250] hover:bg-[#3E6250]/80 text-white font-mono text-xs flex items-center space-x-1">
              <mat-icon class="text-xs">restore</mat-icon>
              <span>RESTORE NOMINAL ENVELOPE</span>
            </button>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 font-mono text-xs">
            <!-- Fault 1: GNSS Denial -->
            <div class="border p-4 bg-[#111415] transition" 
                 [ngClass]="state.faultGnssDenial() ? 'border-[#A8423B] bg-[#A8423B]/10' : 'border-[#24282A]'">
              <div class="flex justify-between items-center mb-2">
                <span class="font-bold text-white">01 // GNSS RTK SIGNAL LOSS</span>
                <span class="text-[10px] px-1.5 py-0.5" 
                      [ngClass]="state.faultGnssDenial() ? 'bg-[#A8423B] text-white font-bold' : 'bg-[#24282A] text-[#AEB3B2]'">
                  {{ state.faultGnssDenial() ? 'INJECTED' : 'ARMED' }}
                </span>
              </div>
              <p class="text-[#AEB3B2] text-[11px] mb-3">
                Simulates severe multipath attenuation or complete denial under high-bay steel structures.
              </p>
              <button (click)="state.injectFault('gnss')" 
                      [disabled]="state.faultGnssDenial()"
                      class="w-full py-1.5 border border-[#48758A] hover:bg-[#48758A]/30 text-white disabled:opacity-40">
                INJECT GNSS DROPOUT
              </button>
            </div>

            <!-- Fault 2: LiDAR Blackout -->
            <div class="border p-4 bg-[#111415] transition" 
                 [ngClass]="state.faultLidarBlackout() ? 'border-[#A8423B] bg-[#A8423B]/10' : 'border-[#24282A]'">
              <div class="flex justify-between items-center mb-2">
                <span class="font-bold text-white">02 // FRONT LiDAR BLACKOUT</span>
                <span class="text-[10px] px-1.5 py-0.5" 
                      [ngClass]="state.faultLidarBlackout() ? 'bg-[#A8423B] text-white font-bold' : 'bg-[#24282A] text-[#AEB3B2]'">
                  {{ state.faultLidarBlackout() ? 'INJECTED' : 'ARMED' }}
                </span>
              </div>
              <p class="text-[#AEB3B2] text-[11px] mb-3">
                Simulates heavy steam, foundry spray, or front optical sensor lens obstruction.
              </p>
              <button (click)="state.injectFault('lidar')" 
                      [disabled]="state.faultLidarBlackout()"
                      class="w-full py-1.5 border border-[#C48D35] hover:bg-[#C48D35]/30 text-[#C48D35] disabled:opacity-40">
                INJECT LiDAR BLACKOUT
              </button>
            </div>

            <!-- Fault 3: Sudden Forklift Cut-in -->
            <div class="border p-4 bg-[#111415] transition" 
                 [ngClass]="state.faultForkliftIntrusion() ? 'border-[#A8423B] bg-[#A8423B]/10' : 'border-[#24282A]'">
              <div class="flex justify-between items-center mb-2">
                <span class="font-bold text-white">03 // DYNAMIC FORKLIFT CUT-IN</span>
                <span class="text-[10px] px-1.5 py-0.5" 
                      [ngClass]="state.faultForkliftIntrusion() ? 'bg-[#A8423B] text-white font-bold' : 'bg-[#24282A] text-[#AEB3B2]'">
                  {{ state.faultForkliftIntrusion() ? 'INJECTED' : 'ARMED' }}
                </span>
              </div>
              <p class="text-[#AEB3B2] text-[11px] mb-3">
                Emergency proximity intrusion across tractor-trailer swept safety envelope (&lt;1.0m clearance).
              </p>
              <button (click)="state.injectFault('forklift')" 
                      [disabled]="state.faultForkliftIntrusion()"
                      class="w-full py-1.5 bg-[#A8423B] hover:bg-[#A8423B]/80 text-white disabled:opacity-40 font-bold">
                TRIGGER FORKLIFT CUT-IN
              </button>
            </div>

            <!-- Fault 4: EBS Brake Fade -->
            <div class="border p-4 bg-[#111415] transition" 
                 [ngClass]="state.faultBrakeDegradation() ? 'border-[#A8423B] bg-[#A8423B]/10' : 'border-[#24282A]'">
              <div class="flex justify-between items-center mb-2">
                <span class="font-bold text-white">04 // PNEUMATIC BRAKE FADE</span>
                <span class="text-[10px] px-1.5 py-0.5" 
                      [ngClass]="state.faultBrakeDegradation() ? 'bg-[#A8423B] text-white font-bold' : 'bg-[#24282A] text-[#AEB3B2]'">
                  {{ state.faultBrakeDegradation() ? 'INJECTED' : 'ARMED' }}
                </span>
              </div>
              <p class="text-[#AEB3B2] text-[11px] mb-3">
                Electronic Braking System (EBS) pressure loss. Triggers automatic speed clamp down to 8 km/h.
              </p>
              <button (click)="state.injectFault('brake')" 
                      [disabled]="state.faultBrakeDegradation()"
                      class="w-full py-1.5 border border-[#48758A] hover:bg-[#48758A]/30 text-white disabled:opacity-40">
                INJECT BRAKE FADE
              </button>
            </div>

            <!-- Fault 5: Camera Glare Occlusion -->
            <div class="border p-4 bg-[#111415] transition" 
                 [ngClass]="state.faultCameraOcclusion() ? 'border-[#A8423B] bg-[#A8423B]/10' : 'border-[#24282A]'">
              <div class="flex justify-between items-center mb-2">
                <span class="font-bold text-white">05 // LOW-SUN CAMERA GLARE</span>
                <span class="text-[10px] px-1.5 py-0.5" 
                      [ngClass]="state.faultCameraOcclusion() ? 'bg-[#A8423B] text-white font-bold' : 'bg-[#24282A] text-[#AEB3B2]'">
                  {{ state.faultCameraOcclusion() ? 'INJECTED' : 'ARMED' }}
                </span>
              </div>
              <p class="text-[#AEB3B2] text-[11px] mb-3">
                Blinds front optical perception. Fuses high-confidence radar and ultrasonic channels.
              </p>
              <button (click)="state.injectFault('camera')" 
                      [disabled]="state.faultCameraOcclusion()"
                      class="w-full py-1.5 border border-[#48758A] hover:bg-[#48758A]/30 text-white disabled:opacity-40">
                INJECT OPTICAL GLARE
              </button>
            </div>
          </div>
        </div>

        <!-- The Safety Supervisor Cascade Sequence (Section 26 Requirement) -->
        <div class="bg-[#102A36]/60 border border-[#24282A] p-5 shadow-lg font-mono">
          <div class="flex items-center space-x-2 border-b border-[#1F4A5A] pb-3 mb-4">
            <mat-icon class="text-sm text-[#3E6250]">shield</mat-icon>
            <span class="text-sm font-bold text-white">SAFETY SUPERVISOR ARBITRATION CASCADE</span>
          </div>

          <!-- 7-Stage Cascade Diagram -->
          <div class="grid grid-cols-1 md:grid-cols-7 gap-2 text-center text-xs">
            <div class="border border-[#24282A] p-3 bg-[#111415]">
              <div class="text-[10px] text-[#AEB3B2]">STEP 01</div>
              <div class="font-bold text-white mt-1">SENSOR INPUT</div>
              <div class="text-[10px] text-[#71797B] mt-1">Raw CAN/Ethernet</div>
            </div>

            <div class="border border-[#24282A] p-3 bg-[#111415]">
              <div class="text-[10px] text-[#AEB3B2]">STEP 02</div>
              <div class="font-bold text-white mt-1">CONFIDENCE DROP</div>
              <div class="text-[10px] text-[#C48D35] mt-1">Bayesian Weighting</div>
            </div>

            <div class="border border-[#24282A] p-3 bg-[#111415]">
              <div class="text-[10px] text-[#AEB3B2]">STEP 03</div>
              <div class="font-bold text-white mt-1">WORLD MODEL</div>
              <div class="text-[10px] text-[#71797B] mt-1">Covariance Update</div>
            </div>

            <div class="border border-[#24282A] p-3 bg-[#111415]">
              <div class="text-[10px] text-[#AEB3B2]">STEP 04</div>
              <div class="font-bold text-white mt-1">ODD CHECK</div>
              <div class="text-[10px] text-[#C48D35] mt-1">Boundary Verification</div>
            </div>

            <div class="border border-[#24282A] p-3 bg-[#111415]">
              <div class="text-[10px] text-[#AEB3B2]">STEP 05</div>
              <div class="font-bold text-white mt-1">PLANNER RE-EVAL</div>
              <div class="text-[10px] text-[#71797B] mt-1">Spline Lattice</div>
            </div>

            <div class="border border-[#1F4A5A] p-3 bg-[#1F4A5A]/30">
              <div class="text-[10px] text-[#3E6250] font-bold">STEP 06</div>
              <div class="font-bold text-white mt-1">SAFETY SUPERVISOR</div>
              <div class="text-[10px] text-[#3E6250] mt-1">ASIL-D Gatekeeper</div>
            </div>

            <div class="border p-3" 
                 [ngClass]="state.telemetry().safetyState === 'MRM_ACTIVE' ? 'border-[#A8423B] bg-[#A8423B]/20 text-red-200' : 'border-[#3E6250] bg-[#3E6250]/20 text-[#3E6250]'">
              <div class="text-[10px] font-bold">STEP 07</div>
              <div class="font-bold mt-1">
                {{ state.telemetry().safetyState === 'MRM_ACTIVE' ? 'MRM SAFE HALT' : 'NOMINAL EXEC' }}
              </div>
              <div class="text-[10px] mt-1">Controlled Clamp</div>
            </div>
          </div>
        </div>

        <!-- Live Autonomous Safety Event Trace -->
        <div class="bg-[#102A36]/60 border border-[#24282A] p-5 shadow-lg font-mono">
          <div class="flex items-center justify-between border-b border-[#1F4A5A] pb-3 mb-4">
            <span class="text-sm font-bold text-white">LIVE IMMUTABLE AUTONOMY EVENT RECORDER</span>
            <span class="text-xs text-[#AEB3B2]">SHA-256 HASH CHAIN VERIFIED</span>
          </div>

          <div class="space-y-2 text-xs max-h-56 overflow-y-auto">
            @for (evt of state.events(); track evt.id) {
              <div class="flex items-start space-x-3 p-2 bg-[#111415] border border-[#24282A]/80">
                <span class="text-[#AEB3B2] text-[10px] pt-0.5">{{ evt.timestamp }}</span>
                <span class="px-1.5 py-0.5 text-[10px] font-bold"
                      [ngClass]="evt.severity === 'CRIT' ? 'bg-[#A8423B] text-white' : evt.severity === 'WARN' ? 'bg-[#C48D35] text-black' : evt.severity === 'RESOLVED' ? 'bg-[#3E6250] text-white' : 'bg-[#1F4A5A] text-white'">
                  {{ evt.severity }}
                </span>
                <span class="text-gray-300 flex-1">{{ evt.message }}</span>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `
})
export class FailureLabComponent {
  state = inject(FreightStateService);
}
