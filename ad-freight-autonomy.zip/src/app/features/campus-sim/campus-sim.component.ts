import { 
  ChangeDetectionStrategy, 
  Component, 
  ElementRef, 
  OnInit, 
  OnDestroy, 
  ViewChild, 
  inject, 
  computed 
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FreightStateService } from '../../core/services/freight-state.service';

@Component({
  selector: 'app-campus-sim',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex flex-col h-full bg-[#111415] text-[#F1F0EA]">
      <!-- Sub-header & Real-time Metrics HUD -->
      <div class="flex flex-wrap items-center justify-between border-b border-[#24282A] px-5 py-3 bg-[#102A36]/60 backdrop-blur-sm">
        <div class="flex items-center space-x-4">
          <div class="flex items-center space-x-2">
            <span class="inline-block w-2.5 h-2.5 rounded-full" 
                  [ngClass]="state.telemetry().safetyState === 'NOMINAL' ? 'bg-[#3E6250] animate-pulse' : state.telemetry().safetyState === 'MRM_ACTIVE' ? 'bg-[#A8423B] animate-ping' : 'bg-[#C48D35]'"></span>
            <span class="text-xs font-mono font-bold tracking-wider uppercase text-[#AEB3B2]">
              WORLD MODEL // {{ state.activeDomain() }}
            </span>
          </div>
          <span class="text-[#71797B] text-xs">|</span>
          <div class="text-xs font-mono">
            VEHICLE: <span class="text-white font-bold">{{ state.selectedVehicleId() }}</span> (44t ARTICULATED)
          </div>
          <span class="text-[#71797B] text-xs">|</span>
          <div class="text-xs font-mono">
            ODD: <span class="text-[#C48D35] font-semibold">{{ state.autonomyMode() }}</span>
          </div>
        </div>

        <!-- Telemetry Pill Badges (Technical Grid) -->
        <div class="flex items-center space-x-5 font-mono text-xs">
          <div class="flex flex-col items-end">
            <span class="text-[10px] text-[#AEB3B2] uppercase">Speed</span>
            <span class="font-bold text-white text-sm">{{ state.telemetry().speedKph.toFixed(1) }} <span class="text-[10px] text-[#71797B]">km/h</span></span>
          </div>
          <div class="flex flex-col items-end">
            <span class="text-[10px] text-[#AEB3B2] uppercase">Hitch Angle &beta;</span>
            <span class="font-bold text-[#F1F0EA]">{{ state.telemetry().hitchAngleDeg.toFixed(1) }}&deg;</span>
          </div>
          <div class="flex flex-col items-end">
            <span class="text-[10px] text-[#AEB3B2] uppercase">Swept Width</span>
            <span class="font-bold text-[#C48D35]">{{ state.telemetry().sweptWidthM.toFixed(2) }} m</span>
          </div>
          <div class="flex flex-col items-end">
            <span class="text-[10px] text-[#AEB3B2] uppercase">Clearance</span>
            <span class="font-bold" [ngClass]="state.telemetry().minClearanceM < 1.2 ? 'text-[#A8423B]' : 'text-[#3E6250]'">
              {{ state.telemetry().minClearanceM.toFixed(2) }} m
            </span>
          </div>
          <div class="flex flex-col items-end">
            <span class="text-[10px] text-[#AEB3B2] uppercase">Localisation</span>
            <span class="font-bold text-[#48758A]">{{ state.localisationMode() }} ({{ (state.telemetry().localisationConfidence * 100).toFixed(0) }}%)</span>
          </div>
        </div>
      </div>

      <!-- Main Canvas Container -->
      <div class="relative flex-1 w-full bg-[#111415] overflow-hidden bg-cad-grid">
        <canvas #simCanvas class="w-full h-full block cursor-crosshair"></canvas>

        <!-- Technical Drawing Annotations Overlay -->
        <div class="absolute top-4 left-4 pointer-events-none bg-[#102A36]/80 border border-[#1F4A5A] p-3 text-[11px] font-mono space-y-1 shadow-lg backdrop-blur-sm max-w-xs">
          <div class="text-[#AEB3B2] font-bold border-b border-[#1F4A5A] pb-1 flex justify-between">
            <span>ALEXANDER DENNIS DIGITAL TWIN</span>
            <span class="text-[#C48D35]">CAD KINEMATICS</span>
          </div>
          <div class="flex justify-between text-gray-300">
            <span>Tractor Wheelbase:</span>
            <span class="text-white font-bold">3.80 m</span>
          </div>
          <div class="flex justify-between text-gray-300">
            <span>Trailer Kingpin-Axle:</span>
            <span class="text-white font-bold">7.80 m</span>
          </div>
          <div class="flex justify-between text-gray-300">
            <span>Front Overhang Swing:</span>
            <span class="text-[#C48D35] font-bold">+0.48 m</span>
          </div>
          <div class="flex justify-between text-gray-300">
            <span>Trailer Off-Tracking:</span>
            <span class="text-[#C48D35] font-bold">-0.82 m</span>
          </div>
          <div class="flex justify-between text-gray-300">
            <span>Active Trajectory:</span>
            <span class="text-[#3E6250] font-bold">5th-Order Polynomial</span>
          </div>
        </div>

        <!-- Failure Status Banner if faults active -->
        @if (hasActiveFaults()) {
          <div class="absolute top-4 right-4 bg-[#A8423B]/90 border border-red-500 text-white p-3 font-mono text-xs max-w-sm shadow-xl backdrop-blur-sm animate-pulse">
            <div class="font-bold flex items-center space-x-2">
              <mat-icon class="text-sm">warning</mat-icon>
              <span>ODD DEGRADATION ACTIVE</span>
            </div>
            <p class="text-[11px] mt-1 leading-snug text-red-100">
              Safety Supervisor has modified speed ceiling and trajectory envelope due to injected sensor/proximity faults.
            </p>
          </div>
        }

        <!-- Interactive Simulation Controller Bar (Bottom) -->
        <div class="absolute bottom-4 left-1/2 -translate-x-1/2 bg-[#102A36]/90 border border-[#1F4A5A] px-4 py-2 flex items-center space-x-4 shadow-2xl backdrop-blur-md">
          <!-- Play / Pause -->
          <button (click)="state.toggleSimulation()" 
                  class="flex items-center space-x-1 bg-[#1F4A5A] hover:bg-[#48758A] text-white px-3 py-1.5 font-mono text-xs transition">
            <mat-icon class="text-sm">{{ state.isSimPlaying() ? 'pause' : 'play_arrow' }}</mat-icon>
            <span>{{ state.isSimPlaying() ? 'HALT' : 'ENGAGE' }}</span>
          </button>

          <!-- Speed Multipliers -->
          <div class="flex items-center space-x-1 bg-[#111415] border border-[#24282A] p-0.5 font-mono text-xs">
            <button (click)="state.setSpeed(0.25)" [class.bg-[#1F4A5A]]="state.simSpeed() === 0.25" class="px-2 py-1 text-gray-300 hover:text-white">0.25&times;</button>
            <button (click)="state.setSpeed(1.0)" [class.bg-[#1F4A5A]]="state.simSpeed() === 1.0" class="px-2 py-1 text-gray-300 hover:text-white">1.0&times;</button>
            <button (click)="state.setSpeed(4.0)" [class.bg-[#1F4A5A]]="state.simSpeed() === 4.0" class="px-2 py-1 text-gray-300 hover:text-white">4.0&times;</button>
          </div>

          <div class="h-4 w-px bg-[#24282A]"></div>

          <!-- Quick Fault Toggle Buttons -->
          <button (click)="state.injectFault('forklift')" 
                  class="flex items-center space-x-1 border border-[#C48D35]/60 hover:bg-[#C48D35]/20 text-[#C48D35] px-2.5 py-1 font-mono text-xs">
            <mat-icon class="text-xs">forklift</mat-icon>
            <span>CUT-IN FORKLIFT</span>
          </button>

          <button (click)="state.injectFault('gnss')" 
                  class="flex items-center space-x-1 border border-[#48758A]/60 hover:bg-[#48758A]/20 text-[#AEB3B2] px-2.5 py-1 font-mono text-xs">
            <mat-icon class="text-xs">satellite_alt</mat-icon>
            <span>DROP GNSS</span>
          </button>

          <button (click)="resetVehicleSimulation()" 
                  class="flex items-center space-x-1 bg-[#24282A] hover:bg-[#71797B] text-white px-2.5 py-1 font-mono text-xs">
            <mat-icon class="text-xs">refresh</mat-icon>
            <span>RESET PATH</span>
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      height: 100%;
    }
  `]
})
export class CampusSimComponent implements OnInit, OnDestroy {
  @ViewChild('simCanvas', { static: true }) canvasRef!: ElementRef<HTMLCanvasElement>;
  
  state = inject(FreightStateService);

  private animationFrameId: number | null = null;
  private ctx!: CanvasRenderingContext2D;

  // Kinematic Simulation State
  private truckX = 220;
  private truckY = 460;
  private truckHeading = -Math.PI / 2; // Pointing upwards
  private hitchAngle = 0.05;
  private steerAngle = 0.0;
  private speed = 2.4; // internal scale
  private lidarSweepAngle = 0;
  private simStep = 0;

  // Forklift Obstacle State
  private forkliftX = 540;
  private forkliftY = 320;
  private forkliftSpeed = 0.8;
  private forkliftDir = -1;

  // Waypoints for AD Manufacturing Campus / Steel Yard
  private waypoints = [
    { x: 220, y: 460 },
    { x: 220, y: 280 },
    { x: 280, y: 220 },
    { x: 440, y: 220 },
    { x: 580, y: 220 },
    { x: 680, y: 280 },
    { x: 680, y: 420 }, // Dock Bay 4
  ];
  private currentWaypointIdx = 1;

  hasActiveFaults = computed(() => {
    return this.state.faultGnssDenial() || 
           this.state.faultLidarBlackout() || 
           this.state.faultForkliftIntrusion() || 
           this.state.faultBrakeDegradation() || 
           this.state.faultCameraOcclusion();
  });

  ngOnInit() {
    const canvas = this.canvasRef.nativeElement;
    this.ctx = canvas.getContext('2d')!;
    this.resizeCanvas();
    window.addEventListener('resize', this.onResize);
    this.startSimulationLoop();
  }

  ngOnDestroy() {
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
    }
    window.removeEventListener('resize', this.onResize);
  }

  private onResize = () => {
    this.resizeCanvas();
  };

  private resizeCanvas() {
    const canvas = this.canvasRef.nativeElement;
    canvas.width = canvas.parentElement?.clientWidth || 1200;
    canvas.height = canvas.parentElement?.clientHeight || 800;
  }

  private startSimulationLoop() {
    const loop = () => {
      this.updatePhysics();
      this.render();
      this.animationFrameId = requestAnimationFrame(loop);
    };
    this.animationFrameId = requestAnimationFrame(loop);
  }

  resetVehicleSimulation() {
    this.truckX = 220;
    this.truckY = 460;
    this.truckHeading = -Math.PI / 2;
    this.hitchAngle = 0.05;
    this.steerAngle = 0.0;
    this.currentWaypointIdx = 1;
    this.forkliftX = 540;
    this.state.resetAllFaults();
  }

  private updatePhysics() {
    if (!this.state.isSimPlaying()) return;

    const dt = 0.016 * this.state.simSpeed();
    this.simStep++;
    this.lidarSweepAngle = (this.lidarSweepAngle + 0.08) % (Math.PI * 2);

    // Dynamic Forklift motion along cross aisle
    if (this.state.faultForkliftIntrusion()) {
      // Injected cut-in directly into truck path
      this.forkliftX = 340;
      this.forkliftY = 220;
    } else {
      this.forkliftX += this.forkliftSpeed * this.forkliftDir;
      if (this.forkliftX < 360) this.forkliftDir = 1;
      if (this.forkliftX > 560) this.forkliftDir = -1;
    }

    // Target waypoint navigation
    const target = this.waypoints[this.currentWaypointIdx];
    const dx = target.x - this.truckX;
    const dy = target.y - this.truckY;
    const distToTarget = Math.hypot(dx, dy);

    if (distToTarget < 25) {
      this.currentWaypointIdx = (this.currentWaypointIdx + 1) % this.waypoints.length;
    }

    const targetHeading = Math.atan2(dy, dx);
    let headingDiff = targetHeading - this.truckHeading;
    while (headingDiff > Math.PI) headingDiff -= Math.PI * 2;
    while (headingDiff < -Math.PI) headingDiff += Math.PI * 2;

    // Ackermann steering calculation
    this.steerAngle = Math.max(-0.6, Math.min(0.6, headingDiff * 0.8));

    // Distance to forklift
    const distToForklift = Math.hypot(this.forkliftX - this.truckX, this.forkliftY - this.truckY);
    
    // Safety deceleration / emergency braking
    let currentSpeed = this.speed;
    if (this.state.faultForkliftIntrusion() || distToForklift < 50) {
      currentSpeed = 0; // Emergency Safe Halt (MRM)
      this.state.telemetry.update(t => ({
        ...t,
        speedKph: 0,
        minClearanceM: 0.95,
        safetyState: 'MRM_ACTIVE',
        autonomyMode: 'MRM_SAFE_HALT',
      }));
    } else if (this.state.faultLidarBlackout()) {
      currentSpeed = 0.8;
      this.state.telemetry.update(t => ({
        ...t,
        speedKph: 5.5,
        minClearanceM: 1.45,
        safetyState: 'DEGRADED',
      }));
    } else {
      currentSpeed = this.state.activeDomain() === 'ROAD_FREIGHT' ? 4.2 : 2.4;
      this.state.telemetry.update(t => ({
        ...t,
        speedKph: this.state.activeDomain() === 'ROAD_FREIGHT' ? 76.5 : 12.2,
        steeringAngleDeg: Number((this.steerAngle * 180 / Math.PI).toFixed(1)),
        hitchAngleDeg: Number((this.hitchAngle * 180 / Math.PI).toFixed(1)),
        minClearanceM: Math.max(1.1, Number((distToForklift / 25).toFixed(2))),
        safetyState: this.state.faultGnssDenial() ? 'DEGRADED' : 'NOMINAL',
      }));
    }

    // Kinematic motion of tractor + trailer hitch derivative
    const v = currentSpeed;
    const L1 = 38; // tractor wheelbase in canvas pixels
    const L2 = 78; // trailer length in canvas pixels
    
    // Hitch angle differential equation
    const dHitch = (v / L1) * Math.tan(this.steerAngle) - (v / L2) * Math.sin(this.hitchAngle);
    this.hitchAngle += dHitch * dt * 8;
    this.hitchAngle = Math.max(-0.8, Math.min(0.8, this.hitchAngle));

    // Tractor yaw rate
    const dHeading = (v / L1) * Math.tan(this.steerAngle);
    this.truckHeading += dHeading * dt * 8;

    this.truckX += Math.cos(this.truckHeading) * v * dt * 8;
    this.truckY += Math.sin(this.truckHeading) * v * dt * 8;
  }

  private render() {
    const ctx = this.ctx;
    const width = this.canvasRef.nativeElement.width;
    const height = this.canvasRef.nativeElement.height;

    ctx.clearRect(0, 0, width, height);

    // 1. Draw Industrial Campus Environment or Road Network
    if (this.state.activeDomain() === 'INDUSTRIAL_AUTONOMY') {
      this.drawCampusLayout(ctx);
    } else {
      this.drawMotorwayLayout(ctx, width);
    }

    // 2. Draw Dynamic Obstacles (Forklift, Worker, Pallets)
    this.drawObstacles(ctx);

    // 3. Draw Projected Trajectory & Swept-Path Polygons
    this.drawSweptPathEnvelopes(ctx);

    // 4. Draw Sensor Sweep Rays (LiDAR Point Cloud simulation)
    this.drawSensorFields(ctx);

    // 5. Draw 44t Articulated Vehicle (Tractor + 5th Wheel + Semi-Trailer)
    this.drawArticulatedVehicle(ctx);
  }

  private drawCampusLayout(ctx: CanvasRenderingContext2D) {
    // Factory buildings layout
    ctx.strokeStyle = '#24282A';
    ctx.lineWidth = 1.5;

    // Building: ASSEMBLY HALL 1
    ctx.fillStyle = '#102A36';
    ctx.fillRect(40, 40, 220, 160);
    ctx.strokeRect(40, 40, 220, 160);
    ctx.fillStyle = '#AEB3B2';
    ctx.font = '10px "Chivo Mono", monospace';
    ctx.fillText('FACILITY 01 // BODY & ASSEMBLY HALL', 50, 65);
    ctx.fillStyle = '#71797B';
    ctx.fillText('FLOOR AREA: 18,500 m²', 50, 85);
    ctx.fillText('AUTOMATED OVERHEAD CRANE: ACTIVE', 50, 105);

    // Building: BATTERY STORAGE & HIGH-BAY STAGING
    ctx.fillStyle = '#102A36';
    ctx.fillRect(300, 40, 240, 140);
    ctx.strokeRect(300, 40, 240, 140);
    ctx.fillStyle = '#C48D35';
    ctx.fillText('FACILITY 02 // 720kWh BATTERY BUFFER', 315, 65);
    ctx.fillStyle = '#71797B';
    ctx.fillText('HAZARD ZONE: CLASS 9 EV PACKS', 315, 85);

    // Building: LOADING DOCKS BAY 1-6
    ctx.fillStyle = '#102A36';
    ctx.fillRect(600, 320, 240, 260);
    ctx.strokeRect(600, 320, 240, 260);
    ctx.fillStyle = '#AEB3B2';
    ctx.fillText('DEPOT // PRECISION LOADING DOCKS', 615, 345);

    // Draw individual dock bays
    for (let i = 0; i < 4; i++) {
      const bayY = 380 + i * 50;
      ctx.fillStyle = i === 2 ? 'rgba(62, 98, 80, 0.25)' : 'rgba(31, 74, 90, 0.15)';
      ctx.fillRect(600, bayY, 60, 40);
      ctx.strokeRect(600, bayY, 60, 40);
      ctx.fillStyle = i === 2 ? '#3E6250' : '#71797B';
      ctx.fillText(`BAY 0${i + 1} ${i === 2 ? '[ASSIGNED]' : '[READY]'}`, 610, bayY + 24);
    }

    // High Power Charging Plaza (MCS)
    ctx.fillStyle = '#102A36';
    ctx.fillRect(40, 460, 140, 140);
    ctx.strokeRect(40, 460, 140, 140);
    ctx.fillStyle = '#48758A';
    ctx.fillText('MCS CHARGING PLAZA', 50, 485);
    ctx.fillStyle = '#71797B';
    ctx.fillText('350kW DUAL DISPENSER', 50, 505);

    // Road Lanes / Yard Transit Aisles (Dashed technical markings)
    ctx.strokeStyle = '#1F4A5A';
    ctx.setLineDash([8, 8]);
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(220, 480);
    ctx.lineTo(220, 220);
    ctx.lineTo(680, 220);
    ctx.lineTo(680, 380);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  private drawMotorwayLayout(ctx: CanvasRenderingContext2D, w: number) {
    // 3-lane UK Motorway Section (M9 Corridor)
    ctx.fillStyle = '#15191B';
    ctx.fillRect(60, 120, w - 120, 340);
    ctx.strokeStyle = '#24282A';
    ctx.lineWidth = 2;
    ctx.strokeRect(60, 120, w - 120, 340);

    // Hard shoulder, Lane 1, Lane 2, Lane 3
    const laneH = 85;
    for (let i = 1; i <= 3; i++) {
      ctx.strokeStyle = '#71797B';
      ctx.setLineDash([12, 16]);
      ctx.beginPath();
      ctx.moveTo(60, 120 + i * laneH);
      ctx.lineTo(w - 60, 120 + i * laneH);
      ctx.stroke();
    }
    ctx.setLineDash([]);

    ctx.fillStyle = '#AEB3B2';
    ctx.font = '11px "Chivo Mono", monospace';
    ctx.fillText('M9 MOTORWAY // EDINBURGH - STIRLING CORRIDOR // LANE 1 SPEED LIMIT: 55 MPH (88 KM/H)', 80, 150);
  }

  private drawObstacles(ctx: CanvasRenderingContext2D) {
    // 1. Electric Forklift (TRK-4081)
    ctx.save();
    ctx.translate(this.forkliftX, this.forkliftY);
    ctx.fillStyle = '#C48D35';
    ctx.strokeStyle = '#F1F0EA';
    ctx.lineWidth = 1.2;
    ctx.fillRect(-12, -8, 24, 16);
    ctx.strokeRect(-12, -8, 24, 16);
    // Forks
    ctx.fillStyle = '#AEB3B2';
    ctx.fillRect(12, -6, 10, 3);
    ctx.fillRect(12, 3, 10, 3);
    ctx.restore();

    // Forklift Track Bounding Box & Metadata
    ctx.strokeStyle = 'rgba(196, 141, 53, 0.7)';
    ctx.strokeRect(this.forkliftX - 22, this.forkliftY - 20, 48, 40);
    ctx.fillStyle = '#C48D35';
    ctx.font = '9px "Chivo Mono", monospace';
    ctx.fillText('TRK-4081 [FORKLIFT 8km/h]', this.forkliftX - 35, this.forkliftY - 24);

    // 2. Pedestrian Worker (TRK-4082)
    const workerX = 390;
    const workerY = 360;
    ctx.fillStyle = '#48758A';
    ctx.beginPath();
    ctx.arc(workerX, workerY, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = 'rgba(72, 117, 138, 0.6)';
    ctx.strokeRect(workerX - 12, workerY - 12, 24, 24);
    ctx.fillText('TRK-4082 [WORKER]', workerX - 20, workerY - 16);
  }

  private drawSweptPathEnvelopes(ctx: CanvasRenderingContext2D) {
    // Swept path envelope lines representing front swing & trailer off-tracking
    ctx.save();
    ctx.strokeStyle = 'rgba(196, 141, 53, 0.35)'; // Signal Amber
    ctx.lineWidth = 1.5;
    ctx.setLineDash([4, 4]);

    const halfW = 16;
    const trailerOffset = this.hitchAngle * 25;

    // Outer swept envelope
    ctx.beginPath();
    ctx.moveTo(this.truckX - halfW, this.truckY);
    ctx.lineTo(this.truckX - halfW - 12, this.truckY - 60);
    ctx.lineTo(this.truckX + halfW + 12, this.truckY - 60);
    ctx.lineTo(this.truckX + halfW, this.truckY);
    ctx.stroke();

    // Trailer cut-in envelope
    ctx.strokeStyle = 'rgba(31, 74, 90, 0.5)';
    ctx.beginPath();
    ctx.moveTo(this.truckX - halfW, this.truckY);
    ctx.lineTo(this.truckX - halfW - trailerOffset, this.truckY + 80);
    ctx.lineTo(this.truckX + halfW - trailerOffset, this.truckY + 80);
    ctx.lineTo(this.truckX + halfW, this.truckY);
    ctx.stroke();

    ctx.setLineDash([]);
    ctx.restore();
  }

  private drawSensorFields(ctx: CanvasRenderingContext2D) {
    if (this.state.faultLidarBlackout()) return;

    ctx.save();
    ctx.translate(this.truckX, this.truckY);

    // 360 LiDAR Sweep Cones
    const sweepRange = 140;
    const gradient = ctx.createRadialGradient(0, 0, 10, 0, 0, sweepRange);
    gradient.addColorStop(0, 'rgba(31, 74, 90, 0.3)');
    gradient.addColorStop(0.8, 'rgba(31, 74, 90, 0.05)');
    gradient.addColorStop(1, 'transparent');

    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.arc(0, 0, sweepRange, 0, Math.PI * 2);
    ctx.fill();

    // Sweeping ray
    ctx.strokeStyle = 'rgba(72, 117, 138, 0.7)';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(Math.cos(this.lidarSweepAngle) * sweepRange, Math.sin(this.lidarSweepAngle) * sweepRange);
    ctx.stroke();

    // Ultrasonic Near-Field Arcs at Rear of Trailer
    ctx.strokeStyle = 'rgba(62, 98, 80, 0.6)';
    ctx.beginPath();
    ctx.arc(0, 75, 25, Math.PI * 0.25, Math.PI * 0.75);
    ctx.stroke();

    ctx.restore();
  }

  private drawArticulatedVehicle(ctx: CanvasRenderingContext2D) {
    ctx.save();
    ctx.translate(this.truckX, this.truckY);
    ctx.rotate(this.truckHeading + Math.PI / 2);

    // 1. Semi-Trailer (13.6m box, attached at 5th wheel pin)
    ctx.save();
    // 5th wheel pin pivot offset (behind tractor cab)
    ctx.translate(0, 22);
    ctx.rotate(-this.hitchAngle);

    // Trailer Box
    ctx.fillStyle = '#24282A'; // AD Graphite
    ctx.strokeStyle = '#AEB3B2'; // Aluminium trim
    ctx.lineWidth = 1.5;
    ctx.fillRect(-15, 0, 30, 85);
    ctx.strokeRect(-15, 0, 30, 85);

    // Cargo marking on roof
    ctx.fillStyle = '#71797B';
    ctx.font = '7px "Chivo Mono", monospace';
    ctx.save();
    ctx.rotate(-Math.PI / 2);
    ctx.fillText('AD FREIGHT // 31.8t', -75, 4);
    ctx.restore();

    // Trailer triple rear axles
    ctx.fillStyle = '#111415';
    for (let i = 0; i < 3; i++) {
      const axleY = 62 + i * 7;
      ctx.fillRect(-18, axleY, 5, 5);
      ctx.fillRect(13, axleY, 5, 5);
    }
    ctx.restore(); // Return to tractor frame

    // 2. 5th Wheel Coupler Ring
    ctx.fillStyle = '#71797B';
    ctx.beginPath();
    ctx.arc(0, 22, 4, 0, Math.PI * 2);
    ctx.fill();

    // 3. Tractor Chassis & Cab (AD F800E)
    ctx.fillStyle = '#102A36'; // AD Deep Navy
    ctx.strokeStyle = '#1F4A5A'; // AD Engineering Blue
    ctx.lineWidth = 1.8;

    // Tractor Cab Body
    ctx.fillRect(-14, -26, 28, 46);
    ctx.strokeRect(-14, -26, 28, 46);

    // Windscreen / Roof Autonomy Sensor Pod
    ctx.fillStyle = '#1F4A5A';
    ctx.fillRect(-11, -22, 22, 10);

    // Roof LiDAR Pod (Central Dome)
    ctx.fillStyle = '#C48D35';
    ctx.beginPath();
    ctx.arc(0, -18, 3, 0, Math.PI * 2);
    ctx.fill();

    // Steerable Front Wheels
    ctx.save();
    ctx.translate(0, -16);
    ctx.rotate(this.steerAngle);
    ctx.fillStyle = '#111415';
    ctx.fillRect(-18, -4, 5, 10);
    ctx.fillRect(13, -4, 5, 10);
    ctx.restore();

    // Tractor Rear Drive Axles
    ctx.fillStyle = '#111415';
    ctx.fillRect(-18, 14, 5, 9);
    ctx.fillRect(13, 14, 5, 9);

    ctx.restore();
  }
}
