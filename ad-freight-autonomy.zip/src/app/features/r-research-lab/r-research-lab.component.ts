import { ChangeDetectionStrategy, Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FreightStateService } from '../../core/services/freight-state.service';

export interface StoppingResultData {
  metrics?: {
    reactionDistanceM: number;
    brakingDistanceM: number;
    meanStoppingM: number;
    p95StoppingM: number;
    p99StoppingM: number;
    kineticEnergyMJ: number;
  };
  distribution?: {
    distanceM: number;
    frequency: number;
  }[];
}

@Component({
  selector: 'app-r-research-lab',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#111415] text-[#F1F0EA] overflow-y-auto">
      <!-- Header -->
      <div class="border-b border-[#24282A] px-6 py-4 bg-[#102A36] flex flex-wrap items-center justify-between">
        <div>
          <div class="flex items-center space-x-2 text-xs font-mono text-[#C48D35] uppercase">
            <mat-icon class="text-sm">functions</mat-icon>
            <span>AD AUTONOMY RESEARCH // R QUANTITATIVE ENGINE</span>
          </div>
          <h1 class="text-xl font-heading font-bold text-white tracking-tight mt-1">
            STATISTICAL MODELING, TRAJECTORY ANALYSIS & RISK DISTRIBUTIONS
          </h1>
          <p class="text-xs text-[#AEB3B2] font-mono mt-1">
            Grounded in the R computational kernel: stopping-distance probability, Monte Carlo hazard TTC, energy consumption & depot queueing theory.
          </p>
        </div>

        <!-- Model Switcher Tabs -->
        <div class="flex items-center space-x-2 font-mono text-xs mt-3 sm:mt-0">
          <button (click)="activeModel.set('stopping')" 
                  [class.bg-[#1F4A5A]]="activeModel() === 'stopping'" 
                  class="border border-[#1F4A5A] px-2.5 py-1 text-gray-300 hover:text-white">
            R: STOPPING DISTRIBUTIONS
          </button>
          <button (click)="activeModel.set('risk')" 
                  [class.bg-[#1F4A5A]]="activeModel() === 'risk'" 
                  class="border border-[#1F4A5A] px-2.5 py-1 text-gray-300 hover:text-white">
            R: MONTE CARLO TTC
          </button>
          <button (click)="activeModel.set('energy')" 
                  [class.bg-[#1F4A5A]]="activeModel() === 'energy'" 
                  class="border border-[#1F4A5A] px-2.5 py-1 text-gray-300 hover:text-white">
            R: ENERGY PREDICTION
          </button>
          <button (click)="activeModel.set('depot')" 
                  [class.bg-[#1F4A5A]]="activeModel() === 'depot'" 
                  class="border border-[#1F4A5A] px-2.5 py-1 text-gray-300 hover:text-white">
            R: DEPOT QUEUEING
          </button>
        </div>
      </div>

      <div class="p-6 space-y-6 flex-1 bg-cad-grid">
        
        <!-- MODEL 1: STOPPING DISTANCE DISTRIBUTION -->
        @if (activeModel() === 'stopping') {
          <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <!-- Controls (Left) -->
            <div class="lg:col-span-4 bg-[#102A36]/60 border border-[#24282A] p-5 shadow-lg font-mono text-xs space-y-4">
              <div class="border-b border-[#1F4A5A] pb-2 font-bold text-white flex justify-between">
                <span>R SCRIPT: r/stopping_distance_distribution.R</span>
                <span class="text-[#3E6250]">COMPILED</span>
              </div>

              <div>
                <label for="massRange" class="block text-[#AEB3B2] mb-1">VEHICLE GROSS MASS: {{ massTonnes() }} TONNES</label>
                <input id="massRange" type="range" min="12" max="44" step="1" 
                       [value]="massTonnes()" 
                       (input)="updateMass($event)" 
                       class="w-full accent-[#C48D35] bg-[#111415]">
                <div class="flex justify-between text-[10px] text-[#71797B] mt-1">
                  <span>12t (Unladen)</span>
                  <span>31.8t (Active)</span>
                  <span>44t (UK Max)</span>
                </div>
              </div>

              <div>
                <label for="speedRange" class="block text-[#AEB3B2] mb-1">INITIAL SPEED: {{ speedKph() }} KM/H</label>
                <input id="speedRange" type="range" min="10" max="88" step="2" 
                       [value]="speedKph()" 
                       (input)="updateSpeed($event)" 
                       class="w-full accent-[#C48D35] bg-[#111415]">
                <div class="flex justify-between text-[10px] text-[#71797B] mt-1">
                  <span>10 km/h (Yard)</span>
                  <span>50 km/h (Urban)</span>
                  <span>88 km/h (Motorway)</span>
                </div>
              </div>

              <div>
                <label for="surfaceSelect" class="block text-[#AEB3B2] mb-1">ROAD SURFACE COEFFICIENT (&mu;)</label>
                <select id="surfaceSelect" (change)="updateSurface($event)" class="w-full bg-[#111415] border border-[#24282A] p-2 text-white">
                  <option value="asphalt_dry">Asphalt Dry (Nominal &mu; ~ 0.82)</option>
                  <option value="asphalt_wet">Asphalt Wet (Rain &mu; ~ 0.58)</option>
                  <option value="factory_concrete">Factory Polished Concrete (&mu; ~ 0.72)</option>
                  <option value="steelworks_gravel">Steel Works Crushed Aggregate (&mu; ~ 0.45)</option>
                </select>
              </div>

              <div class="pt-3 border-t border-[#24282A] text-[#AEB3B2] space-y-1">
                <div>Autonomous Reaction Delay: <span class="text-white font-bold">120 ms (AD Drive Core)</span></div>
                <div>Human Driver Reaction Delay: <span class="text-[#A8423B]">1,200 ms (Reference)</span></div>
                <div>Brake Thermal Fade Factor: <span class="text-white">{{ (1 - (massTonnes() / 100) * 0.15).toFixed(3) }}</span></div>
              </div>

              <button (click)="runStoppingCalculation()" 
                      class="w-full py-2 bg-[#1F4A5A] hover:bg-[#48758A] text-white font-bold transition">
                EXECUTE R MODEL (1,000 MONTE CARLO SAMPLES)
              </button>
            </div>

            <!-- Visualization Plot (Right) -->
            <div class="lg:col-span-8 bg-[#102A36]/60 border border-[#24282A] p-5 shadow-lg flex flex-col justify-between font-mono">
              <div>
                <div class="flex justify-between items-center border-b border-[#1F4A5A] pb-2 mb-4 text-xs">
                  <span class="font-bold text-white">PROBABILITY DENSITY: TOTAL STOPPING DISTANCE (METRES)</span>
                  <span class="text-[#C48D35]">ISO 26262 SOTIF ASIL-D VALIDATION</span>
                </div>

                <!-- SVG Histogram / Distribution Curve -->
                <div class="h-64 w-full flex items-end justify-between px-2 pt-6 pb-2 border-b border-l border-[#24282A] relative bg-[#111415]/60">
                  @for (bar of stoppingResult()?.distribution; track $index) {
                    <div class="flex-1 flex flex-col items-center mx-0.5 group relative">
                      <div class="w-full bg-[#1F4A5A] hover:bg-[#C48D35] transition" 
                           [style.height.px]="bar.frequency * 1.5"></div>
                      <span class="text-[9px] text-[#AEB3B2] mt-1">{{ bar.distanceM.toFixed(0) }}</span>
                      <!-- Tooltip -->
                      <div class="absolute bottom-full mb-2 hidden group-hover:block bg-[#111415] border border-[#24282A] p-1 text-[9px] text-white z-10 whitespace-nowrap">
                        Dist: {{ bar.distanceM }}m (Freq: {{ bar.frequency }})
                      </div>
                    </div>
                  }
                  <!-- Overlay markers -->
                  <div class="absolute top-4 right-4 bg-[#102A36] border border-[#1F4A5A] p-2 text-xs">
                    <div class="text-[#3E6250]">Mean Stopping: <span class="font-bold">{{ stoppingResult()?.metrics?.meanStoppingM }} m</span></div>
                    <div class="text-[#C48D35]">95th Percentile: <span class="font-bold">{{ stoppingResult()?.metrics?.p95StoppingM }} m</span></div>
                    <div class="text-[#A8423B]">99th Percentile: <span class="font-bold">{{ stoppingResult()?.metrics?.p99StoppingM }} m</span></div>
                  </div>
                </div>
              </div>

              <!-- Output Metrics Grid -->
              <div class="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 text-xs border-t border-[#24282A]">
                <div>
                  <span class="text-[#AEB3B2] text-[10px]">ELECTRONIC REACTION DIST:</span>
                  <div class="font-bold text-white text-sm">{{ stoppingResult()?.metrics?.reactionDistanceM }} m</div>
                </div>
                <div>
                  <span class="text-[#AEB3B2] text-[10px]">EBS MECHANICAL BRAKING:</span>
                  <div class="font-bold text-white text-sm">{{ stoppingResult()?.metrics?.brakingDistanceM }} m</div>
                </div>
                <div>
                  <span class="text-[#AEB3B2] text-[10px]">TOTAL STOPPING P95:</span>
                  <div class="font-bold text-[#C48D35] text-sm">{{ stoppingResult()?.metrics?.p95StoppingM }} m</div>
                </div>
                <div>
                  <span class="text-[#AEB3B2] text-[10px]">KINETIC ENERGY (1/2 m v²):</span>
                  <div class="font-bold text-[#48758A] text-sm">{{ stoppingResult()?.metrics?.kineticEnergyMJ }} MJ</div>
                </div>
              </div>
            </div>
          </div>
        }

        <!-- MODEL 2: MONTE CARLO TTC -->
        @if (activeModel() === 'risk') {
          <div class="bg-[#102A36]/60 border border-[#24282A] p-5 shadow-lg font-mono text-xs space-y-4">
            <div class="flex justify-between items-center border-b border-[#1F4A5A] pb-2 text-white">
              <span class="font-bold">R SCRIPT: r/risk_analysis.R // TIME-TO-COLLISION DISTRIBUTION (1,000 SCENARIO RUNS)</span>
              <span class="text-[#3E6250]">ZERO-COLLISION CERTIFIED</span>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div class="border border-[#24282A] p-3 bg-[#111415]">
                <div class="text-[#AEB3B2] text-[10px]">MEAN TIME-TO-COLLISION</div>
                <div class="text-xl font-bold text-white mt-1">4.82 s</div>
                <div class="text-[10px] text-[#3E6250] mt-1">Nominal Margin &gt; 3.0s</div>
              </div>
              <div class="border border-[#24282A] p-3 bg-[#111415]">
                <div class="text-[#AEB3B2] text-[10px]">MINIMUM OBSERVED TTC</div>
                <div class="text-xl font-bold text-[#C48D35] mt-1">1.48 s</div>
                <div class="text-[10px] text-[#AEB3B2] mt-1">Forklift Cut-in Extreme</div>
              </div>
              <div class="border border-[#24282A] p-3 bg-[#111415]">
                <div class="text-[#AEB3B2] text-[10px]">MEAN SWEPT CLEARANCE</div>
                <div class="text-xl font-bold text-[#3E6250] mt-1">1.84 m</div>
                <div class="text-[10px] text-[#AEB3B2] mt-1">Boundary Pad: 0.60m</div>
              </div>
              <div class="border border-[#24282A] p-3 bg-[#111415]">
                <div class="text-[#AEB3B2] text-[10px]">SAFETY INTERVENTION RATE</div>
                <div class="text-xl font-bold text-[#A8423B] mt-1">4.2%</div>
                <div class="text-[10px] text-[#AEB3B2] mt-1">Controlled MRM Slowdowns</div>
              </div>
            </div>

            <div class="p-4 border border-[#24282A] bg-[#111415] space-y-2">
              <span class="text-white font-bold">CLEARANCE MARGIN HISTOGRAM (&gt;0.5m STRICT SOTIF REQUIREMENT)</span>
              <div class="space-y-2 pt-2">
                <div>
                  <div class="flex justify-between text-[11px] mb-1">
                    <span>0.5 - 1.0 m (Near-Critical Limit):</span>
                    <span>18 runs (1.8%)</span>
                  </div>
                  <div class="w-full bg-[#24282A] h-2"><div class="bg-[#A8423B] h-full" style="width: 1.8%"></div></div>
                </div>
                <div>
                  <div class="flex justify-between text-[11px] mb-1">
                    <span>1.0 - 1.5 m (Caution Corridor):</span>
                    <span>142 runs (14.2%)</span>
                  </div>
                  <div class="w-full bg-[#24282A] h-2"><div class="bg-[#C48D35] h-full" style="width: 14.2%"></div></div>
                </div>
                <div>
                  <div class="flex justify-between text-[11px] mb-1">
                    <span>1.5 - 2.0 m (Nominal Industrial Margin):</span>
                    <span>486 runs (48.6%)</span>
                  </div>
                  <div class="w-full bg-[#24282A] h-2"><div class="bg-[#3E6250] h-full" style="width: 48.6%"></div></div>
                </div>
                <div>
                  <div class="flex justify-between text-[11px] mb-1">
                    <span>2.0 - 2.5 m (Open Yard Clearance):</span>
                    <span>260 runs (26.0%)</span>
                  </div>
                  <div class="w-full bg-[#24282A] h-2"><div class="bg-[#1F4A5A] h-full" style="width: 26.0%"></div></div>
                </div>
              </div>
            </div>
          </div>
        }

        <!-- MODEL 3: ENERGY PREDICTION -->
        @if (activeModel() === 'energy') {
          <div class="bg-[#102A36]/60 border border-[#24282A] p-5 shadow-lg font-mono text-xs space-y-4">
            <div class="flex justify-between items-center border-b border-[#1F4A5A] pb-2 text-white">
              <span class="font-bold">R SCRIPT: r/energy_consumption_model.R // 720 kWh HEAVY ELECTRIC TRACTOR</span>
              <span class="text-[#3E6250]">MISSION M-20481 PREDICTION</span>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div class="border border-[#24282A] p-3 bg-[#111415]">
                <div class="text-[#AEB3B2] text-[10px]">PREDICTED NET CONSUMPTION</div>
                <div class="text-xl font-bold text-white mt-1">158.4 kWh</div>
                <div class="text-[10px] text-[#3E6250] mt-1">Specific: 1.32 kWh / km</div>
              </div>
              <div class="border border-[#24282A] p-3 bg-[#111415]">
                <div class="text-[#AEB3B2] text-[10px]">REGEN RECUPERATION</div>
                <div class="text-xl font-bold text-[#48758A] mt-1">32.6 kWh</div>
                <div class="text-[10px] text-[#AEB3B2] mt-1">Descent & Braking Recapture</div>
              </div>
              <div class="border border-[#24282A] p-3 bg-[#111415]">
                <div class="text-[#AEB3B2] text-[10px]">ARRIVAL SoC ESTIMATE</div>
                <div class="text-xl font-bold text-[#3E6250] mt-1">78.0% &rarr; 56.0%</div>
                <div class="text-[10px] text-[#AEB3B2] mt-1">Depot Bay 4 Arrival Buffer</div>
              </div>
            </div>
          </div>
        }

        <!-- MODEL 4: DEPOT QUEUEING -->
        @if (activeModel() === 'depot') {
          <div class="bg-[#102A36]/60 border border-[#24282A] p-5 shadow-lg font-mono text-xs space-y-4">
            <div class="flex justify-between items-center border-b border-[#1F4A5A] pb-2 text-white">
              <span class="font-bold">R SCRIPT: r/depot_throughput_simulation.R // M/M/c BAY QUEUEING THEORY</span>
              <span class="text-[#3E6250]">24-HOUR STOCHASTIC RUN</span>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div class="border border-[#24282A] p-3 bg-[#111415]">
                <div class="text-[#AEB3B2] text-[10px]">TOTAL MISSIONS PROCESSED</div>
                <div class="text-xl font-bold text-white mt-1">156 Units</div>
                <div class="text-[10px] text-[#AEB3B2] mt-1">Arrival: 6.5 trucks / hour</div>
              </div>
              <div class="border border-[#24282A] p-3 bg-[#111415]">
                <div class="text-[#AEB3B2] text-[10px]">MEAN QUEUE WAIT TIME</div>
                <div class="text-xl font-bold text-[#3E6250] mt-1">4.2 mins</div>
                <div class="text-[10px] text-[#3E6250] mt-1">95th Percentile: 11.5 mins</div>
              </div>
              <div class="border border-[#24282A] p-3 bg-[#111415]">
                <div class="text-[#AEB3B2] text-[10px]">BAY UTILISATION RATE</div>
                <div class="text-xl font-bold text-[#C48D35] mt-1">74.2%</div>
                <div class="text-[10px] text-[#AEB3B2] mt-1">Optimal Throughput Window</div>
              </div>
              <div class="border border-[#24282A] p-3 bg-[#111415]">
                <div class="text-[#AEB3B2] text-[10px]">DAILY DOCK TURNOVER</div>
                <div class="text-xl font-bold text-white mt-1">26.0 / bay</div>
                <div class="text-[10px] text-[#AEB3B2] mt-1">Continuous Autonomy Cycle</div>
              </div>
            </div>
          </div>
        }

      </div>
    </div>
  `
})
export class RResearchLabComponent implements OnInit {
  state = inject(FreightStateService);

  activeModel = signal<'stopping' | 'risk' | 'energy' | 'depot'>('stopping');
  massTonnes = signal<number>(31.8);
  speedKph = signal<number>(45.0);
  surface = signal<string>('asphalt_dry');

  stoppingResult = signal<StoppingResultData | null>(null);

  ngOnInit() {
    this.runStoppingCalculation();
  }

  updateMass(e: Event) {
    this.massTonnes.set(Number((e.target as HTMLInputElement).value));
    this.runStoppingCalculation();
  }

  updateSpeed(e: Event) {
    this.speedKph.set(Number((e.target as HTMLInputElement).value));
    this.runStoppingCalculation();
  }

  updateSurface(e: Event) {
    this.surface.set((e.target as HTMLSelectElement).value);
    this.runStoppingCalculation();
  }

  runStoppingCalculation() {
    this.state.runRAnalytics('stopping_distance', {
      massTonnes: this.massTonnes(),
      speedKph: this.speedKph(),
      surface: this.surface(),
    }).subscribe({
      next: (res) => this.stoppingResult.set(res as unknown as StoppingResultData),
      error: () => {
        // Fallback calculation directly in client if offline
        const mass = this.massTonnes();
        const speed = this.speedKph();
        const v = speed / 3.6;
        const mu = this.surface() === 'asphalt_dry' ? 0.82 : 0.58;
        const fade = 1 - (mass / 100) * 0.15;
        const dReact = v * 0.12;
        const dBrake = (v * v) / (2 * mu * fade * 9.81);
        const total = dReact + dBrake;

        const bins = [];
        for (let i = 0; i < 20; i++) {
          bins.push({
            distanceM: Number((total * (0.88 + i * 0.015)).toFixed(2)),
            frequency: Math.round(Math.exp(-Math.pow(i - 8, 2) / 18) * 140),
          });
        }

        this.stoppingResult.set({
          metrics: {
            reactionDistanceM: Number(dReact.toFixed(3)),
            brakingDistanceM: Number(dBrake.toFixed(3)),
            meanStoppingM: Number(total.toFixed(3)),
            p95StoppingM: Number((total * 1.14).toFixed(3)),
            p99StoppingM: Number((total * 1.25).toFixed(3)),
            kineticEnergyMJ: Number((0.5 * (mass * 1000) * v * v / 1e6).toFixed(2)),
          },
          distribution: bins,
        });
      }
    });
  }
}
