import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FreightStateService } from '../../core/services/freight-state.service';

@Component({
  selector: 'app-sensor-fusion',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#111415] text-[#F1F0EA] overflow-y-auto">
      <!-- Header -->
      <div class="border-b border-[#24282A] px-6 py-4 bg-[#102A36]">
        <div class="flex items-center space-x-2 text-xs font-mono text-[#C48D35] uppercase">
          <span>PERCEPTION ENGINE &bull; MULTI-MODAL FUSION</span>
        </div>
        <h1 class="text-xl font-heading font-bold text-white tracking-tight mt-1">
          SENSOR FUSION MATRIX & FAULT-TOLERANT LOCALISATION
        </h1>
        <p class="text-xs text-[#AEB3B2] font-mono mt-1">
          Real-time Bayesian state estimation combining 128-beam LiDAR, 8x Surround HDR Cameras, 77GHz Corner Radars, and Ultrasonic Yard Sonar.
        </p>
      </div>

      <div class="p-6 space-y-6 flex-1 bg-cad-grid">
        <!-- Sensor Fusion Table (Section 11 requirement) -->
        <div class="bg-[#102A36]/60 border border-[#24282A] p-5 shadow-lg backdrop-blur-sm">
          <div class="flex items-center justify-between border-b border-[#1F4A5A] pb-3 mb-4">
            <div class="flex items-center space-x-2">
              <mat-icon class="text-sm text-[#48758A]">table_chart</mat-icon>
              <span class="font-mono text-sm font-bold text-white">LIVE SENSOR FUSION CONFIDENCE MATRIX</span>
            </div>
            <span class="text-xs font-mono text-[#AEB3B2]">ASSOCIATION: EXTENDED KALMAN FILTER (EKF)</span>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left font-mono text-xs">
              <thead>
                <tr class="border-b border-[#24282A] text-[#AEB3B2] uppercase text-[10px]">
                  <th class="py-2 px-3">Track ID</th>
                  <th class="py-2 px-3">Class Description</th>
                  <th class="py-2 px-3 text-center">LiDAR (128ch)</th>
                  <th class="py-2 px-3 text-center">Camera (Surround)</th>
                  <th class="py-2 px-3 text-center">Radar (77GHz)</th>
                  <th class="py-2 px-3 text-center">Ultrasonic</th>
                  <th class="py-2 px-3 text-center text-[#3E6250]">Fused Track Conf</th>
                  <th class="py-2 px-3 text-right">Age (s)</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-[#24282A]/50">
                @for (obj of state.trackedObjects(); track obj.trackId) {
                  <tr class="hover:bg-[#1F4A5A]/20 transition">
                    <td class="py-3 px-3 font-bold text-white">{{ obj.trackId }}</td>
                    <td class="py-3 px-3">
                      <span class="px-2 py-0.5 border border-[#24282A] bg-[#111415] text-[#C48D35]">
                        {{ obj.objectClass }}
                      </span>
                    </td>
                    <td class="py-3 px-3 text-center" [ngClass]="state.faultLidarBlackout() ? 'text-[#A8423B]' : 'text-white'">
                      {{ state.faultLidarBlackout() ? '0.00 [DROP]' : obj.lidar.toFixed(2) }}
                    </td>
                    <td class="py-3 px-3 text-center" [ngClass]="state.faultCameraOcclusion() ? 'text-[#C48D35]' : 'text-white'">
                      {{ state.faultCameraOcclusion() ? (obj.camera * 0.5).toFixed(2) : obj.camera.toFixed(2) }}
                    </td>
                    <td class="py-3 px-3 text-center text-white">{{ obj.radar.toFixed(2) }}</td>
                    <td class="py-3 px-3 text-center text-white">{{ obj.ultrasonic.toFixed(2) }}</td>
                    <td class="py-3 px-3 text-center font-bold text-[#3E6250]">
                      <span class="px-2 py-0.5 bg-[#3E6250]/20 rounded-none">
                        {{ (obj.fusedConfidence * 100).toFixed(0) }}%
                      </span>
                    </td>
                    <td class="py-3 px-3 text-right text-[#AEB3B2]">{{ obj.persistenceAgeSec.toFixed(1) }}</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>

        <!-- Localisation Architecture & Degradation Modes -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <!-- Strategy Switcher -->
          <div class="bg-[#102A36]/60 border border-[#24282A] p-5 shadow-lg">
            <div class="flex items-center space-x-2 border-b border-[#1F4A5A] pb-3 mb-4">
              <mat-icon class="text-sm text-[#C48D35]">navigation</mat-icon>
              <span class="font-mono text-sm font-bold text-white">LOCALISATION ARBITRATOR</span>
            </div>

            <div class="space-y-3 font-mono text-xs">
              <!-- Strategy 1: GNSS RTK -->
              <div class="p-3 border" 
                   [ngClass]="state.localisationMode() === 'GNSS_RTK' ? 'border-[#3E6250] bg-[#3E6250]/10' : 'border-[#24282A] opacity-60'">
                <div class="flex justify-between items-center mb-1">
                  <span class="font-bold text-white">STRATEGY 1: MULTI-BAND GNSS + RTK CORRECTIONS</span>
                  <span class="text-[10px]" [ngClass]="state.faultGnssDenial() ? 'text-[#A8423B]' : 'text-[#3E6250]'">
                    {{ state.faultGnssDenial() ? 'DENIED' : 'ACTIVE NOMINAL' }}
                  </span>
                </div>
                <p class="text-[#AEB3B2] text-[11px]">
                  Carrier-phase differential GNSS (GPS L1/L2, Galileo E1/E5a). Sub-20mm horizontal accuracy on motorways and open logistics corridors.
                </p>
              </div>

              <!-- Strategy 2: LiDAR-SLAM Fallback -->
              <div class="p-3 border" 
                   [ngClass]="state.localisationMode() === 'LIDAR_SLAM' ? 'border-[#C48D35] bg-[#C48D35]/10' : 'border-[#24282A] opacity-60'">
                <div class="flex justify-between items-center mb-1">
                  <span class="font-bold text-white">STRATEGY 2: NDT LiDAR-SLAM + IMU DEAD-RECKONING</span>
                  <span class="text-[10px] text-[#C48D35]">ENGAGED IN FACTORIES / COVERED DOCKS</span>
                </div>
                <p class="text-[#AEB3B2] text-[11px]">
                  Normal Distributions Transform point matching against pre-surveyed 3D HD point cloud of Alexander Dennis Falkirk campus. Zero satellite reliance.
                </p>
              </div>

              <!-- Strategy 3: Depot Beacons -->
              <div class="p-3 border" 
                   [ngClass]="state.localisationMode() === 'DEPOT_BEACONS' ? 'border-[#48758A] bg-[#48758A]/10' : 'border-[#24282A] opacity-60'">
                <div class="flex justify-between items-center mb-1">
                  <span class="font-bold text-white">STRATEGY 3: ULTRA-WIDEBAND (UWB) BAY BEACONS</span>
                  <span class="text-[10px] text-[#AEB3B2]">STANDBY</span>
                </div>
                <p class="text-[#AEB3B2] text-[11px]">
                  Millimetre-level time-of-flight trilateration used for final reverse docking into Bay 1 to Bay 6.
                </p>
              </div>
            </div>
          </div>

          <!-- Covariance & Error Uncertainty Ellipsoid -->
          <div class="bg-[#102A36]/60 border border-[#24282A] p-5 shadow-lg flex flex-col justify-between font-mono">
            <div>
              <div class="flex items-center space-x-2 border-b border-[#1F4A5A] pb-3 mb-4">
                <mat-icon class="text-sm text-[#48758A]">track_changes</mat-icon>
                <span class="text-sm font-bold text-white">STATE UNCERTAINTY & COVARIANCE BOUNDS</span>
              </div>

              <div class="space-y-3 text-xs">
                <div class="flex justify-between border-b border-[#24282A] pb-2 text-[#AEB3B2]">
                  <span>Position Uncertainty (&plusmn;1&sigma;):</span>
                  <span class="font-bold text-white">
                    {{ state.localisationMode() === 'GNSS_RTK' ? '0.018 m' : '0.045 m' }}
                  </span>
                </div>
                <div class="flex justify-between border-b border-[#24282A] pb-2 text-[#AEB3B2]">
                  <span>Heading Yaw Variance (&sigma;<sub>&theta;</sub>):</span>
                  <span class="font-bold text-white">0.08&deg; (Unscented Kalman Filter)</span>
                </div>
                <div class="flex justify-between border-b border-[#24282A] pb-2 text-[#AEB3B2]">
                  <span>Trailer Hitch Articulation Error:</span>
                  <span class="font-bold text-[#C48D35]">&plusmn;0.12&deg; (Direct Kingpin Hall-Sensor)</span>
                </div>
                <div class="flex justify-between border-b border-[#24282A] pb-2 text-[#AEB3B2]">
                  <span>Perception False Positive Rate:</span>
                  <span class="font-bold text-[#3E6250]">&lt; 0.001 per 1,000 km</span>
                </div>
              </div>
            </div>

            <!-- Manual Localisation Mode Switcher for Evaluation -->
            <div class="pt-4 border-t border-[#24282A] flex items-center justify-between">
              <span class="text-[11px] text-[#AEB3B2]">MANUAL ARBITRATION OVERRIDE:</span>
              <div class="flex space-x-2 text-xs">
                <button (click)="state.localisationMode.set('GNSS_RTK')" 
                        class="px-2.5 py-1 border border-[#1F4A5A] text-white hover:bg-[#1F4A5A]">
                  FORCE GNSS
                </button>
                <button (click)="state.localisationMode.set('LIDAR_SLAM')" 
                        class="px-2.5 py-1 border border-[#C48D35] text-[#C48D35] hover:bg-[#C48D35]/20">
                  FORCE LIDAR
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class SensorFusionComponent {
  state = inject(FreightStateService);
}
