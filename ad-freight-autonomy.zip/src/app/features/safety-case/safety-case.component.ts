import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FreightStateService } from '../../core/services/freight-state.service';

@Component({
  selector: 'app-safety-case',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#111415] text-[#F1F0EA] overflow-y-auto">
      <!-- Header -->
      <div class="border-b border-[#24282A] px-6 py-4 bg-[#102A36]">
        <div class="flex items-center space-x-2 text-xs font-mono text-[#3E6250] uppercase">
          <mat-icon class="text-sm">verified</mat-icon>
          <span>UK REGULATORY SAFETY CASE EXPLORER // CODE OF PRACTICE TRACEABILITY</span>
        </div>
        <h1 class="text-xl font-heading font-bold text-white tracking-tight mt-1">
          GOODS VEHICLE SAFETY ASSURANCE & ISO 26262 ASIL-D EVIDENCE
        </h1>
        <p class="text-xs text-[#AEB3B2] font-mono mt-1">
          Full traceability chain from safety requirements to hazard analysis, test scenarios, automated test execution, and R validation evidence.
        </p>
      </div>

      <div class="p-6 space-y-6 flex-1 bg-cad-grid">
        <!-- Traceability Pipeline Graphic -->
        <div class="bg-[#102A36]/60 border border-[#24282A] p-5 shadow-lg font-mono">
          <div class="flex items-center space-x-2 border-b border-[#1F4A5A] pb-3 mb-4">
            <mat-icon class="text-sm text-[#48758A]">linear_scale</mat-icon>
            <span class="text-sm font-bold text-white">FORMAL ASSURANCE TRACEABILITY PIPELINE</span>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-5 gap-3 text-center text-xs">
            <div class="border border-[#24282A] p-3 bg-[#111415]">
              <div class="text-[10px] text-[#AEB3B2]">STAGE 01</div>
              <div class="font-bold text-white mt-1">SAFETY REQUIREMENT</div>
              <div class="text-[10px] text-[#71797B] mt-1">ODD & ISO 26262 Goals</div>
            </div>

            <div class="border border-[#24282A] p-3 bg-[#111415]">
              <div class="text-[10px] text-[#AEB3B2]">STAGE 02</div>
              <div class="font-bold text-white mt-1">HAZARD ANALYSIS (HARA)</div>
              <div class="text-[10px] text-[#C48D35] mt-1">ASIL-D Classification</div>
            </div>

            <div class="border border-[#24282A] p-3 bg-[#111415]">
              <div class="text-[10px] text-[#AEB3B2]">STAGE 03</div>
              <div class="font-bold text-white mt-1">TEST SCENARIO</div>
              <div class="text-[10px] text-[#71797B] mt-1">Deterministic Simulation</div>
            </div>

            <div class="border border-[#24282A] p-3 bg-[#111415]">
              <div class="text-[10px] text-[#AEB3B2]">STAGE 04</div>
              <div class="font-bold text-white mt-1">EXECUTION RESULT</div>
              <div class="text-[10px] text-[#3E6250] mt-1">Zero Collision Logged</div>
            </div>

            <div class="border border-[#3E6250] p-3 bg-[#3E6250]/20">
              <div class="text-[10px] text-[#3E6250] font-bold">STAGE 05</div>
              <div class="font-bold text-white mt-1">R STATISTICAL EVIDENCE</div>
              <div class="text-[10px] text-[#3E6250] mt-1">Monte Carlo Distribution</div>
            </div>
          </div>
        </div>

        <!-- Safety Cases Traceability Table -->
        <div class="bg-[#102A36]/60 border border-[#24282A] p-5 shadow-lg">
          <div class="flex items-center justify-between border-b border-[#1F4A5A] pb-3 mb-4 font-mono">
            <span class="text-sm font-bold text-white">ACTIVE SAFETY CASE RECORD INDEX</span>
            <span class="text-xs text-[#3E6250]">3 VERIFIED // AUDIT TRAIL IMMUTABLE</span>
          </div>

          <div class="space-y-4 font-mono text-xs">
            @for (sc of state.safetyCases(); track sc.requirementId) {
              <div class="border border-[#24282A] p-4 bg-[#111415] space-y-2 hover:border-[#1F4A5A] transition">
                <div class="flex flex-wrap items-center justify-between gap-2 border-b border-[#24282A]/70 pb-2">
                  <div class="flex items-center space-x-2">
                    <span class="px-2 py-0.5 bg-[#1F4A5A] text-white font-bold">{{ sc.requirementId }}</span>
                    <span class="text-white font-bold text-sm">{{ sc.title }}</span>
                  </div>
                  <span class="px-2 py-0.5 bg-[#3E6250]/20 text-[#3E6250] font-bold border border-[#3E6250]/40">
                    {{ sc.status }}
                  </span>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-[#AEB3B2] pt-1">
                  <div>
                    <span class="text-[10px] text-[#71797B] uppercase block">Identified Operational Hazard:</span>
                    <span class="text-white">{{ sc.hazard }}</span>
                  </div>
                  <div>
                    <span class="text-[10px] text-[#71797B] uppercase block">Engineered Safety Mitigation:</span>
                    <span class="text-[#C48D35]">{{ sc.safetyMitigation }}</span>
                  </div>
                  <div>
                    <span class="text-[10px] text-[#71797B] uppercase block">Test Scenario & Pass Criteria:</span>
                    <span class="text-gray-300">{{ sc.testScenario }}</span>
                  </div>
                  <div>
                    <span class="text-[10px] text-[#71797B] uppercase block">Automated R Statistical Evidence:</span>
                    <span class="text-[#48758A] underline cursor-pointer">{{ sc.rEvidenceScript }}</span>
                    <div class="text-[11px] text-[#3E6250] mt-0.5">&bull; {{ sc.validationResult }}</div>
                  </div>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- UK Trial Guidance Compliance Checklist -->
        <div class="bg-[#102A36]/60 border border-[#24282A] p-5 shadow-lg font-mono text-xs">
          <div class="flex items-center space-x-2 border-b border-[#1F4A5A] pb-3 mb-4">
            <mat-icon class="text-sm text-[#AEB3B2]">policy</mat-icon>
            <span class="text-sm font-bold text-white">UK CODE OF PRACTICE: AUTOMATED GOODS VEHICLE COMPLIANCE</span>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div class="flex items-start space-x-2">
              <mat-icon class="text-sm text-[#3E6250]">check_circle</mat-icon>
              <div>
                <div class="text-white font-bold">Continuous Event Data Recording (EDR)</div>
                <div class="text-[#AEB3B2] text-[11px]">All CAN-FD telemetry, perception tracks, and actuator requests saved deterministically with microsecond timestamps.</div>
              </div>
            </div>
            <div class="flex items-start space-x-2">
              <mat-icon class="text-sm text-[#3E6250]">check_circle</mat-icon>
              <div>
                <div class="text-white font-bold">Minimum-Risk Manoeuvre (MRM) Autonomy Clamp</div>
                <div class="text-[#AEB3B2] text-[11px]">Hardware-supervised fallback to controlled deceleration within lane without reliance on human teleoperator.</div>
              </div>
            </div>
            <div class="flex items-start space-x-2">
              <mat-icon class="text-sm text-[#3E6250]">check_circle</mat-icon>
              <div>
                <div class="text-white font-bold">Articulated Heavy Vehicle Swept Path Safety Margin</div>
                <div class="text-[#AEB3B2] text-[11px]">Real-time kinematic dynamic envelope bounds preventing rear overhang swing and trailer cut-in intrusions.</div>
              </div>
            </div>
            <div class="flex items-start space-x-2">
              <mat-icon class="text-sm text-[#3E6250]">check_circle</mat-icon>
              <div>
                <div class="text-white font-bold">Multi-Modal Sensor Redundancy & ODD Boundary Gate</div>
                <div class="text-[#AEB3B2] text-[11px]">LiDAR, surround camera, 77GHz radar, and ultrasonic sonar isolation allowing graceful operational degradation.</div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  `
})
export class SafetyCaseComponent {
  state = inject(FreightStateService);
}
