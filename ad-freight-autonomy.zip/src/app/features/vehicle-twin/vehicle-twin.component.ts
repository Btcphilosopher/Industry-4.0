import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FreightStateService } from '../../core/services/freight-state.service';

@Component({
  selector: 'app-vehicle-twin',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#111415] text-[#F1F0EA] overflow-y-auto">
      <!-- Digital Twin Header -->
      <div class="flex flex-wrap items-center justify-between border-b border-[#24282A] px-6 py-4 bg-[#102A36]">
        <div class="space-y-1">
          <div class="flex items-center space-x-3">
            <span class="text-xs font-mono font-bold tracking-widest text-[#C48D35] uppercase">
              DIGITAL TWIN // ENGINEERING SPECIFICATION
            </span>
            <span class="text-xs bg-[#1F4A5A] text-white px-2 py-0.5 font-mono">ASIL-D CERTIFIED ARCHITECTURE</span>
          </div>
          <h1 class="text-xl font-heading font-bold text-white tracking-tight">
            ALEXANDER DENNIS AD F800E — 44-TONNE ELECTRIC FREIGHT TRACTOR
          </h1>
          <p class="text-xs text-[#AEB3B2] font-mono">
            CHASSIS VIN: SAD-F800E-2026-UK017 &bull; REG: SN26 ADX &bull; WHEELBASE: 3,800 mm &bull; KINGPIN LOAD: 11,500 kg
          </p>
        </div>

        <!-- Layer Toggles -->
        <div class="flex items-center space-x-2 font-mono text-xs mt-3 sm:mt-0">
          <button (click)="toggleLayer('chassis')" 
                  [class.bg-[#1F4A5A]]="showChassis()" 
                  class="border border-[#1F4A5A] px-2.5 py-1 text-gray-300 hover:text-white transition">
            CHASSIS
          </button>
          <button (click)="toggleLayer('battery')" 
                  [class.bg-[#1F4A5A]]="showBattery()" 
                  class="border border-[#1F4A5A] px-2.5 py-1 text-gray-300 hover:text-white transition">
            720kWh BATTERY
          </button>
          <button (click)="toggleLayer('powertrain')" 
                  [class.bg-[#1F4A5A]]="showPowertrain()" 
                  class="border border-[#1F4A5A] px-2.5 py-1 text-gray-300 hover:text-white transition">
            E-MOTORS
          </button>
          <button (click)="toggleLayer('sensors')" 
                  [class.bg-[#1F4A5A]]="showSensors()" 
                  class="border border-[#1F4A5A] px-2.5 py-1 text-gray-300 hover:text-white transition">
            SENSORS & AUTONOMY
          </button>
        </div>
      </div>

      <!-- Main Layout: Technical Vector Diagram (Left) & Real-time Subsystem Telemetry (Right) -->
      <div class="grid grid-cols-1 lg:grid-cols-12 flex-1 p-6 gap-6 bg-cad-grid">
        
        <!-- Left: High-Fidelity Vector CAD Assembly Drawing -->
        <div class="lg:col-span-8 bg-[#102A36]/40 border border-[#24282A] p-6 flex flex-col justify-between relative shadow-xl backdrop-blur-sm">
          <div class="flex justify-between items-center text-xs font-mono text-[#AEB3B2] border-b border-[#24282A] pb-2">
            <span>FIGURE 1.0 — EXPLODED KINEMATIC TOP-DOWN SCHEMATIC</span>
            <span class="text-[#3E6250] font-bold">100Hz HARDWARE BUS SYNCHRONISED</span>
          </div>

          <!-- SVG Technical Blueprint Illustration -->
          <div class="relative w-full h-[460px] flex items-center justify-center my-4 overflow-hidden">
            <svg class="w-full h-full max-w-2xl" viewBox="0 0 800 480" fill="none" xmlns="http://www.w3.org/2000/svg">
              <!-- Grid marks -->
              <line x1="50" y1="240" x2="750" y2="240" stroke="#1F4A5A" stroke-width="0.8" stroke-dasharray="4 8"/>
              <line x1="300" y1="40" x2="300" y2="440" stroke="#1F4A5A" stroke-width="0.8" stroke-dasharray="4 8"/>
              <line x1="560" y1="40" x2="560" y2="440" stroke="#1F4A5A" stroke-width="0.8" stroke-dasharray="4 8"/>

              <!-- 1. Tractor Chassis Rails (Heavy Steel I-Beams) -->
              @if (showChassis()) {
                <rect x="180" y="195" width="420" height="18" fill="#24282A" stroke="#71797B" stroke-width="1.5"/>
                <rect x="180" y="267" width="420" height="18" fill="#24282A" stroke="#71797B" stroke-width="1.5"/>
                <!-- Crossmembers -->
                <rect x="250" y="213" width="14" height="54" fill="#111415" stroke="#71797B"/>
                <rect x="360" y="213" width="14" height="54" fill="#111415" stroke="#71797B"/>
                <rect x="490" y="213" width="14" height="54" fill="#111415" stroke="#71797B"/>
              }

              <!-- 2. High-Voltage 720 kWh Underfloor Battery Modules -->
              @if (showBattery()) {
                <g class="animate-pulse">
                  <rect x="270" y="160" width="210" height="32" rx="3" fill="#102A36" stroke="#C48D35" stroke-width="2"/>
                  <rect x="270" y="288" width="210" height="32" rx="3" fill="#102A36" stroke="#C48D35" stroke-width="2"/>
                  <text x="310" y="180" fill="#C48D35" font-family="'Chivo Mono'" font-size="10" font-weight="bold">HV BATTERY PACK LEFT (360 kWh)</text>
                  <text x="310" y="308" fill="#C48D35" font-family="'Chivo Mono'" font-size="10" font-weight="bold">HV BATTERY PACK RIGHT (360 kWh)</text>
                </g>
              }

              <!-- 3. Dual Electric Drive Motors & e-Axle -->
              @if (showPowertrain()) {
                <g>
                  <rect x="520" y="210" width="70" height="60" rx="4" fill="#1F4A5A" stroke="#48758A" stroke-width="2"/>
                  <circle cx="555" cy="240" r="18" fill="#102A36" stroke="#AEB3B2" stroke-width="1.5"/>
                  <text x="532" y="244" fill="#F1F0EA" font-family="'Chivo Mono'" font-size="9" font-weight="bold">e-AXLE</text>
                  <!-- Dual Rear Drive Wheels -->
                  <rect x="525" y="130" width="60" height="24" rx="3" fill="#111415" stroke="#AEB3B2" stroke-width="1.5"/>
                  <rect x="525" y="326" width="60" height="24" rx="3" fill="#111415" stroke="#AEB3B2" stroke-width="1.5"/>
                </g>
              }

              <!-- 4. Steer-by-Wire Front Axle & Wheels -->
              <g>
                <line x1="220" y1="140" x2="220" y2="340" stroke="#AEB3B2" stroke-width="4"/>
                <!-- Left Front Wheel (Steer angle indicated) -->
                <g transform="translate(220, 142) rotate(12)">
                  <rect x="-26" y="-12" width="52" height="24" rx="3" fill="#111415" stroke="#C48D35" stroke-width="1.8"/>
                </g>
                <!-- Right Front Wheel -->
                <g transform="translate(220, 338) rotate(12)">
                  <rect x="-26" y="-12" width="52" height="24" rx="3" fill="#111415" stroke="#C48D35" stroke-width="1.8"/>
                </g>
              </g>

              <!-- 5. 5th-Wheel Kingpin Coupler (Trailer Hitch point) -->
              <circle cx="500" cy="240" r="22" fill="#24282A" stroke="#AEB3B2" stroke-width="2"/>
              <circle cx="500" cy="240" r="7" fill="#C48D35"/>
              <text x="475" y="275" fill="#AEB3B2" font-family="'Chivo Mono'" font-size="9">5TH WHEEL COUPLER</text>

              <!-- 6. Sensor Pods & Autonomy Computers -->
              @if (showSensors()) {
                <g>
                  <!-- Front LiDAR array -->
                  <circle cx="160" cy="240" r="10" fill="#A8423B" stroke="#F1F0EA" stroke-width="1.5"/>
                  <line x1="160" y1="240" x2="100" y2="180" stroke="#A8423B" stroke-width="1.2"/>
                  <text x="20" y="175" fill="#A8423B" font-family="'Chivo Mono'" font-size="10" font-weight="bold">FRONT 128-BEAM LiDAR</text>

                  <!-- Cab Roof Solid State LiDAR & Cameras -->
                  <rect x="230" y="222" width="36" height="36" rx="4" fill="#102A36" stroke="#3E6250" stroke-width="1.8"/>
                  <circle cx="248" cy="240" r="6" fill="#3E6250"/>
                  <text x="210" y="210" fill="#3E6250" font-family="'Chivo Mono'" font-size="9" font-weight="bold">AD DRIVE CORE RACK</text>

                  <!-- Corner 77GHz Radars -->
                  <circle cx="170" cy="150" r="5" fill="#48758A"/>
                  <circle cx="170" cy="330" r="5" fill="#48758A"/>
                  <circle cx="590" cy="150" r="5" fill="#48758A"/>
                  <circle cx="590" cy="330" r="5" fill="#48758A"/>
                  <text x="600" y="145" fill="#48758A" font-family="'Chivo Mono'" font-size="9">77GHz RADAR</text>
                </g>
              }

              <!-- Engineering Dimension Lines -->
              <g stroke="#71797B" stroke-width="1">
                <!-- Wheelbase 3,800 mm -->
                <line x1="220" y1="390" x2="555" y2="390"/>
                <line x1="220" y1="380" x2="220" y2="400"/>
                <line x1="555" y1="380" x2="555" y2="400"/>
                <text x="345" y="405" fill="#AEB3B2" font-family="'Chivo Mono'" font-size="10">WHEELBASE: 3,800 mm</text>

                <!-- Overall Length 7,200 mm -->
                <line x1="150" y1="430" x2="620" y2="430"/>
                <line x1="150" y1="420" x2="150" y2="440"/>
                <line x1="620" y1="420" x2="620" y2="440"/>
                <text x="330" y="445" fill="#AEB3B2" font-family="'Chivo Mono'" font-size="10">TRACTOR OAL: 7,200 mm</text>
              </g>
            </svg>
          </div>

          <div class="grid grid-cols-4 gap-2 pt-3 border-t border-[#24282A] text-[11px] font-mono text-[#AEB3B2]">
            <div>UNLADEN WEIGHT: <span class="text-white font-bold">9,200 kg</span></div>
            <div>GCM (GROSS): <span class="text-white font-bold">44,000 kg</span></div>
            <div>TURNING RADIUS: <span class="text-[#C48D35] font-bold">12.4 m</span></div>
            <div>BRAKE TYPE: <span class="text-white font-bold">PNEUMATIC EBS + REGEN</span></div>
          </div>
        </div>

        <!-- Right: Real-time Telemetry & Health Analytics Panel -->
        <div class="lg:col-span-4 flex flex-col space-y-4 font-mono">
          
          <!-- Powertrain & Battery Subsystem -->
          <div class="bg-[#102A36]/60 border border-[#24282A] p-4 shadow-md">
            <div class="flex justify-between items-center border-b border-[#1F4A5A] pb-2 mb-3">
              <span class="text-xs font-bold text-white flex items-center space-x-1">
                <mat-icon class="text-sm text-[#C48D35]">bolt</mat-icon>
                <span>HIGH VOLTAGE TRACTION SYSTEM</span>
              </span>
              <span class="text-[10px] text-[#3E6250] bg-[#3E6250]/20 px-1.5 py-0.5 font-bold">OPTIMAL</span>
            </div>

            <div class="space-y-3 text-xs">
              <div>
                <div class="flex justify-between text-[#AEB3B2] mb-1">
                  <span>State of Charge (SoC):</span>
                  <span class="text-white font-bold">{{ state.telemetry().socPct.toFixed(1) }}% (564 kWh)</span>
                </div>
                <div class="w-full bg-[#111415] h-2 rounded-none overflow-hidden">
                  <div class="bg-[#3E6250] h-full" [style.width.%]="state.telemetry().socPct"></div>
                </div>
              </div>

              <div class="flex justify-between border-t border-[#1F4A5A]/50 pt-2 text-[#AEB3B2]">
                <span>Pack Core Temperature:</span>
                <span class="text-white font-bold">{{ state.telemetry().batteryTempC.toFixed(1) }} &deg;C</span>
              </div>
              <div class="flex justify-between text-[#AEB3B2]">
                <span>Instant Motor Torque:</span>
                <span class="text-[#C48D35] font-bold">{{ state.telemetry().motorTorqueNm }} Nm</span>
              </div>
              <div class="flex justify-between text-[#AEB3B2]">
                <span>Regenerative Potential:</span>
                <span class="text-[#48758A] font-bold">Up to 450 kW</span>
              </div>
            </div>
          </div>

          <!-- Steer-by-Wire & Electronic Braking Subsystem -->
          <div class="bg-[#102A36]/60 border border-[#24282A] p-4 shadow-md">
            <div class="flex justify-between items-center border-b border-[#1F4A5A] pb-2 mb-3">
              <span class="text-xs font-bold text-white flex items-center space-x-1">
                <mat-icon class="text-sm text-[#48758A]">speed</mat-icon>
                <span>CHASSIS ACTUATION DYNAMICS</span>
              </span>
              <span class="text-[10px] text-[#AEB3B2]">REDUNDANT CAN-FD</span>
            </div>

            <div class="space-y-2 text-xs">
              <div class="flex justify-between text-[#AEB3B2]">
                <span>Steer Angle (&delta;):</span>
                <span class="text-white font-bold">{{ state.telemetry().steeringAngleDeg.toFixed(1) }}&deg;</span>
              </div>
              <div class="flex justify-between text-[#AEB3B2]">
                <span>Trailer Articulation (&beta;):</span>
                <span class="text-white font-bold">{{ state.telemetry().hitchAngleDeg.toFixed(1) }}&deg;</span>
              </div>
              <div class="flex justify-between text-[#AEB3B2]">
                <span>EBS Friction Disc Thickness:</span>
                <span class="font-bold" [ngClass]="state.telemetry().brakePadPct < 50 ? 'text-[#A8423B]' : 'text-[#3E6250]'">
                  {{ state.telemetry().brakePadPct }}% nominal
                </span>
              </div>
              <div class="flex justify-between text-[#AEB3B2]">
                <span>Tandem Tyre Pressure:</span>
                <span class="text-white font-bold">{{ state.telemetry().tyrePressureBar.toFixed(1) }} bar (Target: 8.8)</span>
              </div>
            </div>
          </div>

          <!-- AD Drive Core Compute & Kernel Health -->
          <div class="bg-[#102A36]/60 border border-[#24282A] p-4 shadow-md flex-1">
            <div class="flex justify-between items-center border-b border-[#1F4A5A] pb-2 mb-3">
              <span class="text-xs font-bold text-white flex items-center space-x-1">
                <mat-icon class="text-sm text-[#3E6250]">memory</mat-icon>
                <span>AD DRIVE CORE COMPUTATIONAL RACK</span>
              </span>
              <span class="text-[10px] text-[#3E6250]">DUAL SYNC</span>
            </div>

            <div class="space-y-2 text-xs">
              <div class="flex justify-between text-[#AEB3B2]">
                <span>Primary Kernel:</span>
                <span class="text-white font-bold">Rust tokio-rt (ad-safety v0.9.4)</span>
              </div>
              <div class="flex justify-between text-[#AEB3B2]">
                <span>Statistical Modeling Engine:</span>
                <span class="text-[#C48D35] font-bold">Embedded R Engine 4.4</span>
              </div>
              <div class="flex justify-between text-[#AEB3B2]">
                <span>Control Loop Latency:</span>
                <span class="text-[#3E6250] font-bold">4.2 ms (100 Hz Target)</span>
              </div>
              <div class="flex justify-between text-[#AEB3B2]">
                <span>Safety Watchdog Heartbeat:</span>
                <span class="text-white font-bold">0 Jitter / 0 Missed Frames</span>
              </div>
            </div>
          </div>

        </div>

      </div>
    </div>
  `
})
export class VehicleTwinComponent {
  state = inject(FreightStateService);

  showChassis = signal<boolean>(true);
  showBattery = signal<boolean>(true);
  showPowertrain = signal<boolean>(true);
  showSensors = signal<boolean>(true);

  toggleLayer(layer: 'chassis' | 'battery' | 'powertrain' | 'sensors') {
    if (layer === 'chassis') this.showChassis.update(v => !v);
    if (layer === 'battery') this.showBattery.update(v => !v);
    if (layer === 'powertrain') this.showPowertrain.update(v => !v);
    if (layer === 'sensors') this.showSensors.update(v => !v);
  }
}
