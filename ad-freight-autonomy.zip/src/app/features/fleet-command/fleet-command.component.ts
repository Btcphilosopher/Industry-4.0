import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FreightStateService } from '../../core/services/freight-state.service';

@Component({
  selector: 'app-fleet-command',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#111415] text-[#F1F0EA] overflow-y-auto">
      <!-- Header -->
      <div class="border-b border-[#24282A] px-6 py-4 bg-[#102A36] flex flex-wrap items-center justify-between">
        <div>
          <div class="flex items-center space-x-2 text-xs font-mono text-[#C48D35] uppercase">
            <span>AD FLEET COMMAND &bull; LOGISTICS ORCHESTRATION</span>
          </div>
          <h1 class="text-xl font-heading font-bold text-white tracking-tight mt-1">
            AUTONOMOUS FREIGHT FLEET & DEPOT OPERATING SYSTEM
          </h1>
          <p class="text-xs text-[#AEB3B2] font-mono mt-1">
            Orchestrating 42 articulated and rigid autonomous goods vehicles across road corridors, logistics depots and manufacturing campuses.
          </p>
        </div>

        <!-- Filter Buttons -->
        <div class="flex items-center space-x-2 font-mono text-xs mt-3 sm:mt-0">
          <button (click)="filterStatus.set('ALL')" 
                  [class.bg-[#1F4A5A]]="filterStatus() === 'ALL'" 
                  class="border border-[#24282A] px-2.5 py-1 text-gray-300 hover:text-white">
            ALL (42)
          </button>
          <button (click)="filterStatus.set('ACTIVE')" 
                  [class.bg-[#1F4A5A]]="filterStatus() === 'ACTIVE'" 
                  class="border border-[#24282A] px-2.5 py-1 text-gray-300 hover:text-white">
            ACTIVE EN ROUTE (18)
          </button>
          <button (click)="filterStatus.set('DOCKING')" 
                  [class.bg-[#1F4A5A]]="filterStatus() === 'DOCKING'" 
                  class="border border-[#24282A] px-2.5 py-1 text-gray-300 hover:text-white">
            LOADING / DOCK (6)
          </button>
          <button (click)="filterStatus.set('CHARGING')" 
                  [class.bg-[#1F4A5A]]="filterStatus() === 'CHARGING'" 
                  class="border border-[#24282A] px-2.5 py-1 text-gray-300 hover:text-white">
            CHARGING (4)
          </button>
        </div>
      </div>

      <div class="p-6 space-y-6 flex-1 bg-cad-grid">
        <!-- Depot Loading Bays Status (Industrial Docking) -->
        <div class="bg-[#102A36]/60 border border-[#24282A] p-5 shadow-lg">
          <div class="flex items-center justify-between border-b border-[#1F4A5A] pb-3 mb-4 font-mono">
            <div class="flex items-center space-x-2">
              <mat-icon class="text-sm text-[#3E6250]">warehouse</mat-icon>
              <span class="text-sm font-bold text-white">ALEXANDER DENNIS CENTRAL DEPOT // BAY MONITOR</span>
            </div>
            <span class="text-xs text-[#AEB3B2]">6 BAYS CONCURRENT // AUTOMATED TURNAROUND</span>
          </div>

          <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 font-mono text-xs">
            <div class="border border-[#24282A] p-3 bg-[#111415]/80">
              <div class="text-[10px] text-[#AEB3B2]">BAY 01</div>
              <div class="font-bold text-white mt-1">ADF600-022</div>
              <div class="text-[10px] text-[#C48D35] mt-1">LOADING BODYWORK</div>
              <div class="text-[10px] text-[#71797B] mt-2">Dwell: 14 / 25 min</div>
            </div>

            <div class="border border-[#24282A] p-3 bg-[#111415]/80">
              <div class="text-[10px] text-[#AEB3B2]">BAY 02</div>
              <div class="font-bold text-[#3E6250] mt-1">[READY / OPEN]</div>
              <div class="text-[10px] text-[#71797B] mt-1">Clearance: 4.8m</div>
              <div class="text-[10px] text-[#71797B] mt-2">Assigned: ADF800E-004</div>
            </div>

            <div class="border border-[#24282A] p-3 bg-[#111415]/80">
              <div class="text-[10px] text-[#AEB3B2]">BAY 03</div>
              <div class="font-bold text-white mt-1">ADF450-011</div>
              <div class="text-[10px] text-[#48758A] mt-1">MAINTENANCE SCAN</div>
              <div class="text-[10px] text-[#71797B] mt-2">Brake Caliper Audit</div>
            </div>

            <div class="border border-[#3E6250] p-3 bg-[#3E6250]/15">
              <div class="text-[10px] text-[#3E6250] font-bold">BAY 04 [TARGET]</div>
              <div class="font-bold text-white mt-1">ADF800E-017</div>
              <div class="text-[10px] text-[#C48D35] mt-1">BATTERY PACK DELIVERY</div>
              <div class="text-[10px] text-white mt-2">Approach: 4.2 min ETA</div>
            </div>

            <div class="border border-[#24282A] p-3 bg-[#111415]/80">
              <div class="text-[10px] text-[#AEB3B2]">BAY 05</div>
              <div class="font-bold text-white mt-1">ADYARD-01</div>
              <div class="text-[10px] text-[#3E6250] mt-1">AXLE UNLOAD</div>
              <div class="text-[10px] text-[#71797B] mt-2">Dwell: 19 / 20 min</div>
            </div>

            <div class="border border-[#24282A] p-3 bg-[#111415]/80">
              <div class="text-[10px] text-[#AEB3B2]">BAY 06</div>
              <div class="font-bold text-[#3E6250] mt-1">[READY / OPEN]</div>
              <div class="text-[10px] text-[#71797B] mt-1">Clearance: 4.8m</div>
              <div class="text-[10px] text-[#71797B] mt-2">Assigned: ADF900E-002</div>
            </div>
          </div>
        </div>

        <!-- Active Missions Manifest Table -->
        <div class="bg-[#102A36]/60 border border-[#24282A] p-5 shadow-lg">
          <div class="flex items-center justify-between border-b border-[#1F4A5A] pb-3 mb-4 font-mono">
            <div class="flex items-center space-x-2">
              <mat-icon class="text-sm text-[#C48D35]">local_shipping</mat-icon>
              <span class="text-sm font-bold text-white">ACTIVE FREIGHT MISSIONS</span>
            </div>
            <span class="text-xs text-[#AEB3B2]">JUST-IN-TIME (JIT) ASSEMBLY FLOW</span>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left font-mono text-xs">
              <thead>
                <tr class="border-b border-[#24282A] text-[#AEB3B2] uppercase text-[10px]">
                  <th class="py-2 px-3">Mission ID</th>
                  <th class="py-2 px-3">Vehicle</th>
                  <th class="py-2 px-3">Freight Description</th>
                  <th class="py-2 px-3 text-right">Mass (t)</th>
                  <th class="py-2 px-3">Origin &bull; Destination</th>
                  <th class="py-2 px-3">Priority</th>
                  <th class="py-2 px-3">Window</th>
                  <th class="py-2 px-3 text-right">ETA</th>
                  <th class="py-2 px-3 text-center">Status</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-[#24282A]/50">
                @for (m of state.missions(); track m.missionId) {
                  <tr class="hover:bg-[#1F4A5A]/20 transition">
                    <td class="py-3 px-3 font-bold text-[#C48D35]">{{ m.missionId }}</td>
                    <td class="py-3 px-3 font-bold text-white">{{ m.vehicleId }}</td>
                    <td class="py-3 px-3 text-gray-200">{{ m.cargoDescription }}</td>
                    <td class="py-3 px-3 text-right font-bold text-white">{{ m.weightTonnes.toFixed(1) }} t</td>
                    <td class="py-3 px-3 text-[#AEB3B2] text-[11px]">
                      <div>{{ m.origin }}</div>
                      <div class="text-[#71797B]">&darr; {{ m.destination }}</div>
                    </td>
                    <td class="py-3 px-3">
                      <span class="px-2 py-0.5 border border-[#24282A] text-[10px]" 
                            [ngClass]="m.priority === 'CRITICAL_ASSEMBLY' ? 'bg-[#A8423B]/30 text-red-200 border-red-500' : 'bg-[#111415] text-[#AEB3B2]'">
                        {{ m.priority }}
                      </span>
                    </td>
                    <td class="py-3 px-3 text-[#AEB3B2]">{{ m.deliveryWindow }}</td>
                    <td class="py-3 px-3 text-right font-bold text-[#3E6250]">{{ m.estimatedArrivalMin }} min</td>
                    <td class="py-3 px-3 text-center">
                      <span class="px-2 py-0.5 bg-[#3E6250]/20 text-[#3E6250] font-bold">
                        {{ m.status }}
                      </span>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>

        <!-- High-Power Megawatt Charging Systems (MCS) Status -->
        <div class="bg-[#102A36]/60 border border-[#24282A] p-5 shadow-lg">
          <div class="flex items-center justify-between border-b border-[#1F4A5A] pb-3 mb-4 font-mono">
            <div class="flex items-center space-x-2">
              <mat-icon class="text-sm text-[#48758A]">ev_station</mat-icon>
              <span class="text-sm font-bold text-white">MCS PLAZA ENERGY INFRASTRUCTURE</span>
            </div>
            <span class="text-xs text-[#3E6250] font-bold">GRID DEMAND: 680 kW (PEAK LIMIT: 1,400 kW)</span>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-4 gap-4 font-mono text-xs">
            <div class="border border-[#24282A] p-3 bg-[#111415]">
              <div class="text-[#AEB3B2] text-[10px]">MCS DISPENSER A1 (350 kW)</div>
              <div class="font-bold text-white mt-1">ADF900E-002</div>
              <div class="text-[#3E6250] mt-1">Active Charging @ 280 kW</div>
              <div class="text-[#71797B] mt-2">SoC: 41.5% &rarr; 85% in 34m</div>
            </div>
            <div class="border border-[#24282A] p-3 bg-[#111415]">
              <div class="text-[#AEB3B2] text-[10px]">MCS DISPENSER A2 (350 kW)</div>
              <div class="font-bold text-[#3E6250] mt-1">[STANDBY READY]</div>
              <div class="text-[#AEB3B2] mt-1">Automated Coupler Armed</div>
              <div class="text-[#71797B] mt-2">Next Reservation: 12:00</div>
            </div>
            <div class="border border-[#24282A] p-3 bg-[#111415]">
              <div class="text-[#AEB3B2] text-[10px]">DEPOT OVERNIGHT BUFFER (150 kW)</div>
              <div class="font-bold text-white mt-1">ADYARD-03</div>
              <div class="text-[#48758A] mt-1">Trickle Conditioning</div>
              <div class="text-[#71797B] mt-2">SoC: 92% (Cell Balancing)</div>
            </div>
            <div class="border border-[#24282A] p-3 bg-[#111415]">
              <div class="text-[#AEB3B2] text-[10px]">BESS STATIONARY STORAGE</div>
              <div class="font-bold text-white mt-1">2.4 MWh ON-SITE BUFFER</div>
              <div class="text-[#3E6250] mt-1">Peak Shaving Active</div>
              <div class="text-[#71797B] mt-2">Solar Generation: 140 kW</div>
            </div>
          </div>
        </div>

      </div>
    </div>
  `
})
export class FleetCommandComponent {
  state = inject(FreightStateService);
  filterStatus = signal<'ALL' | 'ACTIVE' | 'DOCKING' | 'CHARGING'>('ALL');
}
