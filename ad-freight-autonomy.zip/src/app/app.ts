import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FreightStateService } from './core/services/freight-state.service';
import { CampusSimComponent } from './features/campus-sim/campus-sim.component';
import { VehicleTwinComponent } from './features/vehicle-twin/vehicle-twin.component';
import { SensorFusionComponent } from './features/sensor-fusion/sensor-fusion.component';
import { FleetCommandComponent } from './features/fleet-command/fleet-command.component';
import { FailureLabComponent } from './features/failure-lab/failure-lab.component';
import { RResearchLabComponent } from './features/r-research-lab/r-research-lab.component';
import { SafetyCaseComponent } from './features/safety-case/safety-case.component';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    MatIconModule,
    CampusSimComponent,
    VehicleTwinComponent,
    SensorFusionComponent,
    FleetCommandComponent,
    FailureLabComponent,
    RResearchLabComponent,
    SafetyCaseComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  state = inject(FreightStateService);

  selectView(view: 'campus' | 'twin' | 'sensors' | 'fleet' | 'failure' | 'research' | 'safety') {
    this.state.currentView.set(view);
  }

  loadScenario(scenarioId: string) {
    this.state.loadScenario(scenarioId);
  }

  toggleDomain(domain: 'ROAD_FREIGHT' | 'INDUSTRIAL_AUTONOMY') {
    this.state.setDomain(domain);
  }
}
