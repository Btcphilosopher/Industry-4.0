export type OperationalDomain = 'ROAD_FREIGHT' | 'INDUSTRIAL_AUTONOMY';

export type AutonomyMode = 
  | 'ROAD_CRUISE' 
  | 'URBAN_CORRIDOR' 
  | 'YARD_AUTONOMY' 
  | 'PRECISION_DOCK' 
  | 'DEGRADED_ODD' 
  | 'MRM_SAFE_HALT';

export type LocalisationMode = 'GNSS_RTK' | 'LIDAR_SLAM' | 'IMU_DEAD_RECKONING' | 'DEPOT_BEACONS';

export type VehicleStatus = 
  | 'ACTIVE_EN_ROUTE' 
  | 'PRECISION_DOCKING' 
  | 'LOADING' 
  | 'UNLOADING' 
  | 'CHARGING' 
  | 'MAINTENANCE' 
  | 'SAFETY_HOLD' 
  | 'AVAILABLE';

export interface VehicleTelemetry {
  vehicleId: string;
  timestamp: string;
  speedKph: number;
  headingDeg: number;
  accelerationMps2: number;
  steeringAngleDeg: number;
  hitchAngleDeg: number;
  socPct: number;
  payloadKg: number;
  motorTorqueNm: number;
  batteryTempC: number;
  brakePadPct: number;
  tyrePressureBar: number;
  localisationConfidence: number;
  perceptionConfidence: number;
  minClearanceM: number;
  sweptWidthM: number;
  safetyState: 'NOMINAL' | 'CAUTION' | 'DEGRADED' | 'MRM_ACTIVE' | 'CRITICAL_HALT';
}

export interface TrackedObject {
  trackId: string;
  objectClass: 'ELECTRIC_FORKLIFT' | 'PEDESTRIAN_WORKER' | 'PALLET_STILLAGE' | 'ARTICULATED_TRUCK' | 'AUTOMATED_DOCK_DOOR' | 'OVERHEAD_GANTRY_CRANE';
  lidar: number;
  camera: number;
  radar: number;
  ultrasonic: number;
  fusedConfidence: number;
  persistenceAgeSec: number;
  distM: number;
  relSpeedKph: number;
  riskScore: number;
}

export interface SweptPathPoint {
  x: number;
  y: number;
}

export interface SweptPathGeometry {
  tractorFrontLeft: SweptPathPoint[];
  tractorFrontRight: SweptPathPoint[];
  trailerRearLeft: SweptPathPoint[];
  trailerRearRight: SweptPathPoint[];
  sweptWidthM: number;
  safetyEnvelopePaddingM: number;
  frontSwingMaxM: number;
  rearTrailerCutInM: number;
}

export interface FreightMission {
  missionId: string;
  vehicleId: string;
  cargoDescription: string;
  cargoType: 'BATTERY_MODULES' | 'STEEL_COILS' | 'CHASSIS_COMPONENTS' | 'BODY_PANELS' | 'FINISHED_VEHICLES' | 'INTERMODAL_CONTAINER';
  weightTonnes: number;
  origin: string;
  destination: string;
  priority: 'CRITICAL_ASSEMBLY' | 'STANDARD_HAUL' | 'HIGH_VALUE_PARTS' | 'JUST_IN_TIME';
  deliveryWindow: string;
  estimatedArrivalMin: number;
  routeDomainSequence: string[];
  status: 'PENDING' | 'IN_TRANSIT' | 'DOCKING' | 'DISPATCHED' | 'COMPLETED';
}

export interface SafetyCaseRequirement {
  requirementId: string;
  title: string;
  hazard: string;
  operationalDomain: string;
  safetyMitigation: string;
  testScenario: string;
  validationResult: string;
  rEvidenceScript: string;
  status: 'VERIFIED_ACTIVE' | 'AUDIT_PENDING' | 'RESTRICTED_ODD';
}

export interface AutonomyEvent {
  id: string;
  timestamp: string;
  vehicleId: string;
  eventType: 
    | 'MISSION_STARTED'
    | 'ODD_TRANSITION'
    | 'LOCALISATION_FALLBACK'
    | 'OBSTACLE_DETECTED'
    | 'PATH_REPLANNED'
    | 'MRM_TRIGGERED'
    | 'PRECISION_DOCK_ALIGNED'
    | 'CARGO_LOADED';
  severity: 'INFO' | 'WARN' | 'CRIT' | 'RESOLVED';
  message: string;
  telemetrySnapshot?: Partial<VehicleTelemetry>;
}
