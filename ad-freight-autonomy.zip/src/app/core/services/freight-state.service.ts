import { Injectable, signal, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { 
  OperationalDomain, 
  AutonomyMode, 
  LocalisationMode, 
  VehicleTelemetry, 
  TrackedObject, 
  FreightMission,
  SafetyCaseRequirement,
  AutonomyEvent
} from '../models/freight.models';

export interface ScenarioDefinition {
  id: string;
  name: string;
  vehicleId: string;
  domain: OperationalDomain;
  payloadTonnes: number;
  environment: string;
  weather: 'CLEAR' | 'HEAVY_RAIN' | 'NIGHT_RAIN' | 'INDUSTRIAL_DUST';
  description: string;
}

@Injectable({
  providedIn: 'root'
})
export class FreightStateService {
  private http = inject(HttpClient);

  // Core Operational Domain & Navigation
  readonly activeDomain = signal<OperationalDomain>('INDUSTRIAL_AUTONOMY');
  readonly currentView = signal<'campus' | 'twin' | 'sensors' | 'fleet' | 'failure' | 'research' | 'safety'>('campus');
  
  // Simulation Controls
  readonly isSimPlaying = signal<boolean>(true);
  readonly simSpeed = signal<number>(1.0); // 0.25, 1.0, 4.0
  readonly simTick = signal<number>(0);
  readonly simSeed = signal<number>(42);

  // Selected Vehicle & Telemetry
  readonly selectedVehicleId = signal<string>('ADF800E-017');
  readonly autonomyMode = signal<AutonomyMode>('YARD_AUTONOMY');
  readonly localisationMode = signal<LocalisationMode>('LIDAR_SLAM');
  
  // Real-time dynamic telemetry for ADF800E-017
  readonly telemetry = signal<VehicleTelemetry>({
    vehicleId: 'ADF800E-017',
    timestamp: new Date().toISOString(),
    speedKph: 11.8,
    headingDeg: 142.5,
    accelerationMps2: 0.15,
    steeringAngleDeg: 6.4,
    hitchAngleDeg: 14.2,
    socPct: 78.4,
    payloadKg: 31800,
    motorTorqueNm: 840,
    batteryTempC: 26.4,
    brakePadPct: 91,
    tyrePressureBar: 8.8,
    localisationConfidence: 0.96,
    perceptionConfidence: 0.94,
    minClearanceM: 1.65,
    sweptWidthM: 4.15,
    safetyState: 'NOMINAL',
  });

  // Tracked Objects for Sensor Fusion
  readonly trackedObjects = signal<TrackedObject[]>([
    {
      trackId: 'TRK-4081',
      objectClass: 'ELECTRIC_FORKLIFT',
      lidar: 0.96,
      camera: 0.92,
      radar: 0.84,
      ultrasonic: 0.98,
      fusedConfidence: 0.97,
      persistenceAgeSec: 14.2,
      distM: 12.4,
      relSpeedKph: -8.2,
      riskScore: 32,
    },
    {
      trackId: 'TRK-4082',
      objectClass: 'PEDESTRIAN_WORKER',
      lidar: 0.89,
      camera: 0.95,
      radar: 0.48,
      ultrasonic: 0.92,
      fusedConfidence: 0.94,
      persistenceAgeSec: 8.6,
      distM: 18.2,
      relSpeedKph: 3.5,
      riskScore: 24,
    },
    {
      trackId: 'TRK-3920',
      objectClass: 'PALLET_STILLAGE',
      lidar: 0.94,
      camera: 0.88,
      radar: 0.22,
      ultrasonic: 0.91,
      fusedConfidence: 0.91,
      persistenceAgeSec: 320.0,
      distM: 7.8,
      relSpeedKph: 0.0,
      riskScore: 10,
    },
    {
      trackId: 'TRK-3501',
      objectClass: 'AUTOMATED_DOCK_DOOR',
      lidar: 0.99,
      camera: 0.97,
      radar: 0.91,
      ultrasonic: 0.99,
      fusedConfidence: 0.99,
      persistenceAgeSec: 610.0,
      distM: 28.5,
      relSpeedKph: 0.0,
      riskScore: 5,
    },
  ]);

  // Failure Injection Flags
  readonly faultGnssDenial = signal<boolean>(false);
  readonly faultLidarBlackout = signal<boolean>(false);
  readonly faultForkliftIntrusion = signal<boolean>(false);
  readonly faultBrakeDegradation = signal<boolean>(false);
  readonly faultCameraOcclusion = signal<boolean>(false);

  // Active Scenarios
  readonly scenarios: ScenarioDefinition[] = [
    {
      id: 'MISSION_20481',
      name: 'SIGNATURE 1: MISSION 20481 (ADF800E-017)',
      vehicleId: 'ADF800E-017',
      domain: 'INDUSTRIAL_AUTONOMY',
      payloadTonnes: 31.8,
      environment: 'AD Manufacturing Campus Falkirk -> Regional Logistics Depot',
      weather: 'CLEAR',
      description: 'Collect 720kWh bus battery modules, traverse yard gates, motorway link, precision dock at Bay 4.',
    },
    {
      id: 'STEEL_WORKS',
      name: 'SIGNATURE 2: BRITISH STEEL FREIGHT',
      vehicleId: 'ADF800-009',
      domain: 'INDUSTRIAL_AUTONOMY',
      payloadTonnes: 34.2,
      environment: 'British Steel Scunthorpe Works (Cranes, Rail Sidings, Billets)',
      weather: 'INDUSTRIAL_DUST',
      description: 'Heavy structural steel coil transit through ultra-tight crane clearance bays at 7 km/h.',
    },
    {
      id: 'NIGHT_SHIFT',
      name: 'SIGNATURE 3: FACTORY NIGHT SHIFT',
      vehicleId: 'ADF800E-004',
      domain: 'INDUSTRIAL_AUTONOMY',
      payloadTonnes: 28.4,
      environment: 'Autonomous Manufacturing Campus (23:00 - 05:00 Shift)',
      weather: 'NIGHT_RAIN',
      description: 'Fully autonomous yard logistics under rain and artificial sodium/LED lighting. 7 active vehicles.',
    },
    {
      id: 'GNSS_FAIL_FORKLIFT',
      name: 'SIGNATURE 4: FAULT LAB (GNSS LOSS & FORKLIFT CUT-IN)',
      vehicleId: 'ADF800E-017',
      domain: 'INDUSTRIAL_AUTONOMY',
      payloadTonnes: 31.8,
      environment: 'High-Bay Staging Hall 2',
      weather: 'CLEAR',
      description: 'Simulate instant GNSS multipath dropout -> LiDAR-SLAM fallback -> Sudden forklift lane intrusion -> MRM Replan.',
    },
  ];

  readonly activeScenarioId = signal<string>('MISSION_20481');

  // Immutable Safety Event Log
  readonly events = signal<AutonomyEvent[]>([
    {
      id: 'EVT-109281',
      timestamp: '11:14:02.184',
      vehicleId: 'ADF800E-017',
      eventType: 'MISSION_STARTED',
      severity: 'INFO',
      message: 'Mission M-20481 initiated. Payload: 31.8t Battery Modules. Origin: Battery Assembly Hall 1.',
    },
    {
      id: 'EVT-109282',
      timestamp: '11:14:18.420',
      vehicleId: 'ADF800E-017',
      eventType: 'ODD_TRANSITION',
      severity: 'INFO',
      message: 'ODD Boundary verified: INDUSTRIAL_AUTONOMY confirmed. Speed clamp 15 km/h engaged.',
    },
    {
      id: 'EVT-109283',
      timestamp: '11:15:02.910',
      vehicleId: 'ADF800E-017',
      eventType: 'OBSTACLE_DETECTED',
      severity: 'WARN',
      message: 'Electric Forklift (TRK-4081) detected at 12.4m on crossing vector. Fused confidence 0.97.',
    },
    {
      id: 'EVT-109284',
      timestamp: '11:15:03.240',
      vehicleId: 'ADF800E-017',
      eventType: 'PATH_REPLANNED',
      severity: 'INFO',
      message: 'Lattice planner evaluated 18 alternative candidate splines. Swept clearance maintained >1.65m.',
    },
  ]);

  // Active missions
  readonly missions = signal<FreightMission[]>([
    {
      missionId: 'M-20481',
      vehicleId: 'ADF800E-017',
      cargoDescription: 'High-Density 720kWh Electric Bus Battery Modules (8 Packs)',
      cargoType: 'BATTERY_MODULES',
      weightTonnes: 31.8,
      origin: 'Alexander Dennis Campus (Battery Hall)',
      destination: 'Regional Logistics Depot -> Final Assembly 1',
      priority: 'CRITICAL_ASSEMBLY',
      deliveryWindow: '11:15 - 11:35 GMT',
      estimatedArrivalMin: 14,
      routeDomainSequence: ['FACTORY_GATE_2', 'INDUSTRIAL_ACCESS_RD', 'M9_MOTORWAY', 'DEPOT_APPROACH', 'DOCK_BAY_4'],
      status: 'IN_TRANSIT',
    },
    {
      missionId: 'M-20482',
      vehicleId: 'ADF800-009',
      cargoDescription: 'Rolled Structural High-Tensile Steel Coils',
      cargoType: 'STEEL_COILS',
      weightTonnes: 34.2,
      origin: 'British Steel Scunthorpe Yard 3',
      destination: 'Chassis Fabrication Hall',
      priority: 'STANDARD_HAUL',
      deliveryWindow: '13:00 - 13:45 GMT',
      estimatedArrivalMin: 42,
      routeDomainSequence: ['STEEL_RAIL_SIDING', 'A18_TRUNK_ROAD', 'M180_CORRIDOR', 'INSPECTION_GATE'],
      status: 'IN_TRANSIT',
    },
    {
      missionId: 'M-20483',
      vehicleId: 'ADF800E-004',
      cargoDescription: 'Enviro500 Pre-Formed Aluminium Body Sections',
      cargoType: 'BODY_PANELS',
      weightTonnes: 16.5,
      origin: 'Sub-Assembly Works Larbert',
      destination: 'Paint & Corrosion Protection Facility Bay 2',
      priority: 'JUST_IN_TIME',
      deliveryWindow: '11:45 - 12:00 GMT',
      estimatedArrivalMin: 22,
      routeDomainSequence: ['LARBERT_LOGISTICS_PARK', 'A9_DUAL_CARRIAGEWAY', 'WEST_PLANT_GATE'],
      status: 'IN_TRANSIT',
    },
    {
      missionId: 'M-20488',
      vehicleId: 'ADYARD-01',
      cargoDescription: 'Heavy-Duty Tandem Steer Axles & Disc Braking Subassemblies',
      cargoType: 'CHASSIS_COMPONENTS',
      weightTonnes: 18.2,
      origin: 'Goods Inbound Buffer Yard',
      destination: 'Chassis Line Dock Bay 4',
      priority: 'JUST_IN_TIME',
      deliveryWindow: '11:10 - 11:20 GMT',
      estimatedArrivalMin: 4,
      routeDomainSequence: ['BUFFER_LANE_C', 'PEDESTRIAN_SAFE_CORRIDOR', 'DOCK_ALIGNMENT_4'],
      status: 'DOCKING',
    },
  ]);

  // Safety Case Requirements
  readonly safetyCases = signal<SafetyCaseRequirement[]>([
    {
      requirementId: 'REQ-SAF-042',
      title: 'Factory-Floor Dynamic Obstacle Clearance Boundary',
      hazard: 'Forklift or worker cut-in across articulated trailer swept envelope',
      operationalDomain: 'INDUSTRIAL_AUTONOMY',
      safetyMitigation: 'AD Drive Core dynamic swept path expansion + 1.2s MRM deceleration halt',
      testScenario: 'SCN-YARD-402 (Forklift blind corner emergence at 8 km/h)',
      validationResult: '100% Zero-Contact over 5,000 deterministic Monte Carlo passes',
      rEvidenceScript: 'r/risk_analysis.R',
      status: 'VERIFIED_ACTIVE',
    },
    {
      requirementId: 'REQ-SAF-089',
      title: 'GNSS Signal Loss Fail-Operational Fallback',
      hazard: 'Multipath reflection or complete denial in high-bay steel warehouse / depot hall',
      operationalDomain: 'INDUSTRIAL_AUTONOMY',
      safetyMitigation: 'Autonomous degradation switch to LiDAR-SLAM + IMU + UWB depot beacons within 40ms',
      testScenario: 'SCN-DEPOT-108 (High-bay shed ingress at 12 km/h with simulated GNSS dropout)',
      validationResult: 'Cross-track error maintained under 0.065m through transition',
      rEvidenceScript: 'r/trajectory_analysis.R',
      status: 'VERIFIED_ACTIVE',
    },
    {
      requirementId: 'REQ-SAF-114',
      title: 'Articulated Trailer Jack-Knife Mitigation',
      hazard: 'High hitch articulation angle during heavy regenerative braking on wet concrete',
      operationalDomain: 'ROAD_AND_YARD',
      safetyMitigation: 'Trailer EBS differential brake modulation and hitch angle clamp at 42° (road) / 75° (yard)',
      testScenario: 'SCN-DOCK-311 (Reverse dock jackknife stress test with 34t payload)',
      validationResult: 'Hitch rate bounded to <0.08 rad/s, zero uncontrolled articulation',
      rEvidenceScript: 'r/stopping_distance_distribution.R',
      status: 'VERIFIED_ACTIVE',
    },
  ]);

  // Triggering Scenarios
  loadScenario(scenarioId: string) {
    this.activeScenarioId.set(scenarioId);
    const def = this.scenarios.find(s => s.id === scenarioId);
    if (!def) return;

    this.activeDomain.set(def.domain);
    this.selectedVehicleId.set(def.vehicleId);

    // Reset faults
    this.resetAllFaults();

    if (scenarioId === 'GNSS_FAIL_FORKLIFT') {
      this.injectFault('gnss');
      this.injectFault('forklift');
    }

    this.logEvent({
      id: `EVT-${Date.now().toString().slice(-6)}`,
      timestamp: new Date().toLocaleTimeString('en-GB') + '.' + String(Date.now() % 1000).padStart(3, '0'),
      vehicleId: def.vehicleId,
      eventType: 'MISSION_STARTED',
      severity: 'INFO',
      message: `Scenario '${def.name}' loaded. Target vehicle ${def.vehicleId}. Payload: ${def.payloadTonnes}t.`,
    });
  }

  // Interactive Failure Injection
  injectFault(type: 'gnss' | 'lidar' | 'forklift' | 'brake' | 'camera') {
    const ts = new Date().toLocaleTimeString('en-GB') + '.' + String(Date.now() % 1000).padStart(3, '0');
    const vId = this.selectedVehicleId();

    switch (type) {
      case 'gnss':
        this.faultGnssDenial.set(true);
        this.localisationMode.set('LIDAR_SLAM');
        this.telemetry.update(t => ({
          ...t,
          localisationConfidence: 0.82,
          safetyState: 'DEGRADED',
        }));
        this.logEvent({
          id: `EVT-${Date.now().toString().slice(-6)}`,
          timestamp: ts,
          vehicleId: vId,
          eventType: 'LOCALISATION_FALLBACK',
          severity: 'WARN',
          message: 'FAIL INJECTED: GNSS RTK denied (multipath). AD Drive Core switched to LiDAR-SLAM + IMU.',
        });
        break;

      case 'lidar':
        this.faultLidarBlackout.set(true);
        this.autonomyMode.set('DEGRADED_ODD');
        this.telemetry.update(t => ({
          ...t,
          perceptionConfidence: 0.74,
          speedKph: Math.min(t.speedKph, 6.0),
          safetyState: 'DEGRADED',
        }));
        this.logEvent({
          id: `EVT-${Date.now().toString().slice(-6)}`,
          timestamp: ts,
          vehicleId: vId,
          eventType: 'ODD_TRANSITION',
          severity: 'WARN',
          message: 'FAIL INJECTED: Front LiDAR blinded by steam/spray. Speed restricted to 6 km/h.',
        });
        break;

      case 'forklift':
        this.faultForkliftIntrusion.set(true);
        this.autonomyMode.set('MRM_SAFE_HALT');
        this.telemetry.update(t => ({
          ...t,
          minClearanceM: 0.95,
          speedKph: 0.0,
          safetyState: 'MRM_ACTIVE',
        }));
        this.logEvent({
          id: `EVT-${Date.now().toString().slice(-6)}`,
          timestamp: ts,
          vehicleId: vId,
          eventType: 'MRM_TRIGGERED',
          severity: 'CRIT',
          message: 'FAIL INJECTED: Forklift TRK-4081 cut-in across swept envelope. MRM Deceleration clamp executed.',
        });
        break;

      case 'brake':
        this.faultBrakeDegradation.set(true);
        this.telemetry.update(t => ({
          ...t,
          brakePadPct: 48,
          speedKph: Math.min(t.speedKph, 8.0),
          safetyState: 'CAUTION',
        }));
        this.logEvent({
          id: `EVT-${Date.now().toString().slice(-6)}`,
          timestamp: ts,
          vehicleId: vId,
          eventType: 'ODD_TRANSITION',
          severity: 'WARN',
          message: 'FAIL INJECTED: Pneumatic EBS pressure loss. Speed clamp 8 km/h enforced by Safety Supervisor.',
        });
        break;

      case 'camera':
        this.faultCameraOcclusion.set(true);
        this.telemetry.update(t => ({
          ...t,
          perceptionConfidence: 0.81,
          safetyState: 'CAUTION',
        }));
        this.logEvent({
          id: `EVT-${Date.now().toString().slice(-6)}`,
          timestamp: ts,
          vehicleId: vId,
          eventType: 'ODD_TRANSITION',
          severity: 'WARN',
          message: 'FAIL INJECTED: Camera array direct low-sun blinding. Radar/LiDAR fusion weighting elevated.',
        });
        break;
    }
  }

  resetAllFaults() {
    this.faultGnssDenial.set(false);
    this.faultLidarBlackout.set(false);
    this.faultForkliftIntrusion.set(false);
    this.faultBrakeDegradation.set(false);
    this.faultCameraOcclusion.set(false);

    this.autonomyMode.set(this.activeDomain() === 'ROAD_FREIGHT' ? 'ROAD_CRUISE' : 'YARD_AUTONOMY');
    this.localisationMode.set(this.activeDomain() === 'ROAD_FREIGHT' ? 'GNSS_RTK' : 'LIDAR_SLAM');

    this.telemetry.update(t => ({
      ...t,
      speedKph: this.activeDomain() === 'ROAD_FREIGHT' ? 76.5 : 11.8,
      localisationConfidence: 0.97,
      perceptionConfidence: 0.95,
      minClearanceM: 1.65,
      safetyState: 'NOMINAL',
      brakePadPct: 91,
    }));

    this.logEvent({
      id: `EVT-${Date.now().toString().slice(-6)}`,
      timestamp: new Date().toLocaleTimeString('en-GB') + '.' + String(Date.now() % 1000).padStart(3, '0'),
      vehicleId: this.selectedVehicleId(),
      eventType: 'ODD_TRANSITION',
      severity: 'RESOLVED',
      message: 'All injected faults cleared. Safety Supervisor re-verified nominal envelope.',
    });
  }

  logEvent(event: AutonomyEvent) {
    this.events.update(list => [event, ...list.slice(0, 49)]);
  }

  toggleSimulation() {
    this.isSimPlaying.update(v => !v);
  }

  setSpeed(speed: number) {
    this.simSpeed.set(speed);
  }

  setDomain(domain: OperationalDomain) {
    this.activeDomain.set(domain);
    if (domain === 'ROAD_FREIGHT') {
      this.autonomyMode.set('ROAD_CRUISE');
      this.localisationMode.set('GNSS_RTK');
      this.telemetry.update(t => ({
        ...t,
        speedKph: 78.5,
        hitchAngleDeg: 0.6,
        sweptWidthM: 3.2,
      }));
    } else {
      this.autonomyMode.set('YARD_AUTONOMY');
      this.localisationMode.set('LIDAR_SLAM');
      this.telemetry.update(t => ({
        ...t,
        speedKph: 11.8,
        hitchAngleDeg: 14.2,
        sweptWidthM: 4.15,
      }));
    }
  }

  runRAnalytics(modelType: string, params: Record<string, unknown>): Observable<Record<string, unknown>> {
    return this.http.post<Record<string, unknown>>('/api/v1/r-analytics/run', { modelType, params });
  }
}
