import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());
const angularApp = new AngularNodeAppEngine();

// ==============================================================================
// ALEXANDER DENNIS AUTONOMOUS FREIGHT OS — DATA MODELS & SIMULATION STATE
// ==============================================================================

export interface Vehicle {
  id: string;
  model: string;
  type: 'battery_electric_tractor' | 'rigid_freight' | 'heavy_tractor' | 'yard_tug';
  registration: string;
  status: 'ACTIVE_EN_ROUTE' | 'PRECISION_DOCKING' | 'LOADING' | 'UNLOADING' | 'CHARGING' | 'MAINTENANCE' | 'SAFETY_HOLD' | 'AVAILABLE';
  domain: 'ROAD_FREIGHT' | 'INDUSTRIAL_AUTONOMY';
  speedKph: number;
  headingDeg: number;
  socPct: number;
  payloadKg: number;
  maxGrossKg: number;
  currentFacility: string;
  activeMissionId?: string;
  autonomyMode: 'ROAD_CRUISE' | 'URBAN_CORRIDOR' | 'YARD_AUTONOMY' | 'PRECISION_DOCK' | 'DEGRADED_ODD' | 'MRM_SAFE_HALT';
  localisationMode: 'GNSS_RTK' | 'LIDAR_SLAM' | 'IMU_DEAD_RECKONING' | 'DEPOT_BEACONS';
  localisationConfidence: number;
  perceptionConfidence: number;
  sweptWidthM: number;
  hitchAngleDeg: number;
  overallLengthM: number;
  healthScore: number;
  sensors: {
    lidarFront: number;
    lidarRoof: number;
    cameraArray: number;
    radarCorner: number;
    ultrasonicYard: number;
    gnssRtk: number;
    imuCoupled: number;
  };
  components: {
    batteryTempC: number;
    motorTorqueNm: number;
    ebsBrakePadPct: number;
    steerAngleDeg: number;
    tyrePressureBar: number;
  };
}

const VEHICLE_FLEET: Vehicle[] = [
  {
    id: 'ADF800E-017',
    model: 'AD F800E (Electric 44t Tractor)',
    type: 'battery_electric_tractor',
    registration: 'SN26 ADX',
    status: 'ACTIVE_EN_ROUTE',
    domain: 'INDUSTRIAL_AUTONOMY',
    speedKph: 12.4,
    headingDeg: 142.5,
    socPct: 78.4,
    payloadKg: 31800,
    maxGrossKg: 44000,
    currentFacility: 'Alexander Dennis Manufacturing Campus (Falkirk)',
    activeMissionId: 'M-20481',
    autonomyMode: 'YARD_AUTONOMY',
    localisationMode: 'LIDAR_SLAM',
    localisationConfidence: 0.96,
    perceptionConfidence: 0.94,
    sweptWidthM: 4.15,
    hitchAngleDeg: 14.8,
    overallLengthM: 16.5,
    healthScore: 98,
    sensors: {
      lidarFront: 0.98,
      lidarRoof: 0.95,
      cameraArray: 0.92,
      radarCorner: 0.96,
      ultrasonicYard: 0.99,
      gnssRtk: 0.72,
      imuCoupled: 0.98,
    },
    components: {
      batteryTempC: 26.4,
      motorTorqueNm: 840,
      ebsBrakePadPct: 91,
      steerAngleDeg: 8.2,
      tyrePressureBar: 8.8,
    },
  },
  {
    id: 'ADF800E-004',
    model: 'AD F800E (Electric 44t Tractor)',
    type: 'battery_electric_tractor',
    registration: 'SN26 ADV',
    status: 'ACTIVE_EN_ROUTE',
    domain: 'ROAD_FREIGHT',
    speedKph: 84.0,
    headingDeg: 358.1,
    socPct: 62.0,
    payloadKg: 28400,
    maxGrossKg: 44000,
    currentFacility: 'M9 Motorway Corridor (Junction 6)',
    activeMissionId: 'M-20484',
    autonomyMode: 'ROAD_CRUISE',
    localisationMode: 'GNSS_RTK',
    localisationConfidence: 0.99,
    perceptionConfidence: 0.97,
    sweptWidthM: 3.2,
    hitchAngleDeg: 0.4,
    overallLengthM: 16.5,
    healthScore: 99,
    sensors: {
      lidarFront: 0.96,
      lidarRoof: 0.98,
      cameraArray: 0.95,
      radarCorner: 0.99,
      ultrasonicYard: 0.94,
      gnssRtk: 0.99,
      imuCoupled: 0.99,
    },
    components: {
      batteryTempC: 31.0,
      motorTorqueNm: 1250,
      ebsBrakePadPct: 88,
      steerAngleDeg: 0.2,
      tyrePressureBar: 9.0,
    },
  },
  {
    id: 'ADYARD-01',
    model: 'AD YARD-60 (Autonomous Yard Tug)',
    type: 'yard_tug',
    registration: 'SN26 YRD',
    status: 'PRECISION_DOCKING',
    domain: 'INDUSTRIAL_AUTONOMY',
    speedKph: 3.6,
    headingDeg: 270.0,
    socPct: 89.2,
    payloadKg: 18200,
    maxGrossKg: 36000,
    currentFacility: 'Regional Logistics Depot (Depot Bay 4)',
    activeMissionId: 'M-20488',
    autonomyMode: 'PRECISION_DOCK',
    localisationMode: 'DEPOT_BEACONS',
    localisationConfidence: 0.98,
    perceptionConfidence: 0.96,
    sweptWidthM: 3.8,
    hitchAngleDeg: -22.5,
    overallLengthM: 11.2,
    healthScore: 97,
    sensors: {
      lidarFront: 0.99,
      lidarRoof: 0.94,
      cameraArray: 0.91,
      radarCorner: 0.88,
      ultrasonicYard: 1.0,
      gnssRtk: 0.65,
      imuCoupled: 0.97,
    },
    components: {
      batteryTempC: 24.1,
      motorTorqueNm: 460,
      ebsBrakePadPct: 94,
      steerAngleDeg: -16.4,
      tyrePressureBar: 8.5,
    },
  },
  {
    id: 'ADF600-022',
    model: 'AD F600 (Heavy Rigid 26t)',
    type: 'rigid_freight',
    registration: 'SN26 HGV',
    status: 'LOADING',
    domain: 'INDUSTRIAL_AUTONOMY',
    speedKph: 0.0,
    headingDeg: 90.0,
    socPct: 94.5,
    payloadKg: 14500,
    maxGrossKg: 26000,
    currentFacility: 'Body Assembly Hall 2',
    activeMissionId: 'M-20490',
    autonomyMode: 'YARD_AUTONOMY',
    localisationMode: 'LIDAR_SLAM',
    localisationConfidence: 0.97,
    perceptionConfidence: 0.95,
    sweptWidthM: 3.1,
    hitchAngleDeg: 0.0,
    overallLengthM: 10.4,
    healthScore: 96,
    sensors: {
      lidarFront: 0.97,
      lidarRoof: 0.93,
      cameraArray: 0.94,
      radarCorner: 0.92,
      ultrasonicYard: 0.98,
      gnssRtk: 0.50,
      imuCoupled: 0.96,
    },
    components: {
      batteryTempC: 22.0,
      motorTorqueNm: 0,
      ebsBrakePadPct: 90,
      steerAngleDeg: 0.0,
      tyrePressureBar: 8.6,
    },
  },
  {
    id: 'ADF800-009',
    model: 'AD F800 (Heavy Diesel/HVO Tractor)',
    type: 'heavy_tractor',
    registration: 'SN26 HVO',
    status: 'ACTIVE_EN_ROUTE',
    domain: 'ROAD_FREIGHT',
    speedKph: 72.8,
    headingDeg: 215.3,
    socPct: 82.0,
    payloadKg: 34200,
    maxGrossKg: 44000,
    currentFacility: 'British Steel Scunthorpe Works Transit',
    activeMissionId: 'M-20482',
    autonomyMode: 'ROAD_CRUISE',
    localisationMode: 'GNSS_RTK',
    localisationConfidence: 0.98,
    perceptionConfidence: 0.93,
    sweptWidthM: 3.3,
    hitchAngleDeg: 2.1,
    overallLengthM: 16.5,
    healthScore: 95,
    sensors: {
      lidarFront: 0.95,
      lidarRoof: 0.94,
      cameraArray: 0.93,
      radarCorner: 0.98,
      ultrasonicYard: 0.89,
      gnssRtk: 0.98,
      imuCoupled: 0.98,
    },
    components: {
      batteryTempC: 28.5,
      motorTorqueNm: 1600,
      ebsBrakePadPct: 86,
      steerAngleDeg: 1.4,
      tyrePressureBar: 9.1,
    },
  },
  {
    id: 'ADF900E-002',
    model: 'AD F900E (High-Capacity Electric Tractor)',
    type: 'battery_electric_tractor',
    registration: 'SN26 ADZ',
    status: 'CHARGING',
    domain: 'INDUSTRIAL_AUTONOMY',
    speedKph: 0.0,
    headingDeg: 180.0,
    socPct: 41.5,
    payloadKg: 0,
    maxGrossKg: 44000,
    currentFacility: 'High-Power MCS Charging Plaza 2 (350 kW)',
    activeMissionId: undefined,
    autonomyMode: 'YARD_AUTONOMY',
    localisationMode: 'DEPOT_BEACONS',
    localisationConfidence: 0.99,
    perceptionConfidence: 0.98,
    sweptWidthM: 2.8,
    hitchAngleDeg: 0.0,
    overallLengthM: 7.2,
    healthScore: 99,
    sensors: {
      lidarFront: 0.99,
      lidarRoof: 0.99,
      cameraArray: 0.98,
      radarCorner: 0.97,
      ultrasonicYard: 0.99,
      gnssRtk: 0.85,
      imuCoupled: 0.99,
    },
    components: {
      batteryTempC: 34.2,
      motorTorqueNm: 0,
      ebsBrakePadPct: 98,
      steerAngleDeg: 0.0,
      tyrePressureBar: 9.0,
    },
  },
  {
    id: 'ADF450-011',
    model: 'AD F450 (Rigid Urban Freight 18t)',
    type: 'rigid_freight',
    registration: 'SN26 URB',
    status: 'MAINTENANCE',
    domain: 'INDUSTRIAL_AUTONOMY',
    speedKph: 0.0,
    headingDeg: 0.0,
    socPct: 85.0,
    payloadKg: 0,
    maxGrossKg: 18000,
    currentFacility: 'Vehicle Inspection Bay 3',
    activeMissionId: undefined,
    autonomyMode: 'DEGRADED_ODD',
    localisationMode: 'LIDAR_SLAM',
    localisationConfidence: 0.92,
    perceptionConfidence: 0.81,
    sweptWidthM: 2.6,
    hitchAngleDeg: 0.0,
    overallLengthM: 8.8,
    healthScore: 78,
    sensors: {
      lidarFront: 0.82,
      lidarRoof: 0.90,
      cameraArray: 0.74,
      radarCorner: 0.91,
      ultrasonicYard: 0.92,
      gnssRtk: 0.40,
      imuCoupled: 0.95,
    },
    components: {
      batteryTempC: 21.0,
      motorTorqueNm: 0,
      ebsBrakePadPct: 62,
      steerAngleDeg: 0.0,
      tyrePressureBar: 8.2,
    },
  },
  {
    id: 'ADF800E-021',
    model: 'AD F800E (Electric 44t Tractor)',
    type: 'battery_electric_tractor',
    registration: 'SN26 ADK',
    status: 'SAFETY_HOLD',
    domain: 'INDUSTRIAL_AUTONOMY',
    speedKph: 0.0,
    headingDeg: 120.0,
    socPct: 69.1,
    payloadKg: 31000,
    maxGrossKg: 44000,
    currentFacility: 'Foundry Crossing Zone B',
    activeMissionId: 'M-20485',
    autonomyMode: 'MRM_SAFE_HALT',
    localisationMode: 'LIDAR_SLAM',
    localisationConfidence: 0.89,
    perceptionConfidence: 0.92,
    sweptWidthM: 4.4,
    hitchAngleDeg: 34.2,
    overallLengthM: 16.5,
    healthScore: 92,
    sensors: {
      lidarFront: 0.94,
      lidarRoof: 0.95,
      cameraArray: 0.88,
      radarCorner: 0.95,
      ultrasonicYard: 0.97,
      gnssRtk: 0.35,
      imuCoupled: 0.96,
    },
    components: {
      batteryTempC: 29.8,
      motorTorqueNm: 0,
      ebsBrakePadPct: 89,
      steerAngleDeg: 24.5,
      tyrePressureBar: 8.9,
    },
  },
];

// Generate synthetic fleet up to 42 vehicles to fully satisfy the brief
for (let i = 9; i <= 42; i++) {
  const isElectric = i % 2 === 0;
  const isYard = i % 5 === 0;
  const statuses: Vehicle['status'][] = ['ACTIVE_EN_ROUTE', 'LOADING', 'CHARGING', 'AVAILABLE', 'PRECISION_DOCKING'];
  VEHICLE_FLEET.push({
    id: isYard ? `ADYARD-0${i}` : isElectric ? `ADF800E-0${i}` : `ADF600-0${i}`,
    model: isYard ? 'AD YARD-60 (Yard Tug)' : isElectric ? 'AD F800E (Electric 44t)' : 'AD F600 (Heavy Rigid 26t)',
    type: isYard ? 'yard_tug' : isElectric ? 'battery_electric_tractor' : 'rigid_freight',
    registration: `SN26 AD${String.fromCharCode(65 + (i % 24))}`,
    status: statuses[i % statuses.length],
    domain: isYard || i % 3 === 0 ? 'INDUSTRIAL_AUTONOMY' : 'ROAD_FREIGHT',
    speedKph: isYard ? (i % 2 === 0 ? 5.2 : 0.0) : (i % 2 === 0 ? 64.5 : 0.0),
    headingDeg: (i * 37) % 360,
    socPct: Math.round(40 + (i * 1.3) % 58),
    payloadKg: isYard ? 12000 : 24000 + (i * 350) % 15000,
    maxGrossKg: isYard ? 36000 : isElectric ? 44000 : 26000,
    currentFacility: i % 2 === 0 ? 'Alexander Dennis Manufacturing Campus' : 'Regional Freight Terminal Grangemouth',
    activeMissionId: `M-${20490 + i}`,
    autonomyMode: isYard ? 'YARD_AUTONOMY' : 'ROAD_CRUISE',
    localisationMode: isYard ? 'LIDAR_SLAM' : 'GNSS_RTK',
    localisationConfidence: 0.95 + (i % 4) * 0.01,
    perceptionConfidence: 0.93 + (i % 5) * 0.01,
    sweptWidthM: 3.4,
    hitchAngleDeg: isYard ? ((i * 3) % 25) - 12 : 1.2,
    overallLengthM: isYard ? 11.2 : 16.5,
    healthScore: 92 + (i % 8),
    sensors: {
      lidarFront: 0.96,
      lidarRoof: 0.95,
      cameraArray: 0.94,
      radarCorner: 0.97,
      ultrasonicYard: 0.98,
      gnssRtk: isYard ? 0.65 : 0.99,
      imuCoupled: 0.98,
    },
    components: {
      batteryTempC: 24.0 + (i % 6),
      motorTorqueNm: isYard ? 350 : 850,
      ebsBrakePadPct: 85 + (i % 12),
      steerAngleDeg: (i % 5) - 2,
      tyrePressureBar: 8.8,
    },
  });
}

export interface FreightMission {
  missionId: string;
  vehicleId: string;
  cargoDescription: string;
  cargoType: 'BATTERY_MODULES' | 'STEEL_COILS' | 'CHASSIS_COMPONENTS' | 'BODY_PANELS' | 'FINISHED_VEHICLES' | 'INTERMODAL_CONTAINER';
  weightTonnes: number;
  origin: string;
  destination: string;
  priority: 'CRITICAL_ASSEMBLY' | 'STANDARD_HAUL' | 'HIGH_VALUE_PARTS' | 'JUST_IN_TIME';
  deliveryWindow: string;
  estimatedArrivalMin: number;
  routeDomainSequence: string[];
  status: 'PENDING' | 'IN_TRANSIT' | 'DOCKING' | 'DISPATCHED' | 'COMPLETED';
}

const FREIGHT_MISSIONS: FreightMission[] = [
  {
    missionId: 'M-20481',
    vehicleId: 'ADF800E-017',
    cargoDescription: 'High-Density 720kWh Electric Bus Battery Modules (8 Packs)',
    cargoType: 'BATTERY_MODULES',
    weightTonnes: 31.8,
    origin: 'Alexander Dennis Manufacturing Campus (Battery Assembly)',
    destination: 'Regional Logistics Depot -> Final Assembly Hall 1',
    priority: 'CRITICAL_ASSEMBLY',
    deliveryWindow: '11:15 - 11:35 GMT',
    estimatedArrivalMin: 14,
    routeDomainSequence: ['FACTORY_GATE_2', 'INDUSTRIAL_ACCESS_RD', 'M9_MOTORWAY', 'DEPOT_APPROACH', 'DOCK_BAY_4'],
    status: 'IN_TRANSIT',
  },
  {
    missionId: 'M-20482',
    vehicleId: 'ADF800-009',
    cargoDescription: 'Rolled Structural High-Tensile Steel Coils',
    cargoType: 'STEEL_COILS',
    weightTonnes: 34.2,
    origin: 'British Steel Scunthorpe Yard 3',
    destination: 'Alexander Dennis Chassis Fabrication Hall',
    priority: 'STANDARD_HAUL',
    deliveryWindow: '13:00 - 13:45 GMT',
    estimatedArrivalMin: 42,
    routeDomainSequence: ['STEEL_RAIL_SIDING', 'A18_TRUNK_ROAD', 'M180_CORRIDOR', 'INSPECTION_GATE'],
    status: 'IN_TRANSIT',
  },
  {
    missionId: 'M-20483',
    vehicleId: 'ADF800E-004',
    cargoDescription: 'Enviro500 Complete Pre-Formed Aluminium Body Sections',
    cargoType: 'BODY_PANELS',
    weightTonnes: 16.5,
    origin: 'Sub-Assembly Works Larbert',
    destination: 'Paint & Corrosion Protection Facility Bay 2',
    priority: 'JUST_IN_TIME',
    deliveryWindow: '11:45 - 12:00 GMT',
    estimatedArrivalMin: 22,
    routeDomainSequence: ['LARBERT_LOGISTICS_PARK', 'A9_DUAL_CARRIAGEWAY', 'WEST_PLANT_GATE'],
    status: 'IN_TRANSIT',
  },
  {
    missionId: 'M-20488',
    vehicleId: 'ADYARD-01',
    cargoDescription: 'Heavy-Duty Tandem Steer Axles & Disc Braking Subassemblies',
    cargoType: 'CHASSIS_COMPONENTS',
    weightTonnes: 18.2,
    origin: 'Goods Inbound Buffer Yard',
    destination: 'Chassis Line Dock Bay 4',
    priority: 'JUST_IN_TIME',
    deliveryWindow: '11:10 - 11:20 GMT',
    estimatedArrivalMin: 4,
    routeDomainSequence: ['BUFFER_LANE_C', 'PEDESTRIAN_SAFE_CORRIDOR', 'DOCK_ALIGNMENT_4'],
    status: 'DOCKING',
  },
];

// ==============================================================================
// REST API ROUTES
// ==============================================================================

app.get('/api/v1/vehicles', (req, res) => {
  res.json({
    timestamp: new Date().toISOString(),
    totalFleetSize: VEHICLE_FLEET.length,
    activeMissionsCount: VEHICLE_FLEET.filter(v => v.status === 'ACTIVE_EN_ROUTE' || v.status === 'PRECISION_DOCKING').length,
    chargingCount: VEHICLE_FLEET.filter(v => v.status === 'CHARGING').length,
    maintenanceCount: VEHICLE_FLEET.filter(v => v.status === 'MAINTENANCE').length,
    safetyHoldCount: VEHICLE_FLEET.filter(v => v.status === 'SAFETY_HOLD').length,
    vehicles: VEHICLE_FLEET,
  });
});

app.get('/api/v1/vehicles/:id', (req, res): void => {
  const v = VEHICLE_FLEET.find(item => item.id.toLowerCase() === req.params.id.toLowerCase());
  if (!v) {
    res.status(404).json({ error: 'Vehicle not found' });
    return;
  }
  res.json(v);
  return;
});

app.get('/api/v1/missions', (req, res) => {
  res.json({
    count: FREIGHT_MISSIONS.length,
    missions: FREIGHT_MISSIONS,
  });
});

app.get('/api/v1/sensors/matrix', (req, res) => {
  res.json({
    vehicleId: 'ADF800E-017',
    matrix: [
      { objectClass: 'ELECTRIC_FORKLIFT', lidar: 0.96, camera: 0.92, radar: 0.84, ultrasonic: 0.98, fusedConfidence: 0.97, persistenceAgeSec: 14.2, trackId: 'TRK-4081' },
      { objectClass: 'PEDESTRIAN_WORKER', lidar: 0.89, camera: 0.95, radar: 0.48, ultrasonic: 0.92, fusedConfidence: 0.94, persistenceAgeSec: 8.6, trackId: 'TRK-4082' },
      { objectClass: 'PALLET_STILLAGE', lidar: 0.94, camera: 0.88, radar: 0.22, ultrasonic: 0.91, fusedConfidence: 0.91, persistenceAgeSec: 320.0, trackId: 'TRK-3920' },
      { objectClass: 'ARTICULATED_TRUCK', lidar: 0.98, camera: 0.96, radar: 0.99, ultrasonic: 0.85, fusedConfidence: 0.99, persistenceAgeSec: 42.1, trackId: 'TRK-4075' },
      { objectClass: 'AUTOMATED_DOCK_DOOR', lidar: 0.99, camera: 0.97, radar: 0.91, ultrasonic: 0.99, fusedConfidence: 0.99, persistenceAgeSec: 610.0, trackId: 'TRK-3501' },
      { objectClass: 'OVERHEAD_GANTRY_CRANE', lidar: 0.93, camera: 0.84, radar: 0.96, ultrasonic: 0.10, fusedConfidence: 0.95, persistenceAgeSec: 840.0, trackId: 'TRK-3112' },
    ],
  });
});

// R Analytical Model Engine Endpoint
app.post('/api/v1/r-analytics/run', (req, res): void => {
  const { modelType, params } = req.body || {};

  if (modelType === 'stopping_distance') {
    const mass = params?.massTonnes || 31.8;
    const speed = params?.speedKph || 45.0;
    const surface = params?.surface || 'asphalt_dry';
    const v_mps = speed / 3.6;
    const g = 9.80665;
    const mu = surface === 'asphalt_dry' ? 0.82 : surface === 'asphalt_wet' ? 0.58 : surface === 'factory_concrete' ? 0.72 : 0.45;
    const fade = 1.0 - (mass / 100) * 0.15;
    const tReact = 0.12;
    const dReact = v_mps * tReact;
    const dBrake = (v_mps * v_mps) / (2 * mu * fade * g);
    const totalDist = dReact + dBrake;

    // Distribution samples for histogram
    const histogramBins = [];
    for (let i = 0; i < 20; i++) {
      const d = totalDist * (0.88 + i * 0.015);
      const prob = Math.exp(-Math.pow(i - 8, 2) / 18);
      histogramBins.push({ distanceM: Number(d.toFixed(2)), frequency: Math.round(prob * 140) });
    }

    res.json({
      model: 'R::compute_stopping_distribution',
      parameters: { massTonnes: mass, speedKph: speed, surface },
      metrics: {
        reactionDistanceM: Number(dReact.toFixed(3)),
        brakingDistanceM: Number(dBrake.toFixed(3)),
        meanStoppingM: Number(totalDist.toFixed(3)),
        p95StoppingM: Number((totalDist * 1.14).toFixed(3)),
        p99StoppingM: Number((totalDist * 1.25).toFixed(3)),
        kineticEnergyMJ: Number((0.5 * (mass * 1000) * Math.pow(v_mps, 2) / 1e6).toFixed(2)),
      },
      distribution: histogramBins,
    });
    return;
  }

  if (modelType === 'energy_prediction') {
    const distanceKm = params?.distanceKm || 120.0;
    const mass = params?.massTonnes || 38.5;
    const speed = params?.speedKph || 68.0;
    const gradeM = params?.elevationM || 450.0;

    const totalMass = mass * 1000;
    const v = speed / 3.6;
    const fRoll = totalMass * 9.81 * 0.0055;
    const fAero = 0.5 * 1.225 * 0.52 * 9.2 * Math.pow(v, 2);
    const fGrade = totalMass * 9.81 * Math.sin(Math.atan(gradeM / (distanceKm * 1000)));
    const totalForce = fRoll + fAero + fGrade;
    const mechKwh = (totalForce * distanceKm * 1000) / 3.6e6;
    const durationH = distanceKm / speed;
    const auxKwh = 1.8 * durationH;
    const regenKwh = (totalMass * 9.81 * gradeM * 0.45 * 0.62) / 3.6e6;
    const netKwh = (mechKwh / 0.91) + auxKwh - regenKwh;

    res.json({
      model: 'R::calculate_energy_prediction',
      metrics: {
        totalNetEnergyKwh: Number(netKwh.toFixed(2)),
        specificKwhPerKm: Number((netKwh / distanceKm).toFixed(3)),
        regenRecuperatedKwh: Number(regenKwh.toFixed(2)),
        auxiliaryAutonomyKwh: Number(auxKwh.toFixed(2)),
        batteryPackKwh: 720.0,
        socDepletionPct: Number(((netKwh / 720) * 100).toFixed(1)),
        projectedArrivalSocPct: Number((100 - (netKwh / 720) * 100).toFixed(1)),
      },
    });
    return;
  }

  if (modelType === 'yard_risk_monte_carlo') {
    const obstacle = params?.obstacle || 'electric_forklift';
    res.json({
      model: 'R::simulate_yard_hazard_distribution',
      obstacle,
      runs: 1000,
      metrics: {
        meanTtcSec: 4.82,
        minTtcObservedSec: 1.48,
        p05TtcSec: 2.15,
        meanClearanceM: 1.84,
        p01ClearanceM: 0.72,
        interventionRatePct: 4.2,
        zeroCollisionsConfirmed: true,
      },
      clearanceHistogram: [
        { bin: '0.5 - 1.0 m', count: 18 },
        { bin: '1.0 - 1.5 m', count: 142 },
        { bin: '1.5 - 2.0 m', count: 486 },
        { bin: '2.0 - 2.5 m', count: 260 },
        { bin: '2.5 - 3.0 m+', count: 94 },
      ],
    });
    return;
  }

  res.status(400).json({ error: 'Unknown R model requested' });
  return;
});

// Safety Case and Evidence Explorer API
app.get('/api/v1/safety/cases', (req, res) => {
  res.json({
    standard: 'UK Autonomous Goods Vehicles Code of Practice & ISO 26262 ASIL-D',
    cases: [
      {
        requirementId: 'REQ-SAF-042',
        title: 'Factory-Floor Dynamic Obstacle Clearance Boundary',
        hazard: 'Forklift or worker cut-in across articulated trailer swept envelope',
        operationalDomain: 'INDUSTRIAL_AUTONOMY',
        safetyMitigation: 'AD Drive Core dynamic swept path expansion + 1.2s MRM deceleration halt',
        testScenario: 'SCN-YARD-402 (Forklift blind corner emergence at 8 km/h)',
        validationResult: '100% Zero-Contact over 5,000 deterministic Monte Carlo passes',
        rEvidenceScript: 'r/risk_analysis.R',
        status: 'VERIFIED_ACTIVE',
      },
      {
        requirementId: 'REQ-SAF-089',
        title: 'GNSS Signal Loss Fail-Operational Fallback',
        hazard: 'Multipath reflection or complete denial in high-bay steel warehouse / depot hall',
        operationalDomain: 'INDUSTRIAL_AUTONOMY',
        safetyMitigation: 'Autonomous degradation switch to LiDAR-SLAM + IMU + UWB depot beacons within 40ms',
        testScenario: 'SCN-DEPOT-108 (High-bay shed ingress at 12 km/h with simulated GNSS dropout)',
        validationResult: 'Cross-track error maintained under 0.065m through transition',
        rEvidenceScript: 'r/trajectory_analysis.R',
        status: 'VERIFIED_ACTIVE',
      },
      {
        requirementId: 'REQ-SAF-114',
        title: 'Articulated Trailer Jack-Knife Mitigation',
        hazard: 'High hitch articulation angle during heavy regenerative braking on wet concrete',
        operationalDomain: 'ROAD_AND_YARD',
        safetyMitigation: 'Trailer EBS differential brake modulation and hitch angle clamp at 42° (road) / 75° (yard)',
        testScenario: 'SCN-DOCK-311 (Reverse dock jackknife stress test with 34t payload)',
        validationResult: 'Hitch rate bounded to <0.08 rad/s, zero uncontrolled articulation',
        rEvidenceScript: 'r/stopping_distance_distribution.R',
        status: 'VERIFIED_ACTIVE',
      },
    ],
  });
});

// ==============================================================================
// ANGULAR SSR MIDDLEWARE
// ==============================================================================

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);

