#!/usr/bin/env Rscript
# ==============================================================================
# ALEXANDER DENNIS AUTONOMOUS FREIGHT OS — R RESEARCH & QUANTITATIVE BRAIN
# Module: Trajectory Deviation & Swept-Path Clearance Uncertainty
# Evaluates cross-track errors, trailer off-tracking, and swept path compliance
# ==============================================================================

evaluate_trajectory_tracking <- function(
  planned_curvature_seq,
  target_velocity_mps,
  wheelbase_m = 3.8,
  trailer_length_m = 7.8,
  sensor_noise_sigma = 0.03
) {
  n_points <- length(planned_curvature_seq)
  
  # Simulate lateral error accumulation under Kalman state-space estimator
  cross_track_errors <- numeric(n_points)
  trailer_yaw_errors <- numeric(n_points)
  lateral_accel_mps2 <- numeric(n_points)
  
  current_lateral_err <- 0.0
  current_trailer_err <- 0.0
  
  for (i in seq_len(n_points)) {
    kappa <- planned_curvature_seq[i]
    v <- target_velocity_mps[i]
    
    # Kinematic lateral acceleration a_lat = v^2 * kappa
    a_lat <- (v^2) * kappa
    lateral_accel_mps2[i] <- a_lat
    
    # Tyre slip angle approximation alpha ~ (m * a_lat) / (C_cornering)
    slip_induced_error <- 0.008 * a_lat
    
    # Sensor noise perturbation
    sensor_drift <- rnorm(1, mean = 0, sd = sensor_noise_sigma)
    
    # Closed-loop Stanley / Pure Pursuit steering controller error dynamics
    current_lateral_err <- 0.88 * current_lateral_err + slip_induced_error + sensor_drift
    cross_track_errors[i] <- current_lateral_err
    
    # Articulated trailer geometric off-tracking delay
    current_trailer_err <- 0.92 * current_trailer_err + 0.15 * (trailer_length_m * kappa) + rnorm(1, 0, 0.01)
    trailer_yaw_errors[i] <- current_trailer_err
  }
  
  list(
    max_cross_track_error_m = round(max(abs(cross_track_errors)), 4),
    mean_cross_track_error_m = round(mean(abs(cross_track_errors)), 4),
    p95_cross_track_error_m = round(quantile(abs(cross_track_errors), 0.95)[[1]], 4),
    max_trailer_offtracking_m = round(max(abs(trailer_yaw_errors)), 4),
    max_lateral_accel_g = round(max(abs(lateral_accel_mps2)) / 9.80665, 3),
    cross_track_profile = cross_track_errors,
    trailer_profile = trailer_yaw_errors
  )
}
