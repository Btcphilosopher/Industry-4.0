#!/usr/bin/env Rscript
# ==============================================================================
# ALEXANDER DENNIS AUTONOMOUS FREIGHT OS — R RESEARCH & QUANTITATIVE BRAIN
# Module: Depot Autonomous Throughput & Bay Turnaround Queueing Model
# Models M/M/c bay allocation, dwell times, and charger congestion
# ==============================================================================

simulate_depot_turnaround <- function(
  arrival_rate_per_hour = 6.5,
  num_loading_bays = 8,
  mean_dock_dwell_mins = 28.0,
  sd_dock_dwell_mins = 6.0,
  simulation_hours = 24,
  seed = 101
) {
  set.seed(seed)
  total_arrivals <- rpois(1, arrival_rate_per_hour * simulation_hours)
  
  interarrival_mins <- rexp(total_arrivals, rate = arrival_rate_per_hour / 60)
  arrival_times <- cumsum(interarrival_mins)
  
  service_times <- rnorm(total_arrivals, mean = mean_dock_dwell_mins, sd = sd_dock_dwell_mins)
  service_times <- pmax(12.0, service_times)
  
  # Discrete event bay allocation
  bay_free_time <- rep(0.0, num_loading_bays)
  queue_wait_times <- numeric(total_arrivals)
  departure_times <- numeric(total_arrivals)
  
  for (i in seq_len(total_arrivals)) {
    arr <- arrival_times[i]
    # Find earliest available dock
    earliest_dock <- which.min(bay_free_time)
    start_service <- max(arr, bay_free_time[earliest_dock])
    wait_time <- start_service - arr
    
    queue_wait_times[i] <- wait_time
    dep <- start_service + service_times[i]
    departure_times[i] <- dep
    bay_free_time[earliest_dock] <- dep
  }
  
  list(
    total_missions_processed = total_arrivals,
    num_loading_bays = num_loading_bays,
    mean_wait_time_mins = round(mean(queue_wait_times), 2),
    p95_wait_time_mins = round(quantile(queue_wait_times, 0.95)[[1]], 2),
    max_wait_time_mins = round(max(queue_wait_times), 2),
    bay_utilisation_pct = round((sum(service_times) / (num_loading_bays * simulation_hours * 60)) * 100, 1),
    dock_turnover_per_bay_day = round(total_arrivals / num_loading_bays, 1)
  )
}
