#!/usr/bin/env Rscript
# ==============================================================================
# ALEXANDER DENNIS AUTONOMOUS FREIGHT OS — R RESEARCH & QUANTITATIVE BRAIN
# Module: Stopping Distance Distributions under Heavy Vehicle Dynamic Loads
# SOTIF / ISO 26262 Brake Deceleration Validation
# ==============================================================================

compute_stopping_distribution <- function(
  vehicle_mass_tonnes = 32.0,
  speed_kph = 50.0,
  road_surface = c("asphalt_dry", "asphalt_wet", "factory_concrete", "steelworks_gravel"),
  reaction_time_autonomous_sec = 0.12, # AD Drive Core electronic brake request
  iterations = 1000,
  seed = 42
) {
  set.seed(seed)
  road_surface <- match.arg(road_surface)
  
  # Surface friction coefficient distributions (mu ~ Truncated Normal)
  mu_params <- list(
    asphalt_dry = c(mean = 0.82, sd = 0.04, min = 0.70, max = 0.95),
    asphalt_wet = c(mean = 0.58, sd = 0.06, min = 0.42, max = 0.70),
    factory_concrete = c(mean = 0.72, sd = 0.05, min = 0.55, max = 0.82),
    steelworks_gravel = c(mean = 0.45, sd = 0.08, min = 0.30, max = 0.60)
  )[[road_surface]]
  
  # Sample friction coefficients
  mu_samples <- rnorm(iterations, mean = mu_params["mean"], sd = mu_params["sd"])
  mu_samples <- pmax(mu_params["min"], pmin(mu_params["max"], mu_samples))
  
  # Payload inertia factor (heavier vehicle shifts brake thermal curve)
  # Standard 44-tonne tractor-trailer EBS brake fade coefficient
  fade_factor <- 1.0 - (vehicle_mass_tonnes / 100.0) * 0.15
  
  # Conversion: kph to m/s
  v0_mps <- speed_kph / 3.6
  g <- 9.80665
  
  # Perception + CAN Bus actuation delay (log-normal distribution)
  t_react_samples <- rlnorm(iterations, meanlog = log(reaction_time_autonomous_sec), sdlog = 0.15)
  d_reaction <- v0_mps * t_react_samples
  
  # Physical braking distance: d = v^2 / (2 * mu * g * fade_factor)
  effective_mu <- mu_samples * fade_factor
  d_braking <- (v0_mps^2) / (2 * effective_mu * g)
  
  total_stopping_distance <- d_reaction + d_braking
  
  # Summary Statistics
  summary_metrics <- list(
    vehicle_mass_tonnes = vehicle_mass_tonnes,
    initial_speed_kph = speed_kph,
    road_surface = road_surface,
    mean_stopping_m = round(mean(total_stopping_distance), 3),
    median_stopping_m = round(median(total_stopping_distance), 3),
    p95_stopping_m = round(quantile(total_stopping_distance, 0.95)[[1]], 3),
    p99_stopping_m = round(quantile(total_stopping_distance, 0.99)[[1]], 3),
    reaction_delay_mean_m = round(mean(d_reaction), 3),
    kinetic_energy_megajoules = round(0.5 * (vehicle_mass_tonnes * 1000) * (v0_mps^2) / 1e6, 2)
  )
  
  return(list(metrics = summary_metrics, samples = total_stopping_distance))
}

# Example CLI test
if (!interactive()) {
  res_dry <- compute_stopping_distribution(vehicle_mass_tonnes = 31.8, speed_kph = 45.0, road_surface = "asphalt_dry")
  res_factory <- compute_stopping_distribution(vehicle_mass_tonnes = 31.8, speed_kph = 15.0, road_surface = "factory_concrete")
  cat("[R Model Output] Dry Asphalt 45 kph P95 Stopping Dist:", res_dry$metrics$p95_stopping_m, "m\n")
  cat("[R Model Output] Factory Floor 15 kph P95 Stopping Dist:", res_factory$metrics$p95_stopping_m, "m\n")
}
