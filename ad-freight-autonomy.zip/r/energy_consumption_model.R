#!/usr/bin/env Rscript
# ==============================================================================
# ALEXANDER DENNIS AUTONOMOUS FREIGHT OS — R RESEARCH & QUANTITATIVE BRAIN
# Module: Heavy Electric Vehicle Energy & State-of-Charge Dynamics
# Models 720 kWh battery powertrain, regenerative braking, gradient & mass
# ==============================================================================

calculate_energy_prediction <- function(
  distance_km = 120.0,
  gross_mass_tonnes = 38.5,
  avg_speed_kph = 68.0,
  elevation_gain_m = 450.0,
  ambient_temp_celsius = 11.0,
  wind_head_component_kph = 15.0
) {
  # Physical constants
  g <- 9.80665
  rho_air <- 1.225 # kg/m^3
  cd_drag <- 0.52   # Aerodynamic drag coefficient for British articulated freight
  frontal_area_m2 <- 9.2
  c_rr <- 0.0055   # Rolling resistance coefficient on UK asphalt
  
  total_mass_kg <- gross_mass_tonnes * 1000.0
  v_mps <- avg_speed_kph / 3.6
  v_air_mps <- (avg_speed_kph + wind_head_component_kph) / 3.6
  
  # Rolling resistance force (N)
  f_roll <- total_mass_kg * g * c_rr
  
  # Aerodynamic drag force (N)
  f_aero <- 0.5 * rho_air * cd_drag * frontal_area_m2 * (v_air_mps^2)
  
  # Grade resistance force average
  gradient_rad <- atan(elevation_gain_m / (distance_km * 1000))
  f_grade <- total_mass_kg * g * sin(gradient_rad)
  
  # Total mechanical tractive force (N)
  f_total <- f_roll + f_aero + f_grade
  
  # Mechanical energy required (kWh)
  distance_m <- distance_km * 1000.0
  mechanical_kwh <- (f_total * distance_m) / 3.6e6
  
  # Powertrain efficiency (inverter + dual permanent magnet electric motors)
  powertrain_eff <- 0.91
  
  # HVAC & Auxiliary autonomy computing load (AD Drive Core dual rack: ~1.8 kW)
  duration_hours <- distance_km / avg_speed_kph
  aux_kwh <- (1.8 + max(0, (20.0 - ambient_temp_celsius) * 0.15)) * duration_hours
  
  # Regenerative braking energy recuperation on descents (approx 62% recovery)
  regen_kwh <- (total_mass_kg * g * elevation_gain_m * 0.45 * 0.62) / 3.6e6
  
  net_battery_kwh <- (mechanical_kwh / powertrain_eff) + aux_kwh - regen_kwh
  specific_consumption_kwh_per_km <- net_battery_kwh / distance_km
  
  list(
    gross_mass_tonnes = gross_mass_tonnes,
    distance_km = distance_km,
    total_energy_kwh = round(net_battery_kwh, 2),
    specific_consumption_kwh_per_km = round(specific_consumption_kwh_per_km, 3),
    regen_recuperation_kwh = round(regen_kwh, 2),
    auxiliary_autonomy_load_kwh = round(aux_kwh, 2),
    battery_pack_capacity_kwh = 720.0,
    projected_soc_drop_pct = round((net_battery_kwh / 720.0) * 100.0, 1),
    estimated_arrival_soc_pct = round(100.0 - ((net_battery_kwh / 720.0) * 100.0), 1)
  )
}
