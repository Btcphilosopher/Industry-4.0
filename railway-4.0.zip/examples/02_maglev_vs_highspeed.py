"""
Example 2: Maglev 500 vs High-Speed 350 Infrastructure Comparison
"""

from railway4.python.maglev.maglev_engine import MaglevEngine
from railway4.python.cost.cost_engine import CostEngine, CarbonEngine

def run_comparison():
    print("=== Maglev 500 vs High-Speed 350 Infrastructure Evaluator ===")
    
    # High-Speed 350
    hs_cost = CostEngine.calculate_project_capex(route_length_km=250.0, cut_fill_m3=23e6, bridge_count=12, tunnel_count=4, station_count=10)
    hs_carbon = CarbonEngine.calculate_emissions(route_length_km=250.0, cut_fill_m3=23e6, steel_tonnes=60000, concrete_m3=450000)
    
    # Maglev
    mag = MaglevEngine(technology_type="TRANSRAPID_EMS", target_speed_kmh=500.0)
    mag_infra = mag.compute_maglev_infrastructure_demand(route_length_km=218.0, elevated_pct=88.0)
    
    print("\n--- High-Speed 350 Rail ---")
    print(f"Total CAPEX: £{hs_cost['total_capex_gbp']:,.2f}")
    print(f"Embodied Carbon: {hs_carbon['total_project_tco2e']:,.1f} tCO2e")
    
    print("\n--- Maglev 500 Transrapid ---")
    print(f"Total CAPEX: £{mag_infra['capex_breakdown_gbp']['total_capex_gbp']:,.2f}")
    print(f"Elevated Guideway: {mag_infra['elevated_guideway_km']} km ({mag_infra['guideway_piers_count']} piers)")
    print(f"Power Substations: {mag_infra['power_substations_count']}")

if __name__ == "__main__":
    run_comparison()
