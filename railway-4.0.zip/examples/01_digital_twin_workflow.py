"""
Example 1: RAILWAY 4.0 Digital Twin End-to-End Workflow
"""

from railway4.python.digital_twin.registry import DigitalTwinRegistry
from railway4.python.digital_twin.models import Asset, AssetType, ConstructionState
from railway4.python.telemetry.telemetry_engine import ConstructionSimulator
from railway4.python.machine_learning.ml_engine import MachineLearningEngine

def run_example():
    print("=== RAILWAY 4.0 Digital Twin Workflow Example ===")
    registry = DigitalTwinRegistry("PROJ-DEMO-2026")
    
    # 1. Register assets
    rail = Asset("RL-01", "Section 1 Rail Track", AssetType.RAIL_SECTION, 0.0, 25.0, [[52.0, -1.5, 100.0]], cost_gbp=15_000_000)
    bridge = Asset("BR-01", "Avon Viaduct Bridge", AssetType.BRIDGE, 25.0, 25.8, [[52.02, -1.5, 115.0]], cost_gbp=32_000_000)
    registry.add_asset(rail)
    registry.add_asset(bridge)
    
    # 2. Simulate 60 Days
    simulator = ConstructionSimulator(registry)
    sim_res = simulator.simulate_days(60)
    print(f"Simulated 60 Days. Completed Assets: {sim_res['project_status']['completed_assets']}")
    
    # 3. Predict ML productivity
    ml = MachineLearningEngine()
    prod = ml.predict_productivity(machine_count=8, weather_index=0.1, ground_condition_index=1.5)
    print(f"Forecast Earthwork Productivity: {prod['forecast_m3_per_day']} m³/day")

if __name__ == "__main__":
    run_example()
