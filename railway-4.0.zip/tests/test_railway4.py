"""
Standard Library Unit Tests for Railway 4.0 Architecture
"""

import unittest
from railway4.python.core.units import Quantity, EngineeringUnit, assert_safety_boundary
from railway4.silicaflux import GeometryKernel, SilicaVector, SilicaMatrix, TerrainKernel, EarthworkKernel
from railway4.python.digital_twin.models import Asset, AssetType, ConstructionState
from railway4.python.digital_twin.registry import DigitalTwinRegistry

class TestRailway4(unittest.TestCase):

    def test_unit_conversions(self):
        q_km = Quantity(250.0, EngineeringUnit.KILOMETER)
        q_m = q_km.to(EngineeringUnit.METER)
        self.assertEqual(q_m.value, 250000.0)

        q_speed = Quantity(360.0, EngineeringUnit.KM_PER_HOUR)
        q_m_s = q_speed.to(EngineeringUnit.METER_PER_SEC)
        self.assertEqual(q_m_s.value, 100.0)

    def test_safety_boundary(self):
        with self.assertRaises(PermissionError):
            assert_safety_boundary("AUTONOMOUS_TRAIN_CONTROL")

    def test_silicaflux_matrix_solver(self):
        A = SilicaMatrix.from_list([
            [2.0, 1.0],
            [1.0, 3.0]
        ])
        b = [8.0, 14.0]
        x = A.solve_linear_system(b)
        self.assertAlmostEqual(x[0], 2.0, places=3)
        self.assertAlmostEqual(x[1], 4.0, places=3)

    def test_cant_calculation(self):
        res = GeometryKernel.calculate_cant(radius_m=4000.0, speed_kmh=350.0)
        self.assertGreater(res["equilibrium_cant_mm"], 0)
        self.assertLessEqual(res["applied_cant_mm"], 160.0)

    def test_earthwork_cut_fill(self):
        g = [[10.0, 12.0], [10.0, 12.0]]
        d = [[8.0, 8.0], [8.0, 8.0]] # Ground is higher -> cut
        vol = EarthworkKernel.compute_grid_cut_fill(g, d, cell_size=10.0)
        self.assertEqual(vol["cut_volume_m3"], 1200.0)
        self.assertEqual(vol["fill_volume_m3"], 0.0)

    def test_digital_twin_state_machine(self):
        reg = DigitalTwinRegistry("TEST-PROJ")
        asset = Asset(
            asset_id="BRG-99",
            name="Test Bridge",
            asset_type=AssetType.BRIDGE,
            start_chainage_km=10.0,
            end_chainage_km=10.2,
            coordinates=[[52.0, -1.5, 100.0]]
        )
        reg.add_asset(asset)
        self.assertEqual(asset.construction_state, ConstructionState.DESIGNED)
        reg.transition_asset_state("BRG-99", ConstructionState.CONSTRUCTION, "TestUser")
        self.assertEqual(asset.construction_state, ConstructionState.CONSTRUCTION)
        self.assertEqual(len(asset.state_history), 1)

if __name__ == "__main__":
    unittest.main()
