import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'RAILWAY 4.0 - Computational Digital Twin & Railway Infrastructure Engine',
  description: 'Enterprise-grade computational digital twin for railway design, construction, optimization, machine learning and high-performance simulation.',
  openGraph: {
    title: 'RAILWAY 4.0 - Computational Digital Twin',
    description: 'Enterprise-grade computational digital twin for railway design, construction, optimization, machine learning and high-performance simulation.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'RAILWAY 4.0 - Computational Digital Twin',
    description: 'Enterprise-grade computational digital twin for railway design, construction, optimization, machine learning and high-performance simulation.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
