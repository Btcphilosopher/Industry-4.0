import { NextRequest, NextResponse } from "next/server";
import { execSync } from "child_process";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const action = body.action || "report";

    if (action === "cli") {
      const command = body.command || "report";
      try {
        const stdout = execSync(`python3 -m railway4.python.cli ${command}`, {
          encoding: "utf-8",
          cwd: process.cwd()
        });
        return NextResponse.json({ success: true, output: stdout });
      } catch (err: any) {
        return NextResponse.json({ success: false, error: err.message || String(err) }, { status: 500 });
      }
    }

    if (action === "report") {
      const stdout = execSync("python3 -m railway4.python.cli report", { encoding: "utf-8", cwd: process.cwd() });
      const parsed = JSON.parse(stdout.replace(/^[^{]*/, ""));
      return NextResponse.json({ success: true, data: parsed });
    }

    if (action === "simulate") {
      const days = body.days || 30;
      const stdout = execSync(`python3 -m railway4.python.cli simulate --days ${days}`, { encoding: "utf-8", cwd: process.cwd() });
      const parsed = JSON.parse(stdout.replace(/^[^{]*/, ""));
      return NextResponse.json({ success: true, data: parsed });
    }

    if (action === "optimise") {
      const stdout = execSync("python3 -m railway4.python.cli optimise", { encoding: "utf-8", cwd: process.cwd() });
      const parsed = JSON.parse(stdout.replace(/^[^[]*/, ""));
      return NextResponse.json({ success: true, data: parsed });
    }

    if (action === "forecast") {
      const stdout = execSync("python3 -m railway4.python.cli forecast", { encoding: "utf-8", cwd: process.cwd() });
      const parsed = JSON.parse(stdout.replace(/^[^{]*/, ""));
      return NextResponse.json({ success: true, data: parsed });
    }

    return NextResponse.json({ success: false, error: "Unknown action" }, { status: 400 });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
