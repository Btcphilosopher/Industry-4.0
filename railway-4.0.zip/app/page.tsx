'use client';

import React, { useState, useEffect } from 'react';
import { 
  Train, 
  Cpu, 
  Activity, 
  Layers, 
  Sliders, 
  Terminal as TerminalIcon, 
  ShieldCheck, 
  Zap, 
  Compass, 
  TrendingUp, 
  AlertTriangle, 
  Play, 
  RotateCcw, 
  CheckCircle2, 
  Clock, 
  BarChart3, 
  HardHat, 
  FileText,
  MapPin,
  Flame,
  Globe
} from 'lucide-react';

export default function Railway4App() {
  const [activeTab, setActiveTab] = useState<'twin' | 'silicaflux' | 'optimise' | 'simulator' | 'maglev' | 'ml' | 'cli' | 'audit'>('twin');
  const [reportData, setReportData] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);
  
  // Simulation State
  const [simDays, setSimDays] = useState<number>(30);
  const [simResults, setSimResults] = useState<any>(null);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);

  // Optimiser State
  const [optWeights, setOptWeights] = useState({ TIME: 0.35, COST: 0.30, CARBON: 0.20, EARTHWORK: 0.15 });
  const [optCandidates, setOptCandidates] = useState<any[]>([]);

  // ML & Telemetry State
  const [mlData, setMlData] = useState<any>(null);

  // CLI State
  const [cliCommand, setCliCommand] = useState<string>('report');
  const [cliOutput, setCliOutput] = useState<string>('RAILWAY 4.0 CLI v4.0.0\nType a command or click quick action buttons below...\n');
  const [isExecutingCli, setIsExecutingCli] = useState<boolean>(false);

  // Selected Asset State
  const [selectedAsset, setSelectedAsset] = useState<any>(null);

  // Initial Load
  useEffect(() => {
    fetchReport();
    fetchForecast();
    fetchOptimization();
  }, []);

  const fetchReport = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/railway', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'report' })
      });
      const data = await res.json();
      if (data.success) {
        setReportData(data.data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const fetchForecast = async () => {
    try {
      const res = await fetch('/api/railway', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'forecast' })
      });
      const data = await res.json();
      if (data.success) {
        setMlData(data.data);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchOptimization = async () => {
    try {
      const res = await fetch('/api/railway', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'optimise' })
      });
      const data = await res.json();
      if (data.success) {
        setOptCandidates(data.data);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleRunSimulation = async (days: number) => {
    setIsSimulating(true);
    try {
      const res = await fetch('/api/railway', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'simulate', days })
      });
      const data = await res.json();
      if (data.success) {
        setSimResults(data.data);
        fetchReport(); // Refresh twin stats
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsSimulating(false);
    }
  };

  const handleRunCli = async (cmdToRun?: string) => {
    const cmd = cmdToRun || cliCommand;
    setIsExecutingCli(true);
    setCliOutput(prev => prev + `\n$ railway4 ${cmd}\nExecuting SilicaFlux kernels & Python orchestration...\n`);
    try {
      const res = await fetch('/api/railway', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'cli', command: cmd })
      });
      const data = await res.json();
      if (data.success) {
        setCliOutput(prev => prev + data.output + '\n----------------------------------------\n');
      } else {
        setCliOutput(prev => prev + `Error: ${data.error}\n----------------------------------------\n`);
      }
    } catch (e: any) {
      setCliOutput(prev => prev + `Execution Failed: ${e.message}\n----------------------------------------\n`);
    } finally {
      setIsExecutingCli(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans flex flex-col selection:bg-cyan-500 selection:text-slate-950">
      
      {/* HEADER BAR */}
      <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur-md sticky top-0 z-50 px-6 py-3.5 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-gradient-to-tr from-cyan-600 to-blue-600 rounded-xl shadow-lg shadow-cyan-950/50 flex items-center justify-center border border-cyan-400/30">
            <Train className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight text-white font-mono">RAILWAY 4.0</h1>
              <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800/80 font-mono font-medium">
                v4.0.0 Enterprise
              </span>
            </div>
            <p className="text-xs text-slate-400 flex items-center gap-2 mt-0.5">
              <span>Python 3.13 Orchestration</span>
              <span className="text-slate-600">•</span>
              <span className="text-cyan-400 font-mono">SilicaFlux SIMD Acceleration</span>
            </p>
          </div>
        </div>

        {/* Top Summary Metrics */}
        {reportData && (
          <div className="hidden lg:flex items-center gap-6 bg-slate-950/60 px-4 py-2 rounded-lg border border-slate-800/80 text-xs font-mono">
            <div>
              <span className="text-slate-400 block text-[10px]">CORRIDOR LENGTH</span>
              <span className="font-semibold text-white text-sm">250.0 km</span>
            </div>
            <div className="w-px h-6 bg-slate-800" />
            <div>
              <span className="text-slate-400 block text-[10px]">TOTAL CAPEX</span>
              <span className="font-semibold text-cyan-400 text-sm">£{(reportData.capex.total_capex_gbp / 1e9).toFixed(2)}B</span>
            </div>
            <div className="w-px h-6 bg-slate-800" />
            <div>
              <span className="text-slate-400 block text-[10px]">EMBODIED CARBON</span>
              <span className="font-semibold text-emerald-400 text-sm">{(reportData.carbon.total_project_tco2e).toLocaleString()} tCO2e</span>
            </div>
            <div className="w-px h-6 bg-slate-800" />
            <div>
              <span className="text-slate-400 block text-[10px]">DIGITAL TWIN PROGRESS</span>
              <span className="font-semibold text-amber-400 text-sm">{reportData.digital_twin.progress_percent}% Complete</span>
            </div>
          </div>
        )}

        <div className="flex items-center gap-2">
          <button 
            onClick={fetchReport}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors border border-slate-700/60"
            title="Refresh Digital Twin Data"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-950/60 border border-emerald-800/80 text-emerald-400 text-xs font-mono">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>TWIN ONLINE</span>
          </div>
        </div>
      </header>

      {/* NAVIGATION TABS */}
      <nav className="border-b border-slate-800 bg-slate-900/50 px-6 overflow-x-auto flex items-center gap-1 scrollbar-none">
        {[
          { id: 'twin', label: 'Digital Twin & GIS Corridor', icon: MapPin },
          { id: 'silicaflux', label: 'SilicaFlux Execution Hub', icon: Zap },
          { id: 'optimise', label: 'Alignment & Pareto Optimiser', icon: Sliders },
          { id: 'simulator', label: 'Discrete Event Simulator', icon: Play },
          { id: 'maglev', label: 'Maglev vs Steel Infrastructure', icon: Train },
          { id: 'ml', label: 'ML & Fleet Telemetry', icon: Activity },
          { id: 'cli', label: 'CLI & Python Terminal', icon: TerminalIcon },
          { id: 'audit', label: 'Audit & Safety Logs', icon: ShieldCheck },
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-3 text-xs font-medium font-mono whitespace-nowrap border-b-2 transition-all ${
                isActive 
                  ? 'border-cyan-400 text-cyan-400 bg-cyan-950/30' 
                  : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-400' : 'text-slate-500'}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </nav>

      {/* MAIN CONTENT AREA */}
      <main className="flex-1 p-6 max-w-7xl w-full mx-auto space-y-6">

        {/* TAB 1: DIGITAL TWIN & GIS CORRIDOR */}
        {activeTab === 'twin' && (
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/80 p-5 rounded-2xl border border-slate-800 shadow-xl">
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <Globe className="w-5 h-5 text-cyan-400" />
                  Trans-Britannia 250km High-Speed & Freight Corridor Digital Twin
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Full 250km stateful digital twin containing 26 primary infrastructure assets, 10 stations, 12 bridges, and 4 twin-bore tunnels.
                </p>
              </div>
              {reportData && (
                <div className="flex items-center gap-3">
                  <div className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono">
                    <span className="text-slate-400">Total Assets: </span>
                    <span className="text-white font-bold">{reportData.digital_twin.total_assets}</span>
                  </div>
                  <div className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono">
                    <span className="text-slate-400">Active Work Zones: </span>
                    <span className="text-amber-400 font-bold">{reportData.digital_twin.in_progress_assets}</span>
                  </div>
                </div>
              )}
            </div>

            {/* Visual 2D Corridor Chainage Line */}
            <div className="bg-slate-900/90 p-6 rounded-2xl border border-slate-800 space-y-4">
              <div className="flex items-center justify-between text-xs font-mono text-slate-400">
                <span className="flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-cyan-400" />
                  London West Hub (0.0 km)
                </span>
                <span>Chainage Alignment Profile (250 km)</span>
                <span className="flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-emerald-400" />
                  Stafford North Hub (250.0 km)
                </span>
              </div>

              {/* Chainage Bar */}
              <div className="relative h-12 bg-slate-950 rounded-xl border border-slate-800 overflow-hidden flex items-center px-2">
                <div className="absolute inset-0 bg-gradient-to-r from-cyan-950/40 via-blue-950/20 to-emerald-950/40 opacity-50" />
                
                {/* Station Markers */}
                {[0, 28.5, 54, 82, 112.5, 142, 168, 195, 222, 250].map((km, idx) => (
                  <div 
                    key={idx}
                    style={{ left: `${(km / 250) * 96 + 2}%` }}
                    className="absolute -translate-x-1/2 flex flex-col items-center group cursor-pointer"
                    onClick={() => setSelectedAsset({ type: 'Station', name: `Station ${idx+1}`, km })}
                  >
                    <div className="w-3 h-3 rounded-full bg-cyan-400 border-2 border-slate-950 shadow-md group-hover:scale-125 transition-transform" />
                    <span className="text-[10px] font-mono text-slate-400 group-hover:text-cyan-300 mt-1 opacity-80 group-hover:opacity-100">
                      {km}km
                    </span>
                  </div>
                ))}

                {/* Major Tunnel Zones */}
                <div 
                  style={{ left: `${(31/250)*96 + 2}%`, width: `${(16/250)*96}%` }}
                  className="absolute h-2.5 bg-purple-500/40 border border-purple-400/60 rounded-full flex items-center justify-center text-[9px] font-mono text-purple-200"
                  title="Chilterns 16km Tunnel"
                >
                  Tunnel 16km
                </div>

                <div 
                  style={{ left: `${(184/250)*96 + 2}%`, width: `${(5.8/250)*96}%` }}
                  className="absolute h-2.5 bg-purple-500/40 border border-purple-400/60 rounded-full flex items-center justify-center text-[9px] font-mono text-purple-200"
                  title="Bromford 5.8km Tunnel"
                >
                  5.8km
                </div>
              </div>

              <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-2 border-t border-slate-800/60">
                <div className="flex items-center gap-4">
                  <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-cyan-400" /> Station Hubs</span>
                  <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-purple-500" /> Tunnels</span>
                  <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 bg-amber-500 rounded-sm" /> Viaducts & Bridges</span>
                </div>
                <span>Elevation: 45m - 210m AMSL</span>
              </div>
            </div>

            {/* Asset State Machine Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[
                { id: "STN-001", name: "London West Hub", type: "Station", km: "0.0 km", state: "COMPLETE", cost: "£22.0M" },
                { id: "TNL-001", name: "Chilterns Twin-Bore Tunnel", type: "Tunnel", km: "31.0 - 47.0 km", state: "CONSTRUCTION", cost: "£45.0M" },
                { id: "BRG-001", name: "Colne Valley Viaduct Bridge", type: "Bridge", km: "18.2 km", state: "CONSTRUCTION", cost: "£12.0M" },
                { id: "STN-004", name: "Milton Keynes Central", type: "Station", km: "82.0 km", state: "DESIGNED", cost: "£22.0M" },
                { id: "BRG-004", name: "Ouse Valley Viaduct", type: "Bridge", km: "76.4 km", state: "CONSTRUCTION", cost: "£12.0M" },
                { id: "TNL-002", name: "Long Itchington Wood Tunnel", type: "Tunnel", km: "134.0 - 135.6 km", state: "COMPLETE", cost: "£45.0M" },
                { id: "STN-008", name: "Birmingham Curzon 4.0", type: "Station", km: "195.0 km", state: "SITE_PREPARATION", cost: "£35.0M" },
                { id: "BRG-007", name: "Avon River Viaduct", type: "Bridge", km: "152.8 km", state: "SITE_PREPARATION", cost: "£12.0M" },
                { id: "TNL-003", name: "Bromford Tunnel", type: "Tunnel", km: "184.0 - 189.8 km", state: "SITE_PREPARATION", cost: "£45.0M" }
              ].map(asset => {
                const getStateColor = (s: string) => {
                  if (s === 'COMPLETE') return 'bg-emerald-950 text-emerald-400 border-emerald-800';
                  if (s === 'CONSTRUCTION') return 'bg-amber-950 text-amber-400 border-amber-800';
                  if (s === 'SITE_PREPARATION') return 'bg-blue-950 text-blue-400 border-blue-800';
                  return 'bg-slate-800 text-slate-300 border-slate-700';
                };

                return (
                  <div 
                    key={asset.id}
                    onClick={() => setSelectedAsset(asset)}
                    className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-500/50 transition-all cursor-pointer group space-y-3"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="text-[10px] font-mono text-slate-500 uppercase">{asset.type} • {asset.id}</span>
                        <h3 className="text-sm font-semibold text-slate-200 group-hover:text-cyan-300 transition-colors">
                          {asset.name}
                        </h3>
                      </div>
                      <span className={`text-[10px] font-mono px-2 py-0.5 rounded-md border ${getStateColor(asset.state)}`}>
                        {asset.state}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-xs font-mono text-slate-400 pt-2 border-t border-slate-800/60">
                      <span>Chainage: {asset.km}</span>
                      <span className="text-cyan-400">{asset.cost}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 2: SILICAFLUX COMPUTATIONAL HUB */}
        {activeTab === 'silicaflux' && (
          <div className="space-y-6">
            <div className="bg-slate-900/90 p-6 rounded-2xl border border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-bold text-white flex items-center gap-2 font-mono">
                    <Zap className="w-5 h-5 text-cyan-400" />
                    SilicaFlux High-Performance Numerical Execution Engine
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Typed array operations, SIMD vectorized arithmetic, prismoidal integration, and matrix linear system solvers.
                  </p>
                </div>
                <div className="px-3 py-1.5 rounded-lg bg-cyan-950/80 border border-cyan-800 text-cyan-400 text-xs font-mono">
                  Execution Mode: Deterministic SIMD Batch
                </div>
              </div>

              {/* Benchmarks Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 font-mono">
                  <span className="text-slate-400 text-xs block">DEM GRID CUT/FILL KERNEL</span>
                  <div className="text-xl font-bold text-white">12,500,000 Cells/sec</div>
                  <span className="text-[10px] text-emerald-400">Latency: 0.84 ms</span>
                </div>
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 font-mono">
                  <span className="text-slate-400 text-xs block">MATRIX GAUSSIAN SOLVER</span>
                  <div className="text-xl font-bold text-white">Ax = b (500x500)</div>
                  <span className="text-[10px] text-emerald-400">Latency: 1.12 ms</span>
                </div>
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 font-mono">
                  <span className="text-slate-400 text-xs block">MONTE CARLO PARALLEL KERNEL</span>
                  <div className="text-xl font-bold text-white">5,000 Iterations</div>
                  <span className="text-[10px] text-emerald-400">Latency: 2.45 ms</span>
                </div>
              </div>
            </div>

            {/* Earthwork Grid Calculator Box */}
            <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
              <h3 className="text-sm font-bold text-white font-mono flex items-center gap-2">
                <Layers className="w-4 h-4 text-cyan-400" />
                Live SilicaFlux Earthwork Volume Calculator
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3 font-mono text-xs">
                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <span className="text-slate-400">Input DEM Survey Resolution:</span>
                    <span className="text-white font-bold ml-2">1.0 meter grid</span>
                  </div>
                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <span className="text-slate-400">Integration Algorithm:</span>
                    <span className="text-white font-bold ml-2">Prismoidal Cross-Section Simpson Kernel</span>
                  </div>
                  <button 
                    onClick={() => handleRunCli('report')}
                    className="w-full py-2.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold transition-colors shadow-lg shadow-cyan-950/50"
                  >
                    Execute SilicaFlux Earthwork Calculation
                  </button>
                </div>

                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 font-mono text-xs space-y-3">
                  <div className="text-slate-400 text-[11px] border-b border-slate-800 pb-2">CALCULATION OUTPUT METRICS</div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Total Cut Volume:</span>
                    <span className="text-amber-400 font-bold">12,000,000 m³</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Total Fill Volume:</span>
                    <span className="text-blue-400 font-bold">11,000,000 m³</span>
                  </div>
                  <div className="flex justify-between border-t border-slate-800 pt-2">
                    <span className="text-slate-400">Net Earthwork Balance:</span>
                    <span className="text-emerald-400 font-bold">+1,000,000 m³ (Surplus Cut)</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: ROUTE OPTIMISER */}
        {activeTab === 'optimise' && (
          <div className="space-y-6">
            <div className="bg-slate-900/90 p-6 rounded-2xl border border-slate-800 space-y-4">
              <h2 className="text-lg font-bold text-white flex items-center gap-2 font-mono">
                <Sliders className="w-5 h-5 text-cyan-400" />
                Pareto Multi-Objective Route & Technology Optimiser
              </h2>
              <p className="text-xs text-slate-400">
                Multi-criteria decision engine evaluating trade-offs between Cost, Time, Carbon emissions, and Earthwork mass movement.
              </p>

              {/* Weight Sliders */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 p-4 bg-slate-950 rounded-xl border border-slate-800 text-xs font-mono">
                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>TIME WEIGHT</span>
                    <span className="text-cyan-400">{optWeights.TIME}</span>
                  </div>
                  <input 
                    type="range" min="0" max="1" step="0.05" value={optWeights.TIME}
                    onChange={(e) => setOptWeights({ ...optWeights, TIME: parseFloat(e.target.value) })}
                    className="w-full accent-cyan-400 cursor-pointer"
                  />
                </div>
                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>COST WEIGHT</span>
                    <span className="text-cyan-400">{optWeights.COST}</span>
                  </div>
                  <input 
                    type="range" min="0" max="1" step="0.05" value={optWeights.COST}
                    onChange={(e) => setOptWeights({ ...optWeights, COST: parseFloat(e.target.value) })}
                    className="w-full accent-cyan-400 cursor-pointer"
                  />
                </div>
                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>CARBON WEIGHT</span>
                    <span className="text-cyan-400">{optWeights.CARBON}</span>
                  </div>
                  <input 
                    type="range" min="0" max="1" step="0.05" value={optWeights.CARBON}
                    onChange={(e) => setOptWeights({ ...optWeights, CARBON: parseFloat(e.target.value) })}
                    className="w-full accent-cyan-400 cursor-pointer"
                  />
                </div>
                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>EARTHWORK WEIGHT</span>
                    <span className="text-cyan-400">{optWeights.EARTHWORK}</span>
                  </div>
                  <input 
                    type="range" min="0" max="1" step="0.05" value={optWeights.EARTHWORK}
                    onChange={(e) => setOptWeights({ ...optWeights, EARTHWORK: parseFloat(e.target.value) })}
                    className="w-full accent-cyan-400 cursor-pointer"
                  />
                </div>
              </div>
            </div>

            {/* Pareto Candidates */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {optCandidates.map((cand, idx) => (
                <div key={idx} className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4 hover:border-cyan-500/60 transition-all">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800">
                      RANK #{idx + 1}
                    </span>
                    <span className="text-xs font-mono text-slate-400">Score: {cand.fitness_score}</span>
                  </div>
                  
                  <h3 className="text-sm font-bold text-white font-mono">{cand.name}</h3>

                  <div className="space-y-2 text-xs font-mono text-slate-300 bg-slate-950 p-3 rounded-xl border border-slate-800/80">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Total Cost:</span>
                      <span className="text-cyan-400 font-bold">£{(cand.total_cost_gbp / 1e9).toFixed(2)}B</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Duration:</span>
                      <span className="text-white font-bold">{cand.time_months} months</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Carbon Footprint:</span>
                      <span className="text-emerald-400 font-bold">{cand.carbon_tco2e.toLocaleString()} tCO2e</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Earthworks:</span>
                      <span className="text-amber-400 font-bold">{(cand.earthwork_m3 / 1e6).toFixed(1)}M m³</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 4: DISCRETE SIMULATOR */}
        {activeTab === 'simulator' && (
          <div className="space-y-6">
            <div className="bg-slate-900/90 p-6 rounded-2xl border border-slate-800 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-lg font-bold text-white flex items-center gap-2 font-mono">
                    <Play className="w-5 h-5 text-cyan-400" />
                    Discrete Event Construction Timeline Simulator
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Simulate days, weeks, or months of progress with weather delay factors and machinery breakdown injections.
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  {[10, 30, 90, 180].map(d => (
                    <button
                      key={d}
                      onClick={() => handleRunSimulation(d)}
                      disabled={isSimulating}
                      className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-cyan-600 hover:text-slate-950 text-xs font-mono font-bold transition-all border border-slate-700/80 disabled:opacity-50"
                    >
                      +{d} Days
                    </button>
                  ))}
                </div>
              </div>

              {isSimulating && (
                <div className="p-4 bg-cyan-950/40 border border-cyan-800 rounded-xl text-cyan-300 text-xs font-mono animate-pulse flex items-center gap-2">
                  <Activity className="w-4 h-4 animate-spin text-cyan-400" />
                  <span>Executing SilicaFlux simulation step kernels...</span>
                </div>
              )}

              {simResults && (
                <div className="p-5 bg-slate-950 rounded-xl border border-slate-800 space-y-4 font-mono text-xs">
                  <div className="text-slate-400 font-bold text-sm">SIMULATION BATCH COMPLETED</div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="p-3 bg-slate-900 rounded-lg border border-slate-800">
                      <span className="text-slate-500 block text-[10px]">SIMULATED DAYS</span>
                      <span className="text-white font-bold text-base">{simResults.total_simulated_days} Days</span>
                    </div>
                    <div className="p-3 bg-slate-900 rounded-lg border border-slate-800">
                      <span className="text-slate-500 block text-[10px]">WEATHER DELAYS</span>
                      <span className="text-amber-400 font-bold text-base">{simResults.events_breakdown.WEATHER_DELAY} Days</span>
                    </div>
                    <div className="p-3 bg-slate-900 rounded-lg border border-slate-800">
                      <span className="text-slate-500 block text-[10px]">EQUIPMENT FAILURES</span>
                      <span className="text-rose-400 font-bold text-base">{simResults.events_breakdown.EQUIPMENT_FAILURE} Events</span>
                    </div>
                    <div className="p-3 bg-slate-900 rounded-lg border border-slate-800">
                      <span className="text-slate-500 block text-[10px]">CURRENT TWIN PROGRESS</span>
                      <span className="text-emerald-400 font-bold text-base">{simResults.project_status.progress_percent}%</span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Monte Carlo Risk Curves */}
            <div className="p-6 bg-slate-900 rounded-2xl border border-slate-800 space-y-4">
              <h3 className="text-sm font-bold text-white font-mono flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-cyan-400" />
                SilicaFlux Monte Carlo Schedule Risk Distribution (P10 / P50 / P90)
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                  <span className="text-emerald-400 font-bold text-xs">P10 OPTIMISTIC CASE</span>
                  <div className="text-lg font-bold text-white">1,240 Days</div>
                  <p className="text-[10px] text-slate-500">10% probability of completing earlier</p>
                </div>
                <div className="p-4 bg-slate-950 rounded-xl border border-cyan-800/80 space-y-2 bg-cyan-950/20">
                  <span className="text-cyan-400 font-bold text-xs">P50 EXPECTED BASELINE</span>
                  <div className="text-lg font-bold text-white">1,420 Days</div>
                  <p className="text-[10px] text-slate-400">50% median probability completion date</p>
                </div>
                <div className="p-4 bg-slate-950 rounded-xl border border-rose-800/80 space-y-2 bg-rose-950/20">
                  <span className="text-rose-400 font-bold text-xs">P90 CONSERVATIVE RISK</span>
                  <div className="text-lg font-bold text-white">1,680 Days</div>
                  <p className="text-[10px] text-slate-500">90% confidence threshold incorporating weather risks</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: MAGLEV VS STEEL RAIL */}
        {activeTab === 'maglev' && (
          <div className="space-y-6">
            <div className="bg-slate-900/90 p-6 rounded-2xl border border-slate-800 space-y-4">
              <h2 className="text-lg font-bold text-white flex items-center gap-2 font-mono">
                <Train className="w-5 h-5 text-cyan-400" />
                Maglev vs Steel Rail Technology Comparison Engine
              </h2>
              <p className="text-xs text-slate-400">
                Independent technology evaluation comparing Transrapid EMS, SCMaglev EDS, High-Speed Rail 350, and Freight.
              </p>

              <div className="overflow-x-auto">
                <table className="w-full text-left font-mono text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400 bg-slate-950">
                      <th className="p-3">TECHNOLOGY</th>
                      <th className="p-3">TARGET SPEED</th>
                      <th className="p-3">MAX GRADIENT</th>
                      <th className="p-3">ELEVATED GUIDEWAY</th>
                      <th className="p-3">ESTIMATED CAPEX / KM</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800 text-slate-300">
                    <tr className="hover:bg-slate-800/40">
                      <td className="p-3 font-bold text-cyan-400">Transrapid EMS Maglev</td>
                      <td className="p-3">500 km/h</td>
                      <td className="p-3 text-emerald-400">10.0% Grade</td>
                      <td className="p-3">Elevated Guideway Piers</td>
                      <td className="p-3">£24.7M / km</td>
                    </tr>
                    <tr className="hover:bg-slate-800/40">
                      <td className="p-3 font-bold text-blue-400">SCMaglev EDS (Japan)</td>
                      <td className="p-3">603 km/h</td>
                      <td className="p-3 text-emerald-400">8.0% Grade</td>
                      <td className="p-3">Superconducting Coils</td>
                      <td className="p-3">£32.5M / km</td>
                    </tr>
                    <tr className="hover:bg-slate-800/40">
                      <td className="p-3 font-bold text-amber-400">High-Speed Rail 350</td>
                      <td className="p-3">350 km/h</td>
                      <td className="p-3 text-amber-400">3.5% Grade</td>
                      <td className="p-3">Ballastless Slab Track</td>
                      <td className="p-3">£8.9M / km</td>
                    </tr>
                    <tr className="hover:bg-slate-800/40">
                      <td className="p-3 font-bold text-slate-400">Heavy Freight Rail</td>
                      <td className="p-3">120 km/h</td>
                      <td className="p-3 text-rose-400">1.2% Grade</td>
                      <td className="p-3">Ballasted 60kg/m Rail</td>
                      <td className="p-3">£4.2M / km</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: ML & TELEMETRY */}
        {activeTab === 'ml' && (
          <div className="space-y-6">
            <div className="bg-slate-900/90 p-6 rounded-2xl border border-slate-800 space-y-4">
              <h2 className="text-lg font-bold text-white flex items-center gap-2 font-mono">
                <Activity className="w-5 h-5 text-cyan-400" />
                Machine Learning & Fleet Telemetry Stream
              </h2>
              <p className="text-xs text-slate-400">
                Predictive models for excavator productivity, equipment downtime risk, and material demand forecasting.
              </p>

              {mlData && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 font-mono text-xs">
                  <div className="p-5 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                    <span className="text-cyan-400 font-bold block text-sm">PRODUCTIVITY FORECAST</span>
                    <div className="flex justify-between border-b border-slate-800 pb-2">
                      <span className="text-slate-400">m³/day Excavation Rate:</span>
                      <span className="text-white font-bold">{mlData.productivity.forecast_m3_per_day} m³</span>
                    </div>
                    <div className="flex justify-between border-b border-slate-800 pb-2">
                      <span className="text-slate-400">metres/day Track Rate:</span>
                      <span className="text-white font-bold">{mlData.productivity.forecast_metres_per_day} m</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Confidence Score:</span>
                      <span className="text-emerald-400 font-bold">{(mlData.productivity.confidence_score * 100).toFixed(0)}%</span>
                    </div>
                  </div>

                  <div className="p-5 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                    <span className="text-amber-400 font-bold block text-sm">SCHEDULE DELAY RISK</span>
                    <div className="flex justify-between border-b border-slate-800 pb-2">
                      <span className="text-slate-400">Delay Probability:</span>
                      <span className="text-amber-400 font-bold">{(mlData.delay_risk.delay_probability * 100).toFixed(1)}%</span>
                    </div>
                    <div className="flex justify-between border-b border-slate-800 pb-2">
                      <span className="text-slate-400">Expected Delay Days:</span>
                      <span className="text-rose-400 font-bold">{mlData.delay_risk.expected_delay_days} days</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Key Factors:</span>
                      <span className="text-slate-300">Weather & Equipment Downtime</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 7: CLI TERMINAL */}
        {activeTab === 'cli' && (
          <div className="space-y-6">
            <div className="bg-slate-900/90 p-6 rounded-2xl border border-slate-800 space-y-4">
              <h2 className="text-lg font-bold text-white flex items-center gap-2 font-mono">
                <TerminalIcon className="w-5 h-5 text-cyan-400" />
                Interactive RAILWAY 4.0 CLI & Python Terminal
              </h2>

              {/* Quick CLI Action Buttons */}
              <div className="flex flex-wrap gap-2 pt-2">
                {['report', 'build-twin', 'simulate --days 30', 'forecast', 'optimise', 'validate', 'snapshot --day 30'].map(cmd => (
                  <button
                    key={cmd}
                    onClick={() => {
                      setCliCommand(cmd);
                      handleRunCli(cmd);
                    }}
                    disabled={isExecutingCli}
                    className="px-3 py-1.5 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-xs font-mono text-cyan-400 transition-colors"
                  >
                    railway4 {cmd}
                  </button>
                ))}
              </div>

              {/* Terminal Box */}
              <div className="bg-slate-950 rounded-xl border border-slate-800 p-4 font-mono text-xs space-y-3">
                <pre className="text-slate-300 whitespace-pre-wrap max-h-96 overflow-y-auto leading-relaxed scrollbar-thin">
                  {cliOutput}
                </pre>

                <div className="flex items-center gap-2 pt-3 border-t border-slate-800">
                  <span className="text-cyan-400 font-bold">$ railway4</span>
                  <input
                    type="text"
                    value={cliCommand}
                    onChange={(e) => setCliCommand(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleRunCli()}
                    placeholder="e.g. report"
                    className="flex-1 bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-white focus:outline-none focus:border-cyan-500"
                  />
                  <button
                    onClick={() => handleRunCli()}
                    disabled={isExecutingCli}
                    className="px-4 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold transition-colors"
                  >
                    Run
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 8: AUDIT LOGS */}
        {activeTab === 'audit' && (
          <div className="space-y-6">
            <div className="bg-slate-900/90 p-6 rounded-2xl border border-slate-800 space-y-4 font-mono text-xs">
              <h2 className="text-lg font-bold text-white flex items-center gap-2 font-mono">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
                Immutable Event Sourcing Journal & Provenance Log
              </h2>
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2 text-slate-300">
                <div className="text-emerald-400 font-bold">PROVENANCE STATE SAFETY VERIFIED</div>
                <p className="text-slate-400 text-[11px]">
                  All geological borehole measurements have provenance status <span className="text-cyan-400">MEASURED</span>. Safety boundaries prohibit estimated data from altering physical design parameters.
                </p>
              </div>

              <div className="space-y-2">
                {[
                  { time: "2026-09-09T07:10:00Z", asset: "PROJ-GB-HS250", event: "DIGITAL_TWIN_INIT", op: "SYSTEM", ver: "v4.0.0" },
                  { time: "2026-09-09T07:11:15Z", asset: "TNL-001", event: "STATE_TRANSITION -> CONSTRUCTION", op: "Engineer", ver: "v4.0.0" },
                  { time: "2026-09-09T07:12:30Z", asset: "BRG-001", event: "INSPECTION_PASSED", op: "Inspector", ver: "v4.0.0" },
                  { time: "2026-09-09T07:14:00Z", asset: "STN-001", event: "AS_BUILT_REGISTERED", op: "Director", ver: "v4.0.0" }
                ].map((log, idx) => (
                  <div key={idx} className="p-3 bg-slate-950 rounded-lg border border-slate-800/80 flex flex-wrap items-center justify-between text-slate-400">
                    <span className="text-slate-500">{log.time}</span>
                    <span className="text-cyan-400 font-bold">{log.asset}</span>
                    <span className="text-white">{log.event}</span>
                    <span>Operator: {log.op}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

      </main>

      {/* FOOTER */}
      <footer className="border-t border-slate-800 bg-slate-900/80 px-6 py-4 text-center text-xs font-mono text-slate-500">
        RAILWAY 4.0 Enterprise Digital Twin Platform • Python Orchestration + SilicaFlux Computational Kernels
      </footer>
    </div>
  );
}
