"""
RAILWAY 4.0 - Enterprise Digital Twin & Computational Railway Infrastructure Engineering Platform
"""

__version__ = "4.0.0"
__author__ = "Railway 4.0 Computational Systems Architecture Team"
