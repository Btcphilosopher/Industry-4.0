"""
Geology Digital Twin Model
Handles soil/rock classification, geotechnical bearing capacity, and strict provenance states.
"""

from enum import Enum
from typing import Dict, List, Optional, Any
from railway4.python.core.units import ProvenanceState

class SoilClassification(str, Enum):
    CLAY = "Clay"
    SILT = "Silt"
    SAND = "Sand"
    GRAVEL = "Gravel"
    PEAT = "Peat"
    WEATHERED_ROCK = "Weathered Rock"
    SOLID_GRANITE = "Solid Granite"
    LIMESTONE = "Limestone"

class GeologicalStrata:
    """Geological borehole or profile segment along railway alignment."""
    
    def __init__(self, chainage_km: float, soil_type: SoilClassification, 
                 bearing_capacity_kPa: float, groundwater_depth_m: float, 
                 provenance: ProvenanceState):
        self.chainage_km = chainage_km
        self.soil_type = soil_type
        self.bearing_capacity_kPa = bearing_capacity_kPa
        self.groundwater_depth_m = groundwater_depth_m
        self.provenance = provenance

    def assert_authoritative_engineering(self) -> bool:
        """
        Safety check: Prevents ESTIMATED or UNKNOWN geological data 
        from silently becoming authoritative engineering design baseline!
        """
        if self.provenance in (ProvenanceState.ESTIMATED, ProvenanceState.UNKNOWN):
            raise ValueError(
                f"SAFETY GUARD: Geological data at chainage {self.chainage_km}km has provenance state "
                f"'{self.provenance.value}'. Physical foundation design requires MEASURED or INFERRED survey boreholes."
            )
        return True

    def to_dict(self) -> Dict[str, Any]:
        return {
            "chainage_km": self.chainage_km,
            "soil_type": self.soil_type.value,
            "bearing_capacity_kPa": self.bearing_capacity_kPa,
            "groundwater_depth_m": self.groundwater_depth_m,
            "provenance": self.provenance.value
        }
