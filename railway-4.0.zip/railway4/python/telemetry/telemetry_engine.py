"""
Telemetry Engine & Construction Simulator for Railway 4.0
"""

import random
from typing import Dict, List, Any
from railway4.silicaflux import TelemetryKernel, SimulationKernel

class TelemetryEngine:
    """Ingests synthetic/real machine telemetry streams and delegates vector aggregation to SilicaFlux."""

    def __init__(self):
        self.raw_records: List[Dict[str, Any]] = []

    def ingest_record(self, record: Dict[str, Any]):
        self.raw_records.append(record)

    def process_telemetry_stream(self) -> Dict[str, Any]:
        """Delegates high-throughput aggregation to SilicaFlux TelemetryKernel."""
        return TelemetryKernel.aggregate_telemetry_batch(self.raw_records)


class SimulationEventType:
    MACHINE_START = "MACHINE_START"
    MACHINE_STOP = "MACHINE_STOP"
    MATERIAL_DELIVERY = "MATERIAL_DELIVERY"
    EXCAVATION = "EXCAVATION"
    FILL = "FILL"
    CONCRETE_POUR = "CONCRETE_POUR"
    BRIDGE_CONSTRUCTION = "BRIDGE_CONSTRUCTION"
    TRACK_INSTALLATION = "TRACK_INSTALLATION"
    INSPECTION = "INSPECTION"
    WEATHER_DELAY = "WEATHER_DELAY"
    EQUIPMENT_FAILURE = "EQUIPMENT_FAILURE"


class ConstructionSimulator:
    """Discrete-event construction simulator simulating project days, weeks, or months."""

    def __init__(self, digital_twin_registry):
        self.registry = digital_twin_registry
        self.current_day = 0
        self.simulation_logs: List[Dict[str, Any]] = []

    def simulate_days(self, days_to_simulate: int = 30) -> Dict[str, Any]:
        """Simulates discrete construction timeline progress."""
        start_day = self.current_day
        end_day = start_day + days_to_simulate
        
        events_count = {
            SimulationEventType.EXCAVATION: 0,
            SimulationEventType.CONCRETE_POUR: 0,
            SimulationEventType.TRACK_INSTALLATION: 0,
            SimulationEventType.WEATHER_DELAY: 0,
            SimulationEventType.EQUIPMENT_FAILURE: 0
        }

        random.seed(42 + self.current_day)
        
        for day in range(start_day + 1, end_day + 1):
            self.current_day = day
            
            # Weather roll
            weather_severity = random.triangular(0.0, 0.15, 0.8) # 0 clear, 1 storm
            if weather_severity > 0.65:
                events_count[SimulationEventType.WEATHER_DELAY] += 1
                self.simulation_logs.append({
                    "day": day,
                    "event": SimulationEventType.WEATHER_DELAY,
                    "notes": f"Heavy rain/storm severity {round(weather_severity, 2)}. Work suspended."
                })
                continue # Weather delay stops site progress

            # Equipment failure roll
            if random.random() < 0.05:
                events_count[SimulationEventType.EQUIPMENT_FAILURE] += 1
                self.simulation_logs.append({
                    "day": day,
                    "event": SimulationEventType.EQUIPMENT_FAILURE,
                    "notes": "Excavator hydraulic line rupture. Repaired in 4 hours."
                })

            # Advance planned assets
            assets = self.registry.list_assets()
            for asset in assets:
                if asset.planned_start_day <= day <= asset.planned_completion_day:
                    if asset.construction_state == "DESIGNED":
                        asset.transition_state("PROCURED", "Simulator")
                        asset.transition_state("SITE_PREPARATION", "Simulator")
                        asset.transition_state("CONSTRUCTION", "Simulator")
                    
                    # Accumulate progress cost
                    cost_per_day = asset.cost_gbp / max(1, (asset.planned_completion_day - asset.planned_start_day))
                    asset.actual_cost_gbp += cost_per_day

                    if "RailSection" in asset.asset_type or "Sleeper" in asset.asset_type:
                        events_count[SimulationEventType.TRACK_INSTALLATION] += 1
                    elif "Bridge" in asset.asset_type or "Tunnel" in asset.asset_type:
                        events_count[SimulationEventType.CONCRETE_POUR] += 1
                    else:
                        events_count[SimulationEventType.EXCAVATION] += 1

                if day >= asset.planned_completion_day and asset.construction_state == "CONSTRUCTION":
                    asset.transition_state("INSPECTION", "Simulator")
                    asset.transition_state("COMPLETE", "Simulator")

        # Capture snapshot
        snapshot_id = f"PROJECT_DAY_{self.current_day:03d}"
        self.registry.create_snapshot(snapshot_id, self.current_day)

        return {
            "start_day": start_day,
            "end_day": end_day,
            "total_simulated_days": days_to_simulate,
            "events_breakdown": events_count,
            "logs_count": len(self.simulation_logs),
            "project_status": self.registry.get_summary_stats()
        }
