"""
Cost, Carbon, Quality, Validation, Storage, and Security Modules for Railway 4.0
"""

from enum import Enum
from typing import Dict, List, Any, Optional
import json

class Role(str, Enum):
    PROJECT_DIRECTOR = "PROJECT_DIRECTOR"
    ENGINEER = "ENGINEER"
    SURVEYOR = "SURVEYOR"
    CONSTRUCTION_MANAGER = "CONSTRUCTION_MANAGER"
    DATA_SCIENTIST = "DATA_SCIENTIST"
    INSPECTOR = "INSPECTOR"
    VIEWER = "VIEWER"


class SecurityManager:
    """Role-Based Access Control (RBAC) and security boundary validation."""

    ROLE_PERMISSIONS = {
        Role.PROJECT_DIRECTOR: ["READ", "WRITE", "DELETE", "TRANSITION", "ADMIN"],
        Role.ENGINEER: ["READ", "WRITE", "TRANSITION"],
        Role.SURVEYOR: ["READ", "WRITE_SURVEY"],
        Role.CONSTRUCTION_MANAGER: ["READ", "TRANSITION"],
        Role.DATA_SCIENTIST: ["READ", "RUN_SIMULATION", "RUN_ML"],
        Role.INSPECTOR: ["READ", "LOG_INSPECTION"],
        Role.VIEWER: ["READ"]
    }

    @staticmethod
    def authorize(user_role: Role, required_permission: str) -> bool:
        allowed = SecurityManager.ROLE_PERMISSIONS.get(user_role, [])
        if required_permission not in allowed and "ADMIN" not in allowed:
            raise PermissionError(f"Access Denied: Role '{user_role.value}' lacks permission '{required_permission}'.")
        return True


class CostEngine:
    """Calculates CAPEX breakdown across materials, labor, machinery, earthworks, and structures."""

    @staticmethod
    def calculate_project_capex(route_length_km: float, 
                                cut_fill_m3: float, 
                                bridge_count: int, 
                                tunnel_count: int, 
                                station_count: int) -> Dict[str, float]:
        c_earth = cut_fill_m3 * 16.50
        c_track = route_length_km * 4_200_000.0
        c_bridges = bridge_count * 11_500_000.0
        c_tunnels = tunnel_count * 42_000_000.0
        c_stations = station_count * 22_000_000.0
        c_electrification = route_length_km * 1_100_000.0
        
        total_capex = c_earth + c_track + c_bridges + c_tunnels + c_stations + c_electrification
        cost_per_km = total_capex / max(0.1, route_length_km)

        return {
            "earthworks_gbp": round(c_earth, 2),
            "track_superstructure_gbp": round(c_track, 2),
            "bridges_viaducts_gbp": round(c_bridges, 2),
            "tunnels_gbp": round(c_tunnels, 2),
            "stations_gbp": round(c_stations, 2),
            "electrification_power_gbp": round(c_electrification, 2),
            "total_capex_gbp": round(total_capex, 2),
            "cost_per_km_gbp": round(cost_per_km, 2)
        }


class CarbonEngine:
    """Embodied and operational carbon emission calculator."""

    @staticmethod
    def calculate_emissions(route_length_km: float, cut_fill_m3: float, steel_tonnes: float, concrete_m3: float) -> Dict[str, float]:
        # Carbon factors (kg CO2e / unit)
        co2_steel = steel_tonnes * 1820.0
        co2_concrete = concrete_m3 * 320.0
        co2_machinery = cut_fill_m3 * 4.5 # diesel earthmoving
        
        total_kg = co2_steel + co2_concrete + co2_machinery
        total_tonnes = total_kg / 1000.0
        co2_per_km = total_tonnes / max(0.1, route_length_km)

        return {
            "steel_emissions_tco2e": round(co2_steel / 1000.0, 2),
            "concrete_emissions_tco2e": round(co2_concrete / 1000.0, 2),
            "machinery_emissions_tco2e": round(co2_machinery / 1000.0, 2),
            "total_project_tco2e": round(total_tonnes, 2),
            "tco2e_per_km": round(co2_per_km, 2)
        }


class DataValidator:
    """Validates survey, telemetry, and asset data schemas, ranges, coordinates, and units."""

    @staticmethod
    def validate_survey_points(points: List[List[float]]) -> bool:
        if not points:
            raise ValueError("Validation Error: Survey dataset is empty.")
        for idx, pt in enumerate(points):
            if len(pt) < 3:
                raise ValueError(f"Validation Error at point {idx}: Point must contain [x, y, z] or [lat, lon, elev].")
            if not (-90.0 <= pt[0] <= 90.0 or 100000 <= pt[0] <= 900000): # Lat or UTM
                raise ValueError(f"Validation Error at point {idx}: Coordinate X out of valid range.")
        return True
