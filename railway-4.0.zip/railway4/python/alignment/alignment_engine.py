"""
Alignment Engine & Track Engine
Optimizes railway horizontal/vertical alignment parameters and tracks material demands.
"""

import math
from typing import Dict, List, Tuple, Any
from railway4.silicaflux import GeometryKernel, TrackKernel

class AlignmentEngine:
    """Manages geometric alignment design, speed cant limits, and gradient profiles."""

    def __init__(self, target_speed_kmh: float = 350.0):
        self.target_speed_kmh = target_speed_kmh
        self.geometry_kernel = GeometryKernel()

    def evaluate_curve_cant(self, radius_m: float) -> Dict[str, float]:
        """Uses SilicaFlux GeometryKernel to evaluate equilibrium cant and speed limits."""
        return self.geometry_kernel.calculate_cant(radius_m, self.target_speed_kmh)

    def evaluate_alignment_section(self, points_3d: List[Tuple[float, float, float]]) -> Dict[str, Any]:
        """Calculates total length, max gradient, and minimum horizontal radius along polyline."""
        if len(points_3d) < 2:
            return {"length_km": 0.0, "max_gradient_pct": 0.0, "min_radius_m": float('inf')}

        total_length = 0.0
        max_grad = 0.0
        radii = []

        for i in range(1, len(points_3d)):
            x1, y1, z1 = points_3d[i-1]
            x2, y2, z2 = points_3d[i]
            dx = x2 - x1
            dy = y2 - y1
            dz = z2 - z1
            h_dist = math.sqrt(dx*dx + dy*dy)
            dist = math.sqrt(dx*dx + dy*dy + dz*dz)
            total_length += dist

            if h_dist > 0:
                grad = abs(dz / h_dist) * 100.0
                if grad > max_grad:
                    max_grad = grad

            if i < len(points_3d) - 1:
                x3, y3, _ = points_3d[i+1]
                # 3-point circle radius calculation
                a = math.sqrt((x2-x1)**2 + (y2-y1)**2)
                b = math.sqrt((x3-x2)**2 + (y3-y2)**2)
                c = math.sqrt((x3-x1)**2 + (y3-y1)**2)
                if a > 0 and b > 0 and c > 0:
                    area = abs(x1*(y2 - y3) + x2*(y3 - y1) + x3*(y1 - y2)) / 2.0
                    if area > 1e-4:
                        R = (a * b * c) / (4.0 * area)
                        radii.append(R)

        min_radius = min(radii) if radii else 5000.0 # Default straight line infinity

        return {
            "length_km": round(total_length / 1000.0, 3),
            "max_gradient_pct": round(max_grad, 2),
            "min_radius_m": round(min_radius, 1),
            "cant_check": self.evaluate_curve_cant(min_radius)
        }


class TrackEngine:
    """Conventional, Heavy Freight, and High-Speed Rail superstructure model."""

    def __init__(self, rail_type: str = "CEN60", is_double_track: bool = True):
        self.rail_type = rail_type # e.g. CEN60 (60kg/m)
        self.is_double_track = is_double_track
        self.track_kernel = TrackKernel()

    def compute_track_demand(self, track_length_km: float) -> Dict[str, float]:
        """Calculates material demand using SilicaFlux TrackKernel."""
        rail_kg_m = 60.0 if "60" in self.rail_type else 54.0
        return self.track_kernel.calculate_track_quantities(
            track_length_km=track_length_km,
            is_double_track=self.is_double_track,
            rail_type_kg_m=rail_kg_m
        )
