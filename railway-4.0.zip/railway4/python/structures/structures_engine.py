"""
Structures Engine and Machinery Fleet Model
"""

from enum import Enum
from typing import Dict, List, Optional, Any
from railway4.silicaflux import StructureKernel

class MachineType(str, Enum):
    EXCAVATOR = "Excavator"
    GRADER = "Grader"
    BULLDOZER = "Bulldozer"
    CRANE = "Crane"
    PILE_DRIVER = "PileDriver"
    TBM = "TunnelBoringMachine"
    CONCRETE_PUMP = "ConcreteEquipment"
    RAIL_CRANE = "RailCrane"
    BALLAST_TRAIN = "BallastTrain"
    RAIL_LAYING_MACHINE = "RailLayingMachine"


class MachineryAsset:
    """Tracks construction heavy equipment telemetry, operating hours, fuel, maintenance."""

    def __init__(self, machine_id: str, machine_type: MachineType, name: str, base_capacity_units_h: float = 120.0):
        self.machine_id = machine_id
        self.machine_type = machine_type
        self.name = name
        self.base_capacity = base_capacity_units_h
        self.location_lat = 52.4862 # Default UK Midlands
        self.location_lon = -1.8904
        self.operating_hours = 0.0
        self.total_fuel_l = 0.0
        self.maintenance_due = False
        self.is_down = False
        self.assigned_task: Optional[str] = None

    def log_operation(self, hours: float, fuel_consumed_l: float, units_produced: float):
        if self.is_down:
            return
        self.operating_hours += hours
        self.total_fuel_l += fuel_consumed_l
        if self.operating_hours >= 250.0: # Service interval
            self.maintenance_due = True

    def to_dict(self) -> Dict[str, Any]:
        return {
            "machine_id": self.machine_id,
            "name": self.name,
            "machine_type": self.machine_type.value,
            "operating_hours": round(self.operating_hours, 1),
            "total_fuel_l": round(self.total_fuel_l, 1),
            "is_down": self.is_down,
            "maintenance_due": self.maintenance_due,
            "assigned_task": self.assigned_task
        }


class StructuresEngine:
    """Manages structural design evaluation for bridges, tunnels, viaducts."""

    def __init__(self):
        self.kernel = StructureKernel()

    def evaluate_bridge_structure(self, span_m: float, live_load_kN: float) -> Dict[str, float]:
        return self.kernel.bridge_beam_deflection(span_m=span_m, load_kN=live_load_kN)

    def evaluate_tunnel_structure(self, length_m: float, diameter_m: float) -> Dict[str, float]:
        return self.kernel.tunnel_excavation_volume(length_m=length_m, diameter_m=diameter_m)
