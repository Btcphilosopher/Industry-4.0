"""
Maglev Infrastructure Digital Twin Engine
Supports Transrapid / SCMaglev technology, elevated guideways, linear propulsion, and power substations.
"""

import math
from typing import Dict, List, Any

class MaglevEngine:
    """Dedicated Maglev levitation, guideway, and linear synchronous motor infrastructure engine."""

    def __init__(self, technology_type: str = "TRANSRAPID_EMS", target_speed_kmh: float = 500.0):
        self.technology_type = technology_type # TRANSRAPID_EMS or SCMAGLEV_EDS
        self.target_speed_kmh = target_speed_kmh
        
        # Technology specific parameters
        if technology_type == "TRANSRAPID_EMS":
            self.max_gradient_pct = 10.0 # Maglev can climb steep 10% grades vs 3.5% conventional
            self.guideway_cost_per_km_gbp = 18_500_000.0
            self.linear_stator_cost_per_km_gbp = 6_200_000.0
            self.power_substation_spacing_km = 15.0
            self.substation_cost_gbp = 12_000_000.0
        else: # SCMAGLEV_EDS
            self.max_gradient_pct = 8.0
            self.guideway_cost_per_km_gbp = 24_000_000.0
            self.linear_stator_cost_per_km_gbp = 8_500_000.0
            self.power_substation_spacing_km = 10.0
            self.substation_cost_gbp = 15_000_000.0

    def compute_maglev_infrastructure_demand(self, route_length_km: float, elevated_pct: float = 85.0) -> Dict[str, Any]:
        """Computes elevated guideway piers, stator winding mass, power substations, and total CAPEX."""
        elevated_len_km = route_length_km * (elevated_pct / 100.0)
        num_piers = int((elevated_len_km * 1000.0) / 25.0) # 25m span piers
        num_substations = math.ceil(route_length_km / self.power_substation_spacing_km)
        
        c_guideway = route_length_km * self.guideway_cost_per_km_gbp
        c_stators = route_length_km * self.linear_stator_cost_per_km_gbp
        c_substations = num_substations * self.substation_cost_gbp
        total_capex = c_guideway + c_stators + c_substations

        # Energy consumption estimate kWh/pass-km
        energy_kwh_km = 0.042 * (self.target_speed_kmh ** 1.2) / 100.0

        return {
            "technology": self.technology_type,
            "target_speed_kmh": self.target_speed_kmh,
            "route_length_km": route_length_km,
            "elevated_guideway_km": round(elevated_len_km, 2),
            "guideway_piers_count": num_piers,
            "power_substations_count": num_substations,
            "max_gradient_tolerance_pct": self.max_gradient_pct,
            "capex_breakdown_gbp": {
                "guideway_structure": round(c_guideway, 2),
                "linear_propulsion_stators": round(c_stators, 2),
                "power_substations": round(c_substations, 2),
                "total_capex_gbp": round(total_capex, 2)
            },
            "operational_energy_kwh_per_km": round(energy_kwh_km, 3)
        }
