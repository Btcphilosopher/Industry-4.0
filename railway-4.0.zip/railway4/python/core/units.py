"""
RAILWAY 4.0 Core Engineering Units & Traceability Engine
Strict engineering unit system and computational provenance metadata.
"""

from datetime import datetime
from enum import Enum
from typing import Any, Dict, Optional, Union

class EngineeringUnit(str, Enum):
    # Length
    METER = "m"
    KILOMETER = "km"
    MILLIMETER = "mm"
    
    # Mass
    KILOGRAM = "kg"
    TONNE = "tonnes"
    
    # Force
    NEWTON = "N"
    KILONEWTON = "kN"
    MEGANEWTON = "MN"
    
    # Pressure
    PASCAL = "Pa"
    KILOPASCAL = "kPa"
    MEGAPASCAL = "MPa"
    
    # Volume
    CUBIC_METER = "m³"
    
    # Speed
    METER_PER_SEC = "m/s"
    KM_PER_HOUR = "km/h"
    
    # Energy
    KILOWATT_HOUR = "kWh"
    MEGAJOULE = "MJ"
    GIGAJOULE = "GJ"
    
    # Currency
    GBP = "GBP"

class Quantity:
    """Strictly typed engineering quantity with unit enforcement."""
    
    def __init__(self, value: float, unit: Union[EngineeringUnit, str]):
        self.value = float(value)
        self.unit = EngineeringUnit(unit) if isinstance(unit, str) else unit

    def to(self, target_unit: Union[EngineeringUnit, str]) -> 'Quantity':
        target = EngineeringUnit(target_unit) if isinstance(target_unit, str) else target_unit
        if self.unit == target:
            return Quantity(self.value, target)
            
        # Conversion map
        val = self.value
        # Length
        if self.unit == EngineeringUnit.KILOMETER and target == EngineeringUnit.METER:
            return Quantity(val * 1000.0, target)
        if self.unit == EngineeringUnit.METER and target == EngineeringUnit.KILOMETER:
            return Quantity(val / 1000.0, target)
        if self.unit == EngineeringUnit.METER and target == EngineeringUnit.MILLIMETER:
            return Quantity(val * 1000.0, target)
        if self.unit == EngineeringUnit.MILLIMETER and target == EngineeringUnit.METER:
            return Quantity(val / 1000.0, target)
            
        # Mass
        if self.unit == EngineeringUnit.TONNE and target == EngineeringUnit.KILOGRAM:
            return Quantity(val * 1000.0, target)
        if self.unit == EngineeringUnit.KILOGRAM and target == EngineeringUnit.TONNE:
            return Quantity(val / 1000.0, target)
            
        # Speed
        if self.unit == EngineeringUnit.KM_PER_HOUR and target == EngineeringUnit.METER_PER_SEC:
            return Quantity(val / 3.6, target)
        if self.unit == EngineeringUnit.METER_PER_SEC and target == EngineeringUnit.KM_PER_HOUR:
            return Quantity(val * 3.6, target)

        raise TypeError(f"Incompatible unit conversion from {self.unit} to {target}")

    def __repr__(self) -> str:
        return f"{self.value} {self.unit.value}"


class ProvenanceState(str, Enum):
    MEASURED = "MEASURED"
    INFERRED = "INFERRED"
    ESTIMATED = "ESTIMATED"
    UNKNOWN = "UNKNOWN"


class TraceabilityRecord:
    """Ensures every engineering calculation has traceable metadata."""
    
    def __init__(self, calculation_id: str, input_dataset: str, kernel_name: str, 
                 resolution: str, result_data: Dict[str, Any], units_used: Dict[str, str]):
        self.calculation_id = calculation_id
        self.input_dataset = input_dataset
        self.kernel_name = kernel_name
        self.resolution = resolution
        self.timestamp = datetime.utcnow().isoformat() + "Z"
        self.result_data = result_data
        self.units_used = units_used

    def to_dict(self) -> Dict[str, Any]:
        return {
            "calculation_id": self.calculation_id,
            "input_dataset": self.input_dataset,
            "kernel": self.kernel_name,
            "resolution": self.resolution,
            "timestamp": self.timestamp,
            "units": self.units_used,
            "result": self.result_data
        }


def assert_safety_boundary(operation_type: str):
    """
    Guards safety limits.
    Prevents autonomous connection or control of physical signaling, trains or machinery.
    """
    prohibited = ["AUTONOMOUS_TRAIN_CONTROL", "SIGNALLING_OVERRIDE", "MACHINERY_ACTUATION"]
    if operation_type in prohibited:
        raise PermissionError(
            f"SAFETY BOUNDARY VIOLATION: {operation_type} is prohibited. "
            "Railway 4.0 is a decision-support and planning twin only."
        )
