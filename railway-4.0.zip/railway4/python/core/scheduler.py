"""
Computational Scheduler & Caching Engine for Railway 4.0
"""

import hashlib
import json
from typing import Callable, Any, Dict, Optional

class ComputationalScheduler:
    """Task router selecting scalar Python execution or SilicaFlux vector/parallel kernels based on workload size."""

    @staticmethod
    def dispatch(data_size: int, 
                 small_workload_fn: Callable[[], Any], 
                 large_workload_fn: Callable[[], Any], 
                 vector_threshold: int = 500) -> Any:
        """Chooses low-overhead scalar vs SilicaFlux accelerated execution path."""
        if data_size < vector_threshold:
            return small_workload_fn()
        else:
            return large_workload_fn()


class CalculationCache:
    """In-memory calculation cache using deterministic input cryptographic hashes."""
    
    def __init__(self):
        self._store: Dict[str, Any] = {}

    def _generate_key(self, dataset_id: str, kernel_version: str, params: Dict[str, Any]) -> str:
        param_str = json.dumps(params, sort_keys=True)
        raw_key = f"{dataset_id}:{kernel_version}:{param_str}"
        return hashlib.sha256(raw_key.encode('utf-8')).hexdigest()

    def get(self, dataset_id: str, kernel_version: str, params: Dict[str, Any]) -> Optional[Any]:
        key = self._generate_key(dataset_id, kernel_version, params)
        return self._store.get(key)

    def set(self, dataset_id: str, kernel_version: str, params: Dict[str, Any], result: Any):
        key = self._generate_key(dataset_id, kernel_version, params)
        self._store[key] = result
        
    def clear(self):
        self._store.clear()
