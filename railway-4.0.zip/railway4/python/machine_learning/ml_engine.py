"""
Machine Learning Engine & Multi-Objective Optimisation Engine
Modular ML forecasting models (productivity, delay risk, material demand) and Pareto optimizer.
"""

import math
from typing import Dict, List, Any
from railway4.silicaflux import OptimisationKernel, StatisticsKernel

class MachineLearningEngine:
    """Predicts construction productivity, completion delays, and material demand."""

    def predict_productivity(self, machine_count: int, weather_index: float, 
                             ground_condition_index: float) -> Dict[str, Any]:
        """
        Predicts metres/day, tonnes/day, and m3/day production.
        Inputs: weather (0 clear to 1 storm), ground (1 soft soil to 5 hard rock).
        """
        # Base productivity per machine per day
        base_m3_day = machine_count * 850.0
        base_metres_day = machine_count * 45.0
        
        weather_factor = max(0.2, 1.0 - (weather_index * 0.5))
        ground_factor = max(0.2, 1.0 / (0.8 + 0.3 * ground_condition_index))
        
        predicted_m3_day = base_m3_day * weather_factor * ground_factor
        predicted_metres_day = base_metres_day * weather_factor * ground_factor
        
        confidence = 0.92 if weather_index < 0.3 else 0.78
        
        return {
            "forecast_m3_per_day": round(predicted_m3_day, 1),
            "forecast_metres_per_day": round(predicted_metres_day, 1),
            "confidence_score": confidence,
            "dominant_factors": [
                f"Weather Severity Index ({round(weather_index, 2)})",
                f"Ground Condition Index ({ground_condition_index})",
                f"Active Machinery Count ({machine_count})"
            ]
        }

    def predict_schedule_delay_risk(self, progress_pct: float, 
                                     weather_delay_days: int, 
                                     equipment_downtime_hours: float) -> Dict[str, Any]:
        """Probabilistic delay model calculating likelihood of milestone slip."""
        risk_score = (100.0 - progress_pct) * 0.005 + (weather_delay_days * 0.08) + (equipment_downtime_hours * 0.012)
        delay_prob = min(0.99, max(0.01, risk_score))
        expected_delay_days = round(delay_prob * 45.0, 1)
        
        return {
            "delay_probability": round(delay_prob, 3),
            "expected_delay_days": expected_delay_days,
            "confidence_interval_95": [round(expected_delay_days * 0.6, 1), round(expected_delay_days * 1.5, 1)],
            "contributing_variables": {
                "weather_delays": f"{weather_delay_days} days logged",
                "equipment_downtime": f"{equipment_downtime_hours} hours logged",
                "remaining_scope_pct": f"{round(100.0 - progress_pct, 1)}%"
            }
        }

    def forecast_material_demand(self, remaining_track_km: float, 
                                  bridges_remaining: int, 
                                  tunnels_remaining: int) -> Dict[str, Any]:
        """Forecasts steel, ballast, concrete, and sleeper demands."""
        rail_steel_tonnes = remaining_track_km * 240.0 # ~240t/km double track
        sleepers_count = int(remaining_track_km * 3333)
        ballast_m3 = remaining_track_km * 2450.0
        concrete_m3 = (remaining_track_km * 150.0) + (bridges_remaining * 4500.0) + (tunnels_remaining * 12500.0)
        
        return {
            "rail_steel_tonnes": round(rail_steel_tonnes, 1),
            "sleepers_units": sleepers_count,
            "ballast_volume_m3": round(ballast_m3, 1),
            "structural_concrete_m3": round(concrete_m3, 1)
        }


class OptimisationEngine:
    """Multi-objective route & construction strategy optimizer."""

    def __init__(self, weights: Dict[str, float] = None):
        self.weights = weights or {"TIME": 0.35, "COST": 0.30, "CARBON": 0.20, "EARTHWORK": 0.15}
        self.opt_kernel = OptimisationKernel()

    def evaluate_candidates(self, candidates: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Evaluates route/construction candidates and returns ranked Pareto solutions."""
        evaluated = []
        for cand in candidates:
            res = self.opt_kernel.evaluate_route_candidate(
                route_length_km=cand["route_length_km"],
                cut_vol_m3=cand["cut_m3"],
                fill_vol_m3=cand["fill_m3"],
                bridges_count=cand["bridges_count"],
                tunnels_count=cand["tunnels_count"],
                weights=self.weights
            )
            res["candidate_id"] = cand.get("candidate_id", f"CAND-{len(evaluated)+1}")
            res["name"] = cand.get("name", "Unnamed Route Option")
            evaluated.append(res)
            
        evaluated.sort(key=lambda x: x["fitness_score"])
        return evaluated
