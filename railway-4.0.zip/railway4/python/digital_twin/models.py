"""
Railway 4.0 Digital Twin Asset Models
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Any
from datetime import datetime

class AssetType(str, Enum):
    RAIL_SECTION = "RailSection"
    BRIDGE = "Bridge"
    TUNNEL = "Tunnel"
    SLEEPER_SECTION = "SleeperSection"
    FORMATION_SECTION = "FormationSection"
    STATION = "Station"
    GUIDEWAY_SECTION = "GuidewaySection"
    DRAINAGE_SECTION = "DrainageSection"
    EARTHWORK_ZONE = "EarthworkZone"


class ConstructionState(str, Enum):
    DESIGNED = "DESIGNED"
    PROCURED = "PROCURED"
    SITE_PREPARATION = "SITE_PREPARATION"
    CONSTRUCTION = "CONSTRUCTION"
    INSPECTION = "INSPECTION"
    COMPLETE = "COMPLETE"
    AS_BUILT = "AS_BUILT"


@dataclass
class InspectionRecord:
    inspection_id: str
    timestamp: str
    inspector: str
    inspection_type: str
    measurement: float
    expected_range: List[float]
    passed: bool
    evidence_notes: str


@dataclass
class Asset:
    asset_id: str
    name: str
    asset_type: AssetType
    start_chainage_km: float
    end_chainage_km: float
    coordinates: List[List[float]] # List of [lat, lon, elev]
    construction_state: ConstructionState = ConstructionState.DESIGNED
    state_history: List[Dict[str, str]] = field(default_factory=list)
    engineering_properties: Dict[str, Any] = field(default_factory=dict)
    material_properties: Dict[str, Any] = field(default_factory=dict)
    cost_gbp: float = 0.0
    actual_cost_gbp: float = 0.0
    planned_start_day: int = 0
    planned_completion_day: int = 30
    actual_completion_day: Optional[int] = None
    inspections: List[InspectionRecord] = field(default_factory=list)
    maintenance_history: List[Dict[str, Any]] = field(default_factory=list)

    def transition_state(self, new_state: ConstructionState, operator: str = "System"):
        old_state = self.construction_state
        self.construction_state = new_state
        entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "from_state": old_state.value,
            "to_state": new_state.value,
            "operator": operator
        }
        self.state_history.append(entry)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "asset_id": self.asset_id,
            "name": self.name,
            "asset_type": self.asset_type.value,
            "start_chainage_km": self.start_chainage_km,
            "end_chainage_km": self.end_chainage_km,
            "coordinates": self.coordinates,
            "construction_state": self.construction_state.value,
            "cost_gbp": self.cost_gbp,
            "actual_cost_gbp": self.actual_cost_gbp,
            "engineering_properties": self.engineering_properties,
            "material_properties": self.material_properties,
            "inspections": [
                {
                    "inspection_id": ins.inspection_id,
                    "inspector": ins.inspector,
                    "passed": ins.passed,
                    "measurement": ins.measurement,
                    "timestamp": ins.timestamp
                } for ins in self.inspections
            ],
            "state_history": self.state_history
        }
