"""
Event Sourcing Store for Railway 4.0 Digital Twin
Immutable append-only audit trail and time-travel state reconstruction.
"""

from datetime import datetime
from typing import Dict, List, Any, Optional

class DigitalTwinEventStore:
    """Immutable event journal for all digital twin state transitions and mutations."""

    def __init__(self):
        self._events: List[Dict[str, Any]] = []

    def record_event(self, asset_id: str, event_type: str, input_payload: Dict[str, Any], 
                     operator: str, model_version: str, result_state: Dict[str, Any]):
        event = {
            "event_id": f"EVT-{len(self._events)+1:06d}",
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "asset_id": asset_id,
            "event_type": event_type,
            "input": input_payload,
            "operator": operator,
            "model_version": model_version,
            "result": result_state
        }
        self._events.append(event)

    def get_events_for_asset(self, asset_id: str) -> List[Dict[str, Any]]:
        return [e for e in self._events if e["asset_id"] == asset_id]

    def get_full_history(self) -> List[Dict[str, Any]]:
        return list(self._events)
