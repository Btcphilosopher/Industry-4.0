"""
Digital Twin Registry
Central repository for all railway infrastructure assets.
"""

from typing import Dict, List, Optional, Any
from railway4.python.digital_twin.models import Asset, AssetType, ConstructionState
from railway4.python.digital_twin.event_store import DigitalTwinEventStore
from railway4.python.digital_twin.scenario import ScenarioBranch, DigitalTwinSnapshot

class DigitalTwinRegistry:
    """Stateful coordinator for digital twin assets, snapshots, and event sourcing."""

    def __init__(self, project_id: str = "PROJ-GB-HS250"):
        self.project_id = project_id
        self.assets: Dict[str, Asset] = {}
        self.event_store = DigitalTwinEventStore()
        self.snapshots: Dict[str, DigitalTwinSnapshot] = {}
        self.scenarios: Dict[str, ScenarioBranch] = {
            "BASELINE": ScenarioBranch("BASELINE", "Project Baseline")
        }
        self.current_scenario_id = "BASELINE"

    def add_asset(self, asset: Asset):
        self.assets[asset.asset_id] = asset
        self.event_store.record_event(
            asset_id=asset.asset_id,
            event_type="ASSET_CREATED",
            input_payload=asset.to_dict(),
            operator="SYSTEM",
            model_version="4.0",
            result_state={"status": "REGISTERED"}
        )

    def get_asset(self, asset_id: str) -> Optional[Asset]:
        return self.assets.get(asset_id)

    def list_assets(self, asset_type: Optional[AssetType] = None) -> List[Asset]:
        if asset_type:
            return [a for a in self.assets.values() if a.asset_type == asset_type]
        return list(self.assets.values())

    def transition_asset_state(self, asset_id: str, new_state: ConstructionState, operator: str = "Engineer") -> bool:
        asset = self.get_asset(asset_id)
        if not asset:
            return False
            
        old_state = asset.construction_state
        asset.transition_state(new_state, operator)
        
        self.event_store.record_event(
            asset_id=asset_id,
            event_type="STATE_TRANSITION",
            input_payload={"from": old_state.value, "to": new_state.value},
            operator=operator,
            model_version="4.0",
            result_state={"current_state": new_state.value}
        )
        return True

    def create_snapshot(self, snapshot_id: str, project_day: int) -> DigitalTwinSnapshot:
        snap = DigitalTwinSnapshot(snapshot_id, project_day, list(self.assets.values()))
        self.snapshots[snapshot_id] = snap
        return snap

    def create_scenario(self, scenario_id: str, name: str) -> ScenarioBranch:
        scen = ScenarioBranch(scenario_id, name, parent_branch=self.scenarios.get("BASELINE"))
        scen.clone_from_assets(list(self.assets.values()))
        self.scenarios[scenario_id] = scen
        return scen

    def get_summary_stats(self) -> Dict[str, Any]:
        total = len(self.assets)
        completed = len([a for a in self.assets.values() if a.construction_state in (ConstructionState.COMPLETE, ConstructionState.AS_BUILT)])
        in_progress = len([a for a in self.assets.values() if a.construction_state == ConstructionState.CONSTRUCTION])
        planned = len([a for a in self.assets.values() if a.construction_state == ConstructionState.DESIGNED])
        
        total_cost = sum(a.cost_gbp for a in self.assets.values())
        actual_cost = sum(a.actual_cost_gbp for a in self.assets.values())
        
        return {
            "project_id": self.project_id,
            "total_assets": total,
            "completed_assets": completed,
            "in_progress_assets": in_progress,
            "planned_assets": planned,
            "progress_percent": round((completed / total * 100.0), 1) if total > 0 else 0.0,
            "planned_cost_gbp": round(total_cost, 2),
            "actual_cost_gbp": round(actual_cost, 2),
            "snapshots_count": len(self.snapshots),
            "scenarios_count": len(self.scenarios)
        }
