"""
Digital Twin Scenario Branching & Snapshot Manager
"""

import copy
from typing import Dict, List, Any, Optional
from railway4.python.digital_twin.models import Asset

class DigitalTwinSnapshot:
    """Point-in-time state capture of the railway digital twin."""

    def __init__(self, snapshot_id: str, project_day: int, assets: List[Asset]):
        self.snapshot_id = snapshot_id
        self.project_day = project_day
        self.timestamp = datetime.utcnow().isoformat() + "Z" if 'datetime' in globals() else ""
        self.assets = copy.deepcopy(assets)

    def compare_with(self, other: 'DigitalTwinSnapshot') -> Dict[str, Any]:
        """Compares two snapshots and highlights progress & cost variance."""
        changed_assets = []
        for a1 in self.assets:
            matching = next((a2 for a2 in other.assets if a2.asset_id == a1.asset_id), None)
            if matching and (a1.construction_state != matching.construction_state or a1.actual_cost_gbp != matching.actual_cost_gbp):
                changed_assets.append({
                    "asset_id": a1.asset_id,
                    "name": a1.name,
                    "old_state": a1.construction_state.value,
                    "new_state": matching.construction_state.value,
                    "cost_diff_gbp": matching.actual_cost_gbp - a1.actual_cost_gbp
                })
        return {
            "from_snapshot": self.snapshot_id,
            "to_snapshot": other.snapshot_id,
            "changed_assets_count": len(changed_assets),
            "changes": changed_assets
        }


class ScenarioBranch:
    """Isolated scenario branch inheriting base project configuration."""

    def __init__(self, scenario_id: str, name: str, parent_branch: Optional['ScenarioBranch'] = None):
        self.scenario_id = scenario_id
        self.name = name
        self.parent_branch = parent_branch
        self.assets: Dict[str, Asset] = {}
        self.parameters_override: Dict[str, Any] = {}

    def clone_from_assets(self, assets_list: List[Asset]):
        self.assets = {a.asset_id: copy.deepcopy(a) for a in assets_list}

    def set_parameter_override(self, key: str, value: Any):
        self.parameters_override[key] = value

    def to_dict(self) -> Dict[str, Any]:
        return {
            "scenario_id": self.scenario_id,
            "name": self.name,
            "overrides": self.parameters_override,
            "asset_count": len(self.assets)
        }
