"""
SilicaFlux Terrain Kernels
DEM/DTM processing, point cloud interpolation, slope/aspect calculation.
"""

import math
from typing import Dict, List, Tuple, Any

class TerrainKernel:
    """High-performance terrain interpolation and topographic analysis."""

    @staticmethod
    def interpolate_idw(survey_points: List[Tuple[float, float, float]], 
                        target_x: float, target_y: float, power: float = 2.0) -> float:
        """Inverse Distance Weighting (IDW) surface elevation interpolation."""
        if not survey_points:
            return 0.0
        
        weighted_sum = 0.0
        weight_total = 0.0
        
        for px, py, pz in survey_points:
            dist = math.sqrt((target_x - px)**2 + (target_y - py)**2)
            if dist < 1e-6:
                return pz
            w = 1.0 / (dist ** power)
            weighted_sum += w * pz
            weight_total += w
            
        return weighted_sum / weight_total if weight_total > 0 else 0.0

    @staticmethod
    def calculate_slope_and_aspect(z_grid: List[List[float]], cell_size: float) -> List[List[Dict[str, float]]]:
        """Calculates topographic slope (%) and aspect (degrees) over a 2D DEM grid using Horn's method."""
        rows = len(z_grid)
        cols = len(z_grid[0]) if rows > 0 else 0
        output = [[{"slope_pct": 0.0, "aspect_deg": 0.0} for _ in range(cols)] for _ in range(rows)]
        
        for r in range(1, rows - 1):
            for c in range(1, cols - 1):
                dz_dx = ((z_grid[r-1][c+1] + 2*z_grid[r][c+1] + z_grid[r+1][c+1]) - 
                         (z_grid[r-1][c-1] + 2*z_grid[r][c-1] + z_grid[r+1][c-1])) / (8.0 * cell_size)
                         
                dz_dy = ((z_grid[r+1][c-1] + 2*z_grid[r+1][c] + z_grid[r+1][c+1]) - 
                         (z_grid[r-1][c-1] + 2*z_grid[r-1][c] + z_grid[r-1][c+1])) / (8.0 * cell_size)
                         
                slope_rad = math.atan(math.sqrt(dz_dx**2 + dz_dy**2))
                slope_pct = math.tan(slope_rad) * 100.0
                
                aspect_rad = math.atan2(dz_dy, -dz_dx)
                aspect_deg = math.degrees(aspect_rad)
                if aspect_deg < 0:
                    aspect_deg += 360.0
                    
                output[r][c] = {
                    "slope_pct": round(slope_pct, 2),
                    "aspect_deg": round(aspect_deg, 2)
                }
        return output

    @staticmethod
    def compute_surface_grid(points: List[Tuple[float, float, float]], 
                             bounds: Tuple[float, float, float, float], 
                             resolution: float) -> Dict[str, Any]:
        """Generates a regular DEM grid from scattered survey/LiDAR points."""
        min_x, max_x, min_y, max_y = bounds
        cols = max(1, int((max_x - min_x) / resolution) + 1)
        rows = max(1, int((max_y - min_y) / resolution) + 1)
        
        grid = []
        for r in range(rows):
            y = min_y + r * resolution
            row_data = []
            for c in range(cols):
                x = min_x + c * resolution
                z = TerrainKernel.interpolate_idw(points, x, y)
                row_data.append(round(z, 3))
            grid.append(row_data)
            
        return {
            "bounds": bounds,
            "resolution": resolution,
            "rows": rows,
            "cols": cols,
            "grid": grid
        }
