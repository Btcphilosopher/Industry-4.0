"""
SilicaFlux Vector Operations Kernel
High-performance SIMD-friendly vector arithmetic and transformations.
"""

import math
from typing import List, Tuple, Union

class SilicaVector:
    """Typed numerical vector container optimized for numerical calculations."""
    
    __slots__ = ('data', 'size')
    
    def __init__(self, data: List[float]):
        self.data = [float(x) for x in data]
        self.size = len(self.data)
        
    def add(self, other: 'SilicaVector') -> 'SilicaVector':
        if self.size != other.size:
            raise ValueError(f"Vector size mismatch: {self.size} vs {other.size}")
        return SilicaVector([a + b for a, b in zip(self.data, other.data)])

    def subtract(self, other: 'SilicaVector') -> 'SilicaVector':
        if self.size != other.size:
            raise ValueError(f"Vector size mismatch: {self.size} vs {other.size}")
        return SilicaVector([a - b for a, b in zip(self.data, other.data)])

    def scale(self, factor: float) -> 'SilicaVector':
        return SilicaVector([a * factor for a in self.data])

    def dot(self, other: 'SilicaVector') -> float:
        if self.size != other.size:
            raise ValueError(f"Vector size mismatch: {self.size} vs {other.size}")
        return sum(a * b for a, b in zip(self.data, other.data))

    def norm(self) -> float:
        return math.sqrt(sum(a * a for a in self.data))

    def normalize(self) -> 'SilicaVector':
        n = self.norm()
        if n == 0.0:
            return SilicaVector([0.0] * self.size)
        return self.scale(1.0 / n)

def batch_euclidean_distance(pts_a: List[Tuple[float, float, float]], 
                             pts_b: List[Tuple[float, float, float]]) -> List[float]:
    """Fast batch calculation of 3D point distances."""
    results = []
    for (x1, y1, z1), (x2, y2, z2) in zip(pts_a, pts_b):
        dx = x2 - x1
        dy = y2 - y1
        dz = z2 - z1
        results.append(math.sqrt(dx * dx + dy * dy + dz * dz))
    return results

def batch_polyline_lengths(coords: List[Tuple[float, float, float]]) -> Tuple[float, List[float]]:
    """Calculates cumulative chainage and total 3D length along a polyline."""
    if not coords:
        return 0.0, []
    chainage = [0.0]
    total = 0.0
    for i in range(1, len(coords)):
        x1, y1, z1 = coords[i-1]
        x2, y2, z2 = coords[i]
        dist = math.sqrt((x2-x1)**2 + (y2-y1)**2 + (z2-z1)**2)
        total += dist
        chainage.append(total)
    return total, chainage
