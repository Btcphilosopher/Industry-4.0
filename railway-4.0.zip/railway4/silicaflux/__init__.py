"""
SilicaFlux High-Performance Computational Kernel Architecture
"""

from railway4.silicaflux.vector.vector_ops import SilicaVector, batch_euclidean_distance, batch_polyline_lengths
from railway4.silicaflux.matrix.matrix_ops import SilicaMatrix
from railway4.silicaflux.geometry.geometry_kernels import GeometryKernel
from railway4.silicaflux.terrain.terrain_kernels import TerrainKernel
from railway4.silicaflux.earthworks.earthwork_kernels import EarthworkKernel
from railway4.silicaflux.structures.structure_kernels import StructureKernel, TrackKernel, MaterialKernel
from railway4.silicaflux.optimisation.optimisation_kernels import (
    OptimisationKernel, 
    StatisticsKernel, 
    SimulationKernel, 
    TelemetryKernel
)
from railway4.silicaflux.parallel.executor import SilicaParallelExecutor

__all__ = [
    'SilicaVector',
    'SilicaMatrix',
    'GeometryKernel',
    'TerrainKernel',
    'EarthworkKernel',
    'StructureKernel',
    'TrackKernel',
    'MaterialKernel',
    'OptimisationKernel',
    'StatisticsKernel',
    'SimulationKernel',
    'TelemetryKernel',
    'SilicaParallelExecutor'
]
