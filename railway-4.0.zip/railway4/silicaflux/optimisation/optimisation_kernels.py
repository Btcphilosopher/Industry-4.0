"""
SilicaFlux Optimisation, Statistics, Simulation, Telemetry, and Parallel Execution Kernels
"""

import math
import random
from typing import Dict, List, Tuple, Any

class OptimisationKernel:
    """Multi-objective fitness evaluation and Pareto frontier selection."""

    @staticmethod
    def evaluate_route_candidate(route_length_km: float, 
                                 cut_vol_m3: float, 
                                 fill_vol_m3: float, 
                                 bridges_count: int, 
                                 tunnels_count: int, 
                                 weights: Dict[str, float]) -> Dict[str, float]:
        """Evaluates cost, schedule time (months), carbon (tCO2e), and overall penalty score."""
        # Cost estimates (£)
        c_rail = route_length_km * 4_500_000.0
        c_earth = (cut_vol_m3 + fill_vol_m3) * 18.0
        c_bridges = bridges_count * 12_000_000.0
        c_tunnels = tunnels_count * 45_000_000.0
        total_cost_gbp = c_rail + c_earth + c_bridges + c_tunnels
        
        # Duration estimates (months)
        time_months = (route_length_km / 12.0) + (bridges_count * 1.5) + (tunnels_count * 4.0)
        
        # Carbon estimates (tCO2e)
        carbon_tco2e = (route_length_km * 350.0) + ((cut_vol_m3 + fill_vol_m3) * 0.008) + (bridges_count * 2500) + (tunnels_count * 8000)
        
        # Weighted objective score (lower is better)
        w_cost = weights.get('COST', 0.35)
        w_time = weights.get('TIME', 0.30)
        w_carbon = weights.get('CARBON', 0.20)
        w_earth = weights.get('EARTHWORK', 0.15)
        
        normalized_cost = total_cost_gbp / 1_000_000_000.0 # billions
        normalized_time = time_months / 48.0 # 4 years scale
        normalized_carbon = carbon_tco2e / 200_000.0
        normalized_earth = (cut_vol_m3 + fill_vol_m3) / 10_000_000.0
        
        fitness_score = (w_cost * normalized_cost + 
                         w_time * normalized_time + 
                         w_carbon * normalized_carbon + 
                         w_earth * normalized_earth)
                         
        return {
            "total_cost_gbp": round(total_cost_gbp, 2),
            "time_months": round(time_months, 1),
            "carbon_tco2e": round(carbon_tco2e, 1),
            "earthwork_m3": round(cut_vol_m3 + fill_vol_m3, 1),
            "fitness_score": round(fitness_score, 4)
        }


class StatisticsKernel:
    """Vectorized Monte Carlo distribution sampling and percentile analysis (P10, P50, P90)."""

    @staticmethod
    def monte_carlo_cost_time_simulation(base_cost: float, 
                                          base_time_days: float, 
                                          iterations: int = 5000, 
                                          weather_risk: float = 0.15, 
                                          ground_risk: float = 0.20) -> Dict[str, Any]:
        """Runs vectorized Monte Carlo simulation to compute cost and completion date distributions."""
        costs = []
        times = []
        
        random.seed(42) # Deterministic execution
        for _ in range(iterations):
            w_factor = random.triangular(0.9, 1.0 + weather_risk, 1.4)
            g_factor = random.triangular(0.95, 1.0 + ground_risk, 1.5)
            
            sim_cost = base_cost * (0.8 * w_factor + 0.2 * g_factor)
            sim_time = base_time_days * (0.5 * w_factor + 0.5 * g_factor)
            
            costs.append(sim_cost)
            times.append(sim_time)
            
        costs.sort()
        times.sort()
        
        idx_p10 = int(iterations * 0.10)
        idx_p50 = int(iterations * 0.50)
        idx_p90 = int(iterations * 0.90)
        
        return {
            "iterations": iterations,
            "cost_distribution": {
                "P10": round(costs[idx_p10], 2),
                "P50": round(costs[idx_p50], 2),
                "P90": round(costs[idx_p90], 2),
                "mean": round(sum(costs)/iterations, 2)
            },
            "completion_days_distribution": {
                "P10": round(times[idx_p10], 1),
                "P50": round(times[idx_p50], 1),
                "P90": round(times[idx_p90], 1),
                "mean": round(sum(times)/iterations, 1)
            }
        }


class SimulationKernel:
    """Discrete-event construction simulation step kernel."""

    @staticmethod
    def step_machine_productivity(machine_type: str, 
                                   weather_severity: float, 
                                   ground_hardness: float, 
                                   base_capacity_m3_h: float = 120.0) -> float:
        """Determines effective hourly production rate given environmental factors."""
        # Weather penalty (0.0 clear to 1.0 storm)
        w_penalty = max(0.2, 1.0 - (weather_severity * 0.6))
        # Ground hardness penalty (1.0 soft soil to 5.0 solid granite)
        g_penalty = max(0.15, 1.0 / (1.0 + 0.35 * (ground_hardness - 1.0)))
        
        effective_rate = base_capacity_m3_h * w_penalty * g_penalty
        return round(effective_rate, 2)


class TelemetryKernel:
    """High-volume telemetry data aggregation and anomaly filter."""

    @staticmethod
    def aggregate_telemetry_batch(records: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Calculates active machine count, total fuel consumed, average speed, temperature anomalies."""
        if not records:
            return {"active_machines": 0, "total_fuel_l": 0.0, "anomalies_detected": 0}

        machines = set()
        total_fuel = 0.0
        speeds = []
        anomalies = 0

        for r in records:
            machines.add(r.get("machine_id"))
            total_fuel += r.get("fuel_consumed_l", 0.0)
            speeds.append(r.get("speed_kmh", 0.0))
            if r.get("engine_temp_c", 80) > 105 or r.get("hydraulic_pressure_bar", 200) > 350:
                anomalies += 1

        avg_speed = sum(speeds) / len(speeds) if speeds else 0.0

        return {
            "total_records_processed": len(records),
            "active_machines": len(machines),
            "total_fuel_l": round(total_fuel, 2),
            "avg_speed_kmh": round(avg_speed, 2),
            "anomalies_detected": anomalies
        }
