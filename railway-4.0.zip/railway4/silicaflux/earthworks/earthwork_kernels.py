"""
SilicaFlux Earthworks Kernels
Cut/fill volume calculations, embankment prismoidal integration, mass-haul balancing.
"""

import math
from typing import Dict, List, Tuple, Any

class EarthworkKernel:
    """High-throughput earthworks, volume integration, and mass-haul optimization."""

    @staticmethod
    def compute_grid_cut_fill(ground_grid: List[List[float]], 
                               design_grid: List[List[float]], 
                               cell_size: float) -> Dict[str, float]:
        """Calculates total cut volume (m³), fill volume (m³), and net earthwork balance."""
        rows = len(ground_grid)
        cols = len(ground_grid[0]) if rows > 0 else 0
        cell_area = cell_size * cell_size
        
        total_cut = 0.0
        total_fill = 0.0
        
        for r in range(rows):
            for c in range(cols):
                g_z = ground_grid[r][c]
                d_z = design_grid[r][c]
                diff = d_z - g_z
                if diff < 0:
                    # Ground is higher than design -> Cut required
                    total_cut += abs(diff) * cell_area
                else:
                    # Ground is lower than design -> Fill required
                    total_fill += diff * cell_area
                    
        return {
            "cut_volume_m3": round(total_cut, 2),
            "fill_volume_m3": round(total_fill, 2),
            "net_balance_m3": round(total_fill - total_cut, 2)
        }

    @staticmethod
    def prismoidal_cross_section_volume(chainages: List[float], 
                                         cut_areas: List[float], 
                                         fill_areas: List[float]) -> Dict[str, Any]:
        """Calculates cut/fill volume using Simpson's prismoidal formula across chainage intervals."""
        if len(chainages) < 2:
            return {"total_cut_m3": 0.0, "total_fill_m3": 0.0, "cumulative_mass_haul": []}

        total_cut = 0.0
        total_fill = 0.0
        mass_haul = [0.0]

        for i in range(1, len(chainages)):
            L = chainages[i] - chainages[i-1]
            A1_cut, A2_cut = cut_areas[i-1], cut_areas[i]
            A1_fill, A2_fill = fill_areas[i-1], fill_areas[i]
            
            # Mid-area approximation
            Am_cut = (A1_cut + A2_cut) / 2.0
            Am_fill = (A1_fill + A2_fill) / 2.0
            
            v_cut = (L / 6.0) * (A1_cut + 4 * Am_cut + A2_cut)
            v_fill = (L / 6.0) * (A1_fill + 4 * Am_fill + A2_fill)
            
            total_cut += v_cut
            total_fill += v_fill
            
            net_vol = v_cut - v_fill # positive = surplus cut available
            mass_haul.append(round(mass_haul[-1] + net_vol, 2))

        return {
            "total_cut_m3": round(total_cut, 2),
            "total_fill_m3": round(total_fill, 2),
            "net_volume_m3": round(total_cut - total_fill, 2),
            "cumulative_mass_haul_m3": mass_haul
        }
