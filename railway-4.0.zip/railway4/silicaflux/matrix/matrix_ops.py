"""
SilicaFlux Matrix Operations Kernel
Matrix arithmetic, systems of linear equations, tensor blocks.
"""

from typing import List, Tuple

class SilicaMatrix:
    """Dense matrix container for numerical engineering computations."""
    
    def __init__(self, rows: int, cols: int, initial_value: float = 0.0):
        self.rows = rows
        self.cols = cols
        self.data = [[float(initial_value)] * cols for _ in range(rows)]

    @classmethod
    def from_list(cls, data: List[List[float]]) -> 'SilicaMatrix':
        rows = len(data)
        cols = len(data[0]) if rows > 0 else 0
        mat = cls(rows, cols)
        mat.data = [[float(val) for val in row] for row in data]
        return mat

    def multiply(self, other: 'SilicaMatrix') -> 'SilicaMatrix':
        if self.cols != other.rows:
            raise ValueError(f"Matrix dimension error: ({self.rows}x{self.cols}) x ({other.rows}x{other.cols})")
        res = SilicaMatrix(self.rows, other.cols)
        for i in range(self.rows):
            for k in range(self.cols):
                r_ik = self.data[i][k]
                for j in range(other.cols):
                    res.data[i][j] += r_ik * other.data[k][j]
        return res

    def transpose(self) -> 'SilicaMatrix':
        res = SilicaMatrix(self.cols, self.rows)
        for i in range(self.rows):
            for j in range(self.cols):
                res.data[j][i] = self.data[i][j]
        return res

    def solve_linear_system(self, b: List[float]) -> List[float]:
        """Gaussian elimination solver for Ax = b."""
        n = self.rows
        if n != self.cols or len(b) != n:
            raise ValueError("Matrix must be square and match vector b size")
            
        A = [row[:] for row in self.data]
        x = b[:]
        
        for i in range(n):
            # Pivot
            max_row = i
            for k in range(i + 1, n):
                if abs(A[k][i]) > abs(A[max_row][i]):
                    max_row = k
            A[i], A[max_row] = A[max_row], A[i]
            x[i], x[max_row] = x[max_row], x[i]
            
            pivot = A[i][i]
            if abs(pivot) < 1e-12:
                continue # singular or near singular
                
            for k in range(i + 1, n):
                factor = A[k][i] / pivot
                for j in range(i, n):
                    A[k][j] -= factor * A[i][j]
                x[k] -= factor * x[i]
                
        # Back substitution
        res = [0.0] * n
        for i in range(n - 1, -1, -1):
            s = sum(A[i][j] * res[j] for j in range(i + 1, n))
            denom = A[i][i]
            res[i] = (x[i] - s) / denom if abs(denom) > 1e-12 else 0.0
        return res
