"""
SilicaFlux Geometry Kernels
Coordinate transformations, alignment geometry, cant calculations, chainage mapping.
"""

import math
from typing import Dict, List, Tuple, Any

class GeometryKernel:
    """High-performance geometry computation engine."""
    
    @staticmethod
    def latlon_to_utm(lat: float, lon: float) -> Tuple[float, float, int]:
        """Simplified WGS84 Lat/Lon to UTM Easting, Northing, Zone."""
        zone = int((lon + 180) / 6) + 1
        lat_rad = math.radians(lat)
        lon_rad = math.radians(lon)
        central_lon = math.radians((zone - 1) * 6 - 180 + 3)
        
        a = 6378137.0 # WGS84 semi-major axis
        f = 1 / 298.257223563
        e2 = 2 * f - f * f
        
        k0 = 0.9996
        N = a / math.sqrt(1 - e2 * math.sin(lat_rad)**2)
        T = math.tan(lat_rad)**2
        C = e2 / (1 - e2) * math.cos(lat_rad)**2
        A = (lon_rad - central_lon) * math.cos(lat_rad)
        
        M = a * ((1 - e2/4 - 3*e2**2/64 - 5*e2**3/256)*lat_rad 
                 - (3*e2/8 + 3*e2**2/32 + 45*e2**3/1024)*math.sin(2*lat_rad)
                 + (15*e2**2/256 + 45*e2**3/1024)*math.sin(4*lat_rad)
                 - (35*e2**3/3072)*math.sin(6*lat_rad))
                 
        easting = 500000.0 + k0 * N * (A + (1-T+C)*A**3/6 + (5-18*T+T**2+72*C-58*e2)*A**5/120)
        northing = k0 * (M + N * math.tan(lat_rad) * (A**2/2 + (5-T+9*C+4*C**2)*A**4/24 + (61-58*T+T**2+600*C-330*e2)*A**6/720))
        if lat < 0:
            northing += 10000000.0
            
        return easting, northing, zone

    @staticmethod
    def utm_to_latlon(easting: float, northing: float, zone: int, northern_hemisphere: bool = True) -> Tuple[float, float]:
        """Simplified UTM to Lat/Lon."""
        a = 6378137.0
        f = 1 / 298.257223563
        e2 = 2*f - f*f
        k0 = 0.9996
        
        x = easting - 500000.0
        y = northing if northern_hemisphere else northing - 10000000.0
        
        M = y / k0
        mu = M / (a * (1 - e2/4 - 3*e2**2/64 - 5*e2**3/256))
        
        e1 = (1 - math.sqrt(1 - e2)) / (1 + math.sqrt(1 - e2))
        
        phi1 = mu + (3*e1/2 - 27*e1**3/32)*math.sin(2*mu) + (21*e1**2/16 - 55*e1**4/32)*math.sin(4*mu)
        
        N1 = a / math.sqrt(1 - e2*math.sin(phi1)**2)
        T1 = math.tan(phi1)**2
        C1 = e2 / (1 - e2) * math.cos(phi1)**2
        R1 = a * (1 - e2) / ((1 - e2*math.sin(phi1)**2)**1.5)
        D = x / (N1 * k0)
        
        lat = phi1 - (N1 * math.tan(phi1) / R1) * (D**2/2 - (5 + 3*T1 + 10*C1 - 4*C1**2 - 9*e2)*D**4/24)
        lon = ((zone - 1)*6 - 180 + 3) + math.degrees((D - (1 + 2*T1 + C1)*D**3/6) / math.cos(phi1))
        
        return math.degrees(lat), lon

    @staticmethod
    def calculate_cant(radius_m: float, speed_kmh: float, gauge_m: float = 1.435) -> Dict[str, float]:
        """
        Calculates theoretical cant (superelevation) and equilibrium cant.
        Equilibrium cant E = 11.82 * V^2 / R (mm for 1435mm gauge)
        """
        if radius_m <= 0 or math.isinf(radius_m):
            return {"equilibrium_cant_mm": 0.0, "applied_cant_mm": 0.0, "cant_deficiency_mm": 0.0}
            
        eq_cant = (11.82 * (speed_kmh ** 2)) / radius_m
        applied_cant = min(eq_cant, 160.0) # max standard cant 160mm
        cant_deficiency = eq_cant - applied_cant
        return {
            "equilibrium_cant_mm": round(eq_cant, 2),
            "applied_cant_mm": round(applied_cant, 2),
            "cant_deficiency_mm": round(cant_deficiency, 2)
        }

    @staticmethod
    def interpolate_chainage_point(polyline: List[Tuple[float, float, float]], target_chainage: float) -> Dict[str, Any]:
        """Locates 3D coordinate and tangent at target chainage along a polyline."""
        if not polyline:
            return {"x": 0.0, "y": 0.0, "z": 0.0, "chainage": 0.0}
        if len(polyline) == 1 or target_chainage <= 0:
            return {"x": polyline[0][0], "y": polyline[0][1], "z": polyline[0][2], "chainage": 0.0}

        accum = 0.0
        for i in range(1, len(polyline)):
            p1 = polyline[i-1]
            p2 = polyline[i]
            dx = p2[0] - p1[0]
            dy = p2[1] - p1[1]
            dz = p2[2] - p1[2]
            seg_len = math.sqrt(dx*dx + dy*dy + dz*dz)
            
            if accum + seg_len >= target_chainage:
                fraction = (target_chainage - accum) / seg_len if seg_len > 0 else 0
                return {
                    "x": p1[0] + dx * fraction,
                    "y": p1[1] + dy * fraction,
                    "z": p1[2] + dz * fraction,
                    "chainage": target_chainage,
                    "bearing_deg": math.degrees(math.atan2(dx, dy)) % 360,
                    "gradient_pct": (dz / math.sqrt(dx*dx + dy*dy) * 100) if (dx*dx+dy*dy) > 0 else 0.0
                }
            accum += seg_len

        last = polyline[-1]
        return {"x": last[0], "y": last[1], "z": last[2], "chainage": accum}
