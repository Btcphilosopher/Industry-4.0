"""
SilicaFlux Structures, Track, and Materials Kernels
"""

import math
from typing import Dict, List, Any

class StructureKernel:
    """Numerical evaluation of bridges, viaducts, tunnels, retaining walls."""

    @staticmethod
    def bridge_beam_deflection(span_m: float, load_kN: float, E_GPa: float = 30.0, I_m4: float = 0.8) -> Dict[str, float]:
        """Calculates mid-span deflection and max bending moment for simply supported bridge span under live load."""
        P = load_kN * 1000.0 # convert to N
        E = E_GPa * 1e9 # convert to Pa
        L = span_m
        
        # Max moment M = P * L / 4
        moment_kNm = (load_kN * span_m) / 4.0
        # Deflection delta = P * L^3 / (48 * E * I)
        deflection_m = (P * (L ** 3)) / (48.0 * E * I_m4)
        deflection_mm = deflection_m * 1000.0
        
        allowable_mm = (span_m * 1000.0) / 800.0 # Eurocode standard span/800
        
        return {
            "max_moment_kNm": round(moment_kNm, 2),
            "deflection_mm": round(deflection_mm, 2),
            "allowable_deflection_mm": round(allowable_mm, 2),
            "passes_deflection_check": deflection_mm <= allowable_mm
        }

    @staticmethod
    def tunnel_excavation_volume(length_m: float, diameter_m: float) -> Dict[str, float]:
        """Calculates total muck excavation volume (m³) and lining concrete volume (m³)."""
        radius = diameter_m / 2.0
        excavation_v = math.pi * (radius ** 2) * length_m
        lining_thickness = 0.45 # meters
        inner_r = radius - lining_thickness
        concrete_v = (math.pi * (radius ** 2) - math.pi * (inner_r ** 2)) * length_m
        
        return {
            "excavation_volume_m3": round(excavation_v, 2),
            "segment_concrete_m3": round(concrete_v, 2)
        }


class TrackKernel:
    """Numerical modelling of rail steel mass, ballast volume, sleepers, and TQI (Track Quality Index)."""

    @staticmethod
    def calculate_track_quantities(track_length_km: float, 
                                    is_double_track: bool = True, 
                                    rail_type_kg_m: float = 60.0, 
                                    sleeper_spacing_m: float = 0.6) -> Dict[str, float]:
        """Computes track material quantities for steel rail, sleepers, ballast, and fasteners."""
        tracks = 2 if is_double_track else 1
        rail_length_m = track_length_km * 1000.0 * 2 * tracks # 2 rails per track
        total_rail_mass_tonnes = (rail_length_m * rail_type_kg_m) / 1000.0
        
        num_sleepers = int((track_length_km * 1000.0 / sleeper_spacing_m) * tracks)
        # Standard ballast prism: 0.35m depth x 3.5m width per track
        ballast_m3 = track_length_km * 1000.0 * 0.35 * 3.5 * tracks
        fasteners_count = num_sleepers * 4
        
        return {
            "track_length_km": track_length_km,
            "rail_steel_tonnes": round(total_rail_mass_tonnes, 2),
            "sleeper_count": num_sleepers,
            "ballast_volume_m3": round(ballast_m3, 2),
            "fasteners_count": fasteners_count
        }


class MaterialKernel:
    """Material transformations, carbon footprint density, supply chain mass aggregation."""

    @staticmethod
    def calculate_embodied_carbon(rail_steel_tonnes: float, 
                                   concrete_m3: float, 
                                   ballast_m3: float, 
                                   steel_factor: float = 1.82, 
                                   concrete_factor: float = 320.0, 
                                   ballast_factor: float = 8.5) -> Dict[str, float]:
        """Calculates total embodied carbon emissions (tCO2e) across structural materials."""
        co2_steel = rail_steel_tonnes * steel_factor # tCO2e
        co2_concrete = (concrete_m3 * concrete_factor) / 1000.0 # tCO2e (factor in kg CO2e / m3)
        co2_ballast = (ballast_m3 * ballast_factor) / 1000.0 # tCO2e (factor in kg CO2e / m3)
        total_co2 = co2_steel + co2_concrete + co2_ballast
        
        return {
            "steel_co2e_tonnes": round(co2_steel, 2),
            "concrete_co2e_tonnes": round(co2_concrete, 2),
            "ballast_co2e_tonnes": round(co2_ballast, 2),
            "total_co2e_tonnes": round(total_co2, 2)
        }
