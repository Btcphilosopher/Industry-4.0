// GLASSWORKS.OS — Central Digital Twin Service

import { Injectable, signal, computed } from '@angular/core';
import { BASELINE_RAW_MATERIALS, RawMaterial, optimizeBatchRecipe } from '../engine/materials';
import { calculateGlassProperties, GlassPhysicalProperties } from '../engine/chemistry';
import { FurnaceState, createInitialFurnaceState } from '../engine/furnace';
import { TinBathState, createInitialTinBathState } from '../engine/tinbath';
import { LehrState, createInitialLehrState } from '../engine/lehr';
import { QualityMetrics, createInitialQualityMetrics, DefectItem } from '../engine/quality';
import { createInitialWarehouseState, ProductionOrder, GlassSheetProduct, YieldBreakdown } from '../engine/cutting';
import { calculateEnergyAndEmissions } from '../engine/energy';
import { PREBUILT_SCENARIOS, ScenarioParameters, runScenarioSimulation, ScenarioDeltaResult } from '../engine/scenarios';
import { generateHistorianSnapshots, PlantSnapshot } from '../engine/historian';
import { analyzePlantBottlenecks, BottleneckStage } from '../engine/plant-designer';

export type MainTab = 
  | 'overview_3d' 
  | 'furnace' 
  | 'tin_bath' 
  | 'lehr' 
  | 'quality' 
  | 'batch_lab' 
  | 'scenarios' 
  | 'energy' 
  | 'time_machine' 
  | 'bottlenecks';

export type SimulationMode = 'REALTIME' | 'FAST_FORWARD' | 'CAMPAIGN' | 'PAUSED';

@Injectable({
  providedIn: 'root'
})
export class DigitalTwinService {
  // Navigation & Control State
  readonly activeTab = signal<MainTab>('overview_3d');
  readonly simulationMode = signal<SimulationMode>('REALTIME');
  readonly simulationSpeedMultiplier = signal<number>(1);
  readonly selectedEquipmentId = signal<string | null>('EQ-FURNACE-01');
  readonly selectedDefectId = signal<string | null>('DEF-2026-901');
  readonly signatureDemoActive = signal<'none' | 'sand-to-glass' | 'time-machine' | 'what-if'>('none');
  readonly signatureDemoStep = signal<number>(1);

  // Core Subsystem States
  readonly furnace = signal<FurnaceState>(createInitialFurnaceState());
  readonly tinBath = signal<TinBathState>(createInitialTinBathState());
  readonly lehr = signal<LehrState>(createInitialLehrState());
  readonly quality = signal<QualityMetrics>(createInitialQualityMetrics());
  readonly rawMaterials = signal<RawMaterial[]>(BASELINE_RAW_MATERIALS);
  
  // Warehouse & Orders
  private initialWarehouse = createInitialWarehouseState();
  readonly activeOrders = signal<ProductionOrder[]>(this.initialWarehouse.activeOrders);
  readonly warehouseInventory = signal<GlassSheetProduct[]>(this.initialWarehouse.warehouseInventory);
  readonly yieldBreakdown = signal<YieldBreakdown>(this.initialWarehouse.yieldData);

  // Scenarios State
  readonly availableScenarios = signal<ScenarioParameters[]>(PREBUILT_SCENARIOS);
  readonly activeScenarioId = signal<string>(PREBUILT_SCENARIOS[0].id);
  readonly scenarioResult = signal<ScenarioDeltaResult>(runScenarioSimulation(PREBUILT_SCENARIOS[0]));

  // Historian & Time Machine
  readonly historianSnapshots = signal<PlantSnapshot[]>(generateHistorianSnapshots());
  readonly selectedSnapshotIndex = signal<number>(4); // Default "NOW"

  // Computed State Properties
  readonly activeSnapshot = computed(() => this.historianSnapshots()[this.selectedSnapshotIndex()]);

  readonly glassChemistry = computed(() => {
    const f = this.furnace();
    return optimizeBatchRecipe({}, f.culletPercent, (f.pullRateTonnesPerDay / 24)).calculatedGlassChemistry;
  });

  readonly glassPhysicalProps = computed<GlassPhysicalProperties>(() => {
    return calculateGlassProperties(this.glassChemistry());
  });

  readonly energyAndEmissions = computed(() => {
    const f = this.furnace();
    return calculateEnergyAndEmissions(f.pullRateTonnesPerDay / 24, f.culletPercent, f.activeFuelMode);
  });

  readonly bottlenecks = computed<BottleneckStage[]>(() => {
    return analyzePlantBottlenecks(this.furnace().pullRateTonnesPerDay);
  });

  readonly selectedDefect = computed<DefectItem | undefined>(() => {
    const id = this.selectedDefectId();
    return this.quality().activeDefects.find(d => d.id === id);
  });

  private tickTimer: ReturnType<typeof setInterval> | undefined;

  constructor() {
    this.startSimulationLoop();
  }

  private startSimulationLoop() {
    this.tickTimer = setInterval(() => {
      if (this.simulationMode() !== 'PAUSED') {
        this.tickSimulation();
      }
    }, 1000);
  }

  private tickSimulation() {
    const speed = this.simulationSpeedMultiplier();

    // Micro fluctuations in furnace temperature & glass level
    this.furnace.update(f => {
      const crownDelta = (Math.random() - 0.5) * 0.4 * speed;
      const glassLevelDelta = (Math.random() - 0.5) * 0.02 * speed;
      return {
        ...f,
        crownTempMaxC: Math.min(1600, Math.max(1520, Number((f.crownTempMaxC + crownDelta).toFixed(1)))),
        glassLevelMm: Number((f.glassLevelMm + glassLevelDelta).toFixed(2))
      };
    });

    // Micro fluctuations in tin bath draw thickness
    this.tinBath.update(tb => {
      const thickDelta = (Math.random() - 0.5) * 0.002 * speed;
      return {
        ...tb,
        actualCenterThicknessMm: Number((tb.actualCenterThicknessMm + thickDelta).toFixed(3))
      };
    });
  }

  // Action Methods
  setActiveTab(tab: MainTab) {
    this.activeTab.set(tab);
  }

  setSimulationMode(mode: SimulationMode, speedMultiplier = 1) {
    this.simulationMode.set(mode);
    this.simulationSpeedMultiplier.set(speedMultiplier);
  }

  selectEquipment(id: string | null) {
    this.selectedEquipmentId.set(id);
  }

  selectDefect(id: string | null) {
    this.selectedDefectId.set(id);
  }

  selectSnapshot(index: number) {
    this.selectedSnapshotIndex.set(index);
  }

  selectScenario(id: string) {
    const scen = this.availableScenarios().find(s => s.id === id);
    if (scen) {
      this.activeScenarioId.set(id);
      this.scenarioResult.set(runScenarioSimulation(scen));
    }
  }

  updateFurnaceCullet(newCulletPercent: number) {
    this.furnace.update(f => ({ ...f, culletPercent: newCulletPercent }));
  }

  updateFurnaceFuelMode(newMode: 'NATURAL_GAS' | 'OXY_FUEL' | 'HYBRID_OXY_ELEC' | 'ELECTRIC_ASSIST' | 'HYDROGEN_EXPERIMENTAL') {
    this.furnace.update(f => ({ ...f, activeFuelMode: newMode }));
  }

  startSignatureDemo(type: 'sand-to-glass' | 'time-machine' | 'what-if') {
    this.signatureDemoActive.set(type);
    this.signatureDemoStep.set(1);
    
    if (type === 'sand-to-glass') {
      this.setActiveTab('overview_3d');
    } else if (type === 'time-machine') {
      this.setActiveTab('time_machine');
    } else if (type === 'what-if') {
      this.setActiveTab('scenarios');
    }
  }

  nextSignatureDemoStep() {
    this.signatureDemoStep.update(s => Math.min(5, s + 1));
  }

  closeSignatureDemo() {
    this.signatureDemoActive.set('none');
  }
}
