import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DigitalTwinService } from '../services/digital-twin.service';

@Component({
  selector: 'app-signature-demos-modal',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (dt.signatureDemoActive() !== 'none') {
      <div class="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
        <div class="glass-panel p-6 rounded-2xl max-w-xl w-full border border-slate-700 shadow-2xl flex flex-col gap-4 animate-fade-in text-slate-100 text-xs">
          <!-- Modal Header -->
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div class="flex items-center gap-2">
              <span class="material-icons text-amber-400">stars</span>
              <h2 class="text-base font-bold font-display text-slate-100">
                @if (dt.signatureDemoActive() === 'sand-to-glass') {
                  SIGNATURE DEMO 1: FROM SAND TO GLASS
                } @else if (dt.signatureDemoActive() === 'time-machine') {
                  SIGNATURE DEMO 2: FURNACE TIME MACHINE
                } @else if (dt.signatureDemoActive() === 'what-if') {
                  SIGNATURE DEMO 3: WHAT-IF CULLET OPTIMIZATION
                }
              </h2>
            </div>
            <button (click)="dt.closeSignatureDemo()" class="text-slate-400 hover:text-white">
              <span class="material-icons text-sm">close</span>
            </button>
          </div>

          <!-- Step Content -->
          <div class="bg-slate-950/80 p-4 rounded-xl border border-slate-800 flex flex-col gap-3 leading-relaxed">
            @if (dt.signatureDemoActive() === 'sand-to-glass') {
              @if (dt.signatureDemoStep() === 1) {
                <div class="font-bold text-amber-300 text-sm">Step 1: Raw Materials & Batching</div>
                <p>Silica sand (73%), soda ash (13%), limestone (9%) & dolomite (4%) are weighed and mixed with 25% recycled glass cullet in the Batch House silos.</p>
              } @else if (dt.signatureDemoStep() === 2) {
                <div class="font-bold text-amber-300 text-sm">Step 2: Furnace Melting & SO₃ Fining</div>
                <p>The batch enters the 1,585°C cross-fired regenerator furnace. Carbonates decompose and SO₃ dissociation releases gas bubbles that clarify the molten pool.</p>
              } @else if (dt.signatureDemoStep() === 3) {
                <div class="font-bold text-amber-300 text-sm">Step 3: Tin Bath Float Ribbon Formation</div>
                <p>Molten glass floats over a 58-meter liquid tin bath in a 5% H₂ / 95% N₂ atmosphere. Top rollers stretch the ribbon to an exact 4.00mm thickness.</p>
              } @else if (dt.signatureDemoStep() === 4) {
                <div class="font-bold text-amber-300 text-sm">Step 4: Lehr Controlled Annealing</div>
                <p>The ribbon passes through 16 controlled cooling zones from 595°C to 65°C, reducing residual mechanical stress to < 2.0 MPa.</p>
              } @else if (dt.signatureDemoStep() === 5) {
                <div class="font-bold text-amber-300 text-sm">Step 5: Inspection & Backwards Traceability</div>
                <p>Line-scan cameras detect a 0.35mm bubble seed defect. The digital twin instantly traces back to a -8°C local thermal drop in Furnace Fining Zone 4!</p>
              }
            } @else if (dt.signatureDemoActive() === 'time-machine') {
              <div class="font-bold text-sky-300 text-sm">Furnace Time Machine Demo</div>
              <p>Scrub furnace thermal states back 7 days to analyze historical campaign stability, then project forward 24 hours to anticipate maintenance requirements.</p>
            } @else if (dt.signatureDemoActive() === 'what-if') {
              <div class="font-bold text-emerald-300 text-sm">What-If Cullet Scenario Demo</div>
              <p>Increasing recycled cullet from 25% to 35% reduces furnace fuel consumption by 3.2% and cuts daily CO₂ emissions by 14.8 tonnes!</p>
            }
          </div>

          <!-- Footer Actions -->
          <div class="flex items-center justify-between border-t border-slate-800 pt-3">
            <span class="text-slate-500 font-mono">Step {{ dt.signatureDemoStep() }} of 5</span>
            <div class="flex items-center gap-2">
              @if (dt.signatureDemoStep() < 5) {
                <button 
                  (click)="dt.nextSignatureDemoStep()" 
                  class="px-4 py-2 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-bold rounded-xl transition-all">
                  Next Step
                </button>
              } @else {
                <button 
                  (click)="dt.closeSignatureDemo()" 
                  class="px-4 py-2 bg-emerald-500 text-slate-950 font-bold rounded-xl hover:bg-emerald-400 transition-all">
                  Complete Demo
                </button>
              }
            </div>
          </div>
        </div>
      </div>
    }
  `
})
export class SignatureDemosModalComponent {
  dt = inject(DigitalTwinService);
}
