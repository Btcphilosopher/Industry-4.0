import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DigitalTwinService } from '../services/digital-twin.service';

@Component({
  selector: 'app-furnace-view',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 max-w-7xl mx-auto flex flex-col gap-6 animate-fade-in text-slate-100">
      <!-- Header Bar -->
      <div class="flex flex-wrap items-center justify-between gap-4 bg-slate-900/80 p-5 rounded-2xl border border-slate-800 backdrop-blur-md">
        <div>
          <div class="flex items-center gap-2">
            <span class="material-icons text-amber-400">local_fire_department</span>
            <h1 class="text-xl font-display font-bold">FURNACE.OS — Spatial Thermal & Convection Digital Twin</h1>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            2.5D Reduced-order thermal model (1,585°C Crown Max, 840 t/day pull rate, 6 port cross-firing regenerators).
          </p>
        </div>

        <div class="flex items-center gap-4 text-xs font-mono">
          <div class="bg-slate-950/80 px-3 py-1.5 rounded-xl border border-slate-800">
            <span class="text-slate-500 block text-[10px]">CROWN MAX TEMP</span>
            <span class="text-orange-400 font-bold text-sm">{{ f().crownTempMaxC }}°C</span>
          </div>
          <div class="bg-slate-950/80 px-3 py-1.5 rounded-xl border border-slate-800">
            <span class="text-slate-500 block text-[10px]">GLASS LEVEL</span>
            <span class="text-sky-400 font-bold text-sm">{{ f().glassLevelMm > 0 ? '+' : '' }}{{ f().glassLevelMm }} mm</span>
          </div>
          <div class="bg-slate-950/80 px-3 py-1.5 rounded-xl border border-slate-800">
            <span class="text-slate-500 block text-[10px]">REFRACTORY HEALTH</span>
            <span class="text-emerald-400 font-bold text-sm">{{ f().overallRefractoryHealthPercent }}%</span>
          </div>
        </div>
      </div>

      <!-- Longitudinal Thermal Map Cross-Section -->
      <div class="glass-panel p-6 rounded-2xl flex flex-col gap-4">
        <div class="flex items-center justify-between">
          <h2 class="text-sm font-semibold text-slate-200 flex items-center gap-2">
            <span class="material-icons text-amber-400 text-sm">grid_4x4</span>
            <span>Longitudinal Furnace Cross-Section & Thermal Field</span>
          </h2>
          
          <!-- Layer Selector -->
          <div class="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
            <button 
              (click)="selectedLayer = 'TEMPERATURE'"
              [class.bg-amber-500]="selectedLayer === 'TEMPERATURE'"
              [class.text-slate-950]="selectedLayer === 'TEMPERATURE'"
              class="px-3 py-1 rounded-lg font-medium text-slate-400 transition-colors">
              Temperature Field
            </button>
            <button 
              (click)="selectedLayer = 'CONVECTION'"
              [class.bg-amber-500]="selectedLayer === 'CONVECTION'"
              [class.text-slate-950]="selectedLayer === 'CONVECTION'"
              class="px-3 py-1 rounded-lg font-medium text-slate-400 transition-colors">
              Flow Vectors
            </button>
            <button 
              (click)="selectedLayer = 'REFRACTORY'"
              [class.bg-amber-500]="selectedLayer === 'REFRACTORY'"
              [class.text-slate-950]="selectedLayer === 'REFRACTORY'"
              class="px-3 py-1 rounded-lg font-medium text-slate-400 transition-colors">
              Refractory Corrosion
            </button>
          </div>
        </div>

        <!-- 6 Zone Headers -->
        <div class="grid grid-cols-6 gap-2 text-center text-xs font-mono text-slate-400">
          @for (zone of f().zones; track zone.name) {
            <div class="bg-slate-900/90 p-2 rounded-xl border border-slate-800/80">
              <span class="block font-bold text-amber-300 text-[11px] truncate">{{ zone.name }}</span>
              <span class="text-slate-200 font-mono text-xs">{{ zone.actualTempC }}°C</span>
              <span class="text-[10px] text-slate-500 block">Target {{ zone.targetTempC }}°C</span>
            </div>
          }
        </div>

        <!-- Heat Map Grid Simulation Canvas -->
        <div class="w-full h-48 bg-slate-950 rounded-xl border border-slate-800 p-2 relative overflow-hidden flex flex-col justify-between">
          <!-- Glass Pool Heat Field Grid -->
          <div class="w-full h-full grid grid-cols-25 gap-0.5">
            @for (col of f().gridCells; track $index; let x = $index) {
              <div class="flex flex-col gap-0.5">
                @for (cell of col[4]; track $index; let z = $index) {
                  <div 
                    [style.background]="getCellColor(cell.temperatureC, selectedLayer, cell)"
                    class="w-full h-full rounded-[1px] transition-colors duration-500 relative group cursor-pointer">
                    <!-- Hover Tooltip -->
                    <div class="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 hidden group-hover:block z-30 w-40 bg-slate-900 border border-slate-700 p-2 rounded-lg text-[10px] font-mono text-slate-200 shadow-xl pointer-events-none">
                      <span class="text-amber-400 block font-bold">X:{{ x }} Z:{{ z }}</span>
                      <span>Temp: {{ cell.temperatureC }}°C</span><br>
                      <span>Vel: {{ cell.velocityX }} m/s</span><br>
                      <span>Viscosity: {{ cell.viscosityPaS }} Pa·s</span>
                    </div>
                  </div>
                }
              </div>
            }
          </div>

          <!-- Color Scale Legend -->
          <div class="flex items-center justify-between text-[10px] font-mono text-slate-400 pt-2 border-t border-slate-900">
            <span>1,280°C (Delivery)</span>
            <div class="w-48 h-2 rounded bg-gradient-to-r from-blue-600 via-amber-500 to-red-600"></div>
            <span>1,585°C (Hot Spot)</span>
          </div>
        </div>
      </div>

      <!-- Burner & Fining Control Section -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- 6 Port Combustion Regenerator Firing System -->
        <div class="glass-panel p-5 rounded-2xl lg:col-span-2 flex flex-col gap-4">
          <div class="flex items-center justify-between">
            <h3 class="text-sm font-semibold text-slate-200 flex items-center gap-2">
              <span class="material-icons text-amber-400 text-sm">whatshot</span>
              <span>6-Port Regenerative Combustion System</span>
            </h3>
            <span class="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
              REVERSING CYCLE: LEFT FIRING
            </span>
          </div>

          <div class="grid grid-cols-2 sm:grid-cols-3 gap-3">
            @for (burner of f().burners; track burner.id) {
              @if (burner.side === 'LEFT') {
                <div class="bg-slate-950/80 p-3 rounded-xl border border-slate-800 flex flex-col gap-1 text-xs">
                  <div class="flex items-center justify-between">
                    <span class="font-mono font-bold text-amber-400">{{ burner.id }}</span>
                    <span class="text-[10px] text-slate-500 font-mono">{{ burner.zone }}</span>
                  </div>
                  <div class="text-slate-300 font-mono text-sm font-bold">{{ burner.flameTempC }}°C</div>
                  <div class="flex items-center justify-between text-[11px] text-slate-400 mt-1">
                    <span>Flow: {{ burner.fuelFlowNm3h }} m³/h</span>
                    <span class="text-emerald-400">{{ burner.efficiencyPercent }}%</span>
                  </div>
                </div>
              }
            }
          </div>
        </div>

        <!-- Fining & Bubble Defect Model -->
        <div class="glass-panel p-5 rounded-2xl flex flex-col gap-4">
          <h3 class="text-sm font-semibold text-slate-200 flex items-center gap-2">
            <span class="material-icons text-amber-400 text-sm">bubble_chart</span>
            <span>Fining & Bubble Defect Risk</span>
          </h3>

          <div class="bg-slate-950/80 p-4 rounded-xl border border-slate-800 flex flex-col gap-3 text-xs">
            <div class="flex items-center justify-between">
              <span class="text-slate-400">FINING EFFICENCY</span>
              <span class="font-mono font-bold text-emerald-400">{{ f().finingEfficiencyPercent }}%</span>
            </div>
            <div class="flex items-center justify-between">
              <span class="text-slate-400">RESIDUE BUBBLES</span>
              <span class="font-mono font-bold text-amber-400">{{ f().estimatedResidueBubblesPerTonne }} / tonne</span>
            </div>
            <div class="flex items-center justify-between">
              <span class="text-slate-400">DEFECT RISK LEVEL</span>
              <span class="font-mono font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                {{ f().bubbleDefectRiskLevel }}
              </span>
            </div>
          </div>

          <p class="text-slate-400 text-xs leading-relaxed">
            SO₃ salt cake fining dissociation peaks at 1,425°C in the Fining zone, producing SO₂ and O₂ bubbles that sweep micro-seeds to the glass pool surface.
          </p>
        </div>
      </div>
    </div>
  `
})
export class FurnaceViewComponent {
  dt = inject(DigitalTwinService);
  f = this.dt.furnace;
  selectedLayer: 'TEMPERATURE' | 'CONVECTION' | 'REFRACTORY' = 'TEMPERATURE';

  getCellColor(temp: number, layer: string, cell: { refractoryWallLossPercent?: number }): string {
    if (layer === 'REFRACTORY') {
      const loss = cell.refractoryWallLossPercent || 0;
      return loss > 20 ? '#ef4444' : loss > 10 ? '#f59e0b' : '#334155';
    }
    
    // Thermal scale (1280°C to 1585°C)
    const norm = Math.min(1.0, Math.max(0.0, (temp - 1280) / (1585 - 1280)));
    if (norm < 0.3) return `#1e3a8a`; // Deep blue
    if (norm < 0.6) return `#d97706`; // Amber
    if (norm < 0.85) return `#ea580c`; // Orange
    return `#dc2626`; // Red hot
  }
}
