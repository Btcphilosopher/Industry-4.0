import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DigitalTwinService } from '../services/digital-twin.service';

@Component({
  selector: 'app-bottlenecks-view',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 max-w-7xl mx-auto flex flex-col gap-6 animate-fade-in text-slate-100">
      <!-- Header Bar -->
      <div class="flex flex-wrap items-center justify-between gap-4 bg-slate-900/80 p-5 rounded-2xl border border-slate-800 backdrop-blur-md">
        <div>
          <div class="flex items-center gap-2">
            <span class="material-icons text-amber-400">precision_manufacturing</span>
            <h1 class="text-xl font-display font-bold">DIGITAL COMMISSIONING — Bottleneck & Capacity Analyzer</h1>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Automated process graph capacity utilization analysis identifying factory throughput constraint stages.
          </p>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs">
          <span class="text-slate-500">OPERATING PULL:</span>
          <span class="text-amber-400 font-bold text-sm">{{ dt.furnace().pullRateTonnesPerDay }} t/day</span>
        </div>
      </div>

      <!-- Bottlenecks Grid -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        @for (b of dt.bottlenecks(); track b.stageId) {
          <div 
            [class.border-amber-500]="b.isBottleneck"
            [class.bg-amber-500/10]="b.isBottleneck"
            class="glass-panel p-5 rounded-2xl flex flex-col justify-between gap-4 text-xs font-mono">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <span class="font-bold text-slate-200 text-sm">{{ b.stageName }}</span>
              @if (b.isBottleneck) {
                <span class="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold text-[10px] border border-amber-500/40 uppercase">
                  BOTTLENECK
                </span>
              }
            </div>

            <div>
              <div class="flex items-center justify-between text-slate-400 text-[11px] mb-1">
                <span>Capacity Utilization</span>
                <span class="font-bold text-amber-400">{{ b.capacityUtilizationPercent }}%</span>
              </div>
              <div class="w-full bg-slate-950 h-2.5 rounded-full overflow-hidden border border-slate-800">
                <div 
                  [style.width.%]="b.capacityUtilizationPercent"
                  [class.bg-amber-500]="b.isBottleneck"
                  [class.bg-emerald-500]="!b.isBottleneck"
                  class="h-full rounded-full transition-all"></div>
              </div>
            </div>

            <div class="text-[11px] text-slate-400 leading-relaxed">
              <span class="text-slate-500 block text-[10px]">LIMITING FACTOR:</span>
              {{ b.limitingFactor }}
            </div>
          </div>
        }
      </div>
    </div>
  `
})
export class BottlenecksViewComponent {
  dt = inject(DigitalTwinService);
}
