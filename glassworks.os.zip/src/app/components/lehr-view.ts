import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DigitalTwinService } from '../services/digital-twin.service';

@Component({
  selector: 'app-lehr-view',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 max-w-7xl mx-auto flex flex-col gap-6 animate-fade-in text-slate-100">
      <!-- Header Bar -->
      <div class="flex flex-wrap items-center justify-between gap-4 bg-slate-900/80 p-5 rounded-2xl border border-slate-800 backdrop-blur-md">
        <div>
          <div class="flex items-center gap-2">
            <span class="material-icons text-sky-400">ac_unit</span>
            <h1 class="text-xl font-display font-bold">LEHR.OS — Annealing Lehr & Residual Stress Twin</h1>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            120-meter enclosed 16-zone tunnel kiln controlling glass cooling from 595°C to 65°C to prevent internal mechanical stress.
          </p>
        </div>

        <div class="flex items-center gap-4 text-xs font-mono">
          <div class="bg-slate-950/80 px-3 py-1.5 rounded-xl border border-slate-800">
            <span class="text-slate-500 block text-[10px]">RESIDUAL STRESS</span>
            <span class="text-emerald-400 font-bold text-sm">{{ lehr().residualStressMpa }} MPa</span>
          </div>
          <div class="bg-slate-950/80 px-3 py-1.5 rounded-xl border border-slate-800">
            <span class="text-slate-500 block text-[10px]">STRESS LEVEL</span>
            <span class="text-emerald-400 font-bold text-sm px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20">
              {{ lehr().residualStressLevel }}
            </span>
          </div>
          <div class="bg-slate-950/80 px-3 py-1.5 rounded-xl border border-slate-800">
            <span class="text-slate-500 block text-[10px]">BOW / FLATNESS</span>
            <span class="text-sky-400 font-bold text-sm">{{ lehr().flatnessDeviationMmM }} mm/m</span>
          </div>
        </div>
      </div>

      <!-- Cooling Curve Comparison Chart -->
      <div class="glass-panel p-5 rounded-2xl flex flex-col gap-4">
        <h3 class="text-sm font-semibold text-slate-200 flex items-center gap-2">
          <span class="material-icons text-amber-400 text-sm">timeline</span>
          <span>16-Zone Controlled Annealing Curve (°C) vs Setpoints</span>
        </h3>

        <div class="bg-slate-950/80 p-4 rounded-xl border border-slate-800 flex items-end justify-between h-40 gap-2 text-[10px] font-mono text-slate-400">
          @for (zone of lehr().zones; track zone.zoneNumber) {
            <div class="flex-1 flex flex-col items-center gap-1 h-full justify-end group relative cursor-pointer">
              <!-- Actual Bar -->
              <div 
                [style.height.%]="((zone.actualTempC - 50) / (600 - 50)) * 100"
                class="w-full bg-gradient-to-t from-blue-600 via-amber-500 to-orange-500 rounded-t transition-all group-hover:brightness-125"></div>
              <span class="text-[9px] text-slate-400 mt-1 font-mono">Z{{ zone.zoneNumber }}</span>

              <!-- Hover Tooltip -->
              <div class="absolute bottom-full mb-2 hidden group-hover:block z-30 w-36 bg-slate-900 border border-slate-700 p-2 rounded-lg text-[10px] font-mono text-slate-200 shadow-xl pointer-events-none">
                <span class="text-amber-400 font-bold block">{{ zone.name }}</span>
                <span>Actual: {{ zone.actualTempC }}°C</span><br>
                <span>Setpoint: {{ zone.setpointTempC }}°C</span><br>
                <span>Heater: {{ zone.electricHeaterOutputPercent }}%</span>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- 16 Lehr Zones Grid -->
      <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
        @for (zone of lehr().zones; track zone.zoneNumber) {
          <div class="bg-slate-900/80 p-3 rounded-xl border border-slate-800 flex flex-col gap-1 text-xs">
            <div class="flex items-center justify-between font-mono">
              <span class="font-bold text-amber-400">Zone {{ zone.zoneNumber }}</span>
              <span 
                [class.text-emerald-400]="zone.status === 'STABLE'"
                [class.text-red-400]="zone.status === 'DEVIATION_ALERT'"
                class="text-[9px] font-mono">
                {{ zone.status }}
              </span>
            </div>
            <div class="text-slate-100 font-mono text-sm font-bold">{{ zone.actualTempC }}°C</div>
            <div class="flex items-center justify-between text-[10px] text-slate-400 font-mono mt-1">
              <span>Heat: {{ zone.electricHeaterOutputPercent }}%</span>
              <span>Fan: {{ zone.coolingBlowerSpeedPercent }}%</span>
            </div>
          </div>
        }
      </div>
    </div>
  `
})
export class LehrViewComponent {
  dt = inject(DigitalTwinService);
  lehr = this.dt.lehr;
}
