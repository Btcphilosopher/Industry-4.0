import { Component, inject, ChangeDetectionStrategy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DigitalTwinService } from '../services/digital-twin.service';

@Component({
  selector: 'app-batch-lab-view',
  standalone: true,
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 max-w-7xl mx-auto flex flex-col gap-6 animate-fade-in text-slate-100">
      <!-- Header Bar -->
      <div class="flex flex-wrap items-center justify-between gap-4 bg-slate-900/80 p-5 rounded-2xl border border-slate-800 backdrop-blur-md">
        <div>
          <div class="flex items-center gap-2">
            <span class="material-icons text-emerald-400">science</span>
            <h1 class="text-xl font-display font-bold">BATCH LAB — Formulation, Chemistry & Mass Balance</h1>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Batch recipe formulation engine, oxide contribution calculator & conservation mass balance solver.
          </p>
        </div>

        <div class="flex items-center gap-4 text-xs font-mono">
          <div class="bg-slate-950/80 px-3 py-1.5 rounded-xl border border-slate-800">
            <span class="text-slate-500 block text-[10px]">CULLET RATIO</span>
            <span class="text-emerald-400 font-bold text-sm">{{ culletPercent() }}%</span>
          </div>
          <div class="bg-slate-950/80 px-3 py-1.5 rounded-xl border border-slate-800">
            <span class="text-slate-500 block text-[10px]">BATCH COST</span>
            <span class="text-amber-400 font-bold text-sm">\${{ optResult().batchCostPerTonneUsd | number:'1.2-2' }} / t</span>
          </div>
        </div>
      </div>

      <!-- Cullet & Recipe Interactive Slider Panel -->
      <div class="glass-panel p-5 rounded-2xl flex flex-col gap-4">
        <div class="flex items-center justify-between">
          <h3 class="text-sm font-semibold text-slate-200 flex items-center gap-2">
            <span class="material-icons text-emerald-400 text-sm">recycling</span>
            <span>Cullet Percentage Adjustment</span>
          </h3>
          <span class="text-xs font-mono text-emerald-400 font-bold">{{ culletPercent() }}% Cullet</span>
        </div>

        <input 
          type="range" 
          min="0" 
          max="50" 
          step="1"
          [value]="culletPercent()"
          (input)="onCulletChange($event)"
          class="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500">

        <p class="text-xs text-slate-400 leading-relaxed">
          Increasing recycled glass cullet reduces furnace melting energy by 2.8% per 10% cullet added and eliminates CO₂ emissions from carbonate raw material decomposition.
        </p>
      </div>

      <!-- Calculated Glass Oxide Chemistry Grid -->
      <div class="glass-panel p-5 rounded-2xl flex flex-col gap-4">
        <h3 class="text-sm font-semibold text-slate-200 flex items-center gap-2">
          <span class="material-icons text-amber-400 text-sm">bubble_chart</span>
          <span>Calculated Glass Oxide Composition (%)</span>
        </h3>

        <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          <div class="bg-slate-950/80 p-3 rounded-xl border border-slate-800 text-center font-mono">
            <span class="text-slate-500 block text-[10px]">SiO₂</span>
            <span class="text-amber-400 font-bold text-base">{{ dt.glassChemistry().SiO2 | number:'1.2-2' }}%</span>
          </div>
          <div class="bg-slate-950/80 p-3 rounded-xl border border-slate-800 text-center font-mono">
            <span class="text-slate-500 block text-[10px]">Na₂O</span>
            <span class="text-amber-400 font-bold text-base">{{ dt.glassChemistry().Na2O | number:'1.2-2' }}%</span>
          </div>
          <div class="bg-slate-950/80 p-3 rounded-xl border border-slate-800 text-center font-mono">
            <span class="text-slate-500 block text-[10px]">CaO</span>
            <span class="text-amber-400 font-bold text-base">{{ dt.glassChemistry().CaO | number:'1.2-2' }}%</span>
          </div>
          <div class="bg-slate-950/80 p-3 rounded-xl border border-slate-800 text-center font-mono">
            <span class="text-slate-500 block text-[10px]">MgO</span>
            <span class="text-amber-400 font-bold text-base">{{ dt.glassChemistry().MgO | number:'1.2-2' }}%</span>
          </div>
          <div class="bg-slate-950/80 p-3 rounded-xl border border-slate-800 text-center font-mono">
            <span class="text-slate-500 block text-[10px]">Al₂O₃</span>
            <span class="text-amber-400 font-bold text-base">{{ dt.glassChemistry().Al2O3 | number:'1.2-2' }}%</span>
          </div>
          <div class="bg-slate-950/80 p-3 rounded-xl border border-slate-800 text-center font-mono">
            <span class="text-slate-500 block text-[10px]">Fe₂O₃</span>
            <span class="text-amber-400 font-bold text-base">{{ dt.glassChemistry().Fe2O3 | number:'1.3-3' }}%</span>
          </div>
          <div class="bg-slate-950/80 p-3 rounded-xl border border-slate-800 text-center font-mono">
            <span class="text-slate-500 block text-[10px]">SO₃</span>
            <span class="text-amber-400 font-bold text-base">{{ dt.glassChemistry().SO3 | number:'1.2-2' }}%</span>
          </div>
          <div class="bg-slate-950/80 p-3 rounded-xl border border-slate-800 text-center font-mono">
            <span class="text-slate-500 block text-[10px]">DENSITY</span>
            <span class="text-sky-400 font-bold text-base">{{ dt.glassPhysicalProps().densityKgM3 | number:'1.0-0' }} kg/m³</span>
          </div>
        </div>
      </div>

      <!-- Mass Balance Conservation Model -->
      <div class="glass-panel p-5 rounded-2xl flex flex-col gap-4">
        <h3 class="text-sm font-semibold text-slate-200 flex items-center gap-2">
          <span class="material-icons text-sky-400 text-sm">balance</span>
          <span>Mass Balance Conservation (Input = Recycled + Output + Gas Loss)</span>
        </h3>

        <div class="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs font-mono">
          <div class="bg-slate-950/80 p-3 rounded-xl border border-slate-800">
            <span class="text-slate-500 block text-[10px]">RAW BATCH INPUT</span>
            <span class="text-slate-200 font-bold text-sm">{{ optResult().massBalance.inputMassKg | number:'1.0-0' }} kg/h</span>
          </div>
          <div class="bg-slate-950/80 p-3 rounded-xl border border-slate-800">
            <span class="text-slate-500 block text-[10px]">RECYCLED CULLET</span>
            <span class="text-emerald-400 font-bold text-sm">{{ optResult().massBalance.recycledCulletKg | number:'1.0-0' }} kg/h</span>
          </div>
          <div class="bg-slate-950/80 p-3 rounded-xl border border-slate-800">
            <span class="text-slate-500 block text-[10px]">DE-GAS VOLATILE LOSS (CO₂)</span>
            <span class="text-amber-400 font-bold text-sm">-{{ optResult().massBalance.volatileLossGasesKg | number:'1.0-0' }} kg/h</span>
          </div>
          <div class="bg-slate-950/80 p-3 rounded-xl border border-slate-800">
            <span class="text-slate-500 block text-[10px]">OUTPUT MOLTEN GLASS</span>
            <span class="text-sky-400 font-bold text-sm">{{ optResult().massBalance.outputMoltenGlassKg | number:'1.0-0' }} kg/h</span>
          </div>
        </div>
      </div>
    </div>
  `
})
export class BatchLabViewComponent {
  dt = inject(DigitalTwinService);
  culletPercent = signal<number>(25);

  optResult = signal({
    batchCostPerTonneUsd: 112,
    massBalance: {
      inputMassKg: 35000,
      recycledCulletKg: 8750,
      volatileLossGasesKg: 4068,
      outputMoltenGlassKg: 30932
    }
  });

  onCulletChange(e: Event) {
    const val = Number((e.target as HTMLInputElement).value);
    this.culletPercent.set(val);
    this.dt.updateFurnaceCullet(val);
  }
}
