import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DigitalTwinService } from '../services/digital-twin.service';

@Component({
  selector: 'app-energy-view',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 max-w-7xl mx-auto flex flex-col gap-6 animate-fade-in text-slate-100">
      <!-- Header Bar -->
      <div class="flex flex-wrap items-center justify-between gap-4 bg-slate-900/80 p-5 rounded-2xl border border-slate-800 backdrop-blur-md">
        <div>
          <div class="flex items-center gap-2">
            <span class="material-icons text-amber-400">bolt</span>
            <h1 class="text-xl font-display font-bold">ENERGY & EMISSIONS — Thermodynamic & Carbon Balance</h1>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Thermodynamic energy balance (Thermal 82.4 MWh/day + Electric 11.8 MWh/day) and live flue gas emissions tracking.
          </p>
        </div>

        <div class="flex items-center gap-4 text-xs font-mono">
          <div class="bg-slate-950/80 px-3 py-1.5 rounded-xl border border-slate-800">
            <span class="text-slate-500 block text-[10px]">TOTAL POWER</span>
            <span class="text-amber-400 font-bold text-sm">{{ ee().energy.totalEnergyMwhPerDay }} MWh/day</span>
          </div>
          <div class="bg-slate-950/80 px-3 py-1.5 rounded-xl border border-slate-800">
            <span class="text-slate-500 block text-[10px]">ENERGY / TONNE</span>
            <span class="text-sky-400 font-bold text-sm">{{ ee().energy.energyPerTonneMwh }} MWh/t</span>
          </div>
          <div class="bg-slate-950/80 px-3 py-1.5 rounded-xl border border-slate-800">
            <span class="text-slate-500 block text-[10px]">CO₂ EMISSIONS</span>
            <span class="text-emerald-400 font-bold text-sm">{{ ee().emissions.co2EmissionsTonnesPerDay }} t/day</span>
          </div>
        </div>
      </div>

      <!-- Sankey Power Distribution Breakdown -->
      <div class="glass-panel p-5 rounded-2xl flex flex-col gap-4">
        <h3 class="text-sm font-semibold text-slate-200 flex items-center gap-2">
          <span class="material-icons text-amber-400 text-sm">account_tree</span>
          <span>Plant Power Consumer Distribution (kW)</span>
        </h3>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 font-mono text-xs">
          <div class="bg-slate-950/80 p-4 rounded-xl border border-slate-800 flex flex-col gap-1">
            <span class="text-slate-500 text-[10px]">FURNACE GAS</span>
            <span class="text-orange-400 font-bold text-base">{{ ee().energy.furnaceNaturalGasPowerKw }} kW</span>
            <span class="text-slate-500 text-[10px]">Natural Gas Burners</span>
          </div>
          <div class="bg-slate-950/80 p-4 rounded-xl border border-slate-800 flex flex-col gap-1">
            <span class="text-slate-500 text-[10px]">ELECTRIC BOOST</span>
            <span class="text-amber-400 font-bold text-base">{{ ee().energy.furnaceElectricBoostPowerKw }} kW</span>
            <span class="text-slate-500 text-[10px]">Molybdenum Electrodes</span>
          </div>
          <div class="bg-slate-950/80 p-4 rounded-xl border border-slate-800 flex flex-col gap-1">
            <span class="text-slate-500 text-[10px]">TIN BATH HEATERS</span>
            <span class="text-sky-400 font-bold text-base">{{ ee().energy.tinBathHeatersPowerKw }} kW</span>
            <span class="text-slate-500 text-[10px]">Roof Carbon Elements</span>
          </div>
          <div class="bg-slate-950/80 p-4 rounded-xl border border-slate-800 flex flex-col gap-1">
            <span class="text-slate-500 text-[10px]">LEHR BLOWERS</span>
            <span class="text-emerald-400 font-bold text-base">{{ ee().energy.lehrHeatersAndBlowersPowerKw }} kW</span>
            <span class="text-slate-500 text-[10px]">Indirect Cooling Fans</span>
          </div>
          <div class="bg-slate-950/80 p-4 rounded-xl border border-slate-800 flex flex-col gap-1">
            <span class="text-slate-500 text-[10px]">AUXILIARIES</span>
            <span class="text-slate-300 font-bold text-base">{{ ee().energy.auxiliaryMotorsCompressorsPowerKw }} kW</span>
            <span class="text-slate-500 text-[10px]">Compressors & Pumps</span>
          </div>
        </div>
      </div>

      <!-- Live Flue Gas Emissions Gauges -->
      <div class="glass-panel p-5 rounded-2xl flex flex-col gap-4">
        <h3 class="text-sm font-semibold text-slate-200 flex items-center gap-2">
          <span class="material-icons text-emerald-400 text-sm">cloud_sync</span>
          <span>Flue Gas Environmental Emissions</span>
        </h3>

        <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
          <div class="bg-slate-950/80 p-4 rounded-xl border border-slate-800 flex flex-col gap-1 text-center">
            <span class="text-slate-500 text-[10px]">CO₂ DENSITY</span>
            <span class="text-emerald-400 font-bold text-xl">{{ ee().emissions.co2PerTonneGlassKg }} kg / t</span>
            <span class="text-slate-500 text-[10px]">Target < 240 kg/t</span>
          </div>
          <div class="bg-slate-950/80 p-4 rounded-xl border border-slate-800 flex flex-col gap-1 text-center">
            <span class="text-slate-500 text-[10px]">NOx EMISSIONS</span>
            <span class="text-amber-400 font-bold text-xl">{{ ee().emissions.noxEmissionsKgPerDay }} kg / day</span>
            <span class="text-slate-500 text-[10px]">Selective Catalytic Reduction</span>
          </div>
          <div class="bg-slate-950/80 p-4 rounded-xl border border-slate-800 flex flex-col gap-1 text-center">
            <span class="text-slate-500 text-[10px]">SOx EMISSIONS</span>
            <span class="text-sky-400 font-bold text-xl">{{ ee().emissions.soxEmissionsKgPerDay }} kg / day</span>
            <span class="text-slate-500 text-[10px]">Salt Cake Scrubber</span>
          </div>
          <div class="bg-slate-950/80 p-4 rounded-xl border border-slate-800 flex flex-col gap-1 text-center">
            <span class="text-slate-500 text-[10px]">CULLET CARBON SAVINGS</span>
            <span class="text-emerald-300 font-bold text-xl">-{{ ee().emissions.co2SavedByCulletTonnesPerDay }} t / day</span>
            <span class="text-slate-500 text-[10px]">At {{ ee().emissions.culletPercentCurrent }}% Cullet</span>
          </div>
        </div>
      </div>
    </div>
  `
})
export class EnergyViewComponent {
  dt = inject(DigitalTwinService);
  ee = this.dt.energyAndEmissions;
}
