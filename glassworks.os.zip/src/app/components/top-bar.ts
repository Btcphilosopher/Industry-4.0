import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DigitalTwinService, MainTab, SimulationMode } from '../services/digital-twin.service';

@Component({
  selector: 'app-top-bar',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="h-16 px-6 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 flex items-center justify-between z-30 sticky top-0 shrink-0">
      <!-- Zone 1: Single text element wordmark -->
      <div class="flex items-center gap-3">
        <a href="/" class="text-xl font-display font-extrabold tracking-wider bg-gradient-to-r from-amber-400 via-orange-400 to-amber-200 bg-clip-text text-transparent">
          GLASSWORKS.OS
        </a>
        <span class="text-xs font-mono px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">
          DIGITAL TWIN v2.4
        </span>
      </div>

      <!-- Zone 2: Navigation Links -->
      <nav class="hidden lg:flex items-center gap-1 bg-slate-950/60 p-1 rounded-xl border border-slate-800/80">
        <button 
          (click)="setTab('overview_3d')"
          [class]="getTabClass('overview_3d')">
          <span class="material-icons text-sm">view_in_ar</span>
          <span>3D Plant</span>
        </button>
        <button 
          (click)="setTab('furnace')"
          [class]="getTabClass('furnace')">
          <span class="material-icons text-sm">local_fire_department</span>
          <span>Furnace</span>
        </button>
        <button 
          (click)="setTab('tin_bath')"
          [class]="getTabClass('tin_bath')">
          <span class="material-icons text-sm">waves</span>
          <span>Tin Bath</span>
        </button>
        <button 
          (click)="setTab('lehr')"
          [class]="getTabClass('lehr')">
          <span class="material-icons text-sm">ac_unit</span>
          <span>Lehr</span>
        </button>
        <button 
          (click)="setTab('quality')"
          [class]="getTabClass('quality')">
          <span class="material-icons text-sm">qr_code_scanner</span>
          <span>Quality</span>
        </button>
        <button 
          (click)="setTab('batch_lab')"
          [class]="getTabClass('batch_lab')">
          <span class="material-icons text-sm">science</span>
          <span>Batch Lab</span>
        </button>
        <button 
          (click)="setTab('scenarios')"
          [class]="getTabClass('scenarios')">
          <span class="material-icons text-sm">alt_route</span>
          <span>What-If</span>
        </button>
        <button 
          (click)="setTab('energy')"
          [class]="getTabClass('energy')">
          <span class="material-icons text-sm">bolt</span>
          <span>Energy</span>
        </button>
        <button 
          (click)="setTab('time_machine')"
          [class]="getTabClass('time_machine')">
          <span class="material-icons text-sm">history</span>
          <span>Time Machine</span>
        </button>
      </nav>

      <!-- Zone 3: Actions (Simulation Controls & Signature Demos) -->
      <div class="flex items-center gap-3">
        <!-- Simulation Speed Selector -->
        <div class="hidden sm:flex items-center gap-1 bg-slate-950/80 px-2 py-1 rounded-lg border border-slate-800 text-xs font-mono">
          <button 
            (click)="setMode('REALTIME', 1)" 
            [class.text-amber-400]="dt.simulationMode() === 'REALTIME' && dt.simulationSpeedMultiplier() === 1"
            class="px-1.5 py-0.5 rounded hover:bg-slate-800 text-slate-400 transition-colors">
            1x
          </button>
          <button 
            (click)="setMode('FAST_FORWARD', 60)" 
            [class.text-amber-400]="dt.simulationMode() === 'FAST_FORWARD' && dt.simulationSpeedMultiplier() === 60"
            class="px-1.5 py-0.5 rounded hover:bg-slate-800 text-slate-400 transition-colors">
            60x
          </button>
          <button 
            (click)="setMode('PAUSED', 0)" 
            [class.text-amber-400]="dt.simulationMode() === 'PAUSED'"
            class="px-1.5 py-0.5 rounded hover:bg-slate-800 text-slate-400 transition-colors">
            <span class="material-icons text-xs">pause</span>
          </button>
        </div>

        <!-- Signature Demos Menu -->
        <div class="relative">
          <button 
            (click)="toggleDemoMenu()"
            class="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-slate-950 font-semibold rounded-lg shadow-sm transition-all whitespace-nowrap">
            <span class="material-icons text-sm">play_circle_filled</span>
            <span>Signature Demos</span>
          </button>

          @if (showDemoMenu) {
            <div class="absolute right-0 mt-2 w-64 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl p-2 z-50 flex flex-col gap-1 text-xs">
              <button 
                (click)="startDemo('sand-to-glass')"
                class="flex items-start gap-2 p-2 rounded-lg hover:bg-slate-800 text-left transition-colors">
                <span class="material-icons text-amber-400 text-base mt-0.5">grain</span>
                <div>
                  <div class="font-semibold text-slate-200">1. Sand to Glass</div>
                  <div class="text-slate-400 text-[11px]">Full continuous flow & defect origin tracing</div>
                </div>
              </button>
              <button 
                (click)="startDemo('time-machine')"
                class="flex items-start gap-2 p-2 rounded-lg hover:bg-slate-800 text-left transition-colors">
                <span class="material-icons text-sky-400 text-base mt-0.5">history</span>
                <div>
                  <div class="font-semibold text-slate-200">2. Furnace Time Machine</div>
                  <div class="text-slate-400 text-[11px]">Rewind state & predict thermal trends</div>
                </div>
              </button>
              <button 
                (click)="startDemo('what-if')"
                class="flex items-start gap-2 p-2 rounded-lg hover:bg-slate-800 text-left transition-colors">
                <span class="material-icons text-emerald-400 text-base mt-0.5">insights</span>
                <div>
                  <div class="font-semibold text-slate-200">3. What-If Scenario</div>
                  <div class="text-slate-400 text-[11px]">35% Cullet energy & CO2 optimization</div>
                </div>
              </button>
            </div>
          }
        </div>
      </div>
    </header>
  `
})
export class TopBarComponent {
  dt = inject(DigitalTwinService);
  showDemoMenu = false;

  setTab(tab: MainTab) {
    this.dt.setActiveTab(tab);
    this.showDemoMenu = false;
  }

  setMode(mode: SimulationMode, speed: number) {
    this.dt.setSimulationMode(mode, speed);
  }

  toggleDemoMenu() {
    this.showDemoMenu = !this.showDemoMenu;
  }

  startDemo(type: 'sand-to-glass' | 'time-machine' | 'what-if') {
    this.dt.startSignatureDemo(type);
    this.showDemoMenu = false;
  }

  getTabClass(tab: MainTab): string {
    const isActive = this.dt.activeTab() === tab;
    return `flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
      isActive 
        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' 
        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
    }`;
  }
}
