import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DigitalTwinService } from '../services/digital-twin.service';

@Component({
  selector: 'app-quality-view',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 max-w-7xl mx-auto flex flex-col gap-6 animate-fade-in text-slate-100">
      <!-- Header Bar -->
      <div class="flex flex-wrap items-center justify-between gap-4 bg-slate-900/80 p-5 rounded-2xl border border-slate-800 backdrop-blur-md">
        <div>
          <div class="flex items-center gap-2">
            <span class="material-icons text-emerald-400">qr_code_scanner</span>
            <h1 class="text-xl font-display font-bold">QUALITY.OS — Inspection & Backwards Traceability</h1>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Real-time optical line-scan camera defect detection & automated backwards provenance root-cause analysis.
          </p>
        </div>

        <div class="flex items-center gap-4 text-xs font-mono">
          <div class="bg-slate-950/80 px-3 py-1.5 rounded-xl border border-slate-800">
            <span class="text-slate-500 block text-[10px]">PRIME YIELD</span>
            <span class="text-emerald-400 font-bold text-sm">{{ q().primeQualityYieldPercent }}%</span>
          </div>
          <div class="bg-slate-950/80 px-3 py-1.5 rounded-xl border border-slate-800">
            <span class="text-slate-500 block text-[10px]">DEFECT RATE</span>
            <span class="text-amber-400 font-bold text-sm">{{ q().defectRatePpm }} PPM</span>
          </div>
          <div class="bg-slate-950/80 px-3 py-1.5 rounded-xl border border-slate-800">
            <span class="text-slate-500 block text-[10px]">CLARITY INDEX</span>
            <span class="text-sky-400 font-bold text-sm">{{ q().opticalClarityIndex }} / 100</span>
          </div>
        </div>
      </div>

      <!-- Main Grid: Defect Heatmap vs Backwards Traceability Inspector -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Ribbon Defect Scan Heatmap (Left 2 cols) -->
        <div class="glass-panel p-5 rounded-2xl lg:col-span-2 flex flex-col gap-4">
          <div class="flex items-center justify-between">
            <h3 class="text-sm font-semibold text-slate-200 flex items-center gap-2">
              <span class="material-icons text-amber-400 text-sm">filter_center_focus</span>
              <span>Line-Scan Camera Ribbon Defect Heatmap</span>
            </h3>
            <span class="text-xs font-mono text-slate-400">Ribbon Width: 3.85m</span>
          </div>

          <!-- Synthetic Ribbon Surface Canvas -->
          <div class="w-full h-56 bg-slate-950 rounded-xl border border-slate-800 relative overflow-hidden p-4 flex flex-col justify-between">
            <!-- Glass Ribbon Background Texture -->
            <div class="absolute inset-0 bg-gradient-to-r from-sky-950/30 via-slate-900/50 to-sky-950/30"></div>
            
            <!-- Grid Lines -->
            <div class="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:2rem_2rem]"></div>

            <!-- Defect Markers on Ribbon Surface -->
            @for (defect of q().activeDefects; track defect.id) {
              <button 
                (click)="dt.selectDefect(defect.id)"
                [style.left.%]="(defect.xPositionMeters / 3.85) * 88 + 6"
                [style.top.%]="((defect.yPositionMeters % 100) / 100) * 70 + 15"
                [class.ring-4]="dt.selectedDefectId() === defect.id"
                [class.ring-amber-400]="dt.selectedDefectId() === defect.id"
                class="absolute z-20 w-6 h-6 -ml-3 -mt-3 rounded-full flex items-center justify-center bg-red-500/30 border border-red-400 text-red-300 hover:scale-125 transition-all shadow-lg">
                <span class="material-icons text-xs">warning</span>
              </button>
            }

            <div class="relative z-10 flex items-center justify-between text-[10px] font-mono text-slate-500">
              <span>0.0m (Left Edge)</span>
              <span>1.92m (Center)</span>
              <span>3.85m (Right Edge)</span>
            </div>
          </div>

          <!-- Defect List Table -->
          <div class="flex flex-col gap-2">
            <span class="text-xs font-mono text-slate-400 font-semibold">DETECTED DEFECTS IN CURRENT RUN</span>
            <div class="flex flex-col gap-1.5">
              @for (d of q().activeDefects; track d.id) {
                <button 
                  (click)="dt.selectDefect(d.id)"
                  [class.border-amber-500/50]="dt.selectedDefectId() === d.id"
                  [class.bg-slate-900/90]="dt.selectedDefectId() === d.id"
                  class="bg-slate-950/60 p-3 rounded-xl border border-slate-800/80 flex items-center justify-between text-xs cursor-pointer hover:border-slate-700 transition-colors w-full text-left">
                  <div class="flex items-center gap-3">
                    <span class="material-icons text-red-400 text-base">report_problem</span>
                    <div>
                      <span class="font-mono font-bold text-slate-200">{{ d.id }} — {{ d.type }}</span>
                      <span class="text-slate-500 block text-[11px]">Pos: {{ d.xPositionMeters }}m | Size: {{ d.sizeMm }}mm</span>
                    </div>
                  </div>
                  <div class="text-right font-mono">
                    <span class="px-2 py-0.5 rounded bg-red-500/10 text-red-400 border border-red-500/20 text-[10px] uppercase font-bold block">
                      {{ d.severity }}
                    </span>
                    <span class="text-slate-500 text-[10px]">{{ d.provenance.probableOriginStage }}</span>
                  </div>
                </button>
              }
            </div>
          </div>
        </div>

        <!-- Backwards Traceability Root Cause Inspector (Right 1 col) -->
        <div class="glass-panel p-5 rounded-2xl flex flex-col gap-4">
          <h3 class="text-sm font-semibold text-slate-200 flex items-center gap-2 border-b border-slate-800 pb-2">
            <span class="material-icons text-amber-400 text-sm">history_edu</span>
            <span>BACKWARDS PROVENANCE TRACEABILITY</span>
          </h3>

          @if (selectedDefect(); as sel) {
            <div class="flex flex-col gap-3 text-xs">
              <div class="bg-amber-500/10 p-3 rounded-xl border border-amber-500/20 font-mono text-amber-300">
                <span class="text-[10px] text-amber-500 block uppercase font-bold">SUSPECTED ROOT CAUSE</span>
                <p class="mt-1 leading-relaxed text-xs">{{ sel.provenance.suspectedCause }}</p>
              </div>

              <!-- Upstream Provenance Chain Timeline -->
              <div class="flex flex-col gap-2 text-slate-300 font-mono">
                <span class="text-[10px] text-slate-500 uppercase font-bold">UPSTREAM PROCESS CHAIN</span>

                <div class="flex items-center gap-2 bg-slate-950/80 p-2 rounded-lg border border-slate-800">
                  <span class="material-icons text-sky-400 text-sm">description</span>
                  <div>
                    <span class="text-[10px] text-slate-500 block">1. SHEET ID</span>
                    <span class="font-bold text-slate-200">{{ sel.sheetId }}</span>
                  </div>
                </div>

                <div class="flex items-center gap-2 bg-slate-950/80 p-2 rounded-lg border border-slate-800">
                  <span class="material-icons text-sky-400 text-sm">ac_unit</span>
                  <div>
                    <span class="text-[10px] text-slate-500 block">2. LEHR ZONE 4 TEMP</span>
                    <span class="font-bold text-slate-200">{{ sel.provenance.processConditionsAtTime.lehrZone4TempC }}°C</span>
                  </div>
                </div>

                <div class="flex items-center gap-2 bg-slate-950/80 p-2 rounded-lg border border-slate-800">
                  <span class="material-icons text-amber-400 text-sm">waves</span>
                  <div>
                    <span class="text-[10px] text-slate-500 block">3. TIN BATH TEMP</span>
                    <span class="font-bold text-amber-300">{{ sel.provenance.processConditionsAtTime.tinBathTempC }}°C</span>
                  </div>
                </div>

                <div class="flex items-center gap-2 bg-slate-950/80 p-2 rounded-lg border border-slate-800">
                  <span class="material-icons text-orange-400 text-sm">local_fire_department</span>
                  <div>
                    <span class="text-[10px] text-slate-500 block">4. FURNACE MELTING TEMP</span>
                    <span class="font-bold text-orange-400">{{ sel.provenance.processConditionsAtTime.furnaceMeltingTempC }}°C</span>
                  </div>
                </div>

                <div class="flex items-center gap-2 bg-slate-950/80 p-2 rounded-lg border border-slate-800">
                  <span class="material-icons text-emerald-400 text-sm">science</span>
                  <div>
                    <span class="text-[10px] text-slate-500 block">5. BATCH RECIPE LOT</span>
                    <span class="font-bold text-emerald-300">{{ sel.provenance.processConditionsAtTime.batchLotNumber }}</span>
                  </div>
                </div>
              </div>
            </div>
          } @else {
            <p class="text-slate-500 text-xs italic">Select a defect from the ribbon heatmap to inspect backwards process provenance chain.</p>
          }
        </div>
      </div>
    </div>
  `
})
export class QualityViewComponent {
  dt = inject(DigitalTwinService);
  q = this.dt.quality;
  selectedDefect = this.dt.selectedDefect;
}
