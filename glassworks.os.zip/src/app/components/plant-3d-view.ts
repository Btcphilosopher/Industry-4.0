import { Component, ElementRef, ViewChild, AfterViewInit, OnDestroy, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import * as THREE from 'three';
import { DigitalTwinService, MainTab } from '../services/digital-twin.service';

interface SelectedEquipmentInfo {
  name: string;
  type: string;
  health: number;
  temp: number;
  status: string;
  description: string;
  tab: MainTab;
}

@Component({
  selector: 'app-plant-3d-view',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-[calc(100vh-4rem)] bg-slate-950 overflow-hidden flex flex-col">
      <!-- Top Control Overlay -->
      <div class="absolute top-4 left-4 z-20 flex items-center gap-2 bg-slate-900/80 backdrop-blur-md p-2 rounded-xl border border-slate-800 text-xs">
        <span class="text-slate-400 font-medium px-2">Layer View:</span>
        <button 
          (click)="set3DMode('OVERVIEW')" 
          [class.bg-amber-500]="active3DMode === 'OVERVIEW'"
          [class.text-slate-950]="active3DMode === 'OVERVIEW'"
          class="px-3 py-1 rounded-lg font-medium text-slate-300 hover:text-white transition-colors">
          Full Plant
        </button>
        <button 
          (click)="set3DMode('FURNACE_CUTAWAY')" 
          [class.bg-amber-500]="active3DMode === 'FURNACE_CUTAWAY'"
          [class.text-slate-950]="active3DMode === 'FURNACE_CUTAWAY'"
          class="px-3 py-1 rounded-lg font-medium text-slate-300 hover:text-white transition-colors">
          Furnace Cutaway
        </button>
        <button 
          (click)="set3DMode('TIN_BATH')" 
          [class.bg-amber-500]="active3DMode === 'TIN_BATH'"
          [class.text-slate-950]="active3DMode === 'TIN_BATH'"
          class="px-3 py-1 rounded-lg font-medium text-slate-300 hover:text-white transition-colors">
          Tin Bath Ribbon
        </button>
        <button 
          (click)="set3DMode('LEHR')" 
          [class.bg-amber-500]="active3DMode === 'LEHR'"
          [class.text-slate-950]="active3DMode === 'LEHR'"
          class="px-3 py-1 rounded-lg font-medium text-slate-300 hover:text-white transition-colors">
          Lehr Zones
        </button>
      </div>

      <!-- Live Flow Bar Banner -->
      <div class="absolute top-4 right-4 z-20 bg-slate-900/90 backdrop-blur-md p-3 rounded-xl border border-slate-800 text-xs font-mono flex items-center gap-4">
        <div>
          <span class="text-slate-500 block text-[10px]">PULL RATE</span>
          <span class="text-amber-400 font-bold text-sm">{{ dt.furnace().pullRateTonnesPerDay }} t/day</span>
        </div>
        <div class="w-px h-6 bg-slate-800"></div>
        <div>
          <span class="text-slate-500 block text-[10px]">CROWN MAX TEMP</span>
          <span class="text-orange-400 font-bold text-sm">{{ dt.furnace().crownTempMaxC }}°C</span>
        </div>
        <div class="w-px h-6 bg-slate-800"></div>
        <div>
          <span class="text-slate-500 block text-[10px]">RIBBON THICKNESS</span>
          <span class="text-sky-400 font-bold text-sm">{{ dt.tinBath().actualCenterThicknessMm }} mm</span>
        </div>
        <div class="w-px h-6 bg-slate-800"></div>
        <div>
          <span class="text-slate-500 block text-[10px]">PRIME YIELD</span>
          <span class="text-emerald-400 font-bold text-sm">{{ dt.quality().primeQualityYieldPercent }}%</span>
        </div>
      </div>

      <!-- 3D Canvas CanvasContainer -->
      <div #canvasContainer class="w-full h-full cursor-grab active:cursor-grabbing"></div>

      <!-- Interactive Equipment Inspector Sidebar -->
      @if (selectedEquipment) {
        <div class="absolute bottom-6 left-6 z-20 w-80 bg-slate-900/95 backdrop-blur-md p-4 rounded-2xl border border-slate-700 shadow-2xl text-xs flex flex-col gap-3 animate-fade-in">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <div class="flex items-center gap-2">
              <span class="material-icons text-amber-400">precision_manufacturing</span>
              <span class="font-bold text-sm text-slate-100">{{ selectedEquipment.name }}</span>
            </div>
            <button (click)="deselectEquipment()" class="text-slate-500 hover:text-slate-300">
              <span class="material-icons text-sm">close</span>
            </button>
          </div>

          <div class="grid grid-cols-2 gap-2 text-slate-300">
            <div class="bg-slate-950/60 p-2 rounded-lg border border-slate-800">
              <span class="text-slate-500 block text-[10px]">HEALTH</span>
              <span class="font-mono text-emerald-400 font-semibold">{{ selectedEquipment.health }}%</span>
            </div>
            <div class="bg-slate-950/60 p-2 rounded-lg border border-slate-800">
              <span class="text-slate-500 block text-[10px]">TEMPERATURE</span>
              <span class="font-mono text-amber-400 font-semibold">{{ selectedEquipment.temp }}°C</span>
            </div>
            <div class="bg-slate-950/60 p-2 rounded-lg border border-slate-800">
              <span class="text-slate-500 block text-[10px]">STATUS</span>
              <span class="font-mono text-sky-400 font-semibold">{{ selectedEquipment.status }}</span>
            </div>
            <div class="bg-slate-950/60 p-2 rounded-lg border border-slate-800">
              <span class="text-slate-500 block text-[10px]">STAGE</span>
              <span class="font-mono text-slate-200 font-semibold">{{ selectedEquipment.type }}</span>
            </div>
          </div>

          <p class="text-slate-400 text-[11px] leading-relaxed">
            {{ selectedEquipment.description }}
          </p>

          <button 
            (click)="navigateToStage(selectedEquipment.tab)"
            class="w-full py-2 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 rounded-xl font-medium transition-colors flex items-center justify-center gap-1.5">
            <span>Inspect Engineering Twin</span>
            <span class="material-icons text-xs">arrow_forward</span>
          </button>
        </div>
      }
    </div>
  `
})
export class Plant3DViewComponent implements AfterViewInit, OnDestroy {
  @ViewChild('canvasContainer') canvasContainer!: ElementRef<HTMLDivElement>;
  dt = inject(DigitalTwinService);

  active3DMode: 'OVERVIEW' | 'FURNACE_CUTAWAY' | 'TIN_BATH' | 'LEHR' = 'OVERVIEW';
  selectedEquipment: SelectedEquipmentInfo | null = null;

  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animationFrameId!: number;
  private raycaster = new THREE.Raycaster();
  private mouse = new THREE.Vector2();
  private clickableObjects: THREE.Object3D[] = [];
  private glassRibbonMesh!: THREE.Mesh;

  ngAfterViewInit() {
    this.init3DScene();
    this.buildPlantGeometry();
    this.animate();
  }

  ngOnDestroy() {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  set3DMode(mode: 'OVERVIEW' | 'FURNACE_CUTAWAY' | 'TIN_BATH' | 'LEHR') {
    this.active3DMode = mode;
    
    // Animate camera target position
    if (mode === 'OVERVIEW') {
      this.animateCameraTo(new THREE.Vector3(0, 35, 45), new THREE.Vector3(0, 0, 0));
    } else if (mode === 'FURNACE_CUTAWAY') {
      this.animateCameraTo(new THREE.Vector3(-22, 12, 18), new THREE.Vector3(-22, 2, 0));
    } else if (mode === 'TIN_BATH') {
      this.animateCameraTo(new THREE.Vector3(-5, 8, 12), new THREE.Vector3(-5, 1, 0));
    } else if (mode === 'LEHR') {
      this.animateCameraTo(new THREE.Vector3(12, 10, 15), new THREE.Vector3(12, 1, 0));
    }
  }

  private animateCameraTo(targetPos: THREE.Vector3, targetLookAt: THREE.Vector3) {
    const startPos = this.camera.position.clone();
    let progress = 0;
    
    const step = () => {
      progress += 0.04;
      if (progress <= 1) {
        this.camera.position.lerpVectors(startPos, targetPos, progress);
        this.camera.lookAt(targetLookAt);
        requestAnimationFrame(step);
      }
    };
    step();
  }

  private init3DScene() {
    const container = this.canvasContainer.nativeElement;
    const width = container.clientWidth;
    const height = container.clientHeight;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0a0f1d);
    this.scene.fog = new THREE.FogExp2(0x0a0f1d, 0.008);

    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    this.camera.position.set(0, 35, 45);
    this.camera.lookAt(0, 0, 0);

    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    container.appendChild(this.renderer.domElement);

    // Lights
    const ambientLight = new THREE.AmbientLight(0x334155, 1.5);
    this.scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 1.2);
    dirLight.position.set(20, 40, 20);
    this.scene.add(dirLight);

    // Furnace glow point light
    const furnaceLight = new THREE.PointLight(0xf59e0b, 3.5, 40);
    furnaceLight.position.set(-22, 4, 0);
    this.scene.add(furnaceLight);

    // Grid Floor
    const gridHelper = new THREE.GridHelper(100, 50, 0x334155, 0x1e293b);
    gridHelper.position.y = -0.5;
    this.scene.add(gridHelper);

    // Window resize handler
    window.addEventListener('resize', () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(w, h);
    });

    // Click handler for raycasting equipment
    container.addEventListener('click', (e) => this.onCanvasClick(e));
  }

  private buildPlantGeometry() {
    // Stage 1: Batch House & Silos (X = -36)
    const siloGroup = new THREE.Group();
    siloGroup.position.set(-36, 0, 0);
    siloGroup.userData = {
      name: 'Batch House & Raw Silos',
      type: 'BATCHING',
      health: 98,
      temp: 22,
      status: 'OPERATIONAL',
      description: 'Computer-controlled weighing and mixing of silica sand, soda ash, limestone, dolomite & recycled cullet.',
      tab: 'batch_lab'
    };

    for (let i = -1; i <= 1; i++) {
      const siloGeo = new THREE.CylinderGeometry(1.2, 1.2, 8, 16);
      const siloMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.8, roughness: 0.3 });
      const siloMesh = new THREE.Mesh(siloGeo, siloMat);
      siloMesh.position.set(0, 4, i * 2.8);
      siloGroup.add(siloMesh);
    }
    this.scene.add(siloGroup);
    this.clickableObjects.push(siloGroup);

    // Stage 2: Melting Furnace (X = -22, Length = 12, Width = 6)
    const furnaceGroup = new THREE.Group();
    furnaceGroup.position.set(-22, 0, 0);
    furnaceGroup.userData = {
      name: 'Glass Melting Furnace (1585°C)',
      type: 'FURNACE',
      health: 82,
      temp: 1585,
      status: 'HEAVY_FIRING',
      description: 'Regenerative cross-fired float glass furnace with 6 combustion ports, producing 840 tonnes/day molten glass.',
      tab: 'furnace'
    };

    const furnaceGeo = new THREE.BoxGeometry(12, 4.5, 6);
    const furnaceMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.7 });
    const furnaceMesh = new THREE.Mesh(furnaceGeo, furnaceMat);
    furnaceMesh.position.y = 2.25;
    furnaceGroup.add(furnaceMesh);

    // Glowing interior pool
    const poolGeo = new THREE.PlaneGeometry(11, 5);
    const poolMat = new THREE.MeshBasicMaterial({ color: 0xf97316, side: THREE.DoubleSide });
    const poolMesh = new THREE.Mesh(poolGeo, poolMat);
    poolMesh.rotation.x = -Math.PI / 2;
    poolMesh.position.set(0, 4.51, 0);
    furnaceGroup.add(poolMesh);

    this.scene.add(furnaceGroup);
    this.clickableObjects.push(furnaceGroup);

    // Stage 3: Tin Bath (X = -5, Length = 16, Width = 4)
    const tinGroup = new THREE.Group();
    tinGroup.position.set(-5, 0, 0);
    tinGroup.userData = {
      name: 'Float Tin Bath (Molten Tin Pool)',
      type: 'TIN_BATH',
      health: 96,
      temp: 1090,
      status: 'FLOATING_ACTIVE',
      description: 'Molten tin bath in N2/H2 reducing atmosphere where glass forms a flat ribbon between 1100°C and 600°C.',
      tab: 'tin_bath'
    };

    const tinGeo = new THREE.BoxGeometry(16, 2, 4.2);
    const tinMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.9, roughness: 0.1 });
    const tinMesh = new THREE.Mesh(tinGeo, tinMat);
    tinMesh.position.y = 1;
    tinGroup.add(tinMesh);
    this.scene.add(tinGroup);
    this.clickableObjects.push(tinGroup);

    // Continuous Glass Ribbon (X = -28 to X = 32)
    const ribbonGeo = new THREE.PlaneGeometry(60, 2.8, 60, 1);
    const ribbonMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.7,
      roughness: 0.1,
      metalness: 0.2
    });
    this.glassRibbonMesh = new THREE.Mesh(ribbonGeo, ribbonMat);
    this.glassRibbonMesh.rotation.x = -Math.PI / 2;
    this.glassRibbonMesh.position.set(2, 2.05, 0);
    this.scene.add(this.glassRibbonMesh);

    // Stage 4: Annealing Lehr (X = 12, Length = 16, Width = 3.5)
    const lehrGroup = new THREE.Group();
    lehrGroup.position.set(12, 0, 0);
    lehrGroup.userData = {
      name: 'Annealing Lehr (16 Cooling Zones)',
      type: 'LEHR',
      health: 99,
      temp: 595,
      status: 'CONTROLLED_COOLING',
      description: '120-meter enclosed tunnel kiln reducing residual internal thermal stress down to < 2.0 MPa.',
      tab: 'lehr'
    };

    const lehrGeo = new THREE.BoxGeometry(16, 3, 3.8);
    const lehrMat = new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.4 });
    const lehrMesh = new THREE.Mesh(lehrGeo, lehrMat);
    lehrMesh.position.y = 1.5;
    lehrGroup.add(lehrMesh);
    this.scene.add(lehrGroup);
    this.clickableObjects.push(lehrGroup);

    // Stage 5: Inspection Camera & Cutting (X = 26)
    const inspectionGroup = new THREE.Group();
    inspectionGroup.position.set(26, 0, 0);
    inspectionGroup.userData = {
      name: 'Optical Line-Scan Inspection & Cross-Cutter',
      type: 'INSPECTION_CUTTER',
      health: 99,
      temp: 45,
      status: 'SCANNING_ACTIVE',
      description: 'High-resolution line-scan camera array detecting micro-bubbles, inclusions and surface defects.',
      tab: 'quality'
    };

    const archGeo = new THREE.TorusGeometry(2.5, 0.2, 8, 20);
    const archMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.9 });
    const archMesh = new THREE.Mesh(archGeo, archMat);
    archMesh.position.y = 2.5;
    archMesh.rotation.y = Math.PI / 2;
    inspectionGroup.add(archMesh);
    this.scene.add(inspectionGroup);
    this.clickableObjects.push(inspectionGroup);

    // Stage 6: Warehouse & Stacker (X = 35)
    const whGroup = new THREE.Group();
    whGroup.position.set(35, 0, 0);
    whGroup.userData = {
      name: 'Automated Warehouse & Robotic Stacker',
      type: 'WAREHOUSE',
      health: 100,
      temp: 20,
      status: 'STACKING',
      description: 'Vacuum cup robotic arms stacking finished glass sheets into customer order racks.',
      tab: 'bottlenecks'
    };

    for (let r = -1; r <= 1; r++) {
      const rackGeo = new THREE.BoxGeometry(3, 4, 1.8);
      const rackMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.5 });
      const rackMesh = new THREE.Mesh(rackGeo, rackMat);
      rackMesh.position.set(0, 2, r * 2.5);
      whGroup.add(rackMesh);
    }
    this.scene.add(whGroup);
    this.clickableObjects.push(whGroup);
  }

  private animate() {
    this.animationFrameId = requestAnimationFrame(() => this.animate());

    // Gently animate ribbon texture/pulse
    if (this.glassRibbonMesh) {
      const time = Date.now() * 0.002;
      (this.glassRibbonMesh.material as THREE.MeshStandardMaterial).opacity = 0.65 + Math.sin(time) * 0.05;
    }

    this.renderer.render(this.scene, this.camera);
  }

  private onCanvasClick(event: MouseEvent) {
    const rect = this.canvasContainer.nativeElement.getBoundingClientRect();
    this.mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(this.mouse, this.camera);
    const intersects = this.raycaster.intersectObjects(this.clickableObjects, true);

    if (intersects.length > 0) {
      let obj: THREE.Object3D | null = intersects[0].object;
      while (obj && !obj.userData['name'] && obj.parent) {
        obj = obj.parent;
      }
      if (obj && obj.userData['name']) {
        this.selectedEquipment = obj.userData as unknown as SelectedEquipmentInfo;
      }
    } else {
      this.selectedEquipment = null;
    }
  }

  deselectEquipment() {
    this.selectedEquipment = null;
  }

  navigateToStage(tab: MainTab) {
    this.dt.setActiveTab(tab);
  }
}
