import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DigitalTwinService } from '../services/digital-twin.service';

@Component({
  selector: 'app-scenarios-view',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 max-w-7xl mx-auto flex flex-col gap-6 animate-fade-in text-slate-100">
      <!-- Header Bar -->
      <div class="flex flex-wrap items-center justify-between gap-4 bg-slate-900/80 p-5 rounded-2xl border border-slate-800 backdrop-blur-md">
        <div>
          <div class="flex items-center gap-2">
            <span class="material-icons text-amber-400">alt_route</span>
            <h1 class="text-xl font-display font-bold">SCENARIO LAB — What-If Digital Experimentation</h1>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Simulate plant operational modifications against live baseline without affecting real physical plant operations.
          </p>
        </div>

        <span class="text-xs font-mono px-3 py-1 rounded-xl bg-amber-500/10 text-amber-300 border border-amber-500/20">
          PROVENANCE: SIMULATED
        </span>
      </div>

      <!-- Prebuilt Scenario Selection Cards -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        @for (scen of dt.availableScenarios(); track scen.id) {
          <button 
            (click)="dt.selectScenario(scen.id)"
            [class.border-amber-500]="dt.activeScenarioId() === scen.id"
            [class.bg-slate-900]="dt.activeScenarioId() === scen.id"
            class="glass-panel-interactive p-4 rounded-2xl cursor-pointer flex flex-col justify-between gap-3 text-xs w-full text-left">
            <div>
              <span class="font-bold text-slate-100 text-sm block mb-1">{{ scen.name }}</span>
              <p class="text-slate-400 text-[11px] leading-relaxed">{{ scen.description }}</p>
            </div>
            <div class="w-full py-1.5 bg-slate-950 hover:bg-slate-800 rounded-lg text-slate-300 font-mono text-[11px] border border-slate-800 text-center">
              Run Scenario
            </div>
          </button>
        }
      </div>

      <!-- Baseline vs Simulated Split-Screen Delta View -->
      @if (dt.scenarioResult(); as res) {
        <div class="glass-panel p-6 rounded-2xl flex flex-col gap-6">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <h2 class="text-base font-bold text-amber-400 font-display">
              COMPARISON: BASELINE vs {{ res.scenarioName | uppercase }}
            </h2>
            <span class="text-xs font-mono text-slate-500">Simulated: {{ res.simulatedTimestamp | date:'mediumTime' }}</span>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-3 gap-6 font-mono text-xs">
            <!-- Baseline Column -->
            <div class="bg-slate-950/80 p-5 rounded-2xl border border-slate-800 flex flex-col gap-3">
              <span class="text-slate-500 font-bold block text-sm border-b border-slate-800 pb-2">BASELINE CURRENT</span>
              <div class="flex items-center justify-between">
                <span class="text-slate-400">ENERGY DEMAND</span>
                <span class="font-bold text-slate-200">{{ res.baseline.energyMwhTonne }} MWh/t</span>
              </div>
              <div class="flex items-center justify-between">
                <span class="text-slate-400">CO₂ EMISSIONS</span>
                <span class="font-bold text-slate-200">{{ res.baseline.co2TonnesDay }} t/day</span>
              </div>
              <div class="flex items-center justify-between">
                <span class="text-slate-400">PRODUCTION</span>
                <span class="font-bold text-slate-200">{{ res.baseline.dailyProductionTonnes }} t/day</span>
              </div>
              <div class="flex items-center justify-between">
                <span class="text-slate-400">PRIME YIELD</span>
                <span class="font-bold text-emerald-400">{{ res.baseline.primeYieldPercent }}%</span>
              </div>
            </div>

            <!-- Simulated Column -->
            <div class="bg-slate-950/80 p-5 rounded-2xl border border-slate-800 flex flex-col gap-3">
              <span class="text-amber-400 font-bold block text-sm border-b border-slate-800 pb-2">SIMULATED SCENARIO</span>
              <div class="flex items-center justify-between">
                <span class="text-slate-400">ENERGY DEMAND</span>
                <span class="font-bold text-amber-300">{{ res.simulated.energyMwhTonne }} MWh/t</span>
              </div>
              <div class="flex items-center justify-between">
                <span class="text-slate-400">CO₂ EMISSIONS</span>
                <span class="font-bold text-amber-300">{{ res.simulated.co2TonnesDay }} t/day</span>
              </div>
              <div class="flex items-center justify-between">
                <span class="text-slate-400">PRODUCTION</span>
                <span class="font-bold text-amber-300">{{ res.simulated.dailyProductionTonnes }} t/day</span>
              </div>
              <div class="flex items-center justify-between">
                <span class="text-slate-400">PRIME YIELD</span>
                <span class="font-bold text-amber-300">{{ res.simulated.primeYieldPercent }}%</span>
              </div>
            </div>

            <!-- Deltas Column -->
            <div class="bg-amber-500/10 p-5 rounded-2xl border border-amber-500/30 flex flex-col gap-3">
              <span class="text-amber-300 font-bold block text-sm border-b border-amber-500/20 pb-2">SIMULATED DELTAS (Δ)</span>
              <div class="flex items-center justify-between">
                <span class="text-slate-400">ENERGY DELTA</span>
                <span 
                  [class.text-emerald-400]="res.deltas.energyMwhTonneDeltaPercent <= 0"
                  [class.text-red-400]="res.deltas.energyMwhTonneDeltaPercent > 0"
                  class="font-bold">
                  {{ res.deltas.energyMwhTonneDeltaPercent }}%
                </span>
              </div>
              <div class="flex items-center justify-between">
                <span class="text-slate-400">CO₂ DELTA</span>
                <span 
                  [class.text-emerald-400]="res.deltas.co2TonnesDayDeltaPercent <= 0"
                  [class.text-red-400]="res.deltas.co2TonnesDayDeltaPercent > 0"
                  class="font-bold">
                  {{ res.deltas.co2TonnesDayDeltaPercent }}%
                </span>
              </div>
              <div class="flex items-center justify-between">
                <span class="text-slate-400">YIELD DELTA</span>
                <span 
                  [class.text-emerald-400]="res.deltas.primeYieldDeltaPercent >= 0"
                  [class.text-red-400]="res.deltas.primeYieldDeltaPercent < 0"
                  class="font-bold">
                  {{ res.deltas.primeYieldDeltaPercent }}%
                </span>
              </div>
              <div class="flex items-center justify-between">
                <span class="text-slate-400">DAILY COST DELTA</span>
                <span 
                  [class.text-emerald-400]="res.deltas.dailyCostUsdDelta <= 0"
                  [class.text-red-400]="res.deltas.dailyCostUsdDelta > 0"
                  class="font-bold">
                  \${{ res.deltas.dailyCostUsdDelta }} / day
                </span>
              </div>
            </div>
          </div>
        </div>
      }
    </div>
  `
})
export class ScenariosViewComponent {
  dt = inject(DigitalTwinService);
}
