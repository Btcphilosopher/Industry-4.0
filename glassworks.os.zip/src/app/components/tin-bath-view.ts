import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DigitalTwinService } from '../services/digital-twin.service';

@Component({
  selector: 'app-tin-bath-view',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 max-w-7xl mx-auto flex flex-col gap-6 animate-fade-in text-slate-100">
      <!-- Header Bar -->
      <div class="flex flex-wrap items-center justify-between gap-4 bg-slate-900/80 p-5 rounded-2xl border border-slate-800 backdrop-blur-md">
        <div>
          <div class="flex items-center gap-2">
            <span class="material-icons text-sky-400">waves</span>
            <h1 class="text-xl font-display font-bold">Tin Bath Digital Twin — Molten Tin & Ribbon Formation</h1>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            58-meter molten tin pool (210 tonnes liquid tin, 5.0% H₂ / 95% N₂ reducing atmosphere, top-roll stretch mechanics).
          </p>
        </div>

        <div class="flex items-center gap-4 text-xs font-mono">
          <div class="bg-slate-950/80 px-3 py-1.5 rounded-xl border border-slate-800">
            <span class="text-slate-500 block text-[10px]">RIBBON WIDTH</span>
            <span class="text-sky-400 font-bold text-sm">{{ tb().glassRibbonWidthMeters }} m</span>
          </div>
          <div class="bg-slate-950/80 px-3 py-1.5 rounded-xl border border-slate-800">
            <span class="text-slate-500 block text-[10px]">CENTER THICKNESS</span>
            <span class="text-amber-400 font-bold text-sm">{{ tb().actualCenterThicknessMm }} mm</span>
          </div>
          <div class="bg-slate-950/80 px-3 py-1.5 rounded-xl border border-slate-800">
            <span class="text-slate-500 block text-[10px]">DRAW SPEED</span>
            <span class="text-emerald-400 font-bold text-sm">{{ tb().drawSpeedMetersPerMin }} m/min</span>
          </div>
        </div>
      </div>

      <!-- Cross-Ribbon Thickness Map & Longitudinal Profile -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Thickness Profile Map (Left Edge, Center, Right Edge) -->
        <div class="glass-panel p-5 rounded-2xl flex flex-col gap-4">
          <h3 class="text-sm font-semibold text-slate-200 flex items-center gap-2">
            <span class="material-icons text-sky-400 text-sm">straighten</span>
            <span>Cross-Ribbon Thickness Distribution</span>
          </h3>

          <div class="bg-slate-950/80 p-4 rounded-xl border border-slate-800 flex items-center justify-between text-xs font-mono">
            <div class="text-center">
              <span class="text-slate-500 block text-[10px]">LEFT EDGE</span>
              <span class="text-slate-200 font-bold text-sm">{{ tb().actualLeftEdgeThicknessMm }} mm</span>
            </div>
            <div class="text-center bg-amber-500/10 px-4 py-2 rounded-xl border border-amber-500/20">
              <span class="text-amber-400 block text-[10px] font-bold">CENTER TARGET: {{ tb().targetThicknessMm }} mm</span>
              <span class="text-amber-300 font-bold text-base">{{ tb().actualCenterThicknessMm }} mm</span>
            </div>
            <div class="text-center">
              <span class="text-slate-500 block text-[10px]">RIGHT EDGE</span>
              <span class="text-slate-200 font-bold text-sm">{{ tb().actualRightEdgeThicknessMm }} mm</span>
            </div>
          </div>

          <div class="w-full bg-slate-950 h-16 rounded-xl border border-slate-800 p-3 flex items-center justify-between text-xs text-slate-400">
            <span>Left Knurl (12mm)</span>
            <div class="flex-1 mx-4 h-3 bg-gradient-to-r from-sky-500 via-amber-400 to-sky-500 rounded-full"></div>
            <span>Right Knurl (12mm)</span>
          </div>
        </div>

        <!-- Longitudinal Bath Temperature Profile (1100°C -> 600°C) -->
        <div class="glass-panel p-5 rounded-2xl flex flex-col gap-4">
          <h3 class="text-sm font-semibold text-slate-200 flex items-center gap-2">
            <span class="material-icons text-amber-400 text-sm">show_chart</span>
            <span>Longitudinal Bath Temperature Profile (°C)</span>
          </h3>

          <div class="bg-slate-950/80 p-4 rounded-xl border border-slate-800 flex items-end justify-between h-32 gap-1 text-[10px] font-mono text-slate-400">
            @for (temp of tb().longitudinalTempProfileC; track $index) {
              <div class="flex-1 flex flex-col items-center gap-1 h-full justify-end">
                <div 
                  [style.height.%]="((temp - 550) / (1100 - 550)) * 100"
                  class="w-full bg-gradient-to-t from-sky-600 via-amber-500 to-orange-500 rounded-t"></div>
                <span class="text-[9px] text-slate-500 rotate-90 my-2">{{ temp }}</span>
              </div>
            }
          </div>
        </div>
      </div>

      <!-- Top Rollers Interactive Machine Controls -->
      <div class="glass-panel p-5 rounded-2xl flex flex-col gap-4">
        <div class="flex items-center justify-between">
          <h3 class="text-sm font-semibold text-slate-200 flex items-center gap-2">
            <span class="material-icons text-amber-400 text-sm">settings_suggest</span>
            <span>Top-Roll Drive Knurl Penetration & Angle Adjustments</span>
          </h3>
          <span class="text-xs font-mono text-slate-400">12 Active Top-Roll Units</span>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          @for (roller of tb().topRollers; track roller.id) {
            <div class="bg-slate-950/80 p-3 rounded-xl border border-slate-800 flex flex-col gap-2 text-xs">
              <div class="flex items-center justify-between font-mono">
                <span class="font-bold text-amber-400">{{ roller.id }}</span>
                <span class="text-[10px] text-slate-500">{{ roller.side }}</span>
              </div>
              <div class="flex items-center justify-between text-[11px] text-slate-300 font-mono">
                <span>Angle:</span>
                <span class="text-slate-100 font-bold">{{ roller.angleDegrees }}°</span>
              </div>
              <div class="flex items-center justify-between text-[11px] text-slate-300 font-mono">
                <span>Depth:</span>
                <span class="text-sky-400 font-bold">{{ roller.penetrationDepthMm }} mm</span>
              </div>
              <div class="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden mt-1">
                <div [style.width.%]="100 - roller.wearPercent" class="bg-emerald-400 h-full"></div>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class TinBathViewComponent {
  dt = inject(DigitalTwinService);
  tb = this.dt.tinBath;
}
