import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DigitalTwinService } from '../services/digital-twin.service';

@Component({
  selector: 'app-time-machine-view',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 max-w-7xl mx-auto flex flex-col gap-6 animate-fade-in text-slate-100">
      <!-- Header Bar -->
      <div class="flex flex-wrap items-center justify-between gap-4 bg-slate-900/80 p-5 rounded-2xl border border-slate-800 backdrop-blur-md">
        <div>
          <div class="flex items-center gap-2">
            <span class="material-icons text-sky-400">history</span>
            <h1 class="text-xl font-display font-bold">FURNACE TIME MACHINE — Historical Rewind & Predictive Forecast</h1>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Scrub plant historical state back 7 days or project forward 24 hours to observe thermal evolution and quality trends.
          </p>
        </div>

        @if (dt.activeSnapshot(); as snap) {
          <div class="flex items-center gap-2 font-mono text-xs">
            <span class="text-slate-400 font-bold">{{ snap.label }}</span>
            <span 
              [class.bg-emerald-500/10]="snap.provenance === 'MEASURED'"
              [class.text-emerald-400]="snap.provenance === 'MEASURED'"
              [class.bg-amber-500/10]="snap.provenance === 'ESTIMATED'"
              [class.text-amber-400]="snap.provenance === 'ESTIMATED'"
              [class.bg-sky-500/10]="snap.provenance === 'PREDICTED'"
              [class.text-sky-400]="snap.provenance === 'PREDICTED'"
              class="px-2.5 py-1 rounded-lg border border-slate-700 font-bold uppercase">
              STATUS: {{ snap.provenance }}
            </span>
          </div>
        }
      </div>

      <!-- Timeline Scrubber Control -->
      <div class="glass-panel p-6 rounded-2xl flex flex-col gap-4">
        <h3 class="text-sm font-semibold text-slate-200 flex items-center justify-between">
          <span class="flex items-center gap-2">
            <span class="material-icons text-amber-400 text-sm">more_time</span>
            <span>Plant Timeline Scrubber</span>
          </span>
          <span class="text-xs font-mono text-slate-400">{{ dt.activeSnapshot().timestamp | date:'medium' }}</span>
        </h3>

        <div class="grid grid-cols-6 gap-2">
          @for (s of dt.historianSnapshots(); track s.label; let i = $index) {
            <button 
              (click)="dt.selectSnapshot(i)"
              [class.border-amber-500]="dt.selectedSnapshotIndex() === i"
              [class.bg-amber-500/20]="dt.selectedSnapshotIndex() === i"
              [class.text-amber-300]="dt.selectedSnapshotIndex() === i"
              class="p-3 rounded-xl border border-slate-800 bg-slate-950 flex flex-col items-center gap-1 font-mono text-xs transition-colors hover:border-slate-700">
              <span class="font-bold">{{ s.label }}</span>
              <span class="text-[9px] text-slate-500 uppercase">{{ s.provenance }}</span>
            </button>
          }
        </div>
      </div>

      <!-- Snapshot Detailed State View -->
      @if (dt.activeSnapshot(); as snap) {
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 font-mono text-xs">
          <div class="glass-panel p-5 rounded-2xl flex flex-col gap-1">
            <span class="text-slate-500 text-[10px]">CROWN MAX TEMP</span>
            <span class="text-orange-400 font-bold text-xl">{{ snap.crownTempC }}°C</span>
            <span class="text-slate-500 text-[10px] uppercase">STATUS: {{ snap.provenance }}</span>
          </div>
          <div class="glass-panel p-5 rounded-2xl flex flex-col gap-1">
            <span class="text-slate-500 text-[10px]">MELTING ZONE TEMP</span>
            <span class="text-amber-400 font-bold text-xl">{{ snap.meltingTempC }}°C</span>
            <span class="text-slate-500 text-[10px] uppercase">STATUS: {{ snap.provenance }}</span>
          </div>
          <div class="glass-panel p-5 rounded-2xl flex flex-col gap-1">
            <span class="text-slate-500 text-[10px]">PRIME YIELD</span>
            <span class="text-emerald-400 font-bold text-xl">{{ snap.primeYieldPercent }}%</span>
            <span class="text-slate-500 text-[10px] uppercase">STATUS: {{ snap.provenance }}</span>
          </div>
          <div class="glass-panel p-5 rounded-2xl flex flex-col gap-1">
            <span class="text-slate-500 text-[10px]">CO₂ EMISSIONS</span>
            <span class="text-sky-400 font-bold text-xl">{{ snap.co2TonnesDay }} t/day</span>
            <span class="text-slate-500 text-[10px] uppercase">STATUS: {{ snap.provenance }}</span>
          </div>
        </div>
      }
    </div>
  `
})
export class TimeMachineViewComponent {
  dt = inject(DigitalTwinService);
}
