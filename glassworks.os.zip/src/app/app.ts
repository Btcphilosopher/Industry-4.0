import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DigitalTwinService } from './services/digital-twin.service';
import { TopBarComponent } from './components/top-bar';
import { Plant3DViewComponent } from './components/plant-3d-view';
import { FurnaceViewComponent } from './components/furnace-view';
import { TinBathViewComponent } from './components/tin-bath-view';
import { LehrViewComponent } from './components/lehr-view';
import { QualityViewComponent } from './components/quality-view';
import { BatchLabViewComponent } from './components/batch-lab-view';
import { ScenariosViewComponent } from './components/scenarios-view';
import { EnergyViewComponent } from './components/energy-view';
import { TimeMachineViewComponent } from './components/time-machine-view';
import { BottlenecksViewComponent } from './components/bottlenecks-view';
import { SignatureDemosModalComponent } from './components/signature-demos-modal';

@Component({
  selector: 'app-root',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    TopBarComponent,
    Plant3DViewComponent,
    FurnaceViewComponent,
    TinBathViewComponent,
    LehrViewComponent,
    QualityViewComponent,
    BatchLabViewComponent,
    ScenariosViewComponent,
    EnergyViewComponent,
    TimeMachineViewComponent,
    BottlenecksViewComponent,
    SignatureDemosModalComponent
  ],
  template: `
    <div class="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500/30 selection:text-amber-200">
      <!-- Top Navigation Contract Bar -->
      <app-top-bar></app-top-bar>

      <!-- Main View Router Container based on active tab signal -->
      <main class="flex-1 relative overflow-x-hidden">
        @switch (dt.activeTab()) {
          @case ('overview_3d') {
            <app-plant-3d-view></app-plant-3d-view>
          }
          @case ('furnace') {
            <app-furnace-view></app-furnace-view>
          }
          @case ('tin_bath') {
            <app-tin-bath-view></app-tin-bath-view>
          }
          @case ('lehr') {
            <app-lehr-view></app-lehr-view>
          }
          @case ('quality') {
            <app-quality-view></app-quality-view>
          }
          @case ('batch_lab') {
            <app-batch-lab-view></app-batch-lab-view>
          }
          @case ('scenarios') {
            <app-scenarios-view></app-scenarios-view>
          }
          @case ('energy') {
            <app-energy-view></app-energy-view>
          }
          @case ('time_machine') {
            <app-time-machine-view></app-time-machine-view>
          }
          @case ('bottlenecks') {
            <app-bottlenecks-view></app-bottlenecks-view>
          }
        }
      </main>

      <!-- Signature Demos Modal -->
      <app-signature-demos-modal></app-signature-demos-modal>
    </div>
  `
})
export class App {
  dt = inject(DigitalTwinService);
}
