// GLASSWORKS.OS — Tin Bath Digital Twin Engine (Molten Tin & Glass Ribbon Formation)

export interface TopRoller {
  id: string;
  positionMetersFromEntry: number;
  side: 'LEFT' | 'RIGHT';
  angleDegrees: number;        // Top roll knurl drive angle (-30° to +30°)
  penetrationDepthMm: number;  // Depth into glass ribbon edge (0 to 15mm)
  rotationSpeedRpm: number;
  temperatureC: number;
  wearPercent: number;
  status: 'ACTIVE' | 'RETRACTED' | 'WARNING';
}

export interface TinBathState {
  lengthMeters: number;       // e.g. 58 meters
  widthMeters: number;        // e.g. 8.5 meters
  tinDepthMm: number;         // e.g. 70 mm of liquid tin
  tinInventoryTonnes: number; // e.g. 210 tonnes of pure tin
  
  // Ribbon dimensions & kinematics
  glassRibbonWidthMeters: number;    // e.g. 3.85 meters
  targetThicknessMm: number;         // e.g. 4.00 mm
  actualCenterThicknessMm: number;   // e.g. 4.01 mm
  actualLeftEdgeThicknessMm: number; // e.g. 4.02 mm
  actualRightEdgeThicknessMm: number;// e.g. 4.00 mm
  drawSpeedMetersPerMin: number;     // e.g. 11.2 m/min
  ribbonTensionNewton: number;       // e.g. 1420 N
  
  // Atmosphere & Chemistry
  atmosphereH2Percent: number; // e.g. 5.0% H2 (reducing gas to prevent SnO dross)
  atmosphereN2Percent: number; // e.g. 95.0% N2
  atmospherePressureMbar: number; // +3.5 mbar overpressure
  tinOxideDrossPpm: number;     // Dross contamination metric
  
  // Longitudinal Temperature Zones (°C)
  // Entry: ~1100°C (molten liquid glass) -> Exit: ~600°C (rigid sheet ready for lift-off)
  longitudinalTempProfileC: number[]; // 20 probe points along 58m
  
  topRollers: TopRoller[];
  drossBoxTempC: number;
  liftOffRollerSpeedMpm: number;
}

export function createInitialTinBathState(): TinBathState {
  // Longitudinal temperature decay from 1090°C down to 602°C across 20 sensor points
  const tempProfile: number[] = [
    1090, 1075, 1050, 1020, 980, 940, 900, 860, 820, 780,
    740, 710, 685, 665, 645, 630, 620, 612, 606, 602
  ];

  // 12 Top Rollers (6 pairs along the stretch/thinning zone)
  const topRollers: TopRoller[] = [];
  const rollerPositions = [8, 12, 16, 20, 24, 28]; // meters from canal entry
  rollerPositions.forEach((pos, idx) => {
    topRollers.push({
      id: `TR_L${idx + 1}`,
      positionMetersFromEntry: pos,
      side: 'LEFT',
      angleDegrees: 8.5 - idx * 0.5,
      penetrationDepthMm: 12.0 - idx * 1.0,
      rotationSpeedRpm: 14.5 + idx * 0.2,
      temperatureC: 890 - idx * 45,
      wearPercent: 12 + idx * 3,
      status: 'ACTIVE'
    });
    topRollers.push({
      id: `TR_R${idx + 1}`,
      positionMetersFromEntry: pos,
      side: 'RIGHT',
      angleDegrees: -(8.5 - idx * 0.5),
      penetrationDepthMm: 12.0 - idx * 1.0,
      rotationSpeedRpm: 14.5 + idx * 0.2,
      temperatureC: 890 - idx * 45,
      wearPercent: 11 + idx * 3,
      status: 'ACTIVE'
    });
  });

  return {
    lengthMeters: 58,
    widthMeters: 8.5,
    tinDepthMm: 70,
    tinInventoryTonnes: 210,
    glassRibbonWidthMeters: 3.85,
    targetThicknessMm: 4.00,
    actualCenterThicknessMm: 4.01,
    actualLeftEdgeThicknessMm: 4.02,
    actualRightEdgeThicknessMm: 4.00,
    drawSpeedMetersPerMin: 11.2,
    ribbonTensionNewton: 1420,
    atmosphereH2Percent: 5.0,
    atmosphereN2Percent: 95.0,
    atmospherePressureMbar: 3.5,
    tinOxideDrossPpm: 18,
    longitudinalTempProfileC: tempProfile,
    topRollers,
    drossBoxTempC: 595,
    liftOffRollerSpeedMpm: 11.22
  };
}
