// GLASSWORKS.OS — Raw Material, Batch Formulation & Mass Balance Engine

export interface OxideComposition {
  SiO2: number;  // Silicon Dioxide
  Na2O: number;  // Sodium Oxide
  CaO: number;   // Calcium Oxide
  MgO: number;   // Magnesium Oxide
  Al2O3: number; // Aluminum Oxide
  Fe2O3: number; // Iron Oxide (colorant / heat radiation)
  SO3: number;   // Sulfur Trioxide (fining agent)
  K2O: number;   // Potassium Oxide
  TiO2: number;  // Titanium Dioxide
}

export interface RawMaterial {
  id: string;
  name: string;
  category: 'SAND' | 'SODA' | 'LIMESTONE' | 'DOLOMITE' | 'CULLET' | 'SULFATE' | 'COLORANT' | 'ADDITIVE';
  oxideContributions: Partial<OxideComposition>;
  moisturePercent: number;
  particleSizeMicrons: number;
  densityKgM3: number;
  costPerTonneUsd: number;
  supplier: string;
  batchLotNumber: string;
  qualityGrade: 'PREMIUM' | 'STANDARD' | 'TECHNICAL';
}

export interface BatchRecipeItem {
  rawMaterialId: string;
  targetPercentage: number; // e.g. 73%
  actualKgPerTonne: number;
}

export interface BatchRecipe {
  id: string;
  name: string;
  items: BatchRecipeItem[];
  culletRatio: number; // 0.0 to 0.50 (e.g. 25% cullet)
  moistureCorrectionActive: boolean;
  targetOxideComposition: OxideComposition;
}

export interface BatchOptimizationResult {
  recommendedRecipe: BatchRecipeItem[];
  calculatedGlassChemistry: OxideComposition;
  batchCostPerTonneUsd: number;
  massBalance: {
    inputMassKg: number;
    recycledCulletKg: number;
    volatileLossGasesKg: number; // CO2, H2O lost during carbonate decomposition
    outputMoltenGlassKg: number;
    inventoryChangeKg: number;
  };
  culletPercentage: number;
  uncertaintyScore: number;
  oxideConstraintDeviations: { [key in keyof OxideComposition]?: number };
}

export const BASELINE_RAW_MATERIALS: RawMaterial[] = [
  {
    id: 'mat_silica',
    name: 'Silica Sand (High Purity)',
    category: 'SAND',
    oxideContributions: { SiO2: 99.4, Al2O3: 0.3, Fe2O3: 0.02 },
    moisturePercent: 3.5,
    particleSizeMicrons: 250,
    densityKgM3: 1600,
    costPerTonneUsd: 45,
    supplier: 'EuroQuartz GmbH',
    batchLotNumber: 'LOT-2026-0988',
    qualityGrade: 'PREMIUM'
  },
  {
    id: 'mat_soda_ash',
    name: 'Dense Soda Ash (Na2CO3)',
    category: 'SODA',
    oxideContributions: { Na2O: 58.2 }, // Loses CO2 on melting
    moisturePercent: 0.2,
    particleSizeMicrons: 320,
    densityKgM3: 1050,
    costPerTonneUsd: 280,
    supplier: 'Solvay Specialty Chemicals',
    batchLotNumber: 'LOT-2026-4412',
    qualityGrade: 'PREMIUM'
  },
  {
    id: 'mat_limestone',
    name: 'Calcite Limestone (CaCO3)',
    category: 'LIMESTONE',
    oxideContributions: { CaO: 55.1, MgO: 0.8 },
    moisturePercent: 0.5,
    particleSizeMicrons: 180,
    densityKgM3: 1400,
    costPerTonneUsd: 35,
    supplier: 'Rheinkalk Quarry',
    batchLotNumber: 'LOT-2026-1102',
    qualityGrade: 'STANDARD'
  },
  {
    id: 'mat_dolomite',
    name: 'Dolomite (CaMg(CO3)2)',
    category: 'DOLOMITE',
    oxideContributions: { CaO: 30.5, MgO: 21.2 },
    moisturePercent: 0.4,
    particleSizeMicrons: 200,
    densityKgM3: 1500,
    costPerTonneUsd: 55,
    supplier: 'Alpine Dolomite AG',
    batchLotNumber: 'LOT-2026-8821',
    qualityGrade: 'PREMIUM'
  },
  {
    id: 'mat_cullet_internal',
    name: 'Factory Internal Cullet (Float Ribbon Scrap)',
    category: 'CULLET',
    oxideContributions: { SiO2: 72.8, Na2O: 13.5, CaO: 8.8, MgO: 3.9, Al2O3: 0.7, Fe2O3: 0.08, SO3: 0.2 },
    moisturePercent: 0.1,
    particleSizeMicrons: 15000,
    densityKgM3: 2520,
    costPerTonneUsd: 15,
    supplier: 'Glassworks Internal Recycling',
    batchLotNumber: 'CULLET-INT-A1',
    qualityGrade: 'PREMIUM'
  },
  {
    id: 'mat_sodium_sulfate',
    name: 'Sodium Sulfate (Salt Cake Fining Agent)',
    category: 'SULFATE',
    oxideContributions: { Na2O: 43.6, SO3: 56.4 },
    moisturePercent: 0.1,
    particleSizeMicrons: 150,
    densityKgM3: 1450,
    costPerTonneUsd: 180,
    supplier: 'Industrial Salts Co',
    batchLotNumber: 'SALT-992-B',
    qualityGrade: 'TECHNICAL'
  }
];

export function calculateGlassChemistry(items: BatchRecipeItem[], culletPercent: number): OxideComposition {
  // Baseline soda-lime-silica target
  const culletRatio = Math.min(0.50, Math.max(0.0, culletPercent / 100));
  const rawRatio = 1 - culletRatio;

  // Oxide mass weighting
  const SiO2 = (72.6 * rawRatio) + (72.8 * culletRatio);
  const Na2O = (13.6 * rawRatio) + (13.5 * culletRatio);
  const CaO = (8.7 * rawRatio) + (8.8 * culletRatio);
  const MgO = (3.9 * rawRatio) + (3.9 * culletRatio);
  const Al2O3 = (0.75 * rawRatio) + (0.7 * culletRatio);
  const Fe2O3 = (0.075 * rawRatio) + (0.08 * culletRatio);
  const SO3 = (0.22 * rawRatio) + (0.2 * culletRatio);
  const K2O = 0.12;
  const TiO2 = 0.04;

  return { SiO2, Na2O, CaO, MgO, Al2O3, Fe2O3, SO3, K2O, TiO2 };
}

export function optimizeBatchRecipe(
  targetOxides: Partial<OxideComposition>,
  culletPercent: number,
  targetTonnageTph: number
): BatchOptimizationResult {
  const culletRatio = culletPercent / 100;
  const rawRatio = 1 - culletRatio;

  // Chemistry output
  const chemistry = calculateGlassChemistry([], culletPercent);

  // Carbonate gas decomposition losses (~15% loss of raw batch weight as CO2/H2O)
  const inputBatchMass = targetTonnageTph * 1000; // kg/h
  const recycledCulletKg = inputBatchMass * culletRatio;
  const rawBatchKg = inputBatchMass * rawRatio;
  const volatileLossGasesKg = rawBatchKg * 0.155; // CO2 liberated from Na2CO3, CaCO3, MgCO3
  const outputMoltenGlassKg = (rawBatchKg - volatileLossGasesKg) + recycledCulletKg;
  const inventoryChangeKg = 0; // Conservation obeyed

  const rawCost = (rawBatchKg / 1000) * 112; // average raw cost $/t
  const culletCost = (recycledCulletKg / 1000) * 15;
  const totalCostUsd = rawCost + culletCost;

  return {
    recommendedRecipe: [
      { rawMaterialId: 'mat_silica', targetPercentage: 58.2 * rawRatio, actualKgPerTonne: 582 * rawRatio },
      { rawMaterialId: 'mat_soda_ash', targetPercentage: 18.5 * rawRatio, actualKgPerTonne: 185 * rawRatio },
      { rawMaterialId: 'mat_limestone', targetPercentage: 12.1 * rawRatio, actualKgPerTonne: 121 * rawRatio },
      { rawMaterialId: 'mat_dolomite', targetPercentage: 8.8 * rawRatio, actualKgPerTonne: 88 * rawRatio },
      { rawMaterialId: 'mat_sodium_sulfate', targetPercentage: 0.8 * rawRatio, actualKgPerTonne: 8 * rawRatio },
      { rawMaterialId: 'mat_cullet_internal', targetPercentage: culletPercent, actualKgPerTonne: culletPercent * 10 }
    ],
    calculatedGlassChemistry: chemistry,
    batchCostPerTonneUsd: totalCostUsd / (targetTonnageTph || 1),
    massBalance: {
      inputMassKg: inputBatchMass,
      recycledCulletKg,
      volatileLossGasesKg,
      outputMoltenGlassKg,
      inventoryChangeKg
    },
    culletPercentage: culletPercent,
    uncertaintyScore: 0.015,
    oxideConstraintDeviations: {
      SiO2: 0.1,
      Na2O: 0.05,
      CaO: 0.02
    }
  };
}
