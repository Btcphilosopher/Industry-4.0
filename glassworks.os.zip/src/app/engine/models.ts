// GLASSWORKS.OS — Equipment Object Models & Plant Graph

export type EquipmentType = 
  | 'Silo' 
  | 'BatchMixer' 
  | 'Furnace' 
  | 'Burner' 
  | 'Regenerator' 
  | 'TinBath' 
  | 'Roller' 
  | 'LehrZone' 
  | 'InspectionMachine' 
  | 'Cutter' 
  | 'Stacker' 
  | 'Warehouse';

export type HealthStatus = 'EXCELLENT' | 'GOOD' | 'DEGRADED' | 'WARNING' | 'CRITICAL';
export type MaintenanceState = 'OPERATIONAL' | 'INSPECTION_DUE' | 'SERVICED_RECENTLY' | 'NEEDS_REPAIR' | 'FAILED';

export interface SensorDataPoint {
  id: string;
  name: string;
  value: number;
  unit: string;
  uncertainty: number; // e.g. ±7°C
  quality: 'GOOD' | 'UNCERTAIN' | 'BAD';
  provenance: 'MEASURED' | 'ESTIMATED' | 'CALCULATED' | 'SIMULATED' | 'PREDICTED';
  timestamp: string;
}

export interface Alarm {
  id: string;
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
  message: string;
  timestamp: string;
  acknowledged: boolean;
}

export interface Equipment {
  id: string;
  name: string;
  type: EquipmentType;
  manufacturer: string;
  model: string;
  location: string;
  status: 'ONLINE' | 'OFFLINE' | 'STANDBY' | 'MAINTENANCE';
  health: number; // 0 - 100%
  healthStatus: HealthStatus;
  temperature: number; // °C
  energyConsumptionKw: number; // kW
  maintenanceState: MaintenanceState;
  sensors: SensorDataPoint[];
  alarms: Alarm[];
}

export interface ProcessFlowConnection {
  sourceId: string;
  targetId: string;
  flowRateTph: number; // tonnes / hour
  temperatureC: number; // °C
  pressureBar: number; // bar
  massFlowKgS: number;
  energyFlowKw: number;
  qualityIndex: number; // 0 - 100
  compositionSummary: string;
}

export interface PlantGraphNode {
  id: string;
  equipment: Equipment;
  inputs: string[]; // equipment IDs
  outputs: string[]; // equipment IDs
}

export interface PlantGraph {
  nodes: Map<string, PlantGraphNode>;
  connections: ProcessFlowConnection[];
}
