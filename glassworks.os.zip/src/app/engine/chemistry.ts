// GLASSWORKS.OS — Glass Chemistry & Physical Property Model

import { OxideComposition } from './materials';

export interface GlassPhysicalProperties {
  densityKgM3: number; // e.g. 2500 - 2530 kg/m3 at 20°C
  
  // Vogel-Fulcher-Tammann (VFT) viscosity constants: log10(eta) = A + B / (T - T0)
  vftA: number;
  vftB: number;
  vftT0: number; // °C
  
  // Characteristic temperatures (°C)
  meltingTemperatureC: number;      // log10(eta) = 2.0 (~1480°C - 1520°C)
  workingTemperatureC: number;      // log10(eta) = 4.0 (~1000°C - 1040°C)
  softeningPointC: number;          // log10(eta) = 7.6 (~720°C - 740°C)
  annealingPointC: number;          // log10(eta) = 13.0 (~540°C - 550°C)
  strainPointC: number;             // log10(eta) = 14.5 (~500°C - 510°C)
  
  thermalExpansionAlpha: number;   // 10^-7 / K (e.g. 85 - 90)
  liquidusTemperatureC: number;    // Devitrification limit (~1000°C - 1020°C)
  
  opticalTransmittancePercent: number; // Visible light transmittance (e.g. 89.5%)
  ironFe2Fe3Ratio: number;          // Redox ratio (Fe2+ / total Fe) - affects solar heat gain & green tint
  finingGasReleaseTempC: number;    // SO3 dissociation peak (~1420°C)
}

export function calculateViscosityPaS(tempC: number, props: GlassPhysicalProperties): number {
  // log10(eta in dPa.s) = A + B / (tempC - T0)
  // 1 Pa.s = 10 dPa.s
  const logEtaDpas = props.vftA + props.vftB / Math.max(1, tempC - props.vftT0);
  const etaDpas = Math.pow(10, logEtaDpas);
  return etaDpas / 10; // convert dPa.s to Pa.s
}

export function calculateGlassProperties(comp: OxideComposition): GlassPhysicalProperties {
  // Lakatos / Appen oxide addition empirical factors for soda-lime float glass
  const SiO2 = comp.SiO2;
  const Na2O = comp.Na2O;
  const CaO = comp.CaO;
  const MgO = comp.MgO;
  const Al2O3 = comp.Al2O3;
  const Fe2O3 = comp.Fe2O3;

  // Density at room temp
  const densityKgM3 = 2500 + (CaO * 4.2) + (MgO * 2.8) + (Na2O * 2.1) + (Al2O3 * 1.5) - (SiO2 * 0.5);

  // VFT constants for standard float glass
  const vftA = -2.58 + (Al2O3 * 0.02);
  const vftB = 4220 + (SiO2 * 12) - (Na2O * 25) + (Al2O3 * 35);
  const vftT0 = 265 - (Na2O * 3.5) + (CaO * 2.1);

  // Characteristic Points derived from VFT inversion
  // log10(eta_dPas) = A + B / (T - T0)  =>  T = T0 + B / (logEta - A)
  const calcT = (logEta: number) => vftT0 + vftB / (logEta - vftA);

  const meltingTemperatureC = Math.round(calcT(2.0));      // log10(eta) = 2
  const workingTemperatureC = Math.round(calcT(4.0));      // log10(eta) = 4
  const softeningPointC = Math.round(calcT(7.65));         // Littleton softening point
  const annealingPointC = Math.round(calcT(13.0));         // Annealing point
  const strainPointC = Math.round(calcT(14.5));            // Strain point

  const thermalExpansionAlpha = 88.5 + (Na2O * 1.2) + (CaO * 0.5) - (SiO2 * 0.1);
  const liquidusTemperatureC = 1005 + (SiO2 * 0.8) - (Na2O * 4.0) + (Al2O3 * 3.0);

  // Fe2O3 impact on optical transmission
  const ironContent = Fe2O3;
  const opticalTransmittancePercent = Math.max(75, 91.2 - (ironContent * 22.0));
  const ironFe2Fe3Ratio = 0.28; // Standard oxidising furnace atmosphere
  const finingGasReleaseTempC = 1425;

  return {
    densityKgM3,
    vftA,
    vftB,
    vftT0,
    meltingTemperatureC,
    workingTemperatureC,
    softeningPointC,
    annealingPointC,
    strainPointC,
    thermalExpansionAlpha,
    liquidusTemperatureC,
    opticalTransmittancePercent,
    ironFe2Fe3Ratio,
    finingGasReleaseTempC
  };
}
