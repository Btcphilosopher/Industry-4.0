// GLASSWORKS.OS — CUTTING.OS Yield, Stacker & Digital Warehouse Engine

export interface GlassSheetProduct {
  id: string;
  orderId: string;
  customerName: string;
  widthMeters: number;    // e.g. 3.21 m (Jumbo DLF format)
  lengthMeters: number;   // e.g. 6.00 m
  thicknessMm: number;    // e.g. 4.00 mm
  glassType: 'CLEAR_FLOAT' | 'ULTRA_CLEAR_LOW_IRON' | 'TINTED_GREEN' | 'COATED_LOW_E';
  qualityGrade: 'PRIME_A' | 'STANDARD_B' | 'REJECT';
  producedTimestamp: string;
  warehouseLocationSlot: string; // e.g. "BAY-04-RACK-12"
  weightKg: number;
}

export interface ProductionOrder {
  id: string;
  customerName: string;
  productName: string;
  thicknessMm: number;
  widthMeters: number;
  lengthMeters: number;
  quantityOrderedSheets: number;
  quantityProducedSheets: number;
  qualityGradeRequired: 'PRIME_A' | 'STANDARD_B';
  deadline: string;
  status: 'SCHEDULED' | 'IN_PRODUCTION' | 'COMPLETED';
}

export interface YieldBreakdown {
  grossRibbonTonnes: number;
  netUsableGlassTonnes: number;
  edgeTrimScrapTonnes: number;
  snapDefectBreakageTonnes: number;
  qualityRejectCulletTonnes: number;
  grossYieldPercent: number; // e.g. 96.8%
  netPrimeYieldPercent: number; // e.g. 94.2%
}

export function createInitialWarehouseState() {
  const activeOrders: ProductionOrder[] = [
    {
      id: 'ORD-2026-701',
      customerName: 'Saint-Gobain Glass Solutions',
      productName: 'Clear Float 4mm Jumbo DLF',
      thicknessMm: 4.0,
      widthMeters: 3.21,
      lengthMeters: 6.00,
      quantityOrderedSheets: 1200,
      quantityProducedSheets: 840,
      qualityGradeRequired: 'PRIME_A',
      deadline: '2026-10-01',
      status: 'IN_PRODUCTION'
    },
    {
      id: 'ORD-2026-702',
      customerName: 'AGC Architectural Glass',
      productName: 'Ultra-Clear Low-Iron 6mm',
      thicknessMm: 6.0,
      widthMeters: 3.21,
      lengthMeters: 5.00,
      quantityOrderedSheets: 500,
      quantityProducedSheets: 0,
      qualityGradeRequired: 'PRIME_A',
      deadline: '2026-10-05',
      status: 'SCHEDULED'
    }
  ];

  const warehouseInventory: GlassSheetProduct[] = [
    {
      id: 'SH-88219-01',
      orderId: 'ORD-2026-701',
      customerName: 'Saint-Gobain Glass Solutions',
      widthMeters: 3.21,
      lengthMeters: 6.00,
      thicknessMm: 4.00,
      glassType: 'CLEAR_FLOAT',
      qualityGrade: 'PRIME_A',
      producedTimestamp: new Date().toISOString(),
      warehouseLocationSlot: 'BAY-01-RACK-04',
      weightKg: 192.6
    },
    {
      id: 'SH-88219-02',
      orderId: 'ORD-2026-701',
      customerName: 'Saint-Gobain Glass Solutions',
      widthMeters: 3.21,
      lengthMeters: 6.00,
      thicknessMm: 4.00,
      glassType: 'CLEAR_FLOAT',
      qualityGrade: 'PRIME_A',
      producedTimestamp: new Date().toISOString(),
      warehouseLocationSlot: 'BAY-01-RACK-05',
      weightKg: 192.6
    }
  ];

  const yieldData: YieldBreakdown = {
    grossRibbonTonnes: 840,
    netUsableGlassTonnes: 813.1,
    edgeTrimScrapTonnes: 18.5,
    snapDefectBreakageTonnes: 3.2,
    qualityRejectCulletTonnes: 5.2,
    grossYieldPercent: 96.8,
    netPrimeYieldPercent: 94.2
  };

  return {
    activeOrders,
    warehouseInventory,
    yieldData
  };
}
