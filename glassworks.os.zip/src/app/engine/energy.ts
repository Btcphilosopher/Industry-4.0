// GLASSWORKS.OS — Energy & Emissions Model (Thermodynamics, Power & Cullet Sensitivity)

export interface EnergyMetrics {
  thermalEnergyMwhPerDay: number; // e.g. 82.4 MWh
  electricalEnergyMwhPerDay: number; // e.g. 11.8 MWh
  totalEnergyMwhPerDay: number;      // e.g. 94.2 MWh
  
  energyPerTonneMwh: number; // e.g. 0.112 MWh/tonne (4.03 GJ/tonne)
  targetEnergyPerTonneMwh: number; // e.g. 0.110 MWh/tonne
  
  energyCostPerTonneUsd: number; // e.g. $14.20 / tonne
  
  // Power Breakdown (kW)
  furnaceNaturalGasPowerKw: number;
  furnaceElectricBoostPowerKw: number;
  tinBathHeatersPowerKw: number;
  lehrHeatersAndBlowersPowerKw: number;
  auxiliaryMotorsCompressorsPowerKw: number;
}

export interface EmissionsMetrics {
  co2EmissionsTonnesPerDay: number; // e.g. 188.4 t CO2 / day
  noxEmissionsKgPerDay: number;      // e.g. 420 kg NOx / day
  soxEmissionsKgPerDay: number;      // e.g. 115 kg SOx / day
  coEmissionsKgPerDay: number;       // e.g. 32 kg CO / day
  particulatesKgPerDay: number;      // e.g. 18 kg particulates / day
  
  co2PerTonneGlassKg: number;        // e.g. 224 kg CO2 / t glass
  
  // Cullet Impact Sensitivity Model
  // Every 10% increase in cullet reduces energy demand by ~2.5-3.0% and CO2 emissions by ~5%
  culletPercentCurrent: number;
  co2SavedByCulletTonnesPerDay: number;
  energySavedByCulletMwhPerDay: number;
}

export function calculateEnergyAndEmissions(
  pullRateTph: number,
  culletPercent: number,
  fuelMode: string
): { energy: EnergyMetrics; emissions: EmissionsMetrics } {
  const pullRateTpd = pullRateTph * 24; // tonnes / day
  const culletFactor = 1 - (culletPercent - 20) * 0.003; // baseline 20% cullet

  // Energy
  const baseThermalMwh = pullRateTpd * 0.098 * culletFactor;
  const baseElectricMwh = pullRateTpd * 0.014;
  const totalMwh = baseThermalMwh + baseElectricMwh;
  const energyPerTonne = totalMwh / (pullRateTpd || 1);

  // Power breakdown kW
  const thermalKw = (baseThermalMwh * 1000) / 24;
  const electricKw = (baseElectricMwh * 1000) / 24;

  // Fuel mode emission multiplier
  const isOxyFuel = fuelMode === 'OXY_FUEL';
  const isHydrogen = fuelMode === 'HYDROGEN_EXPERIMENTAL';
  const noxMult = isOxyFuel ? 0.35 : isHydrogen ? 0.15 : 1.0;
  const co2FuelMult = isHydrogen ? 0.10 : 1.0;

  // CO2 calculation (Combustion CO2 + Carbonate Process De-gas CO2)
  const carbonateCo2Tpd = pullRateTpd * (1 - culletPercent / 100) * 0.155;
  const fuelCo2Tpd = baseThermalMwh * 0.202 * co2FuelMult; // ~0.202 t CO2 / MWh natural gas
  const totalCo2Tpd = carbonateCo2Tpd + fuelCo2Tpd;

  const co2SavedByCullet = (pullRateTpd * (culletPercent / 100) * 0.155) + (pullRateTpd * 0.003 * culletPercent * 0.202);

  return {
    energy: {
      thermalEnergyMwhPerDay: Number(baseThermalMwh.toFixed(1)),
      electricalEnergyMwhPerDay: Number(baseElectricMwh.toFixed(1)),
      totalEnergyMwhPerDay: Number(totalMwh.toFixed(1)),
      energyPerTonneMwh: Number(energyPerTonne.toFixed(3)),
      targetEnergyPerTonneMwh: 0.110,
      energyCostPerTonneUsd: Number((energyPerTonne * 125).toFixed(2)),
      furnaceNaturalGasPowerKw: Math.round(thermalKw * 0.88),
      furnaceElectricBoostPowerKw: Math.round(electricKw * 0.45),
      tinBathHeatersPowerKw: Math.round(electricKw * 0.25),
      lehrHeatersAndBlowersPowerKw: Math.round(electricKw * 0.20),
      auxiliaryMotorsCompressorsPowerKw: Math.round(electricKw * 0.10)
    },
    emissions: {
      co2EmissionsTonnesPerDay: Number(totalCo2Tpd.toFixed(1)),
      noxEmissionsKgPerDay: Math.round(420 * noxMult),
      soxEmissionsKgPerDay: Math.round(115 * (1 - culletPercent * 0.005)),
      coEmissionsKgPerDay: 32,
      particulatesKgPerDay: 18,
      co2PerTonneGlassKg: Math.round((totalCo2Tpd * 1000) / (pullRateTpd || 1)),
      culletPercentCurrent: culletPercent,
      co2SavedByCulletTonnesPerDay: Number(co2SavedByCullet.toFixed(1)),
      energySavedByCulletMwhPerDay: Number((pullRateTpd * 0.003 * culletPercent).toFixed(1))
    }
  };
}
