// GLASSWORKS.OS — LEHR.OS Annealing Lehr & Residual Thermal Stress Twin

export type StressLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export interface LehrZoneState {
  zoneNumber: number; // 1 to 16
  name: string;       // e.g. "Zone 01 - Initial Annealing"
  lengthMeters: number;
  setpointTempC: number;
  actualTempC: number;
  coolingRateCDegPerMin: number;
  electricHeaterOutputPercent: number;
  coolingBlowerSpeedPercent: number;
  upperAirTempC: number;
  lowerAirTempC: number;
  status: 'STABLE' | 'HEATING' | 'COOLING' | 'DEVIATION_ALERT';
}

export interface LehrState {
  totalLengthMeters: number; // e.g. 120 meters
  ribbonSpeedMpm: number;    // e.g. 11.22 m/min
  lehrEntryTempC: number;    // e.g. 595°C
  lehrExitTempC: number;     // e.g. 65°C
  
  zones: LehrZoneState[];
  
  // Internal Stress & Mechanical Geometry
  residualStressMpa: number; // e.g. 1.8 MPa (Target < 2.5 MPa)
  residualStressLevel: StressLevel;
  flatnessDeviationMmM: number; // e.g. 0.12 mm / m bow
  warpMm: number;               // 0.08 mm
  edgeKnurlStressMpa: number;   // 3.1 MPa
  
  // Cooling Curve Points (16 zones)
  actualCoolingCurveC: number[];
  idealCoolingCurveC: number[];
}

export function createInitialLehrState(): LehrState {
  // Ideal vs Actual Annealing Profile (°C) across 16 zones
  // Entry at ~595°C, controlled dwell near annealing point (~545°C), slow cooling through strain point (~505°C), rapid air cooling to ~65°C
  const setpoints = [
    590, 565, 545, 540, 525, 505, 480, 440,
    390, 330, 260, 200, 150, 110, 80, 65
  ];
  const actuals = [
    591, 564, 546, 539, 526, 504, 481, 438,
    392, 328, 261, 198, 151, 109, 81, 65
  ];

  const zones: LehrZoneState[] = setpoints.map((sp, idx) => {
    const num = idx + 1;
    const isAnnealingSection = num <= 6;
    const isCoolingSection = num > 6 && num <= 12;
    return {
      zoneNumber: num,
      name: `Zone ${num < 10 ? '0' + num : num} — ${isAnnealingSection ? 'Annealing' : isCoolingSection ? 'Indirect Cooling' : 'Direct Cooling'}`,
      lengthMeters: 7.5,
      setpointTempC: sp,
      actualTempC: actuals[idx],
      coolingRateCDegPerMin: num <= 4 ? 4.5 : num <= 8 ? 12.0 : 22.0,
      electricHeaterOutputPercent: Math.max(0, Math.round(75 - num * 4.5)),
      coolingBlowerSpeedPercent: Math.min(100, Math.round(15 + num * 5.2)),
      upperAirTempC: actuals[idx] + 2,
      lowerAirTempC: actuals[idx] - 2,
      status: Math.abs(sp - actuals[idx]) > 5 ? 'DEVIATION_ALERT' : 'STABLE'
    };
  });

  return {
    totalLengthMeters: 120,
    ribbonSpeedMpm: 11.22,
    lehrEntryTempC: 595,
    lehrExitTempC: 65,
    zones,
    residualStressMpa: 1.85,
    residualStressLevel: 'LOW',
    flatnessDeviationMmM: 0.12,
    warpMm: 0.08,
    edgeKnurlStressMpa: 3.1,
    actualCoolingCurveC: actuals,
    idealCoolingCurveC: setpoints
  };
}
