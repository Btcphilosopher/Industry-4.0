// GLASSWORKS.OS — Digital Commissioning & Process Bottleneck Analyzer

export interface BottleneckStage {
  stageId: string;
  stageName: string;
  designCapacityTonnesDay: number;
  currentOperatingTonnesDay: number;
  capacityUtilizationPercent: number; // e.g. 82%
  isBottleneck: boolean;
  limitingFactor: string;
}

export function analyzePlantBottlenecks(currentPullRateTpd: number): BottleneckStage[] {
  const stages = [
    {
      stageId: 'batch_house',
      stageName: 'Batch House & Silos',
      designCapacityTonnesDay: 1200,
      limitingFactor: 'Raw material weigh hopper cycle time'
    },
    {
      stageId: 'furnace_melting',
      stageName: 'Melting Furnace',
      designCapacityTonnesDay: 980,
      limitingFactor: 'Specific melting rate area (2.2 t/m²/day thermal refractory limit)'
    },
    {
      stageId: 'tin_bath',
      stageName: 'Tin Bath Float Line',
      designCapacityTonnesDay: 890,
      limitingFactor: 'Max top-roll drive ribbon stretch velocity (14.2 m/min limit)'
    },
    {
      stageId: 'annealing_lehr',
      stageName: 'Annealing Lehr',
      designCapacityTonnesDay: 1100,
      limitingFactor: 'Max cooling blower heat dissipation rate in Zone 8'
    },
    {
      stageId: 'cutting_line',
      stageName: 'Cross-Cut & Edge Trim',
      designCapacityTonnesDay: 1250,
      limitingFactor: 'Carbide scoring wheel traversal speed limit'
    },
    {
      stageId: 'warehouse_stacker',
      stageName: 'Robotic Stacker & Warehouse',
      designCapacityTonnesDay: 1400,
      limitingFactor: 'Vacuum cup crane cycle time'
    }
  ];

  // Highest utilization stage is the bottleneck
  let maxUtil = 0;
  let bottleneckId = '';

  const results: BottleneckStage[] = stages.map(s => {
    const util = Math.min(100, Math.round((currentPullRateTpd / s.designCapacityTonnesDay) * 100));
    if (util > maxUtil) {
      maxUtil = util;
      bottleneckId = s.stageId;
    }
    return {
      stageId: s.stageId,
      stageName: s.stageName,
      designCapacityTonnesDay: s.designCapacityTonnesDay,
      currentOperatingTonnesDay: currentPullRateTpd,
      capacityUtilizationPercent: util,
      isBottleneck: false,
      limitingFactor: s.limitingFactor
    };
  });

  return results.map(r => ({
    ...r,
    isBottleneck: r.stageId === bottleneckId
  }));
}
