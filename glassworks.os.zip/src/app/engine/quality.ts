// GLASSWORKS.OS — QUALITY.OS Line-Scan Inspection & Defect Traceability Engine

export type DefectType = 
  | 'BUBBLE_SEED' 
  | 'STONE_INCLUSION' 
  | 'TIN_DROPLET' 
  | 'SURFACE_SCRATCH' 
  | 'OPTICAL_DISTORTION' 
  | 'THICKNESS_THIN' 
  | 'THICKNESS_THICK' 
  | 'EDGE_CHIP' 
  | 'REFRAC_DRIP';

export interface DefectItem {
  id: string;
  type: DefectType;
  xPositionMeters: number; // Across ribbon width (0 to 3.85m)
  yPositionMeters: number; // Along length sequence
  sizeMm: number;          // Defect size (0.1mm to 5mm)
  severity: 'MINOR' | 'MODERATE' | 'MAJOR' | 'CRITICAL';
  cameraConfidence: number; // 0.0 to 1.0 (e.g. 0.98)
  timestamp: string;
  sheetId: string;
  
  // Provenance / Backwards Traceability
  provenance: {
    ribbonDistanceMeters: number;
    detectionTime: string;
    probableOriginStage: 'FURNACE_MELTING' | 'REFINING_FINING' | 'TIN_BATH' | 'LEHR_ANNEALING' | 'CUTTING';
    suspectedCause: string;
    processConditionsAtTime: {
      furnaceMeltingTempC: number;
      furnaceCulletPercent: number;
      tinBathTempC: number;
      lehrZone4TempC: number;
      batchLotNumber: string;
    };
  };
}

export interface QualityMetrics {
  totalSheetsInspectedCount: number;
  primeQualityYieldPercent: number; // e.g. 98.4%
  defectRatePpm: number;           // Parts per million
  opticalClarityIndex: number;     // 0 - 100
  thicknessUniformityPercent: number;
  activeDefects: DefectItem[];
}

export const SAMPLE_DEFECTS: DefectItem[] = [
  {
    id: 'DEF-2026-901',
    type: 'BUBBLE_SEED',
    xPositionMeters: 1.25,
    yPositionMeters: 14.8,
    sizeMm: 0.35,
    severity: 'MINOR',
    cameraConfidence: 0.97,
    timestamp: new Date().toISOString(),
    sheetId: 'SHEET-88219-A',
    provenance: {
      ribbonDistanceMeters: 14.8,
      detectionTime: new Date(Date.now() - 120000).toISOString(),
      probableOriginStage: 'REFINING_FINING',
      suspectedCause: 'Incomplete SO3 fining gas dissociation due to local temperature drop (-8°C in Zone 4).',
      processConditionsAtTime: {
        furnaceMeltingTempC: 1552,
        furnaceCulletPercent: 25.0,
        tinBathTempC: 1045,
        lehrZone4TempC: 540,
        batchLotNumber: 'LOT-2026-0988'
      }
    }
  },
  {
    id: 'DEF-2026-902',
    type: 'TIN_DROPLET',
    xPositionMeters: 3.40,
    yPositionMeters: 38.2,
    sizeMm: 0.85,
    severity: 'MODERATE',
    cameraConfidence: 0.99,
    timestamp: new Date().toISOString(),
    sheetId: 'SHEET-88219-B',
    provenance: {
      ribbonDistanceMeters: 38.2,
      detectionTime: new Date(Date.now() - 360000).toISOString(),
      probableOriginStage: 'TIN_BATH',
      suspectedCause: 'Tin oxide (SnO) condensation drop from roof refractory in Tin Bath Zone 3.',
      processConditionsAtTime: {
        furnaceMeltingTempC: 1558,
        furnaceCulletPercent: 25.0,
        tinBathTempC: 980,
        lehrZone4TempC: 539,
        batchLotNumber: 'LOT-2026-0988'
      }
    }
  },
  {
    id: 'DEF-2026-903',
    type: 'STONE_INCLUSION',
    xPositionMeters: 0.65,
    yPositionMeters: 82.5,
    sizeMm: 1.40,
    severity: 'MAJOR',
    cameraConfidence: 0.96,
    timestamp: new Date().toISOString(),
    sheetId: 'SHEET-88220-A',
    provenance: {
      ribbonDistanceMeters: 82.5,
      detectionTime: new Date(Date.now() - 720000).toISOString(),
      probableOriginStage: 'FURNACE_MELTING',
      suspectedCause: 'Unmelted quartz sand grain or AZS refractory spall in Charging zone.',
      processConditionsAtTime: {
        furnaceMeltingTempC: 1545,
        furnaceCulletPercent: 28.5,
        tinBathTempC: 1020,
        lehrZone4TempC: 542,
        batchLotNumber: 'LOT-2026-1102'
      }
    }
  }
];

export function createInitialQualityMetrics(): QualityMetrics {
  return {
    totalSheetsInspectedCount: 14280,
    primeQualityYieldPercent: 98.4,
    defectRatePpm: 12.4,
    opticalClarityIndex: 99.1,
    thicknessUniformityPercent: 99.6,
    activeDefects: SAMPLE_DEFECTS
  };
}
