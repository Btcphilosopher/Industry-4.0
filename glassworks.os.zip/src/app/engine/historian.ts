// GLASSWORKS.OS — Data Historian, Sensor Uncertainty & Furnace Time Machine Engine

export type DataProvenanceState = 'MEASURED' | 'ESTIMATED' | 'CALCULATED' | 'SIMULATED' | 'PREDICTED';

export interface HistorianTagValue {
  tag: string;
  timestamp: string;
  value: number;
  unit: string;
  uncertainty: number; // e.g. ±7.0°C
  provenance: DataProvenanceState;
  quality: 'GOOD' | 'UNCERTAIN' | 'BAD';
}

export interface PlantSnapshot {
  timestamp: string;
  label: string; // e.g. "NOW", "-1 HOUR", "-24 HOURS", "-7 DAYS", "+24H PREDICTED"
  provenance: DataProvenanceState;
  crownTempC: number;
  meltingTempC: number;
  glassLevelMm: number;
  pullRateTph: number;
  tinBathTempC: number;
  lehrZone4TempC: number;
  primeYieldPercent: number;
  co2TonnesDay: number;
  energyMwhTonne: number;
}

export function generateHistorianSnapshots(): PlantSnapshot[] {
  const now = new Date();
  
  return [
    {
      timestamp: new Date(now.getTime() - 7 * 86400000).toISOString(),
      label: '-7 DAYS',
      provenance: 'MEASURED',
      crownTempC: 1578,
      meltingTempC: 1552,
      glassLevelMm: 0.1,
      pullRateTph: 34.8,
      tinBathTempC: 1088,
      lehrZone4TempC: 541,
      primeYieldPercent: 97.9,
      co2TonnesDay: 191.2,
      energyMwhTonne: 0.114
    },
    {
      timestamp: new Date(now.getTime() - 24 * 3600000).toISOString(),
      label: '-24 HOURS',
      provenance: 'MEASURED',
      crownTempC: 1582,
      meltingTempC: 1556,
      glassLevelMm: -0.1,
      pullRateTph: 35.0,
      tinBathTempC: 1092,
      lehrZone4TempC: 540,
      primeYieldPercent: 98.2,
      co2TonnesDay: 189.5,
      energyMwhTonne: 0.113
    },
    {
      timestamp: new Date(now.getTime() - 6 * 3600000).toISOString(),
      label: '-6 HOURS',
      provenance: 'MEASURED',
      crownTempC: 1585,
      meltingTempC: 1558,
      glassLevelMm: 0.0,
      pullRateTph: 35.0,
      tinBathTempC: 1090,
      lehrZone4TempC: 539,
      primeYieldPercent: 98.4,
      co2TonnesDay: 188.8,
      energyMwhTonne: 0.112
    },
    {
      timestamp: new Date(now.getTime() - 3600000).toISOString(),
      label: '-1 HOUR',
      provenance: 'MEASURED',
      crownTempC: 1584,
      meltingTempC: 1558,
      glassLevelMm: 0.0,
      pullRateTph: 35.0,
      tinBathTempC: 1090,
      lehrZone4TempC: 540,
      primeYieldPercent: 98.4,
      co2TonnesDay: 188.4,
      energyMwhTonne: 0.112
    },
    {
      timestamp: now.toISOString(),
      label: 'NOW',
      provenance: 'ESTIMATED',
      crownTempC: 1585,
      meltingTempC: 1558,
      glassLevelMm: 0.0,
      pullRateTph: 35.0,
      tinBathTempC: 1090,
      lehrZone4TempC: 540,
      primeYieldPercent: 98.4,
      co2TonnesDay: 188.4,
      energyMwhTonne: 0.112
    },
    {
      timestamp: new Date(now.getTime() + 24 * 3600000).toISOString(),
      label: '+24H PREDICTED',
      provenance: 'PREDICTED',
      crownTempC: 1583,
      meltingTempC: 1556,
      glassLevelMm: 0.1,
      pullRateTph: 35.0,
      tinBathTempC: 1089,
      lehrZone4TempC: 540,
      primeYieldPercent: 98.5,
      co2TonnesDay: 187.9,
      energyMwhTonne: 0.111
    }
  ];
}
