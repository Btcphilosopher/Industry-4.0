// GLASSWORKS.OS — Scenario Engine & What-If Digital Experimentation Lab

export interface ScenarioParameters {
  id: string;
  name: string;
  description: string;
  furnaceTargetTempC: number;
  culletPercentage: number;
  fuelMode: 'NATURAL_GAS' | 'OXY_FUEL' | 'HYBRID_OXY_ELEC' | 'ELECTRIC_ASSIST' | 'HYDROGEN_EXPERIMENTAL';
  drawSpeedMpm: number;
  targetThicknessMm: number;
  lehrZone4TempC: number;
  tinBathAtmosphereH2Percent: number;
}

export interface ScenarioDeltaResult {
  scenarioName: string;
  baseline: {
    energyMwhTonne: number;
    co2TonnesDay: number;
    dailyProductionTonnes: number;
    primeYieldPercent: number;
    defectRiskLevel: string;
    dailyCostUsd: number;
  };
  simulated: {
    energyMwhTonne: number;
    co2TonnesDay: number;
    dailyProductionTonnes: number;
    primeYieldPercent: number;
    defectRiskLevel: string;
    dailyCostUsd: number;
  };
  deltas: {
    energyMwhTonneDeltaPercent: number;
    co2TonnesDayDeltaPercent: number;
    productionTonnesDeltaPercent: number;
    primeYieldDeltaPercent: number;
    dailyCostUsdDelta: number;
  };
  simulatedTimestamp: string;
  modelProvenance: 'SIMULATED';
}

export const PREBUILT_SCENARIOS: ScenarioParameters[] = [
  {
    id: 'scen_high_cullet',
    name: '35% Cullet De-carbonization Boost',
    description: 'Increase recycled cullet from 25% to 35% to reduce energy demand, decrease carbonate emissions, and lower raw material batch costs.',
    furnaceTargetTempC: 1550,
    culletPercentage: 35.0,
    fuelMode: 'NATURAL_GAS',
    drawSpeedMpm: 11.2,
    targetThicknessMm: 4.0,
    lehrZone4TempC: 540,
    tinBathAtmosphereH2Percent: 5.0
  },
  {
    id: 'scen_hydrogen_fuel',
    name: 'Experimental Hydrogen / Oxy-Gas Combustion',
    description: 'Replace natural gas with 80% Green Hydrogen blend in furnace ports P1-P4 to eliminate combustion CO2 emissions.',
    furnaceTargetTempC: 1560,
    culletPercentage: 25.0,
    fuelMode: 'HYDROGEN_EXPERIMENTAL',
    drawSpeedMpm: 11.2,
    targetThicknessMm: 4.0,
    lehrZone4TempC: 540,
    tinBathAtmosphereH2Percent: 5.0
  },
  {
    id: 'scen_high_throughput',
    name: '950 Tonnes/Day High Throughput Draw',
    description: 'Increase pull rate from 840 t/d to 950 t/d by increasing furnace temperature +15°C and draw speed to 12.8 m/min.',
    furnaceTargetTempC: 1575,
    culletPercentage: 25.0,
    fuelMode: 'NATURAL_GAS',
    drawSpeedMpm: 12.8,
    targetThicknessMm: 3.5,
    lehrZone4TempC: 545,
    tinBathAtmosphereH2Percent: 5.0
  },
  {
    id: 'scen_lehr_failure',
    name: 'Lehr Zone 7 Cooling Blower Fault',
    description: 'Simulate a complete blower motor trip in Lehr Zone 7 to evaluate internal stress buildup and glass breakage risk.',
    furnaceTargetTempC: 1560,
    culletPercentage: 25.0,
    fuelMode: 'NATURAL_GAS',
    drawSpeedMpm: 11.2,
    targetThicknessMm: 4.0,
    lehrZone4TempC: 585, // Excessive temperature deviation
    tinBathAtmosphereH2Percent: 5.0
  }
];

export function runScenarioSimulation(params: ScenarioParameters): ScenarioDeltaResult {
  // Baseline benchmarks
  const baseEnergy = 0.112;
  const baseCo2 = 188.4;
  const baseProd = 840;
  const baseYield = 98.4;
  const baseCost = 42800;

  // Deliberate physics-based delta calculation
  const culletDelta = params.culletPercentage - 25.0;
  const tempDelta = params.furnaceTargetTempC - 1560;
  const isHydrogen = params.fuelMode === 'HYDROGEN_EXPERIMENTAL';

  // Energy & CO2 changes
  const simEnergy = baseEnergy * (1 - culletDelta * 0.003 + tempDelta * 0.001);
  const simCo2 = baseCo2 * (isHydrogen ? 0.22 : 1 - culletDelta * 0.006);
  const simProd = params.drawSpeedMpm > 12.0 ? 950 : 840;
  
  // Lehr failure or extreme temp impact on yield
  const isLehrFailure = params.lehrZone4TempC > 570;
  const simYield = isLehrFailure ? 84.2 : (baseYield - Math.abs(tempDelta) * 0.05);
  const defectRisk = isLehrFailure ? 'HIGH' : tempDelta > 15 ? 'ELEVATED' : 'LOW';

  const simCost = baseCost * (simEnergy / baseEnergy) * (simYield / baseYield);

  return {
    scenarioName: params.name,
    baseline: {
      energyMwhTonne: baseEnergy,
      co2TonnesDay: baseCo2,
      dailyProductionTonnes: baseProd,
      primeYieldPercent: baseYield,
      defectRiskLevel: 'LOW',
      dailyCostUsd: baseCost
    },
    simulated: {
      energyMwhTonne: Number(simEnergy.toFixed(3)),
      co2TonnesDay: Number(simCo2.toFixed(1)),
      dailyProductionTonnes: simProd,
      primeYieldPercent: Number(simYield.toFixed(1)),
      defectRiskLevel: defectRisk,
      dailyCostUsd: Number(simCost.toFixed(0))
    },
    deltas: {
      energyMwhTonneDeltaPercent: Number((((simEnergy - baseEnergy) / baseEnergy) * 100).toFixed(1)),
      co2TonnesDayDeltaPercent: Number((((simCo2 - baseCo2) / baseCo2) * 100).toFixed(1)),
      productionTonnesDeltaPercent: Number((((simProd - baseProd) / baseProd) * 100).toFixed(1)),
      primeYieldDeltaPercent: Number((simYield - baseYield).toFixed(1)),
      dailyCostUsdDelta: Math.round(simCost - baseCost)
    },
    simulatedTimestamp: new Date().toISOString(),
    modelProvenance: 'SIMULATED'
  };
}
