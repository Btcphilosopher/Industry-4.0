// GLASSWORKS.OS — FURNACE.OS Spatial Thermal & Flow Digital Twin Engine

export type FurnaceZoneName = 
  | 'CHARGING' 
  | 'MELTING' 
  | 'REFINING' 
  | 'FINING' 
  | 'HOMOGENISATION' 
  | 'DELIVERY';

export type CombustionFuelMode = 
  | 'NATURAL_GAS' 
  | 'OXY_FUEL' 
  | 'HYBRID_OXY_ELEC' 
  | 'ELECTRIC_ASSIST' 
  | 'HYDROGEN_EXPERIMENTAL';

export interface FurnaceZone {
  name: FurnaceZoneName;
  xStartMeters: number;
  xEndMeters: number;
  targetTempC: number;
  actualTempC: number;
  glassDepthMeters: number;
  refractoryWallThicknessMm: number;
  refractoryCorrosionMmYr: number;
  bubbleDensityPerM3: number;
  hotSpotCrownTempC: number;
}

export interface GridCell {
  x: number; // Longitudinal 0 - 24
  y: number; // Lateral 0 - 8
  z: number; // Depth 0 - 4 (Surface, Mid, Bottom)
  temperatureC: number;
  velocityX: number; // m/s
  velocityY: number;
  velocityZ: number;
  viscosityPaS: number;
  densityKgM3: number;
  bubbleCount: number;
  refractoryWallLossPercent: number;
}

export interface BurnerState {
  id: string;
  zone: FurnaceZoneName;
  side: 'LEFT' | 'RIGHT';
  fuelMode: CombustionFuelMode;
  fuelFlowNm3h: number; // Normal m3 / hour
  oxygenFlowNm3h: number;
  airFlowNm3h: number;
  flameTempC: number;
  firingStatus: 'FIRING' | 'REVERSING' | 'STANDBY' | 'FAULT';
  efficiencyPercent: number;
  noxEmissionsPpm: number;
}

export interface RefractoryZoneHealth {
  zoneName: FurnaceZoneName;
  materialType: 'AZS_FUSED_CAST' | 'ZIRCONIA' | 'SILICA_CROWN' | 'HIGH_ALUMINA';
  ageYears: number;
  originalThicknessMm: number;
  currentThicknessMm: number;
  corrosionRateMmYr: number;
  remainingLifeYears: number;
  healthPercent: number; // 0 - 100%
  hotSpotRisk: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
}

export interface FurnaceState {
  totalLengthMeters: number; // e.g. 35 meters
  widthMeters: number;       // e.g. 10 meters
  poolDepthMeters: number;   // e.g. 1.25 meters
  pullRateTonnesPerDay: number; // e.g. 840 t/d
  glassLevelMm: number;       // e.g. 0.0 ± 0.2 mm
  crownTempMaxC: number;      // e.g. 1585°C
  bottomTempMinC: number;     // e.g. 1280°C
  activeFuelMode: CombustionFuelMode;
  culletPercent: number;
  
  zones: FurnaceZone[];
  gridCells: GridCell[][][]; // 25 x 9 x 5 reduced spatial grid
  burners: BurnerState[];
  refractoryHealth: RefractoryZoneHealth[];
  overallRefractoryHealthPercent: number;
  campaignStageYears: number; // e.g. 8.4 years out of 12-year campaign
  
  // Fining & Bubble Defect Model
  finingEfficiencyPercent: number;
  bubbleDefectRiskLevel: 'LOW' | 'MODERATE' | 'ELEVATED' | 'HIGH';
  estimatedResidueBubblesPerTonne: number;
}

export function createInitialFurnaceState(): FurnaceState {
  const zones: FurnaceZone[] = [
    { name: 'CHARGING', xStartMeters: 0, xEndMeters: 5, targetTempC: 1380, actualTempC: 1378, glassDepthMeters: 1.25, refractoryWallThicknessMm: 380, refractoryCorrosionMmYr: 12, bubbleDensityPerM3: 4500, hotSpotCrownTempC: 1420 },
    { name: 'MELTING', xStartMeters: 5, xEndMeters: 15, targetTempC: 1560, actualTempC: 1558, glassDepthMeters: 1.25, refractoryWallThicknessMm: 340, refractoryCorrosionMmYr: 18, bubbleDensityPerM3: 2800, hotSpotCrownTempC: 1585 },
    { name: 'REFINING', xStartMeters: 15, xEndMeters: 22, targetTempC: 1520, actualTempC: 1518, glassDepthMeters: 1.20, refractoryWallThicknessMm: 350, refractoryCorrosionMmYr: 14, bubbleDensityPerM3: 1100, hotSpotCrownTempC: 1540 },
    { name: 'FINING', xStartMeters: 22, xEndMeters: 27, targetTempC: 1470, actualTempC: 1468, glassDepthMeters: 1.15, refractoryWallThicknessMm: 360, refractoryCorrosionMmYr: 9, bubbleDensityPerM3: 120, hotSpotCrownTempC: 1490 },
    { name: 'HOMOGENISATION', xStartMeters: 27, xEndMeters: 31, targetTempC: 1410, actualTempC: 1408, glassDepthMeters: 1.10, refractoryWallThicknessMm: 375, refractoryCorrosionMmYr: 6, bubbleDensityPerM3: 18, hotSpotCrownTempC: 1430 },
    { name: 'DELIVERY', xStartMeters: 31, xEndMeters: 35, targetTempC: 1280, actualTempC: 1279, glassDepthMeters: 0.85, refractoryWallThicknessMm: 390, refractoryCorrosionMmYr: 4, bubbleDensityPerM3: 4, hotSpotCrownTempC: 1300 }
  ];

  // Burners: 6 ports on Left and Right sides
  const burners: BurnerState[] = [];
  for (let port = 1; port <= 6; port++) {
    const zoneName: FurnaceZoneName = port <= 2 ? 'MELTING' : port <= 4 ? 'REFINING' : 'FINING';
    burners.push({
      id: `B_L${port}`,
      zone: zoneName,
      side: 'LEFT',
      fuelMode: 'NATURAL_GAS',
      fuelFlowNm3h: 380 - port * 20,
      oxygenFlowNm3h: 0,
      airFlowNm3h: 3600 - port * 180,
      flameTempC: 1850 - port * 25,
      firingStatus: 'FIRING',
      efficiencyPercent: 91.5,
      noxEmissionsPpm: 240
    });
    burners.push({
      id: `B_R${port}`,
      zone: zoneName,
      side: 'RIGHT',
      fuelMode: 'NATURAL_GAS',
      fuelFlowNm3h: 380 - port * 20,
      oxygenFlowNm3h: 0,
      airFlowNm3h: 3600 - port * 180,
      flameTempC: 1850 - port * 25,
      firingStatus: 'STANDBY', // Reversing system toggles sides every 20 mins
      efficiencyPercent: 91.5,
      noxEmissionsPpm: 240
    });
  }

  // Refractory Health
  const refractoryHealth: RefractoryZoneHealth[] = zones.map(z => ({
    zoneName: z.name,
    materialType: z.name === 'MELTING' ? 'AZS_FUSED_CAST' : 'ZIRCONIA',
    ageYears: 8.4,
    originalThicknessMm: 450,
    currentThicknessMm: z.refractoryWallThicknessMm,
    corrosionRateMmYr: z.refractoryCorrosionMmYr,
    remainingLifeYears: Math.max(0.5, (z.refractoryWallThicknessMm - 100) / z.refractoryCorrosionMmYr),
    healthPercent: Math.round((z.refractoryWallThicknessMm / 450) * 100),
    hotSpotRisk: z.refractoryWallThicknessMm < 300 ? 'HIGH' : 'LOW'
  }));

  // Build 2.5D spatial grid (25 x 9 x 5)
  const gridCells: GridCell[][][] = [];
  for (let x = 0; x < 25; x++) {
    const planeX: GridCell[][] = [];
    const normX = x / 24; // 0.0 to 1.0 along furnace length
    
    // Thermal longitudinal profile bell curve peaking at hot spot (around x = 10, i.e. normX ~ 0.4)
    const baseTemp = 1350 + 230 * Math.sin(Math.PI * Math.pow(normX, 0.7));

    for (let y = 0; y < 9; y++) {
      const planeY: GridCell[] = [];
      const normY = Math.abs(y - 4) / 4; // 0 at center, 1 at side refractory walls

      for (let z = 0; z < 5; z++) {
        const normZ = z / 4; // 0 at crown surface, 1 at bottom refractories
        
        // Surface is hotter than bottom glass pool
        const temp = baseTemp - (normY * 40) - (normZ * 120) + (Math.random() * 3 - 1.5);
        
        // Convection vector: Surface flows forward (X+), bottom recirculates backward (X-)
        const velX = normZ < 0.5 ? (0.015 * (1 - normZ * 2)) : (-0.008 * (normZ - 0.5) * 2);
        const velY = (y - 4) * 0.001; // subtle lateral buoyancy
        const velZ = normX < 0.4 ? -0.002 : (normX > 0.6 ? 0.002 : 0.000); // buoyant up-currents at hot spot

        planeY.push({
          x,
          y,
          z,
          temperatureC: Math.round(temp),
          velocityX: Number(velX.toFixed(4)),
          velocityY: Number(velY.toFixed(4)),
          velocityZ: Number(velZ.toFixed(4)),
          viscosityPaS: Math.round(Math.exp((1500 - temp) / 120) * 10),
          densityKgM3: 2380 + (1500 - temp) * 0.15,
          bubbleCount: Math.round(Math.max(0, (1 - normX) * 120 * (1 - normZ))),
          refractoryWallLossPercent: normY > 0.8 ? Math.round(15 + normX * 10) : 0
        });
      }
      planeX.push(planeY);
    }
    gridCells.push(planeX);
  }

  return {
    totalLengthMeters: 35,
    widthMeters: 10,
    poolDepthMeters: 1.25,
    pullRateTonnesPerDay: 840,
    glassLevelMm: 0.0,
    crownTempMaxC: 1585,
    bottomTempMinC: 1280,
    activeFuelMode: 'NATURAL_GAS',
    culletPercent: 25.0,
    zones,
    gridCells,
    burners,
    refractoryHealth,
    overallRefractoryHealthPercent: 82,
    campaignStageYears: 8.4,
    finingEfficiencyPercent: 99.2,
    bubbleDefectRiskLevel: 'LOW',
    estimatedResidueBubblesPerTonne: 12
  };
}
