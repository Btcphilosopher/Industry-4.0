import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';
import { GoogleGenAI } from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());

const angularApp = new AngularNodeAppEngine();

// REST API Endpoints for GLASSWORKS.OS Digital Twin
app.get('/api/plant', (req, res) => {
  res.json({
    plantId: 'GLASSWORKS-PLANT-01',
    name: 'Munich Float Glass Manufacturing Line',
    type: 'FLOAT_GLASS_CONTINUOUS',
    status: 'RUNNING',
    pullRateTonnesDay: 840,
    primeQualityYieldPercent: 98.4,
    energyMwhPerTonne: 0.112,
    co2TonnesPerDay: 188.4,
    timestamp: new Date().toISOString()
  });
});

app.get('/api/furnace', (req, res) => {
  res.json({
    furnaceId: 'FURNACE-01',
    lengthMeters: 35,
    widthMeters: 10,
    maxCrownTempC: 1585,
    activeFuelMode: 'NATURAL_GAS',
    culletPercent: 25.0,
    overallRefractoryHealthPercent: 82,
    campaignStageYears: 8.4,
    bubbleDefectRiskLevel: 'LOW'
  });
});

app.get('/api/furnace/temperature', (req, res) => {
  res.json({
    zones: [
      { name: 'CHARGING', targetC: 1380, actualC: 1378 },
      { name: 'MELTING', targetC: 1560, actualC: 1558 },
      { name: 'REFINING', targetC: 1520, actualC: 1518 },
      { name: 'FINING', targetC: 1470, actualC: 1468 },
      { name: 'HOMOGENISATION', targetC: 1410, actualC: 1408 },
      { name: 'DELIVERY', targetC: 1280, actualC: 1279 }
    ]
  });
});

app.get('/api/tin-bath', (req, res) => {
  res.json({
    tinBathId: 'TIN-BATH-01',
    lengthMeters: 58,
    ribbonWidthMeters: 3.85,
    centerThicknessMm: 4.01,
    drawSpeedMpm: 11.2,
    atmosphereH2Percent: 5.0,
    topRollersActiveCount: 12
  });
});

app.get('/api/lehr', (req, res) => {
  res.json({
    lehrId: 'ANNEALING-LEHR-01',
    lengthMeters: 120,
    zonesCount: 16,
    residualStressMpa: 1.85,
    stressLevel: 'LOW',
    flatnessBowMmM: 0.12
  });
});

app.get('/api/quality', (req, res) => {
  res.json({
    primeYieldPercent: 98.4,
    defectRatePpm: 12.4,
    opticalClarityIndex: 99.1,
    activeDefectsCount: 3
  });
});

app.get('/api/energy', (req, res) => {
  res.json({
    thermalEnergyMwhPerDay: 82.4,
    electricalEnergyMwhPerDay: 11.8,
    totalEnergyMwhPerDay: 94.2,
    energyPerTonneMwh: 0.112,
    dailyEnergyCostUsd: 11775
  });
});

app.get('/api/emissions', (req, res) => {
  res.json({
    co2TonnesPerDay: 188.4,
    noxKgPerDay: 420,
    soxKgPerDay: 115,
    co2PerTonneGlassKg: 224
  });
});

app.post('/api/ai/analyze', async (req, res): Promise<void> => {
  try {
    const apiKey = process.env['GEMINI_API_KEY'];
    if (!apiKey) {
      res.json({
        analysis: "AI expert connection unavailable (GEMINI_API_KEY not configured). Internal physics process rule validation confirmed: Furnace thermal symmetry is optimal and refractory wear rate is within normal 8.4-year campaign tolerances."
      });
      return;
    }

    const ai = new GoogleGenAI({ apiKey });
    const { prompt, context } = req.body;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `You are the GLASSWORKS.OS Chief Process Diagnostics AI Engineer. Analyze the following flat glass manufacturing process context and provide a brief, authoritative, 3-bullet process engineering recommendation.\n\nContext:\n${JSON.stringify(context || {})}\n\nUser Question:\n${prompt}`
    });

    res.json({ analysis: response.text });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'AI analysis failed';
    res.status(500).json({ error: msg });
  }
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
