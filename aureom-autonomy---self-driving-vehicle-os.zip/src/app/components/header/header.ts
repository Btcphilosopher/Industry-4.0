// ============================================================================
// AUREOM AUTONOMY — HEADER & MISSION CONTROL COMPONENT
// ============================================================================

import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationEngineService } from '../../core/services/simulation-engine.service';
import { SCENARIOS, ScenarioDefinition } from '../../core/models/scenarios';

@Component({
  selector: 'app-header',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="bg-slate-900 border-b border-slate-800 px-4 py-2.5 select-none shadow-md">
      <div class="flex flex-wrap items-center justify-between gap-3">
        <!-- Brand & Platform Identity -->
        <div class="flex items-center gap-3">
          <div class="w-9 h-9 rounded-lg bg-gradient-to-tr from-cyan-600 via-blue-600 to-indigo-600 flex items-center justify-center shadow-inner border border-cyan-400/30">
            <mat-icon class="text-white text-xl">sensors</mat-icon>
          </div>
          <div>
            <div class="flex items-center gap-2">
              <span class="font-extrabold tracking-wider text-base text-white">AUREOM AUTONOMY</span>
              <span class="text-[10px] uppercase font-bold tracking-widest px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-700/50">
                R + RUST CORE v2.4.0
              </span>
              <span class="text-[10px] uppercase font-medium px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-700/40 flex items-center gap-1">
                <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                DETERMINISTIC SIM
              </span>
            </div>
            <p class="text-xs text-slate-400 font-mono">Self-Driving Vehicle Operating System & Scientific Validation Engine</p>
          </div>
        </div>

        <!-- Simulation Clock & Real-time Metrics -->
        <div class="flex items-center gap-4 bg-slate-950/80 px-3.5 py-1.5 rounded-lg border border-slate-800 font-mono text-xs">
          <div class="flex flex-col">
            <span class="text-[10px] uppercase text-slate-500 font-semibold tracking-wider">Sim Clock</span>
            <span class="text-cyan-400 font-bold text-sm">
              {{ simEngine.simTimeS().toFixed(2) }}s
            </span>
          </div>
          <div class="h-6 w-px bg-slate-800"></div>
          <div class="flex flex-col">
            <span class="text-[10px] uppercase text-slate-500 font-semibold tracking-wider">Velocity</span>
            <span class="text-white font-bold text-sm">
              {{ (simEngine.vehicleState().velocity * 3.6).toFixed(1) }} <span class="text-[10px] text-slate-400 font-normal">km/h</span>
            </span>
          </div>
          <div class="h-6 w-px bg-slate-800"></div>
          <div class="flex flex-col">
            <span class="text-[10px] uppercase text-slate-500 font-semibold tracking-wider">Safety Status</span>
            <span [ngClass]="{
              'text-emerald-400': simEngine.safetyResult().verdict === 'APPROVE',
              'text-amber-400': simEngine.safetyResult().verdict === 'APPROVE_WITH_DEGRADATION' || simEngine.safetyResult().verdict === 'REQUEST_REPLAN',
              'text-rose-400': simEngine.safetyResult().verdict === 'SIMULATED_SAFE_STOP' || simEngine.safetyResult().verdict === 'REJECT'
            }" class="font-bold text-xs flex items-center gap-1">
              <mat-icon class="text-xs">
                {{ simEngine.safetyResult().verdict === 'APPROVE' ? 'verified_user' : 'warning' }}
              </mat-icon>
              {{ simEngine.safetyResult().verdict }}
            </span>
          </div>
        </div>

        <!-- Master Simulation Controls -->
        <div class="flex items-center gap-2">
          <!-- Scenario Selector -->
          <div class="relative">
            <select
              #scenarioSelect
              [value]="simEngine.currentScenario().id"
              (change)="onScenarioChange(scenarioSelect.value)"
              class="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-md px-2.5 py-1.5 pr-7 focus:outline-none focus:border-cyan-500 font-medium cursor-pointer appearance-none"
            >
              @for (scen of scenarios; track scen.id) {
                <option [value]="scen.id">{{ scen.name }}</option>
              }
            </select>
            <mat-icon class="absolute right-1.5 top-1.5 text-slate-400 pointer-events-none text-base">expand_more</mat-icon>
          </div>

          <!-- Play / Pause Button -->
          <button
            (click)="simEngine.togglePlay()"
            [title]="simEngine.isRunning() ? 'Pause Simulation' : 'Run Simulation'"
            class="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold shadow transition-colors cursor-pointer"
            [ngClass]="simEngine.isRunning() ? 'bg-amber-600 hover:bg-amber-500 text-white' : 'bg-emerald-600 hover:bg-emerald-500 text-white'"
          >
            <mat-icon class="text-sm">{{ simEngine.isRunning() ? 'pause' : 'play_arrow' }}</mat-icon>
            {{ simEngine.isRunning() ? 'PAUSE' : 'RUN' }}
          </button>

          <!-- Step Forward Button -->
          <button
            (click)="simEngine.stepManual()"
            title="Step forward single tick (40ms)"
            class="p-1.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs cursor-pointer flex items-center"
          >
            <mat-icon class="text-base">skip_next</mat-icon>
          </button>

          <!-- Sim Speed Toggles -->
          <div class="flex items-center bg-slate-950 p-0.5 rounded-md border border-slate-800 text-[11px] font-mono">
            @for (spd of [0.5, 1.0, 2.0, 5.0]; track spd) {
              <button
                (click)="simEngine.setSpeed(spd)"
                class="px-2 py-1 rounded transition-colors cursor-pointer font-semibold"
                [ngClass]="simEngine.simSpeed() === spd ? 'bg-cyan-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'"
              >
                {{ spd }}x
              </button>
            }
          </div>

          <!-- Reset Button -->
          <button
            (click)="simEngine.loadScenario(simEngine.currentScenario())"
            title="Reset Scenario"
            class="p-1.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 cursor-pointer flex items-center"
          >
            <mat-icon class="text-base">replay</mat-icon>
          </button>
        </div>
      </div>
    </header>
  `
})
export class HeaderComponent {
  public simEngine = inject(SimulationEngineService);
  public scenarios: ScenarioDefinition[] = SCENARIOS;

  public onScenarioChange(scenarioId: string): void {
    const scen = this.scenarios.find(s => s.id === scenarioId);
    if (scen) {
      this.simEngine.loadScenario(scen);
    }
  }
}
