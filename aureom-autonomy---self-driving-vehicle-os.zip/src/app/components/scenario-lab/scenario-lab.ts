// ============================================================================
// AUREOM AUTONOMY — SCENARIO LAB & BENCHMARK SUITE
// ============================================================================

import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationEngineService } from '../../core/services/simulation-engine.service';
import { SCENARIOS, ScenarioDefinition } from '../../core/models/scenarios';

@Component({
  selector: 'app-scenario-lab',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-slate-900 rounded-xl border border-slate-800 p-4 flex flex-col gap-4 text-xs font-mono shadow-xl">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-2.5">
        <div class="flex items-center gap-2">
          <mat-icon class="text-cyan-400 text-lg">science</mat-icon>
          <span class="font-bold text-sm text-white">SCENARIO LAB & STANDARDISED BENCHMARK SUITE</span>
        </div>
        <span class="text-slate-400 text-[11px]">
          Total Benchmarks: <strong class="text-cyan-400">{{ scenarios.length }}</strong>
        </span>
      </div>

      <!-- Scenarios Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        @for (scen of scenarios; track scen.id) {
          <div
            class="bg-slate-950 p-3.5 rounded-lg border transition-all flex flex-col justify-between gap-3"
            [ngClass]="simEngine.currentScenario().id === scen.id ? 'border-cyan-500 shadow-md ring-1 ring-cyan-500/40' : 'border-slate-800 hover:border-slate-700'"
          >
            <div class="flex flex-col gap-1.5">
              <div class="flex items-center justify-between">
                <span class="text-[10px] px-1.5 py-0.5 rounded font-bold uppercase"
                  [ngClass]="{
                    'bg-blue-950 text-blue-300 border border-blue-800/40': scen.category === 'URBAN_LOOP',
                    'bg-rose-950 text-rose-300 border border-rose-800/40': scen.category === 'CRITICAL_SAFETY',
                    'bg-amber-950 text-amber-300 border border-amber-800/40': scen.category === 'WEATHER_DEGRADATION',
                    'bg-purple-950 text-purple-300 border border-purple-800/40': scen.category === 'SENSOR_FAULT',
                    'bg-emerald-950 text-emerald-300 border border-emerald-800/40': scen.category === 'HIGHWAY_NAVIGATION'
                  }">
                  {{ scen.category }}
                </span>
                <span class="text-slate-500 text-[10px]">{{ scen.durationLimitS }}s limit</span>
              </div>

              <h4 class="text-slate-100 font-bold text-xs">{{ scen.name }}</h4>
              <p class="text-[11px] text-slate-400 leading-relaxed">{{ scen.description }}</p>

              <div class="grid grid-cols-3 gap-1.5 pt-2 border-t border-slate-900 text-[10px] text-slate-400">
                <div>Weather: <strong class="text-slate-200 block">{{ scen.weather }}</strong></div>
                <div>Friction μ: <strong class="text-slate-200 block">{{ scen.frictionMu }}</strong></div>
                <div>Actors: <strong class="text-cyan-400 block">{{ scen.actors.length }}</strong></div>
              </div>
            </div>

            <button
              (click)="loadScenario(scen)"
              class="w-full py-1.5 rounded text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1"
              [ngClass]="simEngine.currentScenario().id === scen.id ? 'bg-cyan-600 text-white' : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'"
            >
              <mat-icon class="text-sm">{{ simEngine.currentScenario().id === scen.id ? 'check' : 'play_arrow' }}</mat-icon>
              {{ simEngine.currentScenario().id === scen.id ? 'CURRENTLY ACTIVE' : 'LOAD & RUN SCENARIO' }}
            </button>
          </div>
        }
      </div>
    </div>
  `
})
export class ScenarioLabComponent {
  public simEngine = inject(SimulationEngineService);
  public scenarios: ScenarioDefinition[] = SCENARIOS;

  public loadScenario(scen: ScenarioDefinition): void {
    this.simEngine.loadScenario(scen);
  }
}
