// ============================================================================
// AUREOM AUTONOMY — SENSOR FUSION & EKF LOCALISATION COMPONENT
// ============================================================================

import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationEngineService } from '../../core/services/simulation-engine.service';

@Component({
  selector: 'app-fusion-localisation',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-slate-900 rounded-xl border border-slate-800 p-4 flex flex-col gap-4 text-xs font-mono shadow-xl">
      <!-- Section Header -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-2.5">
        <div class="flex items-center gap-2">
          <mat-icon class="text-blue-400 text-lg">my_location</mat-icon>
          <span class="font-bold text-sm text-white">EXTENDED KALMAN FILTER (EKF) LOCALISATION & SENSOR FUSION</span>
        </div>
        <div class="flex items-center gap-2">
          <span class="text-[10px] px-2 py-0.5 rounded font-bold uppercase"
            [ngClass]="simEngine.localisation().mode === 'EKF_FUSED' ? 'bg-emerald-950 text-emerald-300 border border-emerald-700/50' : 'bg-amber-950 text-amber-300 border border-amber-700/50'">
            MODE: {{ simEngine.localisation().mode }}
          </span>
          <span class="text-slate-400 text-[11px]">Quality: <strong class="text-cyan-400 font-bold">{{ simEngine.localisation().qualityScore }}%</strong></span>
        </div>
      </div>

      <!-- EKF State Vector & Multi-Sensor Modalities -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-3">
        <!-- Estimated State Vector -->
        <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col gap-2">
          <span class="text-cyan-400 font-bold text-[11px] uppercase tracking-wider flex items-center gap-1">
            <mat-icon class="text-sm">functions</mat-icon> EKF State Vector (x̂)
          </span>
          <div class="space-y-1.5 text-[11px]">
            <div class="flex justify-between border-b border-slate-900 pb-1">
              <span class="text-slate-400">Position X (px):</span>
              <span class="text-white font-bold">{{ simEngine.localisation().pose.x.toFixed(3) }} m</span>
            </div>
            <div class="flex justify-between border-b border-slate-900 pb-1">
              <span class="text-slate-400">Position Y (py):</span>
              <span class="text-white font-bold">{{ simEngine.localisation().pose.y.toFixed(3) }} m</span>
            </div>
            <div class="flex justify-between border-b border-slate-900 pb-1">
              <span class="text-slate-400">Heading (ψ):</span>
              <span class="text-white font-bold">{{ (simEngine.localisation().pose.yaw * 180 / 3.14159).toFixed(2) }}°</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Velocity (v):</span>
              <span class="text-emerald-400 font-bold">{{ simEngine.localisation().velocityMS.toFixed(2) }} m/s</span>
            </div>
          </div>
        </div>

        <!-- GNSS Modality Status -->
        <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col gap-2">
          <span class="text-blue-400 font-bold text-[11px] uppercase tracking-wider flex items-center gap-1">
            <mat-icon class="text-sm">satellite_alt</mat-icon> RTK GNSS Receiver
          </span>
          <div class="space-y-1.5 text-[11px]">
            <div class="flex justify-between border-b border-slate-900 pb-1">
              <span class="text-slate-400">Fix Mode:</span>
              <span [ngClass]="simEngine.faultState().gnssUrbanCanyon ? 'text-rose-400 font-bold' : 'text-emerald-400 font-bold'">
                {{ simEngine.faultState().gnssUrbanCanyon ? 'NO_FIX (DENIED)' : 'RTK_FIXED' }}
              </span>
            </div>
            <div class="flex justify-between border-b border-slate-900 pb-1">
              <span class="text-slate-400">HDOP / VDOP:</span>
              <span class="text-white">{{ simEngine.faultState().gnssUrbanCanyon ? '8.5 / 12.0' : '0.85 / 1.10' }}</span>
            </div>
            <div class="flex justify-between border-b border-slate-900 pb-1">
              <span class="text-slate-400">Satellites:</span>
              <span class="text-white">{{ simEngine.faultState().gnssUrbanCanyon ? '4 SVs' : '18 SVs' }}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Innovation Res:</span>
              <span class="text-amber-400 font-bold">{{ simEngine.localisation().gnssResidual.toFixed(3) }} m</span>
            </div>
          </div>
        </div>

        <!-- 6-DOF IMU Modality -->
        <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col gap-2">
          <span class="text-amber-400 font-bold text-[11px] uppercase tracking-wider flex items-center gap-1">
            <mat-icon class="text-sm">screen_rotation</mat-icon> Tactical 6-DOF IMU
          </span>
          <div class="space-y-1.5 text-[11px]">
            <div class="flex justify-between border-b border-slate-900 pb-1">
              <span class="text-slate-400">Yaw Rate (ωz):</span>
              <span class="text-white font-bold">{{ (simEngine.localisation().yawRateRadS * 180 / 3.14159).toFixed(3) }} °/s</span>
            </div>
            <div class="flex justify-between border-b border-slate-900 pb-1">
              <span class="text-slate-400">Long. Accel (ax):</span>
              <span class="text-white font-bold">{{ simEngine.vehicleState().acceleration.toFixed(2) }} m/s²</span>
            </div>
            <div class="flex justify-between border-b border-slate-900 pb-1">
              <span class="text-slate-400">Bias Drift Model:</span>
              <span class="text-slate-300">Random Walk</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Integration:</span>
              <span class="text-emerald-400 font-bold">100Hz Strapdown</span>
            </div>
          </div>
        </div>

        <!-- Covariance & Map-Matching Constraint -->
        <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col gap-2">
          <span class="text-purple-400 font-bold text-[11px] uppercase tracking-wider flex items-center gap-1">
            <mat-icon class="text-sm">map</mat-icon> HD Map Matching
          </span>
          <div class="space-y-1.5 text-[11px]">
            <div class="flex justify-between border-b border-slate-900 pb-1">
              <span class="text-slate-400">Pos Variance (Var_X):</span>
              <span class="text-blue-300 font-bold">{{ simEngine.localisation().posCovarianceM2[0].toFixed(4) }} m²</span>
            </div>
            <div class="flex justify-between border-b border-slate-900 pb-1">
              <span class="text-slate-400">Pos Variance (Var_Y):</span>
              <span class="text-blue-300 font-bold">{{ simEngine.localisation().posCovarianceM2[1].toFixed(4) }} m²</span>
            </div>
            <div class="flex justify-between border-b border-slate-900 pb-1">
              <span class="text-slate-400">Heading Var (Var_ψ):</span>
              <span class="text-blue-300 font-bold">{{ simEngine.localisation().headingCovarianceRad2.toFixed(5) }} rad²</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Map Cross-Track:</span>
              <span class="text-purple-300 font-bold">{{ simEngine.localisation().mapMatchingResidual.toFixed(3) }} m</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class FusionLocalisationComponent {
  public simEngine = inject(SimulationEngineService);
}
