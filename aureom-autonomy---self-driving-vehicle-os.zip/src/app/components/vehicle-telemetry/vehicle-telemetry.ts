// ============================================================================
// AUREOM AUTONOMY — VEHICLE TELEMETRY & DIGITAL TWIN COMPONENT
// ============================================================================

import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationEngineService } from '../../core/services/simulation-engine.service';
import { DEFAULT_VEHICLE_CONFIG } from '../../core/services/vehicle-dynamics.service';
import { ControlService } from '../../core/services/control.service';

@Component({
  selector: 'app-vehicle-telemetry',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-slate-900 rounded-xl border border-slate-800 p-4 flex flex-col gap-4 text-xs font-mono shadow-xl">
      <!-- Section Header -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-2.5">
        <div class="flex items-center gap-2">
          <mat-icon class="text-cyan-400 text-lg">directions_car</mat-icon>
          <span class="font-bold text-sm text-white">DIGITAL TWIN & VEHICLE DYNAMICS TELEMETRY</span>
          <span class="text-[10px] px-1.5 py-0.5 rounded bg-blue-950 text-blue-300 border border-blue-800/60 font-semibold">
            KINEMATIC BICYCLE + SLIP
          </span>
        </div>
        <div class="flex items-center gap-3">
          <!-- Controller Switcher -->
          <div class="flex items-center gap-1 bg-slate-950 p-1 rounded-md border border-slate-800 text-[10px]">
            <span class="text-slate-500 font-semibold px-1">CONTROLLER:</span>
            <button
              (click)="setController('STANLEY')"
              class="px-2 py-0.5 rounded font-bold transition-colors cursor-pointer"
              [ngClass]="controlService.getControllerMode() === 'STANLEY' ? 'bg-cyan-600 text-white' : 'text-slate-400 hover:text-slate-200'"
            >
              STANLEY
            </button>
            <button
              (click)="setController('PURE_PURSUIT')"
              class="px-2 py-0.5 rounded font-bold transition-colors cursor-pointer"
              [ngClass]="controlService.getControllerMode() === 'PURE_PURSUIT' ? 'bg-cyan-600 text-white' : 'text-slate-400 hover:text-slate-200'"
            >
              PURE PURSUIT
            </button>
          </div>
        </div>
      </div>

      <!-- Gauges & Actuators Grid -->
      <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
        <!-- Speed & Powertrain -->
        <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col gap-2">
          <span class="text-cyan-400 font-bold text-[11px] uppercase tracking-wider flex items-center gap-1">
            <mat-icon class="text-sm">speed</mat-icon> Powertrain Dynamics
          </span>
          <div class="space-y-1.5 text-[11px]">
            <div class="flex justify-between border-b border-slate-900 pb-1">
              <span class="text-slate-400">Longitudinal Speed:</span>
              <span class="text-white font-bold">{{ (simEngine.vehicleState().velocity * 3.6).toFixed(1) }} km/h</span>
            </div>
            <div class="flex justify-between border-b border-slate-900 pb-1">
              <span class="text-slate-400">Lateral Slip Speed:</span>
              <span class="text-amber-400 font-bold">{{ simEngine.vehicleState().lateralVelocity.toFixed(3) }} m/s</span>
            </div>
            <div class="flex justify-between border-b border-slate-900 pb-1">
              <span class="text-slate-400">Slip Angle (β):</span>
              <span class="text-amber-300 font-bold">{{ (simEngine.vehicleState().slipAngleRad * 180 / 3.14159).toFixed(3) }}°</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Battery SoC:</span>
              <span class="text-emerald-400 font-bold">{{ simEngine.vehicleState().batterySocPercent.toFixed(1) }}%</span>
            </div>
          </div>
        </div>

        <!-- Steering & Controller Feedback -->
        <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col gap-2">
          <span class="text-blue-400 font-bold text-[11px] uppercase tracking-wider flex items-center gap-1">
            <mat-icon class="text-sm">rotate_right</mat-icon> Steering & Tracking
          </span>
          <div class="space-y-1.5 text-[11px]">
            <div class="flex justify-between border-b border-slate-900 pb-1">
              <span class="text-slate-400">Steer Angle (δ):</span>
              <span class="text-white font-bold">{{ (simEngine.vehicleState().steerAngleRad * 180 / 3.14159).toFixed(2) }}°</span>
            </div>
            <div class="flex justify-between border-b border-slate-900 pb-1">
              <span class="text-slate-400">Cross-Track Error (ey):</span>
              <span class="text-cyan-300 font-bold">{{ simEngine.controlCommand().crossTrackErrorM.toFixed(4) }} m</span>
            </div>
            <div class="flex justify-between border-b border-slate-900 pb-1">
              <span class="text-slate-400">Heading Error (eψ):</span>
              <span class="text-cyan-300 font-bold">{{ (simEngine.controlCommand().headingErrorRad * 180 / 3.14159).toFixed(2) }}°</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Yaw Rate (θ̇):</span>
              <span class="text-white font-bold">{{ (simEngine.vehicleState().yawRate * 180 / 3.14159).toFixed(2) }} °/s</span>
            </div>
          </div>
        </div>

        <!-- Actuator Command Levels -->
        <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col gap-2">
          <span class="text-emerald-400 font-bold text-[11px] uppercase tracking-wider flex items-center gap-1">
            <mat-icon class="text-sm">tune</mat-icon> Actuator Demands
          </span>
          <div class="space-y-2 text-[11px]">
            <div>
              <div class="flex justify-between text-slate-400 mb-1">
                <span>Throttle Demand:</span>
                <span class="text-emerald-400 font-bold">{{ (simEngine.controlCommand().throttle * 100).toFixed(0) }}%</span>
              </div>
              <div class="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden">
                <div class="bg-emerald-500 h-full rounded-full" [style.width.%]="simEngine.controlCommand().throttle * 100"></div>
              </div>
            </div>
            <div>
              <div class="flex justify-between text-slate-400 mb-1">
                <span>Brake Demand:</span>
                <span class="text-rose-400 font-bold">{{ (simEngine.controlCommand().brake * 100).toFixed(0) }}%</span>
              </div>
              <div class="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden">
                <div class="bg-rose-500 h-full rounded-full" [style.width.%]="simEngine.controlCommand().brake * 100"></div>
              </div>
            </div>
            <div class="flex justify-between pt-1 border-t border-slate-900">
              <span class="text-slate-400">Motor Torque:</span>
              <span class="text-white font-bold">{{ simEngine.vehicleState().motorTorqueNm.toFixed(0) }} Nm</span>
            </div>
          </div>
        </div>

        <!-- Four Wheel Odometry & RPM -->
        <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col gap-2">
          <span class="text-purple-400 font-bold text-[11px] uppercase tracking-wider flex items-center gap-1">
            <mat-icon class="text-sm">tire_repair</mat-icon> Wheel Speeds (RPM)
          </span>
          <div class="grid grid-cols-2 gap-2 text-[11px]">
            <div class="bg-slate-900/60 p-1.5 rounded border border-slate-800 text-center">
              <span class="text-[9px] text-slate-500 block">FL WHEEL</span>
              <span class="text-white font-bold">{{ simEngine.vehicleState().wheelRpm[0].toFixed(0) }}</span>
            </div>
            <div class="bg-slate-900/60 p-1.5 rounded border border-slate-800 text-center">
              <span class="text-[9px] text-slate-500 block">FR WHEEL</span>
              <span class="text-white font-bold">{{ simEngine.vehicleState().wheelRpm[1].toFixed(0) }}</span>
            </div>
            <div class="bg-slate-900/60 p-1.5 rounded border border-slate-800 text-center">
              <span class="text-[9px] text-slate-500 block">RL WHEEL</span>
              <span class="text-white font-bold">{{ simEngine.vehicleState().wheelRpm[2].toFixed(0) }}</span>
            </div>
            <div class="bg-slate-900/60 p-1.5 rounded border border-slate-800 text-center">
              <span class="text-[9px] text-slate-500 block">RR WHEEL</span>
              <span class="text-white font-bold">{{ simEngine.vehicleState().wheelRpm[3].toFixed(0) }}</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Vehicle Model Physical Constants Table -->
      <div class="bg-slate-950 p-2.5 rounded-lg border border-slate-800 flex flex-wrap items-center justify-between text-[11px] text-slate-400">
        <div>Vehicle Mass: <strong class="text-white">{{ vehicleConfig.massKg }} kg</strong></div>
        <div>Wheelbase (L): <strong class="text-white">{{ vehicleConfig.wheelbaseM }} m</strong></div>
        <div>Front Axle (lf): <strong class="text-white">{{ vehicleConfig.frontAxleDistM }} m</strong></div>
        <div>Rear Axle (lr): <strong class="text-white">{{ vehicleConfig.rearAxleDistM }} m</strong></div>
        <div>Track Width: <strong class="text-white">{{ vehicleConfig.trackWidthM }} m</strong></div>
        <div>Aerodynamic Cd: <strong class="text-white">{{ vehicleConfig.dragCoefficientCd }}</strong></div>
      </div>
    </div>
  `
})
export class VehicleTelemetryComponent {
  public simEngine = inject(SimulationEngineService);
  public controlService = inject(ControlService);
  public vehicleConfig = DEFAULT_VEHICLE_CONFIG;

  public setController(mode: 'STANLEY' | 'PURE_PURSUIT'): void {
    this.controlService.setControllerMode(mode);
  }
}
