// ============================================================================
// AUREOM AUTONOMY — R STATISTICAL RESEARCH WORKBENCH & MONTE CARLO SUITE
// ============================================================================

import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MonteCarloTrial, RStatisticalService, StatisticalReport } from '../../core/services/r-statistical.service';

@Component({
  selector: 'app-r-workbench',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-slate-900 rounded-xl border border-slate-800 p-4 flex flex-col gap-4 text-xs font-mono shadow-xl">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-2.5">
        <div class="flex items-center gap-2">
          <mat-icon class="text-indigo-400 text-lg">insights</mat-icon>
          <span class="font-bold text-sm text-white">R STATISTICAL RESEARCH WORKBENCH (aureomAutonomyR)</span>
          <span class="text-[10px] px-1.5 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800/60 font-semibold">
            R 4.4+ / CRAN SPEC
          </span>
        </div>
        <div class="flex items-center gap-2">
          <button
            (click)="runBatch(150)"
            class="px-3 py-1.5 rounded-md bg-indigo-600 hover:bg-indigo-500 text-white font-bold flex items-center gap-1.5 shadow cursor-pointer transition-colors"
          >
            <mat-icon class="text-sm">play_arrow</mat-icon> RUN MONTE CARLO EXPERIMENT (N=150)
          </button>
          <button
            (click)="exportCsv()"
            class="px-3 py-1.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 flex items-center gap-1 cursor-pointer"
          >
            <mat-icon class="text-sm">download</mat-icon> EXPORT DATASET (.CSV)
          </button>
        </div>
      </div>

      <!-- Statistical Metrics Summary -->
      @if (report(); as rep) {
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col gap-1">
            <span class="text-slate-400 text-[11px]">Monte Carlo Success Rate:</span>
            <div class="text-lg font-bold text-emerald-400">{{ rep.successRatePercent }}%</div>
            <span class="text-[10px] text-slate-500">Across {{ rep.totalTrials }} stochastic trials</span>
          </div>

          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col gap-1">
            <span class="text-slate-400 text-[11px]">Mean TTC (95% CI):</span>
            <div class="text-lg font-bold text-cyan-400">{{ rep.meanTtcS }}s</div>
            <span class="text-[10px] text-slate-400 font-mono">CI: [{{ rep.ci95Ttc[0] }}, {{ rep.ci95Ttc[1] }}]s</span>
          </div>

          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col gap-1">
            <span class="text-slate-400 text-[11px]">Mean Peak Jerk (95% CI):</span>
            <div class="text-lg font-bold text-blue-400">{{ rep.meanJerkMS3 }} m/s³</div>
            <span class="text-[10px] text-slate-400 font-mono">CI: [{{ rep.ci95Jerk[0] }}, {{ rep.ci95Jerk[1] }}] m/s³</span>
          </div>

          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col gap-1">
            <span class="text-slate-400 text-[11px]">Weibull Reliability Parameters:</span>
            <div class="text-sm font-bold text-purple-300 font-mono">β = {{ rep.weibullShape }}, η = {{ rep.weibullScale }}</div>
            <span class="text-[10px] text-slate-500">Survival Hazard Distribution</span>
          </div>
        </div>
      }

      <!-- Stochastic Trial Samples Distribution Table -->
      <div class="bg-slate-950 rounded-lg border border-slate-800 overflow-hidden">
        <div class="px-3 py-2 bg-slate-900/80 border-b border-slate-800 font-semibold text-slate-300 text-xs flex justify-between items-center">
          <span>Sampled Monte Carlo Parameter Vectors (Stochastic Sweep)</span>
          <span class="text-[10px] text-slate-500">Showing top 10 of {{ trials().length }} iterations</span>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-left text-[11px] font-mono">
            <thead class="bg-slate-900 text-slate-400 text-[10px] uppercase border-b border-slate-800">
              <tr>
                <th class="p-2">Trial #</th>
                <th class="p-2">Road Friction (μ)</th>
                <th class="p-2">Sensor Latency</th>
                <th class="p-2">GNSS Noise</th>
                <th class="p-2">Min TTC</th>
                <th class="p-2">Max Jerk</th>
                <th class="p-2">Cross-Track RMSE</th>
                <th class="p-2">Trial Outcome</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
              @for (t of trials().slice(0, 8); track t.trialId) {
                <tr class="hover:bg-slate-900/50">
                  <td class="p-2 text-cyan-400 font-bold">#{{ t.trialId }}</td>
                  <td class="p-2 text-slate-300">{{ t.frictionMu }}</td>
                  <td class="p-2 text-slate-300">{{ t.sensorLatencyMs }} ms</td>
                  <td class="p-2 text-slate-300">{{ t.gnssErrorStdM }} m</td>
                  <td class="p-2 font-bold" [ngClass]="t.minTtcS < 1.5 ? 'text-rose-400' : 'text-emerald-400'">{{ t.minTtcS }} s</td>
                  <td class="p-2 text-slate-300">{{ t.maxJerkMS3 }} m/s³</td>
                  <td class="p-2 text-blue-300">{{ t.crossTrackRmseM }} m</td>
                  <td class="p-2">
                    <span class="px-1.5 py-0.5 rounded text-[10px] font-bold"
                      [ngClass]="t.outcome === 'SUCCESS' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800/40' : 'bg-amber-950 text-amber-300 border border-amber-800/40'">
                      {{ t.outcome }}
                    </span>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- Reproducible R 4.4+ Script Terminal -->
      <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col gap-2">
        <div class="flex items-center justify-between text-slate-300 font-semibold text-[11px]">
          <span class="flex items-center gap-1.5 text-indigo-400">
            <mat-icon class="text-sm">code</mat-icon> REPRODUCIBLE R SCRIPT (data.table / survival / ggplot2)
          </span>
          <span class="text-[10px] text-slate-500">Copy into R Studio or Quarto Notebook</span>
        </div>
        <pre class="bg-slate-900/90 p-3 rounded border border-slate-800 text-[11px] text-indigo-200 font-mono overflow-x-auto max-h-44">{{ report()?.rScriptExecutable }}</pre>
      </div>
    </div>
  `
})
export class RWorkbenchComponent {
  private rService = inject(RStatisticalService);

  public trials = signal<MonteCarloTrial[]>([]);
  public report = signal<StatisticalReport | null>(null);

  constructor() {
    this.runBatch(150);
  }

  public runBatch(n = 150): void {
    const res = this.rService.runMonteCarloBatch(n);
    this.trials.set(res.trials);
    this.report.set(res.report);
  }

  public exportCsv(): void {
    const list = this.trials();
    if (list.length === 0) return;

    const headers = 'trial_id,friction_mu,sensor_latency_ms,gnss_noise_m,min_ttc_s,max_jerk_ms3,cross_track_rmse_m,outcome\n';
    const rows = list.map(t =>
      `${t.trialId},${t.frictionMu},${t.sensorLatencyMs},${t.gnssErrorStdM},${t.minTtcS},${t.maxJerkMS3},${t.crossTrackRmseM},${t.outcome}`
    ).join('\n');

    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `aureom_autonomy_monte_carlo_${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }
}
