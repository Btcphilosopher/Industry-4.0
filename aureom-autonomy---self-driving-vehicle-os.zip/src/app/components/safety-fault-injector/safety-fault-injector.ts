// ============================================================================
// AUREOM AUTONOMY — SAFETY SUPERVISOR & FAULT INJECTION COMPONENT
// ============================================================================

import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationEngineService } from '../../core/services/simulation-engine.service';
import { FaultInjectionState } from '../../core/models/av-types';

@Component({
  selector: 'app-safety-fault-injector',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-slate-900 rounded-xl border border-slate-800 p-4 flex flex-col gap-4 text-xs font-mono shadow-xl">
      <!-- Section Header -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-2.5">
        <div class="flex items-center gap-2">
          <mat-icon class="text-rose-400 text-lg">shield</mat-icon>
          <span class="font-bold text-sm text-white">INDEPENDENT SAFETY SUPERVISOR & FAULT INJECTOR</span>
        </div>
        <div class="flex items-center gap-2">
          <span class="text-slate-400 text-[11px]">Verdict:</span>
          <span class="px-2.5 py-0.5 rounded font-bold text-xs uppercase"
            [ngClass]="{
              'bg-emerald-950 text-emerald-300 border border-emerald-700/60': simEngine.safetyResult().verdict === 'APPROVE',
              'bg-amber-950 text-amber-300 border border-amber-700/60': simEngine.safetyResult().verdict === 'APPROVE_WITH_DEGRADATION' || simEngine.safetyResult().verdict === 'REQUEST_REPLAN',
              'bg-rose-950 text-rose-300 border border-rose-700/60 animate-pulse': simEngine.safetyResult().verdict === 'SIMULATED_SAFE_STOP' || simEngine.safetyResult().verdict === 'REJECT'
            }">
            {{ simEngine.safetyResult().verdict }}
          </span>
        </div>
      </div>

      <!-- Hard Safety Invariants Grid -->
      <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
        <!-- Time To Collision (TTC) Invariant -->
        <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col gap-1.5">
          <div class="flex justify-between items-center text-slate-400 text-[11px]">
            <span>1. Time-to-Collision (TTC)</span>
            <span class="text-[10px] text-slate-500">Threshold &ge; 1.8s</span>
          </div>
          <div class="text-lg font-bold" [ngClass]="simEngine.safetyResult().timeToCollisionS < 1.8 ? 'text-rose-400' : 'text-emerald-400'">
            {{ simEngine.safetyResult().timeToCollisionS.toFixed(2) }}s
          </div>
          <div class="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden">
            <div
              class="h-full rounded-full"
              [ngClass]="simEngine.safetyResult().timeToCollisionS < 1.8 ? 'bg-rose-500' : 'bg-emerald-500'"
              [style.width.%]="Math.min(100, (simEngine.safetyResult().timeToCollisionS / 5.0) * 100)">
            </div>
          </div>
        </div>

        <!-- Lateral Acceleration Envelope -->
        <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col gap-1.5">
          <div class="flex justify-between items-center text-slate-400 text-[11px]">
            <span>2. Lateral Accel (alat)</span>
            <span class="text-[10px] text-slate-500">Cap &le; 3.5 m/s²</span>
          </div>
          <div class="text-lg font-bold" [ngClass]="simEngine.safetyResult().maxLateralAccelMS2 > 3.5 ? 'text-rose-400' : 'text-cyan-400'">
            {{ simEngine.safetyResult().maxLateralAccelMS2.toFixed(2) }} m/s²
          </div>
          <div class="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden">
            <div
              class="h-full rounded-full bg-cyan-500"
              [style.width.%]="Math.min(100, (simEngine.safetyResult().maxLateralAccelMS2 / 3.5) * 100)">
            </div>
          </div>
        </div>

        <!-- Kinematic Jerk Limit -->
        <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col gap-1.5">
          <div class="flex justify-between items-center text-slate-400 text-[11px]">
            <span>3. Trajectory Jerk (j̇)</span>
            <span class="text-[10px] text-slate-500">Cap &le; 4.0 m/s³</span>
          </div>
          <div class="text-lg font-bold" [ngClass]="simEngine.safetyResult().maxJerkMagnitudeMS3 > 4.0 ? 'text-rose-400' : 'text-blue-400'">
            {{ simEngine.safetyResult().maxJerkMagnitudeMS3.toFixed(2) }} m/s³
          </div>
          <div class="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden">
            <div
              class="h-full rounded-full bg-blue-500"
              [style.width.%]="Math.min(100, (simEngine.safetyResult().maxJerkMagnitudeMS3 / 4.0) * 100)">
            </div>
          </div>
        </div>

        <!-- Boundary Margin Invariant -->
        <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col gap-1.5">
          <div class="flex justify-between items-center text-slate-400 text-[11px]">
            <span>4. Road Margin (dclear)</span>
            <span class="text-[10px] text-slate-500">Margin &ge; 0.45m</span>
          </div>
          <div class="text-lg font-bold" [ngClass]="simEngine.safetyResult().boundaryClearanceM < 0.45 ? 'text-rose-400' : 'text-purple-400'">
            {{ simEngine.safetyResult().boundaryClearanceM.toFixed(2) }}m
          </div>
          <div class="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden">
            <div
              class="h-full rounded-full bg-purple-500"
              [style.width.%]="Math.min(100, (simEngine.safetyResult().boundaryClearanceM / 3.0) * 100)">
            </div>
          </div>
        </div>
      </div>

      <!-- Interactive Synthetic Fault Injection Controls -->
      <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col gap-2">
        <div class="flex items-center justify-between">
          <span class="text-amber-400 font-bold text-[11px] uppercase tracking-wider flex items-center gap-1">
            <mat-icon class="text-sm">bug_report</mat-icon> SYNTHETIC FAULT INJECTION CONTROLS
          </span>
          <span class="text-slate-500 text-[10px]">Toggle live physical perturbations & anomalies</span>
        </div>
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-2">
          @for (f of faultList; track f.key) {
            <button
              (click)="simEngine.toggleFault(f.key)"
              class="p-2 rounded border text-left flex items-center justify-between transition-all cursor-pointer"
              [ngClass]="simEngine.faultState()[f.key]
                ? 'bg-rose-950/70 border-rose-500 text-rose-200 shadow-md font-bold'
                : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'"
            >
              <div class="flex flex-col">
                <span class="text-[11px]">{{ f.label }}</span>
                <span class="text-[9px]" [ngClass]="simEngine.faultState()[f.key] ? 'text-rose-400' : 'text-slate-500'">
                  {{ simEngine.faultState()[f.key] ? 'INJECTED (ACTIVE)' : 'NOMINAL' }}
                </span>
              </div>
              <mat-icon class="text-base" [ngClass]="simEngine.faultState()[f.key] ? 'text-rose-400' : 'text-slate-600'">
                {{ simEngine.faultState()[f.key] ? 'error' : 'check_circle' }}
              </mat-icon>
            </button>
          }
        </div>
      </div>

      <!-- Invariant Violations Stream -->
      @if (simEngine.safetyResult().violations.length > 0) {
        <div class="bg-rose-950/40 p-2.5 rounded-lg border border-rose-800/60 text-[11px] text-rose-300 space-y-1">
          <div class="font-bold flex items-center gap-1.5 text-rose-400">
            <mat-icon class="text-sm">warning</mat-icon> Active Invariant Safety Warnings:
          </div>
          @for (v of simEngine.safetyResult().violations; track v) {
            <div class="font-mono text-[10px] pl-5">• {{ v }}</div>
          }
        </div>
      }
    </div>
  `
})
export class SafetyFaultInjectorComponent {
  public simEngine = inject(SimulationEngineService);
  public Math = Math;

  public faultList: { key: keyof FaultInjectionState; label: string }[] = [
    { key: 'cameraBlackout', label: 'Vision Blackout' },
    { key: 'lidarRainAttenuation', label: 'LiDAR Rain Noise' },
    { key: 'radarJamming', label: 'Radar Jamming' },
    { key: 'gnssUrbanCanyon', label: 'GNSS Multipath Denied' },
    { key: 'imuBiasDrift', label: 'IMU Bias Drift' },
    { key: 'wheelSlipCondition', label: 'Tire Slip (Ice/Wet)' },
    { key: 'plannerLatencySpike', label: 'Compute Latency Spike' },
    { key: 'staleTrackInject', label: 'Phantom Obstacle Ghost' }
  ];
}
