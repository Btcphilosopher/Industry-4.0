// ============================================================================
// AUREOM AUTONOMY — ARCHITECTURE & RUST/R CORE WORKSPACE EXPLORER
// ============================================================================

import { ChangeDetectionStrategy, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-architecture-viewer',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-slate-900 rounded-xl border border-slate-800 p-4 flex flex-col gap-4 text-xs font-mono shadow-xl">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-2.5">
        <div class="flex items-center gap-2">
          <mat-icon class="text-amber-400 text-lg">account_tree</mat-icon>
          <span class="font-bold text-sm text-white">SYSTEM ARCHITECTURE & RUST/R RESEARCH WORKSPACE</span>
        </div>
        <span class="text-[10px] px-1.5 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800/60 font-semibold">
          31 RUST CRATES + R 4.4 PACKAGE
        </span>
      </div>

      <!-- Autonomous Loop Graph -->
      <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col gap-2">
        <span class="text-cyan-400 font-bold text-[11px] uppercase">Canonical Closed-Loop Autonomous Pipeline</span>
        <div class="flex flex-wrap items-center gap-1.5 text-[10px] font-bold">
          <span class="px-2 py-1 bg-slate-900 rounded border border-slate-700 text-slate-300">OBSERVE (Sensors)</span>
          <mat-icon class="text-xs text-slate-500">arrow_forward</mat-icon>
          <span class="px-2 py-1 bg-slate-900 rounded border border-slate-700 text-slate-300">ESTIMATE (EKF / Tracking)</span>
          <mat-icon class="text-xs text-slate-500">arrow_forward</mat-icon>
          <span class="px-2 py-1 bg-slate-900 rounded border border-slate-700 text-slate-300">UNDERSTAND (World Model)</span>
          <mat-icon class="text-xs text-slate-500">arrow_forward</mat-icon>
          <span class="px-2 py-1 bg-slate-900 rounded border border-slate-700 text-slate-300">PREDICT (Multi-Hypothesis)</span>
          <mat-icon class="text-xs text-slate-500">arrow_forward</mat-icon>
          <span class="px-2 py-1 bg-slate-900 rounded border border-slate-700 text-slate-300">PLAN (Frenet Lattice)</span>
          <mat-icon class="text-xs text-slate-500">arrow_forward</mat-icon>
          <span class="px-2 py-1 bg-slate-900 rounded border border-slate-700 text-rose-300 border-rose-800">VALIDATE (Safety Guard)</span>
          <mat-icon class="text-xs text-slate-500">arrow_forward</mat-icon>
          <span class="px-2 py-1 bg-slate-900 rounded border border-slate-700 text-emerald-300 border-emerald-800">CONTROL (Stanley/PID)</span>
          <mat-icon class="text-xs text-slate-500">arrow_forward</mat-icon>
          <span class="px-2 py-1 bg-slate-900 rounded border border-slate-700 text-blue-300">EXECUTE (Dynamics)</span>
        </div>
      </div>

      <!-- Rust Crates & R Modules Split -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
        <!-- Rust Core Crates List -->
        <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col gap-2">
          <div class="flex items-center justify-between text-slate-200 font-semibold text-[11px] border-b border-slate-900 pb-1.5">
            <span class="flex items-center gap-1 text-amber-400">
              <mat-icon class="text-sm">build</mat-icon> Rust Real-Time Core (rust-core/crates/)
            </span>
            <span class="text-slate-500 text-[10px]">Deterministic 100Hz</span>
          </div>
          <div class="grid grid-cols-2 gap-1.5 text-[10px] text-slate-300 max-h-56 overflow-y-auto pr-1">
            <div class="p-1 rounded bg-slate-900/60 border border-slate-800/80"><code>aa-types</code>: Core types</div>
            <div class="p-1 rounded bg-slate-900/60 border border-slate-800/80"><code>aa-math</code>: Linear algebra</div>
            <div class="p-1 rounded bg-slate-900/60 border border-slate-800/80"><code>aa-geometry</code>: SE(2)/SE(3)</div>
            <div class="p-1 rounded bg-slate-900/60 border border-slate-800/80"><code>aa-sensors</code>: Ingestion</div>
            <div class="p-1 rounded bg-slate-900/60 border border-slate-800/80"><code>aa-lidar</code>: 64ch PointCloud</div>
            <div class="p-1 rounded bg-slate-900/60 border border-slate-800/80"><code>aa-radar</code>: FMCW Doppler</div>
            <div class="p-1 rounded bg-slate-900/60 border border-slate-800/80"><code>aa-perception</code>: 3D Clust</div>
            <div class="p-1 rounded bg-slate-900/60 border border-slate-800/80"><code>aa-tracking</code>: Kalman/Hung</div>
            <div class="p-1 rounded bg-slate-900/60 border border-slate-800/80"><code>aa-fusion</code>: Multi-Sensor</div>
            <div class="p-1 rounded bg-slate-900/60 border border-slate-800/80"><code>aa-localisation</code>: EKF</div>
            <div class="p-1 rounded bg-slate-900/60 border border-slate-800/80"><code>aa-mapping</code>: HD Lanes</div>
            <div class="p-1 rounded bg-slate-900/60 border border-slate-800/80"><code>aa-prediction</code>: IDM / Gaps</div>
            <div class="p-1 rounded bg-slate-900/60 border border-slate-800/80"><code>aa-behaviour</code>: HFSM FSM</div>
            <div class="p-1 rounded bg-slate-900/60 border border-slate-800/80"><code>aa-motion</code>: Frenet Lattice</div>
            <div class="p-1 rounded bg-slate-900/60 border border-slate-800/80"><code>aa-control</code>: Stanley/PID</div>
            <div class="p-1 rounded bg-slate-900/60 border border-slate-800/80"><code>aa-safety</code>: Hard Invariants</div>
            <div class="p-1 rounded bg-slate-900/60 border border-slate-800/80"><code>aa-vehicle-dynamics</code>: Bicycle</div>
            <div class="p-1 rounded bg-slate-900/60 border border-slate-800/80"><code>aa-replay</code>: Time-Machine</div>
          </div>
        </div>

        <!-- R Statistical Layer List -->
        <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col gap-2">
          <div class="flex items-center justify-between text-slate-200 font-semibold text-[11px] border-b border-slate-900 pb-1.5">
            <span class="flex items-center gap-1 text-indigo-400">
              <mat-icon class="text-sm">functions</mat-icon> R Research & Validation (r-research/)
            </span>
            <span class="text-slate-500 text-[10px]">Statistical CRAN Spec</span>
          </div>
          <div class="grid grid-cols-2 gap-1.5 text-[10px] text-slate-300 max-h-56 overflow-y-auto pr-1">
            <div class="p-1 rounded bg-slate-900/60 border border-slate-800/80"><code>dataset.R</code>: Parquet I/O</div>
            <div class="p-1 rounded bg-slate-900/60 border border-slate-800/80"><code>uncertainty.R</code>: Monte Carlo</div>
            <div class="p-1 rounded bg-slate-900/60 border border-slate-800/80"><code>reliability.R</code>: Weibull</div>
            <div class="p-1 rounded bg-slate-900/60 border border-slate-800/80"><code>collision_metrics.R</code>: TTC/PET</div>
            <div class="p-1 rounded bg-slate-900/60 border border-slate-800/80"><code>tracking_metrics.R</code>: MOTA/P</div>
            <div class="p-1 rounded bg-slate-900/60 border border-slate-800/80"><code>prediction_metrics.R</code>: ADE/FDE</div>
            <div class="p-1 rounded bg-slate-900/60 border border-slate-800/80"><code>control_metrics.R</code>: CTE/Jerk</div>
            <div class="p-1 rounded bg-slate-900/60 border border-slate-800/80"><code>benchmark_runner.R</code>: A/B Test</div>
            <div class="p-1 rounded bg-slate-900/60 border border-slate-800/80"><code>report_generation.R</code>: Quarto</div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ArchitectureViewerComponent {}
