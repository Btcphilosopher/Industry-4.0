// ============================================================================
// AUREOM AUTONOMY — FRENET MOTION PLANNING & COST INSPECTOR COMPONENT
// ============================================================================

import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationEngineService } from '../../core/services/simulation-engine.service';

@Component({
  selector: 'app-motion-cost-inspector',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-slate-900 rounded-xl border border-slate-800 p-4 flex flex-col gap-4 text-xs font-mono shadow-xl">
      <!-- Section Header -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-2.5">
        <div class="flex items-center gap-2">
          <mat-icon class="text-cyan-400 text-lg">route</mat-icon>
          <span class="font-bold text-sm text-white">FRENET LATTICE MOTION PLANNING & COST OPTIMISATION</span>
          <span class="text-[10px] px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800/60 font-semibold">
            QUINTIC POLYNOMIAL
          </span>
        </div>
        <div class="flex items-center gap-3 text-slate-400 text-[11px]">
          <span>Horizon: <strong class="text-white">{{ simEngine.motionPlan().horizonSeconds }}s</strong></span>
          <span>Compute Time: <strong class="text-cyan-400">{{ simEngine.motionPlan().planningLatencyMs.toFixed(2) }}ms</strong></span>
          <span>Candidates: <strong class="text-white">{{ simEngine.motionPlan().candidateTrajectories.length }}</strong></span>
        </div>
      </div>

      <!-- Cost Function Mathematical Formulation -->
      <div class="bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-[11px] text-slate-300 flex items-center justify-between">
        <div class="flex items-center gap-2">
          <span class="text-cyan-400 font-bold">Cost Formulation:</span>
          <span class="text-slate-400 font-mono">
            J = 100·J_coll + 15·J_bound + 2.0·J_spd + 1.5·J_jerk + 3.0·J_curv + 4.0·J_lat - 2.5·J_prog
          </span>
        </div>
        <span class="text-emerald-400 font-bold text-[10px] uppercase">Strictly Inspectable</span>
      </div>

      <!-- Candidate Trajectories & Cost Breakdown Table -->
      <div class="bg-slate-950 rounded-lg border border-slate-800 overflow-hidden">
        <div class="px-3 py-2 bg-slate-900/80 border-b border-slate-800 font-semibold text-slate-300 text-xs flex justify-between items-center">
          <span>Evaluated Trajectory Candidates (Lattice Sampling)</span>
          <span class="text-[10px] text-emerald-400 font-semibold">Selected: {{ simEngine.motionPlan().chosenTrajectory.id }}</span>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full text-left text-[11px] font-mono">
            <thead class="bg-slate-900 text-slate-400 text-[10px] uppercase border-b border-slate-800">
              <tr>
                <th class="p-2">Candidate ID</th>
                <th class="p-2">Type</th>
                <th class="p-2">Collision Cost</th>
                <th class="p-2">Boundary</th>
                <th class="p-2">Speed Dev</th>
                <th class="p-2">Jerk</th>
                <th class="p-2">Curvature</th>
                <th class="p-2">Total Cost (J)</th>
                <th class="p-2">Status / Rejection</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
              @for (cand of simEngine.motionPlan().candidateTrajectories; track cand.id) {
                <tr
                  class="transition-colors"
                  [ngClass]="cand.id === simEngine.motionPlan().chosenTrajectory.id
                    ? 'bg-emerald-950/40 text-white font-bold border-l-2 border-emerald-400'
                    : 'hover:bg-slate-900/50 text-slate-300'"
                >
                  <td class="p-2 font-mono" [ngClass]="cand.id === simEngine.motionPlan().chosenTrajectory.id ? 'text-emerald-400' : 'text-slate-400'">
                    {{ cand.id }}
                  </td>
                  <td class="p-2">
                    <span class="px-1.5 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300 border border-slate-700">
                      {{ cand.type }}
                    </span>
                  </td>
                  <td class="p-2" [ngClass]="cand.costBreakdown.collisionRisk > 0 ? 'text-rose-400 font-bold' : 'text-slate-400'">
                    {{ cand.costBreakdown.collisionRisk.toFixed(1) }}
                  </td>
                  <td class="p-2 text-slate-400">{{ cand.costBreakdown.roadBoundary.toFixed(1) }}</td>
                  <td class="p-2 text-slate-400">{{ cand.costBreakdown.speedDeviation.toFixed(1) }}</td>
                  <td class="p-2 text-slate-400">{{ cand.costBreakdown.jerk.toFixed(1) }}</td>
                  <td class="p-2 text-slate-400">{{ cand.costBreakdown.curvature.toFixed(1) }}</td>
                  <td class="p-2 font-bold" [ngClass]="cand.id === simEngine.motionPlan().chosenTrajectory.id ? 'text-emerald-300' : 'text-slate-200'">
                    {{ cand.costTotal.toFixed(2) }}
                  </td>
                  <td class="p-2">
                    @if (cand.isValid) {
                      <span class="px-1.5 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800/50 font-bold">
                        {{ cand.id === simEngine.motionPlan().chosenTrajectory.id ? 'CHOSEN (OPTIMAL)' : 'VALID' }}
                      </span>
                    } @else {
                      <span class="text-rose-400 text-[10px] truncate block max-w-xs" [title]="cand.rejectionReason || 'Rejected'">
                        REJECTED: {{ cand.rejectionReason }}
                      </span>
                    }
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class MotionCostInspectorComponent {
  public simEngine = inject(SimulationEngineService);
}
