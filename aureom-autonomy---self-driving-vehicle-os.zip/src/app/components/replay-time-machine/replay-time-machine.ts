// ============================================================================
// AUREOM AUTONOMY — TIME-MACHINE & DETERMINISTIC REPLAY DEBUGGER
// ============================================================================

import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationEngineService } from '../../core/services/simulation-engine.service';

@Component({
  selector: 'app-replay-time-machine',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-slate-900 rounded-xl border border-slate-800 p-4 flex flex-col gap-4 text-xs font-mono shadow-xl">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-2.5">
        <div class="flex items-center gap-2">
          <mat-icon class="text-cyan-400 text-lg">history</mat-icon>
          <span class="font-bold text-sm text-white">DETERMINISTIC TIME-MACHINE & REPLAY DEBUGGER</span>
        </div>
        <div class="flex items-center gap-3 text-slate-400 text-[11px]">
          <span>Recorded Frames: <strong class="text-cyan-400">{{ simEngine.replayBuffer().length }}</strong></span>
          <span>Buffer Span: <strong class="text-white">{{ (simEngine.replayBuffer().length * 0.04).toFixed(1) }}s</strong></span>
        </div>
      </div>

      <!-- Interactive Timeline Slider -->
      <div class="bg-slate-950 p-4 rounded-lg border border-slate-800 flex flex-col gap-3">
        <div class="flex items-center justify-between">
          <span class="text-slate-300 font-semibold text-[11px] flex items-center gap-1.5">
            <mat-icon class="text-sm text-cyan-400">tune</mat-icon> Scrub Timeline to Millisecond State
          </span>
          <span class="text-cyan-400 font-bold font-mono">
            {{ simEngine.simTimeS().toFixed(2) }}s / {{ (simEngine.replayBuffer().length * 0.04).toFixed(2) }}s
          </span>
        </div>

        <input
          type="range"
          [min]="0"
          [max]="simEngine.replayBuffer().length - 1"
          [value]="simEngine.replayIndex() >= 0 ? simEngine.replayIndex() : simEngine.replayBuffer().length - 1"
          (input)="onSliderChange($event)"
          class="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-500"
        />

        <div class="flex items-center justify-between text-[10px] text-slate-500">
          <span>T = 0.00s</span>
          <span>Middle Buffer (T/2)</span>
          <span>Current Live Head</span>
        </div>
      </div>

      <!-- Replay Frame Inspection Details -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col gap-1.5">
          <span class="text-cyan-400 font-bold text-[11px]">Frame Snapshot Info</span>
          <div class="text-[11px] text-slate-300 space-y-1">
            <div class="flex justify-between"><span>Ego Velocity:</span> <span class="font-bold text-white">{{ (simEngine.vehicleState().velocity * 3.6).toFixed(1) }} km/h</span></div>
            <div class="flex justify-between"><span>Steering Angle:</span> <span class="font-bold text-white">{{ (simEngine.vehicleState().steerAngleRad * 180 / 3.14159).toFixed(2) }}°</span></div>
            <div class="flex justify-between"><span>Tracks Detected:</span> <span class="font-bold text-cyan-300">{{ simEngine.activeTracks().length }}</span></div>
          </div>
        </div>

        <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col gap-1.5">
          <span class="text-emerald-400 font-bold text-[11px]">Decision State</span>
          <div class="text-[11px] text-slate-300 space-y-1">
            <div class="flex justify-between"><span>Behaviour State:</span> <span class="font-bold text-emerald-300">{{ simEngine.behaviourDecision().state }}</span></div>
            <div class="flex justify-between"><span>Target Speed:</span> <span class="font-bold text-white">{{ (simEngine.behaviourDecision().targetSpeedMS * 3.6).toFixed(1) }} km/h</span></div>
            <div class="flex justify-between"><span>Safety Verdict:</span> <span class="font-bold text-white">{{ simEngine.safetyResult().verdict }}</span></div>
          </div>
        </div>

        <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col gap-1.5">
          <span class="text-purple-400 font-bold text-[11px]">Control Action</span>
          <div class="text-[11px] text-slate-300 space-y-1">
            <div class="flex justify-between"><span>Throttle Demand:</span> <span class="font-bold text-emerald-400">{{ (simEngine.controlCommand().throttle * 100).toFixed(0) }}%</span></div>
            <div class="flex justify-between"><span>Brake Demand:</span> <span class="font-bold text-rose-400">{{ (simEngine.controlCommand().brake * 100).toFixed(0) }}%</span></div>
            <div class="flex justify-between"><span>Cross-Track Error:</span> <span class="font-bold text-blue-300">{{ simEngine.controlCommand().crossTrackErrorM.toFixed(4) }} m</span></div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ReplayTimeMachineComponent {
  public simEngine = inject(SimulationEngineService);

  public onSliderChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    const index = parseInt(input.value, 10);
    this.simEngine.seekReplay(index);
  }
}
