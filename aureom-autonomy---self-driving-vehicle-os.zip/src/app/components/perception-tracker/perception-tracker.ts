// ============================================================================
// AUREOM AUTONOMY — PERCEPTION & MULTI-OBJECT TRACKING INSPECTOR
// ============================================================================

import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationEngineService } from '../../core/services/simulation-engine.service';

@Component({
  selector: 'app-perception-tracker',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-slate-900 rounded-xl border border-slate-800 p-4 flex flex-col gap-4 text-xs font-mono shadow-xl">
      <!-- Section Header -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-2.5">
        <div class="flex items-center gap-2">
          <mat-icon class="text-cyan-400 text-lg">track_changes</mat-icon>
          <span class="font-bold text-sm text-white">PERCEPTION & MULTI-OBJECT TRACKING ENGINE</span>
          <span class="text-[10px] px-1.5 py-0.5 rounded bg-blue-950 text-blue-300 border border-blue-800/60 font-semibold">
            KALMAN + HUNGARIAN
          </span>
        </div>
        <div class="flex items-center gap-3 text-slate-400 text-[11px]">
          <span>Active Tracks: <strong class="text-cyan-400">{{ simEngine.activeTracks().length }}</strong></span>
          <span>LiDAR Returns: <strong class="text-emerald-400">{{ simEngine.lidarFrame().points.length }}</strong></span>
          <span>Radar Targets: <strong class="text-amber-400">{{ simEngine.radarFrame().targets.length }}</strong></span>
        </div>
      </div>

      <!-- Sensor Pipeline Modalities Overview -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
        <!-- 64ch LiDAR Card -->
        <div class="bg-slate-950 p-3 rounded-lg border border-slate-800/80 flex flex-col gap-1.5">
          <div class="flex items-center justify-between text-slate-300 font-semibold text-[11px]">
            <span class="flex items-center gap-1.5 text-cyan-400">
              <mat-icon class="text-sm">radar</mat-icon> 64-CH ROOF LIDAR
            </span>
            <span class="text-emerald-400 text-[10px] px-1.5 py-0.2 rounded bg-emerald-950 border border-emerald-800/50">
              {{ simEngine.lidarFrame().valid ? 'SYNCHRONISED' : 'ATTENUATED' }}
            </span>
          </div>
          <div class="text-[11px] text-slate-400 space-y-1">
            <div class="flex justify-between"><span>Points in Sweep:</span> <span class="text-white font-bold">{{ simEngine.lidarFrame().points.length }}</span></div>
            <div class="flex justify-between"><span>Max Range:</span> <span class="text-white font-bold">{{ simEngine.lidarFrame().rangeM }}m</span></div>
            <div class="flex justify-between"><span>Ground Filter:</span> <span class="text-cyan-400">Bresenham Grid</span></div>
          </div>
        </div>

        <!-- 77GHz FMCW Radar Card -->
        <div class="bg-slate-950 p-3 rounded-lg border border-slate-800/80 flex flex-col gap-1.5">
          <div class="flex items-center justify-between text-slate-300 font-semibold text-[11px]">
            <span class="flex items-center gap-1.5 text-amber-400">
              <mat-icon class="text-sm">settings_input_antenna</mat-icon> 77GHz FMCW RADAR
            </span>
            <span class="text-emerald-400 text-[10px] px-1.5 py-0.2 rounded bg-emerald-950 border border-emerald-800/50">
              {{ simEngine.radarFrame().valid ? 'TRACKING' : 'JAMMED' }}
            </span>
          </div>
          <div class="text-[11px] text-slate-400 space-y-1">
            <div class="flex justify-between"><span>Doppler Targets:</span> <span class="text-white font-bold">{{ simEngine.radarFrame().targets.length }}</span></div>
            <div class="flex justify-between"><span>Azimuth FOV:</span> <span class="text-white font-bold">±45°</span></div>
            <div class="flex justify-between"><span>Radial Doppler:</span> <span class="text-amber-400">Direct Vel</span></div>
          </div>
        </div>

        <!-- Forward Camera Card -->
        <div class="bg-slate-950 p-3 rounded-lg border border-slate-800/80 flex flex-col gap-1.5">
          <div class="flex items-center justify-between text-slate-300 font-semibold text-[11px]">
            <span class="flex items-center gap-1.5 text-blue-400">
              <mat-icon class="text-sm">videocam</mat-icon> TRI-FOCAL VISION
            </span>
            <span class="text-emerald-400 text-[10px] px-1.5 py-0.2 rounded bg-emerald-950 border border-emerald-800/50">
              ONLINE
            </span>
          </div>
          <div class="text-[11px] text-slate-400 space-y-1">
            <div class="flex justify-between"><span>Traffic Lights:</span> <span class="text-white font-bold">Monitored</span></div>
            <div class="flex justify-between"><span>Lane Markings:</span> <span class="text-white font-bold">Polynomial 3rd</span></div>
            <div class="flex justify-between"><span>Inference Latency:</span> <span class="text-blue-400">12.4ms</span></div>
          </div>
        </div>
      </div>

      <!-- Active Track Lifecycle & Kalman State Table -->
      <div class="bg-slate-950 rounded-lg border border-slate-800 overflow-hidden">
        <div class="px-3 py-2 bg-slate-900/80 border-b border-slate-800 font-semibold text-slate-300 text-xs flex justify-between items-center">
          <span>Active Kalman Filter Tracks (State Vector [x, y, vx, vy])</span>
          <span class="text-[10px] text-slate-500 font-normal">Gating: Mahalanobis dM² &lt; 9.21 (99% Chi-Square)</span>
        </div>
        <div class="overflow-x-auto max-h-56">
          <table class="w-full text-left text-[11px] font-mono">
            <thead class="bg-slate-900 text-slate-400 text-[10px] uppercase border-b border-slate-800">
              <tr>
                <th class="p-2">Track ID</th>
                <th class="p-2">Class</th>
                <th class="p-2">Position [x, y]</th>
                <th class="p-2">Velocity [vx, vy]</th>
                <th class="p-2">Speed</th>
                <th class="p-2">Covariance Trace (P)</th>
                <th class="p-2">Status</th>
                <th class="p-2">Confidence</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
              @for (trk of simEngine.activeTracks(); track trk.trackId) {
                <tr class="hover:bg-slate-900/50 transition-colors">
                  <td class="p-2 font-bold text-cyan-400">{{ trk.trackId }}</td>
                  <td class="p-2">
                    <span class="px-1.5 py-0.5 rounded text-[10px] font-semibold"
                      [ngClass]="{
                        'bg-pink-950 text-pink-300 border border-pink-800/40': trk.class === 'PEDESTRIAN',
                        'bg-purple-950 text-purple-300 border border-purple-800/40': trk.class === 'CYCLIST',
                        'bg-amber-950 text-amber-300 border border-amber-800/40': trk.class === 'VEHICLE',
                        'bg-slate-800 text-slate-300 border border-slate-700': trk.class === 'OBSTACLE'
                      }">
                      {{ trk.class }}
                    </span>
                  </td>
                  <td class="p-2 text-slate-200">[{{ trk.position.x.toFixed(2) }}m, {{ trk.position.y.toFixed(2) }}m]</td>
                  <td class="p-2 text-slate-300">[{{ trk.velocity.x.toFixed(2) }}, {{ trk.velocity.y.toFixed(2) }}] m/s</td>
                  <td class="p-2 font-semibold text-white">{{ (getSpeed(trk) * 3.6).toFixed(1) }} km/h</td>
                  <td class="p-2 text-blue-300 font-mono">{{ getCovTrace(trk).toFixed(4) }} m²</td>
                  <td class="p-2">
                    <span class="px-1.5 py-0.5 rounded text-[10px] font-bold"
                      [ngClass]="trk.status === 'CONFIRMED' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800/40' : 'bg-slate-800 text-slate-400'">
                      {{ trk.status }}
                    </span>
                  </td>
                  <td class="p-2">
                    <div class="flex items-center gap-2">
                      <div class="w-12 bg-slate-800 rounded-full h-1.5 overflow-hidden">
                        <div class="bg-cyan-400 h-full rounded-full" [style.width.%]="trk.confidence * 100"></div>
                      </div>
                      <span class="text-slate-300 font-bold">{{ (trk.confidence * 100).toFixed(0) }}%</span>
                    </div>
                  </td>
                </tr>
              }
              @if (simEngine.activeTracks().length === 0) {
                <tr>
                  <td colspan="8" class="p-4 text-center text-slate-500 italic">No dynamic tracks currently in perception field of view</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class PerceptionTrackerComponent {
  public simEngine = inject(SimulationEngineService);

  public getSpeed(trk: any): number {
    return Math.hypot(trk.velocity.x, trk.velocity.y);
  }

  public getCovTrace(trk: any): number {
    return trk.covariance[0][0] + trk.covariance[1][1];
  }
}
