// ============================================================================
// AUREOM AUTONOMY — BEHAVIOUR PLANNING & EXPLAINABILITY ENGINE
// ============================================================================

import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationEngineService } from '../../core/services/simulation-engine.service';
import { BehaviourState } from '../../core/models/av-types';

@Component({
  selector: 'app-behavior-planning',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-slate-900 rounded-xl border border-slate-800 p-4 flex flex-col gap-4 text-xs font-mono shadow-xl">
      <!-- Section Header -->
      <div class="flex items-center justify-between border-b border-slate-800 pb-2.5">
        <div class="flex items-center gap-2">
          <mat-icon class="text-emerald-400 text-lg">alt_route</mat-icon>
          <span class="font-bold text-sm text-white">HIERARCHICAL BEHAVIOUR PLANNING STATE MACHINE</span>
        </div>
        <div class="flex items-center gap-2">
          <span class="text-slate-400 text-[11px]">Active State:</span>
          <span class="px-2.5 py-0.5 rounded font-bold text-xs bg-emerald-950 text-emerald-300 border border-emerald-700/60 shadow-sm animate-pulse">
            {{ simEngine.behaviourDecision().state }}
          </span>
        </div>
      </div>

      <!-- State Machine Visual Graph Nodes -->
      <div class="bg-slate-950 p-3 rounded-lg border border-slate-800/80">
        <div class="text-[11px] font-semibold text-slate-400 mb-2">BEHAVIOUR STATE TRANSITION NETWORK:</div>
        <div class="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-2">
          @for (st of states; track st.id) {
            <div
              class="p-2 rounded border text-center transition-all duration-300"
              [ngClass]="simEngine.behaviourDecision().state === st.id
                ? 'bg-emerald-900/60 border-emerald-400 text-emerald-200 shadow-md font-bold scale-[1.03]'
                : 'bg-slate-900/50 border-slate-800 text-slate-500 font-normal'"
            >
              <div class="text-[10px] truncate">{{ st.label }}</div>
            </div>
          }
        </div>
      </div>

      <!-- Decision Breakdown & Explainable Reason Code -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
        <!-- Reason Code Card -->
        <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col gap-1.5 md:col-span-2">
          <div class="flex items-center justify-between text-slate-300 font-semibold text-[11px]">
            <span class="flex items-center gap-1.5 text-cyan-400">
              <mat-icon class="text-sm">psychology</mat-icon> EXPLAINABLE DECISION REASON CODE
            </span>
            <span class="text-slate-500 text-[10px]">Deterministic Policy</span>
          </div>
          <div class="bg-slate-900/80 p-2.5 rounded border border-slate-800 text-cyan-300 font-mono text-xs break-all">
            {{ simEngine.behaviourDecision().reasonCode }}
          </div>
          <p class="text-[10px] text-slate-400 mt-1">
            Every tactical behaviour decision is accompanied by a verifiable reason code referencing spatial geometry and road traffic rules.
          </p>
        </div>

        <!-- Target Objectives Card -->
        <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 flex flex-col gap-2">
          <span class="text-purple-400 font-bold text-[11px] uppercase tracking-wider flex items-center gap-1">
            <mat-icon class="text-sm">flag</mat-icon> Tactical Targets
          </span>
          <div class="space-y-1.5 text-[11px]">
            <div class="flex justify-between border-b border-slate-900 pb-1">
              <span class="text-slate-400">Target Lane:</span>
              <span class="text-white font-bold">{{ simEngine.behaviourDecision().targetLaneId }}</span>
            </div>
            <div class="flex justify-between border-b border-slate-900 pb-1">
              <span class="text-slate-400">Target Speed:</span>
              <span class="text-emerald-400 font-bold">{{ (simEngine.behaviourDecision().targetSpeedMS * 3.6).toFixed(1) }} km/h</span>
            </div>
            <div class="flex justify-between border-b border-slate-900 pb-1">
              <span class="text-slate-400">IDM Following Gap:</span>
              <span class="text-blue-300 font-bold">{{ simEngine.behaviourDecision().safetyMarginM.toFixed(1) }} m</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Policy Confidence:</span>
              <span class="text-cyan-400 font-bold">{{ (simEngine.behaviourDecision().confidence * 100).toFixed(0) }}%</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class BehaviorPlanningComponent {
  public simEngine = inject(SimulationEngineService);

  public states: { id: BehaviourState; label: string }[] = [
    { id: 'INITIALISING', label: 'INITIALISING' },
    { id: 'FOLLOW_LANE', label: 'FOLLOW_LANE' },
    { id: 'FOLLOW_VEHICLE', label: 'FOLLOW_VEHICLE' },
    { id: 'APPROACH_CROSSWALK', label: 'CROSSWALK_YIELD' },
    { id: 'APPROACH_INTERSECTION', label: 'APPROACH_JUNCTION' },
    { id: 'WAIT_AT_RED_LIGHT', label: 'WAIT_RED_LIGHT' },
    { id: 'YIELD', label: 'YIELD_TRAFFIC' },
    { id: 'CHANGE_LANE_LEFT', label: 'LANE_CHANGE_LEFT' },
    { id: 'CHANGE_LANE_RIGHT', label: 'LANE_CHANGE_RIGHT' },
    { id: 'OVERTAKE_SIMULATION', label: 'OVERTAKE_LATTICE' },
    { id: 'EMERGENCY_STOP_SIMULATION', label: 'EMERGENCY_STOP' },
    { id: 'SAFE_HALT', label: 'SAFE_HALT' }
  ];
}
