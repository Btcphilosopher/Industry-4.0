// ============================================================================
// AUREOM AUTONOMY — HIGH-PRECISION 2D/3D SIMULATION CANVAS VIEWPORT
// Renders:
//   - HD Vector Road Network (Lanes, Curbs, Crosswalks, Stop Lines)
//   - Real-time Traffic Lights
//   - 64-Channel LiDAR Point Cloud Sweep (Ground & Obstacle Returns)
//   - FMCW Radar Doppler Velocity Vectors & Beam Cones
//   - Multi-Sensor 3D Tracked Bounding Boxes & Covariance Error Ellipses
//   - Frenet Motion Planning Candidate Trajectory Lattice & Chosen Optimal Path
//   - Ego Vehicle with Steerable Wheels & Pose
// ============================================================================

import { AfterViewInit, ChangeDetectionStrategy, Component, ElementRef, inject, OnDestroy, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationEngineService } from '../../core/services/simulation-engine.service';
import { WorldMapService } from '../../core/services/world-map.service';

@Component({
  selector: 'app-simulation-viewport',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-[540px] bg-slate-950 rounded-xl overflow-hidden border border-slate-800 shadow-2xl flex flex-col">
      <!-- Top Viewport Control Bar -->
      <div class="absolute top-3 left-3 right-3 z-10 flex flex-wrap items-center justify-between gap-2 pointer-events-none">
        <!-- View Mode Buttons -->
        <div class="flex items-center gap-1 bg-slate-900/90 backdrop-blur px-2 py-1 rounded-lg border border-slate-700 pointer-events-auto shadow-lg text-xs font-mono">
          <span class="text-slate-400 font-semibold px-1 text-[11px]">VIEW:</span>
          @for (mode of viewModes; track mode.id) {
            <button
              (click)="activeViewMode = mode.id"
              class="px-2.5 py-1 rounded font-medium transition-colors cursor-pointer flex items-center gap-1"
              [ngClass]="activeViewMode === mode.id ? 'bg-cyan-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'"
            >
              <mat-icon class="text-xs">{{ mode.icon }}</mat-icon>
              {{ mode.label }}
            </button>
          }
        </div>

        <!-- Layer Toggles -->
        <div class="flex items-center gap-1 bg-slate-900/90 backdrop-blur px-2.5 py-1 rounded-lg border border-slate-700 pointer-events-auto shadow-lg text-xs font-mono">
          <label class="flex items-center gap-1.5 text-slate-300 cursor-pointer text-[11px] select-none mr-2">
            <input type="checkbox" [checked]="showLidar" (change)="showLidar = !showLidar" class="rounded text-cyan-600 accent-cyan-500">
            <span>LiDAR</span>
          </label>
          <label class="flex items-center gap-1.5 text-slate-300 cursor-pointer text-[11px] select-none mr-2">
            <input type="checkbox" [checked]="showRadar" (change)="showRadar = !showRadar" class="rounded text-cyan-600 accent-cyan-500">
            <span>Radar</span>
          </label>
          <label class="flex items-center gap-1.5 text-slate-300 cursor-pointer text-[11px] select-none mr-2">
            <input type="checkbox" [checked]="showTrajectoryLattice" (change)="showTrajectoryLattice = !showTrajectoryLattice" class="rounded text-cyan-600 accent-cyan-500">
            <span>Plan Lattice</span>
          </label>
          <label class="flex items-center gap-1.5 text-slate-300 cursor-pointer text-[11px] select-none">
            <input type="checkbox" [checked]="showOccupancy" (change)="showOccupancy = !showOccupancy" class="rounded text-cyan-600 accent-cyan-500">
            <span>Covariance</span>
          </label>
        </div>

        <!-- Zoom & Center Controls -->
        <div class="flex items-center gap-1 bg-slate-900/90 backdrop-blur p-1 rounded-lg border border-slate-700 pointer-events-auto shadow-lg">
          <button (click)="zoomIn()" title="Zoom In" class="p-1 rounded text-slate-300 hover:bg-slate-800 flex items-center">
            <mat-icon class="text-sm">zoom_in</mat-icon>
          </button>
          <button (click)="zoomOut()" title="Zoom Out" class="p-1 rounded text-slate-300 hover:bg-slate-800 flex items-center">
            <mat-icon class="text-sm">zoom_out</mat-icon>
          </button>
          <button (click)="resetCamera()" title="Recenter Ego" class="p-1 rounded text-slate-300 hover:bg-slate-800 flex items-center">
            <mat-icon class="text-sm">center_focus_strong</mat-icon>
          </button>
        </div>
      </div>

      <!-- Main High-Resolution Canvas -->
      <canvas
        #simCanvas
        class="w-full h-full cursor-grab active:cursor-grabbing bg-[#050811]"
        (mousedown)="onMouseDown($event)"
        (mousemove)="onMouseMove($event)"
        (mouseup)="onMouseUp()"
        (wheel)="onWheel($event)"
      ></canvas>

      <!-- Bottom Real-time Telemetry HUD -->
      <div class="absolute bottom-3 left-3 right-3 z-10 flex items-center justify-between pointer-events-none text-xs font-mono">
        <div class="flex items-center gap-2 bg-slate-900/90 backdrop-blur px-3 py-1.5 rounded-lg border border-slate-800 pointer-events-auto text-slate-300">
          <span class="text-cyan-400 font-bold flex items-center gap-1">
            <span class="w-2 h-2 rounded-full bg-cyan-400 animate-ping"></span>
            LATERAL CONTROLLER: {{ simEngine.controlCommand().controllerMode }}
          </span>
          <span class="text-slate-600">|</span>
          <span>Steer: <strong class="text-white">{{ (simEngine.vehicleState().steerAngleRad * 180 / 3.14159).toFixed(1) }}°</strong></span>
          <span class="text-slate-600">|</span>
          <span>Cross-Track Err: <strong class="text-white">{{ simEngine.controlCommand().crossTrackErrorM.toFixed(3) }}m</strong></span>
          <span class="text-slate-600">|</span>
          <span>Slip Angle β: <strong class="text-amber-400">{{ (simEngine.vehicleState().slipAngleRad * 180 / 3.14159).toFixed(2) }}°</strong></span>
        </div>

        <div class="flex items-center gap-2 bg-slate-900/90 backdrop-blur px-3 py-1.5 rounded-lg border border-slate-800 pointer-events-auto text-slate-300">
          <span>Active Behaviour: <strong class="text-emerald-400 font-bold">{{ simEngine.behaviourDecision().state }}</strong></span>
          <span class="text-slate-600">|</span>
          <span>Min TTC: <strong [ngClass]="simEngine.safetyResult().timeToCollisionS < 2.0 ? 'text-rose-400' : 'text-emerald-400'">{{ simEngine.safetyResult().timeToCollisionS.toFixed(2) }}s</strong></span>
        </div>
      </div>
    </div>
  `
})
export class SimulationViewportComponent implements AfterViewInit, OnDestroy {
  @ViewChild('simCanvas', { static: true }) canvasRef!: ElementRef<HTMLCanvasElement>;

  public simEngine = inject(SimulationEngineService);
  private mapService = inject(WorldMapService);

  public activeViewMode: 'BEV' | 'CHASE' | 'HUD' = 'BEV';
  public viewModes = [
    { id: 'BEV' as const, label: "Bird's-Eye (BEV)", icon: 'map' },
    { id: 'CHASE' as const, label: 'Ego Follow', icon: 'videocam' },
    { id: 'HUD' as const, label: 'Front Sensor HUD', icon: 'dashboard' }
  ];

  public showLidar = true;
  public showRadar = true;
  public showTrajectoryLattice = true;
  public showOccupancy = true;

  private scale = 8.5; // pixels per metre
  private cameraOffset = { x: 0, y: 0 };
  private isDragging = false;
  private dragStart = { x: 0, y: 0 };
  private animFrameId: number | null = null;

  ngAfterViewInit(): void {
    this.renderLoop();
  }

  ngOnDestroy(): void {
    if (this.animFrameId) cancelAnimationFrame(this.animFrameId);
  }

  public zoomIn(): void {
    this.scale = Math.min(25, this.scale * 1.25);
  }

  public zoomOut(): void {
    this.scale = Math.max(3, this.scale * 0.8);
  }

  public resetCamera(): void {
    const ego = this.simEngine.vehicleState();
    this.cameraOffset = { x: -ego.pose.x * this.scale + 200, y: -ego.pose.y * this.scale + 250 };
  }

  public onMouseDown(event: MouseEvent): void {
    this.isDragging = true;
    this.dragStart = { x: event.clientX - this.cameraOffset.x, y: event.clientY - this.cameraOffset.y };
  }

  public onMouseMove(event: MouseEvent): void {
    if (this.isDragging) {
      this.cameraOffset.x = event.clientX - this.dragStart.x;
      this.cameraOffset.y = event.clientY - this.dragStart.y;
    }
  }

  public onMouseUp(): void {
    this.isDragging = false;
  }

  public onWheel(event: WheelEvent): void {
    event.preventDefault();
    const zoomFactor = event.deltaY < 0 ? 1.15 : 0.87;
    this.scale = Math.max(3, Math.min(30, this.scale * zoomFactor));
  }

  private renderLoop = (): void => {
    this.draw();
    this.animFrameId = requestAnimationFrame(this.renderLoop);
  };

  private draw(): void {
    const canvas = this.canvasRef?.nativeElement;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Resize canvas if needed
    if (canvas.width !== canvas.clientWidth || canvas.height !== canvas.clientHeight) {
      canvas.width = canvas.clientWidth;
      canvas.height = canvas.clientHeight;
    }

    const w = canvas.width;
    const h = canvas.height;
    const ego = this.simEngine.vehicleState();
    const map = this.mapService.getMap();
    const tracks = this.simEngine.activeTracks();
    const lidar = this.simEngine.lidarFrame();
    const radar = this.simEngine.radarFrame();
    const motion = this.simEngine.motionPlan();

    // Auto-follow ego vehicle camera
    if (this.activeViewMode === 'CHASE' || (this.activeViewMode === 'BEV' && !this.isDragging)) {
      this.cameraOffset.x = w * 0.3 - ego.pose.x * this.scale;
      this.cameraOffset.y = h * 0.5 - ego.pose.y * this.scale;
    }

    // Clear Canvas with subtle tech background
    ctx.fillStyle = '#030712';
    ctx.fillRect(0, 0, w, h);

    // Save context for transform matrix
    ctx.save();
    ctx.translate(this.cameraOffset.x, this.cameraOffset.y);

    // 1. Draw Grid Lines (10m intervals)
    ctx.strokeStyle = '#0f172a';
    ctx.lineWidth = 1;
    const gridStep = 10 * this.scale;
    for (let gx = -100 * this.scale; gx < 800 * this.scale; gx += gridStep) {
      ctx.beginPath();
      ctx.moveTo(gx, -100 * this.scale);
      ctx.lineTo(gx, 200 * this.scale);
      ctx.stroke();
    }
    for (let gy = -50 * this.scale; gy < 100 * this.scale; gy += gridStep) {
      ctx.beginPath();
      ctx.moveTo(-100 * this.scale, gy);
      ctx.lineTo(800 * this.scale, gy);
      ctx.stroke();
    }

    // 2. Draw HD Road Network
    // Road Asphalt base
    ctx.fillStyle = '#111827';
    ctx.fillRect(0, 11 * this.scale, 600 * this.scale, 10 * this.scale);

    // Curbs
    ctx.strokeStyle = '#475569';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(0, 11 * this.scale);
    ctx.lineTo(600 * this.scale, 11 * this.scale);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(0, 21 * this.scale);
    ctx.lineTo(600 * this.scale, 21 * this.scale);
    ctx.stroke();

    // Lane dividing lines
    // Dashed center line (between cruising y=15 and passing y=18.75)
    ctx.strokeStyle = '#94a3b8';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([4 * this.scale, 4 * this.scale]);
    ctx.beginPath();
    ctx.moveTo(0, 16.875 * this.scale);
    ctx.lineTo(600 * this.scale, 16.875 * this.scale);
    ctx.stroke();
    ctx.setLineDash([]);

    // Solid outer edge lines
    ctx.strokeStyle = '#f8fafc';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, 13.125 * this.scale);
    ctx.lineTo(600 * this.scale, 13.125 * this.scale);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(0, 20.625 * this.scale);
    ctx.lineTo(600 * this.scale, 20.625 * this.scale);
    ctx.stroke();

    // Draw Crosswalk at x=82m
    ctx.fillStyle = '#cbd5e1';
    for (let cy = 11.5; cy < 20.5; cy += 1.2) {
      ctx.fillRect(80 * this.scale, cy * this.scale, 4 * this.scale, 0.6 * this.scale);
    }

    // Draw Traffic Lights
    for (const tl of map.trafficLights) {
      // Stop line
      ctx.strokeStyle = tl.state === 'RED' ? '#ef4444' : tl.state === 'YELLOW' ? '#f59e0b' : '#10b981';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(tl.stopLineX * this.scale, 11 * this.scale);
      ctx.lineTo(tl.stopLineX * this.scale, 16.875 * this.scale);
      ctx.stroke();

      // Signal beacon
      ctx.fillStyle = tl.state === 'RED' ? '#ef4444' : tl.state === 'YELLOW' ? '#f59e0b' : '#10b981';
      ctx.beginPath();
      ctx.arc(tl.position.x * this.scale, (tl.position.y - 4.5) * this.scale, 6, 0, Math.PI * 2);
      ctx.fill();

      // Signal Label
      ctx.fillStyle = '#f8fafc';
      ctx.font = '10px monospace';
      ctx.fillText(`${tl.state} (${tl.timeRemainingS.toFixed(0)}s)`, tl.position.x * this.scale - 15, (tl.position.y - 5.5) * this.scale);
    }

    // 3. Draw FMCW Radar Targets & Sensor FOV Cones
    if (this.showRadar) {
      // Radar Cone (45 deg)
      ctx.fillStyle = 'rgba(245, 158, 11, 0.08)';
      ctx.beginPath();
      ctx.moveTo(ego.pose.x * this.scale, ego.pose.y * this.scale);
      ctx.arc(ego.pose.x * this.scale, ego.pose.y * this.scale, 80 * this.scale, ego.pose.yaw - 0.4, ego.pose.yaw + 0.4);
      ctx.closePath();
      ctx.fill();

      // Radar velocity vectors
      for (const tgt of radar.targets) {
        const tx = ego.pose.x + tgt.rangeM * Math.cos(ego.pose.yaw + tgt.azimuthRad);
        const ty = ego.pose.y + tgt.rangeM * Math.sin(ego.pose.yaw + tgt.azimuthRad);

        ctx.fillStyle = '#f59e0b';
        ctx.beginPath();
        ctx.arc(tx * this.scale, ty * this.scale, 4, 0, Math.PI * 2);
        ctx.fill();

        // Relative velocity arrow
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(tx * this.scale, ty * this.scale);
        ctx.lineTo(
          (tx + tgt.radialVelocityMS * 0.4 * Math.cos(ego.pose.yaw)) * this.scale,
          (ty + tgt.radialVelocityMS * 0.4 * Math.sin(ego.pose.yaw)) * this.scale
        );
        ctx.stroke();
      }
    }

    // 4. Draw 64-Channel LiDAR Point Cloud Sweep
    if (this.showLidar && lidar.valid) {
      for (const pt of lidar.points) {
        if (pt.isGround) {
          ctx.fillStyle = 'rgba(6, 182, 212, 0.25)'; // Dark Cyan Ground
          ctx.fillRect(pt.x * this.scale - 1, pt.y * this.scale - 1, 2, 2);
        } else {
          ctx.fillStyle = pt.intensity > 180 ? '#22c55e' : '#eab308'; // Obstacle returns
          ctx.fillRect(pt.x * this.scale - 1.5, pt.y * this.scale - 1.5, 3, 3);
        }
      }
    }

    // 5. Draw Motion Planning Candidate Trajectory Lattice
    if (this.showTrajectoryLattice && motion.candidateTrajectories) {
      for (const cand of motion.candidateTrajectories) {
        if (!cand.points || cand.points.length === 0) continue;
        ctx.strokeStyle = cand.isValid ? 'rgba(148, 163, 184, 0.3)' : 'rgba(239, 68, 68, 0.25)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        for (let p = 0; p < cand.points.length; p++) {
          const pt = cand.points[p];
          if (p === 0) ctx.moveTo(pt.x * this.scale, pt.y * this.scale);
          else ctx.lineTo(pt.x * this.scale, pt.y * this.scale);
        }
        ctx.stroke();
      }
    }

    // Draw Chosen Optimal Trajectory (High-contrast emerald ribbon)
    if (motion.chosenTrajectory && motion.chosenTrajectory.points) {
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 3.5;
      ctx.beginPath();
      for (let p = 0; p < motion.chosenTrajectory.points.length; p++) {
        const pt = motion.chosenTrajectory.points[p];
        if (p === 0) ctx.moveTo(pt.x * this.scale, pt.y * this.scale);
        else ctx.lineTo(pt.x * this.scale, pt.y * this.scale);
      }
      ctx.stroke();

      // Trajectory Waypoint discs with speed color coding
      for (let p = 0; p < motion.chosenTrajectory.points.length; p += 4) {
        const pt = motion.chosenTrajectory.points[p];
        ctx.fillStyle = '#34d399';
        ctx.beginPath();
        ctx.arc(pt.x * this.scale, pt.y * this.scale, 3, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // 6. Draw Tracked Dynamic Actors & 3D Bounding Boxes
    for (const trk of tracks) {
      ctx.save();
      ctx.translate(trk.position.x * this.scale, trk.position.y * this.scale);
      ctx.rotate(trk.headingRad);

      // Covariance Error Ellipse
      if (this.showOccupancy) {
        ctx.strokeStyle = 'rgba(56, 189, 248, 0.4)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.ellipse(0, 0, Math.sqrt(trk.covariance[0][0]) * this.scale * 2, Math.sqrt(trk.covariance[1][1]) * this.scale * 2, 0, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Bounding Box
      const len = trk.dimensions.x * this.scale;
      const wid = trk.dimensions.y * this.scale;

      ctx.fillStyle = trk.class === 'PEDESTRIAN' ? 'rgba(236, 72, 153, 0.85)' : trk.class === 'CYCLIST' ? 'rgba(168, 85, 247, 0.85)' : 'rgba(249, 115, 22, 0.85)';
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.5;
      ctx.fillRect(-len / 2, -wid / 2, len, wid);
      ctx.strokeRect(-len / 2, -wid / 2, len, wid);

      // Heading indicator
      ctx.strokeStyle = '#ffffff';
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(len / 2 + 6, 0);
      ctx.stroke();

      ctx.restore();

      // Track Label
      ctx.fillStyle = '#f8fafc';
      ctx.font = '10px monospace';
      const speedKmh = (Math.hypot(trk.velocity.x, trk.velocity.y) * 3.6).toFixed(0);
      ctx.fillText(`${trk.trackId} [${trk.class}] ${speedKmh} km/h`, trk.position.x * this.scale - 18, (trk.position.y - 2.5) * this.scale);

      // Draw predicted future trajectory line
      if (trk.predictedPath) {
        ctx.strokeStyle = 'rgba(249, 115, 22, 0.5)';
        ctx.lineWidth = 1.5;
        ctx.setLineDash([2, 2]);
        ctx.beginPath();
        for (let p = 0; p < trk.predictedPath.length; p++) {
          const pt = trk.predictedPath[p];
          if (p === 0) ctx.moveTo(pt.x * this.scale, pt.y * this.scale);
          else ctx.lineTo(pt.x * this.scale, pt.y * this.scale);
        }
        ctx.stroke();
        ctx.setLineDash([]);
      }
    }

    // 7. Draw Ego Autonomous Vehicle (Digital Twin)
    ctx.save();
    ctx.translate(ego.pose.x * this.scale, ego.pose.y * this.scale);
    ctx.rotate(ego.pose.yaw);

    const egoLen = 4.88 * this.scale;
    const egoWid = 1.92 * this.scale;

    // Headlights Beam Projection
    const grad = ctx.createRadialGradient(egoLen / 2, 0, 5, egoLen / 2 + 25 * this.scale, 0, 30 * this.scale);
    grad.addColorStop(0, 'rgba(255, 255, 255, 0.4)');
    grad.addColorStop(1, 'rgba(255, 255, 255, 0)');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(egoLen / 2, -egoWid / 2);
    ctx.lineTo(egoLen / 2 + 25 * this.scale, -egoWid * 2.5);
    ctx.lineTo(egoLen / 2 + 25 * this.scale, egoWid * 2.5);
    ctx.lineTo(egoLen / 2, egoWid / 2);
    ctx.closePath();
    ctx.fill();

    // Vehicle Body Chassis
    ctx.fillStyle = '#0284c7'; // Aureom Blue Body
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(-egoLen / 2, -egoWid / 2, egoLen, egoWid, 6);
    ctx.fill();
    ctx.stroke();

    // Glass Windscreen & Roof
    ctx.fillStyle = '#082f49';
    ctx.beginPath();
    ctx.roundRect(-egoLen * 0.15, -egoWid * 0.4, egoLen * 0.55, egoWid * 0.8, 3);
    ctx.fill();

    // Front Steerable Wheels
    const wheelLen = 0.85 * this.scale;
    const wheelWid = 0.3 * this.scale;
    const frontAxleX = 1.45 * this.scale;
    const rearAxleX = -1.5 * this.scale;
    const halfTrack = (1.62 / 2) * this.scale;

    // Front Left Wheel (Steered)
    ctx.save();
    ctx.translate(frontAxleX, -halfTrack);
    ctx.rotate(ego.steerAngleRad);
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(-wheelLen / 2, -wheelWid / 2, wheelLen, wheelWid);
    ctx.restore();

    // Front Right Wheel (Steered)
    ctx.save();
    ctx.translate(frontAxleX, halfTrack);
    ctx.rotate(ego.steerAngleRad);
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(-wheelLen / 2, -wheelWid / 2, wheelLen, wheelWid);
    ctx.restore();

    // Rear Wheels (Fixed)
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(rearAxleX - wheelLen / 2, -halfTrack - wheelWid / 2, wheelLen, wheelWid);
    ctx.fillRect(rearAxleX - wheelLen / 2, halfTrack - wheelWid / 2, wheelLen, wheelWid);

    // Roof LiDAR Sensor Dome
    ctx.fillStyle = '#06b6d4';
    ctx.beginPath();
    ctx.arc(0, 0, 4, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();

    ctx.restore();
  }
}
