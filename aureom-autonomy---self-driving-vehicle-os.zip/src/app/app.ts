// ============================================================================
// AUREOM AUTONOMY — ROOT APPLICATION COMPONENT
// Serious, research-grade autonomous-vehicle operating system control workbench.
// ============================================================================

import { ChangeDetectionStrategy, Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { HeaderComponent } from './components/header/header';
import { SimulationViewportComponent } from './components/simulation-viewport/simulation-viewport';
import { PerceptionTrackerComponent } from './components/perception-tracker/perception-tracker';
import { FusionLocalisationComponent } from './components/fusion-localisation/fusion-localisation';
import { BehaviorPlanningComponent } from './components/behavior-planning/behavior-planning';
import { MotionCostInspectorComponent } from './components/motion-cost-inspector/motion-cost-inspector';
import { VehicleTelemetryComponent } from './components/vehicle-telemetry/vehicle-telemetry';
import { SafetyFaultInjectorComponent } from './components/safety-fault-injector/safety-fault-injector';
import { RWorkbenchComponent } from './components/r-workbench/r-workbench';
import { ScenarioLabComponent } from './components/scenario-lab/scenario-lab';
import { ReplayTimeMachineComponent } from './components/replay-time-machine/replay-time-machine';
import { ArchitectureViewerComponent } from './components/architecture-viewer/architecture-viewer';

export type ActiveTab =
  | 'OVERVIEW'
  | 'PERCEPTION'
  | 'LOCALISATION'
  | 'PLANNING'
  | 'DYNAMICS'
  | 'SAFETY'
  | 'R_WORKBENCH'
  | 'SCENARIOS'
  | 'REPLAY'
  | 'ARCHITECTURE';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    MatIconModule,
    HeaderComponent,
    SimulationViewportComponent,
    PerceptionTrackerComponent,
    FusionLocalisationComponent,
    BehaviorPlanningComponent,
    MotionCostInspectorComponent,
    VehicleTelemetryComponent,
    SafetyFaultInjectorComponent,
    RWorkbenchComponent,
    ScenarioLabComponent,
    ReplayTimeMachineComponent,
    ArchitectureViewerComponent
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  public activeTab = signal<ActiveTab>('OVERVIEW');

  public navTabs: { id: ActiveTab; label: string; icon: string; tag?: string }[] = [
    { id: 'OVERVIEW', label: 'Overview & Simulation', icon: 'dashboard' },
    { id: 'PERCEPTION', label: 'Perception & Tracking', icon: 'track_changes', tag: 'Kalman' },
    { id: 'LOCALISATION', label: 'Localisation & Fusion', icon: 'my_location', tag: 'EKF' },
    { id: 'PLANNING', label: 'Behaviour & Planning', icon: 'alt_route', tag: 'Frenet' },
    { id: 'DYNAMICS', label: 'Vehicle Dynamics', icon: 'directions_car', tag: 'Bicycle' },
    { id: 'SAFETY', label: 'Safety & Faults', icon: 'shield', tag: 'Guards' },
    { id: 'R_WORKBENCH', label: 'R Analytics & Monte Carlo', icon: 'insights', tag: 'R 4.4+' },
    { id: 'SCENARIOS', label: 'Scenario Lab', icon: 'science' },
    { id: 'REPLAY', label: 'Replay Debugger', icon: 'history' },
    { id: 'ARCHITECTURE', label: 'Architecture & Workspace', icon: 'account_tree' }
  ];

  public setTab(tab: ActiveTab): void {
    this.activeTab.set(tab);
  }
}
