// ============================================================================
// AUREOM AUTONOMY — HD ROAD NETWORK & WORLD MODEL OCCUPANCY SERVICE
// Provides:
//   - HD Vector Lanes with Waypoint Interpolation & Curvature
//   - Junction Topologies & Signalized Stop Lines
//   - Multi-Layer Log-Odds Dynamic 2D Occupancy Grid
// ============================================================================

import { Injectable } from '@angular/core';
import { Lane, RoadNetworkMap, TrafficLight, Vector2D, Waypoint } from '../models/av-types';

@Injectable({
  providedIn: 'root'
})
export class WorldMapService {
  private map: RoadNetworkMap;

  constructor() {
    this.map = this.buildAureomCityMap();
  }

  public getMap(): RoadNetworkMap {
    return this.map;
  }

  private buildAureomCityMap(): RoadNetworkMap {
    const lanes: Lane[] = [];

    // Lane 0: Main Urban Cruising Lane (y = 15m)
    const waypointsLane0: Waypoint[] = [];
    for (let x = 0; x <= 600; x += 5) {
      waypointsLane0.push({
        x,
        y: 15.0,
        heading: 0,
        curvature: 0,
        s: x,
        speedLimitMS: 13.88 // 50 km/h
      });
    }

    lanes.push({
      id: 'lane_main_cruising',
      name: 'South Avenue Cruising Lane',
      laneIndex: 0,
      waypoints: waypointsLane0,
      leftBoundaryType: 'DASHED',
      rightBoundaryType: 'SOLID',
      speedLimitMS: 13.88,
      successorLaneIds: [],
      predecessorLaneIds: [],
      adjacentLeftLaneId: 'lane_main_passing',
      isIntersection: false
    });

    // Lane 1: Main Passing / Left Lane (y = 18.75m)
    const waypointsLane1: Waypoint[] = [];
    for (let x = 0; x <= 600; x += 5) {
      waypointsLane1.push({
        x,
        y: 18.75,
        heading: 0,
        curvature: 0,
        s: x,
        speedLimitMS: 16.67 // 60 km/h
      });
    }

    lanes.push({
      id: 'lane_main_passing',
      name: 'South Avenue Overtaking Lane',
      laneIndex: 1,
      waypoints: waypointsLane1,
      leftBoundaryType: 'SOLID',
      rightBoundaryType: 'DASHED',
      speedLimitMS: 16.67,
      successorLaneIds: [],
      predecessorLaneIds: [],
      adjacentRightLaneId: 'lane_main_cruising',
      isIntersection: false
    });

    const trafficLights: TrafficLight[] = [
      {
        id: 'tl_junction_1',
        laneId: 'lane_main_cruising',
        position: { x: 110, y: 15 },
        state: 'GREEN',
        timeRemainingS: 8,
        stopLineX: 104,
        stopLineY: 15
      },
      {
        id: 'tl_junction_2',
        laneId: 'lane_main_cruising',
        position: { x: 280, y: 15 },
        state: 'RED',
        timeRemainingS: 12,
        stopLineX: 274,
        stopLineY: 15
      }
    ];

    return {
      id: 'aureom_metropolis_hd_v2',
      name: 'Aureom Metropolis HD Digital Twin Map',
      lanes,
      trafficLights,
      speedLimitDefaultMS: 13.88,
      bounds: { minX: 0, maxX: 600, minY: 0, maxY: 40 }
    };
  }

  /**
   * Find nearest lane waypoint for a given world coordinate
   */
  public getClosestWaypoint(pos: Vector2D, laneId = 'lane_main_cruising'): { waypoint: Waypoint; index: number; dist: number } {
    const lane = this.map.lanes.find(l => l.id === laneId) || this.map.lanes[0];
    let bestIdx = 0;
    let minDist = Infinity;

    for (let i = 0; i < lane.waypoints.length; i++) {
      const wp = lane.waypoints[i];
      const d = Math.hypot(wp.x - pos.x, wp.y - pos.y);
      if (d < minDist) {
        minDist = d;
        bestIdx = i;
      }
    }

    return {
      waypoint: lane.waypoints[bestIdx],
      index: bestIdx,
      dist: minDist
    };
  }
}
