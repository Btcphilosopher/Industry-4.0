// ============================================================================
// AUREOM AUTONOMY — MASTER REAL-TIME SIMULATION & CLOSED-LOOP RUNTIME ENGINE
// Canonical Loop:
//   OBSERVE -> ESTIMATE -> UNDERSTAND -> PREDICT -> PLAN -> VALIDATE -> CONTROL -> EXECUTE -> OBSERVE
// ============================================================================

import { Injectable, signal } from '@angular/core';
import {
  BehaviourDecision,
  ControlCommand,
  FaultInjectionState,
  LidarFrame,
  LocalisationEstimate,
  MotionPlan,
  ObjectTrack,
  RadarFrame,
  ReplayFrame,
  SafetyCheckResult,
  VehicleState
} from '../models/av-types';
import { SCENARIOS, ScenarioActor, ScenarioDefinition } from '../models/scenarios';
import { ControlService } from './control.service';
import { LocalisationFusionService } from './localisation-fusion.service';
import { PerceptionTrackingService } from './perception-tracking.service';
import { PlanningService } from './planning.service';
import { SafetySupervisorService } from './safety-supervisor.service';
import { SensorsService } from './sensors.service';
import { DEFAULT_VEHICLE_CONFIG, VehicleDynamicsService } from './vehicle-dynamics.service';
import { WorldMapService } from './world-map.service';

@Injectable({
  providedIn: 'root'
})
export class SimulationEngineService {
  // Reactive Signals for UI Components
  public isRunning = signal<boolean>(true);
  public simSpeed = signal<number>(1.0); // 0.1, 0.5, 1.0, 2.0, 5.0
  public simTimeS = signal<number>(0);
  public currentScenario = signal<ScenarioDefinition>(SCENARIOS[0]);

  public vehicleState = signal<VehicleState>({
    timestamp: 0,
    seq: 0,
    pose: { x: 10, y: 15, yaw: 0 },
    velocity: 0,
    lateralVelocity: 0,
    acceleration: 0,
    yawRate: 0,
    steerAngleRad: 0,
    slipAngleRad: 0,
    wheelRpm: [0, 0, 0, 0],
    brakeTorqueNm: 0,
    motorTorqueNm: 0,
    batterySocPercent: 98.4,
    gear: 'D'
  });

  public lidarFrame = signal<LidarFrame>({
    sensorId: 'lidar_roof_64ch',
    timestamp: 0,
    seq: 0,
    points: [],
    beams: 64,
    rangeM: 90,
    valid: true
  });

  public radarFrame = signal<RadarFrame>({
    sensorId: 'radar_front_77ghz',
    timestamp: 0,
    seq: 0,
    targets: [],
    valid: true
  });

  public activeTracks = signal<ObjectTrack[]>([]);
  public localisation = signal<LocalisationEstimate>({
    timestamp: 0,
    pose: { x: 10, y: 15, yaw: 0 },
    velocityMS: 0,
    yawRateRadS: 0,
    posCovarianceM2: [0.05, 0.05],
    headingCovarianceRad2: 0.005,
    mode: 'EKF_FUSED',
    qualityScore: 98,
    gnssResidual: 0.04,
    mapMatchingResidual: 0.02,
    isDegraded: false
  });

  public behaviourDecision = signal<BehaviourDecision>({
    timestamp: 0,
    state: 'FOLLOW_LANE',
    targetLaneId: 'lane_main_cruising',
    targetSpeedMS: 13.88,
    targetFollowingDistanceM: 15,
    reasonCode: 'NOMINAL_SPEED_LANE_CENTERING',
    safetyMarginM: 15,
    confidence: 0.98
  });

  public motionPlan = signal<MotionPlan>({
    timestamp: 0,
    chosenTrajectory: {
      id: 'default_init',
      type: 'LANE_KEEP',
      points: [],
      costTotal: 0,
      costBreakdown: {
        collisionRisk: 0,
        roadBoundary: 0,
        speedDeviation: 0,
        curvature: 0,
        jerk: 0,
        lateralOffset: 0,
        progress: 0,
        comfort: 0
      },
      isValid: true
    },
    candidateTrajectories: [],
    horizonSeconds: 4.0,
    planningLatencyMs: 2.1,
    valid: true
  });

  public controlCommand = signal<ControlCommand>({
    timestamp: 0,
    throttle: 0.2,
    brake: 0,
    steeringAngleRad: 0,
    targetSpeedMS: 13.88,
    controllerMode: 'STANLEY',
    crossTrackErrorM: 0,
    headingErrorRad: 0,
    valid: true,
    safetyStatus: 'NOMINAL'
  });

  public safetyResult = signal<SafetyCheckResult>({
    timestamp: 0,
    verdict: 'APPROVE',
    timeToCollisionS: 99.9,
    minDistanceToObstacleM: 99.9,
    maxJerkMagnitudeMS3: 0.4,
    maxLateralAccelMS2: 0.1,
    boundaryClearanceM: 3.75,
    sensorHealthOk: true,
    localisationHealthOk: true,
    violations: []
  });

  public faultState = signal<FaultInjectionState>({
    cameraBlackout: false,
    lidarRainAttenuation: false,
    radarJamming: false,
    gnssUrbanCanyon: false,
    imuBiasDrift: false,
    wheelSlipCondition: false,
    plannerLatencySpike: false,
    staleTrackInject: false
  });

  public dynamicActors = signal<ScenarioActor[]>([]);
  public replayBuffer = signal<ReplayFrame[]>([]);
  public replayIndex = signal<number>(-1);

  // Internal Loop Timer
  private timerId: any = null;
  private readonly DT = 0.04; // 25 Hz / 40ms simulation step

  constructor(
    private dynamicsService: VehicleDynamicsService,
    private sensorsService: SensorsService,
    private perceptionService: PerceptionTrackingService,
    private localisationService: LocalisationFusionService,
    private mapService: WorldMapService,
    private planningService: PlanningService,
    private controlService: ControlService,
    private safetyService: SafetySupervisorService
  ) {
    this.loadScenario(SCENARIOS[0]);
    this.start();
  }

  public loadScenario(scenario: ScenarioDefinition): void {
    this.currentScenario.set(scenario);
    this.simTimeS.set(0);
    this.replayBuffer.set([]);
    this.replayIndex.set(-1);

    // Deep clone actors so they can be mutated during simulation
    this.dynamicActors.set(JSON.parse(JSON.stringify(scenario.actors)));

    const initPose = { ...scenario.initialVehiclePose };
    this.vehicleState.set({
      timestamp: 0,
      seq: 0,
      pose: initPose,
      velocity: 0,
      lateralVelocity: 0,
      acceleration: 0,
      yawRate: 0,
      steerAngleRad: 0,
      slipAngleRad: 0,
      wheelRpm: [0, 0, 0, 0],
      brakeTorqueNm: 0,
      motorTorqueNm: 0,
      batterySocPercent: 98.4,
      gear: 'D'
    });

    this.localisationService.initialize(initPose);
    this.planningService.reset();
    this.controlService.reset();
  }

  public start(): void {
    if (this.timerId) clearInterval(this.timerId);
    this.isRunning.set(true);

    this.timerId = setInterval(() => {
      if (this.isRunning()) {
        const steps = Math.max(1, Math.round(this.simSpeed()));
        for (let i = 0; i < steps; i++) {
          this.step();
        }
      }
    }, 40);
  }

  public pause(): void {
    this.isRunning.set(false);
  }

  public resume(): void {
    this.isRunning.set(true);
  }

  public togglePlay(): void {
    this.isRunning.update(v => !v);
  }

  public setSpeed(speed: number): void {
    this.simSpeed.set(speed);
  }

  public stepManual(): void {
    this.pause();
    this.step();
  }

  public toggleFault(faultName: keyof FaultInjectionState): void {
    this.faultState.update(state => ({
      ...state,
      [faultName]: !state[faultName]
    }));
  }

  /**
   * Main Autonomous Driving Loop Step (40ms)
   */
  private step(): void {
    const t = this.simTimeS() + this.DT;
    this.simTimeS.set(t);

    const scenario = this.currentScenario();
    const faults = this.faultState();
    const ego = this.vehicleState();

    // 1. Update Scenario Actors (Kinematics of other vehicles, pedestrians)
    const actors = this.dynamicActors();
    for (const actor of actors) {
      if (t >= actor.activeTimeRange[0] && t <= actor.activeTimeRange[1]) {
        if (actor.behaviourType === 'JAYWALKING_PEDESTRIAN') {
          actor.initialPos.y -= actor.initialSpeedMS * this.DT;
        } else if (actor.behaviourType === 'AGGRESSIVE_CUT_IN') {
          actor.initialPos.x += actor.initialSpeedMS * this.DT;
          if (actor.initialPos.y > 15.1) {
            actor.initialPos.y -= 0.6 * this.DT; // Cut into center lane
          }
        } else if (actor.behaviourType !== 'STOPPED_OBSTACLE') {
          actor.initialPos.x += actor.initialSpeedMS * Math.cos(actor.initialHeadingRad) * this.DT;
          actor.initialPos.y += actor.initialSpeedMS * Math.sin(actor.initialHeadingRad) * this.DT;
        }
      }
    }

    // 2. Update Traffic Lights
    const map = this.mapService.getMap();
    for (const tl of map.trafficLights) {
      tl.timeRemainingS -= this.DT;
      if (tl.timeRemainingS <= 0) {
        if (tl.state === 'GREEN') {
          tl.state = 'YELLOW';
          tl.timeRemainingS = 3;
        } else if (tl.state === 'YELLOW') {
          tl.state = 'RED';
          tl.timeRemainingS = 8;
        } else {
          tl.state = 'GREEN';
          tl.timeRemainingS = 10;
        }
      }
    }

    // 3. Sensor Ingestion Step
    const lidar = this.sensorsService.generateLidarFrame(ego, actors, faults, scenario.weather);
    const radar = this.sensorsService.generateRadarFrame(ego, actors, faults);
    const camera = this.sensorsService.generateCameraDetections(ego, map.trafficLights, faults);
    const imu = this.sensorsService.generateImuSample(ego, faults, this.DT);
    const gnss = this.sensorsService.generateGnssSample(ego, faults);
    const odom = this.sensorsService.generateWheelOdom(ego, faults);

    this.lidarFrame.set(lidar);
    this.radarFrame.set(radar);

    // 4. Perception & Multi-Object Tracking Step
    const { detections, tracks } = this.perceptionService.update(
      ego,
      lidar,
      radar,
      actors,
      faults,
      this.DT
    );
    this.activeTracks.set(tracks);

    // 5. Localisation & Sensor Fusion EKF Step
    const locEstimate = this.localisationService.update(imu, gnss, odom, this.DT, faults);
    this.localisation.set(locEstimate);

    // 6. Behaviour Planning Step
    const behaviour = this.planningService.planBehaviour(ego, tracks, t);
    this.behaviourDecision.set(behaviour);

    // 7. Frenet Lattice Motion Planning Step
    const motion = this.planningService.planMotion(ego, behaviour, tracks);
    this.motionPlan.set(motion);

    // 8. Low-Level Vehicle Control Step
    const cfg = this.dynamicsService.getConfig();
    let command = this.controlService.computeCommand(ego, motion, cfg, this.DT);

    // 9. Independent Safety Supervisor Check
    const safety = this.safetyService.evaluate(ego, motion, command, tracks, locEstimate, cfg);
    this.safetyResult.set(safety);

    if (safety.verdict === 'SIMULATED_SAFE_STOP') {
      command = {
        ...command,
        throttle: 0,
        brake: 0.95,
        safetyStatus: 'OVERRIDDEN'
      };
    }
    this.controlCommand.set(command);

    // 10. Vehicle Dynamics Integration
    const nextEgo = this.dynamicsService.step(ego, command, this.DT, scenario.frictionMu);
    this.vehicleState.set(nextEgo);

    // 11. Record Replay Frame
    const replayFrame: ReplayFrame = {
      timestamp: nextEgo.timestamp,
      simTimeS: t,
      vehicleState: nextEgo,
      sensorSummary: {
        lidarPointCount: lidar.points.length,
        radarTargetCount: radar.targets.length,
        cameraDetectionCount: camera.detectedTrafficLights.length + camera.detectedSigns.length,
        gnssFix: gnss.fixType
      },
      tracks,
      localisation: locEstimate,
      behaviour,
      plan: motion,
      control: command,
      safety,
      faults: { ...faults }
    };

    this.replayBuffer.update(buf => {
      const nextBuf = [...buf, replayFrame];
      if (nextBuf.length > 500) nextBuf.shift(); // Keep last 500 frames (~20s)
      return nextBuf;
    });
  }

  public seekReplay(index: number): void {
    const buf = this.replayBuffer();
    if (index >= 0 && index < buf.length) {
      this.pause();
      this.replayIndex.set(index);
      const frame = buf[index];
      this.vehicleState.set(frame.vehicleState);
      this.activeTracks.set(frame.tracks);
      this.localisation.set(frame.localisation);
      this.behaviourDecision.set(frame.behaviour);
      this.motionPlan.set(frame.plan);
      this.controlCommand.set(frame.control);
      this.safetyResult.set(frame.safety);
      this.simTimeS.set(frame.simTimeS);
    }
  }
}
