// ============================================================================
// AUREOM AUTONOMY — VEHICLE DYNAMICS ENGINE (Rust-grade Kinematic + Slip Model)
// Implements:
//   x_dot = v * cos(theta + beta)
//   y_dot = v * sin(theta + beta)
//   theta_dot = (v / L) * cos(beta) * tan(delta)
//   beta = arctan( (lr / (lf + lr)) * tan(delta) )
//   v_dot = (F_traction - F_brake - F_drag - F_roll) / m
// ============================================================================

import { Injectable } from '@angular/core';
import { ControlCommand, VehicleConfig, VehicleState } from '../models/av-types';

export const DEFAULT_VEHICLE_CONFIG: VehicleConfig = {
  id: 'aureom_saloon_ev',
  name: 'Aureom Research Executive Saloon (Digital Twin EV)',
  type: 'saloon',
  massKg: 1980,
  wheelbaseM: 2.95,
  frontAxleDistM: 1.45,
  rearAxleDistM: 1.50,
  trackWidthM: 1.62,
  lengthM: 4.88,
  widthM: 1.92,
  heightM: 1.46,
  maxSteerRad: 0.61, // ~35 degrees
  maxSteerRateRadS: 0.45, // ~25 deg/s
  maxAccelMS2: 3.8,
  maxDecelMS2: 8.5,
  tyreFrictionMu: 0.85,
  dragCoefficientCd: 0.23,
  frontalAreaM2: 2.25,
  rollingResistanceCr: 0.012,
  sensorMounts: {
    lidarFront: { x: 2.3, y: 0.0, z: 1.4 },
    cameraFrontCenter: { x: 1.8, y: 0.0, z: 1.35 },
    cameraFrontLeft: { x: 1.8, y: 0.35, z: 1.35 },
    cameraFrontRight: { x: 1.8, y: -0.35, z: 1.35 },
    radarFront: { x: 2.4, y: 0.0, z: 0.5 },
    imuBase: { x: 0.0, y: 0.0, z: 0.2 },
    gnssAntenna: { x: -0.5, y: 0.0, z: 1.45 },
  }
};

@Injectable({
  providedIn: 'root'
})
export class VehicleDynamicsService {
  private config: VehicleConfig = { ...DEFAULT_VEHICLE_CONFIG };

  public getConfig(): VehicleConfig {
    return this.config;
  }

  public setConfig(cfg: Partial<VehicleConfig>): void {
    this.config = { ...this.config, ...cfg };
  }

  /**
   * Integrate vehicle state by dt (seconds) given control commands and environment friction
   */
  public step(
    currentState: VehicleState,
    command: ControlCommand,
    dt: number,
    frictionMu: number = 0.85
  ): VehicleState {
    const cfg = this.config;
    const v = currentState.velocity;
    const theta = currentState.pose.yaw;

    // 1. Steering Actuation with Rate Limiting
    const targetSteer = Math.max(
      -cfg.maxSteerRad,
      Math.min(cfg.maxSteerRad, command.steeringAngleRad)
    );
    const steerDelta = targetSteer - currentState.steerAngleRad;
    const maxSteerStep = cfg.maxSteerRateRadS * dt;
    const actualSteer =
      currentState.steerAngleRad +
      Math.max(-maxSteerStep, Math.min(maxSteerStep, steerDelta));

    // 2. Slip angle (beta) calculation at Center of Gravity
    const lrRatio = cfg.rearAxleDistM / cfg.wheelbaseM;
    const beta = Math.atan(lrRatio * Math.tan(actualSteer));

    // 3. Longitudinal Dynamics Forces
    const airDensity = 1.225; // kg/m^3
    const gravity = 9.81; // m/s^2

    // Aero Drag
    const fDrag = 0.5 * airDensity * cfg.dragCoefficientCd * cfg.frontalAreaM2 * v * Math.abs(v);
    // Rolling Resistance
    const fRoll = cfg.rollingResistanceCr * cfg.massKg * gravity * (v > 0.05 ? 1 : 0);

    // Motor / Brake Forces
    let fTraction = 0;
    let fBrake = 0;

    if (command.throttle > 0) {
      fTraction = command.throttle * (cfg.maxAccelMS2 * cfg.massKg);
    }
    if (command.brake > 0) {
      fBrake = command.brake * (cfg.maxDecelMS2 * cfg.massKg);
    }

    // Road friction envelope limit (Kamm's circle approximation)
    const maxTireForce = frictionMu * cfg.massKg * gravity;
    const netLongitudinalForce = Math.max(-maxTireForce, Math.min(maxTireForce, fTraction - fBrake - fDrag - fRoll));
    const accel = netLongitudinalForce / cfg.massKg;

    // 4. Update velocity
    let newVelocity = v + accel * dt;
    if (newVelocity < 0.001 && command.brake > 0.1) {
      newVelocity = 0; // Prevent backward creep under braking in Drive
    }

    // 5. Kinematics Derivatives
    const xDot = newVelocity * Math.cos(theta + beta);
    const yDot = newVelocity * Math.sin(theta + beta);
    const thetaDot = (newVelocity / cfg.wheelbaseM) * Math.cos(beta) * Math.tan(actualSteer);

    // 6. Update Pose
    const newX = currentState.pose.x + xDot * dt;
    const newY = currentState.pose.y + yDot * dt;
    let newYaw = theta + thetaDot * dt;

    // Normalize yaw to [-PI, +PI]
    while (newYaw > Math.PI) newYaw -= 2 * Math.PI;
    while (newYaw < -Math.PI) newYaw += 2 * Math.PI;

    // 7. Calculate Wheel RPMs (with differential effect during turn)
    const wheelRadiusM = 0.33; // ~19 inch wheel
    const halfTrack = cfg.trackWidthM / 2;
    const leftWheelSpeed = newVelocity - (thetaDot * halfTrack);
    const rightWheelSpeed = newVelocity + (thetaDot * halfTrack);
    const flRpm = (leftWheelSpeed / (2 * Math.PI * wheelRadiusM)) * 60;
    const frRpm = (rightWheelSpeed / (2 * Math.PI * wheelRadiusM)) * 60;
    const rlRpm = flRpm;
    const rrRpm = frRpm;

    // Lateral velocity (side slip)
    const lateralVel = newVelocity * Math.sin(beta);

    // Battery Discharge Estimation
    const powerKw = Math.max(0, (fTraction * newVelocity) / 1000);
    const socDelta = (powerKw * (dt / 3600)) / 85.0 * 100; // 85 kWh pack
    const newSoc = Math.max(0, currentState.batterySocPercent - socDelta);

    return {
      timestamp: currentState.timestamp + Math.round(dt * 1_000_000),
      seq: currentState.seq + 1,
      pose: { x: newX, y: newY, yaw: newYaw },
      velocity: newVelocity,
      lateralVelocity: lateralVel,
      acceleration: accel,
      yawRate: thetaDot,
      steerAngleRad: actualSteer,
      slipAngleRad: beta,
      wheelRpm: [flRpm, frRpm, rlRpm, rrRpm],
      brakeTorqueNm: fBrake * wheelRadiusM,
      motorTorqueNm: fTraction * wheelRadiusM,
      batterySocPercent: newSoc,
      gear: 'D'
    };
  }
}
