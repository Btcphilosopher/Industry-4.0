// ============================================================================
// AUREOM AUTONOMY — SYNTHETIC SENSORS & INGESTION ENGINE
// High-fidelity physical sensor simulation with stochastic noise models:
//   - 64-channel LiDAR Point Cloud (Ray-ground + Bounding Box intersection)
//   - Multi-target FMCW Doppler Radar (Range, Azimuth, Radial Velocity, RCS)
//   - Tri-focal Vision Perception Stream (Lanes, Traffic Signs, Traffic Lights)
//   - 6-DOF Tactical-grade IMU (Bias drift random walk + thermal white noise)
//   - Dual-frequency RTK GNSS Receiver (Multipath degradation & HDOP modeling)
//   - Quad Wheel Speed Encoders (Tire slip dynamics)
// ============================================================================

import { Injectable } from '@angular/core';
import {
  CameraDetections,
  FaultInjectionState,
  GnssSample,
  ImuSample,
  LidarFrame,
  LidarPoint,
  RadarFrame,
  RadarTarget,
  TrafficLight,
  VehicleState,
  WheelOdomSample
} from '../models/av-types';
import { ScenarioActor } from '../models/scenarios';

@Injectable({
  providedIn: 'root'
})
export class SensorsService {
  private seq = 0;
  private imuGyroBias = { x: 0.001, y: -0.002, z: 0.0015 };
  private imuAccelBias = { x: 0.02, y: -0.015, z: 0.03 };

  /**
   * Generate Gaussian random numbers using Box-Muller transform
   */
  private gaussianRandom(mean = 0, stdev = 1): number {
    const u = 1 - Math.random();
    const v = Math.random();
    const z = Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
    return z * stdev + mean;
  }

  /**
   * Generate 64-channel LiDAR point cloud sweep
   */
  public generateLidarFrame(
    ego: VehicleState,
    actors: ScenarioActor[],
    faults: FaultInjectionState,
    weather: string
  ): LidarFrame {
    this.seq++;
    if (faults.lidarRainAttenuation && Math.random() < 0.3) {
      return {
        sensorId: 'lidar_roof_64ch',
        timestamp: ego.timestamp,
        seq: this.seq,
        points: [],
        beams: 64,
        rangeM: 120,
        valid: false
      };
    }

    const points: LidarPoint[] = [];
    const maxRange = faults.lidarRainAttenuation ? 35 : 90;
    const numRays = faults.lidarRainAttenuation ? 80 : 180;

    // 1. Generate synthetic ground plane scan rings
    for (let ring = 0; ring < 16; ring++) {
      const ringRadius = 3.0 + ring * 3.5;
      if (ringRadius > maxRange) continue;
      const ringSteps = Math.floor(ringRadius * 4);
      for (let i = 0; i < ringSteps; i++) {
        const angle = (i / ringSteps) * Math.PI * 2;
        const noise = this.gaussianRandom(0, 0.03);
        const px = ego.pose.x + (ringRadius + noise) * Math.cos(ego.pose.yaw + angle);
        const py = ego.pose.y + (ringRadius + noise) * Math.sin(ego.pose.yaw + angle);
        points.push({
          x: px,
          y: py,
          z: -1.35 + this.gaussianRandom(0, 0.02),
          intensity: Math.floor(40 + Math.random() * 60),
          ring,
          isGround: true
        });
      }
    }

    // 2. Ray-trace onto active scenario actors
    for (const actor of actors) {
      const dx = actor.initialPos.x - ego.pose.x;
      const dy = actor.initialPos.y - ego.pose.y;
      const dist = Math.hypot(dx, dy);

      if (dist <= maxRange) {
        // Compute relative angle to front
        const actorHeadingToEgo = Math.atan2(dy, dx) - ego.pose.yaw;
        const isWithinFov = Math.abs(actorHeadingToEgo) < (Math.PI * 0.85);

        if (isWithinFov) {
          const pointDensity = Math.max(12, Math.floor(120 / Math.max(1, dist)));
          for (let p = 0; p < pointDensity; p++) {
            const jitterX = (Math.random() - 0.5) * actor.lengthM;
            const jitterY = (Math.random() - 0.5) * actor.widthM;
            const jitterZ = Math.random() * 1.6;

            const ptX = actor.initialPos.x + jitterX + this.gaussianRandom(0, 0.04);
            const ptY = actor.initialPos.y + jitterY + this.gaussianRandom(0, 0.04);

            points.push({
              x: ptX,
              y: ptY,
              z: jitterZ,
              intensity: Math.floor(150 + Math.random() * 105),
              ring: Math.floor(Math.random() * 32),
              isGround: false,
              objectId: actor.id
            });
          }
        }
      }
    }

    // 3. Rain backscatter particulate noise
    if (weather === 'RAIN' || faults.lidarRainAttenuation) {
      const rainClutterCount = 45;
      for (let r = 0; r < rainClutterCount; r++) {
        const dist = Math.random() * 15;
        const angle = (Math.random() - 0.5) * Math.PI;
        points.push({
          x: ego.pose.x + dist * Math.cos(ego.pose.yaw + angle),
          y: ego.pose.y + dist * Math.sin(ego.pose.yaw + angle),
          z: Math.random() * 2.0,
          intensity: Math.floor(20 + Math.random() * 40),
          ring: Math.floor(Math.random() * 64),
          isGround: false
        });
      }
    }

    return {
      sensorId: 'lidar_roof_64ch',
      timestamp: ego.timestamp,
      seq: this.seq,
      points,
      beams: 64,
      rangeM: maxRange,
      valid: true
    };
  }

  /**
   * Generate FMCW Radar Detections
   */
  public generateRadarFrame(
    ego: VehicleState,
    actors: ScenarioActor[],
    faults: FaultInjectionState
  ): RadarFrame {
    if (faults.radarJamming) {
      return {
        sensorId: 'radar_front_77ghz',
        timestamp: ego.timestamp,
        seq: this.seq,
        targets: [],
        valid: false
      };
    }

    const targets: RadarTarget[] = [];
    for (const actor of actors) {
      const dx = actor.initialPos.x - ego.pose.x;
      const dy = actor.initialPos.y - ego.pose.y;
      const range = Math.hypot(dx, dy);

      // Radar field of view: 180m range, +- 45 deg azimuth
      if (range <= 160) {
        let azimuth = Math.atan2(dy, dx) - ego.pose.yaw;
        while (azimuth > Math.PI) azimuth -= 2 * Math.PI;
        while (azimuth < -Math.PI) azimuth += 2 * Math.PI;

        if (Math.abs(azimuth) < 0.78) {
          // ~45 deg
          // Doppler relative velocity: delta_v = (v_actor - v_ego) projected along line of sight
          const vEgoX = ego.velocity * Math.cos(ego.pose.yaw);
          const vEgoY = ego.velocity * Math.sin(ego.pose.yaw);
          const vActorX = actor.initialSpeedMS * Math.cos(actor.initialHeadingRad);
          const vActorY = actor.initialSpeedMS * Math.sin(actor.initialHeadingRad);

          const relVx = vActorX - vEgoX;
          const relVy = vActorY - vEgoY;
          const unitLosX = dx / range;
          const unitLosY = dy / range;
          const radialSpeed = relVx * unitLosX + relVy * unitLosY;

          targets.push({
            id: `radar_tgt_${actor.id}`,
            rangeM: range + this.gaussianRandom(0, 0.15),
            azimuthRad: azimuth + this.gaussianRandom(0, 0.01),
            radialVelocityMS: radialSpeed + this.gaussianRandom(0, 0.1),
            rcsDb: actor.class === 'TRUCK' ? 24 : actor.class === 'VEHICLE' ? 14 : 2,
            confidence: 0.92
          });
        }
      }
    }

    return {
      sensorId: 'radar_front_77ghz',
      timestamp: ego.timestamp,
      seq: this.seq,
      targets,
      valid: true
    };
  }

  /**
   * Generate Front Camera Detections
   */
  public generateCameraDetections(
    ego: VehicleState,
    trafficLights: TrafficLight[],
    faults: FaultInjectionState
  ): CameraDetections {
    if (faults.cameraBlackout) {
      return {
        sensorId: 'camera_front_wide',
        timestamp: ego.timestamp,
        seq: this.seq,
        fovDeg: 120,
        detectedLanes: [],
        detectedTrafficLights: [],
        detectedSigns: [],
        valid: false
      };
    }

    const detectedLights = trafficLights.map(tl => {
      const dx = tl.position.x - ego.pose.x;
      const dy = tl.position.y - ego.pose.y;
      const dist = Math.hypot(dx, dy);
      return {
        id: tl.id,
        state: dist < 95 ? tl.state : 'UNKNOWN' as const,
        confidence: dist < 60 ? 0.98 : 0.75,
        distanceM: dist
      };
    }).filter(l => l.distanceM < 110);

    return {
      sensorId: 'camera_front_wide',
      timestamp: ego.timestamp,
      seq: this.seq,
      fovDeg: 120,
      detectedLanes: [
        {
          type: 'solid_white',
          points: [
            { x: ego.pose.x, y: ego.pose.y - 1.85 },
            { x: ego.pose.x + 30, y: ego.pose.y - 1.85 }
          ],
          confidence: 0.96
        },
        {
          type: 'dashed_white',
          points: [
            { x: ego.pose.x, y: ego.pose.y + 1.85 },
            { x: ego.pose.x + 30, y: ego.pose.y + 1.85 }
          ],
          confidence: 0.95
        }
      ],
      detectedTrafficLights: detectedLights,
      detectedSigns: [
        {
          type: 'SPEED_LIMIT_50',
          confidence: 0.94,
          distanceM: 35.0
        }
      ],
      valid: true
    };
  }

  /**
   * Generate 6-DOF IMU Sensor Samples
   */
  public generateImuSample(
    ego: VehicleState,
    faults: FaultInjectionState,
    dt: number
  ): ImuSample {
    if (faults.imuBiasDrift) {
      this.imuGyroBias.z += this.gaussianRandom(0, 0.005) * dt;
      this.imuAccelBias.x += this.gaussianRandom(0, 0.02) * dt;
    }

    const gravity = 9.81;
    const centripetalAccel = ego.velocity * ego.yawRate;

    return {
      timestamp: ego.timestamp,
      seq: this.seq,
      accel: {
        x: ego.acceleration + this.imuAccelBias.x + this.gaussianRandom(0, 0.05),
        y: centripetalAccel + this.imuAccelBias.y + this.gaussianRandom(0, 0.05),
        z: gravity + this.imuAccelBias.z + this.gaussianRandom(0, 0.03)
      },
      gyro: {
        x: this.imuGyroBias.x + this.gaussianRandom(0, 0.002),
        y: this.imuGyroBias.y + this.gaussianRandom(0, 0.002),
        z: ego.yawRate + this.imuGyroBias.z + this.gaussianRandom(0, 0.001)
      },
      biasAccel: { ...this.imuAccelBias },
      biasGyro: { ...this.imuGyroBias },
      temperatureC: 38.5,
      valid: true
    };
  }

  /**
   * Generate GNSS Receiver Sample
   */
  public generateGnssSample(
    ego: VehicleState,
    faults: FaultInjectionState
  ): GnssSample {
    if (faults.gnssUrbanCanyon) {
      return {
        timestamp: ego.timestamp,
        seq: this.seq,
        latitude: 51.5074,
        longitude: -0.1278,
        altitudeM: 35.0,
        posEastingM: ego.pose.x + this.gaussianRandom(0, 12.0), // High multipath error
        posNorthingM: ego.pose.y + this.gaussianRandom(0, 15.0),
        hdop: 8.5,
        vdop: 12.0,
        satellites: 4,
        fixType: 'NO_FIX',
        covarianceM: [144.0, 225.0],
        valid: false
      };
    }

    return {
      timestamp: ego.timestamp,
      seq: this.seq,
      latitude: 51.5074 + (ego.pose.y / 111111),
      longitude: -0.1278 + (ego.pose.x / (111111 * Math.cos(51.5074 * Math.PI / 180))),
      altitudeM: 35.0,
      posEastingM: ego.pose.x + this.gaussianRandom(0, 0.08),
      posNorthingM: ego.pose.y + this.gaussianRandom(0, 0.08),
      hdop: 0.85,
      vdop: 1.1,
      satellites: 18,
      fixType: 'RTK_FIXED',
      covarianceM: [0.0064, 0.0064],
      valid: true
    };
  }

  /**
   * Generate Wheel Odometry Sample
   */
  public generateWheelOdom(
    ego: VehicleState,
    faults: FaultInjectionState
  ): WheelOdomSample {
    const slipFactor = faults.wheelSlipCondition ? 1.4 : 1.0;
    const leftSpeed = ego.velocity * slipFactor + this.gaussianRandom(0, 0.02);
    const rightSpeed = ego.velocity * slipFactor + this.gaussianRandom(0, 0.02);

    return {
      timestamp: ego.timestamp,
      seq: this.seq,
      leftSpeedMS: leftSpeed,
      rightSpeedMS: rightSpeed,
      averageSpeedMS: (leftSpeed + rightSpeed) / 2,
      yawRateRadS: ego.yawRate + this.gaussianRandom(0, 0.005),
      slipRatio: faults.wheelSlipCondition ? 0.35 : 0.015,
      valid: true
    };
  }
}
