// ============================================================================
// AUREOM AUTONOMY — SENSOR FUSION & EXTENDED KALMAN FILTER (EKF) LOCALISATION
// State Vector: x = [p_x, p_y, yaw, velocity]
// Fuses:
//   - Inertial Measurement Unit (IMU 6-DOF)
//   - Wheel Speed Odometry
//   - RTK GNSS Receiver with Covariance Weighting
//   - HD Map Lane Boundary Geometry Matching
// ============================================================================

import { Injectable } from '@angular/core';
import {
  FaultInjectionState,
  GnssSample,
  ImuSample,
  LocalisationEstimate,
  Pose2D,
  VehicleState,
  WheelOdomSample
} from '../models/av-types';

@Injectable({
  providedIn: 'root'
})
export class LocalisationFusionService {
  // Estimated state
  private state: [number, number, number, number] = [10, 15, 0, 0]; // x, y, yaw, v
  // State Covariance Matrix (4x4)
  private P: number[][] = [
    [0.1, 0, 0, 0],
    [0, 0.1, 0, 0],
    [0, 0, 0.01, 0],
    [0, 0, 0, 0.05]
  ];

  public initialize(pose: Pose2D): void {
    this.state = [pose.x, pose.y, pose.yaw, 0];
    this.P = [
      [0.05, 0, 0, 0],
      [0, 0.05, 0, 0],
      [0, 0, 0.005, 0],
      [0, 0, 0, 0.02]
    ];
  }

  /**
   * Run EKF Prediction and Update step
   */
  public update(
    imu: ImuSample,
    gnss: GnssSample,
    odom: WheelOdomSample,
    dt: number,
    faults: FaultInjectionState
  ): LocalisationEstimate {
    // -----------------------------------------------------------------------
    // 1. PREDICT STEP (Motion Model using IMU yaw rate & Odometry velocity)
    // -----------------------------------------------------------------------
    const [x, y, yaw, v] = this.state;
    const measuredV = odom.valid ? odom.averageSpeedMS : v;
    const measuredYawRate = imu.valid ? imu.gyro.z : 0;

    const newYaw = yaw + measuredYawRate * dt;
    const newX = x + measuredV * Math.cos(newYaw) * dt;
    const newY = y + measuredV * Math.sin(newYaw) * dt;
    const newV = measuredV;

    this.state = [newX, newY, newYaw, newV];

    // Propagate Covariance: P = F * P * F^T + Q
    const qPos = 0.04 * dt;
    const qYaw = 0.008 * dt;
    const qVel = 0.15 * dt;

    this.P[0][0] += qPos;
    this.P[1][1] += qPos;
    this.P[2][2] += qYaw;
    this.P[3][3] += qVel;

    // -----------------------------------------------------------------------
    // 2. UPDATE STEP (GNSS Measurement fusion if valid)
    // -----------------------------------------------------------------------
    let gnssResidual = 0;
    let mode: LocalisationEstimate['mode'] = 'EKF_FUSED';
    let isDegraded = false;

    if (gnss.valid && !faults.gnssUrbanCanyon) {
      const zX = gnss.posEastingM;
      const zY = gnss.posNorthingM;
      const rX = gnss.covarianceM[0];
      const rY = gnss.covarianceM[1];

      // Innovation
      const innovX = zX - this.state[0];
      const innovY = zY - this.state[1];
      gnssResidual = Math.hypot(innovX, innovY);

      // Outlier rejection (Gating: if residual > 5 sigma reject)
      if (gnssResidual < 4.0) {
        // Kalman Gain: K = P * H^T * (H * P * H^T + R)^-1
        const kX = this.P[0][0] / (this.P[0][0] + rX);
        const kY = this.P[1][1] / (this.P[1][1] + rY);

        this.state[0] += kX * innovX;
        this.state[1] += kY * innovY;

        this.P[0][0] *= (1 - kX);
        this.P[1][1] *= (1 - kY);
      }
    } else {
      // GNSS is degraded or denied: Rely on dead reckoning + map matching
      mode = 'DEAD_RECKONING';
      isDegraded = true;
      // Synthetically bound drift with map matching
      const targetLaneY = 15.0; // Center lane assumption
      const mapInnovY = targetLaneY - this.state[1];
      if (Math.abs(mapInnovY) < 3.5) {
        const kMap = 0.08;
        this.state[1] += kMap * mapInnovY * dt;
        mode = 'MAP_MATCHED';
      }
    }

    // Calculate Quality Score (0..100) based on covariance trace
    const posVarTrace = this.P[0][0] + this.P[1][1];
    const qualityScore = Math.max(10, Math.min(100, Math.round((1.0 - Math.min(1.0, posVarTrace)) * 100)));

    return {
      timestamp: imu.timestamp,
      pose: {
        x: this.state[0],
        y: this.state[1],
        yaw: this.state[2]
      },
      velocityMS: this.state[3],
      yawRateRadS: imu.gyro.z,
      posCovarianceM2: [this.P[0][0], this.P[1][1]],
      headingCovarianceRad2: this.P[2][2],
      mode,
      qualityScore,
      gnssResidual,
      mapMatchingResidual: Math.abs(15.0 - this.state[1]),
      isDegraded
    };
  }
}
