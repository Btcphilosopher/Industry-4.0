// ============================================================================
// AUREOM AUTONOMY — VEHICLE CONTROL SYSTEM (Rust-grade Real-Time Controllers)
// Implements:
//   - Stanley Non-Linear Lateral Tracking Controller:
//       delta(t) = psi_err + arctan( (k * e_y) / (v(t) + k_soft) )
//   - Pure Pursuit Geometric Lateral Controller:
//       delta(t) = arctan( (2 * L * sin(alpha)) / L_d )
//   - Longitudinal PID Speed / Acceleration Controller with Anti-Windup
//   - Steering Rate Limiter & Actuator Clamp Boundary
// ============================================================================

import { Injectable } from '@angular/core';
import { ControlCommand, MotionPlan, VehicleConfig, VehicleState } from '../models/av-types';

@Injectable({
  providedIn: 'root'
})
export class ControlService {
  private controllerMode: 'STANLEY' | 'PURE_PURSUIT' | 'MPC_RESEARCH' = 'STANLEY';

  // PID Internal Integrator States
  private speedErrorIntegral = 0;
  private prevSpeedError = 0;

  public setControllerMode(mode: 'STANLEY' | 'PURE_PURSUIT' | 'MPC_RESEARCH'): void {
    this.controllerMode = mode;
  }

  public getControllerMode(): 'STANLEY' | 'PURE_PURSUIT' | 'MPC_RESEARCH' {
    return this.controllerMode;
  }

  public reset(): void {
    this.speedErrorIntegral = 0;
    this.prevSpeedError = 0;
  }

  /**
   * Compute steering and throttle/brake commands to track planned trajectory
   */
  public computeCommand(
    ego: VehicleState,
    plan: MotionPlan,
    cfg: VehicleConfig,
    dt: number
  ): ControlCommand {
    const traj = plan.chosenTrajectory.points;
    if (!traj || traj.length === 0) {
      return {
        timestamp: ego.timestamp,
        throttle: 0,
        brake: 0.8,
        steeringAngleRad: 0,
        targetSpeedMS: 0,
        controllerMode: this.controllerMode,
        crossTrackErrorM: 0,
        headingErrorRad: 0,
        valid: false,
        safetyStatus: 'OVERRIDDEN'
      };
    }

    // 1. Lookahead reference point along trajectory (approx 1.0s ahead)
    const lookaheadIdx = Math.min(traj.length - 1, 5); // ~1.0s at dt=0.2
    const targetPt = traj[lookaheadIdx];

    // 2. Lateral Control Computation
    let steerCommand = 0;
    let crossTrackErr = 0;
    let headingErr = 0;

    if (this.controllerMode === 'STANLEY') {
      // Stanley Controller at Front Axle
      const fx = ego.pose.x + cfg.frontAxleDistM * Math.cos(ego.pose.yaw);
      const fy = ego.pose.y + cfg.frontAxleDistM * Math.sin(ego.pose.yaw);

      // Find nearest point on trajectory to front axle
      let nearestIdx = 0;
      let minD = Infinity;
      for (let i = 0; i < traj.length; i++) {
        const d = Math.hypot(traj[i].x - fx, traj[i].y - fy);
        if (d < minD) {
          minD = d;
          nearestIdx = i;
        }
      }

      const refPt = traj[nearestIdx];
      // Heading Error
      headingErr = refPt.yaw - ego.pose.yaw;
      while (headingErr > Math.PI) headingErr -= 2 * Math.PI;
      while (headingErr < -Math.PI) headingErr += 2 * Math.PI;

      // Cross-Track Error with sign relative to vehicle heading vector
      const dx = fx - refPt.x;
      const dy = fy - refPt.y;
      crossTrackErr = -Math.sin(refPt.yaw) * dx + Math.cos(refPt.yaw) * dy;

      const kStanley = 0.85;
      const kSoft = 1.0;
      const crossTrackTerm = Math.atan2(kStanley * crossTrackErr, ego.velocity + kSoft);

      steerCommand = headingErr + crossTrackTerm;
    } else {
      // Pure Pursuit Controller
      const ld = Math.max(3.5, 1.2 * ego.velocity);
      let targetIdx = 0;
      for (let i = 0; i < traj.length; i++) {
        const d = Math.hypot(traj[i].x - ego.pose.x, traj[i].y - ego.pose.y);
        if (d >= ld) {
          targetIdx = i;
          break;
        }
      }
      const pt = traj[targetIdx] || traj[traj.length - 1];
      const alpha = Math.atan2(pt.y - ego.pose.y, pt.x - ego.pose.x) - ego.pose.yaw;
      steerCommand = Math.atan2(2 * cfg.wheelbaseM * Math.sin(alpha), ld);
      crossTrackErr = Math.sin(alpha) * ld;
      headingErr = alpha;
    }

    // Steering clamp
    steerCommand = Math.max(-cfg.maxSteerRad, Math.min(cfg.maxSteerRad, steerCommand));

    // 3. Longitudinal PID Speed Control
    const targetSpeed = targetPt.speed;
    const speedError = targetSpeed - ego.velocity;

    // Integral with anti-windup clamping
    this.speedErrorIntegral += speedError * dt;
    this.speedErrorIntegral = Math.max(-5.0, Math.min(5.0, this.speedErrorIntegral));

    const speedDeriv = (speedError - this.prevSpeedError) / (dt + 1e-6);
    this.prevSpeedError = speedError;

    const kp = 0.45;
    const ki = 0.08;
    const kd = 0.05;
    const pidOutput = kp * speedError + ki * this.speedErrorIntegral + kd * speedDeriv;

    let throttle = 0;
    let brake = 0;

    if (pidOutput > 0) {
      throttle = Math.min(1.0, pidOutput);
      brake = 0;
    } else {
      throttle = 0;
      brake = Math.min(1.0, -pidOutput * 1.5);
    }

    // Safety fallback: if target speed is zero and we are moving slowly, hold brake
    if (targetSpeed === 0 && ego.velocity < 0.2) {
      throttle = 0;
      brake = 0.85;
    }

    return {
      timestamp: ego.timestamp,
      throttle,
      brake,
      steeringAngleRad: steerCommand,
      targetSpeedMS: targetSpeed,
      controllerMode: this.controllerMode,
      crossTrackErrorM: crossTrackErr,
      headingErrorRad: headingErr,
      valid: true,
      safetyStatus: 'NOMINAL'
    };
  }
}
