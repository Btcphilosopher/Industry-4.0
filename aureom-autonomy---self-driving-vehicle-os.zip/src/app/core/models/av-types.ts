// ============================================================================
// AUREOM AUTONOMY — CANONICAL MATHEMATICAL AND SENSOR DATA TYPES
// High-precision autonomous vehicle state, sensor, perception, and planning models.
// ============================================================================

export interface Vector2D {
  x: number;
  y: number;
}

export interface Vector3D {
  x: number;
  y: number;
  z: number;
}

export interface Quaternion {
  w: number;
  x: number;
  y: number;
  z: number;
}

export interface Pose2D {
  x: number; // metres
  y: number; // metres
  yaw: number; // radians (-pi to +pi)
}

export interface Pose3D {
  position: Vector3D;
  orientation: Quaternion;
}

export interface TransformFrame {
  parentFrame: string;
  childFrame: string;
  translation: Vector3D;
  rotation: Quaternion;
  timestamp: number; // microseconds
}

// ---------------------------------------------------------------------------
// VEHICLE PARAMETERS & DIGITAL TWIN
// ---------------------------------------------------------------------------
export interface VehicleConfig {
  id: string;
  name: string;
  type: 'compact' | 'saloon' | 'suv' | 'shuttle' | 'truck';
  massKg: number;
  wheelbaseM: number;
  frontAxleDistM: number;
  rearAxleDistM: number;
  trackWidthM: number;
  lengthM: number;
  widthM: number;
  heightM: number;
  maxSteerRad: number; // rad (~35 deg)
  maxSteerRateRadS: number; // rad/s (~25 deg/s)
  maxAccelMS2: number; // m/s^2 (e.g. 4.0)
  maxDecelMS2: number; // m/s^2 (e.g. 8.0)
  tyreFrictionMu: number; // dry=0.85, wet=0.45, ice=0.15
  dragCoefficientCd: number;
  frontalAreaM2: number;
  rollingResistanceCr: number;
  sensorMounts: {
    lidarFront: Vector3D;
    cameraFrontCenter: Vector3D;
    cameraFrontLeft: Vector3D;
    cameraFrontRight: Vector3D;
    radarFront: Vector3D;
    imuBase: Vector3D;
    gnssAntenna: Vector3D;
  };
}

export interface VehicleState {
  timestamp: number; // microsecond simulation time
  seq: number;
  pose: Pose2D;
  velocity: number; // m/s (longitudinal)
  lateralVelocity: number; // m/s (side slip)
  acceleration: number; // m/s^2
  yawRate: number; // rad/s
  steerAngleRad: number; // rad
  slipAngleRad: number; // rad (beta)
  wheelRpm: [number, number, number, number]; // FL, FR, RL, RR
  brakeTorqueNm: number;
  motorTorqueNm: number;
  batterySocPercent: number;
  gear: 'P' | 'R' | 'N' | 'D';
}

// ---------------------------------------------------------------------------
// SENSORS & OBSERVATIONS
// ---------------------------------------------------------------------------
export interface LidarPoint {
  x: number;
  y: number;
  z: number;
  intensity: number; // 0..255
  ring: number; // 0..63
  isGround: boolean;
  objectId?: string;
}

export interface LidarFrame {
  sensorId: string;
  timestamp: number;
  seq: number;
  points: LidarPoint[];
  beams: number;
  rangeM: number;
  valid: boolean;
}

export interface RadarTarget {
  id: string;
  rangeM: number;
  azimuthRad: number;
  radialVelocityMS: number;
  rcsDb: number; // radar cross-section
  confidence: number;
}

export interface RadarFrame {
  sensorId: string;
  timestamp: number;
  seq: number;
  targets: RadarTarget[];
  valid: boolean;
}

export interface CameraDetections {
  sensorId: string;
  timestamp: number;
  seq: number;
  fovDeg: number;
  detectedLanes: {
    type: 'solid_white' | 'dashed_white' | 'solid_yellow' | 'double_yellow';
    points: Vector2D[];
    confidence: number;
  }[];
  detectedTrafficLights: {
    id: string;
    state: 'RED' | 'YELLOW' | 'GREEN' | 'UNKNOWN';
    confidence: number;
    distanceM: number;
  }[];
  detectedSigns: {
    type: 'SPEED_LIMIT_30' | 'SPEED_LIMIT_50' | 'STOP' | 'YIELD' | 'PEDESTRIAN_CROSSING';
    confidence: number;
    distanceM: number;
  }[];
  valid: boolean;
}

export interface ImuSample {
  timestamp: number;
  seq: number;
  accel: Vector3D; // m/s^2 (includes gravity)
  gyro: Vector3D; // rad/s
  biasAccel: Vector3D;
  biasGyro: Vector3D;
  temperatureC: number;
  valid: boolean;
}

export interface GnssSample {
  timestamp: number;
  seq: number;
  latitude: number;
  longitude: number;
  altitudeM: number;
  posEastingM: number;
  posNorthingM: number;
  hdop: number;
  vdop: number;
  satellites: number;
  fixType: 'NO_FIX' | '2D' | '3D' | 'RTK_FLOAT' | 'RTK_FIXED';
  covarianceM: [number, number];
  valid: boolean;
}

export interface WheelOdomSample {
  timestamp: number;
  seq: number;
  leftSpeedMS: number;
  rightSpeedMS: number;
  averageSpeedMS: number;
  yawRateRadS: number;
  slipRatio: number;
  valid: boolean;
}

// ---------------------------------------------------------------------------
// PERCEPTION & MULTI-OBJECT TRACKING
// ---------------------------------------------------------------------------
export type ActorClass = 'VEHICLE' | 'PEDESTRIAN' | 'CYCLIST' | 'TRUCK' | 'EMERGENCY' | 'OBSTACLE';

export interface BoundingBox3D {
  center: Vector3D;
  extent: Vector3D; // length, width, height
  orientationYaw: number;
}

export interface PerceptionDetection {
  id: string;
  class: ActorClass;
  box: BoundingBox3D;
  velocity: Vector2D;
  confidence: number;
  sensorSource: 'CAMERA' | 'LIDAR' | 'RADAR' | 'FUSED_PERCEPTION';
  groundTruthId?: string;
}

export interface ObjectTrack {
  trackId: string;
  class: ActorClass;
  position: Vector2D; // x, y
  velocity: Vector2D; // vx, vy
  acceleration: Vector2D; // ax, ay
  headingRad: number;
  dimensions: Vector2D; // length, width
  covariance: number[][]; // 4x4 or 6x6 state covariance
  trackAgeFrames: number;
  missedFrames: number;
  status: 'TENTATIVE' | 'CONFIRMED' | 'COASTED' | 'DELETED';
  confidence: number;
  predictedPath?: Vector2D[];
}

// ---------------------------------------------------------------------------
// SENSOR FUSION & LOCALISATION
// ---------------------------------------------------------------------------
export interface LocalisationEstimate {
  timestamp: number;
  pose: Pose2D;
  velocityMS: number;
  yawRateRadS: number;
  posCovarianceM2: [number, number];
  headingCovarianceRad2: number;
  mode: 'DEAD_RECKONING' | 'GNSS_RAW' | 'MAP_MATCHED' | 'EKF_FUSED';
  qualityScore: number; // 0..100%
  gnssResidual: number;
  mapMatchingResidual: number;
  isDegraded: boolean;
}

// ---------------------------------------------------------------------------
// WORLD MODEL & ROAD NETWORK
// ---------------------------------------------------------------------------
export interface Waypoint {
  x: number;
  y: number;
  heading: number;
  curvature: number;
  s: number; // arc-length distance along lane
  speedLimitMS: number;
}

export interface Lane {
  id: string;
  name: string;
  laneIndex: number; // 0=rightmost, 1=left
  waypoints: Waypoint[];
  leftBoundaryType: 'SOLID' | 'DASHED' | 'CURB' | 'NONE';
  rightBoundaryType: 'SOLID' | 'DASHED' | 'CURB' | 'NONE';
  speedLimitMS: number;
  successorLaneIds: string[];
  predecessorLaneIds: string[];
  adjacentLeftLaneId?: string;
  adjacentRightLaneId?: string;
  isIntersection: boolean;
}

export interface TrafficLight {
  id: string;
  laneId: string;
  position: Vector2D;
  state: 'RED' | 'YELLOW' | 'GREEN';
  timeRemainingS: number;
  stopLineX: number;
  stopLineY: number;
}

export interface RoadNetworkMap {
  id: string;
  name: string;
  lanes: Lane[];
  trafficLights: TrafficLight[];
  speedLimitDefaultMS: number;
  bounds: { minX: number; maxX: number; minY: number; maxY: number };
}

// ---------------------------------------------------------------------------
// BEHAVIOUR & MOTION PLANNING
// ---------------------------------------------------------------------------
export type BehaviourState =
  | 'INITIALISING'
  | 'FOLLOW_LANE'
  | 'FOLLOW_VEHICLE'
  | 'APPROACH_INTERSECTION'
  | 'WAIT_AT_RED_LIGHT'
  | 'YIELD'
  | 'CHANGE_LANE_LEFT'
  | 'CHANGE_LANE_RIGHT'
  | 'OVERTAKE_SIMULATION'
  | 'APPROACH_CROSSWALK'
  | 'EMERGENCY_STOP_SIMULATION'
  | 'DEGRADED_MODE'
  | 'SAFE_HALT';

export interface BehaviourDecision {
  timestamp: number;
  state: BehaviourState;
  targetLaneId: string;
  targetSpeedMS: number;
  targetFollowingDistanceM: number;
  leadVehicleTrackId?: string;
  reasonCode: string;
  safetyMarginM: number;
  confidence: number;
}

export interface TrajectoryPoint {
  t: number; // seconds from trajectory start (0.0 to 5.0)
  x: number;
  y: number;
  yaw: number;
  speed: number;
  accel: number;
  jerk: number;
  curvature: number;
  s: number; // longitudinal Frenet
  d: number; // lateral Frenet
}

export interface TrajectoryCandidate {
  id: string;
  type: 'LANE_KEEP' | 'LANE_CHANGE_LEFT' | 'LANE_CHANGE_RIGHT' | 'EVASIVE' | 'STOP';
  points: TrajectoryPoint[];
  costTotal: number;
  costBreakdown: {
    collisionRisk: number;
    roadBoundary: number;
    speedDeviation: number;
    curvature: number;
    jerk: number;
    lateralOffset: number;
    progress: number;
    comfort: number;
  };
  isValid: boolean;
  rejectionReason?: string;
}

export interface MotionPlan {
  timestamp: number;
  chosenTrajectory: TrajectoryCandidate;
  candidateTrajectories: TrajectoryCandidate[];
  horizonSeconds: number;
  planningLatencyMs: number;
  valid: boolean;
}

// ---------------------------------------------------------------------------
// VEHICLE CONTROL COMMANDS
// ---------------------------------------------------------------------------
export interface ControlCommand {
  timestamp: number;
  throttle: number; // 0.0 .. 1.0
  brake: number; // 0.0 .. 1.0
  steeringAngleRad: number; // -maxSteer .. +maxSteer
  targetSpeedMS: number;
  controllerMode: 'STANLEY' | 'PURE_PURSUIT' | 'MPC_RESEARCH';
  crossTrackErrorM: number;
  headingErrorRad: number;
  valid: boolean;
  safetyStatus: 'NOMINAL' | 'CLAMPED' | 'OVERRIDDEN';
}

// ---------------------------------------------------------------------------
// SAFETY SUPERVISOR & FAULT INJECTION
// ---------------------------------------------------------------------------
export type SafetyVerdict =
  | 'APPROVE'
  | 'APPROVE_WITH_DEGRADATION'
  | 'REJECT'
  | 'REQUEST_REPLAN'
  | 'SIMULATED_SAFE_STOP';

export interface SafetyCheckResult {
  timestamp: number;
  verdict: SafetyVerdict;
  timeToCollisionS: number;
  minDistanceToObstacleM: number;
  maxJerkMagnitudeMS3: number;
  maxLateralAccelMS2: number;
  boundaryClearanceM: number;
  sensorHealthOk: boolean;
  localisationHealthOk: boolean;
  violations: string[];
}

export interface FaultInjectionState {
  cameraBlackout: boolean;
  lidarRainAttenuation: boolean;
  radarJamming: boolean;
  gnssUrbanCanyon: boolean;
  imuBiasDrift: boolean;
  wheelSlipCondition: boolean;
  plannerLatencySpike: boolean;
  staleTrackInject: boolean;
}

// ---------------------------------------------------------------------------
// REPLAY & EXPERIMENT METRICS
// ---------------------------------------------------------------------------
export interface ReplayFrame {
  timestamp: number;
  simTimeS: number;
  vehicleState: VehicleState;
  sensorSummary: {
    lidarPointCount: number;
    radarTargetCount: number;
    cameraDetectionCount: number;
    gnssFix: string;
  };
  tracks: ObjectTrack[];
  localisation: LocalisationEstimate;
  behaviour: BehaviourDecision;
  plan: MotionPlan;
  control: ControlCommand;
  safety: SafetyCheckResult;
  faults: FaultInjectionState;
}

export interface MetricRunSummary {
  runId: string;
  scenarioId: string;
  scenarioName: string;
  totalTimeS: number;
  distanceTraveledM: number;
  avgSpeedKmh: number;
  maxSpeedKmh: number;
  maxJerkMS3: number;
  avgJerkMS3: number;
  maxLateralAccelMS2: number;
  minTtcS: number;
  minObstacleDistanceM: number;
  laneDeviationRmseM: number;
  speedErrorRmseMS: number;
  localisationErrorRmseM: number;
  safetyInterventionsCount: number;
  nearMissCount: number;
  collisionCount: number;
  completionRatePercent: number;
  status: 'COMPLETED' | 'FAILED_SAFETY_STOP' | 'COLLISION' | 'TIMEOUT';
}
