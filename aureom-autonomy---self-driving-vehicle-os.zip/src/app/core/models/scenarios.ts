// ============================================================================
// AUREOM AUTONOMY — SCENARIO DEFINITIONS & ACTORS
// Presets for the master demonstration "AUREOM CITY LOOP" and specialized tests.
// ============================================================================

import { ActorClass, Vector2D } from './av-types';

export interface ScenarioActor {
  id: string;
  class: ActorClass;
  name: string;
  initialPos: Vector2D;
  initialSpeedMS: number;
  initialHeadingRad: number;
  lengthM: number;
  widthM: number;
  waypoints: Vector2D[];
  behaviourType: 'NORMAL' | 'AGGRESSIVE_CUT_IN' | 'JAYWALKING_PEDESTRIAN' | 'SLOW_CYCLIST' | 'STOPPED_OBSTACLE' | 'TRAFFIC_FLOW';
  activeTimeRange: [number, number]; // [startSec, endSec]
}

export interface ScenarioDefinition {
  id: string;
  name: string;
  category: 'URBAN_LOOP' | 'CRITICAL_SAFETY' | 'WEATHER_DEGRADATION' | 'SENSOR_FAULT' | 'HIGHWAY_NAVIGATION';
  description: string;
  durationLimitS: number;
  weather: 'CLEAR' | 'OVERCAST' | 'RAIN' | 'HEAVY_FOG' | 'NIGHT_WET';
  frictionMu: number;
  trafficDensity: 'LOW' | 'MEDIUM' | 'HIGH';
  initialVehiclePose: { x: number; y: number; yaw: number };
  targetSpeedLimitMS: number;
  actors: ScenarioActor[];
  trafficLightSchedule: {
    id: string;
    cycleS: number;
    initialState: 'RED' | 'GREEN' | 'YELLOW';
    greenDurationS: number;
    yellowDurationS: number;
    redDurationS: number;
  }[];
  expectedOutcome: string;
  successCriteria: {
    noCollisions: boolean;
    maxAllowedJerkMS3: number;
    minTtcS: number;
    reachDestination: boolean;
  };
}

export const SCENARIOS: ScenarioDefinition[] = [
  {
    id: 'aureom_city_loop',
    name: 'AUREOM City Loop (Master Demonstration)',
    category: 'URBAN_LOOP',
    description: 'Full closed-loop autonomy benchmark: urban grid navigation with active traffic lights, pedestrian crosswalk yielding, cyclist overtaking, cut-in vehicle response, and lane change diversion.',
    durationLimitS: 75,
    weather: 'CLEAR',
    frictionMu: 0.85,
    trafficDensity: 'MEDIUM',
    initialVehiclePose: { x: 10, y: 15, yaw: 0 },
    targetSpeedLimitMS: 13.88, // 50 km/h
    actors: [
      {
        id: 'actor_lead_car',
        name: 'Lead Saloon (Vehicle-Following)',
        class: 'VEHICLE',
        initialPos: { x: 35, y: 15 },
        initialSpeedMS: 10.5,
        initialHeadingRad: 0,
        lengthM: 4.8,
        widthM: 1.9,
        waypoints: [{ x: 35, y: 15 }, { x: 120, y: 15 }, { x: 160, y: 25 }],
        behaviourType: 'TRAFFIC_FLOW',
        activeTimeRange: [0, 60],
      },
      {
        id: 'actor_pedestrian_crosswalk',
        name: 'Crossing Pedestrian (Yield)',
        class: 'PEDESTRIAN',
        initialPos: { x: 82, y: 24 },
        initialSpeedMS: 1.3,
        initialHeadingRad: -Math.PI / 2,
        lengthM: 0.6,
        widthM: 0.6,
        waypoints: [{ x: 82, y: 24 }, { x: 82, y: 6 }],
        behaviourType: 'JAYWALKING_PEDESTRIAN',
        activeTimeRange: [8, 25],
      },
      {
        id: 'actor_cyclist_lane',
        name: 'Urban Cyclist (Overtake Target)',
        class: 'CYCLIST',
        initialPos: { x: 130, y: 15.5 },
        initialSpeedMS: 4.5,
        initialHeadingRad: 0,
        lengthM: 1.8,
        widthM: 0.7,
        waypoints: [{ x: 130, y: 15.5 }, { x: 230, y: 15.5 }],
        behaviourType: 'SLOW_CYCLIST',
        activeTimeRange: [18, 55],
      },
      {
        id: 'actor_cut_in_suv',
        name: 'Aggressive Cut-In SUV',
        class: 'VEHICLE',
        initialPos: { x: 160, y: 19 },
        initialSpeedMS: 14.0,
        initialHeadingRad: -0.15,
        lengthM: 5.0,
        widthM: 2.0,
        waypoints: [{ x: 160, y: 19 }, { x: 185, y: 15 }, { x: 230, y: 15 }],
        behaviourType: 'AGGRESSIVE_CUT_IN',
        activeTimeRange: [25, 45],
      },
      {
        id: 'actor_construction_barrier',
        name: 'Construction Barrier (Lane Obstacle)',
        class: 'OBSTACLE',
        initialPos: { x: 240, y: 15 },
        initialSpeedMS: 0,
        initialHeadingRad: 0,
        lengthM: 3.0,
        widthM: 1.5,
        waypoints: [{ x: 240, y: 15 }],
        behaviourType: 'STOPPED_OBSTACLE',
        activeTimeRange: [0, 75],
      }
    ],
    trafficLightSchedule: [
      {
        id: 'tl_junction_1',
        cycleS: 20,
        initialState: 'GREEN',
        greenDurationS: 10,
        yellowDurationS: 3,
        redDurationS: 7,
      },
      {
        id: 'tl_junction_2',
        cycleS: 24,
        initialState: 'RED',
        greenDurationS: 12,
        yellowDurationS: 3,
        redDurationS: 9,
      }
    ],
    expectedOutcome: 'Vehicle completes entire loop smoothly, obeys signalized junctions, yields to pedestrian, negotiates safe cyclist clearance, reacts to cut-in vehicle with smooth deceleration, and safely changes lanes around construction blockage.',
    successCriteria: {
      noCollisions: true,
      maxAllowedJerkMS3: 3.5,
      minTtcS: 1.8,
      reachDestination: true,
    }
  },
  {
    id: 'critical_pedestrian_occlusion',
    name: 'Blind-Spot Pedestrian Crossing',
    category: 'CRITICAL_SAFETY',
    description: 'A pedestrian suddenly darts out from behind parked vehicles at a mid-block crossing. Evaluates emergency perception detection latency, time-to-collision safety supervisor veto, and safe deceleration braking envelope.',
    durationLimitS: 25,
    weather: 'CLEAR',
    frictionMu: 0.85,
    trafficDensity: 'LOW',
    initialVehiclePose: { x: 10, y: 15, yaw: 0 },
    targetSpeedLimitMS: 12.5,
    actors: [
      {
        id: 'actor_parked_van',
        name: 'Occluding Parked Delivery Van',
        class: 'TRUCK',
        initialPos: { x: 55, y: 19 },
        initialSpeedMS: 0,
        initialHeadingRad: 0,
        lengthM: 6.2,
        widthM: 2.2,
        waypoints: [{ x: 55, y: 19 }],
        behaviourType: 'STOPPED_OBSTACLE',
        activeTimeRange: [0, 25],
      },
      {
        id: 'actor_hidden_child',
        name: 'Fast-Moving Pedestrian',
        class: 'PEDESTRIAN',
        initialPos: { x: 58, y: 20.5 },
        initialSpeedMS: 3.0,
        initialHeadingRad: -Math.PI / 2,
        lengthM: 0.5,
        widthM: 0.5,
        waypoints: [{ x: 58, y: 20.5 }, { x: 58, y: 10 }],
        behaviourType: 'JAYWALKING_PEDESTRIAN',
        activeTimeRange: [3, 15],
      }
    ],
    trafficLightSchedule: [],
    expectedOutcome: 'Perception detects pedestrian upon clearing occlusion; Safety supervisor detects TTC < 1.5s; low-level brake controller commands emergency deceleration (-6.0 m/s²) coming to a stop 3.5m prior to pedestrian.',
    successCriteria: {
      noCollisions: true,
      maxAllowedJerkMS3: 6.5,
      minTtcS: 1.2,
      reachDestination: false,
    }
  },
  {
    id: 'heavy_rain_sensor_attenuation',
    name: 'Monsoon Rain & Optical Sensor Degradation',
    category: 'WEATHER_DEGRADATION',
    description: 'Heavy precipitation degrading camera optical clarity and introducing high LiDAR backscatter noise. Evaluates radar-heavy sensor fusion EKF resilience and degraded-mode speed reduction.',
    durationLimitS: 40,
    weather: 'RAIN',
    frictionMu: 0.40,
    trafficDensity: 'MEDIUM',
    initialVehiclePose: { x: 10, y: 15, yaw: 0 },
    targetSpeedLimitMS: 11.11, // 40 km/h reduced
    actors: [
      {
        id: 'actor_rain_lead',
        name: 'Spray-Generating Lead Truck',
        class: 'TRUCK',
        initialPos: { x: 45, y: 15 },
        initialSpeedMS: 9.0,
        initialHeadingRad: 0,
        lengthM: 8.5,
        widthM: 2.5,
        waypoints: [{ x: 45, y: 15 }, { x: 180, y: 15 }],
        behaviourType: 'TRAFFIC_FLOW',
        activeTimeRange: [0, 40],
      }
    ],
    trafficLightSchedule: [],
    expectedOutcome: 'System detects degraded optical confidence, expands sensor fusion covariance, increases following headway from 1.8s to 3.2s, and caps maximum lateral acceleration due to low road friction.',
    successCriteria: {
      noCollisions: true,
      maxAllowedJerkMS3: 2.5,
      minTtcS: 2.2,
      reachDestination: true,
    }
  },
  {
    id: 'urban_canyon_gnss_outage',
    name: 'Dense High-Rise Urban Canyon GNSS Dropout',
    category: 'SENSOR_FAULT',
    description: 'Complete loss of satellite GNSS fix with high multipath reflections between tall glass skyscrapers. Tests IMU dead reckoning, wheel odometry velocity integration, and HD map lane-matching localisation fallback.',
    durationLimitS: 35,
    weather: 'CLEAR',
    frictionMu: 0.85,
    trafficDensity: 'LOW',
    initialVehiclePose: { x: 10, y: 15, yaw: 0 },
    targetSpeedLimitMS: 13.88,
    actors: [
      {
        id: 'actor_city_car',
        name: 'Nearby Traffic Actor',
        class: 'VEHICLE',
        initialPos: { x: 70, y: 19 },
        initialSpeedMS: 12.0,
        initialHeadingRad: 0,
        lengthM: 4.6,
        widthM: 1.8,
        waypoints: [{ x: 70, y: 19 }, { x: 200, y: 19 }],
        behaviourType: 'TRAFFIC_FLOW',
        activeTimeRange: [0, 35],
      }
    ],
    trafficLightSchedule: [],
    expectedOutcome: 'Localisation module handles GNSS fix degradation to NO_FIX without vehicle destabilisation, preserving <0.35m cross-track error using map-matched lane boundary tracking.',
    successCriteria: {
      noCollisions: true,
      maxAllowedJerkMS3: 3.0,
      minTtcS: 2.0,
      reachDestination: true,
    }
  },
  {
    id: 'motorway_overtake_high_speed',
    name: 'Motorway Dynamic Multi-Lane Overtake',
    category: 'HIGHWAY_NAVIGATION',
    description: 'High-speed cruising at 100 km/h (27.8 m/s). Ego vehicle encounters a slow heavy transport in the cruising lane, evaluates gap in adjacent passing lane, executes Frenet quintic polynomial lane change, passes actor, and returns to cruising lane.',
    durationLimitS: 45,
    weather: 'CLEAR',
    frictionMu: 0.90,
    trafficDensity: 'MEDIUM',
    initialVehiclePose: { x: 10, y: 15, yaw: 0 },
    targetSpeedLimitMS: 27.78, // 100 km/h
    actors: [
      {
        id: 'actor_slow_transporter',
        name: 'Slow Heavy Transporter (60 km/h)',
        class: 'TRUCK',
        initialPos: { x: 80, y: 15 },
        initialSpeedMS: 16.67,
        initialHeadingRad: 0,
        lengthM: 12.0,
        widthM: 2.6,
        waypoints: [{ x: 80, y: 15 }, { x: 500, y: 15 }],
        behaviourType: 'TRAFFIC_FLOW',
        activeTimeRange: [0, 45],
      },
      {
        id: 'actor_passing_sedan',
        name: 'Approaching Passing Vehicle',
        class: 'VEHICLE',
        initialPos: { x: 20, y: 19 },
        initialSpeedMS: 29.0,
        initialHeadingRad: 0,
        lengthM: 4.8,
        widthM: 1.9,
        waypoints: [{ x: 20, y: 19 }, { x: 500, y: 19 }],
        behaviourType: 'TRAFFIC_FLOW',
        activeTimeRange: [0, 20],
      }
    ],
    trafficLightSchedule: [],
    expectedOutcome: 'Frenet lattice planner generates candidate overtaking trajectories, validates rear-approaching passing vehicle clearance, times lane change initiation, overtakes slow truck, and returns smoothly with lateral acceleration < 1.8 m/s².',
    successCriteria: {
      noCollisions: true,
      maxAllowedJerkMS3: 2.5,
      minTtcS: 2.5,
      reachDestination: true,
    }
  }
];
