import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { join } from 'node:path';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());
const angularApp = new AngularNodeAppEngine();

/**
 * BAHNWERK 4.0 REST API Endpoints (Specification Section 54)
 */
app.get('/api/v1/network', (req, res) => {
  res.json({
    status: 'ONLINE',
    system: 'BAHNWERK 4.0',
    regions_count: 5,
    stations_count: 30,
    blocks_count: 150,
    switches_count: 40,
    signals_count: 100,
    interlockings_count: 30,
    seed: 42
  });
});

app.get('/api/v1/trains', (req, res) => {
  res.json({
    active_trains_count: 80,
    punctuality_pct: 91.7,
    total_delay_minutes: 142,
    traction_power_mw: 14.8,
    regeneration_quota_pct: 22.9
  });
});

app.get('/api/v1/interlockings', (req, res) => {
  res.json({
    interlockings_online: 30,
    total_interlockings: 30,
    active_routes_count: 8,
    redundancy_active: true
  });
});

app.get('/api/v1/telemetry', (req, res) => {
  res.json({
    catenary_voltage_kv: 15.1,
    frequency_hz: 16.7,
    sensor_stream_status: 'HEALTHY',
    sensors_active: 300
  });
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 3000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`BAHNWERK 4.0 Server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI or Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
