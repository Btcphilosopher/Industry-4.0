import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RailwaySimulationService } from '../../../services/railway-simulation.service';

@Component({
  selector: 'app-disruption-management-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="p-4 space-y-4 max-w-[1600px] mx-auto">
      <!-- Header & Scenarios Bar -->
      <div class="bg-neutral-900 border border-neutral-800 rounded-lg p-3 space-y-2">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <mat-icon class="text-amber-500 text-sm h-4 w-4">emergency</mat-icon>
            <span class="text-xs font-bold text-neutral-200 font-mono uppercase">
              STÖRUNGSMANAGEMENT & DISRUPTION OPTIMIZER (R-ENGINE)
            </span>
          </div>
          <span class="text-[11px] text-neutral-400 font-mono">
            {{ sim.incidents().length }} aktive Störungen im Streckennetz
          </span>
        </div>

        <!-- 6 Demo Scenarios Fast Trigger Buttons -->
        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 text-xs font-mono">
          <button
            (click)="sim.applyDemoScenario(1)"
            [class.border-emerald-500]="sim.activeScenario() === 'normal'"
            class="p-2 rounded bg-neutral-950 border border-neutral-800 hover:border-neutral-600 text-left transition-colors cursor-pointer">
            <div class="font-bold text-neutral-200">1. Normalbetrieb</div>
            <div class="text-[10px] text-neutral-400">Keine Störungen</div>
          </button>
          <button
            (click)="sim.applyDemoScenario(2)"
            [class.border-amber-500]="sim.activeScenario() === 'switch_fault'"
            class="p-2 rounded bg-neutral-950 border border-neutral-800 hover:border-neutral-600 text-left transition-colors cursor-pointer">
            <div class="font-bold text-amber-300">2. Weichenstörung</div>
            <div class="text-[10px] text-neutral-400">W-017 Frankfurt Hbf</div>
          </button>
          <button
            (click)="sim.applyDemoScenario(3)"
            [class.border-amber-500]="sim.activeScenario() === 'block_closed'"
            class="p-2 rounded bg-neutral-950 border border-neutral-800 hover:border-neutral-600 text-left transition-colors cursor-pointer">
            <div class="font-bold text-amber-300">3. Streckensperre</div>
            <div class="text-[10px] text-neutral-400">Block B-081 gesperrt</div>
          </button>
          <button
            (click)="sim.applyDemoScenario(4)"
            [class.border-red-500]="sim.activeScenario() === 'major_disruption'"
            class="p-2 rounded bg-neutral-950 border border-neutral-800 hover:border-neutral-600 text-left transition-colors cursor-pointer">
            <div class="font-bold text-red-400">4. Großstörung</div>
            <div class="text-[10px] text-neutral-400">Multipler Ausfall</div>
          </button>
          <button
            (click)="sim.applyDemoScenario(5)"
            [class.border-blue-500]="sim.activeScenario() === 'etcs_test'"
            class="p-2 rounded bg-neutral-950 border border-neutral-800 hover:border-neutral-600 text-left transition-colors cursor-pointer">
            <div class="font-bold text-blue-300">5. ETCS / ATO Test</div>
            <div class="text-[10px] text-neutral-400">Bremskurventest</div>
          </button>
          <button
            (click)="sim.applyDemoScenario(6)"
            [class.border-purple-500]="sim.activeScenario() === 'maintenance'"
            class="p-2 rounded bg-neutral-950 border border-neutral-800 hover:border-neutral-600 text-left transition-colors cursor-pointer">
            <div class="font-bold text-purple-300">6. Wartungsfall</div>
            <div class="text-[10px] text-neutral-400">Motorstrom 5.4A</div>
          </button>
        </div>
      </div>

      <!-- Main Grid: Incidents List + Strategy Optimizer Panel -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <!-- Incidents List & Injector (5 cols) -->
        <div class="lg:col-span-5 space-y-4">
          <!-- Active Incidents -->
          <div class="bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-3 font-mono text-xs">
            <div class="flex items-center justify-between border-b border-neutral-800 pb-2">
              <span class="font-bold text-neutral-200 uppercase">AKTIVE EREIGNISSE & STÖRUNGEN</span>
              <span class="text-[10px] text-neutral-400">{{ sim.incidents().length }} Einträge</span>
            </div>

            <div class="space-y-2">
              @for (inc of sim.incidents(); track inc.incident_id) {
                <button
                  type="button"
                  (click)="sim.selectIncident(inc.incident_id)"
                  [class.border-amber-500]="inc.incident_id === sim.selectedIncidentId()"
                  [class.bg-neutral-850]="inc.incident_id === sim.selectedIncidentId()"
                  [class.bg-neutral-950]="inc.incident_id !== sim.selectedIncidentId()"
                  class="w-full text-left p-3 rounded border border-neutral-800 hover:border-neutral-600 transition-colors cursor-pointer space-y-1.5">
                  <div class="flex items-center justify-between">
                    <span class="font-bold text-amber-300">{{ inc.type }}</span>
                    <span class="text-[10px] px-1.5 py-0.2 rounded font-bold" [class.bg-red-950]="inc.severity === 'KRITISCH'" [class.text-red-400]="inc.severity === 'KRITISCH'" [class.bg-amber-950]="inc.severity === 'WARNUNG'" [class.text-amber-400]="inc.severity === 'WARNUNG'">
                      {{ inc.severity }}
                    </span>
                  </div>
                  <div class="text-neutral-200 font-semibold leading-snug">{{ inc.title }}</div>
                  <div class="text-[11px] text-neutral-400">Ort: {{ inc.location_name }}</div>
                  <div class="flex justify-between items-center text-[11px] text-neutral-400 pt-1 border-t border-neutral-900">
                    <span>{{ inc.affected_train_ids.length }} Züge betroffen</span>
                    <span class="text-amber-400">+{{ inc.avg_delay_addition_min }} min Prognose</span>
                  </div>
                </button>
              } @empty {
                <div class="p-6 text-center text-neutral-500">
                  Keine ungelösten Störungen vorhanden.
                </div>
              }
            </div>
          </div>

          <!-- Custom Disruption Injector -->
          <div class="bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-3 font-mono text-xs">
            <div class="text-xs font-bold text-neutral-200 uppercase border-b border-neutral-800 pb-2">
              STÖRUNG MANUELL INJIZIEREN (TESTUMGEBUNG)
            </div>

            <div class="grid grid-cols-2 gap-2">
              <button
                (click)="sim.setSwitchFault('sw-17', true)"
                class="p-2 rounded bg-neutral-950 border border-neutral-700 hover:bg-neutral-800 text-amber-400 cursor-pointer text-left">
                <div class="font-bold">Weichenfehler W-017</div>
                <div class="text-[10px] text-neutral-400 mt-0.5">Endlagenprüferkreis</div>
              </button>

              <button
                (click)="sim.setBlockState('blk-81', 'GESPERRT')"
                class="p-2 rounded bg-neutral-950 border border-neutral-700 hover:bg-neutral-800 text-amber-400 cursor-pointer text-left">
                <div class="font-bold">Gleissperre B-081</div>
                <div class="text-[10px] text-neutral-400 mt-0.5">Gleisbettverwerfung</div>
              </button>

              <button
                (click)="sim.setBlockState('blk-46', 'STÖRUNG')"
                class="p-2 rounded bg-neutral-950 border border-neutral-700 hover:bg-neutral-800 text-red-400 cursor-pointer text-left">
                <div class="font-bold">Oberleitungsschaden</div>
                <div class="text-[10px] text-neutral-400 mt-0.5">Spannungsabfall 15kV</div>
              </button>

              <button
                (click)="sim.setSignalAspect('sig-1', 'HALT')"
                class="p-2 rounded bg-neutral-950 border border-neutral-700 hover:bg-neutral-800 text-neutral-300 cursor-pointer text-left">
                <div class="font-bold">Signalstörung S-001</div>
                <div class="text-[10px] text-neutral-400 mt-0.5">Dauerrot HP 0</div>
              </button>
            </div>
          </div>
        </div>

        <!-- Strategy Optimizer & Impact Comparison (7 cols) -->
        <div class="lg:col-span-7 space-y-4">
          @if (sim.selectedIncident(); as inc) {
            <div class="bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-4 font-mono text-xs">
              <div class="flex items-center justify-between border-b border-neutral-800 pb-3">
                <div>
                  <div class="flex items-center gap-2">
                    <span class="text-sm font-bold text-neutral-100">{{ inc.title }}</span>
                    <span class="text-[10px] px-2 py-0.5 rounded bg-red-950 text-red-400 border border-red-800 font-bold">
                      {{ inc.severity }}
                    </span>
                  </div>
                  <div class="text-[11px] text-neutral-400 mt-0.5">
                    Objekt: {{ inc.entity_name }} &middot; Erfasst: {{ inc.timestamp }}
                  </div>
                </div>

                <button
                  (click)="sim.resolveIncident(inc.incident_id)"
                  class="px-3 py-1.5 rounded bg-emerald-950 border border-emerald-700 hover:bg-emerald-900 text-emerald-400 font-bold flex items-center gap-1 cursor-pointer">
                  <mat-icon class="text-xs h-3.5 w-3.5">check_circle</mat-icon>
                  Störung beheben
                </button>
              </div>

              <div class="p-3 rounded bg-neutral-950 border border-neutral-800 text-neutral-300 leading-relaxed">
                {{ inc.description }}
              </div>

              <!-- R Disruption Optimization Strategies (A / B / C) -->
              <div class="space-y-3">
                <div class="flex items-center justify-between">
                  <span class="font-bold text-neutral-200 uppercase">
                    R-OPTIMIERER BETRIEBSSTRATEGIEN (VERGLEICH)
                  </span>
                  <span class="text-[10px] text-emerald-400">Keine 'KI-Magie': Deterministisches LP-Modell</span>
                </div>

                <div class="space-y-2">
                  @for (strat of inc.strategies; track strat.scenario_name; let sIdx = $index) {
                    <div
                      [class.border-emerald-500]="strat.recommended"
                      [class.bg-neutral-950]="!strat.recommended"
                      [class.bg-emerald-950/20]="strat.recommended"
                      class="p-3 rounded border border-neutral-800 space-y-2">
                      <div class="flex items-center justify-between">
                        <div class="flex items-center gap-2">
                          <span class="font-bold text-neutral-100">{{ strat.scenario_name }}</span>
                          @if (strat.recommended) {
                            <span class="text-[10px] px-1.5 py-0.2 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 font-bold">
                              OPTIMALE EMPFEHLUNG
                            </span>
                          }
                        </div>
                        <span class="text-amber-400 font-bold tabular-nums">
                          +{{ strat.total_delay_min }} min Gesamtverspätung
                        </span>
                      </div>

                      <div class="text-[11px] text-neutral-300">
                        {{ strat.description }}
                      </div>

                      <div class="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[10px] pt-1 text-neutral-400">
                        <div>Betroffene Züge: <span class="text-neutral-200 font-bold">{{ strat.affected_trains_count }}</span></div>
                        <div>Machbarkeit: <span class="text-emerald-400 font-bold">{{ strat.feasibility_score }}%</span></div>
                        <div>Fahrgastauswirkung: <span class="text-neutral-200">{{ strat.passenger_impact }}</span></div>
                      </div>

                      <!-- Apply Button -->
                      <div class="pt-2 flex justify-end">
                        <button
                          (click)="sim.applyDisruptionStrategy(inc.incident_id, sIdx)"
                          class="px-3 py-1 rounded bg-neutral-900 border border-neutral-700 hover:bg-neutral-800 text-neutral-200 text-[11px] font-bold flex items-center gap-1 cursor-pointer">
                          <mat-icon class="text-xs h-3.5 w-3.5 text-amber-400">play_arrow</mat-icon>
                          Diese Strategie anwenden
                        </button>
                      </div>
                    </div>
                  }
                </div>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class DisruptionManagementView {
  readonly sim = inject(RailwaySimulationService);
}
