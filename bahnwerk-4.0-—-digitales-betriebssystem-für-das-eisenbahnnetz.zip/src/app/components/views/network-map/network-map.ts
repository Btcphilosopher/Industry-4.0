import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RailwaySimulationService } from '../../../services/railway-simulation.service';
import { BlockSection, Switch } from '../../../models/railway.models';

@Component({
  selector: 'app-network-map-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="p-4 space-y-4 max-w-[1600px] mx-auto">
      <!-- Top Control Bar: Region Filters, Layer Toggles, Mode Switcher -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-neutral-900 border border-neutral-800 rounded-lg p-3">
        <!-- Region Filter Tabs -->
        <div class="flex items-center gap-1 bg-neutral-950 p-1 rounded border border-neutral-800 text-xs font-mono">
          <button
            (click)="selectedRegion.set('ALLE')"
            [class.bg-amber-500]="selectedRegion() === 'ALLE'"
            [class.text-neutral-950]="selectedRegion() === 'ALLE'"
            [class.font-bold]="selectedRegion() === 'ALLE'"
            [class.text-neutral-400]="selectedRegion() !== 'ALLE'"
            class="px-2.5 py-1 rounded transition-colors cursor-pointer">
            Gesamtnetz (5 Reg.)
          </button>
          @for (reg of ['NORD', 'WEST', 'MITTE', 'SUED', 'OST']; track reg) {
            <button
              (click)="selectedRegion.set(reg)"
              [class.bg-amber-500]="selectedRegion() === reg"
              [class.text-neutral-950]="selectedRegion() === reg"
              [class.font-bold]="selectedRegion() === reg"
              [class.text-neutral-400]="selectedRegion() !== reg"
              class="px-2 py-1 rounded transition-colors cursor-pointer">
              {{ reg }}
            </button>
          }
        </div>

        <!-- Train Type Filter -->
        <div class="flex items-center gap-1 bg-neutral-950 p-1 rounded border border-neutral-800 text-xs font-mono">
          <button
            (click)="selectedTrainType.set('ALLE')"
            [class.bg-blue-600]="selectedTrainType() === 'ALLE'"
            [class.text-white]="selectedTrainType() === 'ALLE'"
            [class.text-neutral-400]="selectedTrainType() !== 'ALLE'"
            class="px-2 py-1 rounded transition-colors cursor-pointer">
            Alle Züge
          </button>
          @for (tt of ['ICE', 'IC', 'RE', 'RB', 'S-BAHN', 'GÜTERZUG']; track tt) {
            <button
              (click)="selectedTrainType.set(tt)"
              [class.bg-blue-600]="selectedTrainType() === tt"
              [class.text-white]="selectedTrainType() === tt"
              [class.text-neutral-400]="selectedTrainType() !== tt"
              class="px-2 py-1 rounded transition-colors cursor-pointer">
              {{ tt }}
            </button>
          }
        </div>

        <!-- Display Layer Toggles -->
        <div class="flex items-center gap-3 text-xs font-mono text-neutral-300">
          <label class="flex items-center gap-1.5 cursor-pointer">
            <input type="checkbox" [checked]="showSignals()" (change)="showSignals.set(!showSignals())" class="accent-amber-500 rounded">
            Signale (100)
          </label>
          <label class="flex items-center gap-1.5 cursor-pointer">
            <input type="checkbox" [checked]="showSwitches()" (change)="showSwitches.set(!showSwitches())" class="accent-amber-500 rounded">
            Weichen (40)
          </label>
          <label class="flex items-center gap-1.5 cursor-pointer">
            <input type="checkbox" [checked]="showTrainLabels()" (change)="showTrainLabels.set(!showTrainLabels())" class="accent-amber-500 rounded">
            Zugnummern
          </label>
        </div>
      </div>

      <!-- Main Layout: SVG Track Schematic Canvas + Sidebar Inspector -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <!-- SVG Map Container (8 cols) -->
        <div class="lg:col-span-8 bg-neutral-900 border border-neutral-800 rounded-lg p-3 flex flex-col justify-between">
          <div class="flex items-center justify-between mb-2">
            <div class="flex items-center gap-2">
              <mat-icon class="text-amber-500 text-sm h-4 w-4">share</mat-icon>
              <span class="text-xs font-bold text-neutral-200 font-mono">
                SCHEMATISCHER GLEISNETZPLAN & DIGITALER ZWILLING
              </span>
            </div>
            <div class="text-[11px] font-mono text-neutral-400">
              Klicken Sie auf Züge, Weichen oder Streckenblöcke zur Detailinspektion
            </div>
          </div>

          <div class="relative w-full aspect-[16/11] bg-neutral-950 rounded border border-neutral-800 overflow-hidden">
            <svg viewBox="0 0 100 100" class="w-full h-full select-none">
              <!-- Grid background -->
              <defs>
                <pattern id="grid-pattern" width="5" height="5" patternUnits="userSpaceOnUse">
                  <path d="M 5 0 L 0 0 0 5" fill="none" stroke="#17202e" stroke-width="0.15"/>
                </pattern>
              </defs>
              <rect width="100" height="100" fill="url(#grid-pattern)" />

              <!-- Track Sections & Blocks -->
              @for (sec of filteredSections(); track sec.section_id) {
                @for (blk of sec.blocks; track blk.block_id) {
                  <g class="cursor-pointer" (click)="onBlockClick(blk)">
                    <!-- Glow underlay for active blocks -->
                    @if (blk.state === 'BELEGT') {
                      <line
                        [attr.x1]="blk.x1"
                        [attr.y1]="blk.y1"
                        [attr.x2]="blk.x2"
                        [attr.y2]="blk.y2"
                        stroke="#ef4444"
                        stroke-width="3"
                        stroke-opacity="0.3"
                      />
                    }
                    <!-- Track Line -->
                    <line
                      [attr.x1]="blk.x1"
                      [attr.y1]="blk.y1"
                      [attr.x2]="blk.x2"
                      [attr.y2]="blk.y2"
                      [attr.stroke]="getBlockColor(blk)"
                      [attr.stroke-width]="blk.block_id === sim.selectedBlockId() ? '2.2' : blk.state === 'BELEGT' ? '1.4' : '0.9'"
                      [attr.stroke-dasharray]="blk.state === 'GESPERRT' ? '1,0.8' : 'none'"
                    />
                  </g>
                }
              }

              <!-- Switches -->
              @if (showSwitches()) {
                @for (sw of sim.network().switches; track sw.switch_id) {
                  <g [attr.transform]="'translate(' + sw.x + ',' + sw.y + ')'" class="cursor-pointer" (click)="onSwitchClick(sw)">
                    <rect
                      x="-1.2"
                      y="-1.2"
                      width="2.4"
                      height="2.4"
                      [attr.fill]="sw.state === 'FAULT' ? '#ef4444' : sw.position === 'GERADE' ? '#10b981' : '#f59e0b'"
                      stroke="#0f172a"
                      stroke-width="0.3"
                      rx="0.4"
                    />
                    <text
                      x="0"
                      y="0.6"
                      fill="#0f172a"
                      font-size="1.4"
                      font-family="JetBrains Mono"
                      font-weight="bold"
                      text-anchor="middle">
                      W
                    </text>
                  </g>
                }
              }

              <!-- Signals -->
              @if (showSignals()) {
                @for (sig of sim.network().signals; track sig.signal_id) {
                  <g [attr.transform]="'translate(' + sig.x + ',' + sig.y + ')'" class="cursor-pointer">
                    <circle
                      r="0.8"
                      [attr.fill]="sig.aspect === 'HALT' ? '#ef4444' : sig.aspect === 'WARNUNG' ? '#f59e0b' : '#10b981'"
                      stroke="#000000"
                      stroke-width="0.2"
                    />
                  </g>
                }
              }

              <!-- Stations -->
              @for (st of sim.network().stations; track st.id) {
                <g [attr.transform]="'translate(' + st.x + ',' + st.y + ')'" class="cursor-pointer" (click)="onStationClick(st.id)">
                  <circle
                    r="1.8"
                    [attr.fill]="st.id === sim.selectedStationId() ? '#f59e0b' : st.is_hub ? '#38bdf8' : '#64748b'"
                    stroke="#020617"
                    stroke-width="0.5"
                  />
                  <text
                    x="2.4"
                    y="0.8"
                    fill="#e2e8f0"
                    font-size="2.2"
                    font-family="JetBrains Mono"
                    font-weight="600">
                    {{ st.name.replace(' Hbf', '') }}
                  </text>
                </g>
              }

              <!-- Trains -->
              @for (t of filteredTrains(); track t.train_id) {
                <g [attr.transform]="'translate(' + t.x + ',' + t.y + ')'" class="cursor-pointer" (click)="onTrainClick(t.train_id)">
                  <!-- Train Marker -->
                  <circle
                    r="1.4"
                    [attr.fill]="t.train_id === sim.selectedTrainId() ? '#f59e0b' : t.train_type === 'ICE' ? '#ffffff' : t.train_type === 'GÜTERZUG' ? '#10b981' : '#3b82f6'"
                    stroke="#020617"
                    stroke-width="0.4"
                  />
                  <!-- Direction indicator -->
                  <polygon
                    points="0,-0.8 0.9,0.8 -0.9,0.8"
                    [attr.transform]="'rotate(' + (t.direction_angle + 90) + ')'"
                    [attr.fill]="t.train_id === sim.selectedTrainId() ? '#000000' : '#f59e0b'"
                  />

                  @if (showTrainLabels() || t.train_id === sim.selectedTrainId()) {
                    <rect
                      x="2"
                      y="-2.4"
                      width="12"
                      height="4"
                      fill="#090d16"
                      stroke="#334155"
                      stroke-width="0.3"
                      rx="0.5"
                    />
                    <text
                      x="2.8"
                      y="0.2"
                      fill="#f8fafc"
                      font-size="1.8"
                      font-family="JetBrains Mono"
                      font-weight="bold">
                      {{ t.train_number }} ({{ t.current_speed_kmh }} km/h)
                    </text>
                  }
                </g>
              }
            </svg>
          </div>
        </div>

        <!-- Right: Real-time Object Inspector Panel (4 cols) -->
        <div class="lg:col-span-4 space-y-4">
          <!-- Selected Block or Switch Inspector -->
          <div class="bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-3">
            @if (sim.selectedBlock(); as blk) {
              <div class="flex items-center justify-between border-b border-neutral-800 pb-2">
                <div class="flex items-center gap-2">
                  <mat-icon class="text-amber-500 text-sm h-4 w-4">visibility</mat-icon>
                  <span class="text-xs font-bold text-neutral-200 font-mono">
                    INSPEKTOR: STRECKENBLOCK / WEICHE
                  </span>
                </div>
                <span class="text-[10px] px-2 py-0.5 rounded bg-neutral-800 text-neutral-300 font-mono">
                  {{ blk.code }}
                </span>
              </div>

              <div class="space-y-2 text-xs font-mono">
                <div class="flex justify-between py-1 border-b border-neutral-900">
                  <span class="text-neutral-400">Abschnitt:</span>
                  <span class="text-neutral-200 font-semibold">{{ blk.name }}</span>
                </div>
                <div class="flex justify-between py-1 border-b border-neutral-900">
                  <span class="text-neutral-400">Zustand:</span>
                  <span class="font-bold" [class.text-emerald-400]="blk.state === 'FREI'" [class.text-red-400]="blk.state === 'BELEGT'" [class.text-amber-400]="blk.state === 'GESPERRT'">
                    {{ blk.state }}
                  </span>
                </div>
                <div class="flex justify-between py-1 border-b border-neutral-900">
                  <span class="text-neutral-400">Blocklänge / Vmax:</span>
                  <span class="text-neutral-200">{{ blk.length_m }} m / {{ blk.max_speed_kmh }} km/h</span>
                </div>
                <div class="flex justify-between py-1 border-b border-neutral-900">
                  <span class="text-neutral-400">Schienentemperatur:</span>
                  <span class="text-neutral-200">{{ blk.track_temperature_c }} °C</span>
                </div>
                <div class="flex justify-between py-1 border-b border-neutral-900">
                  <span class="text-neutral-400">Vibrations-RMS:</span>
                  <span class="text-neutral-200">{{ blk.vibration_rms }} mm/s</span>
                </div>
                <div class="flex justify-between py-1 border-b border-neutral-900">
                  <span class="text-neutral-400">Zugeordnetes Stellwerk:</span>
                  <span class="text-neutral-200">{{ blk.interlocking_id }}</span>
                </div>

                <!-- Block Dispatch Actions -->
                <div class="pt-2 flex gap-2">
                  <button
                    (click)="sim.setBlockState(blk.block_id, blk.state === 'GESPERRT' ? 'FREI' : 'GESPERRT')"
                    class="w-full py-1.5 rounded bg-neutral-950 border border-neutral-700 hover:bg-neutral-800 text-amber-400 flex items-center justify-center gap-1 cursor-pointer">
                    <mat-icon class="text-xs h-3.5 w-3.5">lock</mat-icon>
                    {{ blk.state === 'GESPERRT' ? 'Block freigeben' : 'Block sperren' }}
                  </button>
                </div>
              </div>
            }
          </div>

          <!-- Selected Switch Quick Control -->
          <div class="bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-3">
            @if (sim.selectedSwitch(); as sw) {
              <div class="flex items-center justify-between border-b border-neutral-800 pb-2">
                <div class="flex items-center gap-2">
                  <mat-icon class="text-emerald-400 text-sm h-4 w-4">alt_route</mat-icon>
                  <span class="text-xs font-bold text-neutral-200 font-mono">
                    WEICHENSTEUERUNG ({{ sw.code }})
                  </span>
                </div>
                <span class="text-[10px] px-1.5 py-0.2 rounded font-mono" [class.bg-emerald-950]="sw.state === 'IDLE' || sw.state === 'POSITIONED'" [class.text-emerald-400]="sw.state === 'IDLE' || sw.state === 'POSITIONED'" [class.bg-red-950]="sw.state === 'FAULT'" [class.text-red-400]="sw.state === 'FAULT'">
                  {{ sw.state }}
                </span>
              </div>

              <div class="space-y-2 text-xs font-mono">
                <div class="flex justify-between py-1 border-b border-neutral-900">
                  <span class="text-neutral-400">Position:</span>
                  <span class="text-neutral-100 font-bold">{{ sw.position }}</span>
                </div>
                <div class="flex justify-between py-1 border-b border-neutral-900">
                  <span class="text-neutral-400">Motorstrom (Antrieb):</span>
                  <span [class.text-red-400]="sw.motor_current_mA > 4500" [class.text-neutral-200]="sw.motor_current_mA <= 4500">
                    {{ sw.motor_current_mA }} mA
                  </span>
                </div>
                <div class="flex justify-between py-1 border-b border-neutral-900">
                  <span class="text-neutral-400">Schaltzyklen:</span>
                  <span class="text-neutral-200">{{ sw.cycle_count }}</span>
                </div>

                <div class="grid grid-cols-2 gap-2 pt-2">
                  <button
                    (click)="sim.setSwitchPosition(sw.switch_id, 'GERADE')"
                    [disabled]="sw.position === 'GERADE' || sw.state === 'FAULT'"
                    class="py-1.5 rounded bg-neutral-950 border border-neutral-700 disabled:opacity-40 hover:bg-neutral-800 text-neutral-200 cursor-pointer">
                    GERADE
                  </button>
                  <button
                    (click)="sim.setSwitchPosition(sw.switch_id, 'ABZWEIG')"
                    [disabled]="sw.position === 'ABZWEIG' || sw.state === 'FAULT'"
                    class="py-1.5 rounded bg-neutral-950 border border-neutral-700 disabled:opacity-40 hover:bg-neutral-800 text-amber-400 cursor-pointer">
                    ABZWEIG
                  </button>
                </div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `
})
export class NetworkMapView {
  readonly sim = inject(RailwaySimulationService);

  readonly selectedRegion = signal<string>('ALLE');
  readonly selectedTrainType = signal<string>('ALLE');
  readonly showSignals = signal<boolean>(true);
  readonly showSwitches = signal<boolean>(true);
  readonly showTrainLabels = signal<boolean>(false);

  readonly filteredSections = computed(() => {
    const reg = this.selectedRegion();
    if (reg === 'ALLE') return this.sim.network().track_sections;
    return this.sim.network().track_sections.filter((s) => s.region === reg);
  });

  readonly filteredTrains = computed(() => {
    const tt = this.selectedTrainType();
    if (tt === 'ALLE') return this.sim.trains();
    return this.sim.trains().filter((t) => t.train_type === tt);
  });

  getBlockColor(blk: BlockSection): string {
    if (blk.state === 'BELEGT') return '#ef4444';
    if (blk.state === 'GESPERRT') return '#f59e0b';
    if (blk.state === 'STÖRUNG') return '#dc2626';
    if (blk.state === 'RESERVIERT') return '#eab308';
    return '#334155';
  }

  onBlockClick(blk: BlockSection): void {
    this.sim.selectBlock(blk.block_id);
  }

  onSwitchClick(sw: Switch): void {
    this.sim.selectSwitch(sw.switch_id);
  }

  onStationClick(stId: string): void {
    this.sim.selectStation(stId);
  }

  onTrainClick(trId: string): void {
    this.sim.selectTrain(trId);
  }
}
