import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RailwaySimulationService } from '../../../services/railway-simulation.service';

@Component({
  selector: 'app-audit-log-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="p-4 space-y-4 max-w-[1600px] mx-auto font-mono text-xs">
      <!-- Header & Export Actions -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-neutral-900 border border-neutral-800 rounded-lg p-3">
        <div class="flex items-center gap-2">
          <mat-icon class="text-amber-500 text-sm h-4 w-4">receipt_long</mat-icon>
          <span class="font-bold text-neutral-200 uppercase">
            UNVERÄNDERLICHES EREIGNIS- & AUDIT-PROTOKOLL (AUDIT TRAIL)
          </span>
        </div>

        <div class="flex items-center gap-2">
          <!-- Severity Filter -->
          <div class="flex items-center gap-1 bg-neutral-950 p-1 rounded border border-neutral-800 text-xs">
            @for (sev of ['ALLE', 'INFO', 'WARNUNG', 'KRITISCH']; track sev) {
              <button
                (click)="severityFilter.set(sev)"
                [class.bg-amber-500]="severityFilter() === sev"
                [class.text-neutral-950]="severityFilter() === sev"
                [class.font-bold]="severityFilter() === sev"
                [class.text-neutral-400]="severityFilter() !== sev"
                class="px-2 py-0.5 rounded transition-colors cursor-pointer">
                {{ sev }}
              </button>
            }
          </div>

          <!-- Export Buttons -->
          <button
            (click)="sim.exportAuditLogJson()"
            class="px-2.5 py-1 rounded bg-neutral-950 border border-neutral-700 hover:bg-neutral-800 text-neutral-200 flex items-center gap-1 cursor-pointer">
            <mat-icon class="text-xs h-3.5 w-3.5 text-blue-400">download</mat-icon>
            JSON Export
          </button>
          <button
            (click)="sim.exportAuditLogCsv()"
            class="px-2.5 py-1 rounded bg-neutral-950 border border-neutral-700 hover:bg-neutral-800 text-neutral-200 flex items-center gap-1 cursor-pointer">
            <mat-icon class="text-xs h-3.5 w-3.5 text-emerald-400">table_view</mat-icon>
            CSV Export
          </button>
        </div>
      </div>

      <!-- Audit Logs Table -->
      <div class="bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-3">
        <div class="flex items-center justify-between border-b border-neutral-800 pb-2">
          <span class="font-bold text-neutral-200 uppercase">EREIGNISSE ({{ filteredLogs().length }} PROTOKOLLEINTRÄGE)</span>
          <span class="text-[10px] text-neutral-400">Deterministisch getaktet</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-[11px]">
            <thead class="text-neutral-500 border-b border-neutral-800">
              <tr>
                <th class="py-2">ZEIT</th>
                <th class="py-2">EREIGNISTYP</th>
                <th class="py-2">OBJEKT</th>
                <th class="py-2">QUELLE</th>
                <th class="py-2">STATUSÜBERGANG</th>
                <th class="py-2">SCHWEREGRAD</th>
                <th class="py-2">DETAILS</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-neutral-900 text-neutral-300">
              @for (log of filteredLogs(); track log.id) {
                <tr class="hover:bg-neutral-950/60 transition-colors">
                  <td class="py-2 text-neutral-400 font-bold">{{ log.timestamp }}</td>
                  <td class="py-2 text-amber-400 font-semibold">{{ log.event_type }}</td>
                  <td class="py-2 text-neutral-200">{{ log.entity_name }}</td>
                  <td class="py-2 text-neutral-400">{{ log.source }}</td>
                  <td class="py-2 text-neutral-400">
                    <span class="text-neutral-500">{{ log.old_state }}</span> &rarr; <span class="text-neutral-200 font-bold">{{ log.new_state }}</span>
                  </td>
                  <td class="py-2">
                    <span class="px-1.5 py-0.2 rounded text-[10px] font-bold" [class.bg-red-950]="log.severity === 'KRITISCH'" [class.text-red-400]="log.severity === 'KRITISCH'" [class.bg-amber-950]="log.severity === 'WARNUNG'" [class.text-amber-400]="log.severity === 'WARNUNG'" [class.bg-neutral-800]="log.severity === 'INFO'" [class.text-neutral-400]="log.severity === 'INFO'">
                      {{ log.severity }}
                    </span>
                  </td>
                  <td class="py-2 text-neutral-400 max-w-md truncate">{{ log.details }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class AuditLogView {
  readonly sim = inject(RailwaySimulationService);
  readonly severityFilter = signal<string>('ALLE');

  readonly filteredLogs = computed(() => {
    const sev = this.severityFilter();
    if (sev === 'ALLE') return this.sim.auditLogs();
    return this.sim.auditLogs().filter((l) => l.severity === sev);
  });
}
