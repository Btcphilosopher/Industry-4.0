import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RailwaySimulationService } from '../../../services/railway-simulation.service';

@Component({
  selector: 'app-trains-inspector-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="p-4 space-y-4 max-w-[1600px] mx-auto">
      <!-- Top Train List Header & Filters -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-neutral-900 border border-neutral-800 rounded-lg p-3">
        <div class="flex items-center gap-2">
          <mat-icon class="text-amber-500 text-sm h-4 w-4">train</mat-icon>
          <span class="text-xs font-bold text-neutral-200 font-mono uppercase">
            FLOTTE & ZUG-DIGITAL-TWIN ({{ sim.trains().length }} Züge synchron)
          </span>
        </div>

        <div class="flex items-center gap-2">
          <!-- Type Filter -->
          <div class="flex items-center gap-1 bg-neutral-950 p-1 rounded border border-neutral-800 text-xs font-mono">
            @for (tType of ['ALLE', 'ICE', 'IC', 'RE', 'RB', 'S-BAHN', 'GÜTERZUG']; track tType) {
              <button
                (click)="filterType.set(tType)"
                [class.bg-amber-500]="filterType() === tType"
                [class.text-neutral-950]="filterType() === tType"
                [class.font-bold]="filterType() === tType"
                [class.text-neutral-400]="filterType() !== tType"
                class="px-2 py-0.5 rounded transition-colors cursor-pointer">
                {{ tType }}
              </button>
            }
          </div>

          <!-- Delay Only Toggle -->
          <button
            (click)="onlyDelayed.set(!onlyDelayed())"
            [class.bg-amber-950]="onlyDelayed()"
            [class.text-amber-400]="onlyDelayed()"
            [class.border-amber-700]="onlyDelayed()"
            class="px-2.5 py-1 rounded bg-neutral-950 border border-neutral-800 text-xs font-mono text-neutral-300 transition-colors cursor-pointer flex items-center gap-1">
            <mat-icon class="text-xs h-3.5 w-3.5">schedule</mat-icon>
            Nur verspätete Züge
          </button>
        </div>
      </div>

      <!-- Main Layout: Train Table + Detailed Digital Twin Inspector -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <!-- Train List Table (5 cols) -->
        <div class="lg:col-span-5 bg-neutral-900 border border-neutral-800 rounded-lg p-3 flex flex-col h-[750px]">
          <div class="text-xs font-bold text-neutral-400 font-mono mb-2 flex items-center justify-between">
            <span>ZUGÜBERSICHT ({{ filteredTrains().length }})</span>
            <span>STATUS / VERSÄTUNG</span>
          </div>

          <div class="overflow-y-auto flex-1 space-y-1 pr-1 scrollbar-thin">
            @for (t of filteredTrains(); track t.train_id) {
              <button
                type="button"
                (click)="sim.selectTrain(t.train_id)"
                [class.border-amber-500]="t.train_id === sim.selectedTrainId()"
                [class.bg-neutral-850]="t.train_id === sim.selectedTrainId()"
                [class.bg-neutral-950]="t.train_id !== sim.selectedTrainId()"
                class="w-full text-left p-2.5 rounded border border-neutral-800/80 hover:border-neutral-600 transition-colors cursor-pointer flex items-center justify-between text-xs font-mono">
                <div class="space-y-0.5">
                  <div class="flex items-center gap-2">
                    <span class="font-bold text-neutral-100">{{ t.train_number }}</span>
                    <span class="text-[10px] px-1.5 py-0.2 rounded" [class.bg-blue-950]="t.train_type === 'ICE'" [class.text-blue-400]="t.train_type === 'ICE'" [class.bg-emerald-950]="t.train_type === 'GÜTERZUG'" [class.text-emerald-400]="t.train_type === 'GÜTERZUG'" [class.bg-neutral-800]="t.train_type !== 'ICE' && t.train_type !== 'GÜTERZUG'" [class.text-neutral-300]="t.train_type !== 'ICE' && t.train_type !== 'GÜTERZUG'">
                      {{ t.train_type }}
                    </span>
                  </div>
                  <div class="text-[11px] text-neutral-400 truncate max-w-[200px]">
                    {{ t.line_name }}
                  </div>
                </div>

                <div class="text-right space-y-0.5">
                  <div class="font-bold tabular-nums" [class.text-emerald-400]="t.delay_minutes === 0" [class.text-amber-400]="t.delay_minutes > 0 && t.delay_minutes < 6" [class.text-red-400]="t.delay_minutes >= 6">
                    {{ t.delay_minutes > 0 ? '+' + t.delay_minutes + ' min' : 'Pünktlich' }}
                  </div>
                  <div class="text-[10px] text-neutral-400 tabular-nums">
                    {{ t.current_speed_kmh }} km/h · {{ t.state }}
                  </div>
                </div>
              </button>
            }
          </div>
        </div>

        <!-- Train Twin Inspector & Telemetry (7 cols) -->
        <div class="lg:col-span-7 space-y-4">
          @if (sim.selectedTrain(); as tr) {
            <!-- Train Header & Quick Stats -->
            <div class="bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-3">
              <div class="flex items-center justify-between border-b border-neutral-800 pb-3">
                <div>
                  <div class="flex items-center gap-2">
                    <span class="text-lg font-bold text-neutral-100 font-mono">{{ tr.train_number }}</span>
                    <span class="text-xs px-2 py-0.5 rounded bg-amber-950 text-amber-400 border border-amber-800/60 font-mono">
                      {{ tr.model_name }}
                    </span>
                  </div>
                  <div class="text-xs text-neutral-400 font-mono mt-0.5">
                    {{ tr.operator }} · {{ tr.line_name }}
                  </div>
                </div>

                <div class="text-right font-mono">
                  <div class="text-2xl font-bold text-neutral-100 tabular-nums">
                    {{ tr.current_speed_kmh }} <span class="text-xs text-neutral-400">km/h</span>
                  </div>
                  <div class="text-[11px] text-neutral-400">
                    Vmax: {{ tr.max_speed_kmh }} km/h
                  </div>
                </div>
              </div>

              <!-- Technical Specifications Grid -->
              <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
                <div class="p-2 rounded bg-neutral-950 border border-neutral-800">
                  <div class="text-[10px] text-neutral-500 uppercase">Zuglänge / Masse</div>
                  <div class="text-neutral-200 font-semibold mt-0.5">{{ tr.length_m }} m / {{ tr.mass_t }} t</div>
                </div>
                <div class="p-2 rounded bg-neutral-950 border border-neutral-800">
                  <div class="text-[10px] text-neutral-500 uppercase">Traktionsleistung</div>
                  <div class="text-amber-400 font-semibold mt-0.5">{{ tr.energy_active_mw }} MW</div>
                </div>
                <div class="p-2 rounded bg-neutral-950 border border-neutral-800">
                  <div class="text-[10px] text-neutral-500 uppercase">Fahrgäste</div>
                  <div class="text-neutral-200 font-semibold mt-0.5">
                    {{ tr.passenger_count }} / {{ tr.passenger_capacity }} ({{ tr.passenger_capacity > 0 ? Math.round((tr.passenger_count / tr.passenger_capacity) * 100) : 0 }}%)
                  </div>
                </div>
                <div class="p-2 rounded bg-neutral-950 border border-neutral-800">
                  <div class="text-[10px] text-neutral-500 uppercase">Aktueller Block</div>
                  <div class="text-emerald-400 font-semibold mt-0.5">{{ tr.current_block_id }}</div>
                </div>
              </div>

              <!-- ETCS Level 2 & ATO Integration Box -->
              <div class="p-3 rounded bg-neutral-950 border border-neutral-800 space-y-2 font-mono text-xs">
                <div class="flex items-center justify-between text-[11px] text-neutral-400 border-b border-neutral-900 pb-1">
                  <span class="font-bold text-neutral-200 flex items-center gap-1">
                    <mat-icon class="text-xs h-3.5 w-3.5 text-blue-400">speed</mat-icon>
                    ETCS LEVEL 2 / ATO STATUS
                  </span>
                  <span class="text-emerald-400">MA GÜLTIGKEIT: {{ tr.etcs.validity_distance_m }} m</span>
                </div>

                <div class="grid grid-cols-3 gap-2 text-center pt-1">
                  <div>
                    <div class="text-[10px] text-neutral-500">ZULÄSSIGE GESCHW. (V_perm)</div>
                    <div class="text-sm font-bold text-neutral-100">{{ tr.etcs.permitted_speed_kmh }} km/h</div>
                  </div>
                  <div>
                    <div class="text-[10px] text-neutral-500">DISTANZ ZIELPUNKT</div>
                    <div class="text-sm font-bold text-amber-400">{{ tr.etcs.distance_to_target_m }} m</div>
                  </div>
                  <div>
                    <div class="text-[10px] text-neutral-500">ATO REGELMODUS</div>
                    <div class="text-sm font-bold text-blue-400">{{ tr.ato.mode }}</div>
                  </div>
                </div>
              </div>

              <!-- Real-time Sensor Telemetry Stream -->
              <div class="p-3 rounded bg-neutral-950 border border-neutral-800 space-y-2 font-mono text-xs">
                <div class="text-[11px] font-bold text-neutral-200 border-b border-neutral-900 pb-1 flex items-center justify-between">
                  <span>TELEMETRIE-STREAM (TCMS FAHRZEUGBUS)</span>
                  <span class="text-emerald-400">AKTIV · 10 Hz</span>
                </div>

                <div class="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  <div class="flex justify-between py-1 border-b border-neutral-900">
                    <span class="text-neutral-400">Fahrdraht:</span>
                    <span class="text-neutral-200">{{ tr.telemetry.pantograph_voltage_kv }} kV</span>
                  </div>
                  <div class="flex justify-between py-1 border-b border-neutral-900">
                    <span class="text-neutral-400">Oberstrom:</span>
                    <span class="text-neutral-200">{{ tr.telemetry.catenary_current_a }} A</span>
                  </div>
                  <div class="flex justify-between py-1 border-b border-neutral-900">
                    <span class="text-neutral-400">Bremsdruck:</span>
                    <span class="text-neutral-200">{{ tr.telemetry.brake_cylinder_pressure_bar }} bar</span>
                  </div>
                  <div class="flex justify-between py-1 border-b border-neutral-900">
                    <span class="text-neutral-400">Achslager T:</span>
                    <span class="text-neutral-200">{{ tr.telemetry.axle_bearing_temp_c }} °C</span>
                  </div>
                  <div class="flex justify-between py-1 border-b border-neutral-900">
                    <span class="text-neutral-400">Vibration:</span>
                    <span class="text-neutral-200">{{ tr.telemetry.wheel_vibration_mm_s }} mm/s</span>
                  </div>
                  <div class="flex justify-between py-1 border-b border-neutral-900">
                    <span class="text-neutral-400">Türen:</span>
                    <span class="text-emerald-400 font-bold">{{ tr.telemetry.doors_status }}</span>
                  </div>
                </div>
              </div>

              <!-- Itinerary Table (Fahrplan-Haltefolge) -->
              <div class="p-3 rounded bg-neutral-950 border border-neutral-800 space-y-2 font-mono text-xs">
                <div class="text-[11px] font-bold text-neutral-200 border-b border-neutral-900 pb-1">
                  FAHRPLAN-HALTEFOLGE (SOLL / IST)
                </div>

                <div class="overflow-x-auto">
                  <table class="w-full text-left text-[11px]">
                    <thead class="text-neutral-500 border-b border-neutral-900">
                      <tr>
                        <th class="py-1">BAHNHOF</th>
                        <th class="py-1">GLEIS</th>
                        <th class="py-1">PLAN AN</th>
                        <th class="py-1">IST AN</th>
                        <th class="py-1">PLAN AB</th>
                        <th class="py-1">STATUS</th>
                      </tr>
                    </thead>
                    <tbody class="divide-y divide-neutral-900 text-neutral-300">
                      @for (stop of tr.schedule; track stop.station_id) {
                        <tr [class.bg-neutral-900]="stop.status === 'AKTUELL'">
                          <td class="py-1.5 font-medium text-neutral-100">{{ stop.station_name }}</td>
                          <td class="py-1.5 text-neutral-400">{{ stop.platform }}</td>
                          <td class="py-1.5 text-neutral-400">{{ stop.planned_arrival }}</td>
                          <td class="py-1.5" [class.text-amber-400]="stop.actual_arrival && stop.actual_arrival !== stop.planned_arrival">
                            {{ stop.actual_arrival || '—' }}
                          </td>
                          <td class="py-1.5 text-neutral-400">{{ stop.planned_departure }}</td>
                          <td class="py-1.5">
                            <span class="px-1.5 py-0.2 rounded text-[10px]" [class.bg-emerald-950]="stop.status === 'BEENDET'" [class.text-emerald-400]="stop.status === 'BEENDET'" [class.bg-amber-950]="stop.status === 'AKTUELL'" [class.text-amber-400]="stop.status === 'AKTUELL'" [class.bg-neutral-900]="stop.status === 'AUSSTEHEND'" [class.text-neutral-400]="stop.status === 'AUSSTEHEND'">
                              {{ stop.status }}
                            </span>
                          </td>
                        </tr>
                      }
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class TrainsInspectorView {
  readonly sim = inject(RailwaySimulationService);
  readonly filterType = signal<string>('ALLE');
  readonly onlyDelayed = signal<boolean>(false);

  protected readonly Math = Math;

  readonly filteredTrains = computed(() => {
    let list = this.sim.trains();
    const ft = this.filterType();
    if (ft !== 'ALLE') {
      list = list.filter((t) => t.train_type === ft);
    }
    if (this.onlyDelayed()) {
      list = list.filter((t) => t.delay_minutes > 0);
    }
    return list;
  });
}
