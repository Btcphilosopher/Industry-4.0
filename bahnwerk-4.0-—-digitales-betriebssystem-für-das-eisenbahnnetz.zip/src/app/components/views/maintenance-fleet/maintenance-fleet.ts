import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RailwaySimulationService } from '../../../services/railway-simulation.service';

@Component({
  selector: 'app-maintenance-fleet-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="p-4 space-y-4 max-w-[1600px] mx-auto">
      <!-- Header -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-neutral-900 border border-neutral-800 rounded-lg p-3">
        <div class="flex items-center gap-2">
          <mat-icon class="text-amber-500 text-sm h-4 w-4">build</mat-icon>
          <span class="text-xs font-bold text-neutral-200 font-mono uppercase">
            DIGITALE INSTANDHALTUNG & PREDICTIVE MAINTENANCE (R-SENSOR-ANOMALIEERKENNUNG)
          </span>
        </div>

        <div class="text-xs font-mono text-neutral-400">
          {{ sim.workOrders().length }} Instandhaltungsaufträge
        </div>
      </div>

      <!-- Main Layout: Active Maintenance Work Orders & Sensor Degradation Curves -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <!-- Work Orders List (7 cols) -->
        <div class="lg:col-span-7 bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-4 font-mono text-xs">
          <div class="flex items-center justify-between border-b border-neutral-800 pb-2">
            <span class="font-bold text-neutral-200 uppercase">OFFENE ARBEITSAUFTRÄGE (WORK ORDERS)</span>
            <span class="text-[10px] text-amber-400">Automatisch aus Telemetrie-Grenzwertüberschreitung</span>
          </div>

          <div class="space-y-3">
            @for (wo of sim.workOrders(); track wo.order_id) {
              <div class="p-3.5 rounded bg-neutral-950 border border-neutral-800 space-y-2">
                <div class="flex items-center justify-between">
                  <div class="flex items-center gap-2">
                    <span class="font-bold text-neutral-100">{{ wo.code }}</span>
                    <span class="text-[10px] px-2 py-0.5 rounded font-bold" [class.bg-red-950]="wo.priority === 'DRINGEND'" [class.text-red-400]="wo.priority === 'DRINGEND'" [class.bg-amber-950]="wo.priority === 'WARTUNG_PLANEN'" [class.text-amber-400]="wo.priority === 'WARTUNG_PLANEN'" [class.bg-neutral-800]="wo.priority === 'BEOBACHTEN'" [class.text-neutral-300]="wo.priority === 'BEOBACHTEN'">
                      {{ wo.priority }}
                    </span>
                  </div>
                  <span class="text-[11px] font-bold" [class.text-emerald-400]="wo.status === 'ABGESCHLOSSEN'" [class.text-amber-400]="wo.status !== 'ABGESCHLOSSEN'">
                    {{ wo.status }}
                  </span>
                </div>

                <div class="text-[12px] text-neutral-200 font-semibold">
                  {{ wo.component_name }} &middot; {{ wo.location }}
                </div>

                <div class="text-[11px] text-neutral-400 leading-snug">
                  {{ wo.anomaly_description }}
                </div>

                <!-- Sensor Values list -->
                <div class="flex flex-wrap gap-2 pt-1">
                  @for (sen of wo.sensor_anomalies; track sen) {
                    <span class="px-2 py-0.5 rounded bg-neutral-900 border border-neutral-800 text-[10px] text-red-400">
                      {{ sen }}
                    </span>
                  }
                </div>

                <!-- Action button -->
                <div class="pt-2 flex justify-between items-center border-t border-neutral-900 text-[10px] text-neutral-500">
                  <span>Depot: {{ wo.assigned_depot }}</span>
                  @if (wo.status !== 'ABGESCHLOSSEN') {
                    <button
                      (click)="sim.completeWorkOrder(wo.order_id)"
                      class="px-3 py-1 rounded bg-emerald-950 border border-emerald-700 hover:bg-emerald-900 text-emerald-400 font-bold cursor-pointer">
                      Als Erledigt markieren
                    </button>
                  }
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Sensor Degradation Curves & Diagnostics (5 cols) -->
        <div class="lg:col-span-5 space-y-4">
          <!-- Weichenantrieb Motorstrom Diagramm -->
          <div class="bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-3 font-mono text-xs">
            <div class="flex items-center justify-between border-b border-neutral-800 pb-2">
              <span class="font-bold text-neutral-200 uppercase">WEICHENANTRIEB MOTORSTROMKURVE</span>
              <span class="text-[10px] text-red-400">W-017 (5.4A Peak)</span>
            </div>

            <div class="w-full h-36 bg-neutral-950 rounded border border-neutral-800 p-2">
              <svg viewBox="0 0 100 50" class="w-full h-full">
                <!-- Threshold limit line (3.5A) -->
                <line x1="0" y1="20" x2="100" y2="20" stroke="#ef4444" stroke-width="0.8" stroke-dasharray="1,1"/>
                <text x="75" y="18" fill="#ef4444" font-size="2">Limit 3.5A</text>

                <!-- Normal Curve (Green) -->
                <polyline points="0,45 10,40 15,28 35,28 40,45 100,45" fill="none" stroke="#10b981" stroke-width="1.2"/>

                <!-- Degraded W-017 Curve (Red) -->
                <polyline points="0,45 10,35 15,8 45,8 55,45 100,45" fill="none" stroke="#f59e0b" stroke-width="1.6"/>
              </svg>
            </div>
            <div class="flex justify-between text-[10px] text-neutral-500">
              <span>0.0 s (Start)</span>
              <span>1.8 s (Schwergang)</span>
              <span>3.5 s (Endlage)</span>
            </div>
          </div>

          <!-- Achslager Heißläuferortung HOA -->
          <div class="bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-3 font-mono text-xs">
            <div class="flex items-center justify-between border-b border-neutral-800 pb-2">
              <span class="font-bold text-neutral-200 uppercase">HOA / FBOA HEISSLÄUFER-DIAGNOSE</span>
              <span class="text-[10px] text-emerald-400">140 SENSOREN ONLINE</span>
            </div>

            <div class="space-y-2 text-[11px]">
              <div class="flex justify-between py-1 border-b border-neutral-900">
                <span class="text-neutral-400">HOA Messstelle Fulda Nord:</span>
                <span class="text-neutral-200 font-bold">42.1 &deg;C (Normal)</span>
              </div>
              <div class="flex justify-between py-1 border-b border-neutral-900">
                <span class="text-neutral-400">FBOA Flachstellenortung Rohr:</span>
                <span class="text-neutral-200 font-bold">0.12 mm (Frei)</span>
              </div>
              <div class="flex justify-between py-1 border-b border-neutral-900">
                <span class="text-neutral-400">Schienenprofil-Abnutzung VDE8:</span>
                <span class="text-amber-400 font-bold">0.42 mm (Schleifen geplant)</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class MaintenanceFleetView {
  readonly sim = inject(RailwaySimulationService);
}
