import { ChangeDetectionStrategy, Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BAHNWERK_CODEBASE_FILES, CodeFile } from '../../../data/codebase-files.data';

@Component({
  selector: 'app-architecture-export-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="p-4 space-y-4 max-w-[1600px] mx-auto font-mono text-xs">
      <!-- Header -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-neutral-900 border border-neutral-800 rounded-lg p-3">
        <div class="flex items-center gap-2">
          <mat-icon class="text-amber-500 text-sm h-4 w-4">code</mat-icon>
          <span class="font-bold text-neutral-200 uppercase">
            SYSTEM-ARCHITEKTUR & CODEBASE-SPEZIFIKATION (RUST / R / POSTGRESQL / DOCKER)
          </span>
        </div>

        <div class="text-[11px] text-neutral-400">
          Projektstruktur nach BAHNWERK 4.0 Standard
        </div>
      </div>

      <!-- File Explorer Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <!-- File Tree (4 cols) -->
        <div class="lg:col-span-4 bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-3">
          <div class="font-bold text-neutral-200 uppercase border-b border-neutral-800 pb-2 flex items-center gap-2">
            <mat-icon class="text-xs h-3.5 w-3.5 text-neutral-400">folder</mat-icon>
            <span>DATEIBAUM / QUELLCODE</span>
          </div>

          <div class="space-y-1">
            @for (file of files; track file.path) {
              <button
                (click)="selectedFile.set(file)"
                [class.bg-neutral-800]="selectedFile().path === file.path"
                [class.text-amber-400]="selectedFile().path === file.path"
                [class.text-neutral-300]="selectedFile().path !== file.path"
                class="w-full text-left p-2 rounded hover:bg-neutral-950 transition-colors flex items-center justify-between text-xs cursor-pointer">
                <div class="flex items-center gap-2 truncate">
                  <mat-icon class="text-xs h-3.5 w-3.5 text-neutral-500">description</mat-icon>
                  <span class="truncate">{{ file.path }}</span>
                </div>
                <span class="text-[10px] px-1.5 py-0.2 rounded bg-neutral-950 text-neutral-400 uppercase">
                  {{ file.language }}
                </span>
              </button>
            }
          </div>
        </div>

        <!-- Code Viewer (8 cols) -->
        <div class="lg:col-span-8 bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-3 flex flex-col">
          <div class="flex items-center justify-between border-b border-neutral-800 pb-2">
            <div>
              <div class="font-bold text-neutral-100">{{ selectedFile().path }}</div>
              <div class="text-[11px] text-neutral-400 mt-0.5">{{ selectedFile().description }}</div>
            </div>

            <button
              (click)="copyCode()"
              class="px-2.5 py-1 rounded bg-neutral-950 border border-neutral-700 hover:bg-neutral-800 text-neutral-200 text-xs flex items-center gap-1 cursor-pointer">
              <mat-icon class="text-xs h-3.5 w-3.5 text-neutral-400">content_copy</mat-icon>
              {{ copied() ? 'Kopiert!' : 'Kopieren' }}
            </button>
          </div>

          <pre class="bg-neutral-950 p-4 rounded border border-neutral-800/80 text-[11px] text-neutral-300 overflow-x-auto leading-relaxed flex-1 max-h-[600px] scrollbar-thin"><code>{{ selectedFile().content }}</code></pre>
        </div>
      </div>
    </div>
  `
})
export class ArchitectureExportView {
  readonly files = BAHNWERK_CODEBASE_FILES;
  readonly selectedFile = signal<CodeFile>(BAHNWERK_CODEBASE_FILES[0]);
  readonly copied = signal<boolean>(false);

  copyCode(): void {
    navigator.clipboard.writeText(this.selectedFile().content);
    this.copied.set(true);
    setTimeout(() => this.copied.set(false), 2000);
  }
}
