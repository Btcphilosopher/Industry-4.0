import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RailwaySimulationService } from '../../../services/railway-simulation.service';

@Component({
  selector: 'app-timetable-dispatch-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="p-4 space-y-4 max-w-[1600px] mx-auto">
      <!-- Header -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-neutral-900 border border-neutral-800 rounded-lg p-3">
        <div class="flex items-center gap-2">
          <mat-icon class="text-amber-500 text-sm h-4 w-4">timeline</mat-icon>
          <span class="text-xs font-bold text-neutral-200 font-mono uppercase">
            BILDFAHRPLAN (STRINGLINE-DIAGRAMM) & TRASSENMANAGEMENT
          </span>
        </div>

        <!-- Corridor Filter -->
        <div class="flex items-center gap-2">
          <span class="text-xs font-mono text-neutral-400">Korridor:</span>
          <select
            [value]="selectedCorridor()"
            (change)="onCorridorSelect($event)"
            class="bg-neutral-950 border border-neutral-800 text-neutral-200 rounded px-2.5 py-1 text-xs font-mono">
            <option value="SFS_H_WUE">SFS Hannover &ndash; Würzburg (NBS)</option>
            <option value="SFS_K_RM">SFS Köln &ndash; Rhein/Main</option>
            <option value="VDE_8">VDE 8.1 / 8.2 (Berlin &ndash; Erfurt &ndash; Nürnberg)</option>
            <option value="RHEINTAL">Rheintalbahn (Mannheim &ndash; Karlsruhe &ndash; Basel)</option>
          </select>
        </div>
      </div>

      <!-- Main Grid: Graphical Timetable (Bildfahrplan) + Conflict Monitor -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <!-- Graphical Timetable (Stringline / Bildfahrplan SVG) (8 cols) -->
        <div class="lg:col-span-8 bg-neutral-900 border border-neutral-800 rounded-lg p-4 flex flex-col justify-between font-mono text-xs">
          <div class="flex items-center justify-between mb-2">
            <div class="flex items-center gap-2">
              <span class="font-bold text-neutral-200 uppercase">GRAFISCHER BILDFAHRPLAN (ZEIT-WEG-DIAGRAMM)</span>
            </div>
            <span class="text-[11px] text-neutral-400">Zeitfenster: 14:00 &ndash; 16:00 CET</span>
          </div>

          <!-- SVG Canvas for Stringline Diagram -->
          <div class="relative w-full aspect-[16/9] bg-neutral-950 rounded border border-neutral-800 p-4">
            <svg viewBox="0 0 100 60" class="w-full h-full select-none">
              <!-- Horizontal Station Lines -->
              @for (stName of stationsAlongCorridor; track stName; let idx = $index) {
                <line x1="15" [attr.y1]="8 + idx * 10" x2="98" [attr.y2]="8 + idx * 10" stroke="#1f2937" stroke-width="0.4"/>
                <text x="0" [attr.y]="9 + idx * 10" fill="#94a3b8" font-size="2.2" font-family="JetBrains Mono">
                  {{ stName }}
                </text>
              }

              <!-- Vertical Time Grid Lines (every 15 min) -->
              @for (tLabel of timeLabels; track tLabel; let tIdx = $index) {
                <line [attr.x1]="15 + tIdx * 16" y1="5" [attr.x2]="15 + tIdx * 16" y2="52" stroke="#1e293b" stroke-width="0.3"/>
                <text [attr.x]="12 + tIdx * 16" y="56" fill="#64748b" font-size="2.0" font-family="JetBrains Mono">
                  {{ tLabel }}
                </text>
              }

              <!-- Train Stringline Trajectories -->
              <!-- ICE 742 (White solid line) -->
              <polyline points="18,8 30,18 42,28 55,38 72,48" fill="none" stroke="#ffffff" stroke-width="1.2"/>
              <text x="32" y="16" fill="#ffffff" font-size="1.8" font-weight="bold">ICE 742</text>

              <!-- ICE 1502 (Blue line) -->
              <polyline points="28,8 40,18 52,28 66,38 82,48" fill="none" stroke="#38bdf8" stroke-width="1.2"/>
              <text x="42" y="16" fill="#38bdf8" font-size="1.8">ICE 1502</text>

              <!-- RE 3812 (Amber line) -->
              <polyline points="15,48 26,38 48,28 70,18 88,8" fill="none" stroke="#f59e0b" stroke-width="1.0"/>
              <text x="50" y="26" fill="#f59e0b" font-size="1.8">RE 3812</text>

              <!-- Freight Train GAG 44102 (Green slower slope) -->
              <polyline points="15,8 35,18 60,28 88,38" fill="none" stroke="#10b981" stroke-width="0.9" stroke-dasharray="1,0.5"/>
              <text x="62" y="26" fill="#10b981" font-size="1.8">GAG 44102</text>

              <!-- Current Sim Time Vertical Marker -->
              <line x1="45" y1="5" x2="45" y2="52" stroke="#ef4444" stroke-width="0.8" stroke-dasharray="1,1"/>
              <text x="43" y="4" fill="#ef4444" font-size="2" font-weight="bold">JETZT</text>
            </svg>
          </div>

          <div class="flex items-center justify-between text-[11px] text-neutral-400 mt-2">
            <span>Legende: Steile Linie = Schneller ICE &middot; Flache Linie = Güterzug &middot; Schnittpunkte = Kreuzung</span>
            <span class="text-amber-400">Trassenauslastung: 84%</span>
          </div>
        </div>

        <!-- Right: Trassenkonflikte & Anschlusssicherung (4 cols) -->
        <div class="lg:col-span-4 space-y-4">
          <!-- Active Conflict Detector -->
          <div class="bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-3 font-mono text-xs">
            <div class="flex items-center justify-between border-b border-neutral-800 pb-2">
              <div class="flex items-center gap-2">
                <mat-icon class="text-amber-500 text-sm h-4 w-4">warning_amber</mat-icon>
                <span class="font-bold text-neutral-200 uppercase">TRASSENKONFLIKTE</span>
              </div>
              <span class="text-[10px] px-1.5 py-0.2 rounded bg-amber-950 text-amber-400 font-bold">
                1 ERKANNT
              </span>
            </div>

            <div class="p-2.5 rounded bg-neutral-950 border border-neutral-800 space-y-2">
              <div class="flex justify-between text-amber-300 font-bold">
                <span>Konflikt: Block B-081 Trassenüberschneidung</span>
              </div>
              <div class="text-[11px] text-neutral-300">
                ICE 742 (v=250 km/h) schließt auf langsameren RE 3812 (v=140 km/h) auf.
              </div>
              <div class="p-2 rounded bg-neutral-900 text-[10px] text-neutral-400 space-y-1">
                <div class="text-neutral-200 font-bold">R-DISPATCHER EMPFEHLUNG:</div>
                <div>Überholung in Augsburg Hbf Gleis 3 durchführen. RE 3812 erhält +3 min Puffer.</div>
              </div>
            </div>
          </div>

          <!-- Connection Protection (Anschlusssicherung) -->
          <div class="bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-3 font-mono text-xs">
            <div class="flex items-center justify-between border-b border-neutral-800 pb-2">
              <div class="flex items-center gap-2">
                <mat-icon class="text-emerald-400 text-sm h-4 w-4">hub</mat-icon>
                <span class="font-bold text-neutral-200 uppercase">ANSCHLUSSSICHERUNG</span>
              </div>
              <span class="text-[10px] text-neutral-400">Knoten Frankfurt / Köln</span>
            </div>

            <div class="space-y-2 text-[11px]">
              <div class="p-2 rounded bg-neutral-950 border border-neutral-800 flex justify-between items-center">
                <div>
                  <div class="text-neutral-200 font-bold">Frankfurt (M) Hbf &middot; Taktminute 00</div>
                  <div class="text-neutral-400 text-[10px]">ICE 742 &rarr; ICE 1502 (Gleis 4/5)</div>
                </div>
                <span class="text-emerald-400 font-bold">GESICHERT (4 min)</span>
              </div>

              <div class="p-2 rounded bg-neutral-950 border border-neutral-800 flex justify-between items-center">
                <div>
                  <div class="text-neutral-200 font-bold">Mannheim Hbf &middot; Taktminute 30</div>
                  <div class="text-neutral-400 text-[10px]">ICE 518 &rarr; RE 1 (Gleis 1/2)</div>
                </div>
                <span class="text-amber-400 font-bold">KNAPP (+2 min)</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class TimetableDispatchView {
  readonly sim = inject(RailwaySimulationService);
  readonly selectedCorridor = signal<string>('SFS_H_WUE');

  readonly stationsAlongCorridor = ['Hamburg', 'Hannover', 'Kassel-W.', 'Würzburg', 'Nürnberg', 'München'];
  readonly timeLabels = ['14:00', '14:30', '15:00', '15:30', '16:00', '16:30'];

  onCorridorSelect(event: Event): void {
    const val = (event.target as HTMLSelectElement).value;
    this.selectedCorridor.set(val);
  }
}
