import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RailwaySimulationService } from '../../../services/railway-simulation.service';
import { Train } from '../../../models/railway.models';

@Component({
  selector: 'app-etcs-ato-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="p-4 space-y-4 max-w-[1600px] mx-auto">
      <!-- Top Train Switcher & ETCS Mode Bar -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-neutral-900 border border-neutral-800 rounded-lg p-3">
        <div class="flex items-center gap-2">
          <mat-icon class="text-amber-500 text-sm h-4 w-4">speed</mat-icon>
          <span class="text-xs font-bold text-neutral-200 font-mono uppercase">
            ETCS LEVEL 2 DRIVER MACHINE INTERFACE (DMI) & ATO COCKPIT
          </span>
        </div>

        <!-- Train Selector -->
        <div class="flex items-center gap-2">
          <span class="text-xs font-mono text-neutral-400">Triebfahrzeug:</span>
          <select
            [value]="sim.selectedTrainId()"
            (change)="onTrainSelect($event)"
            class="bg-neutral-950 border border-neutral-800 text-neutral-200 rounded px-2.5 py-1 text-xs font-mono">
            @for (t of sim.trains(); track t.train_id) {
              <option [value]="t.train_id">{{ t.train_number }} ({{ t.model_name }})</option>
            }
          </select>
        </div>
      </div>

      <!-- Main Layout: European DMI Display + ATO Curve Controller -->
      @if (sim.selectedTrain(); as tr) {
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
          <!-- Left: ETCS DMI Instrument Cluster (7 cols) -->
          <div class="lg:col-span-7 bg-neutral-950 border-2 border-neutral-800 rounded-lg p-6 font-mono text-neutral-200 space-y-6">
            <!-- Top Status Bar (Level 2 / Full Supervision / GSM-R) -->
            <div class="flex items-center justify-between bg-neutral-900 border border-neutral-800 rounded px-3 py-1.5 text-xs">
              <div class="flex items-center gap-3">
                <span class="px-2 py-0.5 rounded bg-blue-950 text-blue-400 border border-blue-800 font-bold">
                  LEVEL 2
                </span>
                <span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 font-bold">
                  FS (FULL SUPERVISION)
                </span>
              </div>
              <div class="flex items-center gap-3 text-[11px] text-neutral-400">
                <span class="flex items-center gap-1 text-emerald-400">
                  <mat-icon class="text-xs h-3.5 w-3.5">cell_tower</mat-icon> GSM-R VERBUNDEN
                </span>
                <span>RBC: NÜRNBERG-SÜD</span>
              </div>
            </div>

            <!-- Central DMI Circular Speedometer & Distance Gauge -->
            <div class="grid grid-cols-1 sm:grid-cols-12 gap-6 items-center">
              <!-- Circular Speed Dial SVG (8 cols) -->
              <div class="sm:col-span-8 flex flex-col items-center">
                <div class="relative w-64 h-64">
                  <svg viewBox="0 0 200 200" class="w-full h-full">
                    <!-- Background Dial Circle -->
                    <circle cx="100" cy="100" r="80" fill="#090d16" stroke="#1e293b" stroke-width="8" />

                    <!-- Permitted Speed Ceiling Arc (V_perm) -->
                    <circle
                      cx="100"
                      cy="100"
                      r="80"
                      fill="none"
                      [attr.stroke]="tr.etcs.brake_curve_mode === 'INTERVENTION' ? '#ef4444' : tr.etcs.brake_curve_mode === 'WARNING' ? '#f59e0b' : '#38bdf8'"
                      stroke-width="8"
                      stroke-dasharray="380"
                      [attr.stroke-dashoffset]="380 - (380 * (tr.etcs.permitted_speed_kmh / tr.max_speed_kmh)) * 0.75"
                      transform="rotate(135 100 100)"
                    />

                    <!-- Actual Speed Needle -->
                    <line
                      x1="100"
                      y1="100"
                      x2="100"
                      y2="30"
                      stroke="#ffffff"
                      stroke-width="3.5"
                      stroke-linecap="round"
                      [attr.transform]="'rotate(' + getNeedleAngle(tr.current_speed_kmh, tr.max_speed_kmh) + ' 100 100)'"
                    />

                    <!-- Center Hub -->
                    <circle cx="100" cy="100" r="10" fill="#f59e0b" stroke="#000000" stroke-width="2" />
                  </svg>

                  <!-- Digital Speed readout center overlay -->
                  <div class="absolute inset-0 flex flex-col items-center justify-center pointer-events-none mt-16">
                    <span class="text-3xl font-extrabold text-neutral-100 tabular-nums">
                      {{ tr.current_speed_kmh }}
                    </span>
                    <span class="text-[10px] text-neutral-400 uppercase tracking-widest">km/h</span>
                  </div>
                </div>

                <div class="flex items-center gap-4 text-xs mt-2">
                  <div>V_perm: <span class="font-bold text-sky-400">{{ tr.etcs.permitted_speed_kmh }} km/h</span></div>
                  <div>V_target: <span class="font-bold text-amber-400">{{ tr.etcs.target_speed_kmh }} km/h</span></div>
                  <div>V_rel: <span class="font-bold text-emerald-400">{{ tr.etcs.release_speed_kmh }} km/h</span></div>
                </div>
              </div>

              <!-- Distance to Target Bar & Movement Authority (4 cols) -->
              <div class="sm:col-span-4 bg-neutral-900 border border-neutral-800 rounded p-3 space-y-3 text-xs">
                <div class="text-[10px] text-neutral-500 uppercase">Zielentfernung</div>
                <div class="text-xl font-bold text-amber-400 tabular-nums">
                  {{ tr.etcs.distance_to_target_m }} <span class="text-xs text-neutral-400">m</span>
                </div>

                <!-- Distance Progress Bar -->
                <div class="w-full bg-neutral-950 h-3 rounded overflow-hidden border border-neutral-800">
                  <div
                    class="bg-amber-500 h-full transition-all duration-300"
                    [style.width.%]="Math.min(100, (tr.etcs.distance_to_target_m / 4000) * 100)">
                  </div>
                </div>

                <div class="space-y-1 text-[11px] pt-2 border-t border-neutral-800">
                  <div class="flex justify-between">
                    <span class="text-neutral-500">Bremskurve:</span>
                    <span class="font-bold" [class.text-emerald-400]="tr.etcs.brake_curve_mode === 'NORMAL'" [class.text-amber-400]="tr.etcs.brake_curve_mode === 'WARNING'" [class.text-red-400]="tr.etcs.brake_curve_mode === 'INTERVENTION'">
                      {{ tr.etcs.brake_curve_mode }}
                    </span>
                  </div>
                  <div class="flex justify-between">
                    <span class="text-neutral-500">Notbremsdistanz:</span>
                    <span class="text-neutral-300">{{ tr.etcs.emergency_brake_distance_m }} m</span>
                  </div>
                  <div class="flex justify-between">
                    <span class="text-neutral-500">Betriebsbremsung:</span>
                    <span class="text-neutral-300">{{ tr.etcs.service_brake_distance_m }} m</span>
                  </div>
                </div>
              </div>
            </div>

            <!-- Cab Brake & Traction Controls -->
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
              <div class="p-2 bg-neutral-900 rounded border border-neutral-800">
                <div class="text-[10px] text-neutral-500">TRAKTIONSKRAFT</div>
                <div class="text-sm font-bold text-neutral-100 mt-0.5">{{ tr.telemetry.motor_torque_pct }} %</div>
              </div>
              <div class="p-2 bg-neutral-900 rounded border border-neutral-800">
                <div class="text-[10px] text-neutral-500">HAUPTLUFTLEITUNG</div>
                <div class="text-sm font-bold text-emerald-400 mt-0.5">{{ (5.0 - tr.telemetry.brake_cylinder_pressure_bar * 0.7).toFixed(1) }} bar</div>
              </div>
              <div class="p-2 bg-neutral-900 rounded border border-neutral-800">
                <div class="text-[10px] text-neutral-500">BREMSZYLINDER</div>
                <div class="text-sm font-bold text-amber-400 mt-0.5">{{ tr.telemetry.brake_cylinder_pressure_bar }} bar</div>
              </div>
              <div class="p-2 bg-neutral-900 rounded border border-neutral-800">
                <div class="text-[10px] text-neutral-500">PANTOGRAPH</div>
                <div class="text-sm font-bold text-neutral-100 mt-0.5">{{ tr.telemetry.pantograph_voltage_kv }} kV</div>
              </div>
            </div>
          </div>

          <!-- Right: ATO (Automatic Train Operation) Controller (5 cols) -->
          <div class="lg:col-span-5 bg-neutral-900 border border-neutral-800 rounded-lg p-4 font-mono text-xs space-y-4 flex flex-col justify-between">
            <div class="space-y-4">
              <div class="flex items-center justify-between border-b border-neutral-800 pb-2">
                <div class="flex items-center gap-2">
                  <mat-icon class="text-blue-400 text-sm h-4 w-4">smart_toy</mat-icon>
                  <span class="font-bold text-neutral-200 uppercase">ATO PROZESSRECHNER (GoA 2)</span>
                </div>
                <span class="text-[10px] px-2 py-0.5 rounded bg-blue-950 text-blue-400 border border-blue-800 font-bold">
                  {{ tr.ato.enabled ? 'ATO AKTIV' : 'MANUELL' }}
                </span>
              </div>

              <!-- ATO Real-time State -->
              <div class="p-3 bg-neutral-950 rounded border border-neutral-800 space-y-2">
                <div class="flex justify-between">
                  <span class="text-neutral-400">Fahrstrategie:</span>
                  <span class="text-blue-400 font-bold">{{ tr.ato.mode }}</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-neutral-400">Energie-Optimierung (Coasting):</span>
                  <span class="text-emerald-400 font-bold">{{ tr.ato.energy_saving_mode ? 'AKTIVIERT' : 'DEAKTIVIERT' }}</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-neutral-400">Zielhaltegenauigkeit:</span>
                  <span class="text-amber-400 font-bold">&plusmn; {{ tr.ato.target_stop_accuracy_cm }} cm</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-neutral-400">Restliche Haltezeit:</span>
                  <span class="text-neutral-200">{{ Math.round(tr.ato.dwell_time_remaining_s) }} s</span>
                </div>
              </div>

              <!-- ATO Trajectory Graph Preview -->
              <div class="space-y-1">
                <div class="text-[10px] text-neutral-500 uppercase">Fahrtverlauf-Trajektorie (Geschwindigkeitsprofil)</div>
                <div class="w-full h-32 bg-neutral-950 rounded border border-neutral-800 p-2">
                  <svg viewBox="0 0 100 50" class="w-full h-full">
                    <!-- Grid -->
                    <line x1="0" y1="25" x2="100" y2="25" stroke="#1f2937" stroke-width="0.5"/>
                    <line x1="0" y1="50" x2="100" y2="50" stroke="#1f2937" stroke-width="0.5"/>

                    <!-- Target Profile (Blue line) -->
                    <polyline
                      points="0,48 10,20 30,10 70,10 90,48 100,48"
                      fill="none"
                      stroke="#38bdf8"
                      stroke-width="1.2"
                      stroke-dasharray="1,1"
                    />

                    <!-- Actual Trajectory (White/Amber line) -->
                    <polyline
                      points="0,48 10,22 30,11 65,11"
                      fill="none"
                      stroke="#f59e0b"
                      stroke-width="1.8"
                    />

                    <!-- Current Position Point -->
                    <circle cx="65" cy="11" r="2" fill="#ffffff" stroke="#f59e0b" stroke-width="0.8" />
                  </svg>
                </div>
                <div class="flex justify-between text-[10px] text-neutral-500">
                  <span>Start (0 km)</span>
                  <span>Streckenmitte</span>
                  <span>Zielbahnsteig (Halt)</span>
                </div>
              </div>
            </div>

            <!-- ATO Action Buttons -->
            <div class="space-y-2 pt-2 border-t border-neutral-800">
              <div class="grid grid-cols-2 gap-2">
                <button
                  (click)="toggleAto(tr)"
                  class="py-2 rounded bg-neutral-950 border border-neutral-700 hover:bg-neutral-800 text-neutral-200 flex items-center justify-center gap-1 cursor-pointer">
                  <mat-icon class="text-xs h-3.5 w-3.5 text-blue-400">settings</mat-icon>
                  {{ tr.ato.enabled ? 'ATO Deaktivieren' : 'ATO Aktivieren' }}
                </button>
                <button
                  (click)="triggerPrecisionStop(tr)"
                  class="py-2 rounded bg-neutral-950 border border-neutral-700 hover:bg-neutral-800 text-amber-400 flex items-center justify-center gap-1 cursor-pointer">
                  <mat-icon class="text-xs h-3.5 w-3.5">adjust</mat-icon>
                  Präzisionshalt Auslösen
                </button>
              </div>

              <button
                (click)="triggerEmergencyBrake(tr)"
                class="w-full py-2 rounded bg-red-950 border border-red-700 hover:bg-red-900 text-red-400 font-bold flex items-center justify-center gap-1.5 cursor-pointer">
                <mat-icon class="text-xs h-3.5 w-3.5">dangerous</mat-icon>
                FÜHRERSTAND-NOTBREMSUNG AUSLÖSEN
              </button>
            </div>
          </div>
        </div>
      }
    </div>
  `
})
export class EtcsAtoView {
  readonly sim = inject(RailwaySimulationService);

  protected readonly Math = Math;

  onTrainSelect(event: Event): void {
    const val = (event.target as HTMLSelectElement).value;
    this.sim.selectTrain(val);
  }

  getNeedleAngle(speed: number, maxSpeed: number): number {
    const ratio = Math.min(1, Math.max(0, speed / (maxSpeed || 250)));
    return -135 + ratio * 270;
  }

  toggleAto(tr: Train): void {
    tr.ato.enabled = !tr.ato.enabled;
  }

  triggerPrecisionStop(tr: Train): void {
    tr.ato.mode = 'PRECISION_BRAKING';
    tr.target_speed_kmh = 0;
  }

  triggerEmergencyBrake(tr: Train): void {
    tr.current_speed_kmh = 0;
    tr.state = 'HALT';
    tr.etcs.brake_curve_mode = 'INTERVENTION';
    tr.telemetry.brake_cylinder_pressure_bar = 3.8;
  }
}
