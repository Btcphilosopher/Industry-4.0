import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RailwaySimulationService } from '../../../services/railway-simulation.service';

@Component({
  selector: 'app-r-analytics-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="p-4 space-y-4 max-w-[1600px] mx-auto font-mono text-xs">
      <!-- Header -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-neutral-900 border border-neutral-800 rounded-lg p-3">
        <div class="flex items-center gap-2">
          <mat-icon class="text-amber-500 text-sm h-4 w-4">analytics</mat-icon>
          <span class="font-bold text-neutral-200 uppercase">
            R-ANALYTIK & FORECASTING ENGINE (DATA.TABLE / LP-SOLVE / SURVIVAL)
          </span>
        </div>

        <div class="text-[11px] text-neutral-400">
          Statistischer Berechnungs-Seed: #{{ sim.seed() }} &middot; Reproduzierbar
        </div>
      </div>

      <!-- Analytics Cards & Heatmaps -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <!-- Punctuality Distribution by Corridor -->
        <div class="bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-3">
          <div class="flex items-center justify-between border-b border-neutral-800 pb-2">
            <span class="font-bold text-neutral-200 uppercase">PÜNKTLICHKEIT NACH KORRIDOR</span>
            <span class="text-emerald-400 font-bold">Ø 91.7%</span>
          </div>

          <div class="space-y-2.5 text-[11px]">
            <div>
              <div class="flex justify-between mb-1">
                <span class="text-neutral-300">SFS Köln &ndash; Rhein/Main:</span>
                <span class="text-emerald-400 font-bold">96.4%</span>
              </div>
              <div class="w-full bg-neutral-950 h-2 rounded overflow-hidden">
                <div class="bg-emerald-500 h-full" style="width: 96.4%"></div>
              </div>
            </div>

            <div>
              <div class="flex justify-between mb-1">
                <span class="text-neutral-300">VDE 8 (Berlin &ndash; Erfurt &ndash; Nürnberg):</span>
                <span class="text-emerald-400 font-bold">94.8%</span>
              </div>
              <div class="w-full bg-neutral-950 h-2 rounded overflow-hidden">
                <div class="bg-emerald-500 h-full" style="width: 94.8%"></div>
              </div>
            </div>

            <div>
              <div class="flex justify-between mb-1">
                <span class="text-neutral-300">Nord-Süd-Magistrale (HH &ndash; H):</span>
                <span class="text-emerald-400 font-bold">92.1%</span>
              </div>
              <div class="w-full bg-neutral-950 h-2 rounded overflow-hidden">
                <div class="bg-emerald-500 h-full" style="width: 92.1%"></div>
              </div>
            </div>

            <div>
              <div class="flex justify-between mb-1">
                <span class="text-neutral-300">Frankfurt Fernbf Vorfeld (W-017):</span>
                <span class="text-amber-400 font-bold">78.2%</span>
              </div>
              <div class="w-full bg-neutral-950 h-2 rounded overflow-hidden">
                <div class="bg-amber-500 h-full" style="width: 78.2%"></div>
              </div>
            </div>
          </div>
        </div>

        <!-- Delay Causes Breakdown -->
        <div class="bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-3">
          <div class="flex items-center justify-between border-b border-neutral-800 pb-2">
            <span class="font-bold text-neutral-200 uppercase">VERSPÄTUNGSURSACHEN-MATRIX</span>
            <span class="text-amber-400">142 MIN TOTAL</span>
          </div>

          <div class="space-y-2 text-[11px]">
            <div class="p-2 rounded bg-neutral-950 flex justify-between">
              <span class="text-neutral-300">Weichen- & Stellwerksstörungen:</span>
              <span class="text-red-400 font-bold">48% (68 min)</span>
            </div>
            <div class="p-2 rounded bg-neutral-950 flex justify-between">
              <span class="text-neutral-300">Langsamfahrstellen / Oberbau:</span>
              <span class="text-amber-400 font-bold">24% (34 min)</span>
            </div>
            <div class="p-2 rounded bg-neutral-950 flex justify-between">
              <span class="text-neutral-300">Fahrgastwechselüberschreitung:</span>
              <span class="text-blue-400 font-bold">16% (23 min)</span>
            </div>
            <div class="p-2 rounded bg-neutral-950 flex justify-between">
              <span class="text-neutral-300">Fahrzeugstörungen (Türen/Klima):</span>
              <span class="text-purple-400 font-bold">12% (17 min)</span>
            </div>
          </div>
        </div>

        <!-- Capacity Utilization & Bottlenecks -->
        <div class="bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-3">
          <div class="flex items-center justify-between border-b border-neutral-800 pb-2">
            <span class="font-bold text-neutral-200 uppercase">KNOTENKAPAZITÄTS-ENGPÄSSE</span>
            <span class="text-neutral-400">ZÜGE / STUNDE</span>
          </div>

          <div class="space-y-2 text-[11px]">
            <div class="p-2 rounded bg-neutral-950 flex justify-between items-center">
              <div>
                <div class="text-neutral-100 font-bold">Frankfurt (Main) Hbf</div>
                <div class="text-[10px] text-neutral-500">Kapazität: 42 Züge/h</div>
              </div>
              <span class="text-red-400 font-bold">95% Auslastung</span>
            </div>

            <div class="p-2 rounded bg-neutral-950 flex justify-between items-center">
              <div>
                <div class="text-neutral-100 font-bold">Köln Hbf (Hohenzollernbrücke)</div>
                <div class="text-[10px] text-neutral-500">Kapazität: 48 Züge/h</div>
              </div>
              <span class="text-amber-400 font-bold">91% Auslastung</span>
            </div>

            <div class="p-2 rounded bg-neutral-950 flex justify-between items-center">
              <div>
                <div class="text-neutral-100 font-bold">München Hbf Zulauf</div>
                <div class="text-[10px] text-neutral-500">Kapazität: 36 Züge/h</div>
              </div>
              <span class="text-emerald-400 font-bold">76% Auslastung</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class RAnalyticsView {
  readonly sim = inject(RailwaySimulationService);
}
