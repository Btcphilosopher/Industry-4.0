import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RailwaySimulationService } from '../../../services/railway-simulation.service';

@Component({
  selector: 'app-what-if-sandbox-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="p-4 space-y-4 max-w-[1600px] mx-auto">
      <!-- Header -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-neutral-900 border border-neutral-800 rounded-lg p-3">
        <div class="flex items-center gap-2">
          <mat-icon class="text-amber-500 text-sm h-4 w-4">science</mat-icon>
          <span class="text-xs font-bold text-neutral-200 font-mono uppercase">
            WAS-WÄRE-WENN SZENARIEN-SIMULATOR & ENTSCHEIDUNGSUNTERSTÜTZUNG
          </span>
        </div>

        <!-- Clone Scenario Action -->
        <button
          (click)="openNewScenarioModal.set(true)"
          class="px-3 py-1.5 rounded bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs font-mono flex items-center gap-1 cursor-pointer">
          <mat-icon class="text-xs h-3.5 w-3.5">content_copy</mat-icon>
          Aktuellen Zustand als Szenario duplizieren
        </button>
      </div>

      <!-- Scenarios Comparison Matrix (Side-by-side) -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        @for (sc of sim.whatIfScenarios(); track sc.id) {
          <div class="bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-3 font-mono text-xs flex flex-col justify-between">
            <div class="space-y-2">
              <div class="flex items-center justify-between border-b border-neutral-800 pb-2">
                <span class="font-bold text-neutral-100 text-sm">{{ sc.name }}</span>
                <span class="text-[10px] text-neutral-500">{{ sc.created_at }}</span>
              </div>

              <div class="text-[11px] text-neutral-400 leading-snug">
                {{ sc.description }}
              </div>

              <!-- Metrics Cards -->
              <div class="space-y-2 pt-2">
                <div class="p-2 rounded bg-neutral-950 border border-neutral-800 flex justify-between items-center">
                  <span class="text-neutral-400">Pünktlichkeit:</span>
                  <span class="font-bold text-sm" [class.text-emerald-400]="sc.metrics.punctuality_pct >= 90" [class.text-amber-400]="sc.metrics.punctuality_pct < 90">
                    {{ sc.metrics.punctuality_pct }}%
                  </span>
                </div>

                <div class="p-2 rounded bg-neutral-950 border border-neutral-800 flex justify-between items-center">
                  <span class="text-neutral-400">Gesamtverspätung:</span>
                  <span class="font-bold text-amber-400">{{ sc.metrics.total_delay_min }} min</span>
                </div>

                <div class="p-2 rounded bg-neutral-950 border border-neutral-800 flex justify-between items-center">
                  <span class="text-neutral-400">Energieverbrauch:</span>
                  <span class="font-bold text-neutral-200">{{ sc.metrics.energy_consumption_mwh }} MWh</span>
                </div>

                <div class="p-2 rounded bg-neutral-950 border border-neutral-800 flex justify-between items-center">
                  <span class="text-neutral-400">Fahrgast-Zufriedenheit:</span>
                  <span class="font-bold text-emerald-400">{{ sc.metrics.passenger_comfort_score }} / 100</span>
                </div>
              </div>
            </div>

            <!-- Strategy Tag -->
            <div class="pt-2 border-t border-neutral-800 text-[10px] text-neutral-500">
              Strategie: <span class="text-neutral-300 font-bold">{{ sc.dispatching_strategy }}</span>
            </div>
          </div>
        }
      </div>

      <!-- Modal to create new Scenario -->
      @if (openNewScenarioModal()) {
        <div class="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
          <div class="bg-neutral-900 border border-neutral-700 rounded-lg p-6 max-w-md w-full font-mono text-xs space-y-4">
            <div class="text-sm font-bold text-neutral-100 uppercase border-b border-neutral-800 pb-2">
              NEUES WAS-WÄRE-WENN SZENARIO ANLEGEN
            </div>

            <div class="space-y-3">
              <div>
                <label for="scenario-name-input" class="block text-neutral-400 mb-1">Szenarioname:</label>
                <input
                  #nameInput
                  id="scenario-name-input"
                  type="text"
                  value="Szenario D: Güterzug-Nachtfenster & Trassentausch"
                  class="w-full bg-neutral-950 border border-neutral-800 rounded p-2 text-neutral-100">
              </div>

              <div>
                <label for="strategy-select" class="block text-neutral-400 mb-1">Optimierungsstrategie:</label>
                <select #stratSelect id="strategy-select" class="w-full bg-neutral-950 border border-neutral-800 rounded p-2 text-neutral-100">
                  <option value="ICE_VORRANG">ICE-Vorrang vor Regional- und Güterverkehr</option>
                  <option value="PUFFER_OPTIMIERUNG">Pufferzeitendehnung & Anschlusssicherung</option>
                  <option value="ENERGIE_MIN">Energieeffizienz & ATO-Coasting Priorität</option>
                </select>
              </div>
            </div>

            <div class="flex justify-end gap-2 pt-3 border-t border-neutral-800">
              <button
                (click)="openNewScenarioModal.set(false)"
                class="px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 cursor-pointer">
                Abbrechen
              </button>
              <button
                (click)="onCreateScenario(nameInput.value, stratSelect.value)"
                class="px-3 py-1.5 rounded bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold cursor-pointer">
                Szenario berechnen
              </button>
            </div>
          </div>
        </div>
      }
    </div>
  `
})
export class WhatIfSandboxView {
  readonly sim = inject(RailwaySimulationService);
  readonly openNewScenarioModal = signal<boolean>(false);

  onCreateScenario(name: string, strategy: 'ICE_VORRANG' | 'PUFFER_OPTIMIERUNG' | 'ENERGIE_MIN' | string): void {
    this.sim.createWhatIfScenario(name, strategy as 'ICE_VORRANG' | 'PUFFER_OPTIMIERUNG' | 'ENERGIE_MIN');
    this.openNewScenarioModal.set(false);
  }
}
