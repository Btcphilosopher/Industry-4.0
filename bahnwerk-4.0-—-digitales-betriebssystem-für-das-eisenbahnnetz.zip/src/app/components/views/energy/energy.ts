import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RailwaySimulationService } from '../../../services/railway-simulation.service';

@Component({
  selector: 'app-energy-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="p-4 space-y-4 max-w-[1600px] mx-auto">
      <!-- Header -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-neutral-900 border border-neutral-800 rounded-lg p-3">
        <div class="flex items-center gap-2">
          <mat-icon class="text-amber-500 text-sm h-4 w-4">bolt</mat-icon>
          <span class="text-xs font-bold text-neutral-200 font-mono uppercase">
            15-kV / 16.7-Hz BAHNSTROMNETZ & REKUPERATION (REGENERATIVES BREMSEN)
          </span>
        </div>

        <div class="text-xs font-mono text-emerald-400 font-bold">
          {{ sim.powerMetrics().regeneration_quota_pct }}% ENERGIERÜCKSPEISUNG
        </div>
      </div>

      <!-- Power Grid KPI Overview -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 font-mono text-xs">
        <div class="p-3.5 bg-neutral-900 border border-neutral-800 rounded-lg">
          <div class="text-[10px] text-neutral-400 uppercase">Momentane Netzwirkleistung</div>
          <div class="text-2xl font-bold text-amber-400 mt-1 tabular-nums">
            {{ sim.powerMetrics().total_active_mw }} <span class="text-xs text-neutral-400">MW</span>
          </div>
          <div class="text-[10px] text-neutral-500 mt-1">Spitze heute: {{ sim.powerMetrics().peak_mw }} MW</div>
        </div>

        <div class="p-3.5 bg-neutral-900 border border-neutral-800 rounded-lg">
          <div class="text-[10px] text-neutral-400 uppercase">Tagesverbrauch (15 kV)</div>
          <div class="text-2xl font-bold text-neutral-100 mt-1 tabular-nums">
            {{ sim.powerMetrics().daily_mwh }} <span class="text-xs text-neutral-400">MWh</span>
          </div>
          <div class="text-[10px] text-neutral-500 mt-1">Spezifisch: 18.2 kWh/Zug-km</div>
        </div>

        <div class="p-3.5 bg-neutral-900 border border-neutral-800 rounded-lg">
          <div class="text-[10px] text-neutral-400 uppercase">Bremsenergie-Rückspeisung</div>
          <div class="text-2xl font-bold text-emerald-400 mt-1 tabular-nums">
            {{ sim.powerMetrics().regenerated_mwh }} <span class="text-xs text-neutral-400">MWh</span>
          </div>
          <div class="text-[10px] text-emerald-500 mt-1">Quote: {{ sim.powerMetrics().regeneration_quota_pct }}%</div>
        </div>

        <div class="p-3.5 bg-neutral-900 border border-neutral-800 rounded-lg">
          <div class="text-[10px] text-neutral-400 uppercase">Netzfrequenz / Spannung</div>
          <div class="text-2xl font-bold text-blue-400 mt-1 tabular-nums">
            {{ sim.powerMetrics().grid_frequency_hz }} <span class="text-xs text-neutral-400">Hz</span>
          </div>
          <div class="text-[10px] text-neutral-500 mt-1">Spannung: {{ sim.powerMetrics().catenary_voltage_kv }} kV AC</div>
        </div>
      </div>

      <!-- Unterwerke (Substations) Table & Daily Load Profile -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <!-- Substations Table (7 cols) -->
        <div class="lg:col-span-7 bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-3 font-mono text-xs">
          <div class="flex items-center justify-between border-b border-neutral-800 pb-2">
            <span class="font-bold text-neutral-200 uppercase">BAHNSTROM-UNTERWERKE (SUBSTATIONS)</span>
            <span class="text-[10px] text-neutral-400">{{ sim.powerMetrics().substations.length }} Standorte</span>
          </div>

          <div class="space-y-2">
            @for (sub of sim.powerMetrics().substations; track sub.id) {
              <div class="p-3 rounded bg-neutral-950 border border-neutral-800 flex items-center justify-between">
                <div>
                  <div class="font-bold text-neutral-100">{{ sub.name }}</div>
                  <div class="text-[11px] text-neutral-400">
                    Region {{ sub.region }} &middot; Spannung: {{ sub.voltage_kv }} kV &middot; Last: {{ sub.load_mw }} MW / {{ sub.capacity_mw }} MW
                  </div>
                </div>

                <div class="text-right space-y-1">
                  <div class="font-bold tabular-nums" [class.text-emerald-400]="sub.load_pct < 70" [class.text-amber-400]="sub.load_pct >= 70">
                    {{ sub.load_pct }}%
                  </div>
                  <div class="w-20 bg-neutral-900 h-1.5 rounded overflow-hidden">
                    <div class="bg-amber-500 h-full" [style.width.%]="sub.load_pct"></div>
                  </div>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Regenerative Braking Physics Model (5 cols) -->
        <div class="lg:col-span-5 bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-3 font-mono text-xs flex flex-col justify-between">
          <div class="space-y-3">
            <div class="font-bold text-neutral-200 uppercase border-b border-neutral-800 pb-2">
              REKUPERATIONS-DYNAMIK IM 15-kV-NETZ
            </div>

            <div class="p-3 rounded bg-neutral-950 border border-neutral-800 text-[11px] text-neutral-300 leading-relaxed space-y-2">
              <div>
                Beim elektrodynamischen Bremsen (E-Bremse) speisen die Drehstrom-Asynchronmotoren der ICE- und Regio-Triebzüge Energie direkt zurück in die Oberleitung.
              </div>
              <div class="text-emerald-400 font-bold">
                Eingesparte CO2-Emissionen heute: {{ sim.powerMetrics().co2_savings_tons }} Tonnen
              </div>
            </div>

            <!-- Energy Balance Bar -->
            <div class="p-3 rounded bg-neutral-950 border border-neutral-800 space-y-2 text-[11px]">
              <div class="flex justify-between">
                <span class="text-neutral-400">Verbrauch ohne Rekuperation:</span>
                <span class="text-neutral-200 font-bold">{{ (sim.powerMetrics().daily_mwh + sim.powerMetrics().regenerated_mwh).toFixed(1) }} MWh</span>
              </div>
              <div class="flex justify-between">
                <span class="text-neutral-400">Rückgespeiste Bremsenergie:</span>
                <span class="text-emerald-400 font-bold">- {{ sim.powerMetrics().regenerated_mwh }} MWh</span>
              </div>
              <div class="flex justify-between pt-1 border-t border-neutral-900">
                <span class="text-neutral-200 font-bold">Netto-Netzbezug:</span>
                <span class="text-amber-400 font-bold">{{ sim.powerMetrics().daily_mwh }} MWh</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class EnergyView {
  readonly sim = inject(RailwaySimulationService);
}
