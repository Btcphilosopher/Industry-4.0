import { ChangeDetectionStrategy, Component, inject, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RailwaySimulationService } from '../../../services/railway-simulation.service';
import { ActiveTab } from '../../header/header';

@Component({
  selector: 'app-overview-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="p-4 space-y-4 max-w-[1600px] mx-auto">
      <!-- Top Leitstellen KPI Grid (Specification Requirement: Hauptleitstelle) -->
      <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-2">
        <div class="bg-neutral-900 border border-neutral-800 rounded-lg p-3">
          <div class="text-[11px] font-mono text-neutral-400 uppercase">Züge Aktiv</div>
          <div class="flex items-baseline justify-between mt-1">
            <span class="text-2xl font-bold font-mono text-neutral-100 tabular-nums">
              {{ sim.activeTrainsCount() }}
            </span>
            <span class="text-xs text-neutral-500 font-mono">/ {{ sim.trains().length }}</span>
          </div>
          <div class="text-[10px] text-emerald-400 mt-1 flex items-center gap-1 font-mono">
            <span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span> 100% Simuliert
          </div>
        </div>

        <div class="bg-neutral-900 border border-neutral-800 rounded-lg p-3">
          <div class="text-[11px] font-mono text-neutral-400 uppercase">Pünktlichkeit</div>
          <div class="flex items-baseline justify-between mt-1">
            <span class="text-2xl font-bold font-mono tabular-nums" [class.text-emerald-400]="sim.punctualityPct() >= 90" [class.text-amber-400]="sim.punctualityPct() < 90">
              {{ sim.punctualityPct() }} %
            </span>
            <span class="text-[10px] text-neutral-500 font-mono">&lt; 6 min</span>
          </div>
          <div class="text-[10px] text-neutral-400 mt-1 font-mono">
            {{ sim.totalDelayMinutes() }} min Gesamtversp.
          </div>
        </div>

        <div class="bg-neutral-900 border border-neutral-800 rounded-lg p-3">
          <div class="text-[11px] font-mono text-neutral-400 uppercase">Streckennetz</div>
          <div class="flex items-baseline justify-between mt-1">
            <span class="text-lg font-bold font-mono text-emerald-400">NORMAL</span>
            <span class="text-xs text-neutral-400 font-mono">5 Reg.</span>
          </div>
          <div class="text-[10px] text-neutral-400 mt-1 font-mono">
            {{ sim.occupiedBlocksCount() }} / {{ sim.network().blocks.length }} Blöcke belegt
          </div>
        </div>

        <div class="bg-neutral-900 border border-neutral-800 rounded-lg p-3">
          <div class="text-[11px] font-mono text-neutral-400 uppercase">Störungen</div>
          <div class="flex items-baseline justify-between mt-1">
            <span class="text-2xl font-bold font-mono tabular-nums" [class.text-amber-400]="sim.incidents().length > 0" [class.text-emerald-400]="sim.incidents().length === 0">
              {{ sim.incidents().length }}
            </span>
            <span class="text-[10px] text-amber-500 font-mono">1 Kritisch</span>
          </div>
          <div class="text-[10px] text-neutral-400 mt-1 font-mono">
            R-Optimierer aktiv
          </div>
        </div>

        <div class="bg-neutral-900 border border-neutral-800 rounded-lg p-3">
          <div class="text-[11px] font-mono text-neutral-400 uppercase">Weichen</div>
          <div class="flex items-baseline justify-between mt-1">
            <span class="text-2xl font-bold font-mono text-neutral-100 tabular-nums">40 / 40</span>
            <span class="text-[10px] text-neutral-400 font-mono">W-017 Fault</span>
          </div>
          <div class="text-[10px] text-emerald-400 mt-1 font-mono">
            97.5% Verfügbar
          </div>
        </div>

        <div class="bg-neutral-900 border border-neutral-800 rounded-lg p-3">
          <div class="text-[11px] font-mono text-neutral-400 uppercase">Stellwerke (DSTW)</div>
          <div class="flex items-baseline justify-between mt-1">
            <span class="text-2xl font-bold font-mono text-emerald-400 tabular-nums">30 / 30</span>
            <span class="text-[10px] text-emerald-500 font-mono">Online</span>
          </div>
          <div class="text-[10px] text-neutral-400 mt-1 font-mono">
            Redundanz: Aktiv
          </div>
        </div>

        <div class="bg-neutral-900 border border-neutral-800 rounded-lg p-3">
          <div class="text-[11px] font-mono text-neutral-400 uppercase">Traktionsenergie</div>
          <div class="flex items-baseline justify-between mt-1">
            <span class="text-2xl font-bold font-mono text-amber-400 tabular-nums">
              {{ sim.powerMetrics().total_active_mw }}
            </span>
            <span class="text-xs text-neutral-400 font-mono">MW</span>
          </div>
          <div class="text-[10px] text-emerald-400 mt-1 font-mono">
            {{ sim.powerMetrics().regeneration_quota_pct }}% Rückspeisung
          </div>
        </div>
      </div>

      <!-- Demo Scenarios Fast-Execution Toolbar (Specification Requirement 62-67) -->
      <div class="bg-neutral-900/80 border border-neutral-800 rounded-lg p-3">
        <div class="flex items-center justify-between mb-2">
          <div class="flex items-center gap-2">
            <mat-icon class="text-amber-500 text-sm h-4 w-4">play_circle</mat-icon>
            <span class="text-xs font-semibold text-neutral-200 uppercase font-mono">
              Vordefinierte Industrie-Prüfszenarien (Demo-Szenarien 1–6)
            </span>
          </div>
          <span class="text-[11px] text-neutral-400 font-mono">
            Deterministische Reproduzierbarkeit mit Seed: #{{ sim.seed() }}
          </span>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2 text-xs">
          <button
            (click)="sim.applyDemoScenario(1)"
            [class.border-emerald-500]="sim.activeScenario() === 'normal'"
            [class.bg-emerald-950/40]="sim.activeScenario() === 'normal'"
            class="p-2 rounded bg-neutral-950 border border-neutral-800 text-left hover:border-neutral-600 transition-colors cursor-pointer flex flex-col justify-between">
            <div class="font-semibold text-neutral-200">1. Normalbetrieb</div>
            <div class="text-[10px] text-neutral-400 mt-1">80 Züge im Takt, alle Strecken frei</div>
          </button>

          <button
            (click)="sim.applyDemoScenario(2)"
            [class.border-amber-500]="sim.activeScenario() === 'switch_fault'"
            [class.bg-amber-950/40]="sim.activeScenario() === 'switch_fault'"
            class="p-2 rounded bg-neutral-950 border border-neutral-800 text-left hover:border-neutral-600 transition-colors cursor-pointer flex flex-col justify-between">
            <div class="font-semibold text-amber-300">2. Weichenstörung</div>
            <div class="text-[10px] text-neutral-400 mt-1">W-017 Frankfurt blockiert (3 Routen)</div>
          </button>

          <button
            (click)="sim.applyDemoScenario(3)"
            [class.border-amber-500]="sim.activeScenario() === 'block_closed'"
            [class.bg-amber-950/40]="sim.activeScenario() === 'block_closed'"
            class="p-2 rounded bg-neutral-950 border border-neutral-800 text-left hover:border-neutral-600 transition-colors cursor-pointer flex flex-col justify-between">
            <div class="font-semibold text-amber-300">3. Streckensperrung</div>
            <div class="text-[10px] text-neutral-400 mt-1">Block B-081 (Augsburg - M) gesperrt</div>
          </button>

          <button
            (click)="sim.applyDemoScenario(4)"
            [class.border-red-500]="sim.activeScenario() === 'major_disruption'"
            [class.bg-red-950/40]="sim.activeScenario() === 'major_disruption'"
            class="p-2 rounded bg-neutral-950 border border-neutral-800 text-left hover:border-neutral-600 transition-colors cursor-pointer flex flex-col justify-between">
            <div class="font-semibold text-red-400">4. Großstörung</div>
            <div class="text-[10px] text-neutral-400 mt-1">Strecke + Weiche + hoher Verkehr</div>
          </button>

          <button
            (click)="sim.applyDemoScenario(5)"
            [class.border-blue-500]="sim.activeScenario() === 'etcs_test'"
            [class.bg-blue-950/40]="sim.activeScenario() === 'etcs_test'"
            class="p-2 rounded bg-neutral-950 border border-neutral-800 text-left hover:border-neutral-600 transition-colors cursor-pointer flex flex-col justify-between">
            <div class="font-semibold text-blue-300">5. ETCS / ATO Fahrt</div>
            <div class="text-[10px] text-neutral-400 mt-1">Präzisionshalt & Bremskurventest</div>
          </button>

          <button
            (click)="sim.applyDemoScenario(6)"
            [class.border-purple-500]="sim.activeScenario() === 'maintenance'"
            [class.bg-purple-950/40]="sim.activeScenario() === 'maintenance'"
            class="p-2 rounded bg-neutral-950 border border-neutral-800 text-left hover:border-neutral-600 transition-colors cursor-pointer flex flex-col justify-between">
            <div class="font-semibold text-purple-300">6. Wartungsanomalie</div>
            <div class="text-[10px] text-neutral-400 mt-1">Weichenantrieb Überstrom 5.4A</div>
          </button>
        </div>
      </div>

      <!-- Main Central Grid: Schematic Map + Disruption Console -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <!-- Left: Schematic Map Mini Overview (8 cols) -->
        <div class="lg:col-span-8 bg-neutral-900 border border-neutral-800 rounded-lg p-4 flex flex-col justify-between">
          <div class="flex items-center justify-between mb-2">
            <div class="flex items-center gap-2">
              <mat-icon class="text-neutral-400 text-sm h-4 w-4">map</mat-icon>
              <span class="text-sm font-bold text-neutral-200 font-mono">
                SCHEMATISCHES DEUTSCHES EISENBAHNNETZ (DEMO-TOPOLOGIE)
              </span>
            </div>
            <button
              (click)="navigateToTab.emit('netz')"
              class="text-xs text-amber-400 hover:text-amber-300 flex items-center gap-1 font-mono cursor-pointer">
              Gleisplan vergrößern <mat-icon class="text-xs h-3.5 w-3.5">arrow_forward</mat-icon>
            </button>
          </div>

          <!-- Scalable SVG Map Canvas -->
          <div class="relative w-full aspect-[16/10] bg-neutral-950 rounded border border-neutral-800/80 overflow-hidden">
            <svg viewBox="0 0 100 100" class="w-full h-full select-none">
              <!-- Grid background lines -->
              <defs>
                <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
                  <path d="M 10 0 L 0 0 0 10" fill="none" stroke="#1f2937" stroke-width="0.2"/>
                </pattern>
              </defs>
              <rect width="100" height="100" fill="url(#grid)" />

              <!-- Railway Track Sections / Blocks -->
              @for (sec of sim.network().track_sections; track sec.section_id) {
                @for (blk of sec.blocks; track blk.block_id) {
                  <line
                    [attr.x1]="blk.x1"
                    [attr.y1]="blk.y1"
                    [attr.x2]="blk.x2"
                    [attr.y2]="blk.y2"
                    [attr.stroke]="blk.state === 'BELEGT' ? '#ef4444' : blk.state === 'GESPERRT' ? '#f59e0b' : blk.state === 'STÖRUNG' ? '#dc2626' : '#334155'"
                    [attr.stroke-width]="blk.state === 'BELEGT' ? '1.2' : '0.8'"
                    [attr.stroke-dasharray]="blk.state === 'GESPERRT' ? '1,1' : 'none'"
                    class="transition-colors duration-300"
                  />
                }
              }

              <!-- Stations -->
              @for (st of sim.network().stations; track st.id) {
                <g [attr.transform]="'translate(' + st.x + ',' + st.y + ')'" class="cursor-pointer" (click)="onStationClick(st.id)">
                  <circle
                    r="1.6"
                    [attr.fill]="st.is_hub ? '#f59e0b' : '#38bdf8'"
                    stroke="#0f172a"
                    stroke-width="0.4"
                  />
                  <text
                    x="2.4"
                    y="0.8"
                    fill="#cbd5e1"
                    font-size="2.2"
                    font-family="JetBrains Mono"
                    font-weight="600">
                    {{ st.name.replace(' Hbf', '') }}
                  </text>
                </g>
              }

              <!-- Moving Trains -->
              @for (t of sim.trains(); track t.train_id) {
                <g [attr.transform]="'translate(' + t.x + ',' + t.y + ')'" class="cursor-pointer" (click)="onTrainClick(t.train_id)">
                  <circle
                    r="1.2"
                    [attr.fill]="t.train_type === 'ICE' ? '#ffffff' : t.train_type === 'GÜTERZUG' ? '#10b981' : '#3b82f6'"
                    stroke="#0f172a"
                    stroke-width="0.3"
                  />
                  <!-- Small direction triangle -->
                  <polygon
                    points="0,-0.6 0.8,0.6 -0.8,0.6"
                    [attr.transform]="'rotate(' + (t.direction_angle + 90) + ')'"
                    fill="#f59e0b"
                  />
                </g>
              }
            </svg>

            <!-- Map Legend Overlay -->
            <div class="absolute bottom-2 left-2 bg-neutral-900/90 border border-neutral-800 rounded p-2 text-[10px] font-mono text-neutral-300 flex items-center gap-3">
              <div class="flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-slate-600"></span> Frei</div>
              <div class="flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-red-500"></span> Belegt</div>
              <div class="flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-amber-500"></span> Gesperrt</div>
              <div class="flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-white"></span> ICE</div>
              <div class="flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-blue-500"></span> Regio</div>
              <div class="flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-emerald-500"></span> Güterzug</div>
            </div>
          </div>
        </div>

        <!-- Right: Real-time Incident Feed & Dispatch Assistant (4 cols) -->
        <div class="lg:col-span-4 bg-neutral-900 border border-neutral-800 rounded-lg p-4 flex flex-col justify-between space-y-3">
          <div>
            <div class="flex items-center justify-between mb-3 border-b border-neutral-800 pb-2">
              <div class="flex items-center gap-2">
                <mat-icon class="text-amber-500 text-sm h-4 w-4">notifications_active</mat-icon>
                <span class="text-xs font-bold text-neutral-200 font-mono">
                  DISPATCHER-LEITSTAND & EILMELDUNGEN
                </span>
              </div>
              <span class="text-[10px] px-2 py-0.5 rounded bg-amber-950 text-amber-400 font-mono">
                {{ sim.incidents().length }} AKTIV
              </span>
            </div>

            <!-- Incident Cards -->
            <div class="space-y-2 max-h-[380px] overflow-y-auto pr-1">
              @for (inc of sim.incidents(); track inc.incident_id) {
                <button
                  type="button"
                  (click)="onIncidentClick(inc.incident_id)"
                  class="w-full text-left p-2.5 rounded border border-neutral-800 bg-neutral-950 hover:border-amber-600/50 transition-colors cursor-pointer space-y-1">
                  <div class="flex items-center justify-between">
                    <span class="text-xs font-bold text-amber-300 font-mono">{{ inc.type }}</span>
                    <span class="text-[10px] px-1.5 py-0.2 rounded font-mono" [class.bg-red-950]="inc.severity === 'KRITISCH'" [class.text-red-400]="inc.severity === 'KRITISCH'" [class.bg-amber-950]="inc.severity === 'WARNUNG'" [class.text-amber-400]="inc.severity === 'WARNUNG'">
                      {{ inc.severity }}
                    </span>
                  </div>
                  <div class="text-xs text-neutral-200 font-medium leading-snug">
                    {{ inc.title }}
                  </div>
                  <div class="text-[11px] text-neutral-400">
                    Ort: <span class="text-neutral-300">{{ inc.location_name }}</span>
                  </div>
                  <div class="text-[11px] text-amber-400 font-mono flex items-center justify-between pt-1 border-t border-neutral-900">
                    <span>{{ inc.affected_train_ids.length }} Züge betroffen</span>
                    <span>+{{ inc.avg_delay_addition_min }} min Verspätung</span>
                  </div>
                </button>
              } @empty {
                <div class="p-6 text-center text-xs text-neutral-500 font-mono">
                  Keine aktiven Störungen im Streckennetz.
                </div>
              }
            </div>
          </div>

          <!-- Fast Dispatcher Jump Buttons -->
          <div class="pt-2 border-t border-neutral-800 grid grid-cols-2 gap-2 text-xs font-mono">
            <button
              (click)="navigateToTab.emit('stoerungen')"
              class="px-3 py-2 rounded bg-neutral-950 border border-neutral-700 hover:bg-neutral-800 text-neutral-200 flex items-center justify-center gap-1.5 cursor-pointer">
              <mat-icon class="text-sm h-4 w-4 text-amber-400">tune</mat-icon>
              Störungs-Optimierer
            </button>
            <button
              (click)="navigateToTab.emit('stellwerk')"
              class="px-3 py-2 rounded bg-neutral-950 border border-neutral-700 hover:bg-neutral-800 text-neutral-200 flex items-center justify-center gap-1.5 cursor-pointer">
              <mat-icon class="text-sm h-4 w-4 text-emerald-400">alt_route</mat-icon>
              Stellwerk öffnen
            </button>
          </div>
        </div>
      </div>

      <!-- Bottom Activity Stream & Audit Highlights -->
      <div class="bg-neutral-900 border border-neutral-800 rounded-lg p-3">
        <div class="flex items-center justify-between mb-2">
          <div class="flex items-center gap-2">
            <mat-icon class="text-neutral-400 text-sm h-4 w-4">receipt_long</mat-icon>
            <span class="text-xs font-bold text-neutral-200 font-mono uppercase">
              Echtzeit-Telemetrie & Audit-Stream (Rust Kernel & DSTW)
            </span>
          </div>
          <button
            (click)="navigateToTab.emit('protokolle')"
            class="text-xs text-neutral-400 hover:text-neutral-200 font-mono flex items-center gap-1 cursor-pointer">
            Vollständiges Protokoll <mat-icon class="text-xs h-3.5 w-3.5">arrow_forward</mat-icon>
          </button>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
          @for (log of sim.auditLogs().slice(0, 3); track log.id) {
            <div class="p-2 rounded bg-neutral-950 border border-neutral-800 text-xs font-mono space-y-0.5">
              <div class="flex items-center justify-between text-[11px] text-neutral-400">
                <span class="text-neutral-500">{{ log.timestamp }}</span>
                <span class="text-amber-400">{{ log.event_type }}</span>
              </div>
              <div class="text-neutral-200 font-medium truncate">{{ log.entity_name }}</div>
              <div class="text-[11px] text-neutral-400 truncate">{{ log.details }}</div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class OverviewView {
  readonly sim = inject(RailwaySimulationService);
  readonly navigateToTab = output<ActiveTab>();

  onStationClick(stationId: string): void {
    this.sim.selectStation(stationId);
    this.navigateToTab.emit('bahnhoefe');
  }

  onTrainClick(trainId: string): void {
    this.sim.selectTrain(trainId);
    this.navigateToTab.emit('zuege');
  }

  onIncidentClick(incidentId: string): void {
    this.sim.selectIncident(incidentId);
    this.navigateToTab.emit('stoerungen');
  }
}
