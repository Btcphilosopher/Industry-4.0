import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RailwaySimulationService } from '../../../services/railway-simulation.service';

@Component({
  selector: 'app-interlocking-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="p-4 space-y-4 max-w-[1600px] mx-auto">
      <!-- Top Interlocking Selection Bar -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-neutral-900 border border-neutral-800 rounded-lg p-3">
        <div class="flex items-center gap-2">
          <mat-icon class="text-amber-500 text-sm h-4 w-4">alt_route</mat-icon>
          <span class="text-xs font-bold text-neutral-200 font-mono uppercase">
            DIGITALES STELLWERK (DSTW) LEITRECHNER
          </span>
        </div>

        <!-- Interlocking Selector -->
        <div class="flex items-center gap-2">
          <span class="text-xs font-mono text-neutral-400">Stellwerksbereich:</span>
          <select
            [value]="sim.selectedInterlockingId()"
            (change)="onInterlockingSelect($event)"
            class="bg-neutral-950 border border-neutral-800 text-neutral-200 rounded px-2.5 py-1 text-xs font-mono">
            @for (il of sim.network().interlockings; track il.interlocking_id) {
              <option [value]="il.interlocking_id">{{ il.name }} ({{ il.code }})</option>
            }
          </select>
        </div>
      </div>

      <!-- Main Layout: Interlocking Overview + ASCII/SVG Track Interlocking Schematic -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <!-- Left: DSTW Status & Route List (5 cols) -->
        <div class="lg:col-span-5 space-y-4">
          <!-- Interlocking System Metrics -->
          @if (sim.selectedInterlocking(); as il) {
            <div class="bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-3 font-mono text-xs">
              <div class="flex items-center justify-between border-b border-neutral-800 pb-2">
                <div class="flex items-center gap-2">
                  <span class="text-sm font-bold text-neutral-100">{{ il.name }}</span>
                  <span class="text-[10px] px-1.5 py-0.2 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                    SIL-4 REFERENZMODELL
                  </span>
                </div>
                <span class="text-emerald-400 font-bold">{{ il.status }}</span>
              </div>

              <div class="grid grid-cols-2 gap-2 text-[11px]">
                <div class="p-2 rounded bg-neutral-950 border border-neutral-800">
                  <div class="text-neutral-500">Betriebsmodus</div>
                  <div class="text-neutral-200 font-bold mt-0.5">{{ il.mode }}</div>
                </div>
                <div class="p-2 rounded bg-neutral-950 border border-neutral-800">
                  <div class="text-neutral-500">Systemlast / Uptime</div>
                  <div class="text-amber-400 font-bold mt-0.5">{{ il.system_load_pct }}% / {{ il.uptime_hours }} h</div>
                </div>
              </div>
            </div>
          }

          <!-- Routes in Interlocking -->
          <div class="bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-3 font-mono text-xs">
            <div class="flex items-center justify-between border-b border-neutral-800 pb-2">
              <span class="font-bold text-neutral-200 uppercase">Fahrstraßenverzeichnis</span>
              <span class="text-[10px] text-neutral-400">{{ sim.network().routes.length }} Fahrstraßen</span>
            </div>

            <div class="space-y-2">
              @for (rt of sim.network().routes; track rt.route_id) {
                <div class="p-2.5 rounded bg-neutral-950 border border-neutral-800 space-y-1.5">
                  <div class="flex items-center justify-between">
                    <span class="font-bold text-amber-400">{{ rt.code }}</span>
                    <span class="text-[10px] px-1.5 py-0.2 rounded font-mono" [class.bg-emerald-950]="rt.state === 'EINGESTELLT_GESICHERT'" [class.text-emerald-400]="rt.state === 'EINGESTELLT_GESICHERT'" [class.bg-neutral-800]="rt.state === 'INAKTIV'" [class.text-neutral-400]="rt.state === 'INAKTIV'">
                      {{ rt.state }}
                    </span>
                  </div>

                  <div class="text-[11px] text-neutral-300">
                    {{ rt.name }}
                  </div>

                  <div class="text-[10px] text-neutral-400">
                    Kette: Start <span class="text-neutral-200">S-042</span> &rarr; Weichen <span class="text-neutral-200">{{ rt.switches.length }} W</span> &rarr; Ziel <span class="text-neutral-200">{{ rt.end_signal_or_platform }}</span>
                  </div>

                  <!-- Route Commands -->
                  <div class="flex gap-2 pt-1">
                    <button
                      (click)="sim.setRouteState(rt.route_id, 'EINGESTELLT_GESICHERT')"
                      [disabled]="rt.state === 'EINGESTELLT_GESICHERT'"
                      class="px-2 py-1 rounded bg-neutral-900 border border-neutral-700 hover:bg-neutral-800 disabled:opacity-40 text-emerald-400 text-[10px] cursor-pointer">
                      Fahrstraße stellen
                    </button>
                    <button
                      (click)="sim.setRouteState(rt.route_id, 'INAKTIV')"
                      [disabled]="rt.state === 'INAKTIV'"
                      class="px-2 py-1 rounded bg-neutral-900 border border-neutral-700 hover:bg-neutral-800 disabled:opacity-40 text-neutral-400 text-[10px] cursor-pointer">
                      Notauflösung
                    </button>
                  </div>
                </div>
              }
            </div>
          </div>
        </div>

        <!-- Right: Schematic Gleisbild Stellwerk Display (7 cols) -->
        <div class="lg:col-span-7 bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-3 font-mono text-xs flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between border-b border-neutral-800 pb-2">
              <div class="flex items-center gap-2">
                <mat-icon class="text-emerald-400 text-sm h-4 w-4">schema</mat-icon>
                <span class="font-bold text-neutral-200 uppercase">
                  GLEISBILD-STELLWERKSANZEIGE (SYNTHETISCHER FAHRWEG)
                </span>
              </div>
              <span class="text-[11px] text-neutral-400">Fahrstraße F-0187 aktiv</span>
            </div>

            <!-- Visual Track Diagram (Specification Section 43: Stellwerksansicht) -->
            <div class="p-6 my-4 bg-neutral-950 rounded border border-neutral-800 space-y-6">
              <div class="text-[11px] text-neutral-500 uppercase">Schematischer Fahrwegverlauf mit Weichenlagen & Blockverriegelung</div>

              <div class="space-y-4 font-mono text-xs leading-relaxed text-neutral-300">
                <div class="flex items-center gap-2">
                  <span class="text-emerald-400 font-bold w-16">GLEIS 1</span>
                  <span class="text-neutral-500">──────[ S-042 ]──────</span>
                  <span class="text-emerald-400 font-bold">[ B-081 BELEGT ]</span>
                  <span class="text-neutral-500">────\\</span>
                  <span class="px-1.5 py-0.5 rounded bg-amber-950 text-amber-400 border border-amber-800">W17: GERADE</span>
                  <span class="text-neutral-500">──────&gt; NACH MÜNCHEN</span>
                </div>

                <div class="flex items-center gap-2">
                  <span class="text-neutral-400 font-bold w-16">GLEIS 2</span>
                  <span class="text-neutral-500">──────[ S-044 ]────────────────────\\</span>
                  <span class="px-1.5 py-0.5 rounded bg-neutral-800 text-neutral-300">W18: GERADE</span>
                  <span class="text-neutral-500">──────[ B-082 FREI ]──────&gt;</span>
                </div>

                <div class="flex items-center gap-2">
                  <span class="text-neutral-400 font-bold w-16">GLEIS 3</span>
                  <span class="text-neutral-500">──────[ S-046 ]───────────────────────────────[ B-083 FREI ]──────&gt; AUSWEICHE</span>
                </div>
              </div>

              <!-- Interlocking Switch & Block State Table -->
              <div class="pt-4 border-t border-neutral-900 grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-[10px]">
                <div class="p-2 rounded bg-neutral-900 border border-neutral-800">
                  <div class="text-neutral-500">START-SIGNAL S-042</div>
                  <div class="text-emerald-400 font-bold mt-0.5">HP 1 (FAHRT)</div>
                </div>
                <div class="p-2 rounded bg-neutral-900 border border-neutral-800">
                  <div class="text-neutral-500">WEICHE W-017</div>
                  <div class="text-emerald-400 font-bold mt-0.5">VERRIEGELT (L)</div>
                </div>
                <div class="p-2 rounded bg-neutral-900 border border-neutral-800">
                  <div class="text-neutral-500">BLOCK B-081</div>
                  <div class="text-red-400 font-bold mt-0.5">BELEGT (ICE 742)</div>
                </div>
                <div class="p-2 rounded bg-neutral-900 border border-neutral-800">
                  <div class="text-neutral-500">FLANKENSCHUTZ</div>
                  <div class="text-emerald-400 font-bold mt-0.5">GESICHERT</div>
                </div>
              </div>
            </div>
          </div>

          <!-- Quick Interlocking Safety Override Actions -->
          <div class="p-3 rounded bg-neutral-950 border border-neutral-800 flex items-center justify-between">
            <span class="text-neutral-400 text-xs">Fahrdienstleiter-Nothalt alle Signale:</span>
            <button
              (click)="onEmergencyAllStop()"
              class="px-3 py-1.5 rounded bg-red-950 border border-red-700 hover:bg-red-900 text-red-400 font-bold text-xs flex items-center gap-1 cursor-pointer">
              <mat-icon class="text-xs h-3.5 w-3.5">dangerous</mat-icon>
              NOTHALT STELLWERKSBEREICH
            </button>
          </div>
        </div>
      </div>
    </div>
  `
})
export class InterlockingView {
  readonly sim = inject(RailwaySimulationService);

  onInterlockingSelect(event: Event): void {
    const val = (event.target as HTMLSelectElement).value;
    this.sim.selectInterlocking(val);
  }

  onEmergencyAllStop(): void {
    const net = this.sim.network();
    net.signals.forEach((sig) => {
      this.sim.setSignalAspect(sig.signal_id, 'HALT');
    });
  }
}
