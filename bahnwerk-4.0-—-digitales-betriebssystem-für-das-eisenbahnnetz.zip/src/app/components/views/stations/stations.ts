import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RailwaySimulationService } from '../../../services/railway-simulation.service';

@Component({
  selector: 'app-stations-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="p-4 space-y-4 max-w-[1600px] mx-auto">
      <!-- Header -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-neutral-900 border border-neutral-800 rounded-lg p-3">
        <div class="flex items-center gap-2">
          <mat-icon class="text-amber-500 text-sm h-4 w-4">location_city</mat-icon>
          <span class="text-xs font-bold text-neutral-200 font-mono uppercase">
            BAHNHOFS-DIGITAL-TWIN & PERSONENSTROM-ANALYTIK (30 BAHNHOFSRINGE)
          </span>
        </div>

        <div class="flex items-center gap-2">
          <span class="text-xs font-mono text-neutral-400">Ausgewählter Bahnhof:</span>
          <select
            [value]="sim.selectedStationId()"
            (change)="onStationSelect($event)"
            class="bg-neutral-950 border border-neutral-800 text-neutral-200 rounded px-2.5 py-1 text-xs font-mono">
            @for (st of sim.network().stations; track st.id) {
              <option [value]="st.id">{{ st.name }} ({{ st.code }}) &middot; Region {{ st.region }}</option>
            }
          </select>
        </div>
      </div>

      <!-- Main Station Twin View -->
      @if (sim.selectedStation(); as st) {
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
          <!-- Station Core Stats & Platforms (7 cols) -->
          <div class="lg:col-span-7 bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-4 font-mono text-xs">
            <div class="flex items-center justify-between border-b border-neutral-800 pb-3">
              <div>
                <div class="flex items-center gap-2">
                  <span class="text-lg font-bold text-neutral-100">{{ st.name }}</span>
                  <span class="text-xs px-2 py-0.5 rounded bg-blue-950 text-blue-400 border border-blue-800 font-bold">
                    DS-100: {{ st.code }}
                  </span>
                </div>
                <div class="text-xs text-neutral-400 mt-0.5">
                  Region {{ st.region }} &middot; {{ st.tracks_count }} Gleise &middot; Stellwerk: {{ st.interlocking_id }}
                </div>
              </div>

              <div class="text-right">
                <span class="text-xs px-2 py-1 rounded font-bold" [class.bg-emerald-950]="st.passenger_flow.crowding_level === 'NORMAL'" [class.text-emerald-400]="st.passenger_flow.crowding_level === 'NORMAL'" [class.bg-amber-950]="st.passenger_flow.crowding_level === 'ERHÖHT'" [class.text-amber-400]="st.passenger_flow.crowding_level === 'ERHÖHT'">
                  LAST: {{ st.passenger_flow.crowding_level }}
                </span>
              </div>
            </div>

            <!-- Platform Tracks Table -->
            <div class="space-y-2">
              <div class="font-bold text-neutral-300 uppercase">Bahnsteiggleise & Belegung</div>

              <div class="space-y-2">
                @for (p of st.platforms; track p.platform_id) {
                  <div class="p-2.5 rounded bg-neutral-950 border border-neutral-800 flex items-center justify-between">
                    <div>
                      <div class="flex items-center gap-2">
                        <span class="font-bold text-neutral-100">Gleis {{ p.track_number }}</span>
                        <span class="text-[10px] text-neutral-400">Länge: {{ p.length_m }} m</span>
                      </div>
                      <div class="text-[11px] text-neutral-400">
                        Kapazität: {{ p.capacity_passengers }} Fahrgäste &middot; Auslastung: {{ p.passenger_load_pct }}%
                      </div>
                    </div>

                    <div class="text-right">
                      <span class="px-2 py-0.5 rounded text-[10px] font-bold" [class.bg-emerald-950]="p.access_state === 'FREI'" [class.text-emerald-400]="p.access_state === 'FREI'">
                        {{ p.access_state }}
                      </span>
                    </div>
                  </div>
                }
              </div>
            </div>
          </div>

          <!-- Passenger Flow Simulation (5 cols) -->
          <div class="lg:col-span-5 bg-neutral-900 border border-neutral-800 rounded-lg p-4 space-y-4 font-mono text-xs">
            <div class="font-bold text-neutral-200 uppercase border-b border-neutral-800 pb-2">
              PERSONENSTRÖME & UMWELTKAPAZITÄT (SYNTHETISCH)
            </div>

            <div class="space-y-2 text-[11px]">
              <div class="p-3 rounded bg-neutral-950 border border-neutral-800 flex justify-between items-center">
                <span class="text-neutral-400">Einsteiger / Stunde:</span>
                <span class="text-neutral-100 font-bold tabular-nums">{{ st.passenger_flow.boardings_per_hour | number }}</span>
              </div>
              <div class="p-3 rounded bg-neutral-950 border border-neutral-800 flex justify-between items-center">
                <span class="text-neutral-400">Aussteiger / Stunde:</span>
                <span class="text-neutral-100 font-bold tabular-nums">{{ st.passenger_flow.alightings_per_hour | number }}</span>
              </div>
              <div class="p-3 rounded bg-neutral-950 border border-neutral-800 flex justify-between items-center">
                <span class="text-neutral-400">Umsteiger (Taktknoten):</span>
                <span class="text-amber-400 font-bold tabular-nums">{{ st.passenger_flow.transfers_per_hour | number }}</span>
              </div>
              <div class="p-3 rounded bg-neutral-950 border border-neutral-800 flex justify-between items-center">
                <span class="text-neutral-400">Aktuell Wartende am Bahnsteig:</span>
                <span class="text-emerald-400 font-bold tabular-nums">{{ st.passenger_flow.current_waiting_passengers | number }}</span>
              </div>
            </div>

            <div class="p-3 bg-neutral-950 rounded border border-neutral-800 text-[11px] text-neutral-400 space-y-1">
              <div class="text-neutral-200 font-bold">FAHRGAST-DISPATCHING REGEL:</div>
              <div>Bei Überschreitung von 85% Bahnsteigauslastung wird Fahrgastsperre an den Abgängen automatisch aktiviert.</div>
            </div>
          </div>
        </div>
      }
    </div>
  `
})
export class StationsView {
  readonly sim = inject(RailwaySimulationService);

  onStationSelect(event: Event): void {
    const val = (event.target as HTMLSelectElement).value;
    this.sim.selectStation(val);
  }
}
