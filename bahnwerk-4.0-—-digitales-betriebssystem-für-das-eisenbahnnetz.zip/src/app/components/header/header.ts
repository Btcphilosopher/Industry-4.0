import { ChangeDetectionStrategy, Component, inject, output, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RailwaySimulationService } from '../../services/railway-simulation.service';

export type ActiveTab =
  | 'uebersicht'
  | 'netz'
  | 'zuege'
  | 'stellwerk'
  | 'etcs'
  | 'fahrplan'
  | 'stoerungen'
  | 'was_waere_wenn'
  | 'bahnhoefe'
  | 'flotte'
  | 'energie'
  | 'analytik'
  | 'protokolle'
  | 'architektur';

@Component({
  selector: 'app-header',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <header class="border-b border-neutral-800 bg-neutral-950/95 sticky top-0 z-50 backdrop-blur">
      <!-- Top Zone: Brand Wordmark, Simulation Control & Digital Twin Safety Badge -->
      <div class="flex items-center justify-between px-4 py-2 border-b border-neutral-900 gap-4">
        <!-- Zone 1: Single Brand Element -->
        <div class="flex items-center gap-3 shrink-0">
          <div class="w-8 h-8 rounded bg-neutral-900 border border-neutral-700 flex items-center justify-center text-amber-500 font-bold font-mono text-base tracking-tighter">
            BW
          </div>
          <div>
            <div class="flex items-center gap-2">
              <span class="text-base font-extrabold tracking-tight text-neutral-100 font-mono">BAHNWERK 4.0</span>
              <span class="text-xs px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-400 border border-emerald-800/60 font-mono font-medium flex items-center gap-1">
                <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                SIMULATOR · DIGITALER ZWILLING
              </span>
            </div>
            <div class="text-[11px] text-neutral-400">
              INFRASTRUKTUR · ZÜGE · VERKEHR · EIN SYSTEM
            </div>
          </div>
        </div>

        <!-- Simulation Safety Warning Banner & Quick Scenario Shortcuts -->
        <div class="hidden xl:flex items-center gap-2 bg-neutral-900/90 border border-neutral-800 rounded px-3 py-1 text-xs">
          <mat-icon class="text-amber-400 text-sm h-4 w-4">shield</mat-icon>
          <span class="text-neutral-300 font-medium">Sicherheitsgrenze aktiv:</span>
          <span class="text-neutral-400 text-[11px]">Keine Verbindung zu realen Stellwerken (Synthetisches Referenzmodell DB-Netz)</span>
        </div>

        <!-- Zone 3: Clock, Controls & Quick Scenario Selector -->
        <div class="flex items-center gap-3 shrink-0">
          <!-- Simulation Clock Display -->
          <div class="flex items-center gap-2 bg-neutral-900 border border-neutral-800 rounded px-3 py-1 font-mono text-sm">
            <mat-icon class="text-neutral-400 text-base h-4 w-4">schedule</mat-icon>
            <span class="text-neutral-100 font-semibold tabular-nums">
              {{ sim.simulationTime() | date:'HH:mm:ss' }} CET
            </span>
          </div>

          <!-- Speed Multipliers -->
          <div class="flex items-center bg-neutral-900 border border-neutral-800 rounded p-0.5 text-xs font-mono">
            @for (speed of [1, 5, 10, 50, 100]; track speed) {
              <button
                (click)="sim.setSpeedMultiplier(speed)"
                [class.bg-amber-500]="sim.speedMultiplier() === speed"
                [class.text-neutral-950]="sim.speedMultiplier() === speed"
                [class.font-bold]="sim.speedMultiplier() === speed"
                [class.text-neutral-400]="sim.speedMultiplier() !== speed"
                class="px-2 py-0.5 rounded transition-colors hover:text-neutral-100 cursor-pointer">
                {{ speed }}×
              </button>
            }
          </div>

          <!-- Simulation Transport Controls -->
          <div class="flex items-center gap-1">
            @if (sim.isRunning()) {
              <button
                (click)="sim.pause()"
                title="Simulation anhalten"
                class="p-1.5 rounded bg-neutral-900 border border-neutral-700 hover:bg-neutral-800 text-amber-400 flex items-center cursor-pointer">
                <mat-icon class="text-base h-4 w-4">pause</mat-icon>
              </button>
            } @else {
              <button
                (click)="sim.resume()"
                title="Simulation fortsetzen"
                class="p-1.5 rounded bg-emerald-950 border border-emerald-700 hover:bg-emerald-900 text-emerald-400 flex items-center cursor-pointer">
                <mat-icon class="text-base h-4 w-4">play_arrow</mat-icon>
              </button>
            }

            <button
              (click)="sim.step()"
              title="Einzelschritt (+1s)"
              class="p-1.5 rounded bg-neutral-900 border border-neutral-700 hover:bg-neutral-800 text-neutral-300 flex items-center cursor-pointer">
              <mat-icon class="text-base h-4 w-4">skip_next</mat-icon>
            </button>

            <button
              (click)="sim.reset()"
              title="Simulation zurücksetzen"
              class="p-1.5 rounded bg-neutral-900 border border-neutral-700 hover:bg-neutral-800 text-neutral-400 hover:text-red-400 flex items-center cursor-pointer">
              <mat-icon class="text-base h-4 w-4">replay</mat-icon>
            </button>
          </div>
        </div>
      </div>

      <!-- Bottom Zone: Primary Industrial Navigation -->
      <nav class="flex items-center gap-1 px-3 py-1 overflow-x-auto text-xs font-medium text-neutral-300 scrollbar-thin">
        <button
          (click)="selectTab('uebersicht')"
          [class.bg-neutral-800]="activeTab() === 'uebersicht'"
          [class.text-amber-400]="activeTab() === 'uebersicht'"
          [class.border-neutral-700]="activeTab() === 'uebersicht'"
          class="flex items-center gap-1.5 px-3 py-1.5 rounded border border-transparent hover:bg-neutral-900 hover:text-neutral-100 transition-colors whitespace-nowrap cursor-pointer">
          <mat-icon class="text-sm h-4 w-4">dashboard</mat-icon>
          Übersicht
        </button>

        <button
          (click)="selectTab('netz')"
          [class.bg-neutral-800]="activeTab() === 'netz'"
          [class.text-amber-400]="activeTab() === 'netz'"
          [class.border-neutral-700]="activeTab() === 'netz'"
          class="flex items-center gap-1.5 px-3 py-1.5 rounded border border-transparent hover:bg-neutral-900 hover:text-neutral-100 transition-colors whitespace-nowrap cursor-pointer">
          <mat-icon class="text-sm h-4 w-4">map</mat-icon>
          Netz & Gleisplan
        </button>

        <button
          (click)="selectTab('zuege')"
          [class.bg-neutral-800]="activeTab() === 'zuege'"
          [class.text-amber-400]="activeTab() === 'zuege'"
          [class.border-neutral-700]="activeTab() === 'zuege'"
          class="flex items-center gap-1.5 px-3 py-1.5 rounded border border-transparent hover:bg-neutral-900 hover:text-neutral-100 transition-colors whitespace-nowrap cursor-pointer">
          <mat-icon class="text-sm h-4 w-4">train</mat-icon>
          Züge & Zwilling ({{ sim.trains().length }})
        </button>

        <button
          (click)="selectTab('stellwerk')"
          [class.bg-neutral-800]="activeTab() === 'stellwerk'"
          [class.text-amber-400]="activeTab() === 'stellwerk'"
          [class.border-neutral-700]="activeTab() === 'stellwerk'"
          class="flex items-center gap-1.5 px-3 py-1.5 rounded border border-transparent hover:bg-neutral-900 hover:text-neutral-100 transition-colors whitespace-nowrap cursor-pointer">
          <mat-icon class="text-sm h-4 w-4">alt_route</mat-icon>
          Digitales Stellwerk (DSTW)
        </button>

        <button
          (click)="selectTab('etcs')"
          [class.bg-neutral-800]="activeTab() === 'etcs'"
          [class.text-amber-400]="activeTab() === 'etcs'"
          [class.border-neutral-700]="activeTab() === 'etcs'"
          class="flex items-center gap-1.5 px-3 py-1.5 rounded border border-transparent hover:bg-neutral-900 hover:text-neutral-100 transition-colors whitespace-nowrap cursor-pointer">
          <mat-icon class="text-sm h-4 w-4">speed</mat-icon>
          ETCS / ATO Cockpit
        </button>

        <button
          (click)="selectTab('fahrplan')"
          [class.bg-neutral-800]="activeTab() === 'fahrplan'"
          [class.text-amber-400]="activeTab() === 'fahrplan'"
          [class.border-neutral-700]="activeTab() === 'fahrplan'"
          class="flex items-center gap-1.5 px-3 py-1.5 rounded border border-transparent hover:bg-neutral-900 hover:text-neutral-100 transition-colors whitespace-nowrap cursor-pointer">
          <mat-icon class="text-sm h-4 w-4">timer</mat-icon>
          Fahrplan & Trassen
        </button>

        <button
          (click)="selectTab('stoerungen')"
          [class.bg-neutral-800]="activeTab() === 'stoerungen'"
          [class.text-amber-400]="activeTab() === 'stoerungen'"
          [class.border-neutral-700]="activeTab() === 'stoerungen'"
          class="flex items-center gap-1.5 px-3 py-1.5 rounded border border-transparent hover:bg-neutral-900 hover:text-neutral-100 transition-colors whitespace-nowrap cursor-pointer">
          <mat-icon class="text-sm h-4 w-4" [class.text-amber-500]="sim.incidents().length > 0">warning</mat-icon>
          Störungsmanagement
          @if (sim.incidents().length > 0) {
            <span class="w-4 h-4 rounded-full bg-amber-500/20 text-amber-400 text-[10px] flex items-center justify-center font-bold">
              {{ sim.incidents().length }}
            </span>
          }
        </button>

        <button
          (click)="selectTab('was_waere_wenn')"
          [class.bg-neutral-800]="activeTab() === 'was_waere_wenn'"
          [class.text-amber-400]="activeTab() === 'was_waere_wenn'"
          [class.border-neutral-700]="activeTab() === 'was_waere_wenn'"
          class="flex items-center gap-1.5 px-3 py-1.5 rounded border border-transparent hover:bg-neutral-900 hover:text-neutral-100 transition-colors whitespace-nowrap cursor-pointer">
          <mat-icon class="text-sm h-4 w-4">science</mat-icon>
          Was-wäre-wenn
        </button>

        <button
          (click)="selectTab('bahnhoefe')"
          [class.bg-neutral-800]="activeTab() === 'bahnhoefe'"
          [class.text-amber-400]="activeTab() === 'bahnhoefe'"
          [class.border-neutral-700]="activeTab() === 'bahnhoefe'"
          class="flex items-center gap-1.5 px-3 py-1.5 rounded border border-transparent hover:bg-neutral-900 hover:text-neutral-100 transition-colors whitespace-nowrap cursor-pointer">
          <mat-icon class="text-sm h-4 w-4">location_city</mat-icon>
          Bahnhöfe
        </button>

        <button
          (click)="selectTab('flotte')"
          [class.bg-neutral-800]="activeTab() === 'flotte'"
          [class.text-amber-400]="activeTab() === 'flotte'"
          [class.border-neutral-700]="activeTab() === 'flotte'"
          class="flex items-center gap-1.5 px-3 py-1.5 rounded border border-transparent hover:bg-neutral-900 hover:text-neutral-100 transition-colors whitespace-nowrap cursor-pointer">
          <mat-icon class="text-sm h-4 w-4">build</mat-icon>
          Instandhaltung
        </button>

        <button
          (click)="selectTab('energie')"
          [class.bg-neutral-800]="activeTab() === 'energie'"
          [class.text-amber-400]="activeTab() === 'energie'"
          [class.border-neutral-700]="activeTab() === 'energie'"
          class="flex items-center gap-1.5 px-3 py-1.5 rounded border border-transparent hover:bg-neutral-900 hover:text-neutral-100 transition-colors whitespace-nowrap cursor-pointer">
          <mat-icon class="text-sm h-4 w-4">bolt</mat-icon>
          Energie (15 kV)
        </button>

        <button
          (click)="selectTab('analytik')"
          [class.bg-neutral-800]="activeTab() === 'analytik'"
          [class.text-amber-400]="activeTab() === 'analytik'"
          [class.border-neutral-700]="activeTab() === 'analytik'"
          class="flex items-center gap-1.5 px-3 py-1.5 rounded border border-transparent hover:bg-neutral-900 hover:text-neutral-100 transition-colors whitespace-nowrap cursor-pointer">
          <mat-icon class="text-sm h-4 w-4">analytics</mat-icon>
          R-Analytik
        </button>

        <button
          (click)="selectTab('protokolle')"
          [class.bg-neutral-800]="activeTab() === 'protokolle'"
          [class.text-amber-400]="activeTab() === 'protokolle'"
          [class.border-neutral-700]="activeTab() === 'protokolle'"
          class="flex items-center gap-1.5 px-3 py-1.5 rounded border border-transparent hover:bg-neutral-900 hover:text-neutral-100 transition-colors whitespace-nowrap cursor-pointer">
          <mat-icon class="text-sm h-4 w-4">receipt_long</mat-icon>
          Audit-Log
        </button>

        <button
          (click)="selectTab('architektur')"
          [class.bg-neutral-800]="activeTab() === 'architektur'"
          [class.text-amber-400]="activeTab() === 'architektur'"
          [class.border-neutral-700]="activeTab() === 'architektur'"
          class="flex items-center gap-1.5 px-3 py-1.5 rounded border border-transparent hover:bg-neutral-900 hover:text-neutral-100 transition-colors whitespace-nowrap cursor-pointer text-neutral-400">
          <mat-icon class="text-sm h-4 w-4">code</mat-icon>
          Codebase & Architektur
        </button>
      </nav>
    </header>
  `
})
export class HeaderComponent {
  readonly sim = inject(RailwaySimulationService);
  readonly activeTab = signal<ActiveTab>('uebersicht');
  readonly tabChange = output<ActiveTab>();

  selectTab(tab: ActiveTab): void {
    this.activeTab.set(tab);
    this.tabChange.emit(tab);
  }
}
