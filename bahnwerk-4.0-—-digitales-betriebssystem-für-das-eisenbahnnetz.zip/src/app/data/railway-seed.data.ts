import {
  RailwayNetwork,
  Station,
  TrackSection,
  BlockSection,
  Switch,
  Signal,
  Route,
  DigitalInterlocking,
  Train,
  Incident,
  MaintenanceWorkOrder,
  PowerGridMetrics,
  AuditLogEntry,
  WhatIfScenario
} from '../models/railway.models';

interface CorridorConnection {
  from: string;
  to: string;
  name: string;
  corridor: string;
  length: number;
  speed: number;
  blocks_count: number;
}

interface TrainTemplate {
  num: string;
  line: string;
  type: Train['train_type'];
  model: string;
  origin: string;
  dest: string;
  stops: string[];
  vmax: number;
  len: number;
  mass: number;
  delay: number;
}

export function createInitialRailwayNetwork(): RailwayNetwork {
  const stations: Station[] = [
    // NORD
    {
      id: 'st-hh',
      code: 'AH',
      name: 'Hamburg Hbf',
      region: 'NORD',
      x: 48,
      y: 18,
      tracks_count: 14,
      is_hub: true,
      has_depot: true,
      interlocking_id: 'dstw-hh',
      passenger_flow: {
        boardings_per_hour: 12400,
        alightings_per_hour: 11800,
        transfers_per_hour: 8500,
        current_waiting_passengers: 3200,
        crowding_level: 'NORMAL'
      },
      platforms: [
        { platform_id: 'p-hh-1', track_number: 1, length_m: 410, capacity_passengers: 950, passenger_load_pct: 65, access_state: 'FREI' },
        { platform_id: 'p-hh-2', track_number: 2, length_m: 410, capacity_passengers: 950, passenger_load_pct: 78, access_state: 'FREI' },
        { platform_id: 'p-hh-3', track_number: 3, length_m: 420, capacity_passengers: 1000, passenger_load_pct: 45, access_state: 'FREI' },
        { platform_id: 'p-hh-4', track_number: 4, length_m: 420, capacity_passengers: 1000, passenger_load_pct: 82, access_state: 'FREI' },
        { platform_id: 'p-hh-5', track_number: 5, length_m: 380, capacity_passengers: 800, passenger_load_pct: 50, access_state: 'FREI' },
        { platform_id: 'p-hh-6', track_number: 6, length_m: 380, capacity_passengers: 800, passenger_load_pct: 35, access_state: 'FREI' }
      ]
    },
    {
      id: 'st-hb',
      code: 'HB',
      name: 'Bremen Hbf',
      region: 'NORD',
      x: 36,
      y: 24,
      tracks_count: 9,
      is_hub: true,
      has_depot: false,
      interlocking_id: 'dstw-hb',
      passenger_flow: {
        boardings_per_hour: 5200,
        alightings_per_hour: 4900,
        transfers_per_hour: 3100,
        current_waiting_passengers: 1200,
        crowding_level: 'NORMAL'
      },
      platforms: [
        { platform_id: 'p-hb-1', track_number: 1, length_m: 390, capacity_passengers: 850, passenger_load_pct: 40, access_state: 'FREI' },
        { platform_id: 'p-hb-2', track_number: 2, length_m: 390, capacity_passengers: 850, passenger_load_pct: 55, access_state: 'FREI' }
      ]
    },
    {
      id: 'st-h',
      code: 'HH',
      name: 'Hannover Hbf',
      region: 'NORD',
      x: 46,
      y: 34,
      tracks_count: 12,
      is_hub: true,
      has_depot: true,
      interlocking_id: 'dstw-h',
      passenger_flow: {
        boardings_per_hour: 9800,
        alightings_per_hour: 9200,
        transfers_per_hour: 7900,
        current_waiting_passengers: 2400,
        crowding_level: 'NORMAL'
      },
      platforms: [
        { platform_id: 'p-h-1', track_number: 1, length_m: 410, capacity_passengers: 950, passenger_load_pct: 70, access_state: 'FREI' },
        { platform_id: 'p-h-2', track_number: 2, length_m: 410, capacity_passengers: 950, passenger_load_pct: 60, access_state: 'FREI' },
        { platform_id: 'p-h-3', track_number: 3, length_m: 420, capacity_passengers: 1000, passenger_load_pct: 50, access_state: 'FREI' },
        { platform_id: 'p-h-4', track_number: 4, length_m: 420, capacity_passengers: 1000, passenger_load_pct: 88, access_state: 'FREI' }
      ]
    },
    {
      id: 'st-ki',
      code: 'AK',
      name: 'Kiel Hbf',
      region: 'NORD',
      x: 50,
      y: 8,
      tracks_count: 6,
      is_hub: false,
      has_depot: false,
      interlocking_id: 'dstw-ki',
      passenger_flow: {
        boardings_per_hour: 2400,
        alightings_per_hour: 2200,
        transfers_per_hour: 800,
        current_waiting_passengers: 650,
        crowding_level: 'NORMAL'
      },
      platforms: [
        { platform_id: 'p-ki-1', track_number: 1, length_m: 320, capacity_passengers: 600, passenger_load_pct: 35, access_state: 'FREI' }
      ]
    },
    {
      id: 'st-ro',
      code: 'WR',
      name: 'Rostock Hbf',
      region: 'NORD',
      x: 68,
      y: 12,
      tracks_count: 8,
      is_hub: false,
      has_depot: false,
      interlocking_id: 'dstw-ro',
      passenger_flow: {
        boardings_per_hour: 2800,
        alightings_per_hour: 2600,
        transfers_per_hour: 900,
        current_waiting_passengers: 720,
        crowding_level: 'NORMAL'
      },
      platforms: [
        { platform_id: 'p-ro-1', track_number: 1, length_m: 350, capacity_passengers: 700, passenger_load_pct: 42, access_state: 'FREI' }
      ]
    },

    // OST
    {
      id: 'st-b',
      code: 'BL',
      name: 'Berlin Hbf',
      region: 'OST',
      x: 74,
      y: 30,
      tracks_count: 16,
      is_hub: true,
      has_depot: true,
      interlocking_id: 'dstw-b',
      passenger_flow: {
        boardings_per_hour: 15800,
        alightings_per_hour: 15100,
        transfers_per_hour: 11200,
        current_waiting_passengers: 4100,
        crowding_level: 'ERHÖHT'
      },
      platforms: [
        { platform_id: 'p-b-1', track_number: 1, length_m: 430, capacity_passengers: 1100, passenger_load_pct: 85, access_state: 'FREI' },
        { platform_id: 'p-b-2', track_number: 2, length_m: 430, capacity_passengers: 1100, passenger_load_pct: 68, access_state: 'FREI' },
        { platform_id: 'p-b-3', track_number: 3, length_m: 430, capacity_passengers: 1100, passenger_load_pct: 92, access_state: 'FREI' },
        { platform_id: 'p-b-4', track_number: 4, length_m: 430, capacity_passengers: 1100, passenger_load_pct: 74, access_state: 'FREI' }
      ]
    },
    {
      id: 'st-l',
      code: 'LL',
      name: 'Leipzig Hbf',
      region: 'OST',
      x: 70,
      y: 46,
      tracks_count: 24,
      is_hub: true,
      has_depot: true,
      interlocking_id: 'dstw-l',
      passenger_flow: {
        boardings_per_hour: 8200,
        alightings_per_hour: 7900,
        transfers_per_hour: 6100,
        current_waiting_passengers: 2100,
        crowding_level: 'NORMAL'
      },
      platforms: [
        { platform_id: 'p-l-1', track_number: 1, length_m: 400, capacity_passengers: 900, passenger_load_pct: 55, access_state: 'FREI' },
        { platform_id: 'p-l-2', track_number: 2, length_m: 400, capacity_passengers: 900, passenger_load_pct: 62, access_state: 'FREI' }
      ]
    },
    {
      id: 'st-dd',
      code: 'DH',
      name: 'Dresden Hbf',
      region: 'OST',
      x: 84,
      y: 52,
      tracks_count: 14,
      is_hub: true,
      has_depot: false,
      interlocking_id: 'dstw-dd',
      passenger_flow: {
        boardings_per_hour: 4900,
        alightings_per_hour: 4600,
        transfers_per_hour: 2800,
        current_waiting_passengers: 1100,
        crowding_level: 'NORMAL'
      },
      platforms: [
        { platform_id: 'p-dd-1', track_number: 1, length_m: 380, capacity_passengers: 800, passenger_load_pct: 45, access_state: 'FREI' }
      ]
    },
    {
      id: 'st-md',
      code: 'LM',
      name: 'Magdeburg Hbf',
      region: 'OST',
      x: 60,
      y: 38,
      tracks_count: 10,
      is_hub: false,
      has_depot: false,
      interlocking_id: 'dstw-md',
      passenger_flow: {
        boardings_per_hour: 3600,
        alightings_per_hour: 3400,
        transfers_per_hour: 1900,
        current_waiting_passengers: 850,
        crowding_level: 'NORMAL'
      },
      platforms: [
        { platform_id: 'p-md-1', track_number: 1, length_m: 360, capacity_passengers: 750, passenger_load_pct: 48, access_state: 'FREI' }
      ]
    },
    {
      id: 'st-ef',
      code: 'UE',
      name: 'Erfurt Hbf',
      region: 'OST',
      x: 58,
      y: 52,
      tracks_count: 10,
      is_hub: true,
      has_depot: false,
      interlocking_id: 'dstw-ef',
      passenger_flow: {
        boardings_per_hour: 6100,
        alightings_per_hour: 5800,
        transfers_per_hour: 5400,
        current_waiting_passengers: 1600,
        crowding_level: 'NORMAL'
      },
      platforms: [
        { platform_id: 'p-ef-1', track_number: 1, length_m: 410, capacity_passengers: 950, passenger_load_pct: 68, access_state: 'FREI' }
      ]
    },

    // WEST
    {
      id: 'st-k',
      code: 'KK',
      name: 'Köln Hbf',
      region: 'WEST',
      x: 24,
      y: 50,
      tracks_count: 11,
      is_hub: true,
      has_depot: true,
      interlocking_id: 'dstw-k',
      passenger_flow: {
        boardings_per_hour: 14200,
        alightings_per_hour: 13900,
        transfers_per_hour: 10400,
        current_waiting_passengers: 3900,
        crowding_level: 'ERHÖHT'
      },
      platforms: [
        { platform_id: 'p-k-1', track_number: 1, length_m: 410, capacity_passengers: 950, passenger_load_pct: 90, access_state: 'FREI' },
        { platform_id: 'p-k-2', track_number: 2, length_m: 410, capacity_passengers: 950, passenger_load_pct: 86, access_state: 'FREI' },
        { platform_id: 'p-k-3', track_number: 3, length_m: 410, capacity_passengers: 950, passenger_load_pct: 72, access_state: 'FREI' },
        { platform_id: 'p-k-4', track_number: 4, length_m: 410, capacity_passengers: 950, passenger_load_pct: 84, access_state: 'FREI' }
      ]
    },
    {
      id: 'st-d',
      code: 'KD',
      name: 'Düsseldorf Hbf',
      region: 'WEST',
      x: 22,
      y: 44,
      tracks_count: 16,
      is_hub: true,
      has_depot: false,
      interlocking_id: 'dstw-d',
      passenger_flow: {
        boardings_per_hour: 11500,
        alightings_per_hour: 11000,
        transfers_per_hour: 7800,
        current_waiting_passengers: 2800,
        crowding_level: 'NORMAL'
      },
      platforms: [
        { platform_id: 'p-d-1', track_number: 1, length_m: 410, capacity_passengers: 950, passenger_load_pct: 64, access_state: 'FREI' }
      ]
    },
    {
      id: 'st-do',
      code: 'EDO',
      name: 'Dortmund Hbf',
      region: 'WEST',
      x: 26,
      y: 40,
      tracks_count: 18,
      is_hub: true,
      has_depot: true,
      interlocking_id: 'dstw-do',
      passenger_flow: {
        boardings_per_hour: 9300,
        alightings_per_hour: 8900,
        transfers_per_hour: 6200,
        current_waiting_passengers: 2200,
        crowding_level: 'NORMAL'
      },
      platforms: [
        { platform_id: 'p-do-1', track_number: 1, length_m: 400, capacity_passengers: 900, passenger_load_pct: 58, access_state: 'FREI' }
      ]
    },
    {
      id: 'st-e',
      code: 'EE',
      name: 'Essen Hbf',
      region: 'WEST',
      x: 23,
      y: 42,
      tracks_count: 13,
      is_hub: true,
      has_depot: false,
      interlocking_id: 'dstw-e',
      passenger_flow: {
        boardings_per_hour: 8100,
        alightings_per_hour: 7800,
        transfers_per_hour: 5100,
        current_waiting_passengers: 1900,
        crowding_level: 'NORMAL'
      },
      platforms: [
        { platform_id: 'p-e-1', track_number: 1, length_m: 390, capacity_passengers: 850, passenger_load_pct: 52, access_state: 'FREI' }
      ]
    },
    {
      id: 'st-ac',
      code: 'KA',
      name: 'Aachen Hbf',
      region: 'WEST',
      x: 16,
      y: 54,
      tracks_count: 7,
      is_hub: false,
      has_depot: false,
      interlocking_id: 'dstw-ac',
      passenger_flow: {
        boardings_per_hour: 3100,
        alightings_per_hour: 2900,
        transfers_per_hour: 1200,
        current_waiting_passengers: 780,
        crowding_level: 'NORMAL'
      },
      platforms: [
        { platform_id: 'p-ac-1', track_number: 1, length_m: 350, capacity_passengers: 700, passenger_load_pct: 40, access_state: 'FREI' }
      ]
    },
    {
      id: 'st-ms',
      code: 'EMST',
      name: 'Münster (Westf) Hbf',
      region: 'WEST',
      x: 30,
      y: 32,
      tracks_count: 9,
      is_hub: false,
      has_depot: false,
      interlocking_id: 'dstw-ms',
      passenger_flow: {
        boardings_per_hour: 4400,
        alightings_per_hour: 4200,
        transfers_per_hour: 2100,
        current_waiting_passengers: 980,
        crowding_level: 'NORMAL'
      },
      platforms: [
        { platform_id: 'p-ms-1', track_number: 1, length_m: 370, capacity_passengers: 780, passenger_load_pct: 45, access_state: 'FREI' }
      ]
    },

    // MITTE
    {
      id: 'st-f',
      code: 'FF',
      name: 'Frankfurt (Main) Hbf',
      region: 'MITTE',
      x: 36,
      y: 62,
      tracks_count: 25,
      is_hub: true,
      has_depot: true,
      interlocking_id: 'dstw-f',
      passenger_flow: {
        boardings_per_hour: 17500,
        alightings_per_hour: 16800,
        transfers_per_hour: 13500,
        current_waiting_passengers: 4600,
        crowding_level: 'ERHÖHT'
      },
      platforms: [
        { platform_id: 'p-f-1', track_number: 1, length_m: 430, capacity_passengers: 1100, passenger_load_pct: 88, access_state: 'FREI' },
        { platform_id: 'p-f-2', track_number: 2, length_m: 430, capacity_passengers: 1100, passenger_load_pct: 94, access_state: 'FREI' },
        { platform_id: 'p-f-3', track_number: 3, length_m: 430, capacity_passengers: 1100, passenger_load_pct: 76, access_state: 'FREI' },
        { platform_id: 'p-f-4', track_number: 4, length_m: 430, capacity_passengers: 1100, passenger_load_pct: 81, access_state: 'FREI' },
        { platform_id: 'p-f-5', track_number: 5, length_m: 400, capacity_passengers: 900, passenger_load_pct: 69, access_state: 'FREI' }
      ]
    },
    {
      id: 'st-fflg',
      code: 'FFLF',
      name: 'Frankfurt Flughafen Fernbf',
      region: 'MITTE',
      x: 33,
      y: 65,
      tracks_count: 4,
      is_hub: true,
      has_depot: false,
      interlocking_id: 'dstw-fflg',
      passenger_flow: {
        boardings_per_hour: 7200,
        alightings_per_hour: 6900,
        transfers_per_hour: 4800,
        current_waiting_passengers: 1800,
        crowding_level: 'NORMAL'
      },
      platforms: [
        { platform_id: 'p-fflg-1', track_number: 4, length_m: 420, capacity_passengers: 1000, passenger_load_pct: 75, access_state: 'FREI' },
        { platform_id: 'p-fflg-2', track_number: 5, length_m: 420, capacity_passengers: 1000, passenger_load_pct: 70, access_state: 'FREI' }
      ]
    },
    {
      id: 'st-ma',
      code: 'RM',
      name: 'Mannheim Hbf',
      region: 'MITTE',
      x: 37,
      y: 71,
      tracks_count: 10,
      is_hub: true,
      has_depot: true,
      interlocking_id: 'dstw-ma',
      passenger_flow: {
        boardings_per_hour: 8800,
        alightings_per_hour: 8400,
        transfers_per_hour: 7200,
        current_waiting_passengers: 2300,
        crowding_level: 'NORMAL'
      },
      platforms: [
        { platform_id: 'p-ma-1', track_number: 1, length_m: 410, capacity_passengers: 950, passenger_load_pct: 62, access_state: 'FREI' },
        { platform_id: 'p-ma-2', track_number: 2, length_m: 410, capacity_passengers: 950, passenger_load_pct: 58, access_state: 'FREI' }
      ]
    },
    {
      id: 'st-ks',
      code: 'FKW',
      name: 'Kassel-Wilhelmshöhe',
      region: 'MITTE',
      x: 44,
      y: 47,
      tracks_count: 8,
      is_hub: true,
      has_depot: false,
      interlocking_id: 'dstw-ks',
      passenger_flow: {
        boardings_per_hour: 5400,
        alightings_per_hour: 5100,
        transfers_per_hour: 4900,
        current_waiting_passengers: 1400,
        crowding_level: 'NORMAL'
      },
      platforms: [
        { platform_id: 'p-ks-1', track_number: 1, length_m: 420, capacity_passengers: 1000, passenger_load_pct: 66, access_state: 'FREI' }
      ]
    },
    {
      id: 'st-wue',
      code: 'NWH',
      name: 'Würzburg Hbf',
      region: 'MITTE',
      x: 48,
      y: 65,
      tracks_count: 11,
      is_hub: true,
      has_depot: false,
      interlocking_id: 'dstw-wue',
      passenger_flow: {
        boardings_per_hour: 6700,
        alightings_per_hour: 6300,
        transfers_per_hour: 5800,
        current_waiting_passengers: 1750,
        crowding_level: 'NORMAL'
      },
      platforms: [
        { platform_id: 'p-wue-1', track_number: 1, length_m: 410, capacity_passengers: 950, passenger_load_pct: 60, access_state: 'FREI' }
      ]
    },
    {
      id: 'st-wi',
      code: 'FW',
      name: 'Wiesbaden Hbf',
      region: 'MITTE',
      x: 32,
      y: 62,
      tracks_count: 10,
      is_hub: false,
      has_depot: false,
      interlocking_id: 'dstw-wi',
      passenger_flow: {
        boardings_per_hour: 3800,
        alightings_per_hour: 3600,
        transfers_per_hour: 1400,
        current_waiting_passengers: 920,
        crowding_level: 'NORMAL'
      },
      platforms: [
        { platform_id: 'p-wi-1', track_number: 1, length_m: 360, capacity_passengers: 750, passenger_load_pct: 44, access_state: 'FREI' }
      ]
    },

    // SÜD
    {
      id: 'st-m',
      code: 'MH',
      name: 'München Hbf',
      region: 'SUED',
      x: 60,
      y: 88,
      tracks_count: 32,
      is_hub: true,
      has_depot: true,
      interlocking_id: 'dstw-m',
      passenger_flow: {
        boardings_per_hour: 16900,
        alightings_per_hour: 16200,
        transfers_per_hour: 12100,
        current_waiting_passengers: 4400,
        crowding_level: 'NORMAL'
      },
      platforms: [
        { platform_id: 'p-m-1', track_number: 11, length_m: 430, capacity_passengers: 1100, passenger_load_pct: 75, access_state: 'FREI' },
        { platform_id: 'p-m-2', track_number: 12, length_m: 430, capacity_passengers: 1100, passenger_load_pct: 82, access_state: 'FREI' },
        { platform_id: 'p-m-3', track_number: 13, length_m: 430, capacity_passengers: 1100, passenger_load_pct: 69, access_state: 'FREI' },
        { platform_id: 'p-m-4', track_number: 14, length_m: 430, capacity_passengers: 1100, passenger_load_pct: 91, access_state: 'FREI' }
      ]
    },
    {
      id: 'st-n',
      code: 'NN',
      name: 'Nürnberg Hbf',
      region: 'SUED',
      x: 57,
      y: 70,
      tracks_count: 22,
      is_hub: true,
      has_depot: true,
      interlocking_id: 'dstw-n',
      passenger_flow: {
        boardings_per_hour: 9600,
        alightings_per_hour: 9100,
        transfers_per_hour: 7500,
        current_waiting_passengers: 2500,
        crowding_level: 'NORMAL'
      },
      platforms: [
        { platform_id: 'p-n-1', track_number: 1, length_m: 420, capacity_passengers: 1000, passenger_load_pct: 70, access_state: 'FREI' },
        { platform_id: 'p-n-2', track_number: 2, length_m: 420, capacity_passengers: 1000, passenger_load_pct: 65, access_state: 'FREI' }
      ]
    },
    {
      id: 'st-s',
      code: 'TS',
      name: 'Stuttgart Hbf',
      region: 'SUED',
      x: 40,
      y: 80,
      tracks_count: 16,
      is_hub: true,
      has_depot: true,
      interlocking_id: 'dstw-s',
      passenger_flow: {
        boardings_per_hour: 10800,
        alightings_per_hour: 10400,
        transfers_per_hour: 8100,
        current_waiting_passengers: 2900,
        crowding_level: 'NORMAL'
      },
      platforms: [
        { platform_id: 'p-s-1', track_number: 1, length_m: 420, capacity_passengers: 1000, passenger_load_pct: 78, access_state: 'FREI' },
        { platform_id: 'p-s-2', track_number: 2, length_m: 420, capacity_passengers: 1000, passenger_load_pct: 72, access_state: 'FREI' }
      ]
    },
    {
      id: 'st-a',
      code: 'MA',
      name: 'Augsburg Hbf',
      region: 'SUED',
      x: 54,
      y: 84,
      tracks_count: 9,
      is_hub: false,
      has_depot: false,
      interlocking_id: 'dstw-a',
      passenger_flow: {
        boardings_per_hour: 5100,
        alightings_per_hour: 4800,
        transfers_per_hour: 3200,
        current_waiting_passengers: 1350,
        crowding_level: 'NORMAL'
      },
      platforms: [
        { platform_id: 'p-a-1', track_number: 1, length_m: 400, capacity_passengers: 900, passenger_load_pct: 54, access_state: 'FREI' }
      ]
    },
    {
      id: 'st-ka',
      code: 'RK',
      name: 'Karlsruhe Hbf',
      region: 'SUED',
      x: 35,
      y: 77,
      tracks_count: 14,
      is_hub: true,
      has_depot: false,
      interlocking_id: 'dstw-ka',
      passenger_flow: {
        boardings_per_hour: 6200,
        alightings_per_hour: 5900,
        transfers_per_hour: 4400,
        current_waiting_passengers: 1600,
        crowding_level: 'NORMAL'
      },
      platforms: [
        { platform_id: 'p-ka-1', track_number: 1, length_m: 410, capacity_passengers: 950, passenger_load_pct: 56, access_state: 'FREI' }
      ]
    },
    {
      id: 'st-fr',
      code: 'RF',
      name: 'Freiburg (Breisgau) Hbf',
      region: 'SUED',
      x: 30,
      y: 89,
      tracks_count: 8,
      is_hub: false,
      has_depot: false,
      interlocking_id: 'dstw-fr',
      passenger_flow: {
        boardings_per_hour: 4100,
        alightings_per_hour: 3900,
        transfers_per_hour: 2200,
        current_waiting_passengers: 1050,
        crowding_level: 'NORMAL'
      },
      platforms: [
        { platform_id: 'p-fr-1', track_number: 1, length_m: 380, capacity_passengers: 800, passenger_load_pct: 46, access_state: 'FREI' }
      ]
    },
    {
      id: 'st-ul',
      code: 'TU',
      name: 'Ulm Hbf',
      region: 'SUED',
      x: 47,
      y: 84,
      tracks_count: 8,
      is_hub: true,
      has_depot: false,
      interlocking_id: 'dstw-ul',
      passenger_flow: {
        boardings_per_hour: 4800,
        alightings_per_hour: 4500,
        transfers_per_hour: 3700,
        current_waiting_passengers: 1250,
        crowding_level: 'NORMAL'
      },
      platforms: [
        { platform_id: 'p-ul-1', track_number: 1, length_m: 400, capacity_passengers: 900, passenger_load_pct: 51, access_state: 'FREI' }
      ]
    },
    {
      id: 'st-in',
      code: 'MI',
      name: 'Ingolstadt Hbf',
      region: 'SUED',
      x: 58,
      y: 79,
      tracks_count: 7,
      is_hub: false,
      has_depot: false,
      interlocking_id: 'dstw-in',
      passenger_flow: {
        boardings_per_hour: 3200,
        alightings_per_hour: 3000,
        transfers_per_hour: 1800,
        current_waiting_passengers: 800,
        crowding_level: 'NORMAL'
      },
      platforms: [
        { platform_id: 'p-in-1', track_number: 1, length_m: 390, capacity_passengers: 850, passenger_load_pct: 42, access_state: 'FREI' }
      ]
    }
  ];

  // Interlockings
  const interlockings: DigitalInterlocking[] = stations.map((st) => ({
    interlocking_id: st.interlocking_id,
    code: `DSTW-${st.code}`,
    name: `DSTW ${st.name}`,
    region: st.region,
    station_ids: [st.id],
    block_ids: [],
    switch_ids: [],
    signal_ids: [],
    routes: [],
    status: 'NORMAL',
    mode: 'AUTOMATISCH',
    system_load_pct: Math.floor(35 + Math.random() * 30),
    uptime_hours: Math.floor(1420 + Math.random() * 5000),
    redundancy_active: true
  }));

  // Track connections (corridors)
  const connections: CorridorConnection[] = [
    { from: 'st-hh', to: 'st-h', name: 'NBS Hamburg - Hannover', corridor: 'Nord-Süd-Magistrale', length: 155, speed: 250, blocks_count: 6 },
    { from: 'st-hb', to: 'st-h', name: 'Strecke Bremen - Hannover', corridor: 'Weser-Leine-Achse', length: 122, speed: 200, blocks_count: 5 },
    { from: 'st-h', to: 'st-ks', name: 'SFS Hannover - Kassel-W.', corridor: 'SFS Hannover - Würzburg', length: 145, speed: 280, blocks_count: 6 },
    { from: 'st-h', to: 'st-b', name: 'SFS Hannover - Berlin', corridor: 'Ost-West-Achse', length: 254, speed: 250, blocks_count: 8 },
    { from: 'st-b', to: 'st-l', name: 'Strecke Berlin - Leipzig', corridor: 'VDE 8.3', length: 165, speed: 200, blocks_count: 6 },
    { from: 'st-l', to: 'st-ef', name: 'NBS Leipzig/Halle - Erfurt', corridor: 'VDE 8.2', length: 121, speed: 300, blocks_count: 5 },
    { from: 'st-ef', to: 'st-n', name: 'NBS Erfurt - Nürnberg', corridor: 'VDE 8.1 (Frankenwald)', length: 191, speed: 300, blocks_count: 7 },
    { from: 'st-ks', to: 'st-f', name: 'Main-Weser-Bahn Kassel - Ffm', corridor: 'Mitte-Nord', length: 185, speed: 200, blocks_count: 6 },
    { from: 'st-ks', to: 'st-wue', name: 'SFS Kassel - Würzburg', corridor: 'SFS Hannover - Würzburg', length: 182, speed: 280, blocks_count: 7 },
    { from: 'st-f', to: 'st-k', name: 'SFS Köln - Rhein/Main', corridor: 'SFS K-RM', length: 177, speed: 300, blocks_count: 7 },
    { from: 'st-k', to: 'st-d', name: 'Strecke Köln - Düsseldorf', corridor: 'Rhein-Ruhr-Achse', length: 40, speed: 160, blocks_count: 3 },
    { from: 'st-d', to: 'st-e', name: 'Strecke Düsseldorf - Essen', corridor: 'Ruhrschnellverkehr', length: 35, speed: 160, blocks_count: 3 },
    { from: 'st-e', to: 'st-do', name: 'Strecke Essen - Dortmund', corridor: 'Ruhrschnellverkehr', length: 32, speed: 160, blocks_count: 3 },
    { from: 'st-do', to: 'st-h', name: 'Strecke Dortmund - Hannover', corridor: 'Stammlinie', length: 210, speed: 200, blocks_count: 7 },
    { from: 'st-f', to: 'st-ma', name: 'Riedbahn Frankfurt - Mannheim', corridor: 'Riedbahn-Korridor', length: 78, speed: 200, blocks_count: 4 },
    { from: 'st-ma', to: 'st-s', name: 'SFS Mannheim - Stuttgart', corridor: 'SFS MA-S', length: 99, speed: 280, blocks_count: 5 },
    { from: 'st-s', to: 'st-ul', name: 'NBS Wendlingen - Ulm', corridor: 'NBS Albaufstieg', length: 85, speed: 250, blocks_count: 4 },
    { from: 'st-ul', to: 'st-a', name: 'Strecke Ulm - Augsburg', corridor: 'Bayerische Westbahn', length: 86, speed: 200, blocks_count: 4 },
    { from: 'st-a', to: 'st-m', name: 'Ausbaustrecke Augsburg - München', corridor: 'Magistrale Süd', length: 62, speed: 230, blocks_count: 3 },
    { from: 'st-n', to: 'st-in', name: 'SFS Nürnberg - Ingolstadt', corridor: 'SFS N-IN-M', length: 90, speed: 300, blocks_count: 4 },
    { from: 'st-in', to: 'st-m', name: 'Strecke Ingolstadt - München', corridor: 'SFS N-IN-M', length: 81, speed: 200, blocks_count: 4 },
    { from: 'st-wue', to: 'st-n', name: 'Strecke Würzburg - Nürnberg', corridor: 'Frankenbahn', length: 102, speed: 160, blocks_count: 4 },
    { from: 'st-ma', to: 'st-ka', name: 'Rheintalbahn Mannheim - Karlsruhe', corridor: 'Rheintal-Magistrale', length: 60, speed: 200, blocks_count: 3 },
    { from: 'st-ka', to: 'st-fr', name: 'Rheintalbahn Karlsruhe - Freiburg', corridor: 'Rheintal-Magistrale', length: 135, speed: 250, blocks_count: 5 },
    { from: 'st-b', to: 'st-dd', name: 'Strecke Berlin - Dresden', corridor: 'VDE 9', length: 180, speed: 200, blocks_count: 6 }
  ];

  const track_sections: TrackSection[] = [];
  const blocks: BlockSection[] = [];
  const switches: Switch[] = [];
  const signals: Signal[] = [];
  const routes: Route[] = [];

  let blockGlobalIndex = 1;
  let switchGlobalIndex = 1;
  let signalGlobalIndex = 1;
  let routeGlobalIndex = 1;

  connections.forEach((conn, connIdx) => {
    const fromSt = stations.find((s) => s.id === conn.from)!;
    const toSt = stations.find((s) => s.id === conn.to)!;
    const sectionId = `sec-${connIdx + 1}`;
    const sectionBlocks: BlockSection[] = [];

    const blockLen = (conn.length * 1000) / conn.blocks_count;
    for (let b = 0; b < conn.blocks_count; b++) {
      const bIdx = blockGlobalIndex++;
      const blockCode = `B-${bIdx.toString().padStart(3, '0')}`;
      const t1 = b / conn.blocks_count;
      const t2 = (b + 1) / conn.blocks_count;
      const x1 = fromSt.x + (toSt.x - fromSt.x) * t1;
      const y1 = fromSt.y + (toSt.y - fromSt.y) * t1;
      const x2 = fromSt.x + (toSt.x - fromSt.x) * t2;
      const y2 = fromSt.y + (toSt.y - fromSt.y) * t2;

      // Create signals for block
      const sig1Id = `sig-${signalGlobalIndex++}`;
      const sigCode = `S-${(signalGlobalIndex - 1).toString().padStart(3, '0')}`;
      signals.push({
        signal_id: sig1Id,
        code: sigCode,
        name: `Signal ${sigCode} (${conn.name})`,
        interlocking_id: fromSt.interlocking_id,
        block_id: `blk-${bIdx}`,
        type: 'HAUPTSIGNAL',
        aspect: 'FAHRT',
        target_speed_kmh: conn.speed,
        is_dark: false,
        fault: false,
        x: x1 + (x2 - x1) * 0.1,
        y: y1 + (y2 - y1) * 0.1
      });

      const blockObj: BlockSection = {
        block_id: `blk-${bIdx}`,
        code: blockCode,
        section_id: sectionId,
        name: `Block ${blockCode} (${conn.name} #${b + 1})`,
        from_node_id: b === 0 ? fromSt.id : `node-${bIdx - 1}`,
        to_node_id: b === conn.blocks_count - 1 ? toSt.id : `node-${bIdx}`,
        length_m: Math.round(blockLen),
        max_speed_kmh: conn.speed,
        state: 'FREI',
        interlocking_id: fromSt.interlocking_id,
        signals: [sig1Id],
        degradation_score: Math.floor(5 + Math.random() * 20),
        track_temperature_c: Math.round(18 + Math.random() * 8),
        vibration_rms: +(0.4 + Math.random() * 0.5).toFixed(2),
        x1,
        y1,
        x2,
        y2
      };

      blocks.push(blockObj);
      sectionBlocks.push(blockObj);
    }

    track_sections.push({
      section_id: sectionId,
      name: conn.name,
      region: fromSt.region,
      from_station_id: fromSt.id,
      to_station_id: toSt.id,
      length_km: conn.length,
      max_speed_kmh: conn.speed,
      electrified: true,
      gradient_permille: Math.round((Math.random() * 20 - 5) * 10) / 10,
      curvature_radius_m: conn.speed > 250 ? 4000 : 1800,
      track_count: 2,
      blocks: sectionBlocks,
      maintenance_state: 'NORMAL',
      corridor_name: conn.corridor
    });
  });

  // Create Switches at hubs & junctions (40 switches)
  stations.forEach((st) => {
    const swCount = st.is_hub ? 2 : 1;
    for (let k = 0; k < swCount; k++) {
      if (switchGlobalIndex <= 40) {
        const swIdx = switchGlobalIndex++;
        const swCode = `W-${swIdx.toString().padStart(3, '0')}`;
        switches.push({
          switch_id: `sw-${swIdx}`,
          code: swCode,
          name: `Weiche ${swCode} (${st.name} Vorfeld)`,
          interlocking_id: st.interlocking_id,
          station_id: st.id,
          position: 'GERADE',
          normal_position: 'GERADE',
          reverse_position: 'ABZWEIG',
          state: 'IDLE',
          locked: false,
          occupied: false,
          motor_current_mA: 2450 + Math.floor(Math.random() * 400),
          vibration_rms: +(0.35 + Math.random() * 0.4).toFixed(2),
          temperature_c: 21.4 + Math.random() * 5,
          cycle_count: 4200 + Math.floor(Math.random() * 8000),
          maintenance_state: 'NORMAL',
          last_maintenance: '2026-08-14',
          x: st.x + (k === 0 ? -1.5 : 1.5),
          y: st.y + (k === 0 ? -1.2 : 1.2)
        });
      }
    }
  });

  // Generate Fahrstraßen (Routes)
  const routeDefinitions = [
    { code: 'F-0187', name: 'Fahrstraße F-0187 (München Hbf -> Augsburg)', from: 'st-m', to: 'st-a', sw: ['sw-22', 'sw-23'], blk: ['blk-81', 'blk-82', 'blk-83'] },
    { code: 'F-0188', name: 'Fahrstraße F-0188 (Frankfurt Fernbf -> Köln)', from: 'st-f', to: 'st-k', sw: ['sw-17', 'sw-18'], blk: ['blk-45', 'blk-46', 'blk-47'] },
    { code: 'F-0189', name: 'Fahrstraße F-0189 (Hannover -> Berlin SFS)', from: 'st-h', to: 'st-b', sw: ['sw-3', 'sw-4'], blk: ['blk-18', 'blk-19', 'blk-20'] },
    { code: 'F-0190', name: 'Fahrstraße F-0190 (Erfurt -> Nürnberg VDE8)', from: 'st-ef', to: 'st-n', sw: ['sw-9', 'sw-24'], blk: ['blk-35', 'blk-36', 'blk-37'] },
    { code: 'F-0191', name: 'Fahrstraße F-0191 (Hamburg -> Hannover NBS)', from: 'st-hh', to: 'st-h', sw: ['sw-1', 'sw-2'], blk: ['blk-1', 'blk-2', 'blk-3'] },
    { code: 'F-0192', name: 'Fahrstraße F-0192 (Mannheim -> Stuttgart SFS)', from: 'st-ma', to: 'st-s', sw: ['sw-19', 'sw-25'], blk: ['blk-66', 'blk-67', 'blk-68'] },
    { code: 'F-0193', name: 'Fahrstraße F-0193 (Dortmund -> Essen Ruhr)', from: 'st-do', to: 'st-e', sw: ['sw-13', 'sw-14'], blk: ['blk-58', 'blk-59', 'blk-60'] },
    { code: 'F-0194', name: 'Fahrstraße F-0194 (Würzburg -> Nürnberg)', from: 'st-wue', to: 'st-n', sw: ['sw-21', 'sw-24'], blk: ['blk-92', 'blk-93', 'blk-94'] }
  ];

  routeDefinitions.forEach((rd) => {
    const rIdx = routeGlobalIndex++;
    const startSt = stations.find((s) => s.id === rd.from)!;
    const rObj: Route = {
      route_id: `rt-${rIdx}`,
      code: rd.code,
      name: rd.name,
      interlocking_id: startSt.interlocking_id,
      start_signal_id: signals[rIdx % signals.length].signal_id,
      end_signal_or_platform: `${rd.to}-Gl.4`,
      switches: rd.sw.map((swId) => ({ switch_id: swId, required_position: 'GERADE' })),
      blocks: rd.blk,
      state: 'EINGESTELLT_GESICHERT',
      priority: 1
    };
    routes.push(rObj);
  });

  return {
    stations,
    track_sections,
    blocks,
    switches,
    signals,
    interlockings,
    routes
  };
}

export function createInitialTrains(network: RailwayNetwork): Train[] {
  const trainTemplates: TrainTemplate[] = [
    { num: 'ICE 742', line: 'ICE-Linie 25', type: 'ICE', model: 'ICE 4 (Baureihe 412 - 12-Teiler)', origin: 'st-m', dest: 'st-hh', stops: ['st-m', 'st-a', 'st-n', 'st-wue', 'st-ks', 'st-h', 'st-hh'], vmax: 265, len: 346, mass: 860, delay: 0 },
    { num: 'ICE 1502', line: 'ICE-Linie 28', type: 'ICE', model: 'ICE 3 Neo (Baureihe 408)', origin: 'st-m', dest: 'st-b', stops: ['st-m', 'st-in', 'st-n', 'st-ef', 'st-l', 'st-b'], vmax: 300, len: 200, mass: 460, delay: 3 },
    { num: 'ICE 904', line: 'ICE-Linie 11', type: 'ICE', model: 'ICE 4 (Baureihe 412 - 13-Teiler XXL)', origin: 'st-b', dest: 'st-m', stops: ['st-b', 'st-l', 'st-ef', 'st-n', 'st-a', 'st-m'], vmax: 250, len: 374, mass: 910, delay: 0 },
    { num: 'ICE 518', line: 'ICE-Linie 42', type: 'ICE', model: 'ICE 3 (Baureihe 403 Velaro)', origin: 'st-m', dest: 'st-do', stops: ['st-m', 'st-a', 'st-ul', 'st-s', 'st-ma', 'st-fflg', 'st-k', 'st-d', 'st-e', 'st-do'], vmax: 300, len: 200, mass: 435, delay: 7 },
    { num: 'ICE 672', line: 'ICE-Linie 12', type: 'ICE', model: 'ICE 1 (Baureihe 401 Modernisiert)', origin: 'st-hh', dest: 'st-s', stops: ['st-hh', 'st-h', 'st-ks', 'st-f', 'st-ma', 'st-s'], vmax: 280, len: 358, mass: 820, delay: 0 },
    { num: 'IC 2011', line: 'IC-Linie 26', type: 'IC', model: 'IC 2 KISS (Baureihe 4110)', origin: 'st-ro', dest: 'st-ka', stops: ['st-ro', 'st-hh', 'st-h', 'st-ks', 'st-f', 'st-ma', 'st-ka'], vmax: 200, len: 156, mass: 310, delay: 2 },
    { num: 'RE 3812', line: 'RE 1 NRW', type: 'RE', model: 'Siemens Desiro HC (Baureihe 1462)', origin: 'st-ac', dest: 'st-h', stops: ['st-ac', 'st-k', 'st-d', 'st-e', 'st-do', 'st-h'], vmax: 160, len: 210, mass: 380, delay: 11 },
    { num: 'RE 4801', line: 'RE 8 Franken-Thüringen', type: 'RE', model: 'Bombardier Twindexx Vario (BR 445)', origin: 'st-wue', dest: 'st-ef', stops: ['st-wue', 'st-n', 'st-ef'], vmax: 160, len: 160, mass: 290, delay: 0 },
    { num: 'RB 2104', line: 'RB 68 Main-Neckar', type: 'RB', model: 'Alstom Coradia Continental (BR 1440)', origin: 'st-f', dest: 'st-ma', stops: ['st-f', 'st-ma'], vmax: 160, len: 140, mass: 220, delay: 15 },
    { num: 'RB 1109', line: 'RB 33 Bayerische Regiobahn', type: 'RB', model: 'Siemens Mireo (Baureihe 463)', origin: 'st-m', dest: 'st-a', stops: ['st-m', 'st-a'], vmax: 160, len: 70, mass: 125, delay: 0 },
    { num: 'S 3410', line: 'S 3 Rhein-Main', type: 'S-BAHN', model: 'Baureihe 430 Triebzug', origin: 'st-wi', dest: 'st-f', stops: ['st-wi', 'st-fflg', 'st-f'], vmax: 140, len: 68, mass: 120, delay: 1 },
    { num: 'S 3411', line: 'S 4 S-Bahn München', type: 'S-BAHN', model: 'Baureihe 423 modernisiert', origin: 'st-a', dest: 'st-m', stops: ['st-a', 'st-m'], vmax: 140, len: 67, mass: 115, delay: 0 },
    { num: 'GAG 44102', line: 'Ganzgüterzug Erz/Kohle', type: 'GÜTERZUG', model: 'Siemens Vectron (Baureihe 193 Doppel)', origin: 'st-hh', dest: 'st-s', stops: ['st-hh', 'st-h', 'st-ks', 'st-wue', 'st-s'], vmax: 120, len: 680, mass: 2800, delay: 4 },
    { num: 'EZ 51203', line: 'Kombinierter Ladungsverkehr (KLV)', type: 'GÜTERZUG', model: 'TRAXX MS3 (Baureihe 188)', origin: 'st-k', dest: 'st-n', stops: ['st-k', 'st-f', 'st-wue', 'st-n'], vmax: 120, len: 620, mass: 1950, delay: 0 }
  ];

  // Populate up to 80 trains programmatically
  const trains: Train[] = [];
  const startHour = 14;

  for (let i = 0; i < 80; i++) {
    const tmpl = trainTemplates[i % trainTemplates.length];
    const isCopy = i >= trainTemplates.length;
    const trainNum = isCopy ? `${tmpl.type} ${Math.floor(1000 + i * 37)}` : tmpl.num;
    const lineName = isCopy ? `${tmpl.type}-Linie ${Math.floor((i % 15) + 1)}` : tmpl.line;

    // Pick 2 connected stations or template stops
    const stopStations = tmpl.stops.map((sid) => network.stations.find((s) => s.id === sid)!);
    const stopCount = stopStations.length;
    const currentStopIdx = Math.min(Math.floor(Math.random() * (stopCount - 1)), stopCount - 2);

    const fromSt = stopStations[currentStopIdx];
    const toSt = stopStations[currentStopIdx + 1];

    // Find a block belonging to this section or a nearby one
    const matchingSection = network.track_sections.find(
      (sec) =>
        (sec.from_station_id === fromSt.id && sec.to_station_id === toSt.id) ||
        (sec.from_station_id === toSt.id && sec.to_station_id === fromSt.id)
    );

    const blockList = matchingSection ? matchingSection.blocks : network.blocks;
    const assignedBlock = blockList[i % blockList.length];

    const progressRatio = +(0.1 + (i % 8) * 0.1).toFixed(2);
    const curSpeed = tmpl.type === 'GÜTERZUG' ? 100 : Math.round(tmpl.vmax * 0.85);

    const schedStops = stopStations.map((st, sIdx) => {
      const arrMinutes = 15 + sIdx * 25 + (i % 10) * 2;
      const arrH = (startHour + Math.floor(arrMinutes / 60)) % 24;
      const arrM = arrMinutes % 60;
      const depM = (arrM + 3) % 60;
      const depH = depM < arrM ? (arrH + 1) % 24 : arrH;

      const arrStr = `${arrH.toString().padStart(2, '0')}:${arrM.toString().padStart(2, '0')}`;
      const depStr = `${depH.toString().padStart(2, '0')}:${depM.toString().padStart(2, '0')}`;

      return {
        station_id: st.id,
        station_name: st.name,
        platform: `Gleis ${(sIdx % 4) + 1}`,
        planned_arrival: arrStr,
        actual_arrival: sIdx <= currentStopIdx ? arrStr : undefined,
        planned_departure: depStr,
        actual_departure: sIdx < currentStopIdx ? depStr : undefined,
        dwell_minutes: 3,
        status: (sIdx < currentStopIdx ? 'BEENDET' : sIdx === currentStopIdx ? 'AKTUELL' : 'AUSSTEHEND') as 'BEENDET' | 'AKTUELL' | 'AUSSTEHEND',
        passenger_exchange: {
          in: Math.floor(40 + Math.random() * 220),
          out: Math.floor(30 + Math.random() * 180)
        }
      };
    });

    const posX = assignedBlock.x1 + (assignedBlock.x2 - assignedBlock.x1) * progressRatio;
    const posY = assignedBlock.y1 + (assignedBlock.y2 - assignedBlock.y1) * progressRatio;

    const maxPax = tmpl.type === 'GÜTERZUG' ? 0 : tmpl.type === 'ICE' ? 830 : tmpl.type === 'RE' ? 520 : 380;
    const curPax = tmpl.type === 'GÜTERZUG' ? 0 : Math.round(maxPax * (0.45 + Math.random() * 0.45));

    trains.push({
      train_id: `tr-${i + 1}`,
      train_number: trainNum,
      line_name: lineName,
      train_type: tmpl.type,
      model_name: tmpl.model,
      operator: 'DB Fernverkehr AG / DB Regio AG',
      origin_station_id: stopStations[0].id,
      destination_station_id: stopStations[stopCount - 1].id,
      length_m: tmpl.len,
      mass_t: tmpl.mass,
      max_speed_kmh: tmpl.vmax,
      current_speed_kmh: curSpeed,
      target_speed_kmh: tmpl.vmax,
      acceleration_mps2: 0.65,
      braking_rate_mps2: 0.95,
      state: i % 12 === 0 ? 'BAHNHOF' : curSpeed > 0 ? 'FAHRT' : 'HALT',
      current_block_id: assignedBlock.block_id,
      current_route_id: `rt-${(i % network.routes.length) + 1}`,
      distance_in_block_m: Math.round(assignedBlock.length_m * progressRatio),
      progress_ratio: progressRatio,
      x: posX,
      y: posY,
      direction_angle: Math.atan2(assignedBlock.y2 - assignedBlock.y1, assignedBlock.x2 - assignedBlock.x1) * (180 / Math.PI),
      schedule: schedStops,
      current_stop_index: currentStopIdx,
      delay_minutes: isCopy ? (i % 7 === 0 ? Math.floor(Math.random() * 14) : 0) : tmpl.delay,
      passenger_count: curPax,
      passenger_capacity: maxPax,
      energy_active_mw: +(tmpl.type === 'GÜTERZUG' ? 3.8 : 2.4 + (curSpeed / tmpl.vmax) * 2.2).toFixed(2),
      total_energy_kwh: Math.round(1850 + Math.random() * 3200),
      regenerated_energy_kwh: Math.round(420 + Math.random() * 850),
      etcs: {
        train_id: `tr-${i + 1}`,
        target_position_m: 4500,
        permitted_speed_kmh: tmpl.vmax,
        target_speed_kmh: tmpl.vmax,
        validity_distance_m: 6800,
        release_speed_kmh: 40,
        brake_curve_mode: 'NORMAL',
        distance_to_target_m: 3400,
        emergency_brake_distance_m: 1450,
        service_brake_distance_m: 2100
      },
      ato: {
        enabled: true,
        mode: 'CRUISING',
        target_stop_accuracy_cm: 6,
        dwell_time_remaining_s: 0,
        energy_saving_mode: true,
        trajectory_points: [
          { dist: 0, target_v: 0, actual_v: 0 },
          { dist: 500, target_v: 120, actual_v: 118 },
          { dist: 1500, target_v: 250, actual_v: 250 },
          { dist: 3500, target_v: 250, actual_v: 248 },
          { dist: 4500, target_v: 0, actual_v: 0 }
        ]
      },
      telemetry: {
        pantograph_voltage_kv: +(14.8 + Math.random() * 0.4).toFixed(2),
        catenary_current_a: Math.round(160 + (curSpeed / tmpl.vmax) * 240),
        motor_torque_pct: Math.round(45 + Math.random() * 30),
        brake_cylinder_pressure_bar: +(0.0).toFixed(1),
        main_reservoir_bar: +(8.8 + Math.random() * 0.4).toFixed(1),
        axle_bearing_temp_c: Math.round(42 + Math.random() * 12),
        wheel_vibration_mm_s: +(0.45 + Math.random() * 0.25).toFixed(2),
        hvac_temp_c: +(21.5 + Math.random() * 0.8).toFixed(1),
        battery_soc_pct: 98,
        doors_status: 'GESCHLOSSEN',
        flange_lubrication_active: true
      },
      route_history: [assignedBlock.block_id]
    });
  }

  return trains;
}

export function createInitialIncidents(): Incident[] {
  return [
    {
      incident_id: 'inc-01',
      type: 'WEICHENSTÖRUNG',
      severity: 'KRITISCH',
      title: 'Weichenantrieb W-017 Endlagenüberwachung gestört',
      description: 'Weiche W-017 (DSTW Frankfurt Hbf Vorfeld) meldet Endlagenverlust im Zweiggleis. Elektrische Sicherung verriegelt.',
      entity_type: 'WEICHE',
      entity_id: 'sw-17',
      entity_name: 'Weiche W-017 (Frankfurt Fernbf Vorfeld)',
      location_name: 'Frankfurt (Main) Fernbahnhof Vorfeld Süd',
      timestamp: '2026-09-25 14:18:02',
      resolved: false,
      affected_train_ids: ['tr-1', 'tr-7', 'tr-9'],
      affected_route_ids: ['rt-2'],
      avg_delay_addition_min: 8.5,
      strategies: [
        {
          scenario_name: 'Strategie A: Umleitung über SFS-Gleis 5',
          description: 'Zug ICE 742 über Verbindungsgleis 5 umleiten. RE 3812 wartet auf Ausweichgleis B-082.',
          total_delay_min: 7,
          affected_trains_count: 3,
          passenger_impact: 'Gering (Anschlüsse in Hannover Hbf bleiben erhalten)',
          energy_impact_kwh: 120,
          feasibility_score: 94,
          actions: ['Fahrstraße F-0188 stornieren', 'Not-Fahrstraße F-0188-B schalten', 'Signal S-042 auf Halt'],
          recommended: true
        },
        {
          scenario_name: 'Strategie B: Wechselseitige Gleisnutzung im Richtungsbetrieb',
          description: 'Gegengleisfahrt mit Zs 6 für alle 5 betroffenen Züge auf Block B-046.',
          total_delay_min: 14,
          affected_trains_count: 5,
          passenger_impact: 'Mittel (+14 Min Verspätung für RE 3812)',
          energy_impact_kwh: 260,
          feasibility_score: 78,
          actions: ['Befehl 2 an Lokführer ICE 742 über GSM-R', 'Gegengleis sperren für Gegenzüge']
        },
        {
          scenario_name: 'Strategie C: Warten bis Entstörung durch Instandhaltung',
          description: 'Züge halten vor Signal S-042 bis Handkurbelbedienung und Festlegung durch Fahrwegprüfer erfolgt.',
          total_delay_min: 32,
          affected_trains_count: 6,
          passenger_impact: 'Kritisch (Anschlussbrüche in Frankfurt Hbf & Köln Hbf)',
          energy_impact_kwh: 480,
          feasibility_score: 42,
          actions: ['Instandhaltungstrupp Werkstatt Frankfurt alarmieren', 'Schadensprotokoll anfertigen']
        }
      ]
    },
    {
      incident_id: 'inc-02',
      type: 'STRECKENSPERRUNG',
      severity: 'WARNUNG',
      title: 'Streckenblock B-081 Gleislagefehler / Notinstandsetzung',
      description: 'Streckensensor meldet unzulässige Gleisverwerfung auf Block B-081 (Augsburg - München).',
      entity_type: 'BLOCK',
      entity_id: 'blk-81',
      entity_name: 'Block B-081 (Magistrale Süd)',
      location_name: 'Strecke Augsburg - München (km 42.8)',
      timestamp: '2026-09-25 14:05:12',
      resolved: false,
      affected_train_ids: ['tr-1', 'tr-4', 'tr-10'],
      affected_route_ids: ['rt-1'],
      avg_delay_addition_min: 11.2,
      strategies: [
        {
          scenario_name: 'Strategie A: Langsamfahrstelle 70 km/h statt Vollsperrung',
          description: 'Betrieb mit reduzierter Geschwindigkeit Vmax = 70 km/h auf 1200 m freigeben.',
          total_delay_min: 5,
          affected_trains_count: 4,
          passenger_impact: 'Minimal (+4 min Pufferaufzehrung)',
          energy_impact_kwh: 80,
          feasibility_score: 91,
          actions: ['La-Eintrag an Fahrdienstleiter übermitteln', 'ETCS Temporary Speed Restriction (TSR) senden'],
          recommended: true
        },
        {
          scenario_name: 'Strategie B: Umleitung über Altstrecke Geltendorf',
          description: 'Fernverkehrszüge über Geltendorf umleiten, Güterverkehr zurückhalten.',
          total_delay_min: 18,
          affected_trains_count: 7,
          passenger_impact: 'Erheblich (+18 Min, Trassenkonflikt mit Regionalbahn)',
          energy_impact_kwh: 340,
          feasibility_score: 65,
          actions: ['Trassenumdisponierung in R-Analytics einspeisen', 'Zuglaufüberwachung aktivieren']
        }
      ]
    },
    {
      incident_id: 'inc-03',
      type: 'TÜRSTÖRUNG',
      severity: 'INFO',
      title: 'Triebzug ICE 518 Tür 4 Wagen 7 blockiert',
      description: 'Lichtgitter-Einklemmschutz meldet Dauerhindernis während Fahrgastwechsel in Mannheim Hbf.',
      entity_type: 'ZUG',
      entity_id: 'tr-4',
      entity_name: 'ICE 518',
      location_name: 'Mannheim Hbf Gleis 2',
      timestamp: '2026-09-25 14:21:40',
      resolved: false,
      affected_train_ids: ['tr-4'],
      affected_route_ids: [],
      avg_delay_addition_min: 4.0,
      strategies: [
        {
          scenario_name: 'Strategie A: Tür lokal mit Vierkant absperren',
          description: 'Zugbegleiter verriegelt Tür mechanisch und bringt Störungsaufkleber an.',
          total_delay_min: 3,
          affected_trains_count: 1,
          passenger_impact: 'Keine Beeinträchtigung anderer Züge',
          energy_impact_kwh: 10,
          feasibility_score: 99,
          actions: ['Zugführer quittiert Störung am MMI', 'Fahrtfreigabe erteilen'],
          recommended: true
        }
      ]
    }
  ];
}

export function createInitialWorkOrders(): MaintenanceWorkOrder[] {
  return [
    {
      order_id: 'wo-101',
      code: 'IA-2026-0881',
      component_type: 'WEICHENANTRIEB',
      component_id: 'sw-17',
      component_name: 'Weichenantrieb Siemens S700K (W-017)',
      location: 'Frankfurt Hbf Vorfeld Süd (Gleis 102)',
      priority: 'DRINGEND',
      anomaly_description: 'Motorstrom bei Umstellvorgang auf 5.4A angestiegen (Toleranz: 3.2A). Vibrationen im Getriebeblock 2.8 mm/s.',
      sensor_anomalies: ['Motorstrom: 5.4A (+68%)', 'Temperatur: 48.2°C', 'Vibration: 2.85 mm/s'],
      detected_at: '2026-09-25 13:42:00',
      scheduled_for: '2026-09-25 15:30:00',
      estimated_downtime_minutes: 45,
      assigned_depot: 'Instandhaltungswerk Frankfurt-Griesheim',
      status: 'OFFEN'
    },
    {
      order_id: 'wo-102',
      code: 'IA-2026-0882',
      component_type: 'GLEISBETT',
      component_id: 'blk-81',
      component_name: 'Schotteroberbau & Spannbetonschwellen (B-081)',
      location: 'Strecke Augsburg - München km 42.8',
      priority: 'WARTUNG_PLANEN',
      anomaly_description: 'Ultraschall-Schienenprüfwagen meldet Riffeln mit Tiefe 0.4mm an Schienenkopf Außenschiene.',
      sensor_anomalies: ['Riffeltiefe: 0.42 mm', 'Achslastdynamik: +18%'],
      detected_at: '2026-09-25 11:20:00',
      scheduled_for: '2026-09-26 01:00:00',
      estimated_downtime_minutes: 180,
      assigned_depot: 'Schweres Instandhaltungsteam Süd (München)',
      status: 'IN_BEARBEITUNG'
    },
    {
      order_id: 'wo-103',
      code: 'IA-2026-0883',
      component_type: 'ACHSLAGER',
      component_id: 'tr-1',
      component_name: 'Achslager Drehgestell 1 Wagen 1 (ICE 742)',
      location: 'München Werk Rbf',
      priority: 'BEOBACHTEN',
      anomaly_description: 'Heißläuferortungsanlage (HOA) meldet Temperaturanstieg auf 58°C bei V = 250 km/h (Referenz 44°C).',
      sensor_anomalies: ['HOA-Sensor T_axle: 58.4°C (+32%)', 'Frequenzspektrum: 1240 Hz Peak'],
      detected_at: '2026-09-25 12:15:00',
      scheduled_for: '2026-09-25 22:00:00',
      estimated_downtime_minutes: 60,
      assigned_depot: 'ICE-Werk Hamburg-Eidelstedt',
      status: 'OFFEN'
    }
  ];
}

export function createInitialPowerMetrics(): PowerGridMetrics {
  return {
    total_active_mw: 14.8,
    peak_mw: 22.4,
    daily_mwh: 168.4,
    regenerated_mwh: 38.6,
    regeneration_quota_pct: 22.9,
    grid_frequency_hz: 16.7,
    catenary_voltage_kv: 15.1,
    co2_savings_tons: 42.8,
    substations: [
      { id: 'sub-1', name: 'Unterwerk Lehrte (NBS Nord)', region: 'NORD', load_mw: 3.4, capacity_mw: 6.0, voltage_kv: 15.2, load_pct: 56, status: 'NORMAL' },
      { id: 'sub-2', name: 'Unterwerk Montabaur (SFS K-RM)', region: 'WEST', load_mw: 4.8, capacity_mw: 8.0, voltage_kv: 15.0, load_pct: 60, status: 'NORMAL' },
      { id: 'sub-3', name: 'Unterwerk Fulda (SFS H-WÜ)', region: 'MITTE', load_mw: 3.1, capacity_mw: 5.5, voltage_kv: 15.1, load_pct: 56, status: 'NORMAL' },
      { id: 'sub-4', name: 'Unterwerk Allersberg (NBS N-IN)', region: 'SUED', load_mw: 2.2, capacity_mw: 5.0, voltage_kv: 15.3, load_pct: 44, status: 'NORMAL' },
      { id: 'sub-5', name: 'Unterwerk Jüterbog (Anhalter Bahn)', region: 'OST', load_mw: 1.3, capacity_mw: 4.0, voltage_kv: 15.2, load_pct: 32, status: 'NORMAL' }
    ]
  };
}

export function createInitialAuditLogs(): AuditLogEntry[] {
  return [
    {
      id: 'log-1',
      timestamp: '14:24:00',
      event_type: 'SIMULATION_TICK',
      entity_type: 'SYSTEM',
      entity_id: 'sim-core',
      entity_name: 'BAHNWERK Rust Sim Engine',
      old_state: 'TICK_N',
      new_state: 'TICK_N+1',
      source: 'DeterministicKernel',
      details: '80 Züge disponiert, 150 Blockabschnitte überwacht, 40 Weichen verriegelt.',
      severity: 'INFO'
    },
    {
      id: 'log-2',
      timestamp: '14:21:40',
      event_type: 'TÜRSTÖRUNG',
      entity_type: 'ZUG',
      entity_id: 'tr-4',
      entity_name: 'ICE 518',
      old_state: 'NORMAL',
      new_state: 'TÜR_GESTÖRT',
      source: 'TCMS_Wagen_7',
      details: 'Lichtgitter-Einklemmschutz Tür 4 blockiert Fahrgastwechsel.',
      severity: 'WARNUNG'
    },
    {
      id: 'log-3',
      timestamp: '14:18:02',
      event_type: 'WEICHENSTÖRUNG',
      entity_type: 'WEICHE',
      entity_id: 'sw-17',
      entity_name: 'Weiche W-017',
      old_state: 'POSITIONED',
      new_state: 'FAULT',
      source: 'DSTW_Frankfurt',
      details: 'Endlagenprüferkreis W-017 unterbrochen. Fahrstraße F-0188 gesperrt.',
      severity: 'KRITISCH'
    },
    {
      id: 'log-4',
      timestamp: '14:12:30',
      event_type: 'FAHRSTRASSE_GESTELLT',
      entity_type: 'FAHRSTRASSE',
      entity_id: 'rt-1',
      entity_name: 'F-0187 (München -> Augsburg)',
      old_state: 'ANGEFORDERT',
      new_state: 'EINGESTELLT_GESICHERT',
      source: 'DSTW_Muenchen',
      details: 'Startsignal S-042 auf Fahrt frei. Weichen W-022, W-023 in Linkslage verschlossen.',
      severity: 'INFO'
    },
    {
      id: 'log-5',
      timestamp: '14:05:12',
      event_type: 'STRECKENSPERRUNG',
      entity_type: 'BLOCK',
      entity_id: 'blk-81',
      entity_name: 'Block B-081',
      old_state: 'FREI',
      new_state: 'GESPERRT',
      source: 'Gleismesssensorik',
      details: 'Gleislageabweichung > 4.5mm detektiert. R-Disruption Optimizer aktiv.',
      severity: 'WARNUNG'
    }
  ];
}

export function createInitialWhatIfScenarios(): WhatIfScenario[] {
  return [
    {
      id: 'sc-base',
      name: 'Ist-Zustand (Baseline)',
      description: 'Aktueller Echtzeit-Betrieb mit bestehenden Störungen W-017 und B-081.',
      created_at: '14:24:00',
      applied_disruptions: ['Weichenstörung W-017', 'Gleisblock B-081 gesperrt'],
      dispatching_strategy: 'BASELINE',
      metrics: {
        punctuality_pct: 91.7,
        total_delay_min: 142,
        cancelled_trains: 0,
        energy_consumption_mwh: 14.8,
        passenger_comfort_score: 84
      }
    },
    {
      id: 'sc-ice-prio',
      name: 'Szenario A: ICE-Vorrang & Überholungen',
      description: 'Streng priorisierter Fernverkehr. Regionalzüge warten auf Nebengleisen.',
      created_at: '14:24:10',
      applied_disruptions: ['Weichenstörung W-017', 'Gleisblock B-081 gesperrt'],
      dispatching_strategy: 'ICE_VORRANG',
      metrics: {
        punctuality_pct: 95.2,
        total_delay_min: 88,
        cancelled_trains: 0,
        energy_consumption_mwh: 15.2,
        passenger_comfort_score: 91
      }
    },
    {
      id: 'sc-puffer',
      name: 'Szenario B: Taktknoten- & Anschlusssicherung',
      description: 'Pufferzeiten dynamisch dehnen, Umsteigeanschlüsse in Frankfurt & Köln halten.',
      created_at: '14:24:20',
      applied_disruptions: ['Weichenstörung W-017', 'Gleisblock B-081 gesperrt'],
      dispatching_strategy: 'PUFFER_OPTIMIERUNG',
      metrics: {
        punctuality_pct: 88.4,
        total_delay_min: 165,
        cancelled_trains: 0,
        energy_consumption_mwh: 14.1,
        passenger_comfort_score: 96
      }
    },
    {
      id: 'sc-eco',
      name: 'Szenario C: Energie- & Rekuperationsoptimierung',
      description: 'ATO-Coasting und versetzte Beschleunigungsphasen zur Vermeidung von Lastspitzen.',
      created_at: '14:24:30',
      applied_disruptions: ['Weichenstörung W-017', 'Gleisblock B-081 gesperrt'],
      dispatching_strategy: 'ENERGIE_MIN',
      metrics: {
        punctuality_pct: 93.1,
        total_delay_min: 110,
        cancelled_trains: 0,
        energy_consumption_mwh: 11.9,
        passenger_comfort_score: 89
      }
    }
  ];
}
