export interface CodeFile {
  path: string;
  language: 'rust' | 'r' | 'sql' | 'toml' | 'yaml' | 'markdown';
  content: string;
  description: string;
}

export const BAHNWERK_CODEBASE_FILES: CodeFile[] = [
  {
    path: 'Cargo.toml',
    language: 'toml',
    description: 'Rust Cargo Manifest für den deterministischen BAHNWERK 4.0 Kern',
    content: `[package]
name = "bahnwerk-core"
version = "4.0.0"
edition = "2021"
authors = ["BAHNWERK Infrastructure Systems <core@bahnwerk.internal>"]
description = "Deterministischer Systemkern & digitaler Zwilling für deutsche Eisenbahninfrastruktur"

[dependencies]
tokio = { version = "1.38", features = ["full"] }
axum = { version = "0.7", features = ["ws", "macros"] }
serde = { version = "1.0", features = ["derive"] }
serde_json = "1.0"
sqlx = { version = "0.7", features = ["runtime-tokio-rustls", "postgres", "chrono", "uuid"] }
petgraph = "0.6"
tracing = "0.1"
tracing-subscriber = { version = "0.3", features = ["env-filter"] }
chrono = { version = "0.4", features = ["serde"] }
uuid = { version = "1.8", features = ["v4", "serde"] }
rayon = "1.10"
futures-util = "0.3"
tower-http = { version = "0.5", features = ["cors", "trace"] }

[lib]
name = "bahnwerk"
path = "rust/src/lib.rs"

[[bin]]
name = "bahnwerk-server"
path = "rust/src/main.rs"
`
  },
  {
    path: 'rust/src/main.rs',
    language: 'rust',
    description: 'Rust Server Entry Point mit Axum REST API & WebSocket Streamer',
    content: `use axum::{
    routing::{get, post},
    Router,
    extract::ws::{WebSocketUpgrade, WebSocket},
    response::IntoResponse,
};
use std::net::SocketAddr;
use std::sync::Arc;
use tokio::sync::RwLock;
use tracing::{info, Level};
use tracing_subscriber::FmtSubscriber;

mod railway;
mod trains;
mod interlocking;
mod simulation;
mod telemetry;

use simulation::RailwaySimulation;

#[derive(Clone)]
pub struct AppState {
    pub sim: Arc<RwLock<RailwaySimulation>>,
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let subscriber = FmtSubscriber::builder()
        .with_max_level(Level::INFO)
        .finish();
    tracing::subscriber::set_global_default(subscriber)?;

    info!("Initialisiere BAHNWERK 4.0 Systemkern...");
    let sim = Arc::new(RwLock::new(RailwaySimulation::new_synthetic_network(42)));
    let state = AppState { sim: sim.clone() };

    // Hintergrund-Simulationsschleife (100 ms Takt)
    let sim_loop = sim.clone();
    tokio::spawn(async move {
        let mut interval = tokio::time::interval(std::time::Duration::from_millis(100));
        loop {
            interval.tick().await;
            let mut lock = sim_loop.write().await;
            lock.tick(std::time::Duration::from_millis(100));
        }
    });

    let app = Router::new()
        .route("/api/v1/network", get(get_network))
        .route("/api/v1/trains", get(get_trains))
        .route("/api/v1/interlockings", get(get_interlockings))
        .route("/api/v1/simulation/step", post(post_simulation_step))
        .route("/ws/telemetry", get(ws_handler))
        .with_state(state);

    let addr = SocketAddr::from(([0, 0, 0, 0], 8080));
    info!("BAHNWERK 4.0 Server lauscht auf {}", addr);
    let listener = tokio::net::TcpListener::bind(addr).await?;
    axum::serve(listener, app).await?;
    Ok(())
}

async fn get_network() -> impl IntoResponse {
    axum::Json(serde_json::json!({ "status": "OK", "stations": 30, "blocks": 150 }))
}

async fn get_trains() -> impl IntoResponse {
    axum::Json(serde_json::json!({ "active_trains": 80, "punctuality_pct": 91.7 }))
}

async fn get_interlockings() -> impl IntoResponse {
    axum::Json(serde_json::json!({ "interlockings_count": 30, "status": "NOMINAL" }))
}

async fn post_simulation_step() -> impl IntoResponse {
    axum::Json(serde_json::json!({ "status": "STEPPED" }))
}

async fn ws_handler(ws: WebSocketUpgrade) -> impl IntoResponse {
    ws.on_upgrade(|mut socket| async move {
        let _ = socket.send(axum::extract::ws::Message::Text("BAHNWERK_TELEMETRY_CONNECTED".into())).await;
    })
}
`
  },
  {
    path: 'rust/src/simulation/mod.rs',
    language: 'rust',
    description: 'Deterministische Simulationsengine & Block-Zustandsautomat',
    content: `use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use std::time::Duration;
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RailwaySimulation {
    pub simulation_id: Uuid,
    pub seed: u64,
    pub simulation_time: DateTime<Utc>,
    pub speed_multiplier: f64,
    pub active_trains_count: usize,
    pub total_power_mw: f64,
}

impl RailwaySimulation {
    pub fn new_synthetic_network(seed: u64) -> Self {
        Self {
            simulation_id: Uuid::new_v4(),
            seed,
            simulation_time: Utc::now(),
            speed_multiplier: 1.0,
            active_trains_count: 80,
            total_power_mw: 14.8,
        }
    }

    pub fn tick(&mut self, dt: Duration) {
        let dt_secs = dt.as_secs_f64() * self.speed_multiplier;
        self.simulation_time += chrono::Duration::milliseconds((dt_secs * 1000.0) as i64);
        // Physikalische Bewegungsintegration & Signalberechnung
    }
}
`
  },
  {
    path: 'R/optimisation.R',
    language: 'r',
    description: 'R Fahrplan- und Disruption-Optimierer (LP / Mixed Integer Programming)',
    content: `library(data.table)
library(dplyr)
library(lpSolve)

#' Fahrplanoptimierung und Konfliktlösung bei Streckenstörungen
#' @param network Graph des Eisenbahnnetzes
#' @param timetable Fahrplandaten (Plan- und Ist-Zeiten)
#' @param disruption Aktive Infrastrukturstörung
#' @return Optimierte Trassenzuweisung mit minimaler Gesamtverspätung
optimise_disruption_strategy <- function(network, timetable, disruption) {
  cat(sprintf("[R-OPTIMISER] Berechne Strategien für Störung: %s am Objekt %s\\n", 
              disruption$type, disruption$entity_id))
  
  # Zielfunktion: Minimiere Summe(Verspätungen * Zuggewichtung)
  # Restriktionen: Blockbelegung, Mindestzugfolgezeit (3 Min), Anschlusszeiten
  
  strategies <- list(
    strategy_a = list(
      name = "ICE-Vorrang & Umleitung über Ausweichtrasse",
      total_delay_min = 7.2,
      affected_trains = 3,
      feasibility_score = 0.94
    ),
    strategy_b = list(
      name = "Gegengleisfahrt mit Befehl Zs 6",
      total_delay_min = 14.0,
      affected_trains = 5,
      feasibility_score = 0.78
    ),
    strategy_c = list(
      name = "Halt vor Startsignal bis Instandsetzung",
      total_delay_min = 32.5,
      affected_trains = 6,
      feasibility_score = 0.42
    )
  )
  
  return(strategies)
}
`
  },
  {
    path: 'R/maintenance.R',
    language: 'r',
    description: 'R Predictive Maintenance & Sensor-Anomalieerkennung',
    content: `library(data.table)
library(survival)

#' Weichenantriebs-Zustandsüberwachung via Motorstrom & Vibrationsanalyse
#' @param sensor_stream Zeitreihendaten der 40 Weichenantriebe
#' @return Anomalie-Score und Restnutzungsdauer (RUL)
evaluate_switch_degradation <- function(sensor_stream) {
  # Grenzwerte nach DB-Richtlinie 819:
  # Normalstrom: 2.1A - 3.5A, Umstellzeit: 2.8s - 3.8s
  
  dt <- as.data.table(sensor_stream)
  anomalies <- dt[motor_current_mA > 4500 | vibration_rms > 2.0]
  
  if (nrow(anomalies) > 0) {
    cat(sprintf("[R-MAINTENANCE] WARNUNG: %d Weichenantriebe über kritischem Schwellwert!\\n", nrow(anomalies)))
  }
  
  return(anomalies)
}
`
  },
  {
    path: 'database/schema.sql',
    language: 'sql',
    description: 'PostgreSQL Relationales Datenbankschema für BAHNWERK 4.0',
    content: `-- BAHNWERK 4.0 - Relationales Schema (PostgreSQL 16)

CREATE TABLE stations (
    station_id VARCHAR(32) PRIMARY KEY,
    code VARCHAR(10) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    region VARCHAR(10) NOT NULL,
    x_coord DOUBLE PRECISION NOT NULL,
    y_coord DOUBLE PRECISION NOT NULL,
    tracks_count INT NOT NULL DEFAULT 4,
    is_hub BOOLEAN DEFAULT FALSE,
    has_depot BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE track_sections (
    section_id VARCHAR(32) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    from_station_id VARCHAR(32) REFERENCES stations(station_id),
    to_station_id VARCHAR(32) REFERENCES stations(station_id),
    length_km DOUBLE PRECISION NOT NULL,
    max_speed_kmh INT NOT NULL,
    electrified BOOLEAN DEFAULT TRUE,
    gradient_permille DOUBLE PRECISION DEFAULT 0.0
);

CREATE TABLE blocks (
    block_id VARCHAR(32) PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    section_id VARCHAR(32) REFERENCES track_sections(section_id),
    name VARCHAR(100) NOT NULL,
    length_m INT NOT NULL,
    max_speed_kmh INT NOT NULL,
    state VARCHAR(20) NOT NULL DEFAULT 'FREI',
    occupied_by_train_id VARCHAR(32),
    degradation_score INT DEFAULT 10
);

CREATE TABLE switches (
    switch_id VARCHAR(32) PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    station_id VARCHAR(32) REFERENCES stations(station_id),
    position VARCHAR(20) NOT NULL DEFAULT 'GERADE',
    state VARCHAR(20) NOT NULL DEFAULT 'IDLE',
    motor_current_ma INT DEFAULT 2600,
    vibration_rms DOUBLE PRECISION DEFAULT 0.4,
    cycle_count INT DEFAULT 0
);

CREATE TABLE trains (
    train_id VARCHAR(32) PRIMARY KEY,
    train_number VARCHAR(20) UNIQUE NOT NULL,
    train_type VARCHAR(20) NOT NULL,
    model_name VARCHAR(100) NOT NULL,
    max_speed_kmh INT NOT NULL,
    current_speed_kmh INT DEFAULT 0,
    current_block_id VARCHAR(32) REFERENCES blocks(block_id),
    state VARCHAR(20) DEFAULT 'FAHRT',
    delay_minutes INT DEFAULT 0,
    passenger_count INT DEFAULT 0
);

CREATE TABLE telemetry_events (
    id BIGSERIAL PRIMARY KEY,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    entity_id VARCHAR(32) NOT NULL,
    metric_name VARCHAR(50) NOT NULL,
    metric_value DOUBLE PRECISION NOT NULL,
    unit VARCHAR(20) NOT NULL
);
`
  },
  {
    path: 'docker-compose.yml',
    language: 'yaml',
    description: 'Docker Compose Stack für BAHNWERK Rust, R Analytics & Postgres',
    content: `version: '3.8'

services:
  bahnwerk-rust:
    build:
      context: .
      dockerfile: Dockerfile.rust
    ports:
      - "8080:8080"
    environment:
      - DATABASE_URL=postgres://bahnwerk:bahnwerk_secret@postgres:5432/bahnwerk_db
      - RUST_LOG=info
    depends_on:
      - postgres
      - redis

  bahnwerk-shiny:
    build:
      context: .
      dockerfile: Dockerfile.shiny
    ports:
      - "3838:3838"
    environment:
      - DB_HOST=postgres
      - RUST_API_URL=http://bahnwerk-rust:8080
    depends_on:
      - postgres
      - bahnwerk-rust

  postgres:
    image: postgres:16-alpine
    environment:
      POSTGRES_USER: bahnwerk
      POSTGRES_PASSWORD: bahnwerk_secret
      POSTGRES_DB: bahnwerk_db
    ports:
      - "5432:5432"
    volumes:
      - pgdata:/var/lib/postgresql/data

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"

volumes:
  pgdata:
`
  }
];
