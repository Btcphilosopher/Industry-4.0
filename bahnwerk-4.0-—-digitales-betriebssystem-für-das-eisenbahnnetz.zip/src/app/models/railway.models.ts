export type RegionCode = 'NORD' | 'WEST' | 'MITTE' | 'SUED' | 'OST';

export type BlockState = 'FREI' | 'BELEGT' | 'RESERVIERT' | 'GESPERRT' | 'STÖRUNG';

export type SwitchPosition = 'GERADE' | 'ABZWEIG';

export type SwitchState = 'IDLE' | 'REQUESTED' | 'MOVING' | 'POSITIONED' | 'LOCKED' | 'FAULT';

export type SignalType = 'HAUPTSIGNAL' | 'VORSIGNAL' | 'SPERRSIGNAL' | 'ETCS_MARKER';

export type SignalAspect = 'HALT' | 'FAHRT' | 'WARNUNG' | 'LANGSAMFAHRT_40' | 'LANGSAMFAHRT_60' | 'DUNKEL';

export type RouteState = 'INAKTIV' | 'ANGEFORDERT' | 'EINGESTELLT_GESICHERT' | 'BEFAHREN' | 'AUFGELÖST' | 'KONFLIKT';

export type TrainType = 'ICE' | 'IC' | 'RE' | 'RB' | 'S-BAHN' | 'GÜTERZUG';

export type TrainState =
  | 'ABGESTELLT'
  | 'BEREIT'
  | 'FAHRT'
  | 'BAHNHOF'
  | 'HALT'
  | 'BESCHLEUNIGUNG'
  | 'BREMSEN'
  | 'VERSPÄTET'
  | 'GESTÖRT'
  | 'WARTUNG';

export type IncidentType =
  | 'WEICHENSTÖRUNG'
  | 'SIGNALSTÖRUNG'
  | 'STRECKENSPERRUNG'
  | 'ZUGAUSFALL'
  | 'LANGSAMFAHRSTELLE'
  | 'TÜRSTÖRUNG'
  | 'FAHRZEUGSTÖRUNG'
  | 'BAHNHOFSSPERRUNG'
  | 'OBERLEITUNGSSCHADEN';

export type IncidentSeverity = 'INFO' | 'WARNUNG' | 'KRITISCH' | 'NOTFALL';

export type MaintenancePriority = 'NORMAL' | 'BEOBACHTEN' | 'WARTUNG_PLANEN' | 'DRINGEND';

export interface Station {
  id: string;
  code: string;
  name: string;
  region: RegionCode;
  x: number; // 0-100 coordinate on schematic map
  y: number;
  tracks_count: number;
  platforms: Platform[];
  is_hub: boolean;
  has_depot: boolean;
  interlocking_id: string;
  passenger_flow: {
    boardings_per_hour: number;
    alightings_per_hour: number;
    transfers_per_hour: number;
    current_waiting_passengers: number;
    crowding_level: 'NORMAL' | 'ERHÖHT' | 'KRITISCH';
  };
}

export interface Platform {
  platform_id: string;
  track_number: number;
  length_m: number;
  capacity_passengers: number;
  current_train_id?: string;
  passenger_load_pct: number;
  access_state: 'FREI' | 'GESPERRT' | 'REINIGUNG';
}

export interface TrackSection {
  section_id: string;
  name: string;
  region: RegionCode;
  from_station_id: string;
  to_station_id: string;
  length_km: number;
  max_speed_kmh: number;
  electrified: boolean;
  gradient_permille: number; // Neigung in Promille
  curvature_radius_m: number;
  track_count: number;
  blocks: BlockSection[];
  maintenance_state: MaintenancePriority;
  corridor_name: string;
}

export interface BlockSection {
  block_id: string;
  code: string;
  section_id: string;
  name: string;
  from_node_id: string;
  to_node_id: string;
  length_m: number;
  max_speed_kmh: number;
  state: BlockState;
  occupied_by_train_id?: string;
  reserved_for_route_id?: string;
  interlocking_id: string;
  signals: string[]; // signal_ids
  degradation_score: number; // 0-100
  track_temperature_c: number;
  vibration_rms: number;
  // Schematic path coordinates for SVG
  x1: number;
  y1: number;
  x2: number;
  y2: number;
}

export interface Switch {
  switch_id: string;
  code: string;
  name: string;
  interlocking_id: string;
  station_id?: string;
  position: SwitchPosition;
  normal_position: SwitchPosition;
  reverse_position: SwitchPosition;
  state: SwitchState;
  locked: boolean;
  occupied: boolean;
  locked_by_route_id?: string;
  fault_reason?: string;
  motor_current_mA: number; // Norm: 2.1A - 3.5A, Fault: > 5.2A
  vibration_rms: number; // mm/s
  temperature_c: number;
  cycle_count: number;
  maintenance_state: MaintenancePriority;
  last_maintenance: string;
  x: number;
  y: number;
}

export interface Signal {
  signal_id: string;
  code: string;
  name: string;
  interlocking_id: string;
  block_id: string;
  type: SignalType;
  aspect: SignalAspect;
  target_speed_kmh: number;
  is_dark: boolean;
  fault: boolean;
  x: number;
  y: number;
}

export interface RouteSwitch {
  switch_id: string;
  required_position: SwitchPosition;
}

export interface Route {
  route_id: string;
  code: string; // e.g. "F-0187"
  name: string;
  interlocking_id: string;
  start_signal_id: string;
  end_signal_or_platform: string;
  switches: RouteSwitch[];
  blocks: string[]; // Block IDs in sequence
  state: RouteState;
  active_train_id?: string;
  priority: number;
}

export interface DigitalInterlocking {
  interlocking_id: string;
  code: string;
  name: string;
  region: RegionCode;
  station_ids: string[];
  block_ids: string[];
  switch_ids: string[];
  signal_ids: string[];
  routes: Route[];
  status: 'NORMAL' | 'WARNUNG' | 'GESTÖRT';
  mode: 'AUTOMATISCH' | 'DISPATCHER_MANUELL' | 'NOTBETRIEB';
  system_load_pct: number;
  uptime_hours: number;
  redundancy_active: boolean;
}

export interface MovementAuthority {
  train_id: string;
  target_position_m: number;
  permitted_speed_kmh: number;
  target_speed_kmh: number;
  validity_distance_m: number;
  release_speed_kmh: number;
  brake_curve_mode: 'NORMAL' | 'INDICATION' | 'PERMITTED' | 'WARNING' | 'INTERVENTION';
  distance_to_target_m: number;
  emergency_brake_distance_m: number;
  service_brake_distance_m: number;
}

export interface TrajectoryPoint {
  dist: number;
  target_v: number;
  actual_v: number;
}

export interface AtoState {
  enabled: boolean;
  mode: 'CRUISING' | 'ACCELERATING' | 'COASTING' | 'PRECISION_BRAKING' | 'STATION_DWELL';
  target_stop_accuracy_cm: number;
  dwell_time_remaining_s: number;
  energy_saving_mode: boolean;
  trajectory_points: TrajectoryPoint[];
}

export interface TrainScheduleStop {
  station_id: string;
  station_name: string;
  platform: string;
  planned_arrival: string;
  actual_arrival?: string;
  planned_departure: string;
  actual_departure?: string;
  dwell_minutes: number;
  status: 'BEENDET' | 'AKTUELL' | 'AUSSTEHEND' | 'ENTFALLEN';
  passenger_exchange: {
    in: number;
    out: number;
  };
}

export interface TrainTelemetry {
  pantograph_voltage_kv: number;
  catenary_current_a: number;
  motor_torque_pct: number;
  brake_cylinder_pressure_bar: number;
  main_reservoir_bar: number;
  axle_bearing_temp_c: number;
  wheel_vibration_mm_s: number;
  hvac_temp_c: number;
  battery_soc_pct: number;
  doors_status: 'GESCHLOSSEN' | 'FREIGEGEBEN' | 'OFFEN' | 'GESTÖRT';
  flange_lubrication_active: boolean;
}

export interface Train {
  train_id: string;
  train_number: string; // e.g. "ICE 742"
  line_name: string; // e.g. "Linie 25"
  train_type: TrainType;
  model_name: string; // e.g. "ICE 4 (Baureihe 412)"
  operator: string;
  origin_station_id: string;
  destination_station_id: string;
  length_m: number;
  mass_t: number;
  max_speed_kmh: number;
  current_speed_kmh: number;
  target_speed_kmh: number;
  acceleration_mps2: number;
  braking_rate_mps2: number;
  state: TrainState;
  current_block_id: string;
  current_route_id?: string;
  distance_in_block_m: number;
  progress_ratio: number; // 0..1 along overall journey
  x: number;
  y: number;
  direction_angle: number; // deg
  schedule: TrainScheduleStop[];
  current_stop_index: number;
  delay_minutes: number;
  active_conflict?: string;
  passenger_count: number;
  passenger_capacity: number;
  energy_active_mw: number;
  total_energy_kwh: number;
  regenerated_energy_kwh: number;
  etcs: MovementAuthority;
  ato: AtoState;
  telemetry: TrainTelemetry;
  route_history: string[];
}

export interface DisruptionStrategy {
  scenario_name: string;
  description: string;
  total_delay_min: number;
  affected_trains_count: number;
  passenger_impact: string;
  energy_impact_kwh: number;
  feasibility_score: number; // 0-100
  actions: string[];
  recommended?: boolean;
}

export interface Incident {
  incident_id: string;
  type: IncidentType;
  severity: IncidentSeverity;
  title: string;
  description: string;
  entity_type: 'WEICHE' | 'SIGNAL' | 'BLOCK' | 'ZUG' | 'BAHNHOF' | 'OBERLEITUNG' | 'STELLWERK';
  entity_id: string;
  entity_name: string;
  location_name: string;
  timestamp: string;
  resolved: boolean;
  affected_train_ids: string[];
  affected_route_ids: string[];
  avg_delay_addition_min: number;
  strategies: DisruptionStrategy[];
  selected_strategy_index?: number;
}

export interface MaintenanceWorkOrder {
  order_id: string;
  code: string;
  component_type: 'WEICHENANTRIEB' | 'GLEISBETT' | 'SIGNALGEBER' | 'ACHSLAGER' | 'OBERLEITUNG' | 'TRAFO';
  component_id: string;
  component_name: string;
  location: string;
  priority: MaintenancePriority;
  anomaly_description: string;
  sensor_anomalies: string[];
  detected_at: string;
  scheduled_for: string;
  estimated_downtime_minutes: number;
  assigned_depot: string;
  status: 'OFFEN' | 'IN_BEARBEITUNG' | 'ABGESCHLOSSEN';
}

export interface SubstationInfo {
  id: string;
  name: string;
  region: RegionCode;
  load_mw: number;
  capacity_mw: number;
  voltage_kv: number;
  load_pct: number;
  status: 'NORMAL' | 'HOCHLAST' | 'WARTUNG';
}

export interface PowerGridMetrics {
  total_active_mw: number;
  peak_mw: number;
  daily_mwh: number;
  regenerated_mwh: number;
  regeneration_quota_pct: number;
  grid_frequency_hz: number; // 16.7 Hz
  catenary_voltage_kv: number; // 15.0 kV
  co2_savings_tons: number;
  substations: SubstationInfo[];
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  event_type: string;
  entity_type: string;
  entity_id: string;
  entity_name: string;
  old_state: string;
  new_state: string;
  source: string;
  details: string;
  severity: IncidentSeverity;
}

export interface WhatIfScenario {
  id: string;
  name: string;
  description: string;
  created_at: string;
  applied_disruptions: string[];
  dispatching_strategy: 'BASELINE' | 'ICE_VORRANG' | 'PUFFER_OPTIMIERUNG' | 'KAPAZITAET_MAX' | 'ENERGIE_MIN';
  metrics: {
    punctuality_pct: number;
    total_delay_min: number;
    cancelled_trains: number;
    energy_consumption_mwh: number;
    passenger_comfort_score: number;
  };
}

export interface RailwayNetwork {
  stations: Station[];
  track_sections: TrackSection[];
  blocks: BlockSection[];
  switches: Switch[];
  signals: Signal[];
  interlockings: DigitalInterlocking[];
  routes: Route[];
}
