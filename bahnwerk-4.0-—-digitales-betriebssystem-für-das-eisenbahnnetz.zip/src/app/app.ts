import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent, ActiveTab } from './components/header/header';
import { OverviewView } from './components/views/overview/overview';
import { NetworkMapView } from './components/views/network-map/network-map';
import { TrainsInspectorView } from './components/views/trains-inspector/trains-inspector';
import { InterlockingView } from './components/views/interlocking/interlocking';
import { EtcsAtoView } from './components/views/etcs-ato/etcs-ato';
import { TimetableDispatchView } from './components/views/timetable-dispatch/timetable-dispatch';
import { DisruptionManagementView } from './components/views/disruption-management/disruption-management';
import { WhatIfSandboxView } from './components/views/what-if-sandbox/what-if-sandbox';
import { StationsView } from './components/views/stations/stations';
import { MaintenanceFleetView } from './components/views/maintenance-fleet/maintenance-fleet';
import { EnergyView } from './components/views/energy/energy';
import { RAnalyticsView } from './components/views/r-analytics/r-analytics';
import { AuditLogView } from './components/views/audit-log/audit-log';
import { ArchitectureExportView } from './components/views/architecture-export/architecture-export';
import { RailwaySimulationService } from './services/railway-simulation.service';

@Component({
  selector: 'app-root',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    HeaderComponent,
    OverviewView,
    NetworkMapView,
    TrainsInspectorView,
    InterlockingView,
    EtcsAtoView,
    TimetableDispatchView,
    DisruptionManagementView,
    WhatIfSandboxView,
    StationsView,
    MaintenanceFleetView,
    EnergyView,
    RAnalyticsView,
    AuditLogView,
    ArchitectureExportView
  ],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  readonly sim = inject(RailwaySimulationService);
  readonly currentTab = signal<ActiveTab>('uebersicht');

  onTabChanged(tab: ActiveTab): void {
    this.currentTab.set(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
}
