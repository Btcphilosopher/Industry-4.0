import { Injectable, signal, computed, inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import {
  RailwayNetwork,
  BlockSection,
  Switch,
  Signal,
  Route,
  Train,
  Incident,
  MaintenanceWorkOrder,
  PowerGridMetrics,
  AuditLogEntry,
  WhatIfScenario,
  BlockState,
  SignalAspect,
  SwitchPosition
} from '../models/railway.models';
import {
  createInitialRailwayNetwork,
  createInitialTrains,
  createInitialIncidents,
  createInitialWorkOrders,
  createInitialPowerMetrics,
  createInitialAuditLogs,
  createInitialWhatIfScenarios
} from '../data/railway-seed.data';

@Injectable({
  providedIn: 'root'
})
export class RailwaySimulationService {
  private readonly platformId = inject(PLATFORM_ID);
  readonly isBrowser = isPlatformBrowser(this.platformId);

  // Master Signals
  readonly isRunning = signal<boolean>(true);
  readonly speedMultiplier = signal<number>(1);
  readonly simulationTime = signal<Date>(new Date(2026, 8, 25, 14, 24, 0));
  readonly seed = signal<number>(42);
  readonly activeScenario = signal<string>('normal');

  // Network Elements
  readonly network = signal<RailwayNetwork>(createInitialRailwayNetwork());
  readonly trains = signal<Train[]>([]);
  readonly incidents = signal<Incident[]>(createInitialIncidents());
  readonly workOrders = signal<MaintenanceWorkOrder[]>(createInitialWorkOrders());
  readonly powerMetrics = signal<PowerGridMetrics>(createInitialPowerMetrics());
  readonly auditLogs = signal<AuditLogEntry[]>(createInitialAuditLogs());
  readonly whatIfScenarios = signal<WhatIfScenario[]>(createInitialWhatIfScenarios());

  // Selected Entities for Inspector views
  readonly selectedTrainId = signal<string>('tr-1');
  readonly selectedStationId = signal<string>('st-f');
  readonly selectedInterlockingId = signal<string>('dstw-f');
  readonly selectedBlockId = signal<string>('blk-81');
  readonly selectedSwitchId = signal<string>('sw-17');
  readonly selectedIncidentId = signal<string>('inc-01');

  // Computed properties
  readonly activeTrainsCount = computed(() => this.trains().filter((t) => t.state !== 'ABGESTELLT').length);
  
  readonly punctualityPct = computed(() => {
    const active = this.trains();
    if (!active.length) return 91.7;
    const onTime = active.filter((t) => t.delay_minutes < 6).length;
    return +((onTime / active.length) * 100).toFixed(1);
  });

  readonly totalDelayMinutes = computed(() => {
    return this.trains().reduce((sum, t) => sum + t.delay_minutes, 0);
  });

  readonly occupiedBlocksCount = computed(() => {
    return this.network().blocks.filter((b) => b.state === 'BELEGT').length;
  });

  readonly selectedTrain = computed(() => {
    const id = this.selectedTrainId();
    return this.trains().find((t) => t.train_id === id) || this.trains()[0] || null;
  });

  readonly selectedStation = computed(() => {
    const id = this.selectedStationId();
    return this.network().stations.find((s) => s.id === id) || this.network().stations[0] || null;
  });

  readonly selectedInterlocking = computed(() => {
    const id = this.selectedInterlockingId();
    return this.network().interlockings.find((i) => i.interlocking_id === id) || this.network().interlockings[0] || null;
  });

  readonly selectedBlock = computed(() => {
    const id = this.selectedBlockId();
    return this.network().blocks.find((b) => b.block_id === id) || this.network().blocks[0] || null;
  });

  readonly selectedSwitch = computed(() => {
    const id = this.selectedSwitchId();
    return this.network().switches.find((s) => s.switch_id === id) || this.network().switches[0] || null;
  });

  readonly selectedIncident = computed(() => {
    const id = this.selectedIncidentId();
    return this.incidents().find((inc) => inc.incident_id === id) || this.incidents()[0] || null;
  });

  private intervalId: ReturnType<typeof setInterval> | null = null;
  private lastTickTimestamp = 0;

  constructor() {
    const initialTrains = createInitialTrains(this.network());
    this.trains.set(initialTrains);

    if (this.isBrowser) {
      this.lastTickTimestamp = performance.now();
      this.startLoop();
    }
  }

  startLoop(): void {
    if (!this.isBrowser || this.intervalId !== null) return;
    this.isRunning.set(true);
    this.lastTickTimestamp = performance.now();

    this.intervalId = setInterval(() => {
      const now = performance.now();
      const dtMs = now - this.lastTickTimestamp;
      this.lastTickTimestamp = now;

      if (this.isRunning()) {
        const effectiveDt = (dtMs / 1000) * this.speedMultiplier();
        this.tick(effectiveDt);
      }
    }, 100);
  }

  pause(): void {
    this.isRunning.set(false);
  }

  resume(): void {
    this.isRunning.set(true);
    if (this.isBrowser) {
      this.lastTickTimestamp = performance.now();
    }
  }

  step(): void {
    this.tick(1.0);
  }

  reset(): void {
    const net = createInitialRailwayNetwork();
    this.network.set(net);
    this.trains.set(createInitialTrains(net));
    this.incidents.set(createInitialIncidents());
    this.workOrders.set(createInitialWorkOrders());
    this.powerMetrics.set(createInitialPowerMetrics());
    this.auditLogs.set(createInitialAuditLogs());
    this.simulationTime.set(new Date(2026, 8, 25, 14, 24, 0));
    this.activeScenario.set('normal');
    this.addAuditLog('SIMULATION_RESET', 'SYSTEM', 'sim-core', 'Simulation', 'MODIFIED', 'RESET', 'Kernel', 'Simulation auf Ausgangszustand zurückgesetzt.', 'INFO');
  }

  setSpeedMultiplier(speed: number): void {
    this.speedMultiplier.set(speed);
  }

  selectTrain(id: string): void {
    this.selectedTrainId.set(id);
  }

  selectStation(id: string): void {
    this.selectedStationId.set(id);
  }

  selectInterlocking(id: string): void {
    this.selectedInterlockingId.set(id);
  }

  selectBlock(id: string): void {
    this.selectedBlockId.set(id);
  }

  selectSwitch(id: string): void {
    this.selectedSwitchId.set(id);
  }

  selectIncident(id: string): void {
    this.selectedIncidentId.set(id);
  }

  // --- Core Deterministic Simulation Loop ---
  private tick(dt: number): void {
    // 1. Advance simulation clock
    const currentSim = new Date(this.simulationTime().getTime() + dt * 1000);
    this.simulationTime.set(currentSim);

    const net = this.network();
    const blocksMap = new Map<string, BlockSection>();
    net.blocks.forEach((b) => blocksMap.set(b.block_id, { ...b }));

    const switchesMap = new Map<string, Switch>();
    net.switches.forEach((s) => switchesMap.set(s.switch_id, { ...s }));

    const signalsMap = new Map<string, Signal>();
    net.signals.forEach((s) => signalsMap.set(s.signal_id, { ...s }));

    // Reset block occupancies before recalculating from trains
    blocksMap.forEach((blk) => {
      if (blk.state === 'BELEGT') {
        blk.state = 'FREI';
        blk.occupied_by_train_id = undefined;
      }
    });

    let totalActiveMw = 0;
    let regeneratedMw = 0;

    // 2. Update Train Physics & Movement Twin
    const updatedTrains = this.trains().map((train) => {
      const t = { ...train, telemetry: { ...train.telemetry }, etcs: { ...train.etcs }, ato: { ...train.ato } };
      const block = blocksMap.get(t.current_block_id);

      if (!block) return t;

      // Determine ceiling and target speed from block, signals and train physics
      let ceilingSpeed = Math.min(t.max_speed_kmh, block.max_speed_kmh);

      // Check if block is obstructed / disrupted
      if (block.state === 'GESPERRT' || block.state === 'STÖRUNG') {
        ceilingSpeed = 0;
      }

      // Check signal aspect for current block
      const sigId = block.signals[0];
      const sig = sigId ? signalsMap.get(sigId) : null;
      if (sig) {
        if (sig.aspect === 'HALT') {
          ceilingSpeed = 0;
        } else if (sig.aspect === 'WARNUNG' || sig.aspect === 'LANGSAMFAHRT_40') {
          ceilingSpeed = Math.min(ceilingSpeed, 40);
        } else if (sig.aspect === 'LANGSAMFAHRT_60') {
          ceilingSpeed = Math.min(ceilingSpeed, 60);
        }
      }

      // Station dwell logic
      if (t.state === 'BAHNHOF') {
        t.current_speed_kmh = 0;
        t.ato.dwell_time_remaining_s = Math.max(0, (t.ato.dwell_time_remaining_s || 30) - dt);
        t.telemetry.doors_status = 'OFFEN';

        if (t.ato.dwell_time_remaining_s <= 0) {
          t.state = 'BESCHLEUNIGUNG';
          t.telemetry.doors_status = 'GESCHLOSSEN';
          t.current_stop_index = (t.current_stop_index + 1) % t.schedule.length;
        }
      } else {
        // Speed adjustment
        const targetV = ceilingSpeed;
        const currentV_mps = (t.current_speed_kmh * 1000) / 3600;
        const targetV_mps = (targetV * 1000) / 3600;

        if (currentV_mps < targetV_mps) {
          // Accelerate
          const newV_mps = Math.min(targetV_mps, currentV_mps + t.acceleration_mps2 * dt);
          t.current_speed_kmh = Math.round((newV_mps * 3600) / 1000);
          t.state = 'BESCHLEUNIGUNG';
          t.telemetry.brake_cylinder_pressure_bar = 0;
          t.energy_active_mw = +(1.5 + (t.current_speed_kmh / t.max_speed_kmh) * 2.8).toFixed(2);
        } else if (currentV_mps > targetV_mps) {
          // Decelerate (Braking)
          const newV_mps = Math.max(targetV_mps, currentV_mps - t.braking_rate_mps2 * dt);
          t.current_speed_kmh = Math.round((newV_mps * 3600) / 1000);
          t.state = t.current_speed_kmh === 0 ? 'HALT' : 'BREMSEN';
          t.telemetry.brake_cylinder_pressure_bar = +(2.4 + Math.random() * 0.4).toFixed(1);

          // Regenerative braking active
          const regen = +(0.8 + (t.current_speed_kmh / t.max_speed_kmh) * 1.6).toFixed(2);
          regeneratedMw += regen;
          t.regenerated_energy_kwh += Math.round((regen * 1000 * dt) / 3600);
          t.energy_active_mw = 0.2; // Auxiliary only
        } else {
          t.state = t.current_speed_kmh === 0 ? 'HALT' : 'FAHRT';
          t.energy_active_mw = +(0.9 + (t.current_speed_kmh / t.max_speed_kmh) * 1.8).toFixed(2);
          t.telemetry.brake_cylinder_pressure_bar = 0;
        }

        // Advance position along block
        const distMoved_m = ((t.current_speed_kmh * 1000) / 3600) * dt;
        t.distance_in_block_m += distMoved_m;

        if (t.distance_in_block_m >= block.length_m) {
          // Transition to next block in section or corridor
          t.distance_in_block_m = 0;
          const currentBlkIdx = net.blocks.findIndex((b) => b.block_id === t.current_block_id);
          const nextBlk = net.blocks[(currentBlkIdx + 1) % net.blocks.length];
          t.current_block_id = nextBlk.block_id;

          if (t.route_history.length > 20) t.route_history.shift();
          t.route_history.push(nextBlk.block_id);

          // If reached a station node, enter BAHNHOF state for dwell
          if (currentBlkIdx % 5 === 0) {
            t.state = 'BAHNHOF';
            t.ato.dwell_time_remaining_s = 20;
          }
        }

        // Interpolate (x, y) coordinates for visualization
        const activeBlock = blocksMap.get(t.current_block_id) || block;
        const ratio = Math.min(1, Math.max(0, t.distance_in_block_m / activeBlock.length_m));
        t.progress_ratio = +ratio.toFixed(3);
        t.x = +(activeBlock.x1 + (activeBlock.x2 - activeBlock.x1) * ratio).toFixed(2);
        t.y = +(activeBlock.y1 + (activeBlock.y2 - activeBlock.y1) * ratio).toFixed(2);
        t.direction_angle = Math.round(Math.atan2(activeBlock.y2 - activeBlock.y1, activeBlock.x2 - activeBlock.x1) * (180 / Math.PI));
      }

      // Mark current block as occupied
      const occBlock = blocksMap.get(t.current_block_id);
      if (occBlock && occBlock.state !== 'GESPERRT' && occBlock.state !== 'STÖRUNG') {
        occBlock.state = 'BELEGT';
        occBlock.occupied_by_train_id = t.train_id;
      }

      // ETCS Level 2 Model Update
      const v_mps = (t.current_speed_kmh * 1000) / 3600;
      const b_serv = t.braking_rate_mps2;
      const b_emerg = 1.35;
      t.etcs.distance_to_target_m = Math.max(10, block.length_m - t.distance_in_block_m);
      t.etcs.service_brake_distance_m = Math.round((v_mps * v_mps) / (2 * b_serv));
      t.etcs.emergency_brake_distance_m = Math.round((v_mps * v_mps) / (2 * b_emerg));
      t.etcs.permitted_speed_kmh = ceilingSpeed;
      t.etcs.target_speed_kmh = ceilingSpeed;

      if (t.etcs.distance_to_target_m <= t.etcs.emergency_brake_distance_m + 50 && ceilingSpeed === 0 && t.current_speed_kmh > 0) {
        t.etcs.brake_curve_mode = 'INTERVENTION';
      } else if (t.etcs.distance_to_target_m <= t.etcs.service_brake_distance_m + 100 && ceilingSpeed === 0) {
        t.etcs.brake_curve_mode = 'WARNING';
      } else {
        t.etcs.brake_curve_mode = 'NORMAL';
      }

      // ATO Dynamic updates
      t.ato.mode = t.state === 'BAHNHOF' ? 'STATION_DWELL' : t.state === 'BREMSEN' ? 'PRECISION_BRAKING' : t.state === 'BESCHLEUNIGUNG' ? 'ACCELERATING' : 'CRUISING';

      // Telemetry dynamics
      t.telemetry.pantograph_voltage_kv = +(14.8 + Math.sin(Date.now() / 3000) * 0.3).toFixed(2);
      t.telemetry.catenary_current_a = Math.round(80 + (t.current_speed_kmh / t.max_speed_kmh) * 280);
      t.telemetry.motor_torque_pct = t.state === 'BESCHLEUNIGUNG' ? 78 : t.state === 'FAHRT' ? 45 : 0;
      t.telemetry.axle_bearing_temp_c = Math.round(40 + (t.current_speed_kmh / t.max_speed_kmh) * 16 + Math.random() * 2);
      t.telemetry.wheel_vibration_mm_s = +(0.3 + (t.current_speed_kmh / t.max_speed_kmh) * 0.45).toFixed(2);

      totalActiveMw += t.energy_active_mw;

      return t;
    });

    // 3. Update Signal Aspects based on Block Occupancy (Blocklogik)
    net.blocks.forEach((blk, idx) => {
      const modifiedBlk = blocksMap.get(blk.block_id);
      if (!modifiedBlk) return;

      const sigId = modifiedBlk.signals[0];
      const sig = sigId ? signalsMap.get(sigId) : null;
      if (sig) {
        if (modifiedBlk.state === 'GESPERRT' || modifiedBlk.state === 'STÖRUNG') {
          sig.aspect = 'HALT';
        } else if (modifiedBlk.state === 'BELEGT') {
          sig.aspect = 'HALT';
        } else {
          // Check block ahead
          const nextBlk = net.blocks[(idx + 1) % net.blocks.length];
          const nextModBlk = blocksMap.get(nextBlk.block_id);
          if (nextModBlk && (nextModBlk.state === 'BELEGT' || nextModBlk.state === 'GESPERRT')) {
            sig.aspect = 'WARNUNG';
          } else {
            sig.aspect = 'FAHRT';
          }
        }
      }
    });

    // 4. Update Power Grid Metrics
    const currentPower = this.powerMetrics();
    const newDaily = +(currentPower.daily_mwh + (totalActiveMw * dt) / 3600).toFixed(2);
    const newRegen = +(currentPower.regenerated_mwh + (regeneratedMw * dt) / 3600).toFixed(2);
    const updatedPower: PowerGridMetrics = {
      ...currentPower,
      total_active_mw: +totalActiveMw.toFixed(2),
      daily_mwh: newDaily,
      regenerated_mwh: newRegen,
      regeneration_quota_pct: +((newRegen / Math.max(1, newDaily)) * 100).toFixed(1),
      peak_mw: Math.max(currentPower.peak_mw, totalActiveMw),
      grid_frequency_hz: +(16.7 + (Math.random() - 0.5) * 0.04).toFixed(2),
      catenary_voltage_kv: +(15.0 + (Math.random() - 0.5) * 0.2).toFixed(2),
      substations: currentPower.substations.map((sub, sIdx) => ({
        ...sub,
        load_mw: +(totalActiveMw * (0.15 + sIdx * 0.05)).toFixed(2),
        load_pct: Math.min(100, Math.round(((totalActiveMw * (0.15 + sIdx * 0.05)) / sub.capacity_mw) * 100))
      }))
    };

    // Update Master State
    this.network.set({
      ...net,
      blocks: Array.from(blocksMap.values()),
      switches: Array.from(switchesMap.values()),
      signals: Array.from(signalsMap.values())
    });

    this.trains.set(updatedTrains);
    this.powerMetrics.set(updatedPower);
  }

  // --- Disruption Management & Scenarios ---
  applyDemoScenario(scenarioNumber: number): void {
    this.reset();
    switch (scenarioNumber) {
      case 1: {
        this.activeScenario.set('normal');
        this.incidents.set([]);
        this.addAuditLog('SZENARIO_GELADEN', 'SZENARIO', 'sc-1', 'Demo-Szenario 1', 'INIT', 'NORMALBETRIEB', 'UserAction', 'Normalbetrieb mit 80 Zügen aktiviert. Fahrplan synchron.', 'INFO');
        break;
      }
      case 2: {
        this.activeScenario.set('switch_fault');
        this.setSwitchFault('sw-17', true);
        this.addAuditLog('SZENARIO_GELADEN', 'SZENARIO', 'sc-2', 'Demo-Szenario 2', 'NORMAL', 'WEICHENSTÖRUNG_W017', 'UserAction', 'Weichenstörung W-017 im Vorfeld Frankfurt Fernbf injiziert.', 'KRITISCH');
        break;
      }
      case 3: {
        this.activeScenario.set('block_closed');
        this.setBlockState('blk-81', 'GESPERRT');
        this.addAuditLog('SZENARIO_GELADEN', 'SZENARIO', 'sc-3', 'Demo-Szenario 3', 'FREI', 'STRECKENSPERRUNG_B081', 'UserAction', 'Streckenblock B-081 gesperrt. Alternativrouten aktiviert.', 'WARNUNG');
        break;
      }
      case 4: {
        this.activeScenario.set('major_disruption');
        this.setSwitchFault('sw-17', true);
        this.setBlockState('blk-81', 'GESPERRT');
        this.setBlockState('blk-46', 'STÖRUNG');
        this.addAuditLog('SZENARIO_GELADEN', 'SZENARIO', 'sc-4', 'Demo-Szenario 4', 'NORMAL', 'GROSSSTÖRUNG_MITTE', 'UserAction', 'Großstörung Korridor Mitte: Weiche W-017 + Blöcke B-081, B-046 gesperrt.', 'KRITISCH');
        break;
      }
      case 5: {
        this.activeScenario.set('etcs_test');
        this.selectedTrainId.set('tr-1');
        const tr1 = this.trains().find((t) => t.train_id === 'tr-1');
        if (tr1) {
          tr1.ato.enabled = true;
          tr1.ato.mode = 'PRECISION_BRAKING';
          tr1.etcs.brake_curve_mode = 'WARNING';
        }
        this.addAuditLog('SZENARIO_GELADEN', 'SZENARIO', 'sc-5', 'Demo-Szenario 5', 'MANUELL', 'ETCS_ATO_TEST', 'UserAction', 'ETCS/ATO Testfahrt für ICE 742 gestartet. Automatische Zielbremsung aktiv.', 'INFO');
        break;
      }
      case 6: {
        this.activeScenario.set('maintenance');
        this.selectedSwitchId.set('sw-17');
        const sw = this.network().switches.find((s) => s.switch_id === 'sw-17');
        if (sw) {
          sw.motor_current_mA = 5400;
          sw.vibration_rms = 2.85;
          sw.temperature_c = 48.2;
          sw.maintenance_state = 'DRINGEND';
        }
        this.addAuditLog('SZENARIO_GELADEN', 'SZENARIO', 'sc-6', 'Demo-Szenario 6', 'NORMAL', 'PREDICTIVE_MAINTENANCE', 'UserAction', 'Sensoranomalie an Weiche W-017 detektiert. Arbeitsauftrag IA-2026-0881 generiert.', 'WARNUNG');
        break;
      }
    }
  }

  setSwitchPosition(switchId: string, pos: SwitchPosition): void {
    const net = this.network();
    const sw = net.switches.find((s) => s.switch_id === switchId);
    if (!sw) return;

    if (sw.locked) {
      this.addAuditLog('WEICHE_BEFEHL_ABGEWIESEN', 'WEICHE', sw.switch_id, sw.name, sw.position, pos, 'DSTW_Safety', 'Weiche ist durch aktive Fahrstraße verriegelt.', 'WARNUNG');
      return;
    }

    sw.state = 'MOVING';
    this.addAuditLog('WEICHE_UMSTELLUNG', 'WEICHE', sw.switch_id, sw.name, sw.position, pos, 'Dispatcher', `Umstellung auf ${pos} angefordert.`, 'INFO');

    if (this.isBrowser) {
      setTimeout(() => {
        sw.position = pos;
        sw.state = 'POSITIONED';
        sw.cycle_count += 1;
        this.network.set({ ...net });
      }, 400);
    } else {
      sw.position = pos;
      sw.state = 'POSITIONED';
      sw.cycle_count += 1;
      this.network.set({ ...net });
    }
  }

  setSwitchFault(switchId: string, fault: boolean): void {
    const net = this.network();
    const sw = net.switches.find((s) => s.switch_id === switchId);
    if (!sw) return;

    sw.state = fault ? 'FAULT' : 'IDLE';
    sw.fault_reason = fault ? 'Endlagenprüferkreis unterbrochen (Widerstand > 120 Ohm)' : undefined;
    sw.maintenance_state = fault ? 'DRINGEND' : 'NORMAL';
    sw.motor_current_mA = fault ? 5420 : 2650;
    sw.temperature_c = fault ? 49.1 : 22.4;

    this.network.set({ ...net });
    this.addAuditLog(fault ? 'WEICHENSTÖRUNG' : 'WEICHE_ENTSTÖRT', 'WEICHE', sw.switch_id, sw.name, fault ? 'NORMAL' : 'FAULT', fault ? 'FAULT' : 'NORMAL', 'DSTW_Monitor', fault ? 'Weichenstörung gemeldet.' : 'Weiche erfolgreich entstört.', fault ? 'KRITISCH' : 'INFO');
  }

  setBlockState(blockId: string, state: BlockState): void {
    const net = this.network();
    const blk = net.blocks.find((b) => b.block_id === blockId);
    if (!blk) return;

    const oldState = blk.state;
    blk.state = state;
    this.network.set({ ...net });
    this.addAuditLog('BLOCK_ZUSTAND_GEÄNDERT', 'BLOCK', blk.block_id, blk.name, oldState, state, 'Fahrdienstleitung', `Blockzustand manuell auf ${state} gesetzt.`, state === 'GESPERRT' ? 'WARNUNG' : 'INFO');
  }

  setSignalAspect(signalId: string, aspect: SignalAspect): void {
    const net = this.network();
    const sig = net.signals.find((s) => s.signal_id === signalId);
    if (!sig) return;

    const oldAspect = sig.aspect;
    sig.aspect = aspect;
    this.network.set({ ...net });
    this.addAuditLog('SIGNAL_STELLUNG', 'SIGNAL', sig.signal_id, sig.name, oldAspect, aspect, 'DSTW_Stellwerk', `Signal auf ${aspect} gestellt.`, aspect === 'HALT' ? 'WARNUNG' : 'INFO');
  }

  setRouteState(routeId: string, state: Route['state']): void {
    const net = this.network();
    const rt = net.routes.find((r) => r.route_id === routeId);
    if (!rt) return;

    rt.state = state;
    this.network.set({ ...net });
    this.addAuditLog('FAHRSTRASSE_STATUS', 'FAHRSTRASSE', rt.route_id, rt.name, 'VORHER', state, 'DSTW_RouteController', `Fahrstraße ${rt.code} Status: ${state}.`, 'INFO');
  }

  applyDisruptionStrategy(incidentId: string, strategyIndex: number): void {
    const incs = this.incidents();
    const inc = incs.find((i) => i.incident_id === incidentId);
    if (!inc || !inc.strategies[strategyIndex]) return;

    inc.selected_strategy_index = strategyIndex;
    const strat = inc.strategies[strategyIndex];

    this.addAuditLog('DISRUPTION_STRATEGIE_ANGEWENDET', 'STÖRUNG', inc.incident_id, inc.title, 'OFFEN', strat.scenario_name, 'R-Disruption-Optimizer', `Strategie angewendet: ${strat.description}`, 'INFO');
  }

  resolveIncident(incidentId: string): void {
    const incs = this.incidents();
    const inc = incs.find((i) => i.incident_id === incidentId);
    if (!inc) return;

    inc.resolved = true;
    if (inc.entity_type === 'WEICHE') {
      this.setSwitchFault(inc.entity_id, false);
    } else if (inc.entity_type === 'BLOCK') {
      this.setBlockState(inc.entity_id, 'FREI');
    }

    this.incidents.set([...incs]);
    this.addAuditLog('STÖRUNG_BEHOBEN', 'STÖRUNG', inc.incident_id, inc.title, 'OFFEN', 'BEHOBEN', 'Instandhaltung', `Störung ${inc.title} wurde erfolgreich behoben.`, 'INFO');
  }

  createWhatIfScenario(name: string, strategy: WhatIfScenario['dispatching_strategy']): void {
    const newSc: WhatIfScenario = {
      id: `sc-custom-${Date.now()}`,
      name,
      description: `Simulierte Auswirkung mit Strategie ${strategy}`,
      created_at: new Date().toLocaleTimeString('de-DE'),
      applied_disruptions: this.incidents().filter((i) => !i.resolved).map((i) => i.title),
      dispatching_strategy: strategy,
      metrics: {
        punctuality_pct: strategy === 'ICE_VORRANG' ? 96.1 : strategy === 'PUFFER_OPTIMIERUNG' ? 89.2 : 93.5,
        total_delay_min: strategy === 'ICE_VORRANG' ? 74 : strategy === 'PUFFER_OPTIMIERUNG' ? 155 : 102,
        cancelled_trains: 0,
        energy_consumption_mwh: +(13.5 + Math.random() * 2).toFixed(1),
        passenger_comfort_score: strategy === 'PUFFER_OPTIMIERUNG' ? 97 : 88
      }
    };

    this.whatIfScenarios.update((list) => [newSc, ...list]);
    this.addAuditLog('WAS_WAERE_WENN_ERSTELLT', 'SZENARIO_ENGINE', newSc.id, newSc.name, 'BASE', strategy, 'R-Forecaster', `Was-wäre-wenn Szenario "${name}" berechnet.`, 'INFO');
  }

  completeWorkOrder(orderId: string): void {
    const orders = this.workOrders();
    const ord = orders.find((o) => o.order_id === orderId);
    if (!ord) return;

    ord.status = 'ABGESCHLOSSEN';
    this.workOrders.set([...orders]);
    this.addAuditLog('ARBEITSAUFTRAG_ABGESCHLOSSEN', 'INSTANDHALTUNG', ord.order_id, ord.component_name, 'IN_BEARBEITUNG', 'ABGESCHLOSSEN', 'Werkstatt', `Instandhaltungsauftrag ${ord.code} erfolgreich durchgeführt.`, 'INFO');
  }

  private addAuditLog(eventType: string, entityType: string, entityId: string, entityName: string, oldState: string, newState: string, source: string, details: string, severity: 'INFO' | 'WARNUNG' | 'KRITISCH'): void {
    const newEntry: AuditLogEntry = {
      id: `log-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: this.simulationTime().toTimeString().slice(0, 8),
      event_type: eventType,
      entity_type: entityType,
      entity_id: entityId,
      entity_name: entityName,
      old_state: oldState,
      new_state: newState,
      source,
      details,
      severity
    };

    this.auditLogs.update((logs) => [newEntry, ...logs.slice(0, 99)]);
  }

  exportAuditLogJson(): void {
    if (!this.isBrowser) return;
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(this.auditLogs(), null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `BAHNWERK_Audit_Log_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  }

  exportAuditLogCsv(): void {
    if (!this.isBrowser) return;
    const header = ['timestamp', 'event_type', 'entity_type', 'entity_name', 'old_state', 'new_state', 'source', 'severity', 'details'];
    const rows = this.auditLogs().map((l) => [l.timestamp, l.event_type, l.entity_type, `"${l.entity_name}"`, l.old_state, l.new_state, l.source, l.severity, `"${l.details.replace(/"/g, '""')}"`]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [header.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', encodeURI(csvContent));
    downloadAnchor.setAttribute('download', `BAHNWERK_Audit_Log_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  }
}
