# ==============================================================================
# MeasurementEngine - Unit & Conversion Test Suite (testthat)
# File: tests/test_units.R
# ==============================================================================

library(testthat)

test_that("Dimensional unit conversions are exact", {
  # Inch to mm: 1 inch = 25.4 mm
  expect_equal(convert_measurement(1, from = "inch", to = "mm"), 25.4, tolerance = 1e-6)
  expect_equal(convert_measurement(25.4, from = "mm", to = "inch"), 1.0, tolerance = 1e-6)

  # Temperature: 0 degC = 32 degF = 273.15 K
  expect_equal(convert_measurement(0, from = "degC", to = "degF"), 32.0, tolerance = 1e-6)
  expect_equal(convert_measurement(100, from = "degC", to = "degF"), 212.0, tolerance = 1e-6)
  expect_equal(convert_measurement(0, from = "degC", to = "K"), 273.15, tolerance = 1e-6)

  # Pressure: 1 bar = 100,000 Pa = 14.50377 psi
  expect_equal(convert_measurement(1, from = "bar", to = "Pa"), 100000, tolerance = 1e-4)
  expect_equal(convert_measurement(1, from = "bar", to = "psi"), 14.50377, tolerance = 1e-3)

  # Mass: 1 lb = 0.45359237 kg = 453.59237 g
  expect_equal(convert_measurement(1, from = "lb", to = "g"), 453.59237, tolerance = 1e-4)
})

test_that("Incompatible dimensional conversions fail safely with structured error", {
  # Cannot convert meters (Length) to kilograms (Mass)
  expect_error(
    convert_measurement(10, from = "m", to = "kg"),
    regexp = "Incompatible dimensions"
  )

  # Cannot convert seconds (Time) to volts (Electrical potential)
  expect_error(
    convert_measurement(5, from = "s", to = "V"),
    regexp = "Incompatible dimensions"
  )
})
