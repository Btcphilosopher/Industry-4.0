# ==============================================================================
# MeasurementEngine - Uncertainty & GUM Test Suite
# File: tests/test_uncertainty.R
# ==============================================================================

library(testthat)

test_that("Type A uncertainty computes standard error of the mean", {
  vals <- c(10.02, 10.04, 10.01, 10.03, 10.05)
  u_a <- calculate_type_a_uncertainty(vals)
  expected <- sd(vals) / sqrt(length(vals))
  expect_equal(u_a, expected, tolerance = 1e-6)
})

test_that("Type B uncertainty uses rectangular divisor sqrt(3)", {
  u_b <- calculate_type_b_uncertainty(0.01, distribution = "rectangular")
  expect_equal(u_b, 0.01 / sqrt(3), tolerance = 1e-6)
})

test_that("Uncertainty propagation combines uncorrelated sums of squares", {
  u1 <- 0.03
  u2 <- 0.04
  u_c <- combine_uncertainties(c(u1, u2))
  expect_equal(u_c, 0.05, tolerance = 1e-6) # 3-4-5 triangle

  exp_res <- expanded_uncertainty(u_c, confidence = 0.95)
  expect_equal(exp_res$expanded_uncertainty, 0.05 * 1.959964, tolerance = 1e-4)
})
