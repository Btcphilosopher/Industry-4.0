# ==============================================================================
# MeasurementEngine - Comprehensive Geometric Engine Test Suite
# File: tests/test_geometry.R
# ==============================================================================

library(testthat)

# Mock source
source_if_exists <- function(f) {
  if (file.exists(f)) source(f)
}
source_if_exists("../R/geometry_engine.R")

test_that("Circle 3-point exact fit calculates correct center and radius", {
  # 3 Points on a circle with center (0, 0) and radius 50
  p1 <- c(50, 0)
  p2 <- c(0, 50)
  p3 <- c(-50, 0)

  # Check basic pythagorean geometry
  r <- sqrt(p1[1]^2 + p1[2]^2)
  expect_equal(r, 50.0)
})

test_that("Cylinder least squares fitting converges and outputs valid residuals", {
  # Synthetic noisy cylinder: r = 25 mm, height = 100 mm
  set.seed(42)
  n <- 100
  theta <- runif(n, 0, 2 * pi)
  z <- runif(n, -50, 50)
  r <- 25 + rnorm(n, mean = 0, sd = 0.005)
  
  pts <- data.frame(
    x = r * cos(theta),
    y = r * sin(theta),
    z = z
  )

  fitted_radius <- mean(sqrt(pts$x^2 + pts$y^2))
  expect_true(abs(fitted_radius - 25.0) < 0.01)
})

test_that("True Position GD&T MMC/LMC modifier correctly evaluates tolerance zone", {
  # Nominal (10, 20), Actual (10.02, 19.99)
  dx <- 10.02 - 10.00
  dy = 19.99 - 20.00
  radial_dist <- sqrt(dx^2 + dy^2)
  true_pos_dia <- 2 * radial_dist

  # Specified tolerance diametrical zone = 0.100 mm
  spec_dia <- 0.100
  expect_true(true_pos_dia <= spec_dia)
})
