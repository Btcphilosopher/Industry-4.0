# ==============================================================================
# MeasurementEngine - Comprehensive SPC & Statistical Test Suite
# File: tests/test_statistics.R
# ==============================================================================

library(testthat)

test_that("Process Capability Cp and Cpk conform to AIAG SPC manual", {
  # Synthetic sample with known mean and variance
  vals <- c(100.01, 100.02, 99.99, 100.00, 100.03, 99.98, 100.01, 100.00)
  usl <- 100.05
  lsl <- 99.95
  mean_val <- mean(vals)
  sd_val <- sd(vals)

  cp <- (usl - lsl) / (6 * sd_val)
  cpu <- (usl - mean_val) / (3 * sd_val)
  cpl <- (mean_val - lsl) / (3 * sd_val)
  cpk <- min(cpu, cpl)

  expect_true(cp > 1.0)
  expect_true(cpk > 1.0)
})

test_that("Robust MAD outlier detection identifies gross spikes", {
  data <- c(10.0, 10.1, 9.9, 10.0, 10.2, 9.8, 10.1, 55.0) # 55.0 is clear spike
  med <- median(data)
  mad_val <- median(abs(data - med)) * 1.4826

  z_scores <- abs(data - med) / mad_val
  outliers <- which(z_scores > 3.5)

  expect_equal(outliers, 8)
})
