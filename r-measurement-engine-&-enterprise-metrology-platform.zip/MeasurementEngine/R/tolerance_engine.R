# ==============================================================================
# MeasurementEngine - Enterprise Metrology & Analytical Architecture
# File: R/tolerance_engine.R
# Industrial Metrology & GD&T Conformity System
# ==============================================================================

#' Evaluate Industrial Tolerances (Pass / Fail / Warning Guardbanding)
#'
#' @param actual_value Numeric vector or measurement object
#' @param nominal Nominal specification target
#' @param upper_tol Upper tolerance limit (+ delta or absolute USL)
#' @param lower_tol Lower tolerance limit (- delta or absolute LSL)
#' @param is_relative If TRUE, upper/lower tol are deltas (e.g. +0.1, -0.1). If FALSE, absolute USL/LSL.
#' @param guardband_factor ISO 14253-1 decision rule guardband factor (0 = standard, 1 = binary acceptance)
#' @param uncertainty Measurement expanded uncertainty for decision rules
#' @export
check_tolerance <- function(
    actual_value,
    nominal,
    upper_tol = 0.1,
    lower_tol = -0.1,
    is_relative = TRUE,
    guardband_factor = 0,
    uncertainty = 0
) {
  actual <- if (is.measurement(actual_value)) actual_value$value else as.numeric(actual_value)
  nominal <- as.numeric(nominal)

  # Calculate Upper Spec Limit (USL) and Lower Spec Limit (LSL)
  if (is_relative) {
    usl <- nominal + abs(upper_tol)
    lsl <- nominal - abs(lower_tol)
  } else {
    usl <- as.numeric(upper_tol)
    lsl <- as.numeric(lower_tol)
  }

  total_tolerance <- usl - lsl

  # ISO 14253-1 Guardbanding: Shrink acceptance zone by k * u
  usl_guardband <- usl - (guardband_factor * uncertainty)
  lsl_guardband <- lsl + (guardband_factor * uncertainty)

  deviation <- actual - nominal
  pct_deviation <- if (nominal != 0) (deviation / abs(nominal)) * 100 else 0
  pct_tolerance_used <- if (total_tolerance > 0) ((actual - lsl) / total_tolerance) * 100 else 50

  pass <- actual >= lsl_guardband & actual <= usl_guardband
  conditional_pass <- (actual >= lsl & actual <= usl) & !pass # In guardband zone

  status <- ifelse(pass, "PASS", ifelse(conditional_pass, "CONDITIONAL_PASS", ifelse(actual > usl, "FAIL_HIGH", "FAIL_LOW")))

  list(
    nominal = nominal,
    actual = actual,
    usl = usl,
    lsl = lsl,
    deviation = deviation,
    percentage_deviation = pct_deviation,
    tolerance_span = total_tolerance,
    percentage_tolerance_consumed = pct_tolerance_used,
    guardbanded_usl = usl_guardband,
    guardbanded_lsl = lsl_guardband,
    status = status,
    pass = pass
  )
}

#' Calculate Measurement Deviation from Nominal
#' @export
calculate_deviation <- function(actual, nominal) {
  as.numeric(actual) - as.numeric(nominal)
}

#' Calculate Tolerance Percentage Used
#' @export
calculate_tolerance_percentage <- function(actual, nominal, upper_tol, lower_tol) {
  usl <- nominal + abs(upper_tol)
  lsl <- nominal - abs(lower_tol)
  span <- usl - lsl
  if (span == 0) return(0)
  ((as.numeric(actual) - lsl) / span) * 100
}
