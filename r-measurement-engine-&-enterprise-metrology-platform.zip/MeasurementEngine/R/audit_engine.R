# ==============================================================================
# MeasurementEngine - Enterprise Metrology & Analytical Architecture
# File: R/audit_engine.R
# ISO 17025 Compliant Digital Measurement Ledger & Transformation Audit Trail
# ==============================================================================

#' Create Digital Measurement Audit Record
#'
#' Records every transformation step:
#' RAW -> CALIBRATION -> FILTER -> CORRECTION -> DERIVATION -> STATISTICAL ANALYSIS -> FINAL RESULT
#'
#' @export
create_audit_record <- function(
    operation,
    input_value,
    output_value,
    algorithm = "Standard GUM / Metrology Core",
    software_version = "MeasurementEngine v4.2.0-Enterprise",
    operator = "Lead Metrologist",
    configuration = list()
) {
  list(
    audit_id = paste0("AUD-", as.numeric(Sys.time()), "-", sample(1000:9999, 1)),
    timestamp = Sys.time(),
    operation = as.character(operation),
    software_version = as.character(software_version),
    algorithm = as.character(algorithm),
    input = input_value,
    output = output_value,
    operator = as.character(operator),
    configuration = configuration,
    hash = digest::digest(list(operation, input_value, output_value, Sys.time()), algo = "sha256")
  )
}

#' Verify Audit Ledger Integrity
#' @export
verify_audit_ledger <- function(audit_trail) {
  if (!is.list(audit_trail) || length(audit_trail) == 0) return(TRUE)
  # Check timestamps are monotonically increasing
  timestamps <- sapply(audit_trail, function(e) as.numeric(as.POSIXct(e$timestamp)))
  is_monotonic <- all(diff(timestamps) >= 0)
  list(
    valid_integrity = is_monotonic,
    entry_count = length(audit_trail),
    first_entry = audit_trail[[1]]$timestamp,
    last_entry = audit_trail[[length(audit_trail)]]$timestamp
  )
}
