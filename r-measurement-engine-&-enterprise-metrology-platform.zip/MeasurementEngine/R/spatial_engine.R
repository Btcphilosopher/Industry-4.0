# ==============================================================================
# MeasurementEngine - Enterprise Metrology & Analytical Architecture
# File: R/spatial_engine.R
# 3D Point Cloud & Coordinate Metrology Subsystem
# ==============================================================================

#' Analyze 3D Point Cloud Dataset (LiDAR / 3D Scanner / CMM)
#'
#' Evaluates bounding box, centroid, principal axes, surface deviations, and volumetric bounds.
#'
#' @param points Matrix or data frame with columns x, y, z
#' @param nominal_cad_primitive Optional reference primitive ("cylinder", "plane", "sphere", "box")
#' @param nominal_params Parameters for nominal CAD comparison
#' @export
analyze_point_cloud <- function(points, nominal_cad_primitive = NULL, nominal_params = list()) {
  pts <- as.matrix(points[, c("x", "y", "z")])
  n <- nrow(pts)

  # Spatial Bounding Box
  min_coords <- apply(pts, 2, min)
  max_coords <- apply(pts, 2, max)
  dimensions <- max_coords - min_coords

  # Centroid & Dispersion
  centroid <- apply(pts, 2, mean)
  cov_mat <- stats::cov(pts)
  eigen_decomp <- eigen(cov_mat)

  # Volumetric OBB (Oriented Bounding Box approximation) / AABB
  aabb_volume <- prod(dimensions)

  # Surface Deviations vs CAD Model
  deviations <- rep(0, n)
  if (!is.null(nominal_cad_primitive)) {
    if (nominal_cad_primitive == "cylinder") {
      # Cylinder aligned with Z axis
      r_nom <- nominal_params$radius %||% (nominal_params$diameter / 2)
      r_actual <- sqrt(pts[, "x"]^2 + pts[, "y"]^2)
      deviations <- r_actual - r_nom
    } else if (nominal_cad_primitive == "plane") {
      z_nom <- nominal_params$z %||% 0
      deviations <- pts[, "z"] - z_nom
    } else if (nominal_cad_primitive == "sphere") {
      r_nom <- nominal_params$radius %||% (nominal_params$diameter / 2)
      dist_center <- sqrt((pts[,"x"]-centroid[1])^2 + (pts[,"y"]-centroid[2])^2 + (pts[,"z"]-centroid[3])^2)
      deviations <- dist_center - r_nom
    }
  }

  list(
    point_count = n,
    centroid = centroid,
    bounding_box = list(min = min_coords, max = max_coords, dimensions = dimensions),
    aabb_volume = aabb_volume,
    principal_components = eigen_decomp$vectors,
    surface_deviations = list(
      mean_deviation = mean(deviations),
      max_deviation = max(abs(deviations)),
      rms_deviation = sqrt(mean(deviations^2)),
      raw_deviations = deviations
    )
  )
}
