# ==============================================================================
# MeasurementEngine - Enterprise Metrology & Analytical Architecture
# File: R/precision_engine.R
# ==============================================================================

#' Calculate Decimal Precision and Significant Figures
#' @export
calculate_precision <- function(values) {
  num_vals <- as.numeric(values)
  num_vals <- num_vals[!is.na(num_vals)]
  if (length(num_vals) == 0) return(list(precision = 0, sig_figs = 0))

  str_vals <- as.character(values)
  decimal_places <- sapply(str_vals, function(s) {
    if (grepl("\\.", s)) {
      nchar(strsplit(s, "\\.")[[1]][2])
    } else {
      0
    }
  })

  # Standard deviation as precision measure
  sd_val <- if (length(num_vals) > 1) stats::sd(num_vals) else 0

  list(
    decimal_places = max(decimal_places),
    mean_decimal_places = mean(decimal_places),
    numerical_precision = sd_val,
    variance = if (length(num_vals) > 1) stats::var(num_vals) else 0,
    coefficient_of_variation = if (mean(num_vals) != 0 && length(num_vals) > 1) (sd_val / mean(num_vals)) * 100 else 0
  )
}

#' Calculate Accuracy (Error vs Reference / Standard)
#' Accuracy = |Measured Mean - True Reference|
#' @export
calculate_accuracy <- function(measured_values, reference_standard) {
  clean <- as.numeric(measured_values[!is.na(measured_values)])
  if (length(clean) == 0) return(list(error = 0, relative_error_pct = 0, bias = 0))

  mean_val <- mean(clean)
  bias <- mean_val - reference_standard
  abs_error <- abs(bias)
  rel_error <- if (reference_standard != 0) (abs_error / abs(reference_standard)) * 100 else 0

  list(
    measured_mean = mean_val,
    reference_standard = reference_standard,
    bias = bias,
    absolute_error = abs_error,
    relative_error_pct = rel_error,
    accuracy_class = if (rel_error < 0.05) "Grade A (0.05%)" else if (rel_error < 0.2) "Grade B (0.2%)" else "Grade C"
  )
}

#' Calculate Instrument Resolution
#' @export
calculate_resolution <- function(readings) {
  diffs <- diff(sort(unique(as.numeric(readings))))
  diffs <- diffs[diffs > 0]
  min_increment <- if (length(diffs) > 0) min(diffs) else 0.001
  list(
    minimum_resolvable_step = min_increment,
    resolution_digits = ceiling(-log10(min_increment))
  )
}

#' Calculate Measurement Repeatability (Type A standard deviation under identical conditions)
#' @export
calculate_repeatability <- function(repeated_runs) {
  clean <- as.numeric(repeated_runs[!is.na(repeated_runs)])
  n <- length(clean)
  if (n < 2) return(list(repeatability_sd = 0, limit_r = 0, n = n))

  s_r <- stats::sd(clean)
  # Repeatability limit r = 2.8 * s_r (ISO 5725)
  r_limit <- 2.8 * s_r

  list(
    repeatability_sd = s_r,
    repeatability_limit_95 = r_limit,
    sample_size = n,
    mean = mean(clean)
  )
}

#' Calculate Measurement Reproducibility (Across operators / instruments / labs)
#' @param data_matrix Matrix or data frame with columns representing runs under different conditions
#' @export
calculate_reproducibility <- function(group_factor, measurement_values) {
  df <- data.frame(group = as.factor(group_factor), val = as.numeric(measurement_values))
  fit <- stats::aov(val ~ group, data = df)
  summary_fit <- summary(fit)[[1]]

  ms_between <- summary_fit["group", "Mean Sq"]
  ms_within  <- summary_fit["Residuals", "Mean Sq"]

  s_within <- sqrt(ms_within)
  s_between <- sqrt(max(0, (ms_between - ms_within) / (nrow(df) / length(unique(df$group)))))
  s_R <- sqrt(s_within^2 + s_between^2)

  list(
    repeatability_sd = s_within,
    between_group_sd = s_between,
    reproducibility_sd = s_R,
    reproducibility_limit_95 = 2.8 * s_R
  )
}
