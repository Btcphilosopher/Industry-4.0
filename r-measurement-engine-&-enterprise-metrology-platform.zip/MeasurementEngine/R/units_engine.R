# ==============================================================================
# MeasurementEngine - Enterprise Metrology & Analytical Architecture
# File: R/units_engine.R
# ==============================================================================

#' Physical Dimension Registry and SI Base Vector Definition
#' Dimensions represented as: [L, M, T, I, Theta, N, J]
#' (Length, Mass, Time, Current, Temp, Amount, Luminous Intensity)
#' @export
UNIT_REGISTRY <- list(
  # Length [L=1]
  "m"     = list(dim = c(1, 0, 0, 0, 0, 0, 0), to_si = function(x) x, from_si = function(x) x, base = "m", desc = "Meter"),
  "mm"    = list(dim = c(1, 0, 0, 0, 0, 0, 0), to_si = function(x) x * 1e-3, from_si = function(x) x * 1e3, base = "m", desc = "Millimeter"),
  "cm"    = list(dim = c(1, 0, 0, 0, 0, 0, 0), to_si = function(x) x * 1e-2, from_si = function(x) x * 1e2, base = "m", desc = "Centimeter"),
  "km"    = list(dim = c(1, 0, 0, 0, 0, 0, 0), to_si = function(x) x * 1e3, from_si = function(x) x * 1e-3, base = "m", desc = "Kilometer"),
  "um"    = list(dim = c(1, 0, 0, 0, 0, 0, 0), to_si = function(x) x * 1e-6, from_si = function(x) x * 1e6, base = "m", desc = "Micrometer"),
  "nm"    = list(dim = c(1, 0, 0, 0, 0, 0, 0), to_si = function(x) x * 1e-9, from_si = function(x) x * 1e9, base = "m", desc = "Nanometer"),
  "inch"  = list(dim = c(1, 0, 0, 0, 0, 0, 0), to_si = function(x) x * 0.0254, from_si = function(x) x / 0.0254, base = "m", desc = "Inch"),
  "foot"  = list(dim = c(1, 0, 0, 0, 0, 0, 0), to_si = function(x) x * 0.3048, from_si = function(x) x / 0.3048, base = "m", desc = "Foot"),
  "yard"  = list(dim = c(1, 0, 0, 0, 0, 0, 0), to_si = function(x) x * 0.9144, from_si = function(x) x / 0.9144, base = "m", desc = "Yard"),
  "mile"  = list(dim = c(1, 0, 0, 0, 0, 0, 0), to_si = function(x) x * 1609.344, from_si = function(x) x / 1609.344, base = "m", desc = "Mile"),

  # Mass [M=1]
  "kg"    = list(dim = c(0, 1, 0, 0, 0, 0, 0), to_si = function(x) x, from_si = function(x) x, base = "kg", desc = "Kilogram"),
  "g"     = list(dim = c(0, 1, 0, 0, 0, 0, 0), to_si = function(x) x * 1e-3, from_si = function(x) x * 1e3, base = "kg", desc = "Gram"),
  "mg"    = list(dim = c(0, 1, 0, 0, 0, 0, 0), to_si = function(x) x * 1e-6, from_si = function(x) x * 1e6, base = "kg", desc = "Milligram"),
  "pound" = list(dim = c(0, 1, 0, 0, 0, 0, 0), to_si = function(x) x * 0.45359237, from_si = function(x) x / 0.45359237, base = "kg", desc = "Pound (lb)"),
  "lb"    = list(dim = c(0, 1, 0, 0, 0, 0, 0), to_si = function(x) x * 0.45359237, from_si = function(x) x / 0.45359237, base = "kg", desc = "Pound (lb)"),
  "ounce" = list(dim = c(0, 1, 0, 0, 0, 0, 0), to_si = function(x) x * 0.0283495231, from_si = function(x) x / 0.0283495231, base = "kg", desc = "Ounce (oz)"),
  "oz"    = list(dim = c(0, 1, 0, 0, 0, 0, 0), to_si = function(x) x * 0.0283495231, from_si = function(x) x / 0.0283495231, base = "kg", desc = "Ounce (oz)"),

  # Time [T=1]
  "s"     = list(dim = c(0, 0, 1, 0, 0, 0, 0), to_si = function(x) x, from_si = function(x) x, base = "s", desc = "Second"),
  "ms"    = list(dim = c(0, 0, 1, 0, 0, 0, 0), to_si = function(x) x * 1e-3, from_si = function(x) x * 1e3, base = "s", desc = "Millisecond"),
  "us"    = list(dim = c(0, 0, 1, 0, 0, 0, 0), to_si = function(x) x * 1e-6, from_si = function(x) x * 1e6, base = "s", desc = "Microsecond"),
  "ns"    = list(dim = c(0, 0, 1, 0, 0, 0, 0), to_si = function(x) x * 1e-9, from_si = function(x) x * 1e9, base = "s", desc = "Nanosecond"),
  "min"   = list(dim = c(0, 0, 1, 0, 0, 0, 0), to_si = function(x) x * 60, from_si = function(x) x / 60, base = "s", desc = "Minute"),
  "h"     = list(dim = c(0, 0, 1, 0, 0, 0, 0), to_si = function(x) x * 3600, from_si = function(x) x / 3600, base = "s", desc = "Hour"),

  # Temperature [Theta=1]
  "K"     = list(dim = c(0, 0, 0, 0, 1, 0, 0), to_si = function(x) x, from_si = function(x) x, base = "K", desc = "Kelvin"),
  "degC"  = list(dim = c(0, 0, 0, 0, 1, 0, 0), to_si = function(x) x + 273.15, from_si = function(x) x - 273.15, base = "K", desc = "Degree Celsius"),
  "C"     = list(dim = c(0, 0, 0, 0, 1, 0, 0), to_si = function(x) x + 273.15, from_si = function(x) x - 273.15, base = "K", desc = "Degree Celsius"),
  "degF"  = list(dim = c(0, 0, 0, 0, 1, 0, 0), to_si = function(x) (x - 32) * 5/9 + 273.15, from_si = function(x) (x - 273.15) * 9/5 + 32, base = "K", desc = "Degree Fahrenheit"),
  "F"     = list(dim = c(0, 0, 0, 0, 1, 0, 0), to_si = function(x) (x - 32) * 5/9 + 273.15, from_si = function(x) (x - 273.15) * 9/5 + 32, base = "K", desc = "Degree Fahrenheit"),

  # Pressure [M=1, L=-1, T=-2]
  "Pa"    = list(dim = c(-1, 1, -2, 0, 0, 0, 0), to_si = function(x) x, from_si = function(x) x, base = "Pa", desc = "Pascal"),
  "kPa"   = list(dim = c(-1, 1, -2, 0, 0, 0, 0), to_si = function(x) x * 1e3, from_si = function(x) x * 1e-3, base = "Pa", desc = "Kilopascal"),
  "MPa"   = list(dim = c(-1, 1, -2, 0, 0, 0, 0), to_si = function(x) x * 1e6, from_si = function(x) x * 1e-6, base = "Pa", desc = "Megapascal"),
  "bar"   = list(dim = c(-1, 1, -2, 0, 0, 0, 0), to_si = function(x) x * 1e5, from_si = function(x) x * 1e-5, base = "Pa", desc = "Bar"),
  "mbar"  = list(dim = c(-1, 1, -2, 0, 0, 0, 0), to_si = function(x) x * 1e2, from_si = function(x) x * 1e-2, base = "Pa", desc = "Millibar"),
  "psi"   = list(dim = c(-1, 1, -2, 0, 0, 0, 0), to_si = function(x) x * 6894.75729, from_si = function(x) x / 6894.75729, base = "Pa", desc = "Pounds per square inch"),

  # Force [M=1, L=1, T=-2]
  "N"     = list(dim = c(1, 1, -2, 0, 0, 0, 0), to_si = function(x) x, from_si = function(x) x, base = "N", desc = "Newton"),
  "kN"    = list(dim = c(1, 1, -2, 0, 0, 0, 0), to_si = function(x) x * 1e3, from_si = function(x) x * 1e-3, base = "N", desc = "Kilonewton"),
  "lbf"   = list(dim = c(1, 1, -2, 0, 0, 0, 0), to_si = function(x) x * 4.448222, from_si = function(x) x / 4.448222, base = "N", desc = "Pound-force"),

  # Energy / Work [M=1, L=2, T=-2]
  "J"     = list(dim = c(2, 1, -2, 0, 0, 0, 0), to_si = function(x) x, from_si = function(x) x, base = "J", desc = "Joule"),
  "kJ"    = list(dim = c(2, 1, -2, 0, 0, 0, 0), to_si = function(x) x * 1e3, from_si = function(x) x * 1e-3, base = "J", desc = "Kilojoule"),
  "Wh"    = list(dim = c(2, 1, -2, 0, 0, 0, 0), to_si = function(x) x * 3600, from_si = function(x) x / 3600, base = "J", desc = "Watt-hour"),
  "kWh"   = list(dim = c(2, 1, -2, 0, 0, 0, 0), to_si = function(x) x * 3.6e6, from_si = function(x) x / 3.6e6, base = "J", desc = "Kilowatt-hour"),

  # Power [M=1, L=2, T=-3]
  "W"     = list(dim = c(2, 1, -3, 0, 0, 0, 0), to_si = function(x) x, from_si = function(x) x, base = "W", desc = "Watt"),
  "kW"    = list(dim = c(2, 1, -3, 0, 0, 0, 0), to_si = function(x) x * 1e3, from_si = function(x) x * 1e-3, base = "W", desc = "Kilowatt"),
  "hp"    = list(dim = c(2, 1, -3, 0, 0, 0, 0), to_si = function(x) x * 745.699872, from_si = function(x) x / 745.699872, base = "W", desc = "Horsepower"),

  # Electrical
  "A"     = list(dim = c(0, 0, 0, 1, 0, 0, 0), to_si = function(x) x, from_si = function(x) x, base = "A", desc = "Ampere"),
  "mA"    = list(dim = c(0, 0, 0, 1, 0, 0, 0), to_si = function(x) x * 1e-3, from_si = function(x) x * 1e3, base = "A", desc = "Milliampere"),
  "V"     = list(dim = c(2, 1, -3, -1, 0, 0, 0), to_si = function(x) x, from_si = function(x) x, base = "V", desc = "Volt"),
  "mV"    = list(dim = c(2, 1, -3, -1, 0, 0, 0), to_si = function(x) x * 1e-3, from_si = function(x) x * 1e3, base = "V", desc = "Millivolt"),
  "ohm"   = list(dim = c(2, 1, -3, -2, 0, 0, 0), to_si = function(x) x, from_si = function(x) x, base = "ohm", desc = "Ohm"),
  "C"     = list(dim = c(0, 0, 1, 1, 0, 0, 0), to_si = function(x) x, from_si = function(x) x, base = "C", desc = "Coulomb"),

  # Frequency / Velocity / Angular
  "Hz"    = list(dim = c(0, 0, -1, 0, 0, 0, 0), to_si = function(x) x, from_si = function(x) x, base = "Hz", desc = "Hertz"),
  "kHz"   = list(dim = c(0, 0, -1, 0, 0, 0, 0), to_si = function(x) x * 1e3, from_si = function(x) x * 1e-3, base = "Hz", desc = "Kilohertz"),
  "rpm"   = list(dim = c(0, 0, -1, 0, 0, 0, 0), to_si = function(x) x / 60, from_si = function(x) x * 60, base = "Hz", desc = "Revolutions per minute"),
  "m/s"   = list(dim = c(1, 0, -1, 0, 0, 0, 0), to_si = function(x) x, from_si = function(x) x, base = "m/s", desc = "Meters per second"),
  "km/h"  = list(dim = c(1, 0, -1, 0, 0, 0, 0), to_si = function(x) x / 3.6, from_si = function(x) x * 3.6, base = "m/s", desc = "Kilometers per hour"),
  "mph"   = list(dim = c(1, 0, -1, 0, 0, 0, 0), to_si = function(x) x * 0.44704, from_si = function(x) x / 0.44704, base = "m/s", desc = "Miles per hour"),

  # Volume & Flow
  "L"     = list(dim = c(3, 0, 0, 0, 0, 0, 0), to_si = function(x) x * 1e-3, from_si = function(x) x * 1e3, base = "m^3", desc = "Litre"),
  "litre" = list(dim = c(3, 0, 0, 0, 0, 0, 0), to_si = function(x) x * 1e-3, from_si = function(x) x * 1e3, base = "m^3", desc = "Litre"),
  "mL"    = list(dim = c(3, 0, 0, 0, 0, 0, 0), to_si = function(x) x * 1e-6, from_si = function(x) x * 1e6, base = "m^3", desc = "Millilitre"),
  "gallon"= list(dim = c(3, 0, 0, 0, 0, 0, 0), to_si = function(x) x * 0.003785411784, from_si = function(x) x / 0.003785411784, base = "m^3", desc = "US Gallon"),
  "m3/s"  = list(dim = c(3, 0, -1, 0, 0, 0, 0), to_si = function(x) x, from_si = function(x) x, base = "m3/s", desc = "Cubic meters per second"),
  "L/min" = list(dim = c(3, 0, -1, 0, 0, 0, 0), to_si = function(x) (x * 1e-3) / 60, from_si = function(x) (x * 60) / 1e-3, base = "m3/s", desc = "Litres per minute"),

  # Photometric & Radiometric
  "lm"    = list(dim = c(0, 0, 0, 0, 0, 0, 1), to_si = function(x) x, from_si = function(x) x, base = "lm", desc = "Lumen"),
  "lx"    = list(dim = c(-2, 0, 0, 0, 0, 0, 1), to_si = function(x) x, from_si = function(x) x, base = "lx", desc = "Lux"),
  "cd"    = list(dim = c(0, 0, 0, 0, 0, 0, 1), to_si = function(x) x, from_si = function(x) x, base = "cd", desc = "Candela"),
  "mol"   = list(dim = c(0, 0, 0, 0, 0, 1, 0), to_si = function(x) x, from_si = function(x) x, base = "mol", desc = "Mole"),

  # Angles
  "rad"   = list(dim = c(0, 0, 0, 0, 0, 0, 0), to_si = function(x) x, from_si = function(x) x, base = "rad", desc = "Radian"),
  "deg"   = list(dim = c(0, 0, 0, 0, 0, 0, 0), to_si = function(x) x * pi / 180, from_si = function(x) x * 180 / pi, base = "rad", desc = "Degree")
)

#' Get unit specification
#' @export
get_unit_spec <- function(unit) {
  if (!unit %in% names(UNIT_REGISTRY)) {
    return(NULL)
  }
  UNIT_REGISTRY[[unit]]
}

#' Check dimensional compatibility between two units
#' @export
are_units_compatible <- function(unit1, unit2) {
  spec1 <- get_unit_spec(unit1)
  spec2 <- get_unit_spec(unit2)
  if (is.null(spec1) || is.null(spec2)) return(FALSE)
  all(spec1$dim == spec2$dim)
}
