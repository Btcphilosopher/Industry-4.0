# ==============================================================================
# MeasurementEngine - Enterprise Metrology & Analytical Architecture
# File: R/quality_engine.R
# ==============================================================================

#' Assess Comprehensive Metrological Quality & Conformity
#' @export
evaluate_quality_conformance <- function(
    measurements,
    nominal,
    upper_tol,
    lower_tol,
    uncertainty_budget = NULL
) {
  x <- as.numeric(measurements)
  n <- length(x)
  tol_res <- check_tolerance(x, nominal, upper_tol, lower_tol)

  pass_count <- sum(tol_res$pass)
  fail_count <- n - pass_count
  yield_pct <- (pass_count / n) * 100

  stats_res <- calculate_statistics(x)
  spc_res <- calculate_process_capability(x, nominal + abs(upper_tol), nominal - abs(lower_tol))

  overall_health <- "EXCELLENT"
  if (yield_pct < 95 || spc_res$Cpk < 1.33) {
    overall_health <- "MARGINAL"
  }
  if (yield_pct < 90 || spc_res$Cpk < 1.0) {
    overall_health <- "CRITICAL"
  }

  list(
    total_samples = n,
    pass_count = pass_count,
    fail_count = fail_count,
    yield_percentage = yield_pct,
    spc_summary = spc_res,
    basic_statistics = stats_res,
    overall_health = overall_health,
    conformance_status = if (fail_count == 0) "CONFORMANT" else "NON_CONFORMANT"
  )
}
