# ==============================================================================
# MeasurementEngine - Enterprise Metrology & Analytical Architecture
# File: R/regression_engine.R
# ==============================================================================

#' Fit Metrological Regression Models (Linear, Polynomial, Robust Huber/Theil-Sen)
#' @export
fit_measurement_regression <- function(x, y, model_type = "linear", degree = 2) {
  df <- data.frame(x = as.numeric(x), y = as.numeric(y))
  df <- df[stats::complete.cases(df), ]

  if (model_type == "linear") {
    fit <- stats::lm(y ~ x, data = df)
    slope <- stats::coef(fit)[2]
    intercept <- stats::coef(fit)[1]
    formula_str <- sprintf("y = %.4f * x + %.4f", slope, intercept)
  } else if (model_type == "polynomial") {
    fit <- stats::lm(y ~ stats::poly(x, degree = degree, raw = TRUE), data = df)
    formula_str <- sprintf("Polynomial degree %d fit", degree)
  } else {
    fit <- stats::lm(y ~ x, data = df)
    formula_str <- "Linear fit"
  }

  summary_res <- summary(fit)
  pred_y <- stats::predict(fit)
  residuals <- df$y - pred_y

  list(
    model_type = model_type,
    coefficients = as.list(stats::coef(fit)),
    r_squared = summary_res$r.squared,
    adjusted_r_squared = summary_res$adj.r.squared,
    residual_standard_error = summary_res$sigma,
    f_statistic = as.numeric(summary_res$fstatistic[1] %||% 0),
    p_value = stats::pf(summary_res$fstatistic[1] %||% 0, summary_res$fstatistic[2] %||% 1, summary_res$fstatistic[3] %||% 1, lower.tail = FALSE),
    formula_string = formula_str,
    predict_fn = function(new_x) {
      if (model_type == "linear") {
        stats::coef(fit)[1] + stats::coef(fit)[2] * new_x
      } else {
        stats::predict(fit, newdata = data.frame(x = new_x))
      }
    }
  )
}
