# ==============================================================================
# MeasurementEngine - Enterprise Metrology & Analytical Architecture
# File: R/statistics_engine.R
# Statistical Process Control (SPC) & Metrological Distribution Engine
# ==============================================================================

#' Comprehensive Metrological Statistical Summary
#' @export
calculate_statistics <- function(data) {
  x <- as.numeric(data)
  x <- x[!is.na(x)]
  n <- length(x)
  if (n == 0) return(NULL)

  mean_val <- mean(x)
  median_val <- stats::median(x)
  sd_val <- if (n > 1) stats::sd(x) else 0
  var_val <- if (n > 1) stats::var(x) else 0
  cv_val <- if (mean_val != 0 && n > 1) (sd_val / mean_val) * 100 else 0

  # Mode estimation via density
  mode_val <- if (n > 2) {
    d <- stats::density(x)
    d$x[which.max(d$y)]
  } else {
    mean_val
  }

  q <- stats::quantile(x, probs = c(0.01, 0.05, 0.25, 0.5, 0.75, 0.95, 0.99))
  iqr_val <- q["75%"] - q["25%"]

  # Skewness & Kurtosis
  skewness <- if (n > 2 && sd_val > 0) mean((x - mean_val)^3) / (sd_val^3) else 0
  kurtosis <- if (n > 3 && sd_val > 0) (mean((x - mean_val)^4) / (sd_val^4)) - 3 else 0

  # 95% Confidence Interval for the Mean
  se_mean <- sd_val / sqrt(n)
  ci_95 <- if (n > 1) {
    t_crit <- stats::qt(0.975, df = n - 1)
    c(lower = mean_val - t_crit * se_mean, upper = mean_val + t_crit * se_mean)
  } else {
    c(lower = mean_val, upper = mean_val)
  }

  list(
    n = n,
    mean = mean_val,
    median = median_val,
    mode = mode_val,
    min = min(x),
    max = max(x),
    range = max(x) - min(x),
    variance = var_val,
    standard_deviation = sd_val,
    standard_error = se_mean,
    coefficient_of_variation_pct = cv_val,
    quantiles = as.list(q),
    iqr = iqr_val,
    skewness = skewness,
    kurtosis = kurtosis,
    confidence_interval_95 = as.list(ci_95)
  )
}

#' Calculate Industrial Process Capability Indices (Cp, Cpk, Pp, Ppk)
#'
#' @param measurements Numeric vector of process measurements
#' @param usl Upper Specification Limit
#' @param lsl Lower Specification Limit
#' @param subgroup_size Subgroup size for within-subgroup variation (default 1)
#' @export
calculate_process_capability <- function(measurements, usl, lsl, subgroup_size = 5) {
  x <- as.numeric(measurements[!is.na(measurements)])
  n <- length(x)
  if (n < 6) stop("[MeasurementEngine:SPCError] Process capability requires at least 6 samples.")

  mean_process <- mean(x)
  total_sd <- stats::sd(x) # Overall variation for Pp, Ppk

  # Estimate within-subgroup variation (sigma_within) via moving range or subgroup ranges
  k <- floor(n / subgroup_size)
  if (k >= 2 && subgroup_size > 1) {
    # Average range R-bar / d2
    ranges <- sapply(1:k, function(i) {
      idx <- ((i - 1) * subgroup_size + 1):(i * subgroup_size)
      diff(range(x[idx]))
    })
    r_bar <- mean(ranges)
    # d2 constant for subgroup size
    d2_table <- c("2" = 1.128, "3" = 1.693, "4" = 2.059, "5" = 2.326, "6" = 2.534, "10" = 3.078)
    d2 <- as.numeric(d2_table[as.character(subgroup_size)] %||% 2.326)
    within_sd <- r_bar / d2
  } else {
    # Moving range of consecutive pairs
    mr <- abs(diff(x))
    within_sd <- mean(mr) / 1.128
  }

  spec_width <- usl - lsl

  # Potential Capability (Cp, Cpk)
  cp <- spec_width / (6 * within_sd)
  cpu <- (usl - mean_process) / (3 * within_sd)
  cpl <- (mean_process - lsl) / (3 * within_sd)
  cpk <- min(cpu, cpl)

  # Overall Performance (Pp, Ppk)
  pp <- spec_width / (6 * total_sd)
  ppu <- (usl - mean_process) / (3 * total_sd)
  ppl <- (mean_process - lsl) / (3 * total_sd)
  ppk <- min(ppu, ppl)

  # Estimated Parts Per Million (PPM) Defective
  p_def_upper <- 1 - stats::pnorm((usl - mean_process) / total_sd)
  p_def_lower <- stats::pnorm((lsl - mean_process) / total_sd)
  ppm_defective <- (p_def_upper + p_def_lower) * 1e6

  list(
    mean = mean_process,
    sigma_within = within_sd,
    sigma_overall = total_sd,
    usl = usl,
    lsl = lsl,
    Cp = cp,
    Cpk = cpk,
    Cpu = cpu,
    Cpl = cpl,
    Pp = pp,
    Ppk = ppk,
    ppm_defective = ppm_defective,
    capability_status = if (cpk >= 1.67) "Six Sigma World-Class" else if (cpk >= 1.33) "Capable (Industry Standard)" else if (cpk >= 1.0) "Marginal" else "Not Capable (Intervention Required)"
  )
}

#' Calculate Statistical Control Limits (X-bar & R / Individuals-MR Chart)
#' @export
calculate_control_limits <- function(measurements, subgroup_size = 1) {
  x <- as.numeric(measurements[!is.na(measurements)])
  n <- length(x)

  if (subgroup_size == 1) {
    # Individuals (I-MR) Chart
    center_line <- mean(x)
    mr <- abs(diff(x))
    mr_bar <- mean(mr)
    sigma_est <- mr_bar / 1.128
    ucl <- center_line + 3 * sigma_est
    lcl <- center_line - 3 * sigma_est
    mr_ucl <- 3.267 * mr_bar
    mr_lcl <- 0
  } else {
    # Subgroup X-bar Chart
    k <- floor(n / subgroup_size)
    means <- sapply(1:k, function(i) mean(x[((i - 1) * subgroup_size + 1):(i * subgroup_size)]))
    center_line <- mean(means)
    total_sd <- stats::sd(means)
    ucl <- center_line + 3 * total_sd
    lcl <- center_line - 3 * total_sd
    mr_ucl <- NULL
    mr_lcl <- NULL
  }

  list(
    center_line = center_line,
    ucl = ucl,
    lcl = lcl,
    mr_ucl = mr_ucl,
    mr_lcl = mr_lcl
  )
}
