# ==============================================================================
# MeasurementEngine - Enterprise Metrology & Analytical Architecture
# File: R/sensor_engine.R
# ==============================================================================

#' Create a Sensor Abstraction Object
#'
#' @param id Sensor alphanumeric identifier
#' @param type Measurement modality ('temperature', 'pressure', 'force', 'distance', 'vibration', etc.)
#' @param unit Native unit of measurement
#' @param range_min Minimum physical working range
#' @param range_max Maximum physical working range
#' @param sampling_rate_hz Nominal sampling frequency
#' @param noise_std Dev standard deviation of measurement noise
#' @param drift_rate Systematic drift per sample/hour
#' @export
create_sensor <- function(
    id = "SENS-001",
    type = "temperature",
    unit = "C",
    range_min = -40,
    range_max = 120,
    sampling_rate_hz = 100,
    noise_std = 0.05,
    drift_rate = 0.0001,
    accuracy = 0.02,
    resolution = 0.001
) {
  sensor_obj <- list(
    id = as.character(id),
    type = as.character(type),
    unit = as.character(unit),
    range_min = as.numeric(range_min),
    range_max = as.numeric(range_max),
    sampling_rate_hz = as.numeric(sampling_rate_hz),
    noise_std = as.numeric(noise_std),
    drift_rate = as.numeric(drift_rate),
    accuracy = as.numeric(accuracy),
    resolution = as.numeric(resolution),
    calibration_model = NULL,
    sample_count = 0,
    last_reading = NULL,
    status = "ONLINE"
  )
  class(sensor_obj) <- c("sensor", "list")
  return(sensor_obj)
}

#' Read from Sensor (Real or Simulated)
#' @export
read_sensor <- function(sensor, n = 1, true_signal = 25.0) {
  t_indices <- (sensor$sample_count + 1):(sensor$sample_count + n)
  drift <- t_indices * sensor$drift_rate
  noise <- stats::rnorm(n, mean = 0, sd = sensor$noise_std)

  raw_vals <- true_signal + drift + noise
  # Quantize by resolution
  if (sensor$resolution > 0) {
    raw_vals <- round(raw_vals / sensor$resolution) * sensor$resolution
  }

  sensor$sample_count <- sensor$sample_count + n
  sensor$last_reading <- raw_vals[length(raw_vals)]

  measurements <- lapply(seq_along(raw_vals), function(i) {
    create_measurement(
      value = raw_vals[i],
      unit = sensor$unit,
      measurement_type = sensor$type,
      instrument = paste0("Sensor_", sensor$type),
      sensor_id = sensor$id,
      accuracy = sensor$accuracy,
      precision = sensor$noise_std,
      resolution = sensor$resolution,
      source = "measured",
      data_state = DataState$RAW
    )
  })

  list(sensor = sensor, measurements = measurements, values = raw_vals)
}

#' Validate Sensor Data Range and Integrity
#' @export
validate_sensor_data <- function(sensor, values) {
  v <- as.numeric(values)
  in_range <- v >= sensor$range_min & v <= sensor$range_max
  is_finite_val <- is.finite(v)
  valid <- in_range & is_finite_val

  list(
    total = length(v),
    valid_count = sum(valid),
    invalid_count = sum(!valid),
    out_of_range_indices = which(!in_range),
    pass = all(valid)
  )
}
