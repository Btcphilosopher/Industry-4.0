# ==============================================================================
# MeasurementEngine - Enterprise Metrology & Analytical Architecture
# File: R/geometry_engine.R
# ==============================================================================

#' Euclidean Distance between 2D or 3D Points
#' @export
calculate_distance <- function(point_a, point_b) {
  a <- as.numeric(point_a)
  b <- as.numeric(point_b)
  if (length(a) != length(b)) {
    stop("[MeasurementEngine:GeomError] Point dimensions must match (2D vs 2D, or 3D vs 3D).")
  }
  sqrt(sum((a - b)^2))
}

#' Calculate 2D Polygon Perimeter and Area (Shoelace Formula)
#' @param vertices Matrix or data frame with columns x, y
#' @export
calculate_area <- function(vertices) {
  if (is.data.frame(vertices)) vertices <- as.matrix(vertices[, c("x", "y")])
  n <- nrow(vertices)
  if (n < 3) stop("[MeasurementEngine:GeomError] Polygon requires at least 3 vertices.")

  x <- vertices[, 1]
  y <- vertices[, 2]

  # Shoelace formula
  i <- 1:n
  j <- c(2:n, 1)
  area <- 0.5 * abs(sum(x[i] * y[j] - x[j] * y[i]))

  # Perimeter
  dx <- x[j] - x[i]
  dy <- y[j] - y[i]
  perimeter <- sum(sqrt(dx^2 + dy^2))

  # Centroid
  cx <- sum((x[i] + x[j]) * (x[i] * y[j] - x[j] * y[i])) / (6 * (if (area == 0) 1 else area))
  cy <- sum((y[i] + y[j]) * (x[i] * y[j] - x[j] * y[i])) / (6 * (if (area == 0) 1 else area))

  list(
    area = area,
    perimeter = perimeter,
    centroid = c(x = abs(cx), y = abs(cy))
  )
}

#' Calculate Volumetric and Surface Dimensions for 3D Geometric Primitives
#' @export
calculate_volume <- function(shape_type = "cylinder", params = list()) {
  type <- tolower(shape_type)

  if (type == "cylinder") {
    r <- params$radius %||% (params$diameter / 2)
    h <- params$height
    vol <- pi * (r^2) * h
    surf_area <- 2 * pi * r * h + 2 * pi * (r^2)
    list(volume = vol, surface_area = surf_area, radius = r, height = h)
  } else if (type == "sphere") {
    r <- params$radius %||% (params$diameter / 2)
    vol <- (4/3) * pi * (r^3)
    surf_area <- 4 * pi * (r^2)
    list(volume = vol, surface_area = surf_area, radius = r)
  } else if (type == "box") {
    l <- params$length
    w <- params$width
    h <- params$height
    vol <- l * w * h
    surf_area <- 2 * (l * w + l * h + w * h)
    list(volume = vol, surface_area = surf_area, length = l, width = w, height = h)
  } else if (type == "cone") {
    r <- params$radius
    h <- params$height
    vol <- (1/3) * pi * (r^2) * h
    slant <- sqrt(r^2 + h^2)
    surf_area <- pi * r * (r + slant)
    list(volume = vol, surface_area = surf_area, radius = r, height = h)
  } else {
    stop("[MeasurementEngine:GeomError] Unsupported 3D shape type: ", shape_type)
  }
}

#' Angle between two 2D or 3D vectors
#' @export
calculate_angle <- function(vector_a, vector_b, unit = "deg") {
  va <- as.numeric(vector_a)
  vb <- as.numeric(vector_b)
  dot_prod <- sum(va * vb)
  norm_a <- sqrt(sum(va^2))
  norm_b <- sqrt(sum(vb^2))

  if (norm_a == 0 || norm_b == 0) return(0)
  cos_theta <- max(-1, min(1, dot_prod / (norm_a * norm_b)))
  rad <- acos(cos_theta)

  if (unit == "deg" || unit == "degree") {
    return(rad * 180 / pi)
  }
  return(rad)
}
