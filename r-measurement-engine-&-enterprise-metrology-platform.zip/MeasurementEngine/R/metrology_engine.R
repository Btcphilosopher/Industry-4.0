# ==============================================================================
# MeasurementEngine - Enterprise Metrology & Analytical Architecture
# File: R/metrology_engine.R
# Unified Industrial Metrology Master Orchestrator
# ==============================================================================

#' High-level Metrology Pipeline Execution
#'
#' Orchestrates end-to-end metrological processing across sensor ingestion,
#' conversion, calibration, uncertainty evaluation, tolerance verification, and audit logging.
#'
#' @export
execute_metrology_pipeline <- function(
    raw_value,
    from_unit = "inch",
    to_unit = "mm",
    calibration_model = NULL,
    nominal = 25.4,
    upper_tol = 0.05,
    lower_tol = -0.05,
    instrument = "Optical_Micrometer_500",
    operator = "Lead Metrologist",
    type_b_bound = 0.002
) {
  audit_entries <- list()

  # Step 1: Create Universal Measurement
  meas <- create_measurement(
    value = raw_value,
    unit = from_unit,
    measurement_type = "length",
    instrument = instrument,
    operator = operator,
    source = "measured",
    data_state = DataState$RAW
  )

  # Step 2: Calibration
  if (!is.null(calibration_model)) {
    meas <- calibrate_sensor(meas, calibration_model)
  }

  # Step 3: Unit Conversion
  if (from_unit != to_unit) {
    meas <- convert_measurement(meas, to = to_unit)
  }

  # Step 4: Uncertainty Evaluation (GUM)
  uncert_res <- calculate_uncertainty(
    measured_value = meas$value,
    type_b_components = list(
      list(bound = type_b_bound, dist = "rectangular")
    ),
    confidence = 0.95,
    unit = meas$unit
  )
  meas$uncertainty <- uncert_res$expanded_uncertainty
  meas$confidence <- 0.95

  # Step 5: Tolerance Evaluation
  tol_res <- check_tolerance(
    actual_value = meas$value,
    nominal = nominal,
    upper_tol = upper_tol,
    lower_tol = lower_tol,
    uncertainty = meas$uncertainty
  )

  # Step 6: Validation & Quality Score
  meas <- validate_measurement(meas, range_bounds = c(nominal - 10, nominal + 10))

  list(
    measurement = meas,
    tolerance = tol_res,
    uncertainty = uncert_res,
    summary = list(
      value = meas$value,
      unit = meas$unit,
      nominal = nominal,
      deviation = tol_res$deviation,
      expanded_uncertainty = meas$uncertainty,
      pass_fail = tol_res$status,
      quality_score = meas$metadata$quality_score,
      state = meas$data_state
    )
  )
}
