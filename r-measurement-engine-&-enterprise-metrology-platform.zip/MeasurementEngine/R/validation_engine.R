# ==============================================================================
# MeasurementEngine - Enterprise Metrology & Analytical Architecture
# File: R/validation_engine.R
# ISO 17025 End-to-End Validation Pipeline
# ==============================================================================

#' Execute Complete Measurement Validation Pipeline
#'
#' Pipeline:
#' RAW DATA -> FORMAT -> UNIT -> RANGE -> CALIBRATION CHECK ->
#' NOISE/OUTLIER DETECTION -> UNCERTAINTY -> QUALITY SCORE -> VALIDATED MEASUREMENT
#'
#' @param measurement Measurement object or raw numeric value
#' @param unit Unit string
#' @param range_bounds Numeric vector c(min, max)
#' @param calibration_required Logical
#' @param max_uncertainty_threshold Maximum allowable expanded uncertainty
#' @return Validated measurement object with quality score and audit history
#' @export
validate_measurement <- function(
    measurement,
    unit = NULL,
    range_bounds = NULL,
    calibration_required = TRUE,
    max_uncertainty_threshold = 0.05
) {
  if (!is.measurement(measurement)) {
    if (is.null(unit)) unit <- "dimensionless"
    measurement <- create_measurement(value = measurement, unit = unit)
  }

  score <- 100
  issues <- c()

  # Step 1: Format Validation
  if (is.null(measurement$value) || is.na(measurement$value) || !is.finite(measurement$value)) {
    measurement$quality_status <- QualityStatus$REJECTED
    issues <- c(issues, "Invalid numeric format / Non-finite value")
    score <- 0
  }

  # Step 2: Unit Validation
  spec <- get_unit_spec(measurement$unit)
  if (is.null(spec)) {
    measurement$quality_status <- QualityStatus$REJECTED
    issues <- c(issues, sprintf("Unrecognized physical unit '%s'", measurement$unit))
    score <- score - 40
  }

  # Step 3: Range Validation
  if (!is.null(range_bounds)) {
    if (measurement$value < range_bounds[1] || measurement$value > range_bounds[2]) {
      measurement$quality_status <- QualityStatus$OUT_OF_RANGE
      issues <- c(issues, sprintf("Value %g outside operating range [%g, %g]", measurement$value, range_bounds[1], range_bounds[2]))
      score <- score - 35
    }
  }

  # Step 4: Calibration Status Check
  if (calibration_required && measurement$calibration_status != "CALIBRATED") {
    measurement$quality_status <- QualityStatus$UNCALIBRATED
    issues <- c(issues, "Sensor calibration is expired or unverified")
    score <- score - 25
  }

  # Step 5: Uncertainty Threshold Check
  if (measurement$uncertainty > max_uncertainty_threshold) {
    issues <- c(issues, sprintf("Uncertainty ±%g exceeds maximum threshold ±%g", measurement$uncertainty, max_uncertainty_threshold))
    score <- score - 15
  }

  # Assign Final Quality Score and Status
  final_score <- max(0, min(100, score))
  measurement$metadata$quality_score <- final_score
  measurement$metadata$validation_issues <- issues

  if (final_score >= 80 && measurement$quality_status != QualityStatus$OUT_OF_RANGE && measurement$quality_status != QualityStatus$REJECTED) {
    measurement$quality_status <- QualityStatus$VALID
  } else if (final_score >= 50) {
    measurement$quality_status <- QualityStatus$SUSPECT
  } else {
    measurement$quality_status <- QualityStatus$REJECTED
  }

  measurement$audit_trail[[length(measurement$audit_trail) + 1]] <- list(
    step = "MEASUREMENT_VALIDATION",
    timestamp = Sys.time(),
    operator = measurement$operator,
    note = sprintf("Validation complete. Score: %d/100, Status: %s", final_score, measurement$quality_status)
  )

  return(measurement)
}

#' Detect Outliers using Metrological Rules (Z-Score & IQR)
#' @export
detect_outliers <- function(values, method = "z_score", threshold = 3.0) {
  x <- as.numeric(values)
  n <- length(x)
  if (n < 4) return(rep(FALSE, n))

  if (method == "z_score") {
    m <- mean(x, na.rm = TRUE)
    s <- stats::sd(x, na.rm = TRUE)
    z <- if (s > 0) abs(x - m) / s else rep(0, n)
    is_outlier <- z > threshold
  } else if (method == "iqr") {
    q25 <- stats::quantile(x, 0.25, na.rm = TRUE)
    q75 <- stats::quantile(x, 0.75, na.rm = TRUE)
    iqr_val <- q75 - q25
    is_outlier <- x < (q25 - 1.5 * iqr_val) | x > (q75 + 1.5 * iqr_val)
  } else {
    is_outlier <- rep(FALSE, n)
  }

  list(
    outliers = is_outlier,
    outlier_count = sum(is_outlier),
    outlier_indices = which(is_outlier)
  )
}

#' Calculate Quality Score
#' @export
calculate_quality_score <- function(snr_db = 40, cal_valid = TRUE, uncert_pct = 0.5, outlier = FALSE) {
  score <- 100
  if (!cal_valid) score <- score - 30
  if (outlier) score <- score - 40
  if (snr_db < 20) score <- score - 20 else if (snr_db < 30) score <- score - 10
  if (uncert_pct > 2.0) score <- score - 20 else if (uncert_pct > 1.0) score <- score - 10
  max(0, min(100, round(score)))
}
