# ==============================================================================
# MeasurementEngine - Enterprise Metrology & Analytical Architecture
# File: R/anomaly_engine.R
# Machine Learning Anomaly & Sensor Drift Detection
# ==============================================================================

#' Detect Anomaly and Outlier Patterns in Time-Series Measurements
#'
#' Evaluates statistical dispersion, sliding variance bursts, and drift signatures.
#' Note: Does NOT alter raw data; maintains strict data state isolation.
#'
#' @param time_series Numeric vector of sensor readings
#' @param contamination Expected anomaly rate (e.g. 0.05)
#' @param window_size Rolling baseline window
#' @export
detect_anomalies <- function(time_series, contamination = 0.05, window_size = 20) {
  x <- as.numeric(time_series)
  n <- length(x)
  if (n < 5) return(list(anomaly_flags = rep(FALSE, n), anomaly_scores = rep(0, n)))

  # Robust rolling median & MAD
  k <- floor(window_size / 2)
  anomaly_scores <- numeric(n)

  for (i in 1:n) {
    w_start <- max(1, i - k)
    w_end <- min(n, i + k)
    window_data <- x[w_start:w_end]
    med <- stats::median(window_data)
    mad_val <- stats::mad(window_data, constant = 1.4826)
    if (mad_val > 0) {
      anomaly_scores[i] <- abs(x[i] - med) / mad_val
    } else {
      anomaly_scores[i] <- 0
    }
  }

  threshold <- stats::quantile(anomaly_scores, 1 - contamination, na.rm = TRUE)
  is_anomaly <- anomaly_scores > max(3.0, threshold)

  list(
    anomaly_flags = is_anomaly,
    anomaly_scores = anomaly_scores,
    threshold = threshold,
    anomaly_count = sum(is_anomaly),
    anomaly_indices = which(is_anomaly)
  )
}

#' Detect Progressive Sensor Calibration Drift
#'
#' Fits Mann-Kendall or linear slope over time to distinguish drift from noise.
#' @export
detect_sensor_drift <- function(readings, timestamps = NULL, drift_threshold_per_hour = 0.05) {
  x <- as.numeric(readings)
  n <- length(x)
  t <- if (!is.null(timestamps)) as.numeric(as.POSIXct(timestamps)) - as.numeric(as.POSIXct(timestamps[1])) else 1:n

  fit <- stats::lm(x ~ t)
  slope <- stats::coef(fit)[2]
  p_val <- summary(fit)$coefficients[2, 4]
  r2 <- summary(fit)$r.squared

  # Hourly drift
  hourly_drift <- slope * (if (!is.null(timestamps)) 3600 else 3600)

  has_drift <- (p_val < 0.01) && (abs(hourly_drift) > drift_threshold_per_hour)

  list(
    has_drift = has_drift,
    slope = slope,
    estimated_drift_rate = hourly_drift,
    p_value = p_val,
    r_squared = r2,
    drift_severity = if (abs(hourly_drift) > drift_threshold_per_hour * 3) "CRITICAL" else if (has_drift) "WARNING" else "NOMINAL"
  )
}

#' Remaining Useful Life (RUL) & Failure Prediction
#' @export
estimate_remaining_useful_life <- function(wear_measurements, failure_threshold, nominal_val = 0) {
  w <- as.numeric(wear_measurements)
  n <- length(w)
  t <- 1:n

  fit <- stats::lm(w ~ t)
  slope <- stats::coef(fit)[2]
  intercept <- stats::coef(fit)[1]

  current_val <- w[n]
  remaining_margin <- abs(failure_threshold - current_val)

  if (slope > 0 && failure_threshold > current_val) {
    cycles_to_fail <- (failure_threshold - current_val) / slope
  } else if (slope < 0 && failure_threshold < current_val) {
    cycles_to_fail <- (current_val - failure_threshold) / abs(slope)
  } else {
    cycles_to_fail <- Inf
  }

  list(
    current_wear = current_val,
    failure_threshold = failure_threshold,
    wear_rate_per_cycle = slope,
    remaining_cycles = max(0, round(cycles_to_fail)),
    health_index_pct = max(0, min(100, (1 - (abs(current_val - nominal_val) / abs(failure_threshold - nominal_val))) * 100))
  )
}
