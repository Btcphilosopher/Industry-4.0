# ==============================================================================
# MeasurementEngine - Enterprise Metrology & Analytical Architecture
# File: R/api_engine.R
# Plumber / REST API Interface for Measurement Engine
# ==============================================================================

#' High-Level Internal API Functions
#' @export
measure <- function(value, unit, type = "general", instrument = "generic") {
  create_measurement(value = value, unit = unit, measurement_type = type, instrument = instrument)
}

#' @export
convert <- function(measurement_or_val, from = NULL, to = NULL) {
  convert_measurement(measurement_or_val, from = from, to = to)
}

#' @export
calibrate <- function(raw_val, model) {
  calibrate_sensor(raw_val, model)
}

#' @export
validate <- function(meas, range_bounds = NULL) {
  validate_measurement(meas, range_bounds = range_bounds)
}

#' @export
analyse <- function(values, usl = NULL, lsl = NULL) {
  res_stats <- calculate_statistics(values)
  res_spc <- if (!is.null(usl) && !is.null(lsl)) calculate_process_capability(values, usl, lsl) else NULL
  res_outliers <- detect_outliers(values)
  list(statistics = res_stats, spc = res_spc, outliers = res_outliers)
}

#' @export
simulate <- function(nominal = 100, noise = 0.05, n = 1000, drift_rate = 0, outliers_pct = 0.01) {
  t <- 1:n
  signal <- nominal + t * drift_rate + stats::rnorm(n, 0, noise)
  # Inject outliers
  n_outliers <- floor(n * outliers_pct)
  if (n_outliers > 0) {
    outlier_idx <- sample(1:n, n_outliers)
    signal[outlier_idx] <- signal[outlier_idx] + sample(c(-1, 1), n_outliers, replace = TRUE) * noise * 8
  }
  signal
}

# ------------------------------------------------------------------------------
# Plumber API Endpoints Definition (conceptually mounted in plumber.R)
# ------------------------------------------------------------------------------

#* @post /measurement
#* @param value:numeric Raw numeric measurement
#* @param unit:character Measurement unit
#* @param type:character Measurement modality
function(value, unit = "mm", type = "length") {
  meas <- create_measurement(value = as.numeric(value), unit = unit, measurement_type = type)
  jsonlite::toJSON(meas, auto_unbox = TRUE)
}

#* @post /calibrate
#* @param raw_value:numeric
#* @param offset:numeric
#* @param gain:numeric
function(raw_value, offset = 0, gain = 1) {
  val <- as.numeric(raw_value) * as.numeric(gain) + as.numeric(offset)
  list(raw = as.numeric(raw_value), calibrated = val, state = DataState$CALIBRATED)
}

#* @post /validate
#* @param value:numeric
#* @param min:numeric
#* @param max:numeric
function(value, min = 0, max = 200) {
  val <- as.numeric(value)
  meas <- create_measurement(val, "mm")
  res <- validate_measurement(meas, range_bounds = c(as.numeric(min), as.numeric(max)))
  res
}

#* @post /analyse
#* @param values:numeric Array of numeric values
#* @param usl:numeric Upper spec limit
#* @param lsl:numeric Lower spec limit
function(values, usl = 100.1, lsl = 99.9) {
  vals <- as.numeric(values)
  analyse(vals, as.numeric(usl), as.numeric(lsl))
}
