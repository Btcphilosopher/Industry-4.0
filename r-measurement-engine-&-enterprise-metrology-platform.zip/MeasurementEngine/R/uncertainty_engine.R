# ==============================================================================
# MeasurementEngine - Enterprise Metrology & Analytical Architecture
# File: R/uncertainty_engine.R
# ISO/IEC Guide 98-3 (GUM: Guide to the Expression of Uncertainty in Measurement)
# ==============================================================================

#' Calculate Type A Standard Uncertainty from Repeated Observations
#'
#' u_A = s / sqrt(n)
#' @param observations Numeric vector of repeated measurements
#' @return Numeric standard uncertainty u_A
#' @export
calculate_type_a_uncertainty <- function(observations) {
  clean <- observations[!is.na(observations)]
  n <- length(clean)
  if (n < 2) {
    return(0.0)
  }
  s <- stats::sd(clean)
  return(s / sqrt(n))
}

#' Calculate Type B Standard Uncertainty from Metrological Specifications
#'
#' @param value_bound Half-width of the tolerance/error interval (a)
#' @param distribution Probability distribution ("rectangular", "triangular", "normal", "u_shaped")
#' @param divisor_or_k Coverage factor if normal, or divisor
#' @return Numeric standard uncertainty u_B
#' @export
calculate_type_b_uncertainty <- function(value_bound, distribution = "rectangular", divisor_or_k = 2) {
  dist <- tolower(distribution)
  if (dist == "rectangular" || dist == "uniform") {
    return(value_bound / sqrt(3))
  } else if (dist == "triangular") {
    return(value_bound / sqrt(6))
  } else if (dist == "u_shaped") {
    return(value_bound / sqrt(2))
  } else if (dist == "normal" || dist == "gaussian") {
    return(value_bound / divisor_or_k)
  } else {
    return(value_bound / sqrt(3))
  }
}

#' Combine Uncertainties using Law of Propagation of Uncertainty (GUM)
#'
#' u_c = sqrt( sum( (c_i * u_i)^2 + 2 * sum_{i<j} c_i c_j u_ij ) )
#' @param uncertainties Numeric vector of standard uncertainties (u_i)
#' @param sensitivity_coeffs Optional numeric vector of sensitivity coefficients c_i (default all 1)
#' @param correlation_matrix Optional correlation matrix (default identity / uncorrelated)
#' @return Combined standard uncertainty u_c
#' @export
combine_uncertainties <- function(uncertainties, sensitivity_coeffs = NULL, correlation_matrix = NULL) {
  u <- as.numeric(uncertainties)
  n <- length(u)
  if (n == 0) return(0.0)
  if (is.null(sensitivity_coeffs)) sensitivity_coeffs <- rep(1, n)
  c <- as.numeric(sensitivity_coeffs)

  cu <- c * u
  if (is.null(correlation_matrix)) {
    # Uncorrelated sum of squares
    u_c <- sqrt(sum(cu^2))
  } else {
    # Correlated variance-covariance propagation
    cov_matrix <- matrix(0, nrow = n, ncol = n)
    for (i in 1:n) {
      for (j in 1:n) {
        cov_matrix[i, j] <- cu[i] * cu[j] * correlation_matrix[i, j]
      }
    }
    u_c <- sqrt(max(0, sum(cov_matrix)))
  }
  return(u_c)
}

#' Compute Expanded Uncertainty and Coverage Interval
#'
#' U = k * u_c
#' @param combined_uncertainty Combined standard uncertainty (u_c)
#' @param confidence Confidence level (e.g. 0.95, 0.99, 0.9545, 0.9973)
#' @param dof Degrees of freedom (infinite by default, or finite for Student-t)
#' @return List containing expanded uncertainty U, coverage factor k, and interval text
#' @export
expanded_uncertainty <- function(combined_uncertainty, confidence = 0.95, dof = Inf) {
  if (is.infinite(dof)) {
    alpha <- 1 - confidence
    k <- stats::qnorm(1 - alpha / 2)
  } else {
    alpha <- 1 - confidence
    k <- stats::qt(1 - alpha / 2, df = max(1, dof))
  }

  U <- combined_uncertainty * k
  list(
    expanded_uncertainty = U,
    coverage_factor = round(k, 4),
    confidence_level = confidence,
    dof = dof
  )
}

#' Complete Metrological Uncertainty Evaluation
#' @export
calculate_uncertainty <- function(
    measured_value,
    observations = NULL,
    type_b_components = list(),
    confidence = 0.95,
    unit = ""
) {
  type_a <- if (!is.null(observations) && length(observations) > 1) {
    calculate_type_a_uncertainty(observations)
  } else {
    0.0
  }

  type_b_values <- c()
  if (length(type_b_components) > 0) {
    for (comp in type_b_components) {
      bound <- comp$bound %||% 0.001
      dist <- comp$dist %||% "rectangular"
      type_b_values <- c(type_b_values, calculate_type_b_uncertainty(bound, dist))
    }
  }

  all_uncertainties <- c(type_a, type_b_values)
  u_c <- combine_uncertainties(all_uncertainties)
  exp_res <- expanded_uncertainty(u_c, confidence = confidence)

  representation <- sprintf(
    "%.4f ± %.4f %s (k=%.2f, %g%% confidence)",
    measured_value, exp_res$expanded_uncertainty, unit, exp_res$coverage_factor, confidence * 100
  )

  list(
    measured_value = measured_value,
    type_a_uncertainty = type_a,
    type_b_uncertainties = type_b_values,
    combined_uncertainty = u_c,
    expanded_uncertainty = exp_res$expanded_uncertainty,
    coverage_factor = exp_res$coverage_factor,
    confidence = confidence,
    formatted_string = representation
  )
}

# Helper
`%||%` <- function(a, b) if (!is.null(a)) a else b
