# ==============================================================================
# MeasurementEngine - Enterprise Metrology & Analytical Architecture
# File: R/measurement_core.R
# Author: Principal Metrology & Statistical Computing Systems Architect
# ==============================================================================

#' Measurement Quality Enumeration
#' @export
QualityStatus <- list(
  VALID = "VALID",
  SUSPECT = "SUSPECT",
  REJECTED = "REJECTED",
  UNCALIBRATED = "UNCALIBRATED",
  OUT_OF_RANGE = "OUT_OF_RANGE"
)

#' Measurement Data State
#' @export
DataState <- list(
  RAW = "RAW",
  CALIBRATED = "CALIBRATED",
  FILTERED = "FILTERED",
  DERIVED = "DERIVED",
  ESTIMATED = "ESTIMATED",
  PREDICTED = "PREDICTED"
)

#' Create a Universal Measurement Object
#'
#' Instantiates a standard metrological measurement record adhering to GUM
#' (Guide to the Expression of Uncertainty in Measurement) and ISO/IEC 17025 standards.
#'
#' @param value Numeric measurement value or vector
#' @param unit Character string representing measurement unit (e.g. 'mm', 'degC', 'Pa')
#' @param measurement_type Character string ('length', 'mass', 'temperature', 'pressure', etc.)
#' @param instrument Character identifier for instrument or sensor
#' @param sensor_id Unique sensor identifier
#' @param location Spatial or plant coordinate/location string
#' @param reference_frame Coordinate system reference (e.g. 'WGS84', 'LOCAL_CAD', 'SENSOR_BODY')
#' @param accuracy Nominal accuracy specification (numeric or percentage)
#' @param precision Decimal precision or standard repeatability
#' @param resolution Minimum detectable increment
#' @param uncertainty Combined standard or expanded uncertainty
#' @param confidence Coverage confidence level (default 0.95 for k=2)
#' @param calibration_status Character ('CALIBRATED', 'UNCALIBRATED', 'EXPIRED', 'PENDING')
#' @param operator Operator or automated system identifier
#' @param source Data source classification ('measured', 'simulated', 'derived', 'estimated')
#' @param data_state State of the measurement ('RAW', 'CALIBRATED', 'FILTERED', 'DERIVED', 'PREDICTED')
#' @param metadata Key-value list of arbitrary metrological attributes
#' @return A validated S3 'measurement' object
#' @export
create_measurement <- function(
    value,
    unit = "dimensionless",
    measurement_type = "general",
    instrument = "generic_sensor",
    sensor_id = paste0("SENS-", substr(as.character(runif(1, 100000, 999999)), 1, 6)),
    location = "Laboratory A-1",
    reference_frame = "LOCAL_CARTESIAN",
    accuracy = 0.001,
    precision = 0.0001,
    resolution = 0.0001,
    uncertainty = 0.005,
    confidence = 0.95,
    calibration_status = "CALIBRATED",
    operator = "Lead Metrologist",
    source = "measured",
    data_state = DataState$RAW,
    metadata = list()
) {
  if (missing(value) || is.null(value)) {
    stop("[MeasurementEngine:Error] Measurement value cannot be NULL or missing.")
  }

  timestamp <- Sys.time()
  measurement_id <- paste0("MEAS-", format(timestamp, "%Y%m%d%H%M%S"), "-", sample(1000:9999, 1))

  # Base object structure
  obj <- list(
    measurement_id = measurement_id,
    timestamp = timestamp,
    value = as.numeric(value),
    unit = as.character(unit),
    measurement_type = as.character(measurement_type),
    instrument = as.character(instrument),
    sensor_id = as.character(sensor_id),
    location = as.character(location),
    reference_frame = as.character(reference_frame),
    accuracy = as.numeric(accuracy),
    precision = as.numeric(precision),
    resolution = as.numeric(resolution),
    uncertainty = as.numeric(uncertainty),
    confidence = as.numeric(confidence),
    calibration_status = as.character(calibration_status),
    operator = as.character(operator),
    source = as.character(source),
    data_state = as.character(data_state),
    quality_status = QualityStatus$VALID,
    audit_trail = list(
      list(
        step = "CREATION",
        timestamp = timestamp,
        operator = operator,
        note = "Measurement instantiated."
      )
    ),
    metadata = as.list(metadata)
  )

  class(obj) <- c("measurement", "list")
  return(obj)
}

#' Print S3 Measurement Method
#' @export
print.measurement <- function(x, ...) {
  cat("========================================================\n")
  cat(sprintf("  Universal Measurement: %s\n", x$measurement_id))
  cat("========================================================\n")
  cat(sprintf("  Value:             %g %s\n", x$value, x$unit))
  cat(sprintf("  Type / State:      %s [%s]\n", x$measurement_type, x$data_state))
  cat(sprintf("  Expanded Uncert:   ±%g (%g%% confidence)\n", x$uncertainty, x$confidence * 100))
  cat(sprintf("  Resolution / Acc:  %g / ±%g\n", x$resolution, x$accuracy))
  cat(sprintf("  Instrument / S/N:  %s (%s)\n", x$instrument, x$sensor_id))
  cat(sprintf("  Calibration:       %s\n", x$calibration_status))
  cat(sprintf("  Quality Status:    %s\n", x$quality_status))
  cat(sprintf("  Timestamp:         %s\n", format(x$timestamp, "%Y-%m-%d %H:%M:%S")))
  cat(sprintf("  Operator:          %s | Source: %s\n", x$operator, x$source))
  cat("========================================================\n")
  invisible(x)
}

#' Check if an object is a valid measurement
#' @export
is.measurement <- function(x) {
  inherits(x, "measurement") &&
    !is.null(x$measurement_id) &&
    !is.null(x$value) &&
    !is.null(x$unit)
}
