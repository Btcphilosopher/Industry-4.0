# ==============================================================================
# MeasurementEngine - Enterprise Metrology & Analytical Architecture
# File: R/forecasting_engine.R
# ==============================================================================

#' Forecast Future Measurement Trajectory (Holt-Winters / Exponential Smoothing)
#' @export
forecast_measurements <- function(time_series, horizon = 10, alpha = 0.3, beta = 0.1) {
  x <- as.numeric(time_series)
  n <- length(x)
  if (n < 4) return(list(forecast = rep(x[max(1, n)], horizon), lower_95 = rep(x[max(1, n)], horizon), upper_95 = rep(x[max(1, n)], horizon)))

  # Double Exponential Smoothing (Holt's Linear)
  level <- x[1]
  trend <- x[2] - x[1]

  for (i in 2:n) {
    last_level <- level
    level <- alpha * x[i] + (1 - alpha) * (level + trend)
    trend <- beta * (level - last_level) + (1 - beta) * trend
  }

  forecast_vals <- numeric(horizon)
  for (h in 1:horizon) {
    forecast_vals[h] <- level + h * trend
  }

  # Forecast Confidence Bounds (95%)
  res_sd <- stats::sd(diff(x), na.rm = TRUE)
  if (is.na(res_sd) || res_sd == 0) res_sd <- 0.001
  lower_bound <- forecast_vals - 1.96 * res_sd * sqrt(1:horizon)
  upper_bound <- forecast_vals + 1.96 * res_sd * sqrt(1:horizon)

  list(
    forecast = forecast_vals,
    lower_95 = lower_bound,
    upper_95 = upper_bound,
    horizon = horizon,
    final_level = level,
    final_trend = trend
  )
}
