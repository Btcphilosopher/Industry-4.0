# ==============================================================================
# MeasurementEngine - Enterprise Metrology & Analytical Architecture
# File: R/visualization_engine.R
# Metrological Plotting and Dashboard Visual Generation (ggplot2 / plotly)
# ==============================================================================

#' Generate Control Chart (X-bar / Run Chart with Control Limits and Spec Limits)
#' @export
plot_control_chart <- function(measurements, usl = NULL, lsl = NULL, target = NULL, title = "Metrological SPC Run Chart") {
  df <- data.frame(
    Sample = 1:length(measurements),
    Value = as.numeric(measurements)
  )

  cl_res <- calculate_control_limits(df$Value)

  p <- ggplot2::ggplot(df, ggplot2::aes(x = Sample, y = Value)) +
    ggplot2::geom_line(color = "#0284c7", size = 0.8) +
    ggplot2::geom_point(color = "#0369a1", size = 2.5) +
    ggplot2::geom_hline(yintercept = cl_res$center_line, color = "#16a34a", linetype = "dashed", size = 1) +
    ggplot2::geom_hline(yintercept = cl_res$ucl, color = "#dc2626", linetype = "dotted", size = 1) +
    ggplot2::geom_hline(yintercept = cl_res$lcl, color = "#dc2626", linetype = "dotted", size = 1)

  if (!is.null(usl)) p <- p + ggplot2::geom_hline(yintercept = usl, color = "#9333ea", size = 1.2)
  if (!is.null(lsl)) p <- p + ggplot2::geom_hline(yintercept = lsl, color = "#9333ea", size = 1.2)
  if (!is.null(target)) p <- p + ggplot2::geom_hline(yintercept = target, color = "#475569", linetype = "solid")

  p + ggplot2::theme_minimal() +
    ggplot2::labs(title = title, x = "Sample Index", y = "Measured Value")
}

#' Generate Metrology Distribution Histogram with Gaussian Fit
#' @export
plot_measurement_distribution <- function(measurements, usl = NULL, lsl = NULL, bins = 30) {
  df <- data.frame(Value = as.numeric(measurements))
  m <- mean(df$Value, na.rm = TRUE)
  s <- stats::sd(df$Value, na.rm = TRUE)

  p <- ggplot2::ggplot(df, ggplot2::aes(x = Value)) +
    ggplot2::geom_histogram(ggplot2::aes(y = ..density..), bins = bins, fill = "#38bdf8", color = "#0284c7", alpha = 0.7) +
    ggplot2::stat_function(fun = stats::dnorm, args = list(mean = m, sd = s), color = "#dc2626", size = 1.2)

  if (!is.null(usl)) p <- p + ggplot2::geom_vline(xintercept = usl, color = "#9333ea", linetype = "dashed", size = 1)
  if (!is.null(lsl)) p <- p + ggplot2::geom_vline(xintercept = lsl, color = "#9333ea", linetype = "dashed", size = 1)

  p + ggplot2::theme_minimal() +
    ggplot2::labs(title = "Measurement Probability Density & Normal Fit", x = "Value", y = "Density")
}

#' Generate Uncertainty Budget Breakdown Bar Plot
#' @export
plot_uncertainty_budget <- function(components) {
  df <- data.frame(
    Source = names(components),
    Uncertainty = as.numeric(unlist(components))
  )
  df$PctVariance <- (df$Uncertainty^2 / sum(df$Uncertainty^2)) * 100

  ggplot2::ggplot(df, ggplot2::aes(x = reorder(Source, -PctVariance), y = PctVariance, fill = Source)) +
    ggplot2::geom_bar(stat = "identity", width = 0.6) +
    ggplot2::coord_flip() +
    ggplot2::theme_minimal() +
    ggplot2::labs(title = "GUM Uncertainty Budget Contribution (% of Variance)", x = "Component", y = "% Contribution")
}
