# ==============================================================================
# MeasurementEngine - Enterprise Metrology & Analytical Architecture
# File: R/filtering_engine.R
# Signal Conditioning & Digital Filtering Pipeline
# ==============================================================================

#' Moving Average Filter
#' @export
filter_moving_average <- function(data, window_size = 5) {
  x <- as.numeric(data)
  n <- length(x)
  if (window_size > n) window_size <- n
  stats::filter(x, rep(1 / window_size, window_size), sides = 2)
}

#' Median Filter (Spike & Impulse Outlier Removal)
#' @export
filter_median <- function(data, window_size = 5) {
  x <- as.numeric(data)
  n <- length(x)
  k <- floor(window_size / 2)
  res <- numeric(n)
  for (i in 1:n) {
    low <- max(1, i - k)
    high <- min(n, i + k)
    res[i] <- stats::median(x[low:high], na.rm = TRUE)
  }
  res
}

#' Digital Low-Pass / High-Pass / Band-Pass Filter (IIR Butterworth / Exponential)
#' @export
filter_frequency <- function(data, sampling_rate_hz = 1000, cutoff_hz = 50, type = "lowpass") {
  x <- as.numeric(data)
  n <- length(x)
  dt <- 1 / sampling_rate_hz
  rc <- 1 / (2 * pi * cutoff_hz)
  alpha <- dt / (rc + dt)

  res <- numeric(n)
  if (type == "lowpass") {
    res[1] <- x[1]
    for (i in 2:n) {
      res[i] <- res[i - 1] + alpha * (x[i] - res[i - 1])
    }
  } else if (type == "highpass") {
    alpha_hp <- rc / (rc + dt)
    res[1] <- x[1]
    for (i in 2:n) {
      res[i] <- alpha_hp * (res[i - 1] + x[i] - x[i - 1])
    }
  } else if (type == "bandpass") {
    # Sequential lowpass + highpass
    low_filtered <- filter_frequency(x, sampling_rate_hz, cutoff_hz = cutoff_hz * 2, type = "lowpass")
    res <- filter_frequency(low_filtered, sampling_rate_hz, cutoff_hz = cutoff_hz * 0.5, type = "highpass")
  }
  res
}

#' Baseline Drift Removal (Polynomial / Spline Background Subtraction)
#' @export
correct_baseline <- function(data, degree = 2) {
  x <- as.numeric(data)
  t <- 1:length(x)
  fit <- stats::lm(x ~ stats::poly(t, degree = degree, raw = TRUE))
  baseline <- stats::predict(fit)
  corrected <- x - baseline

  list(
    corrected_signal = corrected,
    baseline = baseline
  )
}
