# ==============================================================================
# MeasurementEngine - Enterprise Metrology & Analytical Architecture
# File: R/conversion_engine.R
# ==============================================================================

#' Convert a numeric value or measurement object safely between units
#'
#' @param value Numeric value, vector, or 'measurement' S3 object
#' @param from Source unit string (optional if value is a measurement object)
#' @param to Destination unit string
#' @return Converted numeric value or updated measurement S3 object with audit entry
#' @export
convert_measurement <- function(value, from = NULL, to = NULL) {
  is_meas <- is.measurement(value)

  if (is_meas) {
    src_val <- value$value
    from_unit <- value$unit
    to_unit <- if (is.null(to)) from else to
  } else {
    src_val <- value
    from_unit <- from
    to_unit <- to
  }

  if (is.null(from_unit) || is.null(to_unit)) {
    stop("[MeasurementEngine:Error] Both 'from' and 'to' units must be defined.")
  }

  if (from_unit == to_unit) {
    if (is_meas) return(value)
    return(src_val)
  }

  spec_from <- get_unit_spec(from_unit)
  spec_to <- get_unit_spec(to_unit)

  if (is.null(spec_from)) {
    stop(sprintf("[MeasurementEngine:UnitError] Unknown source unit '%s'.", from_unit))
  }
  if (is.null(spec_to)) {
    stop(sprintf("[MeasurementEngine:UnitError] Unknown target unit '%s'.", to_unit))
  }

  # Dimensional consistency check
  if (!all(spec_from$dim == spec_to$dim)) {
    stop(sprintf(
      "[MeasurementEngine:DimensionalError] Incompatible dimensions: Cannot convert from '%s' (%s) to '%s' (%s).",
      from_unit, spec_from$desc, to_unit, spec_to$desc
    ))
  }

  # Convert through SI base
  si_val <- spec_from$to_si(src_val)
  result_val <- spec_to$from_si(si_val)

  if (is_meas) {
    # Scale uncertainty & resolution appropriately
    ratio <- if (mean(abs(src_val), na.rm = TRUE) != 0) mean(result_val, na.rm = TRUE) / mean(src_val, na.rm = TRUE) else 1
    value$value <- result_val
    value$unit <- to_unit
    value$uncertainty <- value$uncertainty * abs(ratio)
    value$resolution <- value$resolution * abs(ratio)
    value$data_state <- DataState$DERIVED
    value$audit_trail[[length(value$audit_trail) + 1]] <- list(
      step = "UNIT_CONVERSION",
      timestamp = Sys.time(),
      operator = value$operator,
      note = sprintf("Converted from %s to %s (ratio %g)", from_unit, to_unit, ratio)
    )
    return(value)
  }

  return(result_val)
}
