# ==============================================================================
# MeasurementEngine - Enterprise Metrology & Analytical Architecture
# File: R/signal_engine.R
# Spectral & Frequency Domain Metrology Analysis
# ==============================================================================

#' Compute Fast Fourier Transform (FFT) and Power Spectral Density (PSD)
#' @param signal_data Numeric vector of time-domain sensor readings
#' @param sampling_rate_hz Sampling rate in Hz
#' @param window_type "rectangular", "hann", "hamming", "blackman"
#' @export
compute_fft_spectrum <- function(signal_data, sampling_rate_hz = 1000, window_type = "hann") {
  x <- as.numeric(signal_data)
  N <- length(x)
  if (N < 4) stop("[MeasurementEngine:SignalError] Signal length must be >= 4 samples.")

  # Detrend / Remove DC offset
  x_detrended <- x - mean(x)

  # Apply Windowing Function
  n_vec <- 0:(N - 1)
  if (window_type == "hann") {
    w <- 0.5 * (1 - cos(2 * pi * n_vec / (N - 1)))
  } else if (window_type == "hamming") {
    w <- 0.54 - 0.46 * cos(2 * pi * n_vec / (N - 1))
  } else if (window_type == "blackman") {
    w <- 0.42 - 0.5 * cos(2 * pi * n_vec / (N - 1)) + 0.08 * cos(4 * pi * n_vec / (N - 1))
  } else {
    w <- rep(1, N) # Rectangular
  }

  x_windowed <- x_detrended * w

  # FFT
  fft_res <- stats::fft(x_windowed)
  mag <- Mod(fft_res)[1:(floor(N / 2) + 1)]
  # Amplitude normalization
  mag_norm <- (mag / N) * 2
  mag_norm[1] <- mag_norm[1] / 2

  # Frequency axis
  freqs <- (0:(floor(N / 2))) * (sampling_rate_hz / N)
  # Power Spectral Density (PSD)
  psd <- (mag_norm^2) / (sampling_rate_hz / N)

  # Dominant Frequency Identification
  peak_idx <- which.max(mag_norm[-1]) + 1
  dominant_freq <- freqs[peak_idx]
  peak_amplitude <- mag_norm[peak_idx]

  # Total Harmonic Distortion (THD) estimation
  harmonics_idx <- which(abs(freqs %% dominant_freq) < (sampling_rate_hz / N * 1.5))
  harmonics_idx <- setdiff(harmonics_idx, c(1, peak_idx))
  thd <- if (length(harmonics_idx) > 0) sqrt(sum(mag_norm[harmonics_idx]^2)) / peak_amplitude else 0

  list(
    frequencies = freqs,
    magnitudes = mag_norm,
    psd = psd,
    dominant_frequency_hz = dominant_freq,
    peak_amplitude = peak_amplitude,
    thd = thd,
    total_power = sum(psd) * (sampling_rate_hz / N),
    snr_db = 20 * log10(peak_amplitude / (stats::sd(mag_norm[-peak_idx]) + 1e-9))
  )
}
