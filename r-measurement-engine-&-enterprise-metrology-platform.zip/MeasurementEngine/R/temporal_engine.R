# ==============================================================================
# MeasurementEngine - Enterprise Metrology & Analytical Architecture
# File: R/temporal_engine.R
# ==============================================================================

#' Calculate Duration between timestamps
#' @export
calculate_duration <- function(start_time, end_time, unit = "s") {
  diff_secs <- as.numeric(difftime(end_time, start_time, units = "secs"))
  if (unit == "ms") return(diff_secs * 1000)
  if (unit == "us") return(diff_secs * 1e6)
  if (unit == "min") return(diff_secs / 60)
  if (unit == "h") return(diff_secs / 3600)
  return(diff_secs)
}

#' Calculate Sampling Rate and Jitter from Timestamp Series
#' @param timestamps Vector of POSIXct or numeric time seconds
#' @export
calculate_sampling_rate <- function(timestamps) {
  ts <- as.numeric(as.POSIXct(timestamps))
  diffs <- diff(ts)
  diffs <- diffs[diffs > 0]

  if (length(diffs) == 0) return(list(frequency_hz = 0, mean_interval_s = 0, jitter_std = 0))

  mean_dt <- mean(diffs)
  freq <- 1 / mean_dt
  jitter <- stats::sd(diffs)

  list(
    frequency_hz = freq,
    mean_interval_s = mean_dt,
    median_interval_s = stats::median(diffs),
    min_interval_s = min(diffs),
    max_interval_s = max(diffs),
    jitter_std_s = jitter,
    jitter_percentage = (jitter / mean_dt) * 100
  )
}

#' Calculate Latency (Transmission or Processing Delay)
#' @export
calculate_latency <- function(sent_time, received_time) {
  latency_s <- as.numeric(difftime(received_time, sent_time, units = "secs"))
  list(
    latency_seconds = latency_s,
    latency_ms = latency_s * 1000,
    latency_us = latency_s * 1e6
  )
}
