# ==============================================================================
# MeasurementEngine - Enterprise Metrology & Analytical Architecture
# File: R/interpolation_engine.R
# Calibration Curves & Sensor Surface Interpolation
# ==============================================================================

#' Interpolate Measurement Grid or Calibration Look-up Table
#' @export
interpolate_measurements <- function(x, y, x_new, method = "linear") {
  x <- as.numeric(x)
  y <- as.numeric(y)
  x_new <- as.numeric(x_new)

  if (method == "linear") {
    stats::approx(x, y, xout = x_new, rule = 2)$y
  } else if (method == "spline") {
    stats::spline(x, y, xout = x_new)$y
  } else {
    stats::approx(x, y, xout = x_new, rule = 2)$y
  }
}

# ==============================================================================
# File: R/forecasting_engine.R
# Time-Series Forecasting for Sensor Drift & Environmental Compensation
# ==============================================================================

#' Forecast Future Measurement Trajectory (Holt-Winters / Exponential Smoothing)
#' @export
forecast_measurements <- function(time_series, horizon = 10, alpha = 0.3, beta = 0.1) {
  x <- as.numeric(time_series)
  n <- length(x)
  if (n < 4) return(rep(x[n], horizon))

  # Double Exponential Smoothing (Holt's Linear)
  level <- x[1]
  trend <- x[2] - x[1]

  for (i in 2:n) {
    last_level <- level
    level <- alpha * x[i] + (1 - alpha) * (level + trend)
    trend <- beta * (level - last_level) + (1 - beta) * trend
  }

  forecast_vals <- numeric(horizon)
  for (h in 1:horizon) {
    forecast_vals[h] <- level + h * trend
  }

  # Forecast Confidence Bounds (95%)
  res_sd <- stats::sd(diff(x))
  lower_bound <- forecast_vals - 1.96 * res_sd * sqrt(1:horizon)
  upper_bound <- forecast_vals + 1.96 * res_sd * sqrt(1:horizon)

  list(
    forecast = forecast_vals,
    lower_95 = lower_bound,
    upper_95 = upper_bound,
    horizon = horizon,
    final_level = level,
    final_trend = trend
  )
}
