# MeasurementEngine: General-Purpose Metrology & Analytical Operating System

An enterprise-grade, ISO/IEC 17025 & GUM-compliant measurement and analytical operating framework written in R.

## Architecture Overview

```
MeasurementEngine/
│
├── R/
│   ├── measurement_core.R      # Universal S3 measurement object & lifecycle
│   ├── units_engine.R          # 7-SI Base dimensional registry & units
│   ├── conversion_engine.R     # Dimensional check & safe unit conversion
│   ├── calibration_engine.R    # Zero, linear, polynomial & temp-drift models
│   ├── uncertainty_engine.R    # ISO GUM Type A & B uncertainty propagation
│   ├── precision_engine.R      # Repeatability, reproducibility, resolution
│   ├── validation_engine.R     # 8-step measurement validation pipeline
│   ├── sensor_engine.R         # Sensor abstraction & real-time streaming
│   ├── geometry_engine.R       # 2D/3D Euclidean geometry, areas & volumes
│   ├── spatial_engine.R        # LiDAR point-clouds & surface metrology
│   ├── temporal_engine.R       # Sampling frequency, latency & duration
│   ├── signal_engine.R         # FFT frequency domain, spectral density & THD
│   ├── filtering_engine.R      # Moving average, median & Butterworth filters
│   ├── statistics_engine.R     # Statistical Process Control (Cp, Cpk, Pp, Ppk)
│   ├── anomaly_engine.R        # Machine learning outlier & drift detection
│   ├── regression_engine.R     # Linear, polynomial & robust regression
│   ├── interpolation_engine.R  # Calibration spline & lookup interpolation
│   ├── forecasting_engine.R    # Time-series drift forecasting & RUL
│   ├── quality_engine.R        # Conformance assessment & yield analysis
│   ├── tolerance_engine.R      # ISO 14253-1 GD&T guardbanding & Pass/Fail
│   ├── metrology_engine.R      # Master high-level orchestration pipeline
│   ├── measurement_database.R  # In-memory & high-throughput batch engine
│   ├── audit_engine.R          # Immutable digital ledger & SHA-256 hash trail
│   ├── visualization_engine.R  # ggplot2 / plotly SPC & distribution charts
│   └── api_engine.R            # Plumber REST API endpoints
│
├── tests/                      # Automated unit test suite (testthat)
├── data/                       # NIST standards & LiDAR sample datasets
├── configuration/              # System tolerance profiles & sensor configs
├── examples/                   # Executable scripts for lab & factory use
└── reports/                    # ISO 17025 certificate templates
```

## Quick Start in R

```r
# Source core modules
lapply(list.files("R", full.names = TRUE), source)

# Create a Universal Measurement
meas <- create_measurement(
  value = 125.43,
  unit = "mm",
  measurement_type = "length",
  instrument = "Laser_Interferometer_X9"
)

# Convert units with dimensional safety
meas_inch <- convert_measurement(meas, to = "inch")

# Check tolerance conformance (Nominal 100mm ±0.1mm)
tol <- check_tolerance(100.07, nominal = 100.0, upper_tol = 0.1, lower_tol = -0.1)
print(tol$status) # "PASS"
```

## Metrological Compliance
- **GUM (Guide to the Expression of Uncertainty in Measurement)**: Type A (statistical) + Type B (resolution, standard certificate, thermal) combined uncertainty with coverage factor $k=2$ (95.45% CI).
- **ISO 14253-1**: Guardbanded decision rules for industrial conformity assessment.
- **ISO 5725**: Accuracy, trueness, repeatability ($r$), and reproducibility ($R$).
- **AIAG SPC 4th Edition**: Process capability ($C_p, C_{pk}, P_p, P_{pk}$) and Shewhart control limits.
