import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MetrologyService } from './core/metrology.service';
import { HeaderComponent } from './components/header/header';
import { SpreadsheetGridComponent } from './components/spreadsheet-grid/spreadsheet-grid';
import { CalibrationBenchComponent } from './components/calibration-bench/calibration-bench';
import { UncertaintyBudgetComponent } from './components/uncertainty-budget/uncertainty-budget';
import { Geometry3dViewerComponent } from './components/geometry3d-viewer/geometry3d-viewer';
import { SignalStudioComponent } from './components/signal-studio/signal-studio';
import { SpcControlComponent } from './components/spc-control/spc-control';
import { AnomalyMlComponent } from './components/anomaly-ml/anomaly-ml';
import { AuditLedgerComponent } from './components/audit-ledger/audit-ledger';
import { RExplorerComponent } from './components/r-explorer/r-explorer';
import { ReportModalComponent } from './components/report-modal/report-modal';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    MatIconModule,
    HeaderComponent,
    SpreadsheetGridComponent,
    CalibrationBenchComponent,
    UncertaintyBudgetComponent,
    Geometry3dViewerComponent,
    SignalStudioComponent,
    SpcControlComponent,
    AnomalyMlComponent,
    AuditLedgerComponent,
    RExplorerComponent,
    ReportModalComponent
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="min-h-screen bg-[#E4E3E0] text-[#141414] flex flex-col selection:bg-[#F27D26] selection:text-white">
      
      <!-- Top Application Header -->
      <app-header (onOpenReport)="showReportModal.set(true)" />

      <!-- Main Workspace Content -->
      <main class="flex-1 w-full max-w-[1440px] mx-auto p-4 sm:p-6">
        @switch (metrology.activeTab()) {
          @case ('grid') {
            <app-spreadsheet-grid />
          }
          @case ('calibration') {
            <app-calibration-bench />
          }
          @case ('uncertainty') {
            <app-uncertainty-budget />
          }
          @case ('geometry3d') {
            <app-geometry3d-viewer />
          }
          @case ('signal') {
            <app-signal-studio />
          }
          @case ('spc') {
            <app-spc-control />
          }
          @case ('anomaly') {
            <app-anomaly-ml />
          }
          @case ('audit') {
            <app-audit-ledger />
          }
          @case ('rCode') {
            <app-r-explorer />
          }
        }
      </main>

      <!-- ISO 17025 Report Modal -->
      @if (showReportModal()) {
        <app-report-modal (onClose)="showReportModal.set(false)" />
      }

      <!-- Bottom Engine Status Bar in Dark Theme Style -->
      <footer class="h-10 bg-[#141414] text-[#E4E3E0] flex items-center justify-between px-4 sm:px-6 font-mono text-[10px] uppercase tracking-widest border-t-2 border-[#141414] select-none">
        <div class="flex items-center space-x-4">
          <span class="flex items-center gap-1.5 text-[#F27D26] font-bold">
            <span class="w-2 h-2 rounded-full bg-[#F27D26] animate-pulse"></span>
            R ENGINE CORE: VALIDATED
          </span>
          <span class="hidden md:inline text-[#E4E3E0]/40">|</span>
          <span class="hidden md:inline text-[#E4E3E0]/75">BUFFER: 10,242 SAMPLES</span>
          <span class="hidden md:inline text-[#E4E3E0]/40">|</span>
          <span class="hidden md:inline text-[#E4E3E0]/75">MODE: CONTINUOUS CAPTURE</span>
        </div>

        <div class="flex items-center space-x-4 text-[#E4E3E0]/70">
          <span class="hidden sm:inline">ISO/IEC 17025:2017</span>
          <span class="hidden sm:inline">•</span>
          <span class="hidden sm:inline">JCGM 100:2008 (GUM)</span>
          <span class="text-emerald-400 font-bold">API: 200 OK</span>
        </div>
      </footer>

    </div>
  `
})
export class App {
  readonly metrology = inject(MetrologyService);
  showReportModal = signal<boolean>(false);
}
