export type QualityStatus = 'VALID' | 'SUSPECT' | 'REJECTED' | 'UNCALIBRATED' | 'OUT_OF_RANGE';
export type DataState = 'RAW' | 'CALIBRATED' | 'FILTERED' | 'DERIVED' | 'ESTIMATED' | 'PREDICTED';
export type ToleranceStatus = 'PASS' | 'CONDITIONAL_PASS' | 'FAIL_HIGH' | 'FAIL_LOW';

export interface AuditRecord {
  step: string;
  timestamp: string;
  operator: string;
  note: string;
}

export interface UniversalMeasurement {
  measurement_id: string;
  timestamp: string;
  value: number;
  unit: string;
  converted_value?: number;
  converted_unit?: string;
  measurement_type: string;
  instrument: string;
  sensor_id: string;
  location: string;
  reference_frame: string;
  accuracy: number;
  precision: number;
  resolution: number;
  uncertainty: number;
  confidence: number;
  calibration_status: string;
  operator: string;
  source: string;
  data_state: DataState;
  quality_status: QualityStatus;
  quality_score: number;
  nominal?: number;
  upper_tol?: number;
  lower_tol?: number;
  tolerance_status?: ToleranceStatus;
  deviation?: number;
  percentage_deviation?: number;
  audit_trail: AuditRecord[];
}

export interface CalibrationModel {
  id: string;
  name: string;
  instrument: string;
  model_type: 'linear' | 'polynomial' | 'zero_offset' | 'multi_point';
  coefficients: Record<string, number>;
  temp_coefficient: number;
  reference_standard: string;
  calibration_date: string;
  next_calibration: string;
  status: 'VALID' | 'EXPIRING_SOON' | 'EXPIRED';
  r_squared: number;
}

export interface UncertaintyComponent {
  id: string;
  name: string;
  bound: number;
  distribution: 'rectangular' | 'triangular' | 'normal' | 'u_shaped';
  divisor: number;
  standard_uncertainty: number;
  sensitivity_coeff: number;
  variance_contribution_pct: number;
}

export interface SpcMetrics {
  n: number;
  mean: number;
  total_sd: number;
  within_sd: number;
  usl: number;
  lsl: number;
  nominal: number;
  Cp: number;
  Cpk: number;
  Pp: number;
  Ppk: number;
  ucl: number;
  lcl: number;
  center_line: number;
  capability_rating: string;
}

export interface RFile {
  name: string;
  path: string;
  category: string;
  content: string;
}
