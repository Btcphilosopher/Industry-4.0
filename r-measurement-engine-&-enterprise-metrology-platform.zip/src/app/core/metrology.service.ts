import { Injectable, inject, signal, computed } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UniversalMeasurement, CalibrationModel, UncertaintyComponent, SpcMetrics, RFile, ToleranceStatus, DataState } from './metrology.types';

@Injectable({
  providedIn: 'root'
})
export class MetrologyService {
  private http = inject(HttpClient);

  // State Signals
  readonly measurements = signal<UniversalMeasurement[]>([]);
  readonly selectedMeasurementId = signal<string | null>(null);
  readonly activeTab = signal<'grid' | 'calibration' | 'uncertainty' | 'geometry3d' | 'signal' | 'spc' | 'anomaly' | 'audit' | 'rCode' | 'reports'>('grid');

  readonly calibrationModels = signal<CalibrationModel[]>([
    {
      id: 'CAL-OPT-001',
      name: 'Laser Interferometer 500 Linear Model',
      instrument: 'Laser Interferometer X9',
      model_type: 'linear',
      coefficients: { slope: 0.99984, intercept: 0.0012 },
      temp_coefficient: 0.00012,
      reference_standard: 'NIST-TRACEABLE-GAUGE-BLOCK-CLASS-0',
      calibration_date: '2026-06-15',
      next_calibration: '2027-06-15',
      status: 'VALID',
      r_squared: 0.99998
    },
    {
      id: 'CAL-CMM-002',
      name: 'Bridge CMM 3-Axis Polynomial Compensation',
      instrument: 'Hexagon Bridge CMM',
      model_type: 'polynomial',
      coefficients: { a0: 0.0004, a1: 1.00002, a2: -0.0000015 },
      temp_coefficient: 0.00008,
      reference_standard: 'UKAS-TRACEABLE-RING-GAUGE-99.999',
      calibration_date: '2026-04-10',
      next_calibration: '2027-04-10',
      status: 'VALID',
      r_squared: 0.99999
    },
    {
      id: 'CAL-PT100-003',
      name: 'Resistance Temperature Detector (RTD) Zero & Gain',
      instrument: 'Fluke 1524 Reference Thermometer',
      model_type: 'linear',
      coefficients: { slope: 1.0002, intercept: -0.015 },
      temp_coefficient: 0.0,
      reference_standard: 'ITS-90 Fixed-Point Triple Point Cell',
      calibration_date: '2026-08-01',
      next_calibration: '2027-08-01',
      status: 'VALID',
      r_squared: 1.00000
    }
  ]);

  readonly uncertaintyComponents = signal<UncertaintyComponent[]>([
    {
      id: 'UNC-01',
      name: 'Type A - Repeatability of 10 Observations (s / √n)',
      bound: 0.0035,
      distribution: 'normal',
      divisor: 1.0,
      standard_uncertainty: 0.0035,
      sensitivity_coeff: 1.0,
      variance_contribution_pct: 35.2
    },
    {
      id: 'UNC-02',
      name: 'Type B - Calibrated Gauge Block Certificate (k=2)',
      bound: 0.0020,
      distribution: 'normal',
      divisor: 2.0,
      standard_uncertainty: 0.0010,
      sensitivity_coeff: 1.0,
      variance_contribution_pct: 2.9
    },
    {
      id: 'UNC-03',
      name: 'Type B - Instrument Digital Readout Resolution (a / √3)',
      bound: 0.0010,
      distribution: 'rectangular',
      divisor: 1.732,
      standard_uncertainty: 0.000577,
      sensitivity_coeff: 1.0,
      variance_contribution_pct: 1.0
    },
    {
      id: 'UNC-04',
      name: 'Type B - Thermal Expansion Differential (20°C ±1.5°C)',
      bound: 0.0080,
      distribution: 'rectangular',
      divisor: 1.732,
      standard_uncertainty: 0.004618,
      sensitivity_coeff: 1.0,
      variance_contribution_pct: 60.9
    }
  ]);

  readonly rFiles = signal<RFile[]>([]);
  readonly isComputing = signal<boolean>(false);

  // Derived Summary Signals
  readonly totalCount = computed(() => this.measurements().length);
  readonly passCount = computed(() => this.measurements().filter(m => m.tolerance_status === 'PASS').length);
  readonly failCount = computed(() => this.measurements().filter(m => m.tolerance_status?.startsWith('FAIL')).length);
  readonly yieldPercentage = computed(() => {
    const total = this.totalCount();
    return total > 0 ? ((this.passCount() / total) * 100).toFixed(1) : '100.0';
  });

  readonly averageQuality = computed(() => {
    const all = this.measurements();
    if (all.length === 0) return 100;
    const sum = all.reduce((acc, m) => acc + (m.quality_score || 100), 0);
    return Math.round(sum / all.length);
  });

  readonly combinedStandardUncertainty = computed(() => {
    const comps = this.uncertaintyComponents();
    const sumSq = comps.reduce((acc, c) => acc + Math.pow(c.standard_uncertainty * c.sensitivity_coeff, 2), 0);
    return Math.sqrt(sumSq);
  });

  readonly expandedUncertaintyK2 = computed(() => {
    return this.combinedStandardUncertainty() * 2.0; // 95.45% coverage
  });

  readonly spcMetrics = computed<SpcMetrics | null>(() => {
    const ms = this.measurements();
    if (ms.length < 4) return null;
    const vals = ms.map(m => m.value);
    const n = vals.length;
    const mean = vals.reduce((a, b) => a + b, 0) / n;
    const variance = vals.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / (n - 1);
    const totalSd = Math.sqrt(variance);

    // Moving range estimate
    const mr: number[] = [];
    for (let i = 1; i < n; i++) mr.push(Math.abs(vals[i] - vals[i - 1]));
    const mrBar = mr.reduce((a, b) => a + b, 0) / mr.length;
    const withinSd = mrBar / 1.128 || totalSd;

    const nominal = ms[0].nominal || 100.0;
    const upperTol = ms[0].upper_tol || 0.1;
    const lowerTol = ms[0].lower_tol || 0.1;
    const usl = nominal + Math.abs(upperTol);
    const lsl = nominal - Math.abs(lowerTol);
    const span = usl - lsl;

    const cp = span / (6 * withinSd);
    const cpu = (usl - mean) / (3 * withinSd);
    const cpl = (mean - lsl) / (3 * withinSd);
    const cpk = Math.min(cpu, cpl);

    const pp = span / (6 * totalSd);
    const ppu = (usl - mean) / (3 * totalSd);
    const ppl = (mean - lsl) / (3 * totalSd);
    const ppk = Math.min(ppu, ppl);

    const ucl = mean + 3 * withinSd;
    const lcl = mean - 3 * withinSd;

    return {
      n,
      mean,
      total_sd: totalSd,
      within_sd: withinSd,
      usl,
      lsl,
      nominal,
      Cp: cp,
      Cpk: cpk,
      Pp: pp,
      Ppk: ppk,
      ucl,
      lcl,
      center_line: mean,
      capability_rating: cpk >= 1.67 ? 'World-Class Six Sigma (Cpk ≥ 1.67)' : (cpk >= 1.33 ? 'Capable Process (Cpk ≥ 1.33)' : (cpk >= 1.0 ? 'Marginal Process' : 'Critical Non-Capable'))
    };
  });

  constructor() {
    this.loadInitialDataset();
    this.fetchRFiles();
  }

  loadInitialDataset() {
    const samples: UniversalMeasurement[] = [
      this.createMeasurementRecord(100.024, 'mm', 'length', 100.000, 0.050, -0.050, 'Laser Interferometer X9', 'SENS-OPT-801', 'Dr. Aris Thorne'),
      this.createMeasurementRecord(100.042, 'mm', 'length', 100.000, 0.050, -0.050, 'Laser Interferometer X9', 'SENS-OPT-801', 'Dr. Aris Thorne'),
      this.createMeasurementRecord(99.988, 'mm', 'length', 100.000, 0.050, -0.050, 'Laser Interferometer X9', 'SENS-OPT-801', 'Dr. Aris Thorne'),
      this.createMeasurementRecord(100.015, 'mm', 'length', 100.000, 0.050, -0.050, 'Laser Interferometer X9', 'SENS-OPT-801', 'Dr. Aris Thorne'),
      this.createMeasurementRecord(99.972, 'mm', 'length', 100.000, 0.050, -0.050, 'Laser Interferometer X9', 'SENS-OPT-801', 'Dr. Aris Thorne'),
      this.createMeasurementRecord(100.038, 'mm', 'length', 100.000, 0.050, -0.050, 'Laser Interferometer X9', 'SENS-OPT-801', 'Dr. Aris Thorne'),
      this.createMeasurementRecord(100.005, 'mm', 'length', 100.000, 0.050, -0.050, 'Laser Interferometer X9', 'SENS-OPT-801', 'Dr. Aris Thorne'),
      this.createMeasurementRecord(99.991, 'mm', 'length', 100.000, 0.050, -0.050, 'Laser Interferometer X9', 'SENS-OPT-801', 'Dr. Aris Thorne'),
      this.createMeasurementRecord(100.058, 'mm', 'length', 100.000, 0.050, -0.050, 'Laser Interferometer X9', 'SENS-OPT-801', 'Dr. Aris Thorne'),
      this.createMeasurementRecord(100.012, 'mm', 'length', 100.000, 0.050, -0.050, 'Laser Interferometer X9', 'SENS-OPT-801', 'Dr. Aris Thorne'),
      this.createMeasurementRecord(100.031, 'mm', 'length', 100.000, 0.050, -0.050, 'Laser Interferometer X9', 'SENS-OPT-801', 'Dr. Aris Thorne'),
      this.createMeasurementRecord(99.965, 'mm', 'length', 100.000, 0.050, -0.050, 'Laser Interferometer X9', 'SENS-OPT-801', 'Dr. Aris Thorne'),
    ];
    this.measurements.set(samples);
  }

  createMeasurementRecord(
    val: number,
    unit: string,
    type: string,
    nom: number,
    uTol: number,
    lTol: number,
    instrument: string,
    sensorId: string,
    operator: string
  ): UniversalMeasurement {
    const dev = val - nom;
    const pctDev = nom !== 0 ? (dev / Math.abs(nom)) * 100 : 0;
    const usl = nom + Math.abs(uTol);
    const lsl = nom - Math.abs(lTol);
    const isPass = val >= lsl && val <= usl;
    const tolStatus: ToleranceStatus = isPass ? 'PASS' : (val > usl ? 'FAIL_HIGH' : 'FAIL_LOW');

    const id = `MEAS-${Date.now().toString().slice(-6)}-${Math.floor(1000 + Math.random() * 9000)}`;

    return {
      measurement_id: id,
      timestamp: new Date().toISOString(),
      value: val,
      unit: unit,
      converted_value: unit === 'mm' ? Number((val / 25.4).toFixed(5)) : val,
      converted_unit: unit === 'mm' ? 'inch' : unit,
      measurement_type: type,
      instrument: instrument,
      sensor_id: sensorId,
      location: 'Metrology Lab CMM-01',
      reference_frame: 'ISO_CARTESIAN_3D',
      accuracy: 0.001,
      precision: 0.0005,
      resolution: 0.0001,
      uncertainty: 0.0058,
      confidence: 0.95,
      calibration_status: 'CALIBRATED',
      operator: operator,
      source: 'measured',
      data_state: 'CALIBRATED' as DataState,
      quality_status: isPass ? 'VALID' : 'SUSPECT',
      quality_score: isPass ? Math.floor(92 + Math.random() * 8) : 55,
      nominal: nom,
      upper_tol: uTol,
      lower_tol: lTol,
      tolerance_status: tolStatus,
      deviation: Number(dev.toFixed(4)),
      percentage_deviation: Number(pctDev.toFixed(3)),
      audit_trail: [
        {
          step: 'INGESTION',
          timestamp: new Date().toISOString(),
          operator: operator,
          note: `Universal measurement record initialized from ${instrument}`
        },
        {
          step: 'TOLERANCE_CHECK',
          timestamp: new Date().toISOString(),
          operator: 'Automated Metrology Engine',
          note: `GD&T conformance verified: ${tolStatus} (Dev: ${dev.toFixed(4)} ${unit})`
        }
      ]
    };
  }

  addMeasurement(m: UniversalMeasurement) {
    this.measurements.update(list => [m, ...list]);
  }

  updateMeasurement(index: number, updated: UniversalMeasurement) {
    this.measurements.update(list => {
      const copy = [...list];
      copy[index] = updated;
      return copy;
    });
  }

  deleteMeasurement(id: string) {
    this.measurements.update(list => list.filter(m => m.measurement_id !== id));
  }

  clearMeasurements() {
    this.measurements.set([]);
  }

  fetchRFiles() {
    this.http.get<{ files: RFile[] }>('/api/r-files').subscribe({
      next: res => {
        if (res?.files) this.rFiles.set(res.files);
      },
      error: () => {
        // Fallback for preview before SSR
      }
    });
  }

  loadSampleScenario(scenario: 'aerospace' | 'cleanroom' | 'automotive' | 'vibration') {
    if (scenario === 'aerospace') {
      const nom = 120.000;
      const data = [120.012, 120.008, 119.994, 120.022, 120.005, 119.988, 120.015, 120.035, 120.001, 119.995];
      const records = data.map(v => this.createMeasurementRecord(v, 'mm', 'diameter', nom, 0.030, -0.030, 'OptiScan 3D LiDAR', 'SENS-LIDAR-X2', 'Senior Metrologist K. Vance'));
      this.measurements.set(records);
    } else if (scenario === 'cleanroom') {
      const nom = 21.00;
      const data = [21.04, 21.08, 20.96, 21.12, 21.02, 20.98, 21.06, 21.15, 21.01, 20.94];
      const records = data.map(v => this.createMeasurementRecord(v, 'degC', 'temperature', nom, 0.50, -0.50, 'Fluke RTD Calibrator', 'SENS-TEMP-99', 'Lab Supervisor T. Ross'));
      this.measurements.set(records);
    } else if (scenario === 'automotive') {
      const nom = 50.000;
      const data = [50.015, 50.008, 49.992, 50.065, 50.012, 49.985, 50.004, 50.021, 50.033, 49.975];
      const records = data.map(v => this.createMeasurementRecord(v, 'mm', 'thickness', nom, 0.040, -0.040, 'Mitutoyo Digital Micrometer', 'SENS-MIC-33', 'Inspector E. Diaz'));
      this.measurements.set(records);
    } else if (scenario === 'vibration') {
      const nom = 4.50;
      const data = [4.52, 4.48, 4.55, 4.46, 4.59, 4.44, 4.51, 4.68, 4.49, 4.53];
      const records = data.map(v => this.createMeasurementRecord(v, 'm/s', 'vibration_velocity', nom, 0.20, -0.20, 'PCB Piezotronics Triaxial Accel', 'SENS-ACC-101', 'Vibration Analyst H. Chen'));
      this.measurements.set(records);
    }
  }

  recalculateAllUncertainties() {
    const U = this.expandedUncertaintyK2();
    this.measurements.update(list => {
      return list.map(m => ({
        ...m,
        uncertainty: Number(U.toFixed(5)),
        confidence: 0.95
      }));
    });
  }
}
