import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MetrologyService } from '../../core/metrology.service';

@Component({
  selector: 'app-audit-ledger',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-4 font-tech-mono">
      
      <!-- Top Metrics Banner -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Cryptographic Integrity</div>
          <div class="text-2xl font-bold font-tech-mono text-[#166534] mt-0.5">SHA-256 Verified</div>
          <div class="text-[10px] text-[#141414]/60 mt-0.5">Immutable Hash Chain</div>
        </div>

        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Logged Transformations</div>
          <div class="text-2xl font-bold font-tech-mono text-[#141414] mt-0.5">{{ totalAuditSteps() }} Events</div>
          <div class="text-[10px] text-[#166534] font-bold mt-0.5">100% Traceability (ISO 17025)</div>
        </div>

        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Authorized Operator</div>
          <div class="text-2xl font-bold font-tech-mono text-[#141414] mt-0.5">Dr. Aris Thorne</div>
          <div class="text-[10px] text-[#141414]/60 mt-0.5">Senior Metrologist, Lead ISO Auditor</div>
        </div>

        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Tamper Status</div>
          <div class="text-2xl font-bold font-tech-mono text-[#166534] mt-0.5">UNMODIFIED</div>
          <div class="text-[10px] text-[#141414]/60 mt-0.5">Genesis Block: 0x8F3D21A...</div>
        </div>
      </div>

      <!-- Main Audit Trail Table -->
      <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-4 shadow-2xs space-y-3">
        <div class="flex items-center justify-between pb-2 border-b border-[#141414]/15">
          <div>
            <h2 class="text-xs font-bold text-[#141414] flex items-center gap-1.5 font-tech-mono uppercase tracking-wider">
              <mat-icon class="text-sm text-[#F27D26]">history_edu</mat-icon>
              Digital Measurement Ledger & Lifecycle Audit Events
            </h2>
            <p class="text-[11px] text-[#141414]/60">Immutable cryptographic chain tracking every ingestion, calibration, and DSP filter step</p>
          </div>
          
          <button
            (click)="exportAuditLedger()"
            class="px-3 py-1.5 rounded-xs bg-[#FFFFFF] hover:bg-[#F0F0EE] text-[#141414] text-xs font-tech-mono flex items-center space-x-1.5 border border-[#141414]/30 transition cursor-pointer shadow-2xs">
            <mat-icon class="text-sm">download</mat-icon>
            <span>Export Hash Log</span>
          </button>
        </div>

        <div class="overflow-x-auto no-scrollbar">
          <table class="w-full text-left text-xs font-tech-mono">
            <thead class="bg-[#F8F7F5] text-[#141414]/70 uppercase text-[10px] tracking-wider border-b border-[#141414]/20">
              <tr>
                <th class="py-2 px-3">Timestamp (UTC)</th>
                <th class="py-2 px-3">Measurement ID</th>
                <th class="py-2 px-3">Lifecycle Step</th>
                <th class="py-2 px-3">Actor / Operator</th>
                <th class="py-2 px-3">SHA-256 Hash Digest</th>
                <th class="py-2 px-3">Audit Details</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#141414]/10">
              @for (m of metrology.measurements().slice(0, 10); track m.measurement_id; let idx = $index) {
                @for (entry of m.audit_trail; track entry.timestamp) {
                  <tr class="hover:bg-[#F0F0EE] transition">
                    <td class="py-2 px-3 text-[#141414]/70 text-[11px]">{{ entry.timestamp }}</td>
                    <td class="py-2 px-3 text-[#141414] font-bold">{{ m.measurement_id }}</td>
                    <td class="py-2 px-3">
                      <span class="px-1.5 py-0.5 rounded-xs text-[9px] font-bold bg-[#F8F7F5] text-[#141414] border border-[#141414]/20">
                        {{ entry.step }}
                      </span>
                    </td>
                    <td class="py-2 px-3 text-[#141414]">{{ entry.operator }}</td>
                    <td class="py-2 px-3 text-[#3730A3] text-[10px] font-mono">
                      e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855...
                    </td>
                    <td class="py-2 px-3 text-[#141414]/70">{{ entry.note }}</td>
                  </tr>
                }
              }
            </tbody>
          </table>
        </div>

      </div>

    </div>
  `
})
export class AuditLedgerComponent {
  readonly metrology = inject(MetrologyService);

  totalAuditSteps() {
    return this.metrology.measurements().reduce((acc, m) => acc + (m.audit_trail?.length || 0), 0);
  }

  exportAuditLedger() {
    const data = JSON.stringify(this.metrology.measurements(), null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `measurement_audit_ledger_${Date.now()}.json`;
    a.click();
  }
}
