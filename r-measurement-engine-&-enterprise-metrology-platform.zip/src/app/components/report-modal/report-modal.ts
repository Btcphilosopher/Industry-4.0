import { ChangeDetectionStrategy, Component, inject, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MetrologyService } from '../../core/metrology.service';

@Component({
  selector: 'app-report-modal',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-[#141414]/60 backdrop-blur-xs p-4 overflow-y-auto font-tech-mono">
      <div class="bg-[#FFFFFF] border border-[#141414]/20 rounded-xs w-full max-w-4xl max-h-[90vh] overflow-y-auto shadow-2xl flex flex-col text-[#141414]">
        
        <!-- Header -->
        <div class="p-4 border-b border-[#141414]/15 flex items-center justify-between sticky top-0 bg-[#FFFFFF] z-10">
          <div class="flex items-center space-x-3">
            <div class="w-8 h-8 rounded-xs bg-[#141414] text-[#E4E3E0] flex items-center justify-center">
              <mat-icon class="text-sm text-[#F27D26]">verified</mat-icon>
            </div>
            <div>
              <h2 class="text-sm font-bold text-[#141414] uppercase tracking-wider font-tech-mono">ISO/IEC 17025 Metrology Calibration & Inspection Certificate</h2>
              <p class="text-[11px] text-[#141414]/60">Certificate Ref: CERT-ISO17025-2026-08832</p>
            </div>
          </div>
          
          <button
            (click)="closeModal.emit()"
            class="text-[#141414]/60 hover:text-[#141414] p-1 rounded-xs hover:bg-[#F0F0EE] transition cursor-pointer">
            <mat-icon>close</mat-icon>
          </button>
        </div>

        <!-- Certificate Printable Body -->
        <div class="p-5 space-y-4 font-tech-mono text-xs text-[#141414]">
          
          <!-- Metadata Grid -->
          <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-[#F8F7F5] p-3.5 rounded-xs border border-[#141414]/15">
            <div>
              <div class="text-[10px] text-[#141414]/60 uppercase font-tech-serif italic">Issuing Metrology Lab</div>
              <div class="text-[#141414] font-bold mt-0.5">National Metrology Center</div>
              <div class="text-[10px] text-[#141414]/60">Accreditation # UKAS-7891</div>
            </div>
            <div>
              <div class="text-[10px] text-[#141414]/60 uppercase font-tech-serif italic">Customer / Facility</div>
              <div class="text-[#141414] font-bold mt-0.5">Advanced Precision Mfg Corp</div>
              <div class="text-[10px] text-[#141414]/60">Cleanroom Bay 4</div>
            </div>
            <div>
              <div class="text-[10px] text-[#141414]/60 uppercase font-tech-serif italic">Audit Date & Time</div>
              <div class="text-[#141414] font-bold mt-0.5">2026-08-31 09:30 UTC</div>
              <div class="text-[10px] text-[#141414]/60">Ambient: 20.04 °C ± 0.05 °C</div>
            </div>
            <div>
              <div class="text-[10px] text-[#141414]/60 uppercase font-tech-serif italic">Lead Metrologist</div>
              <div class="text-[#F27D26] font-bold mt-0.5">Dr. Aris Thorne</div>
              <div class="text-[10px] text-[#141414]/60">Chartered Physicist (CPhys)</div>
            </div>
          </div>

          <!-- Traceability & Standards Section -->
          <div class="space-y-1.5">
            <h3 class="font-bold text-[#141414] text-xs uppercase tracking-wider flex items-center gap-1.5">
              <mat-icon class="text-xs text-[#F27D26]">link</mat-icon>
              Traceability of Primary Standards
            </h3>
            <p class="text-[#141414]/70 text-[11px] leading-relaxed">
              The measurements recorded in this certificate are traceable to the International System of Units (SI) through 
              NIST and UKAS reference calibration standards (Gauge Block Set Cal #NIST-GB-2026-01, Fluke Reference RTD Probe #F1524-78).
            </p>
          </div>

          <!-- Metrological Results Summary Table -->
          <div class="space-y-1.5">
            <h3 class="font-bold text-[#141414] text-xs uppercase tracking-wider flex items-center gap-1.5">
              <mat-icon class="text-xs text-[#166534]">checklist</mat-icon>
              Summary of Conformance & Expanded Uncertainty
            </h3>
            
            <div class="overflow-x-auto border border-[#141414]/15 rounded-xs">
              <table class="w-full text-left text-xs font-tech-mono">
                <thead class="bg-[#F8F7F5] text-[#141414]/70 uppercase text-[10px] border-b border-[#141414]/20">
                  <tr>
                    <th class="p-2">Characteristic</th>
                    <th class="p-2">Nominal</th>
                    <th class="p-2">Observed Mean</th>
                    <th class="p-2">Combined u_c</th>
                    <th class="p-2">Expanded U (k=2)</th>
                    <th class="p-2">Process Cpk</th>
                    <th class="p-2">Verdict</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-[#141414]/10">
                  <tr class="hover:bg-[#F0F0EE]">
                    <td class="p-2 font-bold text-[#141414]">Length / Diameter (mm)</td>
                    <td class="p-2 text-[#141414]/80">100.000 mm</td>
                    <td class="p-2 text-[#141414] font-bold">{{ metrology.spcMetrics()?.mean?.toFixed(4) || '100.0150' }} mm</td>
                    <td class="p-2 text-[#141414]/80">±{{ metrology.combinedStandardUncertainty().toFixed(5) }} mm</td>
                    <td class="p-2 text-[#D97706] font-bold">±{{ metrology.expandedUncertaintyK2().toFixed(5) }} mm</td>
                    <td class="p-2 text-[#141414] font-bold">{{ metrology.spcMetrics()?.Cpk?.toFixed(2) || '1.45' }}</td>
                    <td class="p-2">
                      <span class="px-1.5 py-0.5 rounded-xs text-[9px] font-bold bg-[#DCFCE7] text-[#166534] border border-[#BBF7D0]">
                        CONFORMING
                      </span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <!-- Statement of Compliance ISO 14253-1 -->
          <div class="bg-[#F8F7F5] p-3 rounded-xs border border-[#141414]/15 space-y-1">
            <h4 class="font-bold text-xs text-[#141414] uppercase tracking-wider">ISO 14253-1 Decision Rule & Guardbanding</h4>
            <p class="text-[#141414]/70 text-[11px] leading-relaxed">
              Conformity with specification has been assessed using ISO 14253-1 guardbanded acceptance rules. 
              The expanded uncertainty interval (k=2, 95.45% coverage probability) is completely encompassed within the lower and upper specification limits (USL = 100.050 mm, LSL = 99.950 mm).
            </p>
          </div>

        </div>

        <!-- Footer Actions -->
        <div class="p-4 border-t border-[#141414]/15 flex items-center justify-between sticky bottom-0 bg-[#FFFFFF] z-10">
          <div class="text-[10px] text-[#141414]/60 font-tech-mono">
            Digital Signature: <span class="text-[#141414] font-bold">SHA-256 (0x7F9A1...4D2B)</span>
          </div>

          <div class="flex items-center space-x-2.5">
            <button
              (click)="printReport()"
              class="px-3 py-1.5 rounded-xs bg-[#141414] hover:bg-[#262626] text-[#E4E3E0] font-bold text-xs flex items-center space-x-1.5 border border-[#141414] transition cursor-pointer shadow-2xs">
              <mat-icon class="text-sm text-[#F27D26]">print</mat-icon>
              <span>Print / Save PDF</span>
            </button>

            <button
              (click)="closeModal.emit()"
              class="px-3 py-1.5 rounded-xs bg-[#FFFFFF] hover:bg-[#F0F0EE] text-[#141414] font-medium text-xs border border-[#141414]/30 transition cursor-pointer shadow-2xs">
              Close
            </button>
          </div>
        </div>

      </div>
    </div>
  `
})
export class ReportModalComponent {
  readonly metrology = inject(MetrologyService);
  readonly closeModal = output<void>();

  printReport() {
    window.print();
  }
}
