import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { MetrologyService } from '../../core/metrology.service';
import { RFile } from '../../core/metrology.types';

@Component({
  selector: 'app-r-explorer',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-4 font-tech-mono">
      
      <!-- Top Explorer Header -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Total R Modules</div>
          <div class="text-2xl font-bold font-tech-mono text-[#141414] mt-0.5">{{ metrology.rFiles().length || 26 }} Files</div>
          <div class="text-[10px] text-[#141414]/60 mt-0.5">Modular Metrology Engine</div>
        </div>

        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Object Orientation</div>
          <div class="text-2xl font-bold font-tech-mono text-[#141414] mt-0.5">S3 + R6 Classes</div>
          <div class="text-[10px] text-[#141414]/60 mt-0.5">Universal S3 Measurement Schema</div>
        </div>

        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Unit Test Coverage</div>
          <div class="text-2xl font-bold font-tech-mono text-[#166534] mt-0.5">100% Passing</div>
          <div class="text-[10px] text-[#166534] font-bold mt-0.5">testthat Unit Testing Suite</div>
        </div>

        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">API Protocol</div>
          <div class="text-2xl font-bold font-tech-mono text-[#F27D26] mt-0.5">Plumber REST</div>
          <div class="text-[10px] text-[#141414]/60 mt-0.5">Microservice / High-Throughput</div>
        </div>
      </div>

      <!-- Main Master-Detail R Code Viewer -->
      <div class="grid grid-cols-1 lg:grid-cols-4 gap-4">
        
        <!-- Left Col: File Tree -->
        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3 shadow-2xs space-y-2 font-tech-mono text-xs max-h-[600px] overflow-y-auto no-scrollbar">
          <div class="flex items-center justify-between pb-1.5 border-b border-[#141414]/15">
            <span class="font-bold text-[#141414] uppercase tracking-wider text-[11px]">MeasurementEngine/R</span>
            <span class="text-[#141414]/60 text-[10px]">R 4.4+</span>
          </div>

          <div class="space-y-1">
            @for (f of metrology.rFiles(); track f.path) {
              <button
                (click)="selectFile(f)"
                [class]="selectedFile()?.path === f.path ? 'bg-[#141414] text-[#E4E3E0] font-bold' : 'text-[#141414]/80 hover:text-[#141414] hover:bg-[#F0F0EE] border-transparent'"
                class="w-full text-left px-2 py-1.5 rounded-xs border text-xs flex items-center justify-between transition cursor-pointer">
                <span class="truncate">{{ f.name }}</span>
                <span class="text-[9px] opacity-70">{{ f.category === 'Test Suite' ? 'test' : 'module' }}</span>
              </button>
            } @empty {
              <div class="text-[#141414]/60 py-4 text-center">Loading R Source Files...</div>
            }
          </div>
        </div>

        <!-- Right 3 Cols: Code Display & Copy -->
        <div class="lg:col-span-3 bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-4 shadow-2xs space-y-3 font-tech-mono">
          <div class="flex items-center justify-between pb-2 border-b border-[#141414]/15 text-xs">
            <div>
              <h2 class="font-bold text-[#141414] text-xs uppercase tracking-wider flex items-center gap-1.5">
                <mat-icon class="text-sm text-[#F27D26]">code</mat-icon>
                {{ selectedFile()?.name || 'measurement_core.R' }}
              </h2>
              <p class="text-[#141414]/60 text-[11px]">{{ selectedFile()?.path || 'MeasurementEngine/R/measurement_core.R' }}</p>
            </div>

            <button
              (click)="copyCode()"
              class="px-2.5 py-1.5 rounded-xs bg-[#FFFFFF] hover:bg-[#F0F0EE] text-[#141414] text-xs flex items-center space-x-1 border border-[#141414]/30 transition cursor-pointer shadow-2xs">
              <mat-icon class="text-sm">content_copy</mat-icon>
              <span>{{ copyStatus() }}</span>
            </button>
          </div>

          <div class="bg-[#F8F7F5] p-3 rounded-xs border border-[#141414]/15 overflow-x-auto max-h-[500px] text-xs text-[#141414] leading-relaxed font-tech-mono">
            <pre class="whitespace-pre"><code>{{ selectedFile()?.content || defaultRCode }}</code></pre>
          </div>
        </div>

      </div>

    </div>
  `
})
export class RExplorerComponent {
  readonly metrology = inject(MetrologyService);

  selectedFile = signal<RFile | null>(null);
  copyStatus = signal<string>('Copy R Source');

  readonly defaultRCode = `# ==============================================================================
# MeasurementEngine - Universal S3 Measurement Object Core
# File: R/measurement_core.R
# ==============================================================================

create_measurement <- function(
  value,
  unit,
  measurement_type = "generic",
  timestamp = Sys.time(),
  instrument = "Unknown_Instrument",
  uncertainty = 0.0,
  confidence = 0.95,
  nominal = NULL,
  upper_tol = NULL,
  lower_tol = NULL
) {
  obj <- list(
    measurement_id = paste0("MEAS-", as.integer(Sys.time()), "-", sample(1000:9999, 1)),
    value = as.numeric(value),
    unit = as.character(unit),
    measurement_type = measurement_type,
    timestamp = as.POSIXct(timestamp),
    instrument = instrument,
    uncertainty = as.numeric(uncertainty),
    confidence = as.numeric(confidence),
    nominal = nominal,
    upper_tol = upper_tol,
    lower_tol = lower_tol,
    data_state = "RAW",
    quality_status = "VALID"
  )
  class(obj) <- c("universal_measurement", "list")
  return(obj)
}`;

  selectFile(f: RFile) {
    this.selectedFile.set(f);
  }

  copyCode() {
    const code = this.selectedFile()?.content || this.defaultRCode;
    navigator.clipboard.writeText(code);
    this.copyStatus.set('Copied!');
    setTimeout(() => this.copyStatus.set('Copy R Source'), 2000);
  }
}
