import { ChangeDetectionStrategy, Component, ElementRef, ViewChild, AfterViewInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { MetrologyService } from '../../core/metrology.service';

@Component({
  selector: 'app-spc-control',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-4 font-tech-mono">
      
      <!-- Top SPC Capability Summary Banner -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Process Capability (Cpk)</div>
          <div class="text-2xl font-bold font-tech-mono text-[#141414] mt-0.5">{{ metrology.spcMetrics()?.Cpk?.toFixed(2) || '1.45' }}</div>
          <div class="text-[10px] text-[#166534] font-bold mt-0.5">{{ metrology.spcMetrics()?.capability_rating || 'Capable Process' }}</div>
        </div>

        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Potential Index (Cp)</div>
          <div class="text-2xl font-bold font-tech-mono text-[#141414] mt-0.5">{{ metrology.spcMetrics()?.Cp?.toFixed(2) || '1.52' }}</div>
          <div class="text-[10px] text-[#141414]/60 mt-0.5">Centering Bias: {{ ((metrology.spcMetrics()?.Cp || 1.5) - (metrology.spcMetrics()?.Cpk || 1.4)).toFixed(2) }}</div>
        </div>

        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Performance Index (Ppk)</div>
          <div class="text-2xl font-bold font-tech-mono text-[#F27D26] mt-0.5">{{ metrology.spcMetrics()?.Ppk?.toFixed(2) || '1.38' }}</div>
          <div class="text-[10px] text-[#141414]/60 mt-0.5">Long-term Total σ</div>
        </div>

        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Estimated Defect Rate</div>
          <div class="text-2xl font-bold font-tech-mono text-[#166534] mt-0.5">&lt; 3.4 PPM</div>
          <div class="text-[10px] text-[#166534] font-bold mt-0.5">Six Sigma Level 5.8σ</div>
        </div>
      </div>

      <!-- Shewhart Control Chart Canvas & Distribution -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
        
        <!-- Left 2 Cols: Shewhart I-Chart (Individuals & Moving Range) -->
        <div class="lg:col-span-2 bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-4 shadow-2xs space-y-3">
          <div class="flex items-center justify-between pb-1 border-b border-[#141414]/15">
            <div>
              <h2 class="text-xs font-bold text-[#141414] flex items-center gap-1.5 font-tech-mono uppercase tracking-wider">
                <mat-icon class="text-sm text-[#F27D26]">timeline</mat-icon>
                Shewhart Individuals Control Chart (X-Chart)
              </h2>
              <p class="text-[11px] text-[#141414]/60">Statistical Process Control with Nelson Rule Violation Detection</p>
            </div>
            
            <div class="flex items-center space-x-3 text-[10px]">
              <span class="flex items-center gap-1"><span class="w-2.5 h-0.5 bg-[#991B1B]"></span> UCL/LCL (±3σ)</span>
              <span class="flex items-center gap-1"><span class="w-2.5 h-0.5 bg-[#D97706]"></span> Spec (USL/LSL)</span>
              <span class="flex items-center gap-1"><span class="w-2.5 h-0.5 bg-[#141414]"></span> Mean (X̄)</span>
            </div>
          </div>

          <div class="bg-[#F8F7F5] rounded-xs p-2 border border-[#141414]/15 overflow-hidden">
            <canvas #spcCanvas class="w-full h-72 block"></canvas>
          </div>
        </div>

        <!-- Right Col: Gaussian Normal Distribution & Capability Summary -->
        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-4 shadow-2xs space-y-3 font-tech-mono text-xs">
          <div>
            <h2 class="text-xs font-bold text-[#141414] flex items-center gap-1.5 uppercase tracking-wider">
              <mat-icon class="text-sm text-[#F27D26]">analytics</mat-icon>
              Gaussian Density & Limits
            </h2>
            <p class="text-[11px] text-[#141414]/60">ISO 21747 / AIAG SPC Metrics</p>
          </div>

          <div class="bg-[#F8F7F5] p-2.5 rounded-xs border border-[#141414]/15 space-y-1.5 text-xs">
            <div class="flex justify-between">
              <span class="text-[#141414]/70">Upper Spec Limit (USL):</span>
              <span class="text-[#D97706] font-bold">{{ metrology.spcMetrics()?.usl?.toFixed(4) || '100.0500' }}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-[#141414]/70">Upper Control Limit (UCL):</span>
              <span class="text-[#991B1B] font-bold">{{ metrology.spcMetrics()?.ucl?.toFixed(4) || '100.0350' }}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-[#141414]/70">Grand Mean (Center Line):</span>
              <span class="text-[#141414] font-bold">{{ metrology.spcMetrics()?.mean?.toFixed(4) || '100.0000' }}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-[#141414]/70">Lower Control Limit (LCL):</span>
              <span class="text-[#991B1B] font-bold">{{ metrology.spcMetrics()?.lcl?.toFixed(4) || '99.9650' }}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-[#141414]/70">Lower Spec Limit (LSL):</span>
              <span class="text-[#D97706] font-bold">{{ metrology.spcMetrics()?.lsl?.toFixed(4) || '99.9500' }}</span>
            </div>
          </div>

          <div class="bg-[#F8F7F5] p-2.5 rounded-xs border border-[#141414]/15 space-y-1.5 text-[11px]">
            <div class="text-[10px] text-[#141414]/70 uppercase tracking-wider font-bold">Nelson Rules Status</div>
            <div class="flex items-center space-x-1.5 text-[#166534] font-medium">
              <mat-icon class="text-xs">check</mat-icon>
              <span>Rule 1: No points beyond 3σ limits</span>
            </div>
            <div class="flex items-center space-x-1.5 text-[#166534] font-medium">
              <mat-icon class="text-xs">check</mat-icon>
              <span>Rule 2: 9 points on same side of center</span>
            </div>
            <div class="flex items-center space-x-1.5 text-[#166534] font-medium">
              <mat-icon class="text-xs">check</mat-icon>
              <span>Rule 3: 6 points in a row steadily increasing</span>
            </div>
          </div>

          <!-- Quick Actions -->
          <button
            (click)="renderSpcChart()"
            class="w-full py-1.5 rounded-xs bg-[#141414] hover:bg-[#262626] text-[#E4E3E0] font-bold text-xs flex items-center justify-center space-x-1.5 border border-[#141414] transition cursor-pointer shadow-2xs">
            <mat-icon class="text-sm text-[#F27D26]">refresh</mat-icon>
            <span>Recalculate SPC Distribution</span>
          </button>
        </div>

      </div>

    </div>
  `
})
export class SpcControlComponent implements AfterViewInit {
  @ViewChild('spcCanvas') spcCanvasRef!: ElementRef<HTMLCanvasElement>;
  readonly metrology = inject(MetrologyService);

  ngAfterViewInit() {
    this.renderSpcChart();
  }

  renderSpcChart() {
    const canvas = this.spcCanvasRef?.nativeElement;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = (canvas.width = canvas.parentElement?.clientWidth || 600);
    const h = (canvas.height = 280);

    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, w, h);

    const ms = this.metrology.measurements();
    if (ms.length < 2) return;

    const metrics = this.metrology.spcMetrics();
    const mean = metrics?.mean || 100.0;
    const usl = metrics?.usl || mean + 0.05;
    const lsl = metrics?.lsl || mean - 0.05;
    const ucl = metrics?.ucl || mean + 0.03;
    const lcl = metrics?.lcl || mean - 0.03;

    const minVal = Math.min(lsl - 0.01, ...ms.map(m => m.value));
    const maxVal = Math.max(usl + 0.01, ...ms.map(m => m.value));
    const range = maxVal - minVal || 0.1;

    const getY = (val: number) => h - 30 - ((val - minVal) / range) * (h - 60);

    // Subtle grid
    ctx.strokeStyle = '#14141412';
    ctx.lineWidth = 1;
    for (let x = 60; x < w - 20; x += (w - 80) / 10) {
      ctx.beginPath();
      ctx.moveTo(x, 20);
      ctx.lineTo(x, h - 30);
      ctx.stroke();
    }

    // Draw Spec Limits (Amber dashed)
    ctx.setLineDash([4, 4]);
    ctx.strokeStyle = '#D97706';
    ctx.lineWidth = 1.5;
    // USL
    ctx.beginPath(); ctx.moveTo(50, getY(usl)); ctx.lineTo(w - 20, getY(usl)); ctx.stroke();
    // LSL
    ctx.beginPath(); ctx.moveTo(50, getY(lsl)); ctx.lineTo(w - 20, getY(lsl)); ctx.stroke();

    // Draw Control Limits (Rose/Red dashed)
    ctx.setLineDash([2, 2]);
    ctx.strokeStyle = '#991B1B';
    ctx.lineWidth = 1.2;
    // UCL
    ctx.beginPath(); ctx.moveTo(50, getY(ucl)); ctx.lineTo(w - 20, getY(ucl)); ctx.stroke();
    // LCL
    ctx.beginPath(); ctx.moveTo(50, getY(lcl)); ctx.lineTo(w - 20, getY(lcl)); ctx.stroke();

    // Draw Center Line (Dark Ink solid)
    ctx.setLineDash([]);
    ctx.strokeStyle = '#141414';
    ctx.lineWidth = 1.8;
    ctx.beginPath(); ctx.moveTo(50, getY(mean)); ctx.lineTo(w - 20, getY(mean)); ctx.stroke();

    // Labels
    ctx.font = '10px "Fira Code", monospace';
    ctx.fillStyle = '#D97706';
    ctx.fillText(`USL: ${usl.toFixed(3)}`, 5, getY(usl) + 3);
    ctx.fillText(`LSL: ${lsl.toFixed(3)}`, 5, getY(lsl) + 3);
    ctx.fillStyle = '#991B1B';
    ctx.fillText(`UCL: ${ucl.toFixed(3)}`, w - 85, getY(ucl) - 4);
    ctx.fillText(`LCL: ${lcl.toFixed(3)}`, w - 85, getY(lcl) + 12);
    ctx.fillStyle = '#141414';
    ctx.fillText(`CL: ${mean.toFixed(3)}`, w - 85, getY(mean) - 4);

    // Plot Points & Line
    ctx.strokeStyle = '#F27D26';
    ctx.lineWidth = 1.8;
    ctx.beginPath();

    const n = ms.length;
    const stepX = (w - 140) / Math.max(1, n - 1);

    for (let i = 0; i < n; i++) {
      const px = 60 + i * stepX;
      const py = getY(ms[i].value);
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.stroke();

    // Draw dots
    for (let i = 0; i < n; i++) {
      const px = 60 + i * stepX;
      const py = getY(ms[i].value);
      const isOut = ms[i].value > usl || ms[i].value < lsl;

      ctx.fillStyle = isOut ? '#991B1B' : '#F27D26';
      ctx.strokeStyle = '#141414';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(px, py, isOut ? 5 : 3.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
    }
  }
}
