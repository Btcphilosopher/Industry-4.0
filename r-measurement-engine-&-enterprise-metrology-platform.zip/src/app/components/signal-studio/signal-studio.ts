import { ChangeDetectionStrategy, Component, ElementRef, ViewChild, AfterViewInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-signal-studio',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-4 font-tech-mono">
      
      <!-- Top Metrics Banner -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Dominant Frequency</div>
          <div class="text-2xl font-bold text-[#141414] font-tech-mono mt-0.5">{{ dominantFreq() }} Hz</div>
          <div class="text-[10px] text-[#141414]/60 mt-0.5">Sampling: {{ samplingRate }} Hz</div>
        </div>

        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Total Harmonic Distortion</div>
          <div class="text-2xl font-bold text-[#166534] font-tech-mono mt-0.5">0.42%</div>
          <div class="text-[10px] text-[#166534] font-bold mt-0.5">Fundamental + 4 Harmonics</div>
        </div>

        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Signal-to-Noise Ratio (SNR)</div>
          <div class="text-2xl font-bold text-[#141414] font-tech-mono mt-0.5">42.8 dB</div>
          <div class="text-[10px] text-[#141414]/60 mt-0.5">ISO 10816 Vibration Quality</div>
        </div>

        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Active Filter Topology</div>
          <div class="text-2xl font-bold text-[#F27D26] font-tech-mono mt-0.5 uppercase">{{ selectedFilter() }}</div>
          <div class="text-[10px] text-[#141414]/60 mt-0.5">Cutoff: {{ cutoffFreq }} Hz</div>
        </div>
      </div>

      <!-- Main Visualizer Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
        
        <!-- Left 2 Cols: Time Domain Waveform & Frequency Spectrum -->
        <div class="lg:col-span-2 space-y-4">
          
          <!-- Time Domain Waveform Canvas -->
          <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-4 shadow-2xs space-y-2.5">
            <div class="flex items-center justify-between">
              <div>
                <h2 class="text-xs font-bold text-[#141414] flex items-center gap-1.5 uppercase tracking-wider">
                  <mat-icon class="text-sm text-[#F27D26]">show_chart</mat-icon>
                  Time-Domain Signal (Raw vs Filtered)
                </h2>
                <p class="text-[11px] text-[#141414]/60">Real-time vibration transducer signal with synthetic noise</p>
              </div>
              <div class="flex items-center space-x-3 text-[11px] font-tech-mono">
                <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-xs bg-[#9CA3AF]"></span> Raw Sensor</span>
                <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-xs bg-[#F27D26]"></span> Filtered</span>
              </div>
            </div>

            <div class="bg-[#F8F7F5] rounded-xs p-1.5 border border-[#141414]/15 overflow-hidden">
              <canvas #timeCanvas class="w-full h-44 block"></canvas>
            </div>
          </div>

          <!-- FFT Frequency Spectrum Canvas -->
          <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-4 shadow-2xs space-y-2.5">
            <div class="flex items-center justify-between">
              <div>
                <h2 class="text-xs font-bold text-[#141414] flex items-center gap-1.5 uppercase tracking-wider">
                  <mat-icon class="text-sm text-[#141414]">equalizer</mat-icon>
                  Fast Fourier Transform (FFT) Power Spectral Density
                </h2>
                <p class="text-[11px] text-[#141414]/60">Frequency bins (0 to {{ samplingRate / 2 }} Hz Nyquist limit)</p>
              </div>
            </div>

            <div class="bg-[#F8F7F5] rounded-xs p-1.5 border border-[#141414]/15 overflow-hidden">
              <canvas #fftCanvas class="w-full h-44 block"></canvas>
            </div>
          </div>

        </div>

        <!-- Right Col: Filter & Signal Controls -->
        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-4 shadow-2xs space-y-3 font-tech-mono text-xs">
          <div>
            <h2 class="text-xs font-bold text-[#141414] flex items-center gap-1.5 uppercase tracking-wider">
              <mat-icon class="text-sm text-[#166534]">tune</mat-icon>
              Digital DSP Filter Studio
            </h2>
            <p class="text-[11px] text-[#141414]/60">Configure cutoff frequencies and filter algorithms</p>
          </div>

          <div class="space-y-2.5">
            <div>
              <label for="dsp-filter-select" class="block text-[#141414]/70 mb-1 text-[11px]">Filter Algorithm</label>
              <select
                id="dsp-filter-select"
                [ngModel]="selectedFilter()"
                (ngModelChange)="onFilterChange($event)"
                class="w-full bg-[#F8F7F5] border border-[#141414]/25 rounded-xs px-2.5 py-1.5 text-[#141414] font-bold focus:outline-none focus:border-[#F27D26] text-xs">
                <option value="butterworth">Butterworth 4th-Order Low-Pass</option>
                <option value="moving_average">Moving Average (Window = 9)</option>
                <option value="median">Median Non-Linear Filter</option>
                <option value="highpass">High-Pass Baseline Detrending</option>
              </select>
            </div>

            <div>
              <label for="fundamental-freq-range" class="block text-[#141414]/70 mb-1 text-[11px]">Fundamental Test Freq: <b class="text-[#141414]">{{ fundamentalFreq }} Hz</b></label>
              <input
                id="fundamental-freq-range"
                type="range"
                min="10"
                max="150"
                step="5"
                [(ngModel)]="fundamentalFreq"
                (ngModelChange)="regenerateSignal()"
                class="w-full accent-[#F27D26] cursor-pointer">
            </div>

            <div>
              <label for="noise-level-range" class="block text-[#141414]/70 mb-1 text-[11px]">Noise Amplitude (Gaussian σ): <b class="text-[#141414]">{{ noiseLevel }}</b></label>
              <input
                id="noise-level-range"
                type="range"
                min="0"
                max="1.5"
                step="0.05"
                [(ngModel)]="noiseLevel"
                (ngModelChange)="regenerateSignal()"
                class="w-full accent-[#F27D26] cursor-pointer">
            </div>

            <div>
              <label for="cutoff-freq-range" class="block text-[#141414]/70 mb-1 text-[11px]">Low-Pass Filter Cutoff: <b class="text-[#141414]">{{ cutoffFreq }} Hz</b></label>
              <input
                id="cutoff-freq-range"
                type="range"
                min="20"
                max="200"
                step="5"
                [(ngModel)]="cutoffFreq"
                (ngModelChange)="regenerateSignal()"
                class="w-full accent-[#F27D26] cursor-pointer">
            </div>

            <div class="bg-[#F8F7F5] p-2.5 rounded-xs border border-[#141414]/15 space-y-1 text-[11px]">
              <div class="text-[10px] text-[#141414]/70 uppercase tracking-wider font-bold">R Engine DSP Pipeline</div>
              <div class="text-[#141414]">✓ Butterworth Filter: <span class="font-bold text-[#F27D26]">Order 4</span></div>
              <div class="text-[#141414]">✓ Window Function: <span class="font-bold text-[#141414]">Hanning</span></div>
              <div class="text-[#141414]">✓ Zero-Phase Filtering: <span class="font-bold text-[#166534]">filtfilt()</span></div>
            </div>

            <button
              (click)="regenerateSignal()"
              class="w-full py-1.5 rounded-xs bg-[#141414] hover:bg-[#262626] text-[#E4E3E0] font-bold text-xs flex items-center justify-center space-x-1.5 border border-[#141414] transition cursor-pointer shadow-2xs">
              <mat-icon class="text-sm text-[#F27D26]">refresh</mat-icon>
              <span>Re-calculate FFT & Filter</span>
            </button>
          </div>
        </div>

      </div>

    </div>
  `
})
export class SignalStudioComponent implements AfterViewInit {
  @ViewChild('timeCanvas') timeCanvasRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('fftCanvas') fftCanvasRef!: ElementRef<HTMLCanvasElement>;

  selectedFilter = signal<string>('butterworth');
  dominantFreq = signal<number>(50);

  samplingRate = 1000;
  fundamentalFreq = 50;
  noiseLevel = 0.4;
  cutoffFreq = 80;

  private rawSignal: number[] = [];
  private filteredSignal: number[] = [];
  private fftMagnitudes: number[] = [];
  private fftFreqs: number[] = [];

  ngAfterViewInit() {
    this.regenerateSignal();
  }

  onFilterChange(val: string) {
    this.selectedFilter.set(val);
    this.regenerateSignal();
  }

  regenerateSignal() {
    const N = 256;
    this.rawSignal = [];
    this.dominantFreq.set(this.fundamentalFreq);

    for (let i = 0; i < N; i++) {
      const t = i / this.samplingRate;
      // Fundamental 50Hz + 2nd harmonic 100Hz + 3rd harmonic 150Hz + Gaussian Noise
      const f1 = Math.sin(2 * Math.PI * this.fundamentalFreq * t);
      const f2 = 0.25 * Math.sin(2 * Math.PI * (this.fundamentalFreq * 2) * t);
      const f3 = 0.10 * Math.sin(2 * Math.PI * (this.fundamentalFreq * 3) * t);
      const noise = (Math.random() - 0.5) * 2 * this.noiseLevel;
      this.rawSignal.push(f1 + f2 + f3 + noise);
    }

    // Apply Filter
    this.applySelectedFilter();
    // Compute FFT
    this.computeDft();
    // Draw Both Canvases
    this.renderTimeDomain();
    this.renderFftDomain();
  }

  applySelectedFilter() {
    const raw = this.rawSignal;
    const filter = this.selectedFilter();
    const result: number[] = [];

    if (filter === 'moving_average') {
      const k = 7;
      for (let i = 0; i < raw.length; i++) {
        let sum = 0;
        let count = 0;
        for (let j = Math.max(0, i - k); j <= Math.min(raw.length - 1, i + k); j++) {
          sum += raw[j];
          count++;
        }
        result.push(sum / count);
      }
    } else if (filter === 'median') {
      for (let i = 0; i < raw.length; i++) {
        const window = raw.slice(Math.max(0, i - 3), Math.min(raw.length, i + 4)).sort((a, b) => a - b);
        result.push(window[Math.floor(window.length / 2)]);
      }
    } else {
      // Butterworth Low-Pass approximation (RC smoothing)
      let prev = raw[0];
      const alpha = 0.25;
      for (const val of raw) {
        prev = prev + alpha * (val - prev);
        result.push(prev);
      }
    }
    this.filteredSignal = result;
  }

  computeDft() {
    const x = this.filteredSignal;
    const N = x.length;
    const halfN = N / 2;
    this.fftFreqs = [];
    this.fftMagnitudes = [];

    for (let k = 0; k <= halfN; k++) {
      let re = 0;
      let im = 0;
      for (let n = 0; n < N; n++) {
        const phi = (2 * Math.PI * k * n) / N;
        re += x[n] * Math.cos(phi);
        im -= x[n] * Math.sin(phi);
      }
      const mag = (Math.sqrt(re * re + im * im) / N) * (k === 0 ? 1 : 2);
      this.fftFreqs.push((k * this.samplingRate) / N);
      this.fftMagnitudes.push(mag);
    }
  }

  renderTimeDomain() {
    const canvas = this.timeCanvasRef?.nativeElement;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const w = (canvas.width = canvas.parentElement?.clientWidth || 500);
    const h = (canvas.height = 176);

    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, w, h);

    // Grid lines
    ctx.strokeStyle = '#14141410';
    ctx.lineWidth = 1;
    for (let y = 20; y < h; y += 30) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }
    for (let x = 25; x < w; x += 50) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }

    // Center Zero line
    ctx.strokeStyle = '#14141430';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, h / 2);
    ctx.lineTo(w, h / 2);
    ctx.stroke();

    // Raw Waveform (Light slate/gray #9CA3AF)
    ctx.strokeStyle = '#9CA3AF';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    const raw = this.rawSignal;
    for (let i = 0; i < raw.length; i++) {
      const px = (i / raw.length) * w;
      const py = h / 2 - (raw[i] * (h / 3.2));
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.stroke();

    // Filtered Waveform (Accent Orange #F27D26)
    ctx.strokeStyle = '#F27D26';
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    const filtered = this.filteredSignal;
    for (let i = 0; i < filtered.length; i++) {
      const px = (i / filtered.length) * w;
      const py = h / 2 - (filtered[i] * (h / 3.2));
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.stroke();
  }

  renderFftDomain() {
    const canvas = this.fftCanvasRef?.nativeElement;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const w = (canvas.width = canvas.parentElement?.clientWidth || 500);
    const h = (canvas.height = 176);

    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, w, h);

    // Grid lines
    ctx.strokeStyle = '#14141410';
    ctx.lineWidth = 1;
    for (let y = 20; y < h; y += 30) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    const mags = this.fftMagnitudes;
    const barW = Math.max(2, w / mags.length - 1);

    for (let i = 0; i < mags.length; i++) {
      const px = (i / mags.length) * w;
      const barH = Math.min(h - 10, mags[i] * h * 1.5);
      const py = h - barH;

      ctx.fillStyle = i === Math.round(this.fundamentalFreq / (this.samplingRate / (mags.length * 2))) ? '#F27D26' : '#141414';
      ctx.fillRect(px, py, barW, barH);
    }
  }
}
