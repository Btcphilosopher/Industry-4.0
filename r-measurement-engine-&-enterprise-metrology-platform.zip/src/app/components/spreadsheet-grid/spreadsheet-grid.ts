import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { MetrologyService } from '../../core/metrology.service';

@Component({
  selector: 'app-spreadsheet-grid',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-4 font-tech-mono">
      
      <!-- Top Metrics & Quick KPI Ribbon -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Total Active Records</div>
          <div class="text-2xl font-bold font-tech-mono text-[#141414] mt-0.5">{{ metrology.totalCount() }} Records</div>
          <div class="text-[10px] text-[#141414]/60 mt-0.5">Universal S3 Schema</div>
        </div>

        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Conforming Yield</div>
          <div class="text-2xl font-bold font-tech-mono text-[#166534] mt-0.5">{{ metrology.yieldPercentage() }}%</div>
          <div class="text-[10px] text-[#141414]/60 mt-0.5">{{ metrology.passCount() }} Conforming / {{ metrology.failCount() }} Out-of-Tol</div>
        </div>

        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Mean Quality Score</div>
          <div class="text-2xl font-bold font-tech-mono text-[#141414] mt-0.5">{{ metrology.averageQuality() }} / 100</div>
          <div class="text-[10px] text-[#166534] font-bold mt-0.5">NIST/GUM Calibrated</div>
        </div>

        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Expanded Uncertainty (U)</div>
          <div class="text-2xl font-bold font-tech-mono text-[#F27D26] mt-0.5">±{{ metrology.expandedUncertaintyK2().toFixed(4) }} mm</div>
          <div class="text-[10px] text-[#141414]/60 mt-0.5">Coverage k = 2.0 (95.45%)</div>
        </div>
      </div>

      <!-- Action Controls & Filter Bar -->
      <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3 shadow-2xs flex flex-wrap items-center justify-between gap-3 text-xs">
        
        <div class="flex items-center space-x-2.5 flex-1 min-w-[280px]">
          <div class="relative flex-1">
            <mat-icon class="absolute left-2.5 top-2 text-[#141414]/40 text-xs">search</mat-icon>
            <input
              id="grid-search-filter"
              type="text"
              placeholder="Search by ID, instrument, operator, state..."
              [(ngModel)]="searchQuery"
              class="w-full bg-[#F8F7F5] border border-[#141414]/20 rounded-xs pl-8 pr-3 py-1.5 text-xs text-[#141414] placeholder-[#141414]/40 focus:outline-none focus:border-[#F27D26]">
          </div>

          <select
            id="status-filter-select"
            [(ngModel)]="statusFilter"
            class="bg-[#F8F7F5] border border-[#141414]/20 rounded-xs px-2.5 py-1.5 text-xs text-[#141414] focus:outline-none focus:border-[#F27D26] cursor-pointer">
            <option value="ALL">All Statuses</option>
            <option value="PASS">PASS Only</option>
            <option value="FAIL_HIGH">FAIL High</option>
            <option value="FAIL_LOW">FAIL Low</option>
          </select>
        </div>

        <div class="flex items-center space-x-2">
          <!-- Add Single Measurement Toggle -->
          <button
            (click)="showAddForm.set(!showAddForm())"
            class="px-3 py-1.5 rounded-xs bg-[#141414] hover:bg-[#262626] text-[#E4E3E0] font-medium text-xs flex items-center space-x-1.5 transition border border-[#141414] cursor-pointer shadow-2xs">
            <mat-icon class="text-sm text-[#F27D26]">add</mat-icon>
            <span>Ingest Record</span>
          </button>

          <!-- Export JSON/CSV -->
          <button
            (click)="exportDataset()"
            class="px-3 py-1.5 rounded-xs bg-[#FFFFFF] hover:bg-[#F0F0EE] text-[#141414] font-medium text-xs flex items-center space-x-1.5 transition border border-[#141414]/30 cursor-pointer shadow-2xs">
            <mat-icon class="text-sm">download</mat-icon>
            <span>Export CSV</span>
          </button>

          <!-- Clear Button -->
          <button
            (click)="metrology.clearMeasurements()"
            class="px-2.5 py-1.5 rounded-xs bg-[#FFFFFF] hover:bg-[#FEE2E2] text-[#991B1B] font-medium text-xs flex items-center space-x-1 transition border border-[#141414]/30 cursor-pointer shadow-2xs"
            title="Clear Records">
            <mat-icon class="text-sm">delete_sweep</mat-icon>
          </button>
        </div>

      </div>

      <!-- Quick Add Ingestion Drawer -->
      @if (showAddForm()) {
        <div class="bg-[#FFFFFF] border-2 border-[#141414] rounded-xs p-4 shadow-md space-y-3 text-xs">
          <div class="flex items-center justify-between pb-2 border-b border-[#141414]/15">
            <div class="flex items-center space-x-2 text-[#141414] font-bold text-sm">
              <mat-icon class="text-sm text-[#F27D26]">input</mat-icon>
              <span>Ingest Universal S3 Measurement Object</span>
            </div>
            <button (click)="showAddForm.set(false)" class="text-[#141414]/50 hover:text-[#141414] cursor-pointer">
              <mat-icon class="text-sm">close</mat-icon>
            </button>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
            <div>
              <label for="new-record-val" class="block text-[#141414]/70 mb-1">Measured Value</label>
              <input id="new-record-val" type="number" step="0.0001" [(ngModel)]="newVal" class="w-full bg-[#F8F7F5] border border-[#141414]/20 rounded-xs px-2.5 py-1.5 text-[#141414] focus:outline-none focus:border-[#F27D26]">
            </div>
            <div>
              <label for="new-record-unit" class="block text-[#141414]/70 mb-1">SI Unit</label>
              <input id="new-record-unit" type="text" [(ngModel)]="newUnit" class="w-full bg-[#F8F7F5] border border-[#141414]/20 rounded-xs px-2.5 py-1.5 text-[#141414] focus:outline-none focus:border-[#F27D26]">
            </div>
            <div>
              <label for="new-record-nominal" class="block text-[#141414]/70 mb-1">Nominal Target</label>
              <input id="new-record-nominal" type="number" step="0.0001" [(ngModel)]="newNominal" class="w-full bg-[#F8F7F5] border border-[#141414]/20 rounded-xs px-2.5 py-1.5 text-[#141414] focus:outline-none focus:border-[#F27D26]">
            </div>
            <div>
              <label for="new-record-tol" class="block text-[#141414]/70 mb-1">Tolerance Band (±)</label>
              <input id="new-record-tol" type="number" step="0.0001" [(ngModel)]="newTol" class="w-full bg-[#F8F7F5] border border-[#141414]/20 rounded-xs px-2.5 py-1.5 text-[#141414] focus:outline-none focus:border-[#F27D26]">
            </div>
            <div>
              <label for="new-record-inst" class="block text-[#141414]/70 mb-1">Instrument</label>
              <input id="new-record-inst" type="text" [(ngModel)]="newInstrument" class="w-full bg-[#F8F7F5] border border-[#141414]/20 rounded-xs px-2.5 py-1.5 text-[#141414] focus:outline-none focus:border-[#F27D26]">
            </div>
            <div>
              <label for="new-record-type" class="block text-[#141414]/70 mb-1">Measurement Type</label>
              <input id="new-record-type" type="text" [(ngModel)]="newType" class="w-full bg-[#F8F7F5] border border-[#141414]/20 rounded-xs px-2.5 py-1.5 text-[#141414] focus:outline-none focus:border-[#F27D26]">
            </div>
            <div>
              <label for="new-record-sensor" class="block text-[#141414]/70 mb-1">Sensor Tag</label>
              <input id="new-record-sensor" type="text" [(ngModel)]="newSensor" class="w-full bg-[#F8F7F5] border border-[#141414]/20 rounded-xs px-2.5 py-1.5 text-[#141414] focus:outline-none focus:border-[#F27D26]">
            </div>
            <div>
              <label for="new-record-operator" class="block text-[#141414]/70 mb-1">Operator</label>
              <input id="new-record-operator" type="text" [(ngModel)]="newOperator" class="w-full bg-[#F8F7F5] border border-[#141414]/20 rounded-xs px-2.5 py-1.5 text-[#141414] focus:outline-none focus:border-[#F27D26]">
            </div>
          </div>

          <div class="flex justify-end space-x-2 pt-2">
            <button
              (click)="showAddForm.set(false)"
              class="px-3 py-1.5 rounded-xs bg-[#FFFFFF] hover:bg-[#F0F0EE] text-[#141414] border border-[#141414]/30 transition cursor-pointer">
              Cancel
            </button>
            <button
              (click)="submitNewMeasurement()"
              class="px-3.5 py-1.5 rounded-xs bg-[#F27D26] hover:bg-[#E06810] text-white font-bold transition cursor-pointer">
              Commit Record
            </button>
          </div>
        </div>
      }

      <!-- Interactive Data Grid -->
      <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs overflow-hidden shadow-2xs">
        <div class="overflow-x-auto no-scrollbar max-h-[580px]">
          <table class="w-full text-left text-xs font-tech-mono">
            <thead class="bg-[#F8F7F5] text-[#141414]/70 uppercase text-[10px] tracking-wider sticky top-0 z-10 border-b border-[#141414]/20 select-none">
              <tr>
                <th class="py-2.5 px-3">Status</th>
                <th class="py-2.5 px-3">Measurement ID</th>
                <th class="py-2.5 px-3">Value</th>
                <th class="py-2.5 px-3">Unit</th>
                <th class="py-2.5 px-3">Nominal</th>
                <th class="py-2.5 px-3">Deviation</th>
                <th class="py-2.5 px-3">Tolerance Limits</th>
                <th class="py-2.5 px-3">Uncertainty (U, k=2)</th>
                <th class="py-2.5 px-3">Instrument</th>
                <th class="py-2.5 px-3">Data State</th>
                <th class="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#141414]/10">
              @for (m of filteredMeasurements(); track m.measurement_id) {
                <tr
                  [class]="m.tolerance_status === 'PASS' ? 'hover:bg-[#F0F0EE]' : 'bg-[#FEE2E2]/30 hover:bg-[#FEE2E2]/50'"
                  class="transition">
                  
                  <!-- Conformance Badge -->
                  <td class="py-2.5 px-3 whitespace-nowrap">
                    @if (m.tolerance_status === 'PASS') {
                      <span class="inline-flex items-center px-2 py-0.5 rounded-xs text-[10px] font-bold bg-[#DCFCE7] text-[#166534] border border-[#BBF7D0]">
                        PASS
                      </span>
                    } @else if (m.tolerance_status === 'FAIL_HIGH') {
                      <span class="inline-flex items-center px-2 py-0.5 rounded-xs text-[10px] font-bold bg-[#FEE2E2] text-[#991B1B] border border-[#FECACA]">
                        +OUT TOL
                      </span>
                    } @else {
                      <span class="inline-flex items-center px-2 py-0.5 rounded-xs text-[10px] font-bold bg-[#FEE2E2] text-[#991B1B] border border-[#FECACA]">
                        -OUT TOL
                      </span>
                    }
                  </td>

                  <!-- ID -->
                  <td class="py-2.5 px-3 font-bold text-[#141414] whitespace-nowrap">{{ m.measurement_id }}</td>

                  <!-- Value & Inline Edit -->
                  <td class="py-2.5 px-3 font-bold text-[#141414] whitespace-nowrap">
                    <span class="text-sm">{{ m.value.toFixed(4) }}</span>
                    @if (m.converted_value && m.converted_unit) {
                      <span class="text-[10px] text-[#141414]/50 block">({{ m.converted_value }} {{ m.converted_unit }})</span>
                    }
                  </td>

                  <!-- Unit -->
                  <td class="py-2.5 px-3 text-[#141414]/70 whitespace-nowrap">{{ m.unit }}</td>

                  <!-- Nominal -->
                  <td class="py-2.5 px-3 text-[#141414]/70 whitespace-nowrap">{{ (m.nominal || 0).toFixed(4) }}</td>

                  <!-- Deviation -->
                  <td class="py-2.5 px-3 whitespace-nowrap" [class]="m.tolerance_status === 'PASS' ? 'text-[#166534] font-medium' : 'text-[#991B1B] font-bold'">
                    {{ (m.deviation || 0) >= 0 ? '+' : '' }}{{ (m.deviation || 0).toFixed(4) }}
                    <span class="text-[10px] text-[#141414]/50 block">({{ m.percentage_deviation }}%)</span>
                  </td>

                  <!-- Limits -->
                  <td class="py-2.5 px-3 text-[#141414]/70 whitespace-nowrap text-[11px]">
                    <span>[{{ ((m.nominal || 0) - Math.abs(m.lower_tol || 0.1)).toFixed(3) }} , {{ ((m.nominal || 0) + Math.abs(m.upper_tol || 0.1)).toFixed(3) }}]</span>
                  </td>

                  <!-- Uncertainty -->
                  <td class="py-2.5 px-3 text-[#F27D26] font-medium whitespace-nowrap">±{{ m.uncertainty.toFixed(4) }}</td>

                  <!-- Instrument -->
                  <td class="py-2.5 px-3 text-[#141414]/80 whitespace-nowrap">
                    <span>{{ m.instrument }}</span>
                    <span class="text-[10px] text-[#141414]/50 block">{{ m.operator }}</span>
                  </td>

                  <!-- Data State -->
                  <td class="py-2.5 px-3 whitespace-nowrap">
                    <span class="px-1.5 py-0.5 rounded-xs text-[9px] uppercase font-bold bg-[#FFEDD5] text-[#C2410C] border border-[#FED7AA]">
                      {{ m.data_state }}
                    </span>
                  </td>

                  <!-- Actions -->
                  <td class="py-2.5 px-3 text-right whitespace-nowrap">
                    <button
                      (click)="metrology.deleteMeasurement(m.measurement_id)"
                      class="text-[#141414]/40 hover:text-[#991B1B] p-1 rounded-xs transition cursor-pointer"
                      title="Delete Record">
                      <mat-icon class="text-sm">delete</mat-icon>
                    </button>
                  </td>
                </tr>
              } @empty {
                <tr>
                  <td colspan="11" class="py-8 text-center text-[#141414]/50">
                    No measurements found matching criteria. Click "Ingest Record" or load a Preset Dataset.
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

    </div>
  `
})
export class SpreadsheetGridComponent {
  readonly metrology = inject(MetrologyService);
  readonly Math = Math;

  searchQuery = '';
  statusFilter = 'ALL';
  showAddForm = signal<boolean>(false);

  // New Record Form Fields
  newVal = 100.015;
  newUnit = 'mm';
  newNominal = 100.000;
  newTol = 0.050;
  newInstrument = 'Laser Interferometer X9';
  newType = 'length';
  newSensor = 'SENS-01';
  newOperator = 'Dr. Aris Thorne';

  filteredMeasurements() {
    const query = this.searchQuery.toLowerCase();
    const status = this.statusFilter;

    return this.metrology.measurements().filter(m => {
      const matchSearch =
        m.measurement_id.toLowerCase().includes(query) ||
        m.instrument.toLowerCase().includes(query) ||
        m.operator.toLowerCase().includes(query) ||
        m.data_state.toLowerCase().includes(query);

      const matchStatus = status === 'ALL' || m.tolerance_status === status;
      return matchSearch && matchStatus;
    });
  }

  submitNewMeasurement() {
    const record = this.metrology.createMeasurementRecord(
      Number(this.newVal),
      this.newUnit,
      this.newType,
      Number(this.newNominal),
      Number(this.newTol),
      -Number(this.newTol),
      this.newInstrument,
      this.newSensor,
      this.newOperator
    );
    this.metrology.addMeasurement(record);
    this.showAddForm.set(false);
  }

  exportDataset() {
    const data = this.metrology.measurements();
    const csvRows = [
      ['Measurement_ID', 'Timestamp', 'Value', 'Unit', 'Nominal', 'Upper_Tol', 'Lower_Tol', 'Status', 'Instrument', 'Operator', 'Data_State'].join(',')
    ];
    for (const m of data) {
      csvRows.push([
        m.measurement_id,
        m.timestamp,
        m.value,
        m.unit,
        m.nominal || '',
        m.upper_tol || '',
        m.lower_tol || '',
        m.tolerance_status || '',
        `"${m.instrument}"`,
        `"${m.operator}"`,
        m.data_state
      ].join(','));
    }
    const blob = new Blob([csvRows.join('\n')], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `metrology_measurements_${Date.now()}.csv`;
    a.click();
  }
}
