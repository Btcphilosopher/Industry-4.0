import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { MetrologyService } from '../../core/metrology.service';

@Component({
  selector: 'app-uncertainty-budget',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-4 font-tech-mono">
      
      <!-- Top Metrics Banner -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Combined Std Uncertainty (u_c)</div>
          <div class="text-2xl font-bold text-[#141414] font-tech-mono mt-0.5">±{{ metrology.combinedStandardUncertainty().toFixed(5) }} mm</div>
          <div class="text-[10px] text-[#141414]/60 mt-0.5">Quadrature Sum (RSS)</div>
        </div>

        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Expanded Uncertainty (k=2.00)</div>
          <div class="text-2xl font-bold text-[#D97706] font-tech-mono mt-0.5">±{{ metrology.expandedUncertaintyK2().toFixed(5) }} mm</div>
          <div class="text-[10px] text-[#166534] font-bold mt-0.5">95.45% Coverage Probability</div>
        </div>

        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Effective Deg of Freedom (ν_eff)</div>
          <div class="text-2xl font-bold text-[#141414] font-tech-mono mt-0.5">38.4 df</div>
          <div class="text-[10px] text-[#141414]/60 mt-0.5">Welch-Satterthwaite Formula</div>
        </div>

        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Compliance Standard</div>
          <div class="text-2xl font-bold text-[#141414] font-tech-mono mt-0.5">JCGM 100:2008</div>
          <div class="text-[10px] text-[#141414]/60 mt-0.5">ISO/IEC Guide 98-3 (GUM)</div>
        </div>
      </div>

      <!-- Main Uncertainty Budget Matrix Table -->
      <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-4 shadow-2xs space-y-3">
        <div class="flex items-center justify-between pb-3 border-b border-[#141414]/15">
          <div>
            <h2 class="text-xs font-bold text-[#141414] flex items-center gap-1.5 uppercase tracking-wider">
              <mat-icon class="text-sm text-[#F27D26]">functions</mat-icon>
              GUM Comprehensive Uncertainty Budget Matrix
            </h2>
            <p class="text-[11px] text-[#141414]/60">Mathematical evaluation of all Type A and Type B uncertainty sources</p>
          </div>
          
          <button
            (click)="metrology.recalculateAllUncertainties()"
            class="px-3 py-1.5 rounded-xs bg-[#141414] hover:bg-[#262626] text-[#E4E3E0] font-bold text-xs flex items-center space-x-1.5 border border-[#141414] transition cursor-pointer shadow-2xs">
            <mat-icon class="text-sm text-[#F27D26]">sync</mat-icon>
            <span>Propagate to All Records</span>
          </button>
        </div>

        <div class="overflow-x-auto no-scrollbar border border-[#141414]/15 rounded-xs">
          <table class="w-full text-left text-xs font-tech-mono">
            <thead class="bg-[#F8F7F5] text-[#141414]/70 uppercase text-[10px] tracking-wider border-b border-[#141414]/20">
              <tr>
                <th class="py-2 px-3">Uncertainty Component</th>
                <th class="py-2 px-3">Semi-Range (±a)</th>
                <th class="py-2 px-3">PDF Distribution</th>
                <th class="py-2 px-3">Divisor</th>
                <th class="py-2 px-3">Std Uncertainty u(x_i)</th>
                <th class="py-2 px-3">Sensitivity c_i</th>
                <th class="py-2 px-3">Contrib u_i(y)</th>
                <th class="py-2 px-3">% Variance Contrib</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#141414]/10">
              @for (comp of metrology.uncertaintyComponents(); track comp.id) {
                <tr class="hover:bg-[#F0F0EE] transition">
                  <td class="py-2 px-3 text-[#141414] font-bold">{{ comp.name }}</td>
                  <td class="py-2 px-3 text-[#141414]">±{{ comp.bound.toFixed(4) }} mm</td>
                  <td class="py-2 px-3">
                    <span class="px-1.5 py-0.5 rounded-xs text-[9px] uppercase font-bold bg-[#E4E3E0] text-[#141414] border border-[#141414]/20">
                      {{ comp.distribution }}
                    </span>
                  </td>
                  <td class="py-2 px-3 text-[#141414]/70">{{ comp.divisor.toFixed(3) }}</td>
                  <td class="py-2 px-3 text-[#141414] font-bold">±{{ comp.standard_uncertainty.toFixed(6) }} mm</td>
                  <td class="py-2 px-3 text-[#141414]/70">{{ comp.sensitivity_coeff.toFixed(2) }}</td>
                  <td class="py-2 px-3 text-[#141414] font-bold">±{{ (comp.standard_uncertainty * comp.sensitivity_coeff).toFixed(6) }} mm</td>
                  <td class="py-2 px-3">
                    <div class="flex items-center space-x-2">
                      <div class="w-16 bg-[#E4E3E0] rounded-xs h-2 overflow-hidden border border-[#141414]/10">
                        <div class="bg-[#F27D26] h-full" [style.width.%]="comp.variance_contribution_pct"></div>
                      </div>
                      <span class="text-[#141414] text-[11px] font-bold">{{ comp.variance_contribution_pct.toFixed(1) }}%</span>
                    </div>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>

        <!-- Pareto Analysis Bar -->
        <div class="pt-3 border-t border-[#141414]/15 space-y-2">
          <div class="flex items-center justify-between text-xs font-tech-mono">
            <span class="text-[#141414] font-bold">Uncertainty Pareto Variance Budget Stack:</span>
            <span class="text-[#141414]/70">Total 100% Normalized</span>
          </div>
          <div class="w-full h-3 rounded-xs overflow-hidden flex bg-[#E4E3E0] border border-[#141414]/20">
            <div class="bg-[#F27D26] h-full" style="width: 35.2%" title="Repeatability 35.2%"></div>
            <div class="bg-[#141414] h-full" style="width: 2.9%" title="Gauge Block 2.9%"></div>
            <div class="bg-[#D97706] h-full" style="width: 1.0%" title="Resolution 1.0%"></div>
            <div class="bg-[#166534] h-full" style="width: 60.9%" title="Thermal Expansion 60.9%"></div>
          </div>
          <div class="flex flex-wrap gap-4 text-[10px] font-tech-mono text-[#141414]/80 pt-0.5">
            <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-xs bg-[#F27D26]"></span> Repeatability (35.2%)</span>
            <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-xs bg-[#141414]"></span> Calibration Standard (2.9%)</span>
            <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-xs bg-[#D97706]"></span> Resolution (1.0%)</span>
            <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-xs bg-[#166534]"></span> Thermal Expansion (60.9%)</span>
          </div>
        </div>

      </div>

    </div>
  `
})
export class UncertaintyBudgetComponent {
  readonly metrology = inject(MetrologyService);
}
