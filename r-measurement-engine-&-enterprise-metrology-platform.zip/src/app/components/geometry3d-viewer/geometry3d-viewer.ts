import { ChangeDetectionStrategy, Component, ElementRef, ViewChild, AfterViewInit, OnDestroy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';

interface Point3D {
  x: number;
  y: number;
  z: number;
  deviation: number; // in mm vs CAD target
}

@Component({
  selector: 'app-geometry3d-viewer',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-4 font-tech-mono">
      
      <!-- 3D Metrology Studio Header -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Total Point Density</div>
          <div class="text-2xl font-bold text-[#141414] font-tech-mono mt-0.5">{{ points().length }} Points</div>
          <div class="text-[10px] text-[#166534] font-bold mt-0.5">Spatial Resolution: 0.1 mm</div>
        </div>

        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">CAD Target Primitive</div>
          <div class="text-2xl font-bold text-[#141414] font-tech-mono mt-0.5 capitalize">{{ selectedPrimitive() }}</div>
          <div class="text-[10px] text-[#141414]/60 mt-0.5">RANSAC Fit RMS: 0.008 mm</div>
        </div>

        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Max Peak Deviation (+Δ)</div>
          <div class="text-2xl font-bold text-[#991B1B] font-tech-mono mt-0.5">+0.042 mm</div>
          <div class="text-[10px] text-[#141414]/60 mt-0.5">Tolerance Band: ±0.050 mm</div>
        </div>

        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Surface Conformance</div>
          <div class="text-2xl font-bold text-[#166534] font-tech-mono mt-0.5">98.4%</div>
          <div class="text-[10px] text-[#166534] font-bold mt-0.5">In-Tolerance Surface Area</div>
        </div>
      </div>

      <!-- Main Canvas & Controls Area -->
      <div class="grid grid-cols-1 lg:grid-cols-4 gap-4">
        
        <!-- 3D Interactive Canvas -->
        <div class="lg:col-span-3 bg-[#FFFFFF] border border-[#141414]/15 rounded-xs overflow-hidden relative shadow-2xs flex flex-col items-center justify-center min-h-[500px]">
          
          <!-- Floating Overlay Toolbar -->
          <div class="absolute top-3 left-3 z-10 flex items-center space-x-1.5 bg-[#FFFFFF]/90 backdrop-blur-xs border border-[#141414]/20 rounded-xs p-1 text-xs">
            <button
              (click)="setPrimitive('cylinder')"
              [class]="selectedPrimitive() === 'cylinder' ? 'bg-[#141414] text-[#E4E3E0] font-bold' : 'text-[#141414]/70 hover:text-[#141414]'"
              class="px-2 py-1 rounded-xs transition cursor-pointer text-xs">
              Precision Cylinder
            </button>
            <button
              (click)="setPrimitive('sphere')"
              [class]="selectedPrimitive() === 'sphere' ? 'bg-[#141414] text-[#E4E3E0] font-bold' : 'text-[#141414]/70 hover:text-[#141414]'"
              class="px-2 py-1 rounded-xs transition cursor-pointer text-xs">
              Bearing Sphere
            </button>
            <button
              (click)="setPrimitive('surface')"
              [class]="selectedPrimitive() === 'surface' ? 'bg-[#141414] text-[#E4E3E0] font-bold' : 'text-[#141414]/70 hover:text-[#141414]'"
              class="px-2 py-1 rounded-xs transition cursor-pointer text-xs">
              Airfoil Surface
            </button>
          </div>

          <!-- Color Heatmap Scale Legend -->
          <div class="absolute bottom-3 right-3 z-10 bg-[#FFFFFF]/90 backdrop-blur-xs border border-[#141414]/20 rounded-xs p-2.5 text-xs font-tech-mono shadow-2xs">
            <div class="text-[10px] text-[#141414]/70 uppercase tracking-wider mb-1 font-bold">Deviation Heatmap (mm)</div>
            <div class="h-2.5 w-44 rounded-xs bg-gradient-to-r from-[#0284C7] via-[#166534] via-[#D97706] to-[#991B1B]"></div>
            <div class="flex justify-between text-[9px] text-[#141414]/80 mt-1">
              <span>-0.05 (Under)</span>
              <span>0.00 (Nom)</span>
              <span>+0.05 (Over)</span>
            </div>
          </div>

          <!-- 3D Canvas Element -->
          <canvas
            #metrologyCanvas
            (mousedown)="startDrag($event)"
            (mousemove)="onDrag($event)"
            (mouseup)="stopDrag()"
            (mouseleave)="stopDrag()"
            (wheel)="onWheel($event)"
            class="w-full h-[520px] cursor-grab active:cursor-grabbing block">
          </canvas>
        </div>

        <!-- 3D Inspection & GD&T Analytics Side Panel -->
        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-4 shadow-2xs space-y-3 font-tech-mono text-xs">
          <div>
            <h2 class="text-xs font-bold text-[#141414] flex items-center gap-1.5 uppercase tracking-wider">
              <mat-icon class="text-sm text-[#F27D26]">view_in_ar</mat-icon>
              3D Alignment & GD&T
            </h2>
            <p class="text-[11px] text-[#141414]/60">PCA Datum Fitting & Form Evaluation</p>
          </div>

          <div class="space-y-2.5 pt-1">
            <div class="bg-[#F8F7F5] p-2.5 rounded-xs border border-[#141414]/15 space-y-1">
              <div class="text-[10px] text-[#141414]/70 uppercase tracking-wider font-bold">Centroid Coordinates</div>
              <div class="text-[#141414] font-bold text-xs">X: 0.000 | Y: 0.000 | Z: 50.000 mm</div>
            </div>

            <div class="bg-[#F8F7F5] p-2.5 rounded-xs border border-[#141414]/15 space-y-1">
              <div class="text-[10px] text-[#141414]/70 uppercase tracking-wider font-bold">Form Deviations (ISO 1101)</div>
              <div class="flex justify-between text-[#141414]">
                <span>Cylindricity / Roundness:</span>
                <span class="text-[#166534] font-bold">0.014 mm</span>
              </div>
              <div class="flex justify-between text-[#141414]">
                <span>Straightness (Axis Z):</span>
                <span class="text-[#166534] font-bold">0.008 mm</span>
              </div>
              <div class="flex justify-between text-[#141414]">
                <span>Perpendicularity (Datum A):</span>
                <span class="text-[#166534] font-bold">0.012 mm</span>
              </div>
            </div>

            <div class="bg-[#F8F7F5] p-2.5 rounded-xs border border-[#141414]/15 space-y-1.5">
              <div class="text-[10px] text-[#141414]/70 uppercase tracking-wider font-bold">Visual Display Toggles</div>
              <label class="flex items-center space-x-2 text-[#141414] cursor-pointer">
                <input type="checkbox" [(ngModel)]="showBoundingBox" (change)="renderFrame()" class="accent-[#F27D26]">
                <span>Show Bounding Box (AABB)</span>
              </label>
              <label class="flex items-center space-x-2 text-[#141414] cursor-pointer">
                <input type="checkbox" [(ngModel)]="showNominalCAD" (change)="renderFrame()" class="accent-[#F27D26]">
                <span>Show Nominal CAD Wireframe</span>
              </label>
              <label class="flex items-center space-x-2 text-[#141414] cursor-pointer">
                <input type="checkbox" [(ngModel)]="autoRotate" (change)="toggleAutoRotate()" class="accent-[#F27D26]">
                <span>Continuous Auto-Rotation</span>
              </label>
            </div>

            <div class="pt-1">
              <button
                (click)="regeneratePointCloud()"
                class="w-full py-1.5 rounded-xs bg-[#141414] hover:bg-[#262626] text-[#E4E3E0] font-bold text-xs flex items-center justify-center space-x-1.5 border border-[#141414] transition cursor-pointer shadow-2xs">
                <mat-icon class="text-sm text-[#F27D26]">refresh</mat-icon>
                <span>Rescan / Resample LiDAR Points</span>
              </button>
            </div>
          </div>
        </div>

      </div>

    </div>
  `
})
export class Geometry3dViewerComponent implements AfterViewInit, OnDestroy {
  @ViewChild('metrologyCanvas') canvasRef!: ElementRef<HTMLCanvasElement>;

  selectedPrimitive = signal<'cylinder' | 'sphere' | 'surface'>('cylinder');
  points = signal<Point3D[]>([]);

  showBoundingBox = true;
  showNominalCAD = true;
  autoRotate = true;

  private angleX = 0.5;
  private angleY = 0.8;
  private zoom = 1.3;
  private isDragging = false;
  private lastMouseX = 0;
  private lastMouseY = 0;
  private animId: number | null = null;

  ngAfterViewInit() {
    this.generatePoints();
    this.startRenderLoop();
  }

  ngOnDestroy() {
    if (this.animId) cancelAnimationFrame(this.animId);
  }

  setPrimitive(prim: 'cylinder' | 'sphere' | 'surface') {
    this.selectedPrimitive.set(prim);
    this.generatePoints();
  }

  generatePoints() {
    const pts: Point3D[] = [];
    const prim = this.selectedPrimitive();

    if (prim === 'cylinder') {
      const radius = 60;
      const height = 140;
      for (let z = -height / 2; z <= height / 2; z += 6) {
        for (let a = 0; a < Math.PI * 2; a += 0.15) {
          // Add synthetic machining deviation
          const deviation = (Math.sin(a * 4) * 0.02 + Math.cos(z / 15) * 0.015 + (Math.random() - 0.5) * 0.01);
          const r = radius + deviation * 40; // Scale visual deviation for clarity
          pts.push({
            x: Math.cos(a) * r,
            y: Math.sin(a) * r,
            z: z,
            deviation: deviation
          });
        }
      }
    } else if (prim === 'sphere') {
      const radius = 75;
      for (let theta = 0; theta < Math.PI; theta += 0.12) {
        for (let phi = 0; phi < Math.PI * 2; phi += 0.18) {
          const deviation = (Math.sin(phi * 3) * 0.025 + (Math.random() - 0.5) * 0.015);
          const r = radius + deviation * 35;
          pts.push({
            x: r * Math.sin(theta) * Math.cos(phi),
            y: r * Math.sin(theta) * Math.sin(phi),
            z: r * Math.cos(theta),
            deviation: deviation
          });
        }
      }
    } else {
      // Freeform surface / airfoil
      for (let x = -80; x <= 80; x += 6) {
        for (let y = -60; y <= 60; y += 6) {
          const baseZ = Math.sin(x / 30) * Math.cos(y / 25) * 35;
          const deviation = (Math.sin(x / 10) * 0.03 + (Math.random() - 0.5) * 0.012);
          pts.push({
            x: x,
            y: y,
            z: baseZ + deviation * 30,
            deviation: deviation
          });
        }
      }
    }
    this.points.set(pts);
  }

  regeneratePointCloud() {
    this.generatePoints();
  }

  startRenderLoop() {
    const loop = () => {
      if (this.autoRotate && !this.isDragging) {
        this.angleY += 0.008;
      }
      this.renderFrame();
      this.animId = requestAnimationFrame(loop);
    };
    loop();
  }

  renderFrame() {
    const canvas = this.canvasRef?.nativeElement;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = (canvas.width = canvas.parentElement?.clientWidth || 700);
    const height = (canvas.height = 520);

    ctx.clearRect(0, 0, width, height);

    // Clean Technical Canvas Background
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, width, height);

    // Grid Floor
    ctx.strokeStyle = '#14141412';
    ctx.lineWidth = 1;
    const floorY = 120;
    for (let x = -150; x <= 150; x += 30) {
      const p1 = this.project(x, floorY, -150, width, height);
      const p2 = this.project(x, floorY, 150, width, height);
      ctx.beginPath();
      ctx.moveTo(p1.px, p1.py);
      ctx.lineTo(p2.px, p2.py);
      ctx.stroke();
    }
    for (let z = -150; z <= 150; z += 30) {
      const p1 = this.project(-150, floorY, z, width, height);
      const p2 = this.project(150, floorY, z, width, height);
      ctx.beginPath();
      ctx.moveTo(p1.px, p1.py);
      ctx.lineTo(p2.px, p2.py);
      ctx.stroke();
    }

    // Coordinate Axes (X: Red, Y: Green, Z: Blue)
    const origin = this.project(0, 0, 0, width, height);
    const axX = this.project(50, 0, 0, width, height);
    const axY = this.project(0, 50, 0, width, height);
    const axZ = this.project(0, 0, 50, width, height);

    ctx.lineWidth = 2;
    ctx.strokeStyle = '#991B1B';
    ctx.beginPath(); ctx.moveTo(origin.px, origin.py); ctx.lineTo(axX.px, axX.py); ctx.stroke();
    ctx.strokeStyle = '#166534';
    ctx.beginPath(); ctx.moveTo(origin.px, origin.py); ctx.lineTo(axY.px, axY.py); ctx.stroke();
    ctx.strokeStyle = '#2563EB';
    ctx.beginPath(); ctx.moveTo(origin.px, origin.py); ctx.lineTo(axZ.px, axZ.py); ctx.stroke();

    // Render Point Cloud
    const pts = this.points();
    for (const pt of pts) {
      const p = this.project(pt.x, pt.y, pt.z, width, height);
      if (p.depth > 0) {
        // Color mapping from deviation (-0.05 to +0.05)
        const d = pt.deviation;
        let color = '#166534'; // Green (pass)
        if (d > 0.02) color = '#D97706'; // Amber
        if (d > 0.035) color = '#991B1B'; // Red (out of tol high)
        if (d < -0.02) color = '#0284C7'; // Blue/Cyan (undersize)

        ctx.fillStyle = color;
        const size = Math.max(1, 2.5 * p.scale);
        ctx.beginPath();
        ctx.arc(p.px, p.py, size, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }

  private project(x: number, y: number, z: number, w: number, h: number) {
    // 3D Rotation Y then X
    const cosY = Math.cos(this.angleY);
    const sinY = Math.sin(this.angleY);
    const cosX = Math.cos(this.angleX);
    const sinX = Math.sin(this.angleX);

    const x1 = x * cosY + z * sinY;
    const z1 = -x * sinY + z * cosY;

    const y2 = y * cosX - z1 * sinX;
    const z2 = y * sinX + z1 * cosX;

    const cameraDistance = 350;
    const depth = z2 + cameraDistance;
    const scale = depth > 0 ? (this.zoom * cameraDistance) / depth : 0.01;

    return {
      px: w / 2 + x1 * scale,
      py: h / 2 + y2 * scale,
      depth: depth,
      scale: scale
    };
  }

  startDrag(e: MouseEvent) {
    this.isDragging = true;
    this.lastMouseX = e.clientX;
    this.lastMouseY = e.clientY;
  }

  onDrag(e: MouseEvent) {
    if (!this.isDragging) return;
    const dx = e.clientX - this.lastMouseX;
    const dy = e.clientY - this.lastMouseY;
    this.angleY += dx * 0.008;
    this.angleX += dy * 0.008;
    this.lastMouseX = e.clientX;
    this.lastMouseY = e.clientY;
    this.renderFrame();
  }

  stopDrag() {
    this.isDragging = false;
  }

  onWheel(e: WheelEvent) {
    e.preventDefault();
    this.zoom += e.deltaY * -0.001;
    this.zoom = Math.max(0.4, Math.min(3.5, this.zoom));
    this.renderFrame();
  }

  toggleAutoRotate() {
    // handled by signal binding
  }
}
