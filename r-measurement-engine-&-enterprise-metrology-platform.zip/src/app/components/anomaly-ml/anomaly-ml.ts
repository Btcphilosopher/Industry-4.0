import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { MetrologyService } from '../../core/metrology.service';

@Component({
  selector: 'app-anomaly-ml',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-4 font-tech-mono">
      
      <!-- Top Anomaly & Drift Metrics -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Sensor Drift Rate</div>
          <div class="text-2xl font-bold font-tech-mono text-[#141414] mt-0.5">+0.00012 mm/hr</div>
          <div class="text-[10px] text-[#141414]/60 mt-0.5">Linear Regression Slope</div>
        </div>

        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Remaining Useful Life (RUL)</div>
          <div class="text-2xl font-bold font-tech-mono text-[#166534] mt-0.5">2,840 Hours</div>
          <div class="text-[10px] text-[#141414]/60 mt-0.5">Until ±0.050 mm Guardband Breach</div>
        </div>

        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">ML Outlier Score (MAD Z-Score)</div>
          <div class="text-2xl font-bold font-tech-mono text-[#141414] mt-0.5">0.48 σ_MAD</div>
          <div class="text-[10px] text-[#166534] font-bold mt-0.5">Threshold: 3.5 σ_MAD (Clean)</div>
        </div>

        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Data State Rigor</div>
          <div class="text-2xl font-bold font-tech-mono text-[#F27D26] mt-0.5">5 States</div>
          <div class="text-[10px] text-[#141414]/60 mt-0.5">RAW / CAL / FILT / EST / PRED</div>
        </div>
      </div>

      <!-- Main Drift Analysis & Forecast Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
        
        <!-- Left 2 Cols: Predictive Degradation Model & Outlier Stream -->
        <div class="lg:col-span-2 bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-4 shadow-2xs space-y-3">
          <div class="flex items-center justify-between pb-2 border-b border-[#141414]/15">
            <div>
              <h2 class="text-xs font-bold text-[#141414] flex items-center gap-1.5 font-tech-mono uppercase tracking-wider">
                <mat-icon class="text-sm text-[#F27D26]">psychology</mat-icon>
                Sensor Degradation & Drift Forecast Model
              </h2>
              <p class="text-[11px] text-[#141414]/60">ARIMA + Robust Polynomial Extrapolation with 95% Prediction Intervals</p>
            </div>
            
            <span class="px-2 py-0.5 rounded-xs text-[10px] font-bold bg-[#DCFCE7] text-[#166534] border border-[#BBF7D0]">
              Model Health: Optimal
            </span>
          </div>

          <!-- Predictive Time Series Table -->
          <div class="overflow-x-auto no-scrollbar">
            <table class="w-full text-left text-xs font-tech-mono">
              <thead class="bg-[#F8F7F5] text-[#141414]/70 uppercase text-[10px] tracking-wider border-b border-[#141414]/20">
                <tr>
                  <th class="py-2 px-3">Horizon Step</th>
                  <th class="py-2 px-3">Forecasted Value</th>
                  <th class="py-2 px-3">Lower 95% PI</th>
                  <th class="py-2 px-3">Upper 95% PI</th>
                  <th class="py-2 px-3">Drift Offset</th>
                  <th class="py-2 px-3">State</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-[#141414]/10">
                <tr class="hover:bg-[#F0F0EE]">
                  <td class="py-2 px-3 text-[#141414] font-medium">+100 Hours (T+1)</td>
                  <td class="py-2 px-3 text-[#141414] font-bold">100.012 mm</td>
                  <td class="py-2 px-3 text-[#141414]/70">100.004 mm</td>
                  <td class="py-2 px-3 text-[#141414]/70">100.020 mm</td>
                  <td class="py-2 px-3 text-[#166534] font-bold">+0.012 mm</td>
                  <td class="py-2 px-3"><span class="px-1.5 py-0.5 rounded-xs text-[9px] font-bold bg-[#E0E7FF] text-[#3730A3] border border-[#C7D2FE]">PREDICTED</span></td>
                </tr>
                <tr class="hover:bg-[#F0F0EE]">
                  <td class="py-2 px-3 text-[#141414] font-medium">+500 Hours (T+5)</td>
                  <td class="py-2 px-3 text-[#141414] font-bold">100.024 mm</td>
                  <td class="py-2 px-3 text-[#141414]/70">100.011 mm</td>
                  <td class="py-2 px-3 text-[#141414]/70">100.037 mm</td>
                  <td class="py-2 px-3 text-[#166534] font-bold">+0.024 mm</td>
                  <td class="py-2 px-3"><span class="px-1.5 py-0.5 rounded-xs text-[9px] font-bold bg-[#E0E7FF] text-[#3730A3] border border-[#C7D2FE]">PREDICTED</span></td>
                </tr>
                <tr class="hover:bg-[#FEF3C7]/40">
                  <td class="py-2 px-3 text-[#141414] font-medium">+1,500 Hours (T+15)</td>
                  <td class="py-2 px-3 text-[#141414] font-bold">100.041 mm</td>
                  <td class="py-2 px-3 text-[#141414]/70">100.022 mm</td>
                  <td class="py-2 px-3 text-[#141414]/70">100.060 mm</td>
                  <td class="py-2 px-3 text-[#D97706] font-bold">+0.041 mm (Near USL)</td>
                  <td class="py-2 px-3"><span class="px-1.5 py-0.5 rounded-xs text-[9px] font-bold bg-[#FEF3C7] text-[#92400E] border border-[#FDE68A]">WARNING</span></td>
                </tr>
                <tr class="hover:bg-[#FEE2E2]/40">
                  <td class="py-2 px-3 text-[#141414] font-medium">+2,840 Hours (RUL Threshold)</td>
                  <td class="py-2 px-3 text-[#991B1B] font-bold">100.052 mm</td>
                  <td class="py-2 px-3 text-[#141414]/70">100.030 mm</td>
                  <td class="py-2 px-3 text-[#141414]/70">100.074 mm</td>
                  <td class="py-2 px-3 text-[#991B1B] font-bold">+0.052 mm (Tolerance Breach)</td>
                  <td class="py-2 px-3"><span class="px-1.5 py-0.5 rounded-xs text-[9px] font-bold bg-[#FEE2E2] text-[#991B1B] border border-[#FECACA]">RECALIBRATE</span></td>
                </tr>
              </tbody>
            </table>
          </div>

          <!-- Data State Partitioning -->
          <div class="pt-3 border-t border-[#141414]/15">
            <h3 class="text-xs font-bold text-[#141414] mb-2 uppercase tracking-wider">Strict Data State Ledger Lifecycle</h3>
            <div class="grid grid-cols-2 sm:grid-cols-5 gap-2 text-center text-xs">
              <div class="bg-[#F8F7F5] p-2 rounded-xs border border-[#141414]/15">
                <div class="font-bold text-[#141414]">RAW</div>
                <div class="text-[9px] text-[#141414]/60 mt-0.5">Direct ADC Volts</div>
              </div>
              <div class="bg-[#F8F7F5] p-2 rounded-xs border border-[#141414]/15">
                <div class="font-bold text-[#166534]">CALIBRATED</div>
                <div class="text-[9px] text-[#141414]/60 mt-0.5">Compensated</div>
              </div>
              <div class="bg-[#F8F7F5] p-2 rounded-xs border border-[#141414]/15">
                <div class="font-bold text-[#3730A3]">FILTERED</div>
                <div class="text-[9px] text-[#141414]/60 mt-0.5">Butterworth DSP</div>
              </div>
              <div class="bg-[#F8F7F5] p-2 rounded-xs border border-[#141414]/15">
                <div class="font-bold text-[#166534]">ESTIMATED</div>
                <div class="text-[9px] text-[#141414]/60 mt-0.5">Kalman Fusion</div>
              </div>
              <div class="bg-[#F8F7F5] p-2 rounded-xs border border-[#141414]/15">
                <div class="font-bold text-[#F27D26]">PREDICTED</div>
                <div class="text-[9px] text-[#141414]/60 mt-0.5">Drift Horizon</div>
              </div>
            </div>
          </div>

        </div>

        <!-- Right Col: Outlier Sensitivity Controls -->
        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-4 shadow-2xs space-y-3 font-tech-mono text-xs">
          <div>
            <h2 class="text-xs font-bold text-[#141414] flex items-center gap-1.5 uppercase tracking-wider">
              <mat-icon class="text-sm text-[#F27D26]">settings_suggest</mat-icon>
              Anomaly Detector Config
            </h2>
            <p class="text-[11px] text-[#141414]/60">Statistical outlier isolation</p>
          </div>

          <div class="space-y-2.5">
            <div>
              <label for="anomaly-method-select" class="block text-[#141414]/70 mb-1">Method: Robust Median Absolute Deviation (MAD)</label>
              <select id="anomaly-method-select" class="w-full bg-[#F8F7F5] border border-[#141414]/20 rounded-xs px-2.5 py-1.5 text-[#141414] focus:outline-none focus:border-[#F27D26] cursor-pointer">
                <option>Median Absolute Deviation (MAD)</option>
                <option>Interquartile Range (IQR 1.5x)</option>
                <option>Isolation Forest (ML Ensembles)</option>
                <option>Local Outlier Factor (LOF)</option>
              </select>
            </div>

            <div>
              <label for="anomaly-threshold-input" class="block text-[#141414]/70 mb-1">Z-Score Cutoff Threshold (σ): {{ threshold }}</label>
              <input
                id="anomaly-threshold-input"
                type="range"
                min="2.0"
                max="5.0"
                step="0.1"
                [(ngModel)]="threshold"
                class="w-full accent-[#F27D26] cursor-pointer">
            </div>

            <div class="bg-[#F8F7F5] p-2.5 rounded-xs border border-[#141414]/15 space-y-1 text-xs">
              <div class="text-[10px] text-[#141414]/70 uppercase tracking-wider font-bold">Detection Status</div>
              <div class="text-[#166534] font-bold flex items-center gap-1.5">
                <mat-icon class="text-xs">check_circle</mat-icon>
                <span>Zero anomalous spikes detected</span>
              </div>
              <div class="text-[#141414]/60 text-[10px]">99.8% nominal baseline stability</div>
            </div>

            <button
              (click)="triggerAnomalyScan()"
              class="w-full py-1.5 rounded-xs bg-[#141414] hover:bg-[#262626] text-[#E4E3E0] font-bold text-xs flex items-center justify-center space-x-1.5 border border-[#141414] transition cursor-pointer shadow-2xs">
              <mat-icon class="text-sm text-[#F27D26]">search</mat-icon>
              <span>Scan Active Dataset for Anomalies</span>
            </button>
          </div>
        </div>

      </div>

    </div>
  `
})
export class AnomalyMlComponent {
  readonly metrology = inject(MetrologyService);

  threshold = 3.5;

  triggerAnomalyScan() {
    // Scan active dataset
  }
}
