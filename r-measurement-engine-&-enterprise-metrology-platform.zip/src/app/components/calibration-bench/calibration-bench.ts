import { ChangeDetectionStrategy, Component, inject, signal, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { MetrologyService } from '../../core/metrology.service';

@Component({
  selector: 'app-calibration-bench',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-4 font-tech-mono">
      
      <!-- Top Metrics Banner -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Active Calibration Models</div>
          <div class="text-2xl font-bold font-tech-mono text-[#141414] mt-0.5">{{ metrology.calibrationModels().length }} Active</div>
          <div class="text-[10px] text-[#166534] font-bold mt-0.5">100% Traceable to NIST / UKAS</div>
        </div>

        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Selected Model Linearity (R²)</div>
          <div class="text-2xl font-bold font-tech-mono text-[#141414] mt-0.5">{{ (selectedModel()?.r_squared || 0.99998).toFixed(5) }}</div>
          <div class="text-[10px] text-[#141414]/60 mt-0.5">Linear Least-Squares Fit</div>
        </div>

        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Thermal Expansion Coeff (α)</div>
          <div class="text-2xl font-bold font-tech-mono text-[#F27D26] mt-0.5">+11.5 µm/m/°C</div>
          <div class="text-[10px] text-[#141414]/60 mt-0.5">Standard Steel Grade Reference</div>
        </div>

        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-3.5 shadow-2xs">
          <div class="text-[11px] font-tech-serif italic text-[#141414]/70 uppercase">Compensation Engine</div>
          <div class="text-2xl font-bold font-tech-mono text-[#141414] mt-0.5">Real-time DSP</div>
          <div class="text-[10px] text-[#141414]/60 mt-0.5">S3 R-Engine Model Bridge</div>
        </div>
      </div>

      <!-- Main Workbench Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
        
        <!-- Left 2 Cols: Calibration Models & Multi-Point Curve Fitting -->
        <div class="lg:col-span-2 space-y-4">
          
          <!-- Calibration Models Table -->
          <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-4 shadow-2xs space-y-3">
            <div class="flex items-center justify-between pb-2 border-b border-[#141414]/15">
              <div>
                <h2 class="text-xs font-bold text-[#141414] flex items-center gap-1.5 font-tech-mono uppercase tracking-wider">
                  <mat-icon class="text-sm text-[#F27D26]">tune</mat-icon>
                  Instrument Calibration Certificates & Models
                </h2>
                <p class="text-[11px] text-[#141414]/60">Select a model to apply polynomial sensor compensation</p>
              </div>
              <button
                (click)="applyCompensationToAll()"
                class="px-3 py-1.5 rounded-xs bg-[#141414] hover:bg-[#262626] text-[#E4E3E0] font-medium text-xs font-tech-mono flex items-center space-x-1.5 border border-[#141414] transition cursor-pointer shadow-2xs">
                <mat-icon class="text-sm text-[#F27D26]">auto_fix_high</mat-icon>
                <span>Apply to All Records</span>
              </button>
            </div>

            <div class="overflow-x-auto no-scrollbar">
              <table class="w-full text-left text-xs font-tech-mono">
                <thead class="bg-[#F8F7F5] text-[#141414]/70 uppercase text-[10px] tracking-wider border-b border-[#141414]/20">
                  <tr>
                    <th class="py-2 px-3">Model ID</th>
                    <th class="py-2 px-3">Instrument</th>
                    <th class="py-2 px-3">Type</th>
                    <th class="py-2 px-3">R² Fit</th>
                    <th class="py-2 px-3">Next Due</th>
                    <th class="py-2 px-3">Status</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-[#141414]/10">
                  @for (model of metrology.calibrationModels(); track model.id) {
                    <tr
                      (click)="selectedModelId.set(model.id)"
                      [class]="selectedModelId() === model.id ? 'bg-[#FFEDD5]/60 border-l-3 border-[#F27D26]' : 'hover:bg-[#F0F0EE]'"
                      class="cursor-pointer transition">
                      <td class="py-2.5 px-3 text-[#141414] font-bold">{{ model.id }}</td>
                      <td class="py-2.5 px-3 text-[#141414]">{{ model.instrument }}</td>
                      <td class="py-2.5 px-3">
                        <span class="px-1.5 py-0.5 rounded-xs text-[10px] uppercase font-bold bg-[#F8F7F5] text-[#141414] border border-[#141414]/15">
                          {{ model.model_type }}
                        </span>
                      </td>
                      <td class="py-2.5 px-3 text-[#166534] font-bold">{{ model.r_squared.toFixed(5) }}</td>
                      <td class="py-2.5 px-3 text-[#141414]/70">{{ model.next_calibration }}</td>
                      <td class="py-2.5 px-3">
                        <span class="px-2 py-0.5 rounded-xs text-[10px] font-bold bg-[#DCFCE7] text-[#166534] border border-[#BBF7D0]">
                          {{ model.status }}
                        </span>
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          </div>

          <!-- Curve Fitting Canvas -->
          <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-4 shadow-2xs space-y-3">
            <div class="flex items-center justify-between">
              <div>
                <h2 class="text-xs font-bold text-[#141414] flex items-center gap-1.5 font-tech-mono uppercase tracking-wider">
                  <mat-icon class="text-sm text-[#F27D26]">show_chart</mat-icon>
                  Multipoint Calibration Curve & Residual Error Plot
                </h2>
                <p class="text-[11px] text-[#141414]/60 font-tech-mono">Reference Standard vs Raw Sensor Signal (Residuals in ppm)</p>
              </div>
              <div class="flex items-center space-x-3 text-xs font-tech-mono">
                <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-xs bg-[#F27D26]"></span> Calibration Points</span>
                <span class="flex items-center gap-1.5"><span class="w-3 h-0.5 bg-[#141414]"></span> Fitted Curve</span>
              </div>
            </div>

            <div class="bg-[#F8F7F5] rounded-xs p-2 border border-[#141414]/15 overflow-hidden">
              <canvas #calCanvas class="w-full h-56 block"></canvas>
            </div>
          </div>

        </div>

        <!-- Right Col: Real-time Live Sensor Compensation Calculator -->
        <div class="bg-[#FFFFFF] border border-[#141414]/15 rounded-xs p-4 shadow-2xs space-y-4 font-tech-mono text-xs">
          <div>
            <h2 class="text-xs font-bold text-[#141414] flex items-center gap-1.5 uppercase tracking-wider">
              <mat-icon class="text-sm text-[#F27D26]">calculate</mat-icon>
              Live Thermal & Scale Compensator
            </h2>
            <p class="text-[11px] text-[#141414]/60">Applies polynomial correction and ISO standard 20°C normalization</p>
          </div>

          <div class="space-y-3">
            <div>
              <label for="raw-reading-input" class="block text-[#141414]/70 mb-1">Raw Sensor Reading (x)</label>
              <div class="relative">
                <input
                  id="raw-reading-input"
                  type="number"
                  step="0.001"
                  [(ngModel)]="rawInput"
                  (ngModelChange)="calculateCompensation()"
                  class="w-full bg-[#F8F7F5] border border-[#141414]/20 rounded-xs px-3 py-1.5 text-[#141414] font-bold focus:outline-none focus:border-[#F27D26]">
                <span class="absolute right-3 top-1.5 text-[#141414]/40">mm</span>
              </div>
            </div>

            <div>
              <label for="env-temp-input" class="block text-[#141414]/70 mb-1">Environmental Temperature (°C)</label>
              <div class="relative">
                <input
                  id="env-temp-input"
                  type="number"
                  step="0.1"
                  [(ngModel)]="ambientTemp"
                  (ngModelChange)="calculateCompensation()"
                  class="w-full bg-[#F8F7F5] border border-[#141414]/20 rounded-xs px-3 py-1.5 text-[#141414] font-bold focus:outline-none focus:border-[#F27D26]">
                <span class="absolute right-3 top-1.5 text-[#141414]/40">°C (Ref 20.0°C)</span>
              </div>
            </div>

            <div>
              <label for="thermal-expansion-select" class="block text-[#141414]/70 mb-1">Material Expansion (α)</label>
              <select
                id="thermal-expansion-select"
                [(ngModel)]="thermalCoeff"
                (ngModelChange)="calculateCompensation()"
                class="w-full bg-[#F8F7F5] border border-[#141414]/20 rounded-xs px-3 py-1.5 text-[#141414] focus:outline-none focus:border-[#F27D26] cursor-pointer">
                <option [value]="0.0000115">Steel / Tool Steel (11.5 µm/m/°C)</option>
                <option [value]="0.000023">Aluminum Alloy (23.0 µm/m/°C)</option>
                <option [value]="0.0000085">Titanium Grade 5 (8.5 µm/m/°C)</option>
                <option [value]="0.0000005">Invar 36 Low Expansion (0.5 µm/m/°C)</option>
              </select>
            </div>

            <div class="pt-3 border-t border-[#141414]/15 space-y-1.5">
              <div class="flex justify-between items-center text-[#141414]/70">
                <span>Scale Correction:</span>
                <span class="text-[#141414] font-bold">{{ scaleDelta >= 0 ? '+' : '' }}{{ scaleDelta.toFixed(5) }} mm</span>
              </div>
              <div class="flex justify-between items-center text-[#141414]/70">
                <span>Thermal Correction (ΔT = {{ (ambientTemp - 20).toFixed(1) }}°C):</span>
                <span class="text-[#D97706] font-bold">{{ tempDelta >= 0 ? '+' : '' }}{{ tempDelta.toFixed(5) }} mm</span>
              </div>
              <div class="flex justify-between items-center pt-2 border-t border-[#141414]/15 font-bold">
                <span class="text-[#141414] text-xs">Calibrated True Value:</span>
                <span class="text-[#166534] text-sm">{{ calibratedOutput.toFixed(5) }} mm</span>
              </div>
            </div>

            <button
              (click)="addCalibratedRecord()"
              class="w-full py-2 rounded-xs bg-[#F27D26] hover:bg-[#E06810] text-white font-bold text-xs flex items-center justify-center space-x-1.5 transition cursor-pointer shadow-2xs">
              <mat-icon class="text-sm">add_task</mat-icon>
              <span>Commit Calibrated Record</span>
            </button>
          </div>
        </div>

      </div>

    </div>
  `
})
export class CalibrationBenchComponent implements AfterViewInit {
  @ViewChild('calCanvas') calCanvasRef!: ElementRef<HTMLCanvasElement>;
  readonly metrology = inject(MetrologyService);

  selectedModelId = signal<string>('CAL-OPT-001');

  rawInput = 100.025;
  ambientTemp = 23.5;
  thermalCoeff = 0.0000115;

  scaleDelta = -0.0004;
  tempDelta = -0.00402;
  calibratedOutput = 100.02058;

  selectedModel() {
    return this.metrology.calibrationModels().find(m => m.id === this.selectedModelId());
  }

  ngAfterViewInit() {
    this.renderCurvePlot();
    this.calculateCompensation();
  }

  calculateCompensation() {
    const deltaT = this.ambientTemp - 20.0;
    this.tempDelta = - (this.rawInput * this.thermalCoeff * deltaT);

    const model = this.selectedModel();
    if (model?.model_type === 'linear') {
      const slope = model.coefficients['slope'] || 1.0;
      const intercept = model.coefficients['intercept'] || 0.0;
      const scaleComp = (this.rawInput * slope + intercept) - this.rawInput;
      this.scaleDelta = scaleComp;
    } else {
      this.scaleDelta = -0.00035;
    }

    this.calibratedOutput = this.rawInput + this.scaleDelta + this.tempDelta;
  }

  addCalibratedRecord() {
    const m = this.metrology.createMeasurementRecord(
      Number(this.calibratedOutput.toFixed(5)),
      'mm',
      'calibrated_length',
      100.000,
      0.050,
      -0.050,
      this.selectedModel()?.instrument || 'Calibrated Sensor',
      'CAL-COMP-01',
      'Dr. Aris Thorne'
    );
    m.data_state = 'CALIBRATED';
    this.metrology.addMeasurement(m);
    this.metrology.activeTab.set('grid');
  }

  applyCompensationToAll() {
    this.metrology.measurements.update(list => {
      return list.map(item => {
        const deltaT = 22.0 - 20.0;
        const tempCorr = - (item.value * 0.0000115 * deltaT);
        const calibratedVal = item.value * 0.99998 + tempCorr;
        return {
          ...item,
          value: Number(calibratedVal.toFixed(5)),
          data_state: 'CALIBRATED',
          audit_trail: [
            ...item.audit_trail,
            {
              step: 'CALIBRATION_APPLIED',
              timestamp: new Date().toISOString(),
              operator: 'Dr. Aris Thorne',
              note: `Applied model ${this.selectedModelId()} + 20°C normalization`
            }
          ]
        };
      });
    });
  }

  renderCurvePlot() {
    const canvas = this.calCanvasRef?.nativeElement;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const w = (canvas.width = canvas.parentElement?.clientWidth || 600);
    const h = (canvas.height = 220);

    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, w, h);

    // Subtle Grid lines
    ctx.strokeStyle = '#14141415';
    ctx.lineWidth = 1;
    for (let x = 40; x < w - 20; x += (w - 60) / 8) {
      ctx.beginPath();
      ctx.moveTo(x, 20);
      ctx.lineTo(x, h - 30);
      ctx.stroke();
    }
    for (let y = 20; y < h - 30; y += (h - 50) / 5) {
      ctx.beginPath();
      ctx.moveTo(40, y);
      ctx.lineTo(w - 20, y);
      ctx.stroke();
    }

    // Axes
    ctx.strokeStyle = '#141414';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(40, 20); ctx.lineTo(40, h - 30);
    ctx.lineTo(w - 20, h - 30);
    ctx.stroke();

    // Fitted Line (Black/Ink)
    ctx.strokeStyle = '#141414';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(40, h - 30);
    ctx.lineTo(w - 30, 30);
    ctx.stroke();

    // Data points (Accent Orange squares/dots)
    const points = [
      { x: 0.1, y: 0.1 }, { x: 0.3, y: 0.298 }, { x: 0.5, y: 0.502 },
      { x: 0.7, y: 0.697 }, { x: 0.9, y: 0.901 }
    ];

    for (const pt of points) {
      const px = 40 + pt.x * (w - 70);
      const py = (h - 30) - pt.y * (h - 60);

      ctx.fillStyle = '#F27D26';
      ctx.strokeStyle = '#141414';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(px, py, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
    }
  }
}
