import { ChangeDetectionStrategy, Component, inject, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MetrologyService } from '../../core/metrology.service';

@Component({
  selector: 'app-header',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="bg-[#DCDAD5] border-b-2 border-[#141414] sticky top-0 z-40 select-none shadow-xs">
      <!-- Top Brand & Meta Row -->
      <div class="w-full max-w-[1440px] mx-auto px-4 sm:px-6 h-[60px] flex items-center justify-between">
        
        <!-- Left: Engine Logo & Title -->
        <div class="flex items-center space-x-3">
          <div class="w-8 h-8 rounded-sm bg-[#141414] text-[#E4E3E0] flex items-center justify-center">
            <mat-icon class="text-base text-[#F27D26]">straighten</mat-icon>
          </div>
          <div>
            <div class="flex items-center">
              <h1 class="text-base sm:text-lg font-black text-[#141414] tracking-tight font-tech-sans flex items-center">
                R MEASUREMENT ENGINE
                <span class="font-tech-mono text-[11px] font-bold bg-[#141414] text-[#E4E3E0] px-1.5 py-0.5 rounded-xs ml-2 uppercase tracking-wide">
                  V4.4.2-ENTERPRISE
                </span>
              </h1>
            </div>
          </div>
        </div>

        <!-- Right: Telemetry Indicators & Actions -->
        <div class="flex items-center space-x-3 sm:space-x-5 font-tech-mono text-xs">
          
          <div class="hidden lg:flex items-center space-x-4 text-[11px] text-[#141414]/70">
            <span>OPERATOR: <b class="text-[#141414]">ID-9928</b></span>
            <span class="text-[#141414]/20">|</span>
            <span>STATION: <b class="text-[#141414]">CAL-ALPHA-04</b></span>
            <span class="text-[#141414]/20">|</span>
            <span class="text-[#F27D26] font-bold flex items-center gap-1">
              <span class="inline-block w-2 h-2 rounded-full bg-[#F27D26]"></span>
              SYSTEM LIVE
            </span>
          </div>

          <!-- Sample Scenarios Dropdown -->
          <div class="relative group">
            <button
              class="px-3 py-1.5 rounded-xs bg-[#FFFFFF] hover:bg-[#F0F0EE] text-[#141414] text-xs font-tech-mono font-medium flex items-center space-x-1.5 transition border border-[#141414]/30 cursor-pointer shadow-2xs">
              <mat-icon class="text-sm text-[#F27D26]">dataset</mat-icon>
              <span>Load Preset Data</span>
              <mat-icon class="text-xs text-[#141414]/60">expand_more</mat-icon>
            </button>
            <div class="absolute right-0 mt-1 w-60 bg-[#FFFFFF] border border-[#141414] rounded-xs shadow-xl py-1 hidden group-hover:block z-50 font-tech-mono text-xs">
              <div class="px-3 py-1 text-[10px] uppercase tracking-wider text-[#141414]/50 border-b border-[#141414]/15">
                Calibrated Test Environments
              </div>
              <button
                (click)="metrology.loadSampleScenario('aerospace')"
                class="w-full text-left px-3.5 py-2 hover:bg-[#F0F0EE] text-[#141414] flex items-center space-x-2 transition cursor-pointer">
                <mat-icon class="text-xs text-[#F27D26]">flight</mat-icon>
                <span>Aerospace Turbine (LiDAR)</span>
              </button>
              <button
                (click)="metrology.loadSampleScenario('cleanroom')"
                class="w-full text-left px-3.5 py-2 hover:bg-[#F0F0EE] text-[#141414] flex items-center space-x-2 transition cursor-pointer">
                <mat-icon class="text-xs text-[#166534]">thermostat</mat-icon>
                <span>Cleanroom Thermal RTD</span>
              </button>
              <button
                (click)="metrology.loadSampleScenario('automotive')"
                class="w-full text-left px-3.5 py-2 hover:bg-[#F0F0EE] text-[#141414] flex items-center space-x-2 transition cursor-pointer">
                <mat-icon class="text-xs text-[#D97706]">directions_car</mat-icon>
                <span>Engine Piston Micrometer</span>
              </button>
              <button
                (click)="metrology.loadSampleScenario('vibration')"
                class="w-full text-left px-3.5 py-2 hover:bg-[#F0F0EE] text-[#141414] flex items-center space-x-2 transition cursor-pointer">
                <mat-icon class="text-xs text-[#4F46E5]">vibration</mat-icon>
                <span>Bearing Vibration Transducer</span>
              </button>
            </div>
          </div>

          <!-- ISO 17025 Certificate Report Button -->
          <button
            (click)="openReport.emit()"
            class="px-3.5 py-1.5 rounded-xs bg-[#141414] hover:bg-[#262626] text-[#E4E3E0] font-medium text-xs font-tech-mono flex items-center space-x-1.5 border border-[#141414] transition cursor-pointer shadow-2xs">
            <mat-icon class="text-sm text-[#F27D26]">verified</mat-icon>
            <span>ISO 17025 Cert</span>
          </button>
        </div>

      </div>

      <!-- Navigation Modules Ribbon -->
      <nav class="w-full max-w-[1440px] mx-auto px-4 sm:px-6 flex space-x-1 overflow-x-auto border-t border-[#141414]/15 no-scrollbar bg-[#DCDAD5]">
        <button
          (click)="metrology.activeTab.set('grid')"
          [class]="metrology.activeTab() === 'grid' ? 'border-[#F27D26] text-[#141414] bg-[#E4E3E0] font-bold' : 'border-transparent text-[#141414]/60 hover:text-[#141414] hover:bg-[#E4E3E0]/50'"
          class="flex items-center space-x-2 px-3.5 py-2 text-xs font-tech-mono font-medium border-b-[3px] transition whitespace-nowrap cursor-pointer">
          <span class="text-[10px] text-[#F27D26] font-bold">01</span>
          <span>Measurement Grid ({{ metrology.totalCount() }})</span>
        </button>

        <button
          (click)="metrology.activeTab.set('calibration')"
          [class]="metrology.activeTab() === 'calibration' ? 'border-[#F27D26] text-[#141414] bg-[#E4E3E0] font-bold' : 'border-transparent text-[#141414]/60 hover:text-[#141414] hover:bg-[#E4E3E0]/50'"
          class="flex items-center space-x-2 px-3.5 py-2 text-xs font-tech-mono font-medium border-b-[3px] transition whitespace-nowrap cursor-pointer">
          <span class="text-[10px] text-[#F27D26] font-bold">02</span>
          <span>Calibration Bench</span>
        </button>

        <button
          (click)="metrology.activeTab.set('uncertainty')"
          [class]="metrology.activeTab() === 'uncertainty' ? 'border-[#F27D26] text-[#141414] bg-[#E4E3E0] font-bold' : 'border-transparent text-[#141414]/60 hover:text-[#141414] hover:bg-[#E4E3E0]/50'"
          class="flex items-center space-x-2 px-3.5 py-2 text-xs font-tech-mono font-medium border-b-[3px] transition whitespace-nowrap cursor-pointer">
          <span class="text-[10px] text-[#F27D26] font-bold">03</span>
          <span>GUM Uncertainty Budget</span>
        </button>

        <button
          (click)="metrology.activeTab.set('geometry3d')"
          [class]="metrology.activeTab() === 'geometry3d' ? 'border-[#F27D26] text-[#141414] bg-[#E4E3E0] font-bold' : 'border-transparent text-[#141414]/60 hover:text-[#141414] hover:bg-[#E4E3E0]/50'"
          class="flex items-center space-x-2 px-3.5 py-2 text-xs font-tech-mono font-medium border-b-[3px] transition whitespace-nowrap cursor-pointer">
          <span class="text-[10px] text-[#F27D26] font-bold">04</span>
          <span>Geometry & 3D</span>
        </button>

        <button
          (click)="metrology.activeTab.set('signal')"
          [class]="metrology.activeTab() === 'signal' ? 'border-[#F27D26] text-[#141414] bg-[#E4E3E0] font-bold' : 'border-transparent text-[#141414]/60 hover:text-[#141414] hover:bg-[#E4E3E0]/50'"
          class="flex items-center space-x-2 px-3.5 py-2 text-xs font-tech-mono font-medium border-b-[3px] transition whitespace-nowrap cursor-pointer">
          <span class="text-[10px] text-[#F27D26] font-bold">05</span>
          <span>Signal Processing (FFT)</span>
        </button>

        <button
          (click)="metrology.activeTab.set('spc')"
          [class]="metrology.activeTab() === 'spc' ? 'border-[#F27D26] text-[#141414] bg-[#E4E3E0] font-bold' : 'border-transparent text-[#141414]/60 hover:text-[#141414] hover:bg-[#E4E3E0]/50'"
          class="flex items-center space-x-2 px-3.5 py-2 text-xs font-tech-mono font-medium border-b-[3px] transition whitespace-nowrap cursor-pointer">
          <span class="text-[10px] text-[#F27D26] font-bold">06</span>
          <span>Statistical Control (Cpk)</span>
        </button>

        <button
          (click)="metrology.activeTab.set('anomaly')"
          [class]="metrology.activeTab() === 'anomaly' ? 'border-[#F27D26] text-[#141414] bg-[#E4E3E0] font-bold' : 'border-transparent text-[#141414]/60 hover:text-[#141414] hover:bg-[#E4E3E0]/50'"
          class="flex items-center space-x-2 px-3.5 py-2 text-xs font-tech-mono font-medium border-b-[3px] transition whitespace-nowrap cursor-pointer">
          <span class="text-[10px] text-[#F27D26] font-bold">07</span>
          <span>Drift Forecast & ML</span>
        </button>

        <button
          (click)="metrology.activeTab.set('audit')"
          [class]="metrology.activeTab() === 'audit' ? 'border-[#F27D26] text-[#141414] bg-[#E4E3E0] font-bold' : 'border-transparent text-[#141414]/60 hover:text-[#141414] hover:bg-[#E4E3E0]/50'"
          class="flex items-center space-x-2 px-3.5 py-2 text-xs font-tech-mono font-medium border-b-[3px] transition whitespace-nowrap cursor-pointer">
          <span class="text-[10px] text-[#F27D26] font-bold">08</span>
          <span>Audit Ledger</span>
        </button>

        <button
          (click)="metrology.activeTab.set('rCode')"
          [class]="metrology.activeTab() === 'rCode' ? 'border-[#F27D26] text-[#141414] bg-[#E4E3E0] font-bold' : 'border-transparent text-[#141414]/60 hover:text-[#141414] hover:bg-[#E4E3E0]/50'"
          class="flex items-center space-x-2 px-3.5 py-2 text-xs font-tech-mono font-medium border-b-[3px] transition whitespace-nowrap cursor-pointer">
          <span class="text-[10px] text-[#F27D26] font-bold">09</span>
          <span>R Engine Core Code</span>
        </button>
      </nav>
    </header>
  `
})
export class HeaderComponent {
  readonly metrology = inject(MetrologyService);
  readonly openReport = output<void>();
}
