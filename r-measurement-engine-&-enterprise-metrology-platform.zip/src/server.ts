import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';
import {readFileSync, readdirSync, existsSync} from 'node:fs';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json({ limit: '50mb' }));
const angularApp = new AngularNodeAppEngine();

// ==============================================================================
// METROLOGY & MEASUREMENT ENGINE BACKEND API (R-Engine Parity)
// ==============================================================================

// 7-SI Base Dimensional Registry
const UNIT_SPECS: Record<string, { dim: number[]; toSi: (x: number) => number; fromSi: (x: number) => number; base: string; desc: string }> = {
  // Length
  m:     { dim: [1, 0, 0, 0, 0, 0, 0], toSi: x => x, fromSi: x => x, base: 'm', desc: 'Meter' },
  mm:    { dim: [1, 0, 0, 0, 0, 0, 0], toSi: x => x * 1e-3, fromSi: x => x * 1e3, base: 'm', desc: 'Millimeter' },
  cm:    { dim: [1, 0, 0, 0, 0, 0, 0], toSi: x => x * 1e-2, fromSi: x => x * 1e2, base: 'm', desc: 'Centimeter' },
  km:    { dim: [1, 0, 0, 0, 0, 0, 0], toSi: x => x * 1e3, fromSi: x => x * 1e-3, base: 'm', desc: 'Kilometer' },
  um:    { dim: [1, 0, 0, 0, 0, 0, 0], toSi: x => x * 1e-6, fromSi: x => x * 1e6, base: 'm', desc: 'Micrometer' },
  nm:    { dim: [1, 0, 0, 0, 0, 0, 0], toSi: x => x * 1e-9, fromSi: x => x * 1e9, base: 'm', desc: 'Nanometer' },
  inch:  { dim: [1, 0, 0, 0, 0, 0, 0], toSi: x => x * 0.0254, fromSi: x => x / 0.0254, base: 'm', desc: 'Inch' },
  foot:  { dim: [1, 0, 0, 0, 0, 0, 0], toSi: x => x * 0.3048, fromSi: x => x / 0.3048, base: 'm', desc: 'Foot' },
  yard:  { dim: [1, 0, 0, 0, 0, 0, 0], toSi: x => x * 0.9144, fromSi: x => x / 0.9144, base: 'm', desc: 'Yard' },
  mile:  { dim: [1, 0, 0, 0, 0, 0, 0], toSi: x => x * 1609.344, fromSi: x => x / 1609.344, base: 'm', desc: 'Mile' },

  // Mass
  kg:    { dim: [0, 1, 0, 0, 0, 0, 0], toSi: x => x, fromSi: x => x, base: 'kg', desc: 'Kilogram' },
  g:     { dim: [0, 1, 0, 0, 0, 0, 0], toSi: x => x * 1e-3, fromSi: x => x * 1e3, base: 'kg', desc: 'Gram' },
  mg:    { dim: [0, 1, 0, 0, 0, 0, 0], toSi: x => x * 1e-6, fromSi: x => x * 1e6, base: 'kg', desc: 'Milligram' },
  pound: { dim: [0, 1, 0, 0, 0, 0, 0], toSi: x => x * 0.45359237, fromSi: x => x / 0.45359237, base: 'kg', desc: 'Pound (lb)' },
  lb:    { dim: [0, 1, 0, 0, 0, 0, 0], toSi: x => x * 0.45359237, fromSi: x => x / 0.45359237, base: 'kg', desc: 'Pound (lb)' },
  ounce: { dim: [0, 1, 0, 0, 0, 0, 0], toSi: x => x * 0.0283495231, fromSi: x => x / 0.0283495231, base: 'kg', desc: 'Ounce (oz)' },
  oz:    { dim: [0, 1, 0, 0, 0, 0, 0], toSi: x => x * 0.0283495231, fromSi: x => x / 0.0283495231, base: 'kg', desc: 'Ounce (oz)' },

  // Time
  s:     { dim: [0, 0, 1, 0, 0, 0, 0], toSi: x => x, fromSi: x => x, base: 's', desc: 'Second' },
  ms:    { dim: [0, 0, 1, 0, 0, 0, 0], toSi: x => x * 1e-3, fromSi: x => x * 1e3, base: 's', desc: 'Millisecond' },
  us:    { dim: [0, 0, 1, 0, 0, 0, 0], toSi: x => x * 1e-6, fromSi: x => x * 1e6, base: 's', desc: 'Microsecond' },
  min:   { dim: [0, 0, 1, 0, 0, 0, 0], toSi: x => x * 60, fromSi: x => x / 60, base: 's', desc: 'Minute' },
  h:     { dim: [0, 0, 1, 0, 0, 0, 0], toSi: x => x * 3600, fromSi: x => x / 3600, base: 's', desc: 'Hour' },

  // Temperature
  K:     { dim: [0, 0, 0, 0, 1, 0, 0], toSi: x => x, fromSi: x => x, base: 'K', desc: 'Kelvin' },
  degC:  { dim: [0, 0, 0, 0, 1, 0, 0], toSi: x => x + 273.15, fromSi: x => x - 273.15, base: 'K', desc: 'Degree Celsius' },
  C:     { dim: [0, 0, 0, 0, 1, 0, 0], toSi: x => x + 273.15, fromSi: x => x - 273.15, base: 'K', desc: 'Degree Celsius' },
  degF:  { dim: [0, 0, 0, 0, 1, 0, 0], toSi: x => (x - 32) * 5 / 9 + 273.15, fromSi: x => (x - 273.15) * 9 / 5 + 32, base: 'K', desc: 'Degree Fahrenheit' },
  F:     { dim: [0, 0, 0, 0, 1, 0, 0], toSi: x => (x - 32) * 5 / 9 + 273.15, fromSi: x => (x - 273.15) * 9 / 5 + 32, base: 'K', desc: 'Degree Fahrenheit' },

  // Pressure
  Pa:    { dim: [-1, 1, -2, 0, 0, 0, 0], toSi: x => x, fromSi: x => x, base: 'Pa', desc: 'Pascal' },
  kPa:   { dim: [-1, 1, -2, 0, 0, 0, 0], toSi: x => x * 1e3, fromSi: x => x * 1e-3, base: 'Pa', desc: 'Kilopascal' },
  MPa:   { dim: [-1, 1, -2, 0, 0, 0, 0], toSi: x => x * 1e6, fromSi: x => x * 1e-6, base: 'Pa', desc: 'Megapascal' },
  bar:   { dim: [-1, 1, -2, 0, 0, 0, 0], toSi: x => x * 1e5, fromSi: x => x * 1e-5, base: 'Pa', desc: 'Bar' },
  mbar:  { dim: [-1, 1, -2, 0, 0, 0, 0], toSi: x => x * 1e2, fromSi: x => x * 1e-2, base: 'Pa', desc: 'Millibar' },
  psi:   { dim: [-1, 1, -2, 0, 0, 0, 0], toSi: x => x * 6894.75729, fromSi: x => x / 6894.75729, base: 'Pa', desc: 'PSI' },

  // Force
  N:     { dim: [1, 1, -2, 0, 0, 0, 0], toSi: x => x, fromSi: x => x, base: 'N', desc: 'Newton' },
  kN:    { dim: [1, 1, -2, 0, 0, 0, 0], toSi: x => x * 1e3, fromSi: x => x * 1e-3, base: 'N', desc: 'Kilonewton' },
  lbf:   { dim: [1, 1, -2, 0, 0, 0, 0], toSi: x => x * 4.448222, fromSi: x => x / 4.448222, base: 'N', desc: 'Pound-force' },

  // Electrical & Frequency
  A:     { dim: [0, 0, 0, 1, 0, 0, 0], toSi: x => x, fromSi: x => x, base: 'A', desc: 'Ampere' },
  mA:    { dim: [0, 0, 0, 1, 0, 0, 0], toSi: x => x * 1e-3, fromSi: x => x * 1e3, base: 'A', desc: 'Milliampere' },
  V:     { dim: [2, 1, -3, -1, 0, 0, 0], toSi: x => x, fromSi: x => x, base: 'V', desc: 'Volt' },
  mV:    { dim: [2, 1, -3, -1, 0, 0, 0], toSi: x => x * 1e-3, fromSi: x => x * 1e3, base: 'V', desc: 'Millivolt' },
  Hz:    { dim: [0, 0, -1, 0, 0, 0, 0], toSi: x => x, fromSi: x => x, base: 'Hz', desc: 'Hertz' },
  kHz:   { dim: [0, 0, -1, 0, 0, 0, 0], toSi: x => x * 1e3, fromSi: x => x * 1e-3, base: 'Hz', desc: 'Kilohertz' },
  rpm:   { dim: [0, 0, -1, 0, 0, 0, 0], toSi: x => x / 60, fromSi: x => x * 60, base: 'Hz', desc: 'RPM' },

  // Flow & Volume
  L:     { dim: [3, 0, 0, 0, 0, 0, 0], toSi: x => x * 1e-3, fromSi: x => x * 1e3, base: 'm^3', desc: 'Litre' },
  litre: { dim: [3, 0, 0, 0, 0, 0, 0], toSi: x => x * 1e-3, fromSi: x => x * 1e3, base: 'm^3', desc: 'Litre' },
  gallon:{ dim: [3, 0, 0, 0, 0, 0, 0], toSi: x => x * 0.003785411784, fromSi: x => x / 0.003785411784, base: 'm^3', desc: 'US Gallon' }
};

// 1. Conversion API
app.post('/api/convert', (req, res) => {
  try {
    const { value, from, to } = req.body;
    if (value === undefined || !from || !to) {
      return res.status(400).json({ error: 'Missing parameters: value, from, to required.' });
    }
    const specFrom = UNIT_SPECS[from];
    const specTo = UNIT_SPECS[to];
    if (!specFrom) return res.status(400).json({ error: `Unknown source unit '${from}'` });
    if (!specTo) return res.status(400).json({ error: `Unknown destination unit '${to}'` });

    // Dimensional validation
    const dimsMatch = specFrom.dim.every((d, i) => d === specTo.dim[i]);
    if (!dimsMatch) {
      return res.status(400).json({
        error: `Incompatible dimensions: Cannot convert '${from}' (${specFrom.desc}) to '${to}' (${specTo.desc})`,
        dimensions: { from: specFrom.dim, to: specTo.dim }
      });
    }

    const siVal = specFrom.toSi(Number(value));
    const resultVal = specTo.fromSi(siVal);
    return res.json({
      original_value: Number(value),
      from_unit: from,
      converted_value: resultVal,
      to_unit: to,
      si_value: siVal,
      si_base_unit: specFrom.base
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown server error';
    return res.status(500).json({ error: message });
  }
});

// 2. Tolerance & GD&T Conformity API
app.post('/api/tolerance', (req, res) => {
  try {
    const { actual, nominal, upper_tol, lower_tol, uncertainty = 0, guardband_factor = 0 } = req.body;
    const act = Number(actual);
    const nom = Number(nominal);
    const uTol = Math.abs(Number(upper_tol || 0.1));
    const lTol = Math.abs(Number(lower_tol || 0.1));

    const usl = nom + uTol;
    const lsl = nom - lTol;
    const span = usl - lsl;

    const uslGuard = usl - (Number(guardband_factor) * Number(uncertainty));
    const lslGuard = lsl + (Number(guardband_factor) * Number(uncertainty));

    const deviation = act - nom;
    const pctDeviation = nom !== 0 ? (deviation / Math.abs(nom)) * 100 : 0;
    const pctToleranceUsed = span > 0 ? ((act - lsl) / span) * 100 : 50;

    const pass = act >= lslGuard && act <= uslGuard;
    const status = pass ? 'PASS' : (act > usl ? 'FAIL_HIGH' : 'FAIL_LOW');

    return res.json({
      nominal: nom,
      actual: act,
      usl,
      lsl,
      deviation,
      percentage_deviation: pctDeviation,
      tolerance_span: span,
      percentage_tolerance_consumed: pctToleranceUsed,
      guardbanded_usl: uslGuard,
      guardbanded_lsl: lslGuard,
      pass,
      status
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown server error';
    return res.status(500).json({ error: message });
  }
});

// 3. Uncertainty & GUM Evaluation API
app.post('/api/uncertainty', (req, res) => {
  try {
    const { measured_value, observations, type_b_components = [], confidence = 0.95 } = req.body;
    const val = Number(measured_value);

    // Type A: SD of mean
    let typeA = 0;
    if (Array.isArray(observations) && observations.length > 1) {
      const clean = observations.map(Number).filter(x => !isNaN(x));
      const n = clean.length;
      if (n > 1) {
        const mean = clean.reduce((a, b) => a + b, 0) / n;
        const variance = clean.reduce((acc, x) => acc + Math.pow(x - mean, 2), 0) / (n - 1);
        typeA = Math.sqrt(variance) / Math.sqrt(n);
      }
    }

    // Type B components
    const typeBValues: number[] = [];
    for (const comp of type_b_components) {
      const bound = Number(comp.bound || 0.001);
      const dist = (comp.dist || 'rectangular').toLowerCase();
      let div = Math.sqrt(3);
      if (dist === 'triangular') div = Math.sqrt(6);
      else if (dist === 'normal' || dist === 'gaussian') div = Number(comp.k || 2);
      else if (dist === 'u_shaped') div = Math.sqrt(2);
      typeBValues.push(bound / div);
    }

    const allU = [typeA, ...typeBValues];
    const u_c = Math.sqrt(allU.reduce((acc, u) => acc + Math.pow(u, 2), 0));

    // Coverage factor k for 95% is ~1.96 / 2.0
    const k = confidence >= 0.99 ? 2.576 : (confidence >= 0.9545 ? 2.0 : 1.96);
    const U = u_c * k;

    return res.json({
      measured_value: val,
      type_a_uncertainty: typeA,
      type_b_uncertainties: typeBValues,
      combined_uncertainty: u_c,
      coverage_factor: k,
      expanded_uncertainty: U,
      confidence_level: confidence,
      formatted: `${val.toFixed(4)} ± ${U.toFixed(4)} (k=${k.toFixed(2)}, ${(confidence * 100).toFixed(1)}% CI)`
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown server error';
    return res.status(500).json({ error: message });
  }
});

// 4. Statistical Process Control (SPC) & Quality API
app.post('/api/spc', (req, res) => {
  try {
    const { values, usl, lsl, nominal } = req.body;
    if (!Array.isArray(values) || values.length < 3) {
      return res.status(400).json({ error: 'At least 3 measurement values are required.' });
    }
    const clean = values.map(Number).filter(v => !isNaN(v));
    const n = clean.length;
    const mean = clean.reduce((a, b) => a + b, 0) / n;
    const variance = clean.reduce((acc, x) => acc + Math.pow(x - mean, 2), 0) / (n - 1);
    const totalSd = Math.sqrt(variance);

    // Moving range for within-subgroup variation
    const mr = [];
    for (let i = 1; i < n; i++) mr.push(Math.abs(clean[i] - clean[i - 1]));
    const mrBar = mr.reduce((a, b) => a + b, 0) / mr.length;
    const withinSd = mrBar / 1.128;

    const uSpec = Number(usl);
    const lSpec = Number(lsl);
    const span = uSpec - lSpec;

    const cp = span / (6 * withinSd);
    const cpu = (uSpec - mean) / (3 * withinSd);
    const cpl = (mean - lSpec) / (3 * withinSd);
    const cpk = Math.min(cpu, cpl);

    const pp = span / (6 * totalSd);
    const ppu = (uSpec - mean) / (3 * totalSd);
    const ppl = (mean - lSpec) / (3 * totalSd);
    const ppk = Math.min(ppu, ppl);

    // Control limits for Individuals (I-MR)
    const ucl = mean + 3 * withinSd;
    const lcl = mean - 3 * withinSd;

    return res.json({
      n,
      mean,
      total_sd: totalSd,
      within_sd: withinSd,
      usl: uSpec,
      lsl: lSpec,
      nominal: Number(nominal || (uSpec + lSpec) / 2),
      Cp: cp,
      Cpk: cpk,
      Pp: pp,
      Ppk: ppk,
      ucl,
      lcl,
      center_line: mean,
      capability_rating: cpk >= 1.67 ? 'World-Class Six Sigma' : (cpk >= 1.33 ? 'Capable' : (cpk >= 1.0 ? 'Marginal' : 'Not Capable'))
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown server error';
    return res.status(500).json({ error: message });
  }
});

// 5. Signal Processing & FFT Spectrum API
app.post('/api/signal/fft', (req, res) => {
  try {
    const { signal, sampling_rate_hz = 1000 } = req.body;
    if (!Array.isArray(signal) || signal.length < 8) {
      return res.status(400).json({ error: 'Signal vector of length >= 8 required.' });
    }
    const x = signal.map(Number);
    const N = x.length;
    const mean = x.reduce((a, b) => a + b, 0) / N;
    const detrended = x.map(v => v - mean);

    // Discrete Fourier Transform
    const freqs: number[] = [];
    const magnitudes: number[] = [];
    const psd: number[] = [];
    const halfN = Math.floor(N / 2);

    for (let k = 0; k <= halfN; k++) {
      let re = 0;
      let im = 0;
      for (let nIdx = 0; nIdx < N; nIdx++) {
        const phi = (2 * Math.PI * k * nIdx) / N;
        re += detrended[nIdx] * Math.cos(phi);
        im -= detrended[nIdx] * Math.sin(phi);
      }
      const mag = Math.sqrt(re * re + im * im) / N * (k === 0 ? 1 : 2);
      const freq = (k * Number(sampling_rate_hz)) / N;
      freqs.push(freq);
      magnitudes.push(mag);
      psd.push((mag * mag) / (Number(sampling_rate_hz) / N));
    }

    let peakIdx = 1;
    let maxMag = 0;
    for (let i = 1; i < magnitudes.length; i++) {
      if (magnitudes[i] > maxMag) {
        maxMag = magnitudes[i];
        peakIdx = i;
      }
    }

    return res.json({
      dominant_frequency_hz: freqs[peakIdx] || 0,
      peak_amplitude: maxMag,
      sampling_rate_hz: Number(sampling_rate_hz),
      spectrum: freqs.slice(0, 100).map((f, i) => ({
        frequency: f,
        magnitude: magnitudes[i],
        psd: psd[i]
      }))
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown server error';
    return res.status(500).json({ error: message });
  }
});

// 6. Simulation & Stream Generator API
app.post('/api/simulate', (req, res) => {
  try {
    const { nominal = 100, noise = 0.05, n = 200, drift_rate = 0.0001, outlier_pct = 0.02, temp_cycle = false } = req.body;
    const count = Math.min(10000, Math.max(10, Number(n)));
    const nom = Number(nominal);
    const noiseStd = Number(noise);
    const drift = Number(drift_rate);

    const data = [];
    const now = Date.now();

    for (let i = 0; i < count; i++) {
      // Gaussian noise (Box-Muller)
      const u1 = Math.random() || 1e-6;
      const u2 = Math.random() || 1e-6;
      const gaussianNoise = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2) * noiseStd;

      const tempEffect = temp_cycle ? Math.sin((i / 50) * Math.PI) * 0.08 : 0;
      let val = nom + i * drift + gaussianNoise + tempEffect;

      const isOutlier = Math.random() < Number(outlier_pct);
      if (isOutlier) {
        val += (Math.random() > 0.5 ? 1 : -1) * noiseStd * 6;
      }

      data.push({
        index: i + 1,
        timestamp: new Date(now + i * 1000).toISOString(),
        raw_value: val,
        nominal: nom,
        is_outlier: isOutlier,
        temperature: 20 + (temp_cycle ? Math.sin((i / 50) * Math.PI) * 5 : 0)
      });
    }

    return res.json({
      nominal: nom,
      samples_generated: count,
      data
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown server error';
    return res.status(500).json({ error: message });
  }
});

// 7. R Engine Code Explorer & Files Provider API
app.get('/api/r-files', (_req, res) => {
  try {
    const rDir = join(process.cwd(), 'MeasurementEngine/R');
    const testsDir = join(process.cwd(), 'MeasurementEngine/tests');
    const results: { name: string; path: string; category: string; content: string }[] = [];

    if (existsSync(rDir)) {
      const files = readdirSync(rDir);
      for (const f of files) {
        if (f.endsWith('.R')) {
          const content = readFileSync(join(rDir, f), 'utf-8');
          results.push({ name: f, path: `MeasurementEngine/R/${f}`, category: 'R Core Module', content });
        }
      }
    }

    if (existsSync(testsDir)) {
      const testFiles = readdirSync(testsDir);
      for (const f of testFiles) {
        if (f.endsWith('.R')) {
          const content = readFileSync(join(testsDir, f), 'utf-8');
          results.push({ name: f, path: `MeasurementEngine/tests/${f}`, category: 'Test Suite', content });
        }
      }
    }

    return res.json({ files: results });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown server error';
    return res.status(500).json({ error: message });
  }
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
