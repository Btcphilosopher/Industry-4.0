#!/usr/bin/env Rscript
# ==============================================================================
# sla_risk_monte_carlo.R - Monte Carlo Fulfillment SLA Breach Risk Estimator
# Simulates stochastic picking, conveyor sortation, and loading variations.
# ==============================================================================

suppressPackageStartupMessages({
  if (!require("jsonlite", quietly = TRUE)) {}
})

run_sla_monte_carlo <- function(input_json_str) {
  # Input format:
  # { "order_count": 500, "target_sla_minutes": 45, "amr_travel_mean": 8, "amr_travel_sd": 2.5, "pick_pack_mean": 18, "pick_pack_sd": 6, "staging_load_mean": 12, "staging_load_sd": 4, "simulations": 10000 }

  data <- tryCatch({
    if (requireNamespace("jsonlite", quietly = TRUE)) {
      jsonlite::fromJSON(input_json_str)
    } else {
      list(target_sla_minutes = 45, amr_travel_mean = 8, amr_travel_sd = 2.5, pick_pack_mean = 18, pick_pack_sd = 6, staging_load_mean = 12, staging_load_sd = 4, simulations = 10000)
    }
  }, error = function(e) {
    list(target_sla_minutes = 45, amr_travel_mean = 8, amr_travel_sd = 2.5, pick_pack_mean = 18, pick_pack_sd = 6, staging_load_mean = 12, staging_load_sd = 4, simulations = 10000)
  })

  sla_limit <- as.numeric(data$target_sla_minutes)
  n_sims <- ifelse(is.null(data$simulations), 10000, as.integer(data$simulations))

  set.seed(42) # Deterministic reproducibility

  # Simulate log-normal / gamma distributed process durations
  t_travel <- rnorm(n_sims, mean = as.numeric(data$amr_travel_mean), sd = as.numeric(data$amr_travel_sd))
  t_travel <- pmax(t_travel, 1.0)

  t_pick_pack <- rnorm(n_sims, mean = as.numeric(data$pick_pack_mean), sd = as.numeric(data$pick_pack_sd))
  t_pick_pack <- pmax(t_pick_pack, 2.0)

  t_staging <- rnorm(n_sims, mean = as.numeric(data$staging_load_mean), sd = as.numeric(data$staging_load_sd))
  t_staging <- pmax(t_staging, 1.5)

  # Total end-to-end fulfillment duration distribution
  t_total <- t_travel + t_pick_pack + t_staging

  # Calculate breach metrics
  breaches <- sum(t_total > sla_limit)
  breach_prob <- breaches / n_sims

  quantiles <- quantile(t_total, probs = c(0.50, 0.90, 0.95, 0.99))

  # Expected penalty risk assuming $25 per minute delayed
  penalty_per_min <- 25.0
  delays <- pmax(t_total - sla_limit, 0)
  expected_penalty_per_order <- mean(delays) * penalty_per_min

  output <- list(
    target_sla_minutes = sla_limit,
    simulations_conducted = n_sims,
    mean_duration_minutes = round(mean(t_total), 2),
    sd_duration_minutes = round(sd(t_total), 2),
    p50_minutes = round(quantiles["50%"], 2),
    p90_minutes = round(quantiles["90%"], 2),
    p95_minutes = round(quantiles["95%"], 2),
    p99_minutes = round(quantiles["99%"], 2),
    sla_breach_probability = round(breach_prob, 4),
    risk_classification = ifelse(breach_prob > 0.10, "HIGH_RISK", ifelse(breach_prob > 0.03, "MODERATE_RISK", "LOW_RISK")),
    expected_penalty_usd_per_order = round(expected_penalty_per_order, 2),
    timestamp = format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
  )

  if (requireNamespace("jsonlite", quietly = TRUE)) {
    return(jsonlite::toJSON(output, auto_unbox = TRUE, pretty = TRUE))
  } else {
    return(paste0('{"breach_prob":', breach_prob, ',"risk":"', output$risk_classification, '"}'))
  }
}

args <- commandArgs(trailingOnly = TRUE)
if (length(args) > 0) {
  cat(run_sla_monte_carlo(args[1]))
} else {
  sample_payload <- '{"target_sla_minutes":45,"amr_travel_mean":8,"amr_travel_sd":2.5,"pick_pack_mean":18,"pick_pack_sd":6,"staging_load_mean":12,"staging_load_sd":4,"simulations":10000}'
  cat(run_sla_monte_carlo(sample_payload), "\n")
}
