#!/usr/bin/env Rscript
# ==============================================================================
# energy_tariff_optimizer.R - Dynamic Peak-Shaving & Battery Charging Scheduler
# Optimizes robot charging windows across fluctuating hourly grid spot tariffs.
# ==============================================================================

suppressPackageStartupMessages({
  if (!require("jsonlite", quietly = TRUE)) {}
})

run_energy_optimization <- function(input_json_str) {
  # Input format:
  # { "hourly_tariffs_usd_kwh": [0.12, 0.11, 0.09, 0.08, 0.10, 0.16, 0.28, 0.35, 0.38, 0.32, 0.29, 0.26, 0.24, 0.22, 0.21, 0.28, 0.39, 0.42, 0.36, 0.30, 0.24, 0.19, 0.15, 0.13], "total_robots": 80, "charger_count": 24 }

  data <- tryCatch({
    if (requireNamespace("jsonlite", quietly = TRUE)) {
      jsonlite::fromJSON(input_json_str)
    } else {
      list(hourly_tariffs_usd_kwh = c(0.12, 0.11, 0.09, 0.08, 0.10, 0.16, 0.28, 0.35, 0.38, 0.32, 0.29, 0.26, 0.24, 0.22, 0.21, 0.28, 0.39, 0.42, 0.36, 0.30, 0.24, 0.19, 0.15, 0.13), total_robots = 80, charger_count = 24)
    }
  }, error = function(e) {
    list(hourly_tariffs_usd_kwh = rep(0.20, 24), total_robots = 50, charger_count = 15)
  })

  tariffs <- as.numeric(data$hourly_tariffs_usd_kwh)
  n_robots <- as.integer(data$total_robots)
  n_chargers <- as.integer(data$charger_count)

  # Determine optimal charging power allocated per hour
  # Rank hours by electricity price
  price_order <- order(tariffs)
  
  # Base required daily charging energy: 80 robots * 1.8 kWh battery = 144 kWh total
  total_energy_needed_kwh <- n_robots * 1.8
  charger_max_rate_kw <- 3.5 # 3.5 kW DC fast charge per stall
  max_hourly_kwh <- n_chargers * charger_max_rate_kw

  # Greedy cost minimization allocation across cheapest tariff hours
  hourly_charge_kwh <- rep(0, 24)
  remaining_energy <- total_energy_needed_kwh

  for (h in price_order) {
    if (remaining_energy <= 0) break
    allocated <- min(max_hourly_kwh, remaining_energy)
    hourly_charge_kwh[h] <- allocated
    remaining_energy <- remaining_energy - allocated
  }

  baseline_cost <- sum(tariffs * (total_energy_needed_kwh / 24))
  optimized_cost <- sum(tariffs * hourly_charge_kwh)
  savings_pct <- round(100 * (baseline_cost - optimized_cost) / baseline_cost, 1)

  # Identify peak hours where robot tasks should be prioritized over charging
  peak_hours <- which(tariffs >= quantile(tariffs, 0.75))

  output <- list(
    total_robots = n_robots,
    charger_capacity_count = n_chargers,
    total_energy_kwh = round(total_energy_needed_kwh, 2),
    unmanaged_daily_cost_usd = round(baseline_cost, 2),
    optimized_daily_cost_usd = round(optimized_cost, 2),
    cost_savings_percentage = savings_pct,
    peak_tariff_hours = peak_hours - 1, # 0-indexed hours
    hourly_recommended_charging_kwh = round(hourly_charge_kwh, 2),
    tariff_profile = round(tariffs, 3),
    timestamp = format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
  )

  if (requireNamespace("jsonlite", quietly = TRUE)) {
    return(jsonlite::toJSON(output, auto_unbox = TRUE, pretty = TRUE))
  } else {
    return(paste0('{"savings_pct":', savings_pct, '}'))
  }
}

args <- commandArgs(trailingOnly = TRUE)
if (length(args) > 0) {
  cat(run_energy_optimization(args[1]))
} else {
  sample_payload <- '{"total_robots":100,"charger_count":30,"hourly_tariffs_usd_kwh":[0.12,0.11,0.09,0.08,0.10,0.16,0.28,0.35,0.38,0.32,0.29,0.26,0.24,0.22,0.21,0.28,0.39,0.42,0.36,0.30,0.24,0.19,0.15,0.13]}'
  cat(run_energy_optimization(sample_payload), "\n")
}
