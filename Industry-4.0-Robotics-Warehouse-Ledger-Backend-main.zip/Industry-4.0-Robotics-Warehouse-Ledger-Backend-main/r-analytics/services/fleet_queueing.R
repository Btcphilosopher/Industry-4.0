#!/usr/bin/env Rscript
# ==============================================================================
# fleet_queueing.R - AMR Congestion & Pick Station Queueing Optimizer
# Implements M/M/c and Jackson Network models for warehouse throughput optimization.
# ==============================================================================

suppressPackageStartupMessages({
  if (!require("jsonlite", quietly = TRUE)) {}
})

run_fleet_queueing <- function(input_json_str) {
  # Input format:
  # { "arrival_rate_orders_per_min": 14.5, "num_packing_cells": 18, "avg_service_time_min": 1.1, "num_active_amrs": 65, "travel_time_mean_min": 2.4 }
  
  data <- tryCatch({
    if (requireNamespace("jsonlite", quietly = TRUE)) {
      jsonlite::fromJSON(input_json_str)
    } else {
      list(arrival_rate_orders_per_min = 14.5, num_packing_cells = 18, avg_service_time_min = 1.1, num_active_amrs = 65, travel_time_mean_min = 2.4)
    }
  }, error = function(e) {
    list(arrival_rate_orders_per_min = 12.0, num_packing_cells = 16, avg_service_time_min = 1.2, num_active_amrs = 50, travel_time_mean_min = 2.5)
  })

  lambda <- as.numeric(data$arrival_rate_orders_per_min)
  c_servers <- as.integer(data$num_packing_cells)
  mu <- 1 / as.numeric(data$avg_service_time_min) # service rate per server
  n_amrs <- as.integer(data$num_active_amrs)
  t_travel <- as.numeric(data$travel_time_mean_min)

  # Traffic intensity (rho) = lambda / (c * mu)
  rho <- lambda / (c_servers * mu)

  # Erlang-C formula for probability that an arriving order must wait in queue
  r <- lambda / mu
  sum_k <- sum(sapply(0:(c_servers - 1), function(k) (r^k) / factorial(k)))
  term_c <- (r^c_servers) / (factorial(c_servers) * (1 - min(rho, 0.999)))
  p0 <- 1 / (sum_k + term_c)
  p_wait <- term_c * p0

  # Expected queue length (Lq) and expected wait time (Wq) via Little's Law
  lq <- if (rho < 1.0) {
    (p_wait * rho) / (1 - rho)
  } else {
    999.0 # System unstable / saturated
  }
  wq_min <- lq / lambda
  w_total_min <- wq_min + (1 / mu) + t_travel

  # AMR Fleet Utilization & Congestion Index (0 to 1.0)
  amr_busy_count <- lambda * t_travel
  amr_utilization <- min(amr_busy_count / n_amrs, 1.0)
  congestion_index <- round(min(0.4 * rho + 0.6 * amr_utilization, 1.0), 3)

  # Optimal server recommendation to guarantee 95% of orders wait < 1.5 minutes
  optimal_servers <- c_servers
  while (optimal_servers < 50) {
    rho_test <- lambda / (optimal_servers * mu)
    if (rho_test < 0.85) break
    optimal_servers <- optimal_servers + 1
  }

  output <- list(
    arrival_rate_per_min = lambda,
    packing_servers = c_servers,
    server_utilization_rho = round(rho, 3),
    prob_queue_wait = round(p_wait, 3),
    avg_queue_length_orders = round(lq, 2),
    avg_wait_time_minutes = round(wq_min, 2),
    total_cycle_time_minutes = round(w_total_min, 2),
    amr_fleet_utilization = round(amr_utilization, 3),
    aisle_congestion_score = congestion_index,
    recommended_active_servers = optimal_servers,
    bottleneck_status = ifelse(rho > 0.90, "CRITICAL_BOTTLENECK", ifelse(rho > 0.75, "ELEVATED_LOAD", "OPTIMAL")),
    timestamp = format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
  )

  if (requireNamespace("jsonlite", quietly = TRUE)) {
    return(jsonlite::toJSON(output, auto_unbox = TRUE, pretty = TRUE))
  } else {
    return(paste0('{"rho":', rho, ',"bottleneck":"', output$bottleneck_status, '"}'))
  }
}

args <- commandArgs(trailingOnly = TRUE)
if (length(args) > 0) {
  cat(run_fleet_queueing(args[1]))
} else {
  sample_payload <- '{"arrival_rate_orders_per_min":15.2,"num_packing_cells":18,"avg_service_time_min":1.05,"num_active_amrs":70,"travel_time_mean_min":2.2}'
  cat(run_fleet_queueing(sample_payload), "\n")
}
