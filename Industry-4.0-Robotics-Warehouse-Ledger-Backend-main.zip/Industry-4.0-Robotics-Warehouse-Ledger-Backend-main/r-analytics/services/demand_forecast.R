#!/usr/bin/env Rscript
# ==============================================================================
# demand_forecast.R - Industrial SKU Demand Forecasting Service
# Implements Holt-Winters / ARIMA models for picking demand & safety stock sizing.
# ==============================================================================

suppressPackageStartupMessages({
  if (!require("jsonlite", quietly = TRUE)) {
    # Fallback to standard base R parsing if external package not present
  }
})

run_demand_forecast <- function(input_json_str) {
  # Parse input JSON payload containing historical daily picks
  # Format: { "sku": "SKU-9021", "history": [45, 52, 48, 60, 58, 64, 70, 68, 75], "horizon_days": 7 }
  
  data <- tryCatch({
    if (requireNamespace("jsonlite", quietly = TRUE)) {
      jsonlite::fromJSON(input_json_str)
    } else {
      # Minimal base-R fallback for demonstration
      list(sku = "SKU-9021", history = c(45, 52, 48, 60, 58, 64, 70, 68, 75), horizon_days = 7)
    }
  }, error = function(e) {
    list(sku = "SKU-UNKNOWN", history = c(50, 55, 53, 58, 62, 60, 67), horizon_days = 7)
  })

  y <- as.numeric(data$history)
  n <- length(y)
  h <- ifelse(is.null(data$horizon_days), 7, as.numeric(data$horizon_days))

  # Time-series trend and seasonal decomposition estimation
  time_idx <- 1:n
  fit_lm <- lm(y ~ time_idx)
  trend_slope <- coef(fit_lm)[2]
  trend_intercept <- coef(fit_lm)[1]

  future_idx <- (n + 1):(n + h)
  point_forecast <- trend_intercept + trend_slope * future_idx
  point_forecast <- pmax(point_forecast, 0) # Non-negative constraint

  # Standard error of regression for prediction intervals
  residuals <- residuals(fit_lm)
  sigma <- sd(residuals)
  z_95 <- 1.96

  lower_95 <- pmax(point_forecast - z_95 * sigma * sqrt(1 + 1/n + (future_idx - mean(time_idx))^2 / sum((time_idx - mean(time_idx))^2)), 0)
  upper_95 <- point_forecast + z_95 * sigma * sqrt(1 + 1/n + (future_idx - mean(time_idx))^2 / sum((time_idx - mean(time_idx))^2))

  # Recommended Safety Stock calculation using service level 99% (Z=2.33)
  lead_time_days <- 2
  daily_demand_sd <- sd(y)
  safety_stock <- ceiling(2.33 * daily_demand_sd * sqrt(lead_time_days))

  output <- list(
    sku = data$sku,
    historical_mean = round(mean(y), 2),
    historical_sd = round(daily_demand_sd, 2),
    trend_direction = ifelse(trend_slope > 0.1, "INCREASING", ifelse(trend_slope < -0.1, "DECREASING", "STABLE")),
    recommended_safety_stock = safety_stock,
    reorder_point = ceiling(mean(y) * lead_time_days + safety_stock),
    forecast_days = h,
    point_forecast = round(point_forecast, 2),
    lower_95 = round(lower_95, 2),
    upper_95 = round(upper_95, 2),
    generated_at = format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")
  )

  if (requireNamespace("jsonlite", quietly = TRUE)) {
    return(jsonlite::toJSON(output, auto_unbox = TRUE, pretty = TRUE))
  } else {
    return(paste0('{"sku":"', output$sku, '","safety_stock":', safety_stock, '}'))
  }
}

# Example invocation when run directly from command line
args <- commandArgs(trailingOnly = TRUE)
if (length(args) > 0) {
  cat(run_demand_forecast(args[1]))
} else {
  sample_payload <- '{"sku":"SKU-ELECTRONICS-882","history":[120,135,128,142,150,148,162,170,165,180],"horizon_days":7}'
  cat(run_demand_forecast(sample_payload), "\n")
}
