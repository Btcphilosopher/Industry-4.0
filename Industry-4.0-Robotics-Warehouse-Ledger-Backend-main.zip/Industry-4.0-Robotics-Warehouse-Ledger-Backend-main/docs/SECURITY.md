# Security Architecture & Cryptographic Integrity

## 1. Multi-Tier Identity Model

The platform enforces distinct cryptographic identities:
1. **Machine Identity (AMRs, Arms, PLCs)**: Hardware-bound Ed25519 keypairs stored in TPM 2.0 or secure enclaves. All robot mission updates and telemetry digests are signed at the edge.
2. **Human Operator Identity**: FIDO2/WebAuthn hardware tokens + mTLS X.509 client certificates with role-based attributes.
3. **Enterprise Organization Identity**: Multi-sig root certificates representing Warehouse Operators, 3PL partners, Carriers, and Auditing firms.
4. **Service Identity**: SPIFFE/SPIRE-attested workloads with ephemeral mTLS credentials rotated every 60 minutes.

## 2. Cryptographic Hashing & Tamper-Evident Chains

Every transaction record carries:
- `event_hash`: $H(\text{timestamp} \mathbin{\Vert} \text{event\_type} \mathbin{\Vert} \text{actor} \mathbin{\Vert} \text{payload} \mathbin{\Vert} \text{prev\_hash})$
- `signature`: Ed25519 signature by the initiating entity.
- `nonce`: Monotonically increasing sequence number per actor to prevent replay attacks.

```
┌─────────────────┐       ┌─────────────────┐       ┌─────────────────┐
│     Event A     │       │     Event B     │       │     Event C     │
│ Hash: 0x8f2a... │◀──────│ Prev: 0x8f2a... │◀──────│ Prev: 0x3d11... │
│ Sign: [Robot01] │       │ Hash: 0x3d11... │       │ Hash: 0x9b4c... │
└─────────────────┘       └─────────────────┘       └─────────────────┘
```

Any modification to historical row data in PostgreSQL immediately invalidates the subsequent event hash chain and mismatches the on-chain Merkle root commitment.

## 3. Role-Based & Attribute-Based Access Control (RBAC/ABAC)

| Role | Telemetry Ingest | Ledger Mutation | Batch Anchoring | Maintenance Certify | SLA Override |
| :--- | :---: | :---: | :---: | :---: | :---: |
| `ROBOT_AGENT` | ✅ (Self) | ✅ (Task only) | ❌ | ❌ | ❌ |
| `WAREHOUSE_OPERATOR` | ❌ | ✅ (Pick/Pack) | ❌ | ❌ | ❌ |
| `CERTIFIED_TECHNICIAN` | ❌ | ❌ | ❌ | ✅ | ❌ |
| `LEDGER_COMMITTER` | ❌ | ❌ | ✅ | ❌ | ❌ |
| `THIRD_PARTY_AUDITOR` | ❌ (Read only) | ❌ | ❌ | ❌ | ❌ |
| `SYSTEM_ADMIN` | ✅ | ✅ | ✅ | ✅ | ❌ |

## 4. Key Management & Rotation

- Ephemeral transaction signing keys rotated automatically.
- Compromised machine keys are immediately blacklisted on-chain via the `RobotRegistryContract.revokeKey(address robotId, string reason)`.
