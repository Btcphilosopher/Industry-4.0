# API Gateway & Communication Protocols

## 1. Interface Protocols

The backend exposes 3 primary interfaces:
1. **REST API (JSON/HTTP2)**: For standard resource administration, batch submissions, querying provenance, and audit reporting.
2. **gRPC (HTTP/2 + Protocol Buffers)**: For microsecond-latency internal service inter-op, task dispatching, and R analytics exchange.
3. **WebSocket (`/ws`)**: For real-time telemetry streaming, live robot kinematic updates, and instant blockchain finality events.

## 2. REST Endpoints Overview

| Method | Path | Description |
| :--- | :--- | :--- |
| `GET` | `/api/v1/warehouses` | List registered warehouses, sites, zones, and bins |
| `POST` | `/api/v1/inventory/transactions` | Submit a double-entry inventory movement |
| `GET` | `/api/v1/inventory/units/:id/provenance` | Get full cryptographic chain-of-custody for a unit |
| `GET` | `/api/v1/robots` | List robot fleet status, battery SoC, operational state |
| `POST` | `/api/v1/robots/:id/missions` | Dispatch mission to AMR with Ed25519 signature |
| `POST` | `/api/v1/maintenance/certify` | Submit certified maintenance log signed by technician |
| `GET` | `/api/v1/blockchain/commitments` | List anchored Merkle roots and block heights |
| `POST` | `/api/v1/blockchain/verify-proof` | Verify Merkle inclusion proof for a warehouse event |
| `GET` | `/api/v1/analytics/demand-forecast` | Get R-computed SKU demand forecast and confidence intervals |
| `GET` | `/api/v1/analytics/predictive-maintenance` | Get R Weibull failure risk curve for fleet assets |
| `GET` | `/api/v1/economics/marginal-cost` | Calculate real-time marginal cost breakdown per order |
| `GET` | `/api/v1/energy/ledger` | Query kWh consumption per order, zone, and peak tariff status |

## 3. gRPC Protobuf Definition Preview

```protobuf
syntax = "proto3";
package warehouse.industrial.v1;

service FleetOrchestrationService {
  rpc ReportRobotTelemetry (stream TelemetryPacket) returns (TelemetryAck);
  rpc SubmitMissionTransition (MissionStateUpdate) returns (TransactionReceipt);
  rpc QueryAssetProvenance (AssetQuery) returns (ProvenanceReport);
}

message TelemetryPacket {
  string robot_id = 1;
  int64 timestamp_ns = 2;
  double pos_x = 3;
  double pos_y = 4;
  double battery_soc = 5;
  double motor_current = 6;
  bytes cryptographic_signature = 7;
}
```
