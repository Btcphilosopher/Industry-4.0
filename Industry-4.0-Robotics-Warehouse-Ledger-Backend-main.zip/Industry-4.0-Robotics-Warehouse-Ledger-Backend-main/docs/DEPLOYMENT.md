# Production Deployment & Infrastructure

## 1. Multi-Target Deployment

The platform is designed to deploy seamlessly across:
- **Bare-Metal On-Premises Industrial PCs**: Direct NVMe-backed storage for microsecond I/O.
- **Docker Compose (Local/Dev/Staging)**: Full-stack single-command orchestration.
- **Kubernetes (Production Edge/Cloud Clusters)**: Highly available multi-node topology with StatefulSets for TimescaleDB and Rust services.

## 2. Docker Compose Topology

```yaml
services:
  rust-backend:
    build:
      context: ./warehouse-backend
      dockerfile: Dockerfile
    ports:
      - "8080:8080" # REST & WS
      - "50051:50051" # gRPC
    environment:
      - DATABASE_URL=postgres://warehouse:secret@timescaledb:5432/industrial_warehouse
      - R_SERVICE_URL=http://r-analytics:8000
      - BLOCKCHAIN_RPC=http://blockchain-node:8545
    depends_on:
      - timescaledb
      - r-analytics

  r-analytics:
    build:
      context: ./r-analytics
      dockerfile: Dockerfile
    ports:
      - "8000:8000"

  timescaledb:
    image: timescale/timescaledb-ha:pg16
    ports:
      - "5432:5432"
    volumes:
      - pgdata:/home/postgres/pgdata/data

  blockchain-node:
    image: hyperledger/besu:latest
    ports:
      - "8545:8545"

  prometheus:
    image: prom/prometheus:latest
    ports:
      - "9090:9090"
```
