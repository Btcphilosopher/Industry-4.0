# Operations & Site Reliability Engineering

## 1. Edge-First Resilience Architecture

A robotic warehouse must remain fully functional if wide-area network (WAN) or corporate cloud connectivity fails:
- **Local Edge Cluster**: Every facility runs local Rust API gateways, local TimescaleDB instance, embedded RocksDB event journals, and a local permissioned blockchain validator node.
- **Store-and-Forward Commitment Queue**: If corporate network or blockchain peer connectivity is degraded, events continue recording to local WAL. Outbound commitments are buffered and replayed in strict monotonic sequence once connectivity restores.

## 2. Observability & SRE Metrics

The system exposes OpenTelemetry traces and Prometheus-compatible metrics on port `9090`:

- `warehouse_events_total{type, status}`: Event ingestion throughput (target: >50k events/sec).
- `inventory_ledger_balance_invariants_checked`: Double-entry conservation checks passed.
- `merkle_batch_commit_duration_seconds`: Batch hashing and on-chain anchor latency.
- `robot_telemetry_ingest_rate_hz`: Sensor ingestion frequency.
- `r_optimization_cycle_duration_ms`: Statistical simulation execution time.
- `blockchain_settlement_lag_blocks`: Pending commitments waiting on-chain confirmation.

## 3. Disaster Recovery & Snapshotting

- Daily cryptographic snapshot of the full warehouse digital twin state.
- State root hash committed to the distributed ledger at midnight UTC.
- Instant state reconstitution from Merkle root + event replay stream.
