# System Architecture: Industry 4.0 Robotics Warehouse

## 1. High-Level Principles

The Industry 4.0 Robotic Warehouse backend operates on a strict separation of concerns:
- **Python**: Real-time perception, digital twin rendering, motion planning, AI vision inference, high-level fleet dispatching.
- **Rust Industrial Engine**: Authoritative transaction serialization, double-entry inventory ledger, event canonicalization, machine cryptographic signing, and Merkle tree batching.
- **TimescaleDB / PostgreSQL**: Operational time-series telemetry (position, velocity, vibration, current) and ACID relational records.
- **R Subsystem**: Advanced statistical process control, queueing theory, predictive maintenance, and energy pricing optimization.
- **Permissioned Blockchain**: Multi-party non-repudiable audit logs, asset provenance, digital product passports, and SLA settlement.

```
                    ┌─────────────────────────────┐
                    │     Python Orchestrator     │
                    │   (WMS/WCS/Fleet/Twin/AI)   │
                    └──────────────┬──────────────┘
                                   │ gRPC / REST / WS
                    ┌──────────────▼──────────────┐
                    │      Rust Backend Core      │
                    │                             │
                    │ ┌─────────────────────────┐ │
                    │ │  Event Canonicalizer    │ │
                    │ └────────────┬────────────┘ │
                    │              │              │
                    │ ┌────────────▼────────────┐ │
                    │ │   Double-Entry Ledger   │ │
                    │ └────────────┬────────────┘ │
                    │              │              │
                    │ ┌────────────▼────────────┐ │
                    │ │   Merkle Batch Engine   │ │
                    │ └─────────────────────────┘ │
                    └───────┬─────────────┬───────┘
                            │             │
              ┌─────────────▼────┐   ┌────▼─────────────┐
              │  PostgreSQL /    │   │   Permissioned   │
              │  TimescaleDB     │   │    Blockchain    │
              └─────────────┬────┘   └──────────────────┘
                            │
                    ┌───────▼────────┐
                    │  R Analytics   │
                    │  Optimization  │
                    └────────────────┘
```

## 2. Data Flow Architecture

### 2.1 High-Frequency Operational Data (100 Hz - 1 kHz)
- Data: Robot coordinate $(x,y,z)$, IMU, motor encoder currents, LiDAR point clusters, conveyor tachometers.
- Path: Edge Robot $\to$ UDP/mTLS $\to$ Ingest Buffer $\to$ TimescaleDB Hypertable (with 24h rolling compression).
- Blockchain footprint: **Zero**.

### 2.2 Transactional Industrial Events (1 - 100 Hz)
- Data: State transitions (`INVENTORY_PICKED`, `PALLET_TRANSFERRED`, `MAINTENANCE_LOGGED`).
- Path: Robot/Operator $\to$ Rust Transaction Engine $\to$ Invariant Validation $\to$ Event Store $\to$ Merkle Batch Buffer.
- Blockchain footprint: **Merkle Root Hash periodically anchored every $N$ seconds or $M$ transactions**.

### 2.3 Cryptographic Batching Pipeline
```
[Event E1, Event E2, ... Event En]
            │
            ▼ SHA-256 Canonical Serialization
[H(E1), H(E2), ... H(En)]
            │
            ▼ Balanced Binary Merkle Tree
       [Merkle Root R]
            │
            ▼ Smart Contract Invoke
Blockchain Transaction: anchorBatch(R, batchId, timestamp, eventCount)
```

## 3. Double-Entry Inventory Conservation

Inventory cannot appear or disappear. Every unit state change is balanced across balance accounts:
- Locations (Source Bin $\to$ Destination Bin)
- State Accounts (Unreceived $\to$ In-Inspection $\to$ Available $\to$ Allocated $\to$ In-Transit $\to$ Shipped)
- Invariant equation:
  $$\sum \text{Stock}_{\text{Physical}} + \sum \text{Stock}_{\text{In-Transit}} = \text{Initial Inventory} + \text{Goods Received} - \text{Goods Dispatched} - \text{Scrap}$$

## 4. Resilience & Offline-First Guarantees

If the blockchain network experiences latency or disconnection:
1. Operations continue without pausing;
2. Event batches are committed to local append-only WAL on SSD;
3. Asynchronous queue monitors block finality;
4. Upon reconnection, caught-up batches are submitted with sequential batch nonces.
Robots are never blocked on distributed consensus latency.
