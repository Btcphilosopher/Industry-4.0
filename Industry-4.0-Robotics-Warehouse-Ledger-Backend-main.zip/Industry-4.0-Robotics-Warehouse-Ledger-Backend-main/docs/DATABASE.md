# Database Architecture & Storage Engine

## 1. Hybrid Relational + Time-Series Engine

The persistent layer separates ACID state transitions from high-throughput sensor telemetry:
- **PostgreSQL 16**: Relational master for warehouses, inventory balance ledgers, contracts, and audit trails.
- **TimescaleDB**: Hypertables for high-frequency telemetry, robot velocity, battery temperature, motor vibration, and conveyor power.

## 2. Relational Schema Blueprint

```
┌────────────────────────────────┐       ┌────────────────────────────────┐
│           warehouses           │       │             zones              │
├────────────────────────────────┤       ├────────────────────────────────┤
│ id: UUID (PK)                  │◀──────│ id: UUID (PK)                  │
│ code: VARCHAR(32) UNIQUE       │       │ warehouse_id: UUID (FK)        │
│ name: VARCHAR(128)             │       │ zone_type: VARCHAR(32)         │
│ site_lat: NUMERIC, lon: NUMERIC│       │ name: VARCHAR(64)              │
└────────────────────────────────┘       └────────────────┬───────────────┘
                                                          │
                                         ┌────────────────▼───────────────┐
                                         │           locations            │
                                         ├────────────────────────────────┤
                                         │ id: UUID (PK)                  │
                                         │ zone_id: UUID (FK)             │
                                         │ aisle: INT, rack: INT          │
                                         │ shelf: INT, bin: INT           │
                                         │ barcode: VARCHAR(64) UNIQUE    │
                                         └────────────────────────────────┘
```

## 3. Core Tables

- `inventory_units`: Unique tracking units (SKU, Lot, Serial, Pallet ID, Location ID, State).
- `inventory_transactions`: Double-entry transaction log (Source Loc, Dest Loc, Debit/Credit, Actor ID, Nonce, Event Hash).
- `robots`: Robot identity, Model, Serial, Manufacturer, Firmware, Operating Hours, State, Battery, Public Key.
- `robot_tasks`: Task lifecycle (Accepted, Started, Reached, Picked, Delivered, Completed), Assigned Robot, Mission Hash.
- `asset_maintenance_records`: Diagnostic log, Technician ID, Parts Replaced, Cost, Cryptographic signature.
- `event_store`: Append-only event stream table with `event_id`, `event_hash`, `prev_hash`, `canonical_payload`, `batch_id`.
- `blockchain_commitments`: Anchored Merkle batches (`batch_id`, `merkle_root`, `tx_hash`, `block_number`, `verified_at`).
- `energy_consumption_ledger`: Granular energy breakdown (Robot charging, Conveyors, HVAC, Packaging).

## 4. TimescaleDB Telemetry Hypertables

- `telemetry_robot_kinematics`: Timestamp, Robot ID, $(x,y,\theta)$, Velocity, Acceleration.
- `telemetry_robot_powertrain`: Timestamp, Robot ID, Battery SoC, Voltage, Motor Current, Inverter Temp.
- `telemetry_vibration_spectra`: Timestamp, Asset ID, RMS Vibration, Peak Kurtosis, FFT Spectral Energy.

Hypertables are configured with a 7-day uncompressed retention window and 90-day compressed columnar storage with chunk time intervals of 2 hours.
