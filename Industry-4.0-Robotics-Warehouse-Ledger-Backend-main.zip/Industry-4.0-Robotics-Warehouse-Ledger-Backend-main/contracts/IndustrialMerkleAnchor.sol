// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title IndustrialMerkleAnchor
 * @notice Anchors cryptographic batch roots of high-frequency warehouse events.
 */
contract IndustrialMerkleAnchor {
    struct BatchCommitment {
        uint256 batchId;
        bytes32 merkleRoot;
        uint32 eventCount;
        uint64 timestamp;
        address committedBy;
        string dataUri;
    }

    address public owner;
    mapping(address => bool) public authorizedCommitters;
    mapping(uint256 => BatchCommitment) public commitments;
    mapping(bytes32 => bool) public knownRoots;
    uint256 public totalBatchesAnchored;

    event BatchAnchored(
        uint256 indexed batchId,
        bytes32 indexed merkleRoot,
        uint32 eventCount,
        uint64 timestamp,
        address indexed committer
    );

    modifier onlyCommitter() {
        require(authorizedCommitters[msg.sender] || msg.sender == owner, "Not authorized committer");
        _;
    }

    constructor() {
        owner = msg.sender;
        authorizedCommitters[msg.sender] = true;
    }

    function setCommitter(address committer, bool authorized) external {
        require(msg.sender == owner, "Only owner");
        authorizedCommitters[committer] = authorized;
    }

    function anchorBatchRoot(
        uint256 batchId,
        bytes32 merkleRoot,
        uint32 eventCount,
        string calldata dataUri
    ) external onlyCommitter {
        require(commitments[batchId].timestamp == 0, "Batch ID already anchored");
        require(merkleRoot != bytes32(0), "Invalid Merkle root");

        commitments[batchId] = BatchCommitment({
            batchId: batchId,
            merkleRoot: merkleRoot,
            eventCount: eventCount,
            timestamp: uint64(block.timestamp),
            committedBy: msg.sender,
            dataUri: dataUri
        });

        knownRoots[merkleRoot] = true;
        totalBatchesAnchored++;

        emit BatchAnchored(batchId, merkleRoot, eventCount, uint64(block.timestamp), msg.sender);
    }

    function verifyInclusion(
        bytes32 leaf,
        bytes32[] calldata proof,
        bytes32 root
    ) public pure returns (bool) {
        bytes32 computedHash = leaf;
        for (uint256 i = 0; i < proof.length; i++) {
            bytes32 proofElement = proof[i];
            if (computedHash <= proofElement) {
                computedHash = keccak256(abi.encodePacked(computedHash, proofElement));
            } else {
                computedHash = keccak256(abi.encodePacked(proofElement, computedHash));
            }
        }
        return computedHash == root;
    }
}
