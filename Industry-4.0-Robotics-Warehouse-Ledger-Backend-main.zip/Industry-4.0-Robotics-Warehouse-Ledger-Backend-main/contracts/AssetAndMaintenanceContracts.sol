// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title AssetAndMaintenanceContracts
 * @notice Combines Asset Provenance, Robot Identity Registry, Maintenance Certifications and SLA Penalties.
 */

contract AssetProvenanceContract {
    struct AssetRecord {
        bytes32 assetTagHash;
        string model;
        string manufacturer;
        uint64 manufacturedDate;
        uint32 operatingHours;
        bytes32 firmwareHash;
        address currentOwner;
        bool active;
    }

    mapping(bytes32 => AssetRecord) public assets;
    mapping(address => bool) public authorizedOEMs;
    address public contractOwner;

    event AssetRegistered(bytes32 indexed assetId, string model, string manufacturer, address owner);
    event FirmwareUpdated(bytes32 indexed assetId, bytes32 indexed newFirmwareHash);
    event OperatingHoursLogged(bytes32 indexed assetId, uint32 totalHours);

    constructor() {
        contractOwner = msg.sender;
        authorizedOEMs[msg.sender] = true;
    }

    function registerAsset(
        bytes32 assetId,
        bytes32 assetTagHash,
        string calldata model,
        string calldata manufacturer,
        uint64 manufacturedDate,
        bytes32 firmwareHash,
        address owner
    ) external {
        require(assets[assetId].manufacturedDate == 0, "Asset already registered");
        assets[assetId] = AssetRecord({
            assetTagHash: assetTagHash,
            model: model,
            manufacturer: manufacturer,
            manufacturedDate: manufacturedDate,
            operatingHours: 0,
            firmwareHash: firmwareHash,
            currentOwner: owner,
            active: true
        });
        emit AssetRegistered(assetId, model, manufacturer, owner);
    }
}

contract MaintenanceCertificateContract {
    struct MaintenanceCert {
        bytes32 certId;
        bytes32 assetId;
        address certifiedTechnician;
        bytes32 faultCodeHash;
        bytes32 partsHash;
        uint32 downtimeMinutes;
        uint64 certifiedAt;
        bool safetyPassed;
    }

    mapping(bytes32 => MaintenanceCert) public certificates;
    mapping(address => bool) public certifiedTechnicians;
    address public registryAdmin;

    event MaintenanceCertified(
        bytes32 indexed certId,
        bytes32 indexed assetId,
        address indexed technician,
        bool safetyPassed
    );

    constructor() {
        registryAdmin = msg.sender;
        certifiedTechnicians[msg.sender] = true;
    }

    function certifyMaintenance(
        bytes32 certId,
        bytes32 assetId,
        bytes32 faultCodeHash,
        bytes32 partsHash,
        uint32 downtimeMinutes,
        bool safetyPassed
    ) external {
        require(certifiedTechnicians[msg.sender], "Caller not a certified technician");
        require(certificates[certId].certifiedAt == 0, "Certificate already logged");

        certificates[certId] = MaintenanceCert({
            certId: certId,
            assetId: assetId,
            certifiedTechnician: msg.sender,
            faultCodeHash: faultCodeHash,
            partsHash: partsHash,
            downtimeMinutes: downtimeMinutes,
            certifiedAt: uint64(block.timestamp),
            safetyPassed: safetyPassed
        });

        emit MaintenanceCertified(certId, assetId, msg.sender, safetyPassed);
    }
}

contract SLAEnforcementContract {
    struct ServiceContract {
        bytes32 contractId;
        address customer;
        uint32 maxFulfillmentMinutes;
        uint256 penaltyWeiPerMinute;
        bool active;
    }

    mapping(bytes32 => ServiceContract) public contracts;
    address public warehouseOracle;

    event SLABreachDetected(
        bytes32 indexed contractId,
        bytes32 indexed orderId,
        uint32 delayedMinutes,
        uint256 penaltyAmount
    );

    constructor() {
        warehouseOracle = msg.sender;
    }

    function evaluateFulfillment(
        bytes32 contractId,
        bytes32 orderId,
        uint64 orderTimestamp,
        uint64 dispatchTimestamp
    ) external returns (bool fulfilled, uint32 delayMinutes, uint256 penalty) {
        ServiceContract memory sc = contracts[contractId];
        require(sc.active, "Inactive SLA contract");

        uint64 elapsedMinutes = (dispatchTimestamp - orderTimestamp) / 60;
        if (elapsedMinutes <= sc.maxFulfillmentMinutes) {
            return (true, 0, 0);
        }

        delayMinutes = uint32(elapsedMinutes - sc.maxFulfillmentMinutes);
        penalty = uint256(delayMinutes) * sc.penaltyWeiPerMinute;

        emit SLABreachDetected(contractId, orderId, delayMinutes, penalty);
        return (false, delayMinutes, penalty);
    }
}
