// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title InventoryLedgerContract
 * @notice Enforces state machine transitions and provenance verification for industrial inventory units.
 */
contract InventoryLedgerContract {
    enum InventoryState {
        NONE,
        RECEIVED,
        INSPECTED,
        AVAILABLE,
        ALLOCATED,
        PICKED,
        PACKED,
        STAGED,
        LOADED,
        SHIPPED,
        QUARANTINED,
        DAMAGED
    }

    struct UnitStateRecord {
        bytes32 skuHash;
        bytes32 lotHash;
        uint32 quantity;
        InventoryState currentState;
        uint64 lastUpdated;
        bytes32 lastTransactionHash;
        address currentCustodian;
    }

    mapping(bytes32 => UnitStateRecord) public units;
    mapping(address => bool) public authorizedNodes;
    address public owner;

    event InventoryStateTransition(
        bytes32 indexed unitId,
        InventoryState indexed previousState,
        InventoryState indexed newState,
        uint32 quantity,
        bytes32 txHash,
        address custodian
    );

    constructor() {
        owner = msg.sender;
        authorizedNodes[msg.sender] = true;
    }

    modifier onlyAuthorized() {
        require(authorizedNodes[msg.sender] || msg.sender == owner, "Unauthorized warehouse node");
        _;
    }

    function isValidTransition(InventoryState from, InventoryState to) public pure returns (bool) {
        if (from == InventoryState.NONE && to == InventoryState.RECEIVED) return true;
        if (from == InventoryState.RECEIVED && (to == InventoryState.INSPECTED || to == InventoryState.QUARANTINED)) return true;
        if (from == InventoryState.INSPECTED && (to == InventoryState.AVAILABLE || to == InventoryState.QUARANTINED)) return true;
        if (from == InventoryState.AVAILABLE && to == InventoryState.ALLOCATED) return true;
        if (from == InventoryState.ALLOCATED && to == InventoryState.PICKED) return true;
        if (from == InventoryState.PICKED && to == InventoryState.PACKED) return true;
        if (from == InventoryState.PACKED && to == InventoryState.STAGED) return true;
        if (from == InventoryState.STAGED && to == InventoryState.LOADED) return true;
        if (from == InventoryState.LOADED && to == InventoryState.SHIPPED) return true;
        if (to == InventoryState.DAMAGED || to == InventoryState.QUARANTINED) return true;
        return false;
    }

    function recordTransition(
        bytes32 unitId,
        bytes32 skuHash,
        bytes32 lotHash,
        uint32 quantity,
        InventoryState targetState,
        bytes32 txHash,
        address custodian
    ) external onlyAuthorized {
        UnitStateRecord storage record = units[unitId];
        require(isValidTransition(record.currentState, targetState), "Illegal inventory state machine transition");

        InventoryState oldState = record.currentState;
        record.skuHash = skuHash;
        record.lotHash = lotHash;
        record.quantity = quantity;
        record.currentState = targetState;
        record.lastUpdated = uint64(block.timestamp);
        record.lastTransactionHash = txHash;
        record.currentCustodian = custodian;

        emit InventoryStateTransition(unitId, oldState, targetState, quantity, txHash, custodian);
    }
}
