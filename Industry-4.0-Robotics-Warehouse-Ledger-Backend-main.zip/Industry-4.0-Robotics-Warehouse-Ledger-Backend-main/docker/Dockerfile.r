FROM r-base:4.4.1
RUN apt-get update && apt-get install -y python3 python3-pip && rm -rf /var/lib/apt/lists/*
RUN R -e "install.packages(c('jsonlite', 'forecast'), repos='https://cloud.r-project.org/')"
WORKDIR /app
COPY . /app
EXPOSE 8000
ENTRYPOINT ["python3", "bridge/r_ipc_bridge.py", "8000"]
