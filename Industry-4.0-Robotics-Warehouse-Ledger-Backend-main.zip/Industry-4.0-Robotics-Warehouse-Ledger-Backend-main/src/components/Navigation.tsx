import React from 'react';
import { 
  Boxes, 
  Cpu, 
  Layers, 
  LineChart, 
  ShieldCheck, 
  Zap, 
  FileSearch, 
  Sliders, 
  Code2, 
  BookOpen, 
  Activity,
  Server
} from 'lucide-react';

export type TabKey =
  | 'digital-twin'
  | 'inventory-ledger'
  | 'blockchain-merkle'
  | 'r-optimization'
  | 'asset-maintenance'
  | 'economics-energy'
  | 'audit-provenance'
  | 'simulation'
  | 'api-playground'
  | 'documentation';

interface NavigationProps {
  activeTab: TabKey;
  onSelectTab: (tab: TabKey) => void;
  systemStatus: {
    activeRobots: number;
    totalUnits: number;
    blocksAnchored: number;
    spotTariff: number;
  };
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  onSelectTab,
  systemStatus,
}) => {
  const navItems: { key: TabKey; label: string; icon: React.ReactNode; badge?: string }[] = [
    { key: 'digital-twin', label: 'Robotics Digital Twin', icon: <Cpu className="w-3.5 h-3.5" />, badge: `${systemStatus.activeRobots} AMRs` },
    { key: 'inventory-ledger', label: 'Double-Entry Ledger', icon: <Boxes className="w-3.5 h-3.5" /> },
    { key: 'blockchain-merkle', label: 'Merkle & Blockchain', icon: <Layers className="w-3.5 h-3.5" />, badge: `#${systemStatus.blocksAnchored}` },
    { key: 'r-optimization', label: 'R Analytics & Stats', icon: <LineChart className="w-3.5 h-3.5" /> },
    { key: 'asset-maintenance', label: 'Asset Certification', icon: <ShieldCheck className="w-3.5 h-3.5" /> },
    { key: 'economics-energy', label: 'Economics & Energy', icon: <Zap className="w-3.5 h-3.5" />, badge: `$${systemStatus.spotTariff}/kWh` },
    { key: 'audit-provenance', label: 'Provenance & Audit', icon: <FileSearch className="w-3.5 h-3.5" /> },
    { key: 'simulation', label: 'Load Simulation', icon: <Sliders className="w-3.5 h-3.5" /> },
    { key: 'api-playground', label: 'API & Python SDK', icon: <Code2 className="w-3.5 h-3.5" /> },
    { key: 'documentation', label: 'Architecture Docs', icon: <BookOpen className="w-3.5 h-3.5" /> },
  ];

  return (
    <header className="bg-[#0D0D0D] border-b border-[#262626] text-[#D4D4D8] sticky top-0 z-50">
      {/* Top Status Strip */}
      <div className="max-w-7xl mx-auto px-4 py-2 flex flex-wrap items-center justify-between border-b border-[#1E1E1E] text-xs text-[#71717A]">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-1.5">
            <span className="w-2 h-2 rounded-full bg-[#4ADE80] animate-pulse"></span>
            <span className="font-semibold text-white uppercase tracking-widest text-[10px]">AutonCore L1</span>
          </div>
          <span className="text-[#333333]">|</span>
          <span className="text-[#A1A1AA]">WH-GLOBAL-01 (High-Bay Fulfilment Center)</span>
          <span className="text-[#333333]">|</span>
          <span className="font-mono bg-[#141414] text-[#C5A059] px-2 py-0.5 rounded text-[11px] border border-[#262626]">
            TimescaleDB 1kHz Telemetry
          </span>
        </div>

        <div className="flex items-center space-x-5 text-[11px]">
          <div className="flex items-center space-x-1.5">
            <Activity className="w-3.5 h-3.5 text-[#4ADE80]" />
            <span>Consensus: <span className="text-[#4ADE80] font-medium font-mono">PoA Finalized</span></span>
          </div>
          <div className="flex items-center space-x-1.5">
            <Server className="w-3.5 h-3.5 text-[#C5A059]" />
            <span>R Analytics: <span className="text-[#C5A059] font-medium font-mono">IPC Active</span></span>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between py-3 overflow-x-auto scrollbar-none">
          <div className="flex items-center space-x-3 mr-6 shrink-0">
            <div className="w-9 h-9 rounded bg-[#141414] border border-[#262626] flex items-center justify-center text-[#C5A059]">
              <Boxes className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-base font-serif italic tracking-wide text-white">
                  Aurelian <span className="font-sans not-italic text-sm font-semibold text-[#D4D4D8]">Robotics Ledger</span>
                </h1>
                <span className="text-[9px] uppercase font-mono tracking-wider px-1.5 py-0.5 bg-[#1A1A1A] text-[#C5A059] border border-[#C5A059]/30 rounded">
                  Rust Core
                </span>
              </div>
              <p className="text-[10px] uppercase tracking-[0.2em] text-[#71717A]">Autonomous Industrial Operating OS</p>
            </div>
          </div>

          <nav className="flex items-center space-x-1 shrink-0">
            {navItems.map((item) => {
              const isActive = activeTab === item.key;
              return (
                <button
                  key={item.key}
                  onClick={() => onSelectTab(item.key)}
                  className={`flex items-center space-x-1.5 px-3 py-1.5 rounded text-xs font-medium transition-colors whitespace-nowrap ${
                    isActive
                      ? 'bg-[#1A1A1A] text-[#C5A059] border border-[#C5A059]/40 shadow-sm'
                      : 'text-[#A1A1AA] hover:text-white hover:bg-[#141414] border border-transparent'
                  }`}
                >
                  {item.icon}
                  <span>{item.label}</span>
                  {item.badge && (
                    <span className={`ml-1 text-[10px] px-1.5 py-0.2 rounded font-mono ${
                      isActive ? 'bg-[#0A0A0A] text-[#C5A059] border border-[#C5A059]/30' : 'bg-[#141414] text-[#71717A] border border-[#262626]'
                    }`}>
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>
      </div>
    </header>
  );
};

