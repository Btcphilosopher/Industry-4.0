import React, { useState } from 'react';
import { MarginalCostReport } from '../types';
import { DollarSign, Zap, PieChart, TrendingDown, Cpu, ArrowUpRight } from 'lucide-react';

export const EconomicsEnergyView: React.FC = () => {
  const [orderCost, setOrderCost] = useState<MarginalCostReport>({
    orderId: 'ORD-2026-9812',
    pickLaborCost: 1.26,
    robotEnergyCost: 0.28,
    robotAmortizationCost: 0.45,
    packagingCost: 1.45,
    conveyorCost: 0.35,
    congestionPremium: 0.0,
    totalCostUsd: 3.79,
  });

  const costBreakdown = [
    { label: 'Manual/Cobot Pick Labor', amount: orderCost.pickLaborCost, pct: 33.2, color: 'bg-[#C5A059]' },
    { label: 'Packaging Materials', amount: orderCost.packagingCost, pct: 38.3, color: 'bg-[#D4D4D8]' },
    { label: 'AMR Fleet Amortization', amount: orderCost.robotAmortizationCost, pct: 11.9, color: 'bg-[#71717A]' },
    { label: 'Conveyor Sortation', amount: orderCost.conveyorCost, pct: 9.2, color: 'bg-[#52525B]' },
    { label: 'Electric Energy Consumed', amount: orderCost.robotEnergyCost, pct: 7.4, color: 'bg-[#4ADE80]' },
  ];

  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="bg-[#141414] border border-[#262626] rounded p-6">
        <div className="flex items-center justify-between pb-4 border-b border-[#262626]">
          <div>
            <p className="text-[10px] uppercase tracking-[0.2em] text-[#71717A]">Unit Economics</p>
            <h2 className="text-lg font-serif text-white mt-0.5 flex items-center gap-2">
              Industrial Economics & Energy Accounting Engine
            </h2>
          </div>
          <span className="text-[11px] font-mono text-[#4ADE80] bg-[#0A0A0A] px-3 py-1 rounded border border-[#262626]">
            Marginal Cost Engine Active
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-5 text-xs">
          <div className="p-4 bg-[#0A0A0A] rounded border border-[#262626]">
            <span className="text-[#71717A] text-[10px] uppercase tracking-wider block">Cost / Fulfilled Order</span>
            <span className="text-2xl font-serif text-white mt-1 block font-mono">${orderCost.totalCostUsd}</span>
            <span className="text-[10px] uppercase font-mono text-[#4ADE80] mt-0.5 block">Target SLA: 45 min</span>
          </div>

          <div className="p-4 bg-[#0A0A0A] rounded border border-[#262626]">
            <span className="text-[#71717A] text-[10px] uppercase tracking-wider block">Energy / Order</span>
            <span className="text-2xl font-serif text-[#C5A059] mt-1 block font-mono">1.51 kWh</span>
            <span className="text-[10px] uppercase tracking-wider text-[#52525B] mt-0.5 block">Transit + Packing</span>
          </div>

          <div className="p-4 bg-[#0A0A0A] rounded border border-[#262626]">
            <span className="text-[#71717A] text-[10px] uppercase tracking-wider block">Current Spot Tariff</span>
            <span className="text-2xl font-serif text-white mt-1 block font-mono">$0.185 / kWh</span>
            <span className="text-[10px] uppercase font-mono text-[#4ADE80] mt-0.5 block">Off-Peak Window Active</span>
          </div>

          <div className="p-4 bg-[#0A0A0A] rounded border border-[#262626]">
            <span className="text-[#71717A] text-[10px] uppercase tracking-wider block">Facility Power Draw</span>
            <span className="text-2xl font-serif text-[#4ADE80] mt-1 block font-mono">159.0 kW</span>
            <span className="text-[10px] uppercase tracking-wider text-[#52525B] mt-0.5 block">Baseload + 4 AMRs Charging</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Granular Marginal Cost Breakdown */}
        <div className="bg-[#141414] border border-[#262626] rounded p-6">
          <div className="flex items-center justify-between pb-4 border-b border-[#262626]">
            <div>
              <p className="text-[10px] uppercase tracking-widest text-[#71717A]">OPEX Allocation</p>
              <h3 className="text-base font-serif text-white mt-0.5 flex items-center gap-2">
                Marginal Cost Breakdown ({orderCost.orderId})
              </h3>
            </div>
            <span className="text-xs font-mono font-bold text-[#C5A059] bg-[#0A0A0A] px-2.5 py-1 rounded border border-[#262626]">
              Total: ${orderCost.totalCostUsd}
            </span>
          </div>

          <div className="mt-5 space-y-4 text-xs">
            {costBreakdown.map((item, idx) => (
              <div key={idx} className="space-y-1.5">
                <div className="flex justify-between text-[#D4D4D8]">
                  <span>{item.label}</span>
                  <span className="font-mono font-semibold">${item.amount.toFixed(2)} ({item.pct}%)</span>
                </div>
                <div className="w-full h-1.5 bg-[#0A0A0A] rounded-full overflow-hidden border border-[#262626]">
                  <div className={`h-full ${item.color}`} style={{ width: `${item.pct}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Energy Accounting & Substation Balance */}
        <div className="bg-[#141414] border border-[#262626] rounded p-6">
          <div className="flex items-center justify-between pb-4 border-b border-[#262626]">
            <div>
              <p className="text-[10px] uppercase tracking-widest text-[#71717A]">Substation Distribution</p>
              <h3 className="text-base font-serif text-white mt-0.5 flex items-center gap-2">
                Facility & Fleet Power Ledger
              </h3>
            </div>
            <span className="text-[11px] font-mono text-[#4ADE80] bg-[#0A0A0A] px-2.5 py-1 rounded border border-[#262626]">
              Grid Factor: 0.98 PF
            </span>
          </div>

          <div className="mt-5 grid grid-cols-2 gap-3 text-xs">
            <div className="p-3.5 bg-[#0A0A0A] rounded border border-[#262626] space-y-1">
              <span className="text-[#71717A] text-[10px] uppercase tracking-wider block">HVAC & Environmental</span>
              <span className="font-mono text-lg font-bold text-white block">85.0 kW</span>
              <span className="text-[10px] text-[#52525B] block">18.5°C constant</span>
            </div>

            <div className="p-3.5 bg-[#0A0A0A] rounded border border-[#262626] space-y-1">
              <span className="text-[#71717A] text-[10px] uppercase tracking-wider block">Conveyor & Sortation</span>
              <span className="font-mono text-lg font-bold text-white block">45.0 kW</span>
              <span className="text-[10px] text-[#52525B] block">VFDs active</span>
            </div>

            <div className="p-3.5 bg-[#0A0A0A] rounded border border-[#262626] space-y-1">
              <span className="text-[#71717A] text-[10px] uppercase tracking-wider block">Fleet Fast Charging</span>
              <span className="font-mono text-lg font-bold text-[#C5A059] block">14.0 kW</span>
              <span className="text-[10px] text-[#52525B] block">4 Stalls @ 3.5 kW DC</span>
            </div>

            <div className="p-3.5 bg-[#0A0A0A] rounded border border-[#262626] space-y-1">
              <span className="text-[#71717A] text-[10px] uppercase tracking-wider block">Cells & Robotics Arms</span>
              <span className="font-mono text-lg font-bold text-[#4ADE80] block">15.0 kW</span>
              <span className="text-[10px] text-[#52525B] block">Regen braking enabled</span>
            </div>
          </div>

          <div className="mt-4 p-3.5 bg-[#0A0A0A] rounded border border-[#262626] flex items-center justify-between text-xs">
            <div className="flex items-center space-x-2">
              <TrendingDown className="w-4 h-4 text-[#4ADE80]" />
              <span className="text-[#D4D4D8]">Dynamic Tariff Optimization:</span>
            </div>
            <span className="font-semibold text-[#4ADE80] uppercase tracking-wider text-[11px] font-mono">SHIFTING TO OFF-PEAK</span>
          </div>
        </div>
      </div>
    </div>
  );
};

