import React, { useState } from 'react';
import { InventoryUnitEntity, RobotEntity } from '../types';
import { FileSearch, Search, ArrowDown, ShieldCheck, CheckCircle2, Cpu, Truck, Package, Wrench, Zap } from 'lucide-react';

interface AuditProvenanceViewProps {
  units: InventoryUnitEntity[];
  robots: RobotEntity[];
}

export const AuditProvenanceView: React.FC<AuditProvenanceViewProps> = ({ units, robots }) => {
  const [activeQueryType, setActiveQueryType] = useState<'PALLET' | 'ROBOT'>('PALLET');
  const [selectedPalletId, setSelectedPalletId] = useState(units[0]?.palletId || 'PLT-48102');
  const [selectedRobotCode, setSelectedRobotCode] = useState(robots[0]?.code || 'RBT-AMR-0001');

  const currentUnit = units.find((u) => u.palletId === selectedPalletId) || units[0];
  const currentRobot = robots.find((r) => r.code === selectedRobotCode) || robots[0];

  const palletSteps = [
    { title: 'Supplier Manufacturing & Dispatch', actor: currentUnit.originSupplier, time: '2026-08-18T08:30:00Z', hash: '0x8f2a9910cbe441928019a...', icon: <Truck className="w-4 h-4 text-[#C5A059]" /> },
    { title: 'Inbound Carrier Cross-Border Transit', actor: 'DHL Supply Chain Industrial', time: '2026-08-19T14:15:00Z', hash: '0x3d115e47891aa029f8112...', icon: <Truck className="w-4 h-4 text-[#D4D4D8]" /> },
    { title: 'Warehouse Goods Receipt & Inspection', actor: 'RECEIVING-DOCK-01 (X.509 Signed)', time: '2026-08-20T09:00:00Z', hash: '0x9b4c771920ae883719001...', icon: <CheckCircle2 className="w-4 h-4 text-[#4ADE80]" /> },
    { title: 'Automated Putaway to High-Bay Storage', actor: 'RBT-AMR-0003 (Ed25519 Signed)', time: '2026-08-20T09:25:00Z', hash: '0x1a82ee99104fae8992019...', icon: <Cpu className="w-4 h-4 text-[#C5A059]" /> },
    { title: 'Goods-to-Person Autonomous Pick', actor: currentUnit.currentCustodian, time: currentUnit.updatedAt, hash: currentUnit.latestEventHash, icon: <Package className="w-4 h-4 text-[#D4D4D8]" /> },
  ];

  return (
    <div className="space-y-6">
      {/* Selector Banner */}
      <div className="bg-[#141414] border border-[#262626] rounded p-6">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-[#262626]">
          <div>
            <p className="text-[10px] uppercase tracking-[0.2em] text-[#71717A]">Custody Verification</p>
            <h2 className="text-lg font-serif text-white mt-0.5 flex items-center gap-2">
              Cryptographic Deep-Audit & Provenance Engine
            </h2>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => setActiveQueryType('PALLET')}
              className={`px-3 py-1.5 rounded text-xs font-mono uppercase tracking-wider transition-colors cursor-pointer ${
                activeQueryType === 'PALLET'
                  ? 'bg-[#C5A059] text-[#0A0A0A] font-bold'
                  : 'bg-[#0A0A0A] border border-[#262626] text-[#71717A] hover:text-white'
              }`}
            >
              Pallet / SKU Provenance
            </button>
            <button
              onClick={() => setActiveQueryType('ROBOT')}
              className={`px-3 py-1.5 rounded text-xs font-mono uppercase tracking-wider transition-colors cursor-pointer ${
                activeQueryType === 'ROBOT'
                  ? 'bg-[#C5A059] text-[#0A0A0A] font-bold'
                  : 'bg-[#0A0A0A] border border-[#262626] text-[#71717A] hover:text-white'
              }`}
            >
              Robot Lifecycle History
            </button>
          </div>
        </div>

        <div className="mt-4 flex flex-wrap items-center gap-3 text-xs">
          {activeQueryType === 'PALLET' ? (
            <>
              <span className="text-[#71717A] uppercase text-[10px] tracking-wider">Select Tracking ID:</span>
              <select
                value={selectedPalletId}
                onChange={(e) => setSelectedPalletId(e.target.value)}
                className="bg-[#0A0A0A] border border-[#262626] rounded p-2 font-mono text-white text-xs focus:outline-none focus:border-[#C5A059]"
              >
                {units.map((u) => (
                  <option key={u.id} value={u.palletId}>
                    {u.palletId} — {u.sku} (State: {u.state})
                  </option>
                ))}
              </select>
            </>
          ) : (
            <>
              <span className="text-[#71717A] uppercase text-[10px] tracking-wider">Select Machine ID:</span>
              <select
                value={selectedRobotCode}
                onChange={(e) => setSelectedRobotCode(e.target.value)}
                className="bg-[#0A0A0A] border border-[#262626] rounded p-2 font-mono text-white text-xs focus:outline-none focus:border-[#C5A059]"
              >
                {robots.map((r) => (
                  <option key={r.id} value={r.code}>
                    {r.code} — {r.model} (Status: {r.status})
                  </option>
                ))}
              </select>
            </>
          )}
        </div>
      </div>

      {activeQueryType === 'PALLET' ? (
        /* Pallet Provenance Timeline */
        <div className="bg-[#141414] border border-[#262626] rounded p-6">
          <div className="flex items-center justify-between pb-4 border-b border-[#262626]">
            <div>
              <p className="text-[10px] uppercase tracking-[0.2em] text-[#71717A]">Verifiable Custody Trail</p>
              <h3 className="text-base font-serif text-white mt-0.5">
                Chain of Custody for Pallet {currentUnit.palletId} ({currentUnit.sku})
              </h3>
              <p className="text-xs text-[#71717A] font-mono mt-0.5">
                Lot: {currentUnit.lotNumber} • Serial: {currentUnit.serialNumber} • Origin: {currentUnit.originSupplier}
              </p>
            </div>
            <span className="text-[10px] text-[#4ADE80] font-mono uppercase bg-[#0A0A0A] px-2.5 py-1 rounded border border-[#262626]">
              Cryptographically Verified
            </span>
          </div>

          <div className="mt-6 space-y-5 max-w-3xl">
            {palletSteps.map((step, idx) => (
              <div key={idx} className="relative flex items-start space-x-4">
                <div className="p-2.5 rounded bg-[#0A0A0A] border border-[#262626] shrink-0 z-10">
                  {step.icon}
                </div>
                {idx < palletSteps.length - 1 && (
                  <div className="absolute top-10 left-[18px] -ml-px w-0.5 h-12 bg-[#262626]" />
                )}
                <div className="flex-1 bg-[#0A0A0A] rounded border border-[#262626] p-4 text-xs space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white tracking-wide text-sm">{step.title}</span>
                    <span className="text-[10px] text-[#71717A] font-mono">{new Date(step.time).toLocaleString()}</span>
                  </div>
                  <div className="text-[#A1A1AA] text-[11px]">
                    <span className="text-[#71717A] uppercase text-[10px] tracking-wider mr-1.5">Authorized Actor:</span>
                    <strong className="text-white">{step.actor}</strong>
                  </div>
                  <div className="pt-1.5 font-mono text-[10px] text-[#C5A059] truncate border-t border-[#1E1E1E]">
                    Commitment Hash: {step.hash}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        /* Robot 12-Month Lifecycle History */
        <div className="bg-[#141414] border border-[#262626] rounded p-6 space-y-5">
          <div className="flex items-center justify-between pb-4 border-b border-[#262626]">
            <div>
              <p className="text-[10px] uppercase tracking-[0.2em] text-[#71717A]">Machine Attestation</p>
              <h3 className="text-base font-serif text-white mt-0.5">
                12-Month Lifecycle Dossier for {currentRobot.code}
              </h3>
              <p className="text-xs text-[#71717A] font-mono mt-0.5">
                Serial: SN-2026-90412 • Manufacturer: {currentRobot.manufacturer} • Firmware: {currentRobot.firmware}
              </p>
            </div>
            <span className="text-[10px] text-[#C5A059] font-mono uppercase bg-[#0A0A0A] px-2.5 py-1 rounded border border-[#262626]">
              RobotContract.sol Attested
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
            <div className="p-4 bg-[#0A0A0A] rounded border border-[#262626]">
              <span className="text-[#71717A] text-[10px] uppercase tracking-wider block">Operating Hours</span>
              <span className="text-2xl font-serif text-white mt-1 block font-mono">{currentRobot.operatingHours.toFixed(1)} hrs</span>
              <span className="text-[10px] uppercase tracking-wider text-[#52525B] mt-0.5 block">14,280 km traveled</span>
            </div>
            <div className="p-4 bg-[#0A0A0A] rounded border border-[#262626]">
              <span className="text-[#71717A] text-[10px] uppercase tracking-wider block">Missions Completed</span>
              <span className="text-2xl font-serif text-[#C5A059] mt-1 block font-mono">8,421 tasks</span>
              <span className="text-[10px] font-mono text-[#4ADE80] mt-0.5 block">99.94% Success</span>
            </div>
            <div className="p-4 bg-[#0A0A0A] rounded border border-[#262626]">
              <span className="text-[#71717A] text-[10px] uppercase tracking-wider block">Certified Service</span>
              <span className="text-2xl font-serif text-white mt-1 block font-mono">3 Overhauls</span>
              <span className="text-[10px] uppercase tracking-wider text-[#52525B] mt-0.5 block">Downtime: 4.8 hrs</span>
            </div>
            <div className="p-4 bg-[#0A0A0A] rounded border border-[#262626]">
              <span className="text-[#71717A] text-[10px] uppercase tracking-wider block">Total Energy</span>
              <span className="text-2xl font-serif text-[#4ADE80] mt-1 block font-mono">1,842 kWh</span>
              <span className="text-[10px] uppercase tracking-wider text-[#52525B] mt-0.5 block">$340.77 grid cost</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

