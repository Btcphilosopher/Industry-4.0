import React, { useState } from 'react';
import { Sliders, Zap, AlertTriangle, Play, RefreshCw, Flame, CheckCircle2 } from 'lucide-react';

export const SimulationControls: React.FC = () => {
  const [loadingAction, setLoadingAction] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);

  const runSimAction = async (action: string, payload: any = {}) => {
    setLoadingAction(action);
    setFeedback(null);
    try {
      const res = await fetch('/api/v1/simulation/control', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, ...payload }),
      });
      const data = await res.json();
      setFeedback(`Action executed: ${action}`);
    } catch (e) {
      setFeedback(`Execution error: ${String(e)}`);
    } finally {
      setLoadingAction(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="bg-[#141414] border border-[#262626] rounded p-6">
        <div className="flex items-center justify-between pb-4 border-b border-[#262626]">
          <div>
            <p className="text-[10px] uppercase tracking-[0.2em] text-[#71717A]">Stress Testing</p>
            <h2 className="text-lg font-serif text-white mt-0.5 flex items-center gap-2">
              Industrial Backend Simulation & Load Testing Controls
            </h2>
          </div>
          <span className="text-[11px] font-mono text-[#C5A059] bg-[#0A0A0A] px-3 py-1 rounded border border-[#262626]">
            Target Scale: 1,000+ AMRs / 100k Orders/day
          </span>
        </div>

        {feedback && (
          <div className="mt-4 p-3 bg-[#0A0A0A] border border-[#4ADE80]/40 rounded text-xs text-[#4ADE80] flex items-center gap-2 font-mono">
            <CheckCircle2 className="w-4 h-4 text-[#4ADE80]" />
            <span>{feedback}</span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Scenario 1: Order Burst */}
        <div className="bg-[#141414] border border-[#262626] rounded p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-[#262626]">
              <p className="text-[10px] uppercase tracking-widest text-[#71717A]">Throughput Load</p>
            </div>
            <h3 className="text-base font-serif text-white mt-3 flex items-center gap-2">
              <Flame className="w-4 h-4 text-[#C5A059]" />
              Peak Fulfillment Burst
            </h3>
            <p className="mt-3 text-xs text-[#71717A] leading-relaxed">
              Injects concurrent picking tasks across multiple high-bay aisles. Validates lock-free transaction sequencing and invariant checking.
            </p>
          </div>

          <button
            onClick={() => runSimAction('TRIGGER_ORDER_BURST')}
            disabled={loadingAction === 'TRIGGER_ORDER_BURST'}
            className="mt-6 w-full py-3 bg-[#C5A059] hover:bg-[#d4b068] disabled:opacity-50 text-[#0A0A0A] rounded text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            Trigger 50-Line Burst
          </button>
        </div>

        {/* Scenario 2: Motor Vibration Fault */}
        <div className="bg-[#141414] border border-[#262626] rounded p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-[#262626]">
              <p className="text-[10px] uppercase tracking-widest text-[#71717A]">Telemetry Fault</p>
            </div>
            <h3 className="text-base font-serif text-white mt-3 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-[#EF4444]" />
              Inject Motor Anomaly
            </h3>
            <p className="mt-3 text-xs text-[#71717A] leading-relaxed">
              Simulates elevated vibration spectra (ISO 10816 threshold breach) on an AMR drive. Triggers the R predictive maintenance alert.
            </p>
          </div>

          <button
            onClick={() => runSimAction('INJECT_FAULT', { robotCode: 'RBT-AMR-0002' })}
            disabled={loadingAction === 'INJECT_FAULT'}
            className="mt-6 w-full py-3 bg-[#0A0A0A] border border-[#EF4444]/60 hover:bg-[#EF4444]/10 disabled:opacity-50 text-[#EF4444] rounded text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            Inject Anomaly on AMR-0002
          </button>
        </div>

        {/* Scenario 3: Force Anchor Merkle Batch */}
        <div className="bg-[#141414] border border-[#262626] rounded p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-[#262626]">
              <p className="text-[10px] uppercase tracking-widest text-[#71717A]">Cryptographic Flush</p>
            </div>
            <h3 className="text-base font-serif text-white mt-3 flex items-center gap-2">
              <Zap className="w-4 h-4 text-[#C5A059]" />
              Force Blockchain Anchor
            </h3>
            <p className="mt-3 text-xs text-[#71717A] leading-relaxed">
              Flushes buffered event hashes into a balanced binary Merkle tree and generates an on-chain transaction commitment to the PoA block ledger.
            </p>
          </div>

          <button
            onClick={() => runSimAction('TRIGGER_ORDER_BURST')}
            className="mt-6 w-full py-3 bg-[#0A0A0A] border border-[#C5A059] hover:bg-[#C5A059]/10 text-[#C5A059] rounded text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Flush & Anchor Batch
          </button>
        </div>
      </div>
    </div>
  );
};

