import React, { useState } from 'react';
import { Code2, Copy, Check, Terminal, Play, Send } from 'lucide-react';

export const ApiDocsPlayground: React.FC = () => {
  const [selectedLang, setSelectedLang] = useState<'PYTHON' | 'RUST' | 'CURL' | 'GRPC'>('PYTHON');
  const [copied, setCopied] = useState(false);
  const [apiResponse, setApiResponse] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const pythonSnippet = `from wms_wcs_client import WarehouseClient

# 1. Initialize High-Performance Industrial Client
client = WarehouseClient(
    base_url="http://warehouse-backend.internal:8080",
    client_id="WMS-SAP-INTEGRATION",
    private_key_path="/etc/ssl/certs/wms_ed25519.key"
)

# 2. Commit Double-Entry Inventory Movement
tx = client.record_inventory_movement(
    unit_id="unit-01",
    sku="SKU-SERVO-DRIVE-990",
    from_loc="LOC-A04-R12-B02",
    to_loc="PACKING-CELL-02",
    quantity=10,
    target_state="PICKED",
    actor_id="RBT-AMR-0004"
)
print(f"Transaction Committed: {tx.event_hash} | Block Anchor: {tx.merkle_root}")

# 3. Query R Predictive Optimization Engine
forecast = client.get_demand_forecast("SKU-SERVO-DRIVE-990")
print(f"Recommended Safety Stock: {forecast.safety_stock} units")
`;

  const rustSnippet = `use warehouse_core::crypto::hash_event;
use warehouse_domain::types::*;
use warehouse_inventory::InventoryLedgerEngine;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let ledger = InventoryLedgerEngine::new(db_pool).await?;
    
    // Atomically transition inventory state with double-entry conservation
    let tx = ledger.commit_transaction(
        "SKU-SERVO-DRIVE-990",
        InventoryState::Available,
        InventoryState::Picked,
        10,
        "LOC-A04-R12-B02",
        "PACKING-CELL-02",
        "RBT-AMR-0004"
    ).await?;
    
    println!("Ledger Hash: {}", tx.event_hash);
    Ok(())
}
`;

  const curlSnippet = `curl -X POST http://localhost:3000/api/v1/inventory/transactions \\
  -H "Content-Type: application/json" \\
  -d '{
    "sku": "SKU-SERVO-DRIVE-990",
    "quantity": 10,
    "fromLocation": "LOC-A04-R12-B02",
    "toLocation": "PACKING-CELL-02",
    "targetState": "PICKED",
    "actorId": "RBT-AMR-0004"
  }'
`;

  const grpcSnippet = `syntax = "proto3";
package warehouse.v1;

service WarehouseTelemetryService {
  rpc StreamRobotTelemetry(stream RobotTelemetryPacket) returns (TelemetryAck);
  rpc QueryAssetHealth(AssetHealthRequest) returns (AssetHealthResponse);
}

service InventoryLedgerService {
  rpc CommitMovement(InventoryMovementRequest) returns (InventoryMovementReceipt);
  rpc VerifyMerkleProof(MerkleProofRequest) returns (MerkleProofResponse);
}
`;

  const getCode = () => {
    switch (selectedLang) {
      case 'PYTHON':
        return pythonSnippet;
      case 'RUST':
        return rustSnippet;
      case 'CURL':
        return curlSnippet;
      case 'GRPC':
        return grpcSnippet;
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(getCode());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const testLiveEndpoint = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/v1/status');
      const data = await res.json();
      setApiResponse(JSON.stringify(data, null, 2));
    } catch (e) {
      setApiResponse(`Error: ${String(e)}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="bg-[#141414] border border-[#262626] rounded p-6">
        <div className="flex items-center justify-between pb-4 border-b border-[#262626]">
          <div>
            <p className="text-[10px] uppercase tracking-[0.2em] text-[#71717A]">Developer Interface</p>
            <h2 className="text-lg font-serif text-white mt-0.5 flex items-center gap-2">
              Developer API Playground & Production SDKs
            </h2>
          </div>
          <span className="text-[11px] font-mono text-[#C5A059] bg-[#0A0A0A] px-3 py-1 rounded border border-[#262626]">
            OpenAPI 3.1 & Protocol Buffers Ready
          </span>
        </div>

        <div className="mt-5 flex flex-wrap items-center justify-between gap-3">
          <div className="flex space-x-2">
            {(['PYTHON', 'RUST', 'CURL', 'GRPC'] as const).map((lang) => (
              <button
                key={lang}
                onClick={() => setSelectedLang(lang)}
                className={`px-3 py-1.5 rounded text-xs font-mono tracking-wider transition-colors cursor-pointer ${
                  selectedLang === lang
                    ? 'bg-[#C5A059] text-[#0A0A0A] font-bold'
                    : 'bg-[#0A0A0A] text-[#71717A] hover:text-white border border-[#262626]'
                }`}
              >
                {lang}
              </button>
            ))}
          </div>

          <button
            onClick={handleCopy}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded bg-[#0A0A0A] hover:bg-[#1A1A1A] text-[#D4D4D8] text-xs font-mono tracking-wider transition-colors cursor-pointer border border-[#262626]"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-[#4ADE80]" /> : <Copy className="w-3.5 h-3.5 text-[#C5A059]" />}
            <span>{copied ? 'COPIED' : 'COPY CODE'}</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Code Editor Preview */}
        <div className="bg-[#0A0A0A] border border-[#262626] rounded p-5 font-mono text-xs text-[#D4D4D8] overflow-x-auto">
          <div className="flex items-center justify-between pb-3 mb-4 border-b border-[#262626] text-[#71717A] text-[11px]">
            <span className="flex items-center gap-2 text-[#C5A059]">
              <Terminal className="w-3.5 h-3.5" />
              {selectedLang === 'PYTHON' ? 'wms_integration.py' : selectedLang === 'RUST' ? 'main.rs' : selectedLang === 'GRPC' ? 'warehouse.proto' : 'curl_command.sh'}
            </span>
            <span className="text-[10px] uppercase tracking-wider text-[#52525B]">UTF-8 • Strict Typed</span>
          </div>
          <pre className="leading-relaxed whitespace-pre-wrap">{getCode()}</pre>
        </div>

        {/* Interactive Endpoint Tester */}
        <div className="bg-[#141414] border border-[#262626] rounded p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-[#262626]">
              <div>
                <p className="text-[10px] uppercase tracking-widest text-[#71717A]">Telemetry Probe</p>
                <h3 className="text-base font-serif text-white mt-0.5 flex items-center gap-2">
                  Live Endpoint Execution Probe
                </h3>
              </div>
              <span className="text-[10px] font-mono text-[#4ADE80] bg-[#0A0A0A] px-2.5 py-1 rounded border border-[#262626]">
                GET /api/v1/status
              </span>
            </div>

            <div className="mt-5 bg-[#0A0A0A] border border-[#262626] rounded p-4 font-mono text-[11px] text-[#D4D4D8] min-h-[220px] max-h-[300px] overflow-y-auto">
              {apiResponse ? (
                <pre className="text-[#4ADE80]">{apiResponse}</pre>
              ) : (
                <span className="text-[#52525B]">
                  Click 'Execute Probe' below to query the live backend state and telemetry stream...
                </span>
              )}
            </div>
          </div>

          <button
            onClick={testLiveEndpoint}
            disabled={loading}
            className="mt-5 w-full py-3 bg-[#C5A059] hover:bg-[#d4b068] disabled:opacity-50 text-[#0A0A0A] rounded text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            {loading ? 'Querying Backend...' : 'Execute Probe: GET /api/v1/status'}
          </button>
        </div>
      </div>
    </div>
  );
};

