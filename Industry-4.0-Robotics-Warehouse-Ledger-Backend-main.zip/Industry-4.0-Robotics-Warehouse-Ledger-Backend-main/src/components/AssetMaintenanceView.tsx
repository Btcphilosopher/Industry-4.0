import React, { useState } from 'react';
import { AssetEntity, MaintenanceLog } from '../types';
import { ShieldCheck, Wrench, AlertTriangle, Plus, CheckCircle2, Activity, Cpu } from 'lucide-react';

interface AssetMaintenanceViewProps {
  assets: AssetEntity[];
  maintenanceLogs: MaintenanceLog[];
  onCertifyMaintenance: (payload: {
    assetTag: string;
    faultDescription: string;
    correctiveAction: string;
    technicianId: string;
    partsConsumed: string[];
    costUsd: number;
    downtimeMinutes: number;
  }) => void;
}

export const AssetMaintenanceView: React.FC<AssetMaintenanceViewProps> = ({
  assets,
  maintenanceLogs,
  onCertifyMaintenance,
}) => {
  const [selectedAsset, setSelectedAsset] = useState<AssetEntity>(assets[0]);
  const [fault, setFault] = useState('Harmonic motor vibration threshold exceeded ISO 10816');
  const [action, setAction] = useState('Replaced drive bearing and recalibrated resolver');
  const [techId, setTechId] = useState('TECH-CERT-0491');
  const [cost, setCost] = useState(1240);
  const [downtime, setDowntime] = useState(120);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onCertifyMaintenance({
      assetTag: selectedAsset?.assetTag || 'ARM-KUKA-PALLET-03',
      faultDescription: fault,
      correctiveAction: action,
      technicianId: techId,
      partsConsumed: ['SKU-BEARING-CERAMIC-44'],
      costUsd: cost,
      downtimeMinutes: downtime,
    });
  };

  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="bg-[#141414] border border-[#262626] rounded p-6">
        <div className="flex items-center justify-between pb-4 border-b border-[#262626]">
          <div>
            <p className="text-[10px] uppercase tracking-[0.2em] text-[#71717A]">Certification Ledger</p>
            <h2 className="text-lg font-serif text-white mt-0.5 flex items-center gap-2">
              Cryptographic Asset Provenance & Maintenance Log
            </h2>
          </div>
          <span className="text-[11px] font-mono text-[#4ADE80] bg-[#0A0A0A] px-3 py-1 rounded border border-[#262626]">
            MaintenanceCertificateContract.sol Verified
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-5 text-xs">
          {assets.map((asset) => (
            <div
              key={asset.id}
              onClick={() => setSelectedAsset(asset)}
              className={`p-4 rounded border transition-all cursor-pointer space-y-2 ${
                selectedAsset?.id === asset.id
                  ? 'bg-[#1A1A1A] border-[#C5A059] shadow-md'
                  : 'bg-[#0A0A0A] border-[#262626] hover:border-[#333333]'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-white tracking-wide">{asset.assetTag}</span>
                <span
                  className={`text-[9px] px-2 py-0.5 rounded font-mono uppercase tracking-wider ${
                    asset.status === 'HEALTHY'
                      ? 'bg-[#141414] text-[#4ADE80] border border-[#4ADE80]/30'
                      : 'bg-[#141414] text-[#F59E0B] border border-[#F59E0B]/30'
                  }`}
                >
                  {asset.status}
                </span>
              </div>

              <div className="text-[11px] text-[#71717A]">
                {asset.model} • {asset.manufacturer}
              </div>

              <div className="flex items-center justify-between text-[11px] text-[#A1A1AA] pt-1 border-t border-[#1E1E1E]">
                <span>Health Score: <strong className="text-white font-mono">{asset.healthScore}%</strong></span>
                <span>Vibration: <strong className="text-[#C5A059] font-mono">{asset.rmsVibrationMms} mm/s</strong></span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Sign Maintenance Certification Form */}
        <div className="bg-[#141414] border border-[#262626] rounded p-6">
          <div className="pb-4 border-b border-[#262626]">
            <p className="text-[10px] uppercase tracking-widest text-[#71717A]">Cryptographic Attestation</p>
            <h3 className="text-base font-serif text-white mt-0.5 flex items-center gap-2">
              Certify Maintenance Event
            </h3>
          </div>

          <form onSubmit={handleSubmit} className="mt-5 space-y-3.5 text-xs">
            <div>
              <label className="text-[#A1A1AA] text-[10px] uppercase tracking-wider block mb-1.5">Target Asset</label>
              <select
                value={selectedAsset?.assetTag}
                onChange={(e) => {
                  const a = assets.find((x) => x.assetTag === e.target.value);
                  if (a) setSelectedAsset(a);
                }}
                className="w-full bg-[#0A0A0A] border border-[#262626] rounded p-2.5 text-white font-mono text-xs focus:outline-none focus:border-[#C5A059]"
              >
                {assets.map((a) => (
                  <option key={a.id} value={a.assetTag}>
                    {a.assetTag} ({a.model})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[#A1A1AA] text-[10px] uppercase tracking-wider block mb-1.5">Fault Description</label>
              <textarea
                rows={2}
                value={fault}
                onChange={(e) => setFault(e.target.value)}
                className="w-full bg-[#0A0A0A] border border-[#262626] rounded p-2.5 text-white text-xs focus:outline-none focus:border-[#C5A059]"
              />
            </div>

            <div>
              <label className="text-[#A1A1AA] text-[10px] uppercase tracking-wider block mb-1.5">Corrective Action Completed</label>
              <textarea
                rows={2}
                value={action}
                onChange={(e) => setAction(e.target.value)}
                className="w-full bg-[#0A0A0A] border border-[#262626] rounded p-2.5 text-white text-xs focus:outline-none focus:border-[#C5A059]"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[#A1A1AA] text-[10px] uppercase tracking-wider block mb-1.5">Direct Cost ($ USD)</label>
                <input
                  type="number"
                  value={cost}
                  onChange={(e) => setCost(Number(e.target.value))}
                  className="w-full bg-[#0A0A0A] border border-[#262626] rounded p-2.5 text-white font-mono text-xs focus:outline-none focus:border-[#C5A059]"
                />
              </div>
              <div>
                <label className="text-[#A1A1AA] text-[10px] uppercase tracking-wider block mb-1.5">Downtime (min)</label>
                <input
                  type="number"
                  value={downtime}
                  onChange={(e) => setDowntime(Number(e.target.value))}
                  className="w-full bg-[#0A0A0A] border border-[#262626] rounded p-2.5 text-white font-mono text-xs focus:outline-none focus:border-[#C5A059]"
                />
              </div>
            </div>

            <div>
              <label className="text-[#A1A1AA] text-[10px] uppercase tracking-wider block mb-1.5">Certified Technician ID</label>
              <input
                type="text"
                value={techId}
                onChange={(e) => setTechId(e.target.value)}
                className="w-full bg-[#0A0A0A] border border-[#262626] rounded p-2.5 font-mono text-[#C5A059] text-xs focus:outline-none focus:border-[#C5A059]"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-[#C5A059] hover:bg-[#d4b068] text-[#0A0A0A] font-bold uppercase tracking-widest text-xs rounded transition-colors flex items-center justify-center gap-2 cursor-pointer mt-2"
            >
              <ShieldCheck className="w-3.5 h-3.5 fill-current" />
              Sign & Anchor Certificate on Chain
            </button>
          </form>
        </div>

        {/* Certified Maintenance Logs List */}
        <div className="lg:col-span-2 bg-[#141414] border border-[#262626] rounded p-6">
          <div className="flex items-center justify-between pb-4 border-b border-[#262626]">
            <div>
              <p className="text-[10px] uppercase tracking-[0.2em] text-[#71717A]">Historical Registry</p>
              <h3 className="text-base font-serif text-white mt-0.5 flex items-center gap-2">
                Immutable Service History & Certificates
              </h3>
            </div>
            <span className="text-[10px] font-mono uppercase tracking-wider text-[#C5A059] bg-[#0A0A0A] px-2.5 py-1 rounded border border-[#262626]">
              {maintenanceLogs.length} Records Logged
            </span>
          </div>

          <div className="mt-5 space-y-3 max-h-[460px] overflow-y-auto pr-1 text-xs">
            {maintenanceLogs.map((log) => (
              <div
                key={log.id}
                className="p-4 bg-[#0A0A0A] rounded border border-[#262626] hover:border-[#333333] transition-colors space-y-2.5"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2.5">
                    <span className="font-bold text-white tracking-wide">{log.assetTag}</span>
                    <span className="px-2 py-0.5 rounded text-[9px] font-mono uppercase bg-[#141414] text-[#4ADE80] border border-[#4ADE80]/30">
                      SAFETY PASSED
                    </span>
                  </div>
                  <span className="text-[10px] text-[#71717A] font-mono">
                    {new Date(log.certifiedAt).toLocaleString()}
                  </span>
                </div>

                <div className="text-[#D4D4D8] text-[11px] leading-relaxed">
                  <span className="text-[#71717A] uppercase text-[10px] tracking-wider mr-1.5">Diagnosis:</span>
                  {log.diagnosisCategory} — {log.faultDescription}
                </div>

                <div className="text-[#D4D4D8] text-[11px] leading-relaxed">
                  <span className="text-[#71717A] uppercase text-[10px] tracking-wider mr-1.5">Action:</span>
                  {log.correctiveAction}
                </div>

                <div className="pt-2 flex flex-wrap items-center justify-between text-[10px] text-[#71717A] border-t border-[#1E1E1E] gap-2 font-mono">
                  <span>Tech: <strong className="text-white">{log.technicianId}</strong></span>
                  <span>Cost: <strong className="text-white">${log.costUsd}</strong></span>
                  <span>Downtime: <strong className="text-white">{log.downtimeMinutes} min</strong></span>
                  <span className="text-[#C5A059]">Sig: {log.signature.slice(0, 18)}...</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

