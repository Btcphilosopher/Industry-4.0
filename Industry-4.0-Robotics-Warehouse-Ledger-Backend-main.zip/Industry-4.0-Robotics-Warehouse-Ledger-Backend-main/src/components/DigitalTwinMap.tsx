import React, { useState } from 'react';
import { RobotEntity } from '../types';
import { Cpu, Battery, Gauge, Zap, AlertTriangle, ShieldCheck, Play, Radio } from 'lucide-react';

interface DigitalTwinMapProps {
  robots: RobotEntity[];
  onDispatchMission: (robotId: string, targetX: number, targetY: number) => void;
}

export const DigitalTwinMap: React.FC<DigitalTwinMapProps> = ({ robots, onDispatchMission }) => {
  const [selectedRobot, setSelectedRobot] = useState<RobotEntity | null>(null);

  const zones = [
    { name: 'ZONE A: HIGH-BAY STORAGE', x: 5, y: 5, w: 40, h: 35, color: 'border-[#262626] bg-[#1A1A1A]/40 text-[#A1A1AA]' },
    { name: 'ZONE B: PICKING & ASRS', x: 50, y: 5, w: 45, h: 35, color: 'border-[#C5A059]/30 bg-[#C5A059]/5 text-[#C5A059]' },
    { name: 'ZONE C: PACKING CELLS', x: 5, y: 45, w: 40, h: 25, color: 'border-[#262626] bg-[#141414]/60 text-[#A1A1AA]' },
    { name: 'ZONE D: CHARGING DEPOT', x: 50, y: 45, w: 22, h: 25, color: 'border-[#4ADE80]/30 bg-[#4ADE80]/5 text-[#4ADE80]' },
    { name: 'ZONE E: OUTBOUND DOCKS', x: 75, y: 45, w: 20, h: 25, color: 'border-[#C5A059]/40 bg-[#C5A059]/10 text-[#C5A059]' },
  ];

  return (
    <div className="space-y-6">
      {/* Header Metric Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-[#141414] border border-[#262626] rounded p-5">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase tracking-widest text-[#71717A] font-semibold">Active Fleet</span>
            <Cpu className="w-4 h-4 text-[#C5A059]" />
          </div>
          <div className="mt-3 flex items-baseline space-x-2">
            <span className="text-3xl font-serif text-white">{robots.length}</span>
            <span className="text-xs text-[#4ADE80] font-medium font-sans">
              +{robots.filter((r) => r.status === 'TRANSIT' || r.status === 'IDLE').length} Online
            </span>
          </div>
          <div className="mt-1 text-[10px] uppercase tracking-wider text-[#52525B]">10Hz Kinematic Telemetry</div>
        </div>

        <div className="bg-[#141414] border border-[#262626] rounded p-5">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase tracking-widest text-[#71717A] font-semibold">Avg Battery SoC</span>
            <Battery className="w-4 h-4 text-[#4ADE80]" />
          </div>
          <div className="mt-3 flex items-baseline space-x-2">
            <span className="text-3xl font-serif text-white">
              {Math.round(robots.reduce((acc, r) => acc + r.batterySoc, 0) / (robots.length || 1))}
              <span className="text-sm font-sans text-[#71717A] ml-0.5">%</span>
            </span>
            <span className="text-xs text-[#71717A]">
              {robots.filter((r) => r.status === 'CHARGING').length} Charging
            </span>
          </div>
          <div className="mt-1 text-[10px] uppercase tracking-wider text-[#52525B]">Automated Opportunity Cycle</div>
        </div>

        <div className="bg-[#141414] border border-[#262626] rounded p-5">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase tracking-widest text-[#71717A] font-semibold">Security Protocol</span>
            <Radio className="w-4 h-4 text-[#C5A059]" />
          </div>
          <div className="mt-3 flex items-baseline space-x-2">
            <span className="text-2xl font-serif text-white">gRPC / TLS</span>
            <span className="text-xs text-[#C5A059] font-mono">Ed25519</span>
          </div>
          <div className="mt-1 text-[10px] uppercase tracking-wider text-[#52525B]">TPM 2.0 Hardware Authenticated</div>
        </div>

        <div className="bg-[#141414] border border-[#262626] rounded p-5">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase tracking-widest text-[#71717A] font-semibold">Safety Integrity</span>
            <ShieldCheck className="w-4 h-4 text-[#4ADE80]" />
          </div>
          <div className="mt-3 flex items-baseline space-x-2">
            <span className="text-3xl font-serif text-[#4ADE80]">99.8<span className="text-sm font-sans text-[#71717A] ml-0.5">%</span></span>
            <span className="text-xs text-[#71717A]">ISO 3691-4</span>
          </div>
          <div className="mt-1 text-[10px] uppercase tracking-wider text-[#52525B]">LiDAR 360° Safety Fields Active</div>
        </div>
      </div>

      {/* Main Digital Twin Grid Map */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-[#141414] border border-[#262626] rounded p-6">
          <div className="flex items-center justify-between pb-4 border-b border-[#262626]">
            <div>
              <p className="text-[10px] uppercase tracking-[0.2em] text-[#71717A]">Spatial Floor Plan</p>
              <h2 className="text-lg font-serif text-white mt-0.5 flex items-center gap-2">
                Live Spatial Fleet Grid <span className="font-mono text-xs text-[#C5A059] not-italic">(WH-GLOBAL-01)</span>
              </h2>
            </div>
            <div className="flex items-center space-x-4 text-xs">
              <span className="flex items-center gap-1.5 text-[#D4D4D8]"><span className="w-2 h-2 rounded-full bg-[#C5A059]"></span> Transit</span>
              <span className="flex items-center gap-1.5 text-[#D4D4D8]"><span className="w-2 h-2 rounded-full bg-[#4ADE80]"></span> Charging</span>
              <span className="flex items-center gap-1.5 text-[#D4D4D8]"><span className="w-2 h-2 rounded-full bg-[#52525B]"></span> Idle</span>
            </div>
          </div>

          {/* Interactive 2D Canvas Area */}
          <div className="relative w-full h-[420px] bg-[#0A0A0A] rounded border border-[#262626] mt-5 overflow-hidden select-none">
            {/* Subtle Grid Lines */}
            <div 
              className="absolute inset-0 opacity-20"
              style={{
                backgroundImage: 'radial-gradient(#52525b 1px, transparent 1px)',
                backgroundSize: '24px 24px'
              }}
            />

            {/* Conveyor Line Graphic */}
            <div className="absolute top-[41%] left-[5%] right-[5%] h-1.5 bg-[#C5A059]/20 border-y border-[#C5A059]/50 flex items-center justify-around overflow-hidden">
              <span className="text-[9px] text-[#C5A059] font-mono tracking-widest uppercase">◄ HIGH-SPEED CROSS-BELT CONVEYOR LOOP ◄</span>
            </div>

            {/* Warehouse Zones */}
            {zones.map((zone, idx) => (
              <div
                key={idx}
                className={`absolute border rounded p-2.5 ${zone.color} transition-all`}
                style={{
                  left: `${zone.x}%`,
                  top: `${zone.y}%`,
                  width: `${zone.w}%`,
                  height: `${zone.h}%`,
                }}
              >
                <span className="text-[10px] font-semibold font-mono tracking-wider block uppercase">
                  {zone.name}
                </span>
              </div>
            ))}

            {/* Robots Markers */}
            {robots.map((robot) => {
              const isSelected = selectedRobot?.id === robot.id;
              const isCharging = robot.status === 'CHARGING';
              const isTransit = robot.status === 'TRANSIT';

              return (
                <button
                  key={robot.id}
                  onClick={() => setSelectedRobot(robot)}
                  className="absolute transform -translate-x-1/2 -translate-y-1/2 group transition-all duration-700 ease-out cursor-pointer z-10"
                  style={{
                    left: `${robot.position.x}%`,
                    top: `${robot.position.y}%`,
                  }}
                >
                  <div className={`relative p-1.5 rounded border transition-all ${
                    isSelected
                      ? 'bg-[#C5A059] border-white ring-4 ring-[#C5A059]/30 text-[#0A0A0A] scale-125'
                      : isCharging
                      ? 'bg-[#141414] border-[#4ADE80] text-[#4ADE80]'
                      : isTransit
                      ? 'bg-[#141414] border-[#C5A059] text-[#C5A059]'
                      : 'bg-[#1A1A1A] border-[#333333] text-[#71717A]'
                  }`}>
                    <Cpu className="w-3.5 h-3.5" />
                    {isTransit && (
                      <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-[#C5A059] animate-ping" />
                    )}
                  </div>

                  <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-1 bg-[#141414] text-[9px] font-mono text-white px-2 py-0.5 rounded border border-[#262626] whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-20 shadow-lg">
                    {robot.code} ({Math.round(robot.batterySoc)}%)
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Robot Telemetry Inspector */}
        <div className="bg-[#141414] border border-[#262626] rounded p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-[#262626]">
              <div>
                <p className="text-[10px] uppercase tracking-widest text-[#71717A]">Hardware Diagnostics</p>
                <h3 className="text-base font-serif text-white mt-0.5">Machine Inspector</h3>
              </div>
              {selectedRobot ? (
                <span className="text-[10px] font-mono px-2 py-1 rounded bg-[#1A1A1A] text-[#C5A059] border border-[#C5A059]/40">
                  {selectedRobot.code}
                </span>
              ) : (
                <span className="text-xs text-[#52525B]">Select an AMR</span>
              )}
            </div>

            {selectedRobot ? (
              <div className="mt-5 space-y-4">
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="p-3 bg-[#0A0A0A] rounded border border-[#262626]">
                    <span className="text-[#71717A] text-[10px] uppercase tracking-wider block">Robot Model</span>
                    <span className="font-medium text-white mt-0.5 block">{selectedRobot.model}</span>
                  </div>
                  <div className="p-3 bg-[#0A0A0A] rounded border border-[#262626]">
                    <span className="text-[#71717A] text-[10px] uppercase tracking-wider block">Status</span>
                    <span className={`font-semibold mt-0.5 block ${
                      selectedRobot.status === 'CHARGING' ? 'text-[#4ADE80]' : 'text-[#C5A059]'
                    }`}>
                      {selectedRobot.status}
                    </span>
                  </div>
                  <div className="p-3 bg-[#0A0A0A] rounded border border-[#262626]">
                    <span className="text-[#71717A] text-[10px] uppercase tracking-wider block">Battery SoC</span>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <Battery className="w-3.5 h-3.5 text-[#4ADE80]" />
                      <span className="font-serif text-lg text-white">{Math.round(selectedRobot.batterySoc)}%</span>
                    </div>
                  </div>
                  <div className="p-3 bg-[#0A0A0A] rounded border border-[#262626]">
                    <span className="text-[#71717A] text-[10px] uppercase tracking-wider block">Operating Hours</span>
                    <span className="font-serif text-lg text-white mt-0.5 block">{selectedRobot.operatingHours.toFixed(1)} <span className="text-xs font-sans text-[#71717A]">hrs</span></span>
                  </div>
                </div>

                <div className="p-4 bg-[#0A0A0A] rounded border border-[#262626] space-y-2.5 text-xs">
                  <div className="flex justify-between">
                    <span className="text-[#71717A]">Motor Current</span>
                    <span className="font-mono text-white">{selectedRobot.motorCurrentA.toFixed(2)} A</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#71717A]">Velocity</span>
                    <span className="font-mono text-white">{selectedRobot.speedMps} m/s</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#71717A]">Firmware</span>
                    <span className="font-mono text-[#C5A059]">{selectedRobot.firmware}</span>
                  </div>
                </div>

                <div className="p-3 bg-[#0A0A0A] rounded border border-[#262626] space-y-1.5 text-xs">
                  <span className="text-[#71717A] text-[10px] uppercase tracking-wider block">Public Key (Ed25519)</span>
                  <div className="font-mono text-[10px] text-[#C5A059] break-all bg-[#141414] p-2 rounded border border-[#262626]">
                    {selectedRobot.publicKey}
                  </div>
                </div>

                <button
                  onClick={() => {
                    const tx = Math.floor(10 + Math.random() * 75);
                    const ty = Math.floor(10 + Math.random() * 55);
                    onDispatchMission(selectedRobot.id, tx, ty);
                  }}
                  className="w-full py-3 bg-[#C5A059] hover:bg-[#d4b068] text-[#0A0A0A] font-bold uppercase tracking-widest text-xs rounded flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  Dispatch Mission via Gateway
                </button>
              </div>
            ) : (
              <div className="py-20 text-center text-[#52525B] text-xs leading-relaxed">
                Click any robot on the floor plan to inspect its cryptographic identity and live kinematic telemetry.
              </div>
            )}
          </div>

          <div className="mt-4 pt-3 border-t border-[#262626] text-[10px] uppercase tracking-wider text-[#52525B] flex items-center gap-2">
            <Zap className="w-3.5 h-3.5 text-[#C5A059]" />
            <span>TimescaleDB Continuous Aggregation Engine</span>
          </div>
        </div>
      </div>
    </div>
  );
};

