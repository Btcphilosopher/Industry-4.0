import React, { useState } from 'react';
import { InventoryUnitEntity, InventoryTransaction, InventoryState } from '../types';
import { Boxes, ArrowRight, ShieldCheck, Plus, CheckCircle2, Hash, RefreshCw } from 'lucide-react';

interface InventoryLedgerViewProps {
  units: InventoryUnitEntity[];
  transactions: InventoryTransaction[];
  onSubmitTransaction: (payload: {
    sku: string;
    quantity: number;
    fromLocation: string;
    toLocation: string;
    targetState: InventoryState;
    actorId: string;
  }) => void;
}

const STATE_FLOW: InventoryState[] = [
  'RECEIVED',
  'INSPECTED',
  'AVAILABLE',
  'ALLOCATED',
  'PICKED',
  'PACKED',
  'STAGED',
  'LOADED',
  'SHIPPED',
];

export const InventoryLedgerView: React.FC<InventoryLedgerViewProps> = ({
  units,
  transactions,
  onSubmitTransaction,
}) => {
  const [selectedSku, setSelectedSku] = useState(units[0]?.sku || 'SKU-SERVO-DRIVE-990');
  const [quantity, setQuantity] = useState(50);
  const [targetState, setTargetState] = useState<InventoryState>('PICKED');
  const [fromLoc, setFromLoc] = useState('LOC-A04-R12-B02');
  const [toLoc, setToLoc] = useState('PACKING-CELL-02');
  const [actorId, setActorId] = useState('RBT-AMR-0004');

  const selectedUnit = units.find((u) => u.sku === selectedSku);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmitTransaction({
      sku: selectedSku,
      quantity,
      fromLocation: fromLoc,
      toLocation: toLoc,
      targetState,
      actorId,
    });
  };

  return (
    <div className="space-y-6">
      {/* State Machine Pipeline Banner */}
      <div className="bg-[#141414] border border-[#262626] rounded p-6">
        <div className="flex items-center justify-between pb-4 border-b border-[#262626]">
          <div>
            <p className="text-[10px] uppercase tracking-[0.2em] text-[#71717A]">Verification Framework</p>
            <h2 className="text-lg font-serif text-white mt-0.5 flex items-center gap-2">
              Deterministic State Machine Pipeline
            </h2>
          </div>
          <div className="flex items-center gap-2 text-xs text-[#4ADE80] font-medium font-mono">
            <ShieldCheck className="w-4 h-4" />
            <span>Invariant Conservation: Verified (0 Skips / 0 Losses)</span>
          </div>
        </div>

        <div className="mt-5 flex items-center justify-between overflow-x-auto py-2 scrollbar-none gap-2">
          {STATE_FLOW.map((state, idx) => {
            const isCurrent = selectedUnit?.state === state;
            return (
              <React.Fragment key={state}>
                <div
                  className={`flex flex-col items-center px-3.5 py-2.5 rounded border text-xs font-mono transition-all shrink-0 ${
                    isCurrent
                      ? 'bg-[#C5A059] border-[#C5A059] text-[#0A0A0A] font-bold shadow-lg shadow-[#C5A059]/10'
                      : 'bg-[#0A0A0A] border-[#262626] text-[#71717A]'
                  }`}
                >
                  <span className={`text-[9px] font-sans uppercase tracking-widest ${isCurrent ? 'text-[#0A0A0A]/80 font-semibold' : 'text-[#52525B]'}`}>
                    Stage 0{idx + 1}
                  </span>
                  <span className="mt-0.5 tracking-wider">{state}</span>
                </div>
                {idx < STATE_FLOW.length - 1 && (
                  <ArrowRight className="w-3.5 h-3.5 text-[#333333] shrink-0" />
                )}
              </React.Fragment>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Submit Double-Entry Transaction Form */}
        <div className="bg-[#141414] border border-[#262626] rounded p-6">
          <div className="pb-4 border-b border-[#262626]">
            <p className="text-[10px] uppercase tracking-widest text-[#71717A]">Ledger Input</p>
            <h3 className="text-base font-serif text-white mt-0.5 flex items-center gap-2">
              Execute Movement
            </h3>
          </div>

          <form onSubmit={handleSubmit} className="mt-5 space-y-4 text-xs">
            <div>
              <label className="text-[#A1A1AA] text-[10px] uppercase tracking-wider block mb-1.5">Target SKU</label>
              <select
                value={selectedSku}
                onChange={(e) => setSelectedSku(e.target.value)}
                className="w-full bg-[#0A0A0A] border border-[#262626] rounded p-2.5 text-white font-mono text-xs focus:outline-none focus:border-[#C5A059]"
              >
                {units.map((u) => (
                  <option key={u.id} value={u.sku}>
                    {u.sku} (Qty: {u.quantity} in {u.locationBarcode})
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[#A1A1AA] text-[10px] uppercase tracking-wider block mb-1.5">Movement Qty</label>
                <input
                  type="number"
                  value={quantity}
                  onChange={(e) => setQuantity(Number(e.target.value))}
                  className="w-full bg-[#0A0A0A] border border-[#262626] rounded p-2.5 text-white font-mono text-xs focus:outline-none focus:border-[#C5A059]"
                />
              </div>
              <div>
                <label className="text-[#A1A1AA] text-[10px] uppercase tracking-wider block mb-1.5">Target State</label>
                <select
                  value={targetState}
                  onChange={(e) => setTargetState(e.target.value as InventoryState)}
                  className="w-full bg-[#0A0A0A] border border-[#262626] rounded p-2.5 text-white font-mono text-xs focus:outline-none focus:border-[#C5A059]"
                >
                  {STATE_FLOW.map((st) => (
                    <option key={st} value={st}>
                      {st}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="text-[#A1A1AA] text-[10px] uppercase tracking-wider block mb-1.5">Source Location</label>
              <input
                type="text"
                value={fromLoc}
                onChange={(e) => setFromLoc(e.target.value)}
                className="w-full bg-[#0A0A0A] border border-[#262626] rounded p-2.5 font-mono text-white text-xs focus:outline-none focus:border-[#C5A059]"
              />
            </div>

            <div>
              <label className="text-[#A1A1AA] text-[10px] uppercase tracking-wider block mb-1.5">Destination Location</label>
              <input
                type="text"
                value={toLoc}
                onChange={(e) => setToLoc(e.target.value)}
                className="w-full bg-[#0A0A0A] border border-[#262626] rounded p-2.5 font-mono text-white text-xs focus:outline-none focus:border-[#C5A059]"
              />
            </div>

            <div>
              <label className="text-[#A1A1AA] text-[10px] uppercase tracking-wider block mb-1.5">Executing Machine / Operator</label>
              <input
                type="text"
                value={actorId}
                onChange={(e) => setActorId(e.target.value)}
                className="w-full bg-[#0A0A0A] border border-[#262626] rounded p-2.5 font-mono text-[#C5A059] text-xs focus:outline-none focus:border-[#C5A059]"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-[#C5A059] hover:bg-[#d4b068] text-[#0A0A0A] font-bold uppercase tracking-widest text-xs rounded transition-colors flex items-center justify-center gap-2 cursor-pointer mt-2"
            >
              <CheckCircle2 className="w-3.5 h-3.5 fill-current" />
              Commit Transaction to Ledger
            </button>
          </form>
        </div>

        {/* Real-Time Double-Entry Transaction Stream */}
        <div className="lg:col-span-2 bg-[#141414] border border-[#262626] rounded p-6">
          <div className="flex items-center justify-between pb-4 border-b border-[#262626]">
            <div>
              <p className="text-[10px] uppercase tracking-[0.2em] text-[#71717A]">Double-Entry Journal</p>
              <h3 className="text-base font-serif text-white mt-0.5 flex items-center gap-2">
                Immutable Transaction Stream
              </h3>
            </div>
            <span className="text-[10px] font-mono uppercase tracking-wider text-[#C5A059] bg-[#0A0A0A] px-2.5 py-1 rounded border border-[#262626]">
              {transactions.length} Ledger Records
            </span>
          </div>

          <div className="mt-5 space-y-3 max-h-[460px] overflow-y-auto pr-1">
            {transactions.map((tx) => (
              <div
                key={tx.id}
                className="p-3.5 bg-[#0A0A0A] rounded border border-[#262626] hover:border-[#333333] transition-colors text-xs space-y-2"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2.5">
                    <span className="font-semibold text-white tracking-wide">{tx.sku}</span>
                    <span className="px-2 py-0.5 rounded text-[9px] font-mono uppercase tracking-wider bg-[#141414] text-[#C5A059] border border-[#C5A059]/30">
                      {tx.type}
                    </span>
                  </div>
                  <span className="text-[10px] text-[#71717A] font-mono">
                    {new Date(tx.timestamp).toLocaleTimeString()}
                  </span>
                </div>

                <div className="flex items-center justify-between text-[#A1A1AA] text-[11px]">
                  <span>
                    Path: <span className="font-mono text-white">{tx.fromLocation}</span> →{' '}
                    <span className="font-mono text-white">{tx.toLocation}</span>
                  </span>
                  <span>
                    State: <span className="font-semibold text-[#C5A059] font-mono">{tx.toState}</span> ({tx.quantity} pcs)
                  </span>
                </div>

                <div className="pt-1.5 border-t border-[#1E1E1E] flex items-center justify-between text-[10px] text-[#52525B] font-mono">
                  <span className="truncate max-w-[280px]">Hash: {tx.eventHash}</span>
                  <span className="text-[#71717A]">Actor: {tx.actorId}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

