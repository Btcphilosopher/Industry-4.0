import React, { useState } from 'react';
import { BookOpen, FileText, ChevronRight, Shield, Database, Cpu, Layers, Server, Activity, Wrench } from 'lucide-react';

export const DocViewer: React.FC = () => {
  const [selectedDoc, setSelectedDoc] = useState<'ARCH' | 'SEC' | 'DB' | 'CHAIN' | 'R_STATS' | 'OPS'>('ARCH');

  const docs = [
    { key: 'ARCH', title: 'System Architecture & Concurrency', icon: <Cpu className="w-4 h-4 text-[#C5A059]" /> },
    { key: 'SEC', title: 'Industrial Security & Trust', icon: <Shield className="w-4 h-4 text-[#4ADE80]" /> },
    { key: 'DB', title: 'PostgreSQL & TimescaleDB', icon: <Database className="w-4 h-4 text-[#D4D4D8]" /> },
    { key: 'CHAIN', title: 'Merkle & Solidity Contracts', icon: <Layers className="w-4 h-4 text-[#C5A059]" /> },
    { key: 'R_STATS', title: 'R Statistical Analytics', icon: <Activity className="w-4 h-4 text-[#C5A059]" /> },
    { key: 'OPS', title: 'Operational Runbooks & Edge', icon: <Wrench className="w-4 h-4 text-[#D4D4D8]" /> },
  ];

  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="bg-[#141414] border border-[#262626] rounded p-6">
        <div className="flex items-center justify-between pb-4 border-b border-[#262626]">
          <div>
            <p className="text-[10px] uppercase tracking-[0.2em] text-[#71717A]">Documentation</p>
            <h2 className="text-lg font-serif text-white mt-0.5 flex items-center gap-2">
              Technical Architecture & Formal Engineering Specifications
            </h2>
          </div>
          <span className="text-[11px] font-mono text-[#C5A059] bg-[#0A0A0A] px-3 py-1 rounded border border-[#262626]">
            6 Specification Documents
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-2.5 mt-5 text-xs">
          {docs.map((d) => (
            <button
              key={d.key}
              onClick={() => setSelectedDoc(d.key as any)}
              className={`p-3.5 rounded border transition-all text-left flex flex-col justify-between space-y-2.5 cursor-pointer ${
                selectedDoc === d.key
                  ? 'bg-[#1A1A1A] border-[#C5A059] text-white shadow-md'
                  : 'bg-[#0A0A0A] border-[#262626] hover:border-[#333333] text-[#71717A]'
              }`}
            >
              <div className="flex items-center justify-between">
                {d.icon}
                <ChevronRight className="w-3.5 h-3.5 opacity-50" />
              </div>
              <span className="font-semibold text-[11px] leading-tight block tracking-wide">{d.title}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Document Reader Container */}
      <div className="bg-[#141414] border border-[#262626] rounded p-8 text-[#D4D4D8] text-xs leading-relaxed space-y-5">
        {selectedDoc === 'ARCH' && (
          <div className="space-y-4">
            <h3 className="text-base font-serif text-white border-b border-[#262626] pb-3">
              1. System Architecture & Double-Entry Invariant Engine
            </h3>
            <p className="text-[#A1A1AA]">
              The <strong className="text-white">Industry 4.0 Robotics Warehouse Ledger</strong> implements an actor-based, event-sourced architecture built with <strong className="text-white">Rust (Axum/Tokio)</strong> for sub-millisecond execution. Every inventory movement is modeled as a balanced double-entry state transition where the sum of physical and allocated inventory remains invariant across all states.
            </p>
            <div className="p-4 bg-[#0A0A0A] rounded border border-[#262626] font-mono text-[11px] text-[#C5A059] space-y-1.5">
              <div className="text-[10px] uppercase tracking-wider text-[#71717A]">Invariant Conservation Law:</div>
              <div className="text-white">Σ Q(received) + Q(available) + Q(picked) + Q(packed) + Q(staged) = Q(total_consignment)</div>
            </div>
            <p className="text-[#A1A1AA]">
              Hardware nodes (AMRs, AGVs, robotic picking arms, and ASRS shuttles) interact with the central edge cluster via <strong className="text-white">mutual TLS (mTLS) with hardware TPM 2.0 / secure-element-backed Ed25519 cryptographic keys</strong>.
            </p>
          </div>
        )}

        {selectedDoc === 'SEC' && (
          <div className="space-y-4">
            <h3 className="text-base font-serif text-white border-b border-[#262626] pb-3">
              2. Industrial Cybersecurity & Hardware Trust
            </h3>
            <p className="text-[#A1A1AA]">
              Compliant with <strong className="text-white">IEC 62443-4-2 (Security for Industrial Automation and Control Systems)</strong>. AMR units sign each high-frequency telemetry packet using their unique TPM-bound hardware private key.
            </p>
            <div className="p-4 bg-[#0A0A0A] rounded border border-[#262626] font-mono text-[11px] text-[#4ADE80] space-y-1.5">
              <div className="text-[10px] uppercase tracking-wider text-[#71717A]">Packet Signature Formulation:</div>
              <div className="text-white">σ = Ed25519.Sign(SK_robot, SHA256(RobotID || Seq || Timestamp || Payload))</div>
            </div>
          </div>
        )}

        {selectedDoc === 'DB' && (
          <div className="space-y-4">
            <h3 className="text-base font-serif text-white border-b border-[#262626] pb-3">
              3. Relational & TimescaleDB Time-Series Telemetry Schemas
            </h3>
            <p className="text-[#A1A1AA]">
              Transactional entities (Ledgers, SKUs, Pallets, Warehouses, Lots) are stored in <strong className="text-white">PostgreSQL 16</strong> with serializable isolation, while kinematics and sensor telemetry (10Hz–1kHz) stream into <strong className="text-white">TimescaleDB Hypertables</strong> with automatic 7-day compression and continuous materializations.
            </p>
            <div className="p-4 bg-[#0A0A0A] rounded border border-[#262626] font-mono text-[11px] text-[#C5A059] space-y-1.5">
              <div className="text-[10px] uppercase tracking-wider text-[#71717A]">Continuous Aggregate View:</div>
              <div className="text-white">robot_telemetry_1min_rollup (bucket, robot_id, avg_battery, max_vibration, total_distance)</div>
            </div>
          </div>
        )}

        {selectedDoc === 'CHAIN' && (
          <div className="space-y-4">
            <h3 className="text-base font-serif text-white border-b border-[#262626] pb-3">
              4. Cryptographic Merkle Batching & Solidity Anchoring
            </h3>
            <p className="text-[#A1A1AA]">
              To eliminate gas bottlenecks while maintaining strict tamper-evidence, event hashes are buffered into balanced binary Merkle trees. Every 60 seconds or 1,000 events, the batch root is anchored to the <strong className="text-white">Industrial PoA Consortium Blockchain</strong> via <code className="text-[#C5A059] font-mono bg-[#0A0A0A] px-1.5 py-0.5 rounded border border-[#262626]">IndustrialMerkleAnchor.sol</code>.
            </p>
            <div className="p-4 bg-[#0A0A0A] rounded border border-[#262626] font-mono text-[11px] text-[#C5A059] space-y-1.5">
              <div className="text-[10px] uppercase tracking-wider text-[#71717A]">Solidity Function:</div>
              <div className="text-white">commitMerkleBatch(uint256 batchSeqNum, bytes32 merkleRoot, uint32 eventCount)</div>
            </div>
          </div>
        )}

        {selectedDoc === 'R_STATS' && (
          <div className="space-y-4">
            <h3 className="text-base font-serif text-white border-b border-[#262626] pb-3">
              5. R Statistical Optimization & Predictive Maintenance
            </h3>
            <p className="text-[#A1A1AA]">
              The statistical engine runs dedicated <strong className="text-white">R 4.4.1</strong> analytic routines invoked via a low-overhead IPC bridge:
            </p>
            <ul className="list-disc list-inside space-y-2 text-[#A1A1AA]">
              <li><strong className="text-white">ARIMA / Holt-Winters:</strong> Dynamic safety stock and reorder point determination.</li>
              <li><strong className="text-white">Weibull Hazard Modeling:</strong> ISO 10816 vibration spectra and remaining useful life (RUL).</li>
              <li><strong className="text-white">Jackson Open Queueing Network:</strong> Erlang-C wait probability across AMR-to-packing bottlenecks.</li>
              <li><strong className="text-white">Dynamic Tariff Optimizer:</strong> Off-peak energy load shifting.</li>
            </ul>
          </div>
        )}

        {selectedDoc === 'OPS' && (
          <div className="space-y-4">
            <h3 className="text-base font-serif text-white border-b border-[#262626] pb-3">
              6. Operations Runbook & Edge-First Resilience
            </h3>
            <p className="text-[#A1A1AA]">
              In the event of WAN or external blockchain partition, the edge server continues normal operations using a local <strong className="text-white">Write-Ahead Log (WAL)</strong> and autonomous hash chaining. Upon network restoration, all queued batches are automatically reconciled and committed on-chain.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

