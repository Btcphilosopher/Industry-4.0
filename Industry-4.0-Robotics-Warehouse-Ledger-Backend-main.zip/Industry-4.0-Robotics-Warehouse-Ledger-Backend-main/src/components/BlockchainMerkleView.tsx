import React, { useState } from 'react';
import { MerkleBatchCommitment } from '../types';
import { Layers, ShieldCheck, CheckCircle2, Search, Link2, FileCheck2, Cpu } from 'lucide-react';

interface BlockchainMerkleViewProps {
  commitments: MerkleBatchCommitment[];
  onVerifyProof: (eventHash: string, merkleRoot: string) => Promise<{ valid: boolean; blockNumber?: number; txHash?: string }>;
}

export const BlockchainMerkleView: React.FC<BlockchainMerkleViewProps> = ({
  commitments,
  onVerifyProof,
}) => {
  const [selectedBatch, setSelectedBatch] = useState<MerkleBatchCommitment | null>(commitments[0] || null);
  const [testHash, setTestHash] = useState('');
  const [verificationResult, setVerificationResult] = useState<{
    tested: boolean;
    valid: boolean;
    blockNumber?: number;
    txHash?: string;
  } | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);

  const handleVerify = async () => {
    if (!testHash) return;
    setIsVerifying(true);
    const root = selectedBatch?.merkleRoot || commitments[0]?.merkleRoot || '';
    const res = await onVerifyProof(testHash, root);
    setVerificationResult({
      tested: true,
      valid: res.valid,
      blockNumber: res.blockNumber,
      txHash: res.txHash,
    });
    setIsVerifying(false);
  };

  return (
    <div className="space-y-6">
      {/* Merkle Batch Overview & PoA Consortium Strip */}
      <div className="bg-[#141414] border border-[#262626] rounded p-6">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-[#262626]">
          <div>
            <p className="text-[10px] uppercase tracking-[0.2em] text-[#71717A]">Consortium Ledger</p>
            <h2 className="text-lg font-serif text-white mt-0.5 flex items-center gap-2">
              Permissioned Consensus Layer <span className="font-mono text-xs text-[#C5A059] not-italic">(PoA L1)</span>
            </h2>
          </div>
          <div className="flex items-center space-x-3 text-xs">
            <span className="bg-[#0A0A0A] text-[#C5A059] px-3 py-1 rounded border border-[#262626] font-mono text-[11px]">
              Consortium Validators: 7 Nodes (3PL, Supplier, Auditor, Insurer)
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-5 text-xs">
          <div className="p-4 bg-[#0A0A0A] rounded border border-[#262626]">
            <span className="text-[#71717A] text-[10px] uppercase tracking-wider block">Total Anchored Batches</span>
            <span className="text-2xl font-serif text-white mt-1 block">{commitments.length}</span>
            <span className="text-[10px] uppercase tracking-wider text-[#52525B] mt-0.5 block">0 dropped / Monotonic sequence</span>
          </div>
          <div className="p-4 bg-[#0A0A0A] rounded border border-[#262626]">
            <span className="text-[#71717A] text-[10px] uppercase tracking-wider block">Current Chain Height</span>
            <span className="text-2xl font-serif text-[#C5A059] mt-1 block font-mono">
              #{commitments[0]?.blockNumber || 1849201}
            </span>
            <span className="text-[10px] uppercase tracking-wider text-[#52525B] mt-0.5 block">IBFT 2.0 Instant Finality</span>
          </div>
          <div className="p-4 bg-[#0A0A0A] rounded border border-[#262626]">
            <span className="text-[#71717A] text-[10px] uppercase tracking-wider block">Latest Merkle Root</span>
            <span className="text-[11px] font-mono text-[#4ADE80] mt-1.5 block truncate">
              {commitments[0]?.merkleRoot || '0x7f2a...'}
            </span>
            <span className="text-[10px] uppercase tracking-wider text-[#52525B] mt-0.5 block">IndustrialMerkleAnchor.sol</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Anchored Batches List */}
        <div className="bg-[#141414] border border-[#262626] rounded p-6">
          <div className="pb-4 border-b border-[#262626]">
            <p className="text-[10px] uppercase tracking-widest text-[#71717A]">Block Registry</p>
            <h3 className="text-base font-serif text-white mt-0.5 flex items-center gap-2">
              Anchored Commitments
            </h3>
          </div>

          <div className="mt-5 space-y-3 max-h-[500px] overflow-y-auto pr-1 text-xs">
            {commitments.map((batch) => {
              const isSelected = (selectedBatch?.id || commitments[0]?.id) === batch.id;
              return (
                <div
                  key={batch.id}
                  onClick={() => setSelectedBatch(batch)}
                  className={`p-3.5 rounded border transition-all cursor-pointer space-y-2 ${
                    isSelected
                      ? 'bg-[#1A1A1A] border-[#C5A059] text-white shadow-md'
                      : 'bg-[#0A0A0A] border-[#262626] hover:border-[#333333] text-[#D4D4D8]'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-white tracking-wide">Batch #{batch.batchSeqNum}</span>
                    <span className="px-2 py-0.5 rounded text-[9px] font-mono uppercase bg-[#141414] text-[#4ADE80] border border-[#4ADE80]/30">
                      Block #{batch.blockNumber}
                    </span>
                  </div>

                  <div className="text-[10px] font-mono text-[#71717A] truncate">
                    Root: <span className="text-[#A1A1AA]">{batch.merkleRoot}</span>
                  </div>

                  <div className="flex justify-between items-center text-[10px] text-[#52525B]">
                    <span>{batch.eventCount} Batched Events</span>
                    <span>{new Date(batch.committedAt).toLocaleTimeString()}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Visual Merkle Tree & Proof Verifier */}
        <div className="lg:col-span-2 space-y-6">
          {/* Merkle Visualizer */}
          <div className="bg-[#141414] border border-[#262626] rounded p-6">
            <div className="flex items-center justify-between pb-4 border-b border-[#262626]">
              <div>
                <p className="text-[10px] uppercase tracking-widest text-[#71717A]">Cryptographic Structure</p>
                <h3 className="text-base font-serif text-white mt-0.5 flex items-center gap-2">
                  Merkle Batch Anatomy
                </h3>
              </div>
              <span className="text-xs text-[#C5A059] font-mono bg-[#0A0A0A] px-2.5 py-1 rounded border border-[#262626]">
                {selectedBatch ? `Batch #${selectedBatch.batchSeqNum}` : 'Select a Batch'}
              </span>
            </div>

            {selectedBatch && (
              <div className="mt-5 space-y-4 text-xs">
                {/* Root Box */}
                <div className="p-4 bg-[#0A0A0A] rounded border border-[#C5A059]/50 flex flex-col items-center text-center">
                  <span className="text-[9px] uppercase font-bold text-[#C5A059] tracking-[0.2em]">
                    On-Chain Merkle Root (Anchor)
                  </span>
                  <span className="font-mono text-xs text-white font-bold mt-1.5 break-all">
                    {selectedBatch.merkleRoot}
                  </span>
                </div>

                {/* Leaf hashes */}
                <div>
                  <span className="text-[#71717A] text-[10px] uppercase tracking-wider block mb-2">
                    Aggregated Leaf Hashes:
                  </span>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 max-h-[160px] overflow-y-auto pr-1">
                    {selectedBatch.events.map((ev, idx) => (
                      <div
                        key={idx}
                        onClick={() => setTestHash(ev)}
                        className="p-2.5 bg-[#0A0A0A] rounded border border-[#262626] font-mono text-[10px] text-[#A1A1AA] truncate hover:border-[#C5A059] cursor-pointer transition-colors"
                        title="Click to paste into proof verifier"
                      >
                        <span className="text-[#52525B] mr-1.5">L{idx + 1}:</span>
                        {ev}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Inclusion Proof Verifier */}
          <div className="bg-[#141414] border border-[#262626] rounded p-6">
            <div className="pb-4 border-b border-[#262626]">
              <p className="text-[10px] uppercase tracking-widest text-[#71717A]">Cryptographic Audit</p>
              <h3 className="text-base font-serif text-white mt-0.5 flex items-center gap-2">
                Merkle Audit Path Verifier
              </h3>
            </div>

            <div className="mt-5 space-y-3 text-xs">
              <div>
                <label className="text-[#A1A1AA] text-[10px] uppercase tracking-wider block mb-1.5">
                  Event Hash to Verify (H(Event_i))
                </label>
                <div className="flex gap-2.5">
                  <input
                    type="text"
                    placeholder="Enter SHA-256 event hash (or click any leaf above)..."
                    value={testHash}
                    onChange={(e) => setTestHash(e.target.value)}
                    className="flex-1 bg-[#0A0A0A] border border-[#262626] rounded p-2.5 font-mono text-white text-xs focus:outline-none focus:border-[#C5A059]"
                  />
                  <button
                    onClick={handleVerify}
                    disabled={!testHash || isVerifying}
                    className="px-5 py-2.5 bg-[#C5A059] hover:bg-[#d4b068] disabled:opacity-40 text-[#0A0A0A] font-bold uppercase tracking-wider text-xs rounded flex items-center gap-2 transition-colors cursor-pointer"
                  >
                    <Search className="w-3.5 h-3.5 fill-current" />
                    Verify Proof
                  </button>
                </div>
              </div>

              {verificationResult?.tested && (
                <div
                  className={`p-4 rounded border text-xs ${
                    verificationResult.valid
                      ? 'bg-[#0A0A0A] border-[#4ADE80] text-[#4ADE80]'
                      : 'bg-[#0A0A0A] border-[#EF4444] text-[#EF4444]'
                  }`}
                >
                  <div className="flex items-center gap-2 font-bold uppercase tracking-wider text-xs">
                    {verificationResult.valid ? (
                      <>
                        <CheckCircle2 className="w-4 h-4 text-[#4ADE80]" />
                        <span>CRYPTOGRAPHIC PROOF VALIDATED: Event is immutably anchored on-chain</span>
                      </>
                    ) : (
                      <>
                        <span>INVALID PROOF: Hash not present in anchored Merkle root</span>
                      </>
                    )}
                  </div>
                  {verificationResult.valid && (
                    <div className="mt-2 text-[11px] font-mono text-[#D4D4D8] space-y-1">
                      <div>Block Number: #{verificationResult.blockNumber}</div>
                      <div className="truncate">Transaction Hash: {verificationResult.txHash}</div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

