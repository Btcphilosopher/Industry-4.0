import React, { useState, useEffect } from 'react';
import { DemandForecastData, QueueingData, EnergyTariffData } from '../types';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, ComposedChart, Bar } from 'recharts';
import { Activity, TrendingUp, Clock, Zap, Cpu, Sparkles, ShieldCheck } from 'lucide-react';

export const ROptimizationView: React.FC = () => {
  const [forecastData, setForecastData] = useState<DemandForecastData | null>(null);
  const [queueData, setQueueData] = useState<QueueingData | null>(null);
  const [energyData, setEnergyData] = useState<EnergyTariffData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadAnalytics() {
      try {
        const [fRes, qRes, eRes] = await Promise.all([
          fetch('/api/v1/analytics/demand-forecast?sku=SKU-SERVO-DRIVE-990').then((r) => r.json()),
          fetch('/api/v1/analytics/fleet-queueing').then((r) => r.json()),
          fetch('/api/v1/analytics/energy-tariff').then((r) => r.json()),
        ]);
        setForecastData(fRes);
        setQueueData(qRes);
        setEnergyData(eRes);
      } catch (err) {
        console.error('Analytics load error', err);
      } finally {
        setLoading(false);
      }
    }
    loadAnalytics();
  }, []);

  if (loading) {
    return <div className="p-8 text-center text-[#71717A] text-xs font-mono">Initializing Mathematical Optimization Engine...</div>;
  }

  return (
    <div className="space-y-6">
      {/* R Architecture Banner */}
      <div className="bg-[#141414] border border-[#262626] rounded p-6">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-[#262626]">
          <div>
            <p className="text-[10px] uppercase tracking-[0.2em] text-[#71717A]">Optimization Engine</p>
            <h2 className="text-lg font-serif text-white mt-0.5 flex items-center gap-2">
              Statistical Computing & Mathematical Analytics
            </h2>
          </div>
          <span className="bg-[#0A0A0A] text-[#C5A059] px-3 py-1 rounded border border-[#262626] text-[11px] font-mono">
            R 4.4.1 (jsonlite, forecast, survival, deSolve)
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-5 text-xs">
          <div className="p-4 bg-[#0A0A0A] rounded border border-[#262626]">
            <span className="text-[#71717A] text-[10px] uppercase tracking-wider block">Forecast Model</span>
            <span className="text-sm font-semibold text-white mt-1 block">Holt-Winters / ARIMA</span>
            <span className="text-[10px] font-mono text-[#4ADE80] mt-0.5 block">95% Confidence Bounds</span>
          </div>
          <div className="p-4 bg-[#0A0A0A] rounded border border-[#262626]">
            <span className="text-[#71717A] text-[10px] uppercase tracking-wider block">Queueing Topology</span>
            <span className="text-sm font-semibold text-[#C5A059] mt-1 block font-mono">M/M/18 Jackson Net</span>
            <span className="text-[10px] text-[#52525B] mt-0.5 block">Erlang-C Wait Probability</span>
          </div>
          <div className="p-4 bg-[#0A0A0A] rounded border border-[#262626]">
            <span className="text-[#71717A] text-[10px] uppercase tracking-wider block">Degradation Model</span>
            <span className="text-sm font-semibold text-white mt-1 block">Weibull (β = 2.80)</span>
            <span className="text-[10px] text-[#52525B] mt-0.5 block">ISO 10816 Vibration</span>
          </div>
          <div className="p-4 bg-[#0A0A0A] rounded border border-[#262626]">
            <span className="text-[#71717A] text-[10px] uppercase tracking-wider block">Tariff Optimizer</span>
            <span className="text-sm font-semibold text-[#4ADE80] mt-1 block">
              {energyData?.savingsPercentage || 36.4}% Savings
            </span>
            <span className="text-[10px] text-[#52525B] mt-0.5 block">Dynamic Charging Shift</span>
          </div>
        </div>
      </div>

      {/* Grid of Visual Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* SKU Demand Forecast Chart */}
        <div className="bg-[#141414] border border-[#262626] rounded p-6">
          <div className="flex items-center justify-between pb-4 border-b border-[#262626]">
            <div>
              <p className="text-[10px] uppercase tracking-widest text-[#71717A]">Time-Series Projection</p>
              <h3 className="text-base font-serif text-white mt-0.5 flex items-center gap-2">
                SKU Demand Forecast <span className="text-xs font-mono text-[#71717A] not-italic">({forecastData?.sku})</span>
              </h3>
            </div>
            <div className="text-right text-xs">
              <span className="text-[#71717A] text-[10px] uppercase tracking-wider">Safety Stock: </span>
              <span className="font-bold text-[#C5A059] font-mono">{forecastData?.recommendedSafetyStock} pcs</span>
            </div>
          </div>

          <div className="h-[260px] mt-5 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={forecastData?.forecast || []}>
                <CartesianGrid strokeDasharray="3 3" stroke="#262626" />
                <XAxis dataKey="day" stroke="#52525B" fontSize={11} />
                <YAxis stroke="#52525B" fontSize={11} domain={['dataMin - 20', 'dataMax + 20']} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0A0A0A', borderColor: '#262626', borderRadius: '4px', fontSize: '11px', color: '#D4D4D8' }}
                />
                <Area type="monotone" dataKey="upper" fill="#C5A059" fillOpacity={0.12} stroke="none" />
                <Area type="monotone" dataKey="lower" fill="#0A0A0A" fillOpacity={1} stroke="none" />
                <Line type="monotone" dataKey="point" stroke="#C5A059" strokeWidth={2} dot={{ r: 4, fill: '#C5A059' }} name="Forecast P95" />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-3 pt-3 border-t border-[#1E1E1E] text-[11px] text-[#71717A] flex justify-between font-mono">
            <span>Historical Mean: {forecastData?.historicalMean} picks/day</span>
            <span>Reorder Point: {forecastData?.reorderPoint} units</span>
          </div>
        </div>

        {/* Dynamic Electricity Tariff vs Peak-Shaving Charging */}
        <div className="bg-[#141414] border border-[#262626] rounded p-6">
          <div className="flex items-center justify-between pb-4 border-b border-[#262626]">
            <div>
              <p className="text-[10px] uppercase tracking-widest text-[#71717A]">Load Balancing</p>
              <h3 className="text-base font-serif text-white mt-0.5 flex items-center gap-2">
                Grid Tariff & Charging Optimizer
              </h3>
            </div>
            <span className="text-xs text-[#4ADE80] font-mono font-medium bg-[#0A0A0A] px-2.5 py-1 rounded border border-[#262626]">
              ${energyData?.optimizedDailyCost}/day (Opt)
            </span>
          </div>

          <div className="h-[260px] mt-5 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={energyData?.hourlyProfile || []}>
                <CartesianGrid strokeDasharray="3 3" stroke="#262626" />
                <XAxis dataKey="hour" stroke="#52525B" fontSize={10} tickFormatter={(h) => `${h}:00`} />
                <YAxis yAxisId="left" stroke="#C5A059" fontSize={11} tickFormatter={(v) => `$${v}`} />
                <YAxis yAxisId="right" orientation="right" stroke="#4ADE80" fontSize={11} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0A0A0A', borderColor: '#262626', borderRadius: '4px', fontSize: '11px', color: '#D4D4D8' }}
                />
                <Bar yAxisId="right" dataKey="chargeKwh" fill="#4ADE80" fillOpacity={0.35} name="Charge Allocation (kWh)" radius={[2, 2, 0, 0]} />
                <Line yAxisId="left" type="monotone" dataKey="tariff" stroke="#C5A059" strokeWidth={2} name="Spot Tariff ($/kWh)" dot={false} />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-3 pt-3 border-t border-[#1E1E1E] text-[11px] text-[#71717A] flex justify-between font-mono">
            <span>Peak Pricing Hours: {energyData?.peakHours?.map((h) => `${h}:00`).join(', ')}</span>
            <span className="text-[#4ADE80]">Cost Reduction: {energyData?.savingsPercentage}%</span>
          </div>
        </div>
      </div>
    </div>
  );
};

