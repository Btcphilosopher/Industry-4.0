export type InventoryState =
  | 'RECEIVED'
  | 'INSPECTED'
  | 'AVAILABLE'
  | 'ALLOCATED'
  | 'PICKED'
  | 'PACKED'
  | 'STAGED'
  | 'LOADED'
  | 'SHIPPED'
  | 'QUARANTINED'
  | 'DAMAGED';

export type RobotStatus =
  | 'IDLE'
  | 'ASSIGNED'
  | 'TRANSIT'
  | 'PICKING'
  | 'DELIVERING'
  | 'CHARGING'
  | 'MAINTENANCE_REQUIRED'
  | 'OUT_OF_SERVICE';

export interface RobotEntity {
  id: string;
  code: string;
  type: 'AMR' | 'AGV' | 'ROBOTIC_ARM' | 'FORKLIFT';
  model: string;
  manufacturer: string;
  status: RobotStatus;
  batterySoc: number;
  operatingHours: number;
  firmware: string;
  publicKey: string;
  position: { x: number; y: number };
  targetPosition?: { x: number; y: number };
  currentPayloadUnitId?: string;
  speedMps: number;
  motorCurrentA: number;
}

export interface InventoryUnitEntity {
  id: string;
  sku: string;
  lotNumber: string;
  serialNumber: string;
  palletId: string;
  locationBarcode: string;
  quantity: number;
  state: InventoryState;
  originSupplier: string;
  currentCustodian: string;
  latestEventHash: string;
  updatedAt: string;
}

export interface InventoryTransaction {
  id: string;
  type: string;
  unitId: string;
  sku: string;
  fromLocation: string;
  toLocation: string;
  fromState: InventoryState;
  toState: InventoryState;
  quantity: number;
  actorId: string;
  robotId?: string;
  orderId?: string;
  eventHash: string;
  prevEventHash: string;
  timestamp: string;
}

export interface MerkleBatchCommitment {
  id: string;
  batchSeqNum: number;
  eventCount: number;
  merkleRoot: string;
  batchHash: string;
  blockchainTxHash: string;
  blockNumber: number;
  status: 'BUFFERING' | 'CALCULATED' | 'CONFIRMED_ON_CHAIN' | 'FINALIZED';
  committedAt: string;
  events: string[];
}

export interface AssetEntity {
  id: string;
  assetTag: string;
  assetType: string;
  zone: string;
  model: string;
  manufacturer: string;
  commissionedDate: string;
  operatingHours: number;
  healthScore: number;
  rmsVibrationMms: number;
  peakKurtosis: number;
  status: 'HEALTHY' | 'WARNING' | 'CRITICAL';
}

export interface MaintenanceLog {
  id: string;
  assetTag: string;
  faultDescription: string;
  diagnosisCategory: string;
  correctiveAction: string;
  technicianId: string;
  partsConsumed: string[];
  costUsd: number;
  downtimeMinutes: number;
  safetyPassed: boolean;
  signature: string;
  certifiedAt: string;
}

export interface ForecastPoint {
  day: string;
  point: number;
  lower: number;
  upper: number;
}

export interface DemandForecastData {
  sku: string;
  historicalMean: number;
  recommendedSafetyStock: number;
  reorderPoint: number;
  trend: 'INCREASING' | 'DECREASING' | 'STABLE';
  forecast: ForecastPoint[];
}

export interface QueueingData {
  arrivalRate: number;
  packingServers: number;
  serverUtilization: number;
  avgQueueOrders: number;
  avgWaitMin: number;
  amrUtilization: number;
  congestionScore: number;
  status: 'OPTIMAL' | 'ELEVATED_LOAD' | 'CRITICAL_BOTTLENECK';
}

export interface EnergyTariffData {
  currentTariffUsdKwh: number;
  isPeak: boolean;
  totalActiveRobots: number;
  activeGridDrawKw: number;
  fleetChargingDrawKw: number;
  facilityBaseloadKw: number;
  unmanagedDailyCost: number;
  optimizedDailyCost: number;
  savingsPercentage: number;
  peakHours: number[];
  hourlyProfile: { hour: number; tariff: number; chargeKwh: number }[];
}

export interface MarginalCostReport {
  orderId: string;
  pickLaborCost: number;
  robotEnergyCost: number;
  robotAmortizationCost: number;
  packagingCost: number;
  conveyorCost: number;
  congestionPremium: number;
  totalCostUsd: number;
}
