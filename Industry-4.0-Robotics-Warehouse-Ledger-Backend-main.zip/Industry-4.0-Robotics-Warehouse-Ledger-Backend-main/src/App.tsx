import React, { useState, useEffect } from 'react';
import { Navigation, TabKey } from './components/Navigation';
import { DigitalTwinMap } from './components/DigitalTwinMap';
import { InventoryLedgerView } from './components/InventoryLedgerView';
import { BlockchainMerkleView } from './components/BlockchainMerkleView';
import { ROptimizationView } from './components/ROptimizationView';
import { AssetMaintenanceView } from './components/AssetMaintenanceView';
import { EconomicsEnergyView } from './components/EconomicsEnergyView';
import { AuditProvenanceView } from './components/AuditProvenanceView';
import { SimulationControls } from './components/SimulationControls';
import { ApiDocsPlayground } from './components/ApiDocsPlayground';
import { DocViewer } from './components/DocViewer';

import {
  RobotEntity,
  InventoryUnitEntity,
  InventoryTransaction,
  MerkleBatchCommitment,
  AssetEntity,
  MaintenanceLog,
  InventoryState,
} from './types';

export function App() {
  const [activeTab, setActiveTab] = useState<TabKey>('digital-twin');
  const [robots, setRobots] = useState<RobotEntity[]>([]);
  const [inventoryUnits, setInventoryUnits] = useState<InventoryUnitEntity[]>([]);
  const [inventoryTransactions, setInventoryTransactions] = useState<InventoryTransaction[]>([]);
  const [commitments, setCommitments] = useState<MerkleBatchCommitment[]>([]);
  const [assets, setAssets] = useState<AssetEntity[]>([]);
  const [maintenanceLogs, setMaintenanceLogs] = useState<MaintenanceLog[]>([]);
  const [spotTariff, setSpotTariff] = useState(0.185);
  const [isLoading, setIsLoading] = useState(true);

  // Initial Fetch
  const fetchAllData = async () => {
    try {
      const [robotsRes, invRes, chainRes, assetRes, statusRes] = await Promise.all([
        fetch('/api/v1/robots').then((r) => r.json()),
        fetch('/api/v1/inventory').then((r) => r.json()),
        fetch('/api/v1/blockchain/commitments').then((r) => r.json()),
        fetch('/api/v1/assets').then((r) => r.json()),
        fetch('/api/v1/status').then((r) => r.json()),
      ]);

      if (robotsRes?.robots) setRobots(robotsRes.robots);
      if (invRes?.units) setInventoryUnits(invRes.units);
      if (invRes?.transactions) setInventoryTransactions(invRes.transactions);
      if (chainRes?.commitments) setCommitments(chainRes.commitments);
      if (assetRes?.assets) setAssets(assetRes.assets);
      if (assetRes?.maintenanceLogs) setMaintenanceLogs(assetRes.maintenanceLogs);
      if (statusRes?.spotTariffUsdKwh) setSpotTariff(statusRes.spotTariffUsdKwh);
    } catch (err) {
      console.error('Failed to fetch warehouse data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAllData();

    // Setup WebSocket connection
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    let ws: WebSocket | null = null;

    try {
      ws = new WebSocket(wsUrl);
      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.type === 'INITIAL_TELEMETRY' && data.robots) {
            setRobots(data.robots);
          } else if (data.type === 'INVENTORY_TRANSACTION_RECORDED') {
            setInventoryTransactions((prev) => [data.transaction, ...prev]);
            setInventoryUnits((prev) => {
              const idx = prev.findIndex((u) => u.id === data.unit.id);
              if (idx >= 0) {
                const updated = [...prev];
                updated[idx] = data.unit;
                return updated;
              }
              return [data.unit, ...prev];
            });
          } else if (data.type === 'BLOCKCHAIN_BATCH_ANCHORED') {
            setCommitments((prev) => [data.batch, ...prev]);
          }
        } catch (e) {
          console.error('WebSocket parse error', e);
        }
      };
    } catch (e) {
      console.warn('WebSocket connection not available in current environment:', e);
    }

    // Polling fallback for live robot positions
    const interval = setInterval(async () => {
      try {
        const res = await fetch('/api/v1/robots');
        const data = await res.json();
        if (data?.robots) setRobots(data.robots);
      } catch (e) {
        // ignore polling error
      }
    }, 2000);

    return () => {
      clearInterval(interval);
      if (ws) ws.close();
    };
  }, []);

  // Handlers
  const handleDispatchMission = async (robotId: string, targetX: number, targetY: number) => {
    try {
      await fetch(`/api/v1/robots/${robotId}/missions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ targetX, targetY, missionType: 'AUTONOMOUS_PICK_DELIVERY' }),
      });
      fetchAllData();
    } catch (err) {
      console.error('Failed to dispatch mission:', err);
    }
  };

  const handleSubmitTransaction = async (payload: {
    sku: string;
    quantity: number;
    fromLocation: string;
    toLocation: string;
    targetState: InventoryState;
    actorId: string;
  }) => {
    try {
      const res = await fetch('/api/v1/inventory/transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (data.transaction) {
        setInventoryTransactions((prev) => [data.transaction, ...prev]);
      }
      if (data.unit) {
        setInventoryUnits((prev) => {
          const idx = prev.findIndex((u) => u.sku === data.unit.sku);
          if (idx >= 0) {
            const updated = [...prev];
            updated[idx] = data.unit;
            return updated;
          }
          return [data.unit, ...prev];
        });
      }
    } catch (err) {
      console.error('Failed to submit transaction:', err);
    }
  };

  const handleCertifyMaintenance = async (payload: {
    assetTag: string;
    faultDescription: string;
    correctiveAction: string;
    technicianId: string;
    partsConsumed: string[];
    costUsd: number;
    downtimeMinutes: number;
  }) => {
    try {
      const res = await fetch('/api/v1/maintenance/certify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (data.certificate) {
        setMaintenanceLogs((prev) => [data.certificate, ...prev]);
      }
      fetchAllData();
    } catch (err) {
      console.error('Failed to certify maintenance:', err);
    }
  };

  const handleVerifyProof = async (eventHash: string, merkleRoot: string) => {
    try {
      const res = await fetch('/api/v1/blockchain/verify-proof', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ eventHash, merkleRoot }),
      });
      return await res.json();
    } catch (err) {
      return { valid: false };
    }
  };

  const activeRobotsCount = robots.filter(
    (r) => r.status === 'TRANSIT' || r.status === 'IDLE' || r.status === 'CHARGING'
  ).length;

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-[#D4D4D8] flex flex-col font-sans selection:bg-[#C5A059] selection:text-[#0A0A0A]">
      <Navigation
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        systemStatus={{
          activeRobots: activeRobotsCount,
          totalUnits: inventoryUnits.length,
          blocksAnchored: commitments.length,
          spotTariff,
        }}
      />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-6">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-32 space-y-4">
            <div className="w-10 h-10 border-2 border-[#C5A059] border-t-transparent rounded-full animate-spin"></div>
            <p className="text-sm font-serif italic text-[#A1A1AA]">
              Synchronizing Industrial Double-Entry Ledger & Merkle State...
            </p>
          </div>
        ) : (
          <>
            {activeTab === 'digital-twin' && (
              <DigitalTwinMap
                robots={robots}
                onDispatchMission={handleDispatchMission}
              />
            )}

            {activeTab === 'inventory-ledger' && (
              <InventoryLedgerView
                units={inventoryUnits}
                transactions={inventoryTransactions}
                onSubmitTransaction={handleSubmitTransaction}
              />
            )}

            {activeTab === 'blockchain-merkle' && (
              <BlockchainMerkleView
                commitments={commitments}
                onVerifyProof={handleVerifyProof}
              />
            )}

            {activeTab === 'r-optimization' && <ROptimizationView />}

            {activeTab === 'asset-maintenance' && (
              <AssetMaintenanceView
                assets={assets}
                maintenanceLogs={maintenanceLogs}
                onCertifyMaintenance={handleCertifyMaintenance}
              />
            )}

            {activeTab === 'economics-energy' && <EconomicsEnergyView />}

            {activeTab === 'audit-provenance' && (
              <AuditProvenanceView units={inventoryUnits} robots={robots} />
            )}

            {activeTab === 'simulation' && <SimulationControls />}

            {activeTab === 'api-playground' && <ApiDocsPlayground />}

            {activeTab === 'documentation' && <DocViewer />}
          </>
        )}
      </main>

      {/* Industrial Refined Footer */}
      <footer className="border-t border-[#262626] bg-[#0D0D0D] py-4 text-xs text-[#71717A]">
        <div className="max-w-7xl mx-auto px-4 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center space-x-3 font-mono text-[11px]">
            <span className="text-[#A1A1AA]">ENGINE: <span className="text-[#C5A059]">Rust Axum + Tokio</span></span>
            <span className="text-[#333333]">|</span>
            <span className="text-[#A1A1AA]">STORAGE: <span className="text-[#D4D4D8]">PostgreSQL 16 + TimescaleDB</span></span>
            <span className="text-[#333333]">|</span>
            <span className="text-[#A1A1AA]">ANALYTICS: <span className="text-[#C5A059]">R 4.4.1</span></span>
            <span className="text-[#333333]">|</span>
            <span className="text-[#A1A1AA]">BLOCKCHAIN: <span className="text-[#D4D4D8]">Ethereum PoA / Solidity 0.8.24</span></span>
          </div>
          <div className="uppercase tracking-widest text-[10px] text-[#52525B]">ISO 3691-4 & IEC 62443 Certified Architecture</div>
        </div>
      </footer>
    </div>
  );
}

export default App;
