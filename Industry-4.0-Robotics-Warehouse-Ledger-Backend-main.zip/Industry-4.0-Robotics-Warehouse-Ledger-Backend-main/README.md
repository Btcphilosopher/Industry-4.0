# Industry 4.0 Robotics Warehouse: Industrial Data, Transaction & Blockchain Platform

A production-grade Rust + R + Blockchain industrial backend for highly automated Industry 4.0 robotic fulfilment centres. This platform acts as the authoritative data, transaction, audit, optimization, and economic layer beneath Python-based warehouse orchestration platforms (WMS, WCS, Fleet Managers, and Digital Twins).

---

## Architectural Role

```
                    ┌─────────────────────────────┐
                    │   Python Platform (WMS/WCS) │
                    │ Robot Control / Vision / AI │
                    └──────────────┬──────────────┘
                                   │ REST / gRPC / WebSocket
                    ┌──────────────▼──────────────┐
                    │   Rust Industrial Engine    │
                    │ Double-Entry / Event Store  │
                    │ Telemetry / State Machine   │
                    └──────────────┬──────────────┘
                ┌──────────────────┼──────────────────┐
        ┌───────▼───────┐  ┌──────▼──────┐   ┌──────▼──────┐
        │ Operational DB│  │ Event Store │   │ Blockchain   │
        │ TimescaleDB   │  │ Append-only │   │ Merkle Batch │
        └───────────────┘  └─────────────┘   └──────────────┘
                                   │
                           ┌───────▼───────┐
                           │   R Analytics │
                           │ Optimization  │
                           └───────────────┘
```

## Subsystem Highlights

1. **Rust Industrial Core (`warehouse-backend/`)**:
   - Tokio async runtime, Axum REST API, Tonic gRPC, and high-throughput event bus.
   - Deterministic double-entry inventory ledger with state machine transitions (`RECEIVED -> INSPECTED -> AVAILABLE -> ALLOCATED -> PICKED -> PACKED -> STAGED -> LOADED -> SHIPPED`).
   - Cryptographic machine identities (Ed25519 & mTLS) for AMRs, robotic arms, conveyors, and PLCs.
   - High-throughput Merkle batch commitment engine: batches thousands of operational events into cryptographic commitments anchored on-chain.
   - Industrial economics engine calculating marginal cost per order, pick, pallet, robot-hour, and congestion.
   - Energy ledger tracking kWh per operation, battery degradation, and dynamic grid tariff shifting.

2. **R Analytics & Optimization Layer (`r-analytics/`)**:
   - ARIMA & exponential smoothing SKU demand forecasting.
   - Weibull distribution & hazard rate modeling for predictive machine maintenance.
   - $M/M/c$ queueing theory for AMR congestion and dock throughput optimization.
   - Dynamic programming for peak-shaving robot charging schedules.
   - Monte Carlo simulation for SLA violation risk assessment.

3. **Permissioned Industrial Blockchain (`contracts/`)**:
   - Smart contracts for Inventory State Transitions, Asset Provenance, Robot Identity, Maintenance Certification, and SLA Penalties.
   - Reverse-lookup indexer from Blockchain TX $\to$ Merkle Root $\to$ Event Batch $\to$ Warehouse Event.
   - Multi-party trust model (Warehouse Operator, 3PL, Supplier, Manufacturer, Carrier, Auditor, Insurer).

4. **Time-Series & Operational Storage (`sql/`, `migrations/`)**:
   - PostgreSQL relational schemas with strict foreign keys, partial indexes, and optimistic locking.
   - TimescaleDB hypertables with compression and continuous aggregates for high-frequency telemetry (LiDAR, motor vibration, battery state).

5. **Python Orchestration Client (`python-client/`)**:
   - Ready-to-use SDK for Python WMS/WCS systems to dispatch tasks, stream telemetry, and query ledger proofs.

---

## Directory Structure

- `warehouse-backend/` - Cargo multi-crate Rust workspace (16 crates)
- `r-analytics/` - Statistical and optimization R scripts with IPC bridge
- `contracts/` - Industrial smart contracts
- `sql/` - PostgreSQL & TimescaleDB DDL schemas and migration scripts
- `python-client/` - Python WMS/WCS client SDK and robot simulation agent
- `docs/` - Comprehensive technical documentation suite
- `docker/` & `k8s/` - Containerization and Kubernetes orchestration manifests
- `src/` & `server.ts` - Live full-stack execution engine and industrial control room
