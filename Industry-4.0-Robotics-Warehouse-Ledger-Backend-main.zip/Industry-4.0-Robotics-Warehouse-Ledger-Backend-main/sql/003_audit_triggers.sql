-- 003_audit_triggers.sql
-- Cryptographic integrity triggers & double-entry conservation verification

-- Function to prevent historical mutation on the event_store
CREATE OR REPLACE FUNCTION enforce_event_store_immutability()
RETURNS TRIGGER AS $$
BEGIN
    RAISE EXCEPTION 'CRITICAL SECURITY VIOLATION: event_store records are strictly append-only and immutable.';
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER trg_event_store_no_update_delete
BEFORE UPDATE OR DELETE ON event_store
FOR EACH ROW EXECUTE FUNCTION enforce_event_store_immutability();

CREATE OR REPLACE TRIGGER trg_event_batches_no_delete
BEFORE DELETE ON event_batches
FOR EACH ROW EXECUTE FUNCTION enforce_event_store_immutability();

-- Function to audit inventory quantity non-negativity and consistency
CREATE OR REPLACE FUNCTION verify_inventory_movement_invariant()
RETURNS TRIGGER AS $$
DECLARE
    current_stock INT;
BEGIN
    SELECT quantity INTO current_stock FROM inventory_units WHERE id = NEW.inventory_unit_id;
    IF current_stock < 0 THEN
        RAISE EXCEPTION 'LEDGER CONSERVATION INVARIANT BREACH: SKU unit % stock went below zero (value: %)', NEW.inventory_unit_id, current_stock;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER trg_check_inventory_invariant
AFTER INSERT OR UPDATE ON inventory_transactions
FOR EACH ROW EXECUTE FUNCTION verify_inventory_movement_invariant();
