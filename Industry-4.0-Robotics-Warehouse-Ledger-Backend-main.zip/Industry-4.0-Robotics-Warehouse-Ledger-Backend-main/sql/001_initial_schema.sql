-- 001_initial_schema.sql
-- Master Industrial Warehouse Schema for PostgreSQL 16+

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================================
-- 1. ORGANIZATIONS, IDENTITIES & ACCESS CONTROL
-- ============================================================================

CREATE TABLE organisations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code VARCHAR(32) NOT NULL UNIQUE,
    legal_name VARCHAR(255) NOT NULL,
    org_type VARCHAR(32) NOT NULL CHECK (org_type IN ('OPERATOR', '3PL', 'SUPPLIER', 'CARRIER', 'MANUFACTURER', 'AUDITOR', 'INSURER')),
    public_key VARCHAR(256) NOT NULL,
    certificate_pem TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    is_active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE identities (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id UUID NOT NULL REFERENCES organisations(id) ON DELETE RESTRICT,
    identifier VARCHAR(64) NOT NULL UNIQUE, -- e.g. "TECH-0192", "RBT-AMR-004", "OP-882"
    identity_type VARCHAR(32) NOT NULL CHECK (identity_type IN ('HUMAN_OPERATOR', 'TECHNICIAN', 'ROBOT', 'MACHINE', 'SYSTEM_SERVICE', 'AUDITOR')),
    public_key VARCHAR(256) NOT NULL,
    roles TEXT[] NOT NULL DEFAULT '{}',
    is_revoked BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================================
-- 2. FACILITY HIERARCHY
-- ============================================================================

CREATE TABLE warehouses (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code VARCHAR(32) NOT NULL UNIQUE,
    name VARCHAR(128) NOT NULL,
    site_name VARCHAR(128) NOT NULL,
    latitude NUMERIC(9,6),
    longitude NUMERIC(9,6),
    total_area_sqm NUMERIC(10,2) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE zones (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    warehouse_id UUID NOT NULL REFERENCES warehouses(id) ON DELETE CASCADE,
    code VARCHAR(32) NOT NULL,
    name VARCHAR(64) NOT NULL,
    zone_type VARCHAR(32) NOT NULL CHECK (zone_type IN ('STORAGE_HIGH_BAY', 'PICKING_AISLE', 'ASRS', 'PACKING_CELL', 'RECEIVING_DOCK', 'SHIPPING_BAY', 'CHARGING_DEPOT', 'MAINTENANCE_BAY', 'CONVEYOR_BUFFER')),
    temp_celsius_target NUMERIC(4,1),
    UNIQUE(warehouse_id, code)
);

CREATE TABLE locations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    zone_id UUID NOT NULL REFERENCES zones(id) ON DELETE CASCADE,
    barcode VARCHAR(64) NOT NULL UNIQUE,
    aisle INT NOT NULL,
    rack INT NOT NULL,
    shelf INT NOT NULL,
    bin INT NOT NULL,
    coord_x_mm INT NOT NULL,
    coord_y_mm INT NOT NULL,
    coord_z_mm INT NOT NULL,
    max_weight_kg NUMERIC(8,2) NOT NULL DEFAULT 1000.0,
    is_occupied BOOLEAN NOT NULL DEFAULT FALSE
);

-- ============================================================================
-- 3. INVENTORY & DOUBLE-ENTRY LEDGER
-- ============================================================================

CREATE TABLE products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sku VARCHAR(64) NOT NULL UNIQUE,
    name VARCHAR(255) NOT NULL,
    category VARCHAR(64) NOT NULL,
    unit_weight_kg NUMERIC(8,3) NOT NULL,
    hazmat_class VARCHAR(32),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE inventory_units (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sku VARCHAR(64) NOT NULL REFERENCES products(sku) ON DELETE RESTRICT,
    lot_number VARCHAR(64) NOT NULL,
    serial_number VARCHAR(64) UNIQUE,
    pallet_id VARCHAR(64) NOT NULL,
    location_id UUID REFERENCES locations(id) ON DELETE RESTRICT,
    quantity INT NOT NULL CHECK (quantity >= 0),
    state VARCHAR(32) NOT NULL CHECK (state IN ('RECEIVED', 'INSPECTED', 'AVAILABLE', 'ALLOCATED', 'PICKED', 'PACKED', 'STAGED', 'LOADED', 'SHIPPED', 'QUARANTINED', 'DAMAGED')),
    origin_supplier_id UUID REFERENCES organisations(id),
    current_custodian_id UUID REFERENCES identities(id),
    latest_event_hash VARCHAR(64) NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE inventory_transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    transaction_type VARCHAR(32) NOT NULL CHECK (transaction_type IN ('RECEIVE', 'PUTAWAY', 'MOVE', 'PICK', 'PACK', 'CONSOLIDATE', 'SORT', 'LOAD', 'SHIP', 'CYCLE_COUNT', 'QUARANTINE', 'ADJUST')),
    inventory_unit_id UUID NOT NULL REFERENCES inventory_units(id) ON DELETE RESTRICT,
    from_location_id UUID REFERENCES locations(id),
    to_location_id UUID REFERENCES locations(id),
    from_state VARCHAR(32) NOT NULL,
    to_state VARCHAR(32) NOT NULL,
    quantity INT NOT NULL,
    actor_identity_id UUID NOT NULL REFERENCES identities(id),
    robot_id UUID,
    order_id UUID,
    event_hash VARCHAR(64) NOT NULL UNIQUE,
    prev_event_hash VARCHAR(64) NOT NULL,
    digital_signature VARCHAR(256) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================================
-- 4. ROBOT FLEET & ASSETS
-- ============================================================================

CREATE TABLE robots (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    robot_code VARCHAR(32) NOT NULL UNIQUE, -- e.g. "RBT-AMR-0482"
    robot_type VARCHAR(32) NOT NULL CHECK (robot_type IN ('AMR', 'AGV', 'ROBOTIC_ARM', 'PALLET_SHUTTLE', 'FORKLIFT', 'ASRS_CRANE')),
    manufacturer VARCHAR(64) NOT NULL,
    model VARCHAR(64) NOT NULL,
    serial_number VARCHAR(64) NOT NULL UNIQUE,
    current_warehouse_id UUID NOT NULL REFERENCES warehouses(id),
    status VARCHAR(32) NOT NULL CHECK (status IN ('IDLE', 'ASSIGNED', 'TRANSIT', 'PICKING', 'DELIVERING', 'CHARGING', 'MAINTENANCE_REQUIRED', 'OUT_OF_SERVICE')),
    battery_soc_percent NUMERIC(5,2) NOT NULL DEFAULT 100.0,
    operating_hours NUMERIC(8,2) NOT NULL DEFAULT 0.0,
    firmware_version VARCHAR(32) NOT NULL,
    public_key VARCHAR(256) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE robot_missions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    robot_id UUID NOT NULL REFERENCES robots(id) ON DELETE RESTRICT,
    mission_type VARCHAR(32) NOT NULL CHECK (mission_type IN ('PALLET_PUTAWAY', 'GOODS_TO_PERSON_PICK', 'CROSS_DOCK_TRANSFER', 'CHARGER_DOCK', 'CYCLE_COUNT_SCAN')),
    state VARCHAR(32) NOT NULL CHECK (state IN ('QUEUED', 'ACCEPTED', 'STARTED', 'WAYPOINT_REACHED', 'PAYLOAD_ACQUIRED', 'PAYLOAD_DELIVERED', 'COMPLETED', 'ABORTED', 'FAILED')),
    source_location_id UUID REFERENCES locations(id),
    target_location_id UUID REFERENCES locations(id),
    payload_unit_id UUID REFERENCES inventory_units(id),
    distance_meters NUMERIC(8,2) NOT NULL DEFAULT 0.0,
    energy_consumed_wh NUMERIC(8,2) NOT NULL DEFAULT 0.0,
    signature VARCHAR(256) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);

CREATE TABLE assets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    asset_tag VARCHAR(64) NOT NULL UNIQUE,
    asset_type VARCHAR(32) NOT NULL CHECK (asset_type IN ('CONVEYOR_SEGMENT', 'SORTATION_DIVERT', 'PACKING_ROBOT', 'PALLET_WRAPPER', 'CHARGING_STATION', 'LIDAR_SCANNER', 'PLC_CONTROLLER', 'BATTERY_PACK')),
    warehouse_id UUID NOT NULL REFERENCES warehouses(id),
    zone_id UUID REFERENCES zones(id),
    model VARCHAR(64) NOT NULL,
    manufacturer VARCHAR(64) NOT NULL,
    commissioned_date DATE NOT NULL,
    operating_hours NUMERIC(8,2) NOT NULL DEFAULT 0.0,
    health_index_score NUMERIC(5,2) NOT NULL DEFAULT 100.0,
    is_active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE asset_maintenance_records (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    asset_id UUID NOT NULL REFERENCES assets(id) ON DELETE RESTRICT,
    fault_description TEXT NOT NULL,
    diagnosis_category VARCHAR(64) NOT NULL,
    corrective_action TEXT NOT NULL,
    technician_identity_id UUID NOT NULL REFERENCES identities(id),
    parts_consumed JSONB NOT NULL DEFAULT '[]'::jsonb,
    direct_cost_usd NUMERIC(10,2) NOT NULL DEFAULT 0.0,
    downtime_minutes NUMERIC(8,2) NOT NULL DEFAULT 0.0,
    safety_inspection_passed BOOLEAN NOT NULL DEFAULT TRUE,
    certification_signature VARCHAR(256) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================================
-- 5. EVENT SOURCING & BLOCKCHAIN COMMITMENTS
-- ============================================================================

CREATE TABLE event_batches (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    batch_seq_num BIGSERIAL UNIQUE,
    event_count INT NOT NULL,
    merkle_root VARCHAR(64) NOT NULL UNIQUE,
    batch_hash VARCHAR(64) NOT NULL,
    blockchain_tx_hash VARCHAR(66),
    block_number BIGINT,
    chain_id VARCHAR(32) NOT NULL DEFAULT 'industrial-poa-net-1',
    status VARCHAR(32) NOT NULL CHECK (status IN ('BUFFERING', 'CALCULATED', 'SUBMITTED', 'CONFIRMED_ON_CHAIN', 'FINALIZED')),
    committed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE event_store (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    batch_id UUID REFERENCES event_batches(id),
    stream_id VARCHAR(128) NOT NULL, -- e.g. "inventory:unit:1024", "robot:0482"
    version BIGINT NOT NULL,
    event_type VARCHAR(64) NOT NULL,
    payload JSONB NOT NULL,
    actor_id UUID NOT NULL REFERENCES identities(id),
    event_hash VARCHAR(64) NOT NULL UNIQUE,
    prev_event_hash VARCHAR(64) NOT NULL,
    signature VARCHAR(256) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(stream_id, version)
);

-- ============================================================================
-- 6. ORDERS, SHIPMENTS & SLA CONTRACTS
-- ============================================================================

CREATE TABLE orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_number VARCHAR(64) NOT NULL UNIQUE,
    customer_org_id UUID REFERENCES organisations(id),
    priority VARCHAR(16) NOT NULL DEFAULT 'STANDARD',
    status VARCHAR(32) NOT NULL CHECK (status IN ('CREATED', 'RELEASED', 'IN_PICKING', 'PICKED', 'PACKED', 'STAGED', 'DISPATCHED', 'DELIVERED', 'CANCELLED')),
    target_dispatch_deadline TIMESTAMPTZ NOT NULL,
    actual_dispatched_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE sla_contracts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    contract_code VARCHAR(64) NOT NULL UNIQUE,
    customer_org_id UUID NOT NULL REFERENCES organisations(id),
    max_fulfillment_minutes INT NOT NULL,
    penalty_usd_per_minute_delayed NUMERIC(8,2) NOT NULL,
    on_chain_contract_address VARCHAR(42),
    is_active BOOLEAN NOT NULL DEFAULT TRUE
);

-- ============================================================================
-- 7. INDUSTRIAL ECONOMICS & ENERGY LEDGER
-- ============================================================================

CREATE TABLE energy_ledger (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    warehouse_id UUID NOT NULL REFERENCES warehouses(id),
    zone_id UUID REFERENCES zones(id),
    consumer_type VARCHAR(32) NOT NULL CHECK (consumer_type IN ('ROBOT_CHARGING', 'CONVEYOR_GRID', 'HVAC_CLIMATE', 'LIGHTING', 'PACKING_MACHINERY')),
    energy_kwh NUMERIC(10,4) NOT NULL,
    grid_tariff_usd_per_kwh NUMERIC(8,4) NOT NULL,
    total_cost_usd NUMERIC(10,4) GENERATED ALWAYS AS (energy_kwh * grid_tariff_usd_per_kwh) STORED,
    timestamp_interval_start TIMESTAMPTZ NOT NULL,
    timestamp_interval_end TIMESTAMPTZ NOT NULL
);

CREATE TABLE economic_cost_records (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID REFERENCES orders(id),
    robot_mission_id UUID REFERENCES robot_missions(id),
    cost_category VARCHAR(32) NOT NULL CHECK (cost_category IN ('ROBOT_ENERGY', 'ROBOT_AMORTIZATION', 'CONVEYOR_TRANSIT', 'LABOR_PICK', 'MAINTENANCE_RESERVE', 'CONGESTION_PENALTY')),
    amount_usd NUMERIC(10,4) NOT NULL,
    calculation_basis JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
