-- 002_timescaledb_telemetry.sql
-- High-frequency time-series tables for TimescaleDB

CREATE TABLE IF NOT EXISTS telemetry_robot_kinematics (
    recorded_at TIMESTAMPTZ NOT NULL,
    robot_id UUID NOT NULL,
    pos_x_mm INT NOT NULL,
    pos_y_mm INT NOT NULL,
    heading_rad NUMERIC(5,4) NOT NULL,
    velocity_mps NUMERIC(5,3) NOT NULL,
    acceleration_mps2 NUMERIC(5,3) NOT NULL,
    obstacle_distance_mm INT,
    lidar_status_code INT NOT NULL DEFAULT 0
);

-- Convert to hypertable (TimescaleDB)
SELECT create_hypertable('telemetry_robot_kinematics', 'recorded_at', if_not_exists => TRUE, chunk_time_interval => INTERVAL '2 hours');

CREATE TABLE IF NOT EXISTS telemetry_robot_powertrain (
    recorded_at TIMESTAMPTZ NOT NULL,
    robot_id UUID NOT NULL,
    battery_soc_pct NUMERIC(5,2) NOT NULL,
    battery_temp_c NUMERIC(5,2) NOT NULL,
    bus_voltage_v NUMERIC(6,2) NOT NULL,
    motor_left_current_a NUMERIC(6,3) NOT NULL,
    motor_right_current_a NUMERIC(6,3) NOT NULL,
    inverter_temp_c NUMERIC(5,2) NOT NULL
);

SELECT create_hypertable('telemetry_robot_powertrain', 'recorded_at', if_not_exists => TRUE, chunk_time_interval => INTERVAL '2 hours');

CREATE TABLE IF NOT EXISTS telemetry_vibration_spectra (
    recorded_at TIMESTAMPTZ NOT NULL,
    asset_id UUID NOT NULL,
    sensor_location VARCHAR(32) NOT NULL, -- e.g. "BEARING_DRIVE_END"
    rms_vibration_mms NUMERIC(7,4) NOT NULL,
    peak_kurtosis NUMERIC(6,3) NOT NULL,
    spectral_energy_hz_10_1000 NUMERIC(10,3) NOT NULL,
    is_anomaly BOOLEAN NOT NULL DEFAULT FALSE
);

SELECT create_hypertable('telemetry_vibration_spectra', 'recorded_at', if_not_exists => TRUE, chunk_time_interval => INTERVAL '6 hours');

-- Compression policies
ALTER TABLE telemetry_robot_kinematics SET (
    timescaledb.compress,
    timescaledb.compress_segmentby = 'robot_id',
    timescaledb.compress_orderby = 'recorded_at DESC'
);
SELECT add_compression_policy('telemetry_robot_kinematics', INTERVAL '24 hours', if_not_exists => TRUE);
