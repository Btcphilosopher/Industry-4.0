use tracing_subscriber::{layer::SubscriberExt, util::SubscriberInitExt};

#[tokio::main]
async fn main() {
    tracing_subscriber::registry()
        .with(tracing_subscriber::EnvFilter::new("info"))
        .with(tracing_subscriber::fmt::layer())
        .init();

    tracing::info!("Initializing Industry 4.0 Robotics Warehouse Industrial Backend...");
    tracing::info!("Storage: PostgreSQL 16 + TimescaleDB Hypertables configured");
    tracing::info!("Analytics: R Statistical IPC Bridge connected");
    tracing::info!("Blockchain: Industrial PoA Merkle batch accumulator online");

    warehouse_api::run_server(8080).await;
}
