use warehouse_core::{WarehouseError, Result, sha256_hex, canonicalize_event};
use warehouse_domain::Asset;

pub struct AssetRegistry;

impl AssetRegistry {
    pub fn assess_telemetry(asset: &mut Asset, rms_vibration_mms: f64, peak_kurtosis: f64) -> Result<String> {
        let is_anomaly = rms_vibration_mms > 4.5 || peak_kurtosis > 5.0;
        if is_anomaly {
            asset.health_index_score = (asset.health_index_score - 15.0).max(10.0);
        } else {
            asset.health_index_score = (asset.health_index_score + 0.5).min(100.0);
        }

        let payload = serde_json::json!({
            "asset_tag": asset.asset_tag,
            "rms_vibration": rms_vibration_mms,
            "peak_kurtosis": peak_kurtosis,
            "health_score": asset.health_index_score,
            "operating_hours": asset.operating_hours
        });

        let (_, hash) = canonicalize_event("ASSET_TELEMETRY_ASSESSED", &format!("asset:{}", asset.id), 1, &payload, "GENESIS");

        if rms_vibration_mms > 6.5 {
            return Err(WarehouseError::AssetMaintenanceRequired {
                asset_id: asset.asset_tag.clone(),
                reason: format!("Vibration exceeded critical ISO threshold: {} mm/s", rms_vibration_mms),
            });
        }

        Ok(hash)
    }
}
