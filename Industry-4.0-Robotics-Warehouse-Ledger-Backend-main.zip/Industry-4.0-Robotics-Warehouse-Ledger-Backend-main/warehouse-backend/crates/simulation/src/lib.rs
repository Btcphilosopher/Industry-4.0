use warehouse_domain::{Robot, RobotStatus, RobotType};
use uuid::Uuid;
use chrono::Utc;

pub struct WarehouseSimulator {
    pub fleet: Vec<Robot>,
}

impl WarehouseSimulator {
    pub fn new(count: usize) -> Self {
        let mut fleet = Vec::with_capacity(count);
        let warehouse_id = Uuid::new_v4();

        for i in 1..=count {
            let robot = Robot {
                id: Uuid::new_v4(),
                robot_code: format!("RBT-AMR-{:04}", i),
                robot_type: RobotType::Amr,
                manufacturer: "KION / Quicktron Industrial".to_string(),
                model: "AMR-Heavy-1500".to_string(),
                serial_number: format!("SN-2026-{}", 90000 + i),
                current_warehouse_id: warehouse_id,
                status: if i % 7 == 0 { RobotStatus::Charging } else if i % 3 == 0 { RobotStatus::Transit } else { RobotStatus::Idle },
                battery_soc_percent: 75.0 + ((i * 13) % 25) as f64,
                operating_hours: 1200.0 + ((i * 73) % 8000) as f64,
                firmware_version: "v8.4.1".to_string(),
                public_key: format!("ed25519_pk_{:04}", i),
                current_position: (((i * 7) % 60) as f64, ((i * 11) % 40) as f64),
                created_at: Utc::now(),
            };
            fleet.push(robot);
        }

        Self { fleet }
    }

    pub fn tick(&mut self) {
        for (i, robot) in self.fleet.iter_mut().enumerate() {
            if robot.status == RobotStatus::Transit {
                robot.current_position.0 = (robot.current_position.0 + 0.5) % 60.0;
                robot.battery_soc_percent = (robot.battery_soc_percent - 0.05).max(5.0);
            } else if robot.status == RobotStatus::Charging {
                robot.battery_soc_percent = (robot.battery_soc_percent + 0.3).min(100.0);
                if robot.battery_soc_percent >= 98.0 {
                    robot.status = RobotStatus::Idle;
                }
            } else if robot.battery_soc_percent < 20.0 {
                robot.status = RobotStatus::Charging;
            } else if i % 2 == 0 {
                robot.status = RobotStatus::Transit;
            }
        }
    }
}
