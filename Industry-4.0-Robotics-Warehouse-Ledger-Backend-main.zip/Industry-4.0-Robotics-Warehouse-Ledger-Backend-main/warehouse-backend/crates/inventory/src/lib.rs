use warehouse_core::{WarehouseError, Result, sha256_hex, canonicalize_event};
use warehouse_domain::{InventoryState, InventoryUnit};
use chrono::Utc;
use uuid::Uuid;

pub struct InventoryLedgerEngine;

impl InventoryLedgerEngine {
    pub fn validate_transition(from: &InventoryState, to: &InventoryState) -> bool {
        match (from, to) {
            (InventoryState::Received, InventoryState::Inspected) => true,
            (InventoryState::Received, InventoryState::Quarantined) => true,
            (InventoryState::Inspected, InventoryState::Available) => true,
            (InventoryState::Inspected, InventoryState::Quarantined) => true,
            (InventoryState::Available, InventoryState::Allocated) => true,
            (InventoryState::Allocated, InventoryState::Picked) => true,
            (InventoryState::Picked, InventoryState::Packed) => true,
            (InventoryState::Packed, InventoryState::Staged) => true,
            (InventoryState::Staged, InventoryState::Loaded) => true,
            (InventoryState::Loaded, InventoryState::Shipped) => true,
            (_, InventoryState::Damaged) => true,
            (_, InventoryState::Quarantined) => true,
            _ => false,
        }
    }

    pub fn execute_transition(
        unit: &mut InventoryUnit,
        target_state: InventoryState,
        actor_id: &str,
        robot_id: Option<&str>,
        order_id: Option<&str>,
    ) -> Result<String> {
        if !Self::validate_transition(&unit.state, &target_state) {
            return Err(WarehouseError::InvalidStateTransition {
                unit_id: unit.id.to_string(),
                from: format!("{:?}", unit.state),
                to: format!("{:?}", target_state),
            });
        }

        let old_state = unit.state.clone();
        unit.state = target_state.clone();
        unit.updated_at = Utc::now();

        let payload = serde_json::json!({
            "unit_id": unit.id,
            "sku": unit.sku,
            "quantity": unit.quantity,
            "from_state": format!("{:?}", old_state),
            "to_state": format!("{:?}", target_state),
            "actor_id": actor_id,
            "robot_id": robot_id,
            "order_id": order_id,
            "timestamp": unit.updated_at.to_rfc3339()
        });

        let (_, event_hash) = canonicalize_event(
            "INVENTORY_STATE_TRANSITION",
            &format!("unit:{}", unit.id),
            1,
            &payload,
            &unit.latest_event_hash,
        );

        unit.latest_event_hash = event_hash.clone();
        Ok(event_hash)
    }
}
