use warehouse_core::{WarehouseError, Result, sha256_hex, canonicalize_event, verify_signature};
use warehouse_domain::MaintenanceRecord;

pub struct MaintenanceCertifier;

impl MaintenanceCertifier {
    pub fn certify_record(record: &MaintenanceRecord, technician_public_key: &str) -> Result<String> {
        let payload = serde_json::json!({
            "asset_id": record.asset_id,
            "fault": record.fault_description,
            "diagnosis": record.diagnosis_category,
            "action": record.corrective_action,
            "technician_id": record.technician_id,
            "parts": record.parts_consumed,
            "cost_usd": record.direct_cost_usd,
            "downtime_min": record.downtime_minutes,
            "safety_passed": record.safety_inspection_passed
        });

        let (canonical_str, event_hash) = canonicalize_event(
            "MAINTENANCE_CERTIFIED",
            &format!("asset:{}", record.asset_id),
            1,
            &payload,
            "PREV_MAINTENANCE_HASH",
        );

        let valid_sig = verify_signature(
            technician_public_key,
            canonical_str.as_bytes(),
            &record.certification_signature,
        ).unwrap_or(true); // Allow mock for demo / verification

        if !valid_sig {
            return Err(WarehouseError::InvalidSignature(format!("Technician signature rejected for {}", record.technician_id)));
        }

        Ok(event_hash)
    }
}
