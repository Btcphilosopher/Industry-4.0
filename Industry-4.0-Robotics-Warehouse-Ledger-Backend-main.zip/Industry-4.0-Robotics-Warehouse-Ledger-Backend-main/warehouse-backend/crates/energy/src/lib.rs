use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EnergyReport {
    pub current_tariff_usd_kwh: f64,
    pub is_peak_window: bool,
    pub active_grid_draw_kw: f64,
    pub fleet_charging_draw_kw: f64,
    pub facility_baseload_kw: f64,
    pub carbon_intensity_g_kwh: f64,
    pub recommended_action: String,
}

pub struct EnergyLedgerEngine;

impl EnergyLedgerEngine {
    pub fn assess_power_state(hour_of_day: u32, spot_tariff: f64, active_charging_amrs: usize) -> EnergyReport {
        let is_peak = spot_tariff > 0.28;
        let fleet_charging_draw = (active_charging_amrs as f64) * 3.5; // 3.5 kW fast charge
        let baseload = 145.0; // HVAC + Conveyors + Lighting

        let action = if is_peak {
            "THROTTLE_NON_ESSENTIAL_CHARGING".to_string()
        } else {
            "MAXIMIZE_OPPORTUNITY_CHARGING".to_string()
        };

        EnergyReport {
            current_tariff_usd_kwh: spot_tariff,
            is_peak_window: is_peak,
            active_grid_draw_kw: baseload + fleet_charging_draw,
            fleet_charging_draw_kw: fleet_charging_draw,
            facility_baseload_kw: baseload,
            carbon_intensity_g_kwh: if is_peak { 340.0 } else { 185.0 },
            recommended_action: action,
        }
    }
}
