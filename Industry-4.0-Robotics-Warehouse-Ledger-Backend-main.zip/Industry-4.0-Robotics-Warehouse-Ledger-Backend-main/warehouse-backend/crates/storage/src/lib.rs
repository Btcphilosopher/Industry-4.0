use warehouse_core::Result;
use warehouse_domain::{InventoryUnit, Robot, Asset, MerkleBatchRecord};
use parking_lot::RwLock;
use std::collections::HashMap;
use std::sync::Arc;
use uuid::Uuid;

#[derive(Clone)]
pub struct InMemoryRepository {
    pub units: Arc<RwLock<HashMap<Uuid, InventoryUnit>>>,
    pub robots: Arc<RwLock<HashMap<Uuid, Robot>>>,
    pub assets: Arc<RwLock<HashMap<Uuid, Asset>>>,
    pub batches: Arc<RwLock<Vec<MerkleBatchRecord>>>,
    pub event_log: Arc<RwLock<Vec<(String, String)>>>,
}

impl InMemoryRepository {
    pub fn new() -> Self {
        Self {
            units: Arc::new(RwLock::new(HashMap::new())),
            robots: Arc::new(RwLock::new(HashMap::new())),
            assets: Arc::new(RwLock::new(HashMap::new())),
            batches: Arc::new(RwLock::new(Vec::new())),
            event_log: Arc::new(RwLock::new(Vec::new())),
        }
    }

    pub fn insert_unit(&self, unit: InventoryUnit) {
        self.units.write().insert(unit.id, unit);
    }

    pub fn get_unit(&self, id: &Uuid) -> Option<InventoryUnit> {
        self.units.read().get(id).cloned()
    }

    pub fn insert_robot(&self, robot: Robot) {
        self.robots.write().insert(robot.id, robot);
    }

    pub fn get_all_robots(&self) -> Vec<Robot> {
        self.robots.read().values().cloned().collect()
    }

    pub fn append_event(&self, stream_id: String, hash: String) {
        self.event_log.write().push((stream_id, hash));
    }
}
