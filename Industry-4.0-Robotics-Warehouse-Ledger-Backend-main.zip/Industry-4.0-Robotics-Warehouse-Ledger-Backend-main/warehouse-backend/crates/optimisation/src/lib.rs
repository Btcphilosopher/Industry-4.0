use serde::{Serialize, Deserialize};
use warehouse_core::{WarehouseError, Result};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DemandForecastResult {
    pub sku: String,
    pub historical_mean: f64,
    pub recommended_safety_stock: u32,
    pub reorder_point: u32,
    pub point_forecast: Vec<f64>,
}

pub struct ROptimizationClient {
    pub endpoint_url: String,
}

impl ROptimizationClient {
    pub fn new(endpoint_url: String) -> Self {
        Self { endpoint_url }
    }

    pub fn compute_forecast_native(&self, sku: &str, history: &[f64]) -> DemandForecastResult {
        let mean_val = if history.is_empty() { 50.0 } else { history.iter().sum::<f64>() / (history.len() as f64) };
        DemandForecastResult {
            sku: sku.to_string(),
            historical_mean: (mean_val * 10.0).round() / 10.0,
            recommended_safety_stock: (mean_val * 0.35).ceil() as u32,
            reorder_point: (mean_val * 2.2).ceil() as u32,
            point_forecast: (0..7).map(|i| ((mean_val + (i as f64) * 2.5) * 10.0).round() / 10.0).collect(),
        }
    }
}
