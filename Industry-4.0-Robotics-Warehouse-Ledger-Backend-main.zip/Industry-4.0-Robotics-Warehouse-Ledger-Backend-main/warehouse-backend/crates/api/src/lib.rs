use axum::{
    routing::{get, post},
    Router, Json, response::IntoResponse,
};
use serde_json::json;
use std::net::SocketAddr;
use tower_http::cors::CorsLayer;

pub fn create_router() -> Router {
    Router::new()
        .route("/api/v1/health", get(health_check))
        .route("/api/v1/status", get(system_status))
        .layer(CorsLayer::permissive())
}

async fn health_check() -> impl IntoResponse {
    Json(json!({
        "status": "HEALTHY",
        "subsystems": {
            "transaction_engine": "ONLINE",
            "double_entry_ledger": "ACTIVE",
            "merkle_batch_committer": "SYNCED",
            "timescaledb_telemetry": "CONNECTED",
            "r_analytics_bridge": "READY"
        }
    }))
}

async fn system_status() -> impl IntoResponse {
    Json(json!({
        "warehouse_code": "WH-GLOBAL-01",
        "active_robots": 84,
        "inventory_units_tracked": 128490,
        "anchored_merkle_batches": 1420,
        "grid_tariff_usd_kwh": 0.185,
        "marginal_cost_per_order": 3.42
    }))
}

pub async fn run_server(port: u16) {
    let app = create_router();
    let addr = SocketAddr::from(([0, 0, 0, 0], port));
    tracing::info!("Rust Industrial Backend listening on {}", addr);
    let listener = tokio::net::TcpListener::bind(addr).await.unwrap();
    axum::serve(listener, app).await.unwrap();
}
