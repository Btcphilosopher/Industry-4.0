use serde::{Serialize, Deserialize};
use chrono::{DateTime, Utc};
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum InventoryState {
    Received,
    Inspected,
    Available,
    Allocated,
    Picked,
    Packed,
    Staged,
    Loaded,
    Shipped,
    Quarantined,
    Damaged,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InventoryUnit {
    pub id: Uuid,
    pub sku: String,
    pub lot_number: String,
    pub serial_number: Option<String>,
    pub pallet_id: String,
    pub location_id: Option<Uuid>,
    pub quantity: u32,
    pub state: InventoryState,
    pub origin_supplier_id: Option<Uuid>,
    pub current_custodian_id: Option<Uuid>,
    pub latest_event_hash: String,
    pub updated_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum RobotStatus {
    Idle,
    Assigned,
    Transit,
    Picking,
    Delivering,
    Charging,
    MaintenanceRequired,
    OutOfService,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum RobotType {
    Amr,
    Agv,
    RoboticArm,
    PalletShuttle,
    Forklift,
    AsrsCrane,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Robot {
    pub id: Uuid,
    pub robot_code: String,
    pub robot_type: RobotType,
    pub manufacturer: String,
    pub model: String,
    pub serial_number: String,
    pub current_warehouse_id: Uuid,
    pub status: RobotStatus,
    pub battery_soc_percent: f64,
    pub operating_hours: f64,
    pub firmware_version: String,
    pub public_key: String,
    pub current_position: (f64, f64),
    pub created_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Asset {
    pub id: Uuid,
    pub asset_tag: String,
    pub asset_type: String,
    pub warehouse_id: Uuid,
    pub model: String,
    pub manufacturer: String,
    pub commissioned_date: String,
    pub operating_hours: f64,
    pub health_index_score: f64,
    pub is_active: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MaintenanceRecord {
    pub id: Uuid,
    pub asset_id: Uuid,
    pub fault_description: String,
    pub diagnosis_category: String,
    pub corrective_action: String,
    pub technician_id: String,
    pub parts_consumed: Vec<String>,
    pub direct_cost_usd: f64,
    pub downtime_minutes: f64,
    pub safety_inspection_passed: bool,
    pub certification_signature: String,
    pub created_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MerkleBatchRecord {
    pub id: Uuid,
    pub batch_seq_num: u64,
    pub event_count: usize,
    pub merkle_root: String,
    pub batch_hash: String,
    pub blockchain_tx_hash: Option<String>,
    pub block_number: Option<u64>,
    pub status: String,
    pub committed_at: Option<DateTime<Utc>>,
}
