use sha2::{Sha256, Digest};
use ed25519_dalek::{Signer, SigningKey, VerifyingKey, Signature, Verifier};
use rand::rngs::OsRng;
use serde::{Serialize, Deserialize};
use crate::errors::{WarehouseError, Result};

pub fn sha256_hex(data: &[u8]) -> String {
    let mut hasher = Sha256::new();
    hasher.update(data);
    hex::encode(hasher.finalize())
}

mod hex {
    pub fn encode(bytes: impl AsRef<[u8]>) -> String {
        bytes.as_ref().iter().map(|b| format!("{:02x}", b)).collect()
    }

    pub fn decode(hex_str: &str) -> std::result::Result<Vec<u8>, ()> {
        if hex_str.len() % 2 != 0 {
            return Err(());
        }
        (0..hex_str.len())
            .step_by(2)
            .map(|i| u8::from_str_radix(&hex_str[i..i + 2], 16).map_err(|_| ()))
            .collect()
    }
}

pub struct KeyPair {
    pub signing_key: SigningKey,
    pub verifying_key: VerifyingKey,
}

pub fn generate_machine_keypair() -> KeyPair {
    let mut csprng = OsRng;
    let signing_key = SigningKey::generate(&mut csprng);
    let verifying_key = signing_key.verifying_key();
    KeyPair { signing_key, verifying_key }
}

pub fn sign_message(signing_key: &SigningKey, message: &[u8]) -> String {
    let signature = signing_key.sign(message);
    hex::encode(signature.to_bytes())
}

pub fn verify_signature(public_key_hex: &str, message: &[u8], signature_hex: &str) -> Result<bool> {
    let pk_bytes = hex::decode(public_key_hex).map_err(|_| WarehouseError::InvalidSignature("Invalid public key hex".into()))?;
    let sig_bytes = hex::decode(signature_hex).map_err(|_| WarehouseError::InvalidSignature("Invalid signature hex".into()))?;

    if pk_bytes.len() != 32 || sig_bytes.len() != 64 {
        return Ok(false);
    }

    let mut pk_arr = [0u8; 32];
    pk_arr.copy_from_slice(&pk_bytes);
    let verifying_key = VerifyingKey::from_bytes(&pk_arr)
        .map_err(|_| WarehouseError::InvalidSignature("Failed to parse public key".into()))?;

    let mut sig_arr = [0u8; 64];
    sig_arr.copy_from_slice(&sig_bytes);
    let signature = Signature::from_bytes(&sig_arr);

    Ok(verifying_key.verify(message, &signature).is_ok())
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MerkleProof {
    pub leaf_hash: String,
    pub path: Vec<MerkleProofStep>,
    pub root_hash: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MerkleProofStep {
    pub hash: String,
    pub is_left: bool,
}

pub struct MerkleTree {
    pub leaves: Vec<String>,
    pub layers: Vec<Vec<String>>,
}

impl MerkleTree {
    pub fn new(leaves: Vec<String>) -> Self {
        if leaves.is_empty() {
            let empty_root = sha256_hex(b"EMPTY_INDUSTRIAL_BATCH");
            return Self {
                leaves: vec![],
                layers: vec![vec![empty_root]],
            };
        }

        let mut current_layer = leaves.clone();
        let mut layers = vec![current_layer.clone()];

        while current_layer.len() > 1 {
            let mut next_layer = Vec::new();
            for chunk in current_layer.chunks(2) {
                if chunk.len() == 2 {
                    let combined = format!("{}{}", chunk[0], chunk[1]);
                    next_layer.push(sha256_hex(combined.as_bytes()));
                } else {
                    // Duplicate last odd leaf
                    let combined = format!("{}{}", chunk[0], chunk[0]);
                    next_layer.push(sha256_hex(combined.as_bytes()));
                }
            }
            layers.push(next_layer.clone());
            current_layer = next_layer;
        }

        Self { leaves, layers }
    }

    pub fn root(&self) -> String {
        self.layers.last().and_then(|l| l.first()).cloned().unwrap_or_else(|| sha256_hex(b""))
    }

    pub fn generate_proof(&self, leaf_index: usize) -> Option<MerkleProof> {
        if leaf_index >= self.leaves.len() {
            return None;
        }

        let mut path = Vec::new();
        let mut idx = leaf_index;

        for layer in &self.layers[0..self.layers.len() - 1] {
            let pair_idx = if idx % 2 == 0 { idx + 1 } else { idx - 1 };
            if pair_idx < layer.len() {
                path.push(MerkleProofStep {
                    hash: layer[pair_idx].clone(),
                    is_left: idx % 2 != 0,
                });
            } else {
                path.push(MerkleProofStep {
                    hash: layer[idx].clone(),
                    is_left: false,
                });
            }
            idx /= 2;
        }

        Some(MerkleProof {
            leaf_hash: self.leaves[leaf_index].clone(),
            path,
            root_hash: self.root(),
        })
    }

    pub fn verify_proof(proof: &MerkleProof) -> bool {
        let mut current = proof.leaf_hash.clone();
        for step in &proof.path {
            let combined = if step.is_left {
                format!("{}{}", step.hash, current)
            } else {
                format!("{}{}", current, step.hash)
            };
            current = sha256_hex(combined.as_bytes());
        }
        current == proof.root_hash
    }
}
