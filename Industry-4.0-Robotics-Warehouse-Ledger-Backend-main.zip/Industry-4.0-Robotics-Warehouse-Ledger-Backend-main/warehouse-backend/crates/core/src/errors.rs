use thiserror::Error;

#[derive(Error, Debug)]
pub enum WarehouseError {
    #[error("Cryptographic signature verification failed for identity {0}")]
    InvalidSignature(String),

    #[error("Double-entry ledger invariant violation: {0}")]
    LedgerInvariantViolation(String),

    #[error("Invalid inventory state transition from {from} to {to} for unit {unit_id}")]
    InvalidStateTransition {
        unit_id: String,
        from: String,
        to: String,
    },

    #[error("Asset {asset_id} requires immediate maintenance: {reason}")]
    AssetMaintenanceRequired {
        asset_id: String,
        reason: String,
    },

    #[error("Robot {robot_id} battery level ({soc_percent}%) below critical mission threshold")]
    LowBattery {
        robot_id: String,
        soc_percent: f64,
    },

    #[error("Merkle inclusion proof failed for event {event_id}")]
    MerkleProofInvalid(String),

    #[error("Storage repository error: {0}")]
    StorageError(String),

    #[error("R Analytics IPC error: {0}")]
    AnalyticsError(String),

    #[error("Serialization error: {0}")]
    SerializationError(#[from] serde_json::Error),

    #[error("Unknown error: {0}")]
    Unknown(String),
}

pub type Result<T> = std::result::Result<T, WarehouseError>;
