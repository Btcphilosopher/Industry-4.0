use serde_json::Value;
use crate::crypto::sha256_hex;

pub fn canonicalize_event(event_type: &str, stream_id: &str, version: u64, payload: &Value, prev_hash: &str) -> (String, String) {
    let canonical_json = serde_json::json!({
        "event_type": event_type,
        "stream_id": stream_id,
        "version": version,
        "payload": payload,
        "prev_hash": prev_hash,
    });
    let serialized = serde_json::to_string(&canonical_json).unwrap_or_default();
    let hash = sha256_hex(serialized.as_bytes());
    (serialized, hash)
}
