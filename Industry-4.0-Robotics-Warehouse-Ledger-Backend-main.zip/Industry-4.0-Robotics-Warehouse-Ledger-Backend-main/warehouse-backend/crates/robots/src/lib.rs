use warehouse_core::{WarehouseError, Result, sha256_hex, canonicalize_event};
use warehouse_domain::{Robot, RobotStatus};
use uuid::Uuid;

pub struct FleetManager;

impl FleetManager {
    pub fn dispatch_task(robot: &mut Robot, mission_type: &str, target_x: f64, target_y: f64) -> Result<String> {
        if robot.battery_soc_percent < 15.0 {
            return Err(WarehouseError::LowBattery {
                robot_id: robot.robot_code.clone(),
                soc_percent: robot.battery_soc_percent,
            });
        }

        robot.status = RobotStatus::Assigned;
        let payload = serde_json::json!({
            "robot_code": robot.robot_code,
            "mission_type": mission_type,
            "target": [target_x, target_y],
            "battery_soc": robot.battery_soc_percent,
            "operating_hours": robot.operating_hours
        });

        let (_, event_hash) = canonicalize_event("MISSION_DISPATCHED", &format!("robot:{}", robot.id), 1, &payload, "GENESIS");
        Ok(event_hash)
    }

    pub fn complete_task(robot: &mut Robot, distance_traveled_meters: f64, energy_kwh: f64) -> String {
        robot.status = RobotStatus::Idle;
        robot.operating_hours += distance_traveled_meters / 1000.0 / 1.5; // ~1.5 m/s avg speed
        robot.battery_soc_percent = (robot.battery_soc_percent - (energy_kwh / 1.8 * 100.0)).max(5.0);

        let payload = serde_json::json!({
            "robot_code": robot.robot_code,
            "distance_m": distance_traveled_meters,
            "energy_kwh": energy_kwh,
            "new_soc": robot.battery_soc_percent,
            "total_hours": robot.operating_hours
        });

        let (_, hash) = canonicalize_event("MISSION_COMPLETED", &format!("robot:{}", robot.id), 2, &payload, "PREV_TASK_HASH");
        hash
    }
}
