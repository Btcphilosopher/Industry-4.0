use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MarginalOrderCost {
    pub order_id: String,
    pub pick_labor_cost: f64,
    pub robot_energy_cost: f64,
    pub robot_amortization_cost: f64,
    pub packaging_material_cost: f64,
    pub conveyor_transit_cost: f64,
    pub congestion_premium: f64,
    pub total_marginal_cost_usd: f64,
}

pub struct EconomicEngine;

impl EconomicEngine {
    pub fn calculate_order_cost(
        order_id: &str,
        picks_count: u32,
        amr_travel_distance_meters: f64,
        energy_kwh: f64,
        tariff_usd_kwh: f64,
        congestion_index: f64,
    ) -> MarginalOrderCost {
        let pick_labor = (picks_count as f64) * 0.42; // $0.42 per line
        let robot_energy = energy_kwh * tariff_usd_kwh;
        let robot_amort = (amr_travel_distance_meters / 1000.0) * 0.15; // $0.15 per km traveled
        let packaging = 1.25 + (picks_count as f64 * 0.10);
        let conveyor = 0.35;
        let congestion = if congestion_index > 0.70 { (congestion_index - 0.70) * 1.50 } else { 0.0 };

        let total = pick_labor + robot_energy + robot_amort + packaging + conveyor + congestion;

        MarginalOrderCost {
            order_id: order_id.to_string(),
            pick_labor_cost: round_2(pick_labor),
            robot_energy_cost: round_2(robot_energy),
            robot_amortization_cost: round_2(robot_amort),
            packaging_material_cost: round_2(packaging),
            conveyor_transit_cost: round_2(conveyor),
            congestion_premium: round_2(congestion),
            total_marginal_cost_usd: round_2(total),
        }
    }
}

fn round_2(val: f64) -> f64 {
    (val * 100.0).round() / 100.0
}
