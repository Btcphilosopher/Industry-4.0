/**
 * TerraForge Industrial AgriTech Operating System
 * Main Enterprise Application Container
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/layout/Header';
import { Sidebar, NavTabId } from './components/layout/Sidebar';
import { NationalCommandView } from './components/views/NationalCommandView';
import { VerticalHydroponicsView } from './components/views/VerticalHydroponicsView';
import { CeaEnergyGridView } from './components/views/CeaEnergyGridView';
import { ClosedLoopWaterView } from './components/views/ClosedLoopWaterView';
import { RoboticsMachineryView } from './components/views/RoboticsMachineryView';
import { RStatisticalLabView } from './components/views/RStatisticalLabView';
import { ProductionSupplyChainView } from './components/views/ProductionSupplyChainView';
import { EconomicsInvestmentView } from './components/views/EconomicsInvestmentView';
import { RustRealtimeEdgeView } from './components/views/RustRealtimeEdgeView';
import { AgronomicCopilotView } from './components/views/AgronomicCopilotView';

import { INITIAL_FACILITIES } from './data/nationalNetwork';
import { generateLiveRustTelemetryLogs } from './data/rustEngineSimulation';
import { Facility, RustActorTelemetryEvent } from './types/agritech';

export default function App() {
  const [facilities, setFacilities] = useState<Facility[]>(INITIAL_FACILITIES);
  const [selectedFacilityId, setSelectedFacilityId] = useState<string>('TF-CA-01');
  const [activeTab, setActiveTab] = useState<NavTabId>('NATIONAL_COMMAND');
  const [isSimulating, setIsSimulating] = useState<boolean>(true);
  const [simSpeed, setSimSpeed] = useState<number>(1);
  const [telemetryTickCount, setTelemetryTickCount] = useState<number>(0);
  const [telemetryLogs, setTelemetryLogs] = useState<RustActorTelemetryEvent[]>(() => generateLiveRustTelemetryLogs());

  // Real-time telemetry tick loop (simulating live 100Hz edge telemetry & ISO spot price updates)
  useEffect(() => {
    if (!isSimulating) return;

    const intervalMs = Math.max(200, 2000 / simSpeed);
    const timer = setInterval(() => {
      setTelemetryTickCount(prev => prev + 1);

      // Micro-jitter to simulate real-world physical dynamics
      setFacilities(prevFacilities => {
        return prevFacilities.map(fac => {
          const jitterTemp = (Math.random() - 0.5) * 0.08;
          const jitterRh = (Math.random() - 0.5) * 0.2;
          const jitterPrice = (Math.random() - 0.5) * 0.8;

          const updatedModules = fac.growingModules.map(mod => ({
            ...mod,
            temperatureC: parseFloat((mod.temperatureC + jitterTemp).toFixed(2)),
            humidityPct: parseFloat(Math.min(90, Math.max(40, mod.humidityPct + jitterRh)).toFixed(1))
          }));

          const updatedEnergy = {
            ...fac.energySystem,
            spotPriceMwh: parseFloat(Math.max(12, fac.energySystem.spotPriceMwh + jitterPrice).toFixed(2))
          };

          return {
            ...fac,
            growingModules: updatedModules,
            energySystem: updatedEnergy
          };
        });
      });

      // Update live Rust telemetry event logs
      if (Math.random() > 0.4) {
        setTelemetryLogs(generateLiveRustTelemetryLogs());
      }
    }, intervalMs);

    return () => clearInterval(timer);
  }, [isSimulating, simSpeed]);

  const activeAlarmsCount = facilities.reduce((sum, f) => {
    return sum + f.growingModules.reduce((mSum, m) => mSum + m.activeAlarms.length, 0);
  }, 0);

  return (
    <div className="min-h-screen bg-[#08090b] text-[#e0e0e0] flex flex-col font-sans selection:bg-[#00ff66] selection:text-black">
      {/* Industrial Header & Real-time ISO Wholesale Ticker */}
      <Header
        facilities={facilities}
        selectedFacilityId={selectedFacilityId}
        onSelectFacility={(id) => setSelectedFacilityId(id)}
        isSimulating={isSimulating}
        onToggleSimulate={() => setIsSimulating(!isSimulating)}
        simSpeed={simSpeed}
        onChangeSimSpeed={(s) => setSimSpeed(s)}
        telemetryTickCount={telemetryTickCount}
      />

      {/* Main Workspace: Sidebar + Specialized View Container */}
      <div className="flex-1 flex overflow-hidden">
        {/* Navigation Sidebar */}
        <Sidebar
          activeTab={activeTab}
          onSelectTab={(tab) => setActiveTab(tab)}
          activeAlarmsCount={activeAlarmsCount}
        />

        {/* View Surface */}
        <main className="flex-1 overflow-y-auto bg-[radial-gradient(circle_at_top_right,_#121418,_#08090b)] p-2">
          {activeTab === 'NATIONAL_COMMAND' && (
            <NationalCommandView
              facilities={facilities}
              onSelectFacility={(id) => setSelectedFacilityId(id)}
              onNavigateTab={(tab) => setActiveTab(tab)}
            />
          )}

          {activeTab === 'VERTICAL_HYDROPONICS' && (
            <VerticalHydroponicsView
              facilities={facilities}
              selectedFacilityId={selectedFacilityId}
              onSelectFacility={(id) => setSelectedFacilityId(id)}
            />
          )}

          {activeTab === 'CEA_ENERGY_GRID' && (
            <CeaEnergyGridView
              facilities={facilities}
              selectedFacilityId={selectedFacilityId}
              onSelectFacility={(id) => setSelectedFacilityId(id)}
            />
          )}

          {activeTab === 'CLOSED_LOOP_WATER' && (
            <ClosedLoopWaterView
              facilities={facilities}
              selectedFacilityId={selectedFacilityId}
              onSelectFacility={(id) => setSelectedFacilityId(id)}
            />
          )}

          {activeTab === 'ROBOTICS_MACHINERY' && (
            <RoboticsMachineryView
              facilities={facilities}
              selectedFacilityId={selectedFacilityId}
              onSelectFacility={(id) => setSelectedFacilityId(id)}
            />
          )}

          {activeTab === 'R_STATISTICAL_LAB' && (
            <RStatisticalLabView />
          )}

          {activeTab === 'PRODUCTION_SUPPLY_CHAIN' && (
            <ProductionSupplyChainView
              facilities={facilities}
            />
          )}

          {activeTab === 'ECONOMICS_INVESTMENT' && (
            <EconomicsInvestmentView />
          )}

          {activeTab === 'RUST_REALTIME_EDGE' && (
            <RustRealtimeEdgeView
              telemetryLogs={telemetryLogs}
            />
          )}

          {activeTab === 'AGRONOMIC_COPILOT' && (
            <AgronomicCopilotView
              facilities={facilities}
              selectedFacilityId={selectedFacilityId}
            />
          )}
        </main>
      </div>
    </div>
  );
}
