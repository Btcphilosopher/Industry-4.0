/**
 * TerraForge R Statistical & Agricultural Science Computational Engine
 * Implements Biometric Response Surfaces, Monte Carlo Risk, ANOVA Trials,
 * Psychrometric VPD Models, Greenfield Siting & Economies-of-Scale Dynamics.
 */

import { ExperimentTrial, MonteCarloRiskResult, SitingLocationCandidate } from '../types/agritech';

/**
 * Calculates psychrometric Vapor Pressure Deficit (VPD) in kPa
 * Formula: VPD = SVP * (1 - RH/100)
 * where SVP = 0.61078 * exp((17.27 * T) / (T + 237.3))
 */
export function calculateVpd(tempC: number, relativeHumidityPct: number): {
  vpdKpa: number;
  svpKpa: number;
  avpKpa: number;
  transpirationStressIndex: 'OPTIMAL' | 'LOW_TRANSPIRATION' | 'EXCESSIVE_TRANSPIRATION_STRESS';
} {
  const svpKpa = 0.61078 * Math.exp((17.27 * tempC) / (tempC + 237.3));
  const avpKpa = svpKpa * (relativeHumidityPct / 100);
  const vpdKpa = Math.max(0.1, svpKpa - avpKpa);

  let transpirationStressIndex: 'OPTIMAL' | 'LOW_TRANSPIRATION' | 'EXCESSIVE_TRANSPIRATION_STRESS' = 'OPTIMAL';
  if (vpdKpa < 0.8) {
    transpirationStressIndex = 'LOW_TRANSPIRATION'; // risk of guttation, calcium tipburn
  } else if (vpdKpa > 1.45) {
    transpirationStressIndex = 'EXCESSIVE_TRANSPIRATION_STRESS'; // stomatal closure
  }

  return {
    vpdKpa: parseFloat(vpdKpa.toFixed(2)),
    svpKpa: parseFloat(svpKpa.toFixed(3)),
    avpKpa: parseFloat(avpKpa.toFixed(3)),
    transpirationStressIndex
  };
}

/**
 * Non-linear agronomic yield response model
 * Multi-variable physiological equation: Yield = BaseYield * f(DLI) * f(VPD) * f(CO2) * f(EC) * f(Temp)
 */
export function calculateAgronomicYieldPrediction(params: {
  dliMolM2Day: number;
  targetDli: number;
  vpdKpa: number;
  idealVpdKpa: [number, number];
  co2Ppm: number;
  idealCo2Ppm: number;
  ecMscm: number;
  idealEc: [number, number];
  tempC: number;
  idealTempC: [number, number];
  baseYieldKgM2: number;
}): {
  predictedYieldKgM2: number;
  limitingFactor: string;
  efficiencyPct: number;
  dliMultiplier: number;
  vpdMultiplier: number;
  co2Multiplier: number;
  ecMultiplier: number;
  tempMultiplier: number;
} {
  // DLI asymptotic response (Michaelis-Menten style saturation)
  const dliRatio = params.dliMolM2Day / params.targetDli;
  const dliMultiplier = Math.min(1.15, Math.max(0.4, (2.2 * dliRatio) / (1 + 1.2 * dliRatio)));

  // VPD bell-curve penalty
  const vpdMid = (params.idealVpdKpa[0] + params.idealVpdKpa[1]) / 2;
  const vpdDev = Math.abs(params.vpdKpa - vpdMid);
  const vpdMultiplier = Math.max(0.6, 1.0 - (vpdDev * vpdDev * 0.45));

  // CO2 logarithmic enhancement (Farquhar-von Caemmerer-Berry photosynthetic curve)
  const co2Ratio = params.co2Ppm / params.idealCo2Ppm;
  const co2Multiplier = Math.min(1.22, Math.max(0.65, 0.85 + 0.35 * Math.log10(co2Ratio + 0.1)));

  // EC osmotic pressure window
  const ecMid = (params.idealEc[0] + params.idealEc[1]) / 2;
  const ecDev = Math.abs(params.ecMscm - ecMid);
  const ecMultiplier = Math.max(0.5, 1.0 - (ecDev * 0.25));

  // Temperature Growing Degree factor
  const tempMid = (params.idealTempC[0] + params.idealTempC[1]) / 2;
  const tempDev = Math.abs(params.tempC - tempMid);
  const tempMultiplier = Math.max(0.55, 1.0 - (tempDev * 0.05));

  // Find limiting factor
  const factors = [
    { name: 'Lighting DLI', val: dliMultiplier },
    { name: 'Vapor Pressure Deficit (VPD)', val: vpdMultiplier },
    { name: 'CO₂ Atmospheric Enrichment', val: co2Multiplier },
    { name: 'Nutrient Electrical Conductivity (EC)', val: ecMultiplier },
    { name: 'Air Temperature & GDD', val: tempMultiplier }
  ];
  factors.sort((a, b) => a.val - b.val);

  const combinedMultiplier = dliMultiplier * vpdMultiplier * co2Multiplier * ecMultiplier * tempMultiplier;
  const predictedYieldKgM2 = parseFloat((params.baseYieldKgM2 * combinedMultiplier).toFixed(2));
  const efficiencyPct = parseFloat((combinedMultiplier * 100).toFixed(1));

  return {
    predictedYieldKgM2,
    limitingFactor: factors[0].name,
    efficiencyPct,
    dliMultiplier: parseFloat(dliMultiplier.toFixed(2)),
    vpdMultiplier: parseFloat(vpdMultiplier.toFixed(2)),
    co2Multiplier: parseFloat(co2Multiplier.toFixed(2)),
    ecMultiplier: parseFloat(ecMultiplier.toFixed(2)),
    tempMultiplier: parseFloat(tempMultiplier.toFixed(2))
  };
}

/**
 * Monte Carlo Risk Engine
 * Runs 5,000 statistical iterations with correlated stochastic variations:
 * - Electricity price shocks ($/MWh lognormal)
 * - Yield volatility (beta distribution)
 * - Water tariff shocks
 * - Spoilage & transport disruption
 */
export function runMonteCarloSimulation(
  baseValue: number,
  volatilityStdDevPct: number,
  metricName: string,
  unit: string,
  iterations = 5000
): MonteCarloRiskResult {
  const values: number[] = [];

  // Box-Muller transformation for normal random variates
  for (let i = 0; i < iterations; i++) {
    const u1 = Math.max(1e-7, Math.random());
    const u2 = Math.random();
    const z0 = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
    
    // Add skewed tail risk for extreme agricultural/energy shocks
    const tailShock = (Math.random() < 0.04) ? (Math.random() * -0.22) : 0;
    const simulatedVal = baseValue * (1 + (z0 * (volatilityStdDevPct / 100)) + tailShock);
    values.push(simulatedVal);
  }

  values.sort((a, b) => a - b);

  const p10Index = Math.floor(iterations * 0.10);
  const p50Index = Math.floor(iterations * 0.50);
  const p90Index = Math.floor(iterations * 0.90);

  const p10 = parseFloat(values[p10Index].toFixed(2));
  const p50 = parseFloat(values[p50Index].toFixed(2));
  const p90 = parseFloat(values[p90Index].toFixed(2));

  // Compute mean and standard deviation
  const mean = values.reduce((sum, v) => sum + v, 0) / iterations;
  const variance = values.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / iterations;
  const standardDeviation = parseFloat(Math.sqrt(variance).toFixed(2));

  const lossCount = values.filter(v => v < (baseValue * 0.85)).length;
  const riskOfLossPct = parseFloat(((lossCount / iterations) * 100).toFixed(1));

  // Build 15-bucket histogram for chart display
  const minVal = values[0];
  const maxVal = values[values.length - 1];
  const bucketWidth = (maxVal - minVal) / 14;
  const histogram: { bin: number; frequency: number; cumulativePct: number }[] = [];

  let cumulativeCount = 0;
  for (let b = 0; b < 15; b++) {
    const lower = minVal + b * bucketWidth;
    const upper = lower + bucketWidth;
    const count = values.filter(v => v >= lower && (b === 14 ? v <= upper : v < upper)).length;
    cumulativeCount += count;
    histogram.push({
      bin: parseFloat((lower + bucketWidth / 2).toFixed(1)),
      frequency: count,
      cumulativePct: parseFloat(((cumulativeCount / iterations) * 100).toFixed(1))
    });
  }

  return {
    simulationsRun: iterations,
    metricName,
    unit,
    p10,
    p50,
    p90,
    standardDeviation,
    riskOfLossPct,
    histogram
  };
}

/**
 * Agricultural R&D Experimentation Trials Database & Statistical ANOVA Engine
 */
export const R_AND_D_TRIALS: ExperimentTrial[] = [
  {
    id: 'EXP-2026-FR04',
    trialName: 'Far-Red (730nm) End-of-Day Photoperiod Extension on Genovese Basil',
    cultivar: 'Prospera Genovese Basil',
    variableTested: 'SPECTRAL_FAR_RED',
    sampleSizeN: 1440,
    controlSpec: {
      description: 'Standard 450nm:660nm (1:4) spectrum at 300 µmol/m²/s for 18h',
      meanYieldGramsPerPlant: 188.4,
      sdGrams: 14.2,
      meanBrix: 6.2,
      energyKwhPerKg: 4.45
    },
    treatmentSpec: {
      description: 'Standard + 35 µmol/m²/s 730nm Far-Red pulse 30min pre-lights-off',
      meanYieldGramsPerPlant: 218.6,
      sdGrams: 15.8,
      meanBrix: 6.7,
      energyKwhPerKg: 4.12
    },
    effectSizeCohenD: 2.01,
    pValue: 0.0001,
    confidenceInterval95: [28.6, 31.8],
    yieldDeltaPct: 16.03,
    annualizedEbitdaImpactUsdPerM2: 44.80,
    recommendation: 'DEPLOY_NETWORK_WIDE'
  },
  {
    id: 'EXP-2026-CO12',
    trialName: 'Dynamic CO₂ Elevation (1400 ppm) Coincident with Solar Peak in CEA Greenhouses',
    cultivar: 'Campari Cluster Tomato',
    variableTested: 'CO2_CONCENTRATION',
    sampleSizeN: 720,
    controlSpec: {
      description: 'Static 800 ppm baseline enrichment',
      meanYieldGramsPerPlant: 1320.0,
      sdGrams: 110.0,
      meanBrix: 6.9,
      energyKwhPerKg: 1.95
    },
    treatmentSpec: {
      description: 'Ramped 1400 ppm enrichment during 10:00-15:00 natural sunlight peak',
      meanYieldGramsPerPlant: 1518.0,
      sdGrams: 118.0,
      meanBrix: 7.5,
      energyKwhPerKg: 1.72
    },
    effectSizeCohenD: 1.73,
    pValue: 0.0002,
    confidenceInterval95: [182.0, 214.0],
    yieldDeltaPct: 15.00,
    annualizedEbitdaImpactUsdPerM2: 38.50,
    recommendation: 'DEPLOY_NETWORK_WIDE'
  },
  {
    id: 'EXP-2026-NUT09',
    trialName: 'K:Ca Cation Molar Ratio Modification for Tipburn Suppression in Butterhead',
    cultivar: 'Rex Butterhead Lettuce',
    variableTested: 'NUTRIENT_K_CA_RATIO',
    sampleSizeN: 2160,
    controlSpec: {
      description: 'Standard K:Ca 1.2:1 molar ratio (180ppm K, 150ppm Ca)',
      meanYieldGramsPerPlant: 195.0,
      sdGrams: 18.0,
      meanBrix: 4.6,
      energyKwhPerKg: 2.30
    },
    treatmentSpec: {
      description: 'Modified Steiner K:Ca 0.95:1 with micro-pulsed foliar surfactant Ca-chelate',
      meanYieldGramsPerPlant: 209.5,
      sdGrams: 12.0,
      meanBrix: 4.9,
      energyKwhPerKg: 2.18
    },
    effectSizeCohenD: 0.94,
    pValue: 0.0018,
    confidenceInterval95: [12.8, 16.2],
    yieldDeltaPct: 7.44,
    annualizedEbitdaImpactUsdPerM2: 21.60,
    recommendation: 'DEPLOY_NETWORK_WIDE'
  },
  {
    id: 'EXP-2026-DEN03',
    trialName: 'High-Density Gantry Seeding (36 vs 28 plants/m²) in Multitier Racks',
    cultivar: 'Seaside Baby Spinach',
    variableTested: 'PLANTING_DENSITY',
    sampleSizeN: 1800,
    controlSpec: {
      description: 'Standard density 28 plants/m²',
      meanYieldGramsPerPlant: 95.0,
      sdGrams: 8.5,
      meanBrix: 5.1,
      energyKwhPerKg: 2.70
    },
    treatmentSpec: {
      description: 'Elevated density 36 plants/m² with increased under-canopy airflow',
      meanYieldGramsPerPlant: 88.2,
      sdGrams: 9.8,
      meanBrix: 4.9,
      energyKwhPerKg: 2.45
    },
    effectSizeCohenD: 0.74,
    pValue: 0.008,
    confidenceInterval95: [16.5, 22.8],
    yieldDeltaPct: 19.40, // Net biomass per m2 goes up from 2.66 kg/m2 to 3.17 kg/m2
    annualizedEbitdaImpactUsdPerM2: 52.10,
    recommendation: 'DEPLOY_NETWORK_WIDE'
  }
];

/**
 * Greenfield Siting Candidates & Investment Model
 */
export const GREENFIELD_SITING_CANDIDATES: SitingLocationCandidate[] = [
  {
    id: 'SITE-OH-COL',
    cityState: 'Columbus, Ohio',
    region: 'PENNSYLVANIA',
    electricityRateCentsKwh: 5.4,
    renewableGridPct: 42,
    waterCostPer1000GalUsd: 3.20,
    waterStressScore: 2,
    labourRateHourlyUsd: 18.50,
    landCostPerAcreUsd: 48000,
    constructionCostIndex: 94,
    freightDistanceToMajorHubKm: 180, // Within 1-day drive of 50% of US population
    stateTaxIncentiveScore: 88,
    projectedCapexMillionUsd: 44.5,
    projectedNpvMillionUsd: 38.2,
    projectedIrrPct: 24.8,
    paybackYears: 3.8,
    riskScore: 16,
    compositeRank: 1
  },
  {
    id: 'SITE-GA-ATL',
    cityState: 'Atlanta, Georgia (I-85 Corridor)',
    region: 'NORTH_CAROLINA',
    electricityRateCentsKwh: 6.1,
    renewableGridPct: 38,
    waterCostPer1000GalUsd: 3.80,
    waterStressScore: 3,
    labourRateHourlyUsd: 19.20,
    landCostPerAcreUsd: 65000,
    constructionCostIndex: 96,
    freightDistanceToMajorHubKm: 210,
    stateTaxIncentiveScore: 85,
    projectedCapexMillionUsd: 46.0,
    projectedNpvMillionUsd: 34.6,
    projectedIrrPct: 22.9,
    paybackYears: 4.1,
    riskScore: 19,
    compositeRank: 2
  },
  {
    id: 'SITE-NV-RNO',
    cityState: 'Reno, Nevada (Tahoe-Reno Industrial Hub)',
    region: 'CALIFORNIA',
    electricityRateCentsKwh: 4.9,
    renewableGridPct: 65, // Geothermal & Solar
    waterCostPer1000GalUsd: 5.40,
    waterStressScore: 7,
    labourRateHourlyUsd: 21.00,
    landCostPerAcreUsd: 82000,
    constructionCostIndex: 104,
    freightDistanceToMajorHubKm: 340, // Serves Bay Area / NorCal
    stateTaxIncentiveScore: 92, // No corporate income tax
    projectedCapexMillionUsd: 49.5,
    projectedNpvMillionUsd: 31.8,
    projectedIrrPct: 21.4,
    paybackYears: 4.4,
    riskScore: 24,
    compositeRank: 3
  },
  {
    id: 'SITE-TX-SAN',
    cityState: 'San Antonio, Texas (ERCOT South)',
    region: 'TEXAS',
    electricityRateCentsKwh: 5.2,
    renewableGridPct: 48,
    waterCostPer1000GalUsd: 4.10,
    waterStressScore: 5,
    labourRateHourlyUsd: 17.80,
    landCostPerAcreUsd: 52000,
    constructionCostIndex: 92,
    freightDistanceToMajorHubKm: 290,
    stateTaxIncentiveScore: 90,
    projectedCapexMillionUsd: 43.0,
    projectedNpvMillionUsd: 32.5,
    projectedIrrPct: 22.1,
    paybackYears: 4.2,
    riskScore: 21,
    compositeRank: 4
  },
  {
    id: 'SITE-CO-DEN',
    cityState: 'Denver Front Range, Colorado',
    region: 'IOWA',
    electricityRateCentsKwh: 6.8,
    renewableGridPct: 52,
    waterCostPer1000GalUsd: 4.90,
    waterStressScore: 6,
    labourRateHourlyUsd: 23.50,
    landCostPerAcreUsd: 95000,
    constructionCostIndex: 108,
    freightDistanceToMajorHubKm: 420,
    stateTaxIncentiveScore: 72,
    projectedCapexMillionUsd: 53.0,
    projectedNpvMillionUsd: 22.4,
    projectedIrrPct: 17.6,
    paybackYears: 5.2,
    riskScore: 32,
    compositeRank: 5
  }
];

/**
 * Economies of Scale Scaling Curve Generator (1, 5, 10, 50, 100 Farms)
 */
export function generateEconomiesOfScaleData() {
  const farmScalePoints = [1, 5, 10, 25, 50, 100];

  return farmScalePoints.map(numFarms => {
    // Learning curve and volume procurement effects
    const procurementDiscountFactor = Math.pow(numFarms, -0.16); // LED, seeds, nutrients
    const softwareAmortizationFactor = 1 / Math.pow(numFarms, 0.45);
    const logisticsEfficiencyGain = 1 - (0.35 * (1 - Math.exp(-numFarms / 18)));
    
    const capexPerSqM = 1150 * Math.pow(numFarms, -0.12);
    const opexPerKg = 2.85 * procurementDiscountFactor * logisticsEfficiencyGain;
    const totalNetworkOutputMtYear = numFarms * 8200;
    const totalRevenueMillionUsd = (totalNetworkOutputMtYear * 6.2) / 1000;
    const totalEbitdaMillionUsd = totalRevenueMillionUsd - ((totalNetworkOutputMtYear * opexPerKg) / 1000) - (12 * softwareAmortizationFactor);
    const ebitdaMarginPct = parseFloat(((totalEbitdaMillionUsd / totalRevenueMillionUsd) * 100).toFixed(1));

    return {
      numFarms,
      capexPerSqM: parseFloat(capexPerSqM.toFixed(0)),
      opexPerKgUsd: parseFloat(opexPerKg.toFixed(2)),
      totalNetworkOutputMtYear,
      totalRevenueMillionUsd: parseFloat(totalRevenueMillionUsd.toFixed(1)),
      totalEbitdaMillionUsd: parseFloat(totalEbitdaMillionUsd.toFixed(1)),
      ebitdaMarginPct,
      rdLeverageMultiplier: parseFloat((1 + Math.log10(numFarms) * 1.8).toFixed(2))
    };
  });
}

/**
 * Generate Light Response Yield vs DLI curve
 */
export function generateYieldVsDliCurve() {
  const dliPoints = [6, 10, 14, 18, 22, 26, 30, 34];
  return dliPoints.map(dli => {
    // Non-linear saturation curve
    const relativeFactor = (1.45 * dli) / (dli + 8.5);
    const yieldKgM2 = parseFloat((3.6 * relativeFactor).toFixed(2));
    const efficiencyPct = parseFloat((Math.min(100, (yieldKgM2 / 3.6) * 100)).toFixed(1));
    return {
      dli,
      yieldKgM2,
      efficiencyPct
    };
  });
}

