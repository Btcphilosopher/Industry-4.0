/**
 * TerraForge Rust Telemetry & Edge Automation Subsystem Emulation
 * Simulates 100Hz Actor-based Telemetry Workers, Fast PID Feedback Loops,
 * CAN Bus J1939 Decoders, Anomaly Detection & Machine Control Command Dispatch.
 */

import { RustActorTelemetryEvent } from '../types/agritech';

export interface PidLoopState {
  loopId: string;
  name: string;
  facilityId: string;
  setpoint: number;
  currentValue: number;
  error: number;
  kp: number;
  ki: number;
  kd: number;
  controlOutputPct: number;
  samplingIntervalMs: number;
  unit: string;
}

export interface CanBusPacket {
  canId: string; // e.g. 0x18FEE000 (J1939 Engine State)
  nodeName: string;
  payloadHex: string;
  decodedMetrics: Record<string, string | number>;
  timestampMicrosec: number;
  busUtilizationPct: number;
}

export interface PumpVibrationDiagnostic {
  pumpId: string;
  facilityId: string;
  rpm: number;
  rmsVelocityMmPerSec: number;
  peakAccelerationG: number;
  bearingHealthScorePct: number;
  dominantHarmonicHz: number;
  anomalyDetected: boolean;
  fftSpectrum: { freqHz: number; amplitudeDb: number }[];
}

export const INITIAL_PID_LOOPS: PidLoopState[] = [
  {
    loopId: 'PID-HVAC-TEMP-CA01',
    name: 'HVAC Supply Air Temperature Loop',
    facilityId: 'TF-CA-01',
    setpoint: 21.0,
    currentValue: 21.2,
    error: -0.2,
    kp: 18.5,
    ki: 2.4,
    kd: 4.1,
    controlOutputPct: 62.4,
    samplingIntervalMs: 10,
    unit: '°C'
  },
  {
    loopId: 'PID-DOSING-PH-CA01',
    name: 'Nutrient Batch A/B pH Acid Dosing Loop',
    facilityId: 'TF-CA-01',
    setpoint: 5.85,
    currentValue: 5.88,
    error: -0.03,
    kp: 42.0,
    ki: 6.8,
    kd: 8.5,
    controlOutputPct: 14.8,
    samplingIntervalMs: 20,
    unit: 'pH'
  },
  {
    loopId: 'PID-BESS-DISPATCH-TX01',
    name: 'BESS Microgrid Fast Peak Shaving Inverter Loop',
    facilityId: 'TF-TX-01',
    setpoint: 2.50, // MW discharge
    currentValue: 2.48,
    error: 0.02,
    kp: 85.0,
    ki: 12.0,
    kd: 1.5,
    controlOutputPct: 92.0,
    samplingIntervalMs: 5,
    unit: 'MW'
  },
  {
    loopId: 'PID-CO2-INJECTION-AZ01',
    name: 'High-Purity Liquid CO₂ Proportional Solenoid',
    facilityId: 'TF-AZ-01',
    setpoint: 1000,
    currentValue: 980,
    error: 20,
    kp: 0.85,
    ki: 0.12,
    kd: 0.05,
    controlOutputPct: 48.6,
    samplingIntervalMs: 50,
    unit: 'ppm'
  }
];

export const INITIAL_CAN_BUS_PACKETS: CanBusPacket[] = [
  {
    canId: '0x18FEE000',
    nodeName: 'Autonomous Tractor Alpha (Ames IA)',
    payloadHex: '8A 3F 02 E1 00 00 A4 7C',
    decodedMetrics: {
      engineRpm: 1850,
      torqueLoadPct: 68.4,
      coolantTempC: 84.5,
      fuelRateLph: 12.4
    },
    timestampMicrosec: 1723789842100,
    busUtilizationPct: 42.8
  },
  {
    canId: '0x18FEDF00',
    nodeName: 'RTK Steering Controller (J1939)',
    payloadHex: '01 24 5E 00 00 12 8A 00',
    decodedMetrics: {
      steeringAngleDeg: -1.24,
      crossTrackErrorCm: 0.82,
      rtkFixQuality: 'RTK_FIXED_DUAL_FREQUENCY',
      satellitesLocked: 28
    },
    timestampMicrosec: 1723789842120,
    busUtilizationPct: 43.1
  },
  {
    canId: '0x18FF4201',
    nodeName: 'Gantry Seeder Axis 1 Servo Drive',
    payloadHex: '00 00 48 E2 01 9A 03 11',
    decodedMetrics: {
      posEncoderTicks: 142850,
      velocityMmSec: 850,
      motorCurrentAmps: 6.4,
      motorTempC: 38.2
    },
    timestampMicrosec: 1723789842150,
    busUtilizationPct: 44.0
  }
];

export const INITIAL_PUMP_DIAGNOSTICS: PumpVibrationDiagnostic[] = [
  {
    pumpId: 'PUMP-RO-CA01-MAIN',
    facilityId: 'TF-CA-01',
    rpm: 3550,
    rmsVelocityMmPerSec: 1.42,
    peakAccelerationG: 0.38,
    bearingHealthScorePct: 98.2,
    dominantHarmonicHz: 59.2,
    anomalyDetected: false,
    fftSpectrum: [
      { freqHz: 20, amplitudeDb: -42 },
      { freqHz: 40, amplitudeDb: -38 },
      { freqHz: 59.2, amplitudeDb: -14 },
      { freqHz: 120, amplitudeDb: -32 },
      { freqHz: 180, amplitudeDb: -45 },
      { freqHz: 240, amplitudeDb: -52 }
    ]
  },
  {
    pumpId: 'CHILLER-COMP-01-TX',
    facilityId: 'TF-TX-01',
    rpm: 2950,
    rmsVelocityMmPerSec: 2.15,
    peakAccelerationG: 0.62,
    bearingHealthScorePct: 92.5,
    dominantHarmonicHz: 49.1,
    anomalyDetected: false,
    fftSpectrum: [
      { freqHz: 25, amplitudeDb: -39 },
      { freqHz: 49.1, amplitudeDb: -12 },
      { freqHz: 100, amplitudeDb: -28 },
      { freqHz: 150, amplitudeDb: -36 },
      { freqHz: 200, amplitudeDb: -48 }
    ]
  }
];

export function generateLiveRustTelemetryLogs(): RustActorTelemetryEvent[] {
  const subsystems: RustActorTelemetryEvent['subsystem'][] = [
    'PID_HVAC', 'DOSING_PUMP', 'CAN_BUS_VEHICLE', 'GANTRY_ROBOT', 'BESS_INVERTER', 'VIBRATION_FFT'
  ];
  const facilities = ['TF-CA-01', 'TF-AZ-01', 'TF-TX-01', 'TF-IA-01', 'TF-IL-01', 'TF-FL-01', 'TF-NY-01'];

  const messages: Record<string, string[]> = {
    PID_HVAC: [
      'HVAC sensible cooling PID loop converged in 12ms (delta: -0.04°C)',
      'Enthalpy recovery wheel speed adjusted to 420 RPM for latent load control',
      'Airflow velocity tuned to 0.45 m/s across canopy boundary layer'
    ],
    DOSING_PUMP: [
      'Micro-pulse Ca(NO3)2 injection: 12.4 mL delivered at 4.2 bar',
      'EC telemetry stable at 1.82 mS/cm across 4 manifold zones',
      'Inline pH optical sensor auto-calibrated with buffer standard offset +0.01'
    ],
    CAN_BUS_VEHICLE: [
      'CAN Frame J1939 0x18FEE000 parsed: Engine load 68%, GPS RTK lock stable',
      'Autonomous implement swath overlap: 0.9 cm (within 2.0 cm tolerance)',
      'Battery state of health (SoH) verified at 98.4% via BMS CAN packet'
    ],
    GANTRY_ROBOT: [
      'Vacuum manifold picked 128/128 pelleted seeds without double-drop',
      'High-speed gantry X-axis translated 4.2m in 1.1s (0.02mm repeatability)',
      'Delta robot completed 85 selective harvests with optical Brix verification'
    ],
    BESS_INVERTER: [
      'ERCOT Real-Time LMP spike detected ($185/MWh): BESS switched to DISCHARGE (2.5 MW)',
      'Solar PV MPPT efficiency tracking at 99.1% across 16.8 MW array',
      'Frequency regulation response delivered within 80ms to grid interconnect'
    ],
    VIBRATION_FFT: [
      '1024-point FFT on high-pressure pump bearing: RMS velocity 1.42 mm/s (NORMAL)',
      'Chiller compressor 2X rotational harmonic within ISO 10816-3 Zone A limits',
      'No cavitational broadband noise detected in RO feed manifold'
    ]
  };

  const logs: RustActorTelemetryEvent[] = [];
  const now = Date.now() * 1000000; // nanoseconds

  for (let i = 0; i < 8; i++) {
    const sub = subsystems[Math.floor(Math.random() * subsystems.length)];
    const fac = facilities[Math.floor(Math.random() * facilities.length)];
    const msgList = messages[sub];
    const msg = msgList[Math.floor(Math.random() * msgList.length)];

    logs.push({
      timestampNs: now - i * 140000000,
      workerThreadId: (i % 8) + 1,
      facilityId: fac,
      subsystem: sub,
      severity: 'INFO',
      message: msg,
      latencyMicroseconds: Math.floor(12 + Math.random() * 85),
      anomalyDetected: false
    });
  }

  return logs;
}
