/**
 * TerraForge Industrial AgriTech Operating System
 * Enterprise TypeScript Type Definitions (Rust Telemetry + R Statistical Model Integration)
 */

export type FarmType = 
  | 'VERTICAL_HYDROPONIC' 
  | 'SEMI_CLOSED_CEA_GREENHOUSE' 
  | 'AUTONOMOUS_PRECISION_FIELD';

export type USRegion = 
  | 'CALIFORNIA' 
  | 'ARIZONA' 
  | 'TEXAS' 
  | 'IOWA' 
  | 'ILLINOIS' 
  | 'FLORIDA' 
  | 'NEW_YORK' 
  | 'PENNSYLVANIA' 
  | 'NORTH_CAROLINA';

export type GrowthStage = 
  | 'SEEDING' 
  | 'GERMINATION' 
  | 'VEGETATIVE' 
  | 'FLOWERING' 
  | 'FRUITING_BULKING' 
  | 'MATURATION' 
  | 'HARVEST_READY' 
  | 'SANITATION_REPLANT';

export interface CropSpec {
  id: string;
  name: string;
  cultivar: string;
  category: 'LEAFY_GREENS' | 'HERBS' | 'VINE_CROPS' | 'BERRIES' | 'MICROGREENS' | 'AGRONOMIC_ROW';
  targetCycleDays: number;
  targetYieldKgPerM2: number;
  idealTempC: [number, number]; // [day, night]
  idealHumidityPct: [number, number];
  idealVpdKpa: [number, number];
  idealCo2Ppm: number;
  idealPpfd: number; // µmol/m²/s
  targetDli: number; // mol/m²/day
  idealPh: [number, number];
  idealEc: [number, number]; // mS/cm
  marketPricePerKg: number;
  productionCostPerKg: number;
  targetBrix: number;
}

export interface GrowingModule {
  moduleId: string;
  facilityId: string;
  tierNumber: number;
  rackId: string;
  cropId: string;
  cropName: string;
  cultivar: string;
  ageDays: number;
  growthStage: GrowthStage;
  healthIndex: number; // 0-100%
  // Environmental Sensor Telemetry (Rust Ingestion)
  temperatureC: number;
  humidityPct: number;
  co2Ppm: number;
  ppfdUmols: number;
  photoperiodHours: number;
  dliAccumulated: number;
  vpdKpa: number;
  // Hydroponic / Root-zone Telemetry
  ph: number;
  ecMscm: number;
  dissolvedOxygenMgL: number;
  rootZoneTempC: number;
  waterFlowRateLpm: number;
  nutrientRatio: {
    n_ppm: number;
    p_ppm: number;
    k_ppm: number;
    ca_ppm: number;
    mg_ppm: number;
    fe_ppm: number;
  };
  // Production Yield Metrics
  growingAreaM2: number;
  plantDensityPerM2: number;
  expectedYieldKg: number;
  actualYieldKg: number;
  harvestCountdownDays: number;
  biomassGramsPerPlant: number;
  predictedBrix: number;
  // Anomaly / State
  status: 'OPTIMAL' | 'DEGRADED' | 'WARNING' | 'ALERT';
  activeAlarms: string[];
}

export interface EnergySystem {
  facilityId: string;
  gridDemandMw: number;
  solarGenerationMw: number;
  windGenerationMw: number;
  bessChargeMw: number;
  bessDischargeMw: number;
  bessStateOfChargePct: number; // 0-100%
  bessCapacityMwh: number;
  hvacDemandMw: number;
  lightingDemandMw: number;
  pumpDemandMw: number;
  coldStorageDemandMw: number;
  totalNetDemandMw: number;
  // Grid Tariff / Wholesale Market
  isoMarket: 'CAISO' | 'ERCOT' | 'PJM' | 'MISO' | 'NYISO';
  spotPriceMwh: number; // $/MWh
  dayAheadPriceMwh: number;
  demandChargeRateKw: number;
  ppaContractPriceMwh: number;
  dailyEnergyCostUsd: number;
  energyIntensityKwhPerKg: number;
  curtailmentOpportunityActive: boolean;
}

export interface WaterClosedLoop {
  facilityId: string;
  freshwaterInputLpd: number;
  irrigationCirculationLpd: number;
  plantTranspirationLpd: number;
  hvacCondensateRecoveredLpd: number;
  drainageRecoveryLpd: number;
  roPermeateOutputLpd: number;
  roBrineRejectLpd: number;
  uvSterilizationStatus: 'NOMINAL' | 'SERVICING' | 'FAULT';
  ozoneContactDosePpm: number;
  waterRecoveryRatePct: number; // e.g. 96.4%
  waterIntensityLitresPerKg: number; // e.g. 1.8 L/kg vs 250 L/kg field
  totalVolumeInCirculationL: number;
  reservoirTempC: number;
  filterDifferentialPressurePsi: number;
}

export interface MachineryAsset {
  id: string;
  facilityId: string;
  name: string;
  type: 'AUTONOMOUS_TRACTOR' | 'AUTONOMOUS_COMBINE' | 'PRECISION_SPRAYER' | 'MULTISPECTRAL_DRONE' | 'LOGISTICS_TRUCK';
  batteryOrFuelPct: number;
  status: 'ACTIVE_MISSION' | 'CHARGING_REFUELING' | 'STANDBY' | 'MAINTENANCE_REQUIRED';
  currentTask: string;
  gpsCoords: [number, number]; // [lat, lng]
  speedKmh: number;
  headingDeg: number;
  fieldCoverageAcresPerHr: number;
  swathOverlapErrorCm: number; // RTK accuracy e.g. 1.2 cm
  engineHours: number;
  remainingUsefulLifeDays: number;
}

export interface RoboticCell {
  id: string;
  facilityId: string;
  name: string;
  type: 'GANTRY_SEEDER' | 'TRANSPLANT_DELTA_ROBOT' | 'INSPECTION_SPECTRAL_AMR' | 'SELECTIVE_HARVESTER' | 'PACKAGING_CELL';
  batteryPct: number;
  status: 'RUNNING' | 'IDLE' | 'TOOL_CHANGEOVER' | 'FAULT_BLOCKED';
  activeTask: string;
  cycleTimeSeconds: number;
  pickRateUnitsPerMin: number;
  visionAccuracyPct: number;
  gripperHealthPct: number;
  maintenanceState: 'OPTIMAL' | 'INSPECTION_DUE' | 'CALIBRATION_NEEDED';
}

export interface ColdStorageUnit {
  unitId: string;
  facilityId: string;
  currentTempC: number;
  targetTempC: number;
  relativeHumidityPct: number;
  co2Ppm: number;
  ethylenePpb: number;
  capacityMetricTons: number;
  currentInventoryMt: number;
  utilizationPct: number;
  inventoryAgeAvgDays: number;
  spoilageRiskPct: number;
  powerDrawKw: number;
}

export interface Facility {
  facilityId: string;
  name: string;
  state: USRegion;
  locationName: string;
  coordinates: [number, number]; // [lat, lng]
  farmType: FarmType;
  growingAreaSqM: number;
  productionCapacityMtYear: number;
  currentAnnualRunRateMt: number;
  energyCapacityMw: number;
  waterCapacityKlDay: number;
  coldStorageCapacityMt: number;
  activeLabourHeadcount: number;
  autonomousRobotsCount: number;
  machineryFleetCount: number;
  currentEbitdaMarginPct: number;
  unitCostPerKgUsd: number;
  growingModules: GrowingModule[];
  energySystem: EnergySystem;
  waterSystem: WaterClosedLoop;
  machinery: MachineryAsset[];
  robotics: RoboticCell[];
  coldStorage: ColdStorageUnit;
  // Digital Twin Discrepancies
  digitalTwinDivergenceScorePct: number;
  status: 'OPTIMAL' | 'ATTENTION' | 'CRITICAL';
}

export interface ExperimentTrial {
  id: string;
  trialName: string;
  cultivar: string;
  variableTested: 'SPECTRAL_FAR_RED' | 'CO2_CONCENTRATION' | 'NUTRIENT_K_CA_RATIO' | 'ROOT_TEMP_O2' | 'PLANTING_DENSITY';
  sampleSizeN: number;
  controlSpec: {
    description: string;
    meanYieldGramsPerPlant: number;
    sdGrams: number;
    meanBrix: number;
    energyKwhPerKg: number;
  };
  treatmentSpec: {
    description: string;
    meanYieldGramsPerPlant: number;
    sdGrams: number;
    meanBrix: number;
    energyKwhPerKg: number;
  };
  effectSizeCohenD: number;
  pValue: number;
  confidenceInterval95: [number, number]; // [low, high]
  yieldDeltaPct: number;
  annualizedEbitdaImpactUsdPerM2: number;
  recommendation: 'DEPLOY_NETWORK_WIDE' | 'EXTEND_REPLICATION' | 'REJECT_TREATMENT';
}

export interface MonteCarloRiskResult {
  simulationsRun: number;
  metricName: string;
  unit: string;
  p10: number; // 90% probability above this
  p50: number; // Median
  p90: number; // Top 10% upside
  standardDeviation: number;
  riskOfLossPct: number;
  histogram: { bin: number; frequency: number; cumulativePct: number }[];
}

export interface SitingLocationCandidate {
  id: string;
  cityState: string;
  region: USRegion;
  electricityRateCentsKwh: number;
  renewableGridPct: number;
  waterCostPer1000GalUsd: number;
  waterStressScore: number; // 1-10
  labourRateHourlyUsd: number;
  landCostPerAcreUsd: number;
  constructionCostIndex: number; // 100 = national avg
  freightDistanceToMajorHubKm: number;
  stateTaxIncentiveScore: number;
  projectedCapexMillionUsd: number;
  projectedNpvMillionUsd: number; // 10-yr NPV
  projectedIrrPct: number;
  paybackYears: number;
  riskScore: number; // 1-100
  compositeRank: number;
}

export interface SupplyChainRoute {
  routeId: string;
  originFacilityId: string;
  destinationHub: string;
  cropType: string;
  shipmentVolumeKg: number;
  truckAssetId: string;
  departureTime: string;
  estimatedArrival: string;
  transitTempC: number;
  targetTempC: number;
  carbonEmissionsKg: number;
  transportCostPerKg: number;
  spoilageProbabilityPct: number;
}

export interface RustActorTelemetryEvent {
  timestampNs: number;
  workerThreadId: number;
  facilityId: string;
  subsystem: 'PID_HVAC' | 'DOSING_PUMP' | 'CAN_BUS_VEHICLE' | 'GANTRY_ROBOT' | 'BESS_INVERTER' | 'VIBRATION_FFT';
  severity: 'TRACE' | 'DEBUG' | 'INFO' | 'WARN' | 'ERROR';
  message: string;
  latencyMicroseconds: number;
  anomalyDetected: boolean;
}
