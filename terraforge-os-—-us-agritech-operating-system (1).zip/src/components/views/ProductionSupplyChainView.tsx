/**
 * TerraForge Industrial AgriTech Operating System
 * National Production Optimizer, Cold Chain & Logistics View
 */

import React, { useState } from 'react';
import { 
  Boxes, 
  Truck, 
  ThermometerSnowflake, 
  TrendingUp, 
  Sparkles, 
  MapPin, 
  Clock, 
  ShieldCheck, 
  DollarSign,
  Play,
  CheckCircle2,
  Sliders
} from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, LineChart, Line } from 'recharts';
import { Facility } from '../../types/agritech';

interface ProductionSupplyChainViewProps {
  facilities: Facility[];
}

export const ProductionSupplyChainView: React.FC<ProductionSupplyChainViewProps> = ({
  facilities
}) => {
  const [targetMarginPct, setTargetMarginPct] = useState<number>(35);
  const [isSolvingLp, setIsSolvingLp] = useState<boolean>(false);
  const [lpSolved, setLpSolved] = useState<boolean>(true);

  const handleRunOptimizer = () => {
    setIsSolvingLp(true);
    setTimeout(() => {
      setIsSolvingLp(false);
      setLpSolved(true);
    }, 500);
  };

  // National Crop Allocation Optimization Result (Simulated LP solver)
  const allocationData = [
    { crop: 'Butterhead Lettuce', facility: 'Salinas (CA-01)', volumeMt: 4200, unitCost: 1.42, marketPrice: 2.80, ebitdaMargin: 49.3, destination: 'West Coast Hubs' },
    { crop: 'Campari Cluster Tomato', facility: 'Maricopa (AZ-01)', volumeMt: 7800, unitCost: 1.25, marketPrice: 2.45, ebitdaMargin: 49.0, destination: 'Southwest Retail' },
    { crop: 'Albion Strawberries', facility: 'Hudson (NY-01)', volumeMt: 3200, unitCost: 2.10, marketPrice: 4.50, ebitdaMargin: 53.3, destination: 'Tri-State Metro' },
    { crop: 'Genovese Basil & Herbs', facility: 'Austin (TX-01)', volumeMt: 3600, unitCost: 1.55, marketPrice: 3.20, ebitdaMargin: 51.6, destination: 'Texas Triangle' },
    { crop: 'Baby Spinach', facility: 'Lancaster (PA-01)', volumeMt: 3900, unitCost: 1.60, marketPrice: 2.90, ebitdaMargin: 44.8, destination: 'Mid-Atlantic DC' },
    { crop: 'Sweet Bell Peppers', facility: 'Immokalee (FL-01)', volumeMt: 6400, unitCost: 1.30, marketPrice: 2.30, ebitdaMargin: 43.5, destination: 'Southeast Network' },
    { crop: 'Microgreens Gourmet', facility: 'Chicago (IL-01)', volumeMt: 850, unitCost: 4.20, marketPrice: 9.50, ebitdaMargin: 55.8, destination: 'Midwest Metro' },
    { crop: 'Precision Soy & Grain', facility: 'Ames (IA-01)', volumeMt: 14500, unitCost: 0.38, marketPrice: 0.58, ebitdaMargin: 34.5, destination: 'National Grain Terminals' }
  ];

  // Cold Chain Shelf-Life Decay Curves (Standard vs Modified Atmosphere Vacuum Pre-Cooled)
  const shelfLifeData = [
    { day: 'Day 0', terraforgeMap: 100, standardRefrig: 100 },
    { day: 'Day 3', terraforgeMap: 99.2, standardRefrig: 94.0 },
    { day: 'Day 7', terraforgeMap: 97.5, standardRefrig: 84.5 },
    { day: 'Day 10', terraforgeMap: 94.8, standardRefrig: 71.0 },
    { day: 'Day 14', terraforgeMap: 91.2, standardRefrig: 52.0 },
    { day: 'Day 18', terraforgeMap: 84.0, standardRefrig: 32.0 },
    { day: 'Day 21', terraforgeMap: 74.5, standardRefrig: 15.0 }
  ];

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm">
        <div>
          <div className="flex items-center space-x-2 text-[10px] font-mono text-[#00ccff] uppercase tracking-[0.2em] font-bold mb-1">
            <Boxes className="w-3.5 h-3.5 text-[#00ccff]" />
            <span>National Supply Chain & Linear Programming Optimization</span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight font-mono">
            NATIONAL PRODUCTION ALLOCATOR & COLD CHAIN LOGISTICS
          </h2>
          <p className="text-xs text-[#888] mt-0.5 font-mono">
            Multi-site LP objective: Maximizing national net margin subject to electricity tariffs, harvest dates & transit shelf-life.
          </p>
        </div>

        <button
          id="run-lp-optimizer-btn"
          onClick={handleRunOptimizer}
          disabled={isSolvingLp}
          className="px-3 py-1.5 bg-[#00ff66]/15 hover:bg-[#00ff66]/25 border border-[#00ff66]/50 text-[#00ff66] rounded-sm text-xs font-mono font-bold flex items-center space-x-2 transition-colors disabled:opacity-50 cursor-pointer"
        >
          <Play className="w-3.5 h-3.5" />
          <span>{isSolvingLp ? 'Solving Simplex LP...' : 'Re-Run LP Allocation'}</span>
        </button>
      </div>

      {/* Primary Supply Chain Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-[#0c0e12] border border-[#2d3035] p-3 rounded-sm">
          <div className="flex items-center justify-between text-[#888] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider">National Allocation</span>
            <Boxes className="w-3.5 h-3.5 text-[#00ff66]" />
          </div>
          <div className="text-xl font-bold font-mono text-[#00ff66]">
            44,450 <span className="text-xs font-normal text-[#888]">MT</span>
          </div>
          <div className="text-[10px] font-mono text-[#888] mt-1">
            100% Demand Met
          </div>
        </div>

        <div className="bg-[#0c0e12] border border-[#2d3035] p-3 rounded-sm">
          <div className="flex items-center justify-between text-[#888] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider">Cold Chain Spoilage</span>
            <ThermometerSnowflake className="w-3.5 h-3.5 text-[#00ccff]" />
          </div>
          <div className="text-xl font-bold font-mono text-[#00ccff]">
            0.42% <span className="text-xs font-normal text-[#888]">Loss</span>
          </div>
          <div className="text-[10px] font-mono text-[#888] mt-1">
            Industry Avg: 8.5%
          </div>
        </div>

        <div className="bg-[#0c0e12] border border-[#2d3035] p-3 rounded-sm">
          <div className="flex items-center justify-between text-[#888] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider">Transport Carbon</span>
            <Truck className="w-3.5 h-3.5 text-[#ffaa00]" />
          </div>
          <div className="text-xl font-bold font-mono text-[#ffaa00]">
            18.4 <span className="text-xs font-normal text-[#888]">g CO₂/kg</span>
          </div>
          <div className="text-[10px] font-mono text-[#888] mt-1">
            Minimizes Ton-Miles
          </div>
        </div>

        <div className="bg-[#0c0e12] border border-[#2d3035] p-3 rounded-sm">
          <div className="flex items-center justify-between text-[#888] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider">Target EBITDA</span>
            <TrendingUp className="w-3.5 h-3.5 text-[#00ff66]" />
          </div>
          <div className="text-xl font-bold font-mono text-[#00ff66]">
            46.8%
          </div>
          <div className="text-[10px] font-mono text-[#888] mt-1">
            Enterprise Blended
          </div>
        </div>
      </div>

      {/* LP Allocation Table */}
      <div className="bg-[#0c0e12] border border-[#2d3035] rounded-sm p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center space-x-2">
            <CheckCircle2 className="w-3.5 h-3.5 text-[#00ff66]" />
            <span>Optimal National Crop Allocation Matrix (Linear Program Solution)</span>
          </h3>
          <span className="text-[10px] font-mono bg-[#00ff66]/10 text-[#00ff66] border border-[#00ff66]/30 px-2 py-0.5 rounded-sm font-bold">
            SIMPLEX CONVERGED (0.014s)
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-[#2d3035] text-[#666] uppercase text-[9px]">
                <th className="pb-2 font-semibold">Crop & Cultivar</th>
                <th className="pb-2 font-semibold">Assigned Production Hub</th>
                <th className="pb-2 font-semibold text-right">Allocated Volume</th>
                <th className="pb-2 font-semibold text-right">Unit Cost ($/kg)</th>
                <th className="pb-2 font-semibold text-right">Contract Price ($/kg)</th>
                <th className="pb-2 font-semibold text-right">EBITDA Margin</th>
                <th className="pb-2 font-semibold">Distribution Market</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#2d3035]/60">
              {allocationData.map((row, idx) => (
                <tr key={idx} className="hover:bg-[#111317] transition-colors">
                  <td className="py-2 font-bold text-white">{row.crop}</td>
                  <td className="py-2 text-[#00ccff]">{row.facility}</td>
                  <td className="py-2 text-right font-bold text-white">{row.volumeMt.toLocaleString()} MT</td>
                  <td className="py-2 text-right text-[#ffaa00]">${row.unitCost.toFixed(2)}</td>
                  <td className="py-2 text-right text-white font-bold">${row.marketPrice.toFixed(2)}</td>
                  <td className="py-2 text-right text-[#00ff66] font-bold">{row.ebitdaMargin.toFixed(1)}%</td>
                  <td className="py-2 text-[#888]">{row.destination}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Shelf-Life Decay Curve & Cold Chain Telemetry */}
      <div className="bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center space-x-2">
              <ThermometerSnowflake className="w-3.5 h-3.5 text-[#00ccff]" />
              <span>Post-Harvest Shelf-Life & Freshness Decay Curve (% Salable Biomass)</span>
            </h3>
            <p className="text-[11px] text-[#888]">Vacuum Pre-cooling + Modified Atmosphere Packaging (MAP) vs Standard Refrigeration</p>
          </div>
        </div>

        <div className="h-56">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={shelfLifeData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="2 2" stroke="#2d3035" opacity={0.6} />
              <XAxis dataKey="day" stroke="#666" fontSize={10} />
              <YAxis stroke="#666" fontSize={10} domain={[0, 100]} />
              <Tooltip contentStyle={{ backgroundColor: '#0c0e12', borderColor: '#2d3035', borderRadius: '2px', color: '#e0e0e0', fontSize: '11px' }} />
              <Line type="monotone" dataKey="terraforgeMap" name="TerraForge MAP Pre-Cooled (%)" stroke="#00ff66" strokeWidth={2} />
              <Line type="monotone" dataKey="standardRefrig" name="Standard Refrigeration (%)" stroke="#666" strokeWidth={1.5} strokeDasharray="3 3" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
