/**
 * TerraForge Industrial AgriTech Operating System
 * Vertical Hydroponics & Controlled-Environment Agriculture (CEA) View
 */

import React, { useState } from 'react';
import { 
  Layers, 
  Sun, 
  Droplets, 
  Wind, 
  Gauge, 
  Sparkles, 
  Sliders, 
  CheckCircle2, 
  AlertCircle, 
  Activity,
  ArrowRight,
  TrendingUp,
  RefreshCw
} from 'lucide-react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, AreaChart, Area } from 'recharts';
import { Facility, GrowingModule } from '../../types/agritech';
import { calculateVpd, calculateAgronomicYieldPrediction } from '../../data/rEngineCalculations';
import { CROP_LIBRARY } from '../../data/nationalNetwork';

interface VerticalHydroponicsViewProps {
  facilities: Facility[];
  selectedFacilityId: string;
  onSelectFacility: (id: string) => void;
}

export const VerticalHydroponicsView: React.FC<VerticalHydroponicsViewProps> = ({
  facilities,
  selectedFacilityId,
  onSelectFacility
}) => {
  // Active facility or default to Salinas CA
  const currentFacility = facilities.find(f => f.facilityId === selectedFacilityId) || 
                          facilities.find(f => f.farmType === 'VERTICAL_HYDROPONIC') || 
                          facilities[0];

  const modules = currentFacility.growingModules.length > 0 ? currentFacility.growingModules : [
    {
      moduleId: 'MOD-DEMO-R01-T1',
      facilityId: currentFacility.facilityId,
      rackId: 'RACK-01',
      tierNumber: 1,
      cropId: 'butterhead_lettuce',
      cropName: 'Rex Butterhead Lettuce',
      cultivar: 'Lactuca sativa (Rex RZ)',
      ageDays: 21,
      growthStage: 'VEGETATIVE' as const,
      healthIndex: 98.2,
      temperatureC: 21.4,
      humidityPct: 66.5,
      co2Ppm: 1050,
      ppfdUmols: 260,
      photoperiodHours: 18,
      dliAccumulated: 16.8,
      vpdKpa: 1.05,
      ph: 5.85,
      ecMscm: 1.85,
      dissolvedOxygenMgL: 8.7,
      rootZoneTempC: 19.2,
      waterFlowRateLpm: 14.5,
      nutrientRatio: { n_ppm: 170, p_ppm: 50, k_ppm: 215, ca_ppm: 175, mg_ppm: 55, fe_ppm: 3.2 },
      growingAreaM2: 600,
      plantDensityPerM2: 28,
      expectedYieldKg: 3480,
      actualYieldKg: 3520,
      harvestCountdownDays: 7,
      biomassGramsPerPlant: 204.0,
      predictedBrix: 4.8,
      status: 'OPTIMAL' as const,
      activeAlarms: []
    }
  ];

  const [selectedModuleId, setSelectedModuleId] = useState<string>(modules[0].moduleId);
  const activeModule = modules.find(m => m.moduleId === selectedModuleId) || modules[0];
  const cropSpec = CROP_LIBRARY[activeModule.cropId] || CROP_LIBRARY.butterhead_lettuce;

  // Interactive Live Climate & Hydroponic Tuning Controls
  const [tempSetpoint, setTempSetpoint] = useState<number>(activeModule.temperatureC);
  const [rhSetpoint, setRhSetpoint] = useState<number>(activeModule.humidityPct);
  const [co2Setpoint, setCo2Setpoint] = useState<number>(activeModule.co2Ppm);
  const [ppfdSetpoint, setPpfdSetpoint] = useState<number>(activeModule.ppfdUmols);
  const [photoperiod, setPhotoperiod] = useState<number>(activeModule.photoperiodHours);
  const [phSetpoint, setPhSetpoint] = useState<number>(activeModule.ph);
  const [ecSetpoint, setEcSetpoint] = useState<number>(activeModule.ecMscm);

  // Compute live psychrometric VPD and DLI
  const vpdResult = calculateVpd(tempSetpoint, rhSetpoint);
  const liveDli = parseFloat(((ppfdSetpoint * photoperiod * 3600) / 1000000).toFixed(2));

  // Compute live R-driven yield prediction
  const yieldPrediction = calculateAgronomicYieldPrediction({
    dliMolM2Day: liveDli,
    targetDli: cropSpec.targetDli,
    vpdKpa: vpdResult.vpdKpa,
    idealVpdKpa: cropSpec.idealVpdKpa,
    co2Ppm: co2Setpoint,
    idealCo2Ppm: cropSpec.idealCo2Ppm,
    ecMscm: ecSetpoint,
    idealEc: cropSpec.idealEc,
    tempC: tempSetpoint,
    idealTempC: cropSpec.idealTempC,
    baseYieldKgM2: cropSpec.targetYieldKgPerM2
  });

  // Simulated 24-hour diurnal telemetry curve
  const diurnalData = Array.from({ length: 24 }, (_, hour) => {
    const isLightOn = hour >= 4 && hour < (4 + photoperiod);
    const hourTemp = isLightOn ? tempSetpoint : tempSetpoint - 4.5;
    const hourRh = isLightOn ? rhSetpoint : rhSetpoint + 8.0;
    const hourVpd = calculateVpd(hourTemp, hourRh).vpdKpa;
    const hourPpfd = isLightOn ? ppfdSetpoint : 0;
    const hourCo2 = isLightOn ? co2Setpoint : 450;

    return {
      hour: `${hour.toString().padStart(2, '0')}:00`,
      temp: parseFloat(hourTemp.toFixed(1)),
      rh: parseFloat(hourRh.toFixed(1)),
      vpd: hourVpd,
      ppfd: hourPpfd,
      co2: hourCo2
    };
  });

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto">
      {/* Header & Facility Selector */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm">
        <div>
          <div className="flex items-center space-x-2 text-[10px] font-mono text-[#00ff66] uppercase tracking-[0.2em] font-bold mb-1">
            <Layers className="w-3.5 h-3.5 text-[#00ff66]" />
            <span>Multitier Vertical Hydroponic Automation</span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight font-mono">
            VERTICAL HYDROPONIC RACKS & PHOTOBIOLOGICAL CONTROLS
          </h2>
          <p className="text-xs text-[#888] mt-0.5">
            Active Facility: <strong className="text-white font-mono">{currentFacility.name}</strong> ({currentFacility.state}) — {currentFacility.farmType.replace(/_/g, ' ')}
          </p>
        </div>

        {/* Facility Selector */}
        <div className="flex items-center space-x-3">
          <select
            id="hydro-facility-select"
            value={currentFacility.facilityId}
            onChange={(e) => onSelectFacility(e.target.value)}
            className="bg-[#1a1c1e] text-xs font-mono text-[#e0e0e0] border border-[#2d3035] rounded-sm px-3 py-1.5 focus:outline-none cursor-pointer"
          >
            {facilities.map((fac) => (
              <option key={fac.facilityId} value={fac.facilityId} className="bg-[#0c0e12] text-[#e0e0e0]">
                {fac.facilityId} — {fac.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Growing Module Tabs Selector */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-1">
        {modules.map((mod) => (
          <button
            key={mod.moduleId}
            id={`rack-tab-${mod.moduleId.toLowerCase()}`}
            onClick={() => setSelectedModuleId(mod.moduleId)}
            className={`px-3.5 py-2 rounded-sm border text-left transition-all min-w-max cursor-pointer ${
              selectedModuleId === mod.moduleId
                ? 'bg-[#1a1c1e] border-l-2 border-[#00ff66] border-[#2d3035] text-white shadow-sm'
                : 'bg-[#0c0e12] border border-[#2d3035] text-[#888] hover:text-[#e0e0e0] hover:bg-[#1a1c1e]'
            }`}
          >
            <div className="flex items-center justify-between space-x-3">
              <span className="text-[11px] font-mono font-bold text-[#00ff66]">
                {mod.rackId} • Tier {mod.tierNumber}
              </span>
              <span className="text-[9px] font-mono px-1.5 py-0.2 rounded-sm bg-[#08090b] text-[#888] border border-[#2d3035]">
                Day {mod.ageDays}
              </span>
            </div>
            <div className="text-xs font-bold text-white mt-1 font-mono">{mod.cropName}</div>
            <div className="text-[10px] text-[#888] flex items-center space-x-2 mt-0.5 font-mono">
              <span>Stage: <strong className="text-[#e0e0e0]">{mod.growthStage}</strong></span>
              <span>•</span>
              <span>Health: <strong className="text-[#00ff66]">{mod.healthIndex}%</strong></span>
            </div>
          </button>
        ))}
      </div>

      {/* Main Grid: Telemetry Gauges + Photobiological Controls + Digital Twin */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left Column: Live Environmental & Root-Zone Telemetry */}
        <div className="space-y-4">
          <div className="bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm space-y-3">
            <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center justify-between">
              <span className="flex items-center space-x-2">
                <Gauge className="w-3.5 h-3.5 text-[#00ccff]" />
                <span>Live Environmental Telemetry</span>
              </span>
              <span className="text-[9px] font-mono bg-[#00ff66]/10 text-[#00ff66] border border-[#00ff66]/30 px-1.5 py-0.5 rounded-sm">
                100Hz RUST SYNC
              </span>
            </h3>

            {/* Microclimate Matrix */}
            <div className="grid grid-cols-2 gap-2 text-xs font-mono">
              <div className="bg-[#111317] p-2.5 rounded-sm border border-[#2d3035]">
                <span className="text-[9px] text-[#666] block uppercase tracking-widest">Canopy Temp</span>
                <span className="text-lg font-bold text-white">{tempSetpoint}°C</span>
                <span className="text-[9px] text-[#666] block">Opt: {cropSpec.idealTempC[0]}°C</span>
              </div>
              <div className="bg-[#111317] p-2.5 rounded-sm border border-[#2d3035]">
                <span className="text-[9px] text-[#666] block uppercase tracking-widest">Relative Humidity</span>
                <span className="text-lg font-bold text-[#00ccff]">{rhSetpoint}%</span>
                <span className="text-[9px] text-[#666] block">Opt: {cropSpec.idealHumidityPct[0]}-{cropSpec.idealHumidityPct[1]}%</span>
              </div>
              <div className="bg-[#111317] p-2.5 rounded-sm border border-[#2d3035]">
                <span className="text-[9px] text-[#666] block uppercase tracking-widest">CO₂ Enrichment</span>
                <span className="text-lg font-bold text-[#00ff66]">{co2Setpoint} <span className="text-[9px]">ppm</span></span>
                <span className="text-[9px] text-[#666] block">Opt: {cropSpec.idealCo2Ppm} ppm</span>
              </div>
              <div className="bg-[#111317] p-2.5 rounded-sm border border-[#2d3035]">
                <span className="text-[9px] text-[#666] block uppercase tracking-widest">Calculated VPD</span>
                <span className={`text-lg font-bold ${
                  vpdResult.transpirationStressIndex === 'OPTIMAL' ? 'text-[#00ff66]' : 'text-[#ffaa00]'
                }`}>
                  {vpdResult.vpdKpa} <span className="text-[9px]">kPa</span>
                </span>
                <span className="text-[9px] text-[#888] block">{vpdResult.transpirationStressIndex}</span>
              </div>
            </div>

            {/* Root-Zone & Hydroponic Chemistry */}
            <div className="pt-2 border-t border-[#2d3035]">
              <h4 className="text-[10px] font-bold text-[#888] uppercase tracking-widest font-mono mb-2 flex items-center space-x-1.5">
                <Droplets className="w-3 h-3 text-[#00ccff]" />
                <span>Root-Zone Solution Chemistry</span>
              </h4>
              <div className="grid grid-cols-3 gap-2 text-xs font-mono">
                <div className="bg-[#111317] p-2 rounded-sm border border-[#2d3035]">
                  <span className="text-[9px] text-[#666] block">pH Level</span>
                  <span className="text-sm font-bold text-[#00ccff]">{phSetpoint}</span>
                  <span className="text-[8px] text-[#666] block">Opt: {cropSpec.idealPh[0]}-{cropSpec.idealPh[1]}</span>
                </div>
                <div className="bg-[#111317] p-2 rounded-sm border border-[#2d3035]">
                  <span className="text-[9px] text-[#666] block">EC (mS/cm)</span>
                  <span className="text-sm font-bold text-[#00ccff]">{ecSetpoint}</span>
                  <span className="text-[8px] text-[#666] block">Opt: {cropSpec.idealEc[0]}-{cropSpec.idealEc[1]}</span>
                </div>
                <div className="bg-[#111317] p-2 rounded-sm border border-[#2d3035]">
                  <span className="text-[9px] text-[#666] block">DO (mg/L)</span>
                  <span className="text-sm font-bold text-[#00ff66]">{activeModule.dissolvedOxygenMgL}</span>
                  <span className="text-[8px] text-[#666] block">O₂ Venturi</span>
                </div>
              </div>

              {/* Elemental PPM Breakdown (Modified Steiner Solution) */}
              <div className="mt-2.5 p-2.5 bg-[#08090b] rounded-sm border border-[#2d3035] text-[10px] font-mono space-y-1 text-[#888]">
                <span className="text-[9px] text-[#666] uppercase font-bold tracking-widest block mb-1">
                  Active Ion Formulation (PPM)
                </span>
                <div className="grid grid-cols-3 gap-1">
                  <div>NO₃-N: <strong className="text-[#00ff66]">{activeModule.nutrientRatio.n_ppm}</strong></div>
                  <div>PO₄-P: <strong className="text-[#00ff66]">{activeModule.nutrientRatio.p_ppm}</strong></div>
                  <div>K+: <strong className="text-[#00ff66]">{activeModule.nutrientRatio.k_ppm}</strong></div>
                  <div>Ca++: <strong className="text-[#00ccff]">{activeModule.nutrientRatio.ca_ppm}</strong></div>
                  <div>Mg++: <strong className="text-[#00ccff]">{activeModule.nutrientRatio.mg_ppm}</strong></div>
                  <div>Fe-DTPA: <strong className="text-[#ffaa00]">{activeModule.nutrientRatio.fe_ppm}</strong></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Middle Column: Interactive Setpoint Sliders & Photobiological Controls */}
        <div className="space-y-4">
          <div className="bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center space-x-2">
                <Sliders className="w-3.5 h-3.5 text-[#00ff66]" />
                <span>Photobiological & Actuation</span>
              </h3>
              <button
                onClick={() => {
                  setTempSetpoint(cropSpec.idealTempC[0]);
                  setRhSetpoint((cropSpec.idealHumidityPct[0] + cropSpec.idealHumidityPct[1]) / 2);
                  setCo2Setpoint(cropSpec.idealCo2Ppm);
                  setPpfdSetpoint(cropSpec.idealPpfd);
                  setPhotoperiod(18);
                  setPhSetpoint((cropSpec.idealPh[0] + cropSpec.idealPh[1]) / 2);
                  setEcSetpoint((cropSpec.idealEc[0] + cropSpec.idealEc[1]) / 2);
                }}
                className="text-[10px] font-mono text-[#00ff66] hover:underline flex items-center space-x-1 cursor-pointer"
                title="Reset to biological optimum"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Optimum</span>
              </button>
            </div>

            {/* Slider 1: PPFD */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-[#888] flex items-center space-x-1">
                  <Sun className="w-3 h-3 text-[#ffaa00]" />
                  <span>LED PPFD Output</span>
                </span>
                <span className="text-[#ffaa00] font-bold">{ppfdSetpoint} µmol/m²/s</span>
              </div>
              <input
                id="ppfd-slider"
                type="range"
                min={100}
                max={900}
                step={10}
                value={ppfdSetpoint}
                onChange={(e) => setPpfdSetpoint(Number(e.target.value))}
                className="w-full h-1 bg-[#1a1c1e] rounded-sm appearance-none cursor-pointer accent-[#00ff66]"
              />
              <div className="flex justify-between text-[9px] font-mono text-[#666]">
                <span>100</span>
                <span>DLI: {liveDli} mol/m²/day</span>
                <span>900</span>
              </div>
            </div>

            {/* Slider 2: Photoperiod */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-[#888]">Photoperiod Duration</span>
                <span className="text-[#00ccff] font-bold">{photoperiod} Hours/Day</span>
              </div>
              <input
                id="photoperiod-slider"
                type="range"
                min={12}
                max={24}
                step={1}
                value={photoperiod}
                onChange={(e) => setPhotoperiod(Number(e.target.value))}
                className="w-full h-1 bg-[#1a1c1e] rounded-sm appearance-none cursor-pointer accent-[#00ccff]"
              />
            </div>

            {/* Slider 3: CO2 */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-[#888] flex items-center space-x-1">
                  <Wind className="w-3 h-3 text-[#00ff66]" />
                  <span>CO₂ Enrichment Dosing</span>
                </span>
                <span className="text-[#00ff66] font-bold">{co2Setpoint} PPM</span>
              </div>
              <input
                id="co2-slider"
                type="range"
                min={400}
                max={1600}
                step={25}
                value={co2Setpoint}
                onChange={(e) => setCo2Setpoint(Number(e.target.value))}
                className="w-full h-1 bg-[#1a1c1e] rounded-sm appearance-none cursor-pointer accent-[#00ff66]"
              />
            </div>

            {/* Slider 4: Canopy Temperature */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-[#888]">Daytime Air Temp</span>
                <span className="text-white font-bold">{tempSetpoint}°C</span>
              </div>
              <input
                id="temp-slider"
                type="range"
                min={16.0}
                max={30.0}
                step={0.2}
                value={tempSetpoint}
                onChange={(e) => setTempSetpoint(Number(e.target.value))}
                className="w-full h-1 bg-[#1a1c1e] rounded-sm appearance-none cursor-pointer accent-[#ffaa00]"
              />
            </div>

            {/* Slider 5: Relative Humidity */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-[#888]">Dehumidification / RH</span>
                <span className="text-[#00ccff] font-bold">{rhSetpoint}%</span>
              </div>
              <input
                id="rh-slider"
                type="range"
                min={40}
                max={85}
                step={1}
                value={rhSetpoint}
                onChange={(e) => setRhSetpoint(Number(e.target.value))}
                className="w-full h-1 bg-[#1a1c1e] rounded-sm appearance-none cursor-pointer accent-[#00ccff]"
              />
            </div>

            {/* Slider 6: EC */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-[#888]">Dosing Target EC</span>
                <span className="text-indigo-400 font-bold">{ecSetpoint} mS/cm</span>
              </div>
              <input
                id="ec-slider"
                type="range"
                min={0.8}
                max={3.5}
                step={0.05}
                value={ecSetpoint}
                onChange={(e) => setEcSetpoint(Number(e.target.value))}
                className="w-full h-1 bg-[#1a1c1e] rounded-sm appearance-none cursor-pointer accent-indigo-500"
              />
            </div>
          </div>
        </div>

        {/* Right Column: R-Driven Real-Time Yield & Digital Twin Output */}
        <div className="space-y-4">
          <div className="bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center space-x-2">
                <Sparkles className="w-3.5 h-3.5 text-[#00ff66]" />
                <span>R Yield & Biomass Response</span>
              </h3>
              <span className="text-[9px] font-mono text-indigo-400 bg-indigo-500/10 border border-indigo-500/30 px-1.5 py-0.5 rounded-sm">
                NON-LINEAR
              </span>
            </div>

            {/* Predicted Yield & Efficiency Output */}
            <div className="bg-[#111317] p-3.5 rounded-sm border border-[#2d3035] text-center space-y-1.5">
              <span className="text-[10px] text-[#666] uppercase font-mono tracking-widest">
                Predicted Harvest Yield
              </span>
              <div className="text-3xl font-bold font-mono text-[#00ff66]">
                {yieldPrediction.predictedYieldKgM2} <span className="text-xs font-normal text-[#666]">kg/m²</span>
              </div>
              <div className="flex items-center justify-center space-x-2 text-[11px] font-mono">
                <span className="text-[#888]">Photosynthetic Efficiency:</span>
                <span className={`font-bold ${yieldPrediction.efficiencyPct >= 95 ? 'text-[#00ff66]' : 'text-[#ffaa00]'}`}>
                  {yieldPrediction.efficiencyPct}%
                </span>
              </div>
              <div className="text-[10px] font-mono text-[#888] pt-1.5 border-t border-[#2d3035]">
                Limiting Factor: <strong className="text-[#ffaa00]">{yieldPrediction.limitingFactor}</strong>
              </div>
            </div>

            {/* Physiological Multiplier Diagnostics */}
            <div className="space-y-1.5 text-[11px] font-mono">
              <div className="flex justify-between items-center bg-[#111317] p-1.5 rounded-sm border border-[#2d3035]">
                <span className="text-[#666]">DLI Saturation:</span>
                <span className="font-bold text-[#e0e0e0]">{yieldPrediction.dliMultiplier}x</span>
              </div>
              <div className="flex justify-between items-center bg-[#111317] p-1.5 rounded-sm border border-[#2d3035]">
                <span className="text-[#666]">VPD Stomatal:</span>
                <span className="font-bold text-[#e0e0e0]">{yieldPrediction.vpdMultiplier}x</span>
              </div>
              <div className="flex justify-between items-center bg-[#111317] p-1.5 rounded-sm border border-[#2d3035]">
                <span className="text-[#666]">CO₂ Affinity:</span>
                <span className="font-bold text-[#e0e0e0]">{yieldPrediction.co2Multiplier}x</span>
              </div>
              <div className="flex justify-between items-center bg-[#111317] p-1.5 rounded-sm border border-[#2d3035]">
                <span className="text-[#666]">Nutrient EC:</span>
                <span className="font-bold text-[#e0e0e0]">{yieldPrediction.ecMultiplier}x</span>
              </div>
            </div>

            {/* Harvest & Quality Predictions */}
            <div className="p-2.5 bg-[#00ff66]/5 border border-[#00ff66]/20 rounded-sm text-[11px] font-mono text-[#888] space-y-1">
              <div className="flex justify-between">
                <span>Countdown to Cut:</span>
                <strong className="text-[#00ff66]">{activeModule.harvestCountdownDays} Days Remaining</strong>
              </div>
              <div className="flex justify-between">
                <span>Predicted Brix Sugar:</span>
                <strong className="text-[#ffaa00]">{activeModule.predictedBrix}° Brix</strong>
              </div>
              <div className="flex justify-between">
                <span>Total Rack Yield Target:</span>
                <strong className="text-white">
                  {(yieldPrediction.predictedYieldKgM2 * activeModule.growingAreaM2).toLocaleString()} kg
                </strong>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Diurnal 24-Hour CEA Microclimate Simulation Chart */}
      <div className="bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center space-x-2">
              <Activity className="w-3.5 h-3.5 text-[#00ccff]" />
              <span>24-Hour Diurnal CEA Climate & VPD Dynamics</span>
            </h3>
            <p className="text-[11px] text-[#888]">Simulated psychrometric curve under current photoperiod & HVAC-D control</p>
          </div>
          <div className="flex items-center space-x-4 text-[10px] font-mono text-[#888]">
            <span className="flex items-center space-x-1.5">
              <span className="w-2 h-2 rounded-sm bg-[#00ff66]" />
              <span>Temp (°C)</span>
            </span>
            <span className="flex items-center space-x-1.5">
              <span className="w-2 h-2 rounded-sm bg-[#00ccff]" />
              <span>RH (%)</span>
            </span>
            <span className="flex items-center space-x-1.5">
              <span className="w-2 h-2 rounded-sm bg-[#ffaa00]" />
              <span>VPD (kPa)</span>
            </span>
          </div>
        </div>

        <div className="h-56">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={diurnalData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="colorTemp" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#00ff66" stopOpacity={0.4}/>
                  <stop offset="95%" stopColor="#00ff66" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorRh" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#00ccff" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#00ccff" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="2 2" stroke="#2d3035" opacity={0.6} />
              <XAxis dataKey="hour" stroke="#666" fontSize={10} />
              <YAxis stroke="#666" fontSize={10} />
              <Tooltip contentStyle={{ backgroundColor: '#0c0e12', borderColor: '#2d3035', borderRadius: '2px', color: '#e0e0e0', fontSize: '11px' }} />
              <Area type="monotone" dataKey="temp" name="Temperature (°C)" stroke="#00ff66" strokeWidth={1.5} fillOpacity={1} fill="url(#colorTemp)" />
              <Area type="monotone" dataKey="rh" name="Relative Humidity (%)" stroke="#00ccff" strokeWidth={1.5} fillOpacity={1} fill="url(#colorRh)" />
              <Line type="monotone" dataKey="vpd" name="VPD (kPa)" stroke="#ffaa00" strokeWidth={2} dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
