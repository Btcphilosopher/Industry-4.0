/**
 * TerraForge Industrial AgriTech Operating System
 * Robotics, Autonomous Machinery & Field Telemetry View
 */

import React, { useState } from 'react';
import { 
  Bot, 
  Tractor, 
  Radio, 
  Cpu, 
  Activity, 
  CheckCircle2, 
  AlertTriangle, 
  Gauge, 
  Compass, 
  Play, 
  RotateCcw,
  Zap,
  Wrench
} from 'lucide-react';
import { Facility, RoboticCell, MachineryAsset } from '../../types/agritech';

interface RoboticsMachineryViewProps {
  facilities: Facility[];
  selectedFacilityId: string;
  onSelectFacility: (id: string) => void;
}

export const RoboticsMachineryView: React.FC<RoboticsMachineryViewProps> = ({
  facilities,
  selectedFacilityId,
  onSelectFacility
}) => {
  const currentFacility = facilities.find(f => f.facilityId === selectedFacilityId) || facilities[0];
  const [fleetCategory, setFleetCategory] = useState<'ALL' | 'INDOOR_ROBOTS' | 'FIELD_MACHINERY'>('ALL');

  const robots = currentFacility.robotics || [];
  const machinery = currentFacility.machinery || [];

  // Aggregate fleet stats
  const totalRobots = robots.length;
  const totalMachinery = machinery.length;
  const avgVisionAccuracy = robots.length > 0 
    ? (robots.reduce((sum, r) => sum + r.visionAccuracyPct, 0) / robots.length).toFixed(1)
    : '99.4';
  const avgCycleTime = robots.length > 0
    ? (robots.reduce((sum, r) => sum + r.cycleTimeSeconds, 0) / robots.length).toFixed(1)
    : '4.2';

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm">
        <div>
          <div className="flex items-center space-x-2 text-[10px] font-mono text-[#00ccff] uppercase tracking-[0.2em] font-bold mb-1">
            <Bot className="w-3.5 h-3.5 text-[#00ccff]" />
            <span>Industrial Robotics & Autonomous Implement Telemetry</span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight font-mono">
            ROBOTIC AUTOMATION FLEET & AUTONOMOUS MACHINERY
          </h2>
          <p className="text-xs text-[#888] mt-0.5 font-mono">
            Facility: <strong className="text-white">{currentFacility.name}</strong> • Active Fleet: <strong className="text-[#00ccff]">{totalRobots} CEA Robots / {totalMachinery} Field Machines</strong>
          </p>
        </div>

        {/* Facility Selector */}
        <select
          id="robotics-facility-select"
          value={currentFacility.facilityId}
          onChange={(e) => onSelectFacility(e.target.value)}
          className="bg-[#1a1c1e] text-xs font-mono text-[#e0e0e0] border border-[#2d3035] rounded-sm px-3 py-1.5 focus:outline-none cursor-pointer"
        >
          {facilities.map((fac) => (
            <option key={fac.facilityId} value={fac.facilityId} className="bg-[#0c0e12] text-[#e0e0e0]">
              {fac.facilityId} — {fac.name} ({fac.autonomousRobotsCount + fac.machineryFleetCount} Units)
            </option>
          ))}
        </select>
      </div>

      {/* Fleet Overview KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-[#0c0e12] border border-[#2d3035] p-3 rounded-sm">
          <div className="flex items-center justify-between text-[#888] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider">Average Cycle Time</span>
            <Activity className="w-3.5 h-3.5 text-[#00ff66]" />
          </div>
          <div className="text-xl font-bold font-mono text-[#00ff66]">
            {avgCycleTime}s
          </div>
          <div className="text-[10px] font-mono text-[#888] mt-1">
            Target: &lt; 5.0s
          </div>
        </div>

        <div className="bg-[#0c0e12] border border-[#2d3035] p-3 rounded-sm">
          <div className="flex items-center justify-between text-[#888] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider">Vision AI Accuracy</span>
            <CheckCircle2 className="w-3.5 h-3.5 text-[#00ccff]" />
          </div>
          <div className="text-xl font-bold font-mono text-[#00ccff]">
            {avgVisionAccuracy}%
          </div>
          <div className="text-[10px] font-mono text-[#888] mt-1">
            Optical Defect ID
          </div>
        </div>

        <div className="bg-[#0c0e12] border border-[#2d3035] p-3 rounded-sm">
          <div className="flex items-center justify-between text-[#888] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider">RTK GPS Precision</span>
            <Compass className="w-3.5 h-3.5 text-[#ffaa00]" />
          </div>
          <div className="text-xl font-bold font-mono text-[#ffaa00]">
            1.2 cm
          </div>
          <div className="text-[10px] font-mono text-[#888] mt-1">
            Dual-Frequency RTK
          </div>
        </div>

        <div className="bg-[#0c0e12] border border-[#2d3035] p-3 rounded-sm">
          <div className="flex items-center justify-between text-[#888] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider">CAN Bus J1939</span>
            <Radio className="w-3.5 h-3.5 text-indigo-400" />
          </div>
          <div className="text-xl font-bold font-mono text-indigo-400">
            250 kbps
          </div>
          <div className="text-[10px] font-mono text-[#888] mt-1">
            Rust Stream Decoders
          </div>
        </div>
      </div>

      {/* Category Filter Toolbar */}
      <div className="flex items-center space-x-2 bg-[#0c0e12] p-2 rounded-sm border border-[#2d3035]">
        <button
          onClick={() => setFleetCategory('ALL')}
          className={`px-3 py-1 rounded-sm text-xs font-mono transition-colors cursor-pointer ${
            fleetCategory === 'ALL' ? 'bg-[#1a1c1e] text-white border border-[#00ff66] font-bold' : 'text-[#888] hover:text-white'
          }`}
        >
          Complete Fleet ({robots.length + machinery.length})
        </button>
        <button
          onClick={() => setFleetCategory('INDOOR_ROBOTS')}
          className={`px-3 py-1 rounded-sm text-xs font-mono transition-colors cursor-pointer ${
            fleetCategory === 'INDOOR_ROBOTS' ? 'bg-[#00ccff]/10 text-[#00ccff] border border-[#00ccff]/30 font-bold' : 'text-[#888] hover:text-white'
          }`}
        >
          CEA Indoor Robotics ({robots.length})
        </button>
        <button
          onClick={() => setFleetCategory('FIELD_MACHINERY')}
          className={`px-3 py-1 rounded-sm text-xs font-mono transition-colors cursor-pointer ${
            fleetCategory === 'FIELD_MACHINERY' ? 'bg-[#ffaa00]/10 text-[#ffaa00] border border-[#ffaa00]/30 font-bold' : 'text-[#888] hover:text-white'
          }`}
        >
          Autonomous Field Machinery ({machinery.length})
        </button>
      </div>

      {/* Robotics Cards Grid */}
      {(fleetCategory === 'ALL' || fleetCategory === 'INDOOR_ROBOTS') && robots.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center space-x-2">
            <Bot className="w-3.5 h-3.5 text-[#00ccff]" />
            <span>CEA Indoor Robotic Automation Fleet</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {robots.map((robot) => (
              <div
                key={robot.id}
                className="bg-[#0c0e12] border border-[#2d3035] p-3.5 rounded-sm space-y-2.5 text-xs font-mono"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[9px] text-[#00ccff] font-bold bg-[#00ccff]/10 px-1.5 py-0.5 rounded-sm border border-[#00ccff]/30">
                      {robot.id}
                    </span>
                    <h4 className="text-sm font-bold text-white mt-1 font-mono">{robot.name}</h4>
                    <p className="text-[10px] text-[#888] font-mono">{robot.type.replace(/_/g, ' ')}</p>
                  </div>
                  <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded-sm uppercase ${
                    robot.status === 'RUNNING' ? 'bg-[#00ff66]/10 text-[#00ff66] border border-[#00ff66]/30' :
                    robot.status === 'IDLE' ? 'bg-[#00ccff]/10 text-[#00ccff] border border-[#00ccff]/30' :
                    'bg-[#ffaa00]/10 text-[#ffaa00] border border-[#ffaa00]/30'
                  }`}>
                    {robot.status.replace(/_/g, ' ')}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 bg-[#111317] p-2 rounded-sm border border-[#2d3035]">
                  <div>
                    <span className="text-[9px] text-[#666] block">Cycle Time:</span>
                    <span className="text-white font-bold">{robot.cycleTimeSeconds}s</span>
                  </div>
                  <div>
                    <span className="text-[9px] text-[#666] block">Vision Acc:</span>
                    <span className="text-[#00ff66] font-bold">{robot.visionAccuracyPct}%</span>
                  </div>
                  <div>
                    <span className="text-[9px] text-[#666] block">Pick Rate:</span>
                    <span className="text-[#00ccff] font-bold">{robot.pickRateUnitsPerMin} u/min</span>
                  </div>
                  <div>
                    <span className="text-[9px] text-[#666] block">Gripper Health:</span>
                    <span className="text-white font-bold">{robot.gripperHealthPct}%</span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[#888] pt-1 text-[11px]">
                  <span>Power: <strong className="text-white">{robot.batteryPct}%</strong></span>
                  <span>Task: <strong className="text-[#00ccff]">{robot.activeTask}</strong></span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Field Machinery Cards Grid */}
      {(fleetCategory === 'ALL' || fleetCategory === 'FIELD_MACHINERY') && machinery.length > 0 && (
        <div className="space-y-3 pt-2">
          <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center space-x-2">
            <Tractor className="w-3.5 h-3.5 text-[#ffaa00]" />
            <span>Autonomous Precision Ag Field Machinery</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {machinery.map((machine) => (
              <div
                key={machine.id}
                className="bg-[#0c0e12] border border-[#2d3035] p-3.5 rounded-sm space-y-2.5 text-xs font-mono"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[9px] text-[#ffaa00] font-bold bg-[#ffaa00]/10 px-1.5 py-0.5 rounded-sm border border-[#ffaa00]/30">
                      {machine.id}
                    </span>
                    <h4 className="text-sm font-bold text-white mt-1 font-mono">{machine.name}</h4>
                    <p className="text-[10px] text-[#888] font-mono">{machine.type.replace(/_/g, ' ')}</p>
                  </div>
                  <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded-sm uppercase ${
                    machine.status === 'ACTIVE_MISSION' ? 'bg-[#00ff66]/10 text-[#00ff66] border border-[#00ff66]/30' :
                    machine.status === 'STANDBY' ? 'bg-[#1a1c1e] text-[#888] border border-[#2d3035]' :
                    'bg-[#ffaa00]/10 text-[#ffaa00] border border-[#ffaa00]/30'
                  }`}>
                    {machine.status.replace(/_/g, ' ')}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 bg-[#111317] p-2 rounded-sm border border-[#2d3035]">
                  <div>
                    <span className="text-[9px] text-[#666] block">RTK Overlap:</span>
                    <span className="text-[#00ff66] font-bold">{machine.swathOverlapErrorCm} cm</span>
                  </div>
                  <div>
                    <span className="text-[9px] text-[#666] block">Coverage:</span>
                    <span className="text-[#ffaa00] font-bold">{machine.fieldCoverageAcresPerHr} ac/hr</span>
                  </div>
                  <div>
                    <span className="text-[9px] text-[#666] block">Speed:</span>
                    <span className="text-[#00ccff] font-bold">{machine.speedKmh} km/h</span>
                  </div>
                  <div>
                    <span className="text-[9px] text-[#666] block">Useful Life:</span>
                    <span className="text-[#00ff66] font-bold">{machine.remainingUsefulLifeDays} d</span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[#888] pt-1 text-[11px]">
                  <span>Engine: <strong className="text-white">{machine.engineHours} hrs</strong></span>
                  <span>Fuel/Batt: <strong className="text-[#00ff66]">{machine.batteryOrFuelPct}%</strong></span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
