/**
 * TerraForge Industrial AgriTech Operating System
 * Closed-Loop Water Recycling & Nutrient Mass-Balance View
 */

import React, { useState } from 'react';
import { 
  Droplets, 
  RefreshCw, 
  ShieldCheck, 
  Activity, 
  Zap, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight,
  Filter,
  Gauge
} from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { Facility } from '../../types/agritech';

interface ClosedLoopWaterViewProps {
  facilities: Facility[];
  selectedFacilityId: string;
  onSelectFacility: (id: string) => void;
}

export const ClosedLoopWaterView: React.FC<ClosedLoopWaterViewProps> = ({
  facilities,
  selectedFacilityId,
  onSelectFacility
}) => {
  const currentFacility = facilities.find(f => f.facilityId === selectedFacilityId) || facilities[0];
  const water = currentFacility.waterSystem;

  // Comparison benchmark data: TerraForge Closed-Loop vs Traditional Outdoor Flood
  const waterComparisonData = [
    { name: 'Butterhead Lettuce', terraforge: 1.85, traditional: 240 },
    { name: 'Baby Spinach', terraforge: 2.10, traditional: 290 },
    { name: 'Genovese Basil', terraforge: 1.65, traditional: 220 },
    { name: 'Strawberries', terraforge: 3.20, traditional: 340 },
    { name: 'Cluster Tomatoes', terraforge: 1.62, traditional: 180 }
  ];

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm">
        <div>
          <div className="flex items-center space-x-2 text-[10px] font-mono text-[#00ccff] uppercase tracking-[0.2em] font-bold mb-1">
            <Droplets className="w-3.5 h-3.5 text-[#00ccff]" />
            <span>Closed-Loop Hydrological Mass Balance</span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight font-mono">
            CLOSED-LOOP WATER RECYCLING & RO SYSTEMS
          </h2>
          <p className="text-xs text-[#888] mt-0.5 font-mono">
            Facility: <strong className="text-white">{currentFacility.name}</strong> • Water Recovery Rate: <strong className="text-[#00ccff]">{water.waterRecoveryRatePct.toFixed(1)}% Recycled</strong>
          </p>
        </div>

        {/* Facility Selector */}
        <select
          id="water-facility-select"
          value={currentFacility.facilityId}
          onChange={(e) => onSelectFacility(e.target.value)}
          className="bg-[#1a1c1e] text-xs font-mono text-[#e0e0e0] border border-[#2d3035] rounded-sm px-3 py-1.5 focus:outline-none cursor-pointer"
        >
          {facilities.map((fac) => (
            <option key={fac.facilityId} value={fac.facilityId} className="bg-[#0c0e12] text-[#e0e0e0]">
              {fac.facilityId} — {fac.name}
            </option>
          ))}
        </select>
      </div>

      {/* High-Level Hydrology KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-[#0c0e12] border border-[#2d3035] p-3 rounded-sm">
          <div className="flex items-center justify-between text-[#888] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider">Water Intensity</span>
            <Droplets className="w-3.5 h-3.5 text-[#00ccff]" />
          </div>
          <div className="text-xl font-bold font-mono text-[#00ccff]">
            {water.waterIntensityLitresPerKg} <span className="text-[10px] font-normal text-[#666]">L/kg</span>
          </div>
          <div className="text-[10px] font-mono text-[#00ff66] mt-1">
            99.2% Less vs Field
          </div>
        </div>

        <div className="bg-[#0c0e12] border border-[#2d3035] p-3 rounded-sm">
          <div className="flex items-center justify-between text-[#888] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider">Recovery Efficiency</span>
            <RefreshCw className="w-3.5 h-3.5 text-[#00ff66]" />
          </div>
          <div className="text-xl font-bold font-mono text-[#00ff66]">
            {water.waterRecoveryRatePct.toFixed(1)}%
          </div>
          <div className="text-[10px] font-mono text-[#888] mt-1">
            HVAC Condensate + RO
          </div>
        </div>

        <div className="bg-[#0c0e12] border border-[#2d3035] p-3 rounded-sm">
          <div className="flex items-center justify-between text-[#888] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider">Daily Circulation</span>
            <Activity className="w-3.5 h-3.5 text-[#00ccff]" />
          </div>
          <div className="text-xl font-bold font-mono text-[#00ccff]">
            {(water.irrigationCirculationLpd / 1000).toFixed(0)} <span className="text-[10px] font-normal text-[#666]">kL/d</span>
          </div>
          <div className="text-[10px] font-mono text-[#888] mt-1">
            Makeup: {(water.freshwaterInputLpd / 1000).toFixed(1)} kL/d
          </div>
        </div>

        <div className="bg-[#0c0e12] border border-[#2d3035] p-3 rounded-sm">
          <div className="flex items-center justify-between text-[#888] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider">Sterilization</span>
            <ShieldCheck className="w-3.5 h-3.5 text-[#00ff66]" />
          </div>
          <div className="text-xl font-bold font-mono text-[#00ff66]">
            {water.uvSterilizationStatus}
          </div>
          <div className="text-[10px] font-mono text-[#888] mt-1">
            UV-C 254nm + {water.ozoneContactDosePpm}ppm O₃
          </div>
        </div>
      </div>

      {/* Closed-Loop Mass-Balance Flow Schematic */}
      <div className="bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm space-y-3">
        <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center space-x-2">
          <RefreshCw className="w-3.5 h-3.5 text-[#00ccff]" />
          <span>Closed-Loop Hydrological Mass Balance Schematic (Litres / Day)</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-2.5 text-xs font-mono">
          {/* Step 1: Main Circulation */}
          <div className="bg-[#111317] p-3 rounded-sm border border-[#2d3035] flex flex-col justify-between">
            <div>
              <span className="text-[9px] text-[#00ccff] font-bold uppercase block mb-1">1. Irrigation Loop</span>
              <div className="text-lg font-bold text-white">{water.irrigationCirculationLpd.toLocaleString()} L</div>
              <p className="text-[10px] text-[#888] mt-1 font-mono">
                Active nutrient solution fed to root manifolds.
              </p>
            </div>
            <div className="mt-2 pt-1.5 border-t border-[#2d3035] text-[9px] text-[#666]">
              Temp: {water.reservoirTempC}°C
            </div>
          </div>

          {/* Step 2: Plant Uptake & Transpiration */}
          <div className="bg-[#111317] p-3 rounded-sm border border-[#2d3035] flex flex-col justify-between">
            <div>
              <span className="text-[9px] text-[#00ff66] font-bold uppercase block mb-1">2. Transpiration</span>
              <div className="text-lg font-bold text-[#00ff66]">{water.plantTranspirationLpd.toLocaleString()} L</div>
              <p className="text-[10px] text-[#888] mt-1 font-mono">
                Transpired into sealed atmosphere.
              </p>
            </div>
            <div className="mt-2 pt-1.5 border-t border-[#2d3035] text-[9px] text-[#666]">
              Biomass Uptake: ~3%
            </div>
          </div>

          {/* Step 3: HVAC Condensate Capture */}
          <div className="bg-[#111317] p-3 rounded-sm border border-[#2d3035] flex flex-col justify-between">
            <div>
              <span className="text-[9px] text-[#00ccff] font-bold uppercase block mb-1">3. Condensate</span>
              <div className="text-lg font-bold text-[#00ccff]">{water.hvacCondensateRecoveredLpd.toLocaleString()} L</div>
              <p className="text-[10px] text-[#888] mt-1 font-mono">
                Dehumidification extracts 96%+ of vapor.
              </p>
            </div>
            <div className="mt-2 pt-1.5 border-t border-[#2d3035] text-[9px] text-[#666]">
              Ultra-Pure (0 EC)
            </div>
          </div>

          {/* Step 4: RO & Multi-Stage Filtration */}
          <div className="bg-[#111317] p-3 rounded-sm border border-[#2d3035] flex flex-col justify-between">
            <div>
              <span className="text-[9px] text-indigo-400 font-bold uppercase block mb-1">4. RO & UV Polishing</span>
              <div className="text-lg font-bold text-indigo-400">{water.roPermeateOutputLpd.toLocaleString()} L</div>
              <p className="text-[10px] text-[#888] mt-1 font-mono">
                0.01µm filter + RO rejects organics.
              </p>
            </div>
            <div className="mt-2 pt-1.5 border-t border-[#2d3035] text-[9px] text-[#666]">
              Brine: {water.roBrineRejectLpd.toLocaleString()} L
            </div>
          </div>

          {/* Step 5: Closed-Loop Return */}
          <div className="bg-[#00ff66]/5 p-3 rounded-sm border border-[#00ff66]/20 flex flex-col justify-between">
            <div>
              <span className="text-[9px] text-[#00ff66] font-bold uppercase block mb-1">5. Freshwater Makeup</span>
              <div className="text-lg font-bold text-[#00ff66]">+{water.freshwaterInputLpd.toLocaleString()} L</div>
              <p className="text-[10px] text-[#888] mt-1 font-mono">
                Only replaces biomass water.
              </p>
            </div>
            <div className="mt-2 pt-1.5 border-t border-[#00ff66]/20 text-[9px] text-[#00ff66] font-bold">
              {water.waterRecoveryRatePct.toFixed(1)}% Closed-Loop
            </div>
          </div>
        </div>
      </div>

      {/* Water Intensity Comparison Chart */}
      <div className="bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center space-x-2">
              <BarChart className="w-3.5 h-3.5 text-[#00ccff]" />
              <span>Water Intensity: TerraForge Closed-Loop vs Conventional US Field (Litres / kg)</span>
            </h3>
            <p className="text-[11px] text-[#888]">Comparison demonstrating 95%+ water reduction across key crops</p>
          </div>
        </div>

        <div className="h-56">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={waterComparisonData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="2 2" stroke="#2d3035" opacity={0.6} />
              <XAxis dataKey="name" stroke="#666" fontSize={10} />
              <YAxis stroke="#666" fontSize={10} />
              <Tooltip contentStyle={{ backgroundColor: '#0c0e12', borderColor: '#2d3035', borderRadius: '2px', color: '#e0e0e0', fontSize: '11px' }} />
              <Bar dataKey="traditional" name="Conventional Field (L/kg)" fill="#2d3035" radius={[2, 2, 0, 0]} />
              <Bar dataKey="terraforge" name="TerraForge Closed-Loop (L/kg)" fill="#00ccff" radius={[2, 2, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
