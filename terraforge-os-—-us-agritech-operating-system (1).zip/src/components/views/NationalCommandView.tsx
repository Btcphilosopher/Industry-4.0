/**
 * TerraForge Industrial AgriTech Operating System
 * National Command View - 9 US Production Facilities & Enterprise KPI Aggregates
 */

import React, { useState } from 'react';
import { 
  Globe, 
  MapPin, 
  Layers, 
  Zap, 
  Droplets, 
  Bot, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle2, 
  ArrowUpRight,
  Filter,
  BarChart3,
  Factory,
  ChevronRight
} from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, PieChart, Pie, Cell } from 'recharts';
import { Facility, FarmType } from '../../types/agritech';

interface NationalCommandViewProps {
  facilities: Facility[];
  onSelectFacility: (id: string) => void;
  onNavigateTab: (tab: any) => void;
}

export const NationalCommandView: React.FC<NationalCommandViewProps> = ({
  facilities,
  onSelectFacility,
  onNavigateTab
}) => {
  const [filterType, setFilterType] = useState<string>('ALL');
  const [searchTerm, setSearchTerm] = useState<string>('');

  const filteredFacilities = facilities.filter(fac => {
    const matchesFilter = filterType === 'ALL' || fac.farmType === filterType;
    const matchesSearch = fac.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          fac.locationName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          fac.state.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  // KPI Calculations
  const totalProductionRunRateMt = facilities.reduce((sum, f) => sum + f.currentAnnualRunRateMt, 0);
  const totalCapacityMt = facilities.reduce((sum, f) => sum + f.productionCapacityMtYear, 0);
  const totalAreaSqM = facilities.reduce((sum, f) => sum + f.growingAreaSqM, 0);
  const totalSolarMw = facilities.reduce((sum, f) => sum + f.energySystem.solarGenerationMw, 0);
  const totalWindMw = facilities.reduce((sum, f) => sum + f.energySystem.windGenerationMw, 0);
  const totalBessMwh = facilities.reduce((sum, f) => sum + f.energySystem.bessCapacityMwh, 0);
  const totalRobots = facilities.reduce((sum, f) => sum + f.autonomousRobotsCount, 0);
  const totalMachinery = facilities.reduce((sum, f) => sum + f.machineryFleetCount, 0);
  const avgEbitdaMargin = facilities.reduce((sum, f) => sum + f.currentEbitdaMarginPct, 0) / facilities.length;

  // Chart data: Production by Facility
  const facilityProductionChartData = facilities.map(f => ({
    name: f.state.substring(0, 2) + '-' + f.facilityId.split('-')[1],
    fullName: f.name,
    runRate: f.currentAnnualRunRateMt,
    capacity: f.productionCapacityMtYear,
    margin: f.currentEbitdaMarginPct,
    unitCost: f.unitCostPerKgUsd
  }));

  // Chart data: Production by Farm Type
  const typeDistribution = [
    {
      name: 'Vertical Hydroponic',
      value: facilities.filter(f => f.farmType === 'VERTICAL_HYDROPONIC').reduce((sum, f) => sum + f.currentAnnualRunRateMt, 0),
      color: '#00ff66'
    },
    {
      name: 'Semi-Closed Greenhouse',
      value: facilities.filter(f => f.farmType === 'SEMI_CLOSED_CEA_GREENHOUSE').reduce((sum, f) => sum + f.currentAnnualRunRateMt, 0),
      color: '#00ccff'
    },
    {
      name: 'Autonomous Field',
      value: facilities.filter(f => f.farmType === 'AUTONOMOUS_PRECISION_FIELD').reduce((sum, f) => sum + f.currentAnnualRunRateMt, 0),
      color: '#ffaa00'
    }
  ];

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto">
      {/* View Title & High-Level Scope Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm">
        <div>
          <div className="flex items-center space-x-2 text-[10px] font-mono text-[#00ff66] uppercase tracking-[0.2em] font-bold mb-1">
            <Globe className="w-3.5 h-3.5 text-[#00ff66]" />
            <span>National Enterprise Operations Grid</span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight font-mono">
            US AGRITECH FACILITY FLEET & PRODUCTION COMMAND
          </h2>
          <p className="text-xs text-[#888] mt-0.5">
            Real-time telemetry and biometric supervision across 9 national vertical hydroponic, greenhouse, and precision field hubs.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            id="national-optimize-btn"
            onClick={() => onNavigateTab('PRODUCTION_SUPPLY_CHAIN')}
            className="px-3.5 py-2 bg-[#00ff66]/10 border border-[#00ff66]/40 text-[#00ff66] hover:bg-[#00ff66]/20 rounded-sm text-xs font-mono font-bold flex items-center space-x-2 shadow-[0_0_8px_rgba(0,255,102,0.2)] transition-all cursor-pointer"
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>OPTIMIZE ALLOCATION</span>
          </button>
          <button
            id="national-risk-btn"
            onClick={() => onNavigateTab('R_STATISTICAL_LAB')}
            className="px-3.5 py-2 bg-[#1a1c1e] hover:bg-[#25282c] text-[#00ccff] border border-[#00ccff]/30 rounded-sm text-xs font-mono font-bold flex items-center space-x-2 transition-all cursor-pointer"
          >
            <BarChart3 className="w-3.5 h-3.5 text-[#00ccff]" />
            <span>R MONTE CARLO</span>
          </button>
        </div>
      </div>

      {/* Enterprise Metric Cards Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-[#0c0e12] border border-[#2d3035] p-3 rounded-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#888] mb-1">
            <span className="text-[10px] uppercase font-mono font-bold tracking-widest text-[#666]">Annual Production</span>
            <Factory className="w-3.5 h-3.5 text-[#00ff66]" />
          </div>
          <div className="text-2xl font-bold font-mono text-[#00ff66]">
            {totalProductionRunRateMt.toLocaleString()} <span className="text-xs font-normal text-[#666]">MT/yr</span>
          </div>
          <div className="mt-2 flex items-center justify-between text-[11px] font-mono border-t border-[#2d3035] pt-1.5">
            <span className="text-[#666]">Utilization:</span>
            <span className="text-[#00ff66] font-bold">
              {((totalProductionRunRateMt / totalCapacityMt) * 100).toFixed(1)}%
            </span>
          </div>
        </div>

        <div className="bg-[#0c0e12] border border-[#2d3035] p-3 rounded-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#888] mb-1">
            <span className="text-[10px] uppercase font-mono font-bold tracking-widest text-[#666]">Clean Power Gen</span>
            <Zap className="w-3.5 h-3.5 text-[#ffaa00]" />
          </div>
          <div className="text-2xl font-bold font-mono text-[#ffaa00]">
            {(totalSolarMw + totalWindMw).toFixed(1)} <span className="text-xs font-normal text-[#666]">MW</span>
          </div>
          <div className="mt-2 flex items-center justify-between text-[11px] font-mono border-t border-[#2d3035] pt-1.5">
            <span className="text-[#666]">BESS Storage:</span>
            <span className="text-[#00ccff] font-bold">{totalBessMwh} MWh</span>
          </div>
        </div>

        <div className="bg-[#0c0e12] border border-[#2d3035] p-3 rounded-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#888] mb-1">
            <span className="text-[10px] uppercase font-mono font-bold tracking-widest text-[#666]">Autonomous Fleet</span>
            <Bot className="w-3.5 h-3.5 text-[#00ccff]" />
          </div>
          <div className="text-2xl font-bold font-mono text-white">
            {totalRobots + totalMachinery} <span className="text-xs font-normal text-[#666]">Units</span>
          </div>
          <div className="mt-2 flex items-center justify-between text-[11px] font-mono border-t border-[#2d3035] pt-1.5">
            <span className="text-[#666]">Robots / Machinery:</span>
            <span className="text-[#e0e0e0]">{totalRobots} / {totalMachinery}</span>
          </div>
        </div>

        <div className="bg-[#0c0e12] border border-[#2d3035] p-3 rounded-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#888] mb-1">
            <span className="text-[10px] uppercase font-mono font-bold tracking-widest text-[#666]">Fleet EBITDA Margin</span>
            <TrendingUp className="w-3.5 h-3.5 text-[#00ff66]" />
          </div>
          <div className="text-2xl font-bold font-mono text-[#00ff66]">
            {avgEbitdaMargin.toFixed(1)}%
          </div>
          <div className="mt-2 flex items-center justify-between text-[11px] font-mono border-t border-[#2d3035] pt-1.5">
            <span className="text-[#666]">Total Area:</span>
            <span className="text-[#e0e0e0]">{(totalAreaSqM / 10000).toFixed(1)} Hectares</span>
          </div>
        </div>
      </div>

      {/* Production Analytics Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* National Run Rate vs Capacity Chart */}
        <div className="lg:col-span-2 bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center space-x-2">
                <BarChart3 className="w-3.5 h-3.5 text-[#00ff66]" />
                <span>Production Run-Rate vs Capacity (MT/yr)</span>
              </h3>
              <p className="text-[11px] text-[#888]">Real-time facility output comparison across all 9 US sites</p>
            </div>
            <span className="text-[10px] font-mono text-[#00ff66] bg-[#00ff66]/10 border border-[#00ff66]/30 px-2 py-0.5 rounded-sm">
              Total: {totalProductionRunRateMt.toLocaleString()} MT
            </span>
          </div>

          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={facilityProductionChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="2 2" stroke="#2d3035" opacity={0.6} />
                <XAxis dataKey="name" stroke="#666" fontSize={10} />
                <YAxis stroke="#666" fontSize={10} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0c0e12', borderColor: '#2d3035', borderRadius: '2px', color: '#e0e0e0', fontSize: '11px' }}
                  itemStyle={{ color: '#00ccff' }}
                  labelStyle={{ fontWeight: 'bold', color: '#00ff66' }}
                />
                <Bar dataKey="capacity" name="Capacity (MT)" fill="#1a1c1e" stroke="#2d3035" />
                <Bar dataKey="runRate" name="Current Run-Rate (MT)" fill="#00ff66" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Farm Type Production Breakdown */}
        <div className="bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center space-x-2 mb-1">
              <Layers className="w-3.5 h-3.5 text-[#00ccff]" />
              <span>Production by Farm Archetype</span>
            </h3>
            <p className="text-[11px] text-[#888] mb-3">Hydroponics vs Greenhouses vs Field</p>

            <div className="h-36 flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={typeDistribution}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    innerRadius={38}
                    outerRadius={60}
                    paddingAngle={3}
                  >
                    {typeDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0c0e12', borderColor: '#2d3035', borderRadius: '2px', color: '#e0e0e0', fontSize: '11px' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="space-y-1.5 text-xs pt-2 border-t border-[#2d3035]">
            {typeDistribution.map((item) => (
              <div key={item.name} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <span className="w-2 h-2 rounded-sm" style={{ backgroundColor: item.color }} />
                  <span className="text-[#888] text-[11px]">{item.name}</span>
                </div>
                <span className="font-mono font-bold text-white text-[11px]">{item.value.toLocaleString()} MT</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Facility Filter & Search Toolbar */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-3 bg-[#0c0e12] p-2.5 rounded-sm border border-[#2d3035]">
        <div className="flex items-center space-x-2 overflow-x-auto w-full md:w-auto">
          <span className="text-[10px] text-[#666] font-mono uppercase font-bold tracking-widest px-1 flex items-center space-x-1">
            <Filter className="w-3 h-3" />
            <span>Farm Type:</span>
          </span>
          {['ALL', 'VERTICAL_HYDROPONIC', 'SEMI_CLOSED_CEA_GREENHOUSE', 'AUTONOMOUS_PRECISION_FIELD'].map((type) => (
            <button
              key={type}
              onClick={() => setFilterType(type)}
              className={`px-2.5 py-1 text-[11px] font-mono rounded-sm transition-all cursor-pointer ${
                filterType === type 
                  ? 'bg-[#1a1c1e] text-[#00ff66] font-bold border border-[#00ff66]/40 shadow-[0_0_5px_rgba(0,255,102,0.2)]' 
                  : 'text-[#888] hover:text-[#e0e0e0] hover:bg-[#1a1c1e]'
              }`}
            >
              {type === 'ALL' ? 'All (9)' : type.replace(/_/g, ' ')}
            </button>
          ))}
        </div>

        <input
          id="facility-search-input"
          type="text"
          placeholder="Filter facilities by name or state..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full md:w-64 bg-[#08090b] border border-[#2d3035] rounded-sm px-3 py-1 text-xs font-mono text-[#e0e0e0] focus:outline-none focus:border-[#00ff66]"
        />
      </div>

      {/* 9 US Facility Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {filteredFacilities.map((fac) => {
          return (
            <div
              key={fac.facilityId}
              id={`facility-card-${fac.facilityId.toLowerCase()}`}
              className="bg-[#0c0e12] border border-[#2d3035] hover:border-[#00ff66]/50 rounded-sm p-4 transition-all flex flex-col justify-between group"
            >
              <div>
                {/* Facility Header */}
                <div className="flex items-start justify-between mb-2 pb-2 border-b border-[#2d3035]">
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="text-[10px] font-mono font-bold text-[#00ff66] bg-[#00ff66]/10 px-1.5 py-0.5 rounded-sm border border-[#00ff66]/30">
                        {fac.facilityId}
                      </span>
                      <span className="text-[11px] text-[#888] font-mono">
                        {fac.state}
                      </span>
                    </div>
                    <h4 className="text-sm font-bold text-white font-mono mt-1">
                      {fac.name}
                    </h4>
                    <p className="text-[11px] text-[#666] flex items-center space-x-1 mt-0.5">
                      <MapPin className="w-3 h-3 text-[#666]" />
                      <span>{fac.locationName}</span>
                    </p>
                  </div>

                  <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded-sm font-bold uppercase ${
                    fac.farmType === 'VERTICAL_HYDROPONIC' ? 'bg-[#00ff66]/10 text-[#00ff66] border border-[#00ff66]/30' :
                    fac.farmType === 'SEMI_CLOSED_CEA_GREENHOUSE' ? 'bg-[#00ccff]/10 text-[#00ccff] border border-[#00ccff]/30' :
                    'bg-[#ffaa00]/10 text-[#ffaa00] border border-[#ffaa00]/30'
                  }`}>
                    {fac.farmType.replace(/_/g, ' ')}
                  </span>
                </div>

                {/* Key Facility Telemetry Specs */}
                <div className="grid grid-cols-2 gap-2 my-3 text-xs font-mono bg-[#111317] p-2.5 rounded-sm border border-[#2d3035]">
                  <div>
                    <span className="text-[9px] text-[#666] block uppercase tracking-widest">Annual Run Rate</span>
                    <span className="text-[#00ff66] font-bold text-sm">
                      {fac.currentAnnualRunRateMt.toLocaleString()} <span className="text-[9px] font-normal text-[#666]">MT</span>
                    </span>
                  </div>
                  <div>
                    <span className="text-[9px] text-[#666] block uppercase tracking-widest">Unit Cost</span>
                    <span className="text-[#ffaa00] font-bold text-sm">
                      ${fac.unitCostPerKgUsd.toFixed(2)} <span className="text-[9px] font-normal text-[#666]">/kg</span>
                    </span>
                  </div>
                  <div>
                    <span className="text-[9px] text-[#666] block uppercase tracking-widest">Clean Power</span>
                    <span className="text-[#00ccff] font-bold">
                      {(fac.energySystem.solarGenerationMw + fac.energySystem.windGenerationMw).toFixed(1)} MW
                    </span>
                  </div>
                  <div>
                    <span className="text-[9px] text-[#666] block uppercase tracking-widest">Water Recycled</span>
                    <span className="text-[#00ccff] font-bold">
                      {fac.waterSystem.waterRecoveryRatePct.toFixed(1)}%
                    </span>
                  </div>
                </div>

                {/* Operations & Automation Footprint */}
                <div className="space-y-1 text-[11px] text-[#888] font-mono">
                  <div className="flex justify-between">
                    <span className="text-[#666]">Growing Area:</span>
                    <span className="text-[#e0e0e0]">
                      {fac.growingAreaSqM > 100000 
                        ? `${(fac.growingAreaSqM / 4046.86).toFixed(0)} Acres` 
                        : `${fac.growingAreaSqM.toLocaleString()} m²`}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#666]">Fleet Active:</span>
                    <span className="text-[#e0e0e0]">
                      {fac.autonomousRobotsCount} CEA / {fac.machineryFleetCount} Field
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#666]">Cold Storage:</span>
                    <span className="text-[#e0e0e0]">
                      {fac.coldStorage.currentInventoryMt} / {fac.coldStorageCapacityMt} MT
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-[#666]">Twin Sync Error:</span>
                    <span className="text-[#00ff66] font-bold">
                      ±{fac.digitalTwinDivergenceScorePct}% (Nominal)
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-3 pt-2.5 border-t border-[#2d3035] flex items-center space-x-2">
                <button
                  id={`select-fac-btn-${fac.facilityId.toLowerCase()}`}
                  onClick={() => onSelectFacility(fac.facilityId)}
                  className="flex-1 px-3 py-1.5 bg-[#00ff66]/10 border border-[#00ff66]/30 hover:bg-[#00ff66]/20 text-[#00ff66] rounded-sm text-xs font-mono font-bold flex items-center justify-center space-x-1 transition-all cursor-pointer"
                >
                  <span>INSPECT TELEMETRY</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => {
                    onSelectFacility(fac.facilityId);
                    onNavigateTab('VERTICAL_HYDROPONICS');
                  }}
                  className="px-2.5 py-1.5 bg-[#1a1c1e] hover:bg-[#25282c] text-[#888] hover:text-[#e0e0e0] rounded-sm text-xs border border-[#2d3035] cursor-pointer"
                  title="Direct to Hydroponics Racks"
                >
                  <Layers className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
