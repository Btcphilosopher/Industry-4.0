/**
 * TerraForge Industrial AgriTech Operating System
 * Agronomic AI Copilot & Systems Engineering Assistant View
 */

import React, { useState } from 'react';
import { 
  Sparkles, 
  Send, 
  Bot, 
  Cpu, 
  Activity, 
  CheckCircle2, 
  RotateCw, 
  Lightbulb, 
  Layers, 
  Zap, 
  Droplets,
  BookOpen
} from 'lucide-react';
import { queryAgronomyCopilot } from '../../services/api';
import { Facility } from '../../types/agritech';

interface AgronomicCopilotViewProps {
  facilities: Facility[];
  selectedFacilityId: string;
}

interface Message {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  source?: string;
}

export const AgronomicCopilotView: React.FC<AgronomicCopilotViewProps> = ({
  facilities,
  selectedFacilityId
}) => {
  const currentFacility = facilities.find(f => f.facilityId === selectedFacilityId) || facilities[0];

  const [inputPrompt, setInputPrompt] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome-msg',
      sender: 'assistant',
      text: `Hello Chief Agronomist & Systems Engineer. I am the TerraForge Agronomic AI Systems Copilot.\n\nI have real-time access to the **${currentFacility.name}** telemetry streams (${currentFacility.farmType}), including our closed-loop water balance, LED DLI schedules, R-statistical yield models, and wholesale electricity arbitrage engines.\n\nHow can I assist your crop physiology, climate optimization, or unit economics today?`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      source: 'gemini-3.7-flash'
    }
  ]);

  const presetQueries = [
    {
      label: 'Albion Strawberry Brix Optimization',
      prompt: 'What photobiological DLI, red/far-red ratio, and diurnal temperature drop (°C) maximize Brix sugar accumulation and crown yield in Albion strawberries?'
    },
    {
      label: 'Tipburn Prevention & Ca++ Mass-Flow',
      prompt: 'Diagnose inner leaf tipburn in fast-growing Butterhead lettuce under 250 µmol/m²/s LED lighting. How should we adjust VPD, airflow velocity across canopy boundary layers, and Ca(NO3)2 dosing?'
    },
    {
      label: 'ERCOT Peak Tariff Load Shaving',
      prompt: 'Formulate an optimal microgrid response for our Texas facility when ERCOT real-time LMP exceeds $180/MWh. Detail chiller pre-cooling, BESS discharge rate, and LED dimming thresholds without dropping DLI below 16 mol/m²/day.'
    },
    {
      label: 'Closed-Loop RO Brine Chemistry',
      prompt: 'Detail the chemical mass balance and pH neutralization strategy for recycling 97%+ of nutrient solution in closed-loop vertical hydroponics without sodium accumulation or trace mineral precipitation.'
    }
  ];

  const handleSendMessage = async (customPrompt?: string) => {
    const textToSend = customPrompt || inputPrompt;
    if (!textToSend.trim() || isLoading) return;

    const userMessage: Message = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMessage]);
    setInputPrompt('');
    setIsLoading(true);

    try {
      const result = await queryAgronomyCopilot({
        prompt: textToSend,
        context: {
          facilityId: currentFacility.facilityId,
          facilityName: currentFacility.name,
          farmType: currentFacility.farmType,
          annualRunRateMt: currentFacility.currentAnnualRunRateMt,
          energyIntensity: currentFacility.energySystem.energyIntensityKwhPerKg,
          waterRecoveryPct: currentFacility.waterSystem.waterRecoveryRatePct,
          unitCostKg: currentFacility.unitCostPerKgUsd,
          isoMarket: currentFacility.energySystem.isoMarket
        }
      });

      const assistantMessage: Message = {
        id: `ast-${Date.now()}`,
        sender: 'assistant',
        text: result.response,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        source: result.source
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm">
        <div>
          <div className="flex items-center space-x-2 text-[10px] font-mono text-[#00ccff] uppercase tracking-[0.2em] font-bold mb-1">
            <Sparkles className="w-3.5 h-3.5 text-[#00ccff]" />
            <span>Industrial AI Agronomist & Systems Engineering Assistant</span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight font-mono">
            AGRONOMIC AI COPILOT & SYSTEMS INTELLIGENCE
          </h2>
          <p className="text-xs text-[#888] mt-0.5 font-mono">
            Powered by Google Gemini with live facility telemetry injection, crop physiology models & wholesale electricity market context.
          </p>
        </div>

        <div className="flex items-center space-x-2 text-xs font-mono text-[#00ccff] bg-[#111317] border border-[#2d3035] px-3 py-1.5 rounded-sm">
          <Bot className="w-3.5 h-3.5 text-[#00ccff]" />
          <span>Active Context: <strong className="text-white">{currentFacility.name}</strong></span>
        </div>
      </div>

      {/* Preset Engineering Prompts */}
      <div className="space-y-2">
        <span className="text-[10px] font-mono text-[#888] uppercase tracking-wider font-semibold flex items-center space-x-1.5">
          <Lightbulb className="w-3.5 h-3.5 text-[#ffaa00]" />
          <span>Recommended Industrial Engineering Inquiries:</span>
        </span>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-2.5">
          {presetQueries.map((query, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(query.prompt)}
              className="text-left p-2.5 rounded-sm bg-[#0c0e12] hover:bg-[#111317] border border-[#2d3035] hover:border-[#00ccff]/50 transition-all text-xs group cursor-pointer"
            >
              <div className="font-bold text-white font-mono group-hover:text-[#00ccff] transition-colors text-[11px]">
                {query.label}
              </div>
              <div className="text-[10px] text-[#888] mt-1 line-clamp-2 font-mono">
                {query.prompt}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Interactive Chat Console */}
      <div className="bg-[#0c0e12] border border-[#2d3035] rounded-sm flex flex-col h-[500px] overflow-hidden">
        {/* Messages Scroll Area */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3 font-sans">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div className="flex items-center space-x-2 mb-1 text-[10px] font-mono text-[#666]">
                <span>{msg.sender === 'user' ? 'Operating Engineer' : 'TerraForge Agronomic AI'}</span>
                <span>•</span>
                <span>{msg.timestamp}</span>
                {msg.source && (
                  <span className="bg-[#00ccff]/10 text-[#00ccff] border border-[#00ccff]/30 px-1.5 py-0.2 rounded-sm text-[9px] font-mono">
                    {msg.source}
                  </span>
                )}
              </div>

              <div
                className={`p-3.5 rounded-sm text-xs leading-relaxed max-w-3xl whitespace-pre-wrap font-mono ${
                  msg.sender === 'user'
                    ? 'bg-[#00ff66]/15 text-[#e0e0e0] border border-[#00ff66]/40'
                    : 'bg-[#111317] text-[#e0e0e0] border border-[#2d3035]'
                }`}
              >
                {msg.text}
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex items-center space-x-2 text-xs font-mono text-[#00ccff] bg-[#111317] p-2.5 rounded-sm border border-[#2d3035] w-max">
              <RotateCw className="w-3.5 h-3.5 animate-spin text-[#00ccff]" />
              <span>Analyzing crop physiology & microgrid telemetry in Gemini...</span>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-[#08090b] border-t border-[#2d3035]">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center space-x-2.5"
          >
            <input
              id="copilot-input-field"
              type="text"
              placeholder="Ask the Agronomic AI Copilot regarding crop recipes, lighting schedules, nutrient formulations, or microgrid optimization..."
              value={inputPrompt}
              onChange={(e) => setInputPrompt(e.target.value)}
              disabled={isLoading}
              className="flex-1 bg-[#111317] border border-[#2d3035] rounded-sm px-3.5 py-2 text-xs text-[#e0e0e0] placeholder-[#666] focus:outline-none focus:border-[#00ccff] transition-colors font-mono"
            />
            <button
              id="copilot-send-btn"
              type="submit"
              disabled={isLoading || !inputPrompt.trim()}
              className="px-3.5 py-2 bg-[#00ccff]/15 hover:bg-[#00ccff]/25 border border-[#00ccff]/50 text-[#00ccff] rounded-sm text-xs font-mono font-bold flex items-center space-x-1.5 transition-colors disabled:opacity-50 cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Inquire</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
