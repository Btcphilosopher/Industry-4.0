/**
 * TerraForge Industrial AgriTech Operating System
 * Rust Real-Time Telemetry, Fast PID Control Loops & Edge Actor Workers View
 */

import React, { useState, useEffect } from 'react';
import { 
  Cpu, 
  Activity, 
  Zap, 
  Radio, 
  Sliders, 
  Terminal, 
  ShieldCheck, 
  AlertCircle, 
  CheckCircle2, 
  Play, 
  RotateCw,
  Clock
} from 'lucide-react';
import { ResponsiveContainer, LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { 
  INITIAL_PID_LOOPS, 
  INITIAL_CAN_BUS_PACKETS, 
  INITIAL_PUMP_DIAGNOSTICS,
  PidLoopState,
  CanBusPacket,
  PumpVibrationDiagnostic
} from '../../data/rustEngineSimulation';
import { RustActorTelemetryEvent } from '../../types/agritech';

interface RustRealtimeEdgeViewProps {
  telemetryLogs: RustActorTelemetryEvent[];
}

export const RustRealtimeEdgeView: React.FC<RustRealtimeEdgeViewProps> = ({
  telemetryLogs
}) => {
  const [pidLoops, setPidLoops] = useState<PidLoopState[]>(INITIAL_PID_LOOPS);
  const [selectedLoopId, setSelectedLoopId] = useState<string>(INITIAL_PID_LOOPS[0].loopId);
  const [canPackets] = useState<CanBusPacket[]>(INITIAL_CAN_BUS_PACKETS);
  const [pumpDiagnostics] = useState<PumpVibrationDiagnostic[]>(INITIAL_PUMP_DIAGNOSTICS);

  const selectedPid = pidLoops.find(p => p.loopId === selectedLoopId) || pidLoops[0];

  // Modify PID parameters in real-time
  const updatePidParam = (param: 'kp' | 'ki' | 'kd' | 'setpoint', val: number) => {
    setPidLoops(prev => prev.map(p => {
      if (p.loopId === selectedLoopId) {
        const updated = { ...p, [param]: val };
        if (param === 'setpoint') {
          updated.error = parseFloat((updated.setpoint - updated.currentValue).toFixed(2));
        }
        return updated;
      }
      return p;
    }));
  };

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm">
        <div>
          <div className="flex items-center space-x-2 text-[10px] font-mono text-[#00ccff] uppercase tracking-[0.2em] font-bold mb-1">
            <Cpu className="w-3.5 h-3.5 text-[#00ccff]" />
            <span>Rust Actor Architecture • Tokio Async Runtime • Embedded CAN-Bus</span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight font-mono">
            RUST HIGH-FREQUENCY EDGE TELEMETRY & MACHINE CONTROL
          </h2>
          <p className="text-xs text-[#888] mt-0.5 font-mono">
            100Hz Actor-based sensor acquisition, sub-millisecond PID feedback loops, J1939 CAN frame decoders, and 1024-point FFT vibration diagnostics.
          </p>
        </div>

        <div className="flex items-center space-x-3 text-xs font-mono text-[#00ccff] bg-[#111317] px-3 py-1.5 rounded-sm border border-[#2d3035]">
          <Activity className="w-3.5 h-3.5 text-[#00ff66] animate-pulse" />
          <span>Edge Latency: <strong className="text-white">18.4 µs</strong></span>
        </div>
      </div>

      {/* Top Edge Subsystem KPI Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-[#0c0e12] border border-[#2d3035] p-3 rounded-sm">
          <div className="flex items-center justify-between text-[#888] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider">Tokio Worker Threads</span>
            <Cpu className="w-3.5 h-3.5 text-[#00ccff]" />
          </div>
          <div className="text-xl font-bold font-mono text-[#00ccff]">
            64 Threads <span className="text-xs font-normal text-[#888]">(0% Stalls)</span>
          </div>
          <div className="text-[10px] font-mono text-[#888] mt-1">
            Async MPSC: 1.2M msg/sec
          </div>
        </div>

        <div className="bg-[#0c0e12] border border-[#2d3035] p-3 rounded-sm">
          <div className="flex items-center justify-between text-[#888] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider">PID Loop Rate</span>
            <Activity className="w-3.5 h-3.5 text-[#00ff66]" />
          </div>
          <div className="text-xl font-bold font-mono text-[#00ff66]">
            100 Hz <span className="text-xs font-normal text-[#888]">(10ms tick)</span>
          </div>
          <div className="text-[10px] font-mono text-[#888] mt-1">
            Deterministic Scheduling
          </div>
        </div>

        <div className="bg-[#0c0e12] border border-[#2d3035] p-3 rounded-sm">
          <div className="flex items-center justify-between text-[#888] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider">CAN Bus J1939 Nodes</span>
            <Radio className="w-3.5 h-3.5 text-[#ffaa00]" />
          </div>
          <div className="text-xl font-bold font-mono text-[#ffaa00]">
            142 Nodes <span className="text-xs font-normal text-[#888]">Locked</span>
          </div>
          <div className="text-[10px] font-mono text-[#888] mt-1">
            0 Bus Errors • 43% Util
          </div>
        </div>

        <div className="bg-[#0c0e12] border border-[#2d3035] p-3 rounded-sm">
          <div className="flex items-center justify-between text-[#888] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider">FFT Bearing Diagnostic</span>
            <ShieldCheck className="w-3.5 h-3.5 text-[#00ff66]" />
          </div>
          <div className="text-xl font-bold font-mono text-[#00ff66]">
            ISO 10816-3 <span className="text-xs font-normal text-[#888]">Zone A</span>
          </div>
          <div className="text-[10px] font-mono text-[#888] mt-1">
            Zero Cavitation Anomaly
          </div>
        </div>
      </div>

      {/* Interactive PID Tuning Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* PID Loop Selector & Status */}
        <div className="bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm space-y-3">
          <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center space-x-2">
            <Sliders className="w-3.5 h-3.5 text-[#00ccff]" />
            <span>Active Fast PID Closed-Loops</span>
          </h3>

          <div className="space-y-2">
            {pidLoops.map((loop) => (
              <button
                key={loop.loopId}
                onClick={() => setSelectedLoopId(loop.loopId)}
                className={`w-full text-left p-2.5 rounded-sm border text-xs font-mono transition-colors cursor-pointer ${
                  selectedLoopId === loop.loopId
                    ? 'bg-[#00ccff]/15 border-[#00ccff]/50 text-white'
                    : 'bg-[#111317] border-[#2d3035] text-[#888] hover:text-[#e0e0e0]'
                }`}
              >
                <div className="flex justify-between font-bold text-white">
                  <span>{loop.name}</span>
                  <span className="text-[#00ccff]">{loop.samplingIntervalMs}ms</span>
                </div>
                <div className="flex justify-between text-[10px] text-[#888] mt-1">
                  <span>PV: <strong className="text-white">{loop.currentValue} {loop.unit}</strong></span>
                  <span>SP: <strong className="text-[#00ff66]">{loop.setpoint} {loop.unit}</strong></span>
                  <span>Out: <strong className="text-[#ffaa00]">{loop.controlOutputPct}%</strong></span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* PID Real-time Gains Tuning */}
        <div className="bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center space-x-2">
              <Cpu className="w-3.5 h-3.5 text-[#00ff66]" />
              <span>Rust Controller Gains</span>
            </h3>
            <span className="text-[9px] font-mono text-[#00ccff] bg-[#00ccff]/10 border border-[#00ccff]/30 px-1.5 py-0.5 rounded-sm">
              {selectedPid.loopId}
            </span>
          </div>

          <div className="space-y-2.5 text-xs font-mono">
            {/* Setpoint */}
            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-[#888]">Target Setpoint (SP)</span>
                <span className="text-[#00ff66] font-bold">{selectedPid.setpoint} {selectedPid.unit}</span>
              </div>
              <input
                type="range"
                min={selectedPid.setpoint * 0.7}
                max={selectedPid.setpoint * 1.3}
                step={0.1}
                value={selectedPid.setpoint}
                onChange={(e) => updatePidParam('setpoint', Number(e.target.value))}
                className="w-full h-1 bg-[#111317] rounded-sm appearance-none cursor-pointer accent-[#00ff66]"
              />
            </div>

            {/* Kp Proportional */}
            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-[#888]">Proportional Gain (Kp)</span>
                <span className="text-[#00ccff] font-bold">{selectedPid.kp}</span>
              </div>
              <input
                type="range"
                min={1}
                max={150}
                step={1}
                value={selectedPid.kp}
                onChange={(e) => updatePidParam('kp', Number(e.target.value))}
                className="w-full h-1 bg-[#111317] rounded-sm appearance-none cursor-pointer accent-[#00ccff]"
              />
            </div>

            {/* Ki Integral */}
            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-[#888]">Integral Gain (Ki)</span>
                <span className="text-[#818cf8] font-bold">{selectedPid.ki}</span>
              </div>
              <input
                type="range"
                min={0.1}
                max={25}
                step={0.1}
                value={selectedPid.ki}
                onChange={(e) => updatePidParam('ki', Number(e.target.value))}
                className="w-full h-1 bg-[#111317] rounded-sm appearance-none cursor-pointer accent-[#818cf8]"
              />
            </div>

            {/* Kd Derivative */}
            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-[#888]">Derivative Gain (Kd)</span>
                <span className="text-[#ffaa00] font-bold">{selectedPid.kd}</span>
              </div>
              <input
                type="range"
                min={0}
                max={20}
                step={0.1}
                value={selectedPid.kd}
                onChange={(e) => updatePidParam('kd', Number(e.target.value))}
                className="w-full h-1 bg-[#111317] rounded-sm appearance-none cursor-pointer accent-[#ffaa00]"
              />
            </div>
          </div>

          <div className="p-2.5 bg-[#111317] rounded-sm border border-[#2d3035] text-[10px] font-mono space-y-1">
            <div className="flex justify-between text-[#888]">
              <span>Instantaneous Error (e):</span>
              <span className="text-white font-bold">{selectedPid.error} {selectedPid.unit}</span>
            </div>
            <div className="flex justify-between text-[#888]">
              <span>Actuator Control Output:</span>
              <span className="text-[#00ff66] font-bold">{selectedPid.controlOutputPct}%</span>
            </div>
          </div>
        </div>

        {/* CAN-Bus Frame Decoder */}
        <div className="bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm space-y-3">
          <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center justify-between">
            <span className="flex items-center space-x-2">
              <Radio className="w-3.5 h-3.5 text-[#ffaa00]" />
              <span>CAN Bus J1939 Frame Stream</span>
            </span>
            <span className="text-[9px] font-mono text-[#00ff66] bg-[#00ff66]/10 border border-[#00ff66]/30 px-1.5 py-0.5 rounded-sm font-bold">
              250 KBPS
            </span>
          </h3>

          <div className="space-y-2 text-xs font-mono">
            {canPackets.map((pkt) => (
              <div key={pkt.canId} className="p-2 bg-[#111317] rounded-sm border border-[#2d3035] space-y-1">
                <div className="flex justify-between text-[#e0e0e0]">
                  <span className="text-[#ffaa00] font-bold">{pkt.canId}</span>
                  <span className="text-[#888]">{pkt.nodeName}</span>
                </div>
                <div className="text-[9px] text-[#666]">
                  RAW: <span className="text-[#888]">{pkt.payloadHex}</span>
                </div>
                <div className="text-[10px] text-[#00ff66] pt-1 border-t border-[#2d3035]">
                  {Object.entries(pkt.decodedMetrics).map(([k, v]) => (
                    <span key={k} className="mr-3">{k}: <strong>{v}</strong></span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* FFT Vibration Spectrum & Live Rust Actor Event Stream */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* 1024-Point FFT Spectrum */}
        <div className="bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm space-y-2.5">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center space-x-2">
                <Activity className="w-3.5 h-3.5 text-[#00ff66]" />
                <span>High-Pressure RO Pump Vibration FFT Spectrum</span>
              </h3>
              <p className="text-[11px] text-[#888]">1024-point real-time FFT for predictive bearing fatigue</p>
            </div>
            <span className="text-[10px] font-mono text-[#00ff66] font-bold">
              RMS: 1.42 mm/s (HEALTHY)
            </span>
          </div>

          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={pumpDiagnostics[0].fftSpectrum} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="2 2" stroke="#2d3035" opacity={0.6} />
                <XAxis dataKey="freqHz" stroke="#666" fontSize={10} label={{ value: 'Hz', position: 'insideBottom', offset: -5, fill: '#888', fontSize: 10 }} />
                <YAxis stroke="#666" fontSize={10} label={{ value: 'dB', angle: -90, position: 'insideLeft', fill: '#888', fontSize: 10 }} />
                <Tooltip contentStyle={{ backgroundColor: '#0c0e12', borderColor: '#2d3035', borderRadius: '2px', color: '#e0e0e0', fontSize: '11px' }} />
                <Bar dataKey="amplitudeDb" name="Amplitude (dB)" fill="#00ff66" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Live Rust Actor Telemetry Log Stream */}
        <div className="bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm space-y-2.5 flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center space-x-2 mb-2">
              <Terminal className="w-3.5 h-3.5 text-[#00ccff]" />
              <span>Rust Multi-Threaded Actor Telemetry Log</span>
            </h3>

            <div className="bg-[#08090b] p-2.5 rounded-sm border border-[#2d3035] font-mono text-xs space-y-1.5 h-52 overflow-y-auto">
              {telemetryLogs.slice(0, 7).map((log, idx) => (
                <div key={idx} className="flex items-start space-x-2 text-[#888] border-b border-[#1c1f24] pb-1 last:border-0">
                  <span className="text-[9px] text-[#666] shrink-0">[{log.latencyMicroseconds}µs]</span>
                  <span className="text-[9px] text-[#00ccff] font-bold shrink-0">T#{log.workerThreadId}</span>
                  <span className="text-[9px] text-[#ffaa00] font-bold shrink-0">{log.subsystem}</span>
                  <span className="text-[10px] text-[#e0e0e0]">{log.message}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between text-[11px] font-mono text-[#888] pt-2 border-t border-[#2d3035]">
            <span>Actor Supervisor: <strong className="text-[#00ff66]">ONE_FOR_ONE ACTIVE</strong></span>
            <span>Zero Unhandled Panics</span>
          </div>
        </div>
      </div>
    </div>
  );
};
