/**
 * TerraForge Industrial AgriTech Operating System
 * Enterprise Farm Economics, Unit Economics ($/kg) & Greenfield Siting View
 */

import React, { useState } from 'react';
import { 
  DollarSign, 
  TrendingUp, 
  Layers, 
  MapPin, 
  Building, 
  PieChart as PieIcon, 
  ArrowUpRight,
  Sliders,
  CheckCircle2
} from 'lucide-react';
import { ResponsiveContainer, LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { generateEconomiesOfScaleData, GREENFIELD_SITING_CANDIDATES } from '../../data/rEngineCalculations';

export const EconomicsInvestmentView: React.FC = () => {
  const [selectedSiteId, setSelectedSiteId] = useState<string>(GREENFIELD_SITING_CANDIDATES[0].id);
  const scalingData = generateEconomiesOfScaleData();

  // Cost Breakdown for standard Butterhead Lettuce ($1.42/kg)
  const unitCostBreakdown = [
    { name: 'Electricity (LED & HVAC)', cost: 0.44, color: '#ffaa00', pct: 31.0 },
    { name: 'Labor & Ops (Automated)', cost: 0.28, color: '#00ccff', pct: 19.7 },
    { name: 'Nutrients, Seeds & Substrates', cost: 0.22, color: '#00ff66', pct: 15.5 },
    { name: 'Facility Depreciation & CAPEX', cost: 0.30, color: '#818cf8', pct: 21.1 },
    { name: 'Packaging & Distribution', cost: 0.18, color: '#ec4899', pct: 12.7 }
  ];

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm">
        <div>
          <div className="flex items-center space-x-2 text-[10px] font-mono text-[#00ccff] uppercase tracking-[0.2em] font-bold mb-1">
            <DollarSign className="w-3.5 h-3.5 text-[#00ccff]" />
            <span>Corporate Capital Allocation & DCF Valuation Engine</span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight font-mono">
            UNIT ECONOMICS ($/KG), SCALING CURVES & GREENFIELD SITING
          </h2>
          <p className="text-xs text-[#888] mt-0.5 font-mono">
            Unit economics decomposition, 1 to 100 farm network scaling models, and automated site ranking by NPV, IRR & Levelized Cost.
          </p>
        </div>
      </div>

      {/* Top Financial Metric Badges */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-[#0c0e12] border border-[#2d3035] p-3 rounded-sm">
          <div className="flex items-center justify-between text-[#888] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider">Vertical Farm Unit Cost</span>
            <DollarSign className="w-3.5 h-3.5 text-[#00ff66]" />
          </div>
          <div className="text-xl font-bold font-mono text-[#00ff66]">
            $1.42 <span className="text-xs font-normal text-[#888]">/kg</span>
          </div>
          <div className="text-[10px] font-mono text-[#888] mt-1">
            Target: $0.98/kg at 50-farm
          </div>
        </div>

        <div className="bg-[#0c0e12] border border-[#2d3035] p-3 rounded-sm">
          <div className="flex items-center justify-between text-[#888] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider">Greenhouse Unit Cost</span>
            <DollarSign className="w-3.5 h-3.5 text-[#00ccff]" />
          </div>
          <div className="text-xl font-bold font-mono text-[#00ccff]">
            $1.25 <span className="text-xs font-normal text-[#888]">/kg</span>
          </div>
          <div className="text-[10px] font-mono text-[#888] mt-1">
            Semi-Closed Solar Boosted
          </div>
        </div>

        <div className="bg-[#0c0e12] border border-[#2d3035] p-3 rounded-sm">
          <div className="flex items-center justify-between text-[#888] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider">Average Project IRR</span>
            <TrendingUp className="w-3.5 h-3.5 text-[#ffaa00]" />
          </div>
          <div className="text-xl font-bold font-mono text-[#ffaa00]">
            24.8% <span className="text-xs font-normal text-[#888]">Unlevered</span>
          </div>
          <div className="text-[10px] font-mono text-[#888] mt-1">
            Payback: 4.1 Years
          </div>
        </div>

        <div className="bg-[#0c0e12] border border-[#2d3035] p-3 rounded-sm">
          <div className="flex items-center justify-between text-[#888] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider">Fleet Run-Rate EBITDA</span>
            <Building className="w-3.5 h-3.5 text-[#00ff66]" />
          </div>
          <div className="text-xl font-bold font-mono text-[#00ff66]">
            $58.4M <span className="text-xs font-normal text-[#888]">/yr</span>
          </div>
          <div className="text-[10px] font-mono text-[#888] mt-1">
            44.2% Margin
          </div>
        </div>
      </div>

      {/* Unit Cost Decomposition & Economies of Scale */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Unit Cost Breakdown ($1.42/kg) */}
        <div className="bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm space-y-3">
          <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center space-x-2">
            <PieIcon className="w-3.5 h-3.5 text-[#00ff66]" />
            <span>Unit Cost Decomposition: Hydroponic Butterhead ($1.42 / kg)</span>
          </h3>

          <div className="space-y-2.5 pt-1">
            {unitCostBreakdown.map((item) => (
              <div key={item.name} className="space-y-1 text-xs font-mono">
                <div className="flex justify-between text-[#888]">
                  <span>{item.name}:</span>
                  <div className="space-x-2">
                    <strong className="text-white">${item.cost.toFixed(2)}</strong>
                    <span className="text-[#666]">({item.pct}%)</span>
                  </div>
                </div>
                <div className="w-full bg-[#111317] rounded-sm h-1.5 border border-[#2d3035]">
                  <div 
                    className="h-1.5 rounded-sm" 
                    style={{ width: `${item.pct}%`, backgroundColor: item.color }} 
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="p-2.5 bg-[#111317] rounded-sm border border-[#2d3035] text-xs font-mono text-[#888] flex justify-between items-center">
            <span>Total COGS + SG&A:</span>
            <strong className="text-[#00ff66] text-sm font-bold">$1.42 / kg</strong>
          </div>
        </div>

        {/* Economies of Scale Curve (1 to 100 Farms) */}
        <div className="bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm space-y-2.5">
          <div>
            <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center space-x-2">
              <TrendingUp className="w-3.5 h-3.5 text-[#00ccff]" />
              <span>Economies of Scale: OPEX ($/kg) vs Total Network Size</span>
            </h3>
            <p className="text-[11px] text-[#888]">Modeled cost reduction from bulk procurement, centralized AI & robotics</p>
          </div>

          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={scalingData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="2 2" stroke="#2d3035" opacity={0.6} />
                <XAxis dataKey="numFarms" stroke="#666" fontSize={10} label={{ value: 'Facilities', position: 'insideBottom', offset: -5, fill: '#888', fontSize: 10 }} />
                <YAxis stroke="#666" fontSize={10} />
                <Tooltip contentStyle={{ backgroundColor: '#0c0e12', borderColor: '#2d3035', borderRadius: '2px', color: '#e0e0e0', fontSize: '11px' }} />
                <Line type="monotone" dataKey="opexPerKgUsd" name="OPEX ($/kg)" stroke="#00ff66" strokeWidth={2} dot={{ r: 3, fill: '#00ff66' }} />
                <Line type="monotone" dataKey="ebitdaMarginPct" name="EBITDA Margin (%)" stroke="#00ccff" strokeWidth={1.5} strokeDasharray="3 3" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Greenfield Site Siting & Capital Allocation Table */}
      <div className="bg-[#0c0e12] border border-[#2d3035] rounded-sm p-4 space-y-3">
        <div>
          <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center space-x-2">
            <MapPin className="w-3.5 h-3.5 text-[#ffaa00]" />
            <span>Greenfield Expansion Pipeline: Site Ranking by NPV & IRR</span>
          </h3>
          <p className="text-[11px] text-[#888]">Evaluates power tariffs, water rights, metropolitan access & construction CAPEX</p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-[#2d3035] text-[#666] uppercase text-[9px]">
                <th className="pb-2 font-semibold">Location & Candidate Site</th>
                <th className="pb-2 font-semibold">Power Rate (¢/kWh)</th>
                <th className="pb-2 font-semibold">Water Cost ($/kgal)</th>
                <th className="pb-2 font-semibold">Hub Distance</th>
                <th className="pb-2 font-semibold text-right">Required CAPEX</th>
                <th className="pb-2 font-semibold text-right">Project IRR</th>
                <th className="pb-2 font-semibold text-right">10-Yr NPV</th>
                <th className="pb-2 font-semibold text-center">Rank</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#2d3035]/60">
              {GREENFIELD_SITING_CANDIDATES.map((site) => (
                <tr 
                  key={site.id} 
                  onClick={() => setSelectedSiteId(site.id)}
                  className={`hover:bg-[#111317] transition-colors cursor-pointer ${
                    selectedSiteId === site.id ? 'bg-[#111317] border-l-2 border-[#00ff66]' : ''
                  }`}
                >
                  <td className="py-2.5 font-bold text-white">
                    {site.cityState}
                    <span className="block text-[9px] text-[#888] font-mono font-normal">{site.id}</span>
                  </td>
                  <td className="py-2.5 text-[#ffaa00] font-bold">{site.electricityRateCentsKwh.toFixed(1)}¢</td>
                  <td className="py-2.5 text-[#00ccff] font-bold">${site.waterCostPer1000GalUsd.toFixed(2)}</td>
                  <td className="py-2.5 text-[#888]">{site.freightDistanceToMajorHubKm} km</td>
                  <td className="py-2.5 text-right font-bold text-white">${site.projectedCapexMillionUsd.toFixed(1)}M</td>
                  <td className="py-2.5 text-right text-[#00ff66] font-bold">{site.projectedIrrPct.toFixed(1)}%</td>
                  <td className="py-2.5 text-right text-[#00ccff] font-bold">${site.projectedNpvMillionUsd.toFixed(1)}M</td>
                  <td className="py-2.5 text-center">
                    <span className="bg-[#00ff66]/10 text-[#00ff66] border border-[#00ff66]/30 px-1.5 py-0.5 rounded-sm font-bold text-[10px]">
                      #{site.compositeRank}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
