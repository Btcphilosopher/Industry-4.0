/**
 * TerraForge Industrial AgriTech Operating System
 * R Statistical Laboratory, Monte Carlo Risk Engine & Agronomic Modeling View
 */

import React, { useState } from 'react';
import { 
  Activity, 
  Sparkles, 
  BarChart3, 
  TrendingUp, 
  Sliders, 
  Play, 
  RotateCw, 
  Layers, 
  CheckCircle2, 
  FileText,
  ShieldAlert,
  Percent
} from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { runMonteCarloSimulation, generateYieldVsDliCurve, R_AND_D_TRIALS } from '../../data/rEngineCalculations';

export const RStatisticalLabView: React.FC = () => {
  const [iterations, setIterations] = useState<number>(5000);
  const [selectedTrialId, setSelectedTrialId] = useState<string>(R_AND_D_TRIALS[0].id);
  const [simResults, setSimResults] = useState(() => runMonteCarloSimulation(74.2, 14.5, 'National Revenue', 'Million USD', 5000));
  const [isRunningSim, setIsRunningSim] = useState<boolean>(false);

  // Re-run Monte Carlo simulation
  const handleExecuteMonteCarlo = () => {
    setIsRunningSim(true);
    setTimeout(() => {
      setSimResults(runMonteCarloSimulation(74.2, 14.5, 'National Revenue', 'Million USD', iterations));
      setIsRunningSim(false);
    }, 400);
  };

  const selectedTrial = R_AND_D_TRIALS.find(t => t.id === selectedTrialId) || R_AND_D_TRIALS[0];
  const yieldDliCurve = generateYieldVsDliCurve();

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm">
        <div>
          <div className="flex items-center space-x-2 text-[10px] font-mono text-[#00ccff] uppercase tracking-[0.2em] font-bold mb-1">
            <Activity className="w-3.5 h-3.5 text-[#00ccff]" />
            <span>R Statistical Engine • Bioconductor v4.4 • GNU R</span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight font-mono">
            R AGRONOMIC MODELING, STOCHASTIC RISK & EXPERIMENTATION
          </h2>
          <p className="text-xs text-[#888] mt-0.5 font-mono">
            Non-linear response surfaces, 5,000-run Monte Carlo P10/P50/P90 distributions, and multi-factor factorial ANOVA.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            id="run-monte-carlo-btn"
            onClick={handleExecuteMonteCarlo}
            disabled={isRunningSim}
            className="px-3 py-1.5 bg-[#00ccff]/15 hover:bg-[#00ccff]/25 border border-[#00ccff]/50 text-[#00ccff] rounded-sm text-xs font-mono font-bold flex items-center space-x-2 transition-colors disabled:opacity-50 cursor-pointer"
          >
            {isRunningSim ? <RotateCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
            <span>{isRunningSim ? 'Solving in R...' : 'Run Monte Carlo (R)'}</span>
          </button>
        </div>
      </div>

      {/* Monte Carlo Risk & Confidence Intervals (P10, P50, P90) */}
      <div className="bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center space-x-2">
              <ShieldAlert className="w-3.5 h-3.5 text-[#ffaa00]" />
              <span>National Monte Carlo Stochastic Risk & Revenue ({simResults.simulationsRun.toLocaleString()} Iterations)</span>
            </h3>
            <p className="text-[11px] text-[#888]">
              Accounts for electricity LMP volatility, weather anomalies, disease risk factor (2.4%), and spot price shocks
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <span className="text-[11px] text-[#888] font-mono">Iterations:</span>
            <select
              value={iterations}
              onChange={(e) => setIterations(Number(e.target.value))}
              className="bg-[#1a1c1e] text-xs font-mono text-[#e0e0e0] border border-[#2d3035] rounded-sm px-2.5 py-1 focus:outline-none"
            >
              <option value={1000} className="bg-[#0c0e12]">1,000 Iterations</option>
              <option value={5000} className="bg-[#0c0e12]">5,000 Iterations (Standard)</option>
              <option value={10000} className="bg-[#0c0e12]">10,000 Iterations (Deep)</option>
            </select>
          </div>
        </div>

        {/* P10 / P50 / P90 Metric Badges */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="bg-[#111317] p-3.5 rounded-sm border border-[#ff4444]/30">
            <div className="flex items-center justify-between text-[#ff4444] mb-1">
              <span className="text-[10px] font-bold uppercase font-mono">P10 (Bear Case)</span>
              <span className="text-[9px] font-mono bg-[#ff4444]/10 text-[#ff4444] px-1.5 py-0.5 rounded-sm border border-[#ff4444]/30">90% Exceed</span>
            </div>
            <div className="text-xl font-bold font-mono text-white">
              ${simResults.p10}M <span className="text-xs font-normal text-[#888]">Rev</span>
            </div>
            <div className="text-[11px] font-mono text-[#888] mt-1.5 space-y-0.5">
              <div>Std Dev: <strong className="text-white">±${simResults.standardDeviation}M</strong></div>
              <div>Tail Loss Prob (&lt;85%): <strong className="text-[#ff4444]">{simResults.riskOfLossPct}%</strong></div>
            </div>
          </div>

          <div className="bg-[#111317] p-3.5 rounded-sm border border-[#00ccff]/30">
            <div className="flex items-center justify-between text-[#00ccff] mb-1">
              <span className="text-[10px] font-bold uppercase font-mono">P50 (Median Expected)</span>
              <span className="text-[9px] font-mono bg-[#00ccff]/10 text-[#00ccff] px-1.5 py-0.5 rounded-sm border border-[#00ccff]/30">50% Exceed</span>
            </div>
            <div className="text-xl font-bold font-mono text-[#00ccff]">
              ${simResults.p50}M <span className="text-xs font-normal text-[#888]">Rev</span>
            </div>
            <div className="text-[11px] font-mono text-[#888] mt-1.5 space-y-0.5">
              <div>Run-Rate: <strong className="text-white">44,450 MT/yr</strong></div>
              <div>EBITDA Margin: <strong className="text-[#00ccff]">44.2%</strong></div>
            </div>
          </div>

          <div className="bg-[#111317] p-3.5 rounded-sm border border-[#00ff66]/30">
            <div className="flex items-center justify-between text-[#00ff66] mb-1">
              <span className="text-[10px] font-bold uppercase font-mono">P90 (Bull Case)</span>
              <span className="text-[9px] font-mono bg-[#00ff66]/10 text-[#00ff66] px-1.5 py-0.5 rounded-sm border border-[#00ff66]/30">10% Exceed</span>
            </div>
            <div className="text-xl font-bold font-mono text-[#00ff66]">
              ${simResults.p90}M <span className="text-xs font-normal text-[#888]">Rev</span>
            </div>
            <div className="text-[11px] font-mono text-[#888] mt-1.5 space-y-0.5">
              <div>Upside: <strong className="text-white">+22.4% Revenue</strong></div>
              <div>Peak EBITDA: <strong className="text-[#00ff66]">51.8%</strong></div>
            </div>
          </div>
        </div>

        {/* Histogram of Revenue Outcomes */}
        <div className="h-52 pt-1">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={simResults.histogram} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="2 2" stroke="#2d3035" opacity={0.6} />
              <XAxis dataKey="bin" stroke="#666" fontSize={10} tickFormatter={(val) => `$${val}M`} />
              <YAxis stroke="#666" fontSize={10} />
              <Tooltip contentStyle={{ backgroundColor: '#0c0e12', borderColor: '#2d3035', borderRadius: '2px', color: '#e0e0e0', fontSize: '11px' }} />
              <Bar dataKey="frequency" name="Simulation Frequency" fill="#00ccff" radius={[2, 2, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Yield vs DLI Response Surface & Factorial ANOVA Trials */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Yield Response Surface */}
        <div className="bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm space-y-2.5">
          <div>
            <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center space-x-2">
              <TrendingUp className="w-3.5 h-3.5 text-[#00ff66]" />
              <span>Agronomic Light Response Curve (Yield vs DLI)</span>
            </h3>
            <p className="text-[11px] text-[#888]">Non-linear Michaelis-Menten & saturation model computed in R</p>
          </div>

          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={yieldDliCurve} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="2 2" stroke="#2d3035" opacity={0.6} />
                <XAxis dataKey="dli" stroke="#666" fontSize={10} label={{ value: 'DLI (mol/m²/day)', position: 'insideBottom', offset: -5, fill: '#888', fontSize: 10 }} />
                <YAxis stroke="#666" fontSize={10} />
                <Tooltip contentStyle={{ backgroundColor: '#0c0e12', borderColor: '#2d3035', borderRadius: '2px', color: '#e0e0e0', fontSize: '11px' }} />
                <Line type="monotone" dataKey="yieldKgM2" name="Yield (kg/m²)" stroke="#00ff66" strokeWidth={2} dot={{ r: 2.5, fill: '#00ff66' }} />
                <Line type="monotone" dataKey="efficiencyPct" name="Efficiency %" stroke="#00ccff" strokeWidth={1.5} strokeDasharray="3 3" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Factorial ANOVA Experimental Trials */}
        <div className="bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm space-y-3 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center space-x-2">
                <FileText className="w-3.5 h-3.5 text-[#00ccff]" />
                <span>Factorial ANOVA Experimental Trials</span>
              </h3>
              <select
                value={selectedTrialId}
                onChange={(e) => setSelectedTrialId(e.target.value)}
                className="bg-[#1a1c1e] text-xs font-mono text-[#e0e0e0] border border-[#2d3035] rounded-sm px-2 py-1 max-w-[200px] focus:outline-none"
              >
                {R_AND_D_TRIALS.map((t) => (
                  <option key={t.id} value={t.id} className="bg-[#0c0e12]">{t.trialName}</option>
                ))}
              </select>
            </div>

            {/* Trial Details */}
            <div className="p-2.5 bg-[#111317] rounded-sm border border-[#2d3035] text-xs font-mono space-y-1.5">
              <div className="text-[#888]">
                <span className="text-[#666] block text-[9px] uppercase">Trial Name</span>
                <span className="font-bold text-white font-mono">{selectedTrial.trialName}</span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-[#888] pt-1 text-[11px]">
                <div>Cultivar: <span className="text-white">{selectedTrial.cultivar}</span></div>
                <div>Sample Size: <span className="text-white">N = {selectedTrial.sampleSizeN}</span></div>
                <div>Effect Size (Cohen's d): <span className="text-[#00ff66] font-bold">{selectedTrial.effectSizeCohenD}</span></div>
                <div>P-Value: <span className="text-[#00ff66] font-bold">p = {selectedTrial.pValue}</span></div>
              </div>
            </div>

            {/* Treatment Groups Comparison */}
            <div className="mt-2 space-y-1">
              <span className="text-[10px] font-bold text-[#888] font-mono block uppercase">Control vs Treatment Comparison:</span>
              <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                <div className="bg-[#111317] p-2 rounded-sm border border-[#2d3035] space-y-0.5">
                  <span className="text-[9px] text-[#888] block uppercase font-bold">Control</span>
                  <div className="text-[#888] text-[10px]">{selectedTrial.controlSpec.description}</div>
                  <div className="text-white font-bold mt-1 text-[11px]">Mean: {selectedTrial.controlSpec.meanYieldGramsPerPlant}g/plant</div>
                  <div className="text-[#666] text-[9px]">Brix: {selectedTrial.controlSpec.meanBrix}° • {selectedTrial.controlSpec.energyKwhPerKg} kWh/kg</div>
                </div>

                <div className="bg-[#00ff66]/5 p-2 rounded-sm border border-[#00ff66]/30 space-y-0.5">
                  <span className="text-[9px] text-[#00ff66] block uppercase font-bold">Treatment</span>
                  <div className="text-[#888] text-[10px]">{selectedTrial.treatmentSpec.description}</div>
                  <div className="text-[#00ff66] font-bold mt-1 text-[11px]">Mean: {selectedTrial.treatmentSpec.meanYieldGramsPerPlant}g (+{selectedTrial.yieldDeltaPct}%)</div>
                  <div className="text-[#666] text-[9px]">Brix: {selectedTrial.treatmentSpec.meanBrix}° • {selectedTrial.treatmentSpec.energyKwhPerKg} kWh/kg</div>
                </div>
              </div>
            </div>
          </div>

          <div className="p-2.5 bg-[#00ccff]/10 border border-[#00ccff]/30 rounded-sm text-xs font-mono text-[#00ccff] flex items-center justify-between">
            <span>Annual EBITDA Impact: <strong className="text-[#00ff66]">+${selectedTrial.annualizedEbitdaImpactUsdPerM2}/m²</strong></span>
            <span className="bg-[#00ff66]/10 text-[#00ff66] border border-[#00ff66]/30 px-1.5 py-0.5 rounded-sm font-bold uppercase text-[9px]">
              {selectedTrial.recommendation.replace(/_/g, ' ')}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
