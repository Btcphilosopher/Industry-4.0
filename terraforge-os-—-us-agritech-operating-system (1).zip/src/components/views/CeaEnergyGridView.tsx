/**
 * TerraForge Industrial AgriTech Operating System
 * Energy Management & US Wholesale Electricity Market Optimization View
 */

import React, { useState } from 'react';
import { 
  Zap, 
  Sun, 
  Wind, 
  BatteryCharging, 
  TrendingDown, 
  TrendingUp, 
  DollarSign, 
  Clock, 
  Activity, 
  CheckCircle2, 
  AlertTriangle,
  Sliders,
  ShieldAlert
} from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { Facility } from '../../types/agritech';

interface CeaEnergyGridViewProps {
  facilities: Facility[];
  selectedFacilityId: string;
  onSelectFacility: (id: string) => void;
}

export const CeaEnergyGridView: React.FC<CeaEnergyGridViewProps> = ({
  facilities,
  selectedFacilityId,
  onSelectFacility
}) => {
  const currentFacility = facilities.find(f => f.facilityId === selectedFacilityId) || facilities[0];
  const energy = currentFacility.energySystem;

  // Interactive Microgrid Dispatch Controls
  const [bessMode, setBessMode] = useState<'AUTO_ARBITRAGE' | 'PEAK_SHAVING' | 'MANUAL_DISCHARGE' | 'CHARGE_SOLAR'>('AUTO_ARBITRAGE');
  const [curtailmentThresholdMwh, setCurtailmentThresholdMwh] = useState<number>(65.0);
  const [preCoolingEnabled, setPreCoolingEnabled] = useState<boolean>(true);
  const [lightingDimmingPct, setLightingDimmingPct] = useState<number>(0);

  // 24-Hour ISO Spot Price & Microgrid Load Dispatch Profile
  const hourlyEnergyProfile = [
    { hour: '00:00', spotPrice: 28.5, solarGen: 0, windGen: energy.windGenerationMw * 1.1, gridImport: 3.2, hvacLoad: 2.8, ledLoad: 4.8, bessPower: -0.8 },
    { hour: '02:00', spotPrice: 24.2, solarGen: 0, windGen: energy.windGenerationMw * 1.2, gridImport: 3.4, hvacLoad: 2.6, ledLoad: 4.8, bessPower: -1.2 },
    { hour: '04:00', spotPrice: 22.0, solarGen: 0, windGen: energy.windGenerationMw * 1.0, gridImport: 3.5, hvacLoad: 2.6, ledLoad: 4.8, bessPower: -1.0 },
    { hour: '06:00', spotPrice: 38.4, solarGen: energy.solarGenerationMw * 0.15, windGen: energy.windGenerationMw * 0.8, gridImport: 4.0, hvacLoad: 3.2, ledLoad: 4.8, bessPower: 0 },
    { hour: '08:00', spotPrice: 48.0, solarGen: energy.solarGenerationMw * 0.55, windGen: energy.windGenerationMw * 0.6, gridImport: 2.8, hvacLoad: 3.6, ledLoad: 4.8, bessPower: 0 },
    { hour: '10:00', spotPrice: 32.5, solarGen: energy.solarGenerationMw * 0.95, windGen: energy.windGenerationMw * 0.5, gridImport: 0.8, hvacLoad: 4.2, ledLoad: 4.8, bessPower: -2.0 },
    { hour: '12:00', spotPrice: 18.2, solarGen: energy.solarGenerationMw * 1.0, windGen: energy.windGenerationMw * 0.5, gridImport: -1.2, hvacLoad: 4.5, ledLoad: 4.8, bessPower: -3.5 },
    { hour: '14:00', spotPrice: 21.0, solarGen: energy.solarGenerationMw * 0.9, windGen: energy.windGenerationMw * 0.6, gridImport: 0.2, hvacLoad: 4.6, ledLoad: 4.8, bessPower: -2.0 },
    { hour: '16:00', spotPrice: 52.4, solarGen: energy.solarGenerationMw * 0.45, windGen: energy.windGenerationMw * 0.8, gridImport: 3.2, hvacLoad: 4.2, ledLoad: 4.8, bessPower: 1.5 },
    { hour: '18:00', spotPrice: 94.8, solarGen: energy.solarGenerationMw * 0.05, windGen: energy.windGenerationMw * 0.9, gridImport: 1.5, hvacLoad: 3.8, ledLoad: 3.2, bessPower: 3.8 }, // Peak price window: BESS discharge + light dimming
    { hour: '20:00', spotPrice: 82.0, solarGen: 0, windGen: energy.windGenerationMw * 1.1, gridImport: 2.1, hvacLoad: 3.4, ledLoad: 3.2, bessPower: 2.5 },
    { hour: '22:00', spotPrice: 42.0, solarGen: 0, windGen: energy.windGenerationMw * 1.2, gridImport: 3.8, hvacLoad: 2.9, ledLoad: 4.8, bessPower: 0 }
  ];

  // Calculated Financial Metrics
  const calculatedDailySavingsUsd = Math.round(energy.bessCapacityMwh * 42.5 + (energy.solarGenerationMw * 280));
  const renewableSelfConsumptionPct = Math.min(100, Math.round(((energy.solarGenerationMw + energy.windGenerationMw) / (energy.hvacDemandMw + energy.lightingDemandMw + energy.pumpDemandMw)) * 100));

  return (
    <div className="p-4 space-y-4 max-w-7xl mx-auto">
      {/* Header & Market Zone Designation */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm">
        <div>
          <div className="flex items-center space-x-2 text-[10px] font-mono text-[#ffaa00] uppercase tracking-[0.2em] font-bold mb-1">
            <Zap className="w-3.5 h-3.5 text-[#ffaa00]" />
            <span>Industrial Microgrid & US ISO Wholesale Arbitrage</span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight font-mono">
            ENERGY MANAGEMENT, BESS DISPATCH & ELECTRICITY MARKETS
          </h2>
          <p className="text-xs text-[#888] mt-0.5 font-mono">
            Interconnected ISO Market: <strong className="text-[#ffaa00]">{energy.isoMarket}</strong> • Facility: <strong className="text-white">{currentFacility.name}</strong>
          </p>
        </div>

        {/* Facility Selector */}
        <select
          id="energy-facility-select"
          value={currentFacility.facilityId}
          onChange={(e) => onSelectFacility(e.target.value)}
          className="bg-[#1a1c1e] text-xs font-mono text-[#e0e0e0] border border-[#2d3035] rounded-sm px-3 py-1.5 focus:outline-none cursor-pointer"
        >
          {facilities.map((fac) => (
            <option key={fac.facilityId} value={fac.facilityId} className="bg-[#0c0e12] text-[#e0e0e0]">
              {fac.facilityId} — {fac.name} ({fac.energySystem.isoMarket})
            </option>
          ))}
        </select>
      </div>

      {/* Primary Energy KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-[#0c0e12] border border-[#2d3035] p-3 rounded-sm">
          <div className="flex items-center justify-between text-[#888] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider">Spot Price (LMP)</span>
            <DollarSign className="w-3.5 h-3.5 text-[#ffaa00]" />
          </div>
          <div className="text-xl font-bold font-mono text-[#ffaa00]">
            ${energy.spotPriceMwh.toFixed(2)} <span className="text-[10px] font-normal text-[#666]">/MWh</span>
          </div>
          <div className="text-[10px] font-mono text-[#888] mt-1">
            Day-Ahead: <span className="text-white">${energy.dayAheadPriceMwh.toFixed(2)}</span>
          </div>
        </div>

        <div className="bg-[#0c0e12] border border-[#2d3035] p-3 rounded-sm">
          <div className="flex items-center justify-between text-[#888] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider">Energy Intensity</span>
            <Activity className="w-3.5 h-3.5 text-[#00ff66]" />
          </div>
          <div className="text-xl font-bold font-mono text-[#00ff66]">
            {energy.energyIntensityKwhPerKg} <span className="text-[10px] font-normal text-[#666]">kWh/kg</span>
          </div>
          <div className="text-[10px] font-mono text-[#888] mt-1">
            Benchmark: <span className="text-[#666]">12.5 kWh/kg</span>
          </div>
        </div>

        <div className="bg-[#0c0e12] border border-[#2d3035] p-3 rounded-sm">
          <div className="flex items-center justify-between text-[#888] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider">BESS Charge</span>
            <BatteryCharging className="w-3.5 h-3.5 text-[#00ccff]" />
          </div>
          <div className="text-xl font-bold font-mono text-[#00ccff]">
            {energy.bessStateOfChargePct.toFixed(1)}% <span className="text-[10px] font-normal text-[#666]">({energy.bessCapacityMwh} MWh)</span>
          </div>
          <div className="text-[10px] font-mono text-[#888] mt-1">
            LiFePO4 4-Hour Pack
          </div>
        </div>

        <div className="bg-[#0c0e12] border border-[#2d3035] p-3 rounded-sm">
          <div className="flex items-center justify-between text-[#888] mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider">Renewable Fraction</span>
            <Sun className="w-3.5 h-3.5 text-[#00ff66]" />
          </div>
          <div className="text-xl font-bold font-mono text-[#00ff66]">
            {renewableSelfConsumptionPct}% <span className="text-[10px] font-normal text-[#666]">Self-Gen</span>
          </div>
          <div className="text-[10px] font-mono text-[#888] mt-1">
            Arbitrage: <strong className="text-[#00ff66]">+${calculatedDailySavingsUsd}/d</strong>
          </div>
        </div>
      </div>

      {/* Microgrid Load Breakdown & BESS Inverter Actuation */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Subsystem Power Demand Breakdown */}
        <div className="bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm space-y-3">
          <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center justify-between">
            <span className="flex items-center space-x-2">
              <Zap className="w-3.5 h-3.5 text-[#ffaa00]" />
              <span>Real-Time Power Demand</span>
            </span>
            <span className="text-[11px] font-mono text-[#00ccff] font-bold">
              Total: {(energy.hvacDemandMw + energy.lightingDemandMw + energy.pumpDemandMw + energy.coldStorageDemandMw).toFixed(1)} MW
            </span>
          </h3>

          <div className="space-y-2.5 text-xs font-mono">
            <div>
              <div className="flex justify-between text-[#888] mb-1">
                <span>LED Spectral Lighting:</span>
                <strong className="text-[#ffaa00]">{energy.lightingDemandMw.toFixed(1)} MW</strong>
              </div>
              <div className="w-full bg-[#111317] rounded-sm h-1.5 border border-[#2d3035]">
                <div 
                  className="bg-[#ffaa00] h-full rounded-sm" 
                  style={{ width: `${(energy.lightingDemandMw / (energy.lightingDemandMw + energy.hvacDemandMw + 1)) * 100}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-[#888] mb-1">
                <span>HVAC-D & Chiller Plants:</span>
                <strong className="text-[#00ccff]">{energy.hvacDemandMw.toFixed(1)} MW</strong>
              </div>
              <div className="w-full bg-[#111317] rounded-sm h-1.5 border border-[#2d3035]">
                <div 
                  className="bg-[#00ccff] h-full rounded-sm" 
                  style={{ width: `${(energy.hvacDemandMw / (energy.lightingDemandMw + energy.hvacDemandMw + 1)) * 100}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-[#888] mb-1">
                <span>Water Pumps & RO System:</span>
                <strong className="text-blue-400">{energy.pumpDemandMw.toFixed(1)} MW</strong>
              </div>
              <div className="w-full bg-[#111317] rounded-sm h-1.5 border border-[#2d3035]">
                <div className="bg-blue-400 h-full rounded-sm" style={{ width: '15%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-[#888] mb-1">
                <span>Cold Storage Refrigeration:</span>
                <strong className="text-indigo-400">{energy.coldStorageDemandMw.toFixed(1)} MW</strong>
              </div>
              <div className="w-full bg-[#111317] rounded-sm h-1.5 border border-[#2d3035]">
                <div className="bg-indigo-400 h-full rounded-sm" style={{ width: '10%' }} />
              </div>
            </div>
          </div>

          <div className="p-2.5 bg-[#08090b] rounded-sm border border-[#2d3035] text-[10px] font-mono space-y-1">
            <div className="flex justify-between text-[#888]">
              <span>On-Site Solar Gen:</span>
              <span className="text-[#00ff66] font-bold">+{energy.solarGenerationMw.toFixed(1)} MW</span>
            </div>
            <div className="flex justify-between text-[#888]">
              <span>On-Site Wind Gen:</span>
              <span className="text-[#00ff66] font-bold">+{energy.windGenerationMw.toFixed(1)} MW</span>
            </div>
            <div className="flex justify-between text-[#888] pt-1 border-t border-[#2d3035] font-bold">
              <span>Net Grid Import:</span>
              <span className={energy.totalNetDemandMw >= 0 ? 'text-[#ffaa00]' : 'text-[#00ff66]'}>
                {energy.totalNetDemandMw.toFixed(1)} MW
              </span>
            </div>
          </div>
        </div>

        {/* BESS Battery Storage Dispatch Control */}
        <div className="bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm space-y-3">
          <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center justify-between">
            <span className="flex items-center space-x-2">
              <BatteryCharging className="w-3.5 h-3.5 text-[#00ccff]" />
              <span>BESS Fast-Inverter Mode</span>
            </span>
            <span className="text-[9px] font-mono bg-[#00ccff]/10 text-[#00ccff] border border-[#00ccff]/30 px-1.5 py-0.5 rounded-sm">
              5ms RAMP
            </span>
          </h3>

          <div className="grid grid-cols-2 gap-2">
            {[
              { id: 'AUTO_ARBITRAGE', label: 'Auto ISO Arbitrage', desc: 'Discharge during tariff spikes' },
              { id: 'PEAK_SHAVING', label: 'Peak Shaving', desc: 'Caps grid MW demand' },
              { id: 'CHARGE_SOLAR', label: 'Solar Charge', desc: 'Absorbs mid-day solar' },
              { id: 'MANUAL_DISCHARGE', label: 'Island Backup', desc: 'Dispatches 100% battery' }
            ].map((mode) => (
              <button
                key={mode.id}
                onClick={() => setBessMode(mode.id as any)}
                className={`p-2 rounded-sm border text-left transition-colors cursor-pointer ${
                  bessMode === mode.id
                    ? 'bg-[#1a1c1e] border-l-2 border-[#00ccff] border-[#2d3035] text-white shadow-sm'
                    : 'bg-[#111317] border border-[#2d3035] text-[#888] hover:text-white hover:bg-[#1a1c1e]'
                }`}
              >
                <div className="text-xs font-bold font-mono text-white">{mode.label}</div>
                <div className="text-[9px] text-[#666] mt-0.5">{mode.desc}</div>
              </button>
            ))}
          </div>

          {/* Curtailment Threshold Slider */}
          <div className="space-y-1 pt-1">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-[#888]">Price Spike Cut-Off</span>
              <span className="text-[#ffaa00] font-bold">${curtailmentThresholdMwh}/MWh</span>
            </div>
            <input
              type="range"
              min={40}
              max={150}
              step={5}
              value={curtailmentThresholdMwh}
              onChange={(e) => setCurtailmentThresholdMwh(Number(e.target.value))}
              className="w-full h-1 bg-[#1a1c1e] rounded-sm appearance-none cursor-pointer accent-[#ffaa00]"
            />
            <p className="text-[9px] text-[#666] font-mono">
              When spot price exceeds this value, non-critical lighting dims by 25% and BESS discharges.
            </p>
          </div>

          <div className="p-2 bg-[#00ff66]/5 border border-[#00ff66]/20 rounded-sm text-[10px] font-mono text-[#888] flex items-center justify-between">
            <span>Agronomic Interlock:</span>
            <strong className="text-[#00ff66]">ACTIVE (DLI ≥ 16.0)</strong>
          </div>
        </div>

        {/* Demand Response & PPA Contract Status */}
        <div className="bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm space-y-3 flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center space-x-2 mb-2">
              <ShieldAlert className="w-3.5 h-3.5 text-[#00ff66]" />
              <span>PPA Hedging & Tariff Structure</span>
            </h3>

            <div className="space-y-1.5 text-xs font-mono">
              <div className="flex justify-between bg-[#111317] p-2 rounded-sm border border-[#2d3035]">
                <span className="text-[#666]">PPA Rate:</span>
                <span className="font-bold text-white">${energy.ppaContractPriceMwh.toFixed(2)}/MWh</span>
              </div>
              <div className="flex justify-between bg-[#111317] p-2 rounded-sm border border-[#2d3035]">
                <span className="text-[#666]">Demand Charge:</span>
                <span className="font-bold text-white">${energy.demandChargeRateKw.toFixed(2)}/kW-mo</span>
              </div>
              <div className="flex justify-between bg-[#111317] p-2 rounded-sm border border-[#2d3035]">
                <span className="text-[#666]">Thermal Pre-Cooling:</span>
                <span className="font-bold text-[#00ccff]">ACTIVE</span>
              </div>
              <div className="flex justify-between bg-[#111317] p-2 rounded-sm border border-[#2d3035]">
                <span className="text-[#666]">Interconnect Cap:</span>
                <span className="font-bold text-[#00ff66]">{currentFacility.energyCapacityMw} MW Substation</span>
              </div>
            </div>
          </div>

          <div className="p-2.5 bg-[#08090b] rounded-sm border border-[#2d3035] text-[10px]">
            <span className="text-[#666] block mb-1 font-mono uppercase text-[9px]">Agronomic Integrity Rule</span>
            <p className="text-[#888] text-[10px] leading-relaxed font-mono">
              "Never sacrifice crop biomass or photobiological DLI to save energy costs. Optimization occurs strictly via diurnal shifting and BESS arbitrage."
            </p>
          </div>
        </div>
      </div>

      {/* 24-Hour Electricity Price & Microgrid Dispatch Curve */}
      <div className="bg-[#0c0e12] border border-[#2d3035] p-4 rounded-sm">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider flex items-center space-x-2">
              <Activity className="w-3.5 h-3.5 text-[#ffaa00]" />
              <span>24-Hour ISO Spot Price vs Solar Generation & BESS Arbitrage (MW)</span>
            </h3>
            <p className="text-[11px] text-[#888]">Real-time load balancing and peak tariff dispatch profile</p>
          </div>
          <div className="flex items-center space-x-4 text-[10px] font-mono text-[#888]">
            <span className="flex items-center space-x-1.5">
              <span className="w-2 h-2 rounded-sm bg-[#ffaa00]" />
              <span>Spot LMP ($/MWh)</span>
            </span>
            <span className="flex items-center space-x-1.5">
              <span className="w-2 h-2 rounded-sm bg-[#00ff66]" />
              <span>Solar PV (MW)</span>
            </span>
            <span className="flex items-center space-x-1.5">
              <span className="w-2 h-2 rounded-sm bg-[#00ccff]" />
              <span>BESS Power (MW)</span>
            </span>
          </div>
        </div>

        <div className="h-56">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={hourlyEnergyProfile} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="colorSolar" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#00ff66" stopOpacity={0.4}/>
                  <stop offset="95%" stopColor="#00ff66" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="2 2" stroke="#2d3035" opacity={0.6} />
              <XAxis dataKey="hour" stroke="#666" fontSize={10} />
              <YAxis stroke="#666" fontSize={10} />
              <Tooltip contentStyle={{ backgroundColor: '#0c0e12', borderColor: '#2d3035', borderRadius: '2px', color: '#e0e0e0', fontSize: '11px' }} />
              <Area type="monotone" dataKey="solarGen" name="Solar Gen (MW)" stroke="#00ff66" strokeWidth={1.5} fillOpacity={1} fill="url(#colorSolar)" />
              <Line type="monotone" dataKey="spotPrice" name="Spot Price ($/MWh)" stroke="#ffaa00" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="bessPower" name="BESS Dispatch (MW)" stroke="#00ccff" strokeWidth={1.5} strokeDasharray="3 3" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
