/**
 * TerraForge Industrial AgriTech Operating System - Header
 */

import React from 'react';
import { 
  Activity, 
  Zap, 
  Droplets, 
  Cpu, 
  ShieldCheck, 
  Play, 
  Pause, 
  RotateCw,
  TrendingUp,
  MapPin
} from 'lucide-react';
import { Facility } from '../../types/agritech';

interface HeaderProps {
  facilities: Facility[];
  selectedFacilityId: string;
  onSelectFacility: (id: string) => void;
  isSimulating: boolean;
  onToggleSimulate: () => void;
  simSpeed: number;
  onChangeSimSpeed: (speed: number) => void;
  telemetryTickCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  facilities,
  selectedFacilityId,
  onSelectFacility,
  isSimulating,
  onToggleSimulate,
  simSpeed,
  onChangeSimSpeed,
  telemetryTickCount
}) => {
  const selectedFacility = facilities.find(f => f.facilityId === selectedFacilityId) || facilities[0];

  // Calculate national aggregates
  const totalProductionMt = facilities.reduce((sum, f) => sum + f.currentAnnualRunRateMt, 0);
  const totalNetMw = facilities.reduce((sum, f) => sum + f.energySystem.totalNetDemandMw, 0);
  const avgWaterRecovery = facilities.reduce((sum, f) => sum + f.waterSystem.waterRecoveryRatePct, 0) / facilities.length;
  const avgUnitCost = facilities.reduce((sum, f) => sum + f.unitCostPerKgUsd, 0) / facilities.length;

  return (
    <header className="bg-[#0c0e12] border-b border-[#2d3035] text-[#e0e0e0] sticky top-0 z-50">
      {/* Top ISO/RTO Wholesale Market Ticker Bar */}
      <div className="bg-[#08090b] px-4 py-1.5 border-b border-[#2d3035] flex items-center justify-between text-[11px] font-mono text-[#888] overflow-x-auto">
        <div className="flex items-center space-x-6 min-w-max">
          <div className="flex items-center space-x-1.5">
            <span className="inline-block w-2 h-2 rounded-full bg-[#00ff66] shadow-[0_0_6px_#00ff66] animate-pulse" />
            <span className="text-[#e0e0e0] font-bold tracking-wider">US ISO SPOT TELEMETRY:</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-[#666]">CAISO (NP15):</span>
            <span className="text-[#00ff66] font-bold">$34.50/MWh</span>
            <span className="text-[#00ff66] text-[10px]">▼ -3.2%</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-[#666]">ERCOT (South):</span>
            <span className="text-[#ffaa00] font-bold">$58.90/MWh</span>
            <span className="text-[#ffaa00] text-[10px]">▲ +4.8%</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-[#666]">PJM (ComEd):</span>
            <span className="text-[#00ff66] font-bold">$42.80/MWh</span>
            <span className="text-[#00ff66] text-[10px]">▼ -1.5%</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-[#666]">MISO (Zone 3):</span>
            <span className="text-[#00ccff] font-bold">$18.40/MWh</span>
            <span className="text-[#00ccff] text-[10px]">▼ -8.4% (Wind Curtailment)</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-[#666]">NYISO (Zone G):</span>
            <span className="text-[#ffaa00] font-bold">$52.40/MWh</span>
            <span className="text-[#ffaa00] text-[10px]">▲ +2.1%</span>
          </div>
        </div>

        <div className="flex items-center space-x-4 min-w-max pl-4 text-[10px]">
          <div className="flex items-center space-x-1 text-[#888]">
            <Cpu className="w-3.5 h-3.5 text-[#00ccff]" />
            <span>RUST EDGE: <strong className="text-[#00ccff]">100Hz ACTORS</strong></span>
          </div>
          <div className="flex items-center space-x-1 text-[#888]">
            <Activity className="w-3.5 h-3.5 text-[#00ff66]" />
            <span>R ENGINE: <strong className="text-[#00ff66]">BIOCONDUCTOR v4.4</strong></span>
          </div>
        </div>
      </div>

      {/* Main Operating Header */}
      <div className="px-6 py-3 flex items-center justify-between gap-4">
        {/* Brand & Corporate Designation */}
        <div className="flex items-center gap-4">
          <div className="w-8 h-8 bg-[#00ff66] flex items-center justify-center rounded-sm shadow-[0_0_10px_rgba(0,255,102,0.4)]">
            <span className="text-black font-black text-xl">T</span>
          </div>
          <div className="flex flex-col">
            <span className="text-[10px] uppercase tracking-[0.2em] text-[#00ff66] font-bold">
              US Agritech Corp
            </span>
            <div className="flex items-center space-x-2">
              <span className="text-lg font-mono tracking-tighter text-white font-bold">
                TERRAFORGE // INDUSTRIAL STACK v4.8
              </span>
              <span className="text-[9px] font-mono bg-[#00ff66]/10 text-[#00ff66] border border-[#00ff66]/30 px-1.5 py-0.5 rounded-sm">
                RUST-RT-KERN
              </span>
            </div>
          </div>
        </div>

        {/* National Performance Metrics Ribbon */}
        <div className="hidden lg:flex items-center space-x-6 bg-[#08090b] border border-[#2d3035] rounded-sm px-4 py-2">
          <div className="text-left">
            <span className="text-[9px] text-[#666] uppercase tracking-widest block font-mono">National Output</span>
            <span className="text-sm font-bold font-mono text-[#00ff66]">
              {totalProductionMt.toLocaleString()} <span className="text-[10px] text-[#666]">MT/yr</span>
            </span>
          </div>
          <div className="h-6 w-px bg-[#2d3035]" />
          <div className="text-left">
            <span className="text-[9px] text-[#666] uppercase tracking-widest block font-mono">Net Power Demand</span>
            <span className="text-sm font-bold font-mono text-[#ffaa00]">
              {totalNetMw.toFixed(1)} <span className="text-[10px] text-[#666]">MW</span>
            </span>
          </div>
          <div className="h-6 w-px bg-[#2d3035]" />
          <div className="text-left">
            <span className="text-[9px] text-[#666] uppercase tracking-widest block font-mono">Water Closed-Loop</span>
            <span className="text-sm font-bold font-mono text-[#00ccff]">
              {avgWaterRecovery.toFixed(1)}% <span className="text-[10px] text-[#666]">Recycled</span>
            </span>
          </div>
          <div className="h-6 w-px bg-[#2d3035]" />
          <div className="text-left">
            <span className="text-[9px] text-[#666] uppercase tracking-widest block font-mono">Weighted Unit Cost</span>
            <span className="text-sm font-bold font-mono text-white">
              ${avgUnitCost.toFixed(2)} <span className="text-[10px] text-[#666]">/kg</span>
            </span>
          </div>
        </div>

        {/* Facility Selector & Real-Time Engine Simulation Controls */}
        <div className="flex items-center space-x-3">
          {/* Facility Switcher */}
          <div className="flex items-center space-x-2 bg-[#1a1c1e] border border-[#2d3035] rounded-sm px-3 py-1.5">
            <MapPin className="w-3.5 h-3.5 text-[#00ff66]" />
            <select
              id="facility-switcher-select"
              value={selectedFacilityId}
              onChange={(e) => onSelectFacility(e.target.value)}
              className="bg-transparent text-xs font-mono text-[#e0e0e0] focus:outline-none cursor-pointer"
            >
              <option value="ALL" className="bg-[#0c0e12] text-[#e0e0e0]">ALL US FACILITIES (9 Hubs)</option>
              {facilities.map((fac) => (
                <option key={fac.facilityId} value={fac.facilityId} className="bg-[#0c0e12] text-[#e0e0e0]">
                  {fac.facilityId} — {fac.name} ({fac.state})
                </option>
              ))}
            </select>
          </div>

          {/* Simulation Toggle & Speed */}
          <div className="flex items-center space-x-1.5 bg-[#1a1c1e] border border-[#2d3035] rounded-sm p-1">
            <button
              id="telemetry-sim-toggle-btn"
              onClick={onToggleSimulate}
              className={`px-2.5 py-1 rounded-sm text-xs font-mono font-bold flex items-center space-x-1.5 transition-all cursor-pointer ${
                isSimulating 
                  ? 'bg-[#00ff66]/20 border border-[#00ff66]/40 text-[#00ff66] shadow-[0_0_8px_rgba(0,255,102,0.2)]' 
                  : 'bg-[#ffaa00]/20 border border-[#ffaa00]/40 text-[#ffaa00]'
              }`}
              title="Pause or resume live edge telemetry stream"
            >
              {isSimulating ? <Pause className="w-3 h-3 text-[#00ff66]" /> : <Play className="w-3 h-3 text-[#ffaa00]" />}
              <span>{isSimulating ? '100Hz STREAM' : 'PAUSED'}</span>
            </button>

            <select
              id="telemetry-speed-select"
              value={simSpeed}
              onChange={(e) => onChangeSimSpeed(Number(e.target.value))}
              className="bg-[#0c0e12] text-[11px] font-mono text-[#888] rounded-sm px-1.5 py-1 focus:outline-none border border-[#2d3035]"
            >
              <option value={1}>1x (Real-time)</option>
              <option value={5}>5x (Fast)</option>
              <option value={20}>20x (Stress)</option>
            </select>
          </div>
        </div>
      </div>
    </header>
  );
};
