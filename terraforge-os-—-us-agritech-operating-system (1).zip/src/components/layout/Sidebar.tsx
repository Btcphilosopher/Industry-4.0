/**
 * TerraForge Industrial AgriTech Operating System - Sidebar Navigation
 */

import React from 'react';
import {
  Globe,
  Layers,
  Zap,
  Droplets,
  Bot,
  Activity,
  Boxes,
  DollarSign,
  Cpu,
  Sparkles
} from 'lucide-react';

export type NavTabId =
  | 'NATIONAL_COMMAND'
  | 'VERTICAL_HYDROPONICS'
  | 'CEA_ENERGY_GRID'
  | 'CLOSED_LOOP_WATER'
  | 'ROBOTICS_MACHINERY'
  | 'R_STATISTICAL_LAB'
  | 'PRODUCTION_SUPPLY_CHAIN'
  | 'ECONOMICS_INVESTMENT'
  | 'RUST_REALTIME_EDGE'
  | 'AGRONOMIC_COPILOT';

interface SidebarProps {
  activeTab: NavTabId;
  onSelectTab: (tab: NavTabId) => void;
  activeAlarmsCount: number;
}

interface NavItem {
  id: NavTabId;
  label: string;
  sublabel: string;
  icon: React.ComponentType<{ className?: string }>;
  tag?: string;
  tagColor?: string;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  activeAlarmsCount
}) => {
  const navItems: NavItem[] = [
    {
      id: 'NATIONAL_COMMAND',
      label: 'National Fleet Ops',
      sublabel: '9 US Facilities & Telemetry',
      icon: Globe
    },
    {
      id: 'VERTICAL_HYDROPONICS',
      label: 'Vertical Racks & Agronomy',
      sublabel: 'LED Spectra, DLI, Dosing & VPD',
      icon: Layers,
      tag: 'CEA',
      tagColor: 'bg-[#00ff66]/10 text-[#00ff66] border-[#00ff66]/30'
    },
    {
      id: 'CEA_ENERGY_GRID',
      label: 'Energy & ISO Arbitrage',
      sublabel: 'Solar, Wind, BESS & CAISO/ERCOT',
      icon: Zap,
      tag: 'ISO',
      tagColor: 'bg-[#ffaa00]/10 text-[#ffaa00] border-[#ffaa00]/30'
    },
    {
      id: 'CLOSED_LOOP_WATER',
      label: 'Closed-Loop Water & RO',
      sublabel: 'Condensate & Mass Balance',
      icon: Droplets,
      tag: '96.8%',
      tagColor: 'bg-[#00ccff]/10 text-[#00ccff] border-[#00ccff]/30'
    },
    {
      id: 'ROBOTICS_MACHINERY',
      label: 'Robotics & Field Fleet',
      sublabel: 'Gantry Seeders & RTK Machinery',
      icon: Bot
    },
    {
      id: 'R_STATISTICAL_LAB',
      label: 'R-Stats & Monte Carlo',
      sublabel: 'P10/50/90, ANOVA & Yield Curves',
      icon: Activity,
      tag: 'R v4.4',
      tagColor: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/30'
    },
    {
      id: 'PRODUCTION_SUPPLY_CHAIN',
      label: 'Production & Cold Chain',
      sublabel: 'LP Solver & Distribution Matrix',
      icon: Boxes
    },
    {
      id: 'ECONOMICS_INVESTMENT',
      label: 'Unit Econ & Greenfield Siting',
      sublabel: '1-100 Farm Scale & DCF NPV',
      icon: DollarSign
    },
    {
      id: 'RUST_REALTIME_EDGE',
      label: 'Rust Real-Time Systems',
      sublabel: '100Hz Actor Workers, PID & FFT',
      icon: Cpu,
      tag: 'Rust',
      tagColor: 'bg-[#00ff66]/10 text-[#00ff66] border-[#00ff66]/30'
    },
    {
      id: 'AGRONOMIC_COPILOT',
      label: 'Agronomic AI Copilot',
      sublabel: 'Gemini-Powered Diagnostics',
      icon: Sparkles,
      tag: 'AI',
      tagColor: 'bg-purple-500/10 text-purple-400 border-purple-500/30'
    }
  ];

  return (
    <aside className="w-64 bg-[#0c0e12] border-r border-[#2d3035] flex flex-col justify-between shrink-0 h-[calc(100vh-84px)] overflow-y-auto">
      <div className="p-3 space-y-1">
        <div className="text-[10px] text-[#666] uppercase mb-2 px-3 tracking-widest font-mono font-bold">
          Control Layers
        </div>

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              id={`nav-btn-${item.id.toLowerCase()}`}
              onClick={() => onSelectTab(item.id)}
              className={`w-full text-left px-3 py-2.5 rounded-sm flex items-start space-x-3 transition-all duration-150 group cursor-pointer ${
                isActive
                  ? 'bg-[#1a1c1e] border-l-2 border-[#00ff66] text-white shadow-sm'
                  : 'border-l-2 border-transparent text-[#888] hover:bg-[#1a1c1e]/60 hover:text-[#e0e0e0]'
              }`}
            >
              <div
                className={`p-1 rounded-sm mt-0.5 transition-colors ${
                  isActive
                    ? 'text-[#00ff66]'
                    : 'text-[#666] group-hover:text-[#888]'
                }`}
              >
                <Icon className="w-4 h-4" />
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className={`text-xs font-mono font-bold truncate ${isActive ? 'text-white' : 'text-[#bbb]'}`}>
                    {item.label}
                  </span>
                  {item.tag && (
                    <span
                      className={`text-[9px] font-mono px-1.5 py-0.2 rounded-sm border font-bold ${
                        item.tagColor || 'bg-[#1a1c1e] text-[#888] border-[#2d3035]'
                      }`}
                    >
                      {item.tag}
                    </span>
                  )}
                </div>
                <p className="text-[10px] text-[#666] truncate mt-0.5 font-sans">
                  {item.sublabel}
                </p>
              </div>
            </button>
          );
        })}
      </div>

      {/* Digital Twin Sync & Edge Status Footer */}
      <div className="p-3 m-3 bg-[#08090b] border border-[#2d3035] rounded-sm text-xs font-mono">
        <div className="flex items-center justify-between text-[#888] mb-1.5">
          <span className="text-[9px] uppercase font-bold tracking-widest text-[#666]">Digital Twin Sync</span>
          <span className="text-[#00ff66] text-[10px] font-bold">98.4%</span>
        </div>
        <div className="w-full bg-[#1a1c1e] h-1 rounded-full mb-3 overflow-hidden">
          <div className="bg-[#00ff66] h-1 w-[98.4%] shadow-[0_0_5px_#00ff66]" />
        </div>

        <div className="space-y-1 text-[10px] text-[#888] pt-2 border-t border-[#2d3035]">
          <div className="flex justify-between">
            <span className="text-[#666]">RUST BUFFER:</span>
            <span className="text-[#00ff66] font-bold">4.2ms LATENCY</span>
          </div>
          <div className="flex justify-between">
            <span className="text-[#666]">CAN J1939:</span>
            <span className="text-[#00ccff] font-bold">14.2k fps</span>
          </div>
          <div className="flex justify-between">
            <span className="text-[#666]">ACTIVE HUBS:</span>
            <span className="text-[#00ff66] font-bold">9 / 9 ONLINE</span>
          </div>
        </div>
      </div>
    </aside>
  );
};
