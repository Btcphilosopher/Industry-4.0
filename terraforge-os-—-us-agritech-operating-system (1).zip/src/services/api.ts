/**
 * TerraForge API & Engine Client Service
 */

export interface AgronomyCopilotPayload {
  prompt: string;
  context?: any;
}

export async function queryAgronomyCopilot(payload: AgronomyCopilotPayload): Promise<{ response: string; source: string }> {
  try {
    const res = await fetch('/api/agronomy/copilot', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });

    if (!res.ok) {
      throw new Error(`Server returned HTTP ${res.status}`);
    }

    return await res.json();
  } catch (error: any) {
    console.error('Failed to query agronomy copilot:', error);
    return {
      response: `[TerraForge Engine Offline Diagnostic]\nQuery: ${payload.prompt}\n\nAutomated Rule Assessment: In commercial CEA vertical hydroponics, maintain photoperiod DLI between 16–22 mol/m²/day, root-zone dissolved oxygen > 7.5 mg/L, and closed-loop HVAC condensate reclamation to achieve < 2.0 L/kg water intensity.`,
      source: 'offline-rule-engine'
    };
  }
}
