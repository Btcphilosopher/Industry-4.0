/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { CommodityMarket, LogisticsNode } from '../types';
import {
  TrendingUp,
  Truck,
  Database,
  ArrowRight,
  TrendingDown,
  AlertOctagon,
  RefreshCw,
  Sliders,
  DollarSign,
  CheckCircle2
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend
} from 'recharts';

interface EconomicsTerminalProps {
  markets: CommodityMarket[];
  logistics: LogisticsNode[];
  onRefresh: () => void;
}

export default function EconomicsTerminal({
  markets,
  logistics,
  onRefresh
}: EconomicsTerminalProps) {
  // Procurement optimization parameters
  const [procType, setProcType] = useState<'Diesel' | 'Urea' | 'Potash' | 'Seed'>('Diesel');
  const [procVolume, setProcVolume] = useState(15000); // gallons or tons
  const [procSupplier, setProcSupplier] = useState<'CHS' | 'Nutrien' | 'GROWMARK'>('CHS');
  const [procNpv, setProcNpv] = useState<any>(null);

  // Profit comparison data (R models output)
  const cropProfitData = [
    { crop: 'Corn', costPerAcre: 380, revenuePerAcre: 1008, marginPerAcre: 628 },
    { crop: 'Soybeans', costPerAcre: 240, revenuePerAcre: 713, marginPerAcre: 473 },
    { crop: 'Wheat', costPerAcre: 180, revenuePerAcre: 483, marginPerAcre: 303 },
    { crop: 'Cotton', costPerAcre: 410, revenuePerAcre: 684, marginPerAcre: 274 }
  ];

  // Run Procurement Optimizations
  const handleProcureOptimize = () => {
    // R procurement heuristic
    const baseUnitCost = procType === 'Diesel' ? 2.65 : procType === 'Urea' ? 420 : 380;
    const bulkDiscountPercent = procVolume > 20000 ? 8.5 : procVolume > 10000 ? 5.0 : 2.0;
    const calculatedTotal = procVolume * baseUnitCost * (1 - bulkDiscountPercent / 100);

    setProcNpv({
      baseUnitCost,
      bulkDiscountPercent,
      calculatedTotal: Math.round(calculatedTotal),
      freightCost: Math.round(procVolume * (procSupplier === 'CHS' ? 0.12 : 0.18)),
      deliveryETA: procSupplier === 'CHS' ? '3 Days' : '5 Days',
      decisionRecommendation: `R-Procurement Engine: Buy Urea nitrogen inputs immediately from ${procSupplier}. High-capacity inventories and standard autumn pricing curves indicate a localized spot low point.`
    });
  };

  return (
    <div id="economics-terminal" className="space-y-6">
      
      {/* 1. CBOT FUTURES TICKER & REAL-TIME BASIS */}
      <div className="bg-zinc-900/50 border border-zinc-800/80 rounded-xl p-4">
        <div className="flex items-center justify-between pb-3 border-b border-zinc-800 mb-4">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-indigo-400" />
            <h3 className="text-sm font-semibold uppercase tracking-wider text-white">
              CBOT Futures Market & Regional Basis Modifier
            </h3>
          </div>
          <button
            onClick={onRefresh}
            className="p-1 hover:bg-zinc-850 rounded text-zinc-400 hover:text-indigo-400 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Price grid cards */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          {markets.slice(0, 5).map((m) => {
            const isPos = m.dailyChangePercent >= 0;
            return (
              <div key={m.crop} className="bg-zinc-950 p-3.5 border border-zinc-800/80 rounded-lg font-mono">
                <span className="text-[10px] text-zinc-500 uppercase tracking-wide block">{m.crop} Futures</span>
                
                <div className="flex items-baseline gap-2 mt-1">
                  <span className="text-base font-bold text-zinc-100">
                    ${m.futuresPrice.toFixed(2)}
                  </span>
                  <span className={`text-[10px] font-bold flex items-center gap-0.5 ${isPos ? 'text-emerald-400' : 'text-red-400'}`}>
                    {isPos ? '+' : ''}{m.dailyChangePercent}%
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-zinc-900/50 text-[9px] text-zinc-400">
                  <div>
                    <span className="text-zinc-500 block">BASIS</span>
                    <span className="font-bold text-zinc-300">${m.basisPrice.toFixed(2)}</span>
                  </div>
                  <div>
                    <span className="text-zinc-500 block">SPOT PRICE</span>
                    <span className="font-bold text-zinc-100">${m.spotPrice.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 2. SUPPLY CHAIN BOTTLE-NECK SOLVER GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Logistics path map */}
        <div className="lg:col-span-8 bg-zinc-900/50 border border-zinc-800/80 rounded-xl p-5">
          <div className="flex items-center gap-2 pb-3 border-b border-zinc-800 mb-4">
            <Truck className="w-5 h-5 text-indigo-400" />
            <h3 className="text-sm font-semibold uppercase tracking-wider text-white">
              Farm-to-Market Logistics Flow Node Solver
            </h3>
          </div>

          <p className="text-xs text-zinc-400 mb-5 leading-relaxed font-mono">
            Evaluates freight networks. Solves Dijkstra-routing models across farm roads, regional grain terminals, and BNSF rail slots.
          </p>

          {/* Node diagram list */}
          <div className="space-y-3 font-mono text-xs">
            <div className="flex flex-wrap items-center gap-2 bg-zinc-950 p-3 border border-zinc-800/80 rounded-lg">
              <span className="font-bold text-indigo-400">FIELD LOGISTICS NODE CHAIN:</span>
              <span className="text-zinc-300">Lincoln Field (Combine 01)</span>
              <ArrowRight className="w-3.5 h-3.5 text-zinc-500" />
              <span className="text-zinc-300">Hercule Grain Cart (M-107)</span>
              <ArrowRight className="w-3.5 h-3.5 text-zinc-500" />
              <span className="text-zinc-300">Lincoln Bin (L-102)</span>
              <ArrowRight className="w-3.5 h-3.5 text-zinc-500" />
              <span className="text-indigo-400 font-bold">ADM Rapids Mill</span>
            </div>

            {/* Active logistics capacity levels */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-[11px]">
              {logistics.slice(0, 4).map(node => (
                <div key={node.id} className="bg-zinc-950 p-3 rounded-lg border border-zinc-800/80">
                  <span className="text-zinc-500 block uppercase text-[8px] tracking-wide">{node.type} node</span>
                  <span className="font-bold text-zinc-200 block mb-1">{node.name}</span>
                  <div className="flex justify-between text-[10px] text-zinc-400 mb-1">
                    <span>CAPACITY:</span>
                    <span>{node.currentFillLevel}/{node.capacity} bu</span>
                  </div>
                  <div className="w-full h-1 bg-zinc-800 rounded overflow-hidden">
                    <div
                      className="h-full bg-indigo-500"
                      style={{ width: `${(node.currentFillLevel / node.capacity) * 100}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>

            {/* Active bottleneck finder widget */}
            <div className="bg-red-950/15 border border-red-900/30 p-3 rounded-lg flex items-start gap-3 mt-2">
              <AlertOctagon className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold uppercase tracking-wide text-red-400 text-[10px] block">ACTIVE BOTTLENECK DETECTED: GRAIN CART LOGISTICS</span>
                <p className="text-[11px] text-zinc-300 leading-relaxed mt-1">
                  Midwest Field Lincoln F1 combine harvesting speed is currently throttle-restricted by 14% because supporting Grain Cart Hercule-G301 is queued at Silo Bin 01.
                </p>
                <p className="text-[10px] text-zinc-500 mt-1 italic">
                  Recommendation: Deploy auxiliary transport truck T-01 from workshop yard to balance combined payloads.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Procurement inputs optimizer */}
        <div className="lg:col-span-4 bg-zinc-900/50 border border-zinc-800/80 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 pb-3 border-b border-zinc-800 mb-3">
              <Database className="w-5 h-5 text-indigo-400" />
              <h3 className="text-sm font-semibold uppercase tracking-wider text-white">
                R-Procurement Optimizer
              </h3>
            </div>

            <p className="text-xs text-zinc-400 mb-4 leading-relaxed font-mono">
              Calculate bulk input contract parameters. Simulates future pricing shock patterns to lock spot margins on fertilizers and fuels.
            </p>

            <form className="space-y-3 font-mono text-xs">
              <div>
                <label className="text-[10px] text-zinc-500 block mb-1">RAW CHEMICAL / INPUTS</label>
                <select
                  value={procType}
                  onChange={(e) => setProcType(e.target.value as any)}
                  className="w-full bg-zinc-950 border border-zinc-800/85 rounded p-1.5 text-zinc-100 focus:outline-none focus:border-indigo-500 cursor-pointer"
                >
                  <option value="Diesel">Diesel (Ag Grade)</option>
                  <option value="Urea">Urea (Dry Nitrogen)</option>
                  <option value="Potash">Potash (Dry Potassium)</option>
                  <option value="Seed">Row Crop Seed Stocks</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] text-zinc-500 block mb-1">VOLUME</label>
                  <input
                    type="number"
                    value={procVolume}
                    onChange={(e) => setProcVolume(Number(e.target.value))}
                    className="w-full bg-zinc-950 border border-zinc-800/85 rounded p-1.5 text-zinc-100 font-mono focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-zinc-500 block mb-1">WHOLESALE DISTRIB</label>
                  <select
                    value={procSupplier}
                    onChange={(e) => setProcSupplier(e.target.value as any)}
                    className="w-full bg-zinc-950 border border-zinc-800/85 rounded p-1.5 text-zinc-100 focus:outline-none focus:border-indigo-500 cursor-pointer"
                  >
                    <option value="CHS">CHS Inc.</option>
                    <option value="Nutrien">Nutrien Wholesalers</option>
                    <option value="GROWMARK">GROWMARK Supply</option>
                  </select>
                </div>
              </div>

              <button
                type="button"
                onClick={handleProcureOptimize}
                className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-semibold py-2 px-4 rounded transition-colors cursor-pointer"
              >
                Evaluate Purchase Contract
              </button>
            </form>
          </div>

          {procNpv ? (
            <div className="mt-4 bg-zinc-950 p-3 border border-zinc-800/80 rounded-lg space-y-2 font-mono text-xs text-zinc-300">
              <div className="flex justify-between">
                <span className="text-zinc-500">CONTRACT TOTAL:</span>
                <span className="font-bold text-indigo-400">${procNpv.calculatedTotal.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-[11px]">
                <span className="text-zinc-500">DISCOUNT MATRIX:</span>
                <span className="font-bold text-zinc-100">-{procNpv.bulkDiscountPercent}% BULK CONTRACT</span>
              </div>
              
              <div className="p-2 bg-zinc-900/30 rounded border border-zinc-800/80 text-[10px] text-zinc-400 leading-relaxed flex gap-1 items-start">
                <CheckCircle2 className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                <p>{procNpv.decisionRecommendation}</p>
              </div>
            </div>
          ) : (
            <div className="mt-4 border border-dashed border-zinc-800 rounded-lg p-5 text-center text-xs text-zinc-600 font-mono">
              Select procurement parameters to solve dynamic fertilizer pricing frontiers.
            </div>
          )}
        </div>

      </div>

      {/* 3. CROP PROFITABILITY CHART CORES */}
      <div className="bg-zinc-900/50 border border-zinc-800/80 rounded-xl p-5">
        <div className="flex items-center gap-2 pb-4 border-b border-zinc-800 mb-4">
          <TrendingUp className="w-5 h-5 text-indigo-400" />
          <h3 className="text-sm font-semibold uppercase tracking-wider text-white">
            Hedge-Fund Crop Net Margin and Cost Frontier Analysis
          </h3>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          
          <div className="lg:col-span-7 h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={cropProfitData}>
                <XAxis dataKey="crop" stroke="#71717a" fontSize={10} />
                <YAxis stroke="#71717a" fontSize={10} label={{ value: 'Cost vs Revenue ($ / acre)', angle: -90, position: 'insideLeft', fill: '#71717a', fontSize: 10 }} />
                <Tooltip contentStyle={{ background: '#09090b', border: '1px solid #27272a' }} />
                <Legend wrapperStyle={{ fontSize: 10 }} />
                <Bar dataKey="costPerAcre" fill="#52525b" name="Direct Cost/Acre ($)" />
                <Bar dataKey="marginPerAcre" fill="#4f46e5" name="Net Margin/Acre ($)" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="lg:col-span-5 bg-zinc-950 p-4 border border-zinc-800/80 rounded-lg space-y-3 font-mono text-xs text-zinc-400 leading-relaxed">
            <h4 className="text-xs font-bold text-zinc-200 uppercase pb-1 border-b border-zinc-900">Quant Macro Analysis</h4>
            <p>
              Expected financial margins are continuously calculated in R using joint-distribution equations from the **Chicago Board of Trade (CBOT)** alongside real-time localized energy indices.
            </p>
            <p>
              Currently, <span className="text-indigo-400 font-bold">Corn</span> indicates the highest net margin per acre ($628) at standard expected emergence velocities, but maintains double the direct nitrogen expenditure threshold compared to <span className="text-indigo-400 font-bold">Soybeans</span>.
            </p>
          </div>

        </div>
      </div>

    </div>
  );
}
