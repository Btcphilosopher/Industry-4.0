/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Machine, Field, LiveEvent, Mission } from '../types';
import {
  MapPin,
  Play,
  Pause,
  AlertTriangle,
  Send,
  Sliders,
  Radio,
  FileText,
  Shield,
  Compass,
  Zap,
  CheckCircle2,
  Lock
} from 'lucide-react';

interface OperationsTerminalProps {
  machines: Machine[];
  fields: Field[];
  events: LiveEvent[];
  onRefresh: () => void;
}

export default function OperationsTerminal({
  machines,
  fields,
  events,
  onRefresh
}: OperationsTerminalProps) {
  // Map zoom and details
  const [selectedField, setSelectedField] = useState<Field | null>(null);
  
  // Mission dispatch state
  const [targetFieldId, setTargetFieldId] = useState('');
  const [targetOp, setTargetOp] = useState<'Plant' | 'Spray' | 'Fertilize' | 'Irrigate' | 'Harvest' | 'Scout'>('Plant');
  const [targetPriority, setTargetPriority] = useState<'LOW' | 'MEDIUM' | 'HIGH'>('HIGH');
  const [targetRate, setTargetRate] = useState('');
  const [dispatchError, setDispatchError] = useState('');
  const [dispatchSuccess, setDispatchSuccess] = useState('');
  const [isDispatching, setIsDispatching] = useState(false);

  // Filter machines / events
  const [severityFilter, setSeverityFilter] = useState<'ALL' | 'INFO' | 'WARNING' | 'CRITICAL'>('ALL');

  // Submit new autonomous mission
  const handleDispatchMission = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetFieldId) {
      setDispatchError('Please select a target field');
      return;
    }
    setDispatchError('');
    setDispatchSuccess('');
    setIsDispatching(true);

    try {
      const fieldObj = fields.find(f => f.id === targetFieldId);
      const res = await fetch('/api/missions/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          farmId: fieldObj?.farmId || 'IA-01',
          fieldId: targetFieldId,
          operation: targetOp,
          priority: targetPriority,
          targetRate
        })
      });

      const data = await res.json();
      if (!res.ok) {
        setDispatchError(data.error || 'Failed to dispatch');
      } else {
        setDispatchSuccess(`Mission dispatched! Machine started execution.`);
        onRefresh();
      }
    } catch (err) {
      setDispatchError('Connection failure.');
    } finally {
      setIsDispatching(false);
    }
  };

  // Machinery individual safety override (Rust state machine intercept)
  const handleMachineOverride = async (machineId: string, targetState: 'RUNNING' | 'SAFE_STOP' | 'PAUSED' | 'READY') => {
    try {
      const res = await fetch('/api/machinery/override', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ machineId, state: targetState })
      });
      const data = await res.json();
      if (!res.ok) {
        alert(data.error || 'Command rejected by Safety Core.');
      }
      onRefresh();
    } catch (err) {
      console.error(err);
    }
  };

  // All fleet Emergency Stop
  const handleEmergencyStopAll = async () => {
    try {
      await fetch('/api/machinery/emergency-stop', { method: 'POST' });
      onRefresh();
    } catch (err) {
      console.error(err);
    }
  };

  // Filtered Events Log
  const filteredEvents = events.filter(ev => {
    if (severityFilter === 'ALL') return true;
    return ev.severity === severityFilter;
  });

  return (
    <div id="operations-terminal" className="space-y-6">
      
      {/* 1. MAP AND DISPATCH HEADER CONTROL */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* INTERACTIVE GEOSPATIAL MAP CANVAS */}
        <div className="lg:col-span-8 bg-zinc-900/50 border border-zinc-800/80 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between pb-3 border-b border-zinc-800 mb-3">
            <div className="flex items-center gap-2">
              <Compass className="w-5 h-5 text-indigo-400" />
              <h3 className="text-sm font-semibold uppercase tracking-wider text-white">
                Live Interactive Geospatial Map
              </h3>
            </div>
            <span className="text-[10px] font-mono text-emerald-400 animate-pulse flex items-center gap-1 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-900/60">
              <Radio className="w-3 h-3" /> RTK FIXED STATE
            </span>
          </div>

          <p className="text-xs text-zinc-400 mb-4 font-mono leading-relaxed">
            Click fields on the digital twin canvas to view telemetry and soil overlays. Hover over vehicles for telemetry.
          </p>

          {/* SVG Map Canvas */}
          <div className="relative w-full aspect-[4/3] bg-zinc-950 rounded-lg overflow-hidden border border-zinc-850/60 shadow-inner flex items-center justify-center">
            
            {/* Legend Overlay */}
            <div className="absolute top-3 left-3 bg-zinc-900/95 border border-zinc-800/80 p-2.5 rounded text-[9px] font-mono space-y-1 z-10 text-zinc-300">
              <div className="font-bold text-zinc-400 border-b border-zinc-800 pb-1 mb-1">FIELD CROPS</div>
              <div className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 bg-emerald-700/60 border border-emerald-500 rounded" /> Corn (Midwest)</div>
              <div className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 bg-green-800/60 border border-green-500 rounded" /> Soybeans (Midwest)</div>
              <div className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 bg-amber-600/60 border border-amber-500 rounded" /> Wheat (Great Plains)</div>
              <div className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 bg-blue-900/60 border border-blue-500 rounded" /> Cotton (Delta/Texas)</div>
              <div className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 bg-amber-700/60 border border-amber-500 rounded" /> Sorghum (S1)</div>
              <div className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 bg-purple-900/60 border border-purple-500 rounded" /> Orchards/Vineyards (CA)</div>
            </div>

            <svg viewBox="0 0 500 350" className="w-full h-full max-h-[420px] select-none">
              {/* Regional Grid Patterns */}
              <defs>
                <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
                  <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#27272a" strokeWidth="0.5" opacity="0.3" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)" />

              {/* Geofence Boundary Rivers / Drainage Canal outlines */}
              <path d="M 0 110 Q 120 120 200 200 T 500 300" fill="none" stroke="#3b82f6" strokeWidth="2.5" opacity="0.4" strokeDasharray="4,4" />
              <text x="350" y="275" fill="#1d4ed8" fontSize="8" className="font-mono">Geofenced Drainage Canal</text>

              {/* Draw Fields */}
              {fields.map((field) => {
                // Determine field color based on crop
                let fillColor = 'rgba(16, 185, 129, 0.15)'; // default green
                let strokeColor = '#10b981';
                
                if (field.currentCrop === 'Corn') {
                  fillColor = 'rgba(16, 185, 129, 0.2)';
                  strokeColor = '#10b981';
                } else if (field.currentCrop === 'Soybeans') {
                  fillColor = 'rgba(52, 211, 153, 0.15)';
                  strokeColor = '#34d399';
                } else if (field.currentCrop === 'Wheat') {
                  fillColor = 'rgba(245, 158, 11, 0.15)';
                  strokeColor = '#f59e0b';
                } else if (field.currentCrop === 'Cotton') {
                  fillColor = 'rgba(59, 130, 246, 0.15)';
                  strokeColor = '#3b82f6';
                } else if (field.currentCrop === 'Sorghum') {
                  fillColor = 'rgba(180, 83, 9, 0.15)';
                  strokeColor = '#b45309';
                } else {
                  fillColor = 'rgba(147, 51, 234, 0.15)';
                  strokeColor = '#9333ea';
                }

                // If currently executing an operation, pulsate outline
                const isOperating = field.currentOperation !== 'None';

                // Map vertices to SVG poly string
                const pointsString = field.boundary.map(p => `${p.x},${p.y}`).join(' ');

                return (
                  <g key={field.id} className="cursor-pointer group">
                    <polygon
                      points={pointsString}
                      fill={selectedField?.id === field.id ? 'rgba(99, 102, 241, 0.35)' : fillColor}
                      stroke={selectedField?.id === field.id ? '#6366f1' : strokeColor}
                      strokeWidth={selectedField?.id === field.id ? 2.5 : isOperating ? 1.5 : 1}
                      className="transition-all duration-200 group-hover:fill-opacity-50"
                      onClick={() => setSelectedField(field)}
                    />
                    <text
                      x={field.boundary[0].x + 5}
                      y={field.boundary[0].y + 15}
                      fill="#71717a"
                      fontSize="7"
                      className="font-mono opacity-80 pointer-events-none group-hover:opacity-100"
                    >
                      {field.id}
                    </text>
                  </g>
                );
              })}

              {/* Active Vehicles Coordinates Mapping */}
              {machines.map((machine) => {
                // Determine icon color based on autonomyState
                let markerColor = '#10b981'; // Green RUNNING
                if (machine.autonomyState === 'SAFE_STOP') markerColor = '#ef4444'; // Red EMERGENCY
                else if (machine.autonomyState === 'WAITING' || machine.autonomyState === 'PAUSED') markerColor = '#f59e0b'; // Amber
                else if (machine.autonomyState === 'READY') markerColor = '#71717a'; // Gray

                // Vector triangle for direction
                const rad = (machine.heading * Math.PI) / 180;
                const size = machine.type === 'Drone' ? 6 : 9;
                
                // Draw path tracking lines if active
                const hasMission = machine.autonomyState === 'RUNNING';

                return (
                  <g key={machine.id}>
                    {/* Pulsating safety zone for autonomous machines */}
                    {hasMission && (
                      <circle
                        cx={machine.position.x}
                        cy={machine.position.y}
                        r="12"
                        fill="none"
                        stroke={markerColor}
                        strokeWidth="0.5"
                        strokeDasharray="2,2"
                        className="animate-ping"
                        opacity="0.3"
                      />
                    )}

                    {/* Machine Point Indicator */}
                    <g
                      transform={`translate(${machine.position.x}, ${machine.position.y}) rotate(${machine.heading})`}
                      className="cursor-help"
                    >
                      {machine.type === 'Drone' ? (
                        // Drone Icon
                        <path
                          d="M -5 0 L 5 0 M 0 -5 L 0 5 M -4 -4 L 4 4"
                          stroke={markerColor}
                          strokeWidth="1.5"
                        />
                      ) : (
                        // Standard Heavy Tractor Arrow
                        <polygon
                          points={`0,-${size} ${size/1.5},${size/1.2} 0,${size/2} -${size/1.5},${size/1.2}`}
                          fill={markerColor}
                          stroke="#09090b"
                          strokeWidth="1"
                        />
                      )}
                    </g>
                    {/* Machine Mini Label */}
                    <text
                      x={machine.position.x + 8}
                      y={machine.position.y + 3}
                      fill="#e4e4e7"
                      fontSize="6"
                      className="font-mono bg-zinc-900 px-1 py-0.5 rounded pointer-events-none font-bold select-none"
                    >
                      {machine.name.split('-')[1] || machine.name}
                    </text>
                  </g>
                );
              })}
            </svg>

            {/* Selected Field Detail HUD */}
            {selectedField && (
              <div className="absolute bottom-3 right-3 left-3 bg-zinc-950/95 border border-zinc-800 p-3 rounded-lg z-10 flex flex-col justify-between shadow-2xl transition-all font-mono text-xs text-zinc-300">
                <div className="flex justify-between items-center pb-2 border-b border-zinc-900/60 mb-2">
                  <span className="font-bold text-zinc-100 flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-indigo-400" />
                    {selectedField.name} ({selectedField.id})
                  </span>
                  <button
                    onClick={() => setSelectedField(null)}
                    className="text-zinc-500 hover:text-zinc-200 cursor-pointer"
                  >
                    CLOSE
                  </button>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-[11px]">
                  <div>
                    <span className="text-zinc-500 block uppercase text-[9px]">Acreage</span>
                    <span className="font-bold">{selectedField.acres} acres</span>
                  </div>
                  <div>
                    <span className="text-zinc-500 block uppercase text-[9px]">Crop & Yield Est.</span>
                    <span className="font-bold text-indigo-400">{selectedField.currentCrop} ({selectedField.currentYieldEstimates || 'N/A'} bu/ac)</span>
                  </div>
                  <div>
                    <span className="text-zinc-500 block uppercase text-[9px]">Soil Moisture</span>
                    <span className="font-bold">{selectedField.soilMoisture}%</span>
                  </div>
                  <div>
                    <span className="text-zinc-500 block uppercase text-[9px]">Active Status</span>
                    <span className={`font-bold ${selectedField.currentOperation !== 'None' ? 'text-yellow-400 animate-pulse' : 'text-zinc-400'}`}>
                      {selectedField.currentOperation}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* AUTONOMOUS MISSION DISPATCH PLANNER */}
        <div className="lg:col-span-4 bg-zinc-900/50 border border-zinc-800/80 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 pb-3 border-b border-zinc-800 mb-3">
              <Sliders className="w-5 h-5 text-indigo-400" />
              <h3 className="text-sm font-semibold uppercase tracking-wider text-white">
                Autonomous Mission Dispatch
              </h3>
            </div>

            <p className="text-[11px] text-zinc-400 mb-4 leading-relaxed">
              Define operational parameters. Rust safety boundary interceptors will validate geofence locks and physical machine readiness before arming engine starters.
            </p>

            <form onSubmit={handleDispatchMission} className="space-y-3 font-mono text-xs">
              <div>
                <label className="text-[10px] text-zinc-500 block mb-1">TARGET FIELD DIGITAL TWIN</label>
                <select
                  value={targetFieldId}
                  onChange={(e) => setTargetFieldId(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800/85 rounded p-1.5 text-zinc-100 focus:outline-none focus:border-indigo-500"
                  required
                >
                  <option value="">-- select target field --</option>
                  {fields.map(f => (
                    <option key={f.id} value={f.id}>
                      {f.id}: {f.name} ({f.acres} ac - {f.region})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] text-zinc-500 block mb-1">OPERATION</label>
                  <select
                    value={targetOp}
                    onChange={(e) => setTargetOp(e.target.value as any)}
                    className="w-full bg-zinc-950 border border-zinc-800/85 rounded p-1.5 text-zinc-100 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="Plant">Planting Seeding</option>
                    <option value="Spray">Spraying Treatment</option>
                    <option value="Fertilize">Fertilize Nutrients</option>
                    <option value="Irrigate">Irrigate Water</option>
                    <option value="Harvest">Harvest Crop</option>
                    <option value="Scout">Drone Scout</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] text-zinc-500 block mb-1">PRIORITY STATUS</label>
                  <select
                    value={targetPriority}
                    onChange={(e) => setTargetPriority(e.target.value as any)}
                    className="w-full bg-zinc-950 border border-zinc-800/85 rounded p-1.5 text-zinc-100 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="LOW">LOW PRIORITY</option>
                    <option value="MEDIUM">MEDIUM</option>
                    <option value="HIGH">CRITICAL HIGH</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[10px] text-zinc-500 block mb-1">VARIABLE RATE PRESCRIPTION</label>
                <input
                  type="text"
                  placeholder="e.g. 32,000 seeds/ac, 15 gal/ac"
                  value={targetRate}
                  onChange={(e) => setTargetRate(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800/85 rounded p-1.5 text-zinc-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              {/* Status alerts */}
              {dispatchError && (
                <div className="p-2.5 bg-red-950/40 border border-red-900/60 rounded text-red-400 text-[10px] flex gap-1.5 items-start">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{dispatchError}</span>
                </div>
              )}

              {dispatchSuccess && (
                <div className="p-2.5 bg-emerald-950/40 border border-emerald-900/60 rounded text-emerald-400 text-[10px] flex gap-1.5 items-start">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{dispatchSuccess}</span>
                </div>
              )}

              <button
                type="submit"
                disabled={isDispatching}
                className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-semibold py-2 px-4 rounded-lg flex items-center justify-center gap-2 transition-colors cursor-pointer disabled:opacity-50"
              >
                <Send className="w-4 h-4" /> Arm & Dispatch Mission
              </button>
            </form>
          </div>

          {/* ALL FLEET EMERGENCY LOCK BUTTON */}
          <div className="pt-4 border-t border-zinc-800 mt-4">
            <button
              onClick={handleEmergencyStopAll}
              className="w-full bg-red-600 hover:bg-red-500 text-white font-semibold text-xs py-2 px-4 rounded-lg flex items-center justify-center gap-2 transition-all duration-150 cursor-pointer shadow-[0_0_15px_-3px_rgba(239,68,68,0.4)] animate-pulse"
            >
              <Lock className="w-4 h-4" /> EMERGENCY SAFE STOP LOCK
            </button>
            <p className="text-[9px] text-zinc-500 text-center mt-2 font-mono uppercase tracking-wide">
              Direct telemetry bypass. Halts all active operations immediately.
            </p>
          </div>
        </div>

      </div>

      {/* 2. FLEET TELEMETRY & RUST CONTROLLER OVERRIDES */}
      <div className="bg-zinc-900/50 border border-zinc-800/80 rounded-xl p-5">
        <div className="flex items-center gap-2 pb-4 border-b border-zinc-800 mb-4">
          <Shield className="w-5 h-5 text-indigo-400" />
          <h3 className="text-sm font-semibold uppercase tracking-wider text-white">
            Real-time Fleet Telemetry & Safety Overrides
          </h3>
        </div>

        {/* Machinery Grid */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse font-mono text-xs">
            <thead>
              <tr className="border-b border-zinc-800 text-zinc-500 uppercase text-[10px]">
                <th className="py-2.5 px-3">Vehicle ID</th>
                <th className="py-2.5 px-3">Type</th>
                <th className="py-2.5 px-3">State Machine</th>
                <th className="py-2.5 px-3">Fuel/Batt</th>
                <th className="py-2.5 px-3">Hours</th>
                <th className="py-2.5 px-3">Heading / Speed</th>
                <th className="py-2.5 px-3">Lidar / Health</th>
                <th className="py-2.5 px-3 text-right">Rust Controls Override</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/40">
              {machines.map((machine) => {
                // Style state badge
                let stateColor = 'bg-zinc-950 text-zinc-400 border-zinc-850';
                if (machine.autonomyState === 'RUNNING') stateColor = 'bg-emerald-950/60 text-emerald-400 border-emerald-900/60 animate-pulse';
                else if (machine.autonomyState === 'SAFE_STOP') stateColor = 'bg-red-950/60 text-red-400 border-red-900/60';
                else if (machine.autonomyState === 'WAITING' || machine.autonomyState === 'PAUSED') stateColor = 'bg-yellow-950/60 text-yellow-400 border-yellow-900/60';

                return (
                  <tr key={machine.id} className="hover:bg-zinc-950/30 text-zinc-300">
                    <td className="py-3 px-3 font-bold text-zinc-100">{machine.name}</td>
                    <td className="py-3 px-3">{machine.type}</td>
                    <td className="py-3 px-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${stateColor}`}>
                        {machine.autonomyState}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold">{machine.type === 'Drone' ? machine.batteryLevel : machine.fuelLevel}%</span>
                        <div className="w-12 h-1 bg-zinc-800 rounded overflow-hidden">
                          <div
                            className={`h-full ${machine.fuelLevel < 20 || machine.batteryLevel < 20 ? 'bg-red-500' : 'bg-indigo-500'}`}
                            style={{ width: `${machine.type === 'Drone' ? machine.batteryLevel : machine.fuelLevel}%` }}
                          />
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-3">{machine.engineHours}h</td>
                    <td className="py-3 px-3">{machine.heading}° / {machine.speed}mph</td>
                    <td className="py-3 px-3">
                      <span className={`font-bold ${machine.healthIndex > 90 ? 'text-emerald-400' : 'text-yellow-400'}`}>
                        {machine.healthIndex}%
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right space-x-1.5">
                      {machine.autonomyState === 'RUNNING' ? (
                        <button
                          onClick={() => handleMachineOverride(machine.id, 'PAUSED')}
                          className="bg-zinc-950 hover:bg-zinc-900 border border-zinc-800 text-[10px] px-1.5 py-0.5 rounded cursor-pointer text-zinc-300"
                        >
                          Pause
                        </button>
                      ) : (
                        <button
                          onClick={() => handleMachineOverride(machine.id, 'RUNNING')}
                          disabled={machine.autonomyState === 'SAFE_STOP'}
                          className="bg-indigo-950 hover:bg-indigo-900 border border-indigo-900/50 text-[10px] px-1.5 py-0.5 rounded text-indigo-400 disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer"
                        >
                          Resume
                        </button>
                      )}
                      
                      <button
                        onClick={() => handleMachineOverride(machine.id, 'SAFE_STOP')}
                        disabled={machine.autonomyState === 'SAFE_STOP'}
                        className="bg-red-950 hover:bg-red-900 border border-red-900/40 text-[10px] px-1.5 py-0.5 rounded text-red-400 disabled:opacity-40 cursor-pointer"
                      >
                        Safe Stop
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* 3. HIGH FREQUENCY EVENT BUS */}
      <div className="bg-zinc-900/50 border border-zinc-800/80 rounded-xl p-5">
        <div className="flex items-center justify-between pb-4 border-b border-zinc-800 mb-4">
          <div className="flex items-center gap-2">
            <Radio className="w-5 h-5 text-indigo-400" />
            <h3 className="text-sm font-semibold uppercase tracking-wider text-white">
              High-Frequency Rust Core Event Bus
            </h3>
          </div>
          
          <div className="flex gap-2 text-[10px] font-mono">
            <button
              onClick={() => setSeverityFilter('ALL')}
              className={`px-2 py-0.5 rounded border cursor-pointer ${severityFilter === 'ALL' ? 'bg-indigo-950 border-indigo-900 text-indigo-400' : 'bg-zinc-950 border-zinc-800 text-zinc-500'}`}
            >
              ALL
            </button>
            <button
              onClick={() => setSeverityFilter('INFO')}
              className={`px-2 py-0.5 rounded border cursor-pointer ${severityFilter === 'INFO' ? 'bg-indigo-950 border-indigo-900 text-indigo-400' : 'bg-zinc-950 border-zinc-800 text-zinc-500'}`}
            >
              INFO
            </button>
            <button
              onClick={() => setSeverityFilter('WARNING')}
              className={`px-2 py-0.5 rounded border cursor-pointer ${severityFilter === 'WARNING' ? 'bg-yellow-950 border-yellow-900 text-yellow-400' : 'bg-zinc-950 border-zinc-800 text-zinc-500'}`}
            >
              WARNINGS
            </button>
            <button
              onClick={() => setSeverityFilter('CRITICAL')}
              className={`px-2 py-0.5 rounded border cursor-pointer ${severityFilter === 'CRITICAL' ? 'bg-red-950 border-red-900 text-red-400' : 'bg-zinc-950 border-zinc-800 text-zinc-500'}`}
            >
              CRITICALS
            </button>
          </div>
        </div>

        {/* Scrolling logs */}
        <div className="bg-zinc-950 border border-zinc-850/60 rounded-lg p-3 max-h-48 overflow-y-auto space-y-2 font-mono text-[11px]">
          {filteredEvents.length === 0 ? (
            <div className="text-center text-zinc-600 py-6">No event payloads matched current severity filter.</div>
          ) : (
            filteredEvents.map((ev) => {
              let sevColor = 'text-zinc-500';
              if (ev.severity === 'WARNING') sevColor = 'text-yellow-400';
              if (ev.severity === 'CRITICAL') sevColor = 'text-red-400';

              return (
                <div key={ev.id} className="flex items-start gap-3 py-1.5 border-b border-zinc-900/40 hover:bg-zinc-900/20 px-2 rounded">
                  <span className="text-zinc-600 font-bold shrink-0">
                    {new Date(ev.timestamp).toLocaleTimeString()}
                  </span>
                  <span className={`font-bold shrink-0 uppercase tracking-wide text-[10px] w-16 ${sevColor}`}>
                    [{ev.severity}]
                  </span>
                  <p className="text-zinc-300 flex-1">{ev.message}</p>
                </div>
              );
            })
          )}
        </div>
      </div>

    </div>
  );
}
