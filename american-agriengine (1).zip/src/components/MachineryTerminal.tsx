/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Machine } from '../types';
import {
  Wrench,
  ShieldAlert,
  Navigation,
  Compass,
  Zap,
  Activity,
  AlertTriangle,
  Play,
  RotateCcw,
  CheckCircle2
} from 'lucide-react';

interface MachineryTerminalProps {
  machines: Machine[];
}

export default function MachineryTerminal({ machines }: MachineryTerminalProps) {
  // Selected machine for diagnostics
  const [selectedMacId, setSelectedMacId] = useState('');
  
  // Navigation / Swath parameters
  const [pathType, setPathType] = useState<'AB' | 'Headland' | 'Contour' | 'Swath'>('AB');
  const [swathWidth, setSwathWidth] = useState(40); // feet
  const [headlandTurns, setHeadlandTurns] = useState(4); // passes
  const [pathNpv, setPathNpv] = useState<any>(null);

  // Drone schedule flight
  const [droneMissionType, setDroneMissionType] = useState('Scout');
  const [droneField, setDroneField] = useState('F-101');
  const [droneSuccessMsg, setDroneSuccessMsg] = useState('');

  const selectedMachine = machines.find(m => m.id === selectedMacId) || machines[0];

  // Calculate path optimization metrics
  const handleOptimizePath = () => {
    // R-geometry computation mockup
    const coverageEfficiency = pathType === 'AB' ? 98.4 : pathType === 'Headland' ? 94.2 : 91.5;
    const turnCount = pathType === 'AB' ? 24 : pathType === 'Headland' ? 12 : 36;
    const compactionIndex = pathType === 'AB' ? 12.4 : pathType === 'Headland' ? 8.2 : 19.5; // % area compacted

    setPathNpv({
      coverageEfficiency,
      turnCount,
      compactionIndex,
      estimatedTimeHours: parseFloat(((swathWidth === 40 ? 6.4 : 9.2)).toFixed(1)),
      fuelSavesGallons: swathWidth * 0.45,
      guidanceRecommendation: pathType === 'Headland'
        ? 'R-Geometric Solver: Headland passes minimize compaction boundaries by consolidating tire tracks to primary turnaround zones. Axle-weight limits validated.'
        : 'R-Geometric Solver: Straight AB-lines maximize implement overlap efficiency, decreasing fuel burns but exposing headland margins to double compaction passes.'
    });
  };

  const handleLaunchDrone = (e: React.FormEvent) => {
    e.preventDefault();
    setDroneSuccessMsg(`AeroScout drone launched autonomously toward Field ${droneField} for ${droneMissionType} scanning! Telemetry synced.`);
    setTimeout(() => setDroneSuccessMsg(''), 5000);
  };

  return (
    <div id="machinery-terminal" className="space-y-6">
      
      {/* 1. AUTONOMOUS PATH PLANNER & NAVIGATION MATRIX */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Interactive path solver form */}
        <div className="lg:col-span-7 bg-zinc-900/50 border border-zinc-800/80 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 pb-3 border-b border-zinc-800 mb-3">
              <Navigation className="w-5 h-5 text-indigo-400" />
              <h3 className="text-sm font-semibold uppercase tracking-wider text-white">
                R-Geometric Path Planner & Guidance
              </h3>
            </div>

            <p className="text-xs text-zinc-400 mb-4 leading-relaxed font-mono">
              Generate non-overlapping swaths, AB-lines, and terrain-aware turning vectors. Fits mathematical spline polynomials to complex field boundaries to reduce soil shear forces.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4 font-mono text-xs">
              <div>
                <label className="text-[10px] text-zinc-500 block mb-1">GUIDANCE PATTERN</label>
                <select
                  value={pathType}
                  onChange={(e) => setPathType(e.target.value as any)}
                  className="w-full bg-zinc-950 border border-zinc-800/85 rounded p-1.5 text-zinc-100 focus:outline-none focus:border-indigo-500 cursor-pointer"
                >
                  <option value="AB">Straight AB-Lines</option>
                  <option value="Headland">Consolidated Headlands</option>
                  <option value="Contour">Adaptive Contours</option>
                  <option value="Swath">Minimum Overlap Swaths</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] text-zinc-500 block mb-1">IMPLEMENT WIDTH (FT)</label>
                <input
                  type="number"
                  value={swathWidth}
                  onChange={(e) => setSwathWidth(Number(e.target.value))}
                  className="w-full bg-zinc-950 border border-zinc-800/85 rounded p-1.5 text-zinc-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-[10px] text-zinc-500 block mb-1">HEADLAND TURNS (PASSES)</label>
                <input
                  type="number"
                  value={headlandTurns}
                  onChange={(e) => setHeadlandTurns(Number(e.target.value))}
                  className="w-full bg-zinc-950 border border-zinc-800/85 rounded p-1.5 text-zinc-100 focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <button
              onClick={handleOptimizePath}
              className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs py-2 px-4 rounded-lg flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              Solve Optimal Guidance Vectors
            </button>
          </div>

          {pathNpv ? (
            <div className="mt-4 bg-zinc-950 p-3.5 border border-zinc-800/85 rounded-lg space-y-3 font-mono text-xs text-zinc-300">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
                <div className="bg-zinc-900/40 p-2 rounded border border-zinc-800/50">
                  <span className="text-[8px] text-zinc-500 block">COVERAGE</span>
                  <span className="font-bold text-indigo-400">{pathNpv.coverageEfficiency}%</span>
                </div>
                <div className="bg-zinc-900/40 p-2 rounded border border-zinc-800/50">
                  <span className="text-[8px] text-zinc-500 block">TURNS SOLVED</span>
                  <span className="font-bold text-zinc-100">{pathNpv.turnCount}</span>
                </div>
                <div className="bg-zinc-900/40 p-2 rounded border border-zinc-800/50">
                  <span className="text-[8px] text-zinc-500 block">COMPACTION AREA</span>
                  <span className="font-bold text-yellow-400">{pathNpv.compactionIndex}%</span>
                </div>
                <div className="bg-zinc-900/40 p-2 rounded border border-zinc-800/50">
                  <span className="text-[8px] text-zinc-500 block">FUEL EFFICIENCY</span>
                  <span className="font-bold text-emerald-400">+{Math.round(pathNpv.fuelSavesGallons)} gal</span>
                </div>
              </div>

              <div className="p-2 bg-zinc-900/20 rounded border border-zinc-800/80 text-[10px] text-zinc-400 leading-relaxed flex gap-1.5 items-start">
                <CheckCircle2 className="w-4.5 h-4.5 text-indigo-400 shrink-0 mt-0.5" />
                <p>{pathNpv.guidanceRecommendation}</p>
              </div>
            </div>
          ) : (
            <div className="mt-4 border border-dashed border-zinc-800 rounded-lg p-6 text-center text-xs text-zinc-600 font-mono">
              Select turn parameters and trigger solver to display optimal non-overlap swath vectors.
            </div>
          )}
        </div>

        {/* Drone Scout Scheduler / Swarm coordinator */}
        <div className="lg:col-span-5 bg-zinc-900/50 border border-zinc-800/80 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 pb-3 border-b border-zinc-800 mb-3">
              <Zap className="w-5 h-5 text-indigo-400" />
              <h3 className="text-sm font-semibold uppercase tracking-wider text-white">
                Drone Scout Swarm Coordinator
              </h3>
            </div>

            <p className="text-xs text-zinc-400 mb-4 leading-relaxed font-mono">
              Program aerial scouts for plant stand counts, thermal moisture mapping, and multispectral weed patches coordinates. Runs autonomous flights with automated battery inductive charging.
            </p>

            <form onSubmit={handleLaunchDrone} className="space-y-3 font-mono text-xs">
              <div>
                <label className="text-[10px] text-zinc-500 block mb-1">CROP SCOUT MISSION TYPE</label>
                <select
                  value={droneMissionType}
                  onChange={(e) => setDroneMissionType(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800/85 rounded p-1.5 text-zinc-100 focus:outline-none focus:border-indigo-500 cursor-pointer"
                >
                  <option value="Scout">Stand Count (Plants/Acre)</option>
                  <option value="Thermal">Thermal Moisture Proxy Mapping</option>
                  <option value="WeedMap">Target Weeds coordinates</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] text-zinc-500 block mb-1">TARGET FIELD CODES</label>
                <select
                  value={droneField}
                  onChange={(e) => setDroneField(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800/85 rounded p-1.5 text-zinc-100 focus:outline-none focus:border-indigo-500 cursor-pointer"
                >
                  <option value="F-101">Lincoln Ridge F1 (Corn)</option>
                  <option value="F-201">Salina Sweep S1 (Wheat)</option>
                  <option value="F-301">Fresno Grove A (Orchards)</option>
                </select>
              </div>

              {droneSuccessMsg && (
                <div className="p-2 bg-emerald-950/40 border border-emerald-900/50 rounded text-emerald-400 text-[10px] flex gap-1 items-start leading-relaxed">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{droneSuccessMsg}</span>
                </div>
              )}

              <button
                type="submit"
                className="w-full bg-zinc-950 hover:bg-zinc-900 border border-zinc-800 hover:border-indigo-500 text-zinc-300 font-semibold py-2 px-4 rounded transition-colors cursor-pointer"
              >
                Launch AeroScout Drone Mission
              </button>
            </form>
          </div>
        </div>

      </div>

      {/* 2. PREDICTIVE MAINTENANCE & CAN-BUS TELEMETRY HUD */}
      <div className="bg-zinc-900/50 border border-zinc-800/80 rounded-xl p-5">
        <div className="flex items-center gap-2 pb-4 border-b border-zinc-800 mb-4">
          <Wrench className="w-5 h-5 text-indigo-400" />
          <h3 className="text-sm font-semibold uppercase tracking-wider text-white">
            ISOBUS / CAN-Bus Predictive Diagnostics
          </h3>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Machine Selector list */}
          <div className="lg:col-span-4 space-y-2">
            <h4 className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider mb-2">VEHICLES LOG</h4>
            <div className="space-y-1.5 font-mono text-xs max-h-48 overflow-y-auto pr-1">
              {machines.map((m) => (
                <button
                  key={m.id}
                  onClick={() => setSelectedMacId(m.id)}
                  className={`w-full text-left p-2 rounded border transition-colors cursor-pointer ${
                    selectedMachine?.id === m.id
                      ? 'bg-indigo-950/60 border-indigo-900/60 text-indigo-400 font-semibold'
                      : 'bg-zinc-950 border border-zinc-800/80 hover:border-zinc-750 text-zinc-500 hover:text-zinc-300'
                  }`}
                >
                  <div className="flex justify-between">
                    <span>{m.name}</span>
                    <span className="text-[10px] uppercase font-bold">{m.autonomyState}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Diagnostics Display */}
          {selectedMachine && (
            <div className="lg:col-span-8 bg-zinc-950 p-4 border border-zinc-800/80 rounded-lg flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-center pb-2 border-b border-zinc-900/60 mb-3">
                  <span className="font-mono text-xs font-bold text-zinc-100 flex items-center gap-1.5">
                    <Activity className="w-4 h-4 text-indigo-400" />
                    Diagnostics: {selectedMachine.name}
                  </span>
                  <span className="font-mono text-[9px] text-zinc-500 uppercase">CAN Version 2.0B</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono mb-4 text-zinc-300">
                  <div>
                    <span className="text-zinc-500 block uppercase text-[8px]">Health Index</span>
                    <span className={`font-bold ${selectedMachine.healthIndex > 90 ? 'text-emerald-400' : 'text-yellow-400'}`}>
                      {selectedMachine.healthIndex}%
                    </span>
                  </div>
                  <div>
                    <span className="text-zinc-500 block uppercase text-[8px]">Engine Hours</span>
                    <span>{selectedMachine.engineHours} Hrs</span>
                  </div>
                  <div>
                    <span className="text-zinc-500 block uppercase text-[8px]">Implement Width</span>
                    <span>{selectedMachine.workingWidthFeet} Ft</span>
                  </div>
                  <div>
                    <span className="text-zinc-500 block uppercase text-[8px]">Assigned Operator</span>
                    <span className="text-zinc-100">{selectedMachine.operator}</span>
                  </div>
                </div>

                {/* Alarm Threshold logs */}
                <div className="bg-zinc-900/30 p-3 rounded border border-zinc-800/80 text-xs font-mono space-y-1.5 text-zinc-400">
                  <div className="flex justify-between">
                    <span>Hydraulic Manifold pressure:</span>
                    <span className="text-zinc-200">2,850 PSI (Normal)</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Cylinder Compression variance:</span>
                    <span className="text-zinc-200">0.8% deviation (Optimized)</span>
                  </div>
                  <div className="flex justify-between flex-wrap gap-1">
                    <span>Predictive Alert trigger:</span>
                    {selectedMachine.healthIndex < 90 ? (
                      <span className="text-yellow-400 font-bold flex items-center gap-1">
                        <AlertTriangle className="w-3.5 h-3.5" /> micro-vibration detected in pump manifold
                      </span>
                    ) : (
                      <span className="text-emerald-400 font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Weibull wear curves stable
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <div className="text-[10px] text-zinc-500 font-mono mt-3 italic">
                Weibull diagnostic limits computed in R using high-frequency sensor streams transmitted via ISO 11783 CAN-bus architecture.
              </div>
            </div>
          )}

        </div>
      </div>

    </div>
  );
}
