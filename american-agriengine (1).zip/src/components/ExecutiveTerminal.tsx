/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { SimulationState, CropType, AgriculturalRegion } from '../types';
import {
  TrendingUp,
  DollarSign,
  PieChart,
  BarChart,
  Activity,
  Award,
  Sliders,
  Compass,
  AlertTriangle,
  Grid,
  CheckCircle2
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart as RechartsBarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  CartesianGrid
} from 'recharts';

interface ExecutiveTerminalProps {
  simState: SimulationState;
}

export default function ExecutiveTerminal({ simState }: ExecutiveTerminalProps) {
  // Optimizer State
  const [optBudget, setOptBudget] = useState(15000000);
  const [optRisk, setOptRisk] = useState(65);
  const [optRegion, setOptRegion] = useState<AgriculturalRegion>('Midwest');
  const [optResult, setOptResult] = useState<any>(null);
  const [isOptimizing, setIsOptimizing] = useState(false);

  // Land Evaluation State
  const [landAcres, setLandAcres] = useState(640);
  const [landWaterRights, setLandWaterRights] = useState(1200);
  const [landClay, setLandClay] = useState(24);
  const [landYield, setLandYield] = useState(215);
  const [landValueResult, setLandValueResult] = useState<any>(null);
  const [isEvaluating, setIsEvaluating] = useState(false);

  // Stochastic Risk Solver (Monte Carlo simulation tracker)
  const [monteCarloResult, setMonteCarloResult] = useState<any>(null);
  const [isSimulatingRisk, setIsSimulatingRisk] = useState(false);

  // Run R Optimizer Solver
  const handleSolveOptimization = async () => {
    setIsOptimizing(true);
    try {
      const res = await fetch('/api/actions/optimizer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          maxBudget: optBudget,
          riskTolerance: optRisk,
          region: optRegion
        })
      });
      const data = await res.json();
      setOptResult(data);
    } catch (e) {
      console.error(e);
    } finally {
      setIsOptimizing(false);
    }
  };

  // Run Land evaluation
  const handleEvaluateLand = async () => {
    setIsEvaluating(true);
    try {
      const res = await fetch('/api/actions/land-evaluate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          acres: landAcres,
          waterRightsAcreFt: landWaterRights,
          clayPercent: landClay,
          historicalYieldbu: landYield
        })
      });
      const data = await res.json();
      setLandValueResult(data);
    } catch (e) {
      console.error(e);
    } finally {
      setIsEvaluating(false);
    }
  };

  // Trigger Monte Carlo simulations
  const handleRunMonteCarlo = async () => {
    setIsSimulatingRisk(true);
    try {
      const res = await fetch('/api/actions/montecarlo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ iterations: 500, region: optRegion })
      });
      const data = await res.json();
      setMonteCarloResult(data);
    } catch (e) {
      console.error(e);
    } finally {
      setIsSimulatingRisk(false);
    }
  };

  // Crop allocations default visualizer
  const currentAllocationData = [
    { name: 'Corn', acres: 142000, value: 68160000, color: '#10b981' },
    { name: 'Soybeans', acres: 85400, value: 39284000, color: '#34d399' },
    { name: 'Wheat', acres: 38200, value: 18450000, color: '#60a5fa' },
    { name: 'Cotton', acres: 18400, value: 10306000, color: '#fbbf24' }
  ];

  return (
    <div id="executive-terminal" className="space-y-6">
      {/* 1. KEY ENTERPRISE FINANCIALS */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-zinc-900/50 p-5 rounded-xl border border-zinc-800/80 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider block">Enterprise Acres</span>
            <span className="text-xl font-bold font-mono text-white">
              {simState.financials.totalAcres.toLocaleString()}
            </span>
          </div>
          <Grid className="w-8 h-8 text-indigo-400 stroke-1" />
        </div>

        <div className="bg-zinc-900/50 p-5 rounded-xl border border-zinc-800/80 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider block">Projected Revenue</span>
            <span className="text-xl font-bold font-mono text-emerald-400">
              ${(simState.financials.projectedRevenue / 1000000).toFixed(1)}M
            </span>
          </div>
          <DollarSign className="w-8 h-8 text-emerald-400 stroke-1" />
        </div>

        <div className="bg-zinc-900/50 p-5 rounded-xl border border-zinc-800/80 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider block">Operating Expenses</span>
            <span className="text-xl font-bold font-mono text-zinc-400">
              ${(simState.financials.costsTotal / 1000000).toFixed(1)}M
            </span>
          </div>
          <TrendingUp className="w-8 h-8 text-zinc-500 stroke-1" />
        </div>

        <div className="bg-zinc-900/50 p-5 rounded-xl border border-zinc-800/80 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider block">Projected EBITDA</span>
            <span className="text-xl font-bold font-mono text-indigo-400">
              ${(simState.financials.operatingEbitda / 1000000).toFixed(1)}M
            </span>
          </div>
          <Activity className="w-8 h-8 text-indigo-400 stroke-1" />
        </div>
      </div>

      {/* 2. ADVANCED PORTFOLIO OPTIMIZER & RISK MODELLING GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* R-Optimizer Interface */}
        <div className="lg:col-span-7 bg-zinc-900/50 border border-zinc-800/80 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-zinc-800 mb-4">
              <div className="flex items-center gap-2">
                <Sliders className="w-5 h-5 text-indigo-400" />
                <h3 className="text-sm font-semibold uppercase tracking-wider text-white">
                  R-Intelligence Portfolio Optimizer
                </h3>
              </div>
              <span className="text-[10px] font-mono text-zinc-500 bg-zinc-950 px-2 py-0.5 rounded border border-zinc-800/80">
                MODULE: ompr :: Solver
              </span>
            </div>

            <p className="text-xs text-zinc-400 mb-4 leading-relaxed">
              Dynamically fits linear programming matrices to maximize risk-adjusted crop yield margins. Calculates resource constraint boundaries and fertilizer saturation thresholds.
            </p>

            {/* Inputs Panel */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div>
                <label className="text-[10px] font-mono text-zinc-500 block mb-1">CAPEX BUDGET CAPACITY</label>
                <div className="relative">
                  <span className="absolute left-2.5 top-1.5 text-xs text-zinc-500 font-mono">$</span>
                  <input
                    type="number"
                    value={optBudget}
                    onChange={(e) => setOptBudget(Number(e.target.value))}
                    className="w-full bg-zinc-950 border border-zinc-800/80 text-xs rounded p-1.5 pl-6 text-zinc-100 font-mono focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-mono text-zinc-500 block mb-1">RISK TOLERANCE BUFFER</label>
                <div className="flex items-center gap-2">
                  <input
                    type="range"
                    min="10"
                    max="100"
                    value={optRisk}
                    onChange={(e) => setOptRisk(Number(e.target.value))}
                    className="w-full h-1 bg-zinc-850 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                  />
                  <span className="text-xs font-mono text-zinc-300 w-8 text-right">{optRisk}%</span>
                </div>
              </div>

              <div>
                <label className="text-[10px] font-mono text-zinc-500 block mb-1">TARGET US REGION</label>
                <select
                  value={optRegion}
                  onChange={(e) => setOptRegion(e.target.value as AgriculturalRegion)}
                  className="w-full bg-zinc-950 border border-zinc-800/80 text-xs rounded p-1.5 text-zinc-100 focus:outline-none focus:border-indigo-500"
                >
                  <option value="Midwest">Midwest Row Crops</option>
                  <option value="GreatPlains">Great Plains Wheatbelt</option>
                  <option value="California">California Specialty</option>
                  <option value="TexasSouthern">Texas Southern Plains</option>
                </select>
              </div>
            </div>

            <button
              onClick={handleSolveOptimization}
              disabled={isOptimizing}
              className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs py-2.5 px-4 rounded-lg flex items-center justify-center gap-2 transition-colors duration-150 cursor-pointer disabled:opacity-50"
            >
              {isOptimizing ? 'Solver Executing LP Matrix...' : 'Solve Crop Allocation Portfolio'}
            </button>
          </div>

          {/* Results Output */}
          {optResult ? (
            <div className="mt-5 bg-zinc-950 p-4 border border-zinc-800/80 rounded-lg space-y-3">
              <div className="flex justify-between items-center pb-2 border-b border-zinc-900">
                <span className="text-[10px] font-mono text-zinc-500">LP RESOLUTION: SUCCESSFUL</span>
                <span className="text-[10px] font-mono text-indigo-400 font-bold bg-indigo-950/50 px-1.5 py-0.5 rounded border border-indigo-900/30">
                  AVG ROI: {optResult.averageROI}%
                </span>
              </div>
              
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="bg-zinc-900/30 p-2 rounded border border-zinc-800/40">
                  <span className="text-[9px] text-zinc-500 block uppercase">Optimized Acres</span>
                  <span className="text-xs font-mono font-bold text-zinc-100">{optResult.totalOptimalAcres.toLocaleString()}</span>
                </div>
                <div className="bg-zinc-900/30 p-2 rounded border border-zinc-800/40">
                  <span className="text-[9px] text-zinc-500 block uppercase">Expected NPV</span>
                  <span className="text-xs font-mono font-bold text-indigo-400">${(optResult.portfolioNPV / 1000000).toFixed(2)}M</span>
                </div>
                <div className="bg-zinc-900/30 p-2 rounded border border-zinc-800/40">
                  <span className="text-[9px] text-zinc-500 block uppercase">Water Footprint</span>
                  <span className="text-xs font-mono font-bold text-zinc-300">{optResult.allocations[0]?.waterRequirementAcreFeet.toLocaleString()} AF</span>
                </div>
              </div>

              {/* Splits */}
              <div className="space-y-1.5 pt-1">
                {optResult.allocations.map((alloc: any, i: number) => (
                  <div key={i} className="flex justify-between text-xs font-mono">
                    <span className="text-zinc-500">{alloc.crop} Allocation:</span>
                    <span className="text-zinc-300 font-bold">
                      {alloc.allocatedAcres.toLocaleString()} acres (${alloc.marginPerAcre}/ac margin)
                    </span>
                  </div>
                ))}
              </div>

              <p className="text-[10px] text-zinc-500 font-mono italic leading-relaxed pt-1 border-t border-zinc-900">
                {optResult.explanation}
              </p>
            </div>
          ) : (
            <div className="mt-5 border border-dashed border-zinc-800 rounded-lg p-6 text-center text-xs text-zinc-600">
              Enter operational parameters and trigger optimizer to display solved allocations.
            </div>
          )}
        </div>

        {/* Stochastic Risk Curve Display (Monte Carlo) */}
        <div className="lg:col-span-5 bg-zinc-900/50 border border-zinc-800/80 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-zinc-800 mb-4">
              <div className="flex items-center gap-2">
                <BarChart className="w-5 h-5 text-indigo-400" />
                <h3 className="text-sm font-semibold uppercase tracking-wider text-white">
                  Monte Carlo Stochastic Risk Model
                </h3>
              </div>
              <span className="text-[10px] font-mono text-zinc-500">trials: 500</span>
            </div>

            <p className="text-xs text-zinc-400 mb-4 leading-relaxed">
              Fits joint probability density bounds to historical drought parameters and commodity basis variations to forecast portfolio downside protection.
            </p>

            <button
              onClick={handleRunMonteCarlo}
              disabled={isSimulatingRisk}
              className="w-full bg-zinc-950 hover:bg-zinc-900 border border-zinc-800 hover:border-indigo-500 text-zinc-300 font-semibold text-xs py-2 px-4 rounded-lg flex items-center justify-center gap-2 transition-colors duration-150 cursor-pointer disabled:opacity-50"
            >
              {isSimulatingRisk ? 'Simulating 500 Stochastic Paths...' : 'Execute Risk Shock Simulation'}
            </button>
          </div>

          {monteCarloResult ? (
            <div className="mt-4 space-y-4">
              {/* P10/P50/P90 numbers */}
              <div className="bg-zinc-950 p-3 rounded-lg border border-zinc-800/80">
                <h4 className="text-[10px] font-mono font-bold text-zinc-500 uppercase mb-2">Confidence Limits (Stochastic EBITDA)</h4>
                <div className="grid grid-cols-3 gap-2 text-center font-mono">
                  <div className="bg-zinc-900/40 p-1.5 rounded border border-zinc-800/60">
                    <span className="text-[8px] text-red-400 block font-bold">P10 (DOWNSIDE)</span>
                    <span className="text-xs font-bold text-zinc-200">${(monteCarloResult.results.profit.p10 / 1000000).toFixed(1)}M</span>
                  </div>
                  <div className="bg-zinc-900/40 p-1.5 rounded border border-zinc-800/60">
                    <span className="text-[8px] text-indigo-400 block font-bold">P50 (MEDIAN)</span>
                    <span className="text-xs font-bold text-zinc-100">${(monteCarloResult.results.profit.p50 / 1000000).toFixed(1)}M</span>
                  </div>
                  <div className="bg-zinc-900/40 p-1.5 rounded border border-zinc-800/60">
                    <span className="text-[8px] text-blue-400 block font-bold">P90 (UPSIDE)</span>
                    <span className="text-xs font-bold text-zinc-200">${(monteCarloResult.results.profit.p90 / 1000000).toFixed(1)}M</span>
                  </div>
                </div>
              </div>

              {/* Mini Chart */}
              <div className="h-28 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={monteCarloResult.distributionChart}>
                    <XAxis dataKey="yield" stroke="#52525b" fontSize={8} label={{ value: 'Stochastic Yield bu/ac', position: 'insideBottom', offset: -2, fill: '#52525b', fontSize: 8 }} />
                    <YAxis stroke="#52525b" fontSize={8} />
                    <Tooltip contentStyle={{ background: '#09090b', border: '1px solid #27272a', fontSize: 10 }} />
                    <Line type="monotone" dataKey="probabilityDensity" stroke="#6366f1" dot={false} strokeWidth={2} name="Probability Density %" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          ) : (
            <div className="mt-4 border border-dashed border-zinc-800 rounded-lg p-6 text-center text-xs text-zinc-600">
              Run Monte Carlo simulator to compute confidence density curves.
            </div>
          )}
        </div>

      </div>

      {/* 3. FARMLAND ASSET VALUE ESTIMATION & LEASE CALCULATOR */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Land evaluate input form */}
        <div className="lg:col-span-6 bg-zinc-900/50 border border-zinc-800/80 rounded-xl p-5">
          <div className="flex items-center gap-2 pb-4 border-b border-zinc-800 mb-4">
            <Award className="w-5 h-5 text-indigo-400" />
            <h3 className="text-sm font-semibold uppercase tracking-wider text-white">
              Farmland Acquisition Valuator
            </h3>
          </div>

          <p className="text-xs text-zinc-400 mb-4 leading-relaxed">
            Evaluates fair-market acreage pricing for prospective crop expansions based on physical topsoil chemistry, historic water allocations, and baseline crop suitability models.
          </p>

          <div className="grid grid-cols-2 gap-4 mb-4 font-mono text-xs">
            <div>
              <label className="text-[10px] text-zinc-500 block mb-1">PROSPECTIVE ACRES</label>
              <input
                type="number"
                value={landAcres}
                onChange={(e) => setLandAcres(Number(e.target.value))}
                className="w-full bg-zinc-950 border border-zinc-800/80 rounded p-1.5 text-zinc-100 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="text-[10px] text-zinc-500 block mb-1">WATER PERMIT (ACRE-FT)</label>
              <input
                type="number"
                value={landWaterRights}
                onChange={(e) => setLandWaterRights(Number(e.target.value))}
                className="w-full bg-zinc-950 border border-zinc-800/80 rounded p-1.5 text-zinc-100 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="text-[10px] text-zinc-500 block mb-1">CLAY COMPOSITION (%)</label>
              <input
                type="number"
                value={landClay}
                onChange={(e) => setLandClay(Number(e.target.value))}
                className="w-full bg-zinc-950 border border-zinc-800/80 rounded p-1.5 text-zinc-100 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="text-[10px] text-zinc-500 block mb-1">HISTORIC YIELD (BU/ACRE)</label>
              <input
                type="number"
                value={landYield}
                onChange={(e) => setLandYield(Number(e.target.value))}
                className="w-full bg-zinc-950 border border-zinc-800/80 rounded p-1.5 text-zinc-100 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          <button
            onClick={handleEvaluateLand}
            disabled={isEvaluating}
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs py-2.5 px-4 rounded-lg flex items-center justify-center gap-2 transition-colors duration-150 cursor-pointer disabled:opacity-50"
          >
            {isEvaluating ? 'R Solver computing soil models...' : 'Run Acquisition Soil Valuation'}
          </button>
        </div>

        {/* Land evaluation results */}
        <div className="lg:col-span-6 bg-zinc-900/50 border border-zinc-800/80 rounded-xl p-5 flex flex-col justify-between">
          <div className="pb-3 border-b border-zinc-800 mb-2">
            <h4 className="text-xs font-semibold text-zinc-300 uppercase">Acreage Valuation Output</h4>
          </div>

          {landValueResult ? (
            <div className="flex-1 flex flex-col justify-between mt-4">
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="bg-zinc-950 p-3 rounded border border-zinc-800/80">
                  <span className="text-[9px] font-mono text-zinc-500 block">FAIR MARKET VALUATION</span>
                  <span className="text-lg font-mono font-bold text-indigo-400">
                    ${landValueResult.calculatedFairValue.toLocaleString()}
                  </span>
                </div>
                <div className="bg-zinc-950 p-3 rounded border border-zinc-800/80">
                  <span className="text-[9px] font-mono text-zinc-500 block">COST PER ACRE</span>
                  <span className="text-lg font-mono font-bold text-zinc-200">
                    ${landValueResult.costPerAcre.toLocaleString()}/ac
                  </span>
                </div>
                <div className="bg-zinc-950 p-3 rounded border border-zinc-800/80">
                  <span className="text-[9px] font-mono text-zinc-500 block">SOIL SUITABILITY INDEX</span>
                  <span className="text-lg font-mono font-bold text-indigo-400">
                    {Math.round(landValueResult.soilSuitabilityIndex * 100)}%
                  </span>
                </div>
                <div className="bg-zinc-950 p-3 rounded border border-zinc-800/80">
                  <span className="text-[9px] font-mono text-zinc-500 block">PROJECTED PAYBACK</span>
                  <span className="text-lg font-mono font-bold text-amber-500">
                    {landValueResult.projectedPaybackYears} Years
                  </span>
                </div>
              </div>

              <div className="p-3 bg-zinc-950 rounded-lg border border-zinc-800/80 flex gap-2 items-start text-xs text-zinc-400 leading-relaxed font-mono">
                <CheckCircle2 className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
                <p>{landValueResult.analysis}</p>
              </div>
            </div>
          ) : (
            <div className="flex-1 flex items-center justify-center text-center text-xs text-zinc-600 border border-dashed border-zinc-800 rounded-lg p-8 my-4">
              Awaiting farm property parameters to execute statistical pricing models.
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
