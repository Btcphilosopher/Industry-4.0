/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Field, SoilZone, CropType } from '../types';
import {
  Sprout,
  Activity,
  Award,
  BookOpen,
  CloudLightning,
  Percent,
  TrendingUp,
  Cpu,
  CheckCircle2,
  Sliders,
  ChevronRight
} from 'lucide-react';

interface AgronomistTerminalProps {
  fields: Field[];
}

export default function AgronomistTerminal({ fields }: AgronomistTerminalProps) {
  const [selectedFieldId, setSelectedFieldId] = useState('');
  const [soilZones, setSoilZones] = useState<SoilZone[]>([]);
  const [isLoadingZones, setIsLoadingZones] = useState(false);

  // Crop rotation form
  const [rotYear1, setRotYear1] = useState<CropType>('Corn');
  const [rotYear2, setRotYear2] = useState<CropType>('Soybeans');
  const [rotYear3, setRotYear3] = useState<CropType>('Corn');
  const [rotationResult, setRotationResult] = useState<any>(null);
  const [isSimulatingRotation, setIsSimulatingRotation] = useState(false);

  // Active Map Layer selection
  const [activeSoilLayer, setActiveSoilLayer] = useState<'N' | 'P' | 'K' | 'pH' | 'NDVI'>('NDVI');

  // Load soil zones whenever field changes
  useEffect(() => {
    if (!selectedFieldId && fields.length > 0) {
      setSelectedFieldId(fields[0].id);
    }
  }, [fields]);

  useEffect(() => {
    if (!selectedFieldId) return;

    const fetchZones = async () => {
      setIsLoadingZones(true);
      try {
        const res = await fetch(`/api/fields/${selectedFieldId}/zones`);
        const data = await res.json();
        setSoilZones(data);
      } catch (err) {
        console.error(err);
      } finally {
        setIsLoadingZones(false);
      }
    };
    fetchZones();
  }, [selectedFieldId]);

  // Run crop rotation simulator
  const handleSimulateRotation = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSimulatingRotation(true);
    try {
      const res = await fetch('/api/actions/rotation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          cropSequence: [rotYear1, rotYear2, rotYear3]
        })
      });
      const data = await res.json();
      setRotationResult(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSimulatingRotation(false);
    }
  };

  const selectedField = fields.find(f => f.id === selectedFieldId);

  return (
    <div id="agronomist-terminal" className="space-y-6">
      
      {/* 1. SOIL DIGITAL TWIN & SPATIAL MANAGEMENT ZONES */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Spatial Zone visualizer */}
        <div className="lg:col-span-8 bg-zinc-900/50 border border-zinc-800/80 rounded-xl p-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-zinc-800 mb-4 gap-3">
            <div className="flex items-center gap-2">
              <Sprout className="w-5 h-5 text-indigo-400" />
              <h3 className="text-sm font-semibold uppercase tracking-wider text-white">
                Soil Digital Twin & Management Zones
              </h3>
            </div>
            
            {/* Field select dropdown */}
            <select
              value={selectedFieldId}
              onChange={(e) => setSelectedFieldId(e.target.value)}
              className="bg-zinc-950 border border-zinc-800 text-xs rounded px-2.5 py-1 text-zinc-200 font-mono focus:outline-none focus:border-indigo-500 cursor-pointer"
            >
              {fields.map(f => (
                <option key={f.id} value={f.id}>
                  {f.id}: {f.name} ({f.acres} ac)
                </option>
              ))}
            </select>
          </div>

          <p className="text-xs text-zinc-400 mb-5 leading-relaxed">
            Examine high-resolution sub-acre management zone chemistry derived from RTK-coupled disk coulters and thermal satellite imaging.
          </p>

          {/* Layer Selector */}
          <div className="flex flex-wrap gap-2 mb-4 font-mono text-[10px]">
            <span className="text-zinc-500 self-center uppercase tracking-wide mr-2">SPECTRAL LAYERS:</span>
            {[
              { id: 'NDVI', label: 'NDVI Vegetation index' },
              { id: 'N', label: 'Nitrogen (N) Density' },
              { id: 'P', label: 'Phosphorus (P) Density' },
              { id: 'K', label: 'Potassium (K) Density' },
              { id: 'pH', label: 'Soil pH' }
            ].map(layer => (
              <button
                key={layer.id}
                onClick={() => setActiveSoilLayer(layer.id as any)}
                className={`px-3 py-1 rounded border transition-colors cursor-pointer ${
                  activeSoilLayer === layer.id
                    ? 'bg-indigo-950/60 border-indigo-900/60 text-indigo-400 font-semibold'
                    : 'bg-zinc-950 border-zinc-800/80 hover:border-zinc-700 text-zinc-500 hover:text-zinc-300'
                }`}
              >
                {layer.label}
              </button>
            ))}
          </div>

          {/* Grid of zones */}
          {isLoadingZones ? (
            <div className="h-64 flex items-center justify-center text-xs font-mono text-zinc-500">
              Fitting sub-field chemical equations...
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {soilZones.map((zone) => {
                // Get active layer value
                let valueDisplay = '';
                let valueColor = 'text-zinc-200';
                
                if (activeSoilLayer === 'N') {
                  valueDisplay = `${zone.nitrogen} lbs/ac`;
                  valueColor = zone.nitrogen > 110 ? 'text-indigo-400' : 'text-yellow-400';
                } else if (activeSoilLayer === 'P') {
                  valueDisplay = `${zone.phosphorus} lbs/ac`;
                  valueColor = 'text-zinc-200';
                } else if (activeSoilLayer === 'K') {
                  valueDisplay = `${zone.potassium} lbs/ac`;
                  valueColor = 'text-zinc-200';
                } else if (activeSoilLayer === 'pH') {
                  valueDisplay = `${zone.pH} pH`;
                  valueColor = zone.pH >= 6.5 && zone.pH <= 7.2 ? 'text-emerald-400' : 'text-yellow-400';
                } else {
                  valueDisplay = `${zone.ndviIndex} NDVI`;
                  valueColor = zone.ndviIndex > 0.7 ? 'text-emerald-400' : 'text-yellow-400';
                }

                // Classification styling
                let classBadge = 'bg-zinc-950 text-zinc-500 border-zinc-800/80';
                if (zone.classification === 'High Productivity') classBadge = 'bg-emerald-950/40 text-emerald-400 border-emerald-900/50';
                else if (zone.classification === 'Water Constrained') classBadge = 'bg-blue-950/40 text-blue-400 border-blue-900/50';

                return (
                  <div
                    key={zone.id}
                    className="bg-zinc-950 border border-zinc-800/80 p-3.5 rounded-lg flex flex-col justify-between relative hover:border-zinc-700 hover:shadow-lg transition-all"
                  >
                    <div>
                      <div className="flex justify-between items-start mb-2">
                        <span className="font-bold text-xs text-zinc-200">{zone.name}</span>
                        <span className={`px-1.5 py-0.5 rounded text-[9px] font-mono border font-bold ${classBadge}`}>
                          {zone.classification}
                        </span>
                      </div>

                      <div className="grid grid-cols-3 gap-2 py-2 text-[10px] font-mono text-zinc-400 border-t border-b border-zinc-900/60 my-2">
                        <div>
                          <span className="text-[8px] text-zinc-500 block uppercase">N-P-K (lbs)</span>
                          <span>{zone.nitrogen}-{zone.phosphorus}-{zone.potassium}</span>
                        </div>
                        <div>
                          <span className="text-[8px] text-zinc-500 block uppercase">Soil pH</span>
                          <span className={zone.pH >= 6.5 && zone.pH <= 7.2 ? 'text-emerald-400 font-bold' : ''}>{zone.pH}</span>
                        </div>
                        <div>
                          <span className="text-[8px] text-zinc-500 block uppercase">Carbon</span>
                          <span>{zone.organicCarbonPercent}%</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex justify-between items-center pt-1 font-mono">
                      <span className="text-[10px] text-zinc-500 uppercase tracking-wider font-bold">Active Layer Reading:</span>
                      <span className={`text-xs font-bold ${valueColor}`}>{valueDisplay}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* CROP ROTATION INTEL SIMULATOR */}
        <div className="lg:col-span-4 bg-zinc-900/50 border border-zinc-800/80 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 pb-3 border-b border-zinc-800 mb-3">
              <Sliders className="w-5 h-5 text-indigo-400" />
              <h3 className="text-sm font-semibold uppercase tracking-wider text-white">
                R-Agronomy Rotation Optimizer
              </h3>
            </div>

            <p className="text-xs text-zinc-400 mb-4 leading-relaxed">
              Model multi-year cropping pathways. Solves organic carbon decomposition curves and calculates weed resistance factors under repeated inputs.
            </p>

            <form onSubmit={handleSimulateRotation} className="space-y-3 font-mono text-xs">
              <div>
                <label className="text-[10px] text-zinc-500 block mb-1">YEAR 1 CROP (CURRENT)</label>
                <select
                  value={rotYear1}
                  onChange={(e) => setRotYear1(e.target.value as CropType)}
                  className="w-full bg-zinc-950 border border-zinc-800/80 rounded p-1.5 text-zinc-100 font-mono focus:outline-none focus:border-indigo-500 cursor-pointer"
                >
                  <option value="Corn">Corn (Row Grass)</option>
                  <option value="Soybeans">Soybeans (Legume)</option>
                  <option value="Wheat">Wheat (Grain)</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] text-zinc-500 block mb-1">YEAR 2 CROP (PROJECTED)</label>
                <select
                  value={rotYear2}
                  onChange={(e) => setRotYear2(e.target.value as CropType)}
                  className="w-full bg-zinc-950 border border-zinc-800/80 rounded p-1.5 text-zinc-100 font-mono focus:outline-none focus:border-indigo-500 cursor-pointer"
                >
                  <option value="Corn">Corn (Row Grass)</option>
                  <option value="Soybeans">Soybeans (Legume)</option>
                  <option value="Wheat">Wheat (Grain)</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] text-zinc-500 block mb-1">YEAR 3 CROP (PROJECTED)</label>
                <select
                  value={rotYear3}
                  onChange={(e) => setRotYear3(e.target.value as CropType)}
                  className="w-full bg-zinc-950 border border-zinc-800/80 rounded p-1.5 text-zinc-100 font-mono focus:outline-none focus:border-indigo-500 cursor-pointer"
                >
                  <option value="Corn">Corn (Row Grass)</option>
                  <option value="Soybeans">Soybeans (Legume)</option>
                  <option value="Wheat">Wheat (Grain)</option>
                </select>
              </div>

              <button
                type="submit"
                disabled={isSimulatingRotation}
                className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-semibold py-2 px-4 rounded-lg transition-colors cursor-pointer disabled:opacity-50 text-xs"
              >
                {isSimulatingRotation ? 'R solver fitting biology curves...' : 'Simulate Crop Rotation Path'}
              </button>
            </form>
          </div>

          {/* Results display */}
          {rotationResult ? (
            <div className="mt-4 bg-zinc-950 p-3.5 border border-zinc-800/85 rounded-lg space-y-3 font-mono text-xs text-zinc-300">
              <div className="flex justify-between items-center border-b border-zinc-900 pb-2">
                <span className="text-[10px] text-zinc-500 uppercase">NPV MARGIN EXP:</span>
                <span className="font-bold text-indigo-400">${rotationResult.projectedMarginPerAcre}/ac</span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-center text-[11px]">
                <div className="bg-zinc-900/40 p-2 rounded border border-zinc-800/50">
                  <span className="text-[8px] text-zinc-500 block">SOIL HEALTH</span>
                  <span className="font-bold text-zinc-100">{rotationResult.soilHealthScore}%</span>
                </div>
                <div className="bg-zinc-900/40 p-2 rounded border border-zinc-800/50">
                  <span className="text-[8px] text-zinc-500 block">WEED RISK</span>
                  <span className="font-bold text-yellow-400">{rotationResult.weedPressureScore}%</span>
                </div>
              </div>

              <div className="p-2.5 bg-zinc-900/20 rounded border border-zinc-800/80 text-[10px] text-zinc-400 leading-relaxed flex gap-1.5 items-start">
                <CheckCircle2 className="w-4.5 h-4.5 text-indigo-400 shrink-0 mt-0.5" />
                <p>{rotationResult.agronomicEvaluation}</p>
              </div>
            </div>
          ) : (
            <div className="mt-4 border border-dashed border-zinc-800 rounded-lg p-6 text-center text-xs text-zinc-600">
              Submit a 3-year sequencing combination to execute organic depletion algorithms.
            </div>
          )}
        </div>

      </div>

      {/* 2. SATELLITE REMOTE SENSING & DISEASE ALERT CORES */}
      <div className="bg-zinc-900/50 border border-zinc-800/80 rounded-xl p-5">
        <div className="flex items-center gap-2 pb-4 border-b border-zinc-800 mb-4">
          <CloudLightning className="w-5 h-5 text-indigo-400" />
          <h3 className="text-sm font-semibold uppercase tracking-wider text-white">
            Satellite Multispectral Remote Sensing anomalies
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
          
          <div className="bg-zinc-950 p-4 rounded-lg border border-zinc-800/80">
            <span className="text-[9px] text-zinc-500 block font-bold uppercase mb-1">FIELD F-101 :: CORN</span>
            <span className="text-zinc-100 font-bold block mb-1">Tar Spot Mycelium Risk</span>
            <p className="text-[11px] text-zinc-400 leading-relaxed">
              Relative humidity thresholds coupled with 10-day heat indices indicate an 18% mycelium propagation probability. No immediate chemical treatment required.
            </p>
            <span className="text-[10px] text-zinc-500 block mt-2">Remote confidence: 82%</span>
          </div>

          <div className="bg-zinc-950 p-4 rounded-lg border border-zinc-800/80">
            <span className="text-[9px] text-zinc-500 block font-bold uppercase mb-1">FIELD F-201 :: WHEAT</span>
            <span className="text-yellow-400 font-bold block mb-1">Stripe Rust Lesion detection</span>
            <p className="text-[11px] text-zinc-400 leading-relaxed">
              Lower canopy spectral signature deviation matches Stripe Rust reflectance characteristics. Recommendation: Schedule drone scouting.
            </p>
            <span className="text-[10px] text-zinc-500 block mt-2">Remote confidence: 78%</span>
          </div>

          <div className="bg-zinc-950 p-4 rounded-lg border border-zinc-800/80">
            <span className="text-[9px] text-zinc-500 block font-bold uppercase mb-1">FIELD F-301 :: ORCHARDS</span>
            <span className="text-zinc-100 font-bold block mb-1">Xylem Water Deficit</span>
            <p className="text-[11px] text-zinc-400 leading-relaxed">
              Thermal infrared wavebands indicate localized stomatal closure in Fresno Grove Sector A, warning of soil transpiration constraints.
            </p>
            <span className="text-[10px] text-zinc-500 block mt-2">Remote confidence: 91%</span>
          </div>

        </div>
      </div>

    </div>
  );
}
