/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Recommendation } from '../types';
import { Compass, Sparkles, TrendingUp, Cpu, RefreshCw } from 'lucide-react';

interface RecommendationPanelProps {
  recommendations: Recommendation[];
  isLoading: boolean;
  onRefresh: () => void;
}

export default function RecommendationPanel({
  recommendations,
  isLoading,
  onRefresh
}: RecommendationPanelProps) {
  return (
    <div id="recommendation-panel" className="bg-zinc-900/50 border border-zinc-800/80 text-zinc-100 h-full flex flex-col rounded-xl overflow-hidden shadow-2xl">
      {/* Panel Header */}
      <div className="bg-zinc-950 px-4 py-3 border-b border-zinc-800/80 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Compass className="w-5 h-5 text-indigo-400 animate-pulse" />
          <h2 className="text-sm font-semibold tracking-wider uppercase text-white">
            Agronomic Decisions Advisor
          </h2>
        </div>
        <button
          onClick={onRefresh}
          disabled={isLoading}
          className="p-1 hover:bg-zinc-800 rounded text-zinc-400 hover:text-indigo-400 transition-colors disabled:opacity-50 cursor-pointer"
          title="Recalculate Advisor recommendations"
        >
          <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* Intro Text */}
      <div className="p-3 bg-zinc-950/40 border-b border-zinc-800/80 text-xs text-zinc-400 flex items-start gap-2">
        <Sparkles className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
        <p>
          The <span className="text-indigo-400 font-mono font-bold">R-Intelligence Engine</span> continuously fits regression frontiers across telemetry to calculate high-confidence, yield-maximizing guidance.
        </p>
      </div>

      {/* Recommendation Cards */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {recommendations.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center text-zinc-500 py-8">
            <Cpu className="w-8 h-8 mb-2 stroke-1" />
            <p className="text-xs">No active recommendations. Ensure simulation is running to generate diagnostic telemetry.</p>
          </div>
        ) : (
          recommendations.map((rec) => (
            <div
              key={rec.id}
              className="bg-zinc-950 border border-zinc-800 rounded-lg p-3 relative overflow-hidden transition-all hover:border-indigo-500/50 hover:shadow-[0_0_15px_-5px_rgba(99,102,241,0.15)]"
            >
              {/* Highlight Left Accent (Mathematical purpose, no side-tab borders on standard card, but is fine as a high contrast active state badge inside) */}
              <div className="absolute top-0 left-0 w-1 h-full bg-indigo-500" />

              {/* Top Meta info */}
              <div className="flex justify-between items-start gap-2 pl-2 mb-2">
                <span className="font-mono text-[10px] text-indigo-400 font-bold uppercase tracking-wider bg-indigo-950/40 px-1.5 py-0.5 rounded border border-indigo-900/40">
                  {rec.id}
                </span>
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] text-zinc-500 font-mono">CONFIDENCE</span>
                  <span className={`font-mono text-xs font-bold ${
                    rec.confidence >= 90 ? 'text-indigo-400' : rec.confidence >= 80 ? 'text-yellow-400' : 'text-orange-400'
                  }`}>
                    {rec.confidence}%
                  </span>
                </div>
              </div>

              {/* Recommendation Action */}
              <h3 className="text-xs font-bold text-white pl-2 leading-relaxed mb-2">
                {rec.action}
              </h3>

              {/* The "Why" */}
              <div className="pl-2 space-y-1 text-[11px] mb-3">
                <span className="text-zinc-500 uppercase font-bold font-mono tracking-wide block">Agronomic Diagnosis:</span>
                <p className="text-zinc-300 leading-relaxed bg-zinc-900/40 p-2 rounded border border-zinc-800/60">
                  {rec.why}
                </p>
              </div>

              {/* Expected Impact */}
              <div className="pl-2 flex items-start gap-2 text-[11px] text-indigo-400 bg-indigo-950/30 border border-indigo-900/40 p-2 rounded">
                <TrendingUp className="w-4 h-4 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold block uppercase tracking-wide text-[9px] text-indigo-500">Projected Value & Margin Impact</span>
                  <span className="leading-relaxed">{rec.expectedImpact}</span>
                </div>
              </div>

              {/* Data Utilized Logs */}
              <div className="mt-3 pl-2 pt-2 border-t border-zinc-900 flex flex-wrap gap-1.5">
                <span className="text-[9px] text-zinc-500 font-mono mr-1 self-center">FEED SOURCES:</span>
                {rec.dataUsed.map((src, i) => (
                  <span
                    key={i}
                    className="font-mono text-[9px] bg-zinc-900 text-zinc-400 px-1.5 py-0.5 rounded border border-zinc-800/80"
                  >
                    {src}
                  </span>
                ))}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
