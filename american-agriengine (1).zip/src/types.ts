/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Agricultural Regions in the US
export type AgriculturalRegion =
  | 'Midwest'
  | 'GreatPlains'
  | 'California'
  | 'PacificNorthwest'
  | 'MississippiDelta'
  | 'TexasSouthern';

export interface RegionConfig {
  id: AgriculturalRegion;
  name: string;
  totalAcres: number;
  averageRainfall: number; // inches/year
  primaryWaterSource: 'Groundwater' | 'Surface' | 'Ogallala Aquifer' | 'State Project' | 'River Basin';
  states: string[];
}

// Supported Crops
export type CropType =
  | 'Corn'
  | 'Soybeans'
  | 'Wheat'
  | 'Cotton'
  | 'Sorghum'
  | 'Potatoes'
  | 'Alfalfa'
  | 'Orchards'
  | 'Vineyards';

export interface CropModel {
  id: CropType;
  name: string;
  optimalTempRange: [number, number]; // [Min, Max] °F
  waterReqInches: number;
  nitrogenUnits: number; // lbs/acre
  phosphorusUnits: number; // lbs/acre
  potassiumUnits: number; // lbs/acre
  growingDays: number;
  expectedYieldPerAcre: number; // bu/acre, lbs/acre, tons/acre
  yieldUnit: string;
  basePrice: number; // per unit (bu, lb, ton)
  diseaseRiskFactors: string[];
}

// Autonomy State Machine
export type AutonomyState =
  | 'OFFLINE'
  | 'READY'
  | 'ARMED'
  | 'RUNNING'
  | 'PAUSED'
  | 'WAITING'
  | 'SAFE_STOP'
  | 'MANUAL_OVERRIDE'
  | 'FAULT'
  | 'COMPLETED';

// Machinery Types
export type MachineType =
  | 'Tractor'
  | 'Combine'
  | 'Planter'
  | 'Sprayer'
  | 'FertilizerSpreader'
  | 'GrainCart'
  | 'Truck'
  | 'Drone';

export interface Machine {
  id: string;
  name: string;
  type: MachineType;
  region: AgriculturalRegion;
  farmId: string;
  position: { x: number; y: number; lat: number; lng: number };
  heading: number; // degrees 0-359
  speed: number; // mph
  fuelLevel: number; // %
  batteryLevel: number; // %
  engineHours: number;
  autonomyState: AutonomyState;
  activeImplementId: string | null;
  currentMissionId: string | null;
  connectivity: boolean;
  healthIndex: number; // %
  workingWidthFeet: number;
  operator: string;
}

export interface Implement {
  id: string;
  name: string;
  type: 'Planter' | 'Sprayer' | 'FertilizerSpreader' | 'Mower' | 'GrainCart' | 'None';
  workingWidthFeet: number;
  tankCapacityGallons?: number;
  currentFillLevelPercent?: number;
}

// Field Digital Twin
export interface Field {
  id: string;
  name: string;
  farmId: string;
  region: AgriculturalRegion;
  acres: number;
  boundary: { x: number; y: number }[]; // Normalised coordinate polygon for UI map
  center: { lat: number; lng: number };
  currentCrop: CropType;
  plantingDate: string | null;
  expectedHarvestDate: string | null;
  soilMoisture: number; // %
  organicMatter: number; // %
  elevationFeet: number;
  slopePercent: number;
  yieldHistory: { year: number; yield: number }[];
  currentOperation: 'None' | 'Planting' | 'Spraying' | 'Fertilizing' | 'Irrigating' | 'Harvesting' | 'Scouting';
  currentYieldEstimates?: number; // bu/acre
}

// Soil Digital Twin & Management Zones
export interface SoilZone {
  id: string;
  fieldId: string;
  name: string; // e.g. "Zone A - High Yield Clay"
  nitrogen: number; // lbs/acre (0-200)
  phosphorus: number; // lbs/acre (0-100)
  potassium: number; // lbs/acre (0-300)
  pH: number; // 5.5 - 8.0
  organicCarbonPercent: number; // 0.5 - 6.0
  compactionIndex: number; // % (0-100)
  ndviIndex: number; // 0.0 - 1.0 (Vegetation index)
  moisturePercent: number; // %
  classification: 'High Productivity' | 'Medium Productivity' | 'Low Productivity' | 'Water Constrained';
}

// Missions
export interface Mission {
  id: string;
  name: string;
  farmId: string;
  fieldId: string;
  operation: 'Plant' | 'Spray' | 'Fertilize' | 'Irrigate' | 'Harvest' | 'Scout';
  priority: 'LOW' | 'MEDIUM' | 'HIGH';
  assignedMachineId: string | null;
  status: 'PENDING' | 'EXECUTING' | 'PAUSED' | 'COMPLETED' | 'ABORTED';
  targetRate?: string; // e.g., "32k seeds/acre", "15 gal/acre"
  progressPercent: number;
  startedAt: string | null;
  completedAt: string | null;
}

// Logistics Supply Chain
export interface LogisticsNode {
  id: string;
  name: string;
  type: 'Field' | 'Combine' | 'GrainCart' | 'Truck' | 'FarmBin' | 'Elevator' | 'Rail' | 'Processor';
  capacity: number; // bushels or tons
  currentFillLevel: number; // bushels or tons
  status: 'Idle' | 'Receiving' | 'Dispatching' | 'Full' | 'Transit';
  location: { x: number; y: number };
}

export interface CommodityMarket {
  crop: CropType;
  futuresPrice: number; // per bu or unit
  basisPrice: number; // regional modifier
  spotPrice: number; // spot = futures + basis
  dailyChangePercent: number;
  storageCostPerMonth: number;
  freightCostPerBushel: number;
}

// Economic Models
export interface FieldEconomics {
  fieldId: string;
  crop: CropType;
  grossRevenue: number;
  seedCost: number;
  fertilizerCost: number;
  chemicalCost: number;
  fuelCost: number;
  waterCost: number;
  laborCost: number;
  machineryCost: number;
  transportCost: number;
  netMargin: number;
}

// Scenarios & Simulation
export type SimulationScenario =
  | 'BASE_CASE'
  | 'EXTREME_DROUGHT'
  | 'HIGH_CORN_PRICE'
  | 'FUEL_FERTILIZER_SHOCK'
  | 'WATER_RESTRICTIONS'
  | 'LABOUR_SHORTAGE';

export interface SimulationState {
  currentDay: number; // Day of the agricultural year (1 to 365)
  season: 'Winter' | 'Spring' | 'Summer' | 'Autumn';
  simSpeed: number; // 0 = paused, 1 = 1x (day every 10s), 5 = 5x
  activeScenario: SimulationScenario;
  globalWeather: {
    tempF: number;
    rainfallInches: number;
    windSpeedMph: number;
    humidityPercent: number;
    forecast: string;
  };
  irrigationSilos: {
    totalCapacityAcreFt: number;
    currentStorageAcreFt: number;
    dailyUsageAcreFt: number;
  };
  financials: {
    totalAcres: number;
    operatingEbitda: number;
    projectedRevenue: number;
    realizedRevenue: number;
    costsTotal: number;
    capitalAllocated: number;
  };
  activeAlertsCount: number;
}

// Event System Log
export interface LiveEvent {
  id: string;
  timestamp: string;
  type:
    | 'MACHINE_STARTED'
    | 'MACHINE_STOPPED'
    | 'MISSION_CREATED'
    | 'MISSION_STARTED'
    | 'MISSION_COMPLETED'
    | 'FIELD_ENTERED'
    | 'FIELD_COMPLETED'
    | 'GEOFENCE_WARNING'
    | 'OBSTACLE_DETECTED'
    | 'LOW_FUEL'
    | 'SAFETY_SHUTDOWN'
    | 'WEATHER_ALERT'
    | 'YIELD_UPDATED'
    | 'COMMODITY_PRICE_UPDATED';
  message: string;
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
  machineId?: string;
  fieldId?: string;
}

// R explainable recommendation
export interface Recommendation {
  id: string;
  action: string;
  why: string;
  expectedImpact: string;
  confidence: number; // 0 - 100
  dataUsed: string[];
}
