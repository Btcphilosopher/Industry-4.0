/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  SimulationState,
  Machine,
  Field,
  LiveEvent,
  Recommendation,
  CommodityMarket,
  LogisticsNode,
  SimulationScenario
} from './types';

// Component imports
import RecommendationPanel from './components/RecommendationPanel';
import ExecutiveTerminal from './components/ExecutiveTerminal';
import OperationsTerminal from './components/OperationsTerminal';
import AgronomistTerminal from './components/AgronomistTerminal';
import MachineryTerminal from './components/MachineryTerminal';
import EconomicsTerminal from './components/EconomicsTerminal';

import {
  Compass,
  Cpu,
  Sliders,
  DollarSign,
  TrendingUp,
  Activity,
  AlertTriangle,
  Play,
  Pause,
  CloudSun,
  Shield,
  Clock,
  Briefcase,
  Layers,
  Sparkles
} from 'lucide-react';

export default function App() {
  // Global Fetched State
  const [simState, setSimState] = useState<SimulationState | null>(null);
  const [machines, setMachines] = useState<Machine[]>([]);
  const [fields, setFields] = useState<Field[]>([]);
  const [events, setEvents] = useState<LiveEvent[]>([]);
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [markets, setMarkets] = useState<CommodityMarket[]>([]);
  const [logistics, setLogistics] = useState<LogisticsNode[]>([]);
  
  const [activeTab, setActiveTab] = useState<'executive' | 'operations' | 'agronomist' | 'machinery' | 'economics'>('executive');
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshingRecs, setIsRefreshingRecs] = useState(false);
  const [currentTime, setCurrentTime] = useState('');

  // 1. Fetch data from local Express mock APIs (Simulating R & Rust threads)
  const fetchAllData = async (showLoading = false) => {
    if (showLoading) setIsLoading(true);
    try {
      const [simRes, machRes, fieldRes, eventRes, recRes, marketRes, logRes] = await Promise.all([
        fetch('/api/simulation'),
        fetch('/api/machinery'),
        fetch('/api/fields'),
        fetch('/api/events'),
        fetch('/api/recommendations'),
        fetch('/api/markets'),
        fetch('/api/logistics')
      ]);

      const [simData, machData, fieldData, eventData, recData, marketData, logData] = await Promise.all([
        simRes.json(),
        machRes.json(),
        fieldRes.json(),
        eventRes.json(),
        recRes.json(),
        marketRes.json(),
        logRes.json()
      ]);

      setSimState(simData);
      setMachines(machData);
      setFields(fieldData);
      setEvents(eventData);
      setRecommendations(recData);
      setMarkets(marketData);
      setLogistics(logData);
    } catch (e) {
      console.error("Error communicating with AgriEngine Core: ", e);
    } finally {
      setIsLoading(false);
    }
  };

  // Poll server state every 3000ms
  useEffect(() => {
    fetchAllData(true);
    const interval = setInterval(() => {
      fetchAllData(false);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  // Sync virtual clock
  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }) + ' UTC');
    };
    updateClock();
    const interval = setInterval(updateClock, 1000);
    return () => clearInterval(interval);
  }, []);

  // Trigger Scenario selection change
  const handleSelectScenario = async (sc: SimulationScenario) => {
    try {
      const res = await fetch('/api/simulation/scenario', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ scenario: sc })
      });
      const data = await res.json();
      setSimState(data);
      fetchAllData(false);
    } catch (e) {
      console.error(e);
    }
  };

  // Trigger simulation Speed controls (Resume / Pause)
  const handleToggleSimulation = async (speed: number) => {
    try {
      const res = await fetch('/api/simulation/toggle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ speed })
      });
      const data = await res.json();
      setSimState(data);
    } catch (e) {
      console.error(e);
    }
  };

  const handleRefreshRecs = async () => {
    setIsRefreshingRecs(true);
    // Simulate complex R matrix refitting delay
    setTimeout(async () => {
      await fetchAllData(false);
      setIsRefreshingRecs(false);
    }, 1200);
  };

  // Helper to map Day Number to elegant Gregorian Month string
  const getGregorianMonth = (dayNum: number) => {
    const date = new Date(2026, 0, dayNum);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  if (isLoading || !simState) {
    return (
      <div className="min-h-screen bg-zinc-950 text-indigo-400 flex flex-col items-center justify-center font-mono space-y-4">
        <Cpu className="w-12 h-12 animate-spin text-indigo-500" />
        <span className="text-xs uppercase tracking-widest animate-pulse text-zinc-400">
          Initializing Rust Safety Core & R Intelligence Sessions...
        </span>
      </div>
    );
  }

  // Active alarms severity mapping
  const alertColor = simState.activeAlertsCount > 0 
    ? 'text-red-400 border-red-900/50 animate-pulse bg-red-950/20' 
    : 'text-zinc-500 border-zinc-800';

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-300 flex flex-col selection:bg-indigo-600 selection:text-white">
      
      {/* 1. INDUSTRIAL CONTROL BAR HEADER */}
      <header className="bg-zinc-900/90 border-b border-zinc-800/80 p-4 sticky top-0 z-30 shadow-md backdrop-blur-sm">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
          
          {/* Brand & Corporate enterprise */}
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 bg-indigo-500 rounded-full animate-ping" />
              <h1 className="text-sm font-semibold uppercase tracking-wider font-mono text-white">
                American AgriEngine
              </h1>
              <span className="text-[10px] bg-zinc-950 border border-zinc-800 px-1.5 py-0.5 rounded font-mono text-zinc-500 font-bold">
                SYSTEM OS V2.6
              </span>
            </div>
            <p className="text-[10px] text-zinc-500 font-mono tracking-tight uppercase mt-0.5">
              Operating Corporate Asset: <span className="text-zinc-300 font-bold">Heartland Agricultural Group (284,000 Acres)</span>
            </p>
          </div>

          {/* High frequency System Telemetries HUD */}
          <div className="flex flex-wrap items-center gap-3 font-mono text-[10px]">
            <div className="bg-zinc-950 border border-zinc-800 p-1.5 px-3 rounded flex items-center gap-2">
              <Clock className="w-3.5 h-3.5 text-zinc-500" />
              <div>
                <span className="text-zinc-500 uppercase text-[8px] block">ENTERPRISE TIME</span>
                <span className="text-zinc-200 font-bold">{currentTime}</span>
              </div>
            </div>

            <div className="bg-zinc-950 border border-zinc-800 p-1.5 px-3 rounded flex items-center gap-2">
              <Layers className="w-3.5 h-3.5 text-zinc-500" />
              <div>
                <span className="text-zinc-500 uppercase text-[8px] block">AG CALENDAR</span>
                <span className="text-zinc-200 font-bold">
                  Day {simState.currentDay} ({getGregorianMonth(simState.currentDay)}) - {simState.season}
                </span>
              </div>
            </div>

            <div className="bg-zinc-950 border border-zinc-800 p-1.5 px-3 rounded flex items-center gap-2">
              <CloudSun className="w-3.5 h-3.5 text-zinc-500" />
              <div>
                <span className="text-zinc-500 uppercase text-[8px] block">GLOBAL WEATHER</span>
                <span className="text-zinc-200 font-bold">
                  {simState.globalWeather.tempF}°F / {simState.globalWeather.forecast}
                </span>
              </div>
            </div>

            {/* Active alert indicator */}
            <div className={`border p-1.5 px-3 rounded flex items-center gap-2 ${alertColor}`}>
              <AlertTriangle className="w-3.5 h-3.5" />
              <div>
                <span className="text-[8px] uppercase block font-bold">SAFETY EVENTS</span>
                <span className="font-bold">{simState.activeAlertsCount} WARNINGS</span>
              </div>
            </div>
          </div>

          {/* Dynamic Scenario Shocks selection */}
          <div className="flex items-center gap-2 bg-zinc-950 p-2 border border-zinc-800 rounded">
            <span className="text-[9px] font-mono text-zinc-500 uppercase font-bold tracking-wider mr-1">SCENARIO:</span>
            <select
              value={simState.activeScenario}
              onChange={(e) => handleSelectScenario(e.target.value as SimulationScenario)}
              className="bg-zinc-900 border border-zinc-800 text-xs rounded p-1 text-zinc-200 font-mono font-bold cursor-pointer focus:outline-none focus:border-indigo-500"
            >
              <option value="BASE_CASE">Standard Base Case</option>
              <option value="EXTREME_DROUGHT">Severe Midwest Drought</option>
              <option value="HIGH_CORN_PRICE">High Corn Price Tickers</option>
              <option value="FUEL_FERTILIZER_SHOCK">Fuel & Fertilizer Shock</option>
              <option value="WATER_RESTRICTIONS">State Irrigation Caps</option>
              <option value="LABOUR_SHORTAGE">Crew Dispatch Shortages</option>
            </select>
          </div>

        </div>
      </header>

      {/* 2. MAIN HUB INTERFACE GRID */}
      <main className="max-w-7xl w-full mx-auto p-4 flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* LEFT COLUMN: ACTIVE USER PORTFOLIO / TABBED TERMINALS */}
        <section className="lg:col-span-8 space-y-6">
          
          {/* Profile Terminal navigation tabs */}
          <div className="bg-zinc-900/60 p-1.5 rounded-lg border border-zinc-800/80 flex flex-wrap gap-1">
            {[
              { id: 'executive', label: 'Executive Terminal', icon: Briefcase },
              { id: 'operations', label: 'Operations Center', icon: Activity },
              { id: 'agronomist', label: 'Agronomist Lab', icon: Sparkles },
              { id: 'machinery', label: 'Fleet & Robotics', icon: Cpu },
              { id: 'economics', label: 'Economics & Logistics', icon: DollarSign }
            ].map(tab => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center gap-1.5 text-xs font-mono px-4 py-2 rounded-md font-medium uppercase transition-all cursor-pointer ${
                    activeTab === tab.id
                      ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-950/40 font-semibold'
                      : 'text-zinc-500 hover:text-zinc-200 hover:bg-zinc-900/50'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  {tab.label}
                </button>
              );
            })}

            {/* Simulation controls spacer */}
            <div className="ml-auto flex items-center gap-1.5 bg-zinc-950 border border-zinc-800 rounded px-2 text-[10px] font-mono">
              <span className="text-zinc-500 font-bold uppercase">CALENDAR STEP:</span>
              <button
                onClick={() => handleToggleSimulation(0)}
                className={`p-1 rounded ${simState.simSpeed === 0 ? 'bg-red-950/80 text-red-400 border border-red-900/50' : 'text-zinc-500 hover:text-zinc-300'}`}
                title="Pause Calendar"
              >
                <Pause className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => handleToggleSimulation(1)}
                className={`p-1 rounded ${simState.simSpeed === 1 ? 'bg-indigo-950/80 text-indigo-400 border border-indigo-900/50 font-bold' : 'text-zinc-500 hover:text-zinc-300'}`}
                title="Standard 1x Speed"
              >
                1x
              </button>
              <button
                onClick={() => handleToggleSimulation(5)}
                className={`p-1 rounded ${simState.simSpeed === 5 ? 'bg-indigo-950/80 text-indigo-400 border border-indigo-900/50 font-bold' : 'text-zinc-500 hover:text-zinc-300'}`}
                title="Fast 5x Speed"
              >
                5x
              </button>
            </div>
          </div>

          {/* Active Terminal Content Router */}
          <div className="transition-all duration-150">
            {activeTab === 'executive' && (
              <ExecutiveTerminal simState={simState} />
            )}

            {activeTab === 'operations' && (
              <OperationsTerminal
                machines={machines}
                fields={fields}
                events={events}
                onRefresh={() => fetchAllData(false)}
              />
            )}

            {activeTab === 'agronomist' && (
              <AgronomistTerminal fields={fields} />
            )}

            {activeTab === 'machinery' && (
              <MachineryTerminal machines={machines} />
            )}

            {activeTab === 'economics' && (
              <EconomicsTerminal
                markets={markets}
                logistics={logistics}
                onRefresh={() => fetchAllData(false)}
              />
            )}
          </div>
        </section>

        {/* RIGHT COLUMN: DECISION SYSTEM SIDEBAR */}
        <aside className="lg:col-span-4 h-full lg:sticky lg:top-24">
          <RecommendationPanel
            recommendations={recommendations}
            isLoading={isRefreshingRecs}
            onRefresh={handleRefreshRecs}
          />
        </aside>

      </main>

      {/* FOOTER */}
      <footer className="bg-zinc-900/80 border-t border-zinc-800/80 py-4 mt-12 text-center text-[10px] text-zinc-600 font-mono">
        <p className="uppercase tracking-widest">
          American AgriEngine Autonomous Systems Architecture © 2026. Real-time deterministic safety constraints enforced by Rust.
        </p>
      </footer>

    </div>
  );
}
