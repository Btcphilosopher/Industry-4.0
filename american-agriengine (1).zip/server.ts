/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import {
  AgriculturalRegion,
  CropType,
  AutonomyState,
  Machine,
  Field,
  SoilZone,
  Mission,
  LogisticsNode,
  CommodityMarket,
  FieldEconomics,
  LiveEvent,
  Recommendation,
  SimulationState,
  SimulationScenario
} from './src/types';

const app = express();
app.use(express.json());

const PORT = 3000;

// ==========================================
// STATIC INITIAL DATA SEED (SIMULATING POSTGRES/POSTGIS)
// ==========================================

const REGIONS_CONFIG = {
  Midwest: { name: 'Midwest Row Crops', totalAcres: 125000, states: ['IA', 'IL', 'IN'], water: 'Groundwater' },
  GreatPlains: { name: 'Great Plains Wheatbelt', totalAcres: 64000, states: ['KS', 'NE', 'OK'], water: 'Ogallala Aquifer' },
  California: { name: 'California Valley Specialty', totalAcres: 22000, states: ['CA'], water: 'State Project' },
  PacificNorthwest: { name: 'Pacific Northwest Grain', totalAcres: 31000, states: ['WA', 'OR', 'ID'], water: 'River Basin' },
  MississippiDelta: { name: 'Mississippi Delta Cotton', totalAcres: 24000, states: ['MS', 'AR', 'LA'], water: 'Surface' },
  TexasSouthern: { name: 'Texas Southern Plains', totalAcres: 18000, states: ['TX'], water: 'Ogallala Aquifer' }
};

const CROPS_MODEL: Record<CropType, any> = {
  Corn: { optimalTempRange: [50, 86], waterReqInches: 22, nitrogenUnits: 180, phosphorusUnits: 70, potassiumUnits: 80, growingDays: 120, expectedYieldPerAcre: 210, yieldUnit: 'bu', basePrice: 4.80, diseaseRiskFactors: ['Grey Leaf Spot', 'Tar Spot'] },
  Soybeans: { optimalTempRange: [60, 90], waterReqInches: 18, nitrogenUnits: 0, phosphorusUnits: 40, potassiumUnits: 60, growingDays: 110, expectedYieldPerAcre: 62, yieldUnit: 'bu', basePrice: 11.50, diseaseRiskFactors: ['White Mold', 'Sudden Death Syndrome'] },
  Wheat: { optimalTempRange: [40, 75], waterReqInches: 14, nitrogenUnits: 80, phosphorusUnits: 30, potassiumUnits: 40, growingDays: 240, expectedYieldPerAcre: 78, yieldUnit: 'bu', basePrice: 6.20, diseaseRiskFactors: ['Stripe Rust', 'Fusarium Head Blight'] },
  Cotton: { optimalTempRange: [65, 95], waterReqInches: 20, nitrogenUnits: 90, phosphorusUnits: 40, potassiumUnits: 60, growingDays: 150, expectedYieldPerAcre: 950, yieldUnit: 'lbs', basePrice: 0.72, diseaseRiskFactors: ['Boll Rot', 'Verticillium Wilt'] },
  Sorghum: { optimalTempRange: [60, 95], waterReqInches: 12, nitrogenUnits: 100, phosphorusUnits: 45, potassiumUnits: 50, growingDays: 105, expectedYieldPerAcre: 85, yieldUnit: 'bu', basePrice: 4.40, diseaseRiskFactors: ['Anthracnose', 'Head Smut'] },
  Potatoes: { optimalTempRange: [45, 75], waterReqInches: 26, nitrogenUnits: 200, phosphorusUnits: 100, potassiumUnits: 250, growingDays: 115, expectedYieldPerAcre: 420, yieldUnit: 'cwt', basePrice: 14.50, diseaseRiskFactors: ['Late Blight', 'Early Dying'] },
  Alfalfa: { optimalTempRange: [40, 85], waterReqInches: 30, nitrogenUnits: 10, phosphorusUnits: 60, potassiumUnits: 180, growingDays: 90, expectedYieldPerAcre: 6.5, yieldUnit: 'tons', basePrice: 220.00, diseaseRiskFactors: ['Alfalfa Weevil', 'Phytophthora Root Rot'] },
  Orchards: { optimalTempRange: [45, 85], waterReqInches: 36, nitrogenUnits: 120, phosphorusUnits: 50, potassiumUnits: 150, growingDays: 180, expectedYieldPerAcre: 18, yieldUnit: 'tons', basePrice: 480.00, diseaseRiskFactors: ['Fire Blight', 'Powdery Mildew'] },
  Vineyards: { optimalTempRange: [50, 80], waterReqInches: 16, nitrogenUnits: 40, phosphorusUnits: 20, potassiumUnits: 80, growingDays: 140, expectedYieldPerAcre: 5.2, yieldUnit: 'tons', basePrice: 950.00, diseaseRiskFactors: ['Downey Mildew', 'Pierce\'s Disease'] }
};

// Farm Field Digital Twins
let fields: Field[] = [
  // Midwest Fields
  { id: 'F-101', name: 'Lincoln Ridge F1', farmId: 'IA-01', region: 'Midwest', acres: 640, boundary: [{ x: 50, y: 50 }, { x: 120, y: 50 }, { x: 120, y: 120 }, { x: 50, y: 120 }], center: { lat: 41.8780, lng: -93.0977 }, currentCrop: 'Corn', plantingDate: '2026-04-20', expectedHarvestDate: '2026-09-25', soilMoisture: 42, organicMatter: 4.8, elevationFeet: 920, slopePercent: 1.2, yieldHistory: [{ year: 2024, yield: 218 }, { year: 2025, yield: 205 }], currentOperation: 'None', currentYieldEstimates: 222 },
  { id: 'F-102', name: 'Lincoln Ridge F2', farmId: 'IA-01', region: 'Midwest', acres: 480, boundary: [{ x: 130, y: 50 }, { x: 180, y: 50 }, { x: 180, y: 110 }, { x: 130, y: 110 }], center: { lat: 41.8810, lng: -93.0850 }, currentCrop: 'Soybeans', plantingDate: '2026-05-02', expectedHarvestDate: '2026-10-05', soilMoisture: 38, organicMatter: 4.5, elevationFeet: 915, slopePercent: 0.8, yieldHistory: [{ year: 2024, yield: 64 }, { year: 2025, yield: 58 }], currentOperation: 'None', currentYieldEstimates: 65 },
  { id: 'F-103', name: 'Platte North Section', farmId: 'IA-02', region: 'Midwest', acres: 320, boundary: [{ x: 50, y: 130 }, { x: 100, y: 130 }, { x: 100, y: 180 }, { x: 50, y: 180 }], center: { lat: 41.9050, lng: -93.1100 }, currentCrop: 'Corn', plantingDate: '2026-04-22', expectedHarvestDate: '2026-09-27', soilMoisture: 45, organicMatter: 5.1, elevationFeet: 935, slopePercent: 1.5, yieldHistory: [{ year: 2024, yield: 225 }, { year: 2025, yield: 210 }], currentOperation: 'None', currentYieldEstimates: 228 },
  { id: 'F-104', name: 'Wiota Flat S4', farmId: 'IA-03', region: 'Midwest', acres: 1280, boundary: [{ x: 110, y: 130 }, { x: 200, y: 130 }, { x: 200, y: 190 }, { x: 110, y: 190 }], center: { lat: 41.9210, lng: -93.0500 }, currentCrop: 'Corn', plantingDate: '2026-04-24', expectedHarvestDate: '2026-09-30', soilMoisture: 41, organicMatter: 4.2, elevationFeet: 890, slopePercent: 0.5, yieldHistory: [{ year: 2024, yield: 212 }, { year: 2025, yield: 198 }], currentOperation: 'None', currentYieldEstimates: 214 },

  // Great Plains Fields
  { id: 'F-201', name: 'Salina Sweep S1', farmId: 'KS-01', region: 'GreatPlains', acres: 1280, boundary: [{ x: 220, y: 50 }, { x: 310, y: 50 }, { x: 310, y: 140 }, { x: 220, y: 140 }], center: { lat: 38.8403, lng: -97.6114 }, currentCrop: 'Wheat', plantingDate: '2025-09-20', expectedHarvestDate: '2026-06-15', soilMoisture: 22, organicMatter: 2.1, elevationFeet: 1220, slopePercent: 0.2, yieldHistory: [{ year: 2024, yield: 74 }, { year: 2025, yield: 69 }], currentOperation: 'None', currentYieldEstimates: 76 },
  { id: 'F-202', name: 'Salina Sweep S2', farmId: 'KS-01', region: 'GreatPlains', acres: 640, boundary: [{ x: 320, y: 50 }, { x: 370, y: 50 }, { x: 370, y: 120 }, { x: 320, y: 120 }], center: { lat: 38.8450, lng: -97.5800 }, currentCrop: 'Sorghum', plantingDate: '2026-05-10', expectedHarvestDate: '2026-09-20', soilMoisture: 24, organicMatter: 2.3, elevationFeet: 1210, slopePercent: 0.3, yieldHistory: [{ year: 2024, yield: 82 }, { year: 2025, yield: 85 }], currentOperation: 'None', currentYieldEstimates: 88 },
  { id: 'F-203', name: 'Ogallala Pivot West', farmId: 'NE-01', region: 'GreatPlains', acres: 640, boundary: [{ x: 220, y: 150 }, { x: 280, y: 150 }, { x: 280, y: 210 }, { x: 220, y: 210 }], center: { lat: 41.1340, lng: -101.7180 }, currentCrop: 'Corn', plantingDate: '2026-04-28', expectedHarvestDate: '2026-10-02', soilMoisture: 35, organicMatter: 2.8, elevationFeet: 3220, slopePercent: 0.5, yieldHistory: [{ year: 2024, yield: 195 }, { year: 2025, yield: 185 }], currentOperation: 'None', currentYieldEstimates: 192 },

  // California Fields
  { id: 'F-301', name: 'Fresno Grove A', farmId: 'CA-01', region: 'California', acres: 320, boundary: [{ x: 390, y: 50 }, { x: 440, y: 50 }, { x: 440, y: 100 }, { x: 390, y: 100 }], center: { lat: 36.7378, lng: -119.7871 }, currentCrop: 'Orchards', plantingDate: '2020-03-10', expectedHarvestDate: '2026-09-10', soilMoisture: 32, organicMatter: 1.8, elevationFeet: 310, slopePercent: 0.1, yieldHistory: [{ year: 2024, yield: 16.5 }, { year: 2025, yield: 17.2 }], currentOperation: 'None', currentYieldEstimates: 18.1 },
  { id: 'F-302', name: 'Napa Terrace V2', farmId: 'CA-02', region: 'California', acres: 160, boundary: [{ x: 390, y: 110 }, { x: 430, y: 110 }, { x: 430, y: 150 }, { x: 390, y: 150 }], center: { lat: 38.2975, lng: -122.2869 }, currentCrop: 'Vineyards', plantingDate: '2018-04-15', expectedHarvestDate: '2026-10-01', soilMoisture: 28, organicMatter: 2.4, elevationFeet: 520, slopePercent: 8.5, yieldHistory: [{ year: 2024, yield: 4.8 }, { year: 2025, yield: 5.1 }], currentOperation: 'None', currentYieldEstimates: 5.3 },

  // Mississippi Delta
  { id: 'F-401', name: 'Yazoo Delta Cotton 1', farmId: 'MS-01', region: 'MississippiDelta', acres: 1280, boundary: [{ x: 50, y: 220 }, { x: 130, y: 220 }, { x: 130, y: 290 }, { x: 50, y: 290 }], center: { lat: 32.8550, lng: -90.4100 }, currentCrop: 'Cotton', plantingDate: '2026-05-01', expectedHarvestDate: '2026-10-15', soilMoisture: 44, organicMatter: 3.5, elevationFeet: 110, slopePercent: 0.1, yieldHistory: [{ year: 2024, yield: 920 }, { year: 2025, yield: 890 }], currentOperation: 'None', currentYieldEstimates: 960 },

  // Texas Southern
  { id: 'F-501', name: 'Lubbuck Red Plain', farmId: 'TX-01', region: 'TexasSouthern', acres: 640, boundary: [{ x: 150, y: 220 }, { x: 210, y: 220 }, { x: 210, y: 280 }, { x: 150, y: 280 }], center: { lat: 33.5779, lng: -101.8552 }, currentCrop: 'Cotton', plantingDate: '2026-05-05', expectedHarvestDate: '2026-10-20', soilMoisture: 25, organicMatter: 1.5, elevationFeet: 3200, slopePercent: 0.4, yieldHistory: [{ year: 2024, yield: 840 }, { year: 2025, yield: 810 }], currentOperation: 'None', currentYieldEstimates: 870 }
];

// Soil Management Zones (simulating rich geographical grids)
let soilZones: SoilZone[] = [];
fields.forEach((field) => {
  soilZones.push(
    { id: `${field.id}-Z-A`, fieldId: field.id, name: 'North Uplands Clay (Zone A)', nitrogen: 145, phosphorus: 62, potassium: 185, pH: 6.8, organicCarbonPercent: 3.2, compactionIndex: 12, ndviIndex: 0.78, moisturePercent: field.soilMoisture + 4, classification: 'High Productivity' },
    { id: `${field.id}-Z-B`, fieldId: field.id, name: 'Central Silty loam (Zone B)', nitrogen: 120, phosphorus: 45, potassium: 150, pH: 6.5, organicCarbonPercent: 2.8, compactionIndex: 22, ndviIndex: 0.69, moisturePercent: field.soilMoisture, classification: 'Medium Productivity' },
    { id: `${field.id}-Z-C`, fieldId: field.id, name: 'Southeastern Sandbar (Zone C)', nitrogen: 75, phosphorus: 28, potassium: 110, pH: 6.2, organicCarbonPercent: 1.4, compactionIndex: 35, ndviIndex: 0.45, moisturePercent: field.soilMoisture - 6, classification: 'Low Productivity' },
    { id: `${field.id}-Z-D`, fieldId: field.id, name: 'Western Lowland Depression (Zone D)', nitrogen: 110, phosphorus: 38, potassium: 130, pH: 7.2, organicCarbonPercent: 2.5, compactionIndex: 45, ndviIndex: 0.61, moisturePercent: field.soilMoisture + 10, classification: 'Water Constrained' }
  );
});

// Autonomous Machinery fleet
let machines: Machine[] = [
  { id: 'M-101', name: 'AgRover-T101', type: 'Tractor', region: 'Midwest', farmId: 'IA-01', position: { x: 80, y: 80, lat: 41.8782, lng: -93.0975 }, heading: 90, speed: 6.5, fuelLevel: 82, batteryLevel: 100, engineHours: 1240, autonomyState: 'RUNNING', activeImplementId: 'I-101', currentMissionId: 'MSN-101', connectivity: true, healthIndex: 94, workingWidthFeet: 60, operator: 'AutoPilot Primary' },
  { id: 'M-102', name: 'TerraBine-C201', type: 'Combine', region: 'Midwest', farmId: 'IA-01', position: { x: 150, y: 70, lat: 41.8812, lng: -93.0848 }, heading: 180, speed: 0, fuelLevel: 56, batteryLevel: 100, engineHours: 840, autonomyState: 'READY', activeImplementId: 'I-102', currentMissionId: null, connectivity: true, healthIndex: 91, workingWidthFeet: 45, operator: 'Remote Supervisor CA-01' },
  { id: 'M-103', name: 'AgRover-T102', type: 'Tractor', region: 'Midwest', farmId: 'IA-02', position: { x: 75, y: 150, lat: 41.9052, lng: -93.1098 }, heading: 270, speed: 0, fuelLevel: 12, batteryLevel: 100, engineHours: 1420, autonomyState: 'WAITING', activeImplementId: 'I-103', currentMissionId: null, connectivity: true, healthIndex: 85, workingWidthFeet: 40, operator: 'AutoPilot Backup' },
  { id: 'M-104', name: 'AquaPivot-I401', type: 'Tractor', region: 'GreatPlains', farmId: 'NE-01', position: { x: 250, y: 180, lat: 41.1342, lng: -101.7178 }, heading: 45, speed: 1.2, fuelLevel: 100, batteryLevel: 98, engineHours: 3150, autonomyState: 'RUNNING', activeImplementId: null, currentMissionId: 'MSN-102', connectivity: true, healthIndex: 98, workingWidthFeet: 1280, operator: 'Pivot Automated Controller' },
  { id: 'M-105', name: 'AeroScout-D501', type: 'Drone', region: 'California', farmId: 'CA-01', position: { x: 410, y: 75, lat: 36.7380, lng: -119.7869 }, heading: 315, speed: 22, fuelLevel: 0, batteryLevel: 78, engineHours: 140, autonomyState: 'RUNNING', activeImplementId: null, currentMissionId: 'MSN-103', connectivity: true, healthIndex: 99, workingWidthFeet: 100, operator: 'Aero Robotics Swarm Controller' },
  { id: 'M-106', name: 'AgRover-T103', type: 'Tractor', region: 'MississippiDelta', farmId: 'MS-01', position: { x: 90, y: 250, lat: 32.8552, lng: -90.4098 }, heading: 0, speed: 0, fuelLevel: 95, batteryLevel: 100, engineHours: 420, autonomyState: 'ARMED', activeImplementId: 'I-104', currentMissionId: null, connectivity: false, healthIndex: 88, workingWidthFeet: 120, operator: 'Supervisor Delta-East' },
  { id: 'M-107', name: 'Hercule-G301', type: 'GrainCart', region: 'Midwest', farmId: 'IA-01', position: { x: 100, y: 90, lat: 41.8795, lng: -93.0910 }, heading: 240, speed: 0, fuelLevel: 68, batteryLevel: 100, engineHours: 920, autonomyState: 'READY', activeImplementId: null, currentMissionId: null, connectivity: true, healthIndex: 92, workingWidthFeet: 20, operator: 'Adaptive Logistics Follower' }
];

// Implements linked to machines
let implementAssets = [
  { id: 'I-101', name: 'MaxEmerge-24R Planter', type: 'Planter', workingWidthFeet: 60 },
  { id: 'I-102', name: 'GrainHeader-45F', type: 'None', workingWidthFeet: 45 },
  { id: 'I-103', name: 'NutriPlacer-Liquid Fertilizer', type: 'FertilizerSpreader', workingWidthFeet: 40, tankCapacityGallons: 1000, currentFillLevelPercent: 32 },
  { id: 'I-104', name: 'TerrainSpray-120 Sprayer', type: 'Sprayer', workingWidthFeet: 120, tankCapacityGallons: 1600, currentFillLevelPercent: 95 }
];

// Logistics chain supply node network
let logisticsNodes: LogisticsNode[] = [
  { id: 'L-101', name: 'Lincoln Field Cart', type: 'GrainCart', capacity: 1500, currentFillLevel: 1200, status: 'Full', location: { x: 110, y: 100 } },
  { id: 'L-102', name: 'Midwest Bin 01 (Lincoln)', type: 'FarmBin', capacity: 100000, currentFillLevel: 62000, status: 'Receiving', location: { x: 140, y: 140 } },
  { id: 'L-103', name: 'Midwest Bin 02 (Wiota)', type: 'FarmBin', capacity: 250000, currentFillLevel: 145000, status: 'Idle', location: { x: 190, y: 150 } },
  { id: 'L-104', name: 'Enterprise Truck T-01', type: 'Truck', capacity: 1000, currentFillLevel: 0, status: 'Idle', location: { x: 130, y: 140 } },
  { id: 'L-105', name: 'Ames Union Elevator', type: 'Elevator', capacity: 5000000, currentFillLevel: 3100000, status: 'Receiving', location: { x: 230, y: 230 } },
  { id: 'L-106', name: 'BNSF Railway Railhead', type: 'Rail', capacity: 50000, currentFillLevel: 24000, status: 'Dispatching', location: { x: 300, y: 300 } },
  { id: 'L-107', name: 'ADM Cedar Rapids Mill', type: 'Processor', capacity: 10000000, currentFillLevel: 6400000, status: 'Receiving', location: { x: 420, y: 250 } }
];

// Commodity futures base values
let commodityPrices: CommodityMarket[] = [
  { crop: 'Corn', futuresPrice: 4.82, basisPrice: -0.22, spotPrice: 4.60, dailyChangePercent: 1.25, storageCostPerMonth: 0.05, freightCostPerBushel: 0.18 },
  { crop: 'Soybeans', futuresPrice: 11.45, basisPrice: -0.35, spotPrice: 11.10, dailyChangePercent: -0.84, storageCostPerMonth: 0.07, freightCostPerBushel: 0.22 },
  { crop: 'Wheat', futuresPrice: 6.28, basisPrice: -0.40, spotPrice: 5.88, dailyChangePercent: 0.45, storageCostPerMonth: 0.05, freightCostPerBushel: 0.25 },
  { crop: 'Cotton', futuresPrice: 0.74, basisPrice: -0.04, spotPrice: 0.70, dailyChangePercent: 2.10, storageCostPerMonth: 0.02, freightCostPerBushel: 0.05 },
  { crop: 'Sorghum', futuresPrice: 4.45, basisPrice: -0.30, spotPrice: 4.15, dailyChangePercent: 0.00, storageCostPerMonth: 0.05, freightCostPerBushel: 0.19 },
  { crop: 'Potatoes', futuresPrice: 14.50, basisPrice: 0.80, spotPrice: 15.30, dailyChangePercent: 0.15, storageCostPerMonth: 0.12, freightCostPerBushel: 0.45 },
  { crop: 'Alfalfa', futuresPrice: 220.00, basisPrice: -15.00, spotPrice: 205.00, dailyChangePercent: -1.10, storageCostPerMonth: 2.00, freightCostPerBushel: 12.00 },
  { crop: 'Orchards', futuresPrice: 480.00, basisPrice: 24.00, spotPrice: 504.00, dailyChangePercent: 0.50, storageCostPerMonth: 5.00, freightCostPerBushel: 24.00 },
  { crop: 'Vineyards', futuresPrice: 950.00, basisPrice: 50.00, spotPrice: 1000.00, dailyChangePercent: 0.90, storageCostPerMonth: 8.00, freightCostPerBushel: 35.00 }
];

// Active Autonomous Missions list
let activeMissions: Mission[] = [
  { id: 'MSN-101', name: 'Precision Corn Seeding S1', farmId: 'IA-01', fieldId: 'F-101', operation: 'Plant', priority: 'HIGH', assignedMachineId: 'M-101', status: 'EXECUTING', targetRate: '32,000 seeds/acre', progressPercent: 44, startedAt: '2026-08-10T06:00:00Z', completedAt: null },
  { id: 'MSN-102', name: 'Pivot Irrigation Segment C', farmId: 'NE-01', fieldId: 'F-203', operation: 'Irrigate', priority: 'HIGH', assignedMachineId: 'M-104', status: 'EXECUTING', targetRate: '0.75 inches', progressPercent: 12, startedAt: '2026-08-10T04:00:00Z', completedAt: null },
  { id: 'MSN-103', name: 'NDVI Canopy Thermal Scout', farmId: 'CA-01', fieldId: 'F-301', operation: 'Scout', priority: 'MEDIUM', assignedMachineId: 'M-105', status: 'EXECUTING', targetRate: 'Multispectral 10cm', progressPercent: 88, startedAt: '2026-08-10T07:00:00Z', completedAt: null }
];

// Real-time Event log
let eventLog: LiveEvent[] = [
  { id: 'E-101', timestamp: '2026-08-10T07:00:00Z', type: 'MISSION_CREATED', message: 'Mission MSN-103 "NDVI Canopy Thermal Scout" scheduled for drone AeroScout-D501.', severity: 'INFO', fieldId: 'F-301', machineId: 'M-105' },
  { id: 'E-102', timestamp: '2026-08-10T07:05:00Z', type: 'MACHINE_STARTED', message: 'AeroScout-D501 armed and launched autonomously.', severity: 'INFO', machineId: 'M-105' },
  { id: 'E-103', timestamp: '2026-08-10T07:15:00Z', type: 'GEOFENCE_WARNING', message: 'Autobolt Tractor M-101 approached geofenced drainage canal zone. Lateral vector adjustment applied.', severity: 'WARNING', fieldId: 'F-101', machineId: 'M-101' },
  { id: 'E-104', timestamp: '2026-08-10T07:22:00Z', type: 'YIELD_UPDATED', message: 'R-Analytics model updated yield expectation for F-101 to 222 bu/acre (+1.8%) due to optimal localized soil chemistry.', severity: 'INFO', fieldId: 'F-101' },
  { id: 'E-105', timestamp: '2026-08-10T07:30:00Z', type: 'WEATHER_ALERT', message: 'High wind warnings triggered for Kansas Great Plains region. Spray missions automatically deferred.', severity: 'WARNING' }
];

// AI recommendations by R engine
let recommendations: Recommendation[] = [
  { id: 'R-101', action: 'Delay Field 104 Planting by 8 Hours', why: 'Soil moisture is currently slightly under-hydrated. Regional NOAA radar projects a localized 0.4-inch rainfall event at 16:00 today, which will stabilize soil moisture parameters to ideal emergence levels.', expectedImpact: '+3.2% Emergence emergence velocity, saving 11% auxiliary irrigation groundwater requirements ($1,840 value).', confidence: 92, dataUsed: ['NOAA Weather Forecast', 'F-104 Moisture Sensors', 'R-Emergence Statistical Curve'] },
  { id: 'R-102', action: 'Reduce Nitrogen rates by 15 lbs/acre on F-101 Zone D', why: 'Variable-rate crop intelligence detects high residual organic matter saturation in lowland depressions (Zone D), indicating that excessive nitrogen application will trigger leaching rather than additional crop yield.', expectedImpact: '-15% Nitrogen footprint, saving $3,200 in raw material input procurement while preserving the 222 bu/acre harvest limit.', confidence: 88, dataUsed: ['PostGIS Soil Map F-101', 'NDVI Canopy Sensors', 'R-Nutrient Economic Frontier'] },
  { id: 'R-103', action: 'Perform Predictive Maintenance on Spreader Tractor M-103', why: 'Hydraulic high-frequency telemetry indicates micro-vibrations in hydraulic manifold pump B, with a statistical fatigue limit curve predicting a seal failure risk within 18 operational engine hours.', expectedImpact: 'Avoid in-field active deployment catastrophic failure, saving an estimated 6 hours of peak-season downtime and $2,400 repair surcharge.', confidence: 79, dataUsed: ['Tractor M-103 Telemetry', 'Deterministic Hydraulic Thresholds', 'R-Weibull Fatigue Engine'] }
];

// Current Simulation State
let simulationState: SimulationState = {
  currentDay: 222, // Aug 10
  season: 'Summer',
  simSpeed: 1, // 1 = Running
  activeScenario: 'BASE_CASE',
  globalWeather: {
    tempF: 84,
    rainfallInches: 0.05,
    windSpeedMph: 8.5,
    humidityPercent: 62,
    forecast: 'Sunny / Favorable'
  },
  irrigationSilos: {
    totalCapacityAcreFt: 8400000,
    currentStorageAcreFt: 6120000,
    dailyUsageAcreFt: 42000
  },
  financials: {
    totalAcres: 284000,
    operatingEbitda: 42450000,
    projectedRevenue: 136200000,
    realizedRevenue: 24800000,
    costsTotal: 84150000,
    capitalAllocated: 12500000
  },
  activeAlertsCount: 2
};

// ==========================================
// RUST & R CORE ENGINE LOGIC LOOPS (SIMULATORS)
// ==========================================

// Telemetry state update loop (runs in background on timer)
setInterval(() => {
  if (simulationState.simSpeed === 0) return;

  // 1. Advance agricultural day
  simulationState.currentDay += simulationState.simSpeed;
  if (simulationState.currentDay > 365) {
    simulationState.currentDay = 1;
  }

  // Derive season
  const day = simulationState.currentDay;
  if (day >= 355 || day < 80) simulationState.season = 'Winter';
  else if (day >= 80 && day < 172) simulationState.season = 'Spring';
  else if (day >= 172 && day < 265) simulationState.season = 'Summer';
  else simulationState.season = 'Autumn';

  // 2. Simulate Active Machinery Coordinates & State changes (Rust Telemetry simulation)
  machines.forEach((machine) => {
    if (machine.autonomyState === 'RUNNING') {
      // Small directional walk
      const angleRad = (machine.heading * Math.PI) / 180;
      const speedFactor = machine.speed * 0.005;
      
      machine.position.x += Math.cos(angleRad) * speedFactor * 15;
      machine.position.y += Math.sin(angleRad) * speedFactor * 15;
      
      // Keep inside a bounding grid for demo mapping
      if (machine.position.x < 10 || machine.position.x > 450) {
        machine.heading = (machine.heading + 180) % 360;
        machine.position.x = Math.max(15, Math.min(440, machine.position.x));
      }
      if (machine.position.y < 10 || machine.position.y > 320) {
        machine.heading = (machine.heading + 180) % 360;
        machine.position.y = Math.max(15, Math.min(310, machine.position.y));
      }

      // Decrement fuel / battery
      if (machine.type === 'Drone') {
        machine.batteryLevel = Math.max(0, machine.batteryLevel - 0.5 * simulationState.simSpeed);
        if (machine.batteryLevel < 10) {
          machine.autonomyState = 'READY';
          machine.speed = 0;
          createEvent('MACHINE_STOPPED', `Drone ${machine.name} returned and landed for autonomous inductive recharging.`, 'INFO', machine.id);
        }
      } else {
        machine.fuelLevel = Math.max(0, machine.fuelLevel - 0.1 * simulationState.simSpeed);
        if (machine.fuelLevel < 15 && machine.fuelLevel > 14) {
          createEvent('LOW_FUEL', `Machine ${machine.name} reports critical fuel levels (${Math.round(machine.fuelLevel)}%). Logistics dispatching diesel service.`, 'WARNING', machine.id);
        }
      }

      // Advance active missions
      if (machine.currentMissionId) {
        const mission = activeMissions.find(m => m.id === machine.currentMissionId);
        if (mission) {
          mission.progressPercent += 1.5 * simulationState.simSpeed;
          if (mission.progressPercent >= 100) {
            mission.progressPercent = 100;
            mission.status = 'COMPLETED';
            mission.completedAt = new Date().toISOString();
            machine.autonomyState = 'READY';
            machine.currentMissionId = null;
            machine.speed = 0;
            
            // Link mission completion to field operations ending
            const field = fields.find(f => f.id === mission.fieldId);
            if (field) {
              field.currentOperation = 'None';
              createEvent('MISSION_COMPLETED', `Autonomous ${mission.operation} mission on Field "${field.name}" was successfully executed. Coordinates checked and logged.`, 'INFO', machine.id, field.id);
            }
          }
        }
      }
    }
  });

  // 3. Dynamic Commodity markets simulation
  commodityPrices.forEach((price) => {
    const changePercent = (Math.random() - 0.49) * 0.4 * simulationState.simSpeed;
    price.dailyChangePercent = parseFloat(changePercent.toFixed(2));
    price.futuresPrice = parseFloat((price.futuresPrice * (1 + changePercent / 100)).toFixed(2));
    price.spotPrice = parseFloat((price.futuresPrice + price.basisPrice).toFixed(2));
  });

  // 4. Random Environment / Autonomous Engine events
  if (Math.random() < 0.05 * simulationState.simSpeed) {
    const eventTypes: Array<{ type: LiveEvent['type']; msg: string; sev: LiveEvent['severity'] }> = [
      { type: 'GEOFENCE_WARNING', msg: 'Implement drift boundary deviation corrected on Wiota Section field F-104.', sev: 'WARNING' },
      { type: 'WEATHER_ALERT', msg: 'Wind speed exceeds 15mph threshold. Chemical drift parameters adjusted.', sev: 'WARNING' },
      { type: 'YIELD_UPDATED', msg: 'Satellite NDVI mapping suggests 2% dry mass expansion in Midwest corn farms.', sev: 'INFO' },
      { type: 'OBSTACLE_DETECTED', msg: 'Active LIDAR scanning resolved a stationary thermal mass (whitetail deer) on F-101. Vehicle paused autonomously.', sev: 'CRITICAL' }
    ];
    const trigger = eventTypes[Math.floor(Math.random() * eventTypes.length)];
    createEvent(trigger.type, trigger.msg, trigger.sev);
  }
}, 3000);

// Helper to append log event
function createEvent(
  type: LiveEvent['type'],
  message: string,
  severity: LiveEvent['severity'] = 'INFO',
  machineId?: string,
  fieldId?: string
) {
  const newEv: LiveEvent = {
    id: `E-${Math.floor(Math.random() * 100000)}`,
    timestamp: new Date().toISOString(),
    type,
    message,
    severity,
    machineId,
    fieldId
  };
  eventLog.unshift(newEv);
  if (eventLog.length > 50) eventLog.pop();

  if (severity === 'CRITICAL' || severity === 'WARNING') {
    simulationState.activeAlertsCount += 1;
    
    // Safety Engine deterministic transition
    if (type === 'OBSTACLE_DETECTED' && machineId) {
      const mac = machines.find(m => m.id === machineId);
      if (mac) {
        mac.autonomyState = 'SAFE_STOP';
        mac.speed = 0;
        createEvent('SAFETY_SHUTDOWN', `Emergency safety stop triggered. Rust Safety Core intercepted autonomous controls on ${mac.name}.`, 'CRITICAL', mac.id);
      }
    }
  }
}

// ==========================================
// API ROUTING ENDPOINTS
// ==========================================

// Core Simulation State
app.get('/api/simulation', (req, res) => {
  res.json(simulationState);
});

app.post('/api/simulation/toggle', (req, res) => {
  const { speed } = req.body;
  if (speed !== undefined) {
    simulationState.simSpeed = speed;
    createEvent('MISSION_CREATED', `Simulation speed parameter updated to ${speed}x.`, 'INFO');
  }
  res.json(simulationState);
});

// Configure Scenario Shocks (R-Analytics dynamic forecast adjustments)
app.post('/api/simulation/scenario', (req, res) => {
  const { scenario } = req.body as { scenario: SimulationScenario };
  simulationState.activeScenario = scenario;

  // Trigger weather & economic adjustments immediately based on R model outputs
  if (scenario === 'EXTREME_DROUGHT') {
    simulationState.globalWeather = { tempF: 98, rainfallInches: 0, windSpeedMph: 12.0, humidityPercent: 18, forecast: 'Extreme Heatwave / Drought' };
    simulationState.financials.projectedRevenue *= 0.75; // 25% yield hit
    simulationState.financials.operatingEbitda *= 0.65; // High pumping costs + lower yields
    simulationState.financials.costsTotal += 4000000; // Pumping surcharges
    fields.forEach(f => {
      f.soilMoisture = Math.max(5, f.soilMoisture - 15);
      if (f.currentYieldEstimates) f.currentYieldEstimates *= 0.8;
    });
    recommendations = [
      { id: 'R-D01', action: 'Increase Drip Irrigation volumes by 25% on Grape Vineyards', why: 'Sap flow sensors denote severe water xylem pressure depletion under high temperature indices.', expectedImpact: 'Avoid grape skin shriveling, protecting $45,000 crop valuation on F-302.', confidence: 95, dataUsed: ['California Sap Telemetry', 'R-Evapotranspiration Grid'] },
      { id: 'R-D02', action: 'Suspend all active row crop fertilizing cycles', why: 'Fertilizing crops under water stress triggers salt damage around the roots, causing chemical burn.', expectedImpact: 'Avoid root burn, save $12,000 in unused input logistics cost.', confidence: 91, dataUsed: ['F-101 Moisture Sensors', 'Soil Nitrate Models'] }
    ];
    createEvent('WEATHER_ALERT', 'Global Enterprise scenario altered to: Extreme Drought. High Heat, zero rainfall simulation active.', 'CRITICAL');
  } 
  else if (scenario === 'HIGH_CORN_PRICE') {
    simulationState.globalWeather = { tempF: 78, rainfallInches: 0.15, windSpeedMph: 6.2, humidityPercent: 55, forecast: 'Optimal Agronomic Windows' };
    commodityPrices.forEach(p => {
      if (p.crop === 'Corn') {
        p.futuresPrice = 6.45;
        p.spotPrice = 6.45 + p.basisPrice;
      }
    });
    simulationState.financials.projectedRevenue *= 1.25;
    simulationState.financials.operatingEbitda *= 1.35;
    recommendations = [
      { id: 'R-H01', action: 'Maximize Corn Acre Allocations to 65% in next rotation cycle', why: 'R-Portfolio risk model forecasts futures peak persisting into Q4 based on South American harvest shortages.', expectedImpact: 'Boost overall portfolio NPV by an estimated $12.4M across all Midwest operations.', confidence: 89, dataUsed: ['CBOT Futures Forecast', 'R-Crop Rotation Frontier'] }
    ];
    createEvent('COMMODITY_PRICE_UPDATED', 'Corn market spiked to $6.45/bu due to global export supply disruptions.', 'INFO');
  }
  else if (scenario === 'FUEL_FERTILIZER_SHOCK') {
    simulationState.financials.costsTotal += 8500000;
    simulationState.financials.operatingEbitda *= 0.80;
    recommendations = [
      { id: 'R-S01', action: 'Transition fields to Minimum-Tillage / Strips-Till', why: 'Direct drill planting reduces heavy tractor tractive draft loading, slashing diesel consumption by 32% per acre.', expectedImpact: 'Saves 48,000 gallons of premium agricultural grade diesel across the Midwest division.', confidence: 86, dataUsed: ['Fuel Log Telemetry', 'Tractor Draft Models'] }
    ];
    createEvent('WEATHER_ALERT', 'Input Shock active: Fuel + Fertilizer costs inflated by 40% on future procurements.', 'WARNING');
  }
  else if (scenario === 'WATER_RESTRICTIONS') {
    simulationState.irrigationSilos.dailyUsageAcreFt = 18000;
    fields.forEach(f => {
      if (f.region === 'California' || f.region === 'TexasSouthern') {
        f.soilMoisture = Math.max(12, f.soilMoisture - 5);
      }
    });
    recommendations = [
      { id: 'R-W01', action: 'Implement Deficit Irrigation Protocols on F-301 Orchards', why: 'Water utility regulations enforce a 30% reduction in groundwater pumping volumes across Fresno county.', expectedImpact: 'Compliance with state agency, preserving orchard root life while decreasing seasonal growth by 4% max.', confidence: 94, dataUsed: ['County Regulations V4', 'Canopy Thermal Imaging'] }
    ];
    createEvent('WEATHER_ALERT', 'Water Restriction protocols enforced. Peak irrigation pumping strictly capped.', 'WARNING');
  }
  else if (scenario === 'LABOUR_SHORTAGE') {
    machines.forEach(m => {
      if (!m.connectivity && m.operator.includes('Supervisor')) {
        m.connectivity = true; // Switched to automatic satellite supervisor
      }
    });
    recommendations = [
      { id: 'R-L01', action: 'Arm full autonomous Level 4 swarm seeding operations on Wiota F-104', why: 'Human dispatcher shortage in Iowa Central region. Autopilot state machine is certified for driverless headland turns.', expectedImpact: 'Ensures planting finishes within the 10-day optimal moisture window without human crew surcharges.', confidence: 97, dataUsed: ['Crew Scheduling Database', 'Rust Geofence Verification'] }
    ];
    createEvent('WEATHER_ALERT', 'Human crew shortage detected. Promoting Autopilot machinery to high supervision status.', 'WARNING');
  }
  else { // BASE CASE
    simulationState.globalWeather = { tempF: 81, rainfallInches: 0.05, windSpeedMph: 7.2, humidityPercent: 58, forecast: 'Favorable Seasonal Weather' };
    simulationState.financials = {
      totalAcres: 284000,
      operatingEbitda: 42450000,
      projectedRevenue: 136200000,
      realizedRevenue: 24800000,
      costsTotal: 84150000,
      capitalAllocated: 12500000
    };
    recommendations = [
      { id: 'R-101', action: 'Delay Field 104 Planting by 8 Hours', why: 'Soil moisture is currently slightly under-hydrated. Regional NOAA radar projects a localized 0.4-inch rainfall event at 16:00 today.', expectedImpact: '+3.2% Emergence emergence velocity, saving 11% auxiliary irrigation groundwater.', confidence: 92, dataUsed: ['NOAA Weather Forecast', 'F-104 Moisture Sensors'] },
      { id: 'R-102', action: 'Reduce Nitrogen rates by 15 lbs/acre on F-101 Zone D', why: 'Variable-rate crop intelligence detects high residual organic matter saturation in lowland depressions (Zone D).', expectedImpact: '-15% Nitrogen footprint, saving $3,200 input procurement cost.', confidence: 88, dataUsed: ['PostGIS Soil Map F-101', 'NDVI Canopy Sensors'] }
    ];
    createEvent('MISSION_CREATED', 'Simulation reset to optimal standard US Base Case.', 'INFO');
  }

  res.json(simulationState);
});

// Machinery API
app.get('/api/machinery', (req, res) => {
  res.json(machines);
});

// Emergency Override Controls (Rust Safety Intercept Simulation)
app.post('/api/machinery/override', (req, res) => {
  const { machineId, state } = req.body as { machineId: string; state: AutonomyState };
  const mac = machines.find(m => m.id === machineId);
  if (!mac) return res.status(404).json({ error: 'Machine not found' });

  // Safety boundaries: Certain transitions are irreversible or locked by Rust safety core
  if (mac.autonomyState === 'SAFE_STOP' && state === 'RUNNING') {
    // Requires validation first
    createEvent('SAFETY_SHUTDOWN', `Resume command rejected for ${mac.name}. Safety regulations require manual field obstacle inspection before disarming SAFE_STOP.`, 'CRITICAL', mac.id);
    return res.status(400).json({ error: 'Failsafe lock active. Inspection required.' });
  }

  mac.autonomyState = state;
  if (state === 'SAFE_STOP' || state === 'OFFLINE' || state === 'PAUSED') {
    mac.speed = 0;
    createEvent('MACHINE_STOPPED', `Operator issued high-priority override: State set to ${state} for ${mac.name}.`, 'WARNING', mac.id);
  } else if (state === 'RUNNING') {
    mac.speed = mac.type === 'Drone' ? 22 : 6.5;
    createEvent('MACHINE_STARTED', `Autonomous mission controls resume on ${mac.name}. Entering standard vector paths.`, 'INFO', mac.id);
  }

  res.json(mac);
});

// Global Emergency Shutdown (Rust Safety Interceptor)
app.post('/api/machinery/emergency-stop', (req, res) => {
  machines.forEach(m => {
    if (m.autonomyState === 'RUNNING' || m.autonomyState === 'ARMED') {
      m.autonomyState = 'SAFE_STOP';
      m.speed = 0;
    }
  });
  createEvent('SAFETY_SHUTDOWN', 'CRITICAL ALL-FLEET EMERGENCY SHUTDOWN COMPLETED. All active autonomous machinery locked in SAFE_STOP coordinates.', 'CRITICAL');
  res.json({ status: 'Emergency Stop Active' });
});

// Fields API
app.get('/api/fields', (req, res) => {
  res.json(fields);
});

app.get('/api/fields/:id/zones', (req, res) => {
  const fZones = soilZones.filter(z => z.fieldId === req.params.id);
  res.json(fZones);
});

// Logistics supply path coordinates
app.get('/api/logistics', (req, res) => {
  res.json(logisticsNodes);
});

// Commodity Markets
app.get('/api/markets', (req, res) => {
  res.json(commodityPrices);
});

// Explainable recommendations
app.get('/api/recommendations', (req, res) => {
  res.json(recommendations);
});

// Events log
app.get('/api/events', (req, res) => {
  res.json(eventLog);
});

// Create autonomous mission
app.post('/api/missions/create', (req, res) => {
  const { farmId, fieldId, operation, priority, targetRate } = req.body;
  const field = fields.find(f => f.id === fieldId);
  if (!field) return res.status(404).json({ error: 'Field not found' });

  // Verify if a compatible machine is idle/ready in the region
  const compatibleMachine = machines.find(m => 
    m.region === field.region && 
    m.autonomyState === 'READY' &&
    (operation === 'Harvest' ? m.type === 'Combine' : m.type === 'Tractor' || m.type === 'Drone')
  );

  if (!compatibleMachine) {
    return res.status(400).json({ error: 'Rust Core Safety Reject: No compatible autonomous machinery is currently READY or positioned in this management region.' });
  }

  const newMsn: Mission = {
    id: `MSN-${Math.floor(Math.random() * 10000)}`,
    name: `Autonomous ${operation} on ${field.name}`,
    farmId,
    fieldId,
    operation,
    priority,
    assignedMachineId: compatibleMachine.id,
    status: 'EXECUTING',
    targetRate: targetRate || 'Variable Rate Prescribed',
    progressPercent: 0,
    startedAt: new Date().toISOString(),
    completedAt: null
  };

  activeMissions.push(newMsn);
  
  // Link machine to mission
  compatibleMachine.autonomyState = 'RUNNING';
  compatibleMachine.currentMissionId = newMsn.id;
  compatibleMachine.speed = compatibleMachine.type === 'Drone' ? 22 : 6.2;
  
  field.currentOperation = `${operation}ing` as any;

  createEvent('MISSION_STARTED', `Autonomous ${operation} mission "${newMsn.name}" launched. Assigned to machine ${compatibleMachine.name}. Geofences validated.`, 'INFO', compatibleMachine.id, field.id);

  res.json(newMsn);
});

// ==========================================
// R QUANTITATIVE SCIENCE ADVANCED ENDPOINTS (SIMULATING R SESSIONS)
// ==========================================

// R-Portfolio Optimizer: Solves linear constraints for optimum acres
app.post('/api/actions/optimizer', (req, res) => {
  const { maxBudget, riskTolerance, region } = req.body; // e.g. budget $10M, risk 0-100, region
  
  // R Optimization logic simulation
  // Maximize Expected Margin subject to crop rotation constraints and water budgets
  const activeCrops: CropType[] = region === 'California' 
    ? ['Orchards', 'Vineyards', 'Alfalfa'] 
    : region === 'GreatPlains' 
      ? ['Wheat', 'Sorghum', 'Corn']
      : ['Corn', 'Soybeans', 'Wheat'];

  const results = activeCrops.map((crop, index) => {
    const cropModel = CROPS_MODEL[crop];
    // R Optimization algorithm: allocate higher fractions to high-margin crops
    // subject to a quadratic risk penalty on concentration
    const price = commodityPrices.find(p => p.crop === crop)?.futuresPrice || cropModel.basePrice;
    const marginPerAcre = (cropModel.expectedYieldPerAcre * price) - (cropModel.nitrogenUnits * 0.8 + cropModel.waterReqInches * 5 + 150);
    
    // Fraction of acres allocated based on risk tolerance and margins
    let fraction = 0.3;
    if (index === 0) fraction = 0.5 + (riskTolerance / 400); // corn or primary
    if (index === 1) fraction = 0.3 - (riskTolerance / 800); // soy or stabilizer
    if (index === 2) fraction = 0.2; // wheat or orchard

    // Clamp fractions to sum to 1.0
    return {
      crop,
      marginPerAcre: Math.round(marginPerAcre),
      allocatedAcres: Math.round(fraction * 125000),
      expectedYield: Math.round(fraction * 125000 * cropModel.expectedYieldPerAcre),
      projectedNPV: Math.round(fraction * 125000 * marginPerAcre * 1.05),
      waterRequirementAcreFeet: Math.round((fraction * 125000 * cropModel.waterReqInches) / 12)
    };
  });

  const sumNPV = results.reduce((sum, item) => sum + item.projectedNPV, 0);
  const sumAcres = results.reduce((sum, item) => sum + item.allocatedAcres, 0);

  res.json({
    region,
    totalOptimalAcres: sumAcres,
    portfolioNPV: sumNPV,
    averageROI: parseFloat(((sumNPV / (maxBudget || 12000000)) * 100).toFixed(2)),
    allocations: results,
    explanation: `R lpSolve engine resolved constraints successfully in 4.2ms. Concentrated on high-yield frontier with a ${riskTolerance}% risk threshold buffer. Row crop rotations enforced to avoid soybean cyst nematode pressure.`
  });
});

// R Monte Carlo Risk Analyzer
app.post('/api/actions/montecarlo', (req, res) => {
  const { iterations = 500, region = 'Midwest' } = req.body;

  // Generate synthetic stochastic distributions of futures prices and weather shocks
  // Simulating 500 stochastic trials from joint probability frontiers
  const p10_revenue = 112400000;
  const p25_revenue = 124800000;
  const p50_revenue = 136200000;
  const p75_revenue = 148100000;
  const p90_revenue = 159400000;

  const p10_profit = 32100000;
  const p50_profit = 42450000;
  const p90_profit = 54800000;

  // Generate custom yield distribution charts
  const distributionChart = Array.from({ length: 15 }).map((_, i) => {
    const yieldValue = 180 + i * 5;
    // Gaussian-like density
    const z = (yieldValue - 212) / 12;
    const density = Math.exp(-0.5 * z * z) / (12 * Math.sqrt(2 * Math.PI));
    return {
      yield: yieldValue,
      probabilityDensity: parseFloat((density * 100).toFixed(4)),
      accumulatedProbability: parseFloat((1 / (1 + Math.exp(-1.7 * z)) * 100).toFixed(2))
    };
  });

  res.json({
    region,
    iterations,
    model: 'fable::TSLM autoregressive ARIMA joint-shocks',
    results: {
      revenue: { p10: p10_revenue, p25: p25_revenue, p50: p50_revenue, p75: p75_revenue, p90: p90_revenue },
      profit: { p10: p10_profit, p50: p50_profit, p90: p90_profit },
      lossProbabilityPercent: 1.2
    },
    distributionChart,
    summary: `Monte Carlo simulation finished. Under 500 simulated scenarios, the probability of regional margin loss is capped at 1.2%, with the P50 operating profit stabilized around $42.45M.`
  });
});

// R Multi-Year Crop Rotation Simulator
app.post('/api/actions/rotation', (req, res) => {
  const { cropSequence } = req.body as { cropSequence: CropType[] };
  
  if (!cropSequence || cropSequence.length < 3) {
    return res.status(400).json({ error: 'Sequence must be at least 3 years' });
  }

  // Evaluate soil compaction, nitrogen depletion, weed pressure, and net NPV
  let soilHealthScore = 82; // 0-100
  let weedPressureScore = 15; // 0-100 (lower is better)
  let projectedMarginPerAcre = 0;

  // Simple rule engine simulating agronomic heuristics from R
  const seqStr = cropSequence.join('->');
  if (seqStr === 'Corn->Soybeans->Corn') {
    soilHealthScore = 88;
    weedPressureScore = 18;
    projectedMarginPerAcre = 485;
  } else if (seqStr === 'Corn->Wheat->Soybeans') {
    soilHealthScore = 94; // rotation breaks disease cycles
    weedPressureScore = 8;
    projectedMarginPerAcre = 512;
  } else if (seqStr === 'Corn->Corn->Corn') {
    soilHealthScore = 52; // monoculture depletion
    weedPressureScore = 48; // high resistance risk
    projectedMarginPerAcre = 310;
  } else {
    soilHealthScore = 80;
    weedPressureScore = 22;
    projectedMarginPerAcre = 420;
  }

  res.json({
    sequence: seqStr,
    soilHealthScore,
    weedPressureScore,
    projectedMarginPerAcre,
    nitrogenCarryoverLbsPerAcre: cropSequence.includes('Soybeans') ? 45 : 10,
    agronomicEvaluation: soilHealthScore > 85 
      ? 'R-Agronomy Engine recommends this sequence. Alternating nitrogen-fixing legumes (Soybeans) with high-intake grass (Corn) suppresses rootworm larvae and preserves topsoil carbon.'
      : 'Monoculture or high-frequency grass crop rotations detected. Soil depletion risk is high, necessitating extensive supplementary synthetic fertilizers (+18% fertilizer expenses projected).'
  });
});

// R Farmland Value Acquisition Estimator
app.post('/api/actions/land-evaluate', (req, res) => {
  const { acres, waterRightsAcreFt, clayPercent, historicalYieldbu } = req.body;

  // Quantitative pricing model: Land value is a function of clay density, water security, and yield history
  const baseValue = acres * 6200; // standard Midwest land value
  const yieldBonus = (historicalYieldbu - 180) * 120 * acres; // premium for high-yield history
  const waterBonus = waterRightsAcreFt * 850; // premium for secure water allocations
  const valuation = baseValue + yieldBonus + waterBonus;

  res.json({
    acres,
    soilSuitabilityIndex: parseFloat(( (100 - Math.abs(clayPercent - 28)) / 100 ).toFixed(2)), // 28% clay is ideal for corn
    calculatedFairValue: Math.round(valuation),
    costPerAcre: Math.round(valuation / acres),
    projectedPaybackYears: parseFloat(( valuation / (acres * 480) ).toFixed(1)),
    analysis: `R-Investment model rates this asset. Cap rate projected at 5.8% based on immediate water securities. The Ogallala depletion risk is mitigated by ${waterRightsAcreFt} dedicated acre-feet of historic groundwater permits.`
  });
});


// ==========================================
// VITE DEV SERVER / PRODUCTION SERVING
// ==========================================

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
