"""Charging station allocation and battery-lifecycle management."""
from __future__ import annotations

from dataclasses import dataclass

from backend.warehouse.models import ChargingStation
from robotics.robot_models.robot import RobotState, RobotStatus


@dataclass(slots=True)
class ChargingPolicy:
    low_battery_threshold_pct: float = 25.0
    critical_battery_threshold_pct: float = 10.0
    full_charge_target_pct: float = 95.0
    reserve_headroom_slots: int = 1


class ChargingManager:
    """Decides which robots need to charge and reserves stations for them."""

    def __init__(self, stations: dict[str, ChargingStation], policy: ChargingPolicy | None = None) -> None:
        self.stations = stations
        self.policy = policy or ChargingPolicy()

    def needs_charging(self, robot: RobotState) -> bool:
        if robot.status in (RobotStatus.CHARGING, RobotStatus.MOVING_TO_CHARGE):
            return False
        return robot.battery_pct <= self.policy.low_battery_threshold_pct

    def is_critical(self, robot: RobotState) -> bool:
        return robot.battery_pct <= self.policy.critical_battery_threshold_pct

    def nearest_available_station(self, robot: RobotState) -> ChargingStation | None:
        available = [s for s in self.stations.values() if s.available_slots > 0]
        if not available:
            return None
        return min(
            available,
            key=lambda s: (s.position.x - robot.x) ** 2 + (s.position.y - robot.y) ** 2,
        )

    def begin_charging(self, station: ChargingStation, robot_id: str) -> bool:
        if station.available_slots <= 0:
            return False
        station.occupied_by.append(robot_id)
        return True

    def finish_charging(self, station: ChargingStation, robot_id: str) -> None:
        if robot_id in station.occupied_by:
            station.occupied_by.remove(robot_id)

    def apply_charge_tick(self, robot: RobotState, station: ChargingStation, dt_seconds: float) -> None:
        wh_added = station.charge_rate_w * (dt_seconds / 3600.0)
        capacity_wh = robot.capabilities().battery_capacity_wh or 1.0
        pct_added = (wh_added / capacity_wh) * 100.0
        robot.battery_pct = min(100.0, robot.battery_pct + pct_added)

    def utilisation(self) -> float:
        total_slots = sum(s.slots for s in self.stations.values())
        used = sum(len(s.occupied_by) for s in self.stations.values())
        return used / total_slots if total_slots else 0.0
