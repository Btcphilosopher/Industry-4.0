"""Intelligent multi-factor task allocation.

Deliberately *not* round-robin. Each idle, capable robot is scored against
a candidate task on several weighted factors and the highest-scoring robot
wins. Weights are configurable so the optimisation layer can tune them
per-scenario (see ``optimisation.fleet_optimisation``) without touching
this module's logic.
"""
from __future__ import annotations

from dataclasses import dataclass

from backend.orchestration.tasks import Task, TaskPriority
from robotics.navigation.graph import WarehouseGraph
from robotics.navigation.pathfinding import Route, RouteNotFoundError, a_star
from robotics.robot_models.robot import RobotState


@dataclass(slots=True)
class AllocationWeights:
    distance: float = 1.0
    battery: float = 0.8
    payload_fit: float = 0.6
    congestion: float = 0.7
    priority: float = 1.2
    health: float = 0.5
    workload_balance: float = 0.4


@dataclass(slots=True)
class Candidate:
    robot_id: str
    score: float
    route: Route
    eta_seconds: float


class NoCapableRobotError(RuntimeError):
    pass


class TaskAllocator:
    """Scores idle robots against a task and returns the best candidate."""

    def __init__(self, graph: WarehouseGraph, weights: AllocationWeights | None = None) -> None:
        self.graph = graph
        self.weights = weights or AllocationWeights()

    def find_best_robot(
        self,
        task: Task,
        robots: dict[str, RobotState],
        *,
        robot_task_counts: dict[str, int] | None = None,
    ) -> Candidate:
        robot_task_counts = robot_task_counts or {}
        if not task.source:
            raise ValueError(f"task {task.task_id} has no source node to route from")

        candidates: list[Candidate] = []
        for robot in robots.values():
            if not robot.is_available_for_work():
                continue
            if task.required_robot_type and robot.robot_type.value != task.required_robot_type:
                continue
            if not robot.can_perform(task.task_type.value):
                continue
            caps = robot.capabilities()
            if task.payload_kg > caps.max_payload_kg:
                continue
            if robot.current_node is None:
                continue

            try:
                priority_boost = 2.0 if task.priority >= TaskPriority.HIGH else 0.0
                route = a_star(
                    self.graph, robot.current_node, task.source,
                    priority_boost=priority_boost, avg_speed_mps=max(caps.max_speed_mps, 0.1),
                )
            except RouteNotFoundError:
                continue

            eta = route.total_cost
            score = self._score(task, robot, route, eta, robot_task_counts.get(robot.robot_id, 0))
            candidates.append(Candidate(robot.robot_id, score, route, eta))

        if not candidates:
            raise NoCapableRobotError(
                f"no capable, reachable, idle robot found for task {task.task_id} ({task.task_type})"
            )
        candidates.sort(key=lambda c: c.score, reverse=True)
        return candidates[0]

    def _score(
        self, task: Task, robot: RobotState, route: Route, eta_seconds: float, workload: int
    ) -> float:
        w = self.weights
        caps = robot.capabilities()

        distance_score = 1.0 / (1.0 + eta_seconds / 30.0)
        battery_score = min(1.0, robot.battery_pct / 100.0)
        # Penalise very low battery heavily so it doesn't get sent further out.
        if robot.battery_pct < 25:
            battery_score *= 0.3
        payload_fit = 1.0 - abs(caps.max_payload_kg - task.payload_kg) / (caps.max_payload_kg + 1.0)
        congestion_score = 1.0 / (1.0 + self._route_congestion(route))
        priority_score = float(task.priority) / float(TaskPriority.CRITICAL)
        health_score = robot.health_score
        workload_score = 1.0 / (1.0 + workload)

        return (
            w.distance * distance_score
            + w.battery * battery_score
            + w.payload_fit * payload_fit
            + w.congestion * congestion_score
            + w.priority * priority_score
            + w.health * health_score
            + w.workload_balance * workload_score
        )

    def _route_congestion(self, route: Route) -> float:
        total = 0
        for a, b in zip(route.node_ids, route.node_ids[1:]):
            total += self.graph.congestion(a, b)
        return total
