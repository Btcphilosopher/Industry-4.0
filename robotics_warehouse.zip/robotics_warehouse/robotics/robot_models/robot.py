"""Robot domain models: classes, capabilities, and live state.

These are plain, strongly-typed dataclasses rather than an ORM model --
robot state changes at very high frequency (position/velocity every tick)
and should never round-trip through the transactional database directly.
Persistence of a *summary* happens through ``database.repositories``.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import StrEnum


class RobotType(StrEnum):
    AMR = "AMR"
    AGV = "AGV"
    AUTOMATED_FORKLIFT = "AUTOMATED_FORKLIFT"
    PALLET_SHUTTLE = "PALLET_SHUTTLE"
    PICKING_ROBOT = "PICKING_ROBOT"
    ROBOTIC_ARM = "ROBOTIC_ARM"
    SORTER_ROBOT = "SORTER_ROBOT"
    INSPECTION_ROBOT = "INSPECTION_ROBOT"
    CLEANING_ROBOT = "CLEANING_ROBOT"
    INVENTORY_DRONE = "INVENTORY_DRONE"


class RobotStatus(StrEnum):
    IDLE = "IDLE"
    EXECUTING_TASK = "EXECUTING_TASK"
    MOVING_TO_CHARGE = "MOVING_TO_CHARGE"
    CHARGING = "CHARGING"
    FAULTED = "FAULTED"
    MAINTENANCE = "MAINTENANCE"
    OFFLINE = "OFFLINE"
    BLOCKED = "BLOCKED"
    ESTOP = "ESTOP"


class ConnectivityState(StrEnum):
    ONLINE = "ONLINE"
    DEGRADED = "DEGRADED"
    LOST = "LOST"


# Static capability envelope per robot class. Real values would come from
# the manufacturer's spec sheet / commissioning data; these are reasonable
# industrial defaults used for simulation and for validating task fitness.
@dataclass(frozen=True, slots=True)
class RobotCapabilities:
    max_speed_mps: float
    max_payload_kg: float
    battery_capacity_wh: float
    idle_power_w: float
    travel_power_w: float
    lift_power_w: float
    charge_rate_w: float
    supported_task_types: frozenset[str]
    can_carry_pallet: bool = False


CAPABILITY_PROFILES: dict[RobotType, RobotCapabilities] = {
    RobotType.AMR: RobotCapabilities(
        max_speed_mps=1.8, max_payload_kg=250, battery_capacity_wh=1200,
        idle_power_w=15, travel_power_w=180, lift_power_w=0, charge_rate_w=900,
        supported_task_types=frozenset({"MOVE", "PICK", "PUTAWAY", "TRANSFER", "REPLENISH"}),
    ),
    RobotType.AGV: RobotCapabilities(
        max_speed_mps=1.2, max_payload_kg=500, battery_capacity_wh=1800,
        idle_power_w=20, travel_power_w=260, lift_power_w=0, charge_rate_w=1200,
        supported_task_types=frozenset({"MOVE", "TRANSFER", "LOAD", "UNLOAD"}),
        can_carry_pallet=True,
    ),
    RobotType.AUTOMATED_FORKLIFT: RobotCapabilities(
        max_speed_mps=2.0, max_payload_kg=1500, battery_capacity_wh=4800,
        idle_power_w=40, travel_power_w=600, lift_power_w=900, charge_rate_w=3000,
        supported_task_types=frozenset({"MOVE", "LOAD", "UNLOAD", "PUTAWAY", "TRANSFER"}),
        can_carry_pallet=True,
    ),
    RobotType.PALLET_SHUTTLE: RobotCapabilities(
        max_speed_mps=1.5, max_payload_kg=1000, battery_capacity_wh=900,
        idle_power_w=10, travel_power_w=150, lift_power_w=200, charge_rate_w=700,
        supported_task_types=frozenset({"MOVE", "PUTAWAY", "TRANSFER"}),
        can_carry_pallet=True,
    ),
    RobotType.PICKING_ROBOT: RobotCapabilities(
        max_speed_mps=1.0, max_payload_kg=25, battery_capacity_wh=600,
        idle_power_w=12, travel_power_w=90, lift_power_w=40, charge_rate_w=500,
        supported_task_types=frozenset({"PICK", "COUNT", "INSPECT"}),
    ),
    # Modelled as a mobile manipulator cell (arm-on-AMR base) rather than a
    # bolted-down arm, so it can be routed to a packing/sorting station like
    # any other fleet asset while still drawing meaningful travel + actuator
    # power -- a common real deployment pattern alongside fixed-base arms.
    RobotType.ROBOTIC_ARM: RobotCapabilities(
        max_speed_mps=1.0, max_payload_kg=40, battery_capacity_wh=700,
        idle_power_w=60, travel_power_w=140, lift_power_w=300, charge_rate_w=600,
        supported_task_types=frozenset({"PACK", "SORT", "PICK", "LOAD"}),
    ),
    RobotType.SORTER_ROBOT: RobotCapabilities(
        max_speed_mps=2.5, max_payload_kg=15, battery_capacity_wh=400,
        idle_power_w=10, travel_power_w=70, lift_power_w=0, charge_rate_w=350,
        supported_task_types=frozenset({"SORT", "MOVE"}),
    ),
    RobotType.INSPECTION_ROBOT: RobotCapabilities(
        max_speed_mps=1.0, max_payload_kg=5, battery_capacity_wh=350,
        idle_power_w=8, travel_power_w=60, lift_power_w=0, charge_rate_w=300,
        supported_task_types=frozenset({"INSPECT", "COUNT"}),
    ),
    RobotType.CLEANING_ROBOT: RobotCapabilities(
        max_speed_mps=0.8, max_payload_kg=0, battery_capacity_wh=800,
        idle_power_w=10, travel_power_w=200, lift_power_w=0, charge_rate_w=600,
        supported_task_types=frozenset({"MOVE"}),
    ),
    RobotType.INVENTORY_DRONE: RobotCapabilities(
        max_speed_mps=3.0, max_payload_kg=0, battery_capacity_wh=180,
        idle_power_w=5, travel_power_w=140, lift_power_w=0, charge_rate_w=200,
        supported_task_types=frozenset({"COUNT", "INSPECT"}),
    ),
}


@dataclass(slots=True)
class RobotState:
    """The continuously-updated live state of a single robot.

    This mirrors the example in the spec:
        RobotState(robot_id="AMR-042", x=125.4, y=82.7, heading=1.57,
                   velocity=1.4, battery=72.5, payload=184.0,
                   status="EXECUTING_TASK")
    """

    robot_id: str
    robot_type: RobotType
    x: float = 0.0
    y: float = 0.0
    heading: float = 0.0
    velocity: float = 0.0
    battery_pct: float = 100.0
    payload_kg: float = 0.0
    status: RobotStatus = RobotStatus.IDLE
    current_node: str | None = None
    destination_node: str | None = None
    current_task_id: str | None = None
    connectivity: ConnectivityState = ConnectivityState.ONLINE
    motor_temp_c: float = 32.0
    fault_code: str | None = None
    health_score: float = 1.0
    odometer_m: float = 0.0
    hours_in_service: float = 0.0
    last_updated: datetime = field(default_factory=lambda: datetime.now(UTC))

    def capabilities(self) -> RobotCapabilities:
        return CAPABILITY_PROFILES[self.robot_type]

    def can_perform(self, task_type: str) -> bool:
        return task_type in self.capabilities().supported_task_types

    def is_available_for_work(self) -> bool:
        return self.status == RobotStatus.IDLE and self.connectivity == ConnectivityState.ONLINE

    def as_public_dict(self) -> dict:
        """Serialisable snapshot for API / dashboard / digital twin consumers."""
        return {
            "robot_id": self.robot_id,
            "robot_type": self.robot_type.value,
            "x": round(self.x, 3),
            "y": round(self.y, 3),
            "heading": round(self.heading, 3),
            "velocity": round(self.velocity, 3),
            "battery_pct": round(self.battery_pct, 2),
            "payload_kg": round(self.payload_kg, 2),
            "status": self.status.value,
            "current_task_id": self.current_task_id,
            "destination_node": self.destination_node,
            "connectivity": self.connectivity.value,
            "motor_temp_c": round(self.motor_temp_c, 2),
            "fault_code": self.fault_code,
            "health_score": round(self.health_score, 3),
        }
