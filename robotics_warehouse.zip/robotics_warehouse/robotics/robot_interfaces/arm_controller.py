"""Hardware-agnostic robotic arm control interface.

Real robotic-arm vendors (Universal Robots, Fanuc, ABB, KUKA, ...) each
expose their own SDK/protocol. The platform never talks to a vendor SDK
directly -- everything above this layer talks to :class:`RobotArmController`,
and a concrete adapter translates that into vendor-specific calls. Swapping
hardware means writing a new adapter, not touching orchestration code.
"""
from __future__ import annotations

import abc
import asyncio
import random
from dataclasses import dataclass


@dataclass(slots=True)
class ArmPosition:
    x: float
    y: float
    z: float
    yaw: float = 0.0


class ArmFault(RuntimeError):
    """Raised when the arm reports a fault during a command."""


class RobotArmController(abc.ABC):
    """Abstract control surface for a robotic arm / picking cell."""

    @abc.abstractmethod
    async def move_to(self, position: ArmPosition) -> None: ...

    @abc.abstractmethod
    async def pick(self, object_id: str) -> bool:
        """Attempt to grasp ``object_id``. Returns True on a verified grasp."""

    @abc.abstractmethod
    async def place(self, location: str) -> bool:
        """Place the currently-held object at ``location``. Returns True on success."""

    @abc.abstractmethod
    async def emergency_stop(self) -> None: ...

    @abc.abstractmethod
    async def health(self) -> dict:
        """Return a vendor-neutral health snapshot (temps, cycle count, faults)."""


class SimulatedArmController(RobotArmController):
    """Deterministic (seedable) simulated arm used by the digital twin and tests.

    A real deployment would replace this with e.g. ``URArmController`` or
    ``FanucArmController`` that speaks the vendor's native protocol but
    implements this exact interface.
    """

    def __init__(self, arm_id: str, *, seed: int | None = None, pick_success_rate: float = 0.97) -> None:
        self.arm_id = arm_id
        self._rng = random.Random(seed)
        self.pick_success_rate = pick_success_rate
        self._position = ArmPosition(0, 0, 0)
        self._holding: str | None = None
        self._cycle_count = 0
        self._stopped = False

    async def move_to(self, position: ArmPosition) -> None:
        if self._stopped:
            raise ArmFault(f"{self.arm_id}: cannot move, e-stop engaged")
        await asyncio.sleep(0)  # yield control; a real adapter awaits the vendor RPC here
        self._position = position

    async def pick(self, object_id: str) -> bool:
        if self._stopped:
            raise ArmFault(f"{self.arm_id}: cannot pick, e-stop engaged")
        self._cycle_count += 1
        success = self._rng.random() < self.pick_success_rate
        if success:
            self._holding = object_id
        return success

    async def place(self, location: str) -> bool:
        if self._stopped:
            raise ArmFault(f"{self.arm_id}: cannot place, e-stop engaged")
        if self._holding is None:
            return False
        self._holding = None
        return True

    async def emergency_stop(self) -> None:
        self._stopped = True

    async def health(self) -> dict:
        return {
            "arm_id": self.arm_id,
            "cycle_count": self._cycle_count,
            "holding": self._holding,
            "stopped": self._stopped,
        }
