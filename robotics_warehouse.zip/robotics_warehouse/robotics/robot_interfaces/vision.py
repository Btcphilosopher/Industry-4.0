"""Industrial computer-vision integration interface.

Represents vision-system events (cameras, barcode scanners, depth cameras,
LiDAR, OCR, pallet recognition, dimensional measurement) with one
consistent event shape, regardless of vendor. Concrete adapters
(``OpenCVVisionAdapter``, a vendor SDK adapter, ...) publish
:class:`VisionEvent` instances onto the event bus; nothing downstream needs
to know which camera model or SDK produced them.
"""
from __future__ import annotations

import abc
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import StrEnum


class VisionObjectType(StrEnum):
    PALLET = "PALLET"
    CARTON = "CARTON"
    TOTE = "TOTE"
    BARCODE = "BARCODE"
    HUMAN = "HUMAN"
    OBSTACLE = "OBSTACLE"
    SKU_LABEL = "SKU_LABEL"


@dataclass(frozen=True, slots=True)
class VisionEvent:
    camera_id: str
    object_type: VisionObjectType
    confidence: float
    position: tuple[float, float]
    timestamp: datetime = field(default_factory=lambda: datetime.now(UTC))
    dimensions_m: tuple[float, float, float] | None = None
    decoded_text: str | None = None  # OCR / barcode payload


class VisionAdapter(abc.ABC):
    """Hardware-agnostic interface for a vision/sensing station."""

    @abc.abstractmethod
    async def capture(self) -> list[VisionEvent]:
        """Trigger a capture cycle and return detected objects."""

    @abc.abstractmethod
    async def calibrate(self) -> bool: ...


class PickVerificationResult:
    """Outcome of comparing an expected pick against a post-pick vision capture."""

    __slots__ = ("confidence", "detail", "verified")

    def __init__(self, verified: bool, confidence: float, detail: str = "") -> None:
        self.verified = verified
        self.confidence = confidence
        self.detail = detail


def verify_pick(expected_sku: str, events: list[VisionEvent], *, min_confidence: float = 0.85) -> PickVerificationResult:
    """Cross-check a pick against vision events (e.g. a barcode/OCR read of the gripper)."""
    for event in events:
        if event.decoded_text == expected_sku and event.confidence >= min_confidence:
            return PickVerificationResult(True, event.confidence, "sku matched")
    return PickVerificationResult(False, 0.0, "no matching detection")
