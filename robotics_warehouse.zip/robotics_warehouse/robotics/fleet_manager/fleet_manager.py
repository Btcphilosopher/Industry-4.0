"""Central robot fleet manager.

Registers robots, monitors health/connectivity, assigns tasks via the
intelligent :class:`TaskAllocator`, reroutes robots when conditions change,
manages charging, prevents collisions via the :class:`SafetyLayer`, and
recovers failed tasks. This is the WCS (Warehouse Control System) core.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass

from backend.events.event_bus import EventBus
from backend.events.event_types import (
    BatteryLow,
    RobotDisconnected,
    RobotEnteredCharging,
    RobotFaultDetected,
    RobotRegistered,
    TaskAssigned,
    TaskFailed,
)
from backend.orchestration.tasks import Task, TaskStatus
from backend.warehouse.models import ChargingStation
from robotics.charging.charging_manager import ChargingManager
from robotics.collision_avoidance.safety import SafetyLayer
from robotics.navigation.graph import WarehouseGraph
from robotics.navigation.pathfinding import Route
from robotics.robot_models.robot import ConnectivityState, RobotState, RobotStatus
from robotics.task_allocator.allocator import AllocationWeights, NoCapableRobotError, TaskAllocator

logger = logging.getLogger("robotics_warehouse.fleet_manager")


@dataclass(slots=True)
class FleetSnapshot:
    total: int
    by_status: dict[str, int]
    avg_battery_pct: float
    avg_health_score: float


class FleetManager:
    """Owns the live set of robots and coordinates their work."""

    def __init__(
        self,
        graph: WarehouseGraph,
        charging_stations: dict[str, ChargingStation],
        event_bus: EventBus,
        *,
        allocation_weights: AllocationWeights | None = None,
    ) -> None:
        self.graph = graph
        self.event_bus = event_bus
        self.robots: dict[str, RobotState] = {}
        self.allocator = TaskAllocator(graph, allocation_weights)
        self.safety = SafetyLayer()
        self.charging = ChargingManager(charging_stations)
        self._robot_task_counts: dict[str, int] = {}
        self._task_history_by_robot: dict[str, int] = {}
        self.active_routes: dict[str, Route] = {}

    # --- registration & monitoring -----------------------------------------

    def register_robot(self, robot: RobotState) -> None:
        if robot.robot_id in self.robots:
            raise ValueError(f"robot {robot.robot_id} already registered")
        self.robots[robot.robot_id] = robot
        self.event_bus.publish_nowait(
            RobotRegistered(robot_id=robot.robot_id, robot_type=robot.robot_type.value)
        )

    def deregister_robot(self, robot_id: str) -> None:
        self.robots.pop(robot_id, None)

    def mark_disconnected(self, robot_id: str) -> None:
        robot = self.robots.get(robot_id)
        if robot is None:
            return
        robot.connectivity = ConnectivityState.LOST
        robot.status = RobotStatus.OFFLINE
        self.event_bus.publish_nowait(RobotDisconnected(robot_id=robot_id))

    def report_fault(self, robot_id: str, fault_code: str, detail: str = "") -> None:
        robot = self.robots.get(robot_id)
        if robot is None:
            return
        robot.status = RobotStatus.FAULTED
        robot.fault_code = fault_code
        self.event_bus.publish_nowait(
            RobotFaultDetected(robot_id=robot_id, fault_code=fault_code, detail=detail)
        )

    def check_battery_alerts(self) -> None:
        for robot in self.robots.values():
            if self.charging.needs_charging(robot):
                self.event_bus.publish_nowait(
                    BatteryLow(robot_id=robot.robot_id, battery_pct=robot.battery_pct)
                )

    # --- task assignment ----------------------------------------------------

    def assign_task(self, task: Task) -> str | None:
        """Attempt to allocate ``task`` to the best available robot.

        Returns the assigned robot_id, or None if no robot could be found
        (the task remains QUEUED and will be retried on the next cycle).
        """
        try:
            candidate = self.allocator.find_best_robot(
                task, self.robots, robot_task_counts=self._robot_task_counts
            )
        except NoCapableRobotError:
            return None

        robot = self.robots[candidate.robot_id]
        robot.status = RobotStatus.EXECUTING_TASK
        robot.current_task_id = task.task_id
        robot.destination_node = task.source
        task.assigned_robot = robot.robot_id
        task.transition(TaskStatus.ASSIGNED)
        task.estimated_duration_s = candidate.eta_seconds
        self.active_routes[robot.robot_id] = candidate.route
        self._robot_task_counts[robot.robot_id] = self._robot_task_counts.get(robot.robot_id, 0) + 1
        self._task_history_by_robot[robot.robot_id] = self._task_history_by_robot.get(robot.robot_id, 0) + 1
        self.event_bus.publish_nowait(TaskAssigned(task_id=task.task_id, robot_id=robot.robot_id))
        return robot.robot_id

    def release_robot(self, robot_id: str) -> None:
        robot = self.robots.get(robot_id)
        if robot is None:
            return
        robot.status = RobotStatus.IDLE
        robot.current_task_id = None
        robot.destination_node = None
        self.active_routes.pop(robot_id, None)
        self._robot_task_counts[robot_id] = max(0, self._robot_task_counts.get(robot_id, 0) - 1)

    def recover_failed_task(self, task: Task, reason: str) -> None:
        """Recovery: unassign robot, requeue the task for reallocation."""
        if task.assigned_robot:
            self.release_robot(task.assigned_robot)
        task.failure_reason = reason
        task.retry_count += 1
        if task.status not in (TaskStatus.FAILED,):
            task.transition(TaskStatus.FAILED)
        self.event_bus.publish_nowait(
            TaskFailed(task_id=task.task_id, robot_id=task.assigned_robot, reason=reason)
        )
        if task.retry_count <= 3:
            task.assigned_robot = None
            task.transition(TaskStatus.QUEUED)

    # --- charging management -------------------------------------------------

    def dispatch_to_charging(self, robot_id: str) -> bool:
        robot = self.robots.get(robot_id)
        if robot is None or robot.status not in (RobotStatus.IDLE,):
            return False
        station = self.charging.nearest_available_station(robot)
        if station is None:
            return False
        if not self.charging.begin_charging(station, robot_id):
            return False
        robot.status = RobotStatus.MOVING_TO_CHARGE
        robot.destination_node = station.station_id
        self.event_bus.publish_nowait(
            RobotEnteredCharging(robot_id=robot_id, station_id=station.station_id)
        )
        return True

    # --- rebalancing / prioritisation ----------------------------------------

    def rebalance_candidates(self, congestion_threshold: int = 8) -> list[str]:
        """Return robots idling in congested zones that should be redeployed."""
        candidates = []
        for robot in self.robots.values():
            if robot.status != RobotStatus.IDLE or robot.current_node is None:
                continue
            local_congestion = sum(
                self.graph.congestion(robot.current_node, e.to_id)
                for e in self.graph.neighbours(robot.current_node)
            )
            if local_congestion >= congestion_threshold:
                candidates.append(robot.robot_id)
        return candidates

    # --- snapshot / reporting -------------------------------------------------

    def snapshot(self) -> FleetSnapshot:
        by_status: dict[str, int] = {}
        battery_sum = 0.0
        health_sum = 0.0
        for robot in self.robots.values():
            by_status[robot.status.value] = by_status.get(robot.status.value, 0) + 1
            battery_sum += robot.battery_pct
            health_sum += robot.health_score
        n = len(self.robots) or 1
        return FleetSnapshot(
            total=len(self.robots),
            by_status=by_status,
            avg_battery_pct=battery_sum / n,
            avg_health_score=health_sum / n,
        )
