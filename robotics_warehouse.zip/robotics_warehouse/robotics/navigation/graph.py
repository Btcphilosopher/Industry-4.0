"""Warehouse navigation graph.

The warehouse floor is modelled as a weighted directed graph of ``Node``
(intersections, storage-aisle entry points, charging stations, docks,
staging areas...) connected by ``Edge`` segments that robots traverse.
Edge weights combine physical distance with a live congestion penalty so
routing naturally spreads traffic without needing a separate "traffic"
concept bolted on afterwards.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


class NodeKind(StrEnum):
    INTERSECTION = "INTERSECTION"
    STORAGE = "STORAGE"
    CHARGING = "CHARGING"
    DOCK = "DOCK"
    STAGING = "STAGING"
    PACKING = "PACKING"
    ROBOTIC_CELL = "ROBOTIC_CELL"


@dataclass(slots=True)
class Node:
    node_id: str
    x: float
    y: float
    kind: NodeKind = NodeKind.INTERSECTION
    zone_id: str | None = None
    restricted: bool = False
    human_occupied: bool = False


@dataclass(slots=True)
class Edge:
    from_id: str
    to_id: str
    distance_m: float
    max_speed_mps: float = 1.5
    bidirectional: bool = True
    blocked: bool = False


class WarehouseGraph:
    """Adjacency-list graph with live congestion tracking per edge."""

    def __init__(self) -> None:
        self.nodes: dict[str, Node] = {}
        self._adj: dict[str, dict[str, Edge]] = {}
        self._edge_traffic: dict[tuple[str, str], int] = {}

    def add_node(self, node: Node) -> None:
        self.nodes[node.node_id] = node
        self._adj.setdefault(node.node_id, {})

    def add_edge(self, edge: Edge) -> None:
        self._adj.setdefault(edge.from_id, {})[edge.to_id] = edge
        if edge.bidirectional:
            reverse = Edge(
                from_id=edge.to_id, to_id=edge.from_id, distance_m=edge.distance_m,
                max_speed_mps=edge.max_speed_mps, bidirectional=False, blocked=edge.blocked,
            )
            self._adj.setdefault(edge.to_id, {})[edge.from_id] = reverse

    def neighbours(self, node_id: str) -> list[Edge]:
        return list(self._adj.get(node_id, {}).values())

    def edge(self, a: str, b: str) -> Edge | None:
        return self._adj.get(a, {}).get(b)

    def set_blocked(self, a: str, b: str, blocked: bool) -> None:
        e = self.edge(a, b)
        if e:
            e.blocked = blocked

    def record_traffic(self, a: str, b: str, delta: int) -> None:
        key = (a, b)
        self._edge_traffic[key] = max(0, self._edge_traffic.get(key, 0) + delta)

    def congestion(self, a: str, b: str) -> int:
        return self._edge_traffic.get((a, b), 0)

    def traversal_cost(self, edge: Edge, *, priority_boost: float = 0.0) -> float:
        """Cost of traversing ``edge`` right now: distance + congestion penalty.

        Congestion penalty grows superlinearly so heavily-used corridors are
        avoided well before they deadlock, matching real AMR fleet routing
        behaviour (congestion-aware routing, see spec section 6).
        """
        if edge.blocked:
            return float("inf")
        to_node = self.nodes.get(edge.to_id)
        if to_node and (to_node.restricted or to_node.human_occupied):
            return float("inf")
        traffic = self.congestion(edge.from_id, edge.to_id)
        congestion_penalty = (traffic ** 1.6) * 0.75
        base_time = edge.distance_m / max(edge.max_speed_mps, 0.1)
        return max(0.0, base_time + congestion_penalty - priority_boost)
