"""Route planning: A*, Dijkstra, and dynamic replanning helpers.

Both algorithms operate on :class:`~robotics.navigation.graph.WarehouseGraph`
and share the same congestion-aware edge cost function, so switching
strategies never changes what "cost" means -- only how the search explores.
"""
from __future__ import annotations

import heapq
from dataclasses import dataclass

from robotics.navigation.graph import WarehouseGraph


@dataclass(slots=True)
class Route:
    node_ids: list[str]
    total_cost: float
    total_distance_m: float

    @property
    def is_empty(self) -> bool:
        return len(self.node_ids) < 2


class RouteNotFoundError(RuntimeError):
    pass


def _euclidean(graph: WarehouseGraph, a: str, b: str) -> float:
    na, nb = graph.nodes[a], graph.nodes[b]
    return ((na.x - nb.x) ** 2 + (na.y - nb.y) ** 2) ** 0.5


def _reconstruct(came_from: dict[str, str], start: str, goal: str) -> list[str]:
    path = [goal]
    node = goal
    while node != start:
        node = came_from[node]
        path.append(node)
    path.reverse()
    return path


def a_star(
    graph: WarehouseGraph,
    start: str,
    goal: str,
    *,
    priority_boost: float = 0.0,
    avg_speed_mps: float = 1.5,
) -> Route:
    """A* search using Euclidean distance / avg-speed as the admissible heuristic."""
    if start not in graph.nodes or goal not in graph.nodes:
        raise RouteNotFoundError(f"unknown node in route request: {start} -> {goal}")
    if start == goal:
        return Route([start], 0.0, 0.0)

    open_heap: list[tuple[float, str]] = [(0.0, start)]
    came_from: dict[str, str] = {}
    g_score: dict[str, float] = {start: 0.0}
    visited: set[str] = set()

    def h(node_id: str) -> float:
        return _euclidean(graph, node_id, goal) / avg_speed_mps

    while open_heap:
        _, current = heapq.heappop(open_heap)
        if current in visited:
            continue
        if current == goal:
            path = _reconstruct(came_from, start, goal)
            return Route(path, g_score[goal], _path_distance(graph, path))
        visited.add(current)

        for edge in graph.neighbours(current):
            cost = graph.traversal_cost(edge, priority_boost=priority_boost)
            if cost == float("inf"):
                continue
            tentative = g_score[current] + cost
            if tentative < g_score.get(edge.to_id, float("inf")):
                came_from[edge.to_id] = current
                g_score[edge.to_id] = tentative
                heapq.heappush(open_heap, (tentative + h(edge.to_id), edge.to_id))

    raise RouteNotFoundError(f"no route found from {start} to {goal}")


def dijkstra(graph: WarehouseGraph, start: str, goal: str) -> Route:
    """Dijkstra's algorithm -- used as a fallback / baseline comparison for A*."""
    if start not in graph.nodes or goal not in graph.nodes:
        raise RouteNotFoundError(f"unknown node in route request: {start} -> {goal}")
    dist: dict[str, float] = {start: 0.0}
    came_from: dict[str, str] = {}
    visited: set[str] = set()
    heap: list[tuple[float, str]] = [(0.0, start)]

    while heap:
        d, current = heapq.heappop(heap)
        if current in visited:
            continue
        visited.add(current)
        if current == goal:
            path = _reconstruct(came_from, start, goal)
            return Route(path, dist[goal], _path_distance(graph, path))
        for edge in graph.neighbours(current):
            cost = graph.traversal_cost(edge)
            if cost == float("inf"):
                continue
            nd = d + cost
            if nd < dist.get(edge.to_id, float("inf")):
                dist[edge.to_id] = nd
                came_from[edge.to_id] = current
                heapq.heappush(heap, (nd, edge.to_id))

    raise RouteNotFoundError(f"no route found from {start} to {goal}")


def _path_distance(graph: WarehouseGraph, path: list[str]) -> float:
    total = 0.0
    for a, b in zip(path, path[1:]):
        edge = graph.edge(a, b)
        if edge:
            total += edge.distance_m
    return total


def replan_if_blocked(graph: WarehouseGraph, route: Route, current_node: str) -> Route:
    """Recalculate the remaining route if any upcoming edge became blocked.

    Called by the fleet manager whenever warehouse conditions change
    (a conveyor blocks, a human enters a corridor, another robot faults) so
    in-flight robots reroute rather than stall.
    """
    try:
        idx = route.node_ids.index(current_node)
    except ValueError:
        idx = 0
    remaining = route.node_ids[idx:]
    for a, b in zip(remaining, remaining[1:]):
        edge = graph.edge(a, b)
        if edge is None or graph.traversal_cost(edge) == float("inf"):
            goal = route.node_ids[-1]
            return a_star(graph, current_node, goal)
    return route
