"""Dedicated safety layer: intersection reservation, conflict and deadlock detection.

This module is deliberately separate from routing and task allocation: it
is the last line of defence before a robot command is issued, and it never
optimises for throughput -- only for safety. Nothing here calls into the
optimisation or ML layers, per the platform rule that experimental models
must never sit on the safety-critical path.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from enum import StrEnum


class ConflictType(StrEnum):
    ROBOT_ROBOT = "ROBOT_ROBOT"
    ROBOT_HUMAN = "ROBOT_HUMAN"
    ROBOT_OBSTACLE = "ROBOT_OBSTACLE"
    BLOCKED_AISLE = "BLOCKED_AISLE"
    DEADLOCK = "DEADLOCK"
    INTERSECTION = "INTERSECTION"


@dataclass(slots=True)
class Conflict:
    conflict_type: ConflictType
    involved: tuple[str, ...]
    node_id: str | None = None
    detail: str = ""


@dataclass(slots=True)
class Reservation:
    node_id: str
    robot_id: str
    expires_at: datetime


class SafetyLayer:
    """Tracks intersection reservations, minimum separation, and deadlocks.

    Concepts implemented (spec section 7):
        * right-of-way via first-come-first-served node reservation
        * intersection reservation with a short TTL to avoid stale locks
        * minimum safety distance between robots on the same edge
        * priority corridors: a CRITICAL task holder can pre-empt a
          reservation held by a LOW/NORMAL priority robot that has not yet
          entered the node
        * temporary exclusion zones (e.g. maintenance, spill) via
          ``exclude_node`` / ``release_node``
        * emergency stop propagation
    """

    def __init__(self, *, min_separation_m: float = 1.5, reservation_ttl_s: float = 8.0) -> None:
        self.min_separation_m = min_separation_m
        self.reservation_ttl_s = reservation_ttl_s
        self._reservations: dict[str, Reservation] = {}
        self._excluded_nodes: set[str] = set()
        self._estop_scopes: set[str] = set()

    # --- exclusion / emergency ------------------------------------------------

    def exclude_node(self, node_id: str) -> None:
        self._excluded_nodes.add(node_id)

    def release_node(self, node_id: str) -> None:
        self._excluded_nodes.discard(node_id)

    def is_excluded(self, node_id: str) -> bool:
        return node_id in self._excluded_nodes

    def trigger_estop(self, scope: str) -> None:
        self._estop_scopes.add(scope)

    def clear_estop(self, scope: str) -> None:
        self._estop_scopes.discard(scope)

    def is_estopped(self, scope: str) -> bool:
        return scope in self._estop_scopes or "GLOBAL" in self._estop_scopes

    # --- reservations -----------------------------------------------------

    def _purge_expired(self, now: datetime) -> None:
        expired = [nid for nid, r in self._reservations.items() if r.expires_at <= now]
        for nid in expired:
            del self._reservations[nid]

    def request_reservation(
        self, node_id: str, robot_id: str, *, priority: int = 1, now: datetime | None = None
    ) -> bool:
        """Try to reserve ``node_id`` for ``robot_id``. Returns True on success."""
        now = now or datetime.now(UTC)
        self._purge_expired(now)

        if self.is_excluded(node_id):
            return False

        existing = self._reservations.get(node_id)
        if existing is None or existing.robot_id == robot_id:
            self._reservations[node_id] = Reservation(
                node_id, robot_id, now + timedelta(seconds=self.reservation_ttl_s)
            )
            return True

        # Priority corridor pre-emption: a higher-priority robot may take
        # the reservation from a lower-priority holder that hasn't arrived.
        if priority >= 3:
            self._reservations[node_id] = Reservation(
                node_id, robot_id, now + timedelta(seconds=self.reservation_ttl_s)
            )
            return True

        return False

    def release_reservation(self, node_id: str, robot_id: str) -> None:
        existing = self._reservations.get(node_id)
        if existing and existing.robot_id == robot_id:
            del self._reservations[node_id]

    def holder_of(self, node_id: str) -> str | None:
        r = self._reservations.get(node_id)
        return r.robot_id if r else None

    # --- conflict detection -------------------------------------------------

    def detect_proximity_conflicts(
        self, positions: dict[str, tuple[float, float]]
    ) -> list[Conflict]:
        """O(n^2) pairwise separation check -- fine up to a few thousand robots per
        tick when spatially bucketed by the caller; the fleet manager buckets by
        zone before calling this so each invocation only compares nearby robots.
        """
        conflicts: list[Conflict] = []
        ids = list(positions.keys())
        for i in range(len(ids)):
            for j in range(i + 1, len(ids)):
                a, b = ids[i], ids[j]
                (ax, ay), (bx, by) = positions[a], positions[b]
                dist = ((ax - bx) ** 2 + (ay - by) ** 2) ** 0.5
                if dist < self.min_separation_m:
                    conflicts.append(Conflict(ConflictType.ROBOT_ROBOT, (a, b), detail=f"{dist:.2f}m"))
        return conflicts

    def detect_human_conflicts(
        self, robot_positions: dict[str, tuple[float, float]],
        human_positions: dict[str, tuple[float, float]],
        *, safety_margin_m: float = 2.5,
    ) -> list[Conflict]:
        conflicts: list[Conflict] = []
        for rid, (rx, ry) in robot_positions.items():
            for hid, (hx, hy) in human_positions.items():
                dist = ((rx - hx) ** 2 + (ry - hy) ** 2) ** 0.5
                if dist < safety_margin_m:
                    conflicts.append(Conflict(ConflictType.ROBOT_HUMAN, (rid, hid), detail=f"{dist:.2f}m"))
        return conflicts

    def detect_deadlock(self, wait_graph: dict[str, str]) -> list[Conflict]:
        """``wait_graph`` maps robot_id -> robot_id it is waiting on (blocked by).

        A cycle in this graph is a deadlock: robots waiting on each other in a
        loop, none able to proceed. Detected via simple cycle walk.
        """
        conflicts: list[Conflict] = []
        visited_global: set[str] = set()
        for start in wait_graph:
            if start in visited_global:
                continue
            path: list[str] = []
            node = start
            seen_in_path: dict[str, int] = {}
            while node is not None and node not in seen_in_path:
                seen_in_path[node] = len(path)
                path.append(node)
                visited_global.add(node)
                node = wait_graph.get(node)
            if node is not None and node in seen_in_path:
                cycle = tuple(path[seen_in_path[node]:])
                if len(cycle) > 1:
                    conflicts.append(Conflict(ConflictType.DEADLOCK, cycle, detail="cyclic wait"))
        return conflicts
