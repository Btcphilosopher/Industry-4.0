"""High-frequency telemetry ingestion pipeline.

Telemetry ingestion is deliberately decoupled from the transactional
database and order-processing path (spec section 24: "do not allow
telemetry ingestion to degrade order processing"). Readings are pushed
into a bounded, non-blocking ring buffer; a background consumer flushes
batches at a fixed interval. If producers outpace the consumer, the buffer
drops the *oldest* readings rather than applying backpressure to the
producer -- appropriate for telemetry, where a recent value supersedes a
stale one, unlike an order or task event.
"""
from __future__ import annotations

import asyncio
import logging
import time
from collections import deque
from collections.abc import Awaitable, Callable

from telemetry.protocols import TelemetryReading

logger = logging.getLogger("robotics_warehouse.telemetry")

FlushHandler = Callable[[list[TelemetryReading]], Awaitable[None]]


class TelemetryIngestionPipeline:
    def __init__(
        self, *, buffer_size: int = 50_000, flush_interval_s: float = 1.0, flush_handler: FlushHandler | None = None,
    ) -> None:
        self._buffer: deque[TelemetryReading] = deque(maxlen=buffer_size)
        self.flush_interval_s = flush_interval_s
        self.flush_handler = flush_handler
        self._dropped_count = 0
        self._ingested_count = 0
        self._flush_task: asyncio.Task | None = None
        self._running = False
        self._last_flush_duration_s = 0.0
        self._throughput_window: deque[float] = deque(maxlen=1000)

    def ingest(self, reading: TelemetryReading) -> None:
        """Non-blocking, always O(1). Called from the hot path (e.g. every sim tick)."""
        if len(self._buffer) == self._buffer.maxlen:
            self._dropped_count += 1
        self._buffer.append(reading)
        self._ingested_count += 1
        self._throughput_window.append(time.monotonic())

    def ingest_many(self, readings: list[TelemetryReading]) -> None:
        for r in readings:
            self.ingest(r)

    async def start(self) -> None:
        self._running = True
        self._flush_task = asyncio.create_task(self._flush_loop())

    async def stop(self) -> None:
        self._running = False
        if self._flush_task:
            self._flush_task.cancel()

    async def _flush_loop(self) -> None:
        while self._running:
            await asyncio.sleep(self.flush_interval_s)
            await self.flush()

    async def flush(self) -> list[TelemetryReading]:
        batch = list(self._buffer)
        self._buffer.clear()
        if not batch:
            return []
        start = time.monotonic()
        if self.flush_handler:
            try:
                await self.flush_handler(batch)
            except Exception:
                logger.exception("telemetry flush handler failed for batch of %d", len(batch))
        self._last_flush_duration_s = time.monotonic() - start
        return batch

    def throughput_events_per_second(self) -> float:
        if len(self._throughput_window) < 2:
            return 0.0
        span = self._throughput_window[-1] - self._throughput_window[0]
        return (len(self._throughput_window) - 1) / span if span > 0 else 0.0

    @property
    def dropped_count(self) -> int:
        return self._dropped_count

    @property
    def ingested_count(self) -> int:
        return self._ingested_count

    @property
    def buffered_count(self) -> int:
        return len(self._buffer)
