"""Protocol-agnostic telemetry reading + adapter interface.

Industrial IoT sources speak different wire protocols (MQTT, OPC UA,
Modbus, REST push, WebSocket). Every adapter below normalises its source
into the same :class:`TelemetryReading` shape so ``telemetry.ingestion``
and everything downstream never has to know which protocol produced a
given reading.
"""
from __future__ import annotations

import abc
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import StrEnum


class TelemetryKind(StrEnum):
    ROBOT_POSITION = "ROBOT_POSITION"
    MOTOR_TEMPERATURE = "MOTOR_TEMPERATURE"
    BATTERY_TEMPERATURE = "BATTERY_TEMPERATURE"
    VIBRATION = "VIBRATION"
    CONVEYOR_SPEED = "CONVEYOR_SPEED"
    MOTOR_CURRENT = "MOTOR_CURRENT"
    ENERGY_CONSUMPTION = "ENERGY_CONSUMPTION"
    ENVIRONMENTAL = "ENVIRONMENTAL"
    MACHINE_STATE = "MACHINE_STATE"
    SENSOR_ALARM = "SENSOR_ALARM"


@dataclass(frozen=True, slots=True)
class TelemetryReading:
    source_id: str
    kind: TelemetryKind
    value: float
    unit: str
    timestamp: datetime = field(default_factory=lambda: datetime.now(UTC))
    protocol: str = "UNKNOWN"
    tags: dict[str, str] = field(default_factory=dict)


class TelemetryAdapter(abc.ABC):
    """Common interface every protocol adapter implements.

    A real deployment plugs in e.g. ``MqttTelemetryAdapter`` (paho-mqtt),
    ``OpcUaTelemetryAdapter`` (asyncua), or ``ModbusTelemetryAdapter``
    (pymodbus) here; the ingestion pipeline only depends on this interface.
    """

    protocol_name: str = "UNKNOWN"

    @abc.abstractmethod
    async def stream(self) -> AsyncIterator[TelemetryReading]:
        """Yield readings as they arrive from the underlying transport."""
        if False:  # pragma: no cover - makes this an async generator for subclasses
            yield  # type: ignore[misc]

    @abc.abstractmethod
    async def connect(self) -> None: ...

    @abc.abstractmethod
    async def disconnect(self) -> None: ...
