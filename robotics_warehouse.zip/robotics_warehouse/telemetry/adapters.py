"""Concrete telemetry adapters.

``SimulatedRobotTelemetryAdapter`` is the adapter used by the demo/
simulation environment -- it turns live :class:`RobotState` objects into a
telemetry stream without needing real hardware. ``MqttTelemetryAdapter``,
``OpcUaTelemetryAdapter`` and ``ModbusTelemetryAdapter`` are structural
placeholders showing exactly where a real client library integration
plugs in (``paho-mqtt`` / ``asyncua`` / ``pymodbus`` respectively) --
each fully satisfies :class:`TelemetryAdapter` so swapping from simulated
to real hardware requires no change outside this module.
"""
from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator, Iterable

from robotics.robot_models.robot import RobotState
from telemetry.protocols import TelemetryAdapter, TelemetryKind, TelemetryReading


class SimulatedRobotTelemetryAdapter(TelemetryAdapter):
    protocol_name = "SIMULATED"

    def __init__(self, robots: Iterable[RobotState], *, poll_interval_s: float = 0.5) -> None:
        self._robots = robots
        self.poll_interval_s = poll_interval_s
        self._connected = False

    async def connect(self) -> None:
        self._connected = True

    async def disconnect(self) -> None:
        self._connected = False

    async def stream(self) -> AsyncIterator[TelemetryReading]:
        while self._connected:
            for robot in self._robots:
                yield TelemetryReading(
                    source_id=robot.robot_id, kind=TelemetryKind.ROBOT_POSITION,
                    value=robot.velocity, unit="m/s", protocol=self.protocol_name,
                    tags={"x": str(robot.x), "y": str(robot.y)},
                )
                yield TelemetryReading(
                    source_id=robot.robot_id, kind=TelemetryKind.MOTOR_TEMPERATURE,
                    value=robot.motor_temp_c, unit="celsius", protocol=self.protocol_name,
                )
                yield TelemetryReading(
                    source_id=robot.robot_id, kind=TelemetryKind.ENERGY_CONSUMPTION,
                    value=robot.battery_pct, unit="percent", protocol=self.protocol_name,
                )
            await asyncio.sleep(self.poll_interval_s)


class MqttTelemetryAdapter(TelemetryAdapter):
    """Structural placeholder for an MQTT broker connection.

    A production implementation would use ``paho-mqtt`` or ``gmqtt`` to
    subscribe to a topic tree (e.g. ``warehouse/+/robot/+/telemetry``) and
    translate each message payload into a :class:`TelemetryReading`.
    """

    protocol_name = "MQTT"

    def __init__(self, broker_host: str, broker_port: int, topics: list[str]) -> None:
        self.broker_host = broker_host
        self.broker_port = broker_port
        self.topics = topics
        self._connected = False

    async def connect(self) -> None:
        # real implementation: await self._client.connect(self.broker_host, self.broker_port)
        self._connected = True

    async def disconnect(self) -> None:
        self._connected = False

    async def stream(self) -> AsyncIterator[TelemetryReading]:
        if not self._connected:
            raise RuntimeError("MqttTelemetryAdapter.stream() called before connect()")
        return
        yield  # pragma: no cover - placeholder generator, no real broker in this environment


class OpcUaTelemetryAdapter(TelemetryAdapter):
    """Structural placeholder for an OPC UA server subscription (e.g. via ``asyncua``)."""

    protocol_name = "OPC_UA"

    def __init__(self, endpoint_url: str, node_ids: list[str]) -> None:
        self.endpoint_url = endpoint_url
        self.node_ids = node_ids
        self._connected = False

    async def connect(self) -> None:
        self._connected = True

    async def disconnect(self) -> None:
        self._connected = False

    async def stream(self) -> AsyncIterator[TelemetryReading]:
        if not self._connected:
            raise RuntimeError("OpcUaTelemetryAdapter.stream() called before connect()")
        return
        yield  # pragma: no cover


class ModbusTelemetryAdapter(TelemetryAdapter):
    """Structural placeholder for a Modbus TCP/RTU polling loop (e.g. via ``pymodbus``)."""

    protocol_name = "MODBUS"

    def __init__(self, host: str, port: int, registers: dict[str, int]) -> None:
        self.host = host
        self.port = port
        self.registers = registers
        self._connected = False

    async def connect(self) -> None:
        self._connected = True

    async def disconnect(self) -> None:
        self._connected = False

    async def stream(self) -> AsyncIterator[TelemetryReading]:
        if not self._connected:
            raise RuntimeError("ModbusTelemetryAdapter.stream() called before connect()")
        return
        yield  # pragma: no cover
