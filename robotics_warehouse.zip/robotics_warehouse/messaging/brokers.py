"""Message-broker abstraction for multi-node event distribution.

``backend.events.event_bus.EventBus`` is the in-process default. When the
platform scales beyond a single node, a :class:`MessageBroker`
implementation (Redis pub/sub, MQTT) fans events out across processes/
nodes while every publisher/subscriber in the codebase keeps using the
same ``publish`` / ``subscribe`` calls -- only the wiring at startup
changes.
"""
from __future__ import annotations

import abc
import json
import logging
from collections.abc import Awaitable, Callable

from backend.events.event_types import DomainEvent

logger = logging.getLogger("robotics_warehouse.messaging")

MessageHandler = Callable[[str, dict], Awaitable[None]]


class MessageBroker(abc.ABC):
    @abc.abstractmethod
    async def connect(self) -> None: ...

    @abc.abstractmethod
    async def disconnect(self) -> None: ...

    @abc.abstractmethod
    async def publish(self, topic: str, event: DomainEvent) -> None: ...

    @abc.abstractmethod
    async def subscribe(self, topic: str, handler: MessageHandler) -> None: ...


class InProcessBroker(MessageBroker):
    """Loopback broker for single-node / demo deployments: wraps the local
    ``EventBus`` so the same interface works whether or not a real broker
    is configured.
    """

    def __init__(self, event_bus) -> None:  # backend.events.event_bus.EventBus
        self._bus = event_bus
        self._connected = False

    async def connect(self) -> None:
        self._connected = True

    async def disconnect(self) -> None:
        self._connected = False

    async def publish(self, topic: str, event: DomainEvent) -> None:
        await self._bus.publish(event)

    async def subscribe(self, topic: str, handler: MessageHandler) -> None:
        async def _adapt(event: DomainEvent) -> None:
            await handler(topic, event.as_dict())
        self._bus.subscribe_all(_adapt)


class RedisBroker(MessageBroker):
    """Structural placeholder for a Redis pub/sub backed broker (``redis.asyncio``).

    Kept dependency-free in this codebase; a production build would wire in
    ``redis.asyncio.Redis`` here behind the exact same interface.
    """

    def __init__(self, redis_url: str) -> None:
        self.redis_url = redis_url
        self._connected = False

    async def connect(self) -> None:
        self._connected = True

    async def disconnect(self) -> None:
        self._connected = False

    async def publish(self, topic: str, event: DomainEvent) -> None:
        if not self._connected:
            raise RuntimeError("RedisBroker not connected")
        logger.debug("would PUBLISH %s -> %s", topic, json.dumps(event.as_dict(), default=str))

    async def subscribe(self, topic: str, handler: MessageHandler) -> None:
        if not self._connected:
            raise RuntimeError("RedisBroker not connected")
        logger.debug("would SUBSCRIBE to %s", topic)


class MqttBroker(MessageBroker):
    """Structural placeholder for an MQTT-backed broker (see ``telemetry.adapters``
    for the telemetry-specific MQTT adapter; this variant carries domain events).
    """

    def __init__(self, host: str, port: int) -> None:
        self.host = host
        self.port = port
        self._connected = False

    async def connect(self) -> None:
        self._connected = True

    async def disconnect(self) -> None:
        self._connected = False

    async def publish(self, topic: str, event: DomainEvent) -> None:
        if not self._connected:
            raise RuntimeError("MqttBroker not connected")
        logger.debug("would PUBLISH %s -> %s", topic, json.dumps(event.as_dict(), default=str))

    async def subscribe(self, topic: str, handler: MessageHandler) -> None:
        if not self._connected:
            raise RuntimeError("MqttBroker not connected")
        logger.debug("would SUBSCRIBE to %s", topic)
