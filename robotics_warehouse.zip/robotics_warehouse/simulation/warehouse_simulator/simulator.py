"""Main warehouse digital-twin simulation loop.

Ties together every subsystem for a single coherent tick:

    ORDERS -> INVENTORY -> TASK ENGINE -> ROBOT FLEET -> WAREHOUSE EXECUTION
    -> TELEMETRY -> DIGITAL TWIN -> ANALYTICS

Each ``tick(dt_seconds)`` call advances simulated time by ``dt_seconds``:
generates new orders, allocates queued tasks to robots, moves robots along
their routes, drives task/order lifecycle transitions, manages charging,
and injects stochastic warehouse disruptions. The loop performs no I/O and
holds no global state, so it can be embedded in the API's background task,
driven directly by a script, or run headless for load testing.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass

from backend.events.event_bus import EventBus
from backend.events.event_types import TaskCompleted
from backend.inventory.service import InventoryService
from backend.orchestration.tasks import Task, TaskStatus
from backend.orders.pipeline import OrderPipeline
from backend.warehouse.models import Warehouse
from digital_twin.warehouse_model.builder import DigitalTwinBundle
from robotics.fleet_manager.fleet_manager import FleetManager
from robotics.navigation.pathfinding import RouteNotFoundError, a_star, replan_if_blocked
from robotics.robot_models.robot import RobotStatus
from simulation.order_simulator.generator import OrderSimulator
from simulation.robot_simulator.motion import RouteProgress, start_progress, step_robot
from simulation.traffic_simulator.traffic import TrafficSimulator

logger = logging.getLogger("robotics_warehouse.simulation")


@dataclass(slots=True)
class SimulationStats:
    ticks: int = 0
    sim_time_s: float = 0.0
    orders_created: int = 0
    orders_completed: int = 0
    tasks_created: int = 0
    tasks_completed: int = 0
    tasks_failed: int = 0


class WarehouseSimulator:
    def __init__(
        self,
        bundle: DigitalTwinBundle,
        event_bus: EventBus,
        *,
        orders_per_hour: float = 400.0,
        seed: int = 42,
    ) -> None:
        self.warehouse: Warehouse = bundle.warehouse
        self.graph = bundle.graph
        self.location_node_map = bundle.location_node_map
        self.event_bus = event_bus

        self.fleet_manager = FleetManager(self.graph, self.warehouse.charging_stations, event_bus)
        for robot in bundle.robots:
            self.fleet_manager.register_robot(robot)

        self.inventory = InventoryService(event_bus)
        for lot in bundle.initial_inventory:
            self.inventory.receive(lot)

        self.order_pipeline = OrderPipeline(
            self.inventory, event_bus, packing_station_ids=list(self.warehouse.packing_stations.keys()),
            location_node_map=self.location_node_map,
        )
        # Orders are only generated against SKUs that actually have starting
        # stock -- with a 10,000-SKU catalogue but a smaller seeded inventory,
        # sampling the full catalogue would make most generated orders
        # unfulfillable and fail validation immediately.
        skus_with_stock = {lot.sku for lot in bundle.initial_inventory}
        stocked_catalog = {sku: e for sku, e in bundle.sku_catalog.items() if sku in skus_with_stock} or bundle.sku_catalog
        self.order_simulator = OrderSimulator(stocked_catalog, orders_per_hour=orders_per_hour, seed=seed)
        self.traffic_simulator = TrafficSimulator(self.warehouse, self.graph, event_bus, seed=seed)

        self.tasks: dict[str, Task] = {}
        self._route_progress: dict[str, RouteProgress] = {}
        self._task_phase: dict[str, str] = {}  # robot_id -> "TO_SOURCE" | "TO_DEST" | "CHARGING"
        self.stats = SimulationStats()
        self._ticks_since_battery_check = 0

    # --- main loop ------------------------------------------------------------

    def tick(self, dt_seconds: float) -> None:
        self.stats.ticks += 1
        self.stats.sim_time_s += dt_seconds

        self._generate_orders(dt_seconds)
        self._allocate_queued_tasks()
        self._advance_robots(dt_seconds)
        self._manage_charging(dt_seconds)
        self.traffic_simulator.tick(dt_seconds, self.fleet_manager.robots)
        self._reroute_blocked_robots()

        self._ticks_since_battery_check += 1
        if self._ticks_since_battery_check >= 10:
            self.fleet_manager.check_battery_alerts()
            self._dispatch_low_battery_robots()
            self._ticks_since_battery_check = 0

    # --- order generation & task queueing -------------------------------------

    def _generate_orders(self, dt_seconds: float) -> None:
        order = self.order_simulator.maybe_generate(dt_seconds)
        if order is None:
            return
        try:
            tasks = self.order_pipeline.submit(order)
        except Exception:  # noqa: BLE001 - validation/inventory shortfall is expected under load
            logger.debug("order %s could not be submitted (likely inventory shortfall)", order.order_id)
            return
        self.stats.orders_created += 1
        self.stats.tasks_created += len(tasks)
        for t in tasks:
            self.tasks[t.task_id] = t

    # --- allocation -------------------------------------------------------

    def _allocate_queued_tasks(self) -> None:
        queued = [t for t in self.tasks.values() if t.status == TaskStatus.QUEUED]
        for task in queued:
            robot_id = self.fleet_manager.assign_task(task)
            if robot_id is None:
                continue
            route = self.fleet_manager.active_routes[robot_id]
            self._route_progress[robot_id] = start_progress(route, self.graph)
            self._task_phase[robot_id] = "TO_SOURCE"
            task.transition(TaskStatus.EXECUTING)

    # --- robot motion & task completion ----------------------------------

    def _advance_robots(self, dt_seconds: float) -> None:
        for robot_id, rp in list(self._route_progress.items()):
            robot = self.fleet_manager.robots.get(robot_id)
            if robot is None:
                self._route_progress.pop(robot_id, None)
                continue
            if robot.status == RobotStatus.FAULTED:
                continue  # faulted robots stop in place until recovered

            result = step_robot(robot, rp, dt_seconds, self.graph)
            if not result.arrived_final:
                continue

            phase = self._task_phase.get(robot_id)
            if phase == "CHARGING":
                self._begin_charging_session(robot_id)
                continue

            task = self.tasks.get(robot.current_task_id or "")
            if task is None:
                self._route_progress.pop(robot_id, None)
                self._task_phase.pop(robot_id, None)
                continue

            if phase == "TO_SOURCE" and task.destination and task.destination != task.source:
                try:
                    route = a_star(self.graph, task.source, task.destination)
                except RouteNotFoundError:
                    self.fleet_manager.recover_failed_task(task, "no route to destination")
                    self._cleanup_robot_routing(robot_id)
                    self.stats.tasks_failed += 1
                    continue
                self._route_progress[robot_id] = start_progress(route, self.graph)
                self._task_phase[robot_id] = "TO_DEST"
            else:
                self._complete_task(robot_id, task)

    def _complete_task(self, robot_id: str, task: Task) -> None:
        task.transition(TaskStatus.COMPLETED)
        self.order_pipeline.on_task_completed(task)
        self.fleet_manager.release_robot(robot_id)
        self._cleanup_robot_routing(robot_id)
        self.stats.tasks_completed += 1
        self.event_bus.publish_nowait(
            TaskCompleted(
                task_id=task.task_id, robot_id=robot_id,
                duration_seconds=task.actual_duration_s or 0.0,
            )
        )
        order = self.order_pipeline.orders.get(task.order_id or "")
        if order and order.status.value == "DISPATCHED":
            self.stats.orders_completed += 1

    def _cleanup_robot_routing(self, robot_id: str) -> None:
        self._route_progress.pop(robot_id, None)
        self._task_phase.pop(robot_id, None)

    # --- charging -----------------------------------------------------------

    def _dispatch_low_battery_robots(self) -> None:
        for robot in list(self.fleet_manager.robots.values()):
            if robot.robot_id in self._route_progress:
                continue
            if not self.fleet_manager.charging.needs_charging(robot):
                continue
            if robot.status != RobotStatus.IDLE:
                continue
            station = self.fleet_manager.charging.nearest_available_station(robot)
            if station is None or robot.current_node is None:
                continue
            try:
                route = a_star(self.graph, robot.current_node, station.station_id)
            except RouteNotFoundError:
                continue
            if not self.fleet_manager.charging.begin_charging(station, robot.robot_id):
                continue
            robot.status = RobotStatus.MOVING_TO_CHARGE
            robot.destination_node = station.station_id
            self._route_progress[robot.robot_id] = start_progress(route, self.graph)
            self._task_phase[robot.robot_id] = "CHARGING"

    def _begin_charging_session(self, robot_id: str) -> None:
        robot = self.fleet_manager.robots[robot_id]
        robot.status = RobotStatus.CHARGING
        self._cleanup_robot_routing(robot_id)

    def _manage_charging(self, dt_seconds: float) -> None:
        for station in self.warehouse.charging_stations.values():
            for robot_id in list(station.occupied_by):
                robot = self.fleet_manager.robots.get(robot_id)
                if robot is None:
                    station.occupied_by.remove(robot_id)
                    continue
                if robot.status != RobotStatus.CHARGING:
                    continue
                self.fleet_manager.charging.apply_charge_tick(robot, station, dt_seconds)
                if robot.battery_pct >= self.fleet_manager.charging.policy.full_charge_target_pct:
                    self.fleet_manager.charging.finish_charging(station, robot_id)
                    robot.status = RobotStatus.IDLE
                    robot.destination_node = None

    # --- rerouting ----------------------------------------------------------

    def _reroute_blocked_robots(self) -> None:
        for robot_id, rp in list(self._route_progress.items()):
            robot = self.fleet_manager.robots.get(robot_id)
            if robot is None or robot.current_node is None or robot.status == RobotStatus.FAULTED:
                continue
            try:
                new_route = replan_if_blocked(self.graph, rp.route, robot.current_node)
            except RouteNotFoundError:
                # Every alternative path is currently blocked (e.g. a
                # transient human incursion on the only remaining corridor).
                # Hold position and retry on a later tick rather than
                # crashing the simulation -- this is exactly the BLOCKED
                # task state the task lifecycle models for.
                task = self.tasks.get(robot.current_task_id or "")
                if task and task.status == TaskStatus.EXECUTING:
                    task.transition(TaskStatus.BLOCKED)
                continue
            task = self.tasks.get(robot.current_task_id or "")
            if task and task.status == TaskStatus.BLOCKED:
                task.transition(TaskStatus.EXECUTING)
            if new_route.node_ids != rp.route.node_ids:
                self._route_progress[robot_id] = start_progress(new_route, self.graph)
