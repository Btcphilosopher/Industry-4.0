"""Synthetic order-arrival generator.

Orders arrive as a Poisson process (industry-standard model for
independent-customer arrival streams) at a configurable target rate, each
with 1-6 lines drawn from the SKU catalogue weighted towards higher
velocity-class SKUs so demand realistically clusters on fast movers.
"""
from __future__ import annotations

import random

from backend.inventory.models import SKUCatalogEntry
from backend.orchestration.tasks import TaskPriority
from backend.orders.models import Order, OrderLine


class OrderSimulator:
    def __init__(
        self,
        sku_catalog: dict[str, SKUCatalogEntry],
        *,
        orders_per_hour: float,
        seed: int = 42,
        max_lines_per_order: int = 6,
    ) -> None:
        self.sku_catalog = sku_catalog
        self.orders_per_hour = orders_per_hour
        self.max_lines_per_order = max_lines_per_order
        self._rng = random.Random(seed)
        self._skus_by_class = {
            "A": [s for s, e in sku_catalog.items() if e.velocity_class == "A"],
            "B": [s for s, e in sku_catalog.items() if e.velocity_class == "B"],
            "C": [s for s, e in sku_catalog.items() if e.velocity_class == "C"],
        }
        self._time_to_next_order = self._sample_interarrival()

    def _sample_interarrival(self) -> float:
        rate_per_second = max(self.orders_per_hour, 0.01) / 3600.0
        return self._rng.expovariate(rate_per_second)

    def _pick_sku(self) -> str:
        klass = self._rng.choices(["A", "B", "C"], weights=[0.6, 0.3, 0.1])[0]
        pool = self._skus_by_class.get(klass) or list(self.sku_catalog.keys())
        return self._rng.choice(pool)

    def set_rate(self, orders_per_hour: float) -> None:
        self.orders_per_hour = orders_per_hour

    def maybe_generate(self, dt_seconds: float) -> Order | None:
        """Advance the internal Poisson clock by ``dt_seconds``; return a new
        Order if the next scheduled arrival fell within this tick.
        """
        self._time_to_next_order -= dt_seconds
        if self._time_to_next_order > 0:
            return None
        self._time_to_next_order += self._sample_interarrival()

        n_lines = self._rng.randint(1, self.max_lines_per_order)
        lines = [
            OrderLine(sku=self._pick_sku(), quantity=float(self._rng.randint(1, 5)))
            for _ in range(n_lines)
        ]
        priority = self._rng.choices(
            list(TaskPriority), weights=[0.15, 0.55, 0.22, 0.08]
        )[0]
        return Order(lines=lines, priority=priority)
