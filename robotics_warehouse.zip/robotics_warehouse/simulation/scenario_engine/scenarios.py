"""What-if scenario engine.

Runs the warehouse simulator for a fixed simulated duration under a
baseline configuration and under one or more perturbations (order surge,
robot failures, conveyor outage, reduced charging capacity, demand shift,
new zone, added fleet capacity), then hands the resulting metrics to
``digital_twin.scenario_analysis.compare`` for a quantitative diff. Each
run gets an independent, deterministically-seeded warehouse so scenarios
are directly comparable and reproducible.
"""
from __future__ import annotations

import random
from collections.abc import Callable
from dataclasses import asdict, dataclass, field

from backend.analytics.engine import AnalyticsEngine, WarehouseMetrics
from backend.events.event_bus import EventBus
from digital_twin.warehouse_model.builder import BuildSpec, build_demo_warehouse
from robotics.robot_models.robot import RobotType
from simulation.warehouse_simulator.simulator import WarehouseSimulator


@dataclass(slots=True)
class ScenarioDefinition:
    name: str
    description: str
    mutate: Callable[[WarehouseSimulator, random.Random], None] = field(default=lambda sim, rng: None)
    build_spec_override: dict | None = None
    orders_per_hour_multiplier: float = 1.0


@dataclass(slots=True)
class ScenarioRunResult:
    name: str
    metrics: WarehouseMetrics
    stats: dict


def run_scenario(
    scenario: ScenarioDefinition, *, base_spec: BuildSpec, duration_s: float, tick_s: float = 1.0,
) -> ScenarioRunResult:
    spec_kwargs = asdict(base_spec)
    if scenario.build_spec_override:
        spec_kwargs.update(scenario.build_spec_override)
    spec = BuildSpec(**spec_kwargs)

    bundle = build_demo_warehouse(spec)
    event_bus = EventBus()
    orders_per_hour = 400.0 * scenario.orders_per_hour_multiplier
    sim = WarehouseSimulator(bundle, event_bus, orders_per_hour=orders_per_hour, seed=spec.seed)

    rng = random.Random(spec.seed + 1)
    scenario.mutate(sim, rng)

    steps = max(1, int(duration_s / tick_s))
    for _ in range(steps):
        sim.tick(tick_s)

    analytics = AnalyticsEngine(sim)
    metrics = analytics.compute()
    return ScenarioRunResult(
        name=scenario.name, metrics=metrics,
        stats={
            "orders_created": sim.stats.orders_created,
            "orders_completed": sim.stats.orders_completed,
            "tasks_completed": sim.stats.tasks_completed,
            "tasks_failed": sim.stats.tasks_failed,
        },
    )


# --- built-in scenario library ---------------------------------------------

def _fail_n_robots(n: int):
    def _mutate(sim: WarehouseSimulator, rng: random.Random) -> None:
        candidates = [r for r in sim.fleet_manager.robots.values() if r.robot_type == RobotType.AMR]
        for robot in rng.sample(candidates, min(n, len(candidates))):
            sim.fleet_manager.report_fault(robot.robot_id, "SIMULATED_FAILURE", "scenario injection")
    return _mutate


def _disable_conveyor(conveyor_index: int = 0):
    def _mutate(sim: WarehouseSimulator, rng: random.Random) -> None:
        conveyors = list(sim.warehouse.conveyors.values())
        if conveyors:
            conveyors[conveyor_index % len(conveyors)].blocked = True
    return _mutate


def _reduce_charging_capacity(fraction: float):
    def _mutate(sim: WarehouseSimulator, rng: random.Random) -> None:
        for station in sim.warehouse.charging_stations.values():
            station.slots = max(1, int(station.slots * (1 - fraction)))
    return _mutate


BUILT_IN_SCENARIOS: dict[str, ScenarioDefinition] = {
    "baseline": ScenarioDefinition("baseline", "Current fleet and order rate, no perturbation."),
    "order_surge_20pct": ScenarioDefinition(
        "order_surge_20pct", "20% more orders arrive than baseline.", orders_per_hour_multiplier=1.2,
    ),
    "fifty_robots_fail": ScenarioDefinition(
        "fifty_robots_fail", "50 AMRs fault shortly after the run starts.", mutate=_fail_n_robots(50),
    ),
    "conveyor_outage": ScenarioDefinition(
        "conveyor_outage", "One sortation conveyor is unavailable for the whole run.", mutate=_disable_conveyor(0),
    ),
    "charging_capacity_reduced": ScenarioDefinition(
        "charging_capacity_reduced", "Charging station slot capacity cut by 40%.",
        mutate=_reduce_charging_capacity(0.4),
    ),
    "plus_200_amrs": ScenarioDefinition(
        "plus_200_amrs", "200 additional AMRs added to the fleet.", build_spec_override={"num_amrs": 300},
    ),
}
