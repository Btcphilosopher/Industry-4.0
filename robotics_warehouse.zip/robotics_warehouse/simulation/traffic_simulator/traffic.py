"""Stochastic warehouse traffic / disruption generator.

Injects the "difficult congestion scenarios" and equipment faults the spec
asks for (section 7, 14): conveyor blockages, human presence in robot
lanes, and robot faults, each at a small per-tick probability so a long
running simulation naturally accumulates realistic operational friction.
All randomness is drawn from a dedicated seeded RNG for reproducibility.
"""
from __future__ import annotations

import random
from dataclasses import dataclass

from backend.events.event_bus import EventBus
from backend.events.event_types import ConveyorBlocked, HumanDetected, RobotFaultDetected
from backend.warehouse.models import Warehouse
from robotics.navigation.graph import WarehouseGraph
from robotics.robot_models.robot import RobotState, RobotStatus


@dataclass(slots=True)
class DisruptionRates:
    conveyor_blockage_per_hour: float = 0.5
    human_incursion_per_hour: float = 3.0
    robot_fault_per_hour: float = 0.8


class TrafficSimulator:
    def __init__(
        self, warehouse: Warehouse, graph: WarehouseGraph, event_bus: EventBus,
        *, seed: int = 42, rates: DisruptionRates | None = None, human_dwell_s: float = 20.0,
    ) -> None:
        self.warehouse = warehouse
        self.graph = graph
        self.event_bus = event_bus
        self.rates = rates or DisruptionRates()
        self.human_dwell_s = human_dwell_s
        self._rng = random.Random(seed)
        self._sim_time_s = 0.0
        # node_id -> sim time at which the human incursion there clears.
        # Without a hard expiry, a node could stay blocked forever and
        # permanently strand any robot routed through it.
        self._human_clears_at: dict[str, float] = {}

    def tick(self, dt_seconds: float, robots: dict[str, RobotState]) -> None:
        self._sim_time_s += dt_seconds
        self._maybe_block_conveyor(dt_seconds)
        self._expire_human_incursions()
        self._maybe_human_incursion(dt_seconds)
        self._maybe_robot_fault(dt_seconds, robots)

    def _expire_human_incursions(self) -> None:
        expired = [nid for nid, clears_at in self._human_clears_at.items() if self._sim_time_s >= clears_at]
        for nid in expired:
            del self._human_clears_at[nid]
            node = self.graph.nodes.get(nid)
            if node:
                node.human_occupied = False

    def _prob_this_tick(self, per_hour: float, dt_seconds: float) -> float:
        return 1 - pow(2.718281828, -(per_hour / 3600.0) * dt_seconds)

    def _maybe_block_conveyor(self, dt_seconds: float) -> None:
        if not self.warehouse.conveyors:
            return
        if self._rng.random() < self._prob_this_tick(self.rates.conveyor_blockage_per_hour, dt_seconds):
            conveyor = self._rng.choice(list(self.warehouse.conveyors.values()))
            if not conveyor.blocked:
                conveyor.blocked = True
                self.event_bus.publish_nowait(
                    ConveyorBlocked(conveyor_id=conveyor.conveyor_id, reason="jam_detected")
                )
        else:
            # occasionally clear a blocked conveyor (maintenance responded)
            blocked = [c for c in self.warehouse.conveyors.values() if c.blocked]
            if blocked and self._rng.random() < 0.1:
                self._rng.choice(blocked).blocked = False

    def _maybe_human_incursion(self, dt_seconds: float) -> None:
        if self._rng.random() >= self._prob_this_tick(self.rates.human_incursion_per_hour, dt_seconds):
            return
        node = self._rng.choice(list(self.graph.nodes.values()))
        node.human_occupied = True
        self._human_clears_at[node.node_id] = self._sim_time_s + self._rng.uniform(
            self.human_dwell_s * 0.5, self.human_dwell_s * 1.5
        )
        self.event_bus.publish_nowait(
            HumanDetected(zone_id=node.zone_id or "UNKNOWN", position=(node.x, node.y))
        )

    def _maybe_robot_fault(self, dt_seconds: float, robots: dict[str, RobotState]) -> None:
        if not robots:
            return
        if self._rng.random() >= self._prob_this_tick(self.rates.robot_fault_per_hour, dt_seconds):
            return
        candidates = [r for r in robots.values() if r.status not in (RobotStatus.FAULTED, RobotStatus.OFFLINE)]
        if not candidates:
            return
        robot = self._rng.choice(candidates)
        fault_code = self._rng.choice(["MOTOR_OVERCURRENT", "SENSOR_TIMEOUT", "WHEEL_SLIP", "COMMS_GLITCH"])
        robot.status = RobotStatus.FAULTED
        robot.fault_code = fault_code
        self.event_bus.publish_nowait(
            RobotFaultDetected(robot_id=robot.robot_id, fault_code=fault_code, detail="stochastic fault injection")
        )
