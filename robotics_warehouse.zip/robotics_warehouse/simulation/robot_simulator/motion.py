"""Per-robot kinematics: moves a robot along a planned route tick by tick,
consuming battery and accumulating wear, and reports arrival events back to
the caller (the main simulator loop) rather than publishing directly, so
this module has no event-bus dependency and stays trivially unit-testable.
"""
from __future__ import annotations

from dataclasses import dataclass

from robotics.navigation.graph import WarehouseGraph
from robotics.navigation.pathfinding import Route
from robotics.robot_models.robot import RobotState


@dataclass(slots=True)
class RouteProgress:
    route: Route
    edge_index: int = 0
    distance_into_edge_m: float = 0.0

    def current_edge_nodes(self) -> tuple[str, str] | None:
        if self.edge_index >= len(self.route.node_ids) - 1:
            return None
        return self.route.node_ids[self.edge_index], self.route.node_ids[self.edge_index + 1]

    @property
    def finished(self) -> bool:
        return self.edge_index >= len(self.route.node_ids) - 1


def start_progress(route: Route, graph: WarehouseGraph) -> RouteProgress:
    rp = RouteProgress(route)
    edge_nodes = rp.current_edge_nodes()
    if edge_nodes:
        graph.record_traffic(*edge_nodes, +1)
    return rp


@dataclass(slots=True)
class StepResult:
    arrived_final: bool
    arrived_node: str | None  # set whenever a node boundary is crossed this tick


def step_robot(robot: RobotState, rp: RouteProgress, dt_seconds: float, graph: WarehouseGraph) -> StepResult:
    """Advance ``robot`` along ``rp`` by ``dt_seconds``, mutating robot state in place."""
    caps = robot.capabilities()
    remaining_dt = dt_seconds
    arrived_node: str | None = None
    moved_distance = 0.0

    while remaining_dt > 1e-9 and not rp.finished:
        a, b = rp.current_edge_nodes()
        edge = graph.edge(a, b)
        if edge is None:
            break
        speed = max(0.1, min(caps.max_speed_mps, edge.max_speed_mps))
        remaining_on_edge = max(0.0, edge.distance_m - rp.distance_into_edge_m)
        time_to_finish_edge = remaining_on_edge / speed

        if remaining_dt >= time_to_finish_edge:
            remaining_dt -= time_to_finish_edge
            moved_distance += remaining_on_edge
            graph.record_traffic(a, b, -1)
            rp.edge_index += 1
            rp.distance_into_edge_m = 0.0
            node_b = graph.nodes[b]
            robot.x, robot.y = node_b.x, node_b.y
            robot.current_node = b
            arrived_node = b
            robot.velocity = speed
            next_edge_nodes = rp.current_edge_nodes()
            if next_edge_nodes:
                graph.record_traffic(*next_edge_nodes, +1)
        else:
            rp.distance_into_edge_m += remaining_dt * speed
            moved_distance += remaining_dt * speed
            frac = rp.distance_into_edge_m / edge.distance_m if edge.distance_m else 1.0
            na, nb = graph.nodes[a], graph.nodes[b]
            robot.x = na.x + (nb.x - na.x) * frac
            robot.y = na.y + (nb.y - na.y) * frac
            robot.velocity = speed
            remaining_dt = 0.0

    _apply_energy_and_wear(robot, dt_seconds, moving=moved_distance > 0, caps=caps)
    robot.odometer_m += moved_distance
    robot.hours_in_service += dt_seconds / 3600.0

    if rp.finished:
        robot.velocity = 0.0

    return StepResult(arrived_final=rp.finished, arrived_node=arrived_node)


def _apply_energy_and_wear(robot: RobotState, dt_seconds: float, *, moving: bool, caps) -> None:
    power_w = caps.travel_power_w if moving else caps.idle_power_w
    capacity_wh = caps.battery_capacity_wh or 1.0
    energy_wh = power_w * (dt_seconds / 3600.0)
    robot.battery_pct = max(0.0, robot.battery_pct - (energy_wh / capacity_wh) * 100.0)

    target_temp = 55.0 if moving else 30.0
    # first-order thermal lag toward the target temperature
    robot.motor_temp_c += (target_temp - robot.motor_temp_c) * min(1.0, dt_seconds / 30.0)
