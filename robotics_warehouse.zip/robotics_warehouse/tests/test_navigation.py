"""Navigation engine: A*, Dijkstra, congestion, blocking, replanning."""
from __future__ import annotations

import pytest

from robotics.navigation.graph import Node
from robotics.navigation.pathfinding import RouteNotFoundError, a_star, dijkstra, replan_if_blocked


def test_a_star_finds_shortest_path(small_graph):
    route = a_star(small_graph, "A", "D")
    assert route.node_ids == ["A", "B", "C", "D"]
    assert route.total_distance_m == pytest.approx(30.0)


def test_dijkstra_matches_a_star_distance(small_graph):
    a_star_route = a_star(small_graph, "A", "D")
    dijkstra_route = dijkstra(small_graph, "A", "D")
    assert a_star_route.total_distance_m == pytest.approx(dijkstra_route.total_distance_m)


def test_congestion_reroutes_around_busy_edge(small_graph):
    # Load up the direct A-B-C-D path with heavy simulated traffic.
    for _ in range(20):
        small_graph.record_traffic("A", "B", +1)
        small_graph.record_traffic("B", "C", +1)
        small_graph.record_traffic("C", "D", +1)
    route = a_star(small_graph, "A", "D")
    assert route.node_ids == ["A", "E", "D"]


def test_blocked_edge_forces_alternate_route(small_graph):
    small_graph.set_blocked("B", "C", True)
    route = a_star(small_graph, "A", "D")
    assert "C" not in route.node_ids or route.node_ids == ["A", "E", "D"]
    assert route.node_ids == ["A", "E", "D"]


def test_unreachable_goal_raises(small_graph):
    small_graph.add_node(Node("ISOLATED", 100, 100))
    with pytest.raises(RouteNotFoundError):
        a_star(small_graph, "A", "ISOLATED")


def test_replan_if_blocked_only_recomputes_when_needed(small_graph):
    route = a_star(small_graph, "A", "D")
    unchanged = replan_if_blocked(small_graph, route, "A")
    assert unchanged.node_ids == route.node_ids

    small_graph.set_blocked("B", "C", True)
    rerouted = replan_if_blocked(small_graph, route, "B")
    assert rerouted.node_ids != route.node_ids
    assert rerouted.node_ids[0] == "B"


def test_restricted_node_is_avoided(small_graph):
    small_graph.nodes["C"].restricted = True
    route = a_star(small_graph, "A", "D")
    assert "C" not in route.node_ids
