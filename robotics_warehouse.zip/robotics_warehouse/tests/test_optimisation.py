"""Optimisation subsystem: slotting, fleet sizing, task sequencing, workforce, charging."""
from __future__ import annotations

from backend.orchestration.tasks import Task, TaskPriority, TaskType
from optimisation.energy.charging_schedule import optimise_charging_schedule
from optimisation.fleet_optimisation.fleet_sizing import compare_fleet_sizes, evaluate_fleet_size
from optimisation.scheduling.task_sequencing import sequence_tasks
from optimisation.slotting.slotting import classify_abc, recommend_slotting
from optimisation.workforce.workforce import allocate_workforce


def test_abc_classification_ranks_top_volume_as_a():
    counts = {"SKU-1": 100, "SKU-2": 50, "SKU-3": 10, "SKU-4": 1}
    classes = classify_abc(counts)
    assert classes["SKU-1"] == "A"
    assert classes["SKU-4"] == "C"


def test_slotting_recommends_fast_zone_for_a_class():
    recs = recommend_slotting({"SKU-1": 100}, {"SKU-1": "LOC-1"})
    assert recs[0].recommended_zone == "ZONE-FAST"
    assert recs[0].velocity_class == "A"


def test_fleet_sizing_utilisation_increases_with_smaller_fleet():
    small = evaluate_fleet_size(5, tasks_per_hour=200, avg_task_cycle_time_s=120)
    large = evaluate_fleet_size(50, tasks_per_hour=200, avg_task_cycle_time_s=120)
    assert small.utilisation > large.utilisation


def test_compare_fleet_sizes_returns_one_result_per_candidate():
    results = compare_fleet_sizes([10, 20, 30], tasks_per_hour=300, avg_task_cycle_time_s=90)
    assert [r.candidate_fleet_size for r in results] == [10, 20, 30]


def test_task_sequencing_prioritises_critical_first():
    low = Task(task_type=TaskType.MOVE, priority=TaskPriority.LOW)
    critical = Task(task_type=TaskType.MOVE, priority=TaskPriority.CRITICAL)
    normal = Task(task_type=TaskType.MOVE, priority=TaskPriority.NORMAL)
    ordered = sequence_tasks([low, normal, critical])
    assert ordered[0] is critical


def test_workforce_allocation_respects_total_and_minimum():
    plan = allocate_workforce({"ZONE-A": 10, "ZONE-B": 1}, total_workers=6, min_per_zone=1)
    assert sum(p.assigned_workers for p in plan) == 6
    assert all(p.assigned_workers >= 1 for p in plan)


def test_charging_schedule_respects_concurrency_cap():
    needs = {f"AMR-{i:02d}": 500.0 for i in range(10)}
    result = optimise_charging_schedule(
        needs, num_slots=4, slot_seconds=3600, station_power_w=1000, max_concurrent=3,
    )
    assert max(result.slot_demand_w) <= 3 * 1000 + 1e-6
