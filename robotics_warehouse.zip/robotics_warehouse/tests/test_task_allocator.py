"""Multi-factor task allocation: capability filtering and scoring."""
from __future__ import annotations

import pytest

from backend.orchestration.tasks import Task, TaskType
from robotics.robot_models.robot import RobotState, RobotStatus, RobotType
from robotics.task_allocator.allocator import NoCapableRobotError, TaskAllocator


def _amr(robot_id: str, node: str, *, battery: float = 90.0) -> RobotState:
    return RobotState(robot_id=robot_id, robot_type=RobotType.AMR, current_node=node, battery_pct=battery)


def test_allocator_picks_closer_robot(small_graph):
    allocator = TaskAllocator(small_graph)
    robots = {"AMR-NEAR": _amr("AMR-NEAR", "B"), "AMR-FAR": _amr("AMR-FAR", "D")}
    task = Task(task_type=TaskType.MOVE, source="A", destination="D")
    candidate = allocator.find_best_robot(task, robots)
    assert candidate.robot_id == "AMR-NEAR"


def test_allocator_penalises_low_battery(small_graph):
    allocator = TaskAllocator(small_graph)
    robots = {
        "AMR-LOW": _amr("AMR-LOW", "B", battery=8.0),
        "AMR-OK": _amr("AMR-OK", "C", battery=80.0),
    }
    task = Task(task_type=TaskType.MOVE, source="A", destination="D")
    candidate = allocator.find_best_robot(task, robots)
    assert candidate.robot_id == "AMR-OK"


def test_allocator_filters_by_capability(small_graph):
    allocator = TaskAllocator(small_graph)
    robots = {"AMR-01": _amr("AMR-01", "A")}
    task = Task(task_type=TaskType.SORT, source="A", destination="D")  # AMR cannot SORT
    with pytest.raises(NoCapableRobotError):
        allocator.find_best_robot(task, robots)


def test_allocator_filters_by_required_robot_type(small_graph):
    allocator = TaskAllocator(small_graph)
    robots = {"AMR-01": _amr("AMR-01", "A")}
    task = Task(task_type=TaskType.MOVE, source="A", destination="D", required_robot_type="AGV")
    with pytest.raises(NoCapableRobotError):
        allocator.find_best_robot(task, robots)


def test_allocator_ignores_busy_robots(small_graph):
    allocator = TaskAllocator(small_graph)
    busy = _amr("AMR-BUSY", "B")
    busy.status = RobotStatus.EXECUTING_TASK
    robots = {"AMR-BUSY": busy, "AMR-IDLE": _amr("AMR-IDLE", "D")}
    task = Task(task_type=TaskType.MOVE, source="A", destination="D")
    candidate = allocator.find_best_robot(task, robots)
    assert candidate.robot_id == "AMR-IDLE"


def test_allocator_rejects_overweight_payload(small_graph):
    allocator = TaskAllocator(small_graph)
    robots = {"AMR-01": _amr("AMR-01", "A")}
    task = Task(task_type=TaskType.MOVE, source="A", destination="D", payload_kg=10_000)
    with pytest.raises(NoCapableRobotError):
        allocator.find_best_robot(task, robots)
