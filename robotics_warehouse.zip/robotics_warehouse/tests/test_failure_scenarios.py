"""Failure-injection, load and concurrency scenarios (spec section 28):

    - many robots operating simultaneously
    - many robots contending for entry into one zone
    - charging-station failure
    - network interruption
    - robot failure during an active task
    - conveyor failure
    - a sudden order surge
    - warehouse-zone closure
"""
from __future__ import annotations

import time

import pytest

from backend.events.event_bus import EventBus
from backend.orchestration.tasks import TaskStatus
from digital_twin.warehouse_model.builder import BuildSpec, build_demo_warehouse
from robotics.collision_avoidance.safety import SafetyLayer
from robotics.robot_models.robot import RobotStatus
from simulation.warehouse_simulator.simulator import WarehouseSimulator


@pytest.mark.slow
def test_large_fleet_operates_simultaneously_without_error():
    """A fleet at the scale the spec calls out (200 AMRs here, kept below the
    documented 500/1000 ceiling to keep the suite fast; see
    ``simulation.scenario_engine`` for the full-scale what-if runner)."""
    spec = BuildSpec(num_amrs=200, num_robotic_arms=5, num_storage_locations=500, num_skus=500, seed=11)
    bundle = build_demo_warehouse(spec)
    sim = WarehouseSimulator(bundle, EventBus(), orders_per_hour=1500.0, seed=11)

    t0 = time.time()
    for _ in range(300):
        sim.tick(1.0)
    wall = time.time() - t0

    assert sim.stats.tasks_completed > 0
    assert wall < 30.0  # must stay comfortably real-time-capable at this scale


def test_many_robots_contending_for_one_zone_resolves_without_deadlock():
    safety = SafetyLayer()
    node_id = "ZONE-C-ENTRY"
    winners = [safety.request_reservation(node_id, f"AMR-{i:03d}") for i in range(100)]
    # Exactly one robot holds the contested node; the other 99 are correctly refused.
    assert sum(winners) == 1
    assert safety.holder_of(node_id) is not None


def test_charging_station_failure_does_not_crash_dispatch(tiny_spec):
    bundle = build_demo_warehouse(tiny_spec)
    sim = WarehouseSimulator(bundle, EventBus(), orders_per_hour=400.0, seed=tiny_spec.seed)
    # Simulate every charging station going offline (e.g. a power fault).
    for station in sim.warehouse.charging_stations.values():
        station.slots = 0
    for _ in range(300):
        sim.tick(1.0)  # must not raise even though no robot can ever charge
    assert sim.fleet_manager.charging.utilisation() == 0.0


def test_network_interruption_marks_robot_offline_and_frees_it_for_recovery(tiny_spec):
    bundle = build_demo_warehouse(tiny_spec)
    sim = WarehouseSimulator(bundle, EventBus(), orders_per_hour=400.0, seed=tiny_spec.seed)
    robot_id = next(iter(sim.fleet_manager.robots))
    sim.fleet_manager.mark_disconnected(robot_id)
    robot = sim.fleet_manager.robots[robot_id]
    assert robot.status == RobotStatus.OFFLINE
    assert robot.connectivity.value == "LOST"


def test_robot_failure_during_active_task_triggers_recovery(tiny_spec):
    bundle = build_demo_warehouse(tiny_spec)
    sim = WarehouseSimulator(bundle, EventBus(), orders_per_hour=400.0, seed=tiny_spec.seed)
    for _ in range(20):
        sim.tick(1.0)
    busy = next((r for r in sim.fleet_manager.robots.values() if r.status == RobotStatus.EXECUTING_TASK), None)
    if busy is None:
        pytest.skip("no robot picked up a task in the warmup window for this seed")
    task = sim.tasks[busy.current_task_id]
    sim.fleet_manager.recover_failed_task(task, "simulated hardware fault")
    assert task.status == TaskStatus.QUEUED
    assert task.retry_count == 1


def test_conveyor_failure_is_reflected_and_recoverable(tiny_spec):
    bundle = build_demo_warehouse(tiny_spec)
    conveyor = next(iter(bundle.warehouse.conveyors.values()))
    conveyor.blocked = True
    assert conveyor.blocked is True
    conveyor.blocked = False
    assert conveyor.blocked is False


def test_sudden_order_surge_does_not_break_allocation(tiny_spec):
    bundle = build_demo_warehouse(tiny_spec)
    sim = WarehouseSimulator(bundle, EventBus(), orders_per_hour=100.0, seed=tiny_spec.seed)
    for _ in range(60):
        sim.tick(1.0)
    baseline_created = sim.stats.orders_created
    sim.order_simulator.set_rate(5000.0)  # sudden 50x surge
    for _ in range(120):
        sim.tick(1.0)
    assert sim.stats.orders_created > baseline_created
    assert sim.stats.tasks_failed <= sim.stats.tasks_created  # no runaway failure loop


def test_warehouse_zone_closure_prevents_routing_through_it(tiny_spec):
    bundle = build_demo_warehouse(tiny_spec)
    zone_id, zone = next(iter(bundle.warehouse.zones.items()))
    closed_nodes = [n for n in bundle.graph.nodes.values() if n.zone_id == zone_id]
    for node in closed_nodes:
        node.restricted = True

    from robotics.navigation.pathfinding import a_star
    other_nodes = [nid for nid, n in bundle.graph.nodes.items() if n.zone_id != zone_id]
    if len(other_nodes) < 2:
        pytest.skip("facility too small to have a route avoiding the closed zone")
    route = a_star(bundle.graph, other_nodes[0], other_nodes[-1])
    assert all(bundle.graph.nodes[nid].zone_id != zone_id for nid in route.node_ids)
