"""Event bus: pub/sub dispatch, idempotent delivery, wildcard subscription."""
from __future__ import annotations

from backend.events.event_bus import EventBus
from backend.events.event_types import BatteryLow, RobotRegistered


async def test_subscriber_receives_matching_event_type():
    bus = EventBus()
    received = []
    bus.subscribe(BatteryLow, lambda e: received.append(e))
    await bus.publish(BatteryLow(robot_id="AMR-01", battery_pct=12.0))
    assert len(received) == 1
    assert received[0].robot_id == "AMR-01"


async def test_subscriber_does_not_receive_other_event_types():
    bus = EventBus()
    received = []
    bus.subscribe(BatteryLow, lambda e: received.append(e))
    await bus.publish(RobotRegistered(robot_id="AMR-01", robot_type="AMR"))
    assert received == []


async def test_wildcard_subscriber_receives_everything():
    bus = EventBus()
    received = []
    bus.subscribe_all(lambda e: received.append(e))
    await bus.publish(BatteryLow(robot_id="AMR-01", battery_pct=12.0))
    await bus.publish(RobotRegistered(robot_id="AMR-02", robot_type="AGV"))
    assert len(received) == 2


async def test_duplicate_event_id_is_suppressed():
    bus = EventBus()
    received = []
    bus.subscribe_all(lambda e: received.append(e))
    event = BatteryLow(robot_id="AMR-01", battery_pct=12.0)
    await bus.publish(event)
    await bus.publish(event)  # same event_id -- must not be delivered twice
    assert len(received) == 1


async def test_broken_handler_does_not_prevent_other_handlers():
    bus = EventBus()
    received = []

    def _broken(event):
        raise RuntimeError("boom")

    bus.subscribe_all(_broken)
    bus.subscribe_all(lambda e: received.append(e))
    await bus.publish(BatteryLow(robot_id="AMR-01", battery_pct=12.0))
    assert len(received) == 1


async def test_unsubscribe_all_stops_delivery():
    bus = EventBus()
    received = []
    handler = lambda e: received.append(e)
    bus.subscribe_all(handler)
    bus.unsubscribe_all(handler)
    await bus.publish(BatteryLow(robot_id="AMR-01", battery_pct=12.0))
    assert received == []
