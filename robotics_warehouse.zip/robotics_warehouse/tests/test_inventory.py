"""Inventory service: FIFO/FEFO/LIFO allocation, reservation, cycle counting."""
from __future__ import annotations

from datetime import UTC, date, datetime, timedelta

import pytest

from backend.inventory.models import InsufficientInventoryError, InventoryLot
from backend.inventory.service import AllocationStrategy, InventoryService


def _lot(sku, qty, days_ago=0, expiry=None) -> InventoryLot:
    return InventoryLot(
        sku=sku, location_id="LOC-1", quantity=qty, batch_number="B1",
        received_at=datetime.now(UTC) - timedelta(days=days_ago), expiry_date=expiry,
    )


def test_fifo_consumes_oldest_lot_first(event_bus):
    inv = InventoryService(event_bus, default_strategy=AllocationStrategy.FIFO)
    old = _lot("SKU-1", 10, days_ago=10)
    new = _lot("SKU-1", 10, days_ago=1)
    inv.receive(old)
    inv.receive(new)
    plan = inv.reserve("SKU-1", 5)
    assert plan[0][0] == old.lot_id


def test_lifo_consumes_newest_lot_first(event_bus):
    inv = InventoryService(event_bus, default_strategy=AllocationStrategy.LIFO)
    old = _lot("SKU-1", 10, days_ago=10)
    new = _lot("SKU-1", 10, days_ago=1)
    inv.receive(old)
    inv.receive(new)
    plan = inv.reserve("SKU-1", 5)
    assert plan[0][0] == new.lot_id


def test_fefo_consumes_soonest_expiry_first(event_bus):
    inv = InventoryService(event_bus, default_strategy=AllocationStrategy.FEFO)
    soon = _lot("SKU-1", 10, expiry=date.today() + timedelta(days=2))
    later = _lot("SKU-1", 10, expiry=date.today() + timedelta(days=30))
    inv.receive(later)
    inv.receive(soon)
    plan = inv.reserve("SKU-1", 5)
    assert plan[0][0] == soon.lot_id


def test_reservation_spans_multiple_lots_when_needed(event_bus):
    inv = InventoryService(event_bus)
    inv.receive(_lot("SKU-1", 5))
    inv.receive(_lot("SKU-1", 5))
    plan = inv.reserve("SKU-1", 8)
    assert len(plan) == 2
    assert sum(q for _, q in plan) == 8


def test_insufficient_inventory_raises_without_partial_reservation(event_bus):
    inv = InventoryService(event_bus)
    inv.receive(_lot("SKU-1", 5))
    with pytest.raises(InsufficientInventoryError):
        inv.reserve("SKU-1", 100)
    assert inv.available("SKU-1") == 5  # nothing was partially reserved


def test_consume_reduces_on_hand_and_publishes_event(event_bus):
    inv = InventoryService(event_bus)
    lot = _lot("SKU-1", 10)
    inv.receive(lot)
    inv.reserve("SKU-1", 4)
    inv.consume(lot.lot_id, 4, to_location="PACK-01")
    assert inv.on_hand("SKU-1") == 6


def test_cycle_count_reconciles_variance(event_bus):
    inv = InventoryService(event_bus)
    inv.receive(_lot("SKU-1", 10))
    variance = inv.cycle_count("SKU-1", 8)
    assert variance == -2
    assert inv.on_hand("SKU-1") == 8


def test_needs_replenishment(event_bus):
    inv = InventoryService(event_bus)
    inv.receive(_lot("SKU-1", 3))
    assert inv.needs_replenishment("SKU-1", reorder_point=5) is True
    assert inv.needs_replenishment("SKU-1", reorder_point=1) is False
