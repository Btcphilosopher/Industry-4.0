"""Order fulfilment pipeline: RECEIVED -> ... -> TASKS_GENERATED, then completion."""
from __future__ import annotations

from datetime import UTC, datetime

import pytest

from backend.inventory.models import InventoryLot
from backend.inventory.service import InventoryService
from backend.orchestration.tasks import TaskStatus, TaskType
from backend.orders.models import Order, OrderLine
from backend.orders.pipeline import OrderPipeline, OrderValidationError


def _make_pipeline(event_bus):
    inv = InventoryService(event_bus)
    inv.receive(InventoryLot(
        sku="SKU-1", location_id="LOC-1", quantity=20, batch_number="B1",
        received_at=datetime.now(UTC),
    ))
    pipeline = OrderPipeline(
        inv, event_bus, packing_station_ids=["PACK-01", "PACK-02"],
        location_node_map={"LOC-1": "NODE-1"},
    )
    return pipeline, inv


def test_submit_generates_pick_and_pack_tasks(event_bus):
    pipeline, _ = _make_pipeline(event_bus)
    order = Order(lines=[OrderLine(sku="SKU-1", quantity=5)])
    tasks = pipeline.submit(order)
    assert any(t.task_type == TaskType.PICK for t in tasks)
    assert any(t.task_type == TaskType.PACK for t in tasks)
    assert all(t.status == TaskStatus.QUEUED for t in tasks)


def test_pick_task_source_resolves_through_location_node_map(event_bus):
    pipeline, _ = _make_pipeline(event_bus)
    order = Order(lines=[OrderLine(sku="SKU-1", quantity=5)])
    tasks = pipeline.submit(order)
    pick = next(t for t in tasks if t.task_type == TaskType.PICK)
    assert pick.source == "NODE-1"  # not the raw location_id "LOC-1"


def test_empty_order_fails_validation(event_bus):
    pipeline, _ = _make_pipeline(event_bus)
    with pytest.raises(OrderValidationError):
        pipeline.submit(Order(lines=[]))


def test_order_dispatches_once_all_tasks_complete(event_bus):
    pipeline, inv = _make_pipeline(event_bus)
    order = Order(lines=[OrderLine(sku="SKU-1", quantity=5)])
    tasks = pipeline.submit(order)
    for t in tasks:
        for tid in (TaskStatus.ASSIGNED, TaskStatus.EXECUTING, TaskStatus.COMPLETED):
            t.transition(tid)
        pipeline.on_task_completed(t)
    assert order.status.value == "DISPATCHED"
    assert order.dispatched_at is not None


def test_pick_completion_consumes_exact_reserved_lot_only_once(event_bus):
    pipeline, inv = _make_pipeline(event_bus)
    # Two lines with the SAME sku -- a regression test for a bug where
    # completion matched by SKU alone and double-consumed the first line's lot.
    order = Order(lines=[OrderLine(sku="SKU-1", quantity=5), OrderLine(sku="SKU-1", quantity=3)])
    tasks = pipeline.submit(order)
    picks = [t for t in tasks if t.task_type == TaskType.PICK]
    assert len(picks) == 2
    for t in picks:
        t.transition(TaskStatus.ASSIGNED)
        t.transition(TaskStatus.EXECUTING)
        t.transition(TaskStatus.COMPLETED)
        pipeline.on_task_completed(t)  # must not raise
    assert inv.on_hand("SKU-1") == 20 - 8
