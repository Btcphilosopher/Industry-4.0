"""Fleet manager: registration, task assignment, fault handling, recovery."""
from __future__ import annotations

import pytest

from backend.orchestration.tasks import Task, TaskStatus, TaskType
from robotics.fleet_manager.fleet_manager import FleetManager
from robotics.robot_models.robot import RobotState, RobotStatus, RobotType


def _make_fleet(small_graph, event_bus) -> FleetManager:
    return FleetManager(small_graph, charging_stations={}, event_bus=event_bus)


def _queued_task(**kwargs) -> Task:
    """A task in the QUEUED state, matching how the order pipeline hands
    tasks to the fleet manager (assign_task requires QUEUED -> ASSIGNED)."""
    task = Task(**kwargs)
    task.transition(TaskStatus.QUEUED)
    return task


def test_register_and_deregister_robot(small_graph, event_bus):
    fleet = _make_fleet(small_graph, event_bus)
    robot = RobotState(robot_id="AMR-01", robot_type=RobotType.AMR, current_node="A")
    fleet.register_robot(robot)
    assert "AMR-01" in fleet.robots
    fleet.deregister_robot("AMR-01")
    assert "AMR-01" not in fleet.robots


def test_duplicate_registration_raises(small_graph, event_bus):
    fleet = _make_fleet(small_graph, event_bus)
    fleet.register_robot(RobotState(robot_id="AMR-01", robot_type=RobotType.AMR, current_node="A"))
    with pytest.raises(ValueError):
        fleet.register_robot(RobotState(robot_id="AMR-01", robot_type=RobotType.AMR, current_node="B"))


def test_assign_task_selects_and_marks_robot_busy(small_graph, event_bus):
    fleet = _make_fleet(small_graph, event_bus)
    fleet.register_robot(RobotState(robot_id="AMR-01", robot_type=RobotType.AMR, current_node="A"))
    task = _queued_task(task_type=TaskType.MOVE, source="A", destination="D")
    robot_id = fleet.assign_task(task)
    assert robot_id == "AMR-01"
    assert fleet.robots["AMR-01"].status == RobotStatus.EXECUTING_TASK
    assert task.status == TaskStatus.ASSIGNED
    assert "AMR-01" in fleet.active_routes


def test_assign_task_returns_none_when_no_robot_available(small_graph, event_bus):
    fleet = _make_fleet(small_graph, event_bus)
    task = Task(task_type=TaskType.MOVE, source="A", destination="D")
    assert fleet.assign_task(task) is None


def test_report_fault_marks_robot_faulted(small_graph, event_bus):
    fleet = _make_fleet(small_graph, event_bus)
    fleet.register_robot(RobotState(robot_id="AMR-01", robot_type=RobotType.AMR, current_node="A"))
    fleet.report_fault("AMR-01", "MOTOR_OVERCURRENT")
    assert fleet.robots["AMR-01"].status == RobotStatus.FAULTED
    assert fleet.robots["AMR-01"].fault_code == "MOTOR_OVERCURRENT"


def test_recover_failed_task_requeues_up_to_retry_limit(small_graph, event_bus):
    fleet = _make_fleet(small_graph, event_bus)
    fleet.register_robot(RobotState(robot_id="AMR-01", robot_type=RobotType.AMR, current_node="A"))
    task = _queued_task(task_type=TaskType.MOVE, source="A", destination="D")
    fleet.assign_task(task)
    task.transition(TaskStatus.EXECUTING)
    fleet.recover_failed_task(task, "robot disconnected")
    assert task.status == TaskStatus.QUEUED
    assert task.retry_count == 1
    assert fleet.robots["AMR-01"].status == RobotStatus.IDLE


def test_release_robot_clears_task_assignment(small_graph, event_bus):
    fleet = _make_fleet(small_graph, event_bus)
    fleet.register_robot(RobotState(robot_id="AMR-01", robot_type=RobotType.AMR, current_node="A"))
    task = _queued_task(task_type=TaskType.MOVE, source="A", destination="D")
    fleet.assign_task(task)
    fleet.release_robot("AMR-01")
    robot = fleet.robots["AMR-01"]
    assert robot.status == RobotStatus.IDLE
    assert robot.current_task_id is None
    assert "AMR-01" not in fleet.active_routes


def test_fleet_snapshot_aggregates_status_counts(small_graph, event_bus):
    fleet = _make_fleet(small_graph, event_bus)
    fleet.register_robot(RobotState(robot_id="AMR-01", robot_type=RobotType.AMR, current_node="A", battery_pct=80))
    fleet.register_robot(RobotState(robot_id="AMR-02", robot_type=RobotType.AMR, current_node="B", battery_pct=60))
    snapshot = fleet.snapshot()
    assert snapshot.total == 2
    assert snapshot.by_status["IDLE"] == 2
    assert snapshot.avg_battery_pct == pytest.approx(70.0)
