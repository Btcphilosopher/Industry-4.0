"""Predictive maintenance model and ML-layer interfaces."""
from __future__ import annotations

from backend.maintenance.health import MaintenanceService
from ml.anomaly_detection.detector import RollingZScoreDetector
from ml.demand_forecasting.forecaster import MovingAverageForecaster
from ml.optimisation_models.rl_interface import HeuristicPolicy, Observation, safe_recommend
from ml.predictive_maintenance.health_model import (
    AssetSignals,
    MaintenancePriority,
    WeightedDegradationModel,
)
from robotics.robot_models.robot import RobotState, RobotType


def test_healthy_asset_scores_high():
    model = WeightedDegradationModel()
    signals = AssetSignals(asset_id="AMR-01", motor_temp_c=40, vibration_index=0.0, duty_cycle_pct=50, age_hours=100)
    result = model.assess(signals)
    assert result.priority == MaintenancePriority.NONE
    assert result.health_score > 0.85


def test_degraded_asset_scores_low_and_urgent():
    model = WeightedDegradationModel()
    signals = AssetSignals(
        asset_id="AMR-02", motor_temp_c=85, vibration_index=1.0, duty_cycle_pct=100,
        age_hours=19_000, fault_count_30d=10,
    )
    result = model.assess(signals)
    assert result.priority == MaintenancePriority.URGENT
    assert result.health_score < 0.25


def test_maintenance_service_updates_robot_health_score(event_bus):
    service = MaintenanceService(event_bus)
    robot = RobotState(robot_id="AMR-01", robot_type=RobotType.AMR, motor_temp_c=90, hours_in_service=19_000)
    assessment = service.assess_robot(robot, vibration_index=0.9, fault_count_30d=5)
    assert robot.health_score == assessment.health_score
    assert robot.health_score < 1.0


def test_anomaly_detector_flags_outlier_after_warmup():
    detector = RollingZScoreDetector(window=20, z_threshold=3.0)
    for _ in range(10):
        result = detector.observe("AMR-01:motor_temp", 40.0)
    assert result.is_anomaly is False
    spike = detector.observe("AMR-01:motor_temp", 400.0)
    assert spike.is_anomaly is True


def test_forecaster_produces_nonnegative_horizon():
    forecaster = MovingAverageForecaster(window=5)
    forecaster.fit({"SKU-1": [10, 12, 11, 15, 20]})
    forecast = forecaster.predict("SKU-1", horizon=3)
    assert len(forecast) == 3
    assert all(v >= 0 for v in forecast)


def test_safe_recommend_falls_back_on_low_confidence():
    class LowConfidencePolicy:
        def recommend(self, observation):
            from ml.optimisation_models.rl_interface import PolicyRecommendation
            return PolicyRecommendation(robot_id=observation.candidate_robot_ids[0], confidence=0.1, rationale="unsure")

        def record_outcome(self, *a, **k):
            pass

    observation = Observation(
        task_type="PICK", task_priority=1, candidate_robot_ids=["A", "B"], candidate_scores=[0.2, 0.9],
    )
    rec = safe_recommend(LowConfidencePolicy(), observation, min_confidence=0.6)
    assert rec.robot_id == "B"  # deterministic fallback picks the top-scored candidate


def test_safe_recommend_uses_confident_policy_result():
    policy = HeuristicPolicy()
    observation = Observation(
        task_type="PICK", task_priority=1, candidate_robot_ids=["A", "B"], candidate_scores=[0.9, 0.2],
    )
    rec = safe_recommend(policy, observation)
    assert rec.robot_id == "A"
