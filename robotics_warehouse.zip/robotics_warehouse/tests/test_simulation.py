"""End-to-end simulation loop: orders flow through to completed, deterministic seeding."""
from __future__ import annotations

from backend.events.event_bus import EventBus
from digital_twin.warehouse_model.builder import BuildSpec, build_demo_warehouse
from simulation.warehouse_simulator.simulator import WarehouseSimulator


def _run(spec: BuildSpec, *, ticks: int, orders_per_hour: float = 600.0) -> WarehouseSimulator:
    bundle = build_demo_warehouse(spec)
    sim = WarehouseSimulator(bundle, EventBus(), orders_per_hour=orders_per_hour, seed=spec.seed)
    for _ in range(ticks):
        sim.tick(1.0)
    return sim


def test_simulation_runs_without_error_and_progresses(tiny_spec):
    sim = _run(tiny_spec, ticks=600)
    assert sim.stats.ticks == 600
    assert sim.stats.orders_created > 0
    assert sim.stats.tasks_created > 0
    assert sim.stats.tasks_completed > 0


def test_simulation_is_deterministic_given_the_same_seed(tiny_spec):
    sim_a = _run(tiny_spec, ticks=300)
    sim_b = _run(tiny_spec, ticks=300)
    assert sim_a.stats.orders_created == sim_b.stats.orders_created
    assert sim_a.stats.tasks_created == sim_b.stats.tasks_created
    assert sim_a.stats.tasks_completed == sim_b.stats.tasks_completed


def test_robots_consume_battery_over_time(tiny_spec):
    sim = _run(tiny_spec, ticks=900, orders_per_hour=1200.0)
    batteries = [r.battery_pct for r in sim.fleet_manager.robots.values()]
    assert min(batteries) < 100.0


def test_no_task_or_robot_gets_permanently_stuck_in_a_transient_state(tiny_spec):
    sim = _run(tiny_spec, ticks=1200, orders_per_hour=900.0)
    # Every robot must be in a well-defined status (the state machine never
    # leaves a robot in an undefined/half-updated condition).
    valid_statuses = {
        "IDLE", "EXECUTING_TASK", "MOVING_TO_CHARGE", "CHARGING", "FAULTED",
        "MAINTENANCE", "OFFLINE", "BLOCKED", "ESTOP",
    }
    for robot in sim.fleet_manager.robots.values():
        assert robot.status.value in valid_statuses
        assert 0.0 <= robot.battery_pct <= 100.0
