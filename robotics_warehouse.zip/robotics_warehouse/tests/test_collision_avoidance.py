"""Safety layer: reservations, right-of-way, proximity conflicts, deadlock detection."""
from __future__ import annotations

from robotics.collision_avoidance.safety import ConflictType, SafetyLayer


def test_reservation_is_exclusive_between_different_robots():
    safety = SafetyLayer()
    assert safety.request_reservation("NODE-1", "AMR-01") is True
    assert safety.request_reservation("NODE-1", "AMR-02") is False
    assert safety.holder_of("NODE-1") == "AMR-01"


def test_same_robot_can_renew_its_own_reservation():
    safety = SafetyLayer()
    safety.request_reservation("NODE-1", "AMR-01")
    assert safety.request_reservation("NODE-1", "AMR-01") is True


def test_critical_priority_preempts_lower_priority_holder():
    safety = SafetyLayer()
    safety.request_reservation("NODE-1", "AMR-01", priority=1)
    assert safety.request_reservation("NODE-1", "AMR-02", priority=3) is True
    assert safety.holder_of("NODE-1") == "AMR-02"


def test_excluded_node_rejects_all_reservations():
    safety = SafetyLayer()
    safety.exclude_node("NODE-1")
    assert safety.request_reservation("NODE-1", "AMR-01") is False
    safety.release_node("NODE-1")
    assert safety.request_reservation("NODE-1", "AMR-01") is True


def test_release_only_clears_own_reservation():
    safety = SafetyLayer()
    safety.request_reservation("NODE-1", "AMR-01")
    safety.release_reservation("NODE-1", "AMR-02")  # not the holder -- no-op
    assert safety.holder_of("NODE-1") == "AMR-01"
    safety.release_reservation("NODE-1", "AMR-01")
    assert safety.holder_of("NODE-1") is None


def test_proximity_conflict_detected_for_close_robots():
    safety = SafetyLayer(min_separation_m=1.5)
    conflicts = safety.detect_proximity_conflicts({
        "AMR-01": (0.0, 0.0), "AMR-02": (0.5, 0.0), "AMR-03": (50.0, 50.0),
    })
    assert len(conflicts) == 1
    assert conflicts[0].conflict_type == ConflictType.ROBOT_ROBOT
    assert set(conflicts[0].involved) == {"AMR-01", "AMR-02"}


def test_human_conflict_detected_within_safety_margin():
    safety = SafetyLayer()
    conflicts = safety.detect_human_conflicts(
        {"AMR-01": (0.0, 0.0)}, {"WORKER-1": (1.0, 0.0)}, safety_margin_m=2.5,
    )
    assert len(conflicts) == 1
    assert conflicts[0].conflict_type == ConflictType.ROBOT_HUMAN


def test_deadlock_cycle_detected():
    safety = SafetyLayer()
    wait_graph = {"AMR-01": "AMR-02", "AMR-02": "AMR-03", "AMR-03": "AMR-01"}
    conflicts = safety.detect_deadlock(wait_graph)
    assert len(conflicts) == 1
    assert conflicts[0].conflict_type == ConflictType.DEADLOCK
    assert set(conflicts[0].involved) == {"AMR-01", "AMR-02", "AMR-03"}


def test_no_deadlock_when_wait_chain_terminates():
    safety = SafetyLayer()
    wait_graph = {"AMR-01": "AMR-02", "AMR-02": "AMR-03"}  # AMR-03 waits on nothing
    assert safety.detect_deadlock(wait_graph) == []


def test_emergency_stop_scopes():
    safety = SafetyLayer()
    safety.trigger_estop("ZONE-A")
    assert safety.is_estopped("ZONE-A") is True
    assert safety.is_estopped("ZONE-B") is False
    safety.trigger_estop("GLOBAL")
    assert safety.is_estopped("ZONE-B") is True
    safety.clear_estop("GLOBAL")
    assert safety.is_estopped("ZONE-B") is False
