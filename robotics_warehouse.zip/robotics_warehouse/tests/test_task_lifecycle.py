"""Task lifecycle state machine."""
from __future__ import annotations

from datetime import UTC

import pytest

from backend.orchestration.tasks import Task, TaskLifecycleError, TaskStatus, TaskType


def test_valid_transition_sequence():
    task = Task(task_type=TaskType.PICK)
    task.transition(TaskStatus.QUEUED)
    task.transition(TaskStatus.ASSIGNED)
    task.transition(TaskStatus.EXECUTING)
    task.transition(TaskStatus.COMPLETED)
    assert task.status == TaskStatus.COMPLETED
    assert task.is_terminal()


def test_illegal_transition_raises():
    task = Task(task_type=TaskType.PICK)
    with pytest.raises(TaskLifecycleError):
        task.transition(TaskStatus.COMPLETED)  # cannot jump straight from CREATED


def test_failed_task_can_be_requeued_for_recovery():
    task = Task(task_type=TaskType.PICK)
    task.transition(TaskStatus.QUEUED)
    task.transition(TaskStatus.ASSIGNED)
    task.transition(TaskStatus.FAILED)
    task.transition(TaskStatus.QUEUED)
    assert task.status == TaskStatus.QUEUED


def test_completed_and_cancelled_are_terminal_with_no_further_transitions():
    task = Task(task_type=TaskType.MOVE)
    task.transition(TaskStatus.QUEUED)
    task.transition(TaskStatus.CANCELLED)
    with pytest.raises(TaskLifecycleError):
        task.transition(TaskStatus.QUEUED)


def test_actual_duration_recorded_on_completion():
    task = Task(task_type=TaskType.MOVE)
    task.transition(TaskStatus.QUEUED)
    task.transition(TaskStatus.ASSIGNED)
    task.transition(TaskStatus.EXECUTING)
    task.transition(TaskStatus.COMPLETED)
    assert task.actual_duration_s is not None
    assert task.actual_duration_s >= 0


def test_overdue_detection():
    from datetime import datetime, timedelta
    task = Task(task_type=TaskType.PICK, deadline=datetime.now(UTC) - timedelta(seconds=1))
    assert task.is_overdue() is True
