"""Shared pytest fixtures."""
from __future__ import annotations

import pytest

from backend.events.event_bus import EventBus
from digital_twin.warehouse_model.builder import BuildSpec, DigitalTwinBundle, build_demo_warehouse
from robotics.navigation.graph import Edge, Node, WarehouseGraph


@pytest.fixture
def small_graph() -> WarehouseGraph:
    """A tiny deterministic 5-node graph: A - B - C - D, with a shortcut A - E - D."""
    g = WarehouseGraph()
    g.add_node(Node("A", 0, 0))
    g.add_node(Node("B", 10, 0))
    g.add_node(Node("C", 20, 0))
    g.add_node(Node("D", 30, 0))
    g.add_node(Node("E", 15, 10))
    g.add_edge(Edge("A", "B", distance_m=10))
    g.add_edge(Edge("B", "C", distance_m=10))
    g.add_edge(Edge("C", "D", distance_m=10))
    g.add_edge(Edge("A", "E", distance_m=18))
    g.add_edge(Edge("E", "D", distance_m=18))
    return g


@pytest.fixture
def event_bus() -> EventBus:
    return EventBus()


@pytest.fixture
def tiny_spec() -> BuildSpec:
    """A small enough facility to build and simulate in milliseconds for fast tests."""
    return BuildSpec(
        num_zones=8, num_aisles=8, num_storage_locations=200, num_amrs=10, num_robotic_arms=2,
        num_conveyors=2, num_charging_stations=3, num_packing_stations=2, num_docks=2,
        num_skus=200, seed=7,
    )


@pytest.fixture
def tiny_bundle(tiny_spec: BuildSpec) -> DigitalTwinBundle:
    return build_demo_warehouse(tiny_spec)
