"""FastAPI application: health, auth, RBAC-gated endpoints."""
from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from backend.api.app import create_app
from configuration.settings import Settings


@pytest.fixture
def client():
    # simulation_speed_multiplier=0 avoids relying on real-time background
    # ticking during the test; endpoints operate on the runtime's initial state.
    settings = Settings(simulation_speed_multiplier=0.0, rate_limit_per_minute=10_000)
    app = create_app(settings)
    with TestClient(app) as c:
        yield c


def test_health_endpoint(client):
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


def test_list_robots_returns_seeded_fleet(client):
    r = client.get("/api/robots")
    assert r.status_code == 200
    robots = r.json()
    assert len(robots) > 0
    assert "robot_id" in robots[0]


def test_get_unknown_robot_returns_structured_404(client):
    r = client.get("/api/robots/DOES-NOT-EXIST")
    assert r.status_code == 404
    body = r.json()
    assert body["error"]["code"] == "ROBOT_NOT_FOUND"


def test_login_returns_bearer_token(client):
    r = client.post("/api/auth/login", json={"username": "admin", "password": "admin"})
    assert r.status_code == 200
    assert r.json()["role"] == "ADMIN"


def test_login_rejects_bad_credentials(client):
    r = client.post("/api/auth/login", json={"username": "admin", "password": "wrong"})
    assert r.status_code == 401


def test_submit_order_requires_authentication(client):
    r = client.post("/api/orders", json={"lines": [{"sku": "SKU-000001", "quantity": 1}]})
    assert r.status_code == 401


def test_submit_order_succeeds_with_valid_role(client):
    login = client.post("/api/auth/login", json={"username": "operator", "password": "operator"})
    token = login.json()["access_token"]
    r = client.post(
        "/api/orders", json={"lines": [{"sku": "SKU-000001", "quantity": 1}]},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert r.status_code in (201, 422)  # 422 if that particular SKU has no seeded stock this run


def test_emergency_stop_requires_elevated_role(client):
    login = client.post("/api/auth/login", json={"username": "viewer", "password": "viewer"})
    token = login.json()["access_token"]
    robot_id = client.get("/api/robots").json()[0]["robot_id"]
    r = client.post(
        f"/api/robots/{robot_id}/emergency-stop", headers={"Authorization": f"Bearer {token}"},
    )
    assert r.status_code == 403


def test_warehouse_layout_endpoint(client):
    r = client.get("/api/warehouse")
    assert r.status_code == 200
    body = r.json()
    assert len(body["zones"]) == 8


def test_analytics_endpoint_returns_metrics_shape(client):
    r = client.get("/api/analytics")
    assert r.status_code == 200
    body = r.json()
    assert "orders_per_hour" in body
    assert "robot_utilisation_pct" in body
