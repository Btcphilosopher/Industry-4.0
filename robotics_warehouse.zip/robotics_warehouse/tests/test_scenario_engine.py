"""What-if scenario engine: quantitative comparison across perturbed runs."""
from __future__ import annotations

from digital_twin.scenario_analysis.compare import compare_runs
from digital_twin.warehouse_model.builder import BuildSpec
from simulation.scenario_engine.scenarios import ScenarioDefinition, run_scenario


def _tiny_base_spec() -> BuildSpec:
    return BuildSpec(
        num_zones=8, num_aisles=8, num_storage_locations=200, num_amrs=15, num_robotic_arms=2,
        num_conveyors=2, num_charging_stations=3, num_packing_stations=2, num_docks=2, num_skus=200, seed=3,
    )


def test_baseline_scenario_runs_and_produces_metrics():
    scenario = ScenarioDefinition("baseline", "no perturbation")
    result = run_scenario(scenario, base_spec=_tiny_base_spec(), duration_s=180, tick_s=1.0)
    assert result.stats["orders_created"] >= 0
    assert result.metrics.orders_per_hour >= 0


def test_robot_failure_scenario_reduces_completion_relative_to_baseline():
    base_spec = _tiny_base_spec()

    def fail_half(sim, rng):
        robots = list(sim.fleet_manager.robots.values())
        for r in rng.sample(robots, len(robots) // 2):
            sim.fleet_manager.report_fault(r.robot_id, "SIMULATED_FAILURE")

    baseline = run_scenario(ScenarioDefinition("baseline", "control"), base_spec=base_spec, duration_s=300)
    degraded = run_scenario(
        ScenarioDefinition("half_fleet_down", "half the fleet faults immediately", mutate=fail_half),
        base_spec=base_spec, duration_s=300,
    )
    deltas = compare_runs(baseline.metrics, degraded.metrics)
    throughput_delta = next(d for d in deltas if d.name == "orders_per_hour")
    assert throughput_delta.scenario <= throughput_delta.baseline
