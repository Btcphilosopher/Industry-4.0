"""Reinforcement-learning / learned-optimisation interface.

This module deliberately contains *no* safety-critical logic. It defines
the contract a learned policy must satisfy to propose task-allocation or
routing adjustments, and a deterministic baseline (``HeuristicPolicy``)
that always satisfies it. Per spec section 25/33 ("the AI layer must remain
subordinate to deterministic safety and operational rules"): every
suggestion from a policy is a *recommendation* that passes back through
``robotics.task_allocator`` / ``robotics.collision_avoidance`` for
validation before it can affect a real robot -- nothing here issues robot
commands directly.
"""
from __future__ import annotations

import abc
import logging
from dataclasses import dataclass

logger = logging.getLogger("robotics_warehouse.ml.optimisation_models")


@dataclass(slots=True)
class Observation:
    """A snapshot of decision-relevant state for one allocation decision."""

    task_type: str
    task_priority: int
    candidate_robot_ids: list[str]
    candidate_scores: list[float]  # scores from the deterministic allocator


@dataclass(slots=True)
class PolicyRecommendation:
    robot_id: str
    confidence: float
    rationale: str


class OptimisationPolicy(abc.ABC):
    @abc.abstractmethod
    def recommend(self, observation: Observation) -> PolicyRecommendation: ...

    @abc.abstractmethod
    def record_outcome(self, observation: Observation, chosen_robot_id: str, reward: float) -> None:
        """Feedback hook for online/offline learning; no-op for non-learning policies."""


class HeuristicPolicy(OptimisationPolicy):
    """Deterministic fallback: simply agree with the highest-scored candidate.

    Used when no trained model is deployed, and as the safety fallback if a
    learned policy's confidence is too low or it errors.
    """

    def recommend(self, observation: Observation) -> PolicyRecommendation:
        if not observation.candidate_robot_ids:
            raise ValueError("no candidates to recommend from")
        best_idx = max(range(len(observation.candidate_scores)), key=lambda i: observation.candidate_scores[i])
        return PolicyRecommendation(
            robot_id=observation.candidate_robot_ids[best_idx],
            confidence=1.0,
            rationale="deterministic top-scored candidate",
        )

    def record_outcome(self, observation: Observation, chosen_robot_id: str, reward: float) -> None:
        return None


def safe_recommend(
    policy: OptimisationPolicy, observation: Observation, *, min_confidence: float = 0.6
) -> PolicyRecommendation:
    """Guard-railed entry point: falls back to the deterministic policy if the
    supplied policy errors or is not confident enough. This is the only
    function ``robotics.task_allocator`` should call.
    """
    try:
        rec = policy.recommend(observation)
        if rec.confidence >= min_confidence and rec.robot_id in observation.candidate_robot_ids:
            return rec
    except Exception:  # noqa: BLE001 - never let a learned policy crash allocation
        logger.debug("policy %r raised during recommend(); falling back to deterministic", type(policy).__name__)
    return HeuristicPolicy().recommend(observation)
