"""Statistical anomaly detection interface.

A rolling z-score detector is the default implementation -- transparent,
cheap, and good enough for telemetry streams (motor temperature, vibration,
current draw). The interface allows a learned model (e.g. isolation forest,
autoencoder) to be substituted later without changing callers in
``backend.maintenance`` or ``backend.telemetry``.
"""
from __future__ import annotations

import abc
from collections import deque
from dataclasses import dataclass

import numpy as np


@dataclass(slots=True)
class AnomalyResult:
    is_anomaly: bool
    score: float
    threshold: float


class AnomalyDetector(abc.ABC):
    @abc.abstractmethod
    def observe(self, key: str, value: float) -> AnomalyResult: ...


class RollingZScoreDetector(AnomalyDetector):
    def __init__(self, *, window: int = 100, z_threshold: float = 3.0) -> None:
        self.window = window
        self.z_threshold = z_threshold
        self._series: dict[str, deque[float]] = {}

    def observe(self, key: str, value: float) -> AnomalyResult:
        series = self._series.setdefault(key, deque(maxlen=self.window))
        if len(series) < 5:
            series.append(value)
            return AnomalyResult(False, 0.0, self.z_threshold)
        arr = np.asarray(series)
        mean, std = float(arr.mean()), float(arr.std()) or 1e-6
        z = abs((value - mean) / std)
        series.append(value)
        return AnomalyResult(z >= self.z_threshold, z, self.z_threshold)
