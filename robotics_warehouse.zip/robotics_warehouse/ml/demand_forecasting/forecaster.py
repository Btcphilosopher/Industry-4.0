"""Demand / workload forecasting abstraction.

``DemandForecaster`` is the interface the rest of the platform depends on.
``MovingAverageForecaster`` is a lightweight, dependency-free default
implementation good enough to drive slotting and staffing decisions out of
the box; a real deployment can swap in a proper time-series model (e.g. a
gradient-boosted or transformer forecaster) behind the same interface
without touching any caller.
"""
from __future__ import annotations

import abc

import numpy as np


class DemandForecaster(abc.ABC):
    @abc.abstractmethod
    def fit(self, history: dict[str, list[float]]) -> None:
        """``history`` maps SKU (or zone/queue id) to a time-ordered series of demand."""

    @abc.abstractmethod
    def predict(self, key: str, horizon: int) -> list[float]:
        """Predict the next ``horizon`` periods of demand for ``key``."""

    @abc.abstractmethod
    def confidence_interval(self, key: str, horizon: int) -> tuple[list[float], list[float]]:
        """Return (lower, upper) bounds per forecasted period."""


class MovingAverageForecaster(DemandForecaster):
    """Weighted moving-average forecaster with a simple variance-based band."""

    def __init__(self, window: int = 7) -> None:
        self.window = window
        self._history: dict[str, list[float]] = {}

    def fit(self, history: dict[str, list[float]]) -> None:
        self._history = {k: list(v) for k, v in history.items()}

    def _series(self, key: str) -> np.ndarray:
        return np.asarray(self._history.get(key, [0.0]), dtype=float)

    def predict(self, key: str, horizon: int) -> list[float]:
        series = self._series(key)
        window = series[-self.window:] if len(series) >= 1 else np.array([0.0])
        weights = np.linspace(1, 2, num=len(window))
        avg = float(np.average(window, weights=weights)) if len(window) else 0.0
        # naive trend: half the slope of the last two window points, damped
        trend = 0.0
        if len(window) >= 2:
            trend = float((window[-1] - window[0]) / max(len(window) - 1, 1)) * 0.5
        return [max(0.0, avg + trend * i) for i in range(1, horizon + 1)]

    def confidence_interval(self, key: str, horizon: int) -> tuple[list[float], list[float]]:
        series = self._series(key)
        std = float(np.std(series[-self.window:])) if len(series) > 1 else max(series.mean() * 0.2, 1.0)
        point = self.predict(key, horizon)
        lower = [max(0.0, p - 1.96 * std) for p in point]
        upper = [p + 1.96 * std for p in point]
        return lower, upper
