"""Predictive-maintenance health scoring interface.

Produces the four outputs required by the spec: HEALTH SCORE, FAILURE
PROBABILITY, REMAINING USEFUL LIFE, MAINTENANCE PRIORITY. The default
implementation is a transparent weighted-degradation model driven by
telemetry signals (temperature, vibration, duty cycle, age); it is
intentionally simple enough to audit, matching the platform rule that
safety/maintenance-relevant outputs must remain explainable even where an
ML model is involved.
"""
from __future__ import annotations

import abc
from dataclasses import dataclass
from enum import StrEnum


class MaintenancePriority(StrEnum):
    NONE = "NONE"
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    URGENT = "URGENT"


@dataclass(slots=True)
class AssetSignals:
    asset_id: str
    motor_temp_c: float
    vibration_index: float  # 0 (smooth) .. 1 (severe)
    duty_cycle_pct: float  # % of time actively working
    age_hours: float
    fault_count_30d: int = 0


@dataclass(slots=True)
class HealthAssessment:
    asset_id: str
    health_score: float  # 0..1, 1 = perfect health
    failure_probability: float  # 0..1 over the next maintenance window
    remaining_useful_life_hours: float
    priority: MaintenancePriority


class PredictiveMaintenanceModel(abc.ABC):
    @abc.abstractmethod
    def assess(self, signals: AssetSignals) -> HealthAssessment: ...


class WeightedDegradationModel(PredictiveMaintenanceModel):
    """Transparent scoring model: each signal contributes a penalty to health."""

    def __init__(
        self,
        *,
        nominal_temp_c: float = 45.0,
        max_temp_c: float = 85.0,
        design_life_hours: float = 20_000.0,
    ) -> None:
        self.nominal_temp_c = nominal_temp_c
        self.max_temp_c = max_temp_c
        self.design_life_hours = design_life_hours

    def assess(self, signals: AssetSignals) -> HealthAssessment:
        temp_penalty = max(0.0, (signals.motor_temp_c - self.nominal_temp_c)) / max(
            self.max_temp_c - self.nominal_temp_c, 1.0
        )
        temp_penalty = min(1.0, temp_penalty)
        vibration_penalty = min(1.0, signals.vibration_index)
        duty_penalty = min(1.0, max(0.0, signals.duty_cycle_pct - 80) / 20.0)
        age_penalty = min(1.0, signals.age_hours / self.design_life_hours)
        fault_penalty = min(1.0, signals.fault_count_30d / 10.0)

        weights = {
            "temp": 0.30, "vibration": 0.25, "duty": 0.10, "age": 0.20, "fault": 0.15,
        }
        composite_penalty = (
            weights["temp"] * temp_penalty
            + weights["vibration"] * vibration_penalty
            + weights["duty"] * duty_penalty
            + weights["age"] * age_penalty
            + weights["fault"] * fault_penalty
        )
        health_score = max(0.0, 1.0 - composite_penalty)
        failure_probability = min(1.0, composite_penalty ** 1.3)
        remaining_life = max(0.0, self.design_life_hours - signals.age_hours) * health_score

        if health_score >= 0.85:
            priority = MaintenancePriority.NONE
        elif health_score >= 0.65:
            priority = MaintenancePriority.LOW
        elif health_score >= 0.45:
            priority = MaintenancePriority.MEDIUM
        elif health_score >= 0.25:
            priority = MaintenancePriority.HIGH
        else:
            priority = MaintenancePriority.URGENT

        return HealthAssessment(
            asset_id=signals.asset_id,
            health_score=round(health_score, 4),
            failure_probability=round(failure_probability, 4),
            remaining_useful_life_hours=round(remaining_life, 1),
            priority=priority,
        )
