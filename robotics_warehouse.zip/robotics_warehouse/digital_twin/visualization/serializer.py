"""Serialises digital-twin state into a lightweight JSON-friendly shape for
the command-centre dashboard's live warehouse map (spec section 20).

Kept separate from the aggregator so the wire format can evolve (e.g. to
add delta/patch encoding for WebSocket bandwidth) without touching state
aggregation logic.
"""
from __future__ import annotations

from backend.warehouse.models import Warehouse
from digital_twin.live_state.aggregator import TwinSnapshot
from robotics.navigation.graph import WarehouseGraph


def serialize_static_layout(warehouse: Warehouse, graph: WarehouseGraph) -> dict:
    """One-time (or rarely-changing) payload: zones, nodes, stations. Sent once
    on dashboard connect; live updates then only need the dynamic snapshot.
    """
    return {
        "warehouse_id": warehouse.warehouse_id,
        "name": warehouse.name,
        "zones": [
            {
                "zone_id": z.zone_id, "name": z.name, "zone_type": z.zone_type.value,
                "bounds": [[z.bounds[0].x, z.bounds[0].y], [z.bounds[1].x, z.bounds[1].y]],
            }
            for z in warehouse.zones.values()
        ],
        "nodes": [
            {"node_id": n.node_id, "x": n.x, "y": n.y, "kind": n.kind.value, "zone_id": n.zone_id}
            for n in graph.nodes.values()
        ],
        "charging_stations": [
            {"station_id": s.station_id, "x": s.position.x, "y": s.position.y, "slots": s.slots}
            for s in warehouse.charging_stations.values()
        ],
        "packing_stations": [
            {"station_id": s.station_id, "x": s.position.x, "y": s.position.y}
            for s in warehouse.packing_stations.values()
        ],
        "docks": [
            {"dock_id": d.dock_id, "x": d.position.x, "y": d.position.y, "dock_type": d.dock_type}
            for d in warehouse.docks.values()
        ],
    }


def serialize_dynamic_state(snapshot: TwinSnapshot) -> dict:
    """The frequently-refreshed payload: robot positions, task counts, alerts."""
    return {
        "generated_at": snapshot.generated_at.isoformat(),
        "robots": snapshot.robots,
        "fleet_summary": snapshot.fleet_summary,
        "tasks": {
            "active": snapshot.tasks_active,
            "queued": snapshot.tasks_queued,
            "blocked": snapshot.tasks_blocked,
        },
        "zone_congestion": snapshot.zone_congestion,
        "charging_utilisation": snapshot.charging_utilisation,
    }
