"""Digital-twin warehouse builder.

Generates a complete, internally-consistent facility: the structural
digital twin (:class:`~backend.warehouse.models.Warehouse`), its navigation
graph, an initial robot fleet, a SKU catalogue and starting inventory.
Deterministic given a seed -- the same seed always produces the same
facility, which is required for reproducible simulation runs and
comparable what-if scenarios.

The default parameters match the demo-environment sizing in the platform
spec (section 32): 1 warehouse, 8 zones, 40 aisles, 2,000 storage
locations, 100 AMRs, 10 robotic arms, 12 conveyors, 8 charging stations, 5
packing stations, 3 loading docks, 10,000 SKUs.
"""
from __future__ import annotations

import random
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta

from backend.inventory.models import InventoryLot, SKUCatalogEntry
from backend.warehouse.models import (
    Aisle,
    ChargingStation,
    Conveyor,
    Dock,
    LocationType,
    PackingStation,
    Point2D,
    RoboticCell,
    StorageLocation,
    Warehouse,
    Zone,
    ZoneType,
)
from robotics.navigation.graph import Edge, Node, NodeKind, WarehouseGraph
from robotics.robot_models.robot import RobotState, RobotType


@dataclass(slots=True)
class BuildSpec:
    num_zones: int = 8
    num_aisles: int = 40
    num_storage_locations: int = 2000
    num_amrs: int = 100
    num_robotic_arms: int = 10
    num_conveyors: int = 12
    num_charging_stations: int = 8
    num_packing_stations: int = 5
    num_docks: int = 3
    num_skus: int = 10_000
    seed: int = 42


@dataclass(slots=True)
class DigitalTwinBundle:
    warehouse: Warehouse
    graph: WarehouseGraph
    robots: list[RobotState]
    sku_catalog: dict[str, SKUCatalogEntry]
    initial_inventory: list[InventoryLot]
    location_node_map: dict[str, str]  # StorageLocation.location_id -> graph Node.node_id


_STORAGE_ZONE_NAMES = ["Storage-A", "Storage-B", "Storage-C", "Storage-D"]


def build_demo_warehouse(spec: BuildSpec | None = None) -> DigitalTwinBundle:
    spec = spec or BuildSpec()
    rng = random.Random(spec.seed)

    warehouse = Warehouse(warehouse_id="WH-01", name="Northgate Fulfilment Centre", floors=1)
    graph = WarehouseGraph()

    zone_defs = _zone_layout(spec)
    for zone_id, (name, ztype, bounds) in zone_defs.items():
        warehouse.zones[zone_id] = Zone(zone_id=zone_id, name=name, zone_type=ztype, bounds=bounds)

    # --- backbone corridor: one node per zone, chained together -----------
    backbone_ids: list[str] = []
    for zone_id, zone in warehouse.zones.items():
        (x0, y0), (x1, y1) = zone.bounds
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        node_id = f"BB-{zone_id}"
        graph.add_node(Node(node_id, cx, cy, NodeKind.INTERSECTION, zone_id=zone_id))
        backbone_ids.append(node_id)
    for a, b in zip(backbone_ids, backbone_ids[1:]):
        na, nb = graph.nodes[a], graph.nodes[b]
        dist = ((na.x - nb.x) ** 2 + (na.y - nb.y) ** 2) ** 0.5
        graph.add_edge(Edge(a, b, distance_m=max(dist, 5.0), max_speed_mps=2.0))

    storage_zone_ids = [zid for zid, z in warehouse.zones.items() if z.zone_type == ZoneType.STORAGE]
    location_node_map: dict[str, str] = {}
    _build_aisles_and_locations(spec, rng, warehouse, graph, storage_zone_ids, location_node_map)

    picking_zone_id = next(zid for zid, z in warehouse.zones.items() if z.zone_type == ZoneType.PICKING)
    _build_robotic_cells(spec, warehouse, graph, picking_zone_id)

    packing_zone_id = next(zid for zid, z in warehouse.zones.items() if z.zone_type == ZoneType.PACKING)
    _build_packing_stations(spec, warehouse, graph, packing_zone_id)

    sortation_zone_id = next(zid for zid, z in warehouse.zones.items() if z.zone_type == ZoneType.SORTATION)
    _build_conveyors(spec, warehouse, graph, sortation_zone_id)

    receiving_zone_id = next(zid for zid, z in warehouse.zones.items() if z.zone_type == ZoneType.RECEIVING)
    _build_docks(spec, warehouse, graph, receiving_zone_id)

    _build_charging_stations(spec, rng, warehouse, graph, storage_zone_ids)

    robots = _build_robots(spec, rng, warehouse, graph)

    sku_catalog, inventory = _build_catalog_and_inventory(spec, rng, warehouse, location_node_map)

    return DigitalTwinBundle(
        warehouse=warehouse, graph=graph, robots=robots,
        sku_catalog=sku_catalog, initial_inventory=inventory, location_node_map=location_node_map,
    )


def _zone_layout(spec: BuildSpec) -> dict[str, tuple[str, ZoneType, tuple[Point2D, Point2D]]]:
    width, depth, gap = 130.0, 90.0, 10.0
    layout = [
        ("ZONE-RECV", "Receiving", ZoneType.RECEIVING),
        ("ZONE-STOR-A", _STORAGE_ZONE_NAMES[0], ZoneType.STORAGE),
        ("ZONE-STOR-B", _STORAGE_ZONE_NAMES[1], ZoneType.STORAGE),
        ("ZONE-STOR-C", _STORAGE_ZONE_NAMES[2], ZoneType.STORAGE),
        ("ZONE-STOR-D", _STORAGE_ZONE_NAMES[3], ZoneType.STORAGE),
        ("ZONE-PICK", "Picking", ZoneType.PICKING),
        ("ZONE-PACK", "Packing", ZoneType.PACKING),
        ("ZONE-SORT", "Sortation", ZoneType.SORTATION),
    ][: spec.num_zones]

    result: dict[str, tuple[str, ZoneType, tuple[Point2D, Point2D]]] = {}
    for i, (zid, name, ztype) in enumerate(layout):
        x0 = i * (width + gap)
        result[zid] = (name, ztype, (Point2D(x0, 0.0), Point2D(x0 + width, depth)))
    return result


def _build_aisles_and_locations(
    spec: BuildSpec, rng: random.Random, warehouse: Warehouse, graph: WarehouseGraph,
    storage_zone_ids: list[str], location_node_map: dict[str, str],
) -> None:
    aisles_per_zone = max(1, spec.num_aisles // len(storage_zone_ids))
    locations_per_aisle = max(1, spec.num_storage_locations // spec.num_aisles)
    locations_per_node = 10

    aisle_counter = 0
    location_counter = 0
    for zone_id in storage_zone_ids:
        zone = warehouse.zones[zone_id]
        (x0, y0), (x1, y1) = zone.bounds
        backbone_id = f"BB-{zone_id}"
        for a in range(aisles_per_zone):
            if aisle_counter >= spec.num_aisles:
                break
            aisle_id = f"AISLE-{aisle_counter:03d}"
            aisle_counter += 1
            ax = x0 + 8 + (a % 10) * ((x1 - x0 - 16) / max(aisles_per_zone, 1))
            entry_id = f"{aisle_id}-IN"
            graph.add_node(Node(entry_id, ax, y0 + 5, NodeKind.STORAGE, zone_id=zone_id))
            graph.add_edge(Edge(backbone_id, entry_id, distance_m=max(abs(ax - graph.nodes[backbone_id].x), 5.0)))

            aisle = Aisle(aisle_id=aisle_id, zone_id=zone_id, graph_node_ids=[entry_id])
            prev_node = entry_id
            n_sub_nodes = max(1, locations_per_aisle // locations_per_node)
            for sub in range(n_sub_nodes):
                sub_id = f"{aisle_id}-N{sub}"
                sub_y = y0 + 10 + sub * ((y1 - y0 - 15) / max(n_sub_nodes, 1))
                graph.add_node(Node(sub_id, ax, sub_y, NodeKind.STORAGE, zone_id=zone_id))
                graph.add_edge(Edge(prev_node, sub_id, distance_m=3.5, max_speed_mps=1.0))
                aisle.graph_node_ids.append(sub_id)
                prev_node = sub_id

                for _ in range(locations_per_node):
                    if location_counter >= spec.num_storage_locations:
                        break
                    loc_id = f"LOC-{location_counter:05d}"
                    location_counter += 1
                    loc = StorageLocation(
                        location_id=loc_id, aisle_id=aisle_id, location_type=LocationType.BIN,
                        position=Point2D(ax, sub_y), capacity_units=rng.choice([20, 40, 60]),
                        max_weight_kg=rng.choice([100, 250, 500]),
                    )
                    aisle.locations[loc_id] = loc
                    location_node_map[loc_id] = sub_id
            zone.aisles[aisle_id] = aisle


def _build_robotic_cells(spec: BuildSpec, warehouse: Warehouse, graph: WarehouseGraph, zone_id: str) -> None:
    zone = warehouse.zones[zone_id]
    (x0, y0), (x1, y1) = zone.bounds
    backbone_id = f"BB-{zone_id}"
    n_cells = max(1, spec.num_robotic_arms // 2)
    for i in range(n_cells):
        cell_id = f"CELL-{i:02d}"
        px, py = x0 + 10 + (i * 8) % (x1 - x0 - 10), y0 + 10
        graph.add_node(Node(cell_id, px, py, NodeKind.ROBOTIC_CELL, zone_id=zone_id))
        graph.add_edge(Edge(backbone_id, cell_id, distance_m=10.0))
        warehouse.robotic_cells[cell_id] = RoboticCell(cell_id=cell_id, zone_id=zone_id, position=Point2D(px, py))


def _build_packing_stations(spec: BuildSpec, warehouse: Warehouse, graph: WarehouseGraph, zone_id: str) -> None:
    zone = warehouse.zones[zone_id]
    (x0, y0), (x1, y1) = zone.bounds
    backbone_id = f"BB-{zone_id}"
    for i in range(spec.num_packing_stations):
        sid = f"PACK-{i:02d}"
        px, py = x0 + 10 + i * 10, y0 + 15
        graph.add_node(Node(sid, px, py, NodeKind.PACKING, zone_id=zone_id))
        graph.add_edge(Edge(backbone_id, sid, distance_m=8.0))
        warehouse.packing_stations[sid] = PackingStation(station_id=sid, zone_id=zone_id, position=Point2D(px, py))


def _build_conveyors(spec: BuildSpec, warehouse: Warehouse, graph: WarehouseGraph, zone_id: str) -> None:
    zone = warehouse.zones[zone_id]
    (x0, y0), (x1, y1) = zone.bounds
    backbone_id = f"BB-{zone_id}"
    for i in range(spec.num_conveyors):
        cid = f"CONV-{i:02d}"
        n1, n2 = f"{cid}-A", f"{cid}-B"
        y = y0 + 5 + (i % 12) * 6
        graph.add_node(Node(n1, x0 + 5, y, NodeKind.INTERSECTION, zone_id=zone_id))
        graph.add_node(Node(n2, x1 - 5, y, NodeKind.INTERSECTION, zone_id=zone_id))
        graph.add_edge(Edge(backbone_id, n1, distance_m=6.0))
        graph.add_edge(Edge(n1, n2, distance_m=x1 - x0 - 10, max_speed_mps=2.5))
        warehouse.conveyors[cid] = Conveyor(conveyor_id=cid, zone_id=zone_id, segment_ids=[n1, n2])


def _build_docks(spec: BuildSpec, warehouse: Warehouse, graph: WarehouseGraph, zone_id: str) -> None:
    zone = warehouse.zones[zone_id]
    (x0, y0), (x1, y1) = zone.bounds
    backbone_id = f"BB-{zone_id}"
    for i in range(spec.num_docks):
        did = f"DOCK-{i:02d}"
        px, py = x0 + 10 + i * 15, y0 + 5
        dock_type = "OUTBOUND" if i == spec.num_docks - 1 else "INBOUND"
        graph.add_node(Node(did, px, py, NodeKind.DOCK, zone_id=zone_id))
        graph.add_edge(Edge(backbone_id, did, distance_m=8.0))
        warehouse.docks[did] = Dock(dock_id=did, zone_id=zone_id, position=Point2D(px, py), dock_type=dock_type)


def _build_charging_stations(
    spec: BuildSpec, rng: random.Random, warehouse: Warehouse, graph: WarehouseGraph, storage_zone_ids: list[str],
) -> None:
    for i in range(spec.num_charging_stations):
        zone_id = storage_zone_ids[i % len(storage_zone_ids)]
        zone = warehouse.zones[zone_id]
        (x0, y0), (x1, y1) = zone.bounds
        backbone_id = f"BB-{zone_id}"
        sid = f"CHG-{i:02d}"
        px, py = x0 + 5, y1 - 5
        graph.add_node(Node(sid, px, py, NodeKind.CHARGING, zone_id=zone_id))
        graph.add_edge(Edge(backbone_id, sid, distance_m=6.0))
        warehouse.charging_stations[sid] = ChargingStation(
            station_id=sid, zone_id=zone_id, position=Point2D(px, py), slots=rng.choice([2, 3, 4]),
        )


def _build_robots(spec: BuildSpec, rng: random.Random, warehouse: Warehouse, graph: WarehouseGraph) -> list[RobotState]:
    robots: list[RobotState] = []
    backbone_ids = [f"BB-{zid}" for zid in warehouse.zones]

    for i in range(spec.num_amrs):
        node_id = rng.choice(backbone_ids)
        node = graph.nodes[node_id]
        robots.append(
            RobotState(
                robot_id=f"AMR-{i:03d}", robot_type=RobotType.AMR, x=node.x, y=node.y,
                current_node=node_id, battery_pct=rng.uniform(55, 100),
                odometer_m=rng.uniform(0, 5000), hours_in_service=rng.uniform(0, 3000),
            )
        )

    cell_ids = list(warehouse.robotic_cells.keys())
    for i in range(spec.num_robotic_arms):
        cell_id = cell_ids[i % len(cell_ids)] if cell_ids else backbone_ids[0]
        node = graph.nodes[cell_id]
        robot = RobotState(
            robot_id=f"ARM-{i:02d}", robot_type=RobotType.ROBOTIC_ARM, x=node.x, y=node.y,
            current_node=cell_id, battery_pct=100.0, hours_in_service=rng.uniform(0, 3000),
        )
        robots.append(robot)
        if cell_id in warehouse.robotic_cells:
            warehouse.robotic_cells[cell_id].robot_ids.append(robot.robot_id)

    return robots


def _build_catalog_and_inventory(
    spec: BuildSpec, rng: random.Random, warehouse: Warehouse, location_node_map: dict[str, str],
) -> tuple[dict[str, SKUCatalogEntry], list[InventoryLot]]:
    catalog: dict[str, SKUCatalogEntry] = {}
    for i in range(spec.num_skus):
        sku = f"SKU-{i:06d}"
        catalog[sku] = SKUCatalogEntry(
            sku=sku, description=f"Item {i}", unit_weight_kg=round(rng.uniform(0.1, 25.0), 2),
            velocity_class=rng.choices(["A", "B", "C"], weights=[0.2, 0.3, 0.5])[0],
            reorder_point=rng.uniform(5, 40), reorder_quantity=rng.uniform(50, 200),
        )

    all_locations = list(warehouse.all_locations().values())
    inventory: list[InventoryLot] = []
    now = datetime.now(UTC)
    skus = list(catalog.keys())
    rng.shuffle(skus)
    # Seed roughly 80% of locations with a lot of a randomly assigned SKU.
    for loc in all_locations:
        if rng.random() > 0.8:
            continue
        sku = rng.choice(skus)
        qty = rng.uniform(loc.capacity_units * 0.3, loc.capacity_units * 0.95)
        loc.occupied_units = qty
        lot = InventoryLot(
            sku=sku, location_id=loc.location_id, quantity=round(qty, 1),
            batch_number=f"BATCH-{rng.randint(1000, 9999)}",
            received_at=now - timedelta(days=rng.randint(0, 90)),
        )
        inventory.append(lot)

    return catalog, inventory
