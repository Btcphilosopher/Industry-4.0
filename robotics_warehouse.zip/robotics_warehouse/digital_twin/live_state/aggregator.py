"""Continuously-updated digital-twin operational state.

Aggregates the live state scattered across the fleet manager, task engine,
order pipeline and warehouse structural model into one coherent snapshot,
consumed by the API/dashboard layer and by analytics. Nothing here owns
state -- it only reads from the systems of record, so there is exactly one
place each piece of state can be mutated.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime

from backend.orchestration.tasks import Task, TaskStatus
from backend.warehouse.models import Warehouse
from robotics.fleet_manager.fleet_manager import FleetManager


@dataclass(slots=True)
class TwinSnapshot:
    generated_at: datetime
    robots: list[dict]
    fleet_summary: dict
    tasks_active: int
    tasks_queued: int
    tasks_blocked: int
    zone_congestion: dict[str, int]
    charging_utilisation: float


class LiveStateAggregator:
    def __init__(self, warehouse: Warehouse, fleet_manager: FleetManager) -> None:
        self.warehouse = warehouse
        self.fleet_manager = fleet_manager

    def snapshot(self, tasks: dict[str, Task]) -> TwinSnapshot:
        fleet = self.fleet_manager
        robots = [r.as_public_dict() for r in fleet.robots.values()]
        fs = fleet.snapshot()

        active = sum(1 for t in tasks.values() if t.status == TaskStatus.EXECUTING)
        queued = sum(1 for t in tasks.values() if t.status in (TaskStatus.QUEUED, TaskStatus.ASSIGNED))
        blocked = sum(1 for t in tasks.values() if t.status == TaskStatus.BLOCKED)

        zone_congestion: dict[str, int] = {zid: 0 for zid in self.warehouse.zones}
        for robot in fleet.robots.values():
            if robot.current_node is None:
                continue
            node = fleet.graph.nodes.get(robot.current_node)
            if node and node.zone_id:
                zone_congestion[node.zone_id] = zone_congestion.get(node.zone_id, 0) + 1

        return TwinSnapshot(
            generated_at=datetime.now(UTC),
            robots=robots,
            fleet_summary={
                "total": fs.total, "by_status": fs.by_status,
                "avg_battery_pct": round(fs.avg_battery_pct, 2),
                "avg_health_score": round(fs.avg_health_score, 3),
            },
            tasks_active=active, tasks_queued=queued, tasks_blocked=blocked,
            zone_congestion=zone_congestion,
            charging_utilisation=round(fleet.charging.utilisation(), 3),
        )
