"""Quantitative comparison of scenario / simulation runs.

Consumes the metrics produced by ``simulation.scenario_engine`` runs and
produces a structured diff so a what-if question ("what happens if 50
robots fail?") has a concrete, numeric answer rather than a narrative one.
"""
from __future__ import annotations

from dataclasses import dataclass

from backend.analytics.engine import WarehouseMetrics


@dataclass(slots=True)
class MetricDelta:
    name: str
    baseline: float
    scenario: float
    delta: float
    delta_pct: float


def compare_runs(baseline: WarehouseMetrics, scenario: WarehouseMetrics) -> list[MetricDelta]:
    fields = [
        "orders_per_hour", "avg_fulfilment_time_s", "robot_utilisation_pct",
        "congestion_index", "avg_battery_pct", "idle_time_pct", "task_completion_rate_pct",
        "energy_per_order_wh", "on_time_fulfilment_pct",
    ]
    deltas: list[MetricDelta] = []
    for f in fields:
        b = getattr(baseline, f)
        s = getattr(scenario, f)
        delta = s - b
        delta_pct = (delta / b * 100.0) if b else 0.0
        deltas.append(MetricDelta(f, b, s, delta, round(delta_pct, 2)))
    return deltas
