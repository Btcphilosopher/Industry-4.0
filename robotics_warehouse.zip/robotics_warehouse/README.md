# Robotics Warehouse Platform

An Industry 4.0 robotics warehouse **management, orchestration, simulation
and optimisation platform** — the software backbone for a highly automated
fulfilment centre running autonomous mobile robots (AMRs), robotic arms,
conveyors, sortation, charging infrastructure, and human operators
side by side.

It combines, in one coherent codebase: a WMS/WCS core, robot fleet
management, a digital twin, real-time telemetry, task allocation, A*/
Dijkstra path planning with collision avoidance, inventory optimisation,
predictive maintenance, discrete-event simulation, an optimisation engine,
energy management, operational analytics, an event bus, and a FastAPI +
WebSocket API — all driving a live simulated warehouse out of the box.

```
ORDERS → INVENTORY → TASK ENGINE → OPTIMISATION → ROBOT FLEET →
WAREHOUSE EXECUTION → TELEMETRY → DIGITAL TWIN → ANALYTICS → OPTIMISATION FEEDBACK
```

## Quickstart

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"

# Run a live simulated warehouse in the terminal (no server needed):
python scripts/run_demo.py headless --duration 3600 --report-every 60

# Or start the full API + WebSocket server (auto-generates the demo
# warehouse and starts ticking it in the background on startup):
python scripts/run_demo.py api
# -> http://localhost:8000/docs   (OpenAPI)
# -> ws://localhost:8000/ws/live  (live digital-twin snapshot, 1 Hz)
# -> ws://localhost:8000/ws/events (live domain-event feed)

# Run the test suite:
pytest -q

# Full local stack (Postgres + Redis + MQTT + API + a standalone
# simulation worker):
docker compose -f deployment/docker-compose.yml up --build
```

Demo API login (see `backend/api/routers/auth.py` for the full list):
`admin`/`admin`, `operator`/`operator`, `fleet_manager`/`fleet_manager`,
`analyst`/`analyst`, `viewer`/`viewer`.

The demo warehouse matches the platform spec's sizing: 1 warehouse, 8
zones, 40 aisles, 2,000 storage locations, 100 AMRs, 10 mobile
manipulator/robotic-arm cells, 12 conveyors, 8 charging stations, 5 packing
stations, 3 docks, 10,000 SKUs — generated deterministically from a seed
(`digital_twin/warehouse_model/builder.py`), so every run is reproducible.

## Architecture

```
robotics_warehouse/
├── backend/            WMS/WCS core: API, auth, orchestration, inventory,
│                        orders, warehouse (digital-twin structural models),
│                        scheduling glue, telemetry ingestion wiring,
│                        maintenance, analytics, energy, events
├── robotics/            fleet_manager, robot_models, navigation (A*/Dijkstra),
│                        task_allocator, charging, collision_avoidance,
│                        robot_interfaces (arm controller + vision, hardware-agnostic)
├── simulation/           warehouse_simulator (main tick loop), robot_simulator
│                        (kinematics/battery), traffic_simulator (disruptions),
│                        order_simulator (Poisson arrivals), scenario_engine (what-if)
├── optimisation/         route_optimisation, slotting, scheduling,
│                        fleet_optimisation, workforce, energy
├── digital_twin/         warehouse_model (facility builder), live_state
│                        (aggregator), visualization (wire-format serializer),
│                        scenario_analysis (quantitative run comparison)
├── ml/                   demand_forecasting, predictive_maintenance,
│                        anomaly_detection, optimisation_models (RL interface
│                        + deterministic fallback -- see "AI safety" below)
├── database/             SQLAlchemy 2.0 async models, session, repositories
├── messaging/            broker abstraction (in-process default; Redis/MQTT
│                        adapters as swap-in implementations)
├── telemetry/            protocol-agnostic reading model + MQTT/OPC UA/
│                        Modbus/simulated adapters + buffered async ingestion
├── configuration/        pydantic-settings + per-environment profiles
├── tests/                94 unit/integration/API/scenario tests
├── scripts/              run_demo.py, seed_demo_data.py
└── deployment/           Dockerfile, docker-compose.yml, env profiles, k8s notes
```

Every module has one job and depends downward only (e.g. `robotics` never
imports from `backend.api`); `backend/orchestration/runtime.py` is the one
composition root that wires everything together, used identically by the
API, the headless script, and the test suite.

## What's real vs. what's a structural placeholder

This is a working, tested platform, not a mock — the simulation loop
genuinely moves robots node-by-node along A*-planned routes, drains and
recharges real battery models, reserves/consumes real inventory lots,
raises and escalates real alerts, and computes real KPIs from that live
state. In an 8-hour simulated run (verified during development) it
processes hundreds of orders, correctly forms and clears congestion,
injects and recovers from robot faults and conveyor blockages, and cycles
robots through charging — without operator intervention.

Being honest about scope: a handful of pieces are intentionally **thin,
well-defined interfaces** rather than full implementations, because they
depend on infrastructure this environment can't provide (real hardware,
real brokers) or genuinely warrant a dedicated model-training effort. Each
is built so swapping in the real thing requires writing one adapter class,
not restructuring the platform:

- **`telemetry/adapters.py`** — `MqttTelemetryAdapter` / `OpcUaTelemetryAdapter`
  / `ModbusTelemetryAdapter` are structurally complete (`connect`/`disconnect`/
  `stream`) but don't speak the wire protocol; `SimulatedRobotTelemetryAdapter`
  is the adapter actually driving telemetry today.
- **`messaging/brokers.py`** — `RedisBroker` / `MqttBroker` mirror the same
  interface as the working `InProcessBroker`, ready for a multi-node deployment.
- **`ml/optimisation_models/rl_interface.py`** — defines the contract a
  trained policy must satisfy; ships a deterministic `HeuristicPolicy` and
  a `safe_recommend` guard that a real RL policy would sit behind (never in
  front of).
- **`robotics/robot_interfaces/arm_controller.py`** — `SimulatedArmController`
  is fully functional (seedable pick success rate, e-stop); a vendor SDK
  adapter (UR/Fanuc/ABB) implements the same four-method interface.
- Robotic-arm cells are modelled as **mobile manipulator units** (arm-on-AMR
  base) rather than bolted-down arms, so the same fleet-manager/allocator/
  navigation pipeline routes them like any other asset — a real, if
  simplified, deployment pattern, and one that keeps a single task-allocation
  code path for every robot class instead of a special case.
- **Alembic migrations** aren't included; `database/session.py` creates the
  schema directly (`Base.metadata.create_all`), which is fine for demo/dev/
  test but a real production rollout would use `alembic` for schema evolution.

## AI safety boundary

Per the platform rule that experimental models must never sit on the
safety-critical path: `robotics/collision_avoidance` and
`robotics/task_allocator`'s deterministic scoring are the only things that
can authorise a robot movement. `ml.optimisation_models.safe_recommend`
is the *only* entry point a learned policy has, and it always falls back to
the deterministic top-scored candidate on low confidence or any error —
an ML suggestion is a recommendation the deterministic layer validates,
never a command it executes directly.

## API surface

FastAPI app (`backend/api/app.py`) exposing `/api/robots`, `/api/tasks`,
`/api/orders`, `/api/inventory/{sku}`, `/api/warehouse`(+`/state`),
`/api/zones`, `/api/conveyors`, `/api/charging`, `/api/telemetry/stats`,
`/api/maintenance`, `/api/analytics` (+`/history`, `/energy`, `/alerts`),
`/api/simulation` (+`/scenarios`, `/scenarios/{name}/run`),
`/api/optimisation` (`/fleet-size`, `/slotting`, `/workforce`),
`/api/events/recent`, and `/api/auth/login`, plus `/ws/live` and
`/ws/events` WebSocket streams — all behind JWT auth + RBAC
(`backend/authentication/auth.py`, 9 roles per spec), a token-bucket rate
limiter, and structured `{"error": {"code", "message"}}` responses.

## Testing

```bash
pytest -q                 # 94 tests: unit, integration, API, scenario
pytest -m slow -q          # includes the larger (200-robot) fleet smoke test
```

Covers navigation (A*/Dijkstra/blocking/replanning), the safety layer
(reservations, right-of-way pre-emption, proximity/human conflicts,
deadlock cycle detection), multi-factor task allocation, FIFO/FEFO/LIFO
inventory, the full order pipeline (including a regression test for
duplicate-SKU order lines), the task lifecycle state machine, the fleet
manager, the optimisation modules, predictive maintenance/ML interfaces,
the event bus (including idempotent delivery), end-to-end deterministic
simulation runs, the FastAPI layer, and the spec's explicit failure/load
scenarios: a large simultaneous fleet, 100 robots contending for one zone,
charging-station failure, network interruption, robot failure mid-task,
conveyor failure, a sudden order surge, and warehouse-zone closure.

## Performance notes

The simulator is pure Python and single-process by design (no hidden
global state, so it's easy to reason about and to later move hot paths to
Rust/C++ without a redesign — see spec section 29). On this development
machine it sustains roughly 100–175x real time with a 110-robot fleet
(≈5–10 ms/tick), and a 200-robot / 300-tick smoke test completes in single-digit
seconds (`tests/test_failure_scenarios.py::test_large_fleet_operates_simultaneously_without_error`).
Scaling toward the spec's 1,000-robot ceiling would want: spatial bucketing
for the currently O(n²) proximity-conflict check (not on the per-tick hot
path today — it's an on-demand safety query), and moving the per-tick robot
loop to numpy-vectorised array operations instead of per-object Python
attribute updates.

## Configuration

`configuration/settings.py` (pydantic-settings, `RW_`-prefixed env vars) with
profiles for `development` / `staging` / `production` / `simulation` in
`configuration/profiles/*.yaml` and matching `deployment/env.*.example` files.
