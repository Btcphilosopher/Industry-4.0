"""Multi-robot route optimisation.

Wraps the navigation engine's A* / Dijkstra search to plan routes for a
batch of robots while accounting for the routes already claimed earlier in
the same batch -- a simple, effective sequential-planning heuristic for
avoiding the worst congestion without needing a full joint multi-agent
solve (which does not scale to a 1,000-robot fleet). Robots are planned in
priority order so critical tasks get first choice of low-congestion paths.
"""
from __future__ import annotations

from dataclasses import dataclass

from robotics.navigation.graph import WarehouseGraph
from robotics.navigation.pathfinding import Route, RouteNotFoundError, a_star, dijkstra


@dataclass(slots=True)
class RoutingRequest:
    robot_id: str
    start: str
    goal: str
    priority: int = 1


@dataclass(slots=True)
class RoutingPlan:
    robot_id: str
    route: Route | None
    algorithm: str


def plan_batch(graph: WarehouseGraph, requests: list[RoutingRequest], *, algorithm: str = "A_STAR") -> list[RoutingPlan]:
    """Plan routes for many robots at once, updating congestion as each is placed
    so later (lower-priority) robots naturally route around busier corridors.
    """
    plans: list[RoutingPlan] = []
    ordered = sorted(requests, key=lambda r: -r.priority)
    for req in ordered:
        try:
            if algorithm == "DIJKSTRA":
                route = dijkstra(graph, req.start, req.goal)
            else:
                boost = 2.0 if req.priority >= 3 else 0.0
                route = a_star(graph, req.start, req.goal, priority_boost=boost)
        except RouteNotFoundError:
            plans.append(RoutingPlan(req.robot_id, None, algorithm))
            continue
        for a, b in zip(route.node_ids, route.node_ids[1:]):
            graph.record_traffic(a, b, +1)
        plans.append(RoutingPlan(req.robot_id, route, algorithm))
    return plans


def compare_algorithms(graph: WarehouseGraph, requests: list[RoutingRequest]) -> dict[str, float]:
    """Compare total planned distance under A* vs Dijkstra without mutating
    live congestion state (used for the what-if scenario engine).
    """
    results: dict[str, float] = {}
    for algo in ("A_STAR", "DIJKSTRA"):
        total = 0.0
        for req in requests:
            try:
                route = a_star(graph, req.start, req.goal) if algo == "A_STAR" else dijkstra(graph, req.start, req.goal)
                total += route.total_distance_m
            except RouteNotFoundError:
                continue
        results[algo] = total
    return results
