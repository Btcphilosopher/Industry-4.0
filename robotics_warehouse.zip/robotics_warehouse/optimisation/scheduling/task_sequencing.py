"""Task sequencing optimisation.

Reorders a batch of freshly-generated tasks so higher priority / tighter
deadline work is offered to the allocator first. This is a fast heuristic
(stable sort) suitable for the hot path; ``compare_strategies`` lets the
optimisation engine benchmark it against alternative orderings rather than
assuming it is always best (spec section 16: "compare optimisation
strategies rather than blindly applying one algorithm").
"""
from __future__ import annotations

from collections.abc import Callable
from datetime import UTC, datetime

from backend.orchestration.tasks import Task


def _priority_deadline_key(task: Task) -> tuple:
    deadline = task.deadline or datetime.max.replace(tzinfo=UTC)
    return (-int(task.priority), deadline, task.created_at)


def _fifo_key(task: Task) -> tuple:
    return (task.created_at,)


def _shortest_estimated_first_key(task: Task) -> tuple:
    return (task.estimated_duration_s or float("inf"), -int(task.priority))


STRATEGIES: dict[str, Callable[[Task], tuple]] = {
    "PRIORITY_DEADLINE": _priority_deadline_key,
    "FIFO": _fifo_key,
    "SHORTEST_FIRST": _shortest_estimated_first_key,
}


def sequence_tasks(tasks: list[Task], strategy: str = "PRIORITY_DEADLINE") -> list[Task]:
    key = STRATEGIES.get(strategy, _priority_deadline_key)
    return sorted(tasks, key=key)


def compare_strategies(tasks: list[Task]) -> dict[str, list[str]]:
    """Return the task_id ordering produced by each available strategy, for
    offline what-if comparison in the scenario engine / analytics dashboard.
    """
    return {name: [t.task_id for t in sequence_tasks(tasks, name)] for name in STRATEGIES}
