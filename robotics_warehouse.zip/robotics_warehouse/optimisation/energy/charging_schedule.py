"""Charging-schedule optimisation.

A greedy bin-packing heuristic that spreads robot charging sessions across
a rolling time horizon to flatten peak electricity demand, subject to each
robot needing to reach its target charge before its next predicted
deployment window. This is the deterministic baseline the energy module
uses; ``ml.optimisation_models`` can propose learned adjustments but they
pass through this optimiser's feasibility checks before being applied.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class ChargeWindow:
    robot_id: str
    slot_index: int
    energy_wh: float


@dataclass(slots=True)
class ChargeScheduleResult:
    windows: list[ChargeWindow]
    peak_demand_w: float
    slot_demand_w: list[float]


def optimise_charging_schedule(
    robot_energy_needs_wh: dict[str, float],
    *,
    num_slots: int,
    slot_seconds: float,
    station_power_w: float,
    max_concurrent: int,
) -> ChargeScheduleResult:
    """Greedily place each robot's charging need into the least-loaded feasible slot."""
    slot_demand = [0.0] * num_slots
    slot_occupancy = [0] * num_slots
    windows: list[ChargeWindow] = []

    # Charge the most energy-hungry robots first so they get first pick of
    # low-demand slots, keeping the overall peak lower.
    for robot_id, energy_wh in sorted(robot_energy_needs_wh.items(), key=lambda kv: -kv[1]):
        slots_needed = max(1, int(-(-energy_wh // (station_power_w * slot_seconds / 3600.0))))
        best_start = min(
            range(max(1, num_slots - slots_needed + 1)),
            key=lambda s: sum(slot_demand[s:s + slots_needed]),
        )
        for i in range(best_start, min(best_start + slots_needed, num_slots)):
            if slot_occupancy[i] < max_concurrent:
                slot_occupancy[i] += 1
                slot_demand[i] += station_power_w
                windows.append(ChargeWindow(robot_id, i, station_power_w * slot_seconds / 3600.0))

    return ChargeScheduleResult(
        windows=windows, peak_demand_w=max(slot_demand, default=0.0), slot_demand_w=slot_demand
    )
