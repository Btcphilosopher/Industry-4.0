"""Fleet-size and allocation optimisation.

Uses a queueing-theory approximation (a variant of Little's Law) to
estimate the robot fleet size required to sustain a target order rate at a
target average task cycle time, then compares that against candidate fleet
sizes to report utilisation/backlog trade-offs. This is intentionally a
transparent analytical model -- the ML layer's fleet-optimisation
interface (``ml.optimisation_models``) can supplement it with learned
corrections, but never replace its bounds.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class FleetSizingResult:
    candidate_fleet_size: int
    required_fleet_size: float
    utilisation: float
    expected_backlog: float


def estimate_required_fleet_size(
    *, tasks_per_hour: float, avg_task_cycle_time_s: float, target_utilisation: float = 0.75
) -> float:
    """Little's Law: L = lambda * W. Concurrent tasks in the system, inflated
    by a target utilisation headroom so the fleet is not run at 100% (which
    would make queueing delay diverge).
    """
    concurrent_tasks = (tasks_per_hour / 3600.0) * avg_task_cycle_time_s
    return concurrent_tasks / max(target_utilisation, 0.01)


def evaluate_fleet_size(
    candidate_fleet_size: int, *, tasks_per_hour: float, avg_task_cycle_time_s: float
) -> FleetSizingResult:
    concurrent_tasks = (tasks_per_hour / 3600.0) * avg_task_cycle_time_s
    utilisation = min(1.0, concurrent_tasks / max(candidate_fleet_size, 1))
    # M/M/c-style backlog approximation: grows sharply as utilisation -> 1.
    backlog = 0.0 if utilisation < 0.99 else concurrent_tasks * 5
    if 0.0 < utilisation < 0.99:
        backlog = concurrent_tasks * (utilisation ** candidate_fleet_size) / (1 - utilisation)
    return FleetSizingResult(
        candidate_fleet_size=candidate_fleet_size,
        required_fleet_size=estimate_required_fleet_size(
            tasks_per_hour=tasks_per_hour, avg_task_cycle_time_s=avg_task_cycle_time_s
        ),
        utilisation=utilisation,
        expected_backlog=backlog,
    )


def compare_fleet_sizes(
    candidates: list[int], *, tasks_per_hour: float, avg_task_cycle_time_s: float
) -> list[FleetSizingResult]:
    return [
        evaluate_fleet_size(c, tasks_per_hour=tasks_per_hour, avg_task_cycle_time_s=avg_task_cycle_time_s)
        for c in candidates
    ]
