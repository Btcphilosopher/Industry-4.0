"""Warehouse slotting optimisation.

Classifies SKUs into ABC velocity classes from observed pick frequency and
recommends relocating fast movers closer to packing/staging to minimise
travel distance -- a standard, well-understood warehousing optimisation
(not a black box), kept separate from the ML layer's *forecasted* demand
signal so deterministic slotting logic never depends on a model being
available.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class SlottingRecommendation:
    sku: str
    current_location: str
    recommended_zone: str
    velocity_class: str
    pick_frequency: int


def classify_abc(pick_counts: dict[str, int]) -> dict[str, str]:
    """Classic Pareto ABC analysis: A = SKUs whose *cumulative* volume share
    (ranked highest-first) falls within the first 80%, B = the next 15%
    (up to 95%), C = the long tail beyond that.

    The cumulative share is measured *before* adding each SKU's own volume,
    so the single highest-volume SKU is always class A even if it alone
    accounts for the majority of total volume -- a real top mover doesn't
    get demoted just because nothing else comes close to it.
    """
    if not pick_counts:
        return {}
    total = sum(pick_counts.values()) or 1
    ranked = sorted(pick_counts.items(), key=lambda kv: kv[1], reverse=True)
    classes: dict[str, str] = {}
    cumulative = 0
    for sku, count in ranked:
        cum_pct = cumulative / total
        if cum_pct <= 0.80:
            classes[sku] = "A"
        elif cum_pct <= 0.95:
            classes[sku] = "B"
        else:
            classes[sku] = "C"
        cumulative += count
    return classes


def recommend_slotting(
    pick_counts: dict[str, int],
    current_locations: dict[str, str],
    *,
    fast_zone: str = "ZONE-FAST",
    slow_zone: str = "ZONE-BULK",
) -> list[SlottingRecommendation]:
    classes = classify_abc(pick_counts)
    recs: list[SlottingRecommendation] = []
    for sku, klass in classes.items():
        target_zone = fast_zone if klass in ("A", "B") else slow_zone
        recs.append(
            SlottingRecommendation(
                sku=sku,
                current_location=current_locations.get(sku, "UNKNOWN"),
                recommended_zone=target_zone,
                velocity_class=klass,
                pick_frequency=pick_counts.get(sku, 0),
            )
        )
    return recs
