"""Workforce allocation heuristic.

Distributes available human operators across zones proportionally to
workload (open task count / queue depth), respecting a minimum staffing
floor per zone that requires a human presence (e.g. packing QA).
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class WorkforcePlan:
    zone_id: str
    assigned_workers: int
    workload_share: float


def allocate_workforce(
    zone_workload: dict[str, float], total_workers: int, *, min_per_zone: int = 0
) -> list[WorkforcePlan]:
    zones = list(zone_workload.keys())
    if not zones or total_workers <= 0:
        return [WorkforcePlan(z, min_per_zone, 0.0) for z in zones]

    total_load = sum(zone_workload.values()) or 1.0
    floor_total = min_per_zone * len(zones)
    remaining = max(0, total_workers - floor_total)

    raw_shares = {z: zone_workload[z] / total_load for z in zones}
    allocated = {z: min_per_zone + int(remaining * raw_shares[z]) for z in zones}

    # Distribute any rounding remainder to the highest-workload zones.
    leftover = total_workers - sum(allocated.values())
    for z in sorted(zones, key=lambda z: zone_workload[z], reverse=True):
        if leftover <= 0:
            break
        allocated[z] += 1
        leftover -= 1

    return [WorkforcePlan(z, allocated[z], raw_shares[z]) for z in zones]
