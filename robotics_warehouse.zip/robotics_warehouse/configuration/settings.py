"""Central configuration management.

Loads environment-specific settings using pydantic-settings. The active
profile is selected via the ``RW_ENV`` environment variable and can be one
of: ``development``, ``staging``, ``production``, ``simulation``.

Nothing in this module holds mutable global state -- callers obtain a
``Settings`` instance via :func:`get_settings`, which is cached with
``functools.lru_cache`` so the process reads the environment once but the
object itself is fully injectable (e.g. tests can construct their own
``Settings(...)`` and pass it around instead of relying on the cache).
"""
from __future__ import annotations

from enum import StrEnum
from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Environment(StrEnum):
    DEVELOPMENT = "development"
    STAGING = "staging"
    PRODUCTION = "production"
    SIMULATION = "simulation"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="RW_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    env: Environment = Environment.DEVELOPMENT
    app_name: str = "robotics-warehouse"
    log_level: str = "INFO"
    log_json: bool = True

    # --- Database (transactional / OLTP) ---
    database_url: str = "sqlite+aiosqlite:///./robotics_warehouse.db"
    database_pool_size: int = 10
    database_echo: bool = False

    # --- Messaging / event infrastructure ---
    redis_url: str = "redis://localhost:6379/0"
    mqtt_broker_host: str = "localhost"
    mqtt_broker_port: int = 1883

    # --- API ---
    api_host: str = "0.0.0.0"
    api_port: int = 8000
    jwt_secret: str = "change-me-in-production"
    jwt_algorithm: str = "HS256"
    jwt_expiry_minutes: int = 60
    rate_limit_per_minute: int = 600
    cors_origins: list[str] = Field(default_factory=lambda: ["*"])

    # --- Telemetry ---
    telemetry_buffer_size: int = 50_000
    telemetry_flush_interval_seconds: float = 1.0
    telemetry_target_events_per_second: int = 10_000

    # --- Simulation ---
    simulation_seed: int = 42
    simulation_tick_seconds: float = 1.0
    simulation_speed_multiplier: float = 1.0

    @property
    def is_production(self) -> bool:
        return self.env is Environment.PRODUCTION


@lru_cache
def get_settings() -> Settings:
    """Return the process-wide settings singleton (cached, but replaceable in tests)."""
    return Settings()
