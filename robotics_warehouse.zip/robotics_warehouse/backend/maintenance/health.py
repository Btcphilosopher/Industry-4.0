"""Predictive maintenance service.

Periodically assesses every robot (and, in a full deployment, every piece
of fixed equipment) using the pluggable model in
``ml.predictive_maintenance``, writes the resulting health score back onto
the robot's live state (consumed by the task allocator's health factor),
and raises ``MaintenanceRequired`` events when priority crosses a
threshold.
"""
from __future__ import annotations

from dataclasses import dataclass

from backend.events.event_bus import EventBus
from backend.events.event_types import MaintenanceRequired
from ml.predictive_maintenance.health_model import (
    AssetSignals,
    HealthAssessment,
    MaintenancePriority,
    PredictiveMaintenanceModel,
    WeightedDegradationModel,
)
from robotics.robot_models.robot import RobotState


@dataclass(slots=True)
class MaintenanceRecord:
    asset_id: str
    assessment: HealthAssessment
    acknowledged: bool = False


class MaintenanceService:
    def __init__(self, event_bus: EventBus, model: PredictiveMaintenanceModel | None = None) -> None:
        self.event_bus = event_bus
        self.model = model or WeightedDegradationModel()
        self.records: dict[str, MaintenanceRecord] = {}

    def assess_robot(self, robot: RobotState, *, vibration_index: float = 0.0, fault_count_30d: int = 0) -> HealthAssessment:
        signals = AssetSignals(
            asset_id=robot.robot_id,
            motor_temp_c=robot.motor_temp_c,
            vibration_index=vibration_index,
            duty_cycle_pct=100.0 if robot.status.value == "EXECUTING_TASK" else 20.0,
            age_hours=robot.hours_in_service,
            fault_count_30d=fault_count_30d,
        )
        assessment = self.model.assess(signals)
        robot.health_score = assessment.health_score
        self.records[robot.robot_id] = MaintenanceRecord(robot.robot_id, assessment)

        if assessment.priority in (MaintenancePriority.HIGH, MaintenancePriority.URGENT):
            self.event_bus.publish_nowait(
                MaintenanceRequired(
                    asset_id=robot.robot_id, asset_type="ROBOT",
                    health_score=assessment.health_score,
                    reason=f"priority={assessment.priority.value}, RUL={assessment.remaining_useful_life_hours}h",
                )
            )
        return assessment

    def assess_fleet(self, robots: dict[str, RobotState]) -> list[HealthAssessment]:
        return [self.assess_robot(r) for r in robots.values()]

    def acknowledge(self, asset_id: str) -> bool:
        record = self.records.get(asset_id)
        if record is None:
            return False
        record.acknowledged = True
        return True

    def outstanding(self) -> list[MaintenanceRecord]:
        return [
            r for r in self.records.values()
            if not r.acknowledged and r.assessment.priority != MaintenancePriority.NONE
        ]
