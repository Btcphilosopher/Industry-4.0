"""Static digital-twin structural models of the physical warehouse.

Every physical object referenced in the spec has a corresponding software
entity here: buildings/warehouse, zones, aisles, storage locations,
conveyors, docks, charging stations, robotic cells, packing/sorting
stations, human work areas, restricted areas, robot lanes and emergency
zones. These are the *static* layout; live occupancy/state is tracked
separately in ``digital_twin.live_state`` so layout data (rarely changing)
is not coupled to high-frequency state (changing every tick).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum


class ZoneType(StrEnum):
    RECEIVING = "RECEIVING"
    STORAGE = "STORAGE"
    PICKING = "PICKING"
    PACKING = "PACKING"
    SORTATION = "SORTATION"
    STAGING = "STAGING"
    CHARGING = "CHARGING"
    ROBOTIC_CELL = "ROBOTIC_CELL"
    HUMAN_WORK_AREA = "HUMAN_WORK_AREA"
    RESTRICTED = "RESTRICTED"
    EMERGENCY = "EMERGENCY"


class LocationType(StrEnum):
    SHELF = "SHELF"
    BIN = "BIN"
    PALLET_POSITION = "PALLET_POSITION"
    FLOOR = "FLOOR"
    ASRS_SLOT = "ASRS_SLOT"


@dataclass(frozen=True, slots=True)
class Point2D:
    x: float
    y: float

    def distance_to(self, other: Point2D) -> float:
        return ((self.x - other.x) ** 2 + (self.y - other.y) ** 2) ** 0.5

    def __iter__(self):
        yield self.x
        yield self.y


@dataclass(slots=True)
class StorageLocation:
    location_id: str
    aisle_id: str
    location_type: LocationType
    position: Point2D
    capacity_units: float
    max_weight_kg: float
    occupied_units: float = 0.0
    restricted: bool = False


@dataclass(slots=True)
class Aisle:
    aisle_id: str
    zone_id: str
    graph_node_ids: list[str] = field(default_factory=list)
    locations: dict[str, StorageLocation] = field(default_factory=dict)
    is_robot_lane: bool = True

    def utilisation(self) -> float:
        total_cap = sum(l.capacity_units for l in self.locations.values())
        total_occ = sum(l.occupied_units for l in self.locations.values())
        return (total_occ / total_cap) if total_cap else 0.0


@dataclass(slots=True)
class Conveyor:
    conveyor_id: str
    zone_id: str
    segment_ids: list[str]
    speed_mps: float = 1.0
    capacity_items: int = 20
    current_items: int = 0
    blocked: bool = False
    energy_watts: float = 750.0


@dataclass(slots=True)
class Dock:
    dock_id: str
    zone_id: str
    position: Point2D
    dock_type: str = "INBOUND"  # INBOUND | OUTBOUND
    occupied: bool = False


@dataclass(slots=True)
class ChargingStation:
    station_id: str
    zone_id: str
    position: Point2D
    charge_rate_w: float = 900.0
    slots: int = 1
    occupied_by: list[str] = field(default_factory=list)

    @property
    def available_slots(self) -> int:
        return max(0, self.slots - len(self.occupied_by))


@dataclass(slots=True)
class PackingStation:
    station_id: str
    zone_id: str
    position: Point2D
    throughput_per_hour: float = 60.0
    current_order_id: str | None = None
    utilisation_pct: float = 0.0


@dataclass(slots=True)
class RoboticCell:
    cell_id: str
    zone_id: str
    position: Point2D
    robot_ids: list[str] = field(default_factory=list)
    supported_task_types: frozenset[str] = frozenset({"PICK", "PACK", "SORT"})


@dataclass(slots=True)
class RestrictedArea:
    area_id: str
    zone_id: str
    polygon: list[Point2D]
    reason: str = "SAFETY"


@dataclass(slots=True)
class Worker:
    worker_id: str
    name: str
    role: str
    zone_id: str | None = None
    position: Point2D | None = None


@dataclass(slots=True)
class Zone:
    zone_id: str
    name: str
    zone_type: ZoneType
    bounds: tuple[Point2D, Point2D]
    aisles: dict[str, Aisle] = field(default_factory=dict)
    congestion_threshold: int = 12

    def contains(self, p: Point2D) -> bool:
        (x0, y0), (x1, y1) = self.bounds[0], self.bounds[1]
        return min(x0, x1) <= p.x <= max(x0, x1) and min(y0, y1) <= p.y <= max(y0, y1)


@dataclass(slots=True)
class Warehouse:
    """Root digital-twin aggregate: the whole facility."""

    warehouse_id: str
    name: str
    floors: int = 1
    zones: dict[str, Zone] = field(default_factory=dict)
    conveyors: dict[str, Conveyor] = field(default_factory=dict)
    docks: dict[str, Dock] = field(default_factory=dict)
    charging_stations: dict[str, ChargingStation] = field(default_factory=dict)
    packing_stations: dict[str, PackingStation] = field(default_factory=dict)
    robotic_cells: dict[str, RoboticCell] = field(default_factory=dict)
    restricted_areas: dict[str, RestrictedArea] = field(default_factory=dict)
    workers: dict[str, Worker] = field(default_factory=dict)

    def all_locations(self) -> dict[str, StorageLocation]:
        locs: dict[str, StorageLocation] = {}
        for zone in self.zones.values():
            for aisle in zone.aisles.values():
                locs.update(aisle.locations)
        return locs

    def zone_for_location(self, location_id: str) -> Zone | None:
        for zone in self.zones.values():
            for aisle in zone.aisles.values():
                if location_id in aisle.locations:
                    return zone
        return None
