"""Energy management: treats energy as a first-class optimisation variable.

Tracks per-robot and facility-wide energy consumption, charging-station
utilisation and peak demand, and exposes the deterministic charging
schedule optimiser (``optimisation.energy.charging_schedule``) so the
platform can flatten peak draw rather than charging every low-battery
robot immediately and simultaneously.
"""
from __future__ import annotations

from dataclasses import dataclass

from backend.warehouse.models import ChargingStation
from optimisation.energy.charging_schedule import ChargeScheduleResult, optimise_charging_schedule
from robotics.robot_models.robot import RobotState, RobotStatus


@dataclass(slots=True)
class EnergySnapshot:
    total_robot_power_w: float
    charging_power_w: float
    peak_demand_w: float
    avg_battery_pct: float
    battery_health_avg: float


class EnergyManager:
    def __init__(self, charging_stations: dict[str, ChargingStation]) -> None:
        self.charging_stations = charging_stations
        self._peak_demand_w = 0.0

    def facility_snapshot(self, robots: dict[str, RobotState]) -> EnergySnapshot:
        robot_power = 0.0
        for r in robots.values():
            caps = r.capabilities()
            robot_power += caps.travel_power_w if r.status == RobotStatus.EXECUTING_TASK else caps.idle_power_w

        charging_power = sum(
            len(s.occupied_by) * s.charge_rate_w for s in self.charging_stations.values()
        )
        total = robot_power + charging_power
        self._peak_demand_w = max(self._peak_demand_w, total)

        n = len(robots) or 1
        avg_battery = sum(r.battery_pct for r in robots.values()) / n
        avg_health = sum(r.health_score for r in robots.values()) / n

        return EnergySnapshot(
            total_robot_power_w=robot_power, charging_power_w=charging_power,
            peak_demand_w=self._peak_demand_w, avg_battery_pct=avg_battery, battery_health_avg=avg_health,
        )

    def plan_charging_schedule(
        self, robot_energy_needs_wh: dict[str, float], *, num_slots: int = 24, slot_seconds: float = 3600,
    ) -> ChargeScheduleResult:
        total_slots_power = sum(s.charge_rate_w for s in self.charging_stations.values())
        max_concurrent = sum(s.slots for s in self.charging_stations.values())
        avg_station_power = total_slots_power / max(len(self.charging_stations), 1)
        return optimise_charging_schedule(
            robot_energy_needs_wh, num_slots=num_slots, slot_seconds=slot_seconds,
            station_power_w=avg_station_power, max_concurrent=max_concurrent,
        )
