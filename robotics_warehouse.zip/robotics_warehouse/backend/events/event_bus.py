"""In-process asynchronous event bus.

This is the default ``messaging`` transport used inside a single process
(demo / simulation / single-node deployment). For a multi-node deployment,
``messaging.brokers`` provides adapters (Redis pub/sub, MQTT) that satisfy
the same :class:`EventPublisher` protocol, so the rest of the platform never
depends on the transport directly -- only on ``publish`` / ``subscribe``.

Design notes:
    * Handlers are invoked concurrently via ``asyncio.gather`` so a slow
      subscriber cannot block event delivery to others.
    * A bounded ring buffer of recently-seen ``event_id`` values gives
      idempotent delivery semantics if the same event is republished (e.g.
      after a broker redelivery).
    * All dispatch failures are caught and logged rather than propagated,
      so one broken handler cannot take down the bus.
"""
from __future__ import annotations

import asyncio
import logging
from collections import defaultdict, deque
from collections.abc import Awaitable, Callable
from typing import TypeVar

from backend.events.event_types import DomainEvent

logger = logging.getLogger("robotics_warehouse.events")

EventT = TypeVar("EventT", bound=DomainEvent)
Handler = Callable[[DomainEvent], Awaitable[None] | None]


class EventBus:
    """A lightweight, typed, async pub/sub bus with idempotent delivery."""

    def __init__(self, *, dedupe_window: int = 10_000) -> None:
        self._handlers: dict[type[DomainEvent], list[Handler]] = defaultdict(list)
        self._wildcard_handlers: list[Handler] = []
        self._recent_ids: deque[str] = deque(maxlen=dedupe_window)
        self._seen: set[str] = set()
        self._history: deque[DomainEvent] = deque(maxlen=5_000)
        self._published_count = 0

    def subscribe(self, event_type: type[EventT], handler: Handler) -> None:
        """Register ``handler`` for a specific event type."""
        self._handlers[event_type].append(handler)

    def subscribe_all(self, handler: Handler) -> None:
        """Register ``handler`` to receive every event published on the bus."""
        self._wildcard_handlers.append(handler)

    def unsubscribe_all(self, handler: Handler) -> None:
        """Remove a handler previously registered via :meth:`subscribe_all`."""
        if handler in self._wildcard_handlers:
            self._wildcard_handlers.remove(handler)

    async def publish(self, event: DomainEvent) -> None:
        """Publish ``event`` to all matching subscribers, deduplicating by id."""
        if event.event_id in self._seen:
            logger.debug("duplicate event suppressed", extra={"event_id": event.event_id})
            return
        self._seen.add(event.event_id)
        self._recent_ids.append(event.event_id)
        if len(self._recent_ids) == self._recent_ids.maxlen:
            # keep the "seen" set bounded to the same window as the deque
            self._seen = set(self._recent_ids)

        self._history.append(event)
        self._published_count += 1

        handlers = list(self._handlers.get(type(event), ())) + list(self._wildcard_handlers)
        if not handlers:
            return

        async def _run(h: Handler) -> None:
            try:
                result = h(event)
                if asyncio.iscoroutine(result):
                    await result
            except Exception:
                logger.exception("event handler failed", extra={"event_type": event.event_type})

        await asyncio.gather(*(_run(h) for h in handlers))

    def publish_nowait(self, event: DomainEvent) -> None:
        """Schedule ``publish`` without the caller having to await it.

        Most callers here are synchronous domain code (the fleet manager,
        the simulator's per-tick loop) that may or may not be running
        inside an asyncio event loop -- the simulator is explicitly
        designed to also run headless from a plain script or a sync test.
        When a loop is running, publication is scheduled on it as a
        background task (non-blocking, matches the API/background-task
        deployment). When no loop is running, publish synchronously via a
        short-lived loop instead of raising -- event delivery must never
        depend on incidental caller context.
        """
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            asyncio.run(self.publish(event))
            return
        loop.create_task(self.publish(event))

    def recent(self, limit: int = 100) -> list[DomainEvent]:
        return list(self._history)[-limit:]

    @property
    def published_count(self) -> int:
        return self._published_count
