"""Immutable, timestamped domain events for the warehouse event bus.

Every event is a frozen dataclass so it cannot be mutated after publication
(handlers that need to "modify" state should publish a new event instead).
All events carry a UTC timestamp and a unique ``event_id`` for idempotent
downstream consumption (see ``backend.events.event_bus.EventBus``).
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any


def _now() -> datetime:
    return datetime.now(UTC)


def _new_id() -> str:
    return uuid.uuid4().hex


@dataclass(frozen=True, slots=True, kw_only=True)
class DomainEvent:
    """Base class for all domain events."""

    event_id: str = field(default_factory=_new_id)
    occurred_at: datetime = field(default_factory=_now)

    @property
    def event_type(self) -> str:
        return type(self).__name__

    def as_dict(self) -> dict[str, Any]:
        data = {
            k: getattr(self, k)
            for k in self.__dataclass_fields__  # type: ignore[attr-defined]
        }
        data["event_type"] = self.event_type
        data["occurred_at"] = self.occurred_at.isoformat()
        return data


# --- Robot lifecycle -------------------------------------------------------

@dataclass(frozen=True, slots=True, kw_only=True)
class RobotRegistered(DomainEvent):
    robot_id: str
    robot_type: str


@dataclass(frozen=True, slots=True, kw_only=True)
class RobotArrived(DomainEvent):
    robot_id: str
    node_id: str


@dataclass(frozen=True, slots=True, kw_only=True)
class RobotFaultDetected(DomainEvent):
    robot_id: str
    fault_code: str
    detail: str = ""


@dataclass(frozen=True, slots=True, kw_only=True)
class BatteryLow(DomainEvent):
    robot_id: str
    battery_pct: float


@dataclass(frozen=True, slots=True, kw_only=True)
class RobotEnteredCharging(DomainEvent):
    robot_id: str
    station_id: str


@dataclass(frozen=True, slots=True, kw_only=True)
class RobotDisconnected(DomainEvent):
    robot_id: str


# --- Task lifecycle ----------------------------------------------------

@dataclass(frozen=True, slots=True, kw_only=True)
class TaskCreated(DomainEvent):
    task_id: str
    task_type: str
    priority: int


@dataclass(frozen=True, slots=True, kw_only=True)
class TaskAssigned(DomainEvent):
    task_id: str
    robot_id: str


@dataclass(frozen=True, slots=True, kw_only=True)
class TaskCompleted(DomainEvent):
    task_id: str
    robot_id: str
    duration_seconds: float


@dataclass(frozen=True, slots=True, kw_only=True)
class TaskFailed(DomainEvent):
    task_id: str
    robot_id: str | None
    reason: str


@dataclass(frozen=True, slots=True, kw_only=True)
class TaskBlocked(DomainEvent):
    task_id: str
    reason: str


# --- Inventory / orders --------------------------------------------------

@dataclass(frozen=True, slots=True, kw_only=True)
class InventoryMoved(DomainEvent):
    sku: str
    quantity: float
    from_location: str
    to_location: str


@dataclass(frozen=True, slots=True, kw_only=True)
class OrderReceived(DomainEvent):
    order_id: str
    line_count: int
    priority: int


@dataclass(frozen=True, slots=True, kw_only=True)
class OrderCompleted(DomainEvent):
    order_id: str
    duration_seconds: float


# --- Warehouse / equipment -------------------------------------------------

@dataclass(frozen=True, slots=True, kw_only=True)
class ConveyorBlocked(DomainEvent):
    conveyor_id: str
    reason: str


@dataclass(frozen=True, slots=True, kw_only=True)
class HumanDetected(DomainEvent):
    zone_id: str
    position: tuple[float, float]


@dataclass(frozen=True, slots=True, kw_only=True)
class EmergencyStop(DomainEvent):
    scope: str
    reason: str
    triggered_by: str


@dataclass(frozen=True, slots=True, kw_only=True)
class MaintenanceRequired(DomainEvent):
    asset_id: str
    asset_type: str
    health_score: float
    reason: str


@dataclass(frozen=True, slots=True, kw_only=True)
class AlertRaised(DomainEvent):
    alert_id: str
    severity: str
    source: str
    message: str
