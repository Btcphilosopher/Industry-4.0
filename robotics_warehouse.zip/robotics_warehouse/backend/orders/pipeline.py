"""Order fulfilment pipeline.

    ORDER RECEIVED -> VALIDATE -> RESERVE INVENTORY -> GENERATE TASKS ->
    OPTIMISE TASK SEQUENCE -> ALLOCATE ROBOTS -> PICK -> SORT -> PACK -> DISPATCH

This module owns the RECEIVED..TASKS_GENERATED transition; PICK/SORT/PACK/
DISPATCH state transitions happen as the generated tasks complete (driven
by the simulator / fleet manager reporting task completion back in).
"""
from __future__ import annotations

import logging
from datetime import UTC, datetime, timedelta

from backend.events.event_bus import EventBus
from backend.events.event_types import OrderCompleted, OrderReceived
from backend.inventory.models import InsufficientInventoryError
from backend.inventory.service import InventoryService
from backend.orchestration.tasks import Task, TaskPriority, TaskStatus, TaskType
from backend.orders.models import Order, OrderStatus
from optimisation.scheduling.task_sequencing import sequence_tasks

logger = logging.getLogger("robotics_warehouse.orders")

# SLA window each generated task's deadline is set against, by order
# priority -- feeds the on-time-fulfilment analytics metric and the task
# lifecycle's existing `is_overdue()` check.
_SLA_WINDOW: dict[TaskPriority, timedelta] = {
    TaskPriority.CRITICAL: timedelta(minutes=5),
    TaskPriority.HIGH: timedelta(minutes=15),
    TaskPriority.NORMAL: timedelta(minutes=60),
    TaskPriority.LOW: timedelta(minutes=180),
}


class OrderValidationError(RuntimeError):
    pass


class OrderPipeline:
    def __init__(
        self,
        inventory: InventoryService,
        event_bus: EventBus,
        *,
        packing_station_ids: list[str],
        location_node_map: dict[str, str] | None = None,
    ) -> None:
        self.inventory = inventory
        self.event_bus = event_bus
        self.packing_station_ids = packing_station_ids
        # Maps a StorageLocation.location_id (a physical bin) to the
        # navigation graph node a robot actually routes to in order to reach
        # it -- one graph node typically serves many nearby bins.
        self.location_node_map = location_node_map or {}
        self._next_station_idx = 0
        self.orders: dict[str, Order] = {}
        self.tasks: dict[str, Task] = {}

    def submit(self, order: Order) -> list[Task]:
        """Run RECEIVED -> TASKS_GENERATED, returning the (sequenced) tasks."""
        self.orders[order.order_id] = order
        self.event_bus.publish_nowait(
            OrderReceived(order_id=order.order_id, line_count=order.total_lines(), priority=int(order.priority))
        )
        self._validate(order)
        self._reserve_inventory(order)
        tasks = self._generate_tasks(order)
        tasks = sequence_tasks(tasks)
        order.status = OrderStatus.TASKS_GENERATED
        for t in tasks:
            self.tasks[t.task_id] = t
            t.transition(TaskStatus.QUEUED)
        order.task_ids = [t.task_id for t in tasks]
        return tasks

    def _validate(self, order: Order) -> None:
        if not order.lines:
            raise OrderValidationError(f"order {order.order_id} has no lines")
        for line in order.lines:
            if line.quantity <= 0:
                raise OrderValidationError(f"order {order.order_id} line {line.line_id} has non-positive qty")
        order.status = OrderStatus.VALIDATED

    def _reserve_inventory(self, order: Order) -> None:
        try:
            for line in order.lines:
                line.reserved_lots = self.inventory.reserve(line.sku, line.quantity)
        except InsufficientInventoryError:
            order.status = OrderStatus.FAILED
            raise
        order.status = OrderStatus.INVENTORY_RESERVED

    def _next_packing_station(self) -> str:
        station = self.packing_station_ids[self._next_station_idx % len(self.packing_station_ids)]
        self._next_station_idx += 1
        return station

    def _generate_tasks(self, order: Order) -> list[Task]:
        tasks: list[Task] = []
        packing_station = self._next_packing_station()
        deadline = datetime.now(UTC) + _SLA_WINDOW[order.priority]
        for line in order.lines:
            for lot_id, qty in line.reserved_lots:
                lot = next((l for l in self.inventory.lots_for_sku(line.sku) if l.lot_id == lot_id), None)
                location_id = lot.location_id if lot else "UNKNOWN"
                source = self.location_node_map.get(location_id, location_id)
                pick_task = Task(
                    task_type=TaskType.PICK,
                    priority=order.priority,
                    source=source,
                    destination=packing_station,
                    payload_kg=qty,
                    sku=line.sku,
                    quantity=qty,
                    lot_id=lot_id,
                    line_id=line.line_id,
                    order_id=order.order_id,
                    deadline=deadline,
                )
                tasks.append(pick_task)
        pack_task = Task(
            task_type=TaskType.PACK,
            priority=order.priority,
            source=packing_station,
            destination=packing_station,
            order_id=order.order_id,
            deadline=deadline,
        )
        tasks.append(pack_task)
        return tasks

    def on_task_completed(self, task: Task) -> None:
        order = self.orders.get(task.order_id) if task.order_id else None
        if order is None:
            return
        if task.task_type == TaskType.PICK and task.lot_id:
            self.inventory.consume(task.lot_id, task.quantity, to_location=task.destination or "STAGING")
            line = next((l for l in order.lines if l.line_id == task.line_id), None)
            if line is not None:
                line.picked_quantity += task.quantity
            order.status = OrderStatus.PICKING
        elif task.task_type == TaskType.PACK:
            order.status = OrderStatus.PACKING

        all_terminal = all(
            self.tasks[tid].status in (TaskStatus.COMPLETED,) for tid in order.task_ids if tid in self.tasks
        )
        if all_terminal and order.status != OrderStatus.DISPATCHED:
            order.status = OrderStatus.DISPATCHED
            from datetime import datetime
            order.dispatched_at = datetime.now(UTC)
            duration = (order.dispatched_at - order.created_at).total_seconds()
            self.event_bus.publish_nowait(
                OrderCompleted(order_id=order.order_id, duration_seconds=duration)
            )
