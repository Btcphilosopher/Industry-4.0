"""Order domain models."""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import StrEnum

from backend.orchestration.tasks import TaskPriority


class OrderStatus(StrEnum):
    RECEIVED = "RECEIVED"
    VALIDATED = "VALIDATED"
    INVENTORY_RESERVED = "INVENTORY_RESERVED"
    TASKS_GENERATED = "TASKS_GENERATED"
    PICKING = "PICKING"
    SORTING = "SORTING"
    PACKING = "PACKING"
    DISPATCHED = "DISPATCHED"
    CANCELLED = "CANCELLED"
    FAILED = "FAILED"


@dataclass(slots=True)
class OrderLine:
    sku: str
    quantity: float
    line_id: str = field(default_factory=lambda: f"LINE-{uuid.uuid4().hex[:8]}")
    reserved_lots: list[tuple[str, float]] = field(default_factory=list)
    picked_quantity: float = 0.0


@dataclass(slots=True)
class Order:
    lines: list[OrderLine]
    priority: TaskPriority = TaskPriority.NORMAL
    order_id: str = field(default_factory=lambda: f"ORD-{uuid.uuid4().hex[:10]}")
    status: OrderStatus = OrderStatus.RECEIVED
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    dispatched_at: datetime | None = None
    task_ids: list[str] = field(default_factory=list)
    customer_ref: str | None = None

    def total_lines(self) -> int:
        return len(self.lines)

    def is_fully_picked(self) -> bool:
        return all(l.picked_quantity >= l.quantity - 1e-9 for l in self.lines)
