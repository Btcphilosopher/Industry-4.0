"""Industrial-grade inventory domain models."""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import date, datetime
from enum import StrEnum


class InventoryCondition(StrEnum):
    GOOD = "GOOD"
    DAMAGED = "DAMAGED"
    QUARANTINE = "QUARANTINE"
    EXPIRED = "EXPIRED"


@dataclass(slots=True)
class InventoryLot:
    """A physical lot of a SKU sitting at a specific location.

    Distinct lots of the same SKU allow FIFO/FEFO/LIFO strategies to
    differentiate by ``received_at`` / ``expiry_date`` even when they share
    a bin.
    """

    sku: str
    location_id: str
    quantity: float
    batch_number: str
    received_at: datetime
    condition: InventoryCondition = InventoryCondition.GOOD
    expiry_date: date | None = None
    serial_numbers: list[str] = field(default_factory=list)
    owner: str = "DEFAULT"
    reserved_quantity: float = 0.0
    lot_id: str = field(default_factory=lambda: f"LOT-{uuid.uuid4().hex[:10]}")

    @property
    def available_quantity(self) -> float:
        return max(0.0, self.quantity - self.reserved_quantity)


@dataclass(slots=True)
class SKUCatalogEntry:
    sku: str
    description: str
    unit_weight_kg: float
    velocity_class: str = "C"  # ABC classification, set by slotting optimiser
    reorder_point: float = 0.0
    reorder_quantity: float = 0.0
    is_hazardous: bool = False


class InsufficientInventoryError(RuntimeError):
    pass
