"""Inventory service: allocation strategies, reservations, cycle counting."""
from __future__ import annotations

from datetime import date
from enum import StrEnum

from backend.events.event_bus import EventBus
from backend.events.event_types import InventoryMoved
from backend.inventory.models import InsufficientInventoryError, InventoryCondition, InventoryLot


class AllocationStrategy(StrEnum):
    FIFO = "FIFO"  # first in, first out (received_at ascending)
    FEFO = "FEFO"  # first expired, first out (expiry_date ascending, nulls last)
    LIFO = "LIFO"  # last in, first out (received_at descending)


class InventoryService:
    """In-memory inventory ledger with reservation, replenishment and cycle counting.

    Backed by ``database.repositories.InventoryRepository`` for durability;
    kept here as a pure, fast, dependency-free domain service so it can be
    unit tested and used inside the simulation loop without a database.
    """

    def __init__(self, event_bus: EventBus, *, default_strategy: AllocationStrategy = AllocationStrategy.FEFO) -> None:
        self.event_bus = event_bus
        self.default_strategy = default_strategy
        self._lots: dict[str, InventoryLot] = {}
        self._by_sku: dict[str, list[str]] = {}

    def receive(self, lot: InventoryLot) -> None:
        self._lots[lot.lot_id] = lot
        self._by_sku.setdefault(lot.sku, []).append(lot.lot_id)

    def on_hand(self, sku: str) -> float:
        return sum(self._lots[lid].quantity for lid in self._by_sku.get(sku, []))

    def available(self, sku: str) -> float:
        return sum(self._lots[lid].available_quantity for lid in self._by_sku.get(sku, []))

    def _sorted_lots(self, sku: str, strategy: AllocationStrategy) -> list[InventoryLot]:
        lots = [
            self._lots[lid] for lid in self._by_sku.get(sku, [])
            if self._lots[lid].condition == InventoryCondition.GOOD and self._lots[lid].available_quantity > 0
        ]
        if strategy == AllocationStrategy.FIFO:
            return sorted(lots, key=lambda l: l.received_at)
        if strategy == AllocationStrategy.LIFO:
            return sorted(lots, key=lambda l: l.received_at, reverse=True)
        # FEFO: soonest expiry first, lots without an expiry sort last
        return sorted(lots, key=lambda l: (l.expiry_date is None, l.expiry_date or date.max))

    def reserve(
        self, sku: str, quantity: float, *, strategy: AllocationStrategy | None = None
    ) -> list[tuple[str, float]]:
        """Reserve ``quantity`` units of ``sku`` across one or more lots.

        Returns a list of (lot_id, quantity_reserved). Raises
        :class:`InsufficientInventoryError` if not enough stock is
        available -- no partial reservation is left behind on failure.
        """
        strategy = strategy or self.default_strategy
        candidates = self._sorted_lots(sku, strategy)
        remaining = quantity
        plan: list[tuple[str, float]] = []
        for lot in candidates:
            if remaining <= 0:
                break
            take = min(lot.available_quantity, remaining)
            if take > 0:
                plan.append((lot.lot_id, take))
                remaining -= take
        if remaining > 1e-9:
            raise InsufficientInventoryError(
                f"cannot reserve {quantity} of {sku}: only {quantity - remaining} available"
            )
        for lot_id, qty in plan:
            self._lots[lot_id].reserved_quantity += qty
        return plan

    def release_reservation(self, lot_id: str, quantity: float) -> None:
        lot = self._lots.get(lot_id)
        if lot:
            lot.reserved_quantity = max(0.0, lot.reserved_quantity - quantity)

    def consume(self, lot_id: str, quantity: float, *, to_location: str) -> None:
        lot = self._lots.get(lot_id)
        if lot is None:
            raise InsufficientInventoryError(f"unknown lot {lot_id}")
        if quantity > lot.quantity + 1e-9:
            raise InsufficientInventoryError(f"lot {lot_id} has only {lot.quantity}, requested {quantity}")
        lot.quantity -= quantity
        lot.reserved_quantity = max(0.0, lot.reserved_quantity - quantity)
        self.event_bus.publish_nowait(
            InventoryMoved(sku=lot.sku, quantity=quantity, from_location=lot.location_id, to_location=to_location)
        )
        if lot.quantity <= 1e-9:
            self._by_sku[lot.sku].remove(lot_id)
            del self._lots[lot_id]

    def mark_condition(self, lot_id: str, condition: InventoryCondition) -> None:
        lot = self._lots.get(lot_id)
        if lot:
            lot.condition = condition

    def cycle_count(self, sku: str, counted_quantity: float) -> float:
        """Reconcile system on-hand against a physical count. Returns the variance."""
        system_qty = self.on_hand(sku)
        variance = counted_quantity - system_qty
        if abs(variance) > 1e-9 and self._by_sku.get(sku):
            # Adjust the most recently received lot to reconcile the discrepancy.
            adjust_lot = self._lots[self._by_sku[sku][-1]]
            adjust_lot.quantity = max(0.0, adjust_lot.quantity + variance)
        return variance

    def needs_replenishment(self, sku: str, reorder_point: float) -> bool:
        return self.available(sku) <= reorder_point

    def lots_for_sku(self, sku: str) -> list[InventoryLot]:
        return [self._lots[lid] for lid in self._by_sku.get(sku, [])]
