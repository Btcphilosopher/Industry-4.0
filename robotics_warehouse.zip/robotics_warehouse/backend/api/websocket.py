"""WebSocket endpoint for real-time operational telemetry (spec section 22).

Streams the dynamic digital-twin snapshot (robot positions, fleet summary,
task counts, congestion) to the command-centre dashboard at a fixed
cadence. One broadcast loop serves all connected clients rather than
recomputing the snapshot per-connection.
"""
from __future__ import annotations

import asyncio
import contextlib
import logging

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from backend.orchestration.runtime import WarehouseRuntime
from digital_twin.visualization.serializer import serialize_dynamic_state

logger = logging.getLogger("robotics_warehouse.websocket")
router = APIRouter()


@router.websocket("/ws/live")
async def live_state_ws(websocket: WebSocket) -> None:
    await websocket.accept()
    runtime: WarehouseRuntime = websocket.app.state.runtime
    try:
        while True:
            snapshot = runtime.snapshot()
            await websocket.send_json(serialize_dynamic_state(snapshot))
            await asyncio.sleep(1.0)
    except WebSocketDisconnect:
        logger.debug("dashboard client disconnected")
    except Exception:
        logger.exception("live_state_ws error")
        with contextlib.suppress(Exception):
            await websocket.close()


@router.websocket("/ws/events")
async def events_ws(websocket: WebSocket) -> None:
    """Streams domain events as they are published, for an operator activity feed."""
    await websocket.accept()
    runtime: WarehouseRuntime = websocket.app.state.runtime
    queue: asyncio.Queue = asyncio.Queue(maxsize=1000)

    async def _handler(event) -> None:
        if not queue.full():
            await queue.put(event.as_dict())

    runtime.event_bus.subscribe_all(_handler)
    try:
        while True:
            payload = await queue.get()
            await websocket.send_json(payload)
    except WebSocketDisconnect:
        logger.debug("events client disconnected")
    finally:
        runtime.event_bus.unsubscribe_all(_handler)
