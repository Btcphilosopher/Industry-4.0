"""Shared FastAPI dependencies."""
from __future__ import annotations

from fastapi import Request

from backend.orchestration.runtime import WarehouseRuntime


def get_runtime(request: Request) -> WarehouseRuntime:
    return request.app.state.runtime
