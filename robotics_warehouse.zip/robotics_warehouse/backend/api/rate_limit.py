"""A minimal in-process token-bucket rate limiter middleware.

Sufficient for a single-node deployment / demo; a multi-node production
deployment should back this with Redis (see ``messaging.brokers.RedisBroker``
for the same swap-in pattern used elsewhere in the platform).
"""
from __future__ import annotations

import time
from collections import defaultdict

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse


class _Bucket:
    __slots__ = ("last_refill", "tokens")

    def __init__(self, capacity: float) -> None:
        self.tokens = capacity
        self.last_refill = time.monotonic()


class RateLimitMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, *, requests_per_minute: int = 600) -> None:
        super().__init__(app)
        self.capacity = float(requests_per_minute)
        self.refill_rate = requests_per_minute / 60.0
        self._buckets: dict[str, _Bucket] = defaultdict(lambda: _Bucket(self.capacity))

    async def dispatch(self, request: Request, call_next):
        client_key = request.client.host if request.client else "unknown"
        bucket = self._buckets[client_key]
        now = time.monotonic()
        elapsed = now - bucket.last_refill
        bucket.tokens = min(self.capacity, bucket.tokens + elapsed * self.refill_rate)
        bucket.last_refill = now

        if bucket.tokens < 1.0:
            return JSONResponse(
                status_code=429,
                content={"error": {"code": "RATE_LIMITED", "message": "too many requests"}},
            )
        bucket.tokens -= 1.0
        return await call_next(request)
