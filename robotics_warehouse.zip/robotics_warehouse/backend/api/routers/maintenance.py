from __future__ import annotations

from fastapi import APIRouter, Depends

from backend.api.deps import get_runtime
from backend.authentication.auth import AuthenticatedUser, Role, audit_log, require_any_role
from backend.orchestration.runtime import WarehouseRuntime

router = APIRouter(prefix="/api/maintenance", tags=["maintenance"])


@router.get("")
async def list_maintenance_records(runtime: WarehouseRuntime = Depends(get_runtime)) -> list[dict]:
    return [
        {
            "asset_id": r.asset_id, "health_score": r.assessment.health_score,
            "failure_probability": r.assessment.failure_probability,
            "remaining_useful_life_hours": r.assessment.remaining_useful_life_hours,
            "priority": r.assessment.priority.value, "acknowledged": r.acknowledged,
        }
        for r in runtime.maintenance_service.records.values()
    ]


@router.post("/{asset_id}/acknowledge")
async def acknowledge_maintenance(
    asset_id: str, runtime: WarehouseRuntime = Depends(get_runtime),
    user: AuthenticatedUser = Depends(require_any_role(Role.MAINTENANCE, Role.ENGINEER)),
) -> dict:
    ok = runtime.maintenance_service.acknowledge(asset_id)
    audit_log(user, "ACKNOWLEDGE_MAINTENANCE", detail=asset_id)
    return {"asset_id": asset_id, "acknowledged": ok}
