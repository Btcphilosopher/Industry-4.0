from __future__ import annotations

from fastapi import APIRouter, Depends

from backend.api.deps import get_runtime
from backend.orchestration.runtime import WarehouseRuntime

router = APIRouter(prefix="/api/inventory", tags=["inventory"])


@router.get("/{sku}")
async def get_inventory(sku: str, runtime: WarehouseRuntime = Depends(get_runtime)) -> dict:
    inv = runtime.simulator.inventory
    lots = inv.lots_for_sku(sku)
    return {
        "sku": sku, "on_hand": inv.on_hand(sku), "available": inv.available(sku),
        "lots": [
            {
                "lot_id": l.lot_id, "location_id": l.location_id, "quantity": l.quantity,
                "reserved_quantity": l.reserved_quantity, "condition": l.condition.value,
                "received_at": l.received_at.isoformat(),
            }
            for l in lots
        ],
    }
