from __future__ import annotations

from fastapi import APIRouter, Depends

from backend.api.deps import get_runtime
from backend.orchestration.runtime import WarehouseRuntime

router = APIRouter(prefix="/api/events", tags=["events"])


@router.get("/recent")
async def recent_events(limit: int = 100, runtime: WarehouseRuntime = Depends(get_runtime)) -> list[dict]:
    events = runtime.event_bus.recent(limit)
    return [e.as_dict() for e in events]
