from __future__ import annotations

from fastapi import APIRouter, Depends

from backend.api.deps import get_runtime
from backend.orchestration.runtime import WarehouseRuntime

router = APIRouter(prefix="/api/charging", tags=["charging"])


@router.get("")
async def list_charging_stations(runtime: WarehouseRuntime = Depends(get_runtime)) -> list[dict]:
    return [
        {
            "station_id": s.station_id, "zone_id": s.zone_id, "slots": s.slots,
            "occupied_by": list(s.occupied_by), "available_slots": s.available_slots,
            "charge_rate_w": s.charge_rate_w,
        }
        for s in runtime.bundle.warehouse.charging_stations.values()
    ]


@router.get("/utilisation")
async def charging_utilisation(runtime: WarehouseRuntime = Depends(get_runtime)) -> dict:
    return {"utilisation": runtime.simulator.fleet_manager.charging.utilisation()}
