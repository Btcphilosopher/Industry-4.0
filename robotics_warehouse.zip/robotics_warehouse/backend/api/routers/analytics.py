from __future__ import annotations

from dataclasses import asdict

from fastapi import APIRouter, Depends

from backend.api.deps import get_runtime
from backend.orchestration.runtime import WarehouseRuntime

router = APIRouter(prefix="/api/analytics", tags=["analytics"])


@router.get("")
async def current_metrics(runtime: WarehouseRuntime = Depends(get_runtime)) -> dict:
    metrics = runtime.latest_metrics or runtime.analytics_engine.compute()
    return asdict(metrics)


@router.get("/history")
async def metrics_history(runtime: WarehouseRuntime = Depends(get_runtime)) -> list[dict]:
    return [asdict(m) for m in runtime.analytics_engine.history()[-500:]]


@router.get("/energy")
async def energy_metrics(runtime: WarehouseRuntime = Depends(get_runtime)) -> dict:
    return asdict(runtime.energy_snapshot())


@router.get("/alerts")
async def active_alerts(runtime: WarehouseRuntime = Depends(get_runtime)) -> list[dict]:
    return [
        {
            "alert_id": a.alert_id, "severity": a.severity.name, "source": a.source,
            "message": a.message, "raised_at": a.raised_at.isoformat(), "escalated": a.escalated,
        }
        for a in runtime.alert_manager.active()
    ]
