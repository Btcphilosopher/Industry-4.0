from __future__ import annotations

from fastapi import APIRouter, Depends

from backend.api.deps import get_runtime
from backend.api.errors import DomainError
from backend.authentication.auth import AuthenticatedUser, Role, audit_log, require_any_role
from backend.events.event_types import EmergencyStop
from backend.orchestration.runtime import WarehouseRuntime
from robotics.robot_models.robot import RobotStatus

router = APIRouter(prefix="/api/robots", tags=["robots"])


@router.get("")
async def list_robots(runtime: WarehouseRuntime = Depends(get_runtime)) -> list[dict]:
    return [r.as_public_dict() for r in runtime.simulator.fleet_manager.robots.values()]


@router.get("/{robot_id}")
async def get_robot(robot_id: str, runtime: WarehouseRuntime = Depends(get_runtime)) -> dict:
    robot = runtime.simulator.fleet_manager.robots.get(robot_id)
    if robot is None:
        raise DomainError("ROBOT_NOT_FOUND", f"no robot with id {robot_id}", 404)
    return robot.as_public_dict()


@router.post("/{robot_id}/emergency-stop")
async def emergency_stop_robot(
    robot_id: str,
    runtime: WarehouseRuntime = Depends(get_runtime),
    user: AuthenticatedUser = Depends(
        require_any_role(Role.ADMIN, Role.OPERATIONS_MANAGER, Role.FLEET_MANAGER, Role.ENGINEER)
    ),
) -> dict:
    robot = runtime.simulator.fleet_manager.robots.get(robot_id)
    if robot is None:
        raise DomainError("ROBOT_NOT_FOUND", f"no robot with id {robot_id}", 404)
    runtime.simulator.fleet_manager.safety.trigger_estop(robot_id)
    robot.status = RobotStatus.ESTOP
    audit_log(user, "EMERGENCY_STOP", detail=robot_id)
    await runtime.event_bus.publish(EmergencyStop(scope=robot_id, reason="operator command", triggered_by=user.user_id))
    return {"robot_id": robot_id, "status": robot.status.value}
