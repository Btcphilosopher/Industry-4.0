from __future__ import annotations

from fastapi import APIRouter, Depends

from backend.api.deps import get_runtime
from backend.orchestration.runtime import WarehouseRuntime

router = APIRouter(prefix="/api/telemetry", tags=["telemetry"])


@router.get("/stats")
async def telemetry_stats(runtime: WarehouseRuntime = Depends(get_runtime)) -> dict:
    pipeline = runtime.telemetry_pipeline
    return {
        "ingested_count": pipeline.ingested_count,
        "dropped_count": pipeline.dropped_count,
        "buffered_count": pipeline.buffered_count,
        "throughput_events_per_second": round(pipeline.throughput_events_per_second(), 2),
        "target_events_per_second": runtime.settings.telemetry_target_events_per_second,
    }
