from __future__ import annotations

from dataclasses import asdict

from fastapi import APIRouter, Depends
from pydantic import BaseModel

from backend.api.deps import get_runtime
from backend.orchestration.runtime import WarehouseRuntime
from optimisation.fleet_optimisation.fleet_sizing import compare_fleet_sizes
from optimisation.slotting.slotting import recommend_slotting
from optimisation.workforce.workforce import allocate_workforce

router = APIRouter(prefix="/api/optimisation", tags=["optimisation"])


class FleetSizingRequest(BaseModel):
    candidate_sizes: list[int]
    tasks_per_hour: float
    avg_task_cycle_time_s: float


@router.post("/fleet-size")
async def optimise_fleet_size(body: FleetSizingRequest) -> list[dict]:
    results = compare_fleet_sizes(
        body.candidate_sizes, tasks_per_hour=body.tasks_per_hour, avg_task_cycle_time_s=body.avg_task_cycle_time_s,
    )
    return [asdict(r) for r in results]


@router.get("/slotting")
async def optimise_slotting(runtime: WarehouseRuntime = Depends(get_runtime)) -> list[dict]:
    completed_picks = [t for t in runtime.simulator.tasks.values() if t.task_type.value == "PICK" and t.sku]
    pick_counts: dict[str, int] = {}
    current_locations: dict[str, str] = {}
    for t in completed_picks:
        pick_counts[t.sku] = pick_counts.get(t.sku, 0) + 1
        current_locations.setdefault(t.sku, t.source or "UNKNOWN")
    recs = recommend_slotting(pick_counts, current_locations)
    return [asdict(r) for r in recs[:200]]


class WorkforceRequest(BaseModel):
    zone_workload: dict[str, float]
    total_workers: int
    min_per_zone: int = 0


@router.post("/workforce")
async def optimise_workforce(body: WorkforceRequest) -> list[dict]:
    plan = allocate_workforce(body.zone_workload, body.total_workers, min_per_zone=body.min_per_zone)
    return [asdict(p) for p in plan]
