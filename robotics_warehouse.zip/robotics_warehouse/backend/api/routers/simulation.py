from __future__ import annotations

import asyncio
from dataclasses import asdict

from fastapi import APIRouter, Depends

from backend.api.deps import get_runtime
from backend.api.errors import DomainError
from backend.orchestration.runtime import WarehouseRuntime
from digital_twin.warehouse_model.builder import BuildSpec
from simulation.scenario_engine.scenarios import BUILT_IN_SCENARIOS, run_scenario

router = APIRouter(prefix="/api/simulation", tags=["simulation"])


@router.get("/stats")
async def simulation_stats(runtime: WarehouseRuntime = Depends(get_runtime)) -> dict:
    stats = runtime.simulator.stats
    return {
        "ticks": stats.ticks, "sim_time_s": stats.sim_time_s, "orders_created": stats.orders_created,
        "orders_completed": stats.orders_completed, "tasks_created": stats.tasks_created,
        "tasks_completed": stats.tasks_completed, "tasks_failed": stats.tasks_failed,
        "fleet_size": len(runtime.simulator.fleet_manager.robots),
    }


@router.get("/scenarios")
async def list_scenarios() -> list[dict]:
    return [{"name": s.name, "description": s.description} for s in BUILT_IN_SCENARIOS.values()]


@router.post("/scenarios/{name}/run")
async def run_scenario_endpoint(name: str, duration_s: float = 600.0) -> dict:
    scenario = BUILT_IN_SCENARIOS.get(name)
    if scenario is None:
        raise DomainError("SCENARIO_NOT_FOUND", f"no scenario named {name}", 404)
    # Scenario runs are CPU-bound synchronous simulation ticks; offload so the
    # event loop keeps serving other requests (dashboard, WebSocket) meanwhile.
    result = await asyncio.to_thread(
        run_scenario, scenario, base_spec=BuildSpec(num_amrs=50, seed=7), duration_s=min(duration_s, 1800.0),
    )
    return {"name": result.name, "metrics": asdict(result.metrics), "stats": result.stats}
