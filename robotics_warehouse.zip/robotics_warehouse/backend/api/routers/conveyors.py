from __future__ import annotations

from fastapi import APIRouter, Depends

from backend.api.deps import get_runtime
from backend.orchestration.runtime import WarehouseRuntime

router = APIRouter(prefix="/api/conveyors", tags=["conveyors"])


@router.get("")
async def list_conveyors(runtime: WarehouseRuntime = Depends(get_runtime)) -> list[dict]:
    return [
        {
            "conveyor_id": c.conveyor_id, "zone_id": c.zone_id, "speed_mps": c.speed_mps,
            "blocked": c.blocked, "current_items": c.current_items, "capacity_items": c.capacity_items,
            "energy_watts": c.energy_watts,
        }
        for c in runtime.bundle.warehouse.conveyors.values()
    ]
