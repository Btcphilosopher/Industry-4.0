from __future__ import annotations

from fastapi import APIRouter, Depends

from backend.api.deps import get_runtime
from backend.api.errors import DomainError
from backend.orchestration.runtime import WarehouseRuntime

router = APIRouter(prefix="/api/tasks", tags=["tasks"])


def _task_dict(task) -> dict:
    return {
        "task_id": task.task_id, "task_type": task.task_type.value, "priority": int(task.priority),
        "status": task.status.value, "source": task.source, "destination": task.destination,
        "assigned_robot": task.assigned_robot, "order_id": task.order_id,
        "created_at": task.created_at.isoformat(),
        "estimated_duration_s": task.estimated_duration_s, "actual_duration_s": task.actual_duration_s,
        "retry_count": task.retry_count,
    }


@router.get("")
async def list_tasks(status: str | None = None, runtime: WarehouseRuntime = Depends(get_runtime)) -> list[dict]:
    tasks = runtime.simulator.tasks.values()
    if status:
        tasks = [t for t in tasks if t.status.value == status]
    return [_task_dict(t) for t in tasks]


@router.get("/{task_id}")
async def get_task(task_id: str, runtime: WarehouseRuntime = Depends(get_runtime)) -> dict:
    task = runtime.simulator.tasks.get(task_id)
    if task is None:
        raise DomainError("TASK_NOT_FOUND", f"no task with id {task_id}", 404)
    return _task_dict(task)
