from __future__ import annotations

from fastapi import APIRouter, Depends

from backend.api.deps import get_runtime
from backend.orchestration.runtime import WarehouseRuntime

router = APIRouter(prefix="/api/zones", tags=["zones"])


@router.get("")
async def list_zones(runtime: WarehouseRuntime = Depends(get_runtime)) -> list[dict]:
    snapshot = runtime.snapshot()
    zones = []
    for zone in runtime.bundle.warehouse.zones.values():
        zones.append({
            "zone_id": zone.zone_id, "name": zone.name, "zone_type": zone.zone_type.value,
            "aisle_count": len(zone.aisles), "congestion": snapshot.zone_congestion.get(zone.zone_id, 0),
            "congestion_threshold": zone.congestion_threshold,
        })
    return zones
