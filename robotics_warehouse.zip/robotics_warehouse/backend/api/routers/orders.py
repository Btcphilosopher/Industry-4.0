from __future__ import annotations

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from backend.api.deps import get_runtime
from backend.api.errors import DomainError
from backend.authentication.auth import AuthenticatedUser, Role, audit_log, require_any_role
from backend.orchestration.runtime import WarehouseRuntime
from backend.orchestration.tasks import TaskPriority
from backend.orders.models import Order, OrderLine

router = APIRouter(prefix="/api/orders", tags=["orders"])


class OrderLineRequest(BaseModel):
    sku: str
    quantity: float = Field(gt=0)


class SubmitOrderRequest(BaseModel):
    lines: list[OrderLineRequest]
    priority: int = 1
    customer_ref: str | None = None


def _order_dict(order: Order) -> dict:
    return {
        "order_id": order.order_id, "status": order.status.value, "priority": int(order.priority),
        "created_at": order.created_at.isoformat(),
        "dispatched_at": order.dispatched_at.isoformat() if order.dispatched_at else None,
        "lines": [{"sku": l.sku, "quantity": l.quantity, "picked_quantity": l.picked_quantity} for l in order.lines],
        "task_ids": order.task_ids,
    }


@router.get("")
async def list_orders(runtime: WarehouseRuntime = Depends(get_runtime)) -> list[dict]:
    return [_order_dict(o) for o in runtime.simulator.order_pipeline.orders.values()]


@router.get("/{order_id}")
async def get_order(order_id: str, runtime: WarehouseRuntime = Depends(get_runtime)) -> dict:
    order = runtime.simulator.order_pipeline.orders.get(order_id)
    if order is None:
        raise DomainError("ORDER_NOT_FOUND", f"no order with id {order_id}", 404)
    return _order_dict(order)


@router.post("", status_code=201)
async def submit_order(
    body: SubmitOrderRequest,
    runtime: WarehouseRuntime = Depends(get_runtime),
    user: AuthenticatedUser = Depends(require_any_role(Role.OPERATIONS_MANAGER, Role.WAREHOUSE_MANAGER, Role.OPERATOR)),
) -> dict:
    order = Order(
        lines=[OrderLine(sku=l.sku, quantity=l.quantity) for l in body.lines],
        priority=TaskPriority(body.priority), customer_ref=body.customer_ref,
    )
    try:
        tasks = runtime.simulator.order_pipeline.submit(order)
    except Exception as exc:
        raise DomainError("ORDER_SUBMISSION_FAILED", str(exc), 422) from exc
    runtime.simulator.tasks.update({t.task_id: t for t in tasks})
    audit_log(user, "SUBMIT_ORDER", detail=order.order_id)
    return _order_dict(order)
