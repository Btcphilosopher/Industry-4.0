from __future__ import annotations

from fastapi import APIRouter, Depends

from backend.api.deps import get_runtime
from backend.orchestration.runtime import WarehouseRuntime
from digital_twin.visualization.serializer import serialize_dynamic_state, serialize_static_layout

router = APIRouter(prefix="/api/warehouse", tags=["warehouse"])


@router.get("")
async def get_warehouse_layout(runtime: WarehouseRuntime = Depends(get_runtime)) -> dict:
    return serialize_static_layout(runtime.bundle.warehouse, runtime.bundle.graph)


@router.get("/state")
async def get_warehouse_state(runtime: WarehouseRuntime = Depends(get_runtime)) -> dict:
    return serialize_dynamic_state(runtime.snapshot())
