"""Authentication endpoint.

Demo user store only -- a production deployment authenticates against
``database.models.UserRecord`` with hashed passwords via
``backend.authentication.auth.verify_password``. Kept in-memory here so the
platform is usable out of the box without a seeded database.
"""
from __future__ import annotations

from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel

from backend.authentication.auth import Role, create_access_token, hash_password, verify_password

router = APIRouter(prefix="/api/auth", tags=["auth"])

_DEMO_USERS: dict[str, tuple[str, Role]] = {
    "admin": (hash_password("admin"), Role.ADMIN),
    "operator": (hash_password("operator"), Role.OPERATOR),
    "fleet_manager": (hash_password("fleet_manager"), Role.FLEET_MANAGER),
    "analyst": (hash_password("analyst"), Role.ANALYST),
    "viewer": (hash_password("viewer"), Role.VIEWER),
}


class LoginRequest(BaseModel):
    username: str
    password: str


class LoginResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: Role


@router.post("/login", response_model=LoginResponse)
async def login(body: LoginRequest) -> LoginResponse:
    record = _DEMO_USERS.get(body.username)
    if record is None or not verify_password(body.password, record[0]):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "invalid credentials")
    hashed, role = record
    token = create_access_token(body.username, role)
    return LoginResponse(access_token=token, role=role)
