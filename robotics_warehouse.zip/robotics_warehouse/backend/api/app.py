"""FastAPI application factory (spec section 22)."""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware

from backend.api.errors import DomainError, domain_error_handler, unhandled_error_handler
from backend.api.rate_limit import RateLimitMiddleware
from backend.api.routers import (
    analytics,
    auth,
    charging,
    conveyors,
    events,
    inventory,
    maintenance,
    optimisation,
    orders,
    robots,
    simulation,
    tasks,
    telemetry,
    warehouse,
    zones,
)
from backend.api.websocket import router as websocket_router
from backend.orchestration.runtime import WarehouseRuntime
from configuration.settings import Settings, get_settings

logger = logging.getLogger("robotics_warehouse.api")


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or get_settings()

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        app.state.runtime = WarehouseRuntime(settings)
        await app.state.runtime.start()
        logger.info("robotics-warehouse API ready (%s)", settings.env.value)
        yield
        await app.state.runtime.stop()

    app = FastAPI(
        title="Robotics Warehouse Platform",
        description="Industry 4.0 robotics warehouse management, orchestration, simulation and optimisation platform.",
        version="0.1.0",
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware, allow_origins=settings.cors_origins, allow_credentials=True,
        allow_methods=["*"], allow_headers=["*"],
    )
    app.add_middleware(RateLimitMiddleware, requests_per_minute=settings.rate_limit_per_minute)

    app.add_exception_handler(DomainError, domain_error_handler)
    app.add_exception_handler(Exception, unhandled_error_handler)

    for router_module in (
        robots, tasks, orders, inventory, warehouse, zones, conveyors, charging,
        telemetry, maintenance, analytics, simulation, optimisation, events, auth,
    ):
        app.include_router(router_module.router)
    app.include_router(websocket_router)

    @app.get("/health", tags=["system"])
    async def health() -> dict:
        return {"status": "ok", "env": settings.env.value}

    @app.get("/health/ready", tags=["system"])
    async def readiness(request: Request) -> dict:
        runtime: WarehouseRuntime = request.app.state.runtime
        return {
            "status": "ready" if runtime.is_running else "starting",
            "robots": len(runtime.simulator.fleet_manager.robots),
            "sim_ticks": runtime.simulator.stats.ticks,
        }

    return app


app = create_app()
