"""Enterprise authentication & RBAC.

JWT-based API authentication plus role-based authorisation. Every
operational command that mutates state should be wrapped with
``require_role`` / ``require_any_role`` and pass through ``audit_log`` so
it is attributable, per spec section 26.
"""
from __future__ import annotations

import logging
from datetime import UTC, datetime, timedelta
from enum import StrEnum

import bcrypt
import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel

from configuration.settings import Settings, get_settings

logger = logging.getLogger("robotics_warehouse.audit")
_bearer_scheme = HTTPBearer(auto_error=False)


class Role(StrEnum):
    ADMIN = "ADMIN"
    OPERATIONS_MANAGER = "OPERATIONS_MANAGER"
    FLEET_MANAGER = "FLEET_MANAGER"
    WAREHOUSE_MANAGER = "WAREHOUSE_MANAGER"
    MAINTENANCE = "MAINTENANCE"
    ENGINEER = "ENGINEER"
    ANALYST = "ANALYST"
    OPERATOR = "OPERATOR"
    VIEWER = "VIEWER"


# Roles permitted to trigger an emergency stop -- deliberately narrow, per
# spec section 26 "emergency-stop privilege separation".
EMERGENCY_STOP_ROLES = frozenset({Role.ADMIN, Role.OPERATIONS_MANAGER, Role.FLEET_MANAGER, Role.ENGINEER})


class TokenPayload(BaseModel):
    sub: str
    role: Role
    exp: datetime


class AuthenticatedUser(BaseModel):
    user_id: str
    role: Role


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8")[:72], bcrypt.gensalt()).decode("utf-8")


def verify_password(password: str, hashed: str) -> bool:
    return bcrypt.checkpw(password.encode("utf-8")[:72], hashed.encode("utf-8"))


def create_access_token(user_id: str, role: Role, settings: Settings | None = None) -> str:
    settings = settings or get_settings()
    expire = datetime.now(UTC) + timedelta(minutes=settings.jwt_expiry_minutes)
    payload = {"sub": user_id, "role": role.value, "exp": expire}
    return jwt.encode(payload, settings.jwt_secret, algorithm=settings.jwt_algorithm)


def decode_access_token(token: str, settings: Settings | None = None) -> TokenPayload:
    settings = settings or get_settings()
    try:
        raw = jwt.decode(token, settings.jwt_secret, algorithms=[settings.jwt_algorithm])
    except jwt.PyJWTError as exc:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "invalid or expired token") from exc
    return TokenPayload(**raw)


async def get_current_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(_bearer_scheme),
) -> AuthenticatedUser:
    if credentials is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "missing bearer token")
    payload = decode_access_token(credentials.credentials)
    return AuthenticatedUser(user_id=payload.sub, role=payload.role)


def require_any_role(*roles: Role):
    async def _dependency(user: AuthenticatedUser = Depends(get_current_user)) -> AuthenticatedUser:
        if user.role not in roles and user.role != Role.ADMIN:
            raise HTTPException(status.HTTP_403_FORBIDDEN, f"role {user.role} not permitted for this operation")
        return user
    return _dependency


def audit_log(user: AuthenticatedUser, action: str, detail: str = "") -> None:
    """Every operational command handler should call this. Structured so a
    real deployment can ship it straight to an immutable audit sink."""
    logger.info("audit", extra={"user_id": user.user_id, "role": user.role.value, "action": action, "detail": detail})
