"""Industrial analytics engine.

Computes the operational KPIs listed in spec section 19 from the live
state of a running (or completed) :class:`~simulation.warehouse_simulator.simulator.WarehouseSimulator`.
Read-only: this module never mutates simulation state, so it can be called
at any cadence (every tick for the dashboard, once at the end of a
scenario run for comparison) without side effects.
"""
from __future__ import annotations

from dataclasses import dataclass

from backend.orchestration.tasks import TaskStatus
from robotics.robot_models.robot import RobotStatus


@dataclass(slots=True)
class WarehouseMetrics:
    throughput_orders: int
    orders_per_hour: float
    picks_per_hour: float
    robot_utilisation_pct: float
    fleet_utilisation_pct: float
    avg_task_duration_s: float
    avg_fulfilment_time_s: float
    congestion_index: float
    avg_battery_pct: float
    energy_per_order_wh: float
    idle_time_pct: float
    task_completion_rate_pct: float
    on_time_fulfilment_pct: float
    downtime_pct: float


class AnalyticsEngine:
    """Wraps a :class:`WarehouseSimulator`-shaped object (duck-typed to avoid
    importing it at module load time, keeping this a leaf dependency of the
    simulation layer rather than a peer).
    """

    def __init__(self, sim) -> None:
        self.sim = sim
        self._history: list[WarehouseMetrics] = []

    def compute(self) -> WarehouseMetrics:
        sim = self.sim
        hours = max(sim.stats.sim_time_s / 3600.0, 1e-9)

        fleet = sim.fleet_manager
        robots = list(fleet.robots.values())
        n_robots = len(robots) or 1
        status_counts: dict[str, int] = {}
        for r in robots:
            status_counts[r.status.value] = status_counts.get(r.status.value, 0) + 1

        working = status_counts.get(RobotStatus.EXECUTING_TASK.value, 0)
        idle = status_counts.get(RobotStatus.IDLE.value, 0)
        faulted = status_counts.get(RobotStatus.FAULTED.value, 0) + status_counts.get(RobotStatus.OFFLINE.value, 0)

        avg_battery = sum(r.battery_pct for r in robots) / n_robots if robots else 0.0

        completed_tasks = [t for t in sim.tasks.values() if t.status == TaskStatus.COMPLETED]
        avg_task_duration = (
            sum(t.actual_duration_s or 0.0 for t in completed_tasks) / len(completed_tasks)
            if completed_tasks else 0.0
        )

        completed_orders = [
            o for o in sim.order_pipeline.orders.values() if o.status.value == "DISPATCHED" and o.dispatched_at
        ]
        avg_fulfilment = (
            sum((o.dispatched_at - o.created_at).total_seconds() for o in completed_orders) / len(completed_orders)
            if completed_orders else 0.0
        )
        # A task is on-time if it completed at or before the SLA deadline the
        # order pipeline assigned it (see backend.orders.pipeline._SLA_WINDOW).
        tasks_with_deadline = [t for t in completed_tasks if t.deadline is not None]
        on_time_pct = (
            100.0 * sum(1 for t in tasks_with_deadline if t.completed_at and t.completed_at <= t.deadline)
            / len(tasks_with_deadline)
            if tasks_with_deadline else 100.0
        )

        total_congestion = sum(
            sim.graph.congestion(a, b) for a in sim.graph.nodes for b in [n.to_id for n in sim.graph.neighbours(a)]
        )
        congestion_index = total_congestion / max(len(sim.graph.nodes), 1)

        picks_completed = sum(1 for t in completed_tasks if t.task_type.value == "PICK")

        total_energy_wh = sum(
            (r.capabilities().battery_capacity_wh * (100 - r.battery_pct) / 100.0) for r in robots
        )
        energy_per_order = total_energy_wh / max(sim.stats.orders_completed, 1)

        completion_rate = (
            sim.stats.tasks_completed / max(sim.stats.tasks_created, 1) * 100.0
        )

        metrics = WarehouseMetrics(
            throughput_orders=sim.stats.orders_completed,
            orders_per_hour=sim.stats.orders_completed / hours,
            picks_per_hour=picks_completed / hours,
            robot_utilisation_pct=(working / n_robots) * 100.0,
            fleet_utilisation_pct=((n_robots - idle) / n_robots) * 100.0 if robots else 0.0,
            avg_task_duration_s=avg_task_duration,
            avg_fulfilment_time_s=avg_fulfilment,
            congestion_index=congestion_index,
            avg_battery_pct=avg_battery,
            energy_per_order_wh=energy_per_order,
            idle_time_pct=(idle / n_robots) * 100.0 if robots else 0.0,
            task_completion_rate_pct=completion_rate,
            on_time_fulfilment_pct=on_time_pct,
            downtime_pct=(faulted / n_robots) * 100.0 if robots else 0.0,
        )
        self._history.append(metrics)
        return metrics

    def history(self) -> list[WarehouseMetrics]:
        return list(self._history)
