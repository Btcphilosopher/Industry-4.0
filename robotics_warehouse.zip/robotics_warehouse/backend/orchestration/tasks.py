"""Unified task abstraction and lifecycle state machine.

A single ``Task`` model represents every unit of work in the warehouse
(PICK, PUTAWAY, MOVE, ...). The lifecycle is enforced by
:class:`TaskLifecycleError` rather than left to callers to get right by
convention -- illegal transitions raise immediately.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import IntEnum, StrEnum


class TaskType(StrEnum):
    PICK = "PICK"
    PUTAWAY = "PUTAWAY"
    MOVE = "MOVE"
    REPLENISH = "REPLENISH"
    SORT = "SORT"
    PACK = "PACK"
    LOAD = "LOAD"
    UNLOAD = "UNLOAD"
    INSPECT = "INSPECT"
    COUNT = "COUNT"
    CHARGE = "CHARGE"
    MAINTENANCE = "MAINTENANCE"
    TRANSFER = "TRANSFER"


class TaskStatus(StrEnum):
    CREATED = "CREATED"
    QUEUED = "QUEUED"
    ASSIGNED = "ASSIGNED"
    EXECUTING = "EXECUTING"
    BLOCKED = "BLOCKED"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"


class TaskPriority(IntEnum):
    LOW = 0
    NORMAL = 1
    HIGH = 2
    CRITICAL = 3


_VALID_TRANSITIONS: dict[TaskStatus, set[TaskStatus]] = {
    TaskStatus.CREATED: {TaskStatus.QUEUED, TaskStatus.CANCELLED},
    TaskStatus.QUEUED: {TaskStatus.ASSIGNED, TaskStatus.CANCELLED, TaskStatus.BLOCKED},
    TaskStatus.ASSIGNED: {TaskStatus.EXECUTING, TaskStatus.QUEUED, TaskStatus.CANCELLED, TaskStatus.FAILED},
    TaskStatus.EXECUTING: {TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.BLOCKED, TaskStatus.CANCELLED},
    TaskStatus.BLOCKED: {TaskStatus.QUEUED, TaskStatus.EXECUTING, TaskStatus.FAILED, TaskStatus.CANCELLED},
    TaskStatus.COMPLETED: set(),
    TaskStatus.FAILED: {TaskStatus.QUEUED},  # allow recovery re-queue
    TaskStatus.CANCELLED: set(),
}


class TaskLifecycleError(RuntimeError):
    """Raised when an illegal task-state transition is attempted."""


@dataclass(slots=True)
class Task:
    task_type: TaskType
    priority: TaskPriority = TaskPriority.NORMAL
    source: str | None = None
    destination: str | None = None
    payload_kg: float = 0.0
    required_robot_type: str | None = None
    sku: str | None = None
    quantity: float = 0.0
    lot_id: str | None = None
    line_id: str | None = None
    order_id: str | None = None
    deadline: datetime | None = None
    task_id: str = field(default_factory=lambda: f"TASK-{uuid.uuid4().hex[:10]}")
    status: TaskStatus = TaskStatus.CREATED
    assigned_robot: str | None = None
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    assigned_at: datetime | None = None
    started_at: datetime | None = None
    completed_at: datetime | None = None
    estimated_duration_s: float | None = None
    actual_duration_s: float | None = None
    retry_count: int = 0
    failure_reason: str | None = None

    def transition(self, new_status: TaskStatus) -> None:
        allowed = _VALID_TRANSITIONS[self.status]
        if new_status not in allowed:
            raise TaskLifecycleError(
                f"Task {self.task_id}: illegal transition {self.status} -> {new_status}"
            )
        now = datetime.now(UTC)
        if new_status is TaskStatus.ASSIGNED:
            self.assigned_at = now
        elif new_status is TaskStatus.EXECUTING and self.started_at is None:
            self.started_at = now
        elif new_status is TaskStatus.COMPLETED:
            self.completed_at = now
            if self.started_at:
                self.actual_duration_s = (now - self.started_at).total_seconds()
        self.status = new_status

    def is_overdue(self, at: datetime | None = None) -> bool:
        if self.deadline is None:
            return False
        return (at or datetime.now(UTC)) > self.deadline

    def is_terminal(self) -> bool:
        return self.status in (TaskStatus.COMPLETED, TaskStatus.CANCELLED)
