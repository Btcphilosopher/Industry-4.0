"""The platform runtime: wires every subsystem together and drives the
simulation clock.

    ORDERS -> INVENTORY -> TASK ENGINE -> OPTIMISATION -> ROBOT FLEET ->
    WAREHOUSE EXECUTION -> TELEMETRY -> DIGITAL TWIN -> ANALYTICS ->
    OPTIMISATION FEEDBACK

``WarehouseRuntime`` is the single composition root: the API layer, the
demo script, and the test suite all construct one of these rather than
each wiring subsystems together independently.
"""
from __future__ import annotations

import asyncio
import logging

from backend.analytics.engine import AnalyticsEngine, WarehouseMetrics
from backend.energy.energy_manager import EnergyManager
from backend.events.event_bus import EventBus
from backend.maintenance.health import MaintenanceService
from backend.orchestration.alerting import AlertManager
from configuration.settings import Settings, get_settings
from digital_twin.live_state.aggregator import LiveStateAggregator, TwinSnapshot
from digital_twin.warehouse_model.builder import BuildSpec, DigitalTwinBundle, build_demo_warehouse
from simulation.warehouse_simulator.simulator import WarehouseSimulator
from telemetry.ingestion import TelemetryIngestionPipeline
from telemetry.protocols import TelemetryKind, TelemetryReading

logger = logging.getLogger("robotics_warehouse.runtime")


class WarehouseRuntime:
    def __init__(self, settings: Settings | None = None, build_spec: BuildSpec | None = None) -> None:
        self.settings = settings or get_settings()
        self.build_spec = build_spec or BuildSpec(seed=self.settings.simulation_seed)

        self.event_bus = EventBus()
        self.bundle: DigitalTwinBundle = build_demo_warehouse(self.build_spec)
        self.simulator = WarehouseSimulator(
            self.bundle, self.event_bus, orders_per_hour=400.0, seed=self.build_spec.seed,
        )
        self.alert_manager = AlertManager(self.event_bus)
        self.maintenance_service = MaintenanceService(self.event_bus)
        self.energy_manager = EnergyManager(self.bundle.warehouse.charging_stations)
        self.analytics_engine = AnalyticsEngine(self.simulator)
        self.live_state = LiveStateAggregator(self.bundle.warehouse, self.simulator.fleet_manager)
        self.telemetry_pipeline = TelemetryIngestionPipeline(
            buffer_size=self.settings.telemetry_buffer_size,
            flush_interval_s=self.settings.telemetry_flush_interval_seconds,
        )

        self._running = False
        self._loop_task: asyncio.Task | None = None
        self._maintenance_counter = 0
        self.latest_metrics: WarehouseMetrics | None = None

    @property
    def is_running(self) -> bool:
        return self._running

    # --- lifecycle ----------------------------------------------------------

    async def start(self) -> None:
        if self._running:
            return
        self._running = True
        await self.telemetry_pipeline.start()
        self._loop_task = asyncio.create_task(self._run_loop())
        logger.info("warehouse runtime started: %d robots, %d zones", len(self.bundle.robots), len(self.bundle.warehouse.zones))

    async def stop(self) -> None:
        self._running = False
        if self._loop_task:
            self._loop_task.cancel()
        await self.telemetry_pipeline.stop()

    async def _run_loop(self) -> None:
        tick_s = self.settings.simulation_tick_seconds
        speed = max(self.settings.simulation_speed_multiplier, 0.0001)
        real_sleep = tick_s / speed
        while self._running:
            try:
                self.tick(tick_s)
            except Exception:
                logger.exception("simulation tick failed")
            await asyncio.sleep(real_sleep)

    # --- single-step (also used directly by tests / scripts) -----------------

    def tick(self, dt_seconds: float) -> None:
        self.simulator.tick(dt_seconds)
        self._ingest_telemetry()

        self._maintenance_counter += 1
        if self._maintenance_counter >= 20:
            self.maintenance_service.assess_fleet(self.simulator.fleet_manager.robots)
            self._maintenance_counter = 0

        self.latest_metrics = self.analytics_engine.compute()

    def _ingest_telemetry(self) -> None:
        for robot in self.simulator.fleet_manager.robots.values():
            self.telemetry_pipeline.ingest(
                TelemetryReading(
                    source_id=robot.robot_id, kind=TelemetryKind.MOTOR_TEMPERATURE,
                    value=robot.motor_temp_c, unit="celsius", protocol="SIMULATED",
                )
            )

    # --- read models ----------------------------------------------------------

    def snapshot(self) -> TwinSnapshot:
        return self.live_state.snapshot(self.simulator.tasks)

    def energy_snapshot(self):
        return self.energy_manager.facility_snapshot(self.simulator.fleet_manager.robots)
