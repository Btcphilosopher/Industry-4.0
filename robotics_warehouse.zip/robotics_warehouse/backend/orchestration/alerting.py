"""Operational alerting.

Subscribes to the event bus and raises severity-tiered alerts
(INFO/NOTICE/WARNING/CRITICAL/EMERGENCY) for the conditions listed in spec
section 21. Alerts support acknowledgement and escalation: an
unacknowledged CRITICAL/EMERGENCY alert automatically escalates after its
configured timeout, which a real deployment would wire to a paging system.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from enum import IntEnum

from backend.events.event_bus import EventBus
from backend.events.event_types import (
    AlertRaised,
    BatteryLow,
    ConveyorBlocked,
    EmergencyStop,
    MaintenanceRequired,
    RobotFaultDetected,
)


class Severity(IntEnum):
    INFO = 0
    NOTICE = 1
    WARNING = 2
    CRITICAL = 3
    EMERGENCY = 4


_ESCALATION_TIMEOUT = {
    Severity.CRITICAL: timedelta(minutes=5),
    Severity.EMERGENCY: timedelta(minutes=1),
}


@dataclass(slots=True)
class Alert:
    severity: Severity
    source: str
    message: str
    alert_id: str = field(default_factory=lambda: f"ALERT-{uuid.uuid4().hex[:8]}")
    raised_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    acknowledged: bool = False
    acknowledged_by: str | None = None
    escalated: bool = False


class AlertManager:
    def __init__(self, event_bus: EventBus) -> None:
        self.event_bus = event_bus
        self.alerts: dict[str, Alert] = {}
        event_bus.subscribe(BatteryLow, self._on_battery_low)
        event_bus.subscribe(RobotFaultDetected, self._on_robot_fault)
        event_bus.subscribe(ConveyorBlocked, self._on_conveyor_blocked)
        event_bus.subscribe(EmergencyStop, self._on_estop)
        event_bus.subscribe(MaintenanceRequired, self._on_maintenance_required)

    def raise_alert(self, severity: Severity, source: str, message: str) -> Alert:
        alert = Alert(severity=severity, source=source, message=message)
        self.alerts[alert.alert_id] = alert
        self.event_bus.publish_nowait(
            AlertRaised(alert_id=alert.alert_id, severity=severity.name, source=source, message=message)
        )
        return alert

    def acknowledge(self, alert_id: str, by: str) -> bool:
        alert = self.alerts.get(alert_id)
        if alert is None:
            return False
        alert.acknowledged = True
        alert.acknowledged_by = by
        return True

    def escalate_overdue(self, *, now: datetime | None = None) -> list[Alert]:
        now = now or datetime.now(UTC)
        escalated = []
        for alert in self.alerts.values():
            if alert.acknowledged or alert.escalated:
                continue
            timeout = _ESCALATION_TIMEOUT.get(alert.severity)
            if timeout and now - alert.raised_at > timeout:
                alert.escalated = True
                escalated.append(alert)
        return escalated

    def active(self) -> list[Alert]:
        return [a for a in self.alerts.values() if not a.acknowledged]

    # --- event handlers -------------------------------------------------------

    async def _on_battery_low(self, event: BatteryLow) -> None:
        severity = Severity.CRITICAL if event.battery_pct < 10 else Severity.WARNING
        self.raise_alert(severity, event.robot_id, f"battery at {event.battery_pct:.1f}%")

    async def _on_robot_fault(self, event: RobotFaultDetected) -> None:
        self.raise_alert(Severity.CRITICAL, event.robot_id, f"fault {event.fault_code}: {event.detail}")

    async def _on_conveyor_blocked(self, event: ConveyorBlocked) -> None:
        self.raise_alert(Severity.CRITICAL, event.conveyor_id, f"conveyor offline: {event.reason}")

    async def _on_estop(self, event: EmergencyStop) -> None:
        self.raise_alert(Severity.EMERGENCY, event.scope, f"emergency stop triggered by {event.triggered_by}: {event.reason}")

    async def _on_maintenance_required(self, event: MaintenanceRequired) -> None:
        self.raise_alert(Severity.WARNING, event.asset_id, f"maintenance required: {event.reason}")
