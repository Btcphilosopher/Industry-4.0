# Kubernetes deployment shape

This platform is deliberately structured so the Docker Compose topology in
`docker-compose.yml` maps directly onto Kubernetes without redesigning
anything -- each service is already a stateless (or externally-stated)
process reading its configuration from environment variables
(`configuration/settings.py`).

| Compose service     | Kubernetes shape                                   | Notes |
|----------------------|-----------------------------------------------------|-------|
| `api`                 | `Deployment` + `Service` (+ `HorizontalPodAutoscaler`) | Stateless; scale horizontally behind a `Service`/Ingress. Liveness/readiness probes hit `/health` and `/health/ready`. |
| `simulation-worker`   | `Deployment` (replicas=1 per simulated facility)     | Each replica owns one warehouse's simulation loop; scale by adding replicas with distinct `RW_SIMULATION_SEED` / facility config, not by scaling a single replica. |
| `postgres`             | `StatefulSet` + `PersistentVolumeClaim` (or a managed Postgres) | Use a managed service (RDS/Cloud SQL) in real deployments rather than running Postgres in-cluster. |
| `redis`                | `Deployment` (or managed Redis) | Backs the future distributed rate limiter / broker adapters in `messaging.brokers`. |
| `mosquitto`            | `Deployment` (or managed MQTT/IoT Core) | Industrial IoT ingress; swapped for a managed broker (AWS IoT Core, HiveMQ Cloud) in production without touching `telemetry.adapters`. |

Suggested additions for a real cluster rollout (not included here, since
they're infra-specific rather than application code):

- A `ConfigMap` for non-secret settings and a `Secret` for `RW_JWT_SECRET`
  / database credentials, mounted as the `RW_*` environment variables
  `configuration/settings.py` already reads.
- `PodDisruptionBudget` + `readinessProbe` on `/health/ready` so rolling
  updates never take all `api` replicas down at once.
- A `NetworkPolicy` restricting the `postgres`/`redis`/`mosquitto` services
  to only the `api` and `simulation-worker` pods (spec section 26,
  "network segmentation assumptions").
- Metrics scraping (`/api/analytics`, `/api/telemetry/stats`, plus a future
  `/metrics` Prometheus endpoint) via a `ServiceMonitor` if Prometheus
  Operator is available.
