"""SQLAlchemy 2.0 schema for the transactional (OLTP) store.

Split deliberately from high-frequency telemetry: ``TelemetryRecord`` here
represents periodically-*summarised* telemetry (see
``telemetry.ingestion``), not raw per-tick readings -- raw readings belong
in a time-series store (TimescaleDB/InfluxDB in production) sized for
10,000+ events/sec, which this table is intentionally not.

Table naming and columns follow spec section 23 directly: robots,
robot_states, robot_events, tasks, orders, order_lines, inventory,
storage_locations, warehouse_zones, conveyors, stations, charging_stations,
maintenance_records, telemetry, alerts, users, simulation_runs,
optimisation_runs.
"""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import JSON, Boolean, DateTime, Float, ForeignKey, Index, Integer, String
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


class RobotRecord(Base):
    __tablename__ = "robots"

    robot_id: Mapped[str] = mapped_column(String(32), primary_key=True)
    robot_type: Mapped[str] = mapped_column(String(32), nullable=False)
    registered_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    decommissioned_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class RobotStateRecord(Base):
    """Periodic (not per-tick) persisted snapshot of a robot's state, for
    historical trend queries -- high-frequency state lives in the telemetry
    pipeline, not here."""

    __tablename__ = "robot_states"
    __table_args__ = (Index("ix_robot_states_robot_time", "robot_id", "recorded_at"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    robot_id: Mapped[str] = mapped_column(String(32), ForeignKey("robots.robot_id"))
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    x: Mapped[float] = mapped_column(Float)
    y: Mapped[float] = mapped_column(Float)
    battery_pct: Mapped[float] = mapped_column(Float)
    status: Mapped[str] = mapped_column(String(32))
    health_score: Mapped[float] = mapped_column(Float, default=1.0)


class RobotEventRecord(Base):
    __tablename__ = "robot_events"
    __table_args__ = (Index("ix_robot_events_robot_time", "robot_id", "occurred_at"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    robot_id: Mapped[str] = mapped_column(String(32), ForeignKey("robots.robot_id"))
    event_type: Mapped[str] = mapped_column(String(64))
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    payload: Mapped[dict] = mapped_column(JSON, default=dict)


class TaskRecord(Base):
    __tablename__ = "tasks"
    __table_args__ = (Index("ix_tasks_status", "status"), Index("ix_tasks_order", "order_id"))

    task_id: Mapped[str] = mapped_column(String(32), primary_key=True)
    task_type: Mapped[str] = mapped_column(String(32))
    priority: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(32))
    source: Mapped[str | None] = mapped_column(String(64), nullable=True)
    destination: Mapped[str | None] = mapped_column(String(64), nullable=True)
    assigned_robot: Mapped[str | None] = mapped_column(String(32), nullable=True)
    order_id: Mapped[str | None] = mapped_column(String(32), ForeignKey("orders.order_id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    actual_duration_s: Mapped[float | None] = mapped_column(Float, nullable=True)


class OrderRecord(Base):
    __tablename__ = "orders"
    __table_args__ = (Index("ix_orders_status", "status"),)

    order_id: Mapped[str] = mapped_column(String(32), primary_key=True)
    status: Mapped[str] = mapped_column(String(32))
    priority: Mapped[int] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    dispatched_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    lines: Mapped[list[OrderLineRecord]] = relationship(back_populates="order")


class OrderLineRecord(Base):
    __tablename__ = "order_lines"

    line_id: Mapped[str] = mapped_column(String(32), primary_key=True)
    order_id: Mapped[str] = mapped_column(String(32), ForeignKey("orders.order_id"))
    sku: Mapped[str] = mapped_column(String(32))
    quantity: Mapped[float] = mapped_column(Float)
    picked_quantity: Mapped[float] = mapped_column(Float, default=0.0)
    order: Mapped[OrderRecord] = relationship(back_populates="lines")


class InventoryRecord(Base):
    __tablename__ = "inventory"
    __table_args__ = (Index("ix_inventory_sku", "sku"), Index("ix_inventory_location", "location_id"))

    lot_id: Mapped[str] = mapped_column(String(32), primary_key=True)
    sku: Mapped[str] = mapped_column(String(32))
    location_id: Mapped[str] = mapped_column(String(32), ForeignKey("storage_locations.location_id"))
    quantity: Mapped[float] = mapped_column(Float)
    reserved_quantity: Mapped[float] = mapped_column(Float, default=0.0)
    batch_number: Mapped[str] = mapped_column(String(32))
    condition: Mapped[str] = mapped_column(String(16), default="GOOD")
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    expiry_date: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class StorageLocationRecord(Base):
    __tablename__ = "storage_locations"

    location_id: Mapped[str] = mapped_column(String(32), primary_key=True)
    aisle_id: Mapped[str] = mapped_column(String(32))
    zone_id: Mapped[str] = mapped_column(String(32), ForeignKey("warehouse_zones.zone_id"))
    location_type: Mapped[str] = mapped_column(String(32))
    capacity_units: Mapped[float] = mapped_column(Float)
    x: Mapped[float] = mapped_column(Float)
    y: Mapped[float] = mapped_column(Float)


class WarehouseZoneRecord(Base):
    __tablename__ = "warehouse_zones"

    zone_id: Mapped[str] = mapped_column(String(32), primary_key=True)
    name: Mapped[str] = mapped_column(String(64))
    zone_type: Mapped[str] = mapped_column(String(32))


class ConveyorRecord(Base):
    __tablename__ = "conveyors"

    conveyor_id: Mapped[str] = mapped_column(String(32), primary_key=True)
    zone_id: Mapped[str] = mapped_column(String(32), ForeignKey("warehouse_zones.zone_id"))
    speed_mps: Mapped[float] = mapped_column(Float, default=1.0)
    blocked: Mapped[bool] = mapped_column(Boolean, default=False)


class StationRecord(Base):
    """Covers packing stations, robotic cells and docks -- unified via ``station_type``."""

    __tablename__ = "stations"

    station_id: Mapped[str] = mapped_column(String(32), primary_key=True)
    station_type: Mapped[str] = mapped_column(String(32))
    zone_id: Mapped[str] = mapped_column(String(32), ForeignKey("warehouse_zones.zone_id"))
    x: Mapped[float] = mapped_column(Float)
    y: Mapped[float] = mapped_column(Float)


class ChargingStationRecord(Base):
    __tablename__ = "charging_stations"

    station_id: Mapped[str] = mapped_column(String(32), primary_key=True)
    zone_id: Mapped[str] = mapped_column(String(32), ForeignKey("warehouse_zones.zone_id"))
    slots: Mapped[int] = mapped_column(Integer, default=1)
    charge_rate_w: Mapped[float] = mapped_column(Float, default=900.0)


class MaintenanceRecordRow(Base):
    __tablename__ = "maintenance_records"
    __table_args__ = (Index("ix_maintenance_asset_time", "asset_id", "assessed_at"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    asset_id: Mapped[str] = mapped_column(String(32))
    asset_type: Mapped[str] = mapped_column(String(32))
    health_score: Mapped[float] = mapped_column(Float)
    failure_probability: Mapped[float] = mapped_column(Float)
    remaining_useful_life_hours: Mapped[float] = mapped_column(Float)
    priority: Mapped[str] = mapped_column(String(16))
    assessed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class TelemetryRecord(Base):
    """Periodic summarised telemetry (aggregated by ``telemetry.ingestion``
    before persistence -- see module docstring)."""

    __tablename__ = "telemetry"
    __table_args__ = (Index("ix_telemetry_source_time", "source_id", "recorded_at"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    source_id: Mapped[str] = mapped_column(String(32))
    kind: Mapped[str] = mapped_column(String(32))
    value: Mapped[float] = mapped_column(Float)
    unit: Mapped[str] = mapped_column(String(16))
    protocol: Mapped[str] = mapped_column(String(16))
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class AlertRecord(Base):
    __tablename__ = "alerts"
    __table_args__ = (Index("ix_alerts_severity_time", "severity", "raised_at"),)

    alert_id: Mapped[str] = mapped_column(String(32), primary_key=True)
    severity: Mapped[str] = mapped_column(String(16))
    source: Mapped[str] = mapped_column(String(64))
    message: Mapped[str] = mapped_column(String(512))
    raised_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    acknowledged: Mapped[bool] = mapped_column(Boolean, default=False)
    acknowledged_by: Mapped[str | None] = mapped_column(String(64), nullable=True)


class UserRecord(Base):
    __tablename__ = "users"

    user_id: Mapped[str] = mapped_column(String(32), primary_key=True)
    username: Mapped[str] = mapped_column(String(64), unique=True)
    hashed_password: Mapped[str] = mapped_column(String(256))
    role: Mapped[str] = mapped_column(String(32))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class SimulationRunRecord(Base):
    __tablename__ = "simulation_runs"

    run_id: Mapped[str] = mapped_column(String(32), primary_key=True)
    scenario_name: Mapped[str] = mapped_column(String(64))
    seed: Mapped[int] = mapped_column(Integer)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    metrics: Mapped[dict] = mapped_column(JSON, default=dict)


class OptimisationRunRecord(Base):
    __tablename__ = "optimisation_runs"

    run_id: Mapped[str] = mapped_column(String(32), primary_key=True)
    optimisation_type: Mapped[str] = mapped_column(String(64))
    strategy: Mapped[str] = mapped_column(String(64))
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    result: Mapped[dict] = mapped_column(JSON, default=dict)
