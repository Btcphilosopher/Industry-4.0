"""Repository pattern over the transactional database.

Kept intentionally narrow: the simulation loop and fleet manager operate on
fast in-memory domain objects (see ``robotics``/``backend.orchestration``)
for correctness and speed, and periodically persist *summaries* through
these repositories -- the database is the system of record for durability,
audit and historical analytics, not the hot path for robot control.
"""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from database.models import (
    AlertRecord,
    MaintenanceRecordRow,
    OrderRecord,
    RobotEventRecord,
    RobotRecord,
    RobotStateRecord,
    TaskRecord,
    TelemetryRecord,
)


class RobotRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def upsert(self, robot_id: str, robot_type: str, registered_at: datetime) -> None:
        existing = await self.session.get(RobotRecord, robot_id)
        if existing is None:
            self.session.add(RobotRecord(robot_id=robot_id, robot_type=robot_type, registered_at=registered_at))

    async def record_state(self, **kwargs) -> None:
        self.session.add(RobotStateRecord(**kwargs))

    async def record_event(self, **kwargs) -> None:
        self.session.add(RobotEventRecord(**kwargs))

    async def history(self, robot_id: str, limit: int = 200) -> list[RobotStateRecord]:
        stmt = (
            select(RobotStateRecord)
            .where(RobotStateRecord.robot_id == robot_id)
            .order_by(RobotStateRecord.recorded_at.desc())
            .limit(limit)
        )
        result = await self.session.execute(stmt)
        return list(result.scalars())


class TaskRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def upsert(self, **kwargs) -> None:
        existing = await self.session.get(TaskRecord, kwargs["task_id"])
        if existing is None:
            self.session.add(TaskRecord(**kwargs))
        else:
            for k, v in kwargs.items():
                setattr(existing, k, v)

    async def by_status(self, status: str) -> list[TaskRecord]:
        result = await self.session.execute(select(TaskRecord).where(TaskRecord.status == status))
        return list(result.scalars())


class OrderRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def upsert(self, **kwargs) -> None:
        existing = await self.session.get(OrderRecord, kwargs["order_id"])
        if existing is None:
            self.session.add(OrderRecord(**kwargs))
        else:
            for k, v in kwargs.items():
                setattr(existing, k, v)


class AlertRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def add(self, **kwargs) -> None:
        self.session.add(AlertRecord(**kwargs))

    async def active(self) -> list[AlertRecord]:
        result = await self.session.execute(select(AlertRecord).where(AlertRecord.acknowledged.is_(False)))
        return list(result.scalars())


class MaintenanceRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def add(self, **kwargs) -> None:
        self.session.add(MaintenanceRecordRow(**kwargs))


class TelemetryRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def add_batch(self, rows: list[dict]) -> None:
        self.session.add_all([TelemetryRecord(**row) for row in rows])
