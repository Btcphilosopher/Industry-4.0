#!/usr/bin/env python3
"""Run a live, fully-functioning simulated Industry 4.0 warehouse.

Two modes:

    python scripts/run_demo.py api        # start the FastAPI + WebSocket server
    python scripts/run_demo.py headless    # run the sim loop in a terminal, printing live KPIs

The headless mode demonstrates the full pipeline end to end without needing
a browser: orders arriving, inventory being picked, tasks being allocated,
batteries decreasing, robots charging, congestion forming, faults
occurring, maintenance events, and analytics updating -- exactly the demo
environment described in the platform spec.
"""
from __future__ import annotations

import argparse
import logging
import sys
import time

from backend.orchestration.runtime import WarehouseRuntime
from configuration.settings import get_settings
from digital_twin.warehouse_model.builder import BuildSpec

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
logger = logging.getLogger("robotics_warehouse.demo")


def run_headless(*, duration_s: float, tick_s: float, report_every_s: float) -> None:
    settings = get_settings()
    spec = BuildSpec(seed=settings.simulation_seed)
    runtime = WarehouseRuntime(settings, spec)

    print(f"Built demo warehouse '{runtime.bundle.warehouse.name}':")
    print(f"  zones={len(runtime.bundle.warehouse.zones)} "
          f"locations={len(runtime.bundle.warehouse.all_locations())} "
          f"robots={len(runtime.bundle.robots)} "
          f"skus={len(runtime.bundle.sku_catalog)} "
          f"charging_stations={len(runtime.bundle.warehouse.charging_stations)} "
          f"packing_stations={len(runtime.bundle.warehouse.packing_stations)}")
    print()

    elapsed = 0.0
    next_report = 0.0
    t0 = time.time()
    while elapsed < duration_s:
        runtime.tick(tick_s)
        elapsed += tick_s
        if elapsed >= next_report:
            _print_report(runtime, elapsed)
            next_report += report_every_s

    wall = time.time() - t0
    print(f"\nSimulated {elapsed:.0f}s of warehouse operation in {wall:.1f}s wall-clock "
          f"({elapsed / max(wall, 1e-9):.1f}x real time).")


def _print_report(runtime: WarehouseRuntime, elapsed: float) -> None:
    stats = runtime.simulator.stats
    fleet = runtime.simulator.fleet_manager.snapshot()
    metrics = runtime.latest_metrics
    alerts = runtime.alert_manager.active()
    print(
        f"[t={elapsed:7.0f}s] orders={stats.orders_created:4d} done={stats.orders_completed:4d} | "
        f"tasks={stats.tasks_created:5d} done={stats.tasks_completed:5d} failed={stats.tasks_failed:3d} | "
        f"fleet={fleet.by_status} | avg_batt={fleet.avg_battery_pct:5.1f}% | "
        f"orders/hr={metrics.orders_per_hour if metrics else 0:5.1f} | "
        f"active_alerts={len(alerts)}"
    )


def run_api() -> None:
    import uvicorn
    settings = get_settings()
    uvicorn.run("backend.api.app:app", host=settings.api_host, port=settings.api_port, reload=False)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["api", "headless"], nargs="?", default="headless")
    parser.add_argument("--duration", type=float, default=3600.0, help="simulated seconds to run (headless mode)")
    parser.add_argument("--tick", type=float, default=1.0, help="seconds simulated per tick")
    parser.add_argument("--report-every", type=float, default=60.0, help="seconds between console reports")
    args = parser.parse_args()

    if args.mode == "api":
        run_api()
    else:
        run_headless(duration_s=args.duration, tick_s=args.tick, report_every_s=args.report_every)


if __name__ == "__main__":
    sys.exit(main() or 0)
