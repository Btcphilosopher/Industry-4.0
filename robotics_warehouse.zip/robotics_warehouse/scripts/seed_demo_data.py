#!/usr/bin/env python3
"""Seed the transactional database with the demo warehouse's structural data.

Populates the tables that represent the (rarely-changing) physical layout --
zones, storage locations, conveyors, stations, charging stations, robots --
so the database layer can be demonstrated and queried independently of a
running simulation. High-frequency state (robot positions, telemetry) is
intentionally NOT seeded here; that only ever comes from a live simulator
or real fleet, consistent with spec section 24 (telemetry vs. transactional
separation).

Usage:
    python scripts/seed_demo_data.py
"""
from __future__ import annotations

import asyncio
import logging
from datetime import UTC, datetime

from database.models import (
    ChargingStationRecord,
    ConveyorRecord,
    RobotRecord,
    StationRecord,
    StorageLocationRecord,
    WarehouseZoneRecord,
)
from database.session import Database
from digital_twin.warehouse_model.builder import BuildSpec, build_demo_warehouse

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
logger = logging.getLogger("robotics_warehouse.seed")


async def seed(spec: BuildSpec | None = None) -> None:
    spec = spec or BuildSpec()
    logger.info("building demo warehouse (seed=%d)...", spec.seed)
    bundle = build_demo_warehouse(spec)
    now = datetime.now(UTC)

    db = Database()
    await db.init()

    async with db.session() as session:
        for zone in bundle.warehouse.zones.values():
            session.add(WarehouseZoneRecord(zone_id=zone.zone_id, name=zone.name, zone_type=zone.zone_type.value))

        for zone in bundle.warehouse.zones.values():
            for aisle in zone.aisles.values():
                for loc in aisle.locations.values():
                    session.add(StorageLocationRecord(
                        location_id=loc.location_id, aisle_id=aisle.aisle_id, zone_id=zone.zone_id,
                        location_type=loc.location_type.value, capacity_units=loc.capacity_units,
                        x=loc.position.x, y=loc.position.y,
                    ))

        for conveyor in bundle.warehouse.conveyors.values():
            session.add(ConveyorRecord(
                conveyor_id=conveyor.conveyor_id, zone_id=conveyor.zone_id, speed_mps=conveyor.speed_mps,
                blocked=conveyor.blocked,
            ))

        for station in bundle.warehouse.charging_stations.values():
            session.add(ChargingStationRecord(
                station_id=station.station_id, zone_id=station.zone_id, slots=station.slots,
                charge_rate_w=station.charge_rate_w,
            ))

        for station in bundle.warehouse.packing_stations.values():
            session.add(StationRecord(
                station_id=station.station_id, station_type="PACKING", zone_id=station.zone_id,
                x=station.position.x, y=station.position.y,
            ))
        for dock in bundle.warehouse.docks.values():
            session.add(StationRecord(
                station_id=dock.dock_id, station_type="DOCK", zone_id=dock.zone_id,
                x=dock.position.x, y=dock.position.y,
            ))
        for cell in bundle.warehouse.robotic_cells.values():
            session.add(StationRecord(
                station_id=cell.cell_id, station_type="ROBOTIC_CELL", zone_id=cell.zone_id,
                x=cell.position.x, y=cell.position.y,
            ))

        for robot in bundle.robots:
            session.add(RobotRecord(robot_id=robot.robot_id, robot_type=robot.robot_type.value, registered_at=now))

        await session.commit()

    await db.dispose()
    logger.info(
        "seeded %d zones, %d locations, %d conveyors, %d charging stations, %d robots",
        len(bundle.warehouse.zones), len(bundle.warehouse.all_locations()),
        len(bundle.warehouse.conveyors), len(bundle.warehouse.charging_stations), len(bundle.robots),
    )


if __name__ == "__main__":
    asyncio.run(seed())
