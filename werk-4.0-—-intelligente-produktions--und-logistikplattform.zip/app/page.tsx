'use client';

// ============================================================================
// WERK 4.0 — INDUSTRIELLE PRODUKTIONS- UND ROBOTIK-PLATTFORM
// Deutsches Automobilwerk 4.0 (Automobilwerk Süd — Werk 07)
// ============================================================================

import React, { useState, useEffect, useRef } from 'react';
import { FactorySimulationEngine, FactoryFullState } from '../lib/simulationEngine';
import { UserRole, RobotEntity, ProductionHallEntity, MachineEntity, ProductionOrderEntity } from '../lib/types';
import { ControlRoomHeader } from '../components/ControlRoomHeader';
import { KinematicsVisualizer } from '../components/KinematicsVisualizer';
import { FactoryPlanMap } from '../components/FactoryPlanMap';
import { WarehouseGrid } from '../components/WarehouseGrid';
import { MaterialFlowGraph } from '../components/MaterialFlowGraph';
import { SpcControlChart } from '../components/SpcControlChart';
import { TelemetryChart } from '../components/TelemetryChart';
import { EnergyLoadChart } from '../components/EnergyLoadChart';
import { RCodeExplorer } from '../components/RCodeExplorer';
import { ShiftReportModal } from '../components/ShiftReportModal';

import {
  LayoutDashboard,
  Factory,
  Cpu,
  Boxes,
  GitPullRequest,
  ShieldCheck,
  Wrench,
  Zap,
  Network,
  BarChart3,
  Terminal,
  Activity,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Layers,
  ChevronRight,
  TrendingUp,
  Sliders,
  Sparkles,
  Search,
  Eye
} from 'lucide-react';

type NavigationTab =
  | 'UEBERSICHT'
  | 'FABRIK'
  | 'PRODUKTION'
  | 'ROBOTIK'
  | 'LAGER'
  | 'MATERIALFLUSS'
  | 'QUALITAET'
  | 'WARTUNG'
  | 'ENERGIE'
  | 'DIGITAL_TWIN'
  | 'ANALYTIK'
  | 'R_CODE';

export default function Home() {
  const [engine] = useState(() => new FactorySimulationEngine());
  const [state, setState] = useState<FactoryFullState>(() => engine.getState());
  const [activeTab, setActiveTab] = useState<NavigationTab>('UEBERSICHT');
  const [emergencyStop, setEmergencyStop] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);

  // Selected Entities for Deep Inspection
  const [selectedRobotId, setSelectedRobotId] = useState<string>('ROB-017');
  const [selectedHallId, setSelectedHallId] = useState<string>('HALLE-02');
  const [selectedOrderId, setSelectedOrderId] = useState<string>('FA-2026-01842');
  const [orderSearchQuery, setOrderSearchQuery] = useState('');
  const [digitalTwinSearch, setDigitalTwinSearch] = useState('');

  // Subscribe to Simulation Engine Updates
  useEffect(() => {
    const unsub = engine.subscribe((newState) => {
      setState(newState);
    });

    return () => {
      unsub();
      engine.stop();
    };
  }, [engine]);

  // Handlers for Simulation Control
  const handleTogglePlay = () => {
    if (state.isRunning) {
      engine.pause();
    } else {
      engine.start();
    }
  };

  const handleStepTick = () => {
    engine.stepTick(1);
  };

  const handleReset = () => {
    engine.reset();
  };

  const handleChangeSpeed = (speed: number) => {
    engine.setTimeFactor(speed);
  };

  const handleChangeRole = (role: UserRole) => {
    engine.setUserRole(role);
  };

  const handleToggleEmergencyStop = () => {
    setEmergencyStop(!emergencyStop);
    if (!emergencyStop) {
      engine.pause();
    }
  };

  // Scenario Triggers
  const handleTriggerScenario1 = () => {
    engine.triggerScenario1();
    setActiveTab('PRODUKTION');
  };

  const handleAdvanceScenario1 = () => {
    engine.advanceScenario1Step();
  };

  const handleTriggerScenario2 = () => {
    engine.triggerScenario2();
    setActiveTab('WARTUNG');
  };

  const handleTriggerScenario3 = () => {
    engine.triggerScenario3();
    setActiveTab('LAGER');
  };

  const handleResetScenario = () => {
    engine.resetScenario();
  };

  const selectedRobot = state.robots.find((r) => r.id === selectedRobotId) || state.robots[0];
  const selectedHall = state.halls.find((h) => h.id === selectedHallId) || state.halls[0];

  const navigationTabs = [
    { id: 'UEBERSICHT' as const, label: 'ÜBERSICHT', icon: LayoutDashboard },
    { id: 'FABRIK' as const, label: 'FABRIK', icon: Factory },
    { id: 'PRODUKTION' as const, label: 'PRODUKTION', icon: Activity },
    { id: 'ROBOTIK' as const, label: 'ROBOTIK', icon: Cpu },
    { id: 'LAGER' as const, label: 'LAGER', icon: Boxes },
    { id: 'MATERIALFLUSS' as const, label: 'MATERIALFLUSS', icon: GitPullRequest },
    { id: 'QUALITAET' as const, label: 'QUALITÄT', icon: ShieldCheck },
    { id: 'WARTUNG' as const, label: 'WARTUNG', icon: Wrench },
    { id: 'ENERGIE' as const, label: 'ENERGIE', icon: Zap },
    { id: 'DIGITAL_TWIN' as const, label: 'DIGITALER ZWILLING', icon: Network },
    { id: 'ANALYTIK' as const, label: 'ANALYTIK', icon: BarChart3 },
    { id: 'R_CODE' as const, label: 'R-KERN & EXPORT', icon: Terminal },
  ];

  return (
    <div className="min-h-screen bg-[#070a0f] text-[#e6edf3] flex flex-col selection:bg-[#0284c7] selection:text-white">
      {/* Sticky Header with Controls */}
      <ControlRoomHeader
        state={state}
        onTogglePlay={handleTogglePlay}
        onStepTick={handleStepTick}
        onReset={handleReset}
        onChangeSpeed={handleChangeSpeed}
        onChangeRole={handleChangeRole}
        onTriggerScenario1={handleTriggerScenario1}
        onAdvanceScenario1={handleAdvanceScenario1}
        onTriggerScenario2={handleTriggerScenario2}
        onTriggerScenario3={handleTriggerScenario3}
        onResetScenario={handleResetScenario}
        onOpenReport={() => setShowReportModal(true)}
        emergencyStop={emergencyStop}
        onToggleEmergencyStop={handleToggleEmergencyStop}
      />

      {/* Primary Navigation Tabs */}
      <nav className="bg-[#090d13] border-b border-[#21262d] px-4 overflow-x-auto flex items-center gap-1 font-mono text-xs select-none">
        {navigationTabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-3.5 py-2.5 border-b-2 font-semibold whitespace-nowrap transition-all ${
                isActive
                  ? 'border-[#38bdf8] text-[#38bdf8] bg-[#161b22]'
                  : 'border-transparent text-[#8b949e] hover:text-[#f0f6fc] hover:bg-[#161b22]/50'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Main Content Viewport */}
      <main className="flex-1 p-4 max-w-[1700px] w-full mx-auto space-y-4">
        {/* ================================================================ */}
        {/* TAB 1: ÜBERSICHT (Master Control Room Dashboard) */}
        {/* ================================================================ */}
        {activeTab === 'UEBERSICHT' && (
          <div className="space-y-4">
            {/* Top KPI Metric Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-6 gap-3 font-mono text-xs">
              <div className="bg-[#0d1117] border border-[#21262d] p-3">
                <div className="text-[10px] text-[#8b949e] uppercase">OEE GESAMTWIRKUNGSGRAD:</div>
                <div className="text-xl font-bold text-[#f0f6fc] mt-1">{state.kpis.overallOee} %</div>
                <div className="text-[10px] text-[#7ee787] mt-0.5">V: 94.2% | L: 98.1% | Q: {state.kpis.qualityFirstPassYieldPercent}%</div>
              </div>

              <div className="bg-[#0d1117] border border-[#21262d] p-3">
                <div className="text-[10px] text-[#8b949e] uppercase">PRODUKTION / SOLL:</div>
                <div className="text-xl font-bold text-[#38bdf8] mt-1">
                  {state.kpis.completedOrdersCount} / 30
                </div>
                <div className="text-[10px] text-[#8b949e] mt-0.5">Fahrzeuge heute</div>
              </div>

              <div className="bg-[#0d1117] border border-[#21262d] p-3">
                <div className="text-[10px] text-[#8b949e] uppercase">TAKTZEIT DURCHSCHNITT:</div>
                <div className="text-xl font-bold text-[#f0f6fc] mt-1">58.4 s</div>
                <div className="text-[10px] text-[#facc15] mt-0.5">Soll: 58.0 s (+0.4 s)</div>
              </div>

              <div className="bg-[#0d1117] border border-[#21262d] p-3">
                <div className="text-[10px] text-[#8b949e] uppercase">ROBOTER IM EINSATZ:</div>
                <div className="text-xl font-bold text-[#4ade80] mt-1">
                  {state.kpis.activeRobotsCount} / {state.kpis.totalRobotsCount}
                </div>
                <div className="text-[10px] text-[#8b949e] mt-0.5">60 KUKA KR QUANTEC</div>
              </div>

              <div className="bg-[#0d1117] border border-[#21262d] p-3">
                <div className="text-[10px] text-[#8b949e] uppercase">QUALITÄT FIRST-PASS-YIELD:</div>
                <div className="text-xl font-bold text-[#7ee787] mt-1">{state.kpis.qualityFirstPassYieldPercent} %</div>
                <div className="text-[10px] text-[#8b949e] mt-0.5">Ausschuss: 12.5 PPM</div>
              </div>

              <div className="bg-[#0d1117] border border-[#21262d] p-3">
                <div className="text-[10px] text-[#8b949e] uppercase">GESAMTLEISTUNG ELEKTRISCH:</div>
                <div className="text-xl font-bold text-[#facc15] mt-1">{state.kpis.totalPowerMw} MW</div>
                <div className="text-[10px] text-[#8b949e] mt-0.5">Max Vertrag: 22.0 MW</div>
              </div>
            </div>

            {/* Schematic Factory Floor Plan Map */}
            <FactoryPlanMap
              state={state}
              onSelectRobot={(rob) => {
                setSelectedRobotId(rob.id);
                setActiveTab('ROBOTIK');
              }}
              onSelectHall={(hall) => {
                setSelectedHallId(hall.id);
                setActiveTab('FABRIK');
              }}
            />

            {/* Bottom Row: Live Event Log & Real-time Material Flow Preview */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
              {/* Event Log */}
              <div className="lg:col-span-6 bg-[#0d1117] border border-[#21262d] p-3 text-xs font-mono">
                <div className="flex justify-between items-center pb-2 border-b border-[#21262d]">
                  <span className="font-bold text-[#f0f6fc] flex items-center gap-1.5">
                    <Activity className="w-3.5 h-3.5 text-[#38bdf8]" />
                    LEITSTAND-EREIGNISPROTOKOLL (LIVE TICKER)
                  </span>
                  <span className="text-[10px] text-[#8b949e]">{state.events.length} EREIGNISSE</span>
                </div>
                <div className="mt-2 space-y-1.5 max-h-[220px] overflow-y-auto">
                  {state.events.slice(0, 10).map((ev) => (
                    <div
                      key={ev.eventId}
                      className="p-1.5 bg-[#161b22] border border-[#30363d] flex items-start gap-2"
                    >
                      <span className="text-[10px] text-[#8b949e] shrink-0">{ev.timestamp}</span>
                      <span className={`px-1 text-[9px] font-bold shrink-0 ${
                        ev.severity === 'CRITICAL'
                          ? 'bg-[#7f1d1d] text-[#fca5a5]'
                          : ev.severity === 'WARNING'
                          ? 'bg-[#78350f] text-[#fde047]'
                          : 'bg-[#065f46] text-[#6ee7b7]'
                      }`}>
                        {ev.severity}
                      </span>
                      <div className="flex-1">
                        <span className="font-bold text-[#f0f6fc] mr-1">[{ev.location}]</span>
                        <span className="text-[#c9d1d9]">{ev.message}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Quick Scenario Status & Production Highlights */}
              <div className="lg:col-span-6 bg-[#0d1117] border border-[#21262d] p-3 text-xs font-mono space-y-2">
                <div className="flex justify-between items-center pb-2 border-b border-[#21262d]">
                  <span className="font-bold text-[#f0f6fc] flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-[#eab308]" />
                    DEMO-SZENARIEN SCHNELLSTART & STATUS
                  </span>
                </div>

                <div className="space-y-2 text-[11px]">
                  <div className="p-2 bg-[#161b22] border border-[#30363d] flex justify-between items-center">
                    <div>
                      <div className="font-bold text-[#38bdf8]">1. E-Auto Fertigungsdurchlauf FA-2026-01842</div>
                      <div className="text-[10px] text-[#8b949e]">Presse → Zelle K-07 → Lack → Batterie → Hochzeit → EOL</div>
                    </div>
                    <button
                      onClick={handleTriggerScenario1}
                      className="px-2.5 py-1 bg-[#0284c7] hover:bg-[#0369a1] text-white text-[10px] font-bold"
                    >
                      STARTEN
                    </button>
                  </div>

                  <div className="p-2 bg-[#161b22] border border-[#30363d] flex justify-between items-center">
                    <div>
                      <div className="font-bold text-[#f59e0b]">2. Roboter-Ausfall ROB-042 Predictive Failure</div>
                      <div className="text-[10px] text-[#8b949e]">Vibrationsalarm (4.85 mm/s) → Umleitung auf ROB-041/043</div>
                    </div>
                    <button
                      onClick={handleTriggerScenario2}
                      className="px-2.5 py-1 bg-[#b45309] hover:bg-[#d97706] text-white text-[10px] font-bold"
                    >
                      STARTEN
                    </button>
                  </div>

                  <div className="p-2 bg-[#161b22] border border-[#30363d] flex justify-between items-center">
                    <div>
                      <div className="font-bold text-[#818cf8]">3. Hochregallager-Engpass Gang B (95%)</div>
                      <div className="text-[10px] text-[#8b949e]">lpSolve Slotting-Optimierung & AGV-Umleitung auf Gang C/D</div>
                    </div>
                    <button
                      onClick={handleTriggerScenario3}
                      className="px-2.5 py-1 bg-[#4338ca] hover:bg-[#4f46e5] text-white text-[10px] font-bold"
                    >
                      STARTEN
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ================================================================ */}
        {/* TAB 2: FABRIK (Hierarchical Hall & Machine Explorer) */}
        {/* ================================================================ */}
        {activeTab === 'FABRIK' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-5 gap-3 font-mono text-xs">
              {state.halls.map((h) => {
                const isSelected = selectedHallId === h.id;
                return (
                  <button
                    key={h.id}
                    onClick={() => setSelectedHallId(h.id)}
                    className={`p-3 border text-left transition-all ${
                      isSelected
                        ? 'bg-[#1e293b] border-[#38bdf8] text-white shadow-md'
                        : 'bg-[#0d1117] border-[#21262d] text-[#8b949e] hover:bg-[#161b22]'
                    }`}
                  >
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-[#f0f6fc]">{h.code}</span>
                      <span className="text-[10px] text-[#7ee787] font-bold">{h.totalPowerMw} MW</span>
                    </div>
                    <div className="text-xs font-semibold text-[#38bdf8] mt-1">{h.name.split('—')[1] || h.name}</div>
                    <div className="text-[10px] text-[#8b949e] mt-2">
                      {h.lines.length} Linien | {h.temperature}°C | {h.humidity}% rF
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Selected Hall Detailed Breakdown */}
            <div className="bg-[#0d1117] border border-[#21262d] p-4 font-mono text-xs space-y-4">
              <div className="flex justify-between items-center pb-3 border-b border-[#21262d]">
                <div>
                  <div className="text-base font-bold text-[#f0f6fc]">{selectedHall.name}</div>
                  <div className="text-[11px] text-[#8b949e]">
                    Fläche: {selectedHall.areaSqm} m² | Sicherheit: SICHER (SIL-3) | Leistung: {selectedHall.totalPowerMw} MW
                  </div>
                </div>
                <div className="flex gap-2">
                  <span className="px-2 py-1 bg-[#161b22] border border-[#30363d] text-[#7ee787]">
                    Klima: {selectedHall.temperature}°C / {selectedHall.humidity}% rF
                  </span>
                  <span className="px-2 py-1 bg-[#065f46] text-[#6ee7b7] border border-[#10b981]">
                    SICHER (SIL-3)
                  </span>
                </div>
              </div>

              {/* Lines in Hall */}
              <div className="space-y-3">
                <div className="font-bold text-[#38bdf8]">PRODUKTIONSLINIEN IN DIESER HALLE:</div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {selectedHall.lines.map((lineId) => {
                    const line = state.lines.find((l) => l.id === lineId) || {
                      id: lineId,
                      name: lineId,
                      oee: 88,
                      actualTakt: 58,
                      throughputPerHour: 55,
                      robots: [],
                      machines: [],
                    };
                    return (
                      <div key={line.id} className="bg-[#161b22] border border-[#30363d] p-3 space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="font-bold text-[#f0f6fc]">{line.name}</span>
                          <span className="text-[10px] text-[#4ade80] font-bold">OEE: {line.oee}%</span>
                        </div>
                        <div className="text-[10px] text-[#8b949e]">
                          Taktzeit: {line.actualTakt} s | Ausbringung: {line.throughputPerHour} Fzg/h
                        </div>

                        {/* Workcells in line */}
                        <div className="pt-2 border-t border-[#30363d] space-y-1">
                          <div className="text-[10px] text-[#64748b] font-bold">ROBOTER & MASCHINEN:</div>
                          <div className="p-1 bg-[#0d1117] border border-[#21262d] text-[10px] flex justify-between">
                            <span className="text-[#c9d1d9]">{line.robots.join(', ') || 'Roboter-Zellen'}</span>
                            <span className="text-[#38bdf8] font-bold">{line.robots.length} Einheiten</span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ================================================================ */}
        {/* TAB 3: PRODUKTION (Taktzeit Monitor, OEE & 100 Orders) */}
        {/* ================================================================ */}
        {activeTab === 'PRODUKTION' && (
          <div className="space-y-4">
            {/* OEE Cascade Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
              <div className="bg-[#0d1117] border border-[#21262d] p-3">
                <div className="text-[10px] text-[#8b949e]">OEE GESAMTWIRKUNGSGRAD:</div>
                <div className="text-xl font-bold text-[#38bdf8] mt-1">{state.kpis.overallOee} %</div>
                <div className="text-[9px] text-[#8b949e] mt-1">Ziel: &ge; 85.0% (Automotive Benchmark)</div>
              </div>

              <div className="bg-[#0d1117] border border-[#21262d] p-3">
                <div className="text-[10px] text-[#8b949e]">VERFÜGBARKEIT (A):</div>
                <div className="text-xl font-bold text-[#4ade80] mt-1">94.2 %</div>
                <div className="text-[9px] text-[#8b949e] mt-1">Betriebszeit / Planzeit</div>
              </div>

              <div className="bg-[#0d1117] border border-[#21262d] p-3">
                <div className="text-[10px] text-[#8b949e]">LEISTUNGSGRAD (P):</div>
                <div className="text-xl font-bold text-[#facc15] mt-1">98.1 %</div>
                <div className="text-[9px] text-[#8b949e] mt-1">Ist-Ausbringung / Soll-Ausbringung</div>
              </div>

              <div className="bg-[#0d1117] border border-[#21262d] p-3">
                <div className="text-[10px] text-[#8b949e]">QUALITÄTSRATE (Q):</div>
                <div className="text-xl font-bold text-[#7ee787] mt-1">{state.kpis.qualityFirstPassYieldPercent} %</div>
                <div className="text-[9px] text-[#8b949e] mt-1">Gutmenge / Gesamtmenge</div>
              </div>
            </div>

            {/* Production Orders Explorer (100 Orders) */}
            <div className="bg-[#0d1117] border border-[#21262d] p-4 font-mono text-xs space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-[#21262d]">
                <div>
                  <span className="font-bold text-sm text-[#f0f6fc]">
                    PRODUKTIONSAUFTRÄGE (100 AKTIVE FAHRZEUGAUFTRÄGE)
                  </span>
                  <div className="text-[11px] text-[#8b949e]">
                    Vollständige Traceability: Karosserie-, Antriebs-, Lack- und Ausstattungsstatus
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Search className="w-3.5 h-3.5 text-[#8b949e]" />
                  <input
                    type="text"
                    placeholder="Auftrags-Nr. oder Modell suchen..."
                    value={orderSearchQuery}
                    onChange={(e) => setOrderSearchQuery(e.target.value)}
                    className="bg-[#161b22] border border-[#30363d] px-2 py-1 text-xs text-[#f0f6fc] focus:outline-none"
                  />
                </div>
              </div>

              {/* Order Table */}
              <div className="border border-[#21262d] max-h-[380px] overflow-y-auto">
                <table className="w-full text-left">
                  <thead className="bg-[#161b22] sticky top-0 text-[11px] text-[#8b949e] border-b border-[#30363d]">
                    <tr>
                      <th className="p-2">AUFTRAGS-ID</th>
                      <th className="p-2">FAHRZEUGMODELL</th>
                      <th className="p-2">VIN / IDENT-NR.</th>
                      <th className="p-2">BATTERIE</th>
                      <th className="p-2">STATUS</th>
                      <th className="p-2">STATION</th>
                      <th className="p-2">FORTSCHRITT</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#21262d] text-[11px]">
                    {state.orders
                      .filter((o) =>
                        orderSearchQuery
                          ? o.orderId.toLowerCase().includes(orderSearchQuery.toLowerCase()) ||
                            o.model.toLowerCase().includes(orderSearchQuery.toLowerCase()) ||
                            o.vin.toLowerCase().includes(orderSearchQuery.toLowerCase())
                          : true
                      )
                      .slice(0, 30)
                      .map((ord) => {
                        const isSelected = selectedOrderId === ord.orderId;
                        const isDemoOrder = ord.orderId === 'FA-2026-01842';

                        return (
                          <tr
                            key={ord.orderId}
                            onClick={() => setSelectedOrderId(ord.orderId)}
                            className={`cursor-pointer transition-colors ${
                              isDemoOrder
                                ? 'bg-[#0369a1]/20 hover:bg-[#0369a1]/40 border-l-2 border-[#38bdf8]'
                                : isSelected
                                ? 'bg-[#1e293b]'
                                : 'hover:bg-[#161b22]'
                            }`}
                          >
                            <td className="p-2 font-bold text-[#38bdf8] flex items-center gap-1.5">
                              {isDemoOrder && <Sparkles className="w-3 h-3 text-[#eab308]" />}
                              {ord.orderId}
                            </td>
                            <td className="p-2 font-semibold text-[#f0f6fc]">{ord.model}</td>
                            <td className="p-2 font-mono text-[#c9d1d9]">{ord.vin}</td>
                            <td className="p-2 text-[#94a3b8]">800V 100 kWh</td>
                            <td className="p-2">
                              <span className={`px-1.5 py-0.5 text-[10px] font-bold ${
                                ord.status === 'COMPLETED'
                                  ? 'bg-[#065f46] text-[#6ee7b7]'
                                  : ord.status === 'IN_PRODUCTION'
                                  ? 'bg-[#0284c7] text-white'
                                  : ord.status === 'QUALITY_HOLD'
                                  ? 'bg-[#78350f] text-[#fde047]'
                                  : 'bg-[#1e293b] text-[#94a3b8]'
                              }`}>
                                {ord.status === 'COMPLETED' ? 'FERTIG' : ord.status === 'IN_PRODUCTION' ? 'IN PRODUKTION' : ord.status}
                              </span>
                            </td>
                            <td className="p-2 text-[#f0f6fc]">{ord.currentStage}</td>
                            <td className="p-2">
                              <div className="flex items-center gap-2">
                                <div className="w-20 bg-[#0d1117] h-1.5 border border-[#30363d]">
                                  <div className="bg-[#0284c7] h-full" style={{ width: `${ord.progressPercent}%` }} />
                                </div>
                                <span className="text-[10px] text-[#8b949e]">{Math.round(ord.progressPercent)}%</span>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ================================================================ */}
        {/* TAB 4: ROBOTIK (6-Achs-Kinematik & Roboter-Leitstelle) */}
        {/* ================================================================ */}
        {activeTab === 'ROBOTIK' && (
          <div className="space-y-4">
            {/* Robot Selection Bar */}
            <div className="bg-[#0d1117] border border-[#21262d] p-3 flex items-center gap-2 overflow-x-auto font-mono text-xs">
              <span className="text-[10px] text-[#8b949e] uppercase font-bold shrink-0">ROBOTER WÄHLEN:</span>
              {state.robots.slice(0, 20).map((rob) => {
                const isSelected = selectedRobotId === rob.id;
                return (
                  <button
                    key={rob.id}
                    onClick={() => setSelectedRobotId(rob.id)}
                    className={`px-2.5 py-1 border whitespace-nowrap transition-all ${
                      isSelected
                        ? 'bg-[#0284c7] text-white border-[#38bdf8] font-bold shadow-md'
                        : rob.id === 'ROB-042'
                        ? 'bg-[#78350f] text-[#fde047] border-[#f59e0b]'
                        : 'bg-[#161b22] text-[#8b949e] border-[#30363d] hover:text-[#f0f6fc]'
                    }`}
                  >
                    {rob.id} ({rob.tool ? rob.tool.split(' ')[0] : 'Werkzeug'})
                  </button>
                );
              })}
            </div>

            {/* 6-Axis Kinematics Visualizer & DH-Calculator */}
            <KinematicsVisualizer
              robot={selectedRobot}
              onUpdateJoints={(j) => {
                // updates kinematics
              }}
            />
          </div>
        )}

        {/* ================================================================ */}
        {/* TAB 5: LAGER (Hochregallager Digital Twin 250 Bins) */}
        {/* ================================================================ */}
        {activeTab === 'LAGER' && (
          <div className="space-y-4">
            <WarehouseGrid
              bins={state.warehouse}
              onTriggerOptimization={handleTriggerScenario3}
            />
          </div>
        )}

        {/* ================================================================ */}
        {/* TAB 6: MATERIALFLUSS (igraph Topologie & Engpass-Analyse) */}
        {/* ================================================================ */}
        {activeTab === 'MATERIALFLUSS' && (
          <div className="space-y-4">
            <MaterialFlowGraph state={state} />
          </div>
        )}

        {/* ================================================================ */}
        {/* TAB 7: QUALITÄT (SPC Shewhart-Karten & Machine Vision) */}
        {/* ================================================================ */}
        {activeTab === 'QUALITAET' && (
          <div className="space-y-4">
            <SpcControlChart measurements={state.qualityEvents} />
          </div>
        )}

        {/* ================================================================ */}
        {/* TAB 8: WARTUNG (Predictive Maintenance Leitstand) */}
        {/* ================================================================ */}
        {activeTab === 'WARTUNG' && (
          <div className="space-y-4">
            <TelemetryChart
              robots={state.robots}
              onTriggerReroute={() => {
                engine.triggerScenario2();
              }}
            />
          </div>
        )}

        {/* ================================================================ */}
        {/* TAB 9: ENERGIE (Energie-Digital-Twin & Peak Shaving) */}
        {/* ================================================================ */}
        {activeTab === 'ENERGIE' && (
          <div className="space-y-4">
            <EnergyLoadChart
              energyData={{
                currentTotalLoadMW: state.kpis.totalPowerMw,
                kwhPerVehicle: 420.5,
                costPerVehicleEur: 92.51,
                co2PerVehicleKg: 64.2,
                renewablePercentage: 74.0,
                transformerLoadPercent: 78.4,
                peakShavingPotentialMW: 2.4,
              }}
            />
          </div>
        )}

        {/* ================================================================ */}
        {/* TAB 10: DIGITALER ZWILLING (Vollständige Werk-Hierarchie) */}
        {/* ================================================================ */}
        {activeTab === 'DIGITAL_TWIN' && (
          <div className="bg-[#0d1117] border border-[#21262d] p-4 text-[#e6edf3] font-mono text-xs space-y-4">
            <div className="flex justify-between items-center pb-3 border-b border-[#21262d]">
              <div>
                <span className="font-bold text-sm text-[#f0f6fc]">
                  DIGITALER ZWILLING — SYSTEM-HIERARCHIE-INSPEKTOR
                </span>
                <div className="text-[11px] text-[#8b949e]">
                  WERK 07 → 5 HALLEN → 12 LINIEN → 36 ZELLEN → 40 MASCHINEN → 60 ROBOTER → 100 WERKSTÜCKE
                </div>
              </div>
            </div>

            {/* Hierarchical Tree View */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
              <div className="lg:col-span-6 bg-[#070a0f] border border-[#21262d] p-3 max-h-[500px] overflow-y-auto space-y-2">
                <div className="font-bold text-[#38bdf8] flex items-center gap-1.5">
                  <Network className="w-4 h-4" />
                  WERK 07 — AUTOMOBILWERK SÜD (DEUTSCHLAND)
                </div>

                {state.halls.map((hall) => (
                  <div key={hall.id} className="pl-4 border-l border-[#30363d] space-y-1.5">
                    <div className="font-bold text-[#f0f6fc] flex items-center gap-1">
                      <ChevronRight className="w-3 h-3 text-[#38bdf8]" />
                      {hall.name} ({hall.totalPowerMw} MW)
                    </div>

                    {hall.lines.map((lineId) => {
                      const line = state.lines.find((l) => l.id === lineId);
                      return (
                        <div key={lineId} className="pl-4 border-l border-[#30363d] space-y-1">
                          <div className="text-[#93c5fd] font-semibold flex items-center gap-1">
                            <ChevronRight className="w-3 h-3 text-[#93c5fd]" />
                            {line?.name || lineId} (Takt: {line?.actualTakt || 58}s | OEE: {line?.oee || 88}%)
                          </div>
                          <div className="pl-4 border-l border-[#21262d] text-[11px] text-[#8b949e]">
                            • Roboter: {line?.robots?.join(', ') || 'ROB-001 ...'}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ))}
              </div>

              {/* Digital Twin State Inspector */}
              <div className="lg:col-span-6 bg-[#161b22] border border-[#30363d] p-4 space-y-3">
                <div className="font-bold text-[#f0f6fc] pb-2 border-b border-[#30363d]">
                  ECHTZEIT-ZUSTANDS-SNAPSHOT (DIGITAL TWIN TELEMETRIE)
                </div>

                <div className="space-y-2 text-[11px]">
                  <div className="p-2 bg-[#0d1117] border border-[#30363d]">
                    <span className="text-[#8b949e]">SIMULATIONS-ZEITSTEMPEL:</span>
                    <div className="text-[#38bdf8] font-bold text-sm">{state.timeFormatted} (Sekunde {state.simTimeSeconds})</div>
                  </div>

                  <div className="p-2 bg-[#0d1117] border border-[#30363d]">
                    <span className="text-[#8b949e]">SYNCHRONISATIONSSTATUS R-KERN:</span>
                    <div className="text-[#4ade80] font-bold">100% DETERMINISTISCH / SYNC OK</div>
                  </div>

                  <div className="p-2 bg-[#0d1117] border border-[#30363d]">
                    <span className="text-[#8b949e]">DATENMODELL-KONSISTENZ:</span>
                    <div className="text-[#c9d1d9]">
                      • 60 Roboter-Kinematiken aktiv<br />
                      • 250 Lagerplätze indexiert (lpSolve)<br />
                      • 22 FTS-Routen kollisionsfrei<br />
                      • VDA 6.3 SPC Prüfprotokoll aktiv
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ================================================================ */}
        {/* TAB 11: ANALYTIK (Statistik & Forecast-Modelle) */}
        {/* ================================================================ */}
        {activeTab === 'ANALYTIK' && (
          <div className="bg-[#0d1117] border border-[#21262d] p-4 text-[#e6edf3] font-mono text-xs space-y-4">
            <div className="flex justify-between items-center pb-3 border-b border-[#21262d]">
              <div>
                <span className="font-bold text-sm text-[#f0f6fc]">
                  STATISTIK-, PROGNOSE- & OEE-FORECAST-MODELLE (ARIMA / FABLE)
                </span>
                <div className="text-[11px] text-[#8b949e]">
                  Produktionsprognose nächste 7 Tage mit 80% / 95% Konfidenzintervall
                </div>
              </div>
            </div>

            {/* Forecast Chart */}
            <div className="bg-[#070a0f] border border-[#21262d] p-3">
              <div className="text-xs font-bold text-[#f0f6fc] mb-2">
                PRODUKTIONSVOLUMEN-FORECAST (FAHRZEUGE / TAG)
              </div>
              <div className="grid grid-cols-7 gap-2">
                {['Mo', 'Di (Heute)', 'Mi (Prog.)', 'Do (Prog.)', 'Fr (Prog.)', 'Sa (Prog.)', 'So (Wartung)'].map((day, i) => {
                  const val = i === 0 ? 840 : i === 1 ? 874 : i === 2 ? 882 : i === 3 ? 890 : i === 4 ? 865 : i === 5 ? 420 : 0;
                  return (
                    <div key={day} className="bg-[#161b22] border border-[#30363d] p-2 text-center">
                      <div className="text-[10px] text-[#8b949e]">{day}</div>
                      <div className="text-sm font-bold text-[#38bdf8] mt-1">{val}</div>
                      <div className="text-[9px] text-[#64748b]">Fzg/Tag</div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* ================================================================ */}
        {/* TAB 12: R-CODE & KONSOLE */}
        {/* ================================================================ */}
        {activeTab === 'R_CODE' && (
          <div className="space-y-4">
            <RCodeExplorer />
          </div>
        )}
      </main>

      {/* Printable VDA 6.3 Shift Report Modal */}
      {showReportModal && (
        <ShiftReportModal
          state={state}
          onClose={() => setShowReportModal(false)}
        />
      )}
    </div>
  );
}
