import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'WERK 4.0 — Intelligente Produktions- und Logistikplattform | WERK40-R',
  description: 'Deutsches industrielles Softwaresystem für Automobilfabrik, Robotik-Simulation, Hochregallager, Predictive Maintenance und Digitalen Zwilling.',
  openGraph: {
    title: 'WERK 4.0 — Intelligente Produktions- und Logistikplattform',
    description: 'Deutsches industrielles Softwaresystem für Automobilfabrik, Robotik-Simulation, Hochregallager, Predictive Maintenance und Digitalen Zwilling.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'WERK 4.0 — Intelligente Produktions- und Logistikplattform',
    description: 'Deutsches industrielles Softwaresystem für Automobilfabrik, Robotik-Simulation, Hochregallager, Predictive Maintenance und Digitalen Zwilling.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="de">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
