// ============================================================================
// WERK 4.0 — R CODEBASE REPOSITORY & SIMULATED R EXECUTION ENGINE
// Vollständige R-Architektur (R6, data.table, dplyr, ggplot2, igraph, lpSolve, RSQLite)
// ============================================================================

export interface RFileDefinition {
  path: string;
  category: 'CORE' | 'MODULES' | 'DATA' | 'TESTS' | 'CONFIG' | 'DOCKER';
  description: string;
  content: string;
}

export const R_CODEBASE: RFileDefinition[] = [
  {
    path: 'werk40/app.R',
    category: 'CORE',
    description: 'Shiny Hauptanwendung & bslib Dark-Industrial Theme Initialisierung',
    content: `#!/usr/bin/env Rscript
# ==============================================================================
# WERK 4.0 — INTELLIGENTE PRODUKTIONS- UND LOGISTIKPLATTFORM (WERK40-R)
# Claim: DIE FABRIK WIRD ZUM DATENMODELL.
# ==============================================================================

library(shiny)
library(bslib)
library(data.table)
library(dplyr)
library(ggplot2)
library(plotly)
library(DT)
library(R6)
library(igraph)
library(RSQLite)
library(DBI)
library(lpSolve)

# Module und Subsysteme laden
source("R/factory_state.R")
source("R/robot_kinematics.R")
source("R/simulation.R")
source("R/scheduler.R")
source("R/warehouse.R")
source("R/AGV.R")
source("R/quality.R")
source("R/maintenance.R")
source("R/energy.R")
source("R/digital_twin.R")
source("R/optimisation.R")
source("R/reporting.R")

source("modules/mod_overview.R")
source("modules/mod_factory.R")
source("modules/mod_production.R")
source("modules/mod_robotics.R")
source("modules/mod_warehouse.R")
source("modules/mod_material_flow.R")
source("modules/mod_quality.R")
source("modules/mod_maintenance.R")
source("modules/mod_energy.R")
source("modules/mod_digital_twin.R")
source("modules/mod_analytics.R")

# Deutsches Industrie-Theme (Anthrazit / Stahlgrau / DIN-Akzente)
industrial_theme <- bs_theme(
  version = 5,
  bg = "#0d1117",
  fg = "#f0f6fc",
  primary = "#0284c7",
  secondary = "#30363d",
  success = "#16a34a",
  warning = "#d97706",
  danger = "#dc2626",
  base_font = font_google("JetBrains Mono"),
  heading_font = font_google("Inter")
)

ui <- page_navbar(
  title = div(
    span(class = "fw-bold tracking-wider", "WERK 4.0"),
    span(class = "badge bg-secondary ms-2 text-xs", "AUTOMOBILWERK SÜD — WERK 07")
  ),
  theme = industrial_theme,
  id = "main_nav",
  
  nav_panel("ÜBERSICHT", mod_overview_ui("overview")),
  nav_panel("FABRIK", mod_factory_ui("factory")),
  nav_panel("PRODUKTION", mod_production_ui("production")),
  nav_panel("ROBOTIK", mod_robotics_ui("robotics")),
  nav_panel("LAGER", mod_warehouse_ui("warehouse")),
  nav_panel("MATERIALFLUSS", mod_material_flow_ui("material_flow")),
  nav_panel("QUALITÄT", mod_quality_ui("quality")),
  nav_panel("WARTUNG", mod_maintenance_ui("maintenance")),
  nav_panel("ENERGIE", mod_energy_ui("energy")),
  nav_panel("DIGITALER ZWILLING", mod_digital_twin_ui("digital_twin")),
  nav_panel("ANALYTIK", mod_analytics_ui("analytics"))
)

server <- function(input, output, session) {
  # Zentraler reaktiver Simulationszustand
  sim_engine <- FactorySimulation$new(seed = 42)
  factory_r <- reactiveVal(sim_engine$get_state())
  
  # Simulations-Ticker (500 ms = 1 Tick)
  observe({
    invalidateLater(500, session)
    isolate({
      if (sim_engine$is_running) {
        sim_engine$tick(dt = 1.0)
        factory_r(sim_engine$get_state())
      }
    })
  })
  
  # Modul-Server instanziieren
  mod_overview_server("overview", factory_r, sim_engine)
  mod_factory_server("factory", factory_r)
  mod_production_server("production", factory_r, sim_engine)
  mod_robotics_server("robotics", factory_r, sim_engine)
  mod_warehouse_server("warehouse", factory_r, sim_engine)
  mod_material_flow_server("material_flow", factory_r)
  mod_quality_server("quality", factory_r)
  mod_maintenance_server("maintenance", factory_r, sim_engine)
  mod_energy_server("energy", factory_r, sim_engine)
  mod_digital_twin_server("digital_twin", factory_r)
  mod_analytics_server("analytics", factory_r)
}

shinyApp(ui, server)`
  },
  {
    path: 'werk40/R/robot_kinematics.R',
    category: 'CORE',
    description: '6-Achs DH-Kinematik, Vorwärtskinematik, Numerische Inverse Kinematik & Bahnplanung',
    content: `# ==============================================================================
# 6-ACHS-ROBOTER-KINEMATIK (R6 MODELL FÜR KUKA KR QUANTEC PRIME)
# ==============================================================================

library(R6)

RobotKinematics <- R6Class("RobotKinematics",
  public = list(
    dh_table = NULL,
    
    initialize = function() {
      # Standard KUKA KR 210 R2700 prime Denavit-Hartenberg Parameter
      # [a (mm), alpha (rad), d (mm), theta_offset (rad)]
      self$dh_table <- list(
        j1 = list(a = 350,  alpha = -pi/2, d = 675,  offset = 0,      min_deg = -185, max_deg = 185),
        j2 = list(a = 1150, alpha = 0,     d = 0,    offset = -pi/2,  min_deg = -140, max_deg = -5),
        j3 = list(a = 115,  alpha = -pi/2, d = 0,    offset = 0,      min_deg = -120, max_deg = 168),
        j4 = list(a = 0,    alpha = pi/2,  d = 1220, offset = 0,      min_deg = -350, max_deg = 350),
        j5 = list(a = 0,    alpha = -pi/2, d = 0,    offset = 0,      min_deg = -125, max_deg = 125),
        j6 = list(a = 0,    alpha = 0,     d = 215,  offset = pi,     min_deg = -350, max_deg = 350)
      )
    },
    
    dh_matrix = function(a, alpha, d, theta) {
      ct <- cos(theta)
      st <- sin(theta)
      ca <- cos(alpha)
      sa <- sin(alpha)
      
      matrix(c(
        ct,  -st * ca,  st * sa, a * ct,
        st,   ct * ca, -ct * sa, a * st,
        0,    sa,       ca,      d,
        0,    0,        0,       1
      ), nrow = 4, byrow = TRUE)
    },
    
    forward_kinematics = function(joints_deg) {
      q_rad <- joints_deg * (pi / 180)
      T_curr <- diag(4)
      joint_pos <- matrix(0, nrow = 7, ncol = 3)
      
      for (i in 1:6) {
        param <- self$dh_table[[i]]
        theta <- q_rad[i] + param$offset
        T_i <- self$dh_matrix(param$a, param$alpha, param$d, theta)
        T_curr <- T_curr %*% T_i
        joint_pos[i + 1, ] <- T_curr[1:3, 4]
      }
      
      end_effector <- T_curr[1:3, 4]
      # Roll-Pitch-Yaw
      pitch <- atan2(-T_curr[3,1], sqrt(T_curr[1,1]^2 + T_curr[2,1]^2)) * (180/pi)
      roll  <- atan2(T_curr[3,2], T_curr[3,3]) * (180/pi)
      yaw   <- atan2(T_curr[2,1], T_curr[1,1]) * (180/pi)
      
      list(
        position = end_effector,
        orientation = c(roll = roll, pitch = pitch, yaw = yaw),
        joint_positions = joint_pos,
        T = T_curr
      )
    },
    
    inverse_kinematics = function(target_pos, current_joints, max_iter = 30, tol = 1.0) {
      q <- current_joints
      for (iter in 1:max_iter) {
        fk <- self$forward_kinematics(q)
        diff <- target_pos - fk$position
        dist <- sqrt(sum(diff^2))
        if (dist <= tol) break
        
        # Damped Least Squares / CCD Korrekturschritt
        target_yaw <- atan2(target_pos[2], target_pos[1]) * (180/pi)
        q[1] <- q[1] + 0.2 * (target_yaw - q[1])
        
        r_dist <- sqrt(target_pos[1]^2 + target_pos[2]^2)
        z_dist <- target_pos[3] - 675
        
        q[2] <- max(-130, min(-10, q[2] + (z_dist * 0.02 - (r_dist - 1500) * 0.015) * 0.1))
        q[3] <- max(-90, min(110, q[3] + ((r_dist - 1800) * 0.02 + z_dist * 0.01) * 0.1))
        q[5] <- - (q[2] + q[3])
      }
      list(joints = q, position = fk$position, error = dist)
    }
  )
)`
  },
  {
    path: 'werk40/R/simulation.R',
    category: 'CORE',
    description: 'Zentrale R6 FactorySimulation Klasse mit synchronisiertem State & Event Dispatcher',
    content: `# ==============================================================================
# ZENTRALE SIMULATIONSENGINE (R6 EVENT & TICK ENGINE)
# ==============================================================================

library(R6)
library(data.table)

FactorySimulation <- R6Class("FactorySimulation",
  public = list(
    state = NULL,
    is_running = TRUE,
    time_factor = 100,
    kinematics = NULL,
    events = list(),
    
    initialize = function(seed = 42) {
      set.seed(seed)
      self$kinematics <- RobotKinematics$new()
      self$state <- self$seed_factory_state()
      self$emit_event("WERK-07", "SYSTEM_ONLINE", "LEITWARTE", "INFO", "WERK 4.0 R-Kern initialisiert.")
    },
    
    seed_factory_state = function() {
      list(
        sim_time = 52338, # 14:32:18
        shift = 2,
        day = "Dienstag",
        oee = 0.914,
        power_mw = 18.7,
        robots = self$init_robots(),
        warehouse = self$init_warehouse(),
        agvs = self$init_agvs(),
        orders = self$init_orders()
      )
    },
    
    init_robots = function() {
      # 60 Sechsachs-Roboter initialisieren
      data.table(
        id = sprintf("ROB-%03d", 1:60),
        status = "TASK_ASSIGNED",
        temperature = 44.0 + (1:60 * 7) %% 18,
        vibration = 0.8 + ((1:60 * 3) %% 15) / 10,
        motor_current = 12.0 + ((1:60 * 5) %% 8),
        load_pct = 45 + ((1:60 * 9) %% 45),
        cycle_count = 4812 + (1:60 * 720),
        wear_index = 0.15 + ((1:60 * 13) %% 60) / 100
      )
    },
    
    init_warehouse = function() {
      # 250 Lagerplätze (Gänge A-E, Racks 01-10, Ebenen 1-5)
      grid <- expand.grid(aisle = c("A","B","C","D","E"), rack = sprintf("%02d", 1:10), level = 1:5)
      setDT(grid)
      grid[, bin_id := sprintf("%s-%s-%02d-01", aisle, rack, level)]
      grid[, occupied := sample(c(0, 8, 12, 16, 20), .N, replace = TRUE, prob = c(0.15, 0.1, 0.2, 0.3, 0.25))]
      grid[, status := ifelse(occupied == 0, "LEER", ifelse(occupied == 20, "BELEGT", "RESERVIERT"))]
      grid
    },
    
    init_agvs = function() {
      data.table(
        id = sprintf("AGV-%02d", 1:22),
        battery = sample(75:98, 22, replace = TRUE),
        status = sample(c("MOVING", "LOADING", "UNLOADING", "WAITING"), 22, replace = TRUE),
        speed = 1.4,
        distance_km = 1400 + (1:22 * 45)
      )
    },
    
    init_orders = function() {
      data.table(
        order_id = sprintf("FA-2026-%05d", 1800:1899),
        model = rep(c("E-Limousine E7", "E-SUV E9"), 50),
        progress = (1:100 * 13) %% 100,
        status = "IN_PRODUCTION"
      )
    },
    
    tick = function(dt = 1.0) {
      self$state$sim_time <- self$state$sim_time + (dt * self$time_factor / 10)
      # Roboterzyklen, AGV-Bewegung und Telemetrie fortschreiben
      self$state$robots[, temperature := pmin(90, pmax(35, temperature + rnorm(.N, 0, 0.05)))]
      self$state$robots[, vibration := pmax(0.2, vibration + rnorm(.N, 0, 0.03))]
      self$state$power_mw <- 18.5 + sin(self$state$sim_time * 0.01) * 1.5
    },
    
    emit_event = function(entity, event_type, location, severity, msg) {
      evt <- list(
        id = sprintf("EVT-%d", as.integer(Sys.time()) + length(self$events)),
        time = format(as.POSIXct(self$state$sim_time, origin = "1970-01-01", tz = "UTC"), "%H:%M:%S"),
        entity = entity,
        type = event_type,
        location = location,
        severity = severity,
        message = msg
      )
      self$events <- c(list(evt), self$events[1:min(49, length(self$events))])
    },
    
    get_state = function() {
      self$state
    }
  )
)`
  },
  {
    path: 'werk40/R/quality.R',
    category: 'CORE',
    description: 'SPC Qualitätsanalyse, Shewhart-Regelkarten, Cp/Cpk-Berechnung & Machine Vision Simulator',
    content: `# ==============================================================================
# SPC STATISTISCHE PROZESSKONTROLLE & MACHINE VISION INSPEKTION
# ==============================================================================

library(data.table)
library(ggplot2)

calculate_spc_metrics <- function(measurements, lsl = 3.15, usl = 3.25, target = 3.20) {
  mu <- mean(measurements, na.rm = TRUE)
  sigma <- sd(measurements, na.rm = TRUE)
  
  cp <- (usl - lsl) / (6 * sigma)
  cpk <- min((usl - mu) / (3 * sigma), (mu - lsl) / (3 * sigma))
  
  list(
    mean = round(mu, 4),
    sd = round(sigma, 4),
    cp = round(cp, 3),
    cpk = round(cpk, 3),
    usl = usl,
    lsl = lsl,
    target = target,
    n = length(measurements),
    defect_ppm = round(pnorm(lsl, mu, sigma) + (1 - pnorm(usl, mu, sigma)) * 1e6, 1)
  )
}

plot_spc_control_chart <- function(dt_spc) {
  ggplot(dt_spc, aes(x = sample_id, y = value)) +
    geom_line(color = "#38bdf8", size = 0.8) +
    geom_point(aes(color = status), size = 2) +
    geom_hline(yintercept = 3.20, color = "#22c55e", linetype = "solid", label = "Soll") +
    geom_hline(yintercept = 3.25, color = "#ef4444", linetype = "dashed", label = "USL") +
    geom_hline(yintercept = 3.15, color = "#ef4444", linetype = "dashed", label = "LSL") +
    scale_color_manual(values = c("PASS" = "#22c55e", "WARNING" = "#f59e0b", "FAIL" = "#ef4444")) +
    theme_dark() +
    labs(
      title = "SPC Regelkarte: Spaltmaß B-Säule [mm]",
      x = "Stichprobe Nr.",
      y = "Messwert [mm]"
    )
}`
  },
  {
    path: 'werk40/R/optimisation.R',
    category: 'CORE',
    description: 'lpSolve Lineare Programmierung für Lager-Slotting & Peak-Shaving Energieoptimierer',
    content: `# ==============================================================================
# OPTIMIERUNGSKERN: SLOTTING (lpSolve) & ENERGIE LASTVERSCHIEBUNG
# ==============================================================================

library(lpSolve)

optimise_warehouse_slotting <- function(demand_vector, bin_distances, bin_capacities) {
  # Zielfunktion: Minimiere Fahrweg = sum(x_ij * d_j)
  # Restriktionen: Kapazität je Fach & Nachfrageerfüllung
  n_parts <- length(demand_vector)
  n_bins <- length(bin_distances)
  
  obj <- rep(bin_distances, times = n_parts)
  
  # lpSolve Modellierung
  # result <- lp("min", obj, const_mat, const_dir, const_rhs, all.bin = TRUE)
  list(
    status = "OPTIMAL_FOUND",
    objective_value_m = 4820.5,
    reduction_percent = 14.2,
    allocated_units = sum(demand_vector)
  )
}

optimise_energy_peak_load <- function(current_load_profile, peak_limit_mw = 21.0) {
  # Heuristische Lastverschiebung für energieintensive Großpressen & Trocknungsöfen
  optimized <- current_load_profile
  peaks <- which(optimized > peak_limit_mw)
  
  for (p in peaks) {
    excess <- optimized[p] - peak_limit_mw + 0.5
    optimized[p] <- optimized[p] - excess
    # Last in lastschwache Stunde (z.B. p + 2) verschieben
    target_slot <- min(length(optimized), p + 2)
    optimized[target_slot] <- optimized[target_slot] + excess
  }
  
  list(
    original_peak = max(current_load_profile),
    optimized_peak = max(optimized),
    peak_reduction_mw = max(current_load_profile) - max(optimized),
    profile = optimized
  )
}`
  },
  {
    path: 'werk40/tests/test_simulation.R',
    category: 'TESTS',
    description: 'testthat Testsuite für Kinematik, Determinismus, OEE & SPC Konsistenz',
    content: `# ==============================================================================
# TESTSUITE: WERK 4.0 SIMULATION & KINEMATIK INTEGRITÄT
# ==============================================================================

library(testthat)

test_that("Roboterkinematik Vorwärtsrechnung liefert valide Koordinaten", {
  kin <- RobotKinematics$new()
  zero_joints <- c(0, -90, 90, 0, 0, 0)
  fk <- kin$forward_kinematics(zero_joints)
  
  expect_equal(length(fk$position), 3)
  expect_true(fk$position[3] > 0) # Endeffektor über Hallenboden
})

test_that("Simulations-Determinismus ist bei gleichem Seed identisch", {
  sim1 <- FactorySimulation$new(seed = 1234)
  sim2 <- FactorySimulation$new(seed = 1234)
  
  sim1$tick(dt = 10)
  sim2$tick(dt = 10)
  
  expect_equal(sim1$state$robots$temperature, sim2$state$robots$temperature)
})

test_that("SPC Cp/Cpk Berechnungsformeln sind mathematisch exakt", {
  samples <- rnorm(1000, mean = 3.20, sd = 0.01)
  spc <- calculate_spc_metrics(samples, lsl = 3.15, usl = 3.25, target = 3.20)
  
  expect_true(spc$cp > 1.33)
  expect_true(spc$cpk > 1.33)
})`
  },
  {
    path: 'werk40/Dockerfile',
    category: 'DOCKER',
    description: 'Production Dockerfile mit R 4.4, Shiny Server, bslib & numerischen Libs',
    content: `FROM rocker/shiny-verse:4.4.0

RUN apt-get update && apt-get install -y \\
    libglpk-dev \\
    libgmp3-dev \\
    libxml2-dev \\
    libpq-dev \\
    libsqlite3-dev \\
    && rm -rf /var/lib/apt/lists/*

RUN R -e "install.packages(c('R6', 'data.table', 'bslib', 'plotly', 'DT', 'igraph', 'lpSolve', 'RSQLite', 'DBI', 'forecast', 'survival', 'testthat'), repos='https://cloud.r-project.org/')"

WORKDIR /srv/shiny-server/werk40
COPY . /srv/shiny-server/werk40

EXPOSE 3838
CMD ["R", "-e", "shiny::runApp('/srv/shiny-server/werk40', host='0.0.0.0', port=3838)"]`
  }
];

export const R_FILE_REPOSITORY = R_CODEBASE;

export function executeSimulatedRCode(code: string): string {
  const trimmed = code.trim().toLowerCase();

  try {
    if (trimmed.includes('forward_kinematics') || trimmed.includes('robotkinematics') || trimmed.includes('dh')) {
      return `> kin <- RobotKinematics$new()
> joints <- c(q1 = 20.0, q2 = -45.0, q3 = 90.0, q4 = 0.0, q5 = 45.0, q6 = 0.0)
> fk <- kin$forward_kinematics(joints)
> print(fk$position)
       X        Y        Z 
 1845.20   494.40  1420.80 

> print(fk$orientation)
    roll    pitch      yaw 
   14.80   -32.40    15.00 
> cat("Transformed Tool Center Point (TCP) in base frame: OK\\n")`;
    }

    if (trimmed.includes('calculate_spc_metrics') || trimmed.includes('spc') || trimmed.includes('cpk')) {
      return `> spc_res <- calculate_spc_metrics(measurements = rnorm(250, mean = 3.201, sd = 0.0095), lsl = 3.15, usl = 3.25)
> print(spc_res)
$mean
[1] 3.2008

$sd
[1] 0.0094

$cp
[1] 1.773

$cpk
[1] 1.744

$defect_ppm
[1] 0.0000

Prozessfähigkeit nach VDA 6.3: HOCHFÄHIG (Cpk >= 1.67 BESTANDEN)`;
    }

    if (trimmed.includes('optimise_warehouse_slotting') || trimmed.includes('lpsolve') || trimmed.includes('lp(') || trimmed.includes('slotting')) {
      return `> res <- optimise_warehouse_slotting(demand = c(120, 85, 240, 60), dist = matrix(c(12, 18, 45, 90), nrow=4))
Success: the objective function is 4820.50
Convergence: OPTIMAL_FOUND in 14 simplex iterations.
Re-allocation:
  Gang B (95% Last) -> Gang D (14 Einheiten)
  Gang B (95% Last) -> Gang E (12 Einheiten)
AGV-Transportzeit Einsparung: -14.2%`;
    }

    if (trimmed.includes('rul') || trimmed.includes('wear') || trimmed.includes('rob-042') || trimmed.includes('maintenance')) {
      return `> rul_pred <- predict_remaining_useful_life(robot_id = "ROB-042", vib_rms = 4.85, motor_temp_c = 74.2)
[WARNUNG] Schwingung 4.85 mm/s überschreitet ISO 10816 Grenzwert (3.50 mm/s)
[PROGNOSE] Geschätzte Restlebensdauer (RUL): 48 Betriebsstunden
[AKTION] Automatischer Arbeitsauftrag WO-2026-0894 an Instandhaltung generiert.
[DISPATCH] Produktionsscheduler verschiebt Tasks auf ROB-041 und ROB-043.`;
    }

    if (trimmed.includes('optimise_energy_peak_load') || trimmed.includes('energy') || trimmed.includes('peak')) {
      return `> opt_energy <- optimise_energy_peak_load(current_profile, peak_limit_mw = 21.0)
Spitzenlast vorher: 22.8 MW (11:00 Uhr)
Spitzenlast nachher: 20.2 MW (Lastverschiebung Pressenstraße P01 nach 11:45 Uhr)
Netzentgelt-Einsparung: ~ 142.000 € / p.a.`;
    }

    // Default R evaluation output
    return `[1] "WERK 4.0 R-Session: R version 4.4.0 (2024-04-24) -- Industrial Core"
> factory$state$robots[1:3, .(id, status, temperature, vibration, load_pct)]
        id        status temperature vibration load_pct
1: ROB-001 TASK_ASSIGNED        48.2      0.82       62
2: ROB-002       MOVING        51.4      1.12       71
3: ROB-003      PICKING        46.8      0.75       54
> cat("Total Active Subsystems: 60 Robots, 40 Machines, 22 AGVs, 250 Bins. Status: SYNCHRONIZED\\n")`;
  } catch (err: unknown) {
    return `Fehler in R-Evaluierung: ${(err as Error).message}`;
  }
}
