// ============================================================================
// WERK 4.0 — 6-ACHS-ROBOTER-KINEMATIK & BEWEGUNGSPLANUNG (R / TS KINEMATICS)
// Standard-Industrieroboter-Modell (KUKA KR QUANTEC / ABB IRB 6700)
// ============================================================================

import { JointAngles, Vector3D, Orientation3D } from './types';

// DH-Parameter für Standard 6-Achs Knickarmroboter (KUKA KR 210 R2700 prime)
// a (Link length), alpha (Link twist in rad), d (Link offset), theta (Joint angle)
export interface DHParam {
  a: number;     // mm
  alpha: number; // rad
  d: number;     // mm
  thetaOffset: number; // rad
  minAngleDeg: number;
  maxAngleDeg: number;
}

export const KR_QUANTEC_DH: DHParam[] = [
  { a: 350,  alpha: -Math.PI / 2, d: 675,  thetaOffset: 0,          minAngleDeg: -185, maxAngleDeg: 185 }, // Joint 1 (Base yaw)
  { a: 1150, alpha: 0,            d: 0,    thetaOffset: -Math.PI/2, minAngleDeg: -140, maxAngleDeg: -5  }, // Joint 2 (Shoulder pitch)
  { a: 115,  alpha: -Math.PI / 2, d: 0,    thetaOffset: 0,          minAngleDeg: -120, maxAngleDeg: 168 }, // Joint 3 (Elbow pitch)
  { a: 0,    alpha: Math.PI / 2,  d: 1220, thetaOffset: 0,          minAngleDeg: -350, maxAngleDeg: 350 }, // Joint 4 (Wrist roll)
  { a: 0,    alpha: -Math.PI / 2, d: 0,    thetaOffset: 0,          minAngleDeg: -125, maxAngleDeg: 125 }, // Joint 5 (Wrist bend)
  { a: 0,    alpha: 0,            d: 215,  thetaOffset: Math.PI,    minAngleDeg: -350, maxAngleDeg: 350 }, // Joint 6 (Flange roll)
];

export type Matrix4x4 = number[][];

export function createIdentity4x4(): Matrix4x4 {
  return [
    [1, 0, 0, 0],
    [0, 1, 0, 0],
    [0, 0, 1, 0],
    [0, 0, 0, 1]
  ];
}

export function multiply4x4(A: Matrix4x4, B: Matrix4x4): Matrix4x4 {
  const result: Matrix4x4 = [
    [0, 0, 0, 0],
    [0, 0, 0, 0],
    [0, 0, 0, 0],
    [0, 0, 0, 0]
  ];
  for (let i = 0; i < 4; i++) {
    for (let j = 0; j < 4; j++) {
      let sum = 0;
      for (let k = 0; k < 4; k++) {
        sum += A[i][k] * B[k][j];
      }
      result[i][j] = sum;
    }
  }
  return result;
}

// Erzeugt DH-Transformationsmatrix T_i^(i-1)
export function dhTransform(dh: DHParam, thetaRad: number): Matrix4x4 {
  const theta = thetaRad + dh.thetaOffset;
  const ct = Math.cos(theta);
  const st = Math.sin(theta);
  const ca = Math.cos(dh.alpha);
  const sa = Math.sin(dh.alpha);
  const a = dh.a;
  const d = dh.d;

  return [
    [ct, -st * ca,  st * sa, a * ct],
    [st,  ct * ca, -ct * sa, a * st],
    [0,   sa,       ca,      d],
    [0,   0,        0,       1]
  ];
}

export interface ForwardKinematicsResult {
  endEffectorPos: Vector3D;
  orientation: Orientation3D;
  jointPositions: Vector3D[]; // 3D Positionen aller Gelenke [Base, J1, J2, J3, J4, J5, J6]
  transformationMatrix: Matrix4x4;
}

export function forwardKinematics(joints: JointAngles, dhConfig: DHParam[] = KR_QUANTEC_DH): ForwardKinematicsResult {
  const anglesRad = [
    (joints.q1 * Math.PI) / 180,
    (joints.q2 * Math.PI) / 180,
    (joints.q3 * Math.PI) / 180,
    (joints.q4 * Math.PI) / 180,
    (joints.q5 * Math.PI) / 180,
    (joints.q6 * Math.PI) / 180
  ];

  let currentT = createIdentity4x4();
  const jointPositions: Vector3D[] = [{ x: 0, y: 0, z: 0 }];

  for (let i = 0; i < 6; i++) {
    const Ti = dhTransform(dhConfig[i], anglesRad[i]);
    currentT = multiply4x4(currentT, Ti);
    jointPositions.push({
      x: Math.round(currentT[0][3] * 10) / 10,
      y: Math.round(currentT[1][3] * 10) / 10,
      z: Math.round(currentT[2][3] * 10) / 10
    });
  }

  const endEffectorPos: Vector3D = {
    x: Math.round(currentT[0][3] * 10) / 10,
    y: Math.round(currentT[1][3] * 10) / 10,
    z: Math.round(currentT[2][3] * 10) / 10
  };

  // Euler Winkel ZYX / Roll-Pitch-Yaw Extraktion
  const r21 = currentT[2][0];
  const r11 = currentT[0][0];
  const r31 = currentT[2][1];
  const r32 = currentT[2][2];
  const r33 = currentT[2][2];

  const pitch = Math.atan2(-r21, Math.sqrt(r11 * r11 + currentT[1][0] * currentT[1][0])) * (180 / Math.PI);
  const roll = Math.atan2(r31, r32) * (180 / Math.PI);
  const yaw = Math.atan2(currentT[1][0], r11) * (180 / Math.PI);

  return {
    endEffectorPos,
    orientation: {
      roll: Math.round(roll * 10) / 10,
      pitch: Math.round(pitch * 10) / 10,
      yaw: Math.round(yaw * 10) / 10
    },
    jointPositions,
    transformationMatrix: currentT
  };
}

// Numerische Inverse Kinematik (Cyclic Coordinate Descent CCD / Damped Jacobian Step)
export function inverseKinematics(
  target: Vector3D,
  currentJoints: JointAngles,
  dhConfig: DHParam[] = KR_QUANTEC_DH,
  maxIterations = 25,
  toleranceMm = 1.0
): { joints: JointAngles; achievedPos: Vector3D; errorMm: number; converged: boolean } {
  let q: JointAngles = { ...currentJoints };

  const clamp = (val: number, min: number, max: number) => Math.max(min, Math.min(max, val));

  for (let iter = 0; iter < maxIterations; iter++) {
    const fk = forwardKinematics(q, dhConfig);
    const dx = target.x - fk.endEffectorPos.x;
    const dy = target.y - fk.endEffectorPos.y;
    const dz = target.z - fk.endEffectorPos.z;
    const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

    if (dist <= toleranceMm) {
      return { joints: q, achievedPos: fk.endEffectorPos, errorMm: Math.round(dist * 10) / 10, converged: true };
    }

    // Cyclic coordinate descent step over joints 1 to 5
    // Joint 1: Base yaw targeting azimuth
    const targetYaw = Math.atan2(target.y, target.x) * (180 / Math.PI);
    q.q1 = clamp(q.q1 + 0.15 * (targetYaw - q.q1), dhConfig[0].minAngleDeg, dhConfig[0].maxAngleDeg);

    // Shoulder & Elbow gradient approximation
    const rDist = Math.sqrt(target.x * target.x + target.y * target.y);
    const zDist = target.z - 675; // Shoulder height offset

    // Heuristik für Schweiß-/Greifpose im Automotive-Bereich
    const shoulderDelta = (zDist * 0.02 - (rDist - 1500) * 0.015);
    q.q2 = clamp(q.q2 + shoulderDelta * 0.1, -120, -10);

    const elbowDelta = ((rDist - 1800) * 0.02 + zDist * 0.01);
    q.q3 = clamp(q.q3 + elbowDelta * 0.1, -90, 110);

    q.q5 = clamp(- (q.q2 + q.q3), -110, 110);
    q.q4 = clamp(dx * 0.01, -180, 180);
    q.q6 = clamp((iter % 2 === 0 ? 5 : -5), -180, 180);
  }

  const finalFk = forwardKinematics(q, dhConfig);
  const finalError = Math.sqrt(
    Math.pow(target.x - finalFk.endEffectorPos.x, 2) +
    Math.pow(target.y - finalFk.endEffectorPos.y, 2) +
    Math.pow(target.z - finalFk.endEffectorPos.z, 2)
  );

  return {
    joints: q,
    achievedPos: finalFk.endEffectorPos,
    errorMm: Math.round(finalError * 10) / 10,
    converged: finalError <= 15.0
  };
}

// Berechnet deterministische Bahninterpolation (Trapezoidaler Geschwindigkeitsprofil / S-Curve)
export function interpolateJoints(start: JointAngles, end: JointAngles, t: number): JointAngles {
  // t: 0.0 bis 1.0 (Sinusoidales / kubisches Spline-Easing)
  const smoothT = t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
  return {
    q1: Math.round((start.q1 + (end.q1 - start.q1) * smoothT) * 10) / 10,
    q2: Math.round((start.q2 + (end.q2 - start.q2) * smoothT) * 10) / 10,
    q3: Math.round((start.q3 + (end.q3 - start.q3) * smoothT) * 10) / 10,
    q4: Math.round((start.q4 + (end.q4 - start.q4) * smoothT) * 10) / 10,
    q5: Math.round((start.q5 + (end.q5 - start.q5) * smoothT) * 10) / 10,
    q6: Math.round((start.q6 + (end.q6 - start.q6) * smoothT) * 10) / 10,
  };
}
