// ============================================================================
// WERK 4.0 — ZENTRALE SIMULATIONSENGINE (R6-EQUIVALENT STATE & DISCRETE EVENT CORE)
// ============================================================================

import {
  RobotEntity,
  MachineEntity,
  AGVEntity,
  WarehouseBinEntity,
  ProductionOrderEntity,
  ProductionLineEntity,
  ProductionHallEntity,
  QualityMeasurement,
  EnergyLoadEntity,
  FactoryEvent,
  AuditLogEntry,
  ScenarioState,
  UserRole
} from './types';
import {
  SEED_HALLS,
  SEED_LINES,
  SEED_MACHINES,
  SEED_ROBOTS,
  SEED_WAREHOUSE,
  SEED_PARTS,
  SEED_AGVS,
  SEED_ORDERS,
  SEED_QUALITY_MEASUREMENTS,
  SEED_ENERGY_PROFILE,
  SEED_EVENTS,
  SEED_AUDIT_LOGS
} from './seedData';
import { forwardKinematics, inverseKinematics } from './kinematics';

export interface FactoryFullState {
  simTimeSeconds: number;
  timeFormatted: string;
  shift: number;
  dayOfWeek: string;
  timeFactor: number;
  isRunning: boolean;
  activeRole: UserRole;
  scenario: ScenarioState;
  
  halls: ProductionHallEntity[];
  lines: ProductionLineEntity[];
  machines: MachineEntity[];
  robots: RobotEntity[];
  warehouse: WarehouseBinEntity[];
  agvs: AGVEntity[];
  orders: ProductionOrderEntity[];
  qualityEvents: QualityMeasurement[];
  energyProfile: EnergyLoadEntity[];
  events: FactoryEvent[];
  auditLogs: AuditLogEntry[];
  
  // Aggregated KPIs
  kpis: {
    overallOee: number;
    activeRobotsCount: number;
    totalRobotsCount: number;
    activeAgvsCount: number;
    totalAgvsCount: number;
    warehouseOccupancyPercent: number;
    totalPowerMw: number;
    qualityFirstPassYieldPercent: number;
    completedOrdersCount: number;
    taktAdherencePercent: number;
  };
}

export function formatSimTime(seconds: number): string {
  const totalSecondsInDay = seconds % (24 * 3600);
  const h = Math.floor(totalSecondsInDay / 3600);
  const m = Math.floor((totalSecondsInDay % 3600) / 60);
  const s = Math.floor(totalSecondsInDay % 60);
  return `${h < 10 ? '0' + h : h}:${m < 10 ? '0' + m : m}:${s < 10 ? '0' + s : s}`;
}

export function getShift(seconds: number): number {
  const h = Math.floor((seconds % 86400) / 3600);
  if (h >= 6 && h < 14) return 1; // Frühschicht
  if (h >= 14 && h < 22) return 2; // Spätschicht
  return 3; // Nachtschicht
}

export function createInitialFactoryState(): FactoryFullState {
  const initialSimTime = 14 * 3600 + 32 * 60 + 18; // 14:32:18
  const state: FactoryFullState = {
    simTimeSeconds: initialSimTime,
    timeFormatted: formatSimTime(initialSimTime),
    shift: 2,
    dayOfWeek: 'Dienstag',
    timeFactor: 10,
    isRunning: true,
    activeRole: 'WERKSLEITUNG',
    scenario: {
      activeScenarioId: 'NONE',
      stepIndex: 0,
      maxSteps: 11,
      description: 'Standardbetrieb: Kontinuierliche Fertigungsvolumen-Steuerung aktiv.',
      metrics: {
        throughputImpact: '±0.0%',
        downtimeAvoidedMin: 0,
        reroutedTasksCount: 0,
        optimizedSlottingPercent: 0,
      }
    },
    halls: JSON.parse(JSON.stringify(SEED_HALLS)),
    lines: JSON.parse(JSON.stringify(SEED_LINES)),
    machines: JSON.parse(JSON.stringify(SEED_MACHINES)),
    robots: JSON.parse(JSON.stringify(SEED_ROBOTS)),
    warehouse: JSON.parse(JSON.stringify(SEED_WAREHOUSE)),
    agvs: JSON.parse(JSON.stringify(SEED_AGVS)),
    orders: JSON.parse(JSON.stringify(SEED_ORDERS)),
    qualityEvents: JSON.parse(JSON.stringify(SEED_QUALITY_MEASUREMENTS)),
    energyProfile: JSON.parse(JSON.stringify(SEED_ENERGY_PROFILE)),
    events: JSON.parse(JSON.stringify(SEED_EVENTS)),
    auditLogs: JSON.parse(JSON.stringify(SEED_AUDIT_LOGS)),
    kpis: {
      overallOee: 91.4,
      activeRobotsCount: 54,
      totalRobotsCount: 60,
      activeAgvsCount: 17,
      totalAgvsCount: 22,
      warehouseOccupancyPercent: 82.4,
      totalPowerMw: 18.7,
      qualityFirstPassYieldPercent: 98.7,
      completedOrdersCount: 28,
      taktAdherencePercent: 94.6,
    }
  };
  return state;
}

// Single-tick update function for deterministic simulation
export function stepSimulationTick(state: FactoryFullState, dtSeconds: number): FactoryFullState {
  const next = { ...state };
  next.simTimeSeconds += dtSeconds;
  next.timeFormatted = formatSimTime(next.simTimeSeconds);
  next.shift = getShift(next.simTimeSeconds);

  // 1. Roboterkinematik & Zyklus-Fortschritt aktualisieren
  const updatedRobots = next.robots.map((robot, i) => {
    if (robot.status === 'EMERGENCY_STOP' || robot.status === 'MAINTENANCE') {
      return robot;
    }

    // Kinematik-Winkelschwingung im Arbeitsbereich
    const phase = (next.simTimeSeconds * 0.8 + i * 1.3) % (2 * Math.PI);
    const speedFactor = robot.status === 'MOVING' || robot.status === 'PICKING' || robot.status === 'PLACING' ? 1.0 : 0.2;

    const baseDelta = Math.sin(phase) * 15 * speedFactor;
    const shoulderDelta = Math.cos(phase * 0.7) * 8 * speedFactor;
    const elbowDelta = Math.sin(phase * 1.1) * 10 * speedFactor;
    const wristDelta = Math.cos(phase * 1.5) * 18 * speedFactor;

    const newJoints = {
      q1: Math.round(((robot.joints.q1 + baseDelta * 0.05)) * 10) / 10,
      q2: Math.round((Math.max(-130, Math.min(-15, robot.joints.q2 + shoulderDelta * 0.04))) * 10) / 10,
      q3: Math.round((Math.max(-80, Math.min(120, robot.joints.q3 + elbowDelta * 0.04))) * 10) / 10,
      q4: Math.round(((robot.joints.q4 + wristDelta * 0.03)) * 10) / 10,
      q5: Math.round((-(robot.joints.q2 + robot.joints.q3) * 0.9) * 10) / 10,
      q6: Math.round(((robot.joints.q6 + (i % 2 === 0 ? 0.8 : -0.8)) % 360) * 10) / 10,
    };

    const fk = forwardKinematics(newJoints);

    // Wear Index progression
    const isProblematic = robot.id === 'ROB-042';
    const tempInc = isProblematic ? 0.005 : (Math.random() - 0.5) * 0.02;
    const newTemp = Math.round(Math.min(95, Math.max(35, robot.temperature + tempInc)) * 10) / 10;
    const vibNoise = (Math.random() - 0.5) * 0.05;
    const newVib = Math.round(Math.max(0.2, robot.vibration + vibNoise) * 100) / 100;

    let newStatus = robot.status;
    let newProgress = robot.currentTask ? Math.min(100, robot.currentTask.progress + (dtSeconds * 1.5)) : 0;
    if (newProgress >= 100 && robot.currentTask) {
      newProgress = 0;
      // Zyklus abgeschlossen
    }

    return {
      ...robot,
      joints: newJoints,
      position: fk.endEffectorPos,
      orientation: fk.orientation,
      temperature: newTemp,
      vibration: newVib,
      cycleCount: robot.cycleCount + (Math.random() < 0.05 ? 1 : 0),
      currentTask: robot.currentTask ? { ...robot.currentTask, progress: newProgress } : null,
    };
  });
  next.robots = updatedRobots;

  // 2. AGVs aktualisieren
  const updatedAgvs = next.agvs.map((agv, i) => {
    if (agv.status === 'MOVING') {
      const step = 0.8 * dtSeconds;
      const nx = (agv.position.x + step * (i % 2 === 0 ? 1 : -0.7)) % 750;
      const ny = (agv.position.y + step * 0.4) % 450;
      const batteryDrain = 0.002 * dtSeconds;
      return {
        ...agv,
        position: { ...agv.position, x: Math.max(50, nx), y: Math.max(40, ny) },
        batteryPercent: Math.max(15, Math.round((agv.batteryPercent - batteryDrain) * 10) / 10),
      };
    }
    if (agv.status === 'CHARGING') {
      return {
        ...agv,
        batteryPercent: Math.min(100, Math.round((agv.batteryPercent + 0.05 * dtSeconds) * 10) / 10),
      };
    }
    return agv;
  });
  next.agvs = updatedAgvs;

  // 3. Demo Scenario Step Progression if active
  if (next.scenario.activeScenarioId === 'SCENARIO_1_E_AUTO') {
    const stageNames = [
      '1. Wareneingang: Batterie- & Karosserieteile angeliefert & Barcode gescannt',
      '2. Hochregallager: Einlagerung in Gang A & Zuweisung Bereitstellungsplatz',
      '3. FTS-Transport: AGV-04 holt Batteriemodul & fährt zu Zelle K-07',
      '4. Presswerk: Seitenwandrahmen links & rechts geformt',
      '5. Roboterzelle K-07: ROB-017 & ROB-018 fügen Karosseriestruktur',
      '6. Karosserieschweißung: Schweißportal MAS-08 setzt 240 Schweißpunkte',
      '7. Lackiererei: KTL-Tauchbecken & Roboterlackierung L-02 abgeschlossen',
      '8. Batteriemontage: 800V 100kWh NMC Pack in Unterboden eingepasst',
      '9. Hochzeit: MAS-31 verschraubt Fahrwerk & Antriebsstrang (16 Spindeln)',
      '10. Qualitätskontrolle: 3D-Laser-CMM bestätigt Spaltmaße ±0.03 mm (PASS)',
      '11. End-of-Line: Rollenprüfstand absolviert. Freigabe FA-2026-01842 zum Versand!',
    ];
    // Progression is handled via user step or timed
  }

  // Recalculate KPIs
  const activeRobots = next.robots.filter(r => r.status !== 'EMERGENCY_STOP' && r.status !== 'MAINTENANCE' && r.status !== 'TOOL_FAILURE').length;
  const activeAgvs = next.agvs.filter(a => a.status === 'MOVING' || a.status === 'LOADING' || a.status === 'UNLOADING').length;
  const occupiedBins = next.warehouse.filter(b => b.status === 'BELEGT' || b.status === 'RESERVIERT').length;
  const totalBins = next.warehouse.length;

  next.kpis = {
    ...next.kpis,
    activeRobotsCount: activeRobots,
    activeAgvsCount: activeAgvs,
    warehouseOccupancyPercent: Math.round((occupiedBins / totalBins) * 1000) / 10,
    totalPowerMw: Math.round((18.4 + Math.sin(next.simTimeSeconds * 0.01) * 1.2) * 10) / 10,
  };

  return next;
}

// ----------------------------------------------------------------------------
// SCENARIO HANDLERS
// ----------------------------------------------------------------------------

export function triggerScenario1(state: FactoryFullState): FactoryFullState {
  const next = JSON.parse(JSON.stringify(state)) as FactoryFullState;
  next.scenario = {
    activeScenarioId: 'SCENARIO_1_E_AUTO',
    stepIndex: 1,
    maxSteps: 11,
    description: 'Szenario 1: Vollständiger Produktionsdurchlauf Elektrofahrzeug FA-2026-01842 (Variante E7 Performance).',
    metrics: {
      throughputImpact: '+100% (1 Fzg freigegeben)',
      downtimeAvoidedMin: 0,
      reroutedTasksCount: 0,
      optimizedSlottingPercent: 0,
    }
  };
  
  // Highlight order FA-2026-01842
  const order = next.orders.find(o => o.orderId === 'FA-2026-01842');
  if (order) {
    order.status = 'IN_PRODUCTION';
    order.progressPercent = 10;
    order.currentStage = '1. Wareneingang: Batterie- & Karosserieteile gescannt';
  }

  // Emit event
  const newEvent: FactoryEvent = {
    eventId: `EVT-${Date.now()}`,
    timestamp: next.timeFormatted,
    simTimeSeconds: next.simTimeSeconds,
    entityId: 'FA-2026-01842',
    entityType: 'ORDER',
    eventType: 'SCENARIO_1_STARTED',
    location: 'WARENEINGANG SUD',
    severity: 'INFO',
    message: 'Demo-Szenario 1 gestartet: Gesamtdurchlauf E-Fahrzeug FA-2026-01842.',
  };
  next.events = [newEvent, ...next.events.slice(0, 49)];

  return next;
}

export function advanceScenario1Step(state: FactoryFullState): FactoryFullState {
  const next = JSON.parse(JSON.stringify(state)) as FactoryFullState;
  if (next.scenario.activeScenarioId !== 'SCENARIO_1_E_AUTO') return next;

  const currentStep = next.scenario.stepIndex;
  const newStep = Math.min(next.scenario.maxSteps, currentStep + 1);
  next.scenario.stepIndex = newStep;

  const order = next.orders.find(o => o.orderId === 'FA-2026-01842');
  if (order) {
    order.progressPercent = Math.round((newStep / next.scenario.maxSteps) * 100);
    if (newStep === 11) {
      order.status = 'COMPLETED';
      order.currentStage = '11. End-of-Line Prüfung bestanden — Fahrzeug freigegeben';
    }
  }

  const stepDescriptions = [
    '',
    'Wareneingang: Materialprüfung & Einbuchung',
    'Hochregallager: Bereitstellung Palette PART-E7-010',
    'AGV-04 transportiert Batterie zur Roboterzelle K-07',
    'Presswerk MAS-01 formt hochfeste Karosserieseitenwand',
    'Roboter ROB-017 greift Bauteil & positioniert auf Schweißvorrichtung',
    'KUKA Schweißportal MAS-08 führt Nahtschweißung aus',
    'Lackierstraße L-02: KTL & Decklack appliziert',
    'Batteriemontagelinie B-01 fügt 800V NMC Pack',
    'Hochzeit MAS-31: Drehmomentverschraubung 16 Achsen',
    'Qualitätsinspektion Zeiss CMM: Spaltmaß 3.21 mm (PASS)',
    'End-of-Line: Rollenprüfstand absolviert. Fahrzeug versandbereit!',
  ];

  const newEvent: FactoryEvent = {
    eventId: `EVT-${Date.now()}`,
    timestamp: next.timeFormatted,
    simTimeSeconds: next.simTimeSeconds,
    entityId: 'FA-2026-01842',
    entityType: 'ORDER',
    eventType: `SCENARIO_STEP_${newStep}`,
    location: `STATION-STUFE-${newStep}`,
    severity: newStep === 11 ? 'SUCCESS' : 'INFO',
    message: `[Szenario 1 - Schritt ${newStep}/11] ${stepDescriptions[newStep]}`,
  };
  next.events = [newEvent, ...next.events.slice(0, 49)];

  return next;
}

export function triggerScenario2(state: FactoryFullState): FactoryFullState {
  const next = JSON.parse(JSON.stringify(state)) as FactoryFullState;
  
  // 1. Set ROB-042 into alert state
  const rob42 = next.robots.find(r => r.id === 'ROB-042');
  if (rob42) {
    rob42.temperature = 74.2;
    rob42.vibration = 4.92;
    rob42.motorCurrent = 26.5;
    rob42.status = 'WARNING';
    rob42.health = 'WARTUNG ERFORDERLICH';
    rob42.rulHours = 24;
    rob42.warnings = [
      'Vibration 4.92 mm/s überschreitet ISO 10816 Grenze (3.5 mm/s)',
      'Temperaturerhöhung Getriebe Achse 2: 74.2 °C',
      'Predictive Maintenance Engine empfiehlt sofortige Entlastung'
    ];
  }

  // 2. Shift tasks to ROB-041 and ROB-043
  const rob41 = next.robots.find(r => r.id === 'ROB-041');
  const rob43 = next.robots.find(r => r.id === 'ROB-043');
  if (rob41) rob41.loadPercentage = 78;
  if (rob43) rob43.loadPercentage = 82;

  next.scenario = {
    activeScenarioId: 'SCENARIO_2_ROB42_FAILURE',
    stepIndex: 1,
    maxSteps: 3,
    description: 'Szenario 2: Predictive Maintenance & Automatische Umroutung ROB-042 auf ROB-041/043.',
    metrics: {
      throughputImpact: '0.0% Verlust (Puffer ausgeglichen)',
      downtimeAvoidedMin: 85,
      reroutedTasksCount: 14,
      optimizedSlottingPercent: 0,
    }
  };

  const newEvent: FactoryEvent = {
    eventId: `EVT-${Date.now()}`,
    timestamp: next.timeFormatted,
    simTimeSeconds: next.simTimeSeconds,
    entityId: 'ROB-042',
    entityType: 'ROBOT',
    eventType: 'PREDICTIVE_REROUTING_SUCCESS',
    location: 'HALLE 4 / LINIE-B01',
    severity: 'WARNING',
    message: 'Predictive Maintenance: ROB-042 entlastet. 14 Aufträge unterbrechungsfrei auf ROB-041 & ROB-043 umgeleitet. 85 min Stillstand vermieden.',
  };
  next.events = [newEvent, ...next.events.slice(0, 49)];

  return next;
}

export function triggerScenario3(state: FactoryFullState): FactoryFullState {
  const next = JSON.parse(JSON.stringify(state)) as FactoryFullState;
  
  // 1. Simulate Aisle B at 96% and optimize to Aisle D & E
  next.warehouse = next.warehouse.map(bin => {
    if (bin.aisle === 'B' && bin.status === 'BELEGT' && Math.random() < 0.35) {
      return {
        ...bin,
        status: 'LEER' as const,
        occupied: 0,
        partId: null,
        partName: null,
      };
    }
    if ((bin.aisle === 'D' || bin.aisle === 'E') && bin.status === 'LEER' && Math.random() < 0.4) {
      return {
        ...bin,
        status: 'BELEGT' as const,
        occupied: 14,
        partId: 'PART-E7-010',
        partName: 'Hochvolt-Batteriemodul 800V NMC',
      };
    }
    return bin;
  });

  next.scenario = {
    activeScenarioId: 'SCENARIO_3_WAREHOUSE_BOTTLENECK',
    stepIndex: 1,
    maxSteps: 2,
    description: 'Szenario 3: Lager-Engpass in Gang B detektiert. Slotting-Optimierung & dynamische Entzerrung auf Gang D & E aktiv.',
    metrics: {
      throughputImpact: '+14.2% Durchlaufzeitverkürzung',
      downtimeAvoidedMin: 45,
      reroutedTasksCount: 26,
      optimizedSlottingPercent: 92.8,
    }
  };

  const newEvent: FactoryEvent = {
    eventId: `EVT-${Date.now()}`,
    timestamp: next.timeFormatted,
    simTimeSeconds: next.simTimeSeconds,
    entityId: 'WAREHOUSE-AISLE-B',
    entityType: 'WAREHOUSE',
    eventType: 'SLOTTING_OPTIMIZATION_EXECUTED',
    location: 'HOCHREGALLAGER GANG B / D / E',
    severity: 'SUCCESS',
    message: 'Slotting-Optimierer (lpSolve/heuristic): 26 Ladeeinheiten aus überlastetem Gang B in Gang D/E umverteilt. AGV-Wartezeit um 38% gesenkt.',
  };
  next.events = [newEvent, ...next.events.slice(0, 49)];

  return next;
}

export function resetScenario(state: FactoryFullState): FactoryFullState {
  const next = JSON.parse(JSON.stringify(state)) as FactoryFullState;
  next.scenario = {
    activeScenarioId: 'NONE',
    stepIndex: 0,
    maxSteps: 0,
    description: 'Standardbetrieb: Kontinuierliche Fertigungsvolumen-Steuerung aktiv.',
    metrics: {
      throughputImpact: '±0.0%',
      downtimeAvoidedMin: 0,
      reroutedTasksCount: 0,
      optimizedSlottingPercent: 0,
    }
  };
  return next;
}

export class FactorySimulationEngine {
  private state: FactoryFullState;
  private timer: NodeJS.Timeout | null = null;
  private listeners: Set<(state: FactoryFullState) => void> = new Set();

  constructor() {
    this.state = createInitialFactoryState();
    this.start();
  }

  public getState(): FactoryFullState {
    return this.state;
  }

  public subscribe(fn: (state: FactoryFullState) => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  private notify() {
    this.listeners.forEach((fn) => fn(this.state));
  }

  public start() {
    if (this.timer) return;
    this.state = { ...this.state, isRunning: true };
    this.notify();
    this.timer = setInterval(() => {
      if (this.state.isRunning) {
        // Compute dt based on timeFactor (e.g. 1s per 100ms interval)
        const dt = Math.max(1, Math.round(this.state.timeFactor * 0.1));
        this.state = stepSimulationTick(this.state, dt);
        this.notify();
      }
    }, 100);
  }

  public pause() {
    this.state = { ...this.state, isRunning: false };
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
    this.notify();
  }

  public stop() {
    this.pause();
  }

  public stepTick(dt = 1) {
    this.state = stepSimulationTick(this.state, dt);
    this.notify();
  }

  public reset() {
    const isRunning = this.state.isRunning;
    this.state = createInitialFactoryState();
    this.state.isRunning = isRunning;
    this.notify();
  }

  public setTimeFactor(factor: number) {
    this.state = { ...this.state, timeFactor: factor };
    this.notify();
  }

  public setUserRole(role: UserRole) {
    this.state = { ...this.state, activeRole: role };
    this.notify();
  }

  public triggerScenario1() {
    this.state = triggerScenario1(this.state);
    this.notify();
  }

  public advanceScenario1Step() {
    this.state = advanceScenario1Step(this.state);
    this.notify();
  }

  public triggerScenario2() {
    this.state = triggerScenario2(this.state);
    this.notify();
  }

  public triggerScenario3() {
    this.state = triggerScenario3(this.state);
    this.notify();
  }

  public resetScenario() {
    this.state = resetScenario(this.state);
    this.notify();
  }
}

