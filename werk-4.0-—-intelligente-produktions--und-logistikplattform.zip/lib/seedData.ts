// ============================================================================
// WERK 4.0 — SYNTHETISCHE FABRIKDATEN (AUTOMOBILWERK SÜD - WERK 07)
// 5 Hallen, 12 Linien, 40 Maschinen, 60 Roboter, 250 Lagerplätze, 500 Bauteile, 100 Aufträge, 22 AGVs
// ============================================================================

import {
  ProductionHallEntity,
  ProductionLineEntity,
  MachineEntity,
  RobotEntity,
  WarehouseBinEntity,
  PartEntity,
  AGVEntity,
  ProductionOrderEntity,
  QualityMeasurement,
  EnergyLoadEntity,
  FactoryEvent,
  AuditLogEntry
} from './types';
import { forwardKinematics } from './kinematics';

// 1. PRODUKTIONSHALLEN (5 Hallen)
export const SEED_HALLS: ProductionHallEntity[] = [
  {
    id: 'HALLE-01',
    name: 'HALLE 1 — PRESSWERK & UMFORMTECHNIK',
    code: 'H1-PRS',
    areaSqm: 18500,
    temperature: 21.4,
    humidity: 48,
    lines: ['LINIE-P01', 'LINIE-P02'],
    totalPowerMw: 4.8,
  },
  {
    id: 'HALLE-02',
    name: 'HALLE 2 — KAROSSERIEBAU & SCHWEISSZENTRUM',
    code: 'H2-KARO',
    areaSqm: 26000,
    temperature: 22.1,
    humidity: 45,
    lines: ['LINIE-K01', 'LINIE-K02', 'LINIE-K03'],
    totalPowerMw: 5.9,
  },
  {
    id: 'HALLE-03',
    name: 'HALLE 3 — LACKIEREREI & KTL-BESCHICHTUNG',
    code: 'H3-LACK',
    areaSqm: 22000,
    temperature: 23.5,
    humidity: 55,
    lines: ['LINIE-L01', 'LINIE-L02'],
    totalPowerMw: 3.2,
  },
  {
    id: 'HALLE-04',
    name: 'HALLE 4 — ELEKTROANTRIEB & BATTERIEMONTAGE',
    code: 'H4-BAT',
    areaSqm: 19500,
    temperature: 20.8,
    humidity: 38,
    lines: ['LINIE-A01', 'LINIE-B01'],
    totalPowerMw: 2.7,
  },
  {
    id: 'HALLE-05',
    name: 'HALLE 5 — ENDMONTAGE, HOCHREGALLAGER & FINISH',
    code: 'H5-MONT',
    areaSqm: 34000,
    temperature: 21.8,
    humidity: 44,
    lines: ['LINIE-M01', 'LINIE-M02', 'LINIE-M03'],
    totalPowerMw: 2.1,
  },
];

// 2. PRODUKTIONSLINIEN (12 Linien)
export const SEED_LINES: ProductionLineEntity[] = [
  { id: 'LINIE-P01', name: 'Pressenstraße A (Seitenwand & Dach)', hallId: 'HALLE-01', targetTakt: 48, actualTakt: 49.2, isTaktExceeded: false, status: 'RUNNING', throughputPerHour: 73, oee: 0.924, machines: ['MAS-01', 'MAS-02', 'MAS-03'], robots: ['ROB-001', 'ROB-002', 'ROB-003', 'ROB-004'], currentVariant: 'E-Limousine E7' },
  { id: 'LINIE-P02', name: 'Pressenstraße B (Türen & Hauben)', hallId: 'HALLE-01', targetTakt: 52, actualTakt: 51.8, isTaktExceeded: false, status: 'RUNNING', throughputPerHour: 69, oee: 0.941, machines: ['MAS-04', 'MAS-05', 'MAS-06'], robots: ['ROB-005', 'ROB-006', 'ROB-007', 'ROB-008'], currentVariant: 'E-SUV E9' },
  { id: 'LINIE-K01', name: 'Unterboden-Schweißlinie', hallId: 'HALLE-02', targetTakt: 60, actualTakt: 59.4, isTaktExceeded: false, status: 'RUNNING', throughputPerHour: 60, oee: 0.918, machines: ['MAS-07', 'MAS-08', 'MAS-09', 'MAS-10'], robots: ['ROB-009', 'ROB-010', 'ROB-011', 'ROB-012', 'ROB-013'], currentVariant: 'E-Limousine E7' },
  { id: 'LINIE-K02', name: 'Aufbau- & Seitenwandzelle K-07', hallId: 'HALLE-02', targetTakt: 60, actualTakt: 64.2, isTaktExceeded: true, status: 'DEGRADED', throughputPerHour: 56, oee: 0.865, machines: ['MAS-11', 'MAS-12', 'MAS-13'], robots: ['ROB-014', 'ROB-015', 'ROB-016', 'ROB-017', 'ROB-018'], currentVariant: 'E-Limousine E7' },
  { id: 'LINIE-K03', name: 'Geometrie-Finish & Laserschweißen', hallId: 'HALLE-02', targetTakt: 58, actualTakt: 57.9, isTaktExceeded: false, status: 'RUNNING', throughputPerHour: 62, oee: 0.932, machines: ['MAS-14', 'MAS-15', 'MAS-16'], robots: ['ROB-019', 'ROB-020', 'ROB-021', 'ROB-022', 'ROB-023'], currentVariant: 'E-SUV E9' },
  { id: 'LINIE-L01', name: 'KTL-Tauchgrundierung & Trocknung', hallId: 'HALLE-03', targetTakt: 65, actualTakt: 65.0, isTaktExceeded: false, status: 'RUNNING', throughputPerHour: 55, oee: 0.955, machines: ['MAS-17', 'MAS-18', 'MAS-19'], robots: ['ROB-024', 'ROB-025', 'ROB-026', 'ROB-027'], currentVariant: 'E-Limousine E7' },
  { id: 'LINIE-L02', name: 'Roboter-Decklack & Klarlackstraße', hallId: 'HALLE-03', targetTakt: 60, actualTakt: 61.1, isTaktExceeded: false, status: 'RUNNING', throughputPerHour: 59, oee: 0.908, machines: ['MAS-20', 'MAS-21', 'MAS-22', 'MAS-23'], robots: ['ROB-028', 'ROB-029', 'ROB-030', 'ROB-031', 'ROB-032'], currentVariant: 'E-SUV E9' },
  { id: 'LINIE-A01', name: 'E-Maschinen-Stator/Rotor-Montage', hallId: 'HALLE-04', targetTakt: 45, actualTakt: 44.5, isTaktExceeded: false, status: 'RUNNING', throughputPerHour: 80, oee: 0.938, machines: ['MAS-24', 'MAS-25', 'MAS-26'], robots: ['ROB-033', 'ROB-034', 'ROB-035', 'ROB-036', 'ROB-037'], currentVariant: 'Antriebsstrang 220kW SiC' },
  { id: 'LINIE-B01', name: 'Hochvolt-Batteriepack-Zusammenbau', hallId: 'HALLE-04', targetTakt: 55, actualTakt: 56.2, isTaktExceeded: false, status: 'RUNNING', throughputPerHour: 64, oee: 0.912, machines: ['MAS-27', 'MAS-28', 'MAS-29', 'MAS-30'], robots: ['ROB-038', 'ROB-039', 'ROB-040', 'ROB-041', 'ROB-042'], currentVariant: '800V NMC Pack 100kWh' },
  { id: 'LINIE-M01', name: 'Hochzeit (Karosserie + Antrieb)', hallId: 'HALLE-05', targetTakt: 62, actualTakt: 61.8, isTaktExceeded: false, status: 'RUNNING', throughputPerHour: 58, oee: 0.947, machines: ['MAS-31', 'MAS-32', 'MAS-33'], robots: ['ROB-043', 'ROB-044', 'ROB-045', 'ROB-046', 'ROB-047'], currentVariant: 'E-Limousine E7' },
  { id: 'LINIE-M02', name: 'Innenraum- & Cockpit-Roboterzelle', hallId: 'HALLE-05', targetTakt: 62, actualTakt: 63.1, isTaktExceeded: false, status: 'RUNNING', throughputPerHour: 57, oee: 0.895, machines: ['MAS-34', 'MAS-35', 'MAS-36', 'MAS-37'], robots: ['ROB-048', 'ROB-049', 'ROB-050', 'ROB-051', 'ROB-052', 'ROB-053'], currentVariant: 'E-Limousine E7' },
  { id: 'LINIE-M03', name: 'Räder, Verglasung & EOL-Prüfstand', hallId: 'HALLE-05', targetTakt: 60, actualTakt: 59.9, isTaktExceeded: false, status: 'RUNNING', throughputPerHour: 60, oee: 0.962, machines: ['MAS-38', 'MAS-39', 'MAS-40'], robots: ['ROB-054', 'ROB-055', 'ROB-056', 'ROB-057', 'ROB-058', 'ROB-059', 'ROB-060'], currentVariant: 'E-SUV E9' },
];

// 3. MASCHINEN (40 Maschinen)
export const SEED_MACHINES: MachineEntity[] = Array.from({ length: 40 }, (_, idx) => {
  const num = idx + 1;
  const id = `MAS-${num < 10 ? '0' + num : num}`;
  const types = [
    'Schuler Servo-Transferpresse 25.000 kN',
    'Trumpf 3D-Laserschneidanlage TruLaser Cell 7040',
    'KUKA Schweißportal mit adaptiver Nahtregelung',
    'Dürr EcoRP L Lackierkabine mit Zerstäuber EcoBell4',
    'Aumann Batteriezellen-Stapelanlage & Laserschweißung',
    'Dürr Automatisierte Hochzeitsverschraubung (16 Spindeln)',
    'Zeiss 3D-Koordinatenmessmaschine ACCURA 2000',
    'Atlas Copco Drehmoment-Schraubstation Tensor Revo',
  ];
  const type = types[idx % types.length];
  const hallId = num <= 6 ? 'HALLE-01' : num <= 16 ? 'HALLE-02' : num <= 23 ? 'HALLE-03' : num <= 30 ? 'HALLE-04' : 'HALLE-05';
  const lineIdx = Math.min(11, Math.floor(idx / 3.33));
  const lineId = SEED_LINES[lineIdx].id;

  const availability = 0.94 + ((idx * 7) % 50) / 1000;
  const performance = 0.92 + ((idx * 11) % 60) / 1000;
  const quality = 0.97 + ((idx * 13) % 28) / 1000;

  return {
    id,
    name: `${type.split(' ')[0]} ${id}`,
    hallId,
    lineId,
    type,
    status: (idx === 11 ? 'BLOCKED' : idx === 27 ? 'SETUP' : 'RUNNING') as MachineEntity['status'],
    oee: {
      availability: Math.round(availability * 1000) / 1000,
      performance: Math.round(performance * 1000) / 1000,
      quality: Math.round(quality * 1000) / 1000,
      total: Math.round(availability * performance * quality * 1000) / 1000,
    },
    taktTimeTarget: 60,
    taktTimeActual: idx === 11 ? 64.2 : 58.5 + (idx % 4),
    powerDrawKw: Math.round((45 + (idx * 17) % 180) * 10) / 10,
    currentOrderId: `FA-2026-018${40 + (idx % 20)}`,
    totalPiecesProduced: 12400 + idx * 340,
    rejectPieces: Math.round((12400 + idx * 340) * 0.008),
    uptimeHours: 3420 + idx * 85,
    health: idx === 11 ? 'BEOBACHTEN' : idx === 28 ? 'WARTUNG ERFORDERLICH' : 'GESUND',
  };
});

// 4. BAUTEILTYPEN (500 synthetische Bauteiltypen)
export const SEED_PARTS: PartEntity[] = [
  { id: 'PART-E7-001', name: 'Seitenwandrahmen links hochfest (Alu-Druckguss)', category: 'BODY', standardStock: 240, currentStock: 182, reorderLevel: 60, supplier: 'Hydro Aluminium Extrusion SE', weightKg: 14.8, nominalDimensions: { l: 2850, w: 1240, h: 420 }, toleranceMm: 0.05 },
  { id: 'PART-E7-002', name: 'Seitenwandrahmen rechts hochfest (Alu-Druckguss)', category: 'BODY', standardStock: 240, currentStock: 195, reorderLevel: 60, supplier: 'Hydro Aluminium Extrusion SE', weightKg: 14.8, nominalDimensions: { l: 2850, w: 1240, h: 420 }, toleranceMm: 0.05 },
  { id: 'PART-E7-010', name: 'Hochvolt-Batteriemodul 800V NMC811 (12 kWh)', category: 'BATTERY', standardStock: 600, currentStock: 480, reorderLevel: 150, supplier: 'CellTech Battery Gigafactory GmbH', weightKg: 68.5, nominalDimensions: { l: 640, w: 380, h: 115 }, toleranceMm: 0.03 },
  { id: 'PART-E7-011', name: 'Batteriegehäuse-Unterteil Giga-Casting (Alu)', category: 'BATTERY', standardStock: 120, currentStock: 88, reorderLevel: 30, supplier: 'Nemak Europe Casting GmbH', weightKg: 52.0, nominalDimensions: { l: 2150, w: 1450, h: 180 }, toleranceMm: 0.08 },
  { id: 'PART-E7-020', name: 'Permanenterregte Synchronmaschine 220 kW Heck', category: 'POWERTRAIN', standardStock: 180, currentStock: 142, reorderLevel: 45, supplier: 'ZF Friedrichshafen AG', weightKg: 78.2, nominalDimensions: { l: 480, w: 420, h: 390 }, toleranceMm: 0.02 },
  { id: 'PART-E7-021', name: 'SiC-Hochvolt-Inverter 800V / 650A mit Dual-DSP', category: 'POWERTRAIN', standardStock: 180, currentStock: 138, reorderLevel: 45, supplier: 'Bosch Mobility Solutions', weightKg: 9.4, nominalDimensions: { l: 310, w: 240, h: 110 }, toleranceMm: 0.02 },
  { id: 'PART-E7-030', name: 'Vorderachs-Hilfsrahmen mit Mehrlenkeraufhängung', category: 'CHASSIS', standardStock: 150, currentStock: 114, reorderLevel: 40, supplier: 'Benteler Automobiltechnik GmbH', weightKg: 38.6, nominalDimensions: { l: 1120, w: 890, h: 310 }, toleranceMm: 0.05 },
  { id: 'PART-E7-035', name: 'Keramik-Verbundbremsscheibe 380mm gelocht', category: 'CHASSIS', standardStock: 400, currentStock: 312, reorderLevel: 80, supplier: 'Brembo SGL Carbon Ceramic SpA', weightKg: 6.8, nominalDimensions: { l: 380, w: 380, h: 65 }, toleranceMm: 0.01 },
  { id: 'PART-E7-040', name: 'Cockpit-Querträger Magnesium mit HUD-Aufnahme', category: 'INTERIOR', standardStock: 160, currentStock: 125, reorderLevel: 40, supplier: 'Faurecia Interior Systems', weightKg: 8.2, nominalDimensions: { l: 1420, w: 320, h: 280 }, toleranceMm: 0.05 },
  { id: 'PART-E7-045', name: 'Zentralrechner Automotive Supercomputer Dual-SoC', category: 'ELECTRONICS', standardStock: 250, currentStock: 198, reorderLevel: 50, supplier: 'Continental Automotive Technologies', weightKg: 3.1, nominalDimensions: { l: 260, w: 210, h: 75 }, toleranceMm: 0.01 },
  ...Array.from({ length: 490 }, (_, i) => {
    const pNum = i + 12;
    const cats: PartEntity['category'][] = ['BODY', 'POWERTRAIN', 'BATTERY', 'CHASSIS', 'ELECTRONICS', 'INTERIOR'];
    const cat = cats[i % cats.length];
    return {
      id: `PART-E7-${pNum < 100 ? '0' + pNum : pNum}`,
      name: `${cat === 'BODY' ? 'Karosseriestrukturteil' : cat === 'BATTERY' ? 'Batteriezellen-Kontaktierung' : cat === 'POWERTRAIN' ? 'Planetengetriebesatz' : cat === 'CHASSIS' ? 'Stoßdämpfer-Adaptivventil' : cat === 'ELECTRONICS' ? 'Radar-LiDAR Sensorbaugruppe' : 'Türinnenverkleidung Leder'} Modul #${pNum}`,
      category: cat,
      standardStock: 150 + (i * 13) % 300,
      currentStock: 90 + (i * 17) % 240,
      reorderLevel: 40 + (i * 5) % 80,
      supplier: ['Bosch Mobility', 'Schaeffler AG', 'Mahle GmbH', 'Infineon Technologies', 'Hella KGaA', 'Dräxlmaier Group'][i % 6],
      weightKg: Math.round((0.5 + (i * 7 % 45)) * 10) / 10,
      nominalDimensions: { l: 100 + (i * 8 % 800), w: 80 + (i * 6 % 400), h: 40 + (i * 4 % 200) },
      toleranceMm: 0.05,
    };
  }),
];

// 5. HOCHREGALLAGER (250 Lagerplätze: Gänge A, B, C, D, E x Racks 01-10 x Ebenen 1-5 = 250 Bins)
export const SEED_WAREHOUSE: WarehouseBinEntity[] = [];
const aisles = ['A', 'B', 'C', 'D', 'E'];
for (const aisle of aisles) {
  for (let rackNum = 1; rackNum <= 10; rackNum++) {
    const rackStr = rackNum < 10 ? '0' + rackNum : `${rackNum}`;
    for (let level = 1; level <= 5; level++) {
      const id = `${aisle}-${rackStr}-${level < 10 ? '0' + level : level}-01`;
      const binIndex = SEED_WAREHOUSE.length;
      
      // Szenario 3: Gang B ist 95% ausgelastet
      let isOccupied = true;
      let status: WarehouseBinEntity['status'] = 'BELEGT';
      let occRatio = 0.85;

      if (aisle === 'B') {
        occRatio = 0.96;
        isOccupied = Math.random() < 0.96;
        status = isOccupied ? 'BELEGT' : 'LEER';
      } else if (aisle === 'D' || aisle === 'E') {
        isOccupied = binIndex % 4 !== 0;
        status = !isOccupied ? 'LEER' : (binIndex % 7 === 0 ? 'RESERVIERT' : 'BELEGT');
      } else {
        isOccupied = binIndex % 6 !== 0;
        status = !isOccupied ? 'LEER' : 'BELEGT';
      }

      if (id === 'B-04-03-01' || id === 'B-05-02-01') {
        status = 'BLOCKIERT'; // Mechanischer Shuttle-Wartungsblock
      }

      const part = isOccupied ? SEED_PARTS[binIndex % SEED_PARTS.length] : null;
      const capacity = 20;
      const occupiedUnits = isOccupied ? (status === 'RESERVIERT' ? 12 : Math.floor(10 + (binIndex * 7 % 10))) : 0;

      SEED_WAREHOUSE.push({
        id,
        aisle,
        rack: rackStr,
        level,
        bin: 1,
        capacity,
        occupied: occupiedUnits,
        partId: part ? part.id : null,
        partName: part ? part.name : null,
        batchNumber: part ? `CHG-2026-${1000 + binIndex * 3}` : null,
        reserved: status === 'RESERVIERT' ? 8 : (status === 'BELEGT' && binIndex % 5 === 0 ? 4 : 0),
        status,
        targetCellId: isOccupied ? `ZELLE-K0${(binIndex % 8) + 1}` : undefined,
        weightKg: part ? Math.round(part.weightKg * occupiedUnits * 10) / 10 : 0,
      });
    }
  }
}

// 6. ROBOTER (60 6-Achs Industrieroboter mit Kinematik & Telemetrie)
export const SEED_ROBOTS: RobotEntity[] = Array.from({ length: 60 }, (_, idx) => {
  const num = idx + 1;
  const id = `ROB-${num < 10 ? '00' + num : num < 100 ? '0' + num : num}`;
  const hallIdx = Math.min(4, Math.floor(idx / 12));
  const hall = SEED_HALLS[hallIdx];
  const lineIdx = Math.min(11, Math.floor(idx / 5));
  const line = SEED_LINES[lineIdx];
  const cellId = `ZELLE-${line.id.replace('LINIE-', '')}-0${(idx % 4) + 1}`;

  const tools = [
    'Punktschweißzange C-Typ 450 daN',
    'Vakuum-Matrixgreifer mit Konturabtastung',
    'Trumpf Laseroptik BEO D70 mit Schutzgasdüse',
    'Dürr Zerstäuber EcoBell4 Klarlack',
    'Atlas Copco Drehmoment-Schraubspindel EC',
    'Roboter-Dosiereinheit 2K-Strukturklebstoff',
    '3D-Vision Inspektion & Lasertriangulation',
  ];
  const tool = tools[idx % tools.length];

  // Gelenkwinkel mit realistischer Haltung
  const baseAngle = ((idx * 27) % 180) - 90;
  const shoulderAngle = -50 - ((idx * 11) % 40);
  const elbowAngle = 40 + ((idx * 13) % 50);
  const wrist1 = ((idx * 31) % 90) - 45;
  const wrist2 = - shoulderAngle - elbowAngle;
  const wrist3 = ((idx * 19) % 60) - 30;

  const joints = {
    q1: baseAngle,
    q2: shoulderAngle,
    q3: elbowAngle,
    q4: wrist1,
    q5: wrist2,
    q6: wrist3,
  };

  const fk = forwardKinematics(joints);

  // Szenario 2: ROB-042 hat erhöhte Vibrationen & thermischen Anstieg
  const isRob42 = id === 'ROB-042';
  const temperature = isRob42 ? 72.4 : 44.0 + ((idx * 7) % 18);
  const vibration = isRob42 ? 4.85 : 0.8 + ((idx * 3) % 15) / 10;
  const motorCurrent = isRob42 ? 24.8 : 12.0 + ((idx * 5) % 8);
  const wearIndex = isRob42 ? 0.88 : Math.round((0.15 + (idx * 13 % 60) / 100) * 100) / 100;
  const health: RobotEntity['health'] = isRob42 ? 'WARTUNG ERFORDERLICH' : wearIndex > 0.65 ? 'BEOBACHTEN' : 'GESUND';
  const rulHours = isRob42 ? 48 : 2800 - Math.round(wearIndex * 2200);

  const robotState: RobotEntity['status'] = isRob42
    ? 'WARNING'
    : (idx % 7 === 0 ? 'MOVING' : idx % 5 === 0 ? 'PICKING' : idx % 9 === 0 ? 'PLACING' : 'TASK_ASSIGNED');

  return {
    id,
    name: `KUKA KR 210 R2700 prime [${id}]`,
    hallId: hall.id,
    lineId: line.id,
    cellId,
    manufacturer: idx % 3 === 0 ? 'KUKA Robotics GmbH' : idx % 3 === 1 ? 'ABB Automation GmbH' : 'FANUC Robotics',
    model: idx % 3 === 0 ? 'KR 210 R2700 prime' : idx % 3 === 1 ? 'IRB 6700-205/2.80' : 'M-900iB/280L',
    payload: 210,
    reach: 2700,
    joints,
    jointVelocities: { q1: 12.4, q2: 8.2, q3: 10.5, q4: 18.0, q5: 15.2, q6: 22.0 },
    jointAccelerations: { q1: 4.5, q2: 3.1, q3: 3.8, q4: 6.2, q5: 5.5, q6: 7.8 },
    position: fk.endEffectorPos,
    targetPosition: { x: fk.endEffectorPos.x + 80, y: fk.endEffectorPos.y - 50, z: fk.endEffectorPos.z + 40 },
    orientation: fk.orientation,
    gripperState: idx % 2 === 0 ? 'CLOSED' : 'OPEN',
    tool,
    status: robotState,
    currentTask: {
      taskId: `TSK-2026-${1000 + idx}`,
      orderId: `FA-2026-018${40 + (idx % 15)}`,
      source: `LAGERPLATZ ${SEED_WAREHOUSE[idx * 3]?.id || 'A-01-01-01'}`,
      target: cellId,
      partId: SEED_PARTS[idx % SEED_PARTS.length].id,
      partName: SEED_PARTS[idx % SEED_PARTS.length].name,
      quantity: 1,
      priority: (idx % 3) + 1,
      startTime: 14.5,
      progress: (idx * 17) % 100,
      status: robotState,
    },
    temperature,
    vibration,
    motorCurrent,
    velocity: 1.45,
    acceleration: 2.1,
    loadPercentage: 45 + ((idx * 9) % 45),
    energyConsumption: 8.4 + ((idx * 3) % 7),
    cycleCount: 4812 + idx * 720,
    lastMaintenance: '2026-08-14',
    nextMaintenance: isRob42 ? '2026-09-22 (SOFORT)' : '2026-11-30',
    wearIndex,
    health,
    rulHours,
    warnings: isRob42 ? ['Vibration überschreitet ISO 10816 Schwellenwert (4.85 mm/s > 3.50 mm/s)', 'Kugellager Achse A2 Schmierfilm-Abriss detektiert'] : [],
  };
});

// 7. FAHRERLOSE TRANSPORTSYSTEME / AGVs (22 AGVs)
export const SEED_AGVS: AGVEntity[] = Array.from({ length: 22 }, (_, idx) => {
  const num = idx + 1;
  const id = `AGV-${num < 10 ? '0' + num : num}`;
  const statuses: AGVEntity['status'][] = ['MOVING', 'LOADING', 'UNLOADING', 'CHARGING', 'WAITING', 'IDLE'];
  const status = idx === 18 ? 'CHARGING' : statuses[idx % statuses.length];
  const batteryPercent = status === 'CHARGING' ? 32 + ((idx * 11) % 40) : 75 + ((idx * 5) % 24);

  return {
    id,
    name: `KUKA KMP 1500P FTS [${id}]`,
    batteryPercent,
    speed: status === 'MOVING' ? 1.4 : 0.0,
    position: {
      x: 120 + (idx * 38) % 700,
      y: 80 + (idx * 45) % 400,
      hallId: SEED_HALLS[idx % 5].id,
    },
    currentTaskId: `TRANSPORT-AUFTRAG-AGV-${200 + idx}`,
    sourceNode: idx % 2 === 0 ? 'HOCHREGALLAGER GANG A/B' : 'WARENEINGANG SUD',
    targetNode: `ZELLE-K0${(idx % 8) + 1}`,
    carryingPartId: status === 'MOVING' || status === 'LOADING' ? SEED_PARTS[idx % SEED_PARTS.length].id : null,
    status,
    totalDistanceKm: 1420 + idx * 85,
    utilizationPercent: 84 + (idx % 12),
    waitingTimeSeconds: (idx * 14) % 180,
  };
});

// 8. PRODUKTIONSAUFTRÄGE (100 Aufträge, inkl. FA-2026-01842)
export const SEED_ORDERS: ProductionOrderEntity[] = Array.from({ length: 100 }, (_, idx) => {
  const num = 1800 + idx;
  const orderId = `FA-2026-0${num}`;
  const isDemo = orderId === 'FA-2026-01842';
  const model = idx % 2 === 0 ? 'E-Limousine E7 Performance' : 'E-SUV E9 Long-Range';
  const progressPercent = isDemo ? 64 : (idx * 13) % 100;
  const status: ProductionOrderEntity['status'] = progressPercent === 100 ? 'COMPLETED' : progressPercent > 0 ? 'IN_PRODUCTION' : 'PLANNED';

  const stages = [
    '1. Wareneingang & Materialprüfung',
    '2. Hochregallager Kommissionierung',
    '3. AGV-Zellentransport',
    '4. Presswerk Karosserieteile',
    '5. Karosseriebau Zelle K-07',
    '6. KTL-Tauchgrundierung & Lackierung',
    '7. Batteriemontage 800V Pack',
    '8. Hochzeit & Endmontage',
    '9. 3D-Spaltmaß & Laser-Finish-Prüfung',
    '10. End-of-Line Prüfstand & Versand',
  ];

  const currentStageIndex = Math.min(stages.length - 1, Math.floor((progressPercent / 100) * stages.length));

  return {
    orderId,
    vin: `WBA7E004829${10 + idx}`,
    model,
    status,
    progressPercent,
    currentStage: stages[currentStageIndex],
    priority: isDemo ? 1 : (idx % 3) + 1,
    targetCompletion: '2026-09-22 17:00:00',
    actualStartTime: '2026-09-21 06:00:00',
    billOfMaterials: [
      { partId: 'PART-E7-001', partName: 'Seitenwandrahmen links hochfest', quantity: 1, allocated: true },
      { partId: 'PART-E7-002', partName: 'Seitenwandrahmen rechts hochfest', quantity: 1, allocated: true },
      { partId: 'PART-E7-010', partName: 'Hochvolt-Batteriemodul 800V NMC', quantity: 8, allocated: true },
      { partId: 'PART-E7-020', partName: 'Synchronmaschine 220 kW Heck', quantity: 1, allocated: true },
      { partId: 'PART-E7-021', partName: 'SiC-Hochvolt-Inverter 800V', quantity: 1, allocated: true },
      { partId: 'PART-E7-030', partName: 'Vorderachs-Hilfsrahmen', quantity: 1, allocated: true },
      { partId: 'PART-E7-040', partName: 'Cockpit-Querträger Magnesium', quantity: 1, allocated: true },
    ],
    stationsCompleted: stages.slice(0, currentStageIndex),
    defectFlags: isDemo ? [] : idx % 17 === 0 ? ['Spaltmaß Kotflügel +0.06mm (Nachjustiert)'] : [],
  };
});

// 9. SPC QUALITÄTSMESSUNGEN
export const SEED_QUALITY_MEASUREMENTS: QualityMeasurement[] = [
  { id: 'QM-10821', timestamp: '14:31:05', partId: 'PART-E7-001', partName: 'Seitenwand Karosserie', orderId: 'FA-2026-01842', station: 'Station K-07 (Vision CMM)', parameterName: 'Spaltmaß Tür/Kotflügel', nominalValue: 3.20, actualValue: 3.22, tolerancePlus: 0.05, toleranceMinus: 0.05, unit: 'mm', status: 'PASS', gapDimensionMm: 3.22 },
  { id: 'QM-10822', timestamp: '14:29:40', partId: 'PART-E7-020', partName: 'Elektromotor 220kW', orderId: 'FA-2026-01841', station: 'Station A-01 Prüffeld', parameterName: 'Drehmoment Rotorverschraubung', nominalValue: 125.0, actualValue: 125.4, tolerancePlus: 2.5, toleranceMinus: 2.5, unit: 'Nm', status: 'PASS', torqueNm: 125.4 },
  { id: 'QM-10823', timestamp: '14:28:12', partId: 'PART-E7-010', partName: 'Batteriemodul 800V', orderId: 'FA-2026-01840', station: 'Station B-01 Laserschweiß', parameterName: 'Schweißpunkttiefe Zellkontaktierung', nominalValue: 1.80, actualValue: 1.79, tolerancePlus: 0.08, toleranceMinus: 0.08, unit: 'mm', status: 'PASS', weldDepthMm: 1.79 },
  { id: 'QM-10824', timestamp: '14:25:50', partId: 'PART-E7-002', partName: 'Seitenwandrahmen rechts', orderId: 'FA-2026-01839', station: 'Station L-02 Lackoptik', parameterName: 'Klarlack-Schichtdicke', nominalValue: 45.0, actualValue: 46.2, tolerancePlus: 4.0, toleranceMinus: 4.0, unit: 'µm', status: 'PASS', paintThicknessUm: 46.2 },
  { id: 'QM-10825', timestamp: '14:22:15', partId: 'KARO-004812', partName: 'Türrohbau hinten links', orderId: 'FA-2026-01836', station: 'Station K-03 Laser-CMM', parameterName: 'Spaltmaß B-Säule', nominalValue: 3.20, actualValue: 3.27, tolerancePlus: 0.05, toleranceMinus: 0.05, unit: 'mm', status: 'FAIL', gapDimensionMm: 3.27 },
];

// 10. ENERGIE-LASTPROFIL (24 Stunden mit Peak-Shaving Optimierung)
export const SEED_ENERGY_PROFILE: EnergyLoadEntity[] = Array.from({ length: 24 }, (_, hour) => {
  const timeStr = `${hour < 10 ? '0' + hour : hour}:00`;
  // Typisches industrielles Lastprofil mit Spitzen um 10:00 - 15:00 Uhr
  const baseMw = 12.0;
  const shiftMultiplier = (hour >= 6 && hour <= 22) ? 1.5 : 0.8;
  const peakSpike = (hour === 11 || hour === 14) ? 3.8 : (hour >= 9 && hour <= 16 ? 2.1 : 0.5);

  const roboticsPowerMw = 4.2 * shiftMultiplier;
  const pressesPowerMw = (3.8 + peakSpike) * shiftMultiplier;
  const paintPowerMw = 3.5 * shiftMultiplier;
  const assemblyPowerMw = 2.4 * shiftMultiplier;
  const hvacPowerMw = 1.8;
  const warehousePowerMw = 1.2;

  const totalPowerMw = Math.round((roboticsPowerMw + pressesPowerMw + paintPowerMw + assemblyPowerMw + hvacPowerMw + warehousePowerMw) * 10) / 10;
  const peakThresholdMw = 21.0;
  // Optimierte Last mit Peak Shaving
  const optimizedPowerMw = totalPowerMw > peakThresholdMw ? Math.round((peakThresholdMw - 0.8) * 10) / 10 : totalPowerMw;

  return {
    timestamp: timeStr,
    totalPowerMw,
    roboticsPowerMw: Math.round(roboticsPowerMw * 10) / 10,
    pressesPowerMw: Math.round(pressesPowerMw * 10) / 10,
    paintPowerMw: Math.round(paintPowerMw * 10) / 10,
    assemblyPowerMw: Math.round(assemblyPowerMw * 10) / 10,
    hvacPowerMw,
    warehousePowerMw,
    peakThresholdMw,
    kwhPerCar: Math.round((580 + (hour % 5) * 15) * 10) / 10,
    optimizedPowerMw,
  };
});

// 11. INITIALE SYSTEM-EREIGNISSE
export const SEED_EVENTS: FactoryEvent[] = [
  { eventId: 'EVT-9001', timestamp: '14:32:18', simTimeSeconds: 52338, entityId: 'WERK-07', entityType: 'SAFETY', eventType: 'SYSTEM_ONLINE', location: 'LEITWARTE', severity: 'INFO', message: 'WERK 4.0 Simulation synchronisiert mit R-Kern. Alle 12 Linien im Takt.' },
  { eventId: 'EVT-9002', timestamp: '14:31:50', simTimeSeconds: 52310, entityId: 'ROB-042', entityType: 'ROBOT', eventType: 'PREDICTIVE_MAINTENANCE_ALERT', location: 'HALLE 4 / LINIE-B01', severity: 'WARNING', message: 'Vibrationsanstieg Achse 2 (4.85 mm/s > Grenzwert 3.50 mm/s). Wartung empfohlen.' },
  { eventId: 'EVT-9003', timestamp: '14:30:15', simTimeSeconds: 52215, entityId: 'AGV-04', entityType: 'AGV', eventType: 'AGV_ARRIVED', location: 'ZELLE-K07', severity: 'SUCCESS', message: 'FTS AGV-04 hat Karosseriebauteil PART-E7-001 an Roboter ROB-017 übergeben.' },
  { eventId: 'EVT-9004', timestamp: '14:28:44', simTimeSeconds: 52124, entityId: 'ORD-1842', entityType: 'ORDER', eventType: 'PRODUCTION_STEP_COMPLETED', location: 'KAROSSERIEBAU K-02', severity: 'INFO', message: 'Auftrag FA-2026-01842: Karosseriestruktur geschweißt. Weiterleitung an Lackiererei.' },
  { eventId: 'EVT-9005', timestamp: '14:25:50', simTimeSeconds: 51950, entityId: 'QM-10825', entityType: 'QUALITY', eventType: 'QUALITY_FAIL', location: 'STATION K-03 CMM', severity: 'CRITICAL', message: 'Spaltmaßprüfung KARO-004812: Ist 3.27 mm (Toleranz ±0.05 mm, Soll 3.20 mm). Nachjustierung ausgelöst.' },
];

// 12. AUDIT LOG INITIAL
export const SEED_AUDIT_LOGS: AuditLogEntry[] = [
  { id: 'AUD-001', timestamp: '14:30:00', user: 'Dr. T. Weber (Werksleiter)', role: 'WERKSLEITUNG', object: 'WERK 4.0', action: 'SIMULATION_START', oldValue: 'PAUSED', newValue: 'RUNNING (Faktor 100x)' },
  { id: 'AUD-002', timestamp: '14:20:12', user: 'M. Richter (Robotik-Ingenieur)', role: 'ROBOTIK', object: 'ROB-017', action: 'KINEMATICS_CALIBRATION', oldValue: 'Offset q2 = -0.4°', newValue: 'Offset q2 = 0.0°' },
  { id: 'AUD-003', timestamp: '14:15:45', user: 'S. Becker (Logistikleitung)', role: 'LOGISTIK', object: 'HOCHREGALLAGER GANG B', action: 'DYNAMIC_SLOTTING_OPT', oldValue: 'Zone B Static', newValue: 'Dynamic Re-Allocation D/E' },
  { id: 'AUD-004', timestamp: '14:02:18', user: 'H. Schneider (Energiemanager)', role: 'ENERGIE', object: 'PRESSENSTRASSE P01', action: 'PEAK_SHAVING_SHIFT', oldValue: 'Start 11:00', newValue: 'Start 11:45 (-1.8 MW Peak)' },
];
