// ============================================================================
// WERK 4.0 — TYPE DEFINITIONS (WERK40-R INDUSTRIELLE DATENMODELLE)
// ============================================================================

export type RobotState =
  | 'IDLE'
  | 'TASK_ASSIGNED'
  | 'PICKING'
  | 'MOVING'
  | 'PLACING'
  | 'RETURNING'
  | 'INSPECTION'
  | 'COMPLETE'
  | 'WARNING'
  | 'BLOCKED'
  | 'COLLISION_RISK'
  | 'OVERHEAT'
  | 'TOOL_FAILURE'
  | 'EMERGENCY_STOP'
  | 'MAINTENANCE';

export type MachineStatus = 'RUNNING' | 'IDLE' | 'SETUP' | 'BLOCKED' | 'MAINTENANCE' | 'STOPPED';

export type BinStatus = 'LEER' | 'BELEGT' | 'RESERVIERT' | 'BLOCKIERT';

export type AGVStatus = 'IDLE' | 'CHARGING' | 'ASSIGNED' | 'MOVING' | 'WAITING' | 'LOADING' | 'UNLOADING' | 'FAULT';

export type OrderStatus = 'PLANNED' | 'IN_PRODUCTION' | 'QUALITY_HOLD' | 'BUFFER' | 'COMPLETED' | 'CANCELLED';

export type UserRole =
  | 'WERKSLEITUNG'
  | 'PRODUKTIONSLEITUNG'
  | 'ROBOTIK'
  | 'LOGISTIK'
  | 'QUALITÄT'
  | 'INSTANDHALTUNG'
  | 'ENERGIE'
  | 'ADMIN';

export type MaintenanceHealth = 'GESUND' | 'BEOBACHTEN' | 'WARTUNG ERFORDERLICH';

export interface JointAngles {
  q1: number; // Base rotation [-180, 180] deg
  q2: number; // Shoulder [-90, 135] deg
  q3: number; // Elbow [-135, 135] deg
  q4: number; // Wrist 1 [-180, 180] deg
  q5: number; // Wrist 2 [-120, 120] deg
  q6: number; // Wrist 3 [-360, 360] deg
}

export interface Vector3D {
  x: number; // mm
  y: number; // mm
  z: number; // mm
}

export interface Orientation3D {
  roll: number;  // deg
  pitch: number; // deg
  yaw: number;   // deg
}

export interface RobotTask {
  taskId: string;
  orderId: string;
  source: string;
  target: string;
  partId: string;
  partName: string;
  quantity: number;
  priority: number; // 1 (hoch) - 5 (niedrig)
  startTime: number;
  endTime?: number;
  progress: number; // 0 - 100%
  status: RobotState;
}

export interface RobotEntity {
  id: string;              // e.g. "ROB-001"
  name: string;            // e.g. "KUKA KR QUANTEC prime"
  hallId: string;          // e.g. "HALLE-02"
  lineId: string;          // e.g. "LINIE-K01"
  cellId: string;          // e.g. "ZELLE-K07"
  manufacturer: string;    // "KUKA", "ABB", "FANUC"
  model: string;           // "KR 210 R2700 prime"
  payload: number;         // kg (e.g. 210)
  reach: number;           // mm (e.g. 2700)
  joints: JointAngles;
  jointVelocities: JointAngles;
  jointAccelerations: JointAngles;
  position: Vector3D;
  targetPosition: Vector3D;
  orientation: Orientation3D;
  gripperState: 'OPEN' | 'CLOSED' | 'HOLDING' | 'FAULT';
  tool: string;            // "Schweißzange C-Typ", "Vakuum-Matrixgreifer", "KTL-Applikator", "Schraubspindel"
  status: RobotState;
  currentTask: RobotTask | null;
  temperature: number;     // °C
  vibration: number;       // mm/s RMS
  motorCurrent: number;    // A
  velocity: number;        // m/s
  acceleration: number;    // m/s²
  loadPercentage: number;  // %
  energyConsumption: number; // kW
  cycleCount: number;
  lastMaintenance: string;
  nextMaintenance: string;
  wearIndex: number;       // 0.00 - 1.00
  health: MaintenanceHealth;
  rulHours: number;        // Remaining Useful Life in operating hours
  warnings: string[];
}

export interface MachineEntity {
  id: string;
  name: string;
  hallId: string;
  lineId: string;
  type: string;
  status: MachineStatus;
  oee: {
    availability: number; // 0.0 - 1.0
    performance: number;  // 0.0 - 1.0
    quality: number;      // 0.0 - 1.0
    total: number;        // availability * performance * quality
  };
  taktTimeTarget: number; // sec (z.B. 62 s)
  taktTimeActual: number; // sec
  powerDrawKw: number;
  currentOrderId: string | null;
  totalPiecesProduced: number;
  rejectPieces: number;
  uptimeHours: number;
  health: MaintenanceHealth;
}

export interface ProductionLineEntity {
  id: string;
  name: string;
  hallId: string;
  targetTakt: number; // s
  actualTakt: number; // s
  isTaktExceeded: boolean;
  status: 'RUNNING' | 'DEGRADED' | 'STOPPED';
  throughputPerHour: number;
  oee: number;
  machines: string[];
  robots: string[];
  currentVariant: string;
}

export interface ProductionHallEntity {
  id: string;
  name: string;
  code: string;
  areaSqm: number;
  temperature: number;
  humidity: number;
  lines: string[];
  totalPowerMw: number;
}

export interface WarehouseBinEntity {
  id: string;        // e.g. "A-02-03-01"
  aisle: string;     // "A", "B", "C", "D", "E"
  rack: string;      // "01" - "10"
  level: number;     // 1 - 5
  bin: number;       // 1 - 5
  capacity: number;  // max units
  occupied: number;  // current units
  partId: string | null;
  partName: string | null;
  batchNumber: string | null;
  reserved: number;
  status: BinStatus;
  targetCellId?: string;
  weightKg: number;
}

export interface PartEntity {
  id: string;         // e.g. "PART-E7-048"
  name: string;       // e.g. "Hochvolt-Batteriemodul 800V NMC"
  category: 'BODY' | 'POWERTRAIN' | 'BATTERY' | 'CHASSIS' | 'ELECTRONICS' | 'INTERIOR';
  standardStock: number;
  currentStock: number;
  reorderLevel: number;
  supplier: string;
  weightKg: number;
  nominalDimensions: { l: number; w: number; h: number };
  toleranceMm: number;
}

export interface AGVEntity {
  id: string;
  name: string;
  batteryPercent: number;
  speed: number;       // m/s
  position: { x: number; y: number; hallId: string };
  currentTaskId: string | null;
  sourceNode: string;
  targetNode: string;
  carryingPartId: string | null;
  status: AGVStatus;
  totalDistanceKm: number;
  utilizationPercent: number;
  waitingTimeSeconds: number;
}

export interface ProductionOrderEntity {
  orderId: string;     // e.g. "FA-2026-01842"
  vin: string;         // e.g. "WBA7E00482910"
  model: string;       // "E-Limousine E7 Performance" | "E-SUV E9 Long-Range"
  status: OrderStatus;
  progressPercent: number;
  currentStage: string;
  priority: number;
  targetCompletion: string;
  actualStartTime: string;
  billOfMaterials: {
    partId: string;
    partName: string;
    quantity: number;
    allocated: boolean;
  }[];
  stationsCompleted: string[];
  defectFlags: string[];
}

export interface QualityMeasurement {
  id: string;
  timestamp: string;
  partId: string;
  partName: string;
  orderId: string;
  station: string;
  parameterName: string;
  nominalValue: number;
  actualValue: number;
  tolerancePlus: number;
  toleranceMinus: number;
  unit: string;
  status: 'PASS' | 'WARNING' | 'FAIL';
  gapDimensionMm?: number;
  torqueNm?: number;
  weldDepthMm?: number;
  paintThicknessUm?: number;
}

export interface QualitySPCStats {
  parameter: string;
  mean: number;
  sigma: number;
  cp: number;
  cpk: number;
  upperSpecLimit: number;
  lowerSpecLimit: number;
  target: number;
  samples: number;
  defectRatePpm: number;
}

export interface FactoryEnergyData {
  currentTotalLoadMW: number;
  kwhPerVehicle: number;
  costPerVehicleEur: number;
  co2PerVehicleKg: number;
  renewablePercentage: number;
  transformerLoadPercent: number;
  peakShavingPotentialMW: number;
}

export interface EnergyLoadEntity {
  timestamp: string;
  totalPowerMw: number;
  roboticsPowerMw: number;
  pressesPowerMw: number;
  paintPowerMw: number;
  assemblyPowerMw: number;
  hvacPowerMw: number;
  warehousePowerMw: number;
  peakThresholdMw: number;
  kwhPerCar: number;
  optimizedPowerMw: number;
}

export interface FactoryEvent {
  eventId: string;
  timestamp: string;
  simTimeSeconds: number;
  entityId: string;
  entityType: 'ROBOT' | 'MACHINE' | 'AGV' | 'WAREHOUSE' | 'QUALITY' | 'ENERGY' | 'ORDER' | 'SAFETY';
  eventType: string;
  location: string;
  severity: 'INFO' | 'SUCCESS' | 'WARNING' | 'CRITICAL';
  message: string;
  payload?: Record<string, unknown>;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  user: string;
  role: UserRole;
  object: string;
  action: string;
  oldValue: string;
  newValue: string;
}

export interface ScenarioState {
  activeScenarioId: 'NONE' | 'SCENARIO_1_E_AUTO' | 'SCENARIO_2_ROB42_FAILURE' | 'SCENARIO_3_WAREHOUSE_BOTTLENECK';
  stepIndex: number;
  maxSteps: number;
  description: string;
  metrics: {
    throughputImpact: string;
    downtimeAvoidedMin: number;
    reroutedTasksCount: number;
    optimizedSlottingPercent: number;
  };
}
