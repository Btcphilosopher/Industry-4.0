// ============================================================================
// WERK 4.0 — HOCHREGALLAGER DIGITAL TWIN (250 LAGERPLÄTZE GÄNGE A-E)
// ============================================================================

import React, { useState } from 'react';
import { WarehouseBinEntity } from '../lib/types';
import { Box, Search, Filter, Sparkles, CheckCircle2, AlertTriangle, Layers } from 'lucide-react';

interface Props {
  bins: WarehouseBinEntity[];
  onTriggerOptimization?: () => void;
}

export const WarehouseGrid: React.FC<Props> = ({ bins, onTriggerOptimization }) => {
  const [selectedAisle, setSelectedAisle] = useState<string>('ALL');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBin, setSelectedBin] = useState<WarehouseBinEntity | null>(bins[0] || null);

  const aisles = ['ALL', 'A', 'B', 'C', 'D', 'E'];

  const filteredBins = bins.filter((b) => {
    if (selectedAisle !== 'ALL' && b.aisle !== selectedAisle) return false;
    if (filterStatus !== 'ALL' && b.status !== filterStatus) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const matchId = b.id.toLowerCase().includes(q);
      const matchPart = b.partName?.toLowerCase().includes(q) || false;
      const matchBatch = b.batchNumber?.toLowerCase().includes(q) || false;
      if (!matchId && !matchPart && !matchBatch) return false;
    }
    return true;
  });

  // Calculate aisle statistics
  const aisleStats = ['A', 'B', 'C', 'D', 'E'].map((a) => {
    const aisleBins = bins.filter((b) => b.aisle === a);
    const occupied = aisleBins.filter((b) => b.status === 'BELEGT' || b.status === 'RESERVIERT').length;
    const ratio = Math.round((occupied / aisleBins.length) * 100);
    return { aisle: a, count: aisleBins.length, occupied, ratio };
  });

  return (
    <div className="bg-[#0d1117] border border-[#21262d] p-4 text-[#e6edf3]">
      {/* Header & Controls */}
      <div className="flex flex-wrap items-center justify-between pb-3 border-b border-[#21262d] gap-2">
        <div className="flex items-center gap-2">
          <Box className="w-5 h-5 text-[#818cf8]" />
          <div>
            <div className="font-mono font-bold text-sm text-[#f0f6fc]">
              HOCHREGALLAGER DIGITAL TWIN (HRL 07)
            </div>
            <div className="text-[11px] font-mono text-[#8b949e]">
              250 Lagerplätze | 5 Gänge (A-E) | 10 Regale je Gang | 5 Ebenen
            </div>
          </div>
        </div>

        {onTriggerOptimization && (
          <button
            onClick={onTriggerOptimization}
            id="run-slotting-opt-btn"
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#4338ca] hover:bg-[#4f46e5] text-white font-mono text-xs font-bold border border-[#6366f1] transition-all"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#facc15]" />
            <span>DYNAMIC SLOTTING OPTIMIEREN (lpSolve)</span>
          </button>
        )}
      </div>

      {/* Aisle Utilization Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 my-3">
        {aisleStats.map((s) => (
          <button
            key={s.aisle}
            onClick={() => setSelectedAisle(selectedAisle === s.aisle ? 'ALL' : s.aisle)}
            className={`p-2 border text-left font-mono text-xs transition-all ${
              selectedAisle === s.aisle
                ? 'bg-[#1e1b4b] border-[#818cf8] text-white'
                : 'bg-[#161b22] border-[#30363d] text-[#c9d1d9] hover:bg-[#21262d]'
            }`}
          >
            <div className="flex justify-between items-center">
              <span className="font-bold">GANG {s.aisle}</span>
              <span className={`text-[11px] font-bold ${s.ratio >= 95 ? 'text-[#f87171]' : s.ratio >= 80 ? 'text-[#facc15]' : 'text-[#4ade80]'}`}>
                {s.ratio}%
              </span>
            </div>
            <div className="w-full bg-[#0d1117] h-1.5 mt-1 border border-[#30363d]">
              <div
                className={`h-full ${s.ratio >= 95 ? 'bg-[#ef4444]' : s.ratio >= 80 ? 'bg-[#eab308]' : 'bg-[#22c55e]'}`}
                style={{ width: `${s.ratio}%` }}
              />
            </div>
            <div className="text-[9px] text-[#8b949e] mt-1">{s.occupied}/{s.count} Plätze belegt</div>
          </button>
        ))}
      </div>

      {/* Search & Status Filters */}
      <div className="flex flex-wrap items-center justify-between gap-2 py-2 border-y border-[#21262d] text-xs font-mono">
        <div className="flex items-center gap-2 flex-1 max-w-sm">
          <Search className="w-3.5 h-3.5 text-[#8b949e]" />
          <input
            type="text"
            placeholder="Lagerplatz (z.B. B-04), Bauteil oder Charge suchen..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#161b22] border border-[#30363d] px-2.5 py-1 text-[#f0f6fc] text-xs focus:outline-none focus:border-[#38bdf8]"
          />
        </div>

        <div className="flex items-center gap-1">
          <span className="text-[10px] text-[#8b949e] uppercase">STATUS:</span>
          {(['ALL', 'BELEGT', 'LEER', 'RESERVIERT', 'BLOCKIERT'] as const).map((st) => (
            <button
              key={st}
              onClick={() => setFilterStatus(st)}
              className={`px-2 py-0.5 text-[10px] border ${
                filterStatus === st
                  ? 'bg-[#0284c7] text-white border-[#38bdf8] font-bold'
                  : 'bg-[#161b22] text-[#8b949e] border-[#30363d] hover:text-[#f0f6fc]'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Main Rack Visualizer & Details Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 mt-3">
        {/* Left: 250-Bin Grid Matrix */}
        <div className="lg:col-span-8 bg-[#070a0f] border border-[#21262d] p-3 max-h-[460px] overflow-y-auto">
          <div className="grid grid-cols-5 sm:grid-cols-10 gap-1.5">
            {filteredBins.map((bin) => {
              const isSelected = selectedBin?.id === bin.id;
              let bg = '#161b22';
              let border = '#30363d';
              let text = '#8b949e';

              if (bin.status === 'BELEGT') {
                bg = bin.aisle === 'B' ? '#451a03' : '#0f172a';
                border = bin.aisle === 'B' ? '#f59e0b' : '#38bdf8';
                text = '#e2e8f0';
              } else if (bin.status === 'RESERVIERT') {
                bg = '#1e1b4b';
                border = '#818cf8';
                text = '#c7d2fe';
              } else if (bin.status === 'BLOCKIERT') {
                bg = '#450a0a';
                border = '#ef4444';
                text = '#fca5a5';
              }

              return (
                <button
                  key={bin.id}
                  onClick={() => setSelectedBin(bin)}
                  className={`p-1.5 text-left border flex flex-col justify-between h-14 transition-all ${
                    isSelected ? 'ring-2 ring-[#f0f6fc] scale-105 z-10' : ''
                  }`}
                  style={{ backgroundColor: bg, borderColor: isSelected ? '#ffffff' : border }}
                >
                  <div className="flex justify-between items-center text-[9px] font-mono font-bold" style={{ color: text }}>
                    <span>{bin.id.split('-').slice(0, 2).join('-')}</span>
                    <span className="text-[8px] opacity-75">E{bin.level}</span>
                  </div>
                  <div className="text-[8px] font-mono truncate text-[#94a3b8]">
                    {bin.partName ? bin.partName.split(' ')[0] : '—'}
                  </div>
                  <div className="flex justify-between items-center text-[8px] font-mono">
                    <span className={`px-1 rounded-none text-[7px] ${
                      bin.status === 'BELEGT' ? 'bg-[#0284c7] text-white' : bin.status === 'RESERVIERT' ? 'bg-[#6366f1] text-white' : bin.status === 'BLOCKIERT' ? 'bg-[#dc2626] text-white' : 'bg-[#334155] text-[#94a3b8]'
                    }`}>
                      {bin.status}
                    </span>
                    <span className="text-[#64748b]">{bin.occupied}/{bin.capacity}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Selected Bin Detailed Inspector */}
        <div className="lg:col-span-4 bg-[#161b22] border border-[#30363d] p-4 text-xs font-mono space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#30363d]">
            <span className="font-bold text-[#f0f6fc]">LAGERPLATZ-DETAILS</span>
            <span className="text-[#38bdf8] font-bold">{selectedBin?.id}</span>
          </div>

          {selectedBin ? (
            <div className="space-y-2 text-[11px]">
              <div>
                <span className="text-[#8b949e]">GANG / REGAL / EBENE:</span>
                <div className="text-[#f0f6fc] font-bold">
                  Gang {selectedBin.aisle} | Regal {selectedBin.rack} | Ebene {selectedBin.level} (Fach 1)
                </div>
              </div>

              <div>
                <span className="text-[#8b949e]">ZUSTAND:</span>
                <div className="mt-0.5">
                  <span className={`px-2 py-0.5 font-bold ${
                    selectedBin.status === 'BELEGT'
                      ? 'bg-[#065f46] text-[#6ee7b7] border border-[#10b981]'
                      : selectedBin.status === 'RESERVIERT'
                      ? 'bg-[#3730a3] text-[#c7d2fe] border border-[#6366f1]'
                      : selectedBin.status === 'BLOCKIERT'
                      ? 'bg-[#7f1d1d] text-[#fca5a5] border border-[#ef4444]'
                      : 'bg-[#1e293b] text-[#94a3b8] border border-[#475569]'
                  }`}>
                    {selectedBin.status}
                  </span>
                </div>
              </div>

              <div>
                <span className="text-[#8b949e]">ARTIKELBEZEICHNUNG:</span>
                <div className="text-[#38bdf8] font-semibold">
                  {selectedBin.partName || 'Kein Artikel eingelagert (Leerplatz)'}
                </div>
                {selectedBin.partId && (
                  <div className="text-[10px] text-[#64748b]">Art.-Nr.: {selectedBin.partId}</div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-[#30363d]">
                <div>
                  <span className="text-[#8b949e]">MENGE / KAPAZITÄT:</span>
                  <div className="text-[#f0f6fc] font-bold text-sm">
                    {selectedBin.occupied} / {selectedBin.capacity} Stk.
                  </div>
                </div>
                <div>
                  <span className="text-[#8b949e]">RESERVIERT:</span>
                  <div className="text-[#facc15] font-bold text-sm">
                    {selectedBin.reserved} Stk.
                  </div>
                </div>
              </div>

              <div>
                <span className="text-[#8b949e]">CHARGENNUMMER (TRACEABILITY):</span>
                <div className="text-[#f0f6fc]">{selectedBin.batchNumber || '—'}</div>
              </div>

              <div>
                <span className="text-[#8b949e]">ZIEL-ARBEITSZELLE:</span>
                <div className="text-[#f0f6fc]">{selectedBin.targetCellId || 'Bereitstellung Puffer Süd'}</div>
              </div>

              <div>
                <span className="text-[#8b949e]">GESAMTGEWICHT:</span>
                <div className="text-[#f0f6fc] font-bold">{selectedBin.weightKg} kg</div>
              </div>
            </div>
          ) : (
            <div className="text-[#8b949e] py-8 text-center">
              Wählen Sie einen Lagerplatz aus der Matrix
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
