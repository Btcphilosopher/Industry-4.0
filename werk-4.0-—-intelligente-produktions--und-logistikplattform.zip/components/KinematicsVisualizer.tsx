// ============================================================================
// WERK 4.0 — 6-ACHS-ROBOTER-KINEMATIK-VISUALISIERUNG (CAD / DIN PROJEKTION)
// ============================================================================

import React, { useState } from 'react';
import { RobotEntity, JointAngles, Vector3D } from '../lib/types';
import { forwardKinematics, inverseKinematics } from '../lib/kinematics';
import { Cpu, RotateCw, Target, Shield, Zap, AlertTriangle, CheckCircle2 } from 'lucide-react';

interface Props {
  robot: RobotEntity;
  onUpdateJoints?: (joints: JointAngles) => void;
  onSolveTarget?: (target: Vector3D) => void;
}

export const KinematicsVisualizer: React.FC<Props> = ({ robot, onUpdateJoints }) => {
  const [interactiveMode, setInteractiveMode] = useState(false);
  const [manualJoints, setManualJoints] = useState<JointAngles>(robot.joints);
  const [targetX, setTargetX] = useState(1800);
  const [targetY, setTargetY] = useState(500);
  const [targetZ, setTargetZ] = useState(1400);
  const [ikMessage, setIkMessage] = useState<string | null>(null);

  const currentJoints = interactiveMode ? manualJoints : robot.joints;
  const fk = forwardKinematics(currentJoints);

  // 2.5D Orthographic Isometric Projection for Canvas/SVG
  // Maps 3D (X, Y, Z mm) to SVG screen coordinates (px)
  const originX = 260;
  const originY = 320;
  const scale = 0.085; // mm to px

  const project3DTo2D = (pt: Vector3D) => {
    // Isometric angle 30 deg
    const isoX = originX + (pt.x * Math.cos(Math.PI / 6) - pt.y * Math.cos(Math.PI / 6)) * scale;
    const isoY = originY - (pt.z * scale) + (pt.x * Math.sin(Math.PI / 6) + pt.y * Math.sin(Math.PI / 6)) * scale * 0.5;
    return { x: isoX, y: isoY };
  };

  const pts2D = fk.jointPositions.map(project3DTo2D);

  const handleSliderChange = (joint: keyof JointAngles, val: number) => {
    setInteractiveMode(true);
    const updated = { ...manualJoints, [joint]: val };
    setManualJoints(updated);
    if (onUpdateJoints) onUpdateJoints(updated);
  };

  const handleSolveIk = () => {
    setInteractiveMode(true);
    const target: Vector3D = { x: targetX, y: targetY, z: targetZ };
    const res = inverseKinematics(target, manualJoints);
    setManualJoints(res.joints);
    if (onUpdateJoints) onUpdateJoints(res.joints);
    setIkMessage(
      res.converged
        ? `IK Konvergenz: Fehler ${res.errorMm} mm erreicht (TCP x=${res.achievedPos.x}, y=${res.achievedPos.y}, z=${res.achievedPos.z})`
        : `IK Näherungslösung: Fehler ${res.errorMm} mm (Arbeitsbereichsgrenze erreicht)`
    );
  };

  const handleResetToSim = () => {
    setInteractiveMode(false);
    setManualJoints(robot.joints);
    setIkMessage(null);
  };

  return (
    <div className="bg-[#0d1117] border border-[#21262d] p-4 text-[#e6edf3]">
      {/* Header Info */}
      <div className="flex flex-wrap items-center justify-between pb-3 border-b border-[#21262d] gap-2">
        <div className="flex items-center gap-2">
          <Cpu className="w-5 h-5 text-[#38bdf8]" />
          <div>
            <div className="font-mono font-bold text-sm tracking-wide text-[#f0f6fc]">
              {robot.name}
            </div>
            <div className="text-[11px] font-mono text-[#8b949e]">
              Hersteller: {robot.manufacturer} | Modell: {robot.model} | Traglast: {robot.payload} kg | Reichweite: {robot.reach} mm
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className={`px-2 py-0.5 border ${
            robot.status === 'WARNING'
              ? 'bg-[#78350f] text-[#fde047] border-[#f59e0b]'
              : robot.status === 'MOVING' || robot.status === 'PICKING'
              ? 'bg-[#064e3b] text-[#86efac] border-[#22c55e]'
              : 'bg-[#1e293b] text-[#93c5fd] border-[#38bdf8]'
          }`}>
            STATUS: {robot.status}
          </span>
          <span className="px-2 py-0.5 bg-[#161b22] border border-[#30363d] text-[#c9d1d9]">
            WERKZEUG: {robot.tool.split(' ')[0]}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 mt-4">
        {/* Left: 2D/2.5D Technical Kinematics Render */}
        <div className="lg:col-span-7 bg-[#070a0f] border border-[#21262d] p-2 relative flex flex-col items-center justify-center min-h-[380px] overflow-hidden">
          {/* DIN CAD Grid Overlay */}
          <svg className="w-full h-full min-h-[360px]" viewBox="0 0 540 380">
            <defs>
              <pattern id="cadGrid" width="20" height="20" patternUnits="userSpaceOnUse">
                <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#1b222d" strokeWidth="0.75" />
              </pattern>
              <linearGradient id="linkGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#38bdf8" />
                <stop offset="100%" stopColor="#0284c7" />
              </linearGradient>
            </defs>

            {/* Grid */}
            <rect width="100%" height="100%" fill="url(#cadGrid)" />

            {/* Ground Pedestal / Workcell Base */}
            <ellipse cx={originX} cy={originY + 10} rx="90" ry="30" fill="#161b22" stroke="#30363d" strokeWidth="1.5" />
            <rect x={originX - 35} y={originY - 15} width="70" height="25" fill="#21262d" stroke="#484f58" strokeWidth="1.5" />
            
            {/* Safety Radius Circle (reach 2700mm) */}
            <ellipse cx={originX} cy={originY + 10} rx={2700 * scale * 0.9} ry={2700 * scale * 0.45} fill="none" stroke="#78350f" strokeWidth="1" strokeDasharray="4 4" />
            <text x={originX + 130} y={originY + 50} fill="#f59e0b" fontSize="9" fontFamily="monospace">
              SICHERHEITSZONE R=2700mm
            </text>

            {/* Coordinate Axis Marker */}
            <g transform={`translate(${originX - 180}, ${originY - 200})`}>
              <line x1="0" y1="0" x2="35" y2="0" stroke="#ef4444" strokeWidth="1.5" />
              <text x="40" y="4" fill="#ef4444" fontSize="9" fontFamily="monospace">X (rot)</text>
              <line x1="0" y1="0" x2="0" y2="35" stroke="#22c55e" strokeWidth="1.5" />
              <text x="-12" y="48" fill="#22c55e" fontSize="9" fontFamily="monospace">Y (grün)</text>
              <line x1="0" y1="0" x2="-20" y2="-20" stroke="#38bdf8" strokeWidth="1.5" />
              <text x="-48" y="-22" fill="#38bdf8" fontSize="9" fontFamily="monospace">Z (blau)</text>
            </g>

            {/* Robot Links & Joints Drawn from FK Joint Positions */}
            {pts2D.map((pt, idx) => {
              if (idx === 0) return null;
              const prev = pts2D[idx - 1];
              return (
                <g key={`link-${idx}`}>
                  {/* Robot Link Arm */}
                  <line
                    x1={prev.x}
                    y1={prev.y}
                    x2={pt.x}
                    y2={pt.y}
                    stroke="url(#linkGrad)"
                    strokeWidth={idx === 1 ? '14' : idx === 2 ? '11' : idx === 3 ? '9' : '7'}
                    strokeLinecap="round"
                  />
                  <line
                    x1={prev.x}
                    y1={prev.y}
                    x2={pt.x}
                    y2={pt.y}
                    stroke="#0f172a"
                    strokeWidth={idx === 1 ? '4' : '2'}
                    strokeLinecap="round"
                  />
                </g>
              );
            })}

            {/* Joint Hubs / Motor Nodes */}
            {pts2D.map((pt, idx) => (
              <g key={`joint-${idx}`}>
                <circle cx={pt.x} cy={pt.y} r={idx === 0 ? 8 : idx === 6 ? 5 : 7} fill="#1e293b" stroke="#38bdf8" strokeWidth="2" />
                <circle cx={pt.x} cy={pt.y} r="2.5" fill="#f0f6fc" />
                <text x={pt.x + 8} y={pt.y - 6} fill="#94a3b8" fontSize="9" fontFamily="monospace">
                  {idx === 0 ? 'BASE' : idx === 6 ? 'TCP' : `J${idx}`}
                </text>
              </g>
            ))}

            {/* End Effector Tool & Gripper / Workpiece */}
            {pts2D.length >= 7 && (
              <g transform={`translate(${pts2D[6].x}, ${pts2D[6].y})`}>
                {/* Tool Flange & Gripper Jaws */}
                <rect x="-6" y="-6" width="12" height="12" fill="#f59e0b" stroke="#d97706" strokeWidth="1" />
                <line x1="-10" y1="6" x2="-10" y2="18" stroke="#f59e0b" strokeWidth="2.5" />
                <line x1="10" y1="6" x2="10" y2="18" stroke="#f59e0b" strokeWidth="2.5" />

                {/* Held Part in Tool (e.g. Battery Module / Body Sheet) */}
                {robot.gripperState === 'CLOSED' && (
                  <rect x="-14" y="16" width="28" height="14" fill="#0284c7" stroke="#38bdf8" strokeWidth="1" rx="1" />
                )}

                {/* Tool Center Point (TCP) Crosshair */}
                <circle cx="0" cy="24" r="3" fill="none" stroke="#ef4444" strokeWidth="1.5" />
                <line x1="-6" y1="24" x2="6" y2="24" stroke="#ef4444" strokeWidth="1" />
                <line x1="0" y1="18" x2="0" y2="30" stroke="#ef4444" strokeWidth="1" />
              </g>
            )}
          </svg>

          {/* Telemetry Overlay in Corner */}
          <div className="absolute bottom-2 left-2 bg-[#090d13]/90 border border-[#21262d] p-2 text-[10px] font-mono text-[#8b949e] space-y-0.5 backdrop-blur-sm">
            <div>TCP XYZ: <span className="text-[#38bdf8] font-bold">X:{fk.endEffectorPos.x} Y:{fk.endEffectorPos.y} Z:{fk.endEffectorPos.z} mm</span></div>
            <div>ORIENT: <span className="text-[#f0f6fc]">R:{fk.orientation.roll}° P:{fk.orientation.pitch}° Y:{fk.orientation.yaw}°</span></div>
            <div>LAST: <span className="text-[#facc15]">{robot.loadPercentage}%</span> | STROM: <span className="text-[#facc15]">{robot.motorCurrent} A</span></div>
          </div>
        </div>

        {/* Right: Gelenksteuerung & DH-Kinematik Parameter */}
        <div className="lg:col-span-5 space-y-4">
          {/* Joint Sliders */}
          <div className="bg-[#161b22] border border-[#30363d] p-3">
            <div className="flex items-center justify-between pb-2 border-b border-[#30363d] text-xs font-mono">
              <span className="font-bold text-[#f0f6fc]">GELENKWINKEL (DH-MODELL)</span>
              {interactiveMode && (
                <button
                  onClick={handleResetToSim}
                  className="text-[10px] text-[#38bdf8] hover:underline"
                >
                  Sync mit Simulation
                </button>
              )}
            </div>

            <div className="space-y-2.5 mt-2.5 text-xs font-mono">
              {[
                { key: 'q1' as const, label: 'J1 (Basis Drehung)', min: -180, max: 180 },
                { key: 'q2' as const, label: 'J2 (Schulter)', min: -135, max: -10 },
                { key: 'q3' as const, label: 'J3 (Ellenbogen)', min: -90, max: 120 },
                { key: 'q4' as const, label: 'J4 (Handgelenk Roll)', min: -180, max: 180 },
                { key: 'q5' as const, label: 'J5 (Handgelenk Schwenk)', min: -120, max: 120 },
                { key: 'q6' as const, label: 'J6 (Flansch Rotation)', min: -180, max: 180 },
              ].map((j) => (
                <div key={j.key} className="flex items-center justify-between gap-2">
                  <span className="text-[#8b949e] w-36 text-[11px]">{j.label}:</span>
                  <input
                    type="range"
                    min={j.min}
                    max={j.max}
                    step={1}
                    value={currentJoints[j.key]}
                    onChange={(e) => handleSliderChange(j.key, parseFloat(e.target.value))}
                    className="flex-1 accent-[#0284c7] cursor-pointer h-1.5 bg-[#30363d]"
                  />
                  <span className="w-12 text-right text-[#38bdf8] font-bold text-[11px] tabular-nums">
                    {currentJoints[j.key]}°
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Inverse Kinematics Target Positioning */}
          <div className="bg-[#161b22] border border-[#30363d] p-3">
            <div className="flex items-center justify-between pb-2 border-b border-[#30363d] text-xs font-mono">
              <span className="font-bold text-[#f0f6fc] flex items-center gap-1.5">
                <Target className="w-3.5 h-3.5 text-[#eab308]" />
                INVERSE KINEMATIK (IK-SOLVER)
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2 mt-2.5 text-xs font-mono">
              <div>
                <label className="text-[10px] text-[#8b949e]">ZIEL X (mm)</label>
                <input
                  type="number"
                  value={targetX}
                  onChange={(e) => setTargetX(parseInt(e.target.value) || 0)}
                  className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1 text-[#f0f6fc] font-bold"
                />
              </div>
              <div>
                <label className="text-[10px] text-[#8b949e]">ZIEL Y (mm)</label>
                <input
                  type="number"
                  value={targetY}
                  onChange={(e) => setTargetY(parseInt(e.target.value) || 0)}
                  className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1 text-[#f0f6fc] font-bold"
                />
              </div>
              <div>
                <label className="text-[10px] text-[#8b949e]">ZIEL Z (mm)</label>
                <input
                  type="number"
                  value={targetZ}
                  onChange={(e) => setTargetZ(parseInt(e.target.value) || 0)}
                  className="w-full bg-[#0d1117] border border-[#30363d] px-2 py-1 text-[#f0f6fc] font-bold"
                />
              </div>
            </div>

            <button
              onClick={handleSolveIk}
              id="solve-ik-btn"
              className="mt-2.5 w-full py-1.5 bg-[#0284c7] hover:bg-[#0369a1] text-white font-mono text-xs font-bold flex items-center justify-center gap-1.5"
            >
              <RotateCw className="w-3.5 h-3.5" />
              <span>NUMERISCHE IK BERECHNEN (CCD / LEAST-SQUARES)</span>
            </button>

            {ikMessage && (
              <div className="mt-2 p-2 bg-[#090d13] border border-[#30363d] text-[11px] font-mono text-[#7ee787]">
                {ikMessage}
              </div>
            )}
          </div>

          {/* Current Task & Physical Telemetry */}
          <div className="bg-[#161b22] border border-[#30363d] p-3 text-xs font-mono space-y-1.5">
            <div className="text-[10px] text-[#8b949e] uppercase">AKTUELLER PRODUKTIONSAUFTRAG:</div>
            <div className="font-bold text-[#f0f6fc]">
              {robot.currentTask ? robot.currentTask.orderId : 'KEIN AUFTRAG ZUGEWIESEN'}
            </div>
            <div className="text-[11px] text-[#c9d1d9]">
              Bauteil: {robot.currentTask?.partName || '—'}
            </div>
            <div className="text-[11px] text-[#8b949e]">
              Quelle: {robot.currentTask?.source || '—'} → Ziel: {robot.currentTask?.target || '—'}
            </div>

            {robot.currentTask && (
              <div className="mt-2">
                <div className="flex justify-between text-[10px] text-[#8b949e] mb-1">
                  <span>ZYKLUS-FORTSCHRITT:</span>
                  <span className="text-[#38bdf8] font-bold">{Math.round(robot.currentTask.progress)}%</span>
                </div>
                <div className="w-full bg-[#0d1117] h-2 border border-[#30363d]">
                  <div
                    className="bg-[#0284c7] h-full transition-all duration-300"
                    style={{ width: `${robot.currentTask.progress}%` }}
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
