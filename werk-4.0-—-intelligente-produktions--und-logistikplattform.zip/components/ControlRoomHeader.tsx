// ============================================================================
// WERK 4.0 — LEITSTAND HEADER & SIMULATIONS-STEUERUNG
// ============================================================================

import React from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  FastForward,
  ShieldAlert,
  ShieldCheck,
  Cpu,
  UserCheck,
  Sparkles,
  ArrowRight,
  Activity,
  FileText
} from 'lucide-react';
import { FactoryFullState } from '../lib/simulationEngine';
import { UserRole } from '../lib/types';

interface HeaderProps {
  state: FactoryFullState;
  onTogglePlay: () => void;
  onStepTick: () => void;
  onReset: () => void;
  onChangeSpeed: (speed: number) => void;
  onChangeRole: (role: UserRole) => void;
  onTriggerScenario1: () => void;
  onAdvanceScenario1: () => void;
  onTriggerScenario2: () => void;
  onTriggerScenario3: () => void;
  onResetScenario: () => void;
  onOpenReport: () => void;
  emergencyStop: boolean;
  onToggleEmergencyStop: () => void;
}

export const ControlRoomHeader: React.FC<HeaderProps> = ({
  state,
  onTogglePlay,
  onStepTick,
  onReset,
  onChangeSpeed,
  onChangeRole,
  onTriggerScenario1,
  onAdvanceScenario1,
  onTriggerScenario2,
  onTriggerScenario3,
  onResetScenario,
  onOpenReport,
  emergencyStop,
  onToggleEmergencyStop,
}) => {
  const roles: UserRole[] = [
    'WERKSLEITUNG',
    'PRODUKTIONSLEITUNG',
    'ROBOTIK',
    'LOGISTIK',
    'QUALITÄT',
    'INSTANDHALTUNG',
    'ENERGIE',
    'ADMIN',
  ];

  return (
    <header className="bg-[#090d13] border-b border-[#21262d] text-[#e6edf3] select-none sticky top-0 z-40">
      {/* Top Banner: Industrial Identification */}
      <div className="flex flex-wrap items-center justify-between px-4 py-2 border-b border-[#1b1f27] text-xs">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-none bg-[#0284c7] border border-[#38bdf8] shadow-[0_0_8px_#0284c7]" />
            <span className="font-mono font-bold tracking-widest text-sm text-[#f0f6fc]">
              WERK 4.0
            </span>
          </div>
          <span className="text-[#6e7681]">|</span>
          <span className="font-mono text-[#8b949e] font-medium uppercase">
            AUTOMOBILWERK SÜD — WERK 07 (DEUTSCHLAND)
          </span>
          <span className="hidden sm:inline-block px-1.5 py-0.5 bg-[#161b22] border border-[#30363d] text-[10px] font-mono text-[#7ee787]">
            R-KERN v4.4.0 VDA 6.3
          </span>
        </div>

        {/* Live Simulation Time & Shift */}
        <div className="flex items-center gap-4 font-mono text-xs mt-1 sm:mt-0">
          <div className="flex items-center gap-1.5 bg-[#161b22] px-2.5 py-1 border border-[#30363d]">
            <span className="text-[#8b949e]">SIMULATIONSZEIT:</span>
            <span className="font-bold text-[#38bdf8] text-sm tabular-nums">
              {state.timeFormatted}
            </span>
          </div>

          <div className="hidden md:flex items-center gap-1.5 bg-[#161b22] px-2 py-1 border border-[#30363d]">
            <span className="text-[#8b949e]">SCHICHT:</span>
            <span className="font-bold text-[#f0f6fc]">{state.shift} ({state.shift === 1 ? 'FRÜH' : state.shift === 2 ? 'SPÄT' : 'NACHT'})</span>
          </div>

          <div className="hidden lg:flex items-center gap-1.5 bg-[#161b22] px-2 py-1 border border-[#30363d]">
            <span className="text-[#8b949e]">TAG:</span>
            <span className="text-[#e6edf3] font-semibold">{state.dayOfWeek}</span>
          </div>

          {/* Emergency Stop / Safety */}
          <button
            onClick={onToggleEmergencyStop}
            id="emergency-stop-btn"
            className={`flex items-center gap-1 px-3 py-1 font-mono font-bold uppercase transition-all ${
              emergencyStop
                ? 'bg-[#dc2626] text-white animate-pulse border border-[#ef4444]'
                : 'bg-[#1c1917] hover:bg-[#292524] text-[#ef4444] border border-[#7f1d1d]'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>{emergencyStop ? 'NOT-AUS AKTIV' : 'NOT-HALT'}</span>
          </button>
        </div>
      </div>

      {/* Control Bar: Simulation Playback, Speeds, Role Selector & Scenarios */}
      <div className="flex flex-wrap items-center justify-between px-4 py-2 gap-3 bg-[#0d1117]">
        {/* Playback Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={onTogglePlay}
            id="sim-play-pause-btn"
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono font-semibold border transition-colors ${
              state.isRunning
                ? 'bg-[#1e293b] hover:bg-[#334155] border-[#38bdf8] text-[#38bdf8]'
                : 'bg-[#15803d] hover:bg-[#16a34a] border-[#22c55e] text-white'
            }`}
          >
            {state.isRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            <span>{state.isRunning ? 'PAUSE' : 'START'}</span>
          </button>

          <button
            onClick={onStepTick}
            id="sim-step-btn"
            title="Einzelner Simulationsschritt (dt = 1s)"
            className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-mono bg-[#161b22] hover:bg-[#21262d] border border-[#30363d] text-[#c9d1d9]"
          >
            <Activity className="w-3 h-3 text-[#38bdf8]" />
            <span>SCHRITT</span>
          </button>

          <button
            onClick={onReset}
            id="sim-reset-btn"
            title="Simulation auf Ausgangszustand zurücksetzen"
            className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-mono bg-[#161b22] hover:bg-[#21262d] border border-[#30363d] text-[#8b949e] hover:text-[#f0f6fc]"
          >
            <RotateCcw className="w-3 h-3" />
            <span>RESET</span>
          </button>

          {/* Speed Factors */}
          <div className="flex items-center bg-[#161b22] border border-[#30363d] p-0.5 ml-1">
            {[1, 10, 100, 1000].map((spd) => (
              <button
                key={spd}
                onClick={() => onChangeSpeed(spd)}
                className={`px-2 py-1 text-[11px] font-mono transition-colors ${
                  state.timeFactor === spd
                    ? 'bg-[#0284c7] text-white font-bold'
                    : 'text-[#8b949e] hover:text-[#f0f6fc] hover:bg-[#21262d]'
                }`}
              >
                {spd}×
              </button>
            ))}
          </div>
        </div>

        {/* Interactive Demo Scenarios */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-[11px] font-mono text-[#8b949e] uppercase flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-[#eab308]" />
            SZENARIEN:
          </span>

          <button
            onClick={onTriggerScenario1}
            id="scenario-1-btn"
            className={`px-2.5 py-1 text-xs font-mono border transition-all ${
              state.scenario.activeScenarioId === 'SCENARIO_1_E_AUTO'
                ? 'bg-[#0284c7] text-white border-[#38bdf8] font-bold shadow-[0_0_8px_rgba(2,132,199,0.5)]'
                : 'bg-[#161b22] hover:bg-[#21262d] text-[#c9d1d9] border-[#30363d]'
            }`}
          >
            1. E-Auto FA-1842
          </button>

          {state.scenario.activeScenarioId === 'SCENARIO_1_E_AUTO' && (
            <button
              onClick={onAdvanceScenario1}
              id="advance-scenario-step-btn"
              className="px-2 py-1 text-xs font-mono bg-[#16a34a] hover:bg-[#22c55e] text-white border border-[#4ade80] flex items-center gap-1 animate-pulse"
            >
              <span>WEITER (Schritt {state.scenario.stepIndex}/11)</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          )}

          <button
            onClick={onTriggerScenario2}
            id="scenario-2-btn"
            className={`px-2.5 py-1 text-xs font-mono border transition-all ${
              state.scenario.activeScenarioId === 'SCENARIO_2_ROB42_FAILURE'
                ? 'bg-[#b45309] text-white border-[#f59e0b] font-bold shadow-[0_0_8px_rgba(245,158,11,0.5)]'
                : 'bg-[#161b22] hover:bg-[#21262d] text-[#c9d1d9] border-[#30363d]'
            }`}
          >
            2. ROB-042 Predictive
          </button>

          <button
            onClick={onTriggerScenario3}
            id="scenario-3-btn"
            className={`px-2.5 py-1 text-xs font-mono border transition-all ${
              state.scenario.activeScenarioId === 'SCENARIO_3_WAREHOUSE_BOTTLENECK'
                ? 'bg-[#4338ca] text-white border-[#818cf8] font-bold shadow-[0_0_8px_rgba(129,140,248,0.5)]'
                : 'bg-[#161b22] hover:bg-[#21262d] text-[#c9d1d9] border-[#30363d]'
            }`}
          >
            3. Lager-Engpass 95%
          </button>

          {state.scenario.activeScenarioId !== 'NONE' && (
            <button
              onClick={onResetScenario}
              id="reset-scenario-btn"
              className="px-2 py-1 text-xs font-mono text-[#f87171] hover:text-[#ef4444] underline"
            >
              Beenden
            </button>
          )}
        </div>

        {/* Role Switcher & Report Button */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 bg-[#161b22] px-2 py-1 border border-[#30363d]">
            <UserCheck className="w-3.5 h-3.5 text-[#38bdf8]" />
            <span className="text-[10px] font-mono text-[#8b949e]">ROLLE:</span>
            <select
              value={state.activeRole}
              onChange={(e) => onChangeRole(e.target.value as UserRole)}
              aria-label="Benutzerrolle auswählen"
              className="bg-transparent text-xs font-mono text-[#f0f6fc] font-semibold focus:outline-none cursor-pointer"
            >
              {roles.map((r) => (
                <option key={r} value={r} className="bg-[#161b22] text-[#f0f6fc]">
                  {r}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={onOpenReport}
            id="open-report-btn"
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono bg-[#161b22] hover:bg-[#21262d] border border-[#30363d] text-[#e6edf3]"
          >
            <FileText className="w-3.5 h-3.5 text-[#eab308]" />
            <span className="hidden sm:inline">SCHICHTBERICHT</span>
          </button>
        </div>
      </div>

      {/* Active Scenario Info Alert Banner */}
      {state.scenario.activeScenarioId !== 'NONE' && (
        <div className="bg-[#162032] border-t border-[#0284c7] px-4 py-1.5 flex flex-wrap items-center justify-between text-xs font-mono text-[#bae6fd]">
          <div className="flex items-center gap-2">
            <span className="font-bold text-[#38bdf8]">[SZENARIO AKTIV]</span>
            <span>{state.scenario.description}</span>
          </div>
          <div className="flex items-center gap-4 text-[11px] text-[#e0f2fe] mt-1 sm:mt-0">
            <span>Wirkung: <strong>{state.scenario.metrics.throughputImpact}</strong></span>
            {state.scenario.metrics.downtimeAvoidedMin > 0 && (
              <span>Stillstand vermieden: <strong className="text-[#4ade80]">{state.scenario.metrics.downtimeAvoidedMin} min</strong></span>
            )}
            {state.scenario.metrics.reroutedTasksCount > 0 && (
              <span>Umgeroutet: <strong className="text-[#facc15]">{state.scenario.metrics.reroutedTasksCount} Tasks</strong></span>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
