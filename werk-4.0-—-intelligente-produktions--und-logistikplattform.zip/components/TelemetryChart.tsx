// ============================================================================
// WERK 4.0 — PREDICTIVE MAINTENANCE & TELEMETRIE-LEITSTAND
// ============================================================================

import React, { useState } from 'react';
import { RobotEntity } from '../lib/types';
import { Activity, AlertTriangle, ShieldCheck, Wrench, Thermometer, Zap, Clock, RefreshCw } from 'lucide-react';

interface Props {
  robots: RobotEntity[];
  onTriggerReroute?: () => void;
}

export const TelemetryChart: React.FC<Props> = ({ robots, onTriggerReroute }) => {
  const [selectedRobotId, setSelectedRobotId] = useState<string>('ROB-042');

  const selectedRobot = robots.find((r) => r.id === selectedRobotId) || robots[0];

  // Synthesize 24-step historical telemetry for selected robot
  const isProblematic = selectedRobot.id === 'ROB-042';
  const historyPoints = Array.from({ length: 24 }, (_, idx) => {
    const t = idx;
    const baseVib = isProblematic ? 1.2 + (t / 24) * 3.6 + Math.sin(t) * 0.2 : 0.8 + Math.sin(t * 0.5) * 0.15;
    const baseTemp = isProblematic ? 45 + (t / 24) * 28 + Math.cos(t) * 1.5 : 44 + Math.sin(t * 0.8) * 2;
    const baseCurrent = isProblematic ? 14 + (t / 24) * 11 + Math.sin(t) * 0.8 : 12 + Math.cos(t * 0.5) * 0.9;
    return {
      hour: `${idx < 10 ? '0' + idx : idx}:00`,
      vibration: Math.round(baseVib * 100) / 100,
      temperature: Math.round(baseTemp * 10) / 10,
      current: Math.round(baseCurrent * 10) / 10,
    };
  });

  const chartW = 540;
  const chartH = 160;
  const padX = 35;
  const padY = 20;

  const maxVib = 6.0;
  const minVib = 0.0;
  const scaleVibY = (v: number) => chartH - padY - ((v - minVib) / (maxVib - minVib)) * (chartH - 2 * padY);
  const scaleX = (i: number) => padX + (i / 23) * (chartW - 2 * padX);

  return (
    <div className="bg-[#0d1117] border border-[#21262d] p-4 text-[#e6edf3]">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between pb-3 border-b border-[#21262d] gap-2">
        <div className="flex items-center gap-2">
          <Wrench className="w-5 h-5 text-[#f59e0b]" />
          <div>
            <div className="font-mono font-bold text-sm text-[#f0f6fc]">
              PREDICTIVE MAINTENANCE & SCHWINGUNGSANALYSE
            </div>
            <div className="text-[11px] font-mono text-[#8b949e]">
              Telemetrie-Echtzeitstrom | EWMA Anomalieerkennung | ISO 10816 Schwingungsgrenzwerte
            </div>
          </div>
        </div>

        {isProblematic && onTriggerReroute && (
          <button
            onClick={onTriggerReroute}
            id="reroute-rob42-btn"
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#b45309] hover:bg-[#d97706] text-white font-mono text-xs font-bold border border-[#f59e0b] transition-all animate-pulse"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>AUFTRÄGE AUF ROB-041 & ROB-043 UMLEITEN</span>
          </button>
        )}
      </div>

      {/* Robot Selection Pill Matrix */}
      <div className="flex items-center gap-1 overflow-x-auto py-2 border-b border-[#21262d]">
        {robots.slice(35, 48).map((rob) => {
          const isSelected = selectedRobotId === rob.id;
          const isWarn = rob.id === 'ROB-042';
          return (
            <button
              key={rob.id}
              onClick={() => setSelectedRobotId(rob.id)}
              className={`px-2 py-1 text-xs font-mono border whitespace-nowrap transition-all ${
                isSelected
                  ? 'bg-[#0284c7] text-white border-[#38bdf8] font-bold'
                  : isWarn
                  ? 'bg-[#451a03] text-[#fde047] border-[#f59e0b]'
                  : 'bg-[#161b22] text-[#8b949e] border-[#30363d] hover:text-[#f0f6fc]'
              }`}
            >
              {rob.id} {isWarn ? '⚠️' : ''}
            </button>
          );
        })}
      </div>

      {/* Telemetry Charts & Diagnostics Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 mt-3">
        {/* Left: Vibration Chart (ISO 10816) */}
        <div className="lg:col-span-8 space-y-3">
          <div className="bg-[#070a0f] border border-[#21262d] p-3">
            <div className="flex justify-between items-center pb-2 border-b border-[#21262d] text-xs font-mono">
              <span className="font-bold text-[#f0f6fc]">
                SCHWINGUNGS-ZEITREIHE (RMS VIBRATION mm/s) — {selectedRobot.id}
              </span>
              <span className="text-[#8b949e] text-[10px]">ISO 10816 GRENZWERT: 3.50 mm/s</span>
            </div>

            <div className="mt-2 overflow-x-auto flex justify-center">
              <svg className="w-full max-w-[560px] h-[160px]" viewBox={`0 0 ${chartW} ${chartH}`}>
                {/* Critical ISO Limit (3.5 mm/s) */}
                <line x1={padX} y1={scaleVibY(3.5)} x2={chartW - padX} y2={scaleVibY(3.5)} stroke="#ef4444" strokeWidth="1.5" strokeDasharray="5 3" />
                <text x={chartW - padX + 5} y={scaleVibY(3.5) + 4} fill="#ef4444" fontSize="8" fontFamily="monospace">GRENZE 3.50</text>

                {/* Warning Zone (2.5 mm/s) */}
                <line x1={padX} y1={scaleVibY(2.5)} x2={chartW - padX} y2={scaleVibY(2.5)} stroke="#f59e0b" strokeWidth="1" strokeDasharray="3 3" />
                <text x={chartW - padX + 5} y={scaleVibY(2.5) + 4} fill="#f59e0b" fontSize="8" fontFamily="monospace">WARN 2.50</text>

                {/* Telemetry Line */}
                <polyline
                  fill="none"
                  stroke={isProblematic ? '#ef4444' : '#38bdf8'}
                  strokeWidth="2"
                  points={historyPoints.map((p, i) => `${scaleX(i)},${scaleVibY(p.vibration)}`).join(' ')}
                />

                {historyPoints.map((p, i) => (
                  <circle
                    key={i}
                    cx={scaleX(i)}
                    cy={scaleVibY(p.vibration)}
                    r="2.5"
                    fill={p.vibration > 3.5 ? '#ef4444' : '#38bdf8'}
                  />
                ))}
              </svg>
            </div>
          </div>

          {/* Additional Telemetry Metrics */}
          <div className="grid grid-cols-3 gap-2 font-mono text-xs">
            <div className="bg-[#161b22] border border-[#30363d] p-2.5">
              <div className="text-[10px] text-[#8b949e] flex items-center gap-1">
                <Thermometer className="w-3 h-3 text-[#f87171]" />
                MOTORTEMPERATUR:
              </div>
              <div className={`text-base font-bold ${selectedRobot.temperature > 65 ? 'text-[#ef4444]' : 'text-[#f0f6fc]'}`}>
                {selectedRobot.temperature} °C
              </div>
              <div className="text-[9px] text-[#8b949e]">Max zulässig: 70 °C</div>
            </div>

            <div className="bg-[#161b22] border border-[#30363d] p-2.5">
              <div className="text-[10px] text-[#8b949e] flex items-center gap-1">
                <Zap className="w-3 h-3 text-[#facc15]" />
                MOTORSTROM PHASEN-RMS:
              </div>
              <div className={`text-base font-bold ${selectedRobot.motorCurrent > 20 ? 'text-[#facc15]' : 'text-[#f0f6fc]'}`}>
                {selectedRobot.motorCurrent} A
              </div>
              <div className="text-[9px] text-[#8b949e]">Nennstrom: 16.0 A</div>
            </div>

            <div className="bg-[#161b22] border border-[#30363d] p-2.5">
              <div className="text-[10px] text-[#8b949e] flex items-center gap-1">
                <Clock className="w-3 h-3 text-[#38bdf8]" />
                RESTLEBENSDAUER (RUL):
              </div>
              <div className={`text-base font-bold ${selectedRobot.rulHours < 100 ? 'text-[#ef4444]' : 'text-[#4ade80]'}`}>
                {selectedRobot.rulHours} h
              </div>
              <div className="text-[9px] text-[#8b949e]">Zyklen: {selectedRobot.cycleCount}</div>
            </div>
          </div>
        </div>

        {/* Right: Diagnostic Health & Wear Assessment Card */}
        <div className="lg:col-span-4 bg-[#161b22] border border-[#30363d] p-4 text-xs font-mono space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#30363d]">
            <span className="font-bold text-[#f0f6fc]">ZUSTANDSBEWERTUNG</span>
            <span className={`px-2 py-0.5 font-bold ${
              selectedRobot.health === 'WARTUNG ERFORDERLICH'
                ? 'bg-[#7f1d1d] text-[#fca5a5] border border-[#ef4444]'
                : selectedRobot.health === 'BEOBACHTEN'
                ? 'bg-[#78350f] text-[#fde047] border border-[#f59e0b]'
                : 'bg-[#065f46] text-[#6ee7b7] border border-[#10b981]'
            }`}>
              {selectedRobot.health}
            </span>
          </div>

          <div className="space-y-2 text-[11px]">
            <div>
              <span className="text-[#8b949e]">VERSCHLEISS-INDEX f(Zyklen, T, Last):</span>
              <div className="flex justify-between items-center mt-1">
                <div className="w-full bg-[#0d1117] h-2.5 border border-[#30363d] mr-2">
                  <div
                    className={`h-full ${
                      selectedRobot.wearIndex > 0.8 ? 'bg-[#ef4444]' : selectedRobot.wearIndex > 0.6 ? 'bg-[#eab308]' : 'bg-[#22c55e]'
                    }`}
                    style={{ width: `${selectedRobot.wearIndex * 100}%` }}
                  />
                </div>
                <span className="font-bold text-[#f0f6fc]">{(selectedRobot.wearIndex * 100).toFixed(0)}%</span>
              </div>
            </div>

            <div>
              <span className="text-[#8b949e]">LETZTE WARTUNG:</span>
              <div className="text-[#f0f6fc]">{selectedRobot.lastMaintenance}</div>
            </div>

            <div>
              <span className="text-[#8b949e]">NÄCHSTES WARTUNGSFENSTER:</span>
              <div className="text-[#38bdf8] font-bold">{selectedRobot.nextMaintenance}</div>
            </div>

            {selectedRobot.warnings.length > 0 && (
              <div className="pt-2 border-t border-[#30363d]">
                <span className="text-[#ef4444] font-bold flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3" />
                  AKTIVE ANOMALIE-WARNUNGEN:
                </span>
                <ul className="mt-1 space-y-1 text-[10px] text-[#fca5a5]">
                  {selectedRobot.warnings.map((w, i) => (
                    <li key={i}>• {w}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
