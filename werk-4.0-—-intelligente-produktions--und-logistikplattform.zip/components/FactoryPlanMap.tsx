// ============================================================================
// WERK 4.0 — SCHEMATISCHER FABRIKPLAN (AUTOMOBILWERK SÜD - WERK 07)
// Glaubwürdiger deutscher Automobilwerk-Grundriss mit Hallen, Linien, Robotern, AGVs, Hochregallager
// ============================================================================

import React, { useState } from 'react';
import { FactoryFullState } from '../lib/simulationEngine';
import { ProductionHallEntity, RobotEntity, AGVEntity, MachineEntity } from '../lib/types';
import { Layers, Eye, Zap, Shield, Cpu, Truck, Package, Info } from 'lucide-react';

interface Props {
  state: FactoryFullState;
  onSelectRobot?: (robot: RobotEntity) => void;
  onSelectMachine?: (machine: MachineEntity) => void;
  onSelectHall?: (hall: ProductionHallEntity) => void;
}

export const FactoryPlanMap: React.FC<Props> = ({ state, onSelectRobot, onSelectMachine, onSelectHall }) => {
  const [selectedHallId, setSelectedHallId] = useState<string | null>(null);
  const [filterLayer, setFilterLayer] = useState<'ALL' | 'ROBOTS' | 'AGVS' | 'CONVEYOR' | 'SAFETY'>('ALL');
  const [hoveredEntity, setHoveredEntity] = useState<string | null>(null);

  const halls = state.halls;

  return (
    <div className="bg-[#0d1117] border border-[#21262d] p-4 text-[#e6edf3]">
      {/* Control Toolbar */}
      <div className="flex flex-wrap items-center justify-between pb-3 border-b border-[#21262d] gap-2">
        <div className="flex items-center gap-2">
          <Layers className="w-5 h-5 text-[#38bdf8]" />
          <div>
            <div className="font-mono font-bold text-sm text-[#f0f6fc]">
              SCHEMATISCHER FABRIKLAYOUT-PLAN (WERK 07)
            </div>
            <div className="text-[11px] font-mono text-[#8b949e]">
              5 Produktionshallen | 12 Fertigungslinien | 60 6-Achs-Roboter | 22 FTS/AGVs | Hochregallager
            </div>
          </div>
        </div>

        {/* Layer Filters */}
        <div className="flex items-center gap-1 bg-[#161b22] border border-[#30363d] p-1 font-mono text-xs">
          <span className="text-[10px] text-[#8b949e] px-1.5 uppercase">EBENEN:</span>
          {(['ALL', 'ROBOTS', 'AGVS', 'CONVEYOR', 'SAFETY'] as const).map((layer) => (
            <button
              key={layer}
              onClick={() => setFilterLayer(layer)}
              className={`px-2 py-0.5 text-[11px] transition-colors ${
                filterLayer === layer
                  ? 'bg-[#0284c7] text-white font-bold'
                  : 'text-[#8b949e] hover:text-[#f0f6fc] hover:bg-[#21262d]'
              }`}
            >
              {layer === 'ALL' ? 'ALLE' : layer === 'ROBOTS' ? 'ROBOTIK' : layer === 'AGVS' ? 'FTS/AGVs' : layer === 'CONVEYOR' ? 'FÖRDERTECHNIK' : 'SICHERHEIT'}
            </button>
          ))}
        </div>
      </div>

      {/* SVG Factory Floor Plan */}
      <div className="mt-4 bg-[#070a0f] border border-[#21262d] relative min-h-[440px] flex items-center justify-center overflow-x-auto p-2">
        <svg className="w-full max-w-[960px] h-[440px]" viewBox="0 0 960 440">
          <defs>
            <pattern id="factoryGrid" width="20" height="20" patternUnits="userSpaceOnUse">
              <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#141a23" strokeWidth="0.8" />
            </pattern>
            <linearGradient id="hallPressGrad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#1e293b" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#0f172a" stopOpacity="0.9" />
            </linearGradient>
            <marker id="agvArrow" markerWidth="6" markerHeight="6" refX="4" refY="3" orient="auto">
              <path d="M 0 0 L 6 3 L 0 6 z" fill="#38bdf8" />
            </marker>
          </defs>

          {/* Background Technical Grid */}
          <rect width="100%" height="100%" fill="url(#factoryGrid)" />

          {/* Logistics Corridor / Main AGV Roadway */}
          <rect x="30" y="210" width="900" height="30" fill="#111827" stroke="#374151" strokeWidth="1" strokeDasharray="6 4" />
          <text x="40" y="228" fill="#6b7280" fontSize="10" fontFamily="monospace" fontWeight="bold">
            HAUPT-TRANSPORTKORRIDOR & AGV-SPUR (LEITLINIENNUTZUNG)
          </text>

          {/* ============================================================== */}
          {/* HALLE 1: PRESSWERK (Top Left) */}
          {/* ============================================================== */}
          <g
            onClick={() => onSelectHall && onSelectHall(halls[0])}
            className="cursor-pointer group"
          >
            <rect
              x="30"
              y="20"
              width="260"
              height="175"
              fill="url(#hallPressGrad)"
              stroke={selectedHallId === 'HALLE-01' ? '#38bdf8' : '#334155'}
              strokeWidth={selectedHallId === 'HALLE-01' ? 2 : 1}
              className="group-hover:stroke-[#38bdf8] transition-colors"
            />
            <rect x="30" y="20" width="260" height="24" fill="#1e293b" />
            <text x="40" y="36" fill="#f8fafc" fontSize="11" fontFamily="monospace" fontWeight="bold">
              HALLE 1 — PRESSWERK (PRS)
            </text>
            <text x="230" y="36" fill="#94a3b8" fontSize="9" fontFamily="monospace">4.8 MW</text>

            {/* Presses */}
            <rect x="45" y="55" width="105" height="40" fill="#334155" stroke="#475569" strokeWidth="1" />
            <text x="52" y="78" fill="#f1f5f9" fontSize="9" fontFamily="monospace">Presse A 25.000 kN</text>
            
            <rect x="45" y="105" width="105" height="40" fill="#334155" stroke="#475569" strokeWidth="1" />
            <text x="52" y="128" fill="#f1f5f9" fontSize="9" fontFamily="monospace">Presse B 20.000 kN</text>

            {/* Coil Storage */}
            <rect x="165" y="55" width="110" height="90" fill="#1e293b" stroke="#334155" strokeDasharray="3 3" />
            <text x="175" y="75" fill="#94a3b8" fontSize="9" fontFamily="monospace">Coil-Lagerplatz</text>
            <circle cx="195" cy="115" r="16" fill="none" stroke="#64748b" strokeWidth="3" />
            <circle cx="240" cy="115" r="16" fill="none" stroke="#64748b" strokeWidth="3" />
          </g>

          {/* ============================================================== */}
          {/* HALLE 2: KAROSSERIEBAU & SCHWEISSZENTRUM (Top Center) */}
          {/* ============================================================== */}
          <g
            onClick={() => onSelectHall && onSelectHall(halls[1])}
            className="cursor-pointer group"
          >
            <rect
              x="310"
              y="20"
              width="320"
              height="175"
              fill="url(#hallPressGrad)"
              stroke={selectedHallId === 'HALLE-02' ? '#38bdf8' : '#334155'}
              strokeWidth={selectedHallId === 'HALLE-02' ? 2 : 1}
              className="group-hover:stroke-[#38bdf8] transition-colors"
            />
            <rect x="310" y="20" width="320" height="24" fill="#1e293b" />
            <text x="320" y="36" fill="#f8fafc" fontSize="11" fontFamily="monospace" fontWeight="bold">
              HALLE 2 — KAROSSERIEBAU (KARO)
            </text>
            <text x="575" y="36" fill="#94a3b8" fontSize="9" fontFamily="monospace">5.9 MW</text>

            {/* Schweißlinien K-01, K-02 (Zelle K-07), K-03 */}
            <rect x="325" y="55" width="290" height="35" fill="#1e293b" stroke="#3b82f6" strokeWidth="1" />
            <text x="335" y="76" fill="#93c5fd" fontSize="9" fontFamily="monospace" fontWeight="bold">
              LINIE K-01 Unterboden-Schweißung
            </text>

            {/* Demo Cell K-07 */}
            <rect x="325" y="100" width="290" height="42" fill="#172554" stroke="#60a5fa" strokeWidth="1.5" />
            <text x="335" y="118" fill="#60a5fa" fontSize="10" fontFamily="monospace" fontWeight="bold">
              ★ ZELLE K-07 (ROB-017, ROB-018 & Vision CMM)
            </text>
            <text x="335" y="132" fill="#93c5fd" fontSize="8" fontFamily="monospace">
              Aufbau E-Limousine E7 | FA-2026-01842
            </text>

            {/* Safety Perimeter Line */}
            {filterLayer === 'ALL' || filterLayer === 'SAFETY' ? (
              <rect x="320" y="50" width="300" height="135" fill="none" stroke="#d97706" strokeWidth="1" strokeDasharray="4 4" />
            ) : null}
          </g>

          {/* ============================================================== */}
          {/* HALLE 3: LACKIEREREI & KTL (Top Right) */}
          {/* ============================================================== */}
          <g
            onClick={() => onSelectHall && onSelectHall(halls[2])}
            className="cursor-pointer group"
          >
            <rect
              x="650"
              y="20"
              width="280"
              height="175"
              fill="url(#hallPressGrad)"
              stroke={selectedHallId === 'HALLE-03' ? '#38bdf8' : '#334155'}
              strokeWidth={selectedHallId === 'HALLE-03' ? 2 : 1}
              className="group-hover:stroke-[#38bdf8] transition-colors"
            />
            <rect x="650" y="20" width="280" height="24" fill="#1e293b" />
            <text x="660" y="36" fill="#f8fafc" fontSize="11" fontFamily="monospace" fontWeight="bold">
              HALLE 3 — LACKIEREREI (LACK)
            </text>
            <text x="875" y="36" fill="#94a3b8" fontSize="9" fontFamily="monospace">3.2 MW</text>

            {/* KTL Dip Tanks & Drying Oven */}
            <rect x="665" y="55" width="115" height="40" fill="#0f766e" stroke="#14b8a6" strokeWidth="1" />
            <text x="675" y="78" fill="#ccfbf1" fontSize="9" fontFamily="monospace">KTL-Tauchbecken</text>

            <rect x="790" y="55" width="125" height="40" fill="#b45309" stroke="#f59e0b" strokeWidth="1" />
            <text x="800" y="78" fill="#fef3c7" fontSize="9" fontFamily="monospace">Trocknungsofen 180°C</text>

            {/* Decklack Roboterstraße */}
            <rect x="665" y="105" width="250" height="40" fill="#1e293b" stroke="#38bdf8" strokeWidth="1" />
            <text x="675" y="128" fill="#bae6fd" fontSize="9" fontFamily="monospace">Dürr EcoRP L2 Roboter-Lackierstraße</text>
          </g>

          {/* ============================================================== */}
          {/* HALLE 4: ANTRIEB & BATTERIE (Bottom Left) */}
          {/* ============================================================== */}
          <g
            onClick={() => onSelectHall && onSelectHall(halls[3])}
            className="cursor-pointer group"
          >
            <rect
              x="30"
              y="255"
              width="360"
              height="165"
              fill="url(#hallPressGrad)"
              stroke={selectedHallId === 'HALLE-04' ? '#38bdf8' : '#334155'}
              strokeWidth={selectedHallId === 'HALLE-04' ? 2 : 1}
              className="group-hover:stroke-[#38bdf8] transition-colors"
            />
            <rect x="30" y="255" width="360" height="24" fill="#1e293b" />
            <text x="40" y="271" fill="#f8fafc" fontSize="11" fontFamily="monospace" fontWeight="bold">
              HALLE 4 — ANTRIEB & BATTERIE (BAT)
            </text>
            <text x="335" y="271" fill="#94a3b8" fontSize="9" fontFamily="monospace">2.7 MW</text>

            {/* Battery Line B-01 (Warning ROB-042 located here) */}
            <rect x="45" y="290" width="330" height="42" fill="#1e293b" stroke={state.scenario.activeScenarioId === 'SCENARIO_2_ROB42_FAILURE' ? '#f59e0b' : '#10b981'} strokeWidth="1" />
            <text x="55" y="308" fill="#e2e8f0" fontSize="9" fontFamily="monospace" fontWeight="bold">
              LINIE B-01 800V Batteriepack-Montage (NMC811)
            </text>
            <text x="55" y="322" fill={state.scenario.activeScenarioId === 'SCENARIO_2_ROB42_FAILURE' ? '#fde047' : '#94a3b8'} fontSize="8" fontFamily="monospace">
              Roboter: ROB-038 bis ROB-042 {state.scenario.activeScenarioId === 'SCENARIO_2_ROB42_FAILURE' ? '⚠️ [ROB-042 VIBRATIONS-WARNUNG]' : ''}
            </text>

            {/* E-Machine Line A-01 */}
            <rect x="45" y="342" width="330" height="38" fill="#1e293b" stroke="#334155" strokeWidth="1" />
            <text x="55" y="365" fill="#cbd5e1" fontSize="9" fontFamily="monospace">
              LINIE A-01 E-Maschinen 220 kW Synchronfertigung
            </text>
          </g>

          {/* ============================================================== */}
          {/* HALLE 5: ENDMONTAGE, HOCHREGALLAGER & VERSAND (Bottom Right) */}
          {/* ============================================================== */}
          <g
            onClick={() => onSelectHall && onSelectHall(halls[4])}
            className="cursor-pointer group"
          >
            <rect
              x="410"
              y="255"
              width="520"
              height="165"
              fill="url(#hallPressGrad)"
              stroke={selectedHallId === 'HALLE-05' ? '#38bdf8' : '#334155'}
              strokeWidth={selectedHallId === 'HALLE-05' ? 2 : 1}
              className="group-hover:stroke-[#38bdf8] transition-colors"
            />
            <rect x="410" y="255" width="520" height="24" fill="#1e293b" />
            <text x="420" y="271" fill="#f8fafc" fontSize="11" fontFamily="monospace" fontWeight="bold">
              HALLE 5 — ENDMONTAGE, HOCHREGALLAGER & FINISH
            </text>
            <text x="875" y="271" fill="#94a3b8" fontSize="9" fontFamily="monospace">2.1 MW</text>

            {/* High-Bay Automated Warehouse (Hochregallager Gänge A-E) */}
            <rect x="425" y="290" width="160" height="90" fill="#0f172a" stroke="#818cf8" strokeWidth="1.5" />
            <text x="435" y="306" fill="#c7d2fe" fontSize="9" fontFamily="monospace" fontWeight="bold">
              HOCHREGALLAGER (250 BINS)
            </text>
            <text x="435" y="320" fill="#a5b4fc" fontSize="8" fontFamily="monospace">
              Gänge A | B (95%) | C | D | E
            </text>
            {/* Small rack representations */}
            <line x1="435" y1="332" x2="575" y2="332" stroke="#4338ca" strokeWidth="2" strokeDasharray="3 2" />
            <line x1="435" y1="344" x2="575" y2="344" stroke="#4338ca" strokeWidth="2" strokeDasharray="3 2" />
            <line x1="435" y1="356" x2="575" y2="356" stroke="#4338ca" strokeWidth="2" strokeDasharray="3 2" />
            <line x1="435" y1="368" x2="575" y2="368" stroke="#4338ca" strokeWidth="2" strokeDasharray="3 2" />

            {/* Endmontage Hochzeit & Finish */}
            <rect x="600" y="290" width="160" height="90" fill="#1e293b" stroke="#3b82f6" strokeWidth="1" />
            <text x="610" y="308" fill="#93c5fd" fontSize="9" fontFamily="monospace" fontWeight="bold">
              LINIE M-01 HOCHZEIT
            </text>
            <text x="610" y="322" fill="#cbd5e1" fontSize="8" fontFamily="monospace">
              16-fach Spindelverschraubung
            </text>
            <text x="610" y="345" fill="#94a3b8" fontSize="8" fontFamily="monospace">
              LINIE M-02 Cockpit & Interior
            </text>
            <text x="610" y="365" fill="#94a3b8" fontSize="8" fontFamily="monospace">
              LINIE M-03 Räder & Finish
            </text>

            {/* Versand & Rollenprüfstand */}
            <rect x="775" y="290" width="140" height="90" fill="#14532d" stroke="#22c55e" strokeWidth="1" />
            <text x="785" y="308" fill="#86efac" fontSize="9" fontFamily="monospace" fontWeight="bold">
              EOL PRÜFSTAND & VERSAND
            </text>
            <text x="785" y="325" fill="#bbf7d0" fontSize="8" fontFamily="monospace">
              Laser-Spaltmaß CMM
            </text>
            <text x="785" y="342" fill="#bbf7d0" fontSize="8" fontFamily="monospace">
              Dichtigkeitskammer
            </text>
            <text x="785" y="360" fill="#bbf7d0" fontSize="8" fontFamily="monospace">
              Versand-Logistik LKW
            </text>
          </g>

          {/* ============================================================== */}
          {/* ROBOT NODES (Rendered in Hall Cells) */}
          {/* ============================================================== */}
          {(filterLayer === 'ALL' || filterLayer === 'ROBOTS') && state.robots.slice(0, 30).map((rob, i) => {
            // Project into distinct visual halls
            let rx = 100 + (i % 6) * 40;
            let ry = 90;
            if (i >= 6 && i < 16) {
              rx = 350 + ((i - 6) % 5) * 55;
              ry = 85 + Math.floor((i - 6) / 5) * 45;
            } else if (i >= 16 && i < 22) {
              rx = 690 + ((i - 16) % 3) * 75;
              ry = 120;
            } else if (i >= 22) {
              rx = 100 + ((i - 22) % 4) * 70;
              ry = 320;
            }

            const isProblematic = rob.id === 'ROB-042';

            return (
              <g
                key={rob.id}
                onClick={(e) => {
                  e.stopPropagation();
                  if (onSelectRobot) onSelectRobot(rob);
                }}
                onMouseEnter={() => setHoveredEntity(rob.id)}
                onMouseLeave={() => setHoveredEntity(null)}
                className="cursor-pointer"
              >
                <circle
                  cx={rx}
                  cy={ry}
                  r="6"
                  fill={isProblematic ? '#dc2626' : rob.status === 'WARNING' ? '#d97706' : '#0284c7'}
                  stroke={isProblematic ? '#fca5a5' : '#7dd3fc'}
                  strokeWidth="1.5"
                  className={isProblematic ? 'animate-ping' : ''}
                />
                <circle
                  cx={rx}
                  cy={ry}
                  r="6"
                  fill={isProblematic ? '#dc2626' : rob.status === 'WARNING' ? '#d97706' : '#0284c7'}
                  stroke={isProblematic ? '#fca5a5' : '#7dd3fc'}
                  strokeWidth="1.5"
                />
              </g>
            );
          })}

          {/* ============================================================== */}
          {/* ACTIVE AGVs MOVING ON LOGISTICS CORRIDOR */}
          {/* ============================================================== */}
          {(filterLayer === 'ALL' || filterLayer === 'AGVS') && state.agvs.map((agv, i) => {
            const agvX = 60 + ((agv.position.x + i * 38) % 840);
            const agvY = 225 + (i % 2 === 0 ? -4 : 4);

            return (
              <g
                key={agv.id}
                onMouseEnter={() => setHoveredEntity(`${agv.id}: ${agv.status} (${agv.batteryPercent}%)`)}
                onMouseLeave={() => setHoveredEntity(null)}
                className="cursor-pointer"
              >
                <rect
                  x={agvX - 8}
                  y={agvY - 5}
                  width="16"
                  height="10"
                  fill={agv.status === 'CHARGING' ? '#eab308' : '#38bdf8'}
                  stroke="#0f172a"
                  strokeWidth="1"
                  rx="1"
                />
                <circle cx={agvX - 5} cy={agvY + 5} r="1.5" fill="#94a3b8" />
                <circle cx={agvX + 5} cy={agvY + 5} r="1.5" fill="#94a3b8" />
              </g>
            );
          })}
        </svg>

        {/* Hovered Entity Floating Tag */}
        {hoveredEntity && (
          <div className="absolute top-3 right-3 bg-[#0d1117] border border-[#38bdf8] px-3 py-1 text-xs font-mono text-[#38bdf8] font-bold shadow-lg">
            {hoveredEntity}
          </div>
        )}
      </div>

      {/* Footer KPI Status Line */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-3 text-xs font-mono">
        <div className="bg-[#161b22] border border-[#30363d] p-2">
          <div className="text-[10px] text-[#8b949e]">PRODUKTIONSAUSLASTUNG:</div>
          <div className="text-sm font-bold text-[#f0f6fc]">87.2 %</div>
        </div>
        <div className="bg-[#161b22] border border-[#30363d] p-2">
          <div className="text-[10px] text-[#8b949e]">ROBOTER IM EINSATZ:</div>
          <div className="text-sm font-bold text-[#38bdf8]">{state.kpis.activeRobotsCount} / {state.kpis.totalRobotsCount} AKTIV</div>
        </div>
        <div className="bg-[#161b22] border border-[#30363d] p-2">
          <div className="text-[10px] text-[#8b949e]">FTS / AGV FLOTTE:</div>
          <div className="text-sm font-bold text-[#4ade80]">{state.kpis.activeAgvsCount} / {state.kpis.totalAgvsCount} UNTERWEGS</div>
        </div>
        <div className="bg-[#161b22] border border-[#30363d] p-2">
          <div className="text-[10px] text-[#8b949e]">HOCHREGALLAGER FÜLLSTAND:</div>
          <div className="text-sm font-bold text-[#facc15]">{state.kpis.warehouseOccupancyPercent} % (250 PLÄTZE)</div>
        </div>
      </div>
    </div>
  );
};
