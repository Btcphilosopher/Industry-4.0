// ============================================================================
// WERK 4.0 — STATISTISCHE PROZESSKONTROLLE (SPC) & MACHINE VISION INSPEKTOR
// ============================================================================

import React, { useState } from 'react';
import { QualityMeasurement, QualitySPCStats } from '../lib/types';
import { ShieldCheck, Camera, Activity, AlertOctagon, CheckCircle2, TrendingUp, Sliders } from 'lucide-react';

interface Props {
  measurements: QualityMeasurement[];
}

export const SpcControlChart: React.FC<Props> = ({ measurements }) => {
  const [selectedParameter, setSelectedParameter] = useState<string>('Spaltmaß Tür/Kotflügel');
  const [sampleCount, setSampleCount] = useState<number>(30);

  // Generate 30 continuous samples around nominal 3.20 mm (with 1 fail sample KARO-004812 at 3.27 mm)
  const samples = Array.from({ length: sampleCount }, (_, idx) => {
    const isOutlier = idx === 18; // KARO-004812
    const base = 3.20;
    const noise = (Math.sin(idx * 1.7) * 0.02 + Math.cos(idx * 0.9) * 0.015);
    const value = isOutlier ? 3.27 : Math.round((base + noise) * 1000) / 1000;
    const status: 'PASS' | 'WARNING' | 'FAIL' = value > 3.25 || value < 3.15 ? 'FAIL' : value > 3.24 || value < 3.16 ? 'WARNING' : 'PASS';
    return {
      sampleId: idx + 1,
      partNumber: isOutlier ? 'KARO-004812' : `PART-E7-${1000 + idx}`,
      value,
      nominal: 3.20,
      usl: 3.25, // Upper spec limit (+0.05 mm)
      lsl: 3.15, // Lower spec limit (-0.05 mm)
      status,
      timestamp: `14:${Math.floor(30 - idx * 0.8)}:${(idx * 17) % 60}`,
    };
  });

  // Calculate SPC parameters
  const values = samples.map((s) => s.value);
  const mean = Math.round((values.reduce((a, b) => a + b, 0) / values.length) * 1000) / 1000;
  const variance = values.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / (values.length - 1);
  const sigma = Math.round(Math.sqrt(variance) * 1000) / 1000;

  const usl = 3.25;
  const lsl = 3.15;
  const cp = Math.round(((usl - lsl) / (6 * sigma)) * 100) / 100;
  const cpk = Math.round(Math.min((usl - mean) / (3 * sigma), (mean - lsl) / (3 * sigma)) * 100) / 100;
  const defectPpm = Math.round((1 / sampleCount) * 10000);

  // SVG Chart Dimensions
  const chartW = 600;
  const chartH = 220;
  const paddingX = 40;
  const paddingY = 25;

  const minY = 3.12;
  const maxY = 3.30;
  const scaleY = (val: number) => chartH - paddingY - ((val - minY) / (maxY - minY)) * (chartH - 2 * paddingY);
  const scaleX = (idx: number) => paddingX + (idx / (sampleCount - 1)) * (chartW - 2 * paddingX);

  return (
    <div className="bg-[#0d1117] border border-[#21262d] p-4 text-[#e6edf3]">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between pb-3 border-b border-[#21262d] gap-2">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-[#22c55e]" />
          <div>
            <div className="font-mono font-bold text-sm text-[#f0f6fc]">
              SPC STATISTISCHE PROZESSKONTROLLE & MACHINE VISION INSPEKTION
            </div>
            <div className="text-[11px] font-mono text-[#8b949e]">
              Shewhart-Regelkarten | Prozessfähigkeitsindizes Cp / Cpk | 3D-Laser-Triangulation
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="px-2 py-0.5 bg-[#161b22] border border-[#30363d] text-[#7ee787]">
            NORM: DIN EN ISO 9001 / VDA 6.3
          </span>
        </div>
      </div>

      {/* Metric Cards (Cp, Cpk, Mittelwert, Sigma, PPM) */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 my-3 font-mono text-xs">
        <div className="bg-[#161b22] border border-[#30363d] p-2.5">
          <div className="text-[10px] text-[#8b949e]">MITTELWERT (μ):</div>
          <div className="text-base font-bold text-[#f0f6fc]">{mean} mm</div>
          <div className="text-[9px] text-[#8b949e]">Sollwert: 3.200 mm</div>
        </div>

        <div className="bg-[#161b22] border border-[#30363d] p-2.5">
          <div className="text-[10px] text-[#8b949e]">STANDARDABWEICHUNG (σ):</div>
          <div className="text-base font-bold text-[#38bdf8]">±{sigma} mm</div>
          <div className="text-[9px] text-[#8b949e]">Toleranz: ±0.050 mm</div>
        </div>

        <div className="bg-[#161b22] border border-[#30363d] p-2.5">
          <div className="text-[10px] text-[#8b949e]">PROZESSFÄHIGKEIT (Cp):</div>
          <div className={`text-base font-bold ${cp >= 1.33 ? 'text-[#4ade80]' : 'text-[#facc15]'}`}>
            {cp}
          </div>
          <div className="text-[9px] text-[#8b949e]">Ziel: &ge; 1.33 (VDA 6.3)</div>
        </div>

        <div className="bg-[#161b22] border border-[#30363d] p-2.5">
          <div className="text-[10px] text-[#8b949e]">KRITISCHER CPK-INDEX:</div>
          <div className={`text-base font-bold ${cpk >= 1.33 ? 'text-[#4ade80]' : 'text-[#f87171]'}`}>
            {cpk}
          </div>
          <div className="text-[9px] text-[#8b949e]">Status: {cpk >= 1.33 ? 'FÄHIG' : 'NACHJUSTIERUNG'}</div>
        </div>

        <div className="bg-[#161b22] border border-[#30363d] p-2.5">
          <div className="text-[10px] text-[#8b949e]">AUSSCHUSSRATE (PPM):</div>
          <div className="text-base font-bold text-[#facc15]">{defectPpm} PPM</div>
          <div className="text-[9px] text-[#8b949e]">First Pass Yield: 98.7%</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 mt-3">
        {/* Left: Shewhart SPC Regelkarte (SVG) */}
        <div className="lg:col-span-8 bg-[#070a0f] border border-[#21262d] p-3">
          <div className="flex justify-between items-center pb-2 border-b border-[#21262d] text-xs font-mono">
            <span className="font-bold text-[#f0f6fc]">SHEWHART-REGELKARTE: SPALTMASS B-SÄULE [mm]</span>
            <span className="text-[10px] text-[#8b949e]">N = {sampleCount} STICHPROBEN</span>
          </div>

          <div className="mt-2 overflow-x-auto flex justify-center">
            <svg className="w-full max-w-[620px] h-[220px]" viewBox={`0 0 ${chartW} ${chartH}`}>
              {/* Reference Limit Lines */}
              {/* USL Line (3.25 mm) */}
              <line x1={paddingX} y1={scaleY(usl)} x2={chartW - paddingX} y2={scaleY(usl)} stroke="#ef4444" strokeWidth="1.5" strokeDasharray="5 3" />
              <text x={chartW - paddingX + 5} y={scaleY(usl) + 4} fill="#ef4444" fontSize="9" fontFamily="monospace">USL 3.25</text>

              {/* Target Line (3.20 mm) */}
              <line x1={paddingX} y1={scaleY(3.20)} x2={chartW - paddingX} y2={scaleY(3.20)} stroke="#22c55e" strokeWidth="1.5" />
              <text x={chartW - paddingX + 5} y={scaleY(3.20) + 4} fill="#22c55e" fontSize="9" fontFamily="monospace">SOLL 3.20</text>

              {/* LSL Line (3.15 mm) */}
              <line x1={paddingX} y1={scaleY(lsl)} x2={chartW - paddingX} y2={scaleY(lsl)} stroke="#ef4444" strokeWidth="1.5" strokeDasharray="5 3" />
              <text x={chartW - paddingX + 5} y={scaleY(lsl) + 4} fill="#ef4444" fontSize="9" fontFamily="monospace">LSL 3.15</text>

              {/* Trend Line Connecting Sample Points */}
              <polyline
                fill="none"
                stroke="#38bdf8"
                strokeWidth="1.5"
                points={samples.map((s, idx) => `${scaleX(idx)},${scaleY(s.value)}`).join(' ')}
              />

              {/* Sample Data Points */}
              {samples.map((s, idx) => {
                const cx = scaleX(idx);
                const cy = scaleY(s.value);
                const isFail = s.status === 'FAIL';
                const isWarn = s.status === 'WARNING';

                return (
                  <g key={s.sampleId}>
                    <circle
                      cx={cx}
                      cy={cy}
                      r={isFail ? 5 : 3.5}
                      fill={isFail ? '#dc2626' : isWarn ? '#d97706' : '#0284c7'}
                      stroke={isFail ? '#ffffff' : '#7dd3fc'}
                      strokeWidth="1.5"
                    />
                    {isFail && (
                      <text x={cx - 30} y={cy - 10} fill="#f87171" fontSize="9" fontFamily="monospace" fontWeight="bold">
                        KARO-004812 (3.27 mm)
                      </text>
                    )}
                  </g>
                );
              })}
            </svg>
          </div>
        </div>

        {/* Right: Machine Vision Inspection Camera Preview */}
        <div className="lg:col-span-4 bg-[#161b22] border border-[#30363d] p-3 text-xs font-mono space-y-2.5">
          <div className="flex items-center justify-between pb-2 border-b border-[#30363d]">
            <span className="font-bold text-[#f0f6fc] flex items-center gap-1.5">
              <Camera className="w-3.5 h-3.5 text-[#38bdf8]" />
              MACHINE VISION OPTIK
            </span>
            <span className="text-[10px] text-[#ef4444] font-bold animate-pulse">● LIVE CMM</span>
          </div>

          {/* Synthetic Camera Image Display */}
          <div className="bg-[#090d13] border border-[#30363d] p-2 relative h-40 flex items-center justify-center overflow-hidden">
            {/* Synthetic Car Panel Silhouette */}
            <svg className="w-full h-full" viewBox="0 0 240 140">
              <rect x="20" y="20" width="95" height="100" fill="#1e293b" stroke="#475569" strokeWidth="2" />
              <rect x="125" y="20" width="95" height="100" fill="#1e293b" stroke="#475569" strokeWidth="2" />

              {/* The Gap (Spaltmaß) */}
              <line x1="115" y1="20" x2="115" y2="120" stroke="#dc2626" strokeWidth="3" strokeDasharray="3 3" />

              {/* Measurement Crosshairs & Bounding Box */}
              <rect x="100" y="45" width="40" height="50" fill="none" stroke="#ef4444" strokeWidth="1.5" strokeDasharray="4 2" />
              <circle cx="120" cy="70" r="4" fill="none" stroke="#ef4444" strokeWidth="1" />
              <line x1="110" y1="70" x2="130" y2="70" stroke="#ef4444" strokeWidth="1" />
              <line x1="120" y1="60" x2="120" y2="80" stroke="#ef4444" strokeWidth="1" />

              <text x="105" y="110" fill="#f87171" fontSize="9" fontFamily="monospace" fontWeight="bold">
                IST: 3.27 mm [FAIL]
              </text>
            </svg>
          </div>

          <div className="space-y-1.5 text-[11px]">
            <div className="flex justify-between">
              <span className="text-[#8b949e]">PRÜFLING:</span>
              <span className="font-bold text-[#f0f6fc]">KARO-004812</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#8b949e]">SOLL / TOLERANZ:</span>
              <span className="text-[#f0f6fc]">3.20 mm ± 0.05 mm</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#8b949e]">GEMESSENES SPALTMASS:</span>
              <span className="font-bold text-[#ef4444]">3.27 mm (+0.07 mm)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#8b949e]">INSPEKTIONSERGEBNIS:</span>
              <span className="font-bold text-[#ef4444] px-1.5 py-0.5 bg-[#450a0a] border border-[#ef4444]">
                FAIL (NACHJUSTIERUNG)
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
