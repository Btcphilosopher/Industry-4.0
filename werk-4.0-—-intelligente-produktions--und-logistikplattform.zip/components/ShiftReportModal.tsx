// ============================================================================
// WERK 4.0 — SCHICHTBERICHT-GENERATOR (VDA 6.3 & ISO 9001 KONFORM)
// Druckbarer Export für PDF, HTML & CSV mit allen KPIs, Vorfällen & Freigaben
// ============================================================================

import React from 'react';
import { FactoryFullState } from '../lib/simulationEngine';
import { X, Printer, Download, FileText, CheckCircle2, AlertTriangle, ShieldCheck } from 'lucide-react';

interface Props {
  state: FactoryFullState;
  onClose: () => void;
}

export const ShiftReportModal: React.FC<Props> = ({ state, onClose }) => {
  const handlePrint = () => {
    window.print();
  };

  const handleExportCsv = () => {
    const csvContent = [
      ['PRODUKTIONSAUFTRAG', 'MODELL', 'STATUS', 'FORTSCHRITT', 'STATION', 'STARTZEIT'].join(';'),
      ...state.orders.map((o) =>
        [o.orderId, o.model, o.status, `${o.progressPercent}%`, o.currentStage, o.actualStartTime].join(';')
      ),
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `SCHICHTBERICHT_WERK07_${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#0d1117] border border-[#30363d] w-full max-w-4xl text-[#e6edf3] font-mono shadow-2xl my-8">
        {/* Top Control Bar (Screen Only) */}
        <div className="flex items-center justify-between px-4 py-3 bg-[#161b22] border-b border-[#30363d] print:hidden">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-[#eab308]" />
            <span className="font-bold text-sm text-[#f0f6fc]">
              SCHICHTBERICHT — VDA 6.3 PRODUKTIONSPROTOKOLL
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportCsv}
              id="export-csv-btn"
              className="flex items-center gap-1 px-2.5 py-1 text-xs bg-[#21262d] hover:bg-[#30363d] text-[#c9d1d9] border border-[#30363d]"
            >
              <Download className="w-3 h-3" />
              <span>CSV DATEN</span>
            </button>
            <button
              onClick={handlePrint}
              id="print-report-btn"
              className="flex items-center gap-1 px-3 py-1 text-xs bg-[#0284c7] hover:bg-[#0369a1] text-white font-bold"
            >
              <Printer className="w-3 h-3" />
              <span>DRUCKEN / PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1 text-[#8b949e] hover:text-[#f0f6fc]"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Report Document (DIN A4 Formatted Layout) */}
        <div className="p-6 md:p-8 space-y-6 bg-[#090d13] print:bg-white print:text-black print:p-0">
          {/* Document Header */}
          <div className="border-b-2 border-[#38bdf8] pb-4 flex justify-between items-start">
            <div>
              <div className="text-xl font-bold tracking-widest text-[#f0f6fc] print:text-black">
                WERK 4.0 — AUTOMOBILWERK SÜD (WERK 07)
              </div>
              <div className="text-xs text-[#8b949e] print:text-gray-600 mt-1">
                STANDORT: DEUTSCHLAND | PRODUKTIONSBEREICHE: HALLEN 1-5 | ZERTIFIZIERUNG: DIN EN ISO 9001 / IATF 16949
              </div>
            </div>
            <div className="text-right text-xs">
              <div className="font-bold text-[#38bdf8] print:text-blue-700">SCHICHT 2 (SPÄTSCHICHT)</div>
              <div className="text-[#8b949e] print:text-gray-600">DATUM: {new Date().toLocaleDateString('de-DE')}</div>
              <div className="text-[#8b949e] print:text-gray-600">ZEIT: {state.timeFormatted} UHR</div>
            </div>
          </div>

          {/* Section 1: Executive KPI Overview */}
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-[#38bdf8] print:text-blue-700 mb-2">
              1. GESAMTWERKS-KENNZAHLEN (OEE & PRODUKTIONSVOLUMEN)
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
              <div className="p-3 bg-[#161b22] print:bg-gray-100 border border-[#30363d] print:border-gray-300">
                <div className="text-[#8b949e] print:text-gray-600 text-[10px]">OEE GESAMTWIRKUNGSGRAD:</div>
                <div className="text-lg font-bold text-[#f0f6fc] print:text-black">{state.kpis.overallOee}%</div>
                <div className="text-[10px] text-[#7ee787] print:text-green-700">Verf. 94.2% | Leist. 98.1% | Qual. {state.kpis.qualityFirstPassYieldPercent}%</div>
              </div>

              <div className="p-3 bg-[#161b22] print:bg-gray-100 border border-[#30363d] print:border-gray-300">
                <div className="text-[#8b949e] print:text-gray-600 text-[10px]">PRODUKTION IST / SOLL:</div>
                <div className="text-lg font-bold text-[#f0f6fc] print:text-black">{state.kpis.completedOrdersCount} / 30 Fzg.</div>
                <div className="text-[10px] text-[#38bdf8] print:text-blue-700">Planerfüllung: {Math.round((state.kpis.completedOrdersCount / 30) * 100)}%</div>
              </div>

              <div className="p-3 bg-[#161b22] print:bg-gray-100 border border-[#30363d] print:border-gray-300">
                <div className="text-[#8b949e] print:text-gray-600 text-[10px]">DURCHSCHN. TAKTZEIT:</div>
                <div className="text-lg font-bold text-[#f0f6fc] print:text-black">58.4 s</div>
                <div className="text-[10px] text-[#8b949e] print:text-gray-600">Soll-Takt: 58.0 s (Delta: +0.4 s)</div>
              </div>

              <div className="p-3 bg-[#161b22] print:bg-gray-100 border border-[#30363d] print:border-gray-300">
                <div className="text-[#8b949e] print:text-gray-600 text-[10px]">FIRST PASS YIELD (FPY):</div>
                <div className="text-lg font-bold text-[#4ade80] print:text-green-800">{state.kpis.qualityFirstPassYieldPercent}%</div>
                <div className="text-[10px] text-[#8b949e] print:text-gray-600">Ausschuss: 12.5 PPM</div>
              </div>
            </div>
          </div>

          {/* Section 2: Active Events & Incidents Log */}
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-[#38bdf8] print:text-blue-700 mb-2">
              2. EREIGNIS- & ANOMALIEPROTOKOLL
            </div>
            <div className="border border-[#30363d] print:border-gray-300 text-xs overflow-hidden">
              <table className="w-full text-left">
                <thead className="bg-[#161b22] print:bg-gray-200 border-b border-[#30363d] text-[11px] text-[#8b949e] print:text-black">
                  <tr>
                    <th className="p-2">ZEIT</th>
                    <th className="p-2">SCHWERE</th>
                    <th className="p-2">ORT / AGGREGAT</th>
                    <th className="p-2">BESCHREIBUNG / MASSNAHME</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#21262d] print:divide-gray-300 text-[11px]">
                  {state.events.slice(0, 6).map((ev) => (
                    <tr key={ev.eventId} className="hover:bg-[#161b22]/50">
                      <td className="p-2 font-mono text-[#8b949e] print:text-gray-600">{ev.timestamp}</td>
                      <td className="p-2">
                        <span className={`px-1.5 py-0.5 text-[10px] ${
                          ev.severity === 'CRITICAL'
                            ? 'bg-[#7f1d1d] text-[#fca5a5] print:bg-red-100 print:text-red-900'
                            : ev.severity === 'WARNING'
                            ? 'bg-[#78350f] text-[#fde047] print:bg-yellow-100 print:text-yellow-900'
                            : 'bg-[#065f46] text-[#6ee7b7] print:bg-green-100 print:text-green-900'
                        }`}>
                          {ev.severity}
                        </span>
                      </td>
                      <td className="p-2 font-bold text-[#f0f6fc] print:text-black">{ev.location}</td>
                      <td className="p-2 text-[#c9d1d9] print:text-gray-800">{ev.message}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Section 3: Sign-off / Freigaben */}
          <div className="pt-4 border-t border-[#30363d] print:border-gray-400 grid grid-cols-3 gap-4 text-xs">
            <div>
              <div className="text-[10px] text-[#8b949e] print:text-gray-600 uppercase">SCHICHTFÜHRER PRODUKTION:</div>
              <div className="mt-4 border-b border-[#484f58] pb-1 font-bold text-[#f0f6fc] print:text-black">
                M. Weber (Qualitätsbeauftragter)
              </div>
            </div>
            <div>
              <div className="text-[10px] text-[#8b949e] print:text-gray-600 uppercase">LEITSTAND ROBOTIK & INSTANDHALTUNG:</div>
              <div className="mt-4 border-b border-[#484f58] pb-1 font-bold text-[#f0f6fc] print:text-black">
                Dr.-Ing. K. Schneider (Automatisierung)
              </div>
            </div>
            <div>
              <div className="text-[10px] text-[#8b949e] print:text-gray-600 uppercase">WERKSLEITUNG FREIGABE:</div>
              <div className="mt-4 border-b border-[#484f58] pb-1 font-bold text-[#4ade80] print:text-green-800 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                DIGITAL FREIGEGEBEN (VDA 6.3)
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
