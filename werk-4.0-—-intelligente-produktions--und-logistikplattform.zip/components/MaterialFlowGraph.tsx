// ============================================================================
// WERK 4.0 — MATERIALFLUSS-GRAPH (IGRAPH TOPOLOGIE & DURCHSATZ-ANALYSE)
// ============================================================================

import React, { useState } from 'react';
import { FactoryFullState } from '../lib/simulationEngine';
import { GitFork, ArrowRight, Truck, AlertTriangle, CheckCircle2, Clock } from 'lucide-react';

interface Props {
  state: FactoryFullState;
}

interface MaterialNode {
  id: string;
  label: string;
  sublabel: string;
  x: number;
  y: number;
  capacityPerHour: number;
  currentThroughput: number;
  utilization: number;
  status: 'OPTIMAL' | 'WARNUNG' | 'ENGPASS';
  leadTimeMin: number;
}

interface MaterialEdge {
  id: string;
  source: string;
  target: string;
  transportType: 'AGV' | 'FÖRDERBAND' | 'ROLLENBAHN' | 'SHUTTLE';
  transitTimeMin: number;
  activeShipments: number;
}

export const MaterialFlowGraph: React.FC<Props> = ({ state }) => {
  const [selectedNodeId, setSelectedNodeId] = useState<string>('KARO');

  const nodes: MaterialNode[] = [
    { id: 'WE', label: '1. WARENEINGANG', sublabel: 'LKW-Entladung & 2D-Matrixscan', x: 70, y: 190, capacityPerHour: 90, currentThroughput: 82, utilization: 91, status: 'OPTIMAL', leadTimeMin: 12 },
    { id: 'HRL', label: '2. HOCHREGALLAGER', sublabel: '250 Bins (Gänge A-E)', x: 220, y: 190, capacityPerHour: 80, currentThroughput: 74, utilization: 92, status: 'WARNUNG', leadTimeMin: 18 },
    { id: 'PRS', label: '3. PRESSWERK', sublabel: 'Halle 1 (25.000 kN)', x: 380, y: 80, capacityPerHour: 75, currentThroughput: 71, utilization: 94, status: 'OPTIMAL', leadTimeMin: 35 },
    { id: 'BAT', label: '4. BATTERIE & ANTRIEB', sublabel: 'Halle 4 (800V NMC Pack)', x: 380, y: 300, capacityPerHour: 70, currentThroughput: 64, utilization: 91, status: 'OPTIMAL', leadTimeMin: 42 },
    { id: 'KARO', label: '5. KAROSSERIEBAU', sublabel: 'Zelle K-07 Schweißzentrum', x: 530, y: 80, capacityPerHour: 62, currentThroughput: 59, utilization: 95, status: 'ENGPASS', leadTimeMin: 55 },
    { id: 'LACK', label: '6. LACKIEREREI', sublabel: 'KTL & EcoRP Lackierstraße', x: 670, y: 80, capacityPerHour: 65, currentThroughput: 58, utilization: 89, status: 'OPTIMAL', leadTimeMin: 48 },
    { id: 'MONT', label: '7. HOCHZEIT & ENDMONTAGE', sublabel: 'Halle 5 (16-Spindeln)', x: 670, y: 300, capacityPerHour: 60, currentThroughput: 58, utilization: 96, status: 'ENGPASS', leadTimeMin: 62 },
    { id: 'QA', label: '8. QUALITÄTSPRÜFUNG', sublabel: 'Zeiss 3D Laser-CMM', x: 800, y: 190, capacityPerHour: 65, currentThroughput: 60, utilization: 92, status: 'OPTIMAL', leadTimeMin: 15 },
    { id: 'EXP', label: '9. VERSAND & EOL', sublabel: 'Rollenprüfstand & LKW', x: 910, y: 190, capacityPerHour: 65, currentThroughput: 60, utilization: 92, status: 'OPTIMAL', leadTimeMin: 20 },
  ];

  const edges: MaterialEdge[] = [
    { id: 'e1', source: 'WE', target: 'HRL', transportType: 'ROLLENBAHN', transitTimeMin: 4, activeShipments: 6 },
    { id: 'e2', source: 'HRL', target: 'PRS', transportType: 'AGV', transitTimeMin: 8, activeShipments: 4 },
    { id: 'e3', source: 'HRL', target: 'BAT', transportType: 'AGV', transitTimeMin: 10, activeShipments: 5 },
    { id: 'e4', source: 'PRS', target: 'KARO', transportType: 'FÖRDERBAND', transitTimeMin: 6, activeShipments: 3 },
    { id: 'e5', source: 'KARO', target: 'LACK', transportType: 'SHUTTLE', transitTimeMin: 9, activeShipments: 2 },
    { id: 'e6', source: 'LACK', target: 'MONT', transportType: 'FÖRDERBAND', transitTimeMin: 12, activeShipments: 4 },
    { id: 'e7', source: 'BAT', target: 'MONT', transportType: 'AGV', transitTimeMin: 7, activeShipments: 3 },
    { id: 'e8', source: 'MONT', target: 'QA', transportType: 'ROLLENBAHN', transitTimeMin: 5, activeShipments: 2 },
    { id: 'e9', source: 'QA', target: 'EXP', transportType: 'FÖRDERBAND', transitTimeMin: 4, activeShipments: 2 },
  ];

  const selectedNode = nodes.find((n) => n.id === selectedNodeId) || nodes[0];

  return (
    <div className="bg-[#0d1117] border border-[#21262d] p-4 text-[#e6edf3]">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between pb-3 border-b border-[#21262d] gap-2">
        <div className="flex items-center gap-2">
          <GitFork className="w-5 h-5 text-[#38bdf8]" />
          <div>
            <div className="font-mono font-bold text-sm text-[#f0f6fc]">
              MATERIALFLUSS-GRAPH (IGRAPH NETZWERKTOPOLOGIE)
            </div>
            <div className="text-[11px] font-mono text-[#8b949e]">
              End-to-End Fertigungsfluss | Durchlaufzeiten | Kanten-Transportzeiten | Engpassdetektion
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3 font-mono text-xs">
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 bg-[#22c55e]" />
            <span className="text-[#8b949e]">Optimal (&lt;90%)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 bg-[#eab308]" />
            <span className="text-[#8b949e]">Beobachten (90-94%)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 bg-[#ef4444]" />
            <span className="text-[#8b949e]">Engpass (&ge;95%)</span>
          </div>
        </div>
      </div>

      {/* Interactive igraph Canvas */}
      <div className="mt-4 bg-[#070a0f] border border-[#21262d] p-3 overflow-x-auto min-h-[400px] flex items-center justify-center">
        <svg className="w-full max-w-[980px] h-[380px]" viewBox="0 0 980 380">
          <defs>
            <marker id="flowArrow" markerWidth="8" markerHeight="8" refX="6" refY="4" orient="auto">
              <path d="M 0 0 L 8 4 L 0 8 z" fill="#38bdf8" />
            </marker>
            <linearGradient id="edgeGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#0284c7" />
              <stop offset="100%" stopColor="#38bdf8" />
            </linearGradient>
          </defs>

          {/* Render Edges (Connecting Lines with Flow Animations) */}
          {edges.map((edge) => {
            const src = nodes.find((n) => n.id === edge.source)!;
            const tgt = nodes.find((n) => n.id === edge.target)!;

            return (
              <g key={edge.id}>
                <line
                  x1={src.x}
                  y1={src.y}
                  x2={tgt.x}
                  y2={tgt.y}
                  stroke="#334155"
                  strokeWidth="3"
                />
                <line
                  x1={src.x}
                  y1={src.y}
                  x2={tgt.x}
                  y2={tgt.y}
                  stroke="#38bdf8"
                  strokeWidth="2"
                  strokeDasharray="6 6"
                  className="animate-pulse"
                />

                {/* Edge Label: Transit Time & Shipments */}
                <g transform={`translate(${(src.x + tgt.x) / 2}, ${(src.y + tgt.y) / 2 - 10})`}>
                  <rect x="-35" y="-9" width="70" height="18" fill="#0d1117" stroke="#30363d" strokeWidth="1" />
                  <text x="0" y="3" textAnchor="middle" fill="#93c5fd" fontSize="8" fontFamily="monospace">
                    {edge.transitTimeMin}m ({edge.activeShipments} Auftr.)
                  </text>
                </g>
              </g>
            );
          })}

          {/* Render Nodes (Factory Workstations) */}
          {nodes.map((node) => {
            const isSelected = selectedNodeId === node.id;
            const isBottleneck = node.status === 'ENGPASS';
            const isWarning = node.status === 'WARNUNG';

            const strokeColor = isBottleneck ? '#ef4444' : isWarning ? '#f59e0b' : '#38bdf8';
            const fillColor = isBottleneck ? '#450a0a' : isWarning ? '#451a03' : '#0f172a';

            return (
              <g
                key={node.id}
                onClick={() => setSelectedNodeId(node.id)}
                className="cursor-pointer group"
                transform={`translate(${node.x}, ${node.y})`}
              >
                {/* Outer Glow on Selection */}
                {isSelected && (
                  <rect
                    x="-65"
                    y="-45"
                    width="130"
                    height="90"
                    fill="none"
                    stroke="#ffffff"
                    strokeWidth="1.5"
                    strokeDasharray="4 2"
                  />
                )}

                {/* Node Box */}
                <rect
                  x="-60"
                  y="-40"
                  width="120"
                  height="80"
                  fill={fillColor}
                  stroke={strokeColor}
                  strokeWidth={isSelected ? '2.5' : '1.5'}
                  rx="2"
                  className="transition-all group-hover:stroke-[#ffffff]"
                />

                {/* Node Header */}
                <rect x="-60" y="-40" width="120" height="18" fill="#1e293b" />
                <text x="0" y="-27" textAnchor="middle" fill="#f8fafc" fontSize="8" fontFamily="monospace" fontWeight="bold">
                  {node.label}
                </text>

                {/* Subtitle / Station Name */}
                <text x="0" y="-12" textAnchor="middle" fill="#94a3b8" fontSize="7" fontFamily="monospace">
                  {node.sublabel.split(' ')[0]} {node.sublabel.split(' ')[1] || ''}
                </text>

                {/* Utilization Progress Bar */}
                <rect x="-50" y="5" width="100" height="6" fill="#0d1117" stroke="#334155" strokeWidth="0.5" />
                <rect
                  x="-50"
                  y="5"
                  width={node.utilization}
                  height="6"
                  fill={isBottleneck ? '#ef4444' : isWarning ? '#eab308' : '#22c55e'}
                />

                <text x="0" y="24" textAnchor="middle" fill="#f1f5f9" fontSize="9" fontFamily="monospace" fontWeight="bold">
                  {node.currentThroughput} / {node.capacityPerHour} Fzg/h ({node.utilization}%)
                </text>
              </g>
            );
          })}
        </svg>
      </div>

      {/* Selected Node Details & Bottleneck Analytics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4 text-xs font-mono">
        <div className="bg-[#161b22] border border-[#30363d] p-3 space-y-1.5">
          <div className="text-[10px] text-[#8b949e]">GEWÄHLTER KNOTEN:</div>
          <div className="text-sm font-bold text-[#f0f6fc]">{selectedNode.label}</div>
          <div className="text-[11px] text-[#93c5fd]">{selectedNode.sublabel}</div>
          <div className="pt-2 border-t border-[#30363d] flex justify-between">
            <span className="text-[#8b949e]">Durchlaufzeit:</span>
            <span className="font-bold text-[#f0f6fc]">{selectedNode.leadTimeMin} Minuten</span>
          </div>
        </div>

        <div className="bg-[#161b22] border border-[#30363d] p-3 space-y-1.5">
          <div className="text-[10px] text-[#8b949e]">KAPAZITÄTSAUSLASTUNG:</div>
          <div className="text-sm font-bold text-[#f0f6fc]">
            {selectedNode.currentThroughput} von {selectedNode.capacityPerHour} Einheiten / Stunde
          </div>
          <div className="w-full bg-[#0d1117] h-2 border border-[#30363d] mt-2">
            <div
              className={`h-full ${
                selectedNode.status === 'ENGPASS' ? 'bg-[#ef4444]' : selectedNode.status === 'WARNUNG' ? 'bg-[#eab308]' : 'bg-[#22c55e]'
              }`}
              style={{ width: `${selectedNode.utilization}%` }}
            />
          </div>
          <div className="text-[10px] text-[#8b949e] flex justify-between">
            <span>Auslastung:</span>
            <span className="font-bold text-[#f0f6fc]">{selectedNode.utilization}%</span>
          </div>
        </div>

        <div className="bg-[#161b22] border border-[#30363d] p-3 space-y-1.5">
          <div className="text-[10px] text-[#8b949e]">ENGPASS-BEWERTUNG (VDA 6.3):</div>
          <div className={`font-bold text-sm ${
            selectedNode.status === 'ENGPASS' ? 'text-[#ef4444]' : selectedNode.status === 'WARNUNG' ? 'text-[#facc15]' : 'text-[#4ade80]'
          }`}>
            {selectedNode.status === 'ENGPASS'
              ? 'KRITISCHER ENGAPSS — TAKTZEITÜBERSCHREITUNG'
              : selectedNode.status === 'WARNUNG'
              ? 'PUFFER KAPAZITÄT BEOBACHTEN'
              : 'PROZESSFLUSS IM SOLL'}
          </div>
          <div className="text-[10px] text-[#8b949e]">
            {selectedNode.status === 'ENGPASS'
              ? 'Empfehlung: Dynamische Lastverteilung auf Nebenlinie oder AGV-Puffer aktivieren.'
              : 'Materialzufuhr synchron mit Taktzeit.'}
          </div>
        </div>
      </div>
    </div>
  );
};
