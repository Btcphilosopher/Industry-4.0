// ============================================================================
// WERK 4.0 — R-ARCHITEKTUR EXPLORER & SIMULIERTE AUSFÜHRUNGS-KONSOLE
// Inspektion und Ausführung aller 22+ R-Skripte, R6-Klassen, Shiny-Module und Docker-Configs
// ============================================================================

import React, { useState } from 'react';
import { R_FILE_REPOSITORY, executeSimulatedRCode } from '../lib/rCodebase';
import { Code, Play, Download, Copy, Check, Terminal, FileCode, Folder, Database } from 'lucide-react';

export const RCodeExplorer: React.FC<Props> = () => {
  const [selectedFileId, setSelectedFileId] = useState<string>('R/03_robot_kinematics.R');
  const [customRCode, setCustomRCode] = useState<string>('calc_spc_indices(c(3.20, 3.21, 3.19, 3.27, 3.20, 3.18, 3.22), usl=3.25, lsl=3.15)');
  const [executionOutput, setExecutionOutput] = useState<string | null>(null);
  const [isExecuting, setIsExecuting] = useState(false);
  const [copied, setCopied] = useState(false);

  const selectedFile = R_FILE_REPOSITORY.find((f) => f.path === selectedFileId) || R_FILE_REPOSITORY[0];

  const handleRunR = () => {
    setIsExecuting(true);
    setTimeout(() => {
      const out = executeSimulatedRCode(customRCode);
      setExecutionOutput(out);
      setIsExecuting(false);
    }, 400);
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadAll = () => {
    // Generate downloadable combined R package archive as text file or multiple triggers
    const fullProjectText = R_FILE_REPOSITORY.map((f) => `### FILE: ${f.path}\n### DESC: ${f.description}\n${f.content}\n\n`).join('='.repeat(80) + '\n');
    const blob = new Blob([fullProjectText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'WERK_4_0_R_CODEBASE_PROJECT.R';
    link.click();
  };

  // Group files by directory
  const rootFiles = R_FILE_REPOSITORY.filter((f) => !f.path.includes('/'));
  const rCoreFiles = R_FILE_REPOSITORY.filter((f) => f.path.startsWith('R/'));
  const moduleFiles = R_FILE_REPOSITORY.filter((f) => f.path.startsWith('modules/'));
  const docFiles = R_FILE_REPOSITORY.filter((f) => f.path.startsWith('sql/') || f.path.endsWith('.txt') || f.path.endsWith('Dockerfile'));

  return (
    <div className="bg-[#0d1117] border border-[#21262d] p-4 text-[#e6edf3]">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between pb-3 border-b border-[#21262d] gap-2">
        <div className="flex items-center gap-2">
          <Terminal className="w-5 h-5 text-[#38bdf8]" />
          <div>
            <div className="font-mono font-bold text-sm text-[#f0f6fc]">
              R-KERN ARCHITEKTUR & INDUSTRIELLE CODE-BASE
            </div>
            <div className="text-[11px] font-mono text-[#8b949e]">
              22 R-Dateien | R6-Klassen | Shiny bslib Module | igraph & lpSolve | VDA 6.3 SPC Engine
            </div>
          </div>
        </div>

        <button
          onClick={handleDownloadAll}
          id="download-r-project-btn"
          className="flex items-center gap-1.5 px-3 py-1.5 bg-[#161b22] hover:bg-[#21262d] text-[#38bdf8] font-mono text-xs font-bold border border-[#38bdf8] transition-all"
        >
          <Download className="w-3.5 h-3.5" />
          <span>R-PROJEKT HERUNTERLADEN (.R / RStudio)</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 mt-4">
        {/* Left: File Tree Explorer */}
        <div className="lg:col-span-4 bg-[#070a0f] border border-[#21262d] p-3 max-h-[560px] overflow-y-auto font-mono text-xs">
          <div className="text-[10px] text-[#8b949e] font-bold uppercase pb-2 mb-2 border-b border-[#21262d]">
            DATEISTRUKTUR (R-PROJEKT)
          </div>

          {/* Root files */}
          <div className="space-y-1 mb-3">
            <div className="text-[10px] text-[#64748b] font-bold flex items-center gap-1">
              <Folder className="w-3 h-3 text-[#38bdf8]" /> PROJEKT-ROOT
            </div>
            {rootFiles.map((f) => (
              <button
                key={f.path}
                onClick={() => setSelectedFileId(f.path)}
                className={`w-full text-left pl-4 py-1 text-[11px] flex items-center gap-1.5 transition-colors ${
                  selectedFileId === f.path ? 'bg-[#1e293b] text-[#38bdf8] font-bold' : 'text-[#8b949e] hover:text-[#f0f6fc]'
                }`}
              >
                <FileCode className="w-3 h-3 text-[#38bdf8]" />
                <span className="truncate">{f.path}</span>
              </button>
            ))}
          </div>

          {/* R/ Core Logic files */}
          <div className="space-y-1 mb-3">
            <div className="text-[10px] text-[#64748b] font-bold flex items-center gap-1">
              <Folder className="w-3 h-3 text-[#eab308]" /> R/ (MATHEMATIK & SIMULATION)
            </div>
            {rCoreFiles.map((f) => (
              <button
                key={f.path}
                onClick={() => setSelectedFileId(f.path)}
                className={`w-full text-left pl-4 py-1 text-[11px] flex items-center gap-1.5 transition-colors ${
                  selectedFileId === f.path ? 'bg-[#1e293b] text-[#38bdf8] font-bold' : 'text-[#8b949e] hover:text-[#f0f6fc]'
                }`}
              >
                <FileCode className="w-3 h-3 text-[#eab308]" />
                <span className="truncate">{f.path.replace('R/', '')}</span>
              </button>
            ))}
          </div>

          {/* modules/ Shiny Module files */}
          <div className="space-y-1 mb-3">
            <div className="text-[10px] text-[#64748b] font-bold flex items-center gap-1">
              <Folder className="w-3 h-3 text-[#a855f7]" /> MODULES/ (SHINY DASHBOARD)
            </div>
            {moduleFiles.map((f) => (
              <button
                key={f.path}
                onClick={() => setSelectedFileId(f.path)}
                className={`w-full text-left pl-4 py-1 text-[11px] flex items-center gap-1.5 transition-colors ${
                  selectedFileId === f.path ? 'bg-[#1e293b] text-[#38bdf8] font-bold' : 'text-[#8b949e] hover:text-[#f0f6fc]'
                }`}
              >
                <FileCode className="w-3 h-3 text-[#a855f7]" />
                <span className="truncate">{f.path.replace('modules/', '')}</span>
              </button>
            ))}
          </div>

          {/* SQL and Configs */}
          <div className="space-y-1">
            <div className="text-[10px] text-[#64748b] font-bold flex items-center gap-1">
              <Folder className="w-3 h-3 text-[#22c55e]" /> INFRASTRUKTUR / SQL
            </div>
            {docFiles.map((f) => (
              <button
                key={f.path}
                onClick={() => setSelectedFileId(f.path)}
                className={`w-full text-left pl-4 py-1 text-[11px] flex items-center gap-1.5 transition-colors ${
                  selectedFileId === f.path ? 'bg-[#1e293b] text-[#38bdf8] font-bold' : 'text-[#8b949e] hover:text-[#f0f6fc]'
                }`}
              >
                <Database className="w-3 h-3 text-[#22c55e]" />
                <span className="truncate">{f.path}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Right: Code Inspector & Simulated R-Console Execution */}
        <div className="lg:col-span-8 space-y-3">
          {/* File Viewer */}
          <div className="bg-[#070a0f] border border-[#21262d] p-3">
            <div className="flex justify-between items-center pb-2 border-b border-[#21262d] text-xs font-mono">
              <div>
                <span className="font-bold text-[#f0f6fc]">{selectedFile.path}</span>
                <div className="text-[10px] text-[#8b949e]">{selectedFile.description}</div>
              </div>
              <button
                onClick={handleCopyCode}
                className="flex items-center gap-1 px-2.5 py-1 bg-[#161b22] hover:bg-[#21262d] border border-[#30363d] text-xs text-[#c9d1d9]"
              >
                {copied ? <Check className="w-3 h-3 text-[#4ade80]" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? 'Kopiert' : 'Code kopieren'}</span>
              </button>
            </div>

            <pre className="mt-2 p-3 bg-[#0d1117] border border-[#21262d] text-[#e6edf3] font-mono text-[11px] leading-relaxed max-h-[300px] overflow-y-auto whitespace-pre">
              {selectedFile.content}
            </pre>
          </div>

          {/* Interactive R-Command Line */}
          <div className="bg-[#161b22] border border-[#30363d] p-3 text-xs font-mono space-y-2">
            <div className="flex justify-between items-center">
              <span className="font-bold text-[#f0f6fc] flex items-center gap-1.5">
                <Terminal className="w-3.5 h-3.5 text-[#38bdf8]" />
                R-KONSOLE (SIMULIERTER R-KERN v4.4.0)
              </span>
              <span className="text-[10px] text-[#8b949e]">BEFEHLE: SPC, KINEMATIK, SLOTTING, PREDICTIVE</span>
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                value={customRCode}
                onChange={(e) => setCustomRCode(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleRunR()}
                placeholder="R-Befehl eingeben..."
                className="flex-1 bg-[#0d1117] border border-[#30363d] px-3 py-1.5 text-[#f0f6fc] text-xs font-mono focus:outline-none focus:border-[#38bdf8]"
              />
              <button
                onClick={handleRunR}
                disabled={isExecuting}
                id="execute-r-code-btn"
                className="px-4 py-1.5 bg-[#0284c7] hover:bg-[#0369a1] text-white font-bold flex items-center gap-1"
              >
                <Play className="w-3.5 h-3.5" />
                <span>{isExecuting ? 'BERECHNE...' : 'R AUSFÜHREN'}</span>
              </button>
            </div>

            {/* Quick snippet buttons */}
            <div className="flex flex-wrap gap-1.5 pt-1 text-[10px]">
              <span className="text-[#8b949e]">Beispiele:</span>
              <button
                onClick={() => setCustomRCode('calc_spc_indices(c(3.20, 3.21, 3.19, 3.27, 3.20, 3.18, 3.22), usl=3.25, lsl=3.15)')}
                className="px-1.5 py-0.5 bg-[#0d1117] text-[#93c5fd] border border-[#30363d] hover:border-[#38bdf8]"
              >
                SPC Cp/Cpk
              </button>
              <button
                onClick={() => setCustomRCode('forward_kinematics_dh(q=c(20, -45, 90, 0, 45, 0))')}
                className="px-1.5 py-0.5 bg-[#0d1117] text-[#93c5fd] border border-[#30363d] hover:border-[#38bdf8]"
              >
                DH Kinematik
              </button>
              <button
                onClick={() => setCustomRCode('optimize_warehouse_slotting(aisle="B", occupancy=0.95)')}
                className="px-1.5 py-0.5 bg-[#0d1117] text-[#93c5fd] border border-[#30363d] hover:border-[#38bdf8]"
              >
                lpSolve Slotting
              </button>
              <button
                onClick={() => setCustomRCode('predict_rul_wear(robot_id="ROB-042", vib_rms=4.85, temp=74)')}
                className="px-1.5 py-0.5 bg-[#0d1117] text-[#93c5fd] border border-[#30363d] hover:border-[#38bdf8]"
              >
                RUL Prognose
              </button>
            </div>

            {/* Execution Console Output */}
            {executionOutput && (
              <pre className="mt-2 p-3 bg-[#070a0f] border border-[#30363d] text-[#7ee787] text-[11px] font-mono whitespace-pre-wrap">
                {executionOutput}
              </pre>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

interface Props {}
