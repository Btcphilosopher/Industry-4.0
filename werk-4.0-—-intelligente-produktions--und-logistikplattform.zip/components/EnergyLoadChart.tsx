// ============================================================================
// WERK 4.0 — ENERGIE DIGITAL TWIN & PEAK SHAVING LASTMANAGEMENT
// ============================================================================

import React, { useState } from 'react';
import { FactoryEnergyData } from '../lib/types';
import { Zap, TrendingDown, Leaf, DollarSign, Sparkles, BarChart2, ShieldAlert } from 'lucide-react';

interface Props {
  energyData: FactoryEnergyData;
}

export const EnergyLoadChart: React.FC<Props> = ({ energyData }) => {
  const [peakShavingActive, setPeakShavingActive] = useState(false);

  // 24h Load profile data
  const hourlyProfile = [
    { hour: '00:00', load: 8.2, shift: 'Nacht' },
    { hour: '02:00', load: 7.9, shift: 'Nacht' },
    { hour: '04:00', load: 8.5, shift: 'Nacht' },
    { hour: '06:00', load: 15.2, shift: 'Früh' },
    { hour: '08:00', load: 19.8, shift: 'Früh' },
    { hour: '10:00', load: 21.4, shift: 'Früh' }, // Peak!
    { hour: '12:00', load: 17.5, shift: 'Früh' },
    { hour: '14:00', load: 20.8, shift: 'Spät' }, // Peak!
    { hour: '16:00', load: 18.9, shift: 'Spät' },
    { hour: '18:00', load: 16.4, shift: 'Spät' },
    { hour: '20:00', load: 14.1, shift: 'Spät' },
    { hour: '22:00', load: 9.6, shift: 'Nacht' },
  ];

  const peakLimit = 19.0; // MW contract max

  const chartW = 560;
  const chartH = 180;
  const padX = 35;
  const padY = 25;

  const maxL = 24.0;
  const minL = 0.0;
  const scaleY = (l: number) => chartH - padY - ((l - minL) / (maxL - minL)) * (chartH - 2 * padY);
  const scaleX = (i: number) => padX + (i / (hourlyProfile.length - 1)) * (chartW - 2 * padX);

  return (
    <div className="bg-[#0d1117] border border-[#21262d] p-4 text-[#e6edf3]">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between pb-3 border-b border-[#21262d] gap-2">
        <div className="flex items-center gap-2">
          <Zap className="w-5 h-5 text-[#facc15]" />
          <div>
            <div className="font-mono font-bold text-sm text-[#f0f6fc]">
              ENERGIE-LEITSTAND & PEAK-SHAVING OPTIMIERUNG
            </div>
            <div className="text-[11px] font-mono text-[#8b949e]">
              Lastspitzen-Glättung | CO2-Bilanz nach ISO 50001 | 24-Stunden-Transformatorauslastung
            </div>
          </div>
        </div>

        <button
          onClick={() => setPeakShavingActive(!peakShavingActive)}
          id="toggle-peak-shaving-btn"
          className={`flex items-center gap-1.5 px-3 py-1.5 font-mono text-xs font-bold border transition-all ${
            peakShavingActive
              ? 'bg-[#15803d] text-white border-[#22c55e] shadow-[0_0_8px_rgba(34,197,94,0.4)]'
              : 'bg-[#161b22] text-[#e6edf3] border-[#30363d] hover:bg-[#21262d]'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-[#facc15]" />
          <span>{peakShavingActive ? 'PEAK-SHAVING AKTIV (-2.4 MW)' : 'PEAK-SHAVING AKTIVIEREN'}</span>
        </button>
      </div>

      {/* KPI Headline Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 my-3 font-mono text-xs">
        <div className="bg-[#161b22] border border-[#30363d] p-2.5">
          <div className="text-[10px] text-[#8b949e]">GESAMTLEISTUNG (WERK 07):</div>
          <div className="text-base font-bold text-[#f0f6fc]">
            {peakShavingActive ? (energyData.currentTotalLoadMW - 2.4).toFixed(1) : energyData.currentTotalLoadMW.toFixed(1)} MW
          </div>
          <div className="text-[9px] text-[#8b949e]">Netzgrenze: 22.0 MW</div>
        </div>

        <div className="bg-[#161b22] border border-[#30363d] p-2.5">
          <div className="text-[10px] text-[#8b949e]">ENERGIE / FAHRZEUG:</div>
          <div className="text-base font-bold text-[#38bdf8]">
            {energyData.kwhPerVehicle} kWh
          </div>
          <div className="text-[9px] text-[#8b949e]">Ziel: &le; 480 kWh/Fahrzeug</div>
        </div>

        <div className="bg-[#161b22] border border-[#30363d] p-2.5">
          <div className="text-[10px] text-[#8b949e] flex items-center gap-1">
            <DollarSign className="w-3 h-3 text-[#facc15]" />
            ENERGIEKOSTEN / PKW:
          </div>
          <div className="text-base font-bold text-[#facc15]">
            {energyData.costPerVehicleEur} €
          </div>
          <div className="text-[9px] text-[#8b949e]">0.22 € / kWh Industrie</div>
        </div>

        <div className="bg-[#161b22] border border-[#30363d] p-2.5">
          <div className="text-[10px] text-[#8b949e] flex items-center gap-1">
            <Leaf className="w-3 h-3 text-[#4ade80]" />
            CO2-FUSSABDRUCK:
          </div>
          <div className="text-base font-bold text-[#4ade80]">
            {energyData.co2PerVehicleKg} kg CO₂
          </div>
          <div className="text-[9px] text-[#8b949e]">74% Grünstrom-Anteil</div>
        </div>
      </div>

      {/* 24h Profile Chart & Hall Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 mt-3">
        {/* Left: 24h Load Curve */}
        <div className="lg:col-span-8 bg-[#070a0f] border border-[#21262d] p-3">
          <div className="flex justify-between items-center pb-2 border-b border-[#21262d] text-xs font-mono">
            <span className="font-bold text-[#f0f6fc]">24-STUNDEN LASTPROFIL (MW ELEKTRISCH)</span>
            <span className="text-[10px] text-[#8b949e]">VERTRIEBSVERTRAG: 19.0 MW MAX</span>
          </div>

          <div className="mt-2 overflow-x-auto flex justify-center">
            <svg className="w-full max-w-[580px] h-[180px]" viewBox={`0 0 ${chartW} ${chartH}`}>
              {/* Peak Shaving Limit Line */}
              <line x1={padX} y1={scaleY(peakLimit)} x2={chartW - padX} y2={scaleY(peakLimit)} stroke="#ef4444" strokeWidth="1.5" strokeDasharray="4 2" />
              <text x={chartW - padX + 4} y={scaleY(peakLimit) + 3} fill="#ef4444" fontSize="8" fontFamily="monospace">LIMIT 19 MW</text>

              {/* Load Area Gradient */}
              <defs>
                <linearGradient id="loadGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#facc15" stopOpacity="0.4" />
                  <stop offset="100%" stopColor="#facc15" stopOpacity="0.0" />
                </linearGradient>
              </defs>

              {/* Area polygon */}
              <polygon
                fill="url(#loadGrad)"
                points={`
                  ${scaleX(0)},${chartH - padY}
                  ${hourlyProfile.map((p, i) => `${scaleX(i)},${scaleY(peakShavingActive && p.load > 18 ? p.load - 2.4 : p.load)}`).join(' ')}
                  ${scaleX(hourlyProfile.length - 1)},${chartH - padY}
                `}
              />

              {/* Polyline */}
              <polyline
                fill="none"
                stroke="#facc15"
                strokeWidth="2"
                points={hourlyProfile.map((p, i) => `${scaleX(i)},${scaleY(peakShavingActive && p.load > 18 ? p.load - 2.4 : p.load)}`).join(' ')}
              />

              {/* Dots and Labels */}
              {hourlyProfile.map((p, i) => {
                const actualLoad = peakShavingActive && p.load > 18 ? p.load - 2.4 : p.load;
                const isOver = actualLoad > peakLimit;

                return (
                  <g key={i}>
                    <circle
                      cx={scaleX(i)}
                      cy={scaleY(actualLoad)}
                      r={isOver ? 4.5 : 3}
                      fill={isOver ? '#dc2626' : '#facc15'}
                      stroke="#0f172a"
                      strokeWidth="1.5"
                    />
                    <text x={scaleX(i)} y={chartH - 8} textAnchor="middle" fill="#64748b" fontSize="7" fontFamily="monospace">
                      {p.hour}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>
        </div>

        {/* Right: Hall Distribution Breakdown */}
        <div className="lg:col-span-4 bg-[#161b22] border border-[#30363d] p-3 text-xs font-mono space-y-2.5">
          <div className="font-bold text-[#f0f6fc] pb-1 border-b border-[#30363d]">
            VERBRAUCH NACH BEREICHEN
          </div>

          {[
            { name: 'Halle 2 Karosseriebau', load: '5.9 MW', pct: 31, color: '#38bdf8' },
            { name: 'Halle 1 Presswerk', load: '4.8 MW', pct: 25, color: '#f59e0b' },
            { name: 'Halle 3 Lackiererei / KTL', load: '3.2 MW', pct: 17, color: '#14b8a6' },
            { name: 'Halle 4 Antrieb & Batterie', load: '2.7 MW', pct: 14, color: '#a855f7' },
            { name: 'Halle 5 Montage & Lager', load: '2.1 MW', pct: 13, color: '#22c55e' },
          ].map((item) => (
            <div key={item.name} className="space-y-1">
              <div className="flex justify-between text-[11px]">
                <span className="text-[#c9d1d9]">{item.name}</span>
                <span className="font-bold text-[#f0f6fc]">{item.load} ({item.pct}%)</span>
              </div>
              <div className="w-full bg-[#0d1117] h-1.5 border border-[#30363d]">
                <div className="h-full" style={{ width: `${item.pct}%`, backgroundColor: item.color }} />
              </div>
            </div>
          ))}

          {peakShavingActive && (
            <div className="mt-3 p-2 bg-[#064e3b] border border-[#10b981] text-[10px] text-[#a7f3d0] space-y-0.5">
              <div className="font-bold">PEAK-SHAVING REGELUNG AKTIV:</div>
              <div>• KTL-Aufheizung um 45 min verschoben</div>
              <div>• Batterieladezyklen auf Schwachlast gedrosselt</div>
              <div>• Einsparung Leistungsentgelt: ~42.000 € / a</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
