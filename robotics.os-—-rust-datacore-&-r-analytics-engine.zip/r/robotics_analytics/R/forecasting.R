#' Robotics.OS Analytics - ARIMA / Exponential Smoothing Production Forecasting
#' @import forecast
#' @export
forecast_production_output <- function(historical_hourly_units, horizon_hours = 12) {
  ts_data <- ts(historical_hourly_units, frequency = 24)
  fit <- auto.arima(ts_data)
  fc <- forecast(fit, h = horizon_hours)
  
  list(
    model_name = as.character(fit),
    mean_forecast = round(as.numeric(fc$mean), 1),
    lower_95 = round(as.numeric(fc$lower[, 2]), 1),
    upper_95 = round(as.numeric(fc$upper[, 2]), 1),
    aic = round(fit$aic, 2),
    projected_shift_total = round(sum(fc$mean), 0)
  )
}
