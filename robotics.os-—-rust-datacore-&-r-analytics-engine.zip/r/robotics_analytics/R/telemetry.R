#' Robotics.OS Analytics - Ingest Arrow Telemetry & Statistical Aggregations
#' @import arrow data.table dplyr
#' @export
ingest_rust_arrow_stream <- function(arrow_table_or_path) {
  if (is.character(arrow_table_or_path)) {
    df <- arrow::read_parquet(arrow_table_or_path)
  } else {
    df <- as.data.table(arrow_table_or_path)
  }
  
  # Ensure column typing and clean data quality flags
  dt <- as.data.table(df)
  return(dt)
}

#' Calculate rolling summary statistics over robot telemetry
#' @export
compute_robot_kpis <- function(telemetry_dt, window_sec = 60) {
  kpis <- telemetry_dt[, .(
    mean_energy = mean(energy_watts, na.rm = TRUE),
    p95_energy = quantile(energy_watts, 0.95, na.rm = TRUE),
    vibration_rms_mean = mean(vibration_rms, na.rm = TRUE),
    vibration_rms_max = max(vibration_rms, na.rm = TRUE),
    mean_j1_torque = mean(abs(j0_torque), na.rm = TRUE),
    data_quality_pct = 100 * mean(quality_flag == 0, na.rm = TRUE)
  ), by = .(robot_id)]
  
  return(kpis)
}
