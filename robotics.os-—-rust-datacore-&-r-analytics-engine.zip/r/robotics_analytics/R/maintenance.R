#' Robotics.OS Analytics - Predictive Maintenance & Remaining Useful Life (RUL)
#' Implements Weibull Hazard Rate and Joint Degradation Survival Models
#' @import survival
#' @export
estimate_weibull_rul <- function(operating_hours, vibration_rms, motor_temp, beta_shape = 2.4, eta_scale = 12000) {
  # Acceleration factor based on Arrhenius thermal model and vibration penalty
  temp_stress <- exp(0.045 * (motor_temp - 40.0))
  vib_stress <- exp(3.2 * (vibration_rms - 0.02))
  stress_factor <- max(1.0, temp_stress * vib_stress)
  
  effective_age <- operating_hours * stress_factor
  
  # Weibull Survival Function S(t) = exp(-(t / eta)^beta)
  survival_prob <- exp(- (effective_age / eta_scale)^beta_shape)
  
  # Instantaneous failure rate / hazard h(t) = (beta/eta) * (t/eta)^(beta-1)
  hazard_rate <- (beta_shape / eta_scale) * (effective_age / eta_scale)^(beta_shape - 1)
  
  # Median Remaining Useful Life (RUL) where S(t + RUL) / S(t) = 0.5
  rul_hours_nominal <- eta_scale * ( (-log(0.5) + (effective_age / eta_scale)^beta_shape )^(1 / beta_shape) ) - effective_age
  rul_hours <- max(0, rul_hours_nominal / stress_factor)
  
  # Health score (0-100)
  health_score <- round(max(0, min(100, survival_prob * 100)), 1)
  wear_index <- round(min(1.0, (1.0 - survival_prob)), 3)
  
  list(
    health_score = health_score,
    wear_index = wear_index,
    estimated_rul_hours = round(rul_hours, 1),
    survival_prob = round(survival_prob, 4),
    hazard_rate = signif(hazard_rate, 4),
    confidence_interval_90 = c(round(rul_hours * 0.78, 1), round(rul_hours * 1.25, 1)),
    urgency = if (health_score < 40) "CRITICAL" else if (health_score < 70) "SCHEDULED_SOON" else "NORMAL"
  )
}
