#' Robotics.OS Analytics - Energy Analytics & Peak Shaving Optimizer
#' @export
optimize_energy_profile <- function(robot_energy_series_kw, peak_limit_kw = 45.0) {
  mean_power <- mean(robot_energy_series_kw)
  max_power <- max(robot_energy_series_kw)
  
  # Peak-to-average ratio (PAR)
  par <- max_power / mean_power
  
  # Identify regenerative braking windows (negative or minimal current draw)
  regen_opportunity <- sum(robot_energy_series_kw < 0.2 * mean_power) / length(robot_energy_series_kw)
  
  list(
    mean_power_kw = round(mean_power, 2),
    peak_power_kw = round(max_power, 2),
    par_ratio = round(par, 2),
    regen_opportunity_pct = round(regen_opportunity * 100, 1),
    peak_shaving_recommendation = if (max_power > peak_limit_kw) {
      "Stagger acceleration profiles of Robot-3 and Robot-5 by 420ms to eliminate concurrent peak power spikes."
    } else {
      "Power consumption within plant grid threshold."
    }
  )
}
