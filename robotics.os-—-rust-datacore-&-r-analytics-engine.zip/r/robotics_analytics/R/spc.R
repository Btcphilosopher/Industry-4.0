#' Robotics.OS Analytics - Statistical Process Control (SPC) Engine
#' Shewhart Control Charts (X-bar, R, S) and Nelson Rules Violation Detections
#' @export
compute_spc_xbar_r <- function(data_matrix, subgroup_size = 5) {
  # Calculate subgroup means and ranges
  n_subgroups <- floor(length(data_matrix) / subgroup_size)
  if (n_subgroups < 2) {
    stop("Insufficient data points for SPC calculation. Subgroups >= 2 required.")
  }
  
  mat <- matrix(data_matrix[1:(n_subgroups * subgroup_size)], ncol = subgroup_size, byrow = TRUE)
  x_bar <- rowMeans(mat)
  r_val <- apply(mat, 1, function(row) max(row) - min(row))
  
  # Shewhart constants for n=5
  a2 <- 0.577
  d3 <- 0.0
  d4 <- 2.114
  
  grand_mean_x <- mean(x_bar)
  mean_r <- mean(r_val)
  
  ucl_x <- grand_mean_x + (a2 * mean_r)
  lcl_x <- grand_mean_x - (a2 * mean_r)
  
  ucl_r <- d4 * mean_r
  lcl_r <- d3 * mean_r
  
  # Nelson Rule 1: One point beyond 3-sigma (UCL/LCL)
  rule1_violations <- which(x_bar > ucl_x | x_bar < lcl_x)
  
  # Nelson Rule 2: Nine consecutive points on same side of center line
  rule2_violations <- integer(0)
  if (length(x_bar) >= 9) {
    signs <- sign(x_bar - grand_mean_x)
    for (i in 9:length(signs)) {
      if (abs(sum(signs[(i-8):i])) == 9) {
        rule2_violations <- c(rule2_violations, i)
      }
    }
  }
  
  list(
    x_bar = x_bar,
    r_val = r_val,
    grand_mean_x = grand_mean_x,
    mean_r = mean_r,
    ucl_x = ucl_x,
    lcl_x = lcl_x,
    ucl_r = ucl_r,
    lcl_r = lcl_r,
    rule1_violations = rule1_violations,
    rule2_violations = rule2_violations,
    in_control = (length(rule1_violations) == 0 && length(rule2_violations) == 0)
  )
}
