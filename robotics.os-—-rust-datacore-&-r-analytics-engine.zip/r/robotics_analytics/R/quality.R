#' Robotics.OS Analytics - Quality Analytics & Trajectory Defect Modeling
#' Identifies relationships between machine kinematics/vibration and micro-defect rates
#' @export
model_trajectory_quality <- function(joint_vibrations, trajectory_jerks, measured_tolerances_um) {
  df <- data.frame(
    vib = joint_vibrations,
    jerk = trajectory_jerks,
    tol_um = measured_tolerances_um
  )
  
  fit <- lm(tol_um ~ vib + jerk + vib:jerk, data = df)
  s <- summary(fit)
  
  r_squared <- s$r.squared
  p_val_vib <- s$coefficients["vib", 4]
  p_val_jerk <- s$coefficients["jerk", 4]
  
  # Predict defect probability (tolerance breach > 15 um)
  defect_prob <- mean(predict(fit, df) > 15.0)
  
  list(
    r_squared = round(r_squared, 4),
    p_value_vibration = signif(p_val_vib, 3),
    p_value_jerk = signif(p_val_jerk, 3),
    estimated_defect_ppm = round(defect_prob * 1e6, 0),
    recommendation = if (p_val_jerk < 0.05) "Constrain trajectory jerk to <= 18 m/s³ to eliminate micro-chatter defects" else "Quality within statistical control"
  )
}
