import React, { useState, useEffect } from 'react';
import { RobotState, Workcell, FactoryKpis, ClosedLoopEvent } from './types';
import { Header } from './components/Header';
import { DigitalTwinFactory } from './components/DigitalTwinFactory';
import { TrajectoryOptimizerView } from './components/TrajectoryOptimizerView';
import { SpcQualityView } from './components/SpcQualityView';
import { PredictiveMaintenanceView } from './components/PredictiveMaintenanceView';
import { FactorySchedulerView } from './components/FactorySchedulerView';
import { ClosedLoopConsole } from './components/ClosedLoopConsole';
import { CodeExplorerView } from './components/CodeExplorerView';
import { BenchmarkingView } from './components/BenchmarkingView';
import { RobotDetailModal } from './components/RobotDetailModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('factory');
  const [robots, setRobots] = useState<RobotState[]>([]);
  const [workcells, setWorkcells] = useState<Workcell[]>([]);
  const [ingestionCount, setIngestionCount] = useState<number>(1_842_500);
  const [primaryBottleneck, setPrimaryBottleneck] = useState<string>('CELL-7 (Laser Metrology & QA)');
  const [selectedRobot, setSelectedRobot] = useState<RobotState | null>(null);

  const [closedLoopStage, setClosedLoopStage] = useState<string>('OPTIMISE');
  const [isApproved, setIsApproved] = useState<boolean>(false);

  const [events, setEvents] = useState<ClosedLoopEvent[]>([
    {
      id: 'EVT-01',
      timestamp: '03:14:02.140',
      phase: 'SENSE',
      source: 'RUST_DATACORE',
      title: 'High-Throughput Telemetry Ingestion',
      details: 'Ingested 250,000 frames/sec across 8 robot workcells via zero-allocation ring buffers.'
    },
    {
      id: 'EVT-02',
      timestamp: '03:14:02.320',
      phase: 'MEASURE',
      source: 'RUST_DATACORE',
      title: 'Rolling Welford Variance & Vibration RMS',
      details: 'Calculated online variance; flagged elevated RMS (0.062g) in Cell 7 (Laser Metrology).'
    },
    {
      id: 'EVT-03',
      timestamp: '03:14:02.650',
      phase: 'ANALYSE',
      source: 'R_ANALYTICS',
      title: 'Shewhart SPC & Nelson Rule Detection',
      details: 'Flagged Nelson Rule 2 violation in Subgroups 19-21. Bottleneck probability: 98.4%.'
    },
    {
      id: 'EVT-04',
      timestamp: '03:14:02.910',
      phase: 'MODEL',
      source: 'R_ANALYTICS',
      title: 'Weibull RUL & Thermal Degradation',
      details: 'Predicted RUL of 340 operating hours for R-107 metrology gantry (90% CI: [265, 425]h).'
    },
    {
      id: 'EVT-05',
      timestamp: '03:14:03.200',
      phase: 'OPTIMISE',
      source: 'RUST_DATACORE',
      title: 'NSGA-II Pareto Trajectory Rebalancing',
      details: 'Proposed 7-segment S-curve: cycle time 42.3s → 38.7s (+8.5% gain), energy -4.3%.'
    }
  ]);

  const kpis: FactoryKpis = {
    totalUnitsProduced: 48920,
    overallOee: 0.884,
    activeFleetSize: robots.length || 8,
    averageCycleTime: 38.7,
    totalEnergyConsumptionKwh: 878.5,
    factoryBottleneckCell: primaryBottleneck,
    fleetHealthAverage: robots.length ? robots.reduce((acc, r) => acc + r.healthScore, 0) / robots.length : 88.5,
    fleetAnomalyRate: 0.024,
    dataIngestionRateRecordsPerSec: 250_000
  };

  // Poll real-time telemetry stream from backend
  useEffect(() => {
    let isMounted = true;
    const fetchStream = async () => {
      try {
        const res = await fetch('/api/telemetry/stream');
        if (res.ok) {
          const data = await res.json();
          if (isMounted) {
            setRobots(data.robots || []);
            setWorkcells(data.workcells || []);
            setPrimaryBottleneck(data.primaryBottleneck || 'CELL-7 (Laser Metrology)');
            setIngestionCount((prev) => prev + 2500);
          }
        }
      } catch (e) {
        console.error('Error fetching stream', e);
      }
    };

    fetchStream();
    const interval = setInterval(fetchStream, 600);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, []);

  const advanceClosedLoopStage = () => {
    const sequence = ['SENSE', 'MEASURE', 'ANALYSE', 'MODEL', 'OPTIMISE', 'SIMULATE', 'APPROVE', 'EXECUTE'];
    const currentIdx = sequence.indexOf(closedLoopStage);
    const nextIdx = (currentIdx + 1) % sequence.length;
    const nextStage = sequence[nextIdx];
    setClosedLoopStage(nextStage);

    const newEvent: ClosedLoopEvent = {
      id: `EVT-${Date.now()}`,
      timestamp: new Date().toISOString().substring(11, 23),
      phase: nextStage as any,
      source: nextStage === 'ANALYSE' || nextStage === 'MODEL' ? 'R_ANALYTICS' : nextStage === 'SIMULATE' || nextStage === 'EXECUTE' ? 'PYTHON_ROBOTICS_OS' : 'RUST_DATACORE',
      title: `Phase Step: ${nextStage}`,
      details: `Advanced automated closed-loop optimization cycle to ${nextStage}.`
    };

    setEvents((prev) => [newEvent, ...prev.slice(0, 14)]);
  };

  const handleApproveProposal = () => {
    setIsApproved(true);
    setClosedLoopStage('EXECUTE');
    const newEvent: ClosedLoopEvent = {
      id: `EVT-${Date.now()}`,
      timestamp: new Date().toISOString().substring(11, 23),
      phase: 'EXECUTE',
      source: 'PYTHON_ROBOTICS_OS',
      title: 'Human Approval Granted • Deploying Trajectory',
      details: 'Safety constraints validated. S-curve kinematics deployed to physical robot controllers.'
    };
    setEvents((prev) => [newEvent, ...prev.slice(0, 14)]);
  };

  return (
    <div className="min-h-screen bg-[#050608] text-slate-300 flex flex-col font-sans selection:bg-orange-500 selection:text-black">
      {/* Top Header */}
      <Header
        kpis={kpis}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        ingestionCount={ingestionCount}
        closedLoopStage={closedLoopStage}
      />

      {/* Main Workspace View with Subtle Tech Dot Grid */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 bg-grid-dots">
        {activeTab === 'factory' && (
          <DigitalTwinFactory
            robots={robots}
            workcells={workcells}
            onSelectRobot={setSelectedRobot}
            primaryBottleneck={primaryBottleneck}
          />
        )}

        {activeTab === 'trajectory' && <TrajectoryOptimizerView />}

        {activeTab === 'spc' && <SpcQualityView />}

        {activeTab === 'maintenance' && (
          <PredictiveMaintenanceView robots={robots} onSelectRobot={setSelectedRobot} />
        )}

        {activeTab === 'scheduler' && (
          <FactorySchedulerView
            workcells={workcells}
            robots={robots}
            onTriggerClosedLoop={() => {
              setActiveTab('closed_loop');
              setClosedLoopStage('OPTIMISE');
            }}
          />
        )}

        {activeTab === 'closed_loop' && (
          <ClosedLoopConsole
            currentStage={closedLoopStage}
            onAdvanceStage={advanceClosedLoopStage}
            onApproveProposal={handleApproveProposal}
            events={events}
            isApproved={isApproved}
          />
        )}

        {activeTab === 'code' && <CodeExplorerView />}

        {activeTab === 'benchmarks' && <BenchmarkingView />}
      </main>

      {/* Immersive UI Footer */}
      <footer className="bg-[#0F1117] border-t border-white/5 px-4 sm:px-6 lg:px-8 py-4">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-4 items-center font-mono text-xs">
          <div className="text-[10px] text-slate-500">
            (c) 2026 ROBOTICS.OS FRAMEWORK // DETERMINISTIC PRODUCTION RUNTIME
          </div>
          <div className="md:col-span-2 flex flex-wrap justify-center gap-6 text-[10px] uppercase font-bold text-slate-400">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 rounded-full bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.6)]"></div>
              <span>Rust DataCore 1.81.0</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 rounded-full bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.6)]"></div>
              <span>R Analytics 4.4.1</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 rounded-full bg-yellow-500 shadow-[0_0_8px_rgba(234,179,8,0.6)]"></div>
              <span>Python Core 3.12.5</span>
            </div>
          </div>
          <div className="text-right text-[10px] text-emerald-400 font-bold">
            SECURE_NODE_ALPHA_READY
          </div>
        </div>
      </footer>

      {/* Robot Detail Telemetry Modal */}
      <RobotDetailModal robot={selectedRobot} onClose={() => setSelectedRobot(null)} />
    </div>
  );
}
