export interface JointTelemetry {
  jointId: number;
  positionRad: number;
  velocityRadS: number;
  torqueNm: number;
  motorCurrentA: number;
  tempCelsius: number;
  vibrationRms: number;
}

export interface RobotState {
  id: string;
  name: string;
  type: '6-Axis Articulated' | 'SCARA' | 'Delta Picker' | 'Cartesian Gantry' | 'Dual-Arm Cobot';
  cellId: string;
  status: 'ACTIVE' | 'OPTIMIZING' | 'IDLE' | 'MAINTENANCE_REQUIRED' | 'WARNING' | 'EMERGENCY_STOP';
  joints: JointTelemetry[];
  toolPosition: [number, number, number]; // x, y, z in mm
  toolOrientation: [number, number, number, number]; // quaternion w, x, y, z
  cycleTimeSec: number;
  targetCycleTimeSec: number;
  energyWatts: number;
  totalEnergyKwh: number;
  accumulatedCycles: number;
  healthScore: number; // 0 - 100
  wearIndex: number; // 0 - 1.0
  estimatedRulHours: number;
  anomalyScore: number; // 0 - 1.0
  activeTask: string;
  dataQualityScore: number; // 0 - 100%
}

export interface Workcell {
  id: string;
  name: string;
  type: 'Machining CNC' | 'Spot Welding' | 'Precision Assembly' | 'Laser Inspection' | 'Palletizing' | 'Surface Coating';
  robotIds: string[];
  currentOrder: string;
  queueDepth: number;
  maxQueueCapacity: number;
  throughputPph: number;
  targetThroughputPph: number;
  utilizationPct: number;
  bottleneckProbability: number;
  isBottleneck: boolean;
  defectRatePpm: number;
  status: 'OPTIMAL' | 'DEGRADED' | 'BOTTLENECK' | 'OFFLINE';
  lastCycleDuration: number;
}

export interface TrajectoryPoint {
  t: number;
  pos: [number, number, number];
  vel: [number, number, number];
  acc: [number, number, number];
  jerk: [number, number, number];
  energyJoules: number;
  jointAngles: number[];
}

export interface OptimizationCandidate {
  id: string;
  algorithm: 'Pareto Genetic (NSGA-II)' | 'Simulated Annealing' | 'Deterministic Dynamic Programming' | 'Gradient Jerk-Minimizer';
  weights: {
    throughput: number;
    cycleTime: number;
    energy: number;
    wear: number;
    downtime: number;
    quality: number;
  };
  metrics: {
    cycleTimeSec: number;
    energyKwhPerUnit: number;
    wearReductionPct: number;
    throughputGainPct: number;
    qualitySigma: number;
    compositeScore: number;
  };
  trajectoryPoints?: TrajectoryPoint[];
  constraintViolations: string[];
  isParetoOptimal: boolean;
  status: 'VALIDATED' | 'PENDING_SIMULATION' | 'APPROVED' | 'DEPLOYED';
}

export interface SpcMeasurement {
  sampleIndex: number;
  timestamp: string;
  xBar: number;
  rangeR: number;
  stdDevS: number;
  uclX: number;
  lclX: number;
  meanX: number;
  uclR: number;
  lclR: number;
  meanR: number;
  isNelsonViolation: boolean;
  violationRule?: string;
  featureName: string;
}

export interface ClosedLoopEvent {
  id: string;
  timestamp: string;
  phase: 'SENSE' | 'MEASURE' | 'ANALYSE' | 'MODEL' | 'OPTIMISE' | 'SIMULATE' | 'APPROVE' | 'EXECUTE';
  source: 'RUST_DATACORE' | 'R_ANALYTICS' | 'PYTHON_ROBOTICS_OS';
  title: string;
  details: string;
  metrics?: Record<string, number | string>;
  requiresApproval?: boolean;
  approved?: boolean;
}

export interface BenchmarkResult {
  engine: 'Rust DataCore' | 'R Analytics' | 'Python Fallback';
  task: string;
  throughputRecordsPerSec: number;
  latencyMicros: number;
  memoryMb: number;
  cpuPercent: number;
  speedupFactor: number;
}

export interface FactoryKpis {
  totalUnitsProduced: number;
  overallOee: number;
  activeFleetSize: number;
  averageCycleTime: number;
  totalEnergyConsumptionKwh: number;
  factoryBottleneckCell: string;
  fleetHealthAverage: number;
  fleetAnomalyRate: number;
  dataIngestionRateRecordsPerSec: number;
}
