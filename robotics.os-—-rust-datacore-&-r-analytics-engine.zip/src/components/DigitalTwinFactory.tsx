import React, { useState } from 'react';
import { RobotState, Workcell } from '../types';
import { AlertTriangle, CheckCircle, ShieldAlert, Cpu, Activity, Gauge, Flame, Zap, ArrowRight, CornerDownRight } from 'lucide-react';

interface DigitalTwinFactoryProps {
  robots: RobotState[];
  workcells: Workcell[];
  onSelectRobot: (robot: RobotState) => void;
  primaryBottleneck: string;
}

export const DigitalTwinFactory: React.FC<DigitalTwinFactoryProps> = ({
  robots,
  workcells,
  onSelectRobot,
  primaryBottleneck
}) => {
  const [hoveredCell, setHoveredCell] = useState<string | null>(null);

  return (
    <div className="space-y-6">
      {/* Factory Overview Banner */}
      <div className="bg-[#0F1117] border border-white/10 rounded-lg p-5 relative overflow-hidden shadow-lg">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-white uppercase tracking-wider font-mono">INDUSTRY 4.0 DIGITAL TWIN</h2>
              <span className="px-2.5 py-0.5 text-[10px] font-mono font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                SIMULATION SYNCED
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1 font-mono">
              Deterministic 6-Axis kinematics driven by Rust DataCore telemetry with closed-loop R bottleneck mitigation.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="px-3 py-2 bg-black/40 border border-red-500/30 rounded text-xs font-mono">
              <div className="text-[9px] text-slate-500 uppercase flex items-center gap-1">
                <AlertTriangle className="w-3 h-3 text-red-400" />
                PRIMARY BOTTLENECK
              </div>
              <div className="text-red-400 font-bold">{primaryBottleneck}</div>
            </div>

            <div className="px-3 py-2 bg-black/40 border border-white/10 rounded text-xs font-mono">
              <div className="text-[9px] text-slate-500 uppercase">ACTIVE FLEET</div>
              <div className="text-white font-bold">{robots.length} Industrial Units</div>
            </div>
          </div>
        </div>
      </div>

      {/* Interactive Plant Floor Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {workcells.map((cell, idx) => {
          const robot = robots.find((r) => cell.robotIds.includes(r.id)) || robots[idx % robots.length];
          const isBottleneck = cell.isBottleneck;
          const isWarning = robot?.status === 'WARNING';

          return (
            <div
              key={cell.id}
              id={`workcell-card-${cell.id}`}
              onMouseEnter={() => setHoveredCell(cell.id)}
              onMouseLeave={() => setHoveredCell(null)}
              onClick={() => robot && onSelectRobot(robot)}
              className={`cursor-pointer transition-all duration-200 rounded-lg p-4 border bg-[#0F1117] hover:shadow-2xl relative overflow-hidden group ${
                isBottleneck
                  ? 'border-red-500/40 ring-1 ring-red-500/20'
                  : isWarning
                  ? 'border-orange-500/40 ring-1 ring-orange-500/20'
                  : 'border-white/5 hover:border-orange-500/40'
              }`}
            >
              {/* Top Accent Line */}
              <div className={`absolute top-0 left-0 right-0 h-0.5 ${
                isBottleneck ? 'bg-red-500' : isWarning ? 'bg-orange-500' : 'bg-white/10 group-hover:bg-orange-500'
              }`} />

              {/* Header */}
              <div className="flex items-center justify-between mb-3 mt-1">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-black/40 text-slate-300 border border-white/10">
                    {cell.id}
                  </span>
                  <span className="text-xs font-bold text-white font-mono truncate max-w-[130px]">{cell.name}</span>
                </div>
                {isBottleneck ? (
                  <span className="text-[9px] font-mono font-bold px-2 py-0.5 bg-red-500/10 text-red-400 border border-red-500/30 rounded animate-pulse">
                    BOTTLENECK
                  </span>
                ) : isWarning ? (
                  <span className="text-[9px] font-mono font-bold px-2 py-0.5 bg-orange-500/10 text-orange-400 border border-orange-500/30 rounded">
                    WARNING
                  </span>
                ) : (
                  <span className="text-[9px] font-mono font-bold px-2 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded">
                    ONLINE
                  </span>
                )}
              </div>

              {/* Robot Kinematics Visualizer Box */}
              <div className="bg-black/40 border border-white/10 rounded p-3 mb-3 relative">
                <div className="flex items-center justify-between text-[10px] text-slate-400 mb-2 font-mono">
                  <span className="text-orange-400 font-bold">{robot?.name}</span>
                  <span className="text-slate-500">{robot?.type}</span>
                </div>

                {/* Animated Kinematics Arm Simulation */}
                <div className="h-24 w-full flex items-center justify-center relative overflow-hidden bg-[#050608]/80 rounded border border-white/5">
                  <svg className="w-full h-full" viewBox="0 0 200 90">
                    {/* Grid floor */}
                    <line x1="20" y1="75" x2="180" y2="75" stroke="#334155" strokeWidth="0.8" strokeDasharray="3 3" opacity="0.6" />
                    {/* Base */}
                    <rect x="90" y="70" width="20" height="8" rx="1" fill="#334155" />
                    {/* Joint 0 & Link 1 */}
                    <circle cx="100" cy="70" r="3.5" fill="#f97316" />
                    {/* Kinematic calculation based on robot telemetry */}
                    {(() => {
                      const j0 = robot?.joints[0]?.positionRad || 0;
                      const j1 = robot?.joints[1]?.positionRad || 0.5;
                      const j2 = robot?.joints[2]?.positionRad || -0.4;
                      const p1x = 100 + Math.sin(j0) * 22;
                      const p1y = 70 - Math.cos(j0) * 22;
                      const p2x = p1x + Math.sin(j0 + j1) * 24;
                      const p2y = p1y - Math.cos(j0 + j1) * 24;
                      const p3x = p2x + Math.sin(j0 + j1 + j2) * 18;
                      const p3y = p2y - Math.cos(j0 + j1 + j2) * 18;

                      return (
                        <g>
                          <line x1="100" y1="70" x2={p1x} y2={p1y} stroke="#f97316" strokeWidth="3.5" strokeLinecap="round" />
                          <circle cx={p1x} cy={p1y} r="3" fill="#fb923c" />
                          <line x1={p1x} y1={p1y} x2={p2x} y2={p2y} stroke="#3b82f6" strokeWidth="3" strokeLinecap="round" />
                          <circle cx={p2x} cy={p2y} r="2.5" fill="#60a5fa" />
                          <line x1={p2x} y1={p2y} x2={p3x} y2={p3y} stroke="#10b981" strokeWidth="2.5" strokeLinecap="round" />
                          {/* End effector / Tool */}
                          <circle cx={p3x} cy={p3y} r="2.5" fill="#ef4444" />
                          <circle cx={p3x} cy={p3y} r="5" stroke="#ef4444" strokeWidth="0.8" fill="none" opacity="0.6" />
                        </g>
                      );
                    })()}
                  </svg>
                  <div className="absolute bottom-1 right-2 text-[9px] font-mono text-slate-500">
                    TCP: [{robot?.toolPosition[0].toFixed(0)}, {robot?.toolPosition[1].toFixed(0)}, {robot?.toolPosition[2].toFixed(0)}]
                  </div>
                </div>
              </div>

              {/* Workcell Performance Metrics */}
              <div className="space-y-2 text-xs">
                {/* Utilization progress */}
                <div>
                  <div className="flex justify-between text-[10px] text-slate-500 uppercase font-mono mb-1">
                    <span>Station Utilization</span>
                    <span className={`font-bold ${cell.utilizationPct > 90 ? 'text-red-400' : 'text-emerald-400'}`}>
                      {cell.utilizationPct.toFixed(1)}%
                    </span>
                  </div>
                  <div className="w-full h-1.5 bg-black/50 rounded overflow-hidden">
                    <div
                      className={`h-full rounded transition-all duration-300 ${
                        cell.utilizationPct > 90 ? 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.6)]' : cell.utilizationPct > 80 ? 'bg-orange-500' : 'bg-emerald-500'
                      }`}
                      style={{ width: `${Math.min(100, cell.utilizationPct)}%` }}
                    ></div>
                  </div>
                </div>

                {/* Queue depth buffer */}
                <div className="flex items-center justify-between text-[10px] font-mono">
                  <span className="text-slate-500 uppercase">Queue Buffer:</span>
                  <span className="text-white">
                    {cell.queueDepth} / {cell.maxQueueCapacity} units
                  </span>
                </div>

                {/* Cycle Time & Power */}
                <div className="grid grid-cols-2 gap-2 pt-1 border-t border-white/5 text-[10px] font-mono">
                  <div>
                    <span className="text-slate-500 uppercase">Cycle Time:</span>
                    <div className="text-white font-bold">{cell.lastCycleDuration}s</div>
                  </div>
                  <div>
                    <span className="text-slate-500 uppercase">Power:</span>
                    <div className="text-orange-400 font-bold">{robot?.energyWatts.toFixed(0)} W</div>
                  </div>
                </div>

                {/* Health & Vibration indicator */}
                <div className="flex items-center justify-between pt-1 text-[10px] font-mono">
                  <div className="flex items-center gap-1">
                    <Activity className="w-3 h-3 text-blue-400" />
                    <span className="text-slate-300">Health: <strong className="text-emerald-400">{robot?.healthScore.toFixed(0)}%</strong></span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Flame className="w-3 h-3 text-orange-400" />
                    <span className="text-slate-300">{robot?.joints[0]?.tempCelsius.toFixed(1)}°C</span>
                  </div>
                </div>
              </div>

              {/* View detail hover hint */}
              <div className="mt-3 pt-2 border-t border-white/5 text-[10px] font-mono text-orange-400 flex items-center justify-end gap-1 opacity-70 group-hover:opacity-100 transition">
                <span>INSPECT TELEMETRY</span>
                <ArrowRight className="w-3 h-3" />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

