import React from 'react';
import { RobotState } from '../types';
import { X, Activity, Cpu, ShieldCheck, Flame, Gauge, Zap, AlertCircle } from 'lucide-react';

interface RobotDetailModalProps {
  robot: RobotState | null;
  onClose: () => void;
}

export const RobotDetailModal: React.FC<RobotDetailModalProps> = ({ robot, onClose }) => {
  if (!robot) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="bg-[#0F1117] border border-white/10 rounded-lg max-w-3xl w-full p-6 shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-orange-500/10 text-orange-400 border border-orange-500/30">
                {robot.id}
              </span>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">{robot.name}</h3>
              <span className="text-[10px] px-2 py-0.5 rounded bg-white/5 text-slate-300 border border-white/10 font-mono">
                {robot.type}
              </span>
            </div>
            <p className="text-[11px] text-slate-500 font-mono mt-1">
              Workcell: <strong className="text-white">{robot.cellId}</strong> • Task: {robot.activeTask}
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded bg-black/40 hover:bg-white/10 border border-white/10 text-slate-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Top Summary Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
          <div className="p-3 bg-black/40 rounded border border-white/5 shadow-sm">
            <div className="text-slate-500 text-[10px] uppercase">HEALTH SCORE</div>
            <div className="text-xl font-bold text-emerald-400 mt-0.5">{robot.healthScore.toFixed(1)}%</div>
          </div>

          <div className="p-3 bg-black/40 rounded border border-white/5 shadow-sm">
            <div className="text-slate-500 text-[10px] uppercase">ESTIMATED RUL</div>
            <div className="text-xl font-bold text-blue-400 mt-0.5">{robot.estimatedRulHours} hrs</div>
          </div>

          <div className="p-3 bg-black/40 rounded border border-white/5 shadow-sm">
            <div className="text-slate-500 text-[10px] uppercase">POWER DRAW</div>
            <div className="text-xl font-bold text-orange-400 mt-0.5">{robot.energyWatts.toFixed(0)} W</div>
          </div>

          <div className="p-3 bg-black/40 rounded border border-white/5 shadow-sm">
            <div className="text-slate-500 text-[10px] uppercase">DATA QUALITY</div>
            <div className="text-xl font-bold text-emerald-400 mt-0.5">{robot.dataQualityScore}%</div>
          </div>
        </div>

        {/* 6-Axis Joint Telemetry Table */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="font-bold text-white uppercase tracking-wider text-[11px] flex items-center gap-1.5">
              <Cpu className="w-4 h-4 text-orange-500" />
              STRONGLY TYPED JOINT TELEMETRY (RUST STRUCT)
            </span>
            <span className="text-slate-500 text-[10px]">Stream: 250 kHz Native</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-white/10 text-slate-500 text-[10px] uppercase">
                  <th className="pb-1.5">JOINT</th>
                  <th className="pb-1.5">POSITION (RAD)</th>
                  <th className="pb-1.5">VELOCITY (RAD/S)</th>
                  <th className="pb-1.5">TORQUE (NM)</th>
                  <th className="pb-1.5">CURRENT (A)</th>
                  <th className="pb-1.5">TEMP (°C)</th>
                  <th className="pb-1.5">VIBRATION (G)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-slate-300">
                {robot.joints.map((j) => (
                  <tr key={j.jointId} className="hover:bg-white/5 transition">
                    <td className="py-2 text-orange-400 font-bold">J{j.jointId + 1}</td>
                    <td className="py-2">{j.positionRad.toFixed(3)}</td>
                    <td className="py-2">{j.velocityRadS.toFixed(3)}</td>
                    <td className="py-2 text-orange-300">{j.torqueNm.toFixed(1)}</td>
                    <td className="py-2">{j.motorCurrentA.toFixed(1)}</td>
                    <td className="py-2 text-white">{j.tempCelsius.toFixed(1)}</td>
                    <td className="py-2 text-red-400">{j.vibrationRms.toFixed(3)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* End-Effector TCP Pose & Tool Orientation */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
          <div className="p-3.5 bg-black/40 rounded border border-white/5 space-y-1.5">
            <div className="text-slate-500 text-[10px] uppercase">TOOL CENTER POINT (TCP) POSITION</div>
            <div className="flex gap-4 text-white">
              <span>X: <strong className="text-orange-400">{robot.toolPosition[0].toFixed(1)}</strong> mm</span>
              <span>Y: <strong className="text-orange-400">{robot.toolPosition[1].toFixed(1)}</strong> mm</span>
              <span>Z: <strong className="text-orange-400">{robot.toolPosition[2].toFixed(1)}</strong> mm</span>
            </div>
          </div>

          <div className="p-3.5 bg-black/40 rounded border border-white/5 space-y-1.5">
            <div className="text-slate-500 text-[10px] uppercase">QUATERNION ORIENTATION (W, X, Y, Z)</div>
            <div className="flex gap-3 text-white">
              <span>W: <strong className="text-blue-400">{robot.toolOrientation[0]}</strong></span>
              <span>X: <strong className="text-blue-400">{robot.toolOrientation[1]}</strong></span>
              <span>Y: <strong className="text-blue-400">{robot.toolOrientation[2]}</strong></span>
              <span>Z: <strong className="text-blue-400">{robot.toolOrientation[3]}</strong></span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-white/10 hover:bg-white/15 text-white rounded text-xs font-mono transition cursor-pointer tracking-wider uppercase"
          >
            Close Telemetry Stream
          </button>
        </div>
      </div>
    </div>
  );
};
