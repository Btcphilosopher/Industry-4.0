import React from 'react';
import { Cpu, Activity, BarChart3, Radio, RefreshCw, Zap, ShieldCheck, AlertTriangle } from 'lucide-react';
import { FactoryKpis } from '../types';

interface HeaderProps {
  kpis: FactoryKpis;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  ingestionCount: number;
  closedLoopStage: string;
}

export const Header: React.FC<HeaderProps> = ({
  kpis,
  activeTab,
  setActiveTab,
  ingestionCount,
  closedLoopStage
}) => {
  const tabs = [
    { id: 'factory', label: 'Digital Twin Plant', icon: Activity, tag: 'PYTHON' },
    { id: 'trajectory', label: 'Rust Trajectory & Pareto', icon: Zap, tag: 'RUST' },
    { id: 'spc', label: 'R Analytics & SPC', icon: BarChart3, tag: 'R' },
    { id: 'maintenance', label: 'Predictive Health & RUL', icon: ShieldCheck, tag: 'R' },
    { id: 'scheduler', label: 'Factory Scheduler', icon: RefreshCw, tag: 'RUST' },
    { id: 'closed_loop', label: 'Closed-Loop Engine', icon: Radio, tag: '8-STAGE' },
    { id: 'code', label: 'Architecture & Code', icon: Cpu, tag: 'SRC' },
    { id: 'benchmarks', label: 'Rust/R Benchmarks', icon: Activity, tag: 'PERF' }
  ];

  return (
    <header className="bg-[#0F1117] border-b border-white/10 text-slate-300 sticky top-0 z-40">
      {/* Top tier brand and architecture indicator */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center space-x-4">
            <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-red-600 rounded flex items-center justify-center font-bold text-white text-xl shadow-[0_0_15px_rgba(249,115,22,0.4)]">
              R
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-bold tracking-tight text-white leading-none uppercase">Robotics.OS</h1>
                <span className="px-2 py-0.5 text-[10px] font-mono font-bold bg-orange-500/10 text-orange-400 border border-orange-500/30 rounded">
                  v4.2 // DETERMINISTIC
                </span>
              </div>
              <p className="text-[10px] text-orange-500 font-mono tracking-[0.2em] mt-1">
                RUST + R OPTIMISATION ENGINE
              </p>
            </div>
          </div>

          {/* Tri-Language Real-time Status Pills */}
          <div className="hidden lg:flex items-center gap-3">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-black/40 border border-orange-500/30 rounded text-xs font-mono">
              <span className="w-2 h-2 rounded-full bg-orange-500 animate-pulse"></span>
              <div>
                <div className="text-[9px] text-slate-500 uppercase">Rust DataCore</div>
                <div className="text-orange-400 font-bold">250 kHz // P99 420μs</div>
              </div>
            </div>

            <div className="flex items-center gap-2 px-3 py-1.5 bg-black/40 border border-blue-500/30 rounded text-xs font-mono">
              <span className="w-2 h-2 rounded-full bg-blue-500"></span>
              <div>
                <div className="text-[9px] text-slate-500 uppercase">R Analytics</div>
                <div className="text-blue-400 font-bold">Arrow IPC // SPC</div>
              </div>
            </div>

            <div className="flex items-center gap-2 px-3 py-1.5 bg-black/40 border border-emerald-500/30 rounded text-xs font-mono">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              <div>
                <div className="text-[9px] text-slate-500 uppercase">Python Twin</div>
                <div className="text-emerald-400 font-bold">Simulation Synced</div>
              </div>
            </div>
          </div>

          {/* System metadata in header */}
          <div className="flex space-x-6 text-right font-mono">
            <div>
              <p className="text-[10px] uppercase text-slate-500 mb-0.5">System State</p>
              <p className="text-xs font-mono text-emerald-400 font-bold">NOMINAL / DETERMINISTIC</p>
            </div>
            <div className="hidden sm:block">
              <p className="text-[10px] uppercase text-slate-500 mb-0.5">Telemetry Ingest</p>
              <p className="text-xs font-mono text-white font-bold">{ingestionCount.toLocaleString()} <span className="text-slate-500 text-[10px]">rec</span></p>
            </div>
            <div>
              <p className="text-[10px] uppercase text-slate-500 mb-0.5">Environment</p>
              <p className="text-xs font-mono text-white font-bold">FACTORY ALPHA-9</p>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation tabs */}
      <div className="bg-[#050608]/80 border-t border-white/5 px-4 sm:px-6 lg:px-8">
        <nav className="flex space-x-2 overflow-x-auto py-2 scrollbar-none">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                id={`tab-${tab.id}`}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-3.5 py-1.5 text-xs font-mono rounded transition-all duration-150 whitespace-nowrap ${
                  isActive
                    ? 'bg-orange-500/10 border border-orange-500/40 text-orange-400 shadow-[0_0_12px_rgba(249,115,22,0.25)] font-bold'
                    : 'text-slate-400 border border-transparent hover:text-white hover:bg-white/5 hover:border-white/10'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-orange-400' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
                <span className={`text-[9px] px-1.5 py-0.2 rounded ${
                  isActive ? 'bg-orange-500/20 text-orange-300' : 'bg-white/5 text-slate-500'
                }`}>
                  {tab.tag}
                </span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};

