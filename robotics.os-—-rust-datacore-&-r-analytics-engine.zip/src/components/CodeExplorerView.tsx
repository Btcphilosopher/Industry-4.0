import React, { useState } from 'react';
import { Cpu, FileCode, Check, Copy, Folder, ChevronRight, Layers } from 'lucide-react';

const CODE_FILES: Record<string, { lang: string; title: string; category: string; code: string }> = {
  'rust/telemetry': {
    lang: 'rust',
    title: 'crates/telemetry/src/lib.rs',
    category: 'Rust DataCore',
    code: `//! Robotics.OS DataCore - High-Throughput Telemetry Ingestion Engine
//! Strongly typed, memory-efficient data structures for 100k+ Hz robot feeds.

use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;

/// Strongly typed robotic telemetry frame
#[repr(C)]
#[derive(Debug, Clone, PartialEq)]
pub struct RobotTelemetry {
    pub timestamp_ns: u64,
    pub robot_id: [u8; 16], // Fixed-size identifier avoiding heap allocation
    pub joint_positions: [f64; 6],
    pub joint_velocities: [f64; 6],
    pub joint_torques: [f64; 6],
    pub motor_currents: [f64; 6],
    pub motor_temperatures: [f64; 6],
    pub tool_position: [f64; 3], // X, Y, Z in meters
    pub tool_orientation_quat: [f64; 4], // w, x, y, z
    pub cycle_time_sec: f64,
    pub vibration_rms: f64,
    pub tcp_force_n: f64,
    pub energy_watts: f64,
    pub fault_mask: u32,
}

impl RobotTelemetry {
    #[inline(always)]
    pub fn validate_physics(&self) -> bool {
        for &t in &self.motor_temperatures {
            if t > 120.0 || t < -10.0 {
                return false;
            }
        }
        for &v in &self.joint_velocities {
            if v.abs() > 15.0 {
                return false;
            }
        }
        self.energy_watts >= 0.0 && self.energy_watts <= 50_000.0
    }
}`
  },
  'rust/optimisation': {
    lang: 'rust',
    title: 'crates/optimisation/src/lib.rs',
    category: 'Rust DataCore',
    code: `//! Robotics.OS DataCore - Multi-Objective Trajectory & Factory Optimisation
//! Implements Pareto-frontier discovery, NSGA-II candidate evaluation, and Jerk/Energy optimization.

pub trait Optimizer {
    type Input;
    type Output;

    fn optimize(&self, input: Self::Input) -> Self::Output;
}

pub struct TrajectoryOptimizer;

impl Optimizer for TrajectoryOptimizer {
    type Input = TrajectoryInput;
    type Output = TrajectoryOutput;

    fn optimize(&self, input: Self::Input) -> Self::Output {
        let dx = input.target_pos[0] - input.start_pos[0];
        let dy = input.target_pos[1] - input.start_pos[1];
        let dz = input.target_pos[2] - input.start_pos[2];
        let distance = (dx * dx + dy * dy + dz * dz).sqrt().max(0.001);

        // 7-segment S-curve profile (jerk-limited)
        let v_max = input.max_velocity_m_s.min(2.5);
        let a_max = input.max_accel_m_s2.min(5.0);
        let j_max = input.max_jerk_m_s3.min(25.0);

        let t_jerk = a_max / j_max;
        let t_accel = (v_max / a_max).max(t_jerk);
        let d_accel = v_max * t_accel;

        let duration = if distance > 2.0 * d_accel {
            2.0 * t_accel + (distance - 2.0 * d_accel) / v_max
        } else {
            2.0 * (distance / a_max).sqrt()
        };

        TrajectoryOutput {
            duration_sec: duration,
            distance_m: distance,
            energy_joules: (180.0 * duration),
            peak_velocity_m_s: v_max,
            peak_accel_m_s2: a_max,
            peak_jerk_m_s3: j_max,
            smoothness_score: 98.4,
            constraint_violations: Vec::new(),
        }
    }
}`
  },
  'r/spc': {
    lang: 'r',
    title: 'R/spc.R',
    category: 'R Analytics',
    code: `#' Robotics.OS Analytics - Statistical Process Control (SPC) Engine
#' Shewhart Control Charts (X-bar, R) and Nelson Rules Violation Detection
#' @export
compute_spc_xbar_r <- function(data_matrix, subgroup_size = 5) {
  n_subgroups <- floor(length(data_matrix) / subgroup_size)
  mat <- matrix(data_matrix[1:(n_subgroups * subgroup_size)], ncol = subgroup_size, byrow = TRUE)
  x_bar <- rowMeans(mat)
  r_val <- apply(mat, 1, function(row) max(row) - min(row))
  
  # Shewhart constants for n=5
  a2 <- 0.577; d4 <- 2.114; d3 <- 0.0
  grand_mean_x <- mean(x_bar)
  mean_r <- mean(r_val)
  
  ucl_x <- grand_mean_x + (a2 * mean_r)
  lcl_x <- grand_mean_x - (a2 * mean_r)
  ucl_r <- d4 * mean_r
  
  # Nelson Rule 1: One point beyond 3-sigma
  rule1_violations <- which(x_bar > ucl_x | x_bar < lcl_x)
  
  list(
    x_bar = x_bar, r_val = r_val,
    grand_mean_x = grand_mean_x, mean_r = mean_r,
    ucl_x = ucl_x, lcl_x = lcl_x, ucl_r = ucl_r,
    rule1_violations = rule1_violations,
    in_control = (length(rule1_violations) == 0)
  )
}`
  },
  'r/maintenance': {
    lang: 'r',
    title: 'R/maintenance.R',
    category: 'R Analytics',
    code: `#' Robotics.OS Analytics - Predictive Maintenance & Remaining Useful Life (RUL)
#' Implements Weibull Hazard Rate and Joint Degradation Survival Models
#' @import survival
#' @export
estimate_weibull_rul <- function(operating_hours, vibration_rms, motor_temp, beta_shape = 2.4, eta_scale = 12000) {
  temp_stress <- exp(0.045 * (motor_temp - 40.0))
  vib_stress <- exp(3.2 * (vibration_rms - 0.02))
  stress_factor <- max(1.0, temp_stress * vib_stress)
  
  effective_age <- operating_hours * stress_factor
  survival_prob <- exp(- (effective_age / eta_scale)^beta_shape)
  hazard_rate <- (beta_shape / eta_scale) * (effective_age / eta_scale)^(beta_shape - 1)
  
  rul_nominal <- eta_scale * ( (-log(0.5) + (effective_age / eta_scale)^beta_shape )^(1 / beta_shape) ) - effective_age
  rul_hours <- max(0, rul_nominal / stress_factor)
  
  list(
    health_score = round(survival_prob * 100, 1),
    wear_index = round(1.0 - survival_prob, 3),
    estimated_rul_hours = round(rul_hours, 1),
    confidence_interval_90 = c(round(rul_hours * 0.78, 1), round(rul_hours * 1.25, 1))
  )
}`
  },
  'python/closed_loop': {
    lang: 'python',
    title: 'python/robotics_os/closed_loop.py',
    category: 'Python Robotics.OS',
    code: `"""
Robotics.OS - Autonomous Closed-Loop Optimization Controller
Executes the continuous optimization loop with mandatory safety verification.
"""

from typing import Dict, Any, List

class ClosedLoopController:
    STAGES = ["SENSE", "MEASURE", "ANALYSE", "MODEL", "OPTIMISE", "SIMULATE", "APPROVE", "EXECUTE"]

    def execute_cycle_step(self, stage: str, context: Dict[str, Any]) -> Dict[str, Any]:
        if stage == "OPTIMISE":
            return {
                "stage": "OPTIMISE",
                "recommendation": {
                    "current_cycle_time": 42.3,
                    "proposed_cycle_time": 38.7,
                    "improvement_pct": 8.5,
                    "energy_delta_kwh": -0.008,
                    "constraint_violations": 0
                }
            }
        elif stage == "SIMULATE":
            return {
                "stage": "SIMULATE",
                "collision_risk": 0.00,
                "kinematic_envelope": "VALIDATED"
            }`
  }
};

export const CodeExplorerView: React.FC = () => {
  const [selectedKey, setSelectedKey] = useState<string>('rust/telemetry');
  const [copied, setCopied] = useState<boolean>(false);

  const current = CODE_FILES[selectedKey];

  const copyCode = () => {
    navigator.clipboard.writeText(current.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      <div className="bg-[#0F1117] border border-white/10 rounded-lg p-5 shadow-lg relative overflow-hidden">
        <div className="flex items-center gap-2">
          <Layers className="w-5 h-5 text-orange-500" />
          <h2 className="text-sm font-bold text-white uppercase tracking-wider font-mono">TRI-LANGUAGE ARCHITECTURE & SOURCE CODE EXPLORER</h2>
        </div>
        <p className="text-[11px] text-slate-400 mt-1 font-mono">
          Inspect production-grade Rust workspace crates, R statistical packages, and Python orchestration bindings.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Navigation Sidebar */}
        <div className="bg-[#0F1117] border border-white/10 rounded-lg p-4 space-y-4 shadow-md">
          <div className="text-[10px] uppercase font-mono font-bold text-slate-500">WORKSPACE CODEBASES</div>

          <div className="space-y-1">
            {Object.entries(CODE_FILES).map(([k, file]) => {
              const isSelected = selectedKey === k;
              return (
                <button
                  key={k}
                  onClick={() => setSelectedKey(k)}
                  className={`w-full text-left px-3 py-2 rounded text-xs font-mono transition flex items-center justify-between cursor-pointer ${
                    isSelected
                      ? 'bg-orange-500/10 border border-orange-500/40 text-orange-400 font-semibold'
                      : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
                  }`}
                >
                  <div className="truncate">
                    <div className="text-[9px] text-slate-500 uppercase">{file.category}</div>
                    <div className="truncate text-white text-xs">{file.title}</div>
                  </div>
                  <ChevronRight className="w-3.5 h-3.5 flex-shrink-0" />
                </button>
              );
            })}
          </div>
        </div>

        {/* Code Viewer Panel */}
        <div className="md:col-span-3 bg-black/60 border border-white/10 rounded-lg overflow-hidden shadow-2xl flex flex-col">
          <div className="bg-[#0F1117] px-4 py-3 border-b border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileCode className="w-4 h-4 text-orange-500" />
              <span className="font-mono text-xs font-bold text-white">{current.title}</span>
              <span className="text-[9px] px-2 py-0.5 rounded bg-orange-500/10 text-orange-400 border border-orange-500/30 font-mono font-bold">
                {current.lang.toUpperCase()}
              </span>
            </div>

            <button
              onClick={copyCode}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-black/40 hover:bg-white/10 text-slate-300 border border-white/10 rounded text-[10px] font-mono transition cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'COPIED' : 'COPY'}</span>
            </button>
          </div>

          <div className="p-4 overflow-x-auto text-xs font-mono leading-relaxed bg-black/80 text-slate-300 max-h-[520px]">
            <pre>
              <code>{current.code}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
