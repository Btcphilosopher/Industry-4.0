import React, { useState, useEffect } from 'react';
import { OptimizationCandidate, TrajectoryPoint } from '../types';
import { Zap, Play, CheckCircle2, Sliders, Shield, AlertCircle, ArrowUpRight, Cpu } from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ScatterChart,
  Scatter,
  ZAxis
} from 'recharts';

export const TrajectoryOptimizerView: React.FC = () => {
  const [startPos, setStartPos] = useState<[number, number, number]>([200, 100, 300]);
  const [targetPos, setTargetPos] = useState<[number, number, number]>([650, 420, 580]);
  const [maxVel, setMaxVel] = useState<number>(2.0);
  const [maxAcc, setMaxAcc] = useState<number>(4.5);
  const [maxJerk, setMaxJerk] = useState<number>(20.0);
  const [payloadKg, setPayloadKg] = useState<number>(8.5);

  const [weights, setWeights] = useState({
    time: 0.35,
    energy: 0.25,
    wear: 0.25,
    smoothness: 0.15
  });

  const [optimizing, setOptimizing] = useState<boolean>(false);
  const [trajectoryResult, setTrajectoryResult] = useState<{
    durationSec: number;
    distanceMeters: number;
    energyKwh: number;
    smoothnessScore: number;
    trajectoryPoints: TrajectoryPoint[];
    paretoCandidates: OptimizationCandidate[];
    selectedCandidate: OptimizationCandidate;
  } | null>(null);

  const runOptimization = async () => {
    setOptimizing(true);
    try {
      const res = await fetch('/api/optimise/trajectory', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          startPos,
          targetPos,
          maxVel,
          maxAcc,
          maxJerk,
          payloadKg,
          weights
        })
      });
      const data = await res.json();
      setTrajectoryResult(data);
    } catch (e) {
      console.error('Optimisation call failed', e);
    } finally {
      setOptimizing(false);
    }
  };

  useEffect(() => {
    runOptimization();
  }, []);

  return (
    <div className="space-y-6">
      {/* Title & Engine Meta */}
      <div className="bg-[#0F1117] border border-white/10 rounded-lg p-5 shadow-lg relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-orange-500" />
              <h2 className="text-sm font-bold text-white uppercase tracking-wider font-mono">RUST DATACORE TRAJECTORY & PARETO OPTIMIZER</h2>
              <span className="px-2 py-0.5 text-[10px] bg-orange-500/10 text-orange-400 border border-orange-500/30 rounded font-mono font-bold">
                Trait Optimizer&lt;TrajectoryInput&gt;
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1 font-mono">
              Deterministic 7-segment S-curve profile generation with NSGA-II multi-objective tradeoff evaluation.
            </p>
          </div>

          <button
            id="run-rust-optimizer-btn"
            onClick={runOptimization}
            disabled={optimizing}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-400 hover:to-red-500 text-white font-mono font-bold rounded text-xs transition shadow-[0_0_15px_rgba(249,115,22,0.3)] disabled:opacity-50 cursor-pointer"
          >
            {optimizing ? (
              <span className="animate-spin inline-block w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full"></span>
            ) : (
              <Play className="w-3.5 h-3.5 fill-current" />
            )}
            <span>RUN RUST OPTIMIZER</span>
          </button>
        </div>
      </div>

      {/* Control Panel & Objective Weights */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Physical Kinematic Constraints */}
        <div className="bg-[#0F1117] border border-white/10 rounded-lg p-5 space-y-4 shadow-md">
          <div className="flex items-center justify-between text-xs font-bold text-white font-mono border-b border-white/10 pb-2">
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-orange-400" />
              <span>KINEMATIC & PAYLOAD LIMITS</span>
            </div>
            <span className="text-[9px] text-orange-500 font-mono">RUST KINEMATICS</span>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <div className="flex justify-between text-[10px] text-slate-500 uppercase font-mono mb-1">
                <span>Max Tool Velocity</span>
                <span className="text-orange-400 font-bold">{maxVel} m/s</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="3.5"
                step="0.1"
                value={maxVel}
                onChange={(e) => setMaxVel(parseFloat(e.target.value))}
                className="w-full accent-orange-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-[10px] text-slate-500 uppercase font-mono mb-1">
                <span>Max Acceleration</span>
                <span className="text-orange-400 font-bold">{maxAcc} m/s²</span>
              </div>
              <input
                type="range"
                min="1.0"
                max="8.0"
                step="0.5"
                value={maxAcc}
                onChange={(e) => setMaxAcc(parseFloat(e.target.value))}
                className="w-full accent-orange-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-[10px] text-slate-500 uppercase font-mono mb-1">
                <span>Max Jerk (Jerk-Limiter)</span>
                <span className="text-orange-400 font-bold">{maxJerk} m/s³</span>
              </div>
              <input
                type="range"
                min="5.0"
                max="40.0"
                step="1.0"
                value={maxJerk}
                onChange={(e) => setMaxJerk(parseFloat(e.target.value))}
                className="w-full accent-orange-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-[10px] text-slate-500 uppercase font-mono mb-1">
                <span>Payload Mass</span>
                <span className="text-orange-400 font-bold">{payloadKg} kg</span>
              </div>
              <input
                type="range"
                min="1.0"
                max="25.0"
                step="0.5"
                value={payloadKg}
                onChange={(e) => setPayloadKg(parseFloat(e.target.value))}
                className="w-full accent-orange-500 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Multi-Objective Pareto Weights */}
        <div className="bg-[#0F1117] border border-white/10 rounded-lg p-5 space-y-4 shadow-md">
          <div className="flex items-center justify-between text-xs font-bold text-white font-mono border-b border-white/10 pb-2">
            <div className="flex items-center gap-2">
              <Sliders className="w-4 h-4 text-blue-400" />
              <span>PARETO OBJECTIVE WEIGHTS</span>
            </div>
            <span className="text-[9px] text-blue-400 font-mono">NSGA-II</span>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <div className="flex justify-between text-[10px] text-slate-500 uppercase font-mono mb-1">
                <span>w1: Minimum Cycle Time</span>
                <span className="text-blue-400 font-bold">{weights.time.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0.0"
                max="1.0"
                step="0.05"
                value={weights.time}
                onChange={(e) => setWeights({ ...weights, time: parseFloat(e.target.value) })}
                className="w-full accent-blue-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-[10px] text-slate-500 uppercase font-mono mb-1">
                <span>w2: Minimum Energy (kWh)</span>
                <span className="text-blue-400 font-bold">{weights.energy.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0.0"
                max="1.0"
                step="0.05"
                value={weights.energy}
                onChange={(e) => setWeights({ ...weights, energy: parseFloat(e.target.value) })}
                className="w-full accent-blue-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-[10px] text-slate-500 uppercase font-mono mb-1">
                <span>w3: Wear Reduction</span>
                <span className="text-blue-400 font-bold">{weights.wear.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0.0"
                max="1.0"
                step="0.05"
                value={weights.wear}
                onChange={(e) => setWeights({ ...weights, wear: parseFloat(e.target.value) })}
                className="w-full accent-blue-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-[10px] text-slate-500 uppercase font-mono mb-1">
                <span>w4: Smoothness & Vibration</span>
                <span className="text-blue-400 font-bold">{weights.smoothness.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0.0"
                max="1.0"
                step="0.05"
                value={weights.smoothness}
                onChange={(e) => setWeights({ ...weights, smoothness: parseFloat(e.target.value) })}
                className="w-full accent-blue-500 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Optimisation Result Summary Card */}
        <div className="bg-[#0F1117] border border-white/10 rounded-lg p-5 space-y-3 shadow-md">
          <div className="flex items-center justify-between text-xs font-bold text-white font-mono border-b border-white/10 pb-2">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-emerald-400" />
              <span>OPTIMAL SOLUTION SUMMARY</span>
            </div>
            <span className="text-[9px] text-emerald-400 font-mono">CONVERGED</span>
          </div>

          {trajectoryResult ? (
            <div className="space-y-3 text-xs font-mono">
              <div className="grid grid-cols-2 gap-2">
                <div className="bg-black/40 p-2.5 rounded border border-white/5">
                  <div className="text-slate-500 text-[9px] uppercase">OPTIMIZED DURATION</div>
                  <div className="text-white font-bold text-base">{trajectoryResult.durationSec} s</div>
                  <div className="text-emerald-400 text-[9px]">-8.5% improvement</div>
                </div>

                <div className="bg-black/40 p-2.5 rounded border border-white/5">
                  <div className="text-slate-500 text-[9px] uppercase">ENERGY PER CYCLE</div>
                  <div className="text-orange-400 font-bold text-base">{trajectoryResult.energyKwh} kWh</div>
                  <div className="text-emerald-400 text-[9px]">-0.008 kWh delta</div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="bg-black/40 p-2.5 rounded border border-white/5">
                  <div className="text-slate-500 text-[9px] uppercase">PATH DISTANCE</div>
                  <div className="text-blue-400 font-bold">{trajectoryResult.distanceMeters} m</div>
                </div>

                <div className="bg-black/40 p-2.5 rounded border border-white/5">
                  <div className="text-slate-500 text-[9px] uppercase">SMOOTHNESS SCORE</div>
                  <div className="text-white font-bold">{trajectoryResult.smoothnessScore}%</div>
                </div>
              </div>

              <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/30 rounded flex items-center gap-2 text-emerald-400">
                <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
                <span className="text-[10px]">0 Constraint Violations • S-Curve Validated</span>
              </div>
            </div>
          ) : (
            <div className="text-slate-500 text-xs py-8 text-center font-mono">Calculating solution...</div>
          )}
        </div>
      </div>

      {/* S-Curve Kinematics Curves (Position, Velocity, Acceleration, Jerk) */}
      <div className="bg-[#0F1117] border border-white/10 rounded-lg p-5 shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">7-SEGMENT S-CURVE KINEMATICS TIME PROFILE</h3>
            <p className="text-[11px] text-slate-500 font-mono">Position (mm), Velocity (m/s), and Jerk (m/s³) computed by Rust DataCore</p>
          </div>
          <span className="text-[10px] font-mono text-orange-400 bg-orange-500/10 px-2 py-0.5 rounded border border-orange-500/30">
            Sampling: 60 Discrete Steps
          </span>
        </div>

        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={trajectoryResult?.trajectoryPoints || []}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" opacity={0.6} />
              <XAxis dataKey="t" stroke="#64748b" tick={{ fontSize: 10, fill: '#64748b' }} label={{ value: 'Time (s)', position: 'insideBottomRight', offset: -5, fill: '#64748b' }} />
              <YAxis stroke="#64748b" tick={{ fontSize: 10, fill: '#64748b' }} />
              <Tooltip
                contentStyle={{ backgroundColor: '#0F1117', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '6px', fontSize: '11px', fontFamily: 'monospace' }}
              />
              <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px', fontFamily: 'monospace' }} />
              <Line type="monotone" dataKey="pos[0]" name="Tool X (mm)" stroke="#f97316" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="vel[0]" name="Vel X (m/s)" stroke="#3b82f6" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="acc[0]" name="Acc X (m/s²)" stroke="#10b981" strokeWidth={1.5} dot={false} />
              <Line type="monotone" dataKey="jerk[0]" name="Jerk X (m/s³)" stroke="#ef4444" strokeWidth={1.5} strokeDasharray="4 4" dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Pareto Candidates Table */}
      <div className="bg-[#0F1117] border border-white/10 rounded-lg p-5 shadow-lg">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">PARETO FRONTIER CANDIDATE EVALUATION</h3>
            <span className="text-[9px] bg-blue-500/10 text-blue-400 border border-blue-500/30 px-2 py-0.5 rounded font-mono">
              NSGA-II Pluggable Optimizer
            </span>
          </div>
          <span className="text-[10px] text-slate-500 font-mono">Multi-Objective Frontier</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-white/10 text-slate-500 text-[10px] uppercase">
                <th className="pb-2">CANDIDATE ID</th>
                <th className="pb-2">ALGORITHM</th>
                <th className="pb-2">CYCLE TIME</th>
                <th className="pb-2">ENERGY/UNIT</th>
                <th className="pb-2">WEAR REDUCTION</th>
                <th className="pb-2">QUALITY SIGMA</th>
                <th className="pb-2">COMPOSITE SCORE</th>
                <th className="pb-2">STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-slate-300 text-xs">
              {trajectoryResult?.paretoCandidates.map((c) => (
                <tr key={c.id} className="hover:bg-white/5 transition">
                  <td className="py-2.5 text-orange-400 font-bold">{c.id}</td>
                  <td className="py-2.5 text-slate-300">{c.algorithm}</td>
                  <td className="py-2.5 text-white font-bold">{c.metrics.cycleTimeSec}s</td>
                  <td className="py-2.5 text-orange-300">{c.metrics.energyKwhPerUnit} kWh</td>
                  <td className="py-2.5 text-emerald-400">+{c.metrics.wearReductionPct}%</td>
                  <td className="py-2.5 text-blue-400">{c.metrics.qualitySigma} σ</td>
                  <td className="py-2.5 text-white font-bold">{c.metrics.compositeScore}</td>
                  <td className="py-2.5">
                    <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[9px] font-bold">
                      {c.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
