import React, { useState } from 'react';
import { RobotState } from '../types';
import { ShieldCheck, AlertTriangle, Activity, Wrench, Flame, Gauge, Clock, ChevronRight } from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  BarChart,
  Bar
} from 'recharts';

interface PredictiveMaintenanceViewProps {
  robots: RobotState[];
  onSelectRobot: (robot: RobotState) => void;
}

export const PredictiveMaintenanceView: React.FC<PredictiveMaintenanceViewProps> = ({
  robots,
  onSelectRobot
}) => {
  const [selectedRobotId, setSelectedRobotId] = useState<string>(robots[2]?.id || 'R-103');
  const selectedRobot = robots.find((r) => r.id === selectedRobotId) || robots[0];

  // Weibull survival curve computation based on operating cycles
  const weibullCurveData = [];
  const etaScale = 12000;
  const betaShape = 2.4;
  for (let hours = 0; hours <= 16000; hours += 1000) {
    const survivalProb = Math.exp(-Math.pow(hours / etaScale, betaShape));
    const hazardRate = (betaShape / etaScale) * Math.pow(hours / etaScale, betaShape - 1) * 10000;
    weibullCurveData.push({
      hours,
      survivalProbPct: +(survivalProb * 100).toFixed(1),
      hazardRate: +hazardRate.toFixed(2),
      currentAgeHours: 6400
    });
  }

  // Bearing FFT Vibration Frequency Spectrum
  const fftSpectrumData = [
    { freqHz: 25, ampG: 0.04, label: '1X Shaft Rotation' },
    { freqHz: 50, ampG: 0.08, label: '2X Harmonic' },
    { freqHz: 120, ampG: 0.06, label: 'Gear Mesh Frequency (GMF)' },
    { freqHz: 240, ampG: 0.18, label: 'GMF 2X' },
    { freqHz: 360, ampG: selectedRobot.healthScore < 80 ? 0.45 : 0.09, label: 'BPFO Bearing Outer Race' },
    { freqHz: 480, ampG: selectedRobot.healthScore < 80 ? 0.62 : 0.12, label: 'BPFI Bearing Inner Race' },
    { freqHz: 600, ampG: 0.08, label: 'High Freq Noise' },
    { freqHz: 750, ampG: 0.05, label: 'Harmonic' }
  ];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#0F1117] border border-white/10 rounded-lg p-5 shadow-lg relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-500" />
              <h2 className="text-sm font-bold text-white uppercase tracking-wider font-mono">PREDICTIVE MAINTENANCE & WEIBULL RUL ENGINE</h2>
              <span className="px-2 py-0.5 text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded font-mono font-bold">
                robotics.analytics::estimate_weibull_rul
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1 font-mono">
              Survival analysis combining Arrhenius thermal stress, FFT bearing vibration RMS, and joint torque fatigue.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-[10px] text-slate-500 uppercase font-mono">Select Unit:</span>
            <select
              id="maint-robot-select"
              value={selectedRobotId}
              onChange={(e) => setSelectedRobotId(e.target.value)}
              className="bg-black/50 border border-white/10 text-white rounded px-3 py-1.5 font-mono text-xs focus:ring-1 focus:ring-emerald-500 focus:outline-none cursor-pointer"
            >
              {robots.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.id} - {r.name} ({r.healthScore.toFixed(0)}% Health)
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Selected Asset Diagnostic Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#0F1117] border border-white/10 rounded-lg p-4 shadow-md">
          <div className="text-slate-500 text-[10px] uppercase font-mono flex items-center justify-between">
            <span>HEALTH SCORE</span>
            <Activity className="w-4 h-4 text-emerald-400" />
          </div>
          <div className={`text-2xl font-bold font-mono mt-1 ${selectedRobot.healthScore < 75 ? 'text-orange-400' : 'text-emerald-400'}`}>
            {selectedRobot.healthScore.toFixed(1)}%
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-1">
            Wear Index: <strong className="text-white">{(selectedRobot.wearIndex * 100).toFixed(1)}%</strong>
          </div>
        </div>

        <div className="bg-[#0F1117] border border-white/10 rounded-lg p-4 shadow-md">
          <div className="text-slate-500 text-[10px] uppercase font-mono flex items-center justify-between">
            <span>ESTIMATED RUL</span>
            <Clock className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-bold text-blue-400 font-mono mt-1">
            {selectedRobot.estimatedRulHours} hrs
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-1">
            90% CI: [{Math.round(selectedRobot.estimatedRulHours * 0.78)}, {Math.round(selectedRobot.estimatedRulHours * 1.25)}] hrs
          </div>
        </div>

        <div className="bg-[#0F1117] border border-white/10 rounded-lg p-4 shadow-md">
          <div className="text-slate-500 text-[10px] uppercase font-mono flex items-center justify-between">
            <span>VIBRATION RMS</span>
            <Gauge className="w-4 h-4 text-orange-400" />
          </div>
          <div className={`text-2xl font-bold font-mono mt-1 ${selectedRobot.vibrationRms > 0.04 ? 'text-red-400' : 'text-emerald-400'}`}>
            {selectedRobot.vibrationRms.toFixed(3)} g
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-1">ISO 10816 Limit: &lt; 0.028 g</div>
        </div>

        <div className="bg-[#0F1117] border border-white/10 rounded-lg p-4 shadow-md">
          <div className="text-slate-500 text-[10px] uppercase font-mono flex items-center justify-between">
            <span>MAINTENANCE URGENCY</span>
            <Wrench className="w-4 h-4 text-orange-400" />
          </div>
          <div className="mt-1">
            {selectedRobot.healthScore < 70 ? (
              <span className="px-2.5 py-0.5 text-[10px] font-mono font-bold bg-red-500/10 text-red-400 border border-red-500/30 rounded">
                SCHEDULED (SOON)
              </span>
            ) : selectedRobot.healthScore < 85 ? (
              <span className="px-2.5 py-0.5 text-[10px] font-mono font-bold bg-orange-500/10 text-orange-400 border border-orange-500/30 rounded">
                MONITORING
              </span>
            ) : (
              <span className="px-2.5 py-0.5 text-[10px] font-mono font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded">
                NORMAL
              </span>
            )}
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-2">Next Inspection: 45 Cycles</div>
        </div>
      </div>

      {/* Weibull Degradation Curve & FFT Spectrum */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weibull Curve */}
        <div className="bg-[#0F1117] border border-white/10 rounded-lg p-5 shadow-lg">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">WEIBULL SURVIVAL & HAZARD RATE (t)</h3>
              <p className="text-[11px] text-slate-500 font-mono">Shape β = 2.4 (Wearout phase) • Characteristic Life η = 12,000h</p>
            </div>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={weibullCurveData}>
                <defs>
                  <linearGradient id="survivalGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" opacity={0.6} />
                <XAxis dataKey="hours" stroke="#64748b" tick={{ fontSize: 10, fill: '#64748b' }} label={{ value: 'Operating Hours (h)', position: 'insideBottomRight', offset: -5, fill: '#64748b' }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 10, fill: '#64748b' }} domain={[0, 100]} />
                <Tooltip contentStyle={{ backgroundColor: '#0F1117', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '6px', fontSize: '11px', fontFamily: 'monospace' }} />
                <Legend wrapperStyle={{ fontSize: '11px', fontFamily: 'monospace' }} />
                <Area type="monotone" dataKey="survivalProbPct" name="Survival Probability S(t) %" stroke="#10b981" fillOpacity={1} fill="url(#survivalGradient)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* FFT Bearing Vibration Spectrum */}
        <div className="bg-[#0F1117] border border-white/10 rounded-lg p-5 shadow-lg">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">BEARING FFT SPECTRAL HARMONICS</h3>
              <p className="text-[11px] text-slate-500 font-mono">Peak detection on Outer (BPFO) and Inner Race (BPFI) defect frequencies</p>
            </div>
            <span className="text-[10px] font-mono text-orange-400 bg-orange-500/10 px-2 py-0.5 rounded border border-orange-500/30">
              {selectedRobot.id} Joint 4
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={fftSpectrumData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" opacity={0.6} />
                <XAxis dataKey="freqHz" stroke="#64748b" tick={{ fontSize: 10, fill: '#64748b' }} label={{ value: 'Frequency (Hz)', position: 'insideBottomRight', offset: -5, fill: '#64748b' }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 10, fill: '#64748b' }} domain={[0, 0.8]} />
                <Tooltip contentStyle={{ backgroundColor: '#0F1117', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '6px', fontSize: '11px', fontFamily: 'monospace' }} />
                <Legend wrapperStyle={{ fontSize: '11px', fontFamily: 'monospace' }} />
                <Bar dataKey="ampG" name="Vibration Amplitude (g)" fill="#3b82f6" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Fleet Maintenance Priority Ranking Table */}
      <div className="bg-[#0F1117] border border-white/10 rounded-lg p-5 shadow-lg">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">FLEET PREDICTIVE HEALTH RANKING (STOCHASTIC RUL)</h3>
          <span className="text-[10px] text-slate-500 font-mono">Sorted by Urgency</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-white/10 text-slate-500 text-[10px] uppercase">
                <th className="pb-2">ROBOT ID</th>
                <th className="pb-2">MODEL & CELL</th>
                <th className="pb-2">HEALTH SCORE</th>
                <th className="pb-2">ESTIMATED RUL</th>
                <th className="pb-2">VIBRATION RMS</th>
                <th className="pb-2">TEMP</th>
                <th className="pb-2">PRIORITY</th>
                <th className="pb-2">ACTION</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-slate-300 text-xs">
              {[...robots]
                .sort((a, b) => a.healthScore - b.healthScore)
                .map((r) => (
                  <tr key={r.id} className="hover:bg-white/5 transition">
                    <td className="py-2.5 text-orange-400 font-bold">{r.id}</td>
                    <td className="py-2.5">
                      <div className="text-white font-medium">{r.name}</div>
                      <div className="text-[10px] text-slate-500">{r.cellId}</div>
                    </td>
                    <td className="py-2.5 font-bold">
                      <span className={r.healthScore < 75 ? 'text-orange-400' : 'text-emerald-400'}>
                        {r.healthScore.toFixed(1)}%
                      </span>
                    </td>
                    <td className="py-2.5 text-blue-400">{r.estimatedRulHours} hrs</td>
                    <td className="py-2.5 text-orange-300">{r.vibrationRms.toFixed(3)} g</td>
                    <td className="py-2.5 text-white">{r.joints[0]?.tempCelsius.toFixed(1)}°C</td>
                    <td className="py-2.5">
                      {r.healthScore < 70 ? (
                        <span className="px-2 py-0.5 rounded bg-red-500/10 text-red-400 border border-red-500/30 text-[9px] font-bold">
                          HIGH
                        </span>
                      ) : r.healthScore < 85 ? (
                        <span className="px-2 py-0.5 rounded bg-orange-500/10 text-orange-400 border border-orange-500/30 text-[9px] font-bold">
                          MEDIUM
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[9px] font-bold">
                          LOW
                        </span>
                      )}
                    </td>
                    <td className="py-2.5">
                      <button
                        onClick={() => {
                          setSelectedRobotId(r.id);
                          onSelectRobot(r);
                        }}
                        className="px-2.5 py-1 bg-black/40 hover:bg-orange-500/10 border border-white/10 hover:border-orange-500/40 text-orange-400 rounded text-[10px] font-mono transition flex items-center gap-1 cursor-pointer"
                      >
                        INSPECT <ChevronRight className="w-3 h-3" />
                      </button>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
