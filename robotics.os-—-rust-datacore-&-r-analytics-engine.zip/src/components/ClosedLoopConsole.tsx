import React, { useState } from 'react';
import { ClosedLoopEvent } from '../types';
import { Radio, Play, CheckCircle2, AlertTriangle, ShieldCheck, ArrowRight, Cpu, Activity, BarChart3, RefreshCw } from 'lucide-react';

interface ClosedLoopConsoleProps {
  currentStage: string;
  onAdvanceStage: () => void;
  onApproveProposal: () => void;
  events: ClosedLoopEvent[];
  isApproved: boolean;
}

export const ClosedLoopConsole: React.FC<ClosedLoopConsoleProps> = ({
  currentStage,
  onAdvanceStage,
  onApproveProposal,
  events,
  isApproved
}) => {
  const STAGES = [
    { id: 'SENSE', label: '1. SENSE', engine: 'Rust DataCore', desc: 'Ingest 250kHz joint telemetry' },
    { id: 'MEASURE', label: '2. MEASURE', engine: 'Rust DataCore', desc: 'Rolling Welford variance' },
    { id: 'ANALYSE', label: '3. ANALYSE', engine: 'R Analytics', desc: 'Shewhart SPC & Bottleneck detection' },
    { id: 'MODEL', label: '4. MODEL', engine: 'R Analytics', desc: 'Weibull RUL & Quality regression' },
    { id: 'OPTIMISE', label: '5. OPTIMISE', engine: 'Rust DataCore', desc: 'NSGA-II Pareto frontier generation' },
    { id: 'SIMULATE', label: '6. SIMULATE', engine: 'Python Twin', desc: 'Collision & kinematic dry run' },
    { id: 'APPROVE', label: '7. APPROVE', engine: 'Human / System Gate', desc: 'Safety engineer sign-off' },
    { id: 'EXECUTE', label: '8. EXECUTE', engine: 'Python Robot Driver', desc: 'Deploy S-curve to physical controllers' }
  ];

  const currentIdx = STAGES.findIndex((s) => s.id === currentStage);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#0F1117] border border-white/10 rounded-lg p-5 shadow-lg relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <Radio className="w-5 h-5 text-red-500" />
              <h2 className="text-sm font-bold text-white uppercase tracking-wider font-mono">CLOSED-LOOP AUTONOMOUS OPTIMIZATION</h2>
              <span className="px-2 py-0.5 text-[10px] bg-red-500/10 text-red-400 border border-red-500/30 rounded font-mono font-bold">
                Continuous Sense-to-Actuate Cycle
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1 font-mono">
              Deterministic 8-stage loop: SENSE → MEASURE → ANALYSE → MODEL → OPTIMISE → SIMULATE → APPROVE → EXECUTE.
            </p>
          </div>

          <div className="flex items-center gap-2">
            {currentStage === 'APPROVE' && !isApproved ? (
              <button
                id="approve-closed-loop-btn"
                onClick={onApproveProposal}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white font-mono font-bold rounded text-xs transition shadow-lg cursor-pointer tracking-wider"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>APPROVE & AUTHORIZE DEPLOYMENT</span>
              </button>
            ) : (
              <button
                id="advance-stage-btn"
                onClick={onAdvanceStage}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-400 hover:to-red-500 text-white font-mono font-bold rounded text-xs transition shadow-lg cursor-pointer tracking-wider"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>STEP CYCLE: {currentStage}</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Visual 8-Stage Pipeline Flow */}
      <div className="bg-[#0F1117] border border-white/10 rounded-lg p-5 shadow-lg">
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          {STAGES.map((stage, idx) => {
            const isCurrent = stage.id === currentStage;
            const isCompleted = currentIdx > idx || (currentIdx === 0 && events.length > 8);

            return (
              <div
                key={stage.id}
                className={`p-3 rounded border text-xs transition-all relative font-mono ${
                  isCurrent
                    ? 'bg-orange-500/10 border-orange-500/80 shadow-md ring-1 ring-orange-500/50'
                    : isCompleted
                    ? 'bg-black/40 border-emerald-500/30'
                    : 'bg-black/20 border-white/5 opacity-50'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className={`font-mono font-bold text-[10px] uppercase ${isCurrent ? 'text-orange-400' : isCompleted ? 'text-emerald-400' : 'text-slate-500'}`}>
                    {stage.label}
                  </span>
                  {isCompleted && <CheckCircle2 className="w-3 h-3 text-emerald-400 flex-shrink-0" />}
                </div>

                <div className="text-[9px] text-blue-400 font-mono uppercase font-semibold mb-1 truncate">{stage.engine}</div>
                <div className="text-[10px] text-slate-400 leading-tight">{stage.desc}</div>

                {isCurrent && (
                  <div className="absolute -top-1 -right-1 w-2 h-2 bg-orange-500 rounded-full animate-ping"></div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Safety Gate Alert */}
      <div className="bg-[#0F1117] border border-orange-500/30 rounded-lg p-4 flex items-start gap-3 text-xs">
        <AlertTriangle className="w-4 h-4 text-orange-400 flex-shrink-0 mt-0.5" />
        <div>
          <div className="font-bold text-white font-mono text-[11px] uppercase tracking-wider">SAFETY INTERLOCK & MODEL GOVERNANCE ACTIVE</div>
          <p className="text-slate-400 text-[11px] font-mono mt-0.5">
            Per industrial standard ISO 10218-1, autonomous trajectory revisions are strictly quarantined in the Python Digital Twin simulation until simulated collision risks equal 0.00% and human-in-the-loop sign-off is granted.
          </p>
        </div>
      </div>

      {/* Audit Log & Decision Trace */}
      <div className="bg-[#0F1117] border border-white/10 rounded-lg p-5 shadow-lg">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">AUDIT TRAIL & DECISION REPRODUCIBILITY LOG</h3>
          <span className="text-[10px] text-slate-500 font-mono">Cryptographic Event Hash Chain</span>
        </div>

        <div className="space-y-2">
          {events.map((evt) => {
            const isRust = evt.source === 'RUST_DATACORE';
            const isR = evt.source === 'R_ANALYTICS';

            return (
              <div
                key={evt.id}
                className="p-3 bg-black/40 rounded border border-white/5 hover:border-white/15 transition flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs font-mono"
              >
                <div className="flex items-start sm:items-center gap-3">
                  <span className="text-slate-500 text-[10px] whitespace-nowrap">{evt.timestamp}</span>
                  <span
                    className={`px-2 py-0.5 rounded text-[9px] font-bold ${
                      isRust
                        ? 'bg-orange-500/10 text-orange-400 border border-orange-500/30'
                        : isR
                        ? 'bg-blue-500/10 text-blue-400 border border-blue-500/30'
                        : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                    }`}
                  >
                    {evt.source}
                  </span>
                  <span className="text-white font-medium text-xs">{evt.title}</span>
                </div>

                <div className="text-slate-400 text-right text-[11px]">{evt.details}</div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
