import React, { useState, useEffect } from 'react';
import { BenchmarkResult } from '../types';
import { Activity, Play, Zap, Cpu, ArrowUpRight } from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Cell
} from 'recharts';

export const BenchmarkingView: React.FC = () => {
  const [benchmarks, setBenchmarks] = useState<BenchmarkResult[]>([]);
  const [running, setRunning] = useState<boolean>(false);

  const fetchBenchmarks = async () => {
    setRunning(true);
    try {
      const res = await fetch('/api/benchmarks/run');
      const data = await res.json();
      setBenchmarks(data);
    } catch (e) {
      console.error('Failed to run benchmarks', e);
    } finally {
      setTimeout(() => setRunning(false), 500);
    }
  };

  useEffect(() => {
    fetchBenchmarks();
  }, []);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#0F1117] border border-white/10 rounded-lg p-5 shadow-lg relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-orange-500" />
              <h2 className="text-sm font-bold text-white uppercase tracking-wider font-mono">HIGH-PERFORMANCE BENCHMARKING SUITE</h2>
              <span className="px-2 py-0.5 text-[10px] bg-orange-500/10 text-orange-400 border border-orange-500/30 rounded font-mono font-bold">
                Criterion.rs & R-Microbenchmark
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1 font-mono">
              Deterministic comparison of Rust DataCore (Rayon/SIMD), R statistical packages, and Python fallback routines.
            </p>
          </div>

          <button
            onClick={fetchBenchmarks}
            disabled={running}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-400 hover:to-red-500 text-white font-mono font-bold rounded text-xs transition shadow-lg disabled:opacity-50 cursor-pointer tracking-wider"
          >
            {running ? (
              <span className="animate-spin inline-block w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full"></span>
            ) : (
              <Play className="w-3.5 h-3.5 fill-current" />
            )}
            <span>RUN STRESS BENCHMARK (1M FRAMES)</span>
          </button>
        </div>
      </div>

      {/* Throughput & Latency Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Throughput (Records / Sec) */}
        <div className="bg-[#0F1117] border border-white/10 rounded-lg p-5 shadow-lg">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">THROUGHPUT (RECORDS / SEC)</h3>
              <p className="text-[11px] text-slate-500 font-mono">Higher is better • Zero-copy Rust column buffers</p>
            </div>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={benchmarks} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" opacity={0.6} />
                <XAxis type="number" stroke="#64748b" tick={{ fontSize: 10, fill: '#64748b' }} tickFormatter={(val) => `${(val / 1000).toFixed(0)}k`} />
                <YAxis dataKey="task" type="category" stroke="#64748b" tick={{ fontSize: 10, fill: '#64748b' }} width={140} />
                <Tooltip contentStyle={{ backgroundColor: '#0F1117', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '6px', fontSize: '11px', fontFamily: 'monospace' }} />
                <Bar dataKey="throughputRecordsPerSec" name="Records/sec" radius={[0, 2, 2, 0]}>
                  {benchmarks.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={entry.engine === 'Rust DataCore' ? '#f97316' : entry.engine === 'R Analytics' ? '#3b82f6' : '#64748b'}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Latency (Microseconds) */}
        <div className="bg-[#0F1117] border border-white/10 rounded-lg p-5 shadow-lg">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">PROCESSING LATENCY (μs)</h3>
              <p className="text-[11px] text-slate-500 font-mono">Lower is better • Deterministic execution</p>
            </div>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={benchmarks} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" opacity={0.6} />
                <XAxis type="number" stroke="#64748b" tick={{ fontSize: 10, fill: '#64748b' }} unit=" μs" />
                <YAxis dataKey="task" type="category" stroke="#64748b" tick={{ fontSize: 10, fill: '#64748b' }} width={140} />
                <Tooltip contentStyle={{ backgroundColor: '#0F1117', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '6px', fontSize: '11px', fontFamily: 'monospace' }} />
                <Bar dataKey="latencyMicros" name="Latency (μs)" fill="#10b981" radius={[0, 2, 2, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Benchmark Metric Grid */}
      <div className="bg-[#0F1117] border border-white/10 rounded-lg p-5 shadow-lg">
        <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono mb-3">EMPIRICAL SPEEDUP & RESOURCE FOOTPRINT</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-white/10 text-slate-500 text-[10px] uppercase">
                <th className="pb-2">TASK WORKLOAD</th>
                <th className="pb-2">ENGINE</th>
                <th className="pb-2">THROUGHPUT</th>
                <th className="pb-2">LATENCY</th>
                <th className="pb-2">MEMORY (MB)</th>
                <th className="pb-2">CPU (%)</th>
                <th className="pb-2">SPEEDUP FACTOR</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-slate-300">
              {benchmarks.map((b, idx) => (
                <tr key={idx} className="hover:bg-white/5 transition">
                  <td className="py-2.5 text-white font-medium">{b.task}</td>
                  <td className="py-2.5">
                    <span
                      className={`px-2 py-0.5 rounded text-[9px] font-bold ${
                        b.engine === 'Rust DataCore'
                          ? 'bg-orange-500/10 text-orange-400 border border-orange-500/30'
                          : b.engine === 'R Analytics'
                          ? 'bg-blue-500/10 text-blue-400 border border-blue-500/30'
                          : 'bg-white/5 text-slate-400 border border-white/10'
                      }`}
                    >
                      {b.engine}
                    </span>
                  </td>
                  <td className="py-2.5 text-orange-400 font-bold">{b.throughputRecordsPerSec.toLocaleString()} /s</td>
                  <td className="py-2.5 text-emerald-400 font-bold">{b.latencyMicros} μs</td>
                  <td className="py-2.5 text-slate-300">{b.memoryMb} MB</td>
                  <td className="py-2.5 text-slate-300">{b.cpuPercent}%</td>
                  <td className="py-2.5">
                    <span className="text-emerald-400 font-bold text-xs">
                      {b.speedupFactor > 1 ? `${b.speedupFactor.toFixed(1)}x` : '1.0x (Baseline)'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
