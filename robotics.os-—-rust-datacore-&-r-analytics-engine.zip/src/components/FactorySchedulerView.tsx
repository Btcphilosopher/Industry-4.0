import React, { useState } from 'react';
import { Workcell, RobotState } from '../types';
import { RefreshCw, AlertTriangle, TrendingUp, Zap, CheckCircle2, Play, ArrowRight, Activity } from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  LineChart,
  Line,
  Cell
} from 'recharts';

interface FactorySchedulerViewProps {
  workcells: Workcell[];
  robots: RobotState[];
  onTriggerClosedLoop: () => void;
}

export const FactorySchedulerView: React.FC<FactorySchedulerViewProps> = ({
  workcells,
  robots,
  onTriggerClosedLoop
}) => {
  const [staggerOffsets, setStaggerOffsets] = useState<boolean>(true);

  // Power demand profile over 60 seconds (Simulated Plant Grid)
  const powerTimelineData = [];
  for (let s = 0; s <= 60; s += 2) {
    // Concurrent unoptimized spikes vs smooth staggered profile
    const unoptimized = 38.0 + Math.sin(s * 0.3) * 16.0 + (s % 12 === 0 ? 22.0 : 0.0);
    const optimized = 32.0 + Math.sin(s * 0.3) * 6.0;
    powerTimelineData.push({
      sec: s,
      unoptimizedKw: +unoptimized.toFixed(1),
      optimizedKw: +optimized.toFixed(1),
      peakLimitKw: 45.0
    });
  }

  const chartWorkcells = workcells.map((w) => ({
    name: w.name.split(' ')[0] + ' ' + (w.name.split(' ')[1] || ''),
    id: w.id,
    utilizationPct: +w.utilizationPct.toFixed(1),
    queueDepth: w.queueDepth,
    throughputPph: +w.throughputPph.toFixed(1),
    isBottleneck: w.isBottleneck
  }));

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#0F1117] border border-white/10 rounded-lg p-5 shadow-lg relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <RefreshCw className="w-5 h-5 text-orange-500" />
              <h2 className="text-sm font-bold text-white uppercase tracking-wider font-mono">MULTI-ROBOT SCHEDULER & BOTTLENECK OPTIMIZER</h2>
              <span className="px-2 py-0.5 text-[10px] bg-orange-500/10 text-orange-400 border border-orange-500/30 rounded font-mono font-bold">
                Rust::scheduling::FactoryOptimizer
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1 font-mono">
              Discrete-event line balancing, queue dynamic stochastic modeling, and synchronized plant-wide peak shaving.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onTriggerClosedLoop}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-400 hover:to-red-500 text-white font-mono font-bold rounded text-xs transition shadow-lg cursor-pointer tracking-wider"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>TRIGGER RE-OPTIMIZATION</span>
            </button>
          </div>
        </div>
      </div>

      {/* Autonomous Optimization Recommendation Card */}
      <div className="bg-[#0F1117] border border-orange-500/30 rounded-lg p-5 shadow-xl">
        <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-orange-500 animate-pulse"></span>
            <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">AUTONOMOUS OPTIMIZATION PROPOSAL (ROBOTICS.OS)</h3>
          </div>
          <span className="text-[10px] bg-orange-500/10 text-orange-400 border border-orange-500/30 px-2.5 py-0.5 rounded font-mono font-bold">
            Confidence: 94.8% (R-Bayesian)
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="space-y-2 text-xs">
            <div className="text-slate-500 text-[10px] uppercase font-mono font-semibold">CURRENT BOTTLENECK STATE</div>
            <div className="p-3 bg-black/40 rounded border border-white/5 space-y-1.5 font-mono text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">Line Cycle Time:</span>
                <span className="text-white font-bold">42.3 s</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Bottleneck Workcell:</span>
                <span className="text-red-400 font-bold">CELL-7 (Laser 98.4%)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Energy Consumption:</span>
                <span className="text-orange-300">0.184 kWh / unit</span>
              </div>
            </div>
          </div>

          <div className="space-y-2 text-xs">
            <div className="text-orange-400 text-[10px] uppercase font-mono font-semibold">PROPOSED OPTIMIZED STATE</div>
            <div className="p-3 bg-black/40 rounded border border-orange-500/30 space-y-1.5 font-mono text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">Optimized Cycle Time:</span>
                <span className="text-emerald-400 font-bold">38.7 s</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Debottlenecked Gain:</span>
                <span className="text-emerald-400 font-bold">+8.5% Throughput</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Energy Consumption:</span>
                <span className="text-emerald-400 font-bold">0.176 kWh / unit (-4.3%)</span>
              </div>
            </div>
          </div>

          <div className="space-y-2 text-xs flex flex-col justify-between">
            <div>
              <div className="text-slate-500 text-[10px] uppercase font-mono font-semibold">CONSTRAINTS & SAFETY</div>
              <div className="p-3 bg-black/40 rounded border border-white/5 space-y-1.5 text-[11px] font-mono">
                <div className="text-emerald-400 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5" /> 0 Kinematic Violations
                </div>
                <div className="text-emerald-400 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Collision Envelope Zero Risk
                </div>
                <div className="text-slate-500 text-[10px]">Recommendation: Run Python Simulation.</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Workstation Utilization & Queue Dynamics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Workstation Utilization */}
        <div className="bg-[#0F1117] border border-white/10 rounded-lg p-5 shadow-lg">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">WORKCELL UTILIZATION (%)</h3>
              <p className="text-[11px] text-slate-500 font-mono">Highlighting primary and secondary production line bottlenecks</p>
            </div>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartWorkcells}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" opacity={0.6} />
                <XAxis dataKey="name" stroke="#64748b" tick={{ fontSize: 10, fill: '#64748b' }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 10, fill: '#64748b' }} domain={[0, 100]} />
                <Tooltip contentStyle={{ backgroundColor: '#0F1117', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '6px', fontSize: '11px', fontFamily: 'monospace' }} />
                <Bar dataKey="utilizationPct" name="Utilization %" radius={[2, 2, 0, 0]}>
                  {chartWorkcells.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.isBottleneck ? '#ef4444' : entry.utilizationPct > 80 ? '#f97316' : '#3b82f6'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Energy Peak Shaving */}
        <div className="bg-[#0F1117] border border-white/10 rounded-lg p-5 shadow-lg">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">PLANT GRID POWER & PEAK SHAVING</h3>
              <p className="text-[11px] text-slate-500 font-mono">420ms trajectory offset eliminates concurrent robot acceleration spikes</p>
            </div>
            <span className="text-[10px] font-mono text-orange-400 bg-orange-500/10 px-2 py-0.5 rounded border border-orange-500/30">
              Peak Limit: 45 kW
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={powerTimelineData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" opacity={0.6} />
                <XAxis dataKey="sec" stroke="#64748b" tick={{ fontSize: 10, fill: '#64748b' }} label={{ value: 'Time (s)', position: 'insideBottomRight', offset: -5, fill: '#64748b' }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 10, fill: '#64748b' }} domain={[20, 60]} />
                <Tooltip contentStyle={{ backgroundColor: '#0F1117', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '6px', fontSize: '11px', fontFamily: 'monospace' }} />
                <Legend wrapperStyle={{ fontSize: '11px', fontFamily: 'monospace' }} />
                <Line type="monotone" dataKey="unoptimizedKw" name="Unsynchronized Spikes (kW)" stroke="#ef4444" strokeWidth={1.5} strokeDasharray="3 3" dot={false} />
                <Line type="monotone" dataKey="optimizedKw" name="Staggered Smooth Profile (kW)" stroke="#10b981" strokeWidth={2.5} dot={false} />
                <Line type="monotone" dataKey="peakLimitKw" name="Grid Cap (45 kW)" stroke="#f97316" strokeWidth={1} strokeDasharray="6 6" dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
