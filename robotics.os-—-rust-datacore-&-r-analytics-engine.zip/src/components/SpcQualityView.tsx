import React, { useState, useEffect } from 'react';
import { SpcMeasurement } from '../types';
import { BarChart3, AlertOctagon, CheckCircle2, TrendingUp, Filter, Sparkles } from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine
} from 'recharts';

export const SpcQualityView: React.FC = () => {
  const [feature, setFeature] = useState<string>('Laser Metrology (um)');
  const [spcData, setSpcData] = useState<{
    feature: string;
    subgroupSize: number;
    grandMeanX: number;
    meanRangeR: number;
    cpk: number;
    processSigma: number;
    samples: SpcMeasurement[];
  } | null>(null);

  const fetchSpc = async () => {
    try {
      const res = await fetch(`/api/analytics/spc?feature=${encodeURIComponent(feature)}`);
      const data = await res.json();
      setSpcData(data);
    } catch (e) {
      console.error('Failed to fetch SPC data', e);
    }
  };

  useEffect(() => {
    fetchSpc();
  }, [feature]);

  const violations = spcData?.samples.filter((s) => s.isNelsonViolation) || [];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#0F1117] border border-white/10 rounded-lg p-5 shadow-lg relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-blue-500" />
              <h2 className="text-sm font-bold text-white uppercase tracking-wider font-mono">R STATISTICAL PROCESS CONTROL (SPC) ENGINE</h2>
              <span className="px-2 py-0.5 text-[10px] bg-blue-500/10 text-blue-400 border border-blue-500/30 rounded font-mono font-bold">
                robotics.analytics::compute_spc_xbar_r
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1 font-mono">
              Shewhart X-bar and R control charts with real-time Nelson rule automated anomaly detection.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 text-xs">
              <span className="text-[10px] text-slate-500 uppercase font-mono">Parameter:</span>
              <select
                id="spc-feature-select"
                value={feature}
                onChange={(e) => setFeature(e.target.value)}
                className="bg-black/50 border border-white/10 text-white rounded px-3 py-1.5 font-mono text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none cursor-pointer"
              >
                <option value="Laser Metrology (um)">Laser Metrology (um)</option>
                <option value="Spot Weld Tensile (kN)">Spot Weld Tensile (kN)</option>
                <option value="CNC Surface Roughness Ra (um)">CNC Surface Roughness Ra (um)</option>
                <option value="Gear Backlash Angle (arcmin)">Gear Backlash Angle (arcmin)</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#0F1117] border border-white/10 rounded-lg p-4 shadow-md">
          <div className="text-slate-500 text-[10px] uppercase font-mono">PROCESS CAPABILITY (Cpk)</div>
          <div className="text-2xl font-bold text-emerald-400 font-mono mt-1">{spcData?.cpk || '1.48'}</div>
          <div className="text-[10px] text-slate-500 font-mono mt-1">Capable (&gt; 1.33 Standard)</div>
        </div>

        <div className="bg-[#0F1117] border border-white/10 rounded-lg p-4 shadow-md">
          <div className="text-slate-500 text-[10px] uppercase font-mono">PROCESS SIGMA LEVEL</div>
          <div className="text-2xl font-bold text-blue-400 font-mono mt-1">{spcData?.processSigma || '5.12'} σ</div>
          <div className="text-[10px] text-slate-500 font-mono mt-1">Defect Rate &lt; 28 PPM</div>
        </div>

        <div className="bg-[#0F1117] border border-white/10 rounded-lg p-4 shadow-md">
          <div className="text-slate-500 text-[10px] uppercase font-mono">GRAND MEAN (X-Double-Bar)</div>
          <div className="text-2xl font-bold text-white font-mono mt-1">{spcData?.grandMeanX || '12.04'}</div>
          <div className="text-[10px] text-slate-500 font-mono mt-1">Subgroup size n = {spcData?.subgroupSize || 5}</div>
        </div>

        <div className="bg-[#0F1117] border border-white/10 rounded-lg p-4 shadow-md">
          <div className="text-slate-500 text-[10px] uppercase font-mono">NELSON VIOLATIONS</div>
          <div className={`text-2xl font-bold font-mono mt-1 ${violations.length > 0 ? 'text-red-400' : 'text-emerald-400'}`}>
            {violations.length} Samples
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-1">
            {violations.length > 0 ? 'Special cause drift flagged' : 'In Statistical Control'}
          </div>
        </div>
      </div>

      {/* X-Bar Shewhart Chart */}
      <div className="bg-[#0F1117] border border-white/10 rounded-lg p-5 shadow-lg">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">SHEWHART X-BAR CONTROL CHART</h3>
            <p className="text-[11px] text-slate-500 font-mono">Subgroup averages with ±3-sigma statistical control limits</p>
          </div>
          <div className="flex items-center gap-3 text-[10px] font-mono">
            <span className="text-red-400">UCL: {spcData?.samples[0]?.uclX}</span>
            <span className="text-emerald-400">CL: {spcData?.samples[0]?.meanX}</span>
            <span className="text-red-400">LCL: {spcData?.samples[0]?.lclX}</span>
          </div>
        </div>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={spcData?.samples || []}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" opacity={0.6} />
              <XAxis dataKey="sampleIndex" stroke="#64748b" tick={{ fontSize: 10, fill: '#64748b' }} label={{ value: 'Subgroup Sample Index', position: 'insideBottomRight', offset: -5, fill: '#64748b' }} />
              <YAxis stroke="#64748b" tick={{ fontSize: 10, fill: '#64748b' }} domain={['auto', 'auto']} />
              <Tooltip contentStyle={{ backgroundColor: '#0F1117', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '6px', fontSize: '11px', fontFamily: 'monospace' }} />
              <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px', fontFamily: 'monospace' }} />
              
              {/* Control limit reference lines */}
              {spcData?.samples[0] && (
                <>
                  <ReferenceLine y={spcData.samples[0].uclX} stroke="#ef4444" strokeDasharray="4 4" label={{ value: 'UCL (+3σ)', fill: '#ef4444', fontSize: 10 }} />
                  <ReferenceLine y={spcData.samples[0].meanX} stroke="#10b981" strokeWidth={1.5} label={{ value: 'Grand Mean', fill: '#10b981', fontSize: 10 }} />
                  <ReferenceLine y={spcData.samples[0].lclX} stroke="#ef4444" strokeDasharray="4 4" label={{ value: 'LCL (-3σ)', fill: '#ef4444', fontSize: 10 }} />
                </>
              )}

              <Line
                type="monotone"
                dataKey="xBar"
                name="Subgroup Mean (X-Bar)"
                stroke="#3b82f6"
                strokeWidth={2}
                dot={(props: any) => {
                  const isViol = props.payload.isNelsonViolation;
                  return (
                    <circle
                      cx={props.cx}
                      cy={props.cy}
                      r={isViol ? 5 : 3}
                      fill={isViol ? '#ef4444' : '#3b82f6'}
                      stroke={isViol ? '#ffffff' : 'none'}
                      strokeWidth={1.5}
                    />
                  );
                }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Range (R) Chart */}
      <div className="bg-[#0F1117] border border-white/10 rounded-lg p-5 shadow-lg">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">RANGE (R) DISPERSION CHART</h3>
            <p className="text-[11px] text-slate-500 font-mono">Within-subgroup variation (Max - Min)</p>
          </div>
          <div className="flex items-center gap-3 text-[10px] font-mono">
            <span className="text-red-400">UCL_R: {spcData?.samples[0]?.uclR}</span>
            <span className="text-emerald-400">Mean_R: {spcData?.samples[0]?.meanR}</span>
          </div>
        </div>

        <div className="h-48 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={spcData?.samples || []}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" opacity={0.6} />
              <XAxis dataKey="sampleIndex" stroke="#64748b" tick={{ fontSize: 10, fill: '#64748b' }} />
              <YAxis stroke="#64748b" tick={{ fontSize: 10, fill: '#64748b' }} />
              <Tooltip contentStyle={{ backgroundColor: '#0F1117', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '6px', fontSize: '11px', fontFamily: 'monospace' }} />
              <Legend wrapperStyle={{ fontSize: '11px', fontFamily: 'monospace' }} />
              {spcData?.samples[0] && (
                <>
                  <ReferenceLine y={spcData.samples[0].uclR} stroke="#ef4444" strokeDasharray="4 4" />
                  <ReferenceLine y={spcData.samples[0].meanR} stroke="#10b981" />
                </>
              )}
              <Line type="monotone" dataKey="rangeR" name="Sample Range (R)" stroke="#f97316" strokeWidth={2} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Nelson Rules Anomaly Log */}
      {violations.length > 0 && (
        <div className="bg-[#0F1117] border border-red-500/30 rounded-lg p-5 shadow-lg">
          <div className="flex items-center gap-2 mb-3 text-red-400 font-bold font-mono text-xs uppercase tracking-wider">
            <AlertOctagon className="w-4 h-4 text-red-500" />
            <span>NELSON STATISTICAL DRIFT VIOLATIONS FLAGGED</span>
          </div>

          <div className="space-y-2">
            {violations.map((v) => (
              <div key={v.sampleIndex} className="p-3 bg-black/40 rounded border border-red-500/20 flex items-center justify-between text-xs font-mono">
                <div className="flex items-center gap-3">
                  <span className="px-2 py-0.5 bg-red-500/10 text-red-400 border border-red-500/30 rounded text-[10px]">
                    Subgroup #{v.sampleIndex}
                  </span>
                  <span className="text-white">Measured X-Bar: <strong className="text-red-400">{v.xBar}</strong> (Nominal: {v.meanX})</span>
                </div>
                <div className="text-red-400 font-bold text-[11px]">{v.violationRule}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
