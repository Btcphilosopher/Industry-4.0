//! Robotics.OS DataCore - High-Throughput Telemetry Ingestion Engine
//! Strongly typed, memory-efficient data structures for 100k+ Hz robot feeds.

use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;

/// Strongly typed robotic telemetry frame
#[repr(C)]
#[derive(Debug, Clone, PartialEq)]
pub struct RobotTelemetry {
    pub timestamp_ns: u64,
    pub robot_id: [u8; 16], // Fixed-size identifier avoiding heap allocation
    pub joint_positions: [f64; 6],
    pub joint_velocities: [f64; 6],
    pub joint_torques: [f64; 6],
    pub motor_currents: [f64; 6],
    pub motor_temperatures: [f64; 6],
    pub tool_position: [f64; 3], // X, Y, Z in meters
    pub tool_orientation_quat: [f64; 4], // w, x, y, z
    pub cycle_time_sec: f64,
    pub vibration_rms: f64,
    pub tcp_force_n: f64,
    pub energy_watts: f64,
    pub fault_mask: u32,
}

impl RobotTelemetry {
    #[inline(always)]
    pub fn new(id_str: &str) -> Self {
        let mut id_bytes = [0u8; 16];
        let bytes = id_str.as_bytes();
        let len = bytes.len().min(16);
        id_bytes[..len].copy_from_slice(&bytes[..len]);

        Self {
            timestamp_ns: 0,
            robot_id: id_bytes,
            joint_positions: [0.0; 6],
            joint_velocities: [0.0; 6],
            joint_torques: [0.0; 6],
            motor_currents: [0.0; 6],
            motor_temperatures: [25.0; 6],
            tool_position: [0.0, 0.0, 0.0],
            tool_orientation_quat: [1.0, 0.0, 0.0, 0.0],
            cycle_time_sec: 0.0,
            vibration_rms: 0.012,
            tcp_force_n: 0.0,
            energy_watts: 320.0,
            fault_mask: 0,
        }
    }

    #[inline(always)]
    pub fn robot_id_str(&self) -> &str {
        let len = self.robot_id.iter().position(|&c| c == 0).unwrap_or(16);
        std::str::from_utf8(&self.robot_id[..len]).unwrap_or("UNKNOWN")
    }

    /// Fast validation checks for physical boundaries
    #[inline(always)]
    pub fn validate_physics(&self) -> bool {
        for &t in &self.motor_temperatures {
            if t > 120.0 || t < -10.0 {
                return false;
            }
        }
        for &v in &self.joint_velocities {
            if v.abs() > 15.0 {
                return false; // Beyond max physical rad/s limit
            }
        }
        if self.energy_watts < 0.0 || self.energy_watts > 50_000.0 {
            return false;
        }
        true
    }
}

/// Column-Oriented Telemetry Batch for high-speed vectorised analytics and Arrow export
#[derive(Debug, Default, Clone)]
pub struct TelemetryColumnBatch {
    pub timestamps: Vec<u64>,
    pub robot_ids: Vec<String>,
    pub j0_pos: Vec<f64>,
    pub j1_pos: Vec<f64>,
    pub j2_pos: Vec<f64>,
    pub j3_pos: Vec<f64>,
    pub j4_pos: Vec<f64>,
    pub j5_pos: Vec<f64>,
    pub total_energy_watts: Vec<f64>,
    pub vibration_rms: Vec<f64>,
    pub temperatures: Vec<f64>,
}

impl TelemetryColumnBatch {
    pub fn with_capacity(cap: usize) -> Self {
        Self {
            timestamps: Vec::with_capacity(cap),
            robot_ids: Vec::with_capacity(cap),
            j0_pos: Vec::with_capacity(cap),
            j1_pos: Vec::with_capacity(cap),
            j2_pos: Vec::with_capacity(cap),
            j3_pos: Vec::with_capacity(cap),
            j4_pos: Vec::with_capacity(cap),
            j5_pos: Vec::with_capacity(cap),
            total_energy_watts: Vec::with_capacity(cap),
            vibration_rms: Vec::with_capacity(cap),
            temperatures: Vec::with_capacity(cap),
        }
    }

    #[inline(always)]
    pub fn push(&mut self, record: &RobotTelemetry) {
        self.timestamps.push(record.timestamp_ns);
        self.robot_ids.push(record.robot_id_str().to_string());
        self.j0_pos.push(record.joint_positions[0]);
        self.j1_pos.push(record.joint_positions[1]);
        self.j2_pos.push(record.joint_positions[2]);
        self.j3_pos.push(record.joint_positions[3]);
        self.j4_pos.push(record.joint_positions[4]);
        self.j5_pos.push(record.joint_positions[5]);
        self.total_energy_watts.push(record.energy_watts);
        self.vibration_rms.push(record.vibration_rms);
        self.temperatures.push(record.motor_temperatures[0]);
    }

    pub fn len(&self) -> usize {
        self.timestamps.len()
    }

    pub fn is_empty(&self) -> bool {
        self.timestamps.is_empty()
    }
}

/// Thread-safe Telemetry Engine with atomic metrics
pub struct TelemetryEngine {
    ingested_count: Arc<AtomicU64>,
    dropped_count: Arc<AtomicU64>,
}

impl TelemetryEngine {
    pub fn new() -> Self {
        Self {
            ingested_count: Arc::new(AtomicU64::new(0)),
            dropped_count: Arc::new(AtomicU64::new(0)),
        }
    }

    #[inline(always)]
    pub fn ingest(&self, record: &RobotTelemetry) -> bool {
        if record.validate_physics() {
            self.ingested_count.fetch_add(1, Ordering::Relaxed);
            true
        } else {
            self.dropped_count.fetch_add(1, Ordering::Relaxed);
            false
        }
    }

    pub fn metrics(&self) -> (u64, u64) {
        (
            self.ingested_count.load(Ordering::Relaxed),
            self.dropped_count.load(Ordering::Relaxed),
        )
    }
}
