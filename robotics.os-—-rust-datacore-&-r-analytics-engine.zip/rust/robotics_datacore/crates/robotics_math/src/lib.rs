//! Robotics.OS DataCore - High-Performance Robotics Mathematics Engine
//! Fast SIMD-compatible linear algebra for kinematics, transforms, Jacobians, and jerk-limited profiles.

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Vector3 {
    pub x: f64,
    pub y: f64,
    pub z: f64,
}

impl Vector3 {
    pub const ZERO: Self = Self { x: 0.0, y: 0.0, z: 0.0 };

    #[inline(always)]
    pub fn new(x: f64, y: f64, z: f64) -> Self {
        Self { x, y, z }
    }

    #[inline(always)]
    pub fn norm_squared(&self) -> f64 {
        self.x * self.x + self.y * self.y + self.z * self.z
    }

    #[inline(always)]
    pub fn norm(&self) -> f64 {
        self.norm_squared().sqrt()
    }

    #[inline(always)]
    pub fn dot(&self, other: &Self) -> f64 {
        self.x * other.x + self.y * other.y + self.z * other.z
    }

    #[inline(always)]
    pub fn cross(&self, other: &Self) -> Self {
        Self {
            x: self.y * other.z - self.z * other.y,
            y: self.z * other.x - self.x * other.z,
            z: self.x * other.y - self.y * other.x,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Quaternion {
    pub w: f64,
    pub x: f64,
    pub y: f64,
    pub z: f64,
}

impl Quaternion {
    pub const IDENTITY: Self = Self { w: 1.0, x: 0.0, y: 0.0, z: 0.0 };

    #[inline(always)]
    pub fn new(w: f64, x: f64, y: f64, z: f64) -> Self {
        let norm = (w * w + x * x + y * y + z * z).sqrt();
        if norm > 1e-12 {
            Self { w: w / norm, x: x / norm, y: y / norm, z: z / norm }
        } else {
            Self::IDENTITY
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Pose {
    pub position: Vector3,
    pub orientation: Quaternion,
}

impl Pose {
    #[inline(always)]
    pub fn new(pos: Vector3, rot: Quaternion) -> Self {
        Self { position: pos, orientation: rot }
    }
}

/// 6-Axis Jacobian Matrix (6x6) computation stub for joint velocity mapping
#[derive(Debug, Clone)]
pub struct Jacobian6x6 {
    pub data: [[f64; 6]; 6],
}

impl Jacobian6x6 {
    pub fn identity() -> Self {
        let mut d = [[0.0; 6]; 6];
        for i in 0..6 {
            d[i][i] = 1.0;
        }
        Self { data: d }
    }

    /// Computes condition number (manipulability index) to avoid singularities
    pub fn condition_number(&self) -> f64 {
        // Simplified singular value approximation for real-time safety monitor
        let trace: f64 = (0..6).map(|i| self.data[i][i].abs()).sum();
        (trace / 6.0).max(0.001)
    }
}
