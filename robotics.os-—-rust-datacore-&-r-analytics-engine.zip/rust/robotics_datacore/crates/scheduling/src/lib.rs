//! Robotics.OS DataCore - Multi-Robot Scheduling & Factory Bottleneck Engine
//! Discrete-event stochastic simulation for line balancing, OEE, queue dynamics, and bottleneck discovery.

use std::collections::HashMap;

#[derive(Debug, Clone)]
pub struct WorkstationMetric {
    pub name: String,
    pub cycle_time_mean_sec: f64,
    pub cycle_time_std_sec: f64,
    pub utilization_pct: f64,
    pub queue_occupancy: usize,
    pub queue_capacity: usize,
    pub failure_rate_mttf_hrs: f64,
}

#[derive(Debug, Clone)]
pub struct BottleneckAnalysis {
    pub primary_bottleneck: String,
    pub bottleneck_utilization: f64,
    pub line_throughput_pph: f64,
    pub potential_gain_pph: f64,
    pub station_utilizations: HashMap<String, f64>,
}

pub struct FactoryOptimizer;

impl FactoryOptimizer {
    pub fn identify_bottleneck(stations: &[WorkstationMetric]) -> BottleneckAnalysis {
        let mut max_util = 0.0;
        let mut bottleneck_name = "None".to_string();
        let mut utilizations = HashMap::new();

        for s in stations {
            utilizations.insert(s.name.clone(), s.utilization_pct);
            if s.utilization_pct > max_util {
                max_util = s.utilization_pct;
                bottleneck_name = s.name.clone();
            }
        }

        let slowest_cycle = stations
            .iter()
            .map(|s| s.cycle_time_mean_sec)
            .fold(0.0f64, f64::max);

        let throughput_pph = if slowest_cycle > 0.0 {
            3600.0 / slowest_cycle
        } else {
            0.0
        };

        let potential_gain = if max_util > 90.0 {
            throughput_pph * 0.14 // 14% improvement by debottlenecking
        } else {
            throughput_pph * 0.04
        };

        BottleneckAnalysis {
            primary_bottleneck: bottleneck_name,
            bottleneck_utilization: max_util,
            line_throughput_pph: throughput_pph,
            potential_gain_pph: potential_gain,
            station_utilizations: utilizations,
        }
    }
}
