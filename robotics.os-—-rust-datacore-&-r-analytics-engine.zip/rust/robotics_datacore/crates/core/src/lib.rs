//! Robotics.OS DataCore - Core Traits and Shared Types
//! High-performance foundational primitives for industrial robotics telemetry and deterministic pipelines.

use std::time::{SystemTime, UNIX_EPOCH};
use thiserror::Error;

#[derive(Error, Debug)]
pub enum DataCoreError {
    #[error("Validation failed for robot {robot_id}: {reason}")]
    ValidationFailure { robot_id: String, reason: String },

    #[error("Out of order timestamp: received {received_ns} < latest {latest_ns}")]
    TimestampOrderError { received_ns: u64, latest_ns: u64 },

    #[error("Kinematics singularity or limit exceeded: {0}")]
    KinematicsLimit(String),

    #[error("Optimisation convergence error: {0}")]
    ConvergenceFailure(String),

    #[error("IO / Storage error: {0}")]
    StorageError(String),
}

pub type Result<T> = std::result::Result<T, DataCoreError>;

#[inline(always)]
pub fn current_epoch_nanos() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_nanos() as u64
}

/// Metric quality flags for sensor assurance
#[repr(u8)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum QualityFlag {
    Good = 0,
    Degraded = 1,
    OutOfRange = 2,
    StaleSensor = 3,
    Corrupted = 4,
}

/// Generic trait for streaming time series buffers
pub trait TimeSeriesBuffer<T> {
    fn push(&mut self, item: T);
    fn len(&self) -> usize;
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
    fn clear(&mut self);
}
