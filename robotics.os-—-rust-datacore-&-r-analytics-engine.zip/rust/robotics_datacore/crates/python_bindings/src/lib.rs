//! Robotics.OS DataCore - Python C-ABI / PyO3 Interoperability Bindings
//! Exposes the high-performance Rust core to Python orchestrator and digital twin services.

use pyo3::prelude::*;

#[pyclass]
pub struct PyTrajectoryOptimizer;

#[pymethods]
impl PyTrajectoryOptimizer {
    #[new]
    pub fn new() -> Self {
        Self
    }

    pub fn compute_s_curve(
        &self,
        start_x: f64,
        start_y: f64,
        start_z: f64,
        target_x: f64,
        target_y: f64,
        target_z: f64,
        max_vel: f64,
        max_acc: f64,
    ) -> PyResult<(f64, f64, f64)> {
        let dx = target_x - start_x;
        let dy = target_y - start_y;
        let dz = target_z - start_z;
        let dist = (dx * dx + dy * dy + dz * dz).sqrt();
        let duration = (dist / max_vel.max(0.1)) + (max_vel / max_acc.max(0.1));
        let energy = 150.0 * duration + 0.5 * 25.0 * max_vel * max_vel;
        Ok((duration, dist, energy))
    }
}

#[pyclass]
pub struct PyFactoryOptimizer;

#[pymethods]
impl PyFactoryOptimizer {
    #[new]
    pub fn new() -> Self {
        Self
    }

    pub fn compute_line_balance(&self, cycle_times: Vec<f64>) -> PyResult<(f64, usize)> {
        let max_cycle = cycle_times.iter().fold(0.0f64, |a, &b| a.max(b));
        let bottleneck_idx = cycle_times
            .iter()
            .position(|&x| (x - max_cycle).abs() < 1e-6)
            .unwrap_or(0);
        let throughput = if max_cycle > 0.0 { 3600.0 / max_cycle } else { 0.0 };
        Ok((throughput, bottleneck_idx))
    }
}

#[pymodule]
fn robotics_datacore(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PyTrajectoryOptimizer>()?;
    m.add_class::<PyFactoryOptimizer>()?;
    Ok(())
}
