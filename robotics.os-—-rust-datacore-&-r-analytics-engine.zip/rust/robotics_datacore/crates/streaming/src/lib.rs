//! Robotics.OS DataCore - High-Performance Streaming Aggregation & Online Statistics
//! Implements constant-memory Welford variance, rolling windows, exponential smoothing, and anomaly scoring.

use std::collections::VecDeque;

/// Online accumulator using Welford's algorithm for numerically stable variance in single-pass
#[derive(Debug, Clone, Default)]
pub struct WelfordAccumulator {
    count: usize,
    mean: f64,
    m2: f64,
    min_val: f64,
    max_val: f64,
}

impl WelfordAccumulator {
    pub fn new() -> Self {
        Self {
            count: 0,
            mean: 0.0,
            m2: 0.0,
            min_val: f64::INFINITY,
            max_val: f64::NEG_INFINITY,
        }
    }

    #[inline(always)]
    pub fn update(&mut self, x: f64) {
        self.count += 1;
        let delta = x - self.mean;
        self.mean += delta / (self.count as f64);
        let delta2 = x - self.mean;
        self.m2 += delta * delta2;

        if x < self.min_val {
            self.min_val = x;
        }
        if x > self.max_val {
            self.max_val = x;
        }
    }

    #[inline(always)]
    pub fn mean(&self) -> f64 {
        if self.count == 0 { 0.0 } else { self.mean }
    }

    #[inline(always)]
    pub fn variance(&self) -> f64 {
        if self.count < 2 { 0.0 } else { self.m2 / ((self.count - 1) as f64) }
    }

    #[inline(always)]
    pub fn std_dev(&self) -> f64 {
        self.variance().sqrt()
    }

    #[inline(always)]
    pub fn min(&self) -> f64 {
        if self.count == 0 { 0.0 } else { self.min_val }
    }

    #[inline(always)]
    pub fn max(&self) -> f64 {
        if self.count == 0 { 0.0 } else { self.max_val }
    }

    pub fn count(&self) -> usize {
        self.count
    }
}

/// Rolling Window Statistics Filter (fixed size window)
#[derive(Debug, Clone)]
pub struct RollingWindow {
    capacity: usize,
    buffer: VecDeque<f64>,
    sum: f64,
}

impl RollingWindow {
    pub fn new(capacity: usize) -> Self {
        Self {
            capacity: capacity.max(1),
            buffer: VecDeque::with_capacity(capacity),
            sum: 0.0,
        }
    }

    #[inline(always)]
    pub fn push(&mut self, val: f64) {
        if self.buffer.len() == self.capacity {
            if let Some(old) = self.buffer.pop_front() {
                self.sum -= old;
            }
        }
        self.buffer.push_back(val);
        self.sum += val;
    }

    #[inline(always)]
    pub fn moving_average(&self) -> f64 {
        if self.buffer.is_empty() {
            0.0
        } else {
            self.sum / (self.buffer.len() as f64)
        }
    }

    #[inline(always)]
    pub fn rate_of_change(&self) -> f64 {
        if self.buffer.len() < 2 {
            return 0.0;
        }
        let newest = *self.buffer.back().unwrap();
        let oldest = *self.buffer.front().unwrap();
        (newest - oldest) / (self.buffer.len() as f64)
    }

    /// Approximate anomaly z-score against rolling window
    #[inline(always)]
    pub fn compute_anomaly_zscore(&self, current: f64) -> f64 {
        let n = self.buffer.len();
        if n < 3 {
            return 0.0;
        }
        let mean = self.moving_average();
        let mut variance = 0.0;
        for &item in &self.buffer {
            let diff = item - mean;
            variance += diff * diff;
        }
        let std_dev = (variance / ((n - 1) as f64)).sqrt();
        if std_dev < 1e-9 {
            return 0.0;
        }
        ((current - mean) / std_dev).abs()
    }
}
