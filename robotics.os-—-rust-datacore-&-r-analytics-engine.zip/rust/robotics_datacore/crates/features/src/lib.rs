//! Robotics.OS DataCore - Unified Feature Store Engine
//! Stores, updates, and serves real-time engineered signals across robots and factory workcells.

use std::collections::HashMap;
use std::sync::RwLock;

#[derive(Debug, Clone)]
pub struct FeatureRecord {
    pub name: String,
    pub asset_id: String,
    pub timestamp_ns: u64,
    pub window_seconds: u32,
    pub value: f64,
    pub quality_flag: u8,
}

pub struct FeatureStore {
    features: RwLock<HashMap<String, FeatureRecord>>,
}

impl FeatureStore {
    pub fn new() -> Self {
        Self {
            features: RwLock::new(HashMap::new()),
        }
    }

    pub fn set_feature(&self, key: &str, record: FeatureRecord) {
        let mut map = self.features.write().unwrap();
        map.insert(key.to_string(), record);
    }

    pub fn get_feature(&self, key: &str) -> Option<FeatureRecord> {
        let map = self.features.read().unwrap();
        map.get(key).cloned()
    }
}
