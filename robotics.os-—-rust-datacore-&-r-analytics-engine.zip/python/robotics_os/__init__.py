"""
Robotics.OS - Python Robotics Operating System, Digital Twin, and Closed-Loop Orchestrator.
Integrates Rust DataCore and R Analytics into an Industry 4.0 architecture.
"""

__version__ = "0.4.2"
