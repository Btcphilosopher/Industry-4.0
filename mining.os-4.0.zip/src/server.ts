import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';
import {GoogleGenAI} from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
const angularApp = new AngularNodeAppEngine();

app.use(express.json());

// Lazy Google GenAI Client
let genAIClient: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI | null {
  const apiKey = process.env['GEMINI_API_KEY'];
  if (!apiKey) return null;
  if (!genAIClient) {
    genAIClient = new GoogleGenAI({ apiKey });
  }
  return genAIClient;
}

// MINING.OS 4.0 Industrial Decision & Advisor API
app.post('/api/ai/advisor', async (req, res) => {
  try {
    const { prompt, context } = req.body;
    const ai = getGenAI();

    if (ai) {
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `You are MINING.OS 4.0's Autonomous Industrial Intelligence Engine and Chief Mining Engineer.
Analyze the following live digital twin state, machinery telemetry, and geological constraints.
Provide structured, highly technical, and immediately actionable advice adhering to mining safety protocols (AS/NZS 4801, MSHA, ISO 14001).

Current Site & Machine Context:
${JSON.stringify(context || {}, null, 2)}

Operator / System Query:
${prompt || 'Provide a comprehensive shift operational summary, bottleneck analysis, and dispatch optimization advisory.'}

Structure your response with clear technical sections:
1. Operational Overview & Bottleneck Diagnostic
2. Machine Health & Predictive Maintenance Advisory
3. Autonomous Haulage & Dispatch Optimisation
4. Geological & Stockpile Blending Compliance
5. Safety Interlocks & Energy Recommendations`,
      });

      return res.json({
        success: true,
        source: 'gemini-2.5-flash',
        advice: response.text,
      });
    }

    // High-fidelity deterministic industrial fallback
    const site = context?.site?.name || 'Pilbara Iron Ridge Complex';
    const mineral = context?.site?.mineralLabel || 'Iron Ore';
    const tph = context?.tph || 4950;
    const oee = context?.fleetOee || 88.2;
    
    return res.json({
      success: true,
      source: 'deterministic-mining-engine',
      advice: `### MINING.OS 4.0 Autonomous Operations Briefing (${site} - ${mineral})

#### 1. Operational Overview & Bottleneck Diagnostic
- **Real-Time Throughput**: Operating at **${tph} TPH** (Target: ${context?.targetTph || 5400} TPH).
- **Fleet OEE**: **${oee}%** with 94.2% mechanical availability.
- **Identified Bottlenecks**: High cycle congestion identified at Ramp Switch 2 (+8.2% gradient) due to loaded CAT 797F convoy. Crusher infeed bin buffer sitting at 78% capacity.

#### 2. Machine Health & Predictive Maintenance Advisory
- **EXC-02 (Liebherr R9800)**: Hydraulic fluid temperature elevated at **88.6°C** (z-score 3.42). Derated hydraulic pump command recommended to prevent seal degradation.
- **DRL-01 (Sandvik DR412i)**: Penetration rate stabilized at 1.4 m/min; rotary head vibration normalized following pulldown pressure damping.
- **TRK-201 (e-Hauler)**: Downhill regenerative braking capturing +42.0 kWh per cycle; battery SOC stable at 68.5%.

#### 3. Autonomous Haulage & Dispatch Optimisation
- **Dispatch Action**: Recommending divert of **TRK-102** to Bench 03 West Face. Shovel SHV-01 queue reduced to zero trucks, preventing excavator starvation.
- **Cycle Time Improvement**: Dynamic dispatch adjustments project a +180 TPH throughput gain with 4.2 minutes reduction in aggregate queue latency.

#### 4. Geological & Stockpile Blending Compliance
- **Silo 1 Blend Ratio**: High-Grade ROM (55%) + Medium-Grade (35%) + Sweetener Blend (10%) achieving target **62.4% Fe** with silica impurity contained at 2.8% (Target <4.2%).

#### 5. Safety Interlocks & Energy Recommendations
- All autonomous haul trajectories validated against dynamic slope stability and wet-braking envelopes.
- Peak power shaving active: Staggered battery fast-charging scheduled outside SAG mill startup windows.`
    });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Industrial advisory engine error';
    return res.status(500).json({
      success: false,
      error: message,
    });
  }
});

// Telemetry Ingestion Endpoint for Mock SCADA/PLCs
app.post('/api/telemetry/ingest', (req, res) => {
  const packet = req.body;
  res.json({
    status: 'ACK',
    receivedAt: Date.now(),
    packetCount: Array.isArray(packet) ? packet.length : 1,
  });
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`MINING.OS 4.0 Server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);

