import { ChangeDetectionStrategy, Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MiningEngineService } from '../../services/mining-engine.service';
import { WhatIfScenarioInput } from '../../models/mining-os.types';

@Component({
  selector: 'app-what-if-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Header -->
      <div class="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-[#0a0a0a] p-4 rounded-sm border border-[#222]">
        <div>
          <h2 class="text-lg font-black tracking-tight text-white uppercase flex items-center gap-2">
            <mat-icon class="text-[#F27D26]">tune</mat-icon>
            What-If Scenario Simulator & Operations Research
          </h2>
          <p class="text-xs text-zinc-400 font-mono">
            Parametric Sensitivity Analysis, Fleet Mix Sizing, Fuel Cost Shock & Emission Forecasting
          </p>
        </div>

        <!-- Presets -->
        <div class="flex flex-wrap items-center gap-1.5 bg-[#121212] p-1.5 rounded-sm border border-[#262626] text-xs font-mono">
          <button (click)="applyPreset('baseline')" class="px-2.5 py-1 rounded-sm uppercase font-bold hover:bg-[#222] text-zinc-300 transition-colors cursor-pointer">
            Baseline
          </button>
          <button (click)="applyPreset('full_ev')" class="px-2.5 py-1 rounded-sm uppercase font-bold hover:bg-[#222] text-purple-300 transition-colors cursor-pointer">
            100% Electric
          </button>
          <button (click)="applyPreset('high_fuel')" class="px-2.5 py-1 rounded-sm uppercase font-bold hover:bg-[#222] text-[#F27D26] transition-colors cursor-pointer">
            Fuel Spike ($2.20)
          </button>
          <button (click)="applyPreset('max_throughput')" class="px-2.5 py-1 rounded-sm uppercase font-bold hover:bg-[#222] text-emerald-300 transition-colors cursor-pointer">
            Max Push
          </button>
        </div>
      </div>

      <!-- Simulation Outcomes Dashboard -->
      <div class="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <div class="bg-[#0a0a0a] border border-[#222] p-4 rounded-sm flex flex-col justify-between">
          <span class="text-[10px] font-mono uppercase tracking-widest font-bold text-zinc-500">Projected Output</span>
          <div class="text-2xl sm:text-3xl font-black font-mono text-[#F27D26] mt-2 leading-none">
            {{ results().projectedTotalTonnes.toLocaleString() }} <span class="text-xs text-zinc-500 font-sans font-normal">t</span>
          </div>
          <span class="text-[10px] text-zinc-500 font-mono mt-2">{{ results().projectedTph }} TPH Average</span>
        </div>

        <div class="bg-[#0a0a0a] border border-[#222] p-4 rounded-sm flex flex-col justify-between">
          <span class="text-[10px] font-mono uppercase tracking-widest font-bold text-zinc-500">Unit Mining Cost</span>
          <div class="text-2xl sm:text-3xl font-black font-mono text-emerald-400 mt-2 leading-none">
            \${{ results().projectedCostPerTonne.toFixed(2) }} <span class="text-xs text-zinc-500 font-sans font-normal">/ t</span>
          </div>
          <span class="text-[10px] text-zinc-500 font-mono mt-2">Total: \${{ (results().projectedTotalCost / 1000).toFixed(1) }}k</span>
        </div>

        <div class="bg-[#0a0a0a] border border-[#222] p-4 rounded-sm flex flex-col justify-between">
          <span class="text-[10px] font-mono uppercase tracking-widest font-bold text-zinc-500">Fleet Utilisation</span>
          <div class="text-2xl sm:text-3xl font-black font-mono text-cyan-400 mt-2 leading-none">
            {{ results().projectedFleetUtilisationPct.toFixed(1) }}%
          </div>
          <span class="text-[10px] text-zinc-500 font-mono mt-2">Bottleneck: {{ results().projectedPlantBottleneckRiskPct.toFixed(1) }}%</span>
        </div>

        <div class="bg-[#0a0a0a] border border-[#222] p-4 rounded-sm flex flex-col justify-between">
          <span class="text-[10px] font-mono uppercase tracking-widest font-bold text-zinc-500">Energy & Emissions</span>
          <div class="text-2xl sm:text-3xl font-black font-mono text-purple-400 mt-2 leading-none">
            {{ results().projectedEnergyKwhPerTonne.toFixed(2) }} <span class="text-xs text-zinc-500 font-sans font-normal">kWh/t</span>
          </div>
          <span [class.text-emerald-400]="results().comparisonVsBaselinePct.emissions < 0" [class.text-rose-400]="results().comparisonVsBaselinePct.emissions >= 0" class="text-[10px] font-mono font-black mt-2">
            {{ results().comparisonVsBaselinePct.emissions > 0 ? '+' : '' }}{{ results().comparisonVsBaselinePct.emissions.toFixed(1) }}% vs Base
          </span>
        </div>

        <div class="bg-[#0a0a0a] border border-[#222] p-4 rounded-sm col-span-2 lg:col-span-1 flex flex-col justify-between">
          <span class="text-[10px] font-mono uppercase tracking-widest font-bold text-zinc-500">Shift Profit</span>
          <div class="text-2xl sm:text-3xl font-black font-mono text-emerald-400 mt-2 leading-none">
            \${{ results().estimatedProfitability.toFixed(2) }}M
          </div>
          <span class="text-[10px] text-zinc-500 font-mono mt-2 uppercase">Normalized Price</span>
        </div>
      </div>

      <!-- Parametric Sliders Grid -->
      <div class="bg-[#0a0a0a] border border-[#222] rounded-sm p-5 shadow-xl space-y-6">
        <h3 class="text-xs font-black font-mono text-white flex items-center gap-2 uppercase tracking-wider border-b border-[#222] pb-3">
          <mat-icon class="text-[#F27D26] text-base">sliders</mat-icon>
          Adjust Scenario Parameters & Physical Constraints
        </h3>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <!-- Diesel Truck Fleet -->
          <div class="space-y-2">
            <div class="flex justify-between text-xs font-mono">
              <span class="text-zinc-400 uppercase font-bold text-[11px]">Diesel Haulers:</span>
              <span class="text-white font-black">{{ params().truckCountDiesel }} trucks</span>
            </div>
            <input
              type="range"
              min="0"
              max="16"
              [value]="params().truckCountDiesel"
              (input)="updateParam('truckCountDiesel', +$any($event.target).value)"
              class="w-full h-1.5 bg-[#1e1e1e] rounded-none appearance-none cursor-pointer accent-[#F27D26]"
            />
          </div>

          <!-- Electric Truck Fleet -->
          <div class="space-y-2">
            <div class="flex justify-between text-xs font-mono">
              <span class="text-zinc-400 uppercase font-bold text-[11px]">Electric e-Haulers:</span>
              <span class="text-purple-400 font-black">{{ params().truckCountElectric }} trucks</span>
            </div>
            <input
              type="range"
              min="0"
              max="12"
              [value]="params().truckCountElectric"
              (input)="updateParam('truckCountElectric', +$any($event.target).value)"
              class="w-full h-1.5 bg-[#1e1e1e] rounded-none appearance-none cursor-pointer accent-purple-500"
            />
          </div>

          <!-- Active Shovels -->
          <div class="space-y-2">
            <div class="flex justify-between text-xs font-mono">
              <span class="text-zinc-400 uppercase font-bold text-[11px]">Active Shovels:</span>
              <span class="text-[#F27D26] font-black">{{ params().excavatorCount }} units</span>
            </div>
            <input
              type="range"
              min="1"
              max="5"
              [value]="params().excavatorCount"
              (input)="updateParam('excavatorCount', +$any($event.target).value)"
              class="w-full h-1.5 bg-[#1e1e1e] rounded-none appearance-none cursor-pointer accent-[#F27D26]"
            />
          </div>

          <!-- Diesel Fuel Price -->
          <div class="space-y-2">
            <div class="flex justify-between text-xs font-mono">
              <span class="text-zinc-400 uppercase font-bold text-[11px]">Diesel Price ($/L):</span>
              <span class="text-white font-black">\${{ params().fuelPricePerLiter.toFixed(2) }}</span>
            </div>
            <input
              type="range"
              min="0.80"
              max="2.50"
              step="0.05"
              [value]="params().fuelPricePerLiter"
              (input)="updateParam('fuelPricePerLiter', +$any($event.target).value)"
              class="w-full h-1.5 bg-[#1e1e1e] rounded-none appearance-none cursor-pointer accent-[#F27D26]"
            />
          </div>

          <!-- Electricity Price -->
          <div class="space-y-2">
            <div class="flex justify-between text-xs font-mono">
              <span class="text-zinc-400 uppercase font-bold text-[11px]">Electricity ($/kWh):</span>
              <span class="text-white font-black">\${{ params().electricityPricePerKwh.toFixed(2) }}</span>
            </div>
            <input
              type="range"
              min="0.05"
              max="0.40"
              step="0.01"
              [value]="params().electricityPricePerKwh"
              (input)="updateParam('electricityPricePerKwh', +$any($event.target).value)"
              class="w-full h-1.5 bg-[#1e1e1e] rounded-none appearance-none cursor-pointer accent-purple-500"
            />
          </div>

          <!-- Ore Grade Factor -->
          <div class="space-y-2">
            <div class="flex justify-between text-xs font-mono">
              <span class="text-zinc-400 uppercase font-bold text-[11px]">Ore Grade Multiplier:</span>
              <span class="text-emerald-400 font-black">{{ params().oreGradeFactor.toFixed(2) }}x</span>
            </div>
            <input
              type="range"
              min="0.70"
              max="1.40"
              step="0.05"
              [value]="params().oreGradeFactor"
              (input)="updateParam('oreGradeFactor', +$any($event.target).value)"
              class="w-full h-1.5 bg-[#1e1e1e] rounded-none appearance-none cursor-pointer accent-emerald-500"
            />
          </div>

          <!-- Road Surface Resistance -->
          <div class="space-y-2">
            <div class="flex justify-between text-xs font-mono">
              <span class="text-zinc-400 uppercase font-bold text-[11px]">Rolling Resistance:</span>
              <span class="text-white font-black">{{ params().roadRoughnessFactor.toFixed(2) }}x</span>
            </div>
            <input
              type="range"
              min="0.80"
              max="1.50"
              step="0.05"
              [value]="params().roadRoughnessFactor"
              (input)="updateParam('roadRoughnessFactor', +$any($event.target).value)"
              class="w-full h-1.5 bg-[#1e1e1e] rounded-none appearance-none cursor-pointer accent-cyan-500"
            />
          </div>

          <!-- Shift Duration -->
          <div class="space-y-2">
            <div class="flex justify-between text-xs font-mono">
              <span class="text-zinc-400 uppercase font-bold text-[11px]">Shift Length:</span>
              <span class="text-white font-black">{{ params().shiftDurationHours }} Hours</span>
            </div>
            <input
              type="range"
              min="8"
              max="12"
              step="1"
              [value]="params().shiftDurationHours"
              (input)="updateParam('shiftDurationHours', +$any($event.target).value)"
              class="w-full h-1.5 bg-[#1e1e1e] rounded-none appearance-none cursor-pointer accent-zinc-400"
            />
          </div>
        </div>
      </div>
    </div>
  `,
})
export class WhatIfViewComponent {
  readonly engine = inject(MiningEngineService);

  readonly params = signal<WhatIfScenarioInput>({
    truckCountDiesel: 5,
    truckCountElectric: 2,
    excavatorCount: 2,
    targetTph: 4200,
    fuelPricePerLiter: 1.45,
    electricityPricePerKwh: 0.14,
    oreGradeFactor: 1.0,
    plantCapacityTph: 5500,
    roadRoughnessFactor: 1.0,
    shiftDurationHours: 12,
  });

  results = computed(() => {
    return this.engine.runWhatIfSimulation(this.params());
  });

  updateParam<K extends keyof WhatIfScenarioInput>(key: K, value: WhatIfScenarioInput[K]) {
    this.params.update((p) => ({ ...p, [key]: value }));
  }

  applyPreset(preset: 'baseline' | 'full_ev' | 'high_fuel' | 'max_throughput') {
    if (preset === 'baseline') {
      this.params.set({
        truckCountDiesel: 5,
        truckCountElectric: 2,
        excavatorCount: 2,
        targetTph: 4200,
        fuelPricePerLiter: 1.45,
        electricityPricePerKwh: 0.14,
        oreGradeFactor: 1.0,
        plantCapacityTph: 5500,
        roadRoughnessFactor: 1.0,
        shiftDurationHours: 12,
      });
    } else if (preset === 'full_ev') {
      this.params.set({
        truckCountDiesel: 0,
        truckCountElectric: 8,
        excavatorCount: 2,
        targetTph: 4200,
        fuelPricePerLiter: 1.45,
        electricityPricePerKwh: 0.14,
        oreGradeFactor: 1.0,
        plantCapacityTph: 5500,
        roadRoughnessFactor: 0.9,
        shiftDurationHours: 12,
      });
    } else if (preset === 'high_fuel') {
      this.params.set({
        truckCountDiesel: 5,
        truckCountElectric: 2,
        excavatorCount: 2,
        targetTph: 4200,
        fuelPricePerLiter: 2.20,
        electricityPricePerKwh: 0.14,
        oreGradeFactor: 1.0,
        plantCapacityTph: 5500,
        roadRoughnessFactor: 1.0,
        shiftDurationHours: 12,
      });
    } else if (preset === 'max_throughput') {
      this.params.set({
        truckCountDiesel: 9,
        truckCountElectric: 4,
        excavatorCount: 4,
        targetTph: 5400,
        fuelPricePerLiter: 1.45,
        electricityPricePerKwh: 0.14,
        oreGradeFactor: 1.15,
        plantCapacityTph: 5500,
        roadRoughnessFactor: 0.85,
        shiftDurationHours: 12,
      });
    }
  }
}
