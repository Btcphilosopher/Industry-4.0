import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MiningEngineService } from '../../services/mining-engine.service';

@Component({
  selector: 'app-routes-energy-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Header -->
      <div class="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-[#0a0a0a] p-4 rounded-sm border border-[#222]">
        <div>
          <h2 class="text-lg font-black tracking-tight text-white uppercase flex items-center gap-2">
            <mat-icon class="text-purple-400">bolt</mat-icon>
            Mine Road Network & Autonomous Electric Fleet Energy Engine
          </h2>
          <p class="text-xs text-zinc-400 font-mono">
            Gradient Resistance Physics, Regenerative Haulage Recovery & 2.4 MW Ultra-Fast Charging Queue
          </p>
        </div>

        <div class="flex items-center gap-2 bg-[#121212] px-3 py-1.5 rounded-sm border border-[#262626] text-xs font-mono text-zinc-300">
          <span class="w-2 h-2 rounded-full bg-purple-400 animate-pulse"></span>
          Substation Peak Shaving: <strong class="text-emerald-400">18.4 MW / 22.0 MW Cap</strong>
        </div>
      </div>

      <!-- Energy KPI Cards -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="bg-[#0a0a0a] border border-[#222] p-4 rounded-sm flex flex-col justify-between">
          <span class="text-[10px] font-mono uppercase tracking-widest font-bold text-zinc-500">Regenerative Recovery</span>
          <div class="text-2xl sm:text-3xl font-black font-mono text-purple-400 mt-2 leading-none">
            +1,840 <span class="text-xs text-zinc-500 font-sans font-normal">kWh</span>
          </div>
          <span class="text-[10px] text-zinc-500 font-mono mt-2">Downhill (-8.5% Grade)</span>
        </div>

        <div class="bg-[#0a0a0a] border border-[#222] p-4 rounded-sm flex flex-col justify-between">
          <span class="text-[10px] font-mono uppercase tracking-widest font-bold text-zinc-500">Diesel Fuel Saved</span>
          <div class="text-2xl sm:text-3xl font-black font-mono text-emerald-400 mt-2 leading-none">
            1,240 <span class="text-xs text-zinc-500 font-sans font-normal">Liters</span>
          </div>
          <span class="text-[10px] text-zinc-500 font-mono mt-2">CO2 Offset: 3.32 Tonnes</span>
        </div>

        <div class="bg-[#0a0a0a] border border-[#222] p-4 rounded-sm flex flex-col justify-between">
          <span class="text-[10px] font-mono uppercase tracking-widest font-bold text-zinc-500">Fleet Battery SOH</span>
          <div class="text-2xl sm:text-3xl font-black font-mono text-cyan-400 mt-2 leading-none">
            98.2%
          </div>
          <span class="text-[10px] text-zinc-500 font-mono mt-2">Thermal Guard: 45°C Max</span>
        </div>

        <div class="bg-[#0a0a0a] border border-[#222] p-4 rounded-sm flex flex-col justify-between">
          <span class="text-[10px] font-mono uppercase tracking-widest font-bold text-zinc-500">Energy Cost / Tonne</span>
          <div class="text-2xl sm:text-3xl font-black font-mono text-[#F27D26] mt-2 leading-none">
            $0.42 <span class="text-xs text-zinc-500 font-sans font-normal">/ t</span>
          </div>
          <span class="text-[10px] text-zinc-500 font-mono mt-2">Electricity: $0.14 / kWh</span>
        </div>
      </div>

      <!-- Electric Vehicle Charging Station Management -->
      <div class="bg-[#0a0a0a] border border-[#222] rounded-sm p-4 shadow-xl space-y-4">
        <div class="flex items-center justify-between border-b border-[#222] pb-3">
          <h3 class="text-xs font-black font-mono text-white flex items-center gap-2 uppercase tracking-wider">
            <mat-icon class="text-purple-400 text-base">ev_station</mat-icon>
            Autonomous Megawatt EV Fast-Charging Bays
          </h3>
          <span class="text-xs font-mono text-zinc-500 uppercase">Total Output: 4 x 600 kW = 2.4 MW</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-4 gap-3">
          <!-- Bay 1 -->
          <div class="bg-[#121212] p-3.5 rounded-sm border border-[#222] space-y-2">
            <div class="flex justify-between items-center text-xs font-mono">
              <span class="font-bold text-white uppercase">BAY-01 (600 kW)</span>
              <span class="px-1.5 py-0.5 rounded-sm text-[9px] font-bold uppercase bg-[#1c1c1c] text-zinc-400 border border-[#333]">STANDBY</span>
            </div>
            <div class="text-xs font-mono text-zinc-400">Ready for dispatch</div>
            <div class="w-full h-1 bg-[#1e1e1e] rounded-none"></div>
            <div class="text-[10px] font-mono text-zinc-500">Power draw: 0 kW</div>
          </div>

          <!-- Bay 2 -->
          <div class="bg-[#121212] p-3.5 rounded-sm border border-purple-500/40 space-y-2">
            <div class="flex justify-between items-center text-xs font-mono">
              <span class="font-bold text-white uppercase">BAY-02 (600 kW)</span>
              <span class="px-2 py-0.5 rounded-sm text-[9px] font-bold uppercase bg-purple-950/60 text-purple-300 border border-purple-500/40">CHARGING</span>
            </div>
            <div class="text-xs font-mono text-zinc-200 font-bold">TRK-203 (e-Hauler)</div>
            <div class="w-full h-1.5 bg-[#1e1e1e] rounded-none overflow-hidden">
              <div class="h-full bg-purple-500" style="width: 78%"></div>
            </div>
            <div class="flex justify-between text-[10px] font-mono text-zinc-400 font-bold">
              <span>SOC: 78% / 85% Target</span>
              <span class="text-purple-400">12 min left</span>
            </div>
          </div>

          <!-- Bay 3 -->
          <div class="bg-[#121212] p-3.5 rounded-sm border border-[#222] space-y-2">
            <div class="flex justify-between items-center text-xs font-mono">
              <span class="font-bold text-white uppercase">BAY-03 (600 kW)</span>
              <span class="px-1.5 py-0.5 rounded-sm text-[9px] font-bold uppercase bg-[#1c1c1c] text-zinc-400 border border-[#333]">STANDBY</span>
            </div>
            <div class="text-xs font-mono text-zinc-400">Ready for dispatch</div>
            <div class="w-full h-1 bg-[#1e1e1e] rounded-none"></div>
            <div class="text-[10px] font-mono text-zinc-500">Power draw: 0 kW</div>
          </div>

          <!-- Bay 4 -->
          <div class="bg-[#121212] p-3.5 rounded-sm border border-[#222] space-y-2">
            <div class="flex justify-between items-center text-xs font-mono">
              <span class="font-bold text-white uppercase">BAY-04 (600 kW)</span>
              <span class="px-1.5 py-0.5 rounded-sm text-[9px] font-bold uppercase bg-[#1c1c1c] text-zinc-400 border border-[#333]">STANDBY</span>
            </div>
            <div class="text-xs font-mono text-zinc-400">Ready for dispatch</div>
            <div class="w-full h-1 bg-[#1e1e1e] rounded-none"></div>
            <div class="text-[10px] font-mono text-zinc-500">Power draw: 0 kW</div>
          </div>
        </div>
      </div>

      <!-- Road Graph Topology Table -->
      <div class="bg-[#0a0a0a] border border-[#222] rounded-sm p-4 shadow-xl">
        <h3 class="text-xs font-black font-mono text-white mb-3 flex items-center gap-2 uppercase tracking-wider border-b border-[#222] pb-3">
          <mat-icon class="text-[#F27D26] text-base">alt_route</mat-icon>
          Mine Haulage Graph Segments & Physical Resistance Properties
        </h3>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs font-mono">
            <thead>
              <tr class="border-b border-[#222] text-zinc-500 uppercase font-black text-[10px] tracking-wider">
                <th class="pb-2.5">Segment</th>
                <th class="pb-2.5">From Node</th>
                <th class="pb-2.5">To Node</th>
                <th class="pb-2.5">Distance</th>
                <th class="pb-2.5">Gradient (%)</th>
                <th class="pb-2.5">Speed Limit</th>
                <th class="pb-2.5">Road Surface Quality</th>
                <th class="pb-2.5">Regen Brake Active</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#1e1e1e]">
              @for (edge of engine.roadEdges(); track edge.id) {
                <tr class="hover:bg-[#141414] transition-colors">
                  <td class="py-2.5 text-[#F27D26] font-black">{{ edge.id }}</td>
                  <td class="py-2.5 text-white font-bold">{{ edge.fromNodeId }}</td>
                  <td class="py-2.5 text-white font-bold">{{ edge.toNodeId }}</td>
                  <td class="py-2.5 text-zinc-400">{{ edge.distanceMeters }} m</td>
                  <td class="py-2.5">
                    <span [class.text-[#F27D26]]="edge.gradientPct > 5" [class.text-cyan-400]="edge.gradientPct < 0" class="font-bold">
                      {{ edge.gradientPct > 0 ? '+' : '' }}{{ edge.gradientPct }}%
                    </span>
                  </td>
                  <td class="py-2.5 text-zinc-300">{{ edge.speedLimitKmh }} km/h</td>
                  <td class="py-2.5 text-emerald-400 font-bold">{{ (edge.surfaceConditionIndex * 100).toFixed(0) }}% (Graded)</td>
                  <td class="py-2.5">
                    @if (edge.regenerativeAllowed) {
                      <span class="px-2 py-0.5 rounded-sm text-[9px] font-bold uppercase bg-purple-950/60 text-purple-300 border border-purple-500/40">
                        YES (-kWh)
                      </span>
                    } @else {
                      <span class="text-zinc-600">NO</span>
                    }
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class RoutesEnergyViewComponent {
  readonly engine = inject(MiningEngineService);
}
