import { ChangeDetectionStrategy, Component, input, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MachineTelemetry } from '../../models/mining-os.types';

@Component({
  selector: 'app-telemetry-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    @if (machine(); as m) {
      <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
        <div class="bg-[#0a0a0a] border border-[#222] rounded-sm w-full max-w-3xl max-h-[90vh] overflow-hidden shadow-2xl flex flex-col">
          <!-- Modal Header -->
          <div class="px-6 py-4 bg-[#121212] border-b border-[#222] flex items-center justify-between">
            <div class="flex items-center gap-3">
              <div class="w-10 h-10 rounded-sm bg-[#1c1c1c] border border-[#333] flex items-center justify-center text-[#F27D26] font-bold">
                <mat-icon>{{ m.type.startsWith('haul_truck') ? 'local_shipping' : 'construction' }}</mat-icon>
              </div>
              <div>
                <div class="flex items-center gap-2">
                  <h3 class="text-base font-black font-mono text-white tracking-tight">{{ m.machineId }}</h3>
                  <span class="text-xs text-zinc-400 font-mono">({{ m.machineName }})</span>
                  <span class="px-2 py-0.5 rounded-sm text-[9px] font-mono font-bold uppercase bg-emerald-950/60 text-emerald-300 border border-emerald-500/30">
                    {{ m.status.replace('_', ' ') }}
                  </span>
                </div>
                <div class="text-[11px] text-zinc-500 font-mono mt-0.5">
                  Coordinates: X: {{ m.x.toFixed(1) }}, Y: {{ m.y.toFixed(1) }}, Z: {{ m.z.toFixed(1) }}m
                </div>
              </div>
            </div>

            <button
              (click)="closed.emit()"
              class="p-2 rounded-sm text-zinc-400 hover:text-white hover:bg-[#222] transition-colors cursor-pointer"
            >
              <mat-icon>close</mat-icon>
            </button>
          </div>

          <!-- Sensor Matrix Content -->
          <div class="p-6 overflow-y-auto space-y-6">
            <!-- Top Health Summary -->
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
              <div class="bg-[#121212] p-3.5 rounded-sm border border-[#222]">
                <span class="text-zinc-500 text-[10px] uppercase font-bold tracking-wider block">PAYLOAD UTIL</span>
                <span class="text-white font-black text-sm block mt-1">{{ m.currentPayloadTonnes }} / {{ m.maxPayloadTonnes }} t</span>
                <div class="w-full h-1 bg-[#1e1e1e] rounded-none mt-2 overflow-hidden">
                  <div class="h-full bg-[#F27D26]" [style.width.%]="(m.currentPayloadTonnes / m.maxPayloadTonnes) * 100"></div>
                </div>
              </div>

              <div class="bg-[#121212] p-3.5 rounded-sm border border-[#222]">
                <span class="text-zinc-500 text-[10px] uppercase font-bold tracking-wider block">FAILURE RISK / RUL</span>
                <span [class.text-rose-400]="m.failureRiskPct > 30" [class.text-emerald-400]="m.failureRiskPct <= 30" class="font-black text-sm block mt-1">
                  {{ m.failureRiskPct }}% ({{ m.rulHours }}h)
                </span>
                <div class="w-full h-1 bg-[#1e1e1e] rounded-none mt-2 overflow-hidden">
                  <div class="h-full bg-rose-500" [style.width.%]="m.failureRiskPct"></div>
                </div>
              </div>

              <div class="bg-[#121212] p-3.5 rounded-sm border border-[#222]">
                <span class="text-zinc-500 text-[10px] uppercase font-bold tracking-wider block">{{ m.type === 'haul_truck_electric' ? 'BATTERY SOC' : 'FUEL TANK' }}</span>
                <span class="text-cyan-400 font-black text-sm block mt-1">
                  {{ m.type === 'haul_truck_electric' ? m.batterySocPct + '%' : m.fuelLevelPct + '%' }}
                </span>
                <div class="w-full h-1 bg-[#1e1e1e] rounded-none mt-2 overflow-hidden">
                  <div class="h-full bg-cyan-400" [style.width.%]="m.type === 'haul_truck_electric' ? m.batterySocPct : m.fuelLevelPct"></div>
                </div>
              </div>

              <div class="bg-[#121212] p-3.5 rounded-sm border border-[#222]">
                <span class="text-zinc-500 text-[10px] uppercase font-bold tracking-wider block">TELEMETRY QUALITY</span>
                <span class="text-emerald-400 font-black text-sm block mt-1">{{ m.telemetryQualityPct }}%</span>
                <div class="w-full h-1 bg-[#1e1e1e] rounded-none mt-2 overflow-hidden">
                  <div class="h-full bg-emerald-400" [style.width.%]="m.telemetryQualityPct"></div>
                </div>
              </div>
            </div>

            <!-- Complete 18-Parameter Sensor Matrix -->
            <div>
              <h4 class="text-xs font-mono font-black text-white uppercase tracking-wider mb-3 border-b border-[#222] pb-2">
                Live Subsystem Sensor Readings (10 Hz Stream)
              </h4>

              <div class="grid grid-cols-2 sm:grid-cols-3 gap-3 font-mono text-xs">
                <div class="bg-[#121212] p-3 rounded-sm border border-[#222]">
                  <span class="text-zinc-500 text-[10px] uppercase font-bold">Ground Speed</span>
                  <div class="text-white font-black mt-1">{{ m.speedKmh }} km/h</div>
                </div>

                <div class="bg-[#121212] p-3 rounded-sm border border-[#222]">
                  <span class="text-zinc-500 text-[10px] uppercase font-bold">Engine / Motor Speed</span>
                  <div class="text-white font-black mt-1">{{ m.rpm }} RPM</div>
                </div>

                <div class="bg-[#121212] p-3 rounded-sm border border-[#222]">
                  <span class="text-zinc-500 text-[10px] uppercase font-bold">Motor / Engine Current</span>
                  <div class="text-white font-black mt-1">{{ m.motorCurrentAmps }} A</div>
                </div>

                <div class="bg-[#121212] p-3 rounded-sm border border-[#222]">
                  <span class="text-zinc-500 text-[10px] uppercase font-bold">Structural Vibration</span>
                  <div [class.text-rose-400]="m.vibrationMmPerSec > 6.0" [class.text-white]="m.vibrationMmPerSec <= 6.0" class="font-black mt-1">
                    {{ m.vibrationMmPerSec }} mm/s
                  </div>
                </div>

                <div class="bg-[#121212] p-3 rounded-sm border border-[#222]">
                  <span class="text-zinc-500 text-[10px] uppercase font-bold">Hydraulic Temperature</span>
                  <div [class.text-rose-400]="m.hydraulicTempC > 85" [class.text-white]="m.hydraulicTempC <= 85" class="font-black mt-1">
                    {{ m.hydraulicTempC }}°C
                  </div>
                </div>

                <div class="bg-[#121212] p-3 rounded-sm border border-[#222]">
                  <span class="text-zinc-500 text-[10px] uppercase font-bold">Hydraulic Pressure</span>
                  <div class="text-white font-black mt-1">{{ m.hydraulicPressureBar }} bar</div>
                </div>

                <div class="bg-[#121212] p-3 rounded-sm border border-[#222]">
                  <span class="text-zinc-500 text-[10px] uppercase font-bold">Brake Disc Temp</span>
                  <div class="text-white font-black mt-1">{{ m.brakeTempC }}°C</div>
                </div>

                <div class="bg-[#121212] p-3 rounded-sm border border-[#222]">
                  <span class="text-zinc-500 text-[10px] uppercase font-bold">Tyre Pressure</span>
                  <div class="text-white font-black mt-1">{{ m.tyrePressurePsi }} PSI</div>
                </div>

                <div class="bg-[#121212] p-3 rounded-sm border border-[#222]">
                  <span class="text-zinc-500 text-[10px] uppercase font-bold">Engine / Core Temp</span>
                  <div class="text-white font-black mt-1">{{ m.engineTempC }}°C</div>
                </div>

                <div class="bg-[#121212] p-3 rounded-sm border border-[#222]">
                  <span class="text-zinc-500 text-[10px] uppercase font-bold">Lube Oil Quality Index</span>
                  <div class="text-emerald-400 font-black mt-1">{{ m.oilQualityIndexPct }}%</div>
                </div>

                <div class="bg-[#121212] p-3 rounded-sm border border-[#222]">
                  <span class="text-zinc-500 text-[10px] uppercase font-bold">Operating Hours</span>
                  <div class="text-white font-black mt-1">{{ m.operatingHours.toLocaleString() }} hrs</div>
                </div>

                <div class="bg-[#121212] p-3 rounded-sm border border-[#222]">
                  <span class="text-zinc-500 text-[10px] uppercase font-bold">Target Destination</span>
                  <div class="text-[#F27D26] font-black mt-1">{{ m.targetNodeId }}</div>
                </div>
              </div>
            </div>
          </div>

          <!-- Footer -->
          <div class="px-6 py-3 bg-[#121212] border-t border-[#222] flex justify-end">
            <button
              (click)="closed.emit()"
              class="px-4 py-2 rounded-sm bg-[#1c1c1c] hover:bg-[#262626] text-zinc-200 text-xs font-mono uppercase font-bold transition-colors cursor-pointer border border-[#333]"
            >
              Close Telemetry Inspector
            </button>
          </div>
        </div>
      </div>
    }
  `,
})
export class TelemetryModalComponent {
  readonly machine = input<MachineTelemetry | null>(null);
  readonly closed = output<void>();
}
