import { ChangeDetectionStrategy, Component, inject, signal, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MiningEngineService } from '../../services/mining-engine.service';
import { MachineTelemetry } from '../../models/mining-os.types';

@Component({
  selector: 'app-fleet-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Section Header & Filter Tabs -->
      <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-[#0a0a0a] p-4 rounded-sm border border-[#222]">
        <div>
          <h2 class="text-lg font-black tracking-tight text-white uppercase flex items-center gap-2">
            <mat-icon class="text-[#F27D26]">local_shipping</mat-icon>
            Autonomous Fleet & Dispatch Control
          </h2>
          <p class="text-xs text-zinc-400 font-mono">
            Tracking 14 Heavy Mobile Units | Dynamic Dispatch & Autonomous Cycle Optimisation
          </p>
        </div>

        <div class="flex items-center gap-1.5 bg-[#121212] p-1 rounded-sm border border-[#262626] text-xs font-mono">
          @for (tab of filterTabs; track tab.id) {
            <button
              (click)="selectedCategory.set(tab.id)"
              [class.bg-[#F27D26]]="selectedCategory() === tab.id"
              [class.text-black]="selectedCategory() === tab.id"
              [class.font-black]="selectedCategory() === tab.id"
              [class.text-zinc-400]="selectedCategory() !== tab.id"
              class="px-3 py-1.5 rounded-sm uppercase tracking-wider font-bold transition-colors cursor-pointer"
            >
              {{ tab.label }}
            </button>
          }
        </div>
      </div>

      <!-- Queue Balancing & Cycle Time Overview -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <!-- Shovel Queue Meter -->
        <div class="bg-[#0a0a0a] border border-[#222] p-4 rounded-sm">
          <div class="flex items-center justify-between">
            <span class="text-[10px] font-mono uppercase tracking-widest font-bold text-zinc-500">Shovel Queues</span>
            <span class="text-xs font-mono font-bold text-emerald-400">OPTIMAL</span>
          </div>
          <div class="mt-3 space-y-3">
            <div>
              <div class="flex justify-between text-xs font-mono text-zinc-300 mb-1 font-bold">
                <span>SHV-01 (120t Dipper)</span>
                <span class="text-[#F27D26]">1 Hauler in queue</span>
              </div>
              <div class="w-full h-1.5 bg-[#1a1a1a] rounded-none overflow-hidden">
                <div class="h-full bg-[#F27D26]" style="width: 33%"></div>
              </div>
            </div>
            <div>
              <div class="flex justify-between text-xs font-mono text-zinc-300 mb-1 font-bold">
                <span>EXC-02 (Liebherr R9800)</span>
                <span class="text-emerald-400">0 Hauler (Spotting)</span>
              </div>
              <div class="w-full h-1.5 bg-[#1a1a1a] rounded-none overflow-hidden">
                <div class="h-full bg-emerald-400" style="width: 10%"></div>
              </div>
            </div>
          </div>
        </div>

        <!-- Crusher Infeed Queue Meter -->
        <div class="bg-[#0a0a0a] border border-[#222] p-4 rounded-sm">
          <div class="flex items-center justify-between">
            <span class="text-[10px] font-mono uppercase tracking-widest font-bold text-zinc-500">Crusher Infeed Hopper</span>
            <span class="text-xs font-mono font-bold text-[#F27D26]">MODERATE</span>
          </div>
          <div class="mt-3">
            <div class="flex justify-between text-xs font-mono text-zinc-300 mb-1 font-bold">
              <span>CRU-01 Gyratory (5,500 TPH Cap)</span>
              <span class="text-[#F27D26]">2 Trucks Waiting</span>
            </div>
            <div class="w-full h-1.5 bg-[#1a1a1a] rounded-none overflow-hidden">
              <div class="h-full bg-[#F27D26]" style="width: 66%"></div>
            </div>
            <div class="text-[10px] text-zinc-400 font-mono mt-2 flex items-center gap-1">
              <mat-icon class="text-xs text-[#F27D26]">info</mat-icon>
              Auto-divert active for TRK-102 to Stockpile 1
            </div>
          </div>
        </div>

        <!-- Autonomous Cycle Decomposition -->
        <div class="bg-[#0a0a0a] border border-[#222] p-4 rounded-sm">
          <div class="flex items-center justify-between">
            <span class="text-[10px] font-mono uppercase tracking-widest font-bold text-zinc-500">Average Cycle Time</span>
            <span class="text-sm font-mono text-cyan-400 font-black">18.4 MIN</span>
          </div>
          <div class="mt-3 flex h-2 bg-[#1a1a1a] rounded-none overflow-hidden text-[9px] font-mono">
            <div style="width: 12%" class="bg-amber-400" title="Spotting: 2.2 min"></div>
            <div style="width: 20%" class="bg-[#F27D26]" title="Loading: 3.7 min"></div>
            <div style="width: 40%" class="bg-emerald-500" title="Loaded Haul: 7.4 min"></div>
            <div style="width: 8%" class="bg-blue-400" title="Dumping: 1.5 min"></div>
            <div style="width: 20%" class="bg-cyan-500" title="Empty Return: 3.6 min"></div>
          </div>
          <div class="flex justify-between text-[10px] font-mono text-zinc-400 mt-2 uppercase font-bold">
            <span class="text-amber-400">Spot</span>
            <span class="text-[#F27D26]">Load</span>
            <span class="text-emerald-400">Haul</span>
            <span class="text-blue-400">Dump</span>
            <span class="text-cyan-400">Return</span>
          </div>
        </div>
      </div>

      <!-- Fleet Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        @for (m of filteredMachines(); track m.machineId) {
          <div
            tabindex="0"
            role="button"
            (click)="inspectTelemetry.emit(m)"
            (keydown.enter)="inspectTelemetry.emit(m)"
            class="bg-[#0a0a0a] border border-[#222] hover:border-[#F27D26] p-4 rounded-sm transition-all cursor-pointer shadow-lg group focus:outline-none focus:ring-1 focus:ring-[#F27D26]"
          >
            <!-- Header -->
            <div class="flex items-start justify-between">
              <div class="flex items-center gap-2.5">
                <div
                  [class.bg-purple-950/40]="m.type === 'haul_truck_electric'"
                  [class.text-purple-400]="m.type === 'haul_truck_electric'"
                  [class.border-purple-500/40]="m.type === 'haul_truck_electric'"
                  [class.bg-[#161616]]="m.type !== 'haul_truck_electric'"
                  [class.text-[#F27D26]]="m.type !== 'haul_truck_electric'"
                  [class.border-[#333]]="m.type !== 'haul_truck_electric'"
                  class="w-10 h-10 rounded-sm border flex items-center justify-center font-bold"
                >
                  <mat-icon class="text-xl">
                    {{ m.type.startsWith('haul_truck') ? 'local_shipping' : m.type.includes('drill') ? 'hardware' : 'construction' }}
                  </mat-icon>
                </div>
                <div>
                  <div class="font-mono font-black text-white text-base group-hover:text-[#F27D26] transition-colors">
                    {{ m.machineId }}
                  </div>
                  <div class="text-[11px] font-mono text-zinc-400 truncate max-w-[180px]">
                    {{ m.machineName }}
                  </div>
                </div>
              </div>

              <!-- Status Badge -->
              <span
                [class.bg-emerald-950/40]="m.status.includes('hauling_loaded')"
                [class.text-emerald-400]="m.status.includes('hauling_loaded')"
                [class.border-emerald-500/40]="m.status.includes('hauling_loaded')"
                [class.bg-cyan-950/40]="m.status.includes('hauling_empty')"
                [class.text-cyan-400]="m.status.includes('hauling_empty')"
                [class.border-cyan-500/40]="m.status.includes('hauling_empty')"
                [class.bg-amber-950/40]="m.status.includes('loading') || m.status.includes('digging') || m.status.includes('drilling')"
                [class.text-[#F27D26]]="m.status.includes('loading') || m.status.includes('digging') || m.status.includes('drilling')"
                [class.border-orange-500/40]="m.status.includes('loading') || m.status.includes('digging') || m.status.includes('drilling')"
                class="px-2 py-0.5 rounded-sm text-[9px] font-mono font-bold border uppercase"
              >
                {{ m.status.replace('_', ' ') }}
              </span>
            </div>

            <!-- Metrics Grid -->
            <div class="mt-4 grid grid-cols-2 gap-2 text-xs font-mono">
              <!-- Payload or TPH -->
              <div class="bg-[#121212] p-2 rounded-sm border border-[#222]">
                <span class="text-zinc-500 text-[9px] font-bold block uppercase tracking-wider">PAYLOAD</span>
                <span class="text-zinc-100 font-bold">{{ m.currentPayloadTonnes }} <span class="text-zinc-500 font-normal">/ {{ m.maxPayloadTonnes }} t</span></span>
              </div>

              <!-- Speed or RPM -->
              <div class="bg-[#121212] p-2 rounded-sm border border-[#222]">
                <span class="text-zinc-500 text-[9px] font-bold block uppercase tracking-wider">SPEED / RPM</span>
                <span class="text-zinc-100 font-bold">{{ m.speedKmh }} <span class="text-zinc-500 font-normal">km/h</span></span>
              </div>

              <!-- Energy / Fuel -->
              <div class="bg-[#121212] p-2 rounded-sm border border-[#222]">
                <span class="text-zinc-500 text-[9px] font-bold block uppercase tracking-wider">{{ m.type === 'haul_truck_electric' ? 'BATTERY SOC' : 'FUEL TANK' }}</span>
                <span [class.text-purple-300]="m.type === 'haul_truck_electric'" [class.text-orange-400]="m.type !== 'haul_truck_electric'" class="font-bold">
                  {{ m.type === 'haul_truck_electric' ? m.batterySocPct + '%' : m.fuelLevelPct + '%' }}
                </span>
              </div>

              <!-- Health Risk -->
              <div class="bg-[#121212] p-2 rounded-sm border border-[#222]">
                <span class="text-zinc-500 text-[9px] font-bold block uppercase tracking-wider">FAILURE RISK</span>
                <span [class.text-emerald-400]="m.failureRiskPct < 15" [class.text-amber-400]="m.failureRiskPct >= 15 && m.failureRiskPct < 30" [class.text-rose-400]="m.failureRiskPct >= 30" class="font-bold">
                  {{ m.failureRiskPct }}% (RUL: {{ m.rulHours }}h)
                </span>
              </div>
            </div>

            <!-- Footer Action Bar -->
            <div class="mt-3 pt-3 border-t border-[#222] flex items-center justify-between text-[10px] font-mono text-zinc-400">
              <span>Telemetry: <strong class="text-emerald-400">{{ m.telemetryQualityPct }}%</strong></span>
              <span class="text-[#F27D26] font-bold group-hover:underline flex items-center gap-0.5">
                Inspect <mat-icon class="text-xs">chevron_right</mat-icon>
              </span>
            </div>
          </div>
        }
      </div>
    </div>
  `,
})
export class FleetViewComponent {
  readonly engine = inject(MiningEngineService);
  readonly selectedCategory = signal<string>('all');
  readonly inspectTelemetry = output<MachineTelemetry>();

  readonly filterTabs = [
    { id: 'all', label: 'All Fleet (14)' },
    { id: 'haulers', label: 'Haul Trucks (7)' },
    { id: 'shovels', label: 'Excavators & Shovels (3)' },
    { id: 'drills', label: 'Drills & Support (4)' },
  ];

  filteredMachines() {
    const cat = this.selectedCategory();
    const all = this.engine.machines();
    if (cat === 'haulers') return all.filter((m) => m.type.startsWith('haul_truck'));
    if (cat === 'shovels') return all.filter((m) => m.type === 'rope_shovel' || m.type === 'hydraulic_excavator');
    if (cat === 'drills') return all.filter((m) => m.type === 'autonomous_drill' || m.type === 'primary_crusher');
    return all;
  }
}
