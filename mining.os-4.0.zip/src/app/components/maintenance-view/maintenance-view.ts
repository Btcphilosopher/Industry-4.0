import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MiningEngineService } from '../../services/mining-engine.service';
import { AnomalyAlert } from '../../models/mining-os.types';

@Component({
  selector: 'app-maintenance-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Header -->
      <div class="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-[#0a0a0a] p-4 rounded-sm border border-[#222]">
        <div>
          <h2 class="text-lg font-black tracking-tight text-white uppercase flex items-center gap-2">
            <mat-icon class="text-rose-500">build</mat-icon>
            Predictive Maintenance & Telemetry Anomaly Engine
          </h2>
          <p class="text-xs text-zinc-400 font-mono">
            Multi-Sensor Wear Modeling, Remaining Useful Life (RUL) & Real-Time Z-Score Anomaly Alarms
          </p>
        </div>

        <button
          (click)="triggerSimulatedAnomaly()"
          class="px-3.5 py-2 rounded-sm bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-500/50 text-xs font-mono font-black uppercase tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <mat-icon class="text-sm">crisis_alert</mat-icon>
          Simulate Hydraulic Thermal Anomaly
        </button>
      </div>

      <!-- Health KPI Highlights -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <!-- Critical Assets at Risk -->
        <div class="bg-[#0a0a0a] border border-[#222] p-4 rounded-sm">
          <div class="flex items-center justify-between">
            <span class="text-[10px] font-mono uppercase tracking-widest font-bold text-zinc-500">Degradation Alerts</span>
            <span class="text-xs font-mono text-rose-500 font-black">1 CRITICAL / 2 WATCH</span>
          </div>
          <div class="mt-3 space-y-2">
            <div class="flex items-center justify-between p-2.5 rounded-sm bg-rose-950/30 border border-rose-500/30 text-xs font-mono">
              <span class="text-white font-bold">EXC-02 (Liebherr R9800)</span>
              <span class="text-rose-400 font-black">38% Risk (RUL: 320h)</span>
            </div>
            <div class="flex items-center justify-between p-2.5 rounded-sm bg-[#121212] border border-[#222] text-xs font-mono">
              <span class="text-white font-bold">SHV-01 (CAT 7495 Shovel)</span>
              <span class="text-[#F27D26] font-black">18.5% Risk (RUL: 850h)</span>
            </div>
          </div>
        </div>

        <!-- Anomaly Detector Stats -->
        <div class="bg-[#0a0a0a] border border-[#222] p-4 rounded-sm">
          <div class="flex items-center justify-between">
            <span class="text-[10px] font-mono uppercase tracking-widest font-bold text-zinc-500">Anomaly Filter (Z > 3.0)</span>
            <span class="text-xs font-mono font-bold text-emerald-400">ACTIVE</span>
          </div>
          <div class="mt-3 text-xs font-mono space-y-2 text-zinc-300">
            <div class="flex justify-between">
              <span class="text-zinc-500 uppercase">Sample Rate:</span>
              <span class="text-white font-bold">10 Hz High Frequency</span>
            </div>
            <div class="flex justify-between">
              <span class="text-zinc-500 uppercase">Sliding Window:</span>
              <span class="text-white font-bold">30s Rolling Mean / SD</span>
            </div>
            <div class="flex justify-between">
              <span class="text-zinc-500 uppercase">False Positive Rate:</span>
              <span class="text-emerald-400 font-bold">< 0.4%</span>
            </div>
          </div>
        </div>

        <!-- Scheduled Work Orders -->
        <div class="bg-[#0a0a0a] border border-[#222] p-4 rounded-sm">
          <div class="flex items-center justify-between">
            <span class="text-[10px] font-mono uppercase tracking-widest font-bold text-zinc-500">Maintenance Queue</span>
            <span class="text-xs font-mono text-[#F27D26] font-black">{{ engine.workOrders().length }} WORK ORDERS</span>
          </div>
          <div class="mt-3 text-xs font-mono text-zinc-300 space-y-2">
            <div class="flex justify-between">
              <span class="text-zinc-500 uppercase">Next Bay:</span>
              <span class="text-[#F27D26] font-bold">Bay 2 (TRK-104 PM)</span>
            </div>
            <div class="flex justify-between">
              <span class="text-zinc-500 uppercase">Downtime Saved:</span>
              <span class="text-emerald-400 font-bold">+18.5 Hours</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Real-Time Anomaly Alarms Feed -->
      <div class="bg-[#0a0a0a] border border-[#222] rounded-sm p-4 shadow-xl">
        <div class="flex items-center justify-between mb-3 border-b border-[#222] pb-3">
          <h3 class="text-xs font-black font-mono text-white uppercase tracking-wider flex items-center gap-2">
            <mat-icon class="text-[#F27D26] text-base">warning</mat-icon>
            Live Sensor Anomaly Stream (Rolling Z-Scores)
          </h3>
          <span class="text-[10px] font-mono text-zinc-500 uppercase">
            {{ engine.anomalies().length }} detected in session
          </span>
        </div>

        <div class="space-y-2.5">
          @for (a of engine.anomalies(); track a.id) {
            <div
              [class.border-rose-500/60]="a.severity === 'warning'"
              [class.border-orange-500/40]="a.severity === 'info'"
              class="bg-[#121212] border p-3.5 rounded-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-3"
            >
              <div class="flex items-start gap-3">
                <div
                  [class.bg-rose-950/50]="a.severity === 'warning'"
                  [class.text-rose-400]="a.severity === 'warning'"
                  [class.bg-orange-950/50]="a.severity === 'info'"
                  [class.text-[#F27D26]]="a.severity === 'info'"
                  class="w-9 h-9 rounded-sm border border-[#333] flex items-center justify-center font-bold flex-shrink-0"
                >
                  <mat-icon class="text-lg">sensors</mat-icon>
                </div>
                <div>
                  <div class="flex items-center gap-2">
                    <span class="font-mono font-black text-white text-sm uppercase">{{ a.machineName }}</span>
                    <span class="px-2 py-0.5 text-[9px] font-mono font-bold uppercase rounded-sm bg-[#1e1e1e] text-zinc-300 border border-[#333]">
                      {{ a.parameter }}
                    </span>
                    <span class="text-xs font-mono text-rose-400 font-black">
                      Z-SCORE: {{ a.zScore }}
                    </span>
                  </div>
                  <p class="text-xs text-zinc-300 font-sans mt-0.5">{{ a.description }}</p>
                  <p class="text-[11px] text-[#F27D26] font-mono mt-0.5 font-bold">RECOMMENDED: {{ a.suggestedAction }}</p>
                </div>
              </div>

              <div class="flex items-center gap-2 self-end md:self-center">
                @if (!a.acknowledged) {
                  <button
                    (click)="acknowledgeAnomaly(a.id)"
                    class="px-2.5 py-1.5 rounded-sm bg-[#1c1c1c] hover:bg-[#282828] text-zinc-200 text-xs font-mono uppercase font-bold border border-[#333] transition-colors cursor-pointer"
                  >
                    Acknowledge
                  </button>
                  <button
                    (click)="createWorkOrderFromAnomaly(a)"
                    class="px-3 py-1.5 rounded-sm bg-[#F27D26] hover:bg-orange-500 text-black text-xs font-mono uppercase font-black tracking-wider transition-colors cursor-pointer"
                  >
                    Create WO
                  </button>
                } @else {
                  <span class="text-xs font-mono text-emerald-400 font-bold flex items-center gap-1">
                    <mat-icon class="text-xs">check_circle</mat-icon>
                    ACKNOWLEDGED
                  </span>
                }
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Maintenance Work Orders Table -->
      <div class="bg-[#0a0a0a] border border-[#222] rounded-sm p-4 shadow-xl">
        <h3 class="text-xs font-black font-mono text-white mb-3 flex items-center gap-2 uppercase tracking-wider border-b border-[#222] pb-3">
          <mat-icon class="text-cyan-400 text-base">assignment</mat-icon>
          Predictive Maintenance Work Orders & Remaining Useful Life (RUL)
        </h3>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs font-mono">
            <thead>
              <tr class="border-b border-[#222] text-zinc-500 uppercase font-black text-[10px] tracking-wider">
                <th class="pb-2.5">WO ID</th>
                <th class="pb-2.5">Machine</th>
                <th class="pb-2.5">Target Component</th>
                <th class="pb-2.5">Failure Risk</th>
                <th class="pb-2.5">RUL (Hours)</th>
                <th class="pb-2.5">Operating Window</th>
                <th class="pb-2.5">Priority</th>
                <th class="pb-2.5">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#1e1e1e]">
              @for (wo of engine.workOrders(); track wo.id) {
                <tr class="hover:bg-[#141414] transition-colors">
                  <td class="py-2.5 text-[#F27D26] font-black">{{ wo.id }}</td>
                  <td class="py-2.5 text-white font-bold">{{ wo.machineName }}</td>
                  <td class="py-2.5 text-zinc-300">{{ wo.component }}</td>
                  <td class="py-2.5">
                    <span [class.text-rose-400]="wo.failureRiskPct > 30" [class.text-amber-400]="wo.failureRiskPct <= 30" class="font-bold">
                      {{ wo.failureRiskPct }}%
                    </span>
                  </td>
                  <td class="py-2.5 text-emerald-400 font-black">{{ wo.rulHours }}h</td>
                  <td class="py-2.5 text-zinc-400">{{ wo.operatingWindowHours }} hours</td>
                  <td class="py-2.5">
                    <span
                      [class.bg-rose-950/60]="wo.priority === 'high' || wo.priority === 'critical'"
                      [class.text-rose-400]="wo.priority === 'high' || wo.priority === 'critical'"
                      [class.border-rose-500/40]="wo.priority === 'high' || wo.priority === 'critical'"
                      [class.bg-amber-950/60]="wo.priority === 'medium'"
                      [class.text-[#F27D26]]="wo.priority === 'medium'"
                      [class.border-orange-500/40]="wo.priority === 'medium'"
                      class="px-2 py-0.5 rounded-sm text-[9px] uppercase font-black border"
                    >
                      {{ wo.priority }}
                    </span>
                  </td>
                  <td class="py-2.5 text-zinc-500 uppercase font-bold">{{ wo.status }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class MaintenanceViewComponent {
  readonly engine = inject(MiningEngineService);

  acknowledgeAnomaly(id: string) {
    this.engine.acknowledgeAnomaly(id);
  }

  createWorkOrderFromAnomaly(a: AnomalyAlert) {
    this.engine.addWorkOrder({
      machineId: a.machineId,
      machineName: a.machineName,
      component: `${a.parameter.replace('_', ' ').toUpperCase()} Subsystem`,
      priority: a.severity === 'warning' ? 'high' : 'medium',
      failureRiskPct: +(a.zScore * 11.2).toFixed(1),
      rulHours: Math.round(480 / a.zScore),
      operatingWindowHours: 36,
      recommendedInspection: a.suggestedAction,
      status: 'recommended',
    });
    this.engine.acknowledgeAnomaly(a.id);
  }

  triggerSimulatedAnomaly() {
    const alert: AnomalyAlert = {
      id: `ANOM-${Date.now() % 10000}`,
      timestamp: Date.now(),
      machineId: 'EXC-02',
      machineName: 'Liebherr R9800 (EXC-02)',
      parameter: 'hydraulic_temp_c',
      observedValue: 91.4,
      expectedValue: 74.0,
      zScore: 3.88,
      severity: 'warning',
      description: 'Severe thermal rise in main hydraulic return lines (91.4°C). Risk of cavitation and seal blowout.',
      suggestedAction: 'Issue immediate automated speed derate command to SCADA & inspect cooler core airflow.',
      acknowledged: false,
    };

    this.engine.anomalies.update((list) => [alert, ...list]);
    this.engine.addEvent({
      id: `EV-${Date.now()}`,
      timestamp: Date.now(),
      type: 'ANOMALY_FLAGGED',
      message: `Critical hydraulic thermal anomaly on EXC-02: 91.4°C (Z=3.88)`,
      source: 'PREDICTIVE_MAINTENANCE',
      severity: 'critical'
    });
  }
}
