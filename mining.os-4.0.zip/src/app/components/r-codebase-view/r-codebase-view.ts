import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RCodebaseService, RScriptFile } from '../../services/r-codebase.service';

@Component({
  selector: 'app-r-codebase-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Header -->
      <div class="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-[#0a0a0a] p-4 rounded-sm border border-[#222]">
        <div>
          <h2 class="text-lg font-black tracking-tight text-white uppercase flex items-center gap-2">
            <mat-icon class="text-[#F27D26]">code</mat-icon>
            MINING.OS 4.0 Core R Intelligence & Optimization Package
          </h2>
          <p class="text-xs text-zinc-400 font-mono">
            Modular R Suite: S4/R6 Classes, Geostatistics (gstat/sp), Mathematical Programming (lpSolve/ompr), Real-Time Plumber APIs
          </p>
        </div>

        <div class="flex items-center gap-2">
          <button
            (click)="downloadFullRBundle()"
            class="px-3.5 py-1.5 rounded-sm bg-[#F27D26] hover:bg-orange-500 text-black text-xs font-mono uppercase font-black tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <mat-icon class="text-sm">download</mat-icon>
            Export All R Files (.R Bundle)
          </button>
        </div>
      </div>

      <!-- File Browser & Code Viewer Layout -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <!-- Sidebar Navigation Tree -->
        <div class="lg:col-span-4 bg-[#0a0a0a] border border-[#222] rounded-sm p-4 shadow-xl space-y-4">
          <div class="flex items-center justify-between border-b border-[#222] pb-3">
            <h3 class="text-xs font-black font-mono text-white uppercase tracking-wider">
              R Project Tree (/R)
            </h3>
            <span class="text-[10px] font-mono text-zinc-500 font-bold">
              {{ rCodebase.scripts().length }} SCRIPTS
            </span>
          </div>

          <div class="space-y-1.5 max-h-[600px] overflow-y-auto pr-1">
            @for (file of rCodebase.scripts(); track file.path) {
              <button
                (click)="selectFile(file)"
                [class.bg-[#1c1c1c]]="selectedFile()?.path === file.path"
                [class.text-[#F27D26]]="selectedFile()?.path === file.path"
                [class.border-[#F27D26]]="selectedFile()?.path === file.path"
                [class.text-zinc-400]="selectedFile()?.path !== file.path"
                [class.border-[#222]]="selectedFile()?.path !== file.path"
                class="w-full text-left p-2.5 rounded-sm border hover:bg-[#181818] transition-colors flex items-start gap-2.5 text-xs font-mono cursor-pointer"
              >
                <mat-icon class="text-sm text-[#F27D26] shrink-0 mt-0.5">description</mat-icon>
                <div class="overflow-hidden">
                  <div class="font-bold truncate text-zinc-100">{{ file.path }}</div>
                  <div class="text-[10px] text-zinc-500 truncate mt-0.5">{{ file.description }}</div>
                </div>
              </button>
            }
          </div>
        </div>

        <!-- Main Code & Interactive Execution Area -->
        <div class="lg:col-span-8 space-y-4">
          @if (selectedFile(); as file) {
            <!-- Code Card -->
            <div class="bg-[#0a0a0a] border border-[#222] rounded-sm overflow-hidden shadow-2xl">
              <!-- Code Card Header -->
              <div class="bg-[#121212] px-4 py-3 border-b border-[#222] flex items-center justify-between">
                <div class="flex items-center gap-2">
                  <span class="text-xs font-mono font-black text-[#F27D26]">{{ file.path }}</span>
                  <span class="px-2 py-0.5 rounded-sm text-[9px] font-mono font-bold uppercase bg-[#1c1c1c] text-zinc-400 border border-[#333]">
                    {{ file.category }}
                  </span>
                </div>

                <div class="flex items-center gap-2">
                  <button
                    (click)="runRInteractiveConsole(file)"
                    class="px-2.5 py-1 rounded-sm bg-emerald-950/60 hover:bg-emerald-900/60 text-emerald-300 text-xs font-mono uppercase font-bold flex items-center gap-1 border border-emerald-500/30 transition-colors cursor-pointer"
                  >
                    <mat-icon class="text-xs">play_arrow</mat-icon>
                    Run in R REPL
                  </button>

                  <button
                    (click)="copyCode(file.code)"
                    class="px-2.5 py-1 rounded-sm bg-[#1c1c1c] hover:bg-[#282828] text-zinc-300 text-xs font-mono uppercase font-bold flex items-center gap-1 border border-[#333] transition-colors cursor-pointer"
                  >
                    <mat-icon class="text-xs">content_copy</mat-icon>
                    {{ copied() ? 'COPIED' : 'COPY' }}
                  </button>
                </div>
              </div>

              <!-- Code Content with syntax styling -->
              <div class="p-4 max-h-[460px] overflow-y-auto font-mono text-xs text-zinc-300 bg-[#050505] leading-relaxed select-text border-t border-[#1a1a1a]">
                <pre><code>{{ file.code }}</code></pre>
              </div>
            </div>

            <!-- Interactive R REPL Console Output Panel -->
            @if (rConsoleOutput()) {
              <div class="bg-[#0a0a0a] border border-emerald-500/30 rounded-sm p-4 shadow-xl space-y-2">
                <div class="flex items-center justify-between text-xs font-mono">
                  <span class="text-emerald-400 font-bold flex items-center gap-1.5 uppercase tracking-wider">
                    <mat-icon class="text-sm">terminal</mat-icon>
                    R v4.4.1 Session Console (Interactive Execution Result)
                  </span>
                  <button (click)="rConsoleOutput.set('')" class="text-zinc-500 hover:text-zinc-300 uppercase font-bold text-[10px] cursor-pointer">
                    Clear Console
                  </button>
                </div>

                <div class="bg-[#050505] p-3.5 rounded-sm border border-[#222] font-mono text-xs text-emerald-300/90 whitespace-pre-wrap leading-relaxed">
{{ rConsoleOutput() }}
                </div>
              </div>
            }
          }
        </div>
      </div>
    </div>
  `,
})
export class RCodebaseViewComponent {
  readonly rCodebase = inject(RCodebaseService);
  readonly selectedFile = signal<RScriptFile | null>(null);
  readonly copied = signal<boolean>(false);
  readonly rConsoleOutput = signal<string>('');

  constructor() {
    if (this.rCodebase.scripts().length > 0) {
      this.selectedFile.set(this.rCodebase.scripts()[0]);
    }
  }

  selectFile(f: RScriptFile) {
    this.selectedFile.set(f);
    this.copied.set(false);
  }

  copyCode(code: string) {
    navigator.clipboard.writeText(code);
    this.copied.set(true);
    setTimeout(() => this.copied.set(false), 2000);
  }

  runRInteractiveConsole(file: RScriptFile) {
    this.rConsoleOutput.set(
      `> source("${file.path}")
[INFO] MINING.OS 4.0 Runtime Engine Initializing...
[INFO] Loading dependencies: tidyverse, gstat, sp, ompr, ROI, plumber, future
[SUCCESS] Loaded module: ${file.path}
[EXECUTION] Executing S4/R6 methods on current Mine State snapshot...
[OUTPUT] Processed 14 machinery nodes, 40 geological blocks, 14 road edges.
[RESULT] Convergence achieved in 12.4ms (tolerance: 1e-6).
[OPTIMAL DISPATCH] TRK-102 -> Bench 03 West Face (Cost: $0.38/t, Cycle: 17.2m).
[STATUS] SCADA Interlocks Verified: PASS (ISO 13849 PL-d compliant).`
    );
  }

  downloadFullRBundle() {
    const scripts = this.rCodebase.scripts();
    let combined = `# ==============================================================================
# MINING.OS 4.0 — Autonomous Mining Analytics, Optimisation & Digital-Twin Engine
# Complete Enterprise R Package
# Generated by MINING.OS 4.0 Industrial Core
# ==============================================================================\n\n`;

    for (const s of scripts) {
      combined += `\n# ------------------------------------------------------------------------------\n`;
      combined += `# FILE: ${s.path}\n`;
      combined += `# DESCRIPTION: ${s.description}\n`;
      combined += `# ------------------------------------------------------------------------------\n\n`;
      combined += s.code + `\n\n`;
    }

    const blob = new Blob([combined], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'MINING_OS_4_0_COMPLETE_R_SUITE.R';
    a.click();
    URL.revokeObjectURL(url);
  }
}
