import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MiningEngineService } from '../../services/mining-engine.service';
import { Recommendation } from '../../models/mining-os.types';

@Component({
  selector: 'app-industrial-api-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Header -->
      <div class="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-[#0a0a0a] p-4 rounded-sm border border-[#222]">
        <div>
          <h2 class="text-lg font-black tracking-tight text-white uppercase flex items-center gap-2">
            <mat-icon class="text-[#F27D26]">gavel</mat-icon>
            Industrial Control API & Safety Gateway
          </h2>
          <p class="text-xs text-zinc-400 font-mono">
            Deterministic Safety Interlocks, SCADA/PLC Automated Command Dispatch & Immutable Audit Trail
          </p>
        </div>

        <div class="flex items-center gap-2 bg-[#121212] px-3 py-1.5 rounded-sm border border-[#262626] text-xs font-mono text-zinc-300">
          <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
          Safety Gateway: <strong class="text-emerald-400">ALL INTERLOCKS CLEAR (ISO 13849 PL-d)</strong>
        </div>
      </div>

      <!-- Recommendation Approval Queue -->
      <div class="bg-[#0a0a0a] border border-[#222] rounded-sm p-5 shadow-xl space-y-4">
        <div class="flex items-center justify-between border-b border-[#222] pb-3">
          <h3 class="text-xs font-black font-mono text-white flex items-center gap-2 uppercase tracking-wider">
            <mat-icon class="text-[#F27D26] text-base">pending_actions</mat-icon>
            Autonomous Optimization Decisions Awaiting Gateway Dispatch ({{ engine.recommendations().length }})
          </h3>
          <span class="text-[10px] font-mono text-zinc-500 uppercase">Deterministic R Engine Generated</span>
        </div>

        @if (engine.recommendations().length === 0) {
          <div class="p-8 text-center bg-[#121212] rounded-sm border border-[#222] text-zinc-500 font-mono text-xs">
            <mat-icon class="text-3xl text-emerald-400 mb-1">check_circle</mat-icon>
            <div class="uppercase tracking-wider font-bold mt-1 text-zinc-400">All industrial optimization decisions have been dispatched to SCADA/PLCs.</div>
          </div>
        } @else {
          <div class="space-y-3">
            @for (rec of engine.recommendations(); track rec.id) {
              <div class="bg-[#121212] border border-[#222] p-4 rounded-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div class="space-y-1.5 max-w-2xl">
                  <div class="flex items-center gap-2">
                    <span class="font-mono font-black text-[#F27D26] text-sm">{{ rec.id }}</span>
                    <span class="px-2 py-0.5 rounded-sm text-[9px] font-mono font-bold uppercase bg-[#1c1c1c] text-zinc-300 border border-[#333]">
                      {{ rec.action }}
                    </span>
                    <span class="px-2 py-0.5 rounded-sm text-[9px] font-mono font-bold uppercase bg-emerald-950/60 text-emerald-300 border border-emerald-500/30">
                      TARGET: {{ rec.machineId }}
                    </span>
                    <span class="text-xs font-mono text-cyan-400 font-black">
                      CONFIDENCE: {{ Math.round(rec.confidenceScore * 100) }}%
                    </span>
                  </div>

                  <p class="text-xs text-zinc-200 font-bold font-sans">
                    Action: <span class="font-mono text-[#F27D26]">{{ rec.targetDescription }}</span>
                  </p>

                  <p class="text-xs text-zinc-400 font-sans">
                    Rationale: {{ rec.reason }}
                  </p>

                  <!-- Safety Interlocks Checklist -->
                  <div class="pt-1 flex flex-wrap items-center gap-2 text-[10px] font-mono">
                    <span class="text-zinc-500 uppercase font-bold">Safety Envelope:</span>
                    <span class="px-2 py-0.5 rounded-sm bg-emerald-950/50 text-emerald-300 border border-emerald-500/30 flex items-center gap-1 font-bold">
                      <mat-icon class="text-[10px]">verified</mat-icon>
                      {{ rec.safetyNotes }}
                    </span>
                  </div>
                </div>

                <!-- Action Buttons -->
                <div class="flex items-center gap-2 self-end md:self-center">
                  <button
                    (click)="rejectRecommendation(rec)"
                    class="px-3 py-1.5 rounded-sm bg-[#1c1c1c] hover:bg-[#282828] text-zinc-300 text-xs font-mono uppercase font-bold border border-[#333] transition-colors cursor-pointer"
                  >
                    Reject
                  </button>
                  <button
                    (click)="approveRecommendation(rec)"
                    class="px-3.5 py-1.5 rounded-sm bg-[#F27D26] hover:bg-orange-500 text-black text-xs font-mono uppercase font-black tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <mat-icon class="text-xs">send</mat-icon>
                    Transmit SCADA
                  </button>
                </div>
              </div>
            }
          </div>
        }
      </div>

      <!-- Real-Time Event Bus & Audit Log -->
      <div class="bg-[#0a0a0a] border border-[#222] rounded-sm p-5 shadow-xl space-y-3">
        <h3 class="text-xs font-black font-mono text-white flex items-center gap-2 uppercase tracking-wider border-b border-[#222] pb-3">
          <mat-icon class="text-cyan-400 text-base">receipt_long</mat-icon>
          Event Bus & Immutable Operational Audit Trail
        </h3>

        <div class="bg-[#121212] p-3.5 rounded-sm border border-[#222] max-h-64 overflow-y-auto space-y-2 text-xs font-mono">
          @for (ev of engine.eventBus(); track ev.id) {
            <div class="flex items-start gap-2.5 pb-2 border-b border-[#1e1e1e] last:border-0 last:pb-0">
              <span class="text-zinc-500 shrink-0">{{ formatTime(ev.timestamp) }}</span>
              <span
                [class.text-emerald-400]="ev.severity === 'normal' || ev.severity === 'info'"
                [class.text-[#F27D26]]="ev.severity === 'alert'"
                [class.text-rose-400]="ev.severity === 'critical'"
                class="font-black shrink-0"
              >
                [{{ ev.source }}]
              </span>
              <span class="text-zinc-300">{{ ev.message }}</span>
            </div>
          }
        </div>
      </div>
    </div>
  `,
})
export class IndustrialApiViewComponent {
  readonly engine = inject(MiningEngineService);
  readonly Math = Math;

  approveRecommendation(rec: Recommendation) {
    this.engine.applyRecommendation(rec.id);
  }

  rejectRecommendation(rec: Recommendation) {
    this.engine.rejectRecommendation(rec.id, 'Operator dismissed via Gateway Console');
  }

  formatTime(ts: number): string {
    const d = new Date(ts);
    return d.toTimeString().split(' ')[0] + '.' + String(d.getMilliseconds()).padStart(3, '0');
  }
}
