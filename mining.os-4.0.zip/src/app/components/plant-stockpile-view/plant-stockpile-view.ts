import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MiningEngineService } from '../../services/mining-engine.service';

@Component({
  selector: 'app-plant-stockpile-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Header -->
      <div class="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-[#0a0a0a] p-4 rounded-sm border border-[#222]">
        <div>
          <h2 class="text-lg font-black tracking-tight text-white uppercase flex items-center gap-2">
            <mat-icon class="text-cyan-400">precision_manufacturing</mat-icon>
            Processing Plant & Stockpile Blending Engine
          </h2>
          <p class="text-xs text-zinc-400 font-mono">
            Primary Crusher, SAG Mill Throughput & Linear Programming (LP) Grade Blending Optimizer
          </p>
        </div>

        <div class="flex items-center gap-2 bg-[#121212] px-3 py-1.5 rounded-sm border border-[#262626] text-xs font-mono text-zinc-300">
          <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
          Plant Status: <strong class="text-emerald-400">NOMINAL FLOW (92.4% RECOVERY)</strong>
        </div>
      </div>

      <!-- Processing Plant Real-Time Gauges -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
        <!-- Crusher Throughput -->
        <div class="bg-[#0a0a0a] border border-[#222] p-4 rounded-sm">
          <span class="text-[10px] font-mono uppercase tracking-widest font-bold text-zinc-500">Primary Gyratory Crusher</span>
          <div class="text-2xl font-black font-mono text-[#F27D26] mt-2">
            {{ engine.processingPlant().crusherThroughputTph }} <span class="text-xs text-zinc-500 font-sans font-normal">/ {{ engine.processingPlant().crusherCapacityTph }} TPH</span>
          </div>
          <div class="w-full h-1.5 bg-[#1e1e1e] rounded-none mt-3 overflow-hidden">
            <div class="h-full bg-[#F27D26]" [style.width.%]="(engine.processingPlant().crusherThroughputTph / engine.processingPlant().crusherCapacityTph) * 100"></div>
          </div>
          <span class="text-[10px] text-zinc-500 font-mono mt-2 block uppercase">Eccentric: 175 RPM</span>
        </div>

        <!-- SAG Mill Power -->
        <div class="bg-[#0a0a0a] border border-[#222] p-4 rounded-sm">
          <span class="text-[10px] font-mono uppercase tracking-widest font-bold text-zinc-500">SAG Mill Power Draw</span>
          <div class="text-2xl font-black font-mono text-purple-400 mt-2">
            {{ engine.processingPlant().sagMillPowerKw }} <span class="text-xs text-zinc-500 font-sans font-normal">kW</span>
          </div>
          <div class="w-full h-1.5 bg-[#1e1e1e] rounded-none mt-3 overflow-hidden">
            <div class="h-full bg-purple-500" style="width: 88%"></div>
          </div>
          <span class="text-[10px] text-zinc-500 font-mono mt-2 block uppercase">Ball Charge: 14.5% vol</span>
        </div>

        <!-- Flotation Recovery -->
        <div class="bg-[#0a0a0a] border border-[#222] p-4 rounded-sm">
          <span class="text-[10px] font-mono uppercase tracking-widest font-bold text-zinc-500">Metallurgical Recovery</span>
          <div class="text-2xl font-black font-mono text-emerald-400 mt-2">
            {{ engine.processingPlant().flotationRecoveryPct }}%
          </div>
          <div class="w-full h-1.5 bg-[#1e1e1e] rounded-none mt-3 overflow-hidden">
            <div class="h-full bg-emerald-500" [style.width.%]="engine.processingPlant().flotationRecoveryPct"></div>
          </div>
          <span class="text-[10px] text-zinc-500 font-mono mt-2 block uppercase">Tailings Grade: 0.08% loss</span>
        </div>

        <!-- Milled Today -->
        <div class="bg-[#0a0a0a] border border-[#222] p-4 rounded-sm">
          <span class="text-[10px] font-mono uppercase tracking-widest font-bold text-zinc-500">Total Milled Today</span>
          <div class="text-2xl font-black font-mono text-cyan-400 mt-2">
            {{ (engine.processingPlant().totalMilledTodayTonnes / 1000).toFixed(1) }} <span class="text-xs text-zinc-500 font-sans font-normal">/ 60.0 kt</span>
          </div>
          <div class="w-full h-1.5 bg-[#1e1e1e] rounded-none mt-3 overflow-hidden">
            <div class="h-full bg-cyan-400" [style.width.%]="(engine.processingPlant().totalMilledTodayTonnes / 60000) * 100"></div>
          </div>
          <span class="text-[10px] text-zinc-500 font-mono mt-2 block uppercase">Shift Pace: +2.8% on target</span>
        </div>
      </div>

      <!-- Stockpiles Live Status -->
      <div class="bg-[#0a0a0a] border border-[#222] rounded-sm p-4 shadow-xl">
        <h3 class="text-xs font-black font-mono text-white mb-3 flex items-center gap-2 uppercase tracking-wider border-b border-[#222] pb-3">
          <mat-icon class="text-[#F27D26] text-base">layers</mat-icon>
          Run-of-Mine (ROM) Stockpiles & Silos
        </h3>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          @for (s of engine.stockpiles(); track s.id) {
            <div class="bg-[#121212] p-4 rounded-sm border border-[#222] space-y-3">
              <div class="flex items-start justify-between">
                <div>
                  <span class="text-xs font-mono font-black text-white block uppercase">{{ s.id }}</span>
                  <span class="text-[11px] text-zinc-400 font-sans">{{ s.name }}</span>
                </div>
                <span class="px-2 py-0.5 rounded-sm text-[9px] font-mono font-black bg-emerald-950/60 text-emerald-300 border border-emerald-500/30 uppercase">
                  {{ s.currentGrade }} {{ engine.activeSite().primaryGradeUnit }}
                </span>
              </div>

              <!-- Capacity bar -->
              <div>
                <div class="flex justify-between text-[10px] font-mono text-zinc-400 mb-1 font-bold">
                  <span>{{ (s.currentMassTonnes / 1000).toFixed(0) }}k Tonnes</span>
                  <span class="text-white">{{ Math.round((s.currentMassTonnes / s.maxCapacityTonnes) * 100) }}% Cap</span>
                </div>
                <div class="w-full h-1.5 bg-[#1e1e1e] rounded-none overflow-hidden">
                  <div
                    class="h-full bg-cyan-400 transition-all duration-500"
                    [style.width.%]="(s.currentMassTonnes / s.maxCapacityTonnes) * 100"
                  ></div>
                </div>
              </div>

              <div class="pt-2 border-t border-[#222] text-[10px] font-mono text-zinc-400 space-y-1.5">
                <div class="flex justify-between">
                  <span class="text-zinc-500 uppercase">Silica Impurity (SiO2):</span>
                  <span class="text-[#F27D26] font-bold">{{ s.silicaImpurityPct }}%</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-zinc-500 uppercase">Moisture Content:</span>
                  <span class="text-zinc-300 font-bold">{{ s.moisturePct }}%</span>
                </div>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Linear Programming Blending Optimizer Solver -->
      <div class="bg-[#0a0a0a] border border-[#222] rounded-sm p-4 shadow-xl space-y-4">
        <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-[#222] pb-3">
          <div>
            <h3 class="text-xs font-black font-mono text-white flex items-center gap-2 uppercase tracking-wider">
              <mat-icon class="text-emerald-400 text-base">tune</mat-icon>
              LP Stockpile Blending Optimizer (Crusher Infeed Spec)
            </h3>
            <p class="text-xs text-zinc-400 font-mono">
              Solves continuous linear combination of stockpile extractions to satisfy metallurgical feed grade & impurity caps
            </p>
          </div>

          <button
            (click)="solveOptimalBlend()"
            class="px-3.5 py-2 rounded-sm bg-[#F27D26] hover:bg-orange-500 text-black text-xs font-mono font-black uppercase tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <mat-icon class="text-sm">auto_fix_high</mat-icon>
            Run LP Blending Solver
          </button>
        </div>

        <!-- Blending Parameters & Result Box -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 bg-[#121212] p-4 rounded-sm border border-[#222]">
          <div class="space-y-1">
            <span class="text-zinc-500 text-[10px] font-mono uppercase tracking-widest font-bold">Target Crusher Feed Rate:</span>
            <div class="text-lg font-black font-mono text-white">3,500 TPH</div>
            <span class="text-[10px] text-zinc-500 font-mono">Constrained by Primary Screen</span>
          </div>

          <div class="space-y-1">
            <span class="text-zinc-500 text-[10px] font-mono uppercase tracking-widest font-bold">Target Mill Feed Grade:</span>
            <div class="text-lg font-black font-mono text-emerald-400">{{ engine.activeSite().targetPlantGrade }} {{ engine.activeSite().primaryGradeUnit }}</div>
            <span class="text-[10px] text-zinc-500 font-mono">Tolerance: ±0.05%</span>
          </div>

          <div class="space-y-1">
            <span class="text-zinc-500 text-[10px] font-mono uppercase tracking-widest font-bold">Max Allowable Silica (SiO2):</span>
            <div class="text-lg font-black font-mono text-[#F27D26]">< 4.2% Impurity</div>
            <span class="text-[10px] text-zinc-500 font-mono">Protects SAG Mill liners</span>
          </div>
        </div>

        <!-- Calculated Optimal Blend Proportions -->
        <div class="space-y-2">
          <span class="text-xs font-mono text-zinc-400 font-black uppercase tracking-wider">Recommended Feeder Reclaim Speeds & Blend Ratio:</span>
          <div class="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs font-mono">
            <div class="bg-[#121212] p-3 rounded-sm border border-[#222]">
              <span class="text-zinc-500 block text-[10px] uppercase font-bold">STK-01 (High Grade)</span>
              <strong class="text-emerald-400 text-sm font-black">55% (1,925 TPH)</strong>
            </div>
            <div class="bg-[#121212] p-3 rounded-sm border border-[#222]">
              <span class="text-zinc-500 block text-[10px] uppercase font-bold">STK-02 (Medium Grade)</span>
              <strong class="text-cyan-400 text-sm font-black">35% (1,225 TPH)</strong>
            </div>
            <div class="bg-[#121212] p-3 rounded-sm border border-[#222]">
              <span class="text-zinc-500 block text-[10px] uppercase font-bold">STK-03 (Low Grade)</span>
              <strong class="text-zinc-600 text-sm font-black">0% (0 TPH)</strong>
            </div>
            <div class="bg-[#121212] p-3 rounded-sm border border-[#222]">
              <span class="text-zinc-500 block text-[10px] uppercase font-bold">STK-04 (Sweetener)</span>
              <strong class="text-[#F27D26] text-sm font-black">10% (350 TPH)</strong>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class PlantStockpileViewComponent {
  readonly engine = inject(MiningEngineService);
  readonly Math = Math;

  solveOptimalBlend() {
    this.engine.addEvent({
      id: `EV-${Date.now()}`,
      timestamp: Date.now(),
      type: 'STOCKPILE_BLENDED',
      message: `LP Blending Solver calibrated feeder gates: STK-01 (55%), STK-02 (35%), STK-04 (10%) achieving target ${this.engine.activeSite().targetPlantGrade} grade.`,
      source: 'STOCKPILE_BLENDER_LP',
      severity: 'normal'
    });
  }
}
