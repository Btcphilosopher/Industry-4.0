import { ChangeDetectionStrategy, Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MiningEngineService } from '../../services/mining-engine.service';
import { OreBlock } from '../../models/mining-os.types';

@Component({
  selector: 'app-geology-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Header -->
      <div class="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-[#0a0a0a] p-4 rounded-sm border border-[#222]">
        <div>
          <h2 class="text-lg font-black tracking-tight text-white uppercase flex items-center gap-2">
            <mat-icon class="text-emerald-400">science</mat-icon>
            Geological Ore-Grade Spatial Modeller
          </h2>
          <p class="text-xs text-zinc-400 font-mono">
            Spatial Variography, Ordinary 3D Kriging & Inverse Distance Weighting (IDW) Resource Estimation
          </p>
        </div>

        <!-- Method & Bench Switcher -->
        <div class="flex flex-wrap items-center gap-2">
          <!-- Interpolation Method -->
          <div class="flex items-center bg-[#121212] p-1 rounded-sm border border-[#262626] text-xs font-mono">
            <button
              (click)="spatialMethod.set('kriging')"
              [class.bg-[#F27D26]]="spatialMethod() === 'kriging'"
              [class.text-black]="spatialMethod() === 'kriging'"
              [class.font-black]="spatialMethod() === 'kriging'"
              [class.text-zinc-400]="spatialMethod() !== 'kriging'"
              class="px-2.5 py-1 rounded-sm uppercase tracking-wider font-bold transition-colors cursor-pointer"
            >
              Ordinary Kriging
            </button>
            <button
              (click)="spatialMethod.set('idw')"
              [class.bg-[#F27D26]]="spatialMethod() === 'idw'"
              [class.text-black]="spatialMethod() === 'idw'"
              [class.font-black]="spatialMethod() === 'idw'"
              [class.text-zinc-400]="spatialMethod() !== 'idw'"
              class="px-2.5 py-1 rounded-sm uppercase tracking-wider font-bold transition-colors cursor-pointer"
            >
              IDW (p=2.0)
            </button>
          </div>

          <!-- Bench Selector -->
          <select
            #benchSel
            (change)="selectedBench.set(benchSel.value)"
            class="bg-[#121212] border border-[#333] text-white text-xs font-mono px-3 py-1.5 rounded-sm outline-none cursor-pointer uppercase font-bold"
          >
            @for (b of benches; track b) {
              <option [value]="b">{{ b }}</option>
            }
          </select>
        </div>
      </div>

      <!-- Resource Summary Cards -->
      <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="bg-[#0a0a0a] border border-[#222] p-4 rounded-sm flex flex-col justify-between">
          <span class="text-[10px] font-mono uppercase tracking-widest font-bold text-zinc-500">Estimated Ore Reserve</span>
          <div class="text-2xl sm:text-3xl font-black font-mono text-emerald-400 mt-2 leading-none">
            142.8 <span class="text-xs text-zinc-500 font-sans font-normal">Mt</span>
          </div>
          <span class="text-[10px] text-zinc-500 font-mono mt-2">Confidence: 94.8% (Var: 0.042)</span>
        </div>

        <div class="bg-[#0a0a0a] border border-[#222] p-4 rounded-sm flex flex-col justify-between">
          <span class="text-[10px] font-mono uppercase tracking-widest font-bold text-zinc-500">Average In-Situ Grade</span>
          <div class="text-2xl sm:text-3xl font-black font-mono text-[#F27D26] mt-2 leading-none">
            {{ avgGrade() }} <span class="text-xs text-zinc-500 font-sans font-normal">{{ engine.activeSite().primaryGradeUnit }}</span>
          </div>
          <span class="text-[10px] text-zinc-500 font-mono mt-2">Cut-off: {{ customCutOff() }}</span>
        </div>

        <div class="bg-[#0a0a0a] border border-[#222] p-4 rounded-sm flex flex-col justify-between">
          <span class="text-[10px] font-mono uppercase tracking-widest font-bold text-zinc-500">Strip Ratio (Waste : Ore)</span>
          <div class="text-2xl sm:text-3xl font-black font-mono text-cyan-400 mt-2 leading-none">
            1.82 : 1
          </div>
          <span class="text-[10px] text-zinc-500 font-mono mt-2">Bench 03/04 Transition</span>
        </div>

        <div class="bg-[#0a0a0a] border border-[#222] p-4 rounded-sm flex flex-col justify-between">
          <span class="text-[10px] font-mono uppercase tracking-widest font-bold text-zinc-500">Bond Work Index (Hardness)</span>
          <div class="text-2xl sm:text-3xl font-black font-mono text-purple-400 mt-2 leading-none">
            14.6 <span class="text-xs text-zinc-500 font-sans font-normal">kWh/t</span>
          </div>
          <span class="text-[10px] text-zinc-500 font-mono mt-2">Semi-Autogenous Milling</span>
        </div>
      </div>

      <!-- Cut-off Grade Slider & Dynamic Sensitivity -->
      <div class="bg-[#0a0a0a] border border-[#222] p-4 rounded-sm space-y-2">
        <div class="flex justify-between items-center text-xs font-mono">
          <span class="text-zinc-200 font-bold flex items-center gap-1.5">
            <mat-icon class="text-xs text-[#F27D26]">tune</mat-icon>
            Cut-Off Grade Optimization Threshold: <span class="text-[#F27D26] font-bold">{{ customCutOff() }} {{ engine.activeSite().primaryGradeUnit }}</span>
          </span>
          <span class="text-zinc-400">Recoverable Ore: <strong class="text-emerald-400 font-mono">{{ recoverableOrePct() }}%</strong> of bench volume</span>
        </div>
        <input
          type="range"
          [min]="engine.activeSite().cutOffGrade * 0.6"
          [max]="engine.activeSite().cutOffGrade * 1.5"
          step="0.05"
          [value]="customCutOff()"
          (input)="onCutOffChange($event)"
          class="w-full h-1.5 bg-[#1a1a1a] rounded-none appearance-none cursor-pointer accent-[#F27D26]"
        />
      </div>

      <!-- Block Model Grid Heatmap -->
      <div class="bg-[#050505] border border-[#222] rounded-sm p-4 shadow-xl">
        <div class="flex items-center justify-between mb-4">
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-black text-white uppercase tracking-wider">
              3D BLOCK MODEL SLICE — {{ selectedBench() }}
            </span>
            <span class="text-[9px] font-mono font-bold uppercase px-2 py-0.5 rounded-sm bg-emerald-950/60 text-emerald-400 border border-emerald-500/40">
              {{ spatialMethod() === 'kriging' ? 'Ordinary 3D Kriging' : 'IDW' }}
            </span>
          </div>

          <!-- Color Scale Legend -->
          <div class="flex items-center gap-2 text-[10px] font-mono text-zinc-400">
            <span>Waste (<{{ customCutOff() }})</span>
            <div class="w-24 h-2 rounded-none bg-gradient-to-r from-zinc-700 via-amber-600 to-emerald-500"></div>
            <span>High Grade (>{{ engine.activeSite().targetPlantGrade }})</span>
          </div>
        </div>

        <!-- Interactive 2D Grid Representation of the Bench -->
        <div class="grid grid-cols-10 gap-1.5 p-2 bg-[#0a0a0a] rounded-sm border border-[#222]">
          @for (b of benchBlocks(); track b.id) {
            <div
              tabindex="0"
              role="button"
              (click)="selectedBlock.set(b)"
              (keydown.enter)="selectedBlock.set(b)"
              [class.ring-2]="selectedBlock()?.id === b.id"
              [class.ring-[#F27D26]]="selectedBlock()?.id === b.id"
              [style.background-color]="getBlockColor(b)"
              class="aspect-square rounded-sm flex flex-col items-center justify-center p-1 cursor-pointer transition-all hover:scale-105 relative group shadow-sm focus:outline-none focus:ring-1 focus:ring-[#F27D26]"
            >
              <span class="text-[10px] font-mono font-black text-black drop-shadow">
                {{ b.gradeValue }}
              </span>
              <span class="text-[8px] font-mono text-black/80 uppercase font-black">
                {{ b.state === 'depleted' ? 'DEP' : b.state === 'excavating' ? 'ACT' : b.state === 'blasted' ? 'BLS' : 'SITU' }}
              </span>

              <!-- Hover Tooltip -->
              <div class="absolute bottom-full mb-1 hidden group-hover:block z-20 w-44 bg-[#0a0a0a] border border-[#333] p-2.5 rounded-sm text-[10px] font-mono text-zinc-200 shadow-2xl pointer-events-none">
                <div class="font-black text-[#F27D26] uppercase">{{ b.id }}</div>
                <div>Grade: <strong class="text-emerald-400">{{ b.gradeValue }} {{ engine.activeSite().primaryGradeUnit }}</strong></div>
                <div>Density: {{ b.densityTpm3.toFixed(2) }} t/m³</div>
                <div>Hardness: BWI {{ b.hardnessIndex }}</div>
                <div>Status: {{ b.state }}</div>
                <div>Confidence: {{ b.confidencePct }}%</div>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Selected Block Detail Card -->
      @if (selectedBlock(); as blk) {
        <div class="bg-[#0a0a0a] border-2 border-[#F27D26] p-4 rounded-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div class="flex items-center gap-2">
              <span class="text-base font-black font-mono text-white uppercase">{{ blk.id }}</span>
              <span class="px-2 py-0.5 rounded-sm text-[9px] font-mono font-bold uppercase bg-emerald-950/60 text-emerald-400 border border-emerald-500/40">
                {{ blk.rockType }}
              </span>
            </div>
            <div class="text-xs text-zinc-400 font-mono mt-1 flex flex-wrap gap-x-3 gap-y-1">
              <span>ESTIMATED GRADE: <strong class="text-emerald-400 font-bold">{{ blk.gradeValue }} {{ engine.activeSite().primaryGradeUnit }}</strong></span>
              <span>DENSITY: <strong class="text-white font-bold">{{ blk.densityTpm3.toFixed(2) }} t/m³</strong></span>
              <span>HARDNESS: <strong class="text-white font-bold">BWI {{ blk.hardnessIndex }}</strong></span>
              <span>CONFIDENCE: <strong class="text-[#F27D26] font-bold">{{ blk.confidencePct }}%</strong></span>
            </div>
          </div>

          <div class="flex items-center gap-2">
            <button
              (click)="selectedBlock.set(null)"
              class="px-3 py-1.5 rounded-sm bg-[#161616] hover:bg-[#222] text-zinc-300 border border-[#333] text-xs font-mono uppercase font-bold cursor-pointer"
            >
              Close Inspector
            </button>
          </div>
        </div>
      }
    </div>
  `,
})
export class GeologyViewComponent {
  readonly engine = inject(MiningEngineService);
  readonly spatialMethod = signal<'kriging' | 'idw'>('kriging');
  readonly selectedBench = signal<string>('Bench 03 (-90m)');
  readonly customCutOff = signal<number>(56.5);
  readonly selectedBlock = signal<OreBlock | null>(null);

  readonly benches = [
    'Bench 01 (Surface)',
    'Bench 02 (-40m)',
    'Bench 03 (-90m)',
    'Bench 04 (-140m)',
  ];

  constructor() {
    this.customCutOff.set(this.engine.activeSite().cutOffGrade);
  }

  onCutOffChange(e: Event) {
    const val = +(e.target as HTMLInputElement).value;
    this.customCutOff.set(val);
  }

  benchBlocks() {
    const b = this.selectedBench();
    return this.engine.oreBlocks().filter((blk) => blk.benchId.includes(b.split(' ')[1]));
  }

  avgGrade = computed(() => {
    const blocks = this.benchBlocks();
    if (blocks.length === 0) return this.engine.activeSite().targetPlantGrade;
    const sum = blocks.reduce((acc, b) => acc + b.gradeValue, 0);
    return +(sum / blocks.length).toFixed(2);
  });

  recoverableOrePct = computed(() => {
    const blocks = this.benchBlocks();
    if (blocks.length === 0) return 75;
    const oreCount = blocks.filter((b) => b.gradeValue >= this.customCutOff()).length;
    return Math.round((oreCount / blocks.length) * 100);
  });

  getBlockColor(b: OreBlock): string {
    const cutOff = this.customCutOff();
    const target = this.engine.activeSite().targetPlantGrade;
    if (b.state === 'depleted') return '#334155';
    if (b.gradeValue < cutOff) return '#475569'; // Waste rock
    if (b.gradeValue >= target * 1.1) return '#10b981'; // Ultra high grade emerald
    if (b.gradeValue >= target) return '#34d399'; // High grade
    return '#d97706'; // Medium grade amber
  }
}
