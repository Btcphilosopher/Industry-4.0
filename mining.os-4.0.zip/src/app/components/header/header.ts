import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MiningEngineService } from '../../services/mining-engine.service';

@Component({
  selector: 'app-header',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <header class="bg-[#0a0a0a] border-b border-[#2a2a2a] sticky top-0 z-50">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between h-20">
          <!-- Logo & Brand with Bold Typography -->
          <div class="flex items-center gap-4">
            <div class="flex items-baseline gap-3">
              <h1 class="text-2xl sm:text-3xl font-black tracking-tighter text-[#F27D26] uppercase flex items-baseline gap-2">
                <span>Mining.OS</span>
                <span class="text-white opacity-40 text-lg sm:text-xl font-mono">4.0</span>
              </h1>
              <div class="hidden sm:inline-flex px-2.5 py-1 bg-[#161616] border border-[#333] rounded text-[10px] font-mono text-zinc-400 uppercase tracking-wider">
                SITE: {{ engine.activeSite().id.toUpperCase() }}
              </div>
            </div>

            <!-- Mineral Site Selector -->
            <div class="hidden xl:flex items-center ml-3 pl-3 border-l border-[#262626]">
              <div class="flex items-center gap-2 bg-[#121212] px-3 py-1.5 rounded border border-[#2a2a2a]">
                <mat-icon class="text-[#F27D26] text-sm">location_on</mat-icon>
                <div class="flex flex-col">
                  <span class="text-[9px] text-zinc-500 uppercase font-mono tracking-widest font-bold">Active Mine Site</span>
                  <select
                    #siteSelect
                    [value]="engine.activeSite().id"
                    (change)="onSiteChange(siteSelect.value)"
                    class="bg-transparent text-xs font-mono font-bold text-zinc-100 outline-none cursor-pointer pr-3"
                  >
                    @for (s of engine.availableSites; track s.id) {
                      <option [value]="s.id" class="bg-[#111] text-zinc-100">
                        {{ s.name }} ({{ s.mineralLabel }})
                      </option>
                    }
                  </select>
                </div>
              </div>
            </div>
          </div>

          <!-- Header Metrics & Sim Controls -->
          <div class="flex items-center gap-6">
            <!-- Telemetry Production Rate -->
            <div class="hidden md:block text-right">
              <div class="text-[9px] uppercase tracking-widest text-zinc-500 font-mono font-bold">Production Rate</div>
              <div class="text-xl sm:text-2xl font-mono font-bold text-zinc-100 leading-none">
                {{ engine.currentTotalTPH().toLocaleString() }} <span class="text-xs text-zinc-500 font-mono">TPH</span>
              </div>
            </div>

            <!-- System Status -->
            <div class="hidden lg:block text-right border-l border-[#262626] pl-6">
              <div class="text-[9px] uppercase tracking-widest text-zinc-500 font-mono font-bold">System Status</div>
              <div class="flex items-center gap-2 text-emerald-400">
                <div class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></div>
                <div class="text-xs uppercase font-mono font-black tracking-wider">Optimized</div>
              </div>
            </div>

            <!-- Simulation Controls -->
            <div class="flex items-center gap-1 bg-[#121212] p-1.5 rounded border border-[#2a2a2a]">
              <button
                (click)="toggleSimulation()"
                [class.text-emerald-400]="engine.isSimulationRunning()"
                [class.text-zinc-500]="!engine.isSimulationRunning()"
                class="px-2.5 py-1 rounded bg-[#1a1a1a] hover:bg-[#252525] transition-colors flex items-center gap-1.5 text-xs font-mono font-bold"
                [title]="engine.isSimulationRunning() ? 'Pause Simulation' : 'Resume Simulation'"
              >
                <mat-icon class="text-sm">{{ engine.isSimulationRunning() ? 'pause' : 'play_arrow' }}</mat-icon>
                <span class="tracking-wider">{{ engine.isSimulationRunning() ? 'LIVE' : 'PAUSED' }}</span>
              </button>

              <button
                (click)="stepOnce()"
                class="p-1 rounded text-zinc-400 hover:text-zinc-100 hover:bg-[#252525] transition-colors flex items-center"
                title="Single Tick Step"
              >
                <mat-icon class="text-sm">skip_next</mat-icon>
              </button>

              <!-- Speed Multiplier -->
              <div class="flex items-center border-l border-[#262626] ml-1 pl-1">
                @for (spd of [1, 2, 5, 10]; track spd) {
                  <button
                    (click)="engine.setSimulationSpeed(spd)"
                    [class.bg-[#F27D26]]="engine.simulationSpeed() === spd"
                    [class.text-black]="engine.simulationSpeed() === spd"
                    [class.font-bold]="engine.simulationSpeed() === spd"
                    [class.text-zinc-400]="engine.simulationSpeed() !== spd"
                    class="px-2 py-0.5 text-[11px] font-mono rounded-sm hover:text-zinc-100 transition-colors"
                  >
                    {{ spd }}x
                  </button>
                }
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  `,
})
export class HeaderComponent {
  readonly engine = inject(MiningEngineService);

  onSiteChange(siteId: string) {
    this.engine.setMineSite(siteId);
  }

  toggleSimulation() {
    this.engine.setSimulationRunning(!this.engine.isSimulationRunning());
  }

  stepOnce() {
    this.engine.stepSimulation();
  }
}
