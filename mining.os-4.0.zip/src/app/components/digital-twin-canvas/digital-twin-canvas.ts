import { ChangeDetectionStrategy, Component, inject, signal, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MiningEngineService } from '../../services/mining-engine.service';
import { MachineTelemetry, RoadNode } from '../../models/mining-os.types';

@Component({
  selector: 'app-digital-twin-canvas',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Live Operations KPI Ribbon (Bold Typography Theme) -->
      <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5">
        <div class="bg-[#0a0a0a] border border-[#222] p-4 rounded-sm flex flex-col justify-between">
          <div class="text-[10px] uppercase tracking-widest font-mono font-bold text-zinc-500">Total Throughput</div>
          <div class="text-2xl sm:text-3xl font-black font-mono text-[#F27D26] mt-2 leading-none">
            {{ engine.currentTotalTPH().toLocaleString() }} <span class="text-xs text-zinc-500 font-sans font-normal">TPH</span>
          </div>
          <div class="text-[10px] text-zinc-500 font-mono mt-2">Target: {{ engine.activeSite().targetDailyTPH }} TPH</div>
        </div>

        <div class="bg-[#0a0a0a] border border-[#222] p-4 rounded-sm flex flex-col justify-between">
          <div class="text-[10px] uppercase tracking-widest font-mono font-bold text-zinc-500">Average Grade</div>
          <div class="text-2xl sm:text-3xl font-black font-mono text-white mt-2 leading-none">
            {{ engine.averageOreGrade() }} <span class="text-xs text-zinc-500 font-sans font-normal">{{ engine.activeSite().primaryGradeUnit }}</span>
          </div>
          <div class="text-[10px] text-zinc-500 font-mono mt-2">Cut-off: {{ engine.activeSite().cutOffGrade }}</div>
        </div>

        <div class="bg-[#0a0a0a] border border-[#222] p-4 rounded-sm flex flex-col justify-between">
          <div class="text-[10px] uppercase tracking-widest font-mono font-bold text-zinc-500">Fleet OEE</div>
          <div class="text-2xl sm:text-3xl font-black font-mono text-cyan-400 mt-2 leading-none">
            {{ engine.fleetUtilisationPct() }}<span class="text-sm font-sans font-normal opacity-60">%</span>
          </div>
          <div class="text-[10px] text-zinc-500 font-mono mt-2">Avail: {{ engine.fleetAvailabilityPct() }}%</div>
        </div>

        <div class="bg-[#0a0a0a] border border-[#222] p-4 rounded-sm flex flex-col justify-between">
          <div class="text-[10px] uppercase tracking-widest font-mono font-bold text-zinc-500">Fuel Intensity</div>
          <div class="text-2xl sm:text-3xl font-black font-mono text-white mt-2 leading-none">
            {{ engine.fuelIntensityLitersPerTonne() }} <span class="text-xs text-zinc-500 font-sans font-normal">L/t</span>
          </div>
          <div class="text-[10px] text-zinc-500 font-mono mt-2">Diesel Haulers</div>
        </div>

        <div class="bg-[#0a0a0a] border border-[#222] p-4 rounded-sm flex flex-col justify-between">
          <div class="text-[10px] uppercase tracking-widest font-mono font-bold text-zinc-500">Energy Intensity</div>
          <div class="text-2xl sm:text-3xl font-black font-mono text-purple-400 mt-2 leading-none">
            {{ engine.energyIntensityKWhPerTonne() }} <span class="text-xs text-zinc-500 font-sans font-normal">kWh/t</span>
          </div>
          <div class="text-[10px] text-zinc-500 font-mono mt-2">Electric + Mill</div>
        </div>

        <div class="bg-[#0a0a0a] border border-[#222] p-4 rounded-sm flex flex-col justify-between">
          <div class="text-[10px] uppercase tracking-widest font-mono font-bold text-zinc-500">Moved Today</div>
          <div class="text-2xl sm:text-3xl font-black font-mono text-[#F27D26] mt-2 leading-none">
            {{ (engine.totalTonnesMovedToday() / 1000).toFixed(1) }} <span class="text-xs text-zinc-500 font-sans font-normal">kt</span>
          </div>
          <div class="text-[10px] text-zinc-500 font-mono mt-2">Target: 65.0 kt</div>
        </div>
      </div>

      <!-- Main Interactive Digital Twin 2D Surface Map -->
      <div class="relative bg-[#050505] border border-[#222] rounded-sm overflow-hidden shadow-2xl">
        <!-- Canvas Header Banner -->
        <div class="p-4 border-b border-[#222] flex items-center justify-between bg-[#0a0a0a]">
          <div>
            <h3 class="text-[11px] uppercase tracking-[0.25em] font-black text-zinc-400 flex items-center gap-2">
              <span class="w-2 h-2 rounded-full bg-[#F27D26]"></span>
              Digital Twin / Pit Visualization
            </h3>
          </div>
          <div class="flex items-center gap-3 text-xs font-mono">
            <span class="text-zinc-500 text-[10px] hidden sm:inline">ELEVATION: -140M TO +95M</span>
            <button
              (click)="toggleContours()"
              class="px-2.5 py-1 rounded-sm bg-[#161616] hover:bg-[#222] text-[#F27D26] border border-[#333] text-[10px] uppercase font-bold tracking-wider transition-colors"
            >
              {{ showContours() ? 'Hide Contours' : 'Show Contours' }}
            </button>
          </div>
        </div>

        <!-- Legend Overlay -->
        <div class="absolute bottom-4 left-4 z-10 hidden sm:flex items-center gap-4 bg-[#0a0a0a]/90 backdrop-blur-md px-3.5 py-2 rounded-sm border border-[#333] text-[10px] font-mono text-zinc-300">
          <div class="flex items-center gap-1.5 font-bold">
            <span class="w-2.5 h-2.5 rounded-sm bg-emerald-500"></span> Loaded
          </div>
          <div class="flex items-center gap-1.5 font-bold">
            <span class="w-2.5 h-2.5 rounded-sm bg-cyan-400"></span> Empty
          </div>
          <div class="flex items-center gap-1.5 font-bold">
            <span class="w-2.5 h-2.5 rounded-sm bg-[#F27D26]"></span> Shovel
          </div>
          <div class="flex items-center gap-1.5 font-bold">
            <span class="w-2.5 h-2.5 rounded-sm bg-purple-400"></span> e-Hauler
          </div>
        </div>

        <!-- SVG Map Container -->
        <div class="w-full aspect-[16/9] min-h-[480px] max-h-[620px] relative bg-[#040404] cursor-crosshair">
          <svg class="w-full h-full" viewBox="100 80 820 420" preserveAspectRatio="xMidYMid meet">
            <defs>
              <linearGradient id="pitGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stop-color="#0f172a" />
                <stop offset="50%" stop-color="#090e17" />
                <stop offset="100%" stop-color="#04070e" />
              </linearGradient>

              <radialGradient id="highGradeDeposit" cx="25%" cy="75%" r="35%">
                <stop offset="0%" stop-color="#d97706" stop-opacity="0.35" />
                <stop offset="60%" stop-color="#b45309" stop-opacity="0.15" />
                <stop offset="100%" stop-color="#0f172a" stop-opacity="0" />
              </radialGradient>

              <pattern id="gridPattern" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#1e293b" stroke-width="0.5" stroke-opacity="0.4" />
              </pattern>

              <marker id="arrow" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="4" markerHeight="4" orient="auto-start-reverse">
                <path d="M 0 0 L 10 5 L 0 10 z" fill="#475569" />
              </marker>
            </defs>

            <!-- Grid background -->
            <rect x="0" y="0" width="1000" height="600" fill="url(#gridPattern)" />

            <!-- Pit Ore Body Deposit Overlay -->
            <circle cx="200" cy="370" r="140" fill="url(#highGradeDeposit)" />

            <!-- Bench Contour Ellipses -->
            @if (showContours()) {
              <g stroke="#334155" stroke-width="1.2" fill="none" stroke-dasharray="4,3" opacity="0.6">
                <!-- Bench 04 Floor (-140m) -->
                <ellipse cx="200" cy="370" rx="90" ry="60" stroke="#f59e0b" stroke-width="1.5" />
                <text x="145" y="365" fill="#d97706" font-size="9" font-family="monospace">PIT FLOOR (-140m)</text>

                <!-- Bench 03 (-90m) -->
                <ellipse cx="270" cy="310" rx="140" ry="95" />
                <text x="210" y="240" fill="#64748b" font-size="8" font-family="monospace">BENCH 03 (-90m)</text>

                <!-- Bench 02 (-40m) -->
                <ellipse cx="340" cy="250" rx="200" ry="130" />
                <text x="270" y="150" fill="#64748b" font-size="8" font-family="monospace">BENCH 02 (-40m)</text>

                <!-- Surface Rim (+80m) -->
                <ellipse cx="440" cy="220" rx="280" ry="170" stroke="#475569" />
              </g>
            }

            <!-- Road Network Edges -->
            <g stroke="#475569" stroke-width="3" stroke-linecap="round" opacity="0.8">
              @for (edge of engine.roadEdges(); track edge.id) {
                @let fromNode = getNode(edge.fromNodeId);
                @let toNode = getNode(edge.toNodeId);
                @if (fromNode && toNode) {
                  <!-- Road casing -->
                  <line
                    [attr.x1]="fromNode.x"
                    [attr.y1]="fromNode.y"
                    [attr.x2]="toNode.x"
                    [attr.y2]="toNode.y"
                    stroke="#1e293b"
                    stroke-width="7"
                  />
                  <!-- Active Road line with gradient gradient color -->
                  <line
                    [attr.x1]="fromNode.x"
                    [attr.y1]="fromNode.y"
                    [attr.x2]="toNode.x"
                    [attr.y2]="toNode.y"
                    [attr.stroke]="edge.gradientPct > 5 ? '#f59e0b' : edge.gradientPct < -3 ? '#06b6d4' : '#64748b'"
                    stroke-width="2.5"
                    stroke-dasharray="5,3"
                  />
                }
              }
            </g>

            <!-- Fixed Infrastructure Nodes -->
            @for (node of engine.roadNodes(); track node.id) {
              <g [attr.transform]="'translate(' + node.x + ',' + node.y + ')'" class="cursor-pointer">
                @if (node.type === 'crusher_infeed') {
                  <rect x="-16" y="-16" width="32" height="32" rx="6" fill="#0f172a" stroke="#f59e0b" stroke-width="2" />
                  <circle cx="0" cy="0" r="8" fill="#f59e0b" class="animate-pulse" />
                  <text x="22" y="4" fill="#fbbf24" font-size="10" font-weight="bold" font-family="monospace">PRIMARY CRUSHER</text>
                } @else if (node.type === 'stockpile') {
                  <polygon points="0,-14 14,10 -14,10" fill="#0284c7" stroke="#38bdf8" stroke-width="1.5" />
                  <text x="18" y="4" fill="#7dd3fc" font-size="9" font-family="monospace">{{ node.name.split(' ')[0] }}</text>
                } @else if (node.type === 'charging_station') {
                  <rect x="-12" y="-12" width="24" height="24" rx="4" fill="#581c87" stroke="#c084fc" stroke-width="1.5" />
                  <circle cx="0" cy="0" r="4" fill="#e879f9" />
                  <text x="16" y="4" fill="#e879f9" font-size="9" font-family="monospace">EV CHARGING (2.4MW)</text>
                } @else if (node.type === 'waste_dump') {
                  <polygon points="-12,-8 12,-8 8,10 -8,10" fill="#475569" stroke="#94a3b8" stroke-width="1.5" />
                  <text x="16" y="4" fill="#cbd5e1" font-size="9" font-family="monospace">WASTE DUMP NORTH</text>
                } @else {
                  <circle cx="0" cy="0" r="5" fill="#1e293b" stroke="#64748b" stroke-width="1.5" />
                }
              </g>
            }

            <!-- Real-Time Machine Markers -->
            @for (machine of engine.machines(); track machine.machineId) {
              <g
                [attr.transform]="'translate(' + machine.x + ',' + machine.y + ')'"
                (click)="selectMachine(machine)"
                class="cursor-pointer transition-transform hover:scale-125 duration-300"
              >
                <!-- Selection Radar Glow -->
                @if (selectedMachine()?.machineId === machine.machineId) {
                  <circle cx="0" cy="0" r="22" fill="none" stroke="#f59e0b" stroke-width="2" class="radar-ping" />
                }

                @if (machine.type.startsWith('haul_truck')) {
                  <!-- Truck Vehicle Body -->
                  <rect
                    x="-10"
                    y="-7"
                    width="20"
                    height="14"
                    rx="3"
                    [attr.fill]="
                      machine.type === 'haul_truck_electric'
                        ? '#7e22ce'
                        : machine.status === 'hauling_loaded'
                        ? '#059669'
                        : machine.status === 'hauling_empty'
                        ? '#0891b2'
                        : '#d97706'
                    "
                    stroke="#ffffff"
                    stroke-width="1"
                    class="drop-shadow-md"
                  />
                  <!-- Payload bar on truck bed -->
                  @if (machine.currentPayloadTonnes > 0) {
                    <rect x="-8" y="-4" width="16" height="8" rx="1" fill="#fef08a" opacity="0.9" />
                  }
                  <!-- Truck Label -->
                  <text x="13" y="4" fill="#ffffff" font-size="9" font-weight="bold" font-family="monospace">
                    {{ machine.machineId }}
                  </text>
                  <!-- Speed Tag -->
                  @if (machine.speedKmh > 0) {
                    <text x="13" y="14" fill="#94a3b8" font-size="7.5" font-family="monospace">
                      {{ machine.speedKmh }}km/h
                    </text>
                  }
                } @else if (machine.type === 'rope_shovel' || machine.type === 'hydraulic_excavator') {
                  <!-- Excavator / Shovel Circle with Reach sweep -->
                  <circle cx="0" cy="0" r="26" fill="#f59e0b" fill-opacity="0.1" stroke="#f59e0b" stroke-dasharray="3,2" />
                  <rect x="-12" y="-12" width="24" height="24" rx="4" fill="#b45309" stroke="#fbbf24" stroke-width="2" />
                  <line x1="0" y1="0" x2="16" y2="-12" stroke="#fbbf24" stroke-width="3" />
                  <circle cx="16" cy="-12" r="4" fill="#fbbf24" />
                  <text x="24" y="0" fill="#fef08a" font-size="9" font-weight="bold" font-family="monospace">
                    {{ machine.machineId }}
                  </text>
                } @else if (machine.type === 'autonomous_drill') {
                  <polygon points="0,-10 9,6 -9,6" fill="#ea580c" stroke="#fed7aa" stroke-width="1.5" />
                  <circle cx="0" cy="0" r="2" fill="#ffffff" />
                  <text x="14" y="4" fill="#fed7aa" font-size="9" font-weight="bold" font-family="monospace">
                    {{ machine.machineId }}
                  </text>
                }
              </g>
            }
          </svg>
        </div>
      </div>

      <!-- Quick Telemetry Inspection Panel for Selected Machine -->
      @if (selectedMachine(); as m) {
        <div class="bg-[#0a0a0a] border-2 border-[#F27D26] p-4 rounded-sm shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div class="flex items-center gap-3">
            <div class="w-12 h-12 rounded-sm bg-[#161616] border border-[#333] flex items-center justify-center text-[#F27D26] font-bold">
              <mat-icon class="text-2xl">{{ m.type.startsWith('haul_truck') ? 'local_shipping' : 'construction' }}</mat-icon>
            </div>
            <div>
              <div class="flex items-center gap-2">
                <span class="text-base font-black font-mono text-white uppercase">{{ m.machineId }}</span>
                <span class="text-xs text-zinc-400 font-mono">({{ m.machineName }})</span>
                <span class="px-2 py-0.5 rounded-sm text-[9px] font-mono font-bold uppercase bg-emerald-950/60 text-emerald-400 border border-emerald-500/40">
                  {{ m.status.replace('_', ' ') }}
                </span>
              </div>
              <div class="text-xs text-zinc-400 font-mono mt-1 flex flex-wrap gap-x-3 gap-y-1">
                <span>SPEED: <strong class="text-[#F27D26] font-bold">{{ m.speedKmh }} KM/H</strong></span>
                <span>PAYLOAD: <strong class="text-white font-bold">{{ m.currentPayloadTonnes }}/{{ m.maxPayloadTonnes }} T</strong></span>
                <span>VIBRATION: <strong class="text-white font-bold">{{ m.vibrationMmPerSec }} MM/S</strong></span>
                <span>HYDRAULIC: <strong class="text-white font-bold">{{ m.hydraulicTempC }}°C</strong></span>
              </div>
            </div>
          </div>

          <div class="flex items-center gap-2">
            <button
              (click)="inspectFullTelemetry.emit(m)"
              class="px-3 py-2 rounded-sm bg-[#F27D26] hover:bg-orange-500 text-black text-xs font-mono font-black uppercase tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <mat-icon class="text-sm">tune</mat-icon>
              Telemetry Matrix
            </button>
            <button
              (click)="selectedMachine.set(null)"
              class="p-2 rounded-sm text-zinc-400 hover:text-white hover:bg-[#222] transition-colors cursor-pointer"
            >
              <mat-icon class="text-base">close</mat-icon>
            </button>
          </div>
        </div>
      }
    </div>
  `,
})
export class DigitalTwinCanvasComponent {
  readonly engine = inject(MiningEngineService);
  readonly showContours = signal<boolean>(true);
  readonly selectedMachine = signal<MachineTelemetry | null>(null);

  readonly inspectFullTelemetry = output<MachineTelemetry>();

  toggleContours() {
    this.showContours.update((v) => !v);
  }

  getNode(nodeId: string): RoadNode | undefined {
    return this.engine.roadNodes().find((n) => n.id === nodeId);
  }

  selectMachine(m: MachineTelemetry) {
    this.selectedMachine.set(m);
  }
}
