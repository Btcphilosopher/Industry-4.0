import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AiAdvisorService } from '../../services/ai-advisor.service';

@Component({
  selector: 'app-ai-advisor-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Header -->
      <div class="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-[#0a0a0a] p-4 rounded-sm border border-[#222]">
        <div>
          <h2 class="text-lg font-black tracking-tight text-white uppercase flex items-center gap-2">
            <mat-icon class="text-[#F27D26]">psychology</mat-icon>
            AI Operations Specialist & Mining Engineer Copilot
          </h2>
          <p class="text-xs text-zinc-400 font-mono">
            Autonomous Shift Handover Briefings, Root-Cause Diagnostics & Safety Protocol Advisor
          </p>
        </div>

        <button
          (click)="triggerFullAnalysis()"
          [disabled]="advisor.isLoading()"
          class="px-3.5 py-1.5 rounded-sm bg-[#F27D26] hover:bg-orange-500 text-black text-xs font-mono uppercase font-black tracking-wider flex items-center gap-1.5 transition-colors disabled:opacity-50 cursor-pointer"
        >
          <mat-icon class="text-sm">{{ advisor.isLoading() ? 'hourglass_top' : 'auto_awesome' }}</mat-icon>
          {{ advisor.isLoading() ? 'Analyzing Digital Twin...' : 'Generate Shift Handover Advisory' }}
        </button>
      </div>

      <!-- Quick Prompt Pills -->
      <div class="flex flex-wrap items-center gap-2">
        <span class="text-[11px] font-mono uppercase font-bold text-zinc-500">Quick Analysis Queries:</span>
        @for (q of quickQueries; track q) {
          <button
            (click)="submitQuery(q)"
            [disabled]="advisor.isLoading()"
            class="px-2.5 py-1 rounded-sm bg-[#121212] hover:bg-[#222] border border-[#262626] text-xs font-mono text-zinc-300 transition-colors disabled:opacity-50 cursor-pointer uppercase font-bold"
          >
            {{ q }}
          </button>
        }
      </div>

      <!-- Main AI Output Card -->
      <div class="bg-[#0a0a0a] border border-[#222] rounded-sm p-6 shadow-2xl space-y-4">
        <div class="flex items-center justify-between border-b border-[#222] pb-3">
          <div class="flex items-center gap-2">
            <div class="w-8 h-8 rounded-sm bg-[#1c1c1c] border border-[#333] flex items-center justify-center text-[#F27D26] font-bold">
              <mat-icon class="text-base">smart_toy</mat-icon>
            </div>
            <div>
              <div class="text-xs font-mono font-black text-white uppercase tracking-wider">MINING.OS 4.0 Industrial Intelligence Advisory</div>
              <div class="text-[10px] font-mono text-zinc-500">Grounded with live telemetry & geostatistical digital twin state</div>
            </div>
          </div>

          @if (advisor.isLoading()) {
            <span class="text-xs font-mono text-[#F27D26] flex items-center gap-1.5 animate-pulse font-black uppercase">
              <mat-icon class="text-sm">sync</mat-icon>
              Synthesizing Multi-Domain Analytics...
            </span>
          }
        </div>

        @if (!advisor.currentAdvice() && !advisor.isLoading()) {
          <div class="p-8 text-center text-zinc-500 font-mono text-xs space-y-2">
            <mat-icon class="text-4xl text-zinc-600">psychology</mat-icon>
            <div class="uppercase tracking-wider font-bold text-zinc-400">Click "Generate Shift Handover Advisory" or choose a prompt to start real-time engineering diagnosis.</div>
          </div>
        } @else {
          <!-- Advisory Text Display -->
          <div class="max-w-none text-xs font-mono text-zinc-300 leading-relaxed whitespace-pre-wrap bg-[#050505] p-4 rounded-sm border border-[#1e1e1e]">
{{ advisor.currentAdvice() }}
          </div>
        }
      </div>

      <!-- Historical Inquiries -->
      @if (advisor.adviceHistory().length > 1) {
        <div class="bg-[#0a0a0a] border border-[#222] rounded-sm p-4 shadow-xl space-y-3">
          <h3 class="text-xs font-black font-mono text-white uppercase tracking-wider border-b border-[#222] pb-2">
            Previous Session Inquiries
          </h3>

          <div class="space-y-2 max-h-48 overflow-y-auto">
            @for (h of advisor.adviceHistory(); track h.timestamp) {
              <div class="bg-[#121212] p-2.5 rounded-sm border border-[#262626] text-xs font-mono">
                <div class="text-zinc-300 font-bold mb-1 uppercase text-[11px]">{{ h.prompt }}</div>
                <div class="text-[10px] text-zinc-500 truncate">{{ h.response.slice(0, 140) }}...</div>
              </div>
            }
          </div>
        </div>
      }
    </div>
  `,
})
export class AiAdvisorViewComponent {
  readonly advisor = inject(AiAdvisorService);

  readonly quickQueries = [
    'Analyze Excavator EXC-02 Hydraulic Overheat Risk',
    'Assess Shovel vs Crusher Cycle Congestion',
    'Evaluate Stockpile Silo Blending Feasibility',
    'Calculate Electric Fleet Demand Peak Shaving',
  ];

  triggerFullAnalysis() {
    this.advisor.queryAdvisor();
  }

  submitQuery(q: string) {
    this.advisor.queryAdvisor(q);
  }
}
