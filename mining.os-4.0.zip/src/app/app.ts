import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { HeaderComponent } from './components/header/header';
import { DigitalTwinCanvasComponent } from './components/digital-twin-canvas/digital-twin-canvas';
import { FleetViewComponent } from './components/fleet-view/fleet-view';
import { GeologyViewComponent } from './components/geology-view/geology-view';
import { MaintenanceViewComponent } from './components/maintenance-view/maintenance-view';
import { RoutesEnergyViewComponent } from './components/routes-energy-view/routes-energy-view';
import { PlantStockpileViewComponent } from './components/plant-stockpile-view/plant-stockpile-view';
import { WhatIfViewComponent } from './components/what-if-view/what-if-view';
import { IndustrialApiViewComponent } from './components/industrial-api-view/industrial-api-view';
import { RCodebaseViewComponent } from './components/r-codebase-view/r-codebase-view';
import { AiAdvisorViewComponent } from './components/ai-advisor-view/ai-advisor-view';
import { TelemetryModalComponent } from './components/telemetry-modal/telemetry-modal';
import { MachineTelemetry } from './models/mining-os.types';
import { MiningEngineService } from './services/mining-engine.service';

export type NavTabId =
  | 'overview'
  | 'fleet'
  | 'geology'
  | 'maintenance'
  | 'routes_energy'
  | 'plant_stockpile'
  | 'what_if'
  | 'industrial_api'
  | 'r_codebase'
  | 'ai_advisor';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [
    CommonModule,
    MatIconModule,
    HeaderComponent,
    DigitalTwinCanvasComponent,
    FleetViewComponent,
    GeologyViewComponent,
    MaintenanceViewComponent,
    RoutesEnergyViewComponent,
    PlantStockpileViewComponent,
    WhatIfViewComponent,
    IndustrialApiViewComponent,
    RCodebaseViewComponent,
    AiAdvisorViewComponent,
    TelemetryModalComponent,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  readonly engine = inject(MiningEngineService);
  readonly activeTab = signal<NavTabId>('overview');
  readonly inspectedMachine = signal<MachineTelemetry | null>(null);

  readonly navTabs: { id: NavTabId; label: string; icon: string; badge?: () => number | string }[] = [
    { id: 'overview', label: 'Digital Twin', icon: 'terrain' },
    { id: 'fleet', label: 'Autonomous Fleet', icon: 'local_shipping' },
    { id: 'geology', label: '3D Ore Geology', icon: 'science' },
    {
      id: 'maintenance',
      label: 'Predictive Maint',
      icon: 'build',
      badge: () => this.engine.anomalies().filter((a) => !a.acknowledged).length || '',
    },
    { id: 'routes_energy', label: 'Routes & EV Energy', icon: 'bolt' },
    { id: 'plant_stockpile', label: 'Plant & Blending', icon: 'precision_manufacturing' },
    { id: 'what_if', label: 'What-If Simulation', icon: 'tune' },
    {
      id: 'industrial_api',
      label: 'Industrial Gateway',
      icon: 'gavel',
      badge: () => this.engine.recommendations().length || '',
    },
    { id: 'r_codebase', label: 'R Codebase (16 Scripts)', icon: 'code' },
    { id: 'ai_advisor', label: 'AI Mining Engineer', icon: 'psychology' },
  ];

  setTab(tabId: NavTabId) {
    this.activeTab.set(tabId);
  }

  inspectMachine(m: MachineTelemetry) {
    this.inspectedMachine.set(m);
  }

  closeModal() {
    this.inspectedMachine.set(null);
  }
}
