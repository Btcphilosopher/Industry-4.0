import { Injectable } from '@angular/core';

export interface RFile {
  path: string;
  category: string;
  filename: string;
  description: string;
  code: string;
  tags: string[];
}

export type RScriptFile = RFile;

@Injectable({
  providedIn: 'root',
})
export class RCodebaseService {
  readonly rFiles: RFile[] = [
    {
      path: 'R/telemetry/telemetry_engine.R',
      category: 'Telemetry',
      filename: 'telemetry_engine.R',
      description: 'High-frequency telemetry ingestion schema, quality scoring, buffer validation, and time-series sliding windows',
      tags: ['S3/R6 Classes', 'Schema Validation', 'data.table', 'Sensor Ingestion'],
      code: `#' MINING.OS 4.0 - Telemetry Ingestion Engine
#' High-frequency sensor ingestion, sanitisation, and quality grading.

library(data.table)

TelemetryEngine <- R6::R6Class(
  "TelemetryEngine",
  public = list(
    buffer = NULL,
    max_buffer_size = 100000,
    valid_parameters = c(
      "RPM", "engine_temp_c", "hydraulic_pressure_bar",
      "fuel_consumption_lph", "battery_soc_pct", "motor_current_a",
      "motor_temp_c", "gps_x", "gps_y", "gps_z", "speed_kmh",
      "payload_tonnes", "vibration_mm_s", "brake_temp_c",
      "tyre_pressure_psi", "oil_quality_index", "coolant_temp_c"
    ),
    
    initialize = function(max_buffer_size = 100000) {
      self$max_buffer_size <- max_buffer_size
      self$buffer <- data.table(
        timestamp = as.POSIXct(character()),
        machine_id = character(),
        parameter = character(),
        value = numeric(),
        unit = character(),
        quality = numeric()
      )
    },
    
    #' Ingest a raw telemetry packet
    #' @param raw_packet list or data.frame with timestamp, machine_id, parameter, value, unit
    ingest = function(raw_packet) {
      ts <- if (is.null(raw_packet$timestamp)) Sys.time() else as.POSIXct(raw_packet$timestamp)
      m_id <- as.character(raw_packet$machine_id)
      param <- as.character(raw_packet$parameter)
      val <- as.numeric(raw_packet$value)
      u <- as.character(raw_packet$unit)
      
      # Parameter domain check
      if (!(param %in% self$valid_parameters)) {
        warning(sprintf("Unknown telemetry parameter: %s from machine %s", param, m_id))
        q_score <- 0.2
      } else {
        q_score <- self$calculate_quality(param, val)
      }
      
      new_row <- data.table(
        timestamp = ts,
        machine_id = m_id,
        parameter = param,
        value = val,
        unit = u,
        quality = q_score
      )
      
      self$buffer <- rbindlist(list(self$buffer, new_row), use.names = TRUE)
      
      # Trim buffer if exceeding max_buffer_size
      if (nrow(self$buffer) > self$max_buffer_size) {
        self$buffer <- tail(self$buffer, self$max_buffer_size)
      }
      
      invisible(new_row)
    },
    
    calculate_quality = function(parameter, value) {
      if (is.na(value) || is.nan(value)) return(0.0)
      
      # Bounds validation
      bounds <- list(
        RPM = c(0, 3200),
        engine_temp_c = c(-20, 130),
        hydraulic_pressure_bar = c(0, 420),
        battery_soc_pct = c(0, 100),
        vibration_mm_s = c(0, 50),
        speed_kmh = c(0, 80),
        payload_tonnes = c(0, 400)
      )
      
      if (parameter %in% names(bounds)) {
        b <- bounds[[parameter]]
        if (value < b[1] || value > b[2]) {
          return(0.3) # Out of physical bound - sensor faulty
        }
      }
      return(0.99) # High confidence signal
    },
    
    get_latest_machine_state = function(machine_id) {
      sub <- self$buffer[machine_id == machine_id]
      if (nrow(sub) == 0) return(NULL)
      dcast(sub[, .SD[.N], by = parameter], machine_id ~ parameter, value.var = "value")
    }
  )
)`
    },
    {
      path: 'R/digital_twin/digital_twin_model.R',
      category: 'Digital Twin',
      filename: 'digital_twin_model.R',
      description: 'Dynamic mine-wide state synchronizer across pit, benches, crushers, conveyors, stockpiles, and logistics',
      tags: ['State Representation', 'Dynamic Model', 'Industry 4.0'],
      code: `#' MINING.OS 4.0 - Mine Digital Twin Model
#' Holistic dynamic state of mine excavation, logistics, and processing.

MineDigitalTwin <- R6::R6Class(
  "MineDigitalTwin",
  public = list(
    site_id = "PIT-NORTH-01",
    mineral = "copper_gold",
    state = list(),
    history = list(),
    
    initialize = function(site_id = "PIT-NORTH-01", mineral = "iron_ore") {
      self$site_id <- site_id
      self$mineral <- mineral
      self$reset_state()
    },
    
    reset_state = function() {
      self$state <- list(
        timestamp = Sys.time(),
        ore_remaining_mt = 142.8,
        production_rate_tph = 4850,
        target_production_tph = 5200,
        fleet_status = list(
          active_trucks = 14,
          active_excavators = 4,
          active_drills = 3,
          fleet_availability_pct = 93.4,
          fleet_utilisation_pct = 87.2
        ),
        fuel_consumption_lph = 1420.5,
        energy_consumption_kwh = 18450.0,
        ore_grade_avg = 1.42, # % or g/t
        stockpile_levels = list(
          high_grade_t = 84000,
          medium_grade_t = 125000,
          low_grade_t = 310000,
          silica_blend_t = 45000
        ),
        processing_plant = list(
          crusher_infeed_tph = 3100,
          sag_mill_power_kw = 12800,
          flotation_recovery_pct = 91.8
        ),
        environmental = list(
          ambient_temp_c = 34.2,
          wind_speed_kmh = 18.5,
          dust_pm10 = 24.1
        )
      )
    },
    
    update_from_telemetry = function(telemetry_stream) {
      # Ingest dynamic readings and synchronise state
      self$state$timestamp <- Sys.time()
      # Update operational metrics
      self$history <- append(self$history, list(self$state))
      if (length(self$history) > 1000) {
        self$history <- tail(self$history, 1000)
      }
      invisible(self$state)
    },
    
    get_kpi_summary = function() {
      list(
        tph = self$state$production_rate_tph,
        fuel_per_tonne = self$state$fuel_consumption_lph / max(1, self$state$production_rate_tph),
        energy_per_tonne = self$state$energy_consumption_kwh / max(1, self$state$production_rate_tph),
        fleet_oee = (self$state$fleet_status$fleet_availability_pct * self$state$fleet_status$fleet_utilisation_pct) / 100
      )
    }
  )
)`
    },
    {
      path: 'R/fleet/fleet_manager.R',
      category: 'Fleet Management',
      filename: 'fleet_manager.R',
      description: 'Fleet tracking, cycle time decomposition, OEE availability & utilisation KPIs, tonnes/km metrics',
      tags: ['OEE', 'Cycle Analytics', 'Haulage Performance'],
      code: `#' MINING.OS 4.0 - Fleet Management Engine
#' Calculates real-time fleet productivity, cycle efficiency, and fuel intensity.

calculate_fleet_kpis <- function(telemetry_df, cycle_events_df) {
  # cycle_events_df columns: machine_id, cycle_id, phase (spotting, loading, hauling, dumping, empty_return), duration_sec, payload_tonnes, distance_km, fuel_liters
  
  summary_by_truck <- cycle_events_df[, .(
    total_tonnes = sum(payload_tonnes, na.rm = TRUE),
    total_distance_km = sum(distance_km, na.rm = TRUE),
    total_fuel_l = sum(fuel_liters, na.rm = TRUE),
    total_cycle_time_min = sum(duration_sec, na.rm = TRUE) / 60,
    cycles_count = uniqueN(cycle_id)
  ), by = machine_id]
  
  summary_by_truck[, ':='(
    tonnes_per_hour = total_tonnes / (total_cycle_time_min / 60),
    tonnes_per_km = total_tonnes / pmax(0.1, total_distance_km),
    fuel_per_tonne = total_fuel_l / pmax(1, total_tonnes),
    avg_cycle_min = total_cycle_time_min / pmax(1, cycles_count)
  )]
  
  fleet_total_tph <- sum(summary_by_truck$tonnes_per_hour, na.rm = TRUE)
  fleet_avg_fuel_intensity <- sum(summary_by_truck$total_fuel_l) / pmax(1, sum(summary_by_truck$total_tonnes))
  
  return(list(
    truck_metrics = summary_by_truck,
    fleet_tph = fleet_total_tph,
    fleet_fuel_intensity_l_t = fleet_avg_fuel_intensity
  ))
}`
    },
    {
      path: 'R/geology/ore_grade_modeller.R',
      category: 'Geology & Spatial',
      filename: 'ore_grade_modeller.R',
      description: 'Geostatistical spatial modelling using Ordinary Kriging, Variogram estimation, and Inverse Distance Weighting (IDW)',
      tags: ['Spatial Kriging', 'IDW Interpolation', 'Variogram', 'Block Model'],
      code: `#' MINING.OS 4.0 - Ore-Grade Geostatistical Modeller
#' Spatial interpolation, variography, and block model resource estimations.

library(gstat)
library(sp)

estimate_ore_block_grades <- function(sample_points, target_grid, method = "kriging", variogram_model = "Sph") {
  # sample_points: data.frame(x, y, z, grade, density, rock_type)
  # target_grid: data.frame(x, y, z)
  
  coordinates(sample_points) <- ~x+y+z
  coordinates(target_grid) <- ~x+y+z
  
  if (method == "kriging") {
    # Compute experimental variogram
    v_exp <- variogram(grade ~ 1, data = sample_points)
    # Fit theoretical model (Spherical / Exponential / Gaussian)
    v_fit <- fit.variogram(v_exp, model = vgm(psill = var(sample_points$grade), model = variogram_model, range = 250, nugget = 0.05))
    
    # Execute Ordinary 3D Kriging
    kriged_result <- krige(grade ~ 1, sample_points, target_grid, model = v_fit)
    
    res_df <- data.frame(
      x = coordinates(target_grid)[,1],
      y = coordinates(target_grid)[,2],
      z = coordinates(target_grid)[,3],
      predicted_grade = kriged_result$var1.pred,
      variance = kriged_result$var1.var,
      confidence = pmax(0, 1 - sqrt(kriged_result$var1.var) / (mean(sample_points$grade) + 1e-4))
    )
    return(list(predictions = res_df, variogram = v_fit))
  } else {
    # Fallback to Inverse Distance Weighting (IDW with power p=2)
    idw_result <- idw(grade ~ 1, sample_points, target_grid, idp = 2.0)
    res_df <- data.frame(
      x = coordinates(target_grid)[,1],
      y = coordinates(target_grid)[,2],
      z = coordinates(target_grid)[,3],
      predicted_grade = idw_result$var1.pred,
      variance = NA,
      confidence = 0.85
    )
    return(list(predictions = res_df, variogram = NULL))
  }
}`
    },
    {
      path: 'R/optimisation/haulage_optimiser.R',
      category: 'Optimisation',
      filename: 'haulage_optimiser.R',
      description: 'Mixed-Integer Linear Programming (MILP) & dynamic dispatch engine matching haul trucks to shovels and crushers',
      tags: ['MILP Solver', 'Dynamic Dispatch', 'Queue Minimisation', 'lpSolve'],
      code: `#' MINING.OS 4.0 - Autonomous Haulage Optimiser
#' Mixed-Integer Linear Programming for shovel-truck-crusher assignment.

library(lpSolve)

optimize_haul_dispatch <- function(trucks, shovels, dumps, road_matrix, weights = list(tph = 1.0, fuel = 0.3, queue = 0.5)) {
  # trucks: data.frame(id, capacity_t, location_node, battery_soc, is_electric)
  # shovels: data.frame(id, location_node, dig_rate_tph, queue_length)
  # dumps: data.frame(id, location_node, capacity_tph, queue_length)
  
  n_trucks <- nrow(trucks)
  n_shovels <- nrow(shovels)
  n_dumps <- nrow(dumps)
  
  # Objective: minimise travel time + queue penalty - shovel priority reward
  cost_matrix <- matrix(0, nrow = n_trucks, ncol = n_shovels * n_dumps)
  
  idx <- 1
  for (s in 1:n_shovels) {
    for (d in 1:n_dumps) {
      for (t in 1:n_trucks) {
        t_loc <- trucks$location_node[t]
        s_loc <- shovels$location_node[s]
        d_loc <- dumps$location_node[d]
        
        travel_time_empty <- road_matrix[t_loc, s_loc]
        travel_time_loaded <- road_matrix[s_loc, d_loc]
        total_time <- travel_time_empty + travel_time_loaded
        
        queue_penalty <- shovels$queue_length[s] * 2.5 + dumps$queue_length[d] * 1.8
        
        # Energy penalty if truck is low on SOC
        soc_penalty <- if (trucks$is_electric[t] && trucks$battery_soc[t] < 25) 1000 else 0
        
        cost_matrix[t, idx] <- total_time * weights$tph + queue_penalty * weights$queue + soc_penalty
      }
      idx <- idx + 1
    }
  }
  
  # Assignment constraints: each truck assigned to exactly 1 (shovel, dump) pair
  # Solved via linear sum assignment or lp
  res <- lp.assign(cost_matrix)
  
  assignments <- list()
  for (t in 1:n_trucks) {
    assigned_idx <- which(res$solution[t, ] == 1)
    if (length(assigned_idx) > 0) {
      s_id <- ceiling(assigned_idx / n_dumps)
      d_id <- ((assigned_idx - 1) %% n_dumps) + 1
      assignments[[length(assignments) + 1]] <- list(
        truck_id = trucks$id[t],
        shovel_id = shovels$id[s_id],
        dump_id = dumps$id[d_id],
        estimated_cycle_time = cost_matrix[t, assigned_idx]
      )
    }
  }
  return(assignments)
}`
    },
    {
      path: 'R/spatial/road_network_graph.R',
      category: 'Geology & Spatial',
      filename: 'road_network_graph.R',
      description: 'igraph-based road network with gradient penalties, speed limit curves, and regenerative braking energy profiles',
      tags: ['igraph', 'Shortest Path', 'Regenerative Braking', 'Gradient Penalty'],
      code: `#' MINING.OS 4.0 - Mine Road Network Spatial Graph
#' Graph topology with gradient resistance, rolling resistance, and regen energy.

library(igraph)

build_mine_road_graph <- function(nodes_df, edges_df) {
  # nodes_df: id, x, y, z (elevation in meters)
  # edges_df: from, to, distance_m, speed_limit_kmh, gradient_pct, surface_quality
  
  # Compute dynamic edge weights: Time (sec), Diesel (liters), Electric Energy (kWh)
  edges_df$speed_ms <- (edges_df$speed_limit_kmh * edges_df$surface_quality) / 3.6
  edges_df$travel_time_sec <- edges_df$distance_m / pmax(2.0, edges_df$speed_ms)
  
  # Power calculation based on vehicle physics:
  # P = F_total * v = (F_roll + F_grade + F_aero) * v
  # Downhill gradient generates regenerative braking for electric haulers!
  edges_df$energy_kwh <- sapply(1:nrow(edges_df), function(i) {
    dist_km <- edges_df$distance_m[i] / 1000
    grad <- edges_df$gradient_pct[i] # e.g. -8.0 for downhill
    if (grad < -3.0) {
      # Regenerative recovery (efficiency 72%)
      return(dist_km * grad * 0.45 * 0.72) # Negative kWh (charging battery)
    } else {
      # Uphill / Flat haulage
      return(dist_km * (4.2 + max(0, grad * 1.8)))
    }
  })
  
  g <- graph_from_data_frame(d = edges_df, vertices = nodes_df, directed = TRUE)
  return(g)
}

find_optimal_route <- function(graph, origin_node, dest_node, criterion = "energy") {
  weight_attr <- switch(criterion,
    "time" = "travel_time_sec",
    "energy" = "energy_kwh",
    "distance" = "distance_m",
    "travel_time_sec"
  )
  
  sp <- shortest_paths(graph, from = origin_node, to = dest_node, weights = E(graph)[[weight_attr]], output = "both")
  return(list(
    nodes = V(graph)[sp$vpath[[1]]]$name,
    total_cost = sum(E(graph)[sp$epath[[1]]][[weight_attr]])
  ))
}`
    },
    {
      path: 'R/machine_learning/predictive_maintenance.R',
      category: 'Machine Learning',
      filename: 'predictive_maintenance.R',
      description: 'Multi-sensor degradation prediction, Remaining Useful Life (RUL) estimation, and failure risk classification',
      tags: ['RUL Estimation', 'Failure Risk', 'Thermal Degradation', 'Vibration Analysis'],
      code: `#' MINING.OS 4.0 - Predictive Maintenance Engine
#' Multi-sensor telemetry degradation tracking and Remaining Useful Life (RUL).

library(ranger)

predict_equipment_degradation <- function(sensor_readings, component_model) {
  # sensor_readings: vibration_mm_s, hydraulic_pressure_bar, engine_temp_c, oil_quality_idx, operating_hours
  
  # Composite wear index computation
  vib_factor <- (sensor_readings$vibration_mm_s / 4.5)^2
  temp_factor <- max(0, (sensor_readings$engine_temp_c - 95) / 15)
  press_factor <- abs(sensor_readings$hydraulic_pressure_bar - 280) / 40
  oil_factor <- (100 - sensor_readings$oil_quality_idx) / 30
  
  degradation_score <- (vib_factor * 0.4 + temp_factor * 0.25 + press_factor * 0.2 + oil_factor * 0.15)
  failure_risk_pct <- pmin(99.9, pmax(1.0, degradation_score * 35))
  
  # Estimate Remaining Useful Life (hours)
  baseline_rul <- 850
  wear_rate <- max(0.2, degradation_score)
  estimated_rul_hours <- round(pmax(4, baseline_rul / wear_rate))
  
  priority <- if (failure_risk_pct > 75) "CRITICAL" else if (failure_risk_pct > 45) "HIGH" else "NORMAL"
  
  return(list(
    failure_risk_pct = failure_risk_pct,
    rul_hours = estimated_rul_hours,
    priority = priority,
    recommended_action = if (priority == "CRITICAL") "Immediate hydraulic pump & bearing inspection" else "Routine 250hr servicing"
  ))
}`
    },
    {
      path: 'R/machine_learning/anomaly_detector.R',
      category: 'Machine Learning',
      filename: 'anomaly_detector.R',
      description: 'Real-time statistical anomaly detector using rolling Z-scores, multi-variate bounds, and sudden deviation alarms',
      tags: ['Anomaly Detection', 'Rolling Z-Score', 'Spike Filter', 'Safety Alarms'],
      code: `#' MINING.OS 4.0 - Real-Time Anomaly Detector
#' Flags sensor drift, thermal spikes, hydraulic cavitation, and cycle outliers.

detect_telemetry_anomalies <- function(time_series_data, z_threshold = 3.0) {
  # time_series_data: data.table(timestamp, machine_id, parameter, value)
  
  anomalies <- time_series_data[, {
    rolling_mean <- frollmean(value, n = 30, fill = NA, align = "right")
    rolling_sd <- frollapply(value, n = 30, FUN = sd, fill = NA, align = "right")
    z_score <- abs(value - rolling_mean) / pmax(1e-4, rolling_sd)
    
    is_anomaly <- (!is.na(z_score)) & (z_score > z_threshold)
    
    list(
      timestamp = timestamp[is_anomaly],
      value = value[is_anomaly],
      expected_mean = rolling_mean[is_anomaly],
      z_score = z_score[is_anomaly]
    )
  }, by = .(machine_id, parameter)]
  
  return(anomalies)
}`
    },
    {
      path: 'R/optimisation/production_optimiser.R',
      category: 'Optimisation',
      filename: 'production_optimiser.R',
      description: 'Configurable multi-objective optimization function balancing ore recovery, TPH throughput, energy, and maintenance cost',
      tags: ['Multi-Objective', 'Weighted Loss', 'TPH Maximisation'],
      code: `#' MINING.OS 4.0 - Mine Production Optimiser
#' Multi-objective global optimization for mine-to-mill value chain.

production_objective_function <- function(
  production_tph,
  energy_kwh,
  fuel_liters,
  downtime_hours,
  maintenance_risk_score,
  weights = list(
    production = 1.0,
    energy = 0.15,
    fuel = 1.25,
    downtime = 4500.0,
    maintenance = 8000.0
  )
) {
  revenue <- production_tph * 85.0 # Value per tonne product
  cost_energy <- energy_kwh * weights$energy
  cost_fuel <- fuel_liters * weights$fuel
  cost_downtime <- downtime_hours * weights$downtime
  cost_maint <- maintenance_risk_score * weights$maintenance
  
  net_objective <- revenue - cost_energy - cost_fuel - cost_downtime - cost_maint
  return(net_objective)
}`
    },
    {
      path: 'R/stockpiles/stockpile_blender.R',
      category: 'Plant & Stockpile',
      filename: 'stockpile_blender.R',
      description: 'Linear programming solver calculating stockpile blending ratios to satisfy metallurgical feed specifications',
      tags: ['Grade Blending', 'Crusher Infeed', 'Metallurgical Spec', 'LP Solver'],
      code: `#' MINING.OS 4.0 - Stockpile Blending Optimiser
#' Blends material from multiple stockpiles to achieve target plant feed grade.

library(lpSolve)

optimize_stockpile_blend <- function(stockpiles, target_feed_tph = 3500, target_grade = 1.65, max_silica_pct = 4.2) {
  # stockpiles: data.frame(id, available_t, grade_pct, silica_pct, cost_per_t)
  n <- nrow(stockpiles)
  
  # Decision variables: tonnes extracted from each stockpile x_1, x_2, ..., x_n
  # Objective: minimise cost or maximise grade compliance
  obj <- stockpiles$cost_per_t
  
  # Constraints:
  # 1. sum(x_i) == target_feed_tph
  # 2. sum(grade_i * x_i) / target_feed_tph >= target_grade
  # 3. sum(silica_i * x_i) / target_feed_tph <= max_silica_pct
  # 4. x_i <= available_t
  
  con_mat <- rbind(
    rep(1, n),
    stockpiles$grade_pct,
    stockpiles$silica_pct,
    diag(n)
  )
  
  con_dir <- c("==", ">=", "<=", rep("<=", n))
  con_rhs <- c(
    target_feed_tph,
    target_grade * target_feed_tph,
    max_silica_pct * target_feed_tph,
    stockpiles$available_t
  )
  
  res <- lp("min", obj, con_mat, con_dir, con_rhs)
  
  if (res$status == 0) {
    stockpiles$allocated_tph <- res$solution
    stockpiles$blend_ratio_pct <- (res$solution / target_feed_tph) * 100
    return(list(
      success = TRUE,
      stockpiles = stockpiles,
      resulting_grade = sum(stockpiles$allocated_tph * stockpiles$grade_pct) / target_feed_tph,
      resulting_silica = sum(stockpiles$allocated_tph * stockpiles$silica_pct) / target_feed_tph
    ))
  } else {
    return(list(success = FALSE, message = "Infeasible blending spec with current stockpiles"))
  }
}`
    },
    {
      path: 'R/drilling/drill_optimiser.R',
      category: 'Drilling & Blasting',
      filename: 'drill_optimiser.R',
      description: 'Autonomous blast pattern optimizer calculating hole spacing, burden, depth, and energy distribution',
      tags: ['Blast Pattern', 'Burden & Spacing', 'Rock Hardness', 'Fragmentation'],
      code: `#' MINING.OS 4.0 - Autonomous Drilling & Blast Pattern Optimiser
#' Calculates optimal drill coordinates, hole spacing, and powder factor.

optimize_drill_pattern <- function(bench_polygon, rock_hardness_bwi, desired_fragmentation_p80_mm = 150) {
  # Kuz-Ram model for blast fragmentation
  # Spacing S and Burden B based on rock hardness (Bond Work Index)
  base_burden_m <- max(3.5, 7.5 - (rock_hardness_bwi / 3.0))
  base_spacing_m <- base_burden_m * 1.15
  subdrill_m <- base_burden_m * 0.3
  bench_height_m <- 15.0
  hole_depth_m <- bench_height_m + subdrill_m
  
  # Generate regular staggered pattern inside polygon
  x_range <- seq(min(bench_polygon$x), max(bench_polygon$x), by = base_spacing_m)
  y_range <- seq(min(bench_polygon$y), max(bench_polygon$y), by = base_burden_m)
  
  holes <- expand.grid(x = x_range, y = y_range)
  holes$stagger_offset <- ifelse((1:nrow(holes) %% 2) == 0, base_spacing_m / 2, 0)
  holes$x <- holes$x + holes$stagger_offset
  holes$depth_m <- hole_depth_m
  holes$burden_m <- base_burden_m
  holes$spacing_m <- base_spacing_m
  holes$powder_factor_kg_t <- (rock_hardness_bwi * 0.045) + 0.32
  
  return(holes)
}`
    },
    {
      path: 'R/energy/energy_and_battery_optimiser.R',
      category: 'Energy & Electric Fleet',
      filename: 'energy_and_battery_optimiser.R',
      description: 'Electric haul fleet battery State-of-Charge (SOC) optimizer and dynamic charging station allocation',
      tags: ['Battery SOC/SOH', 'Electric Mining Trucks', 'Peak Shaving', 'Charging Queue'],
      code: `#' MINING.OS 4.0 - Battery Electric Fleet & Energy Optimiser
#' Schedules vehicle charging, manages peak substation demand, and guards battery longevity.

schedule_electric_truck_charging <- function(electric_trucks, chargers, electricity_price_curve) {
  # electric_trucks: id, current_soc, battery_kwh, required_next_cycle_kwh, urgency_score
  # chargers: id, power_kw, is_occupied
  
  urgent_trucks <- electric_trucks[electric_trucks$current_soc < 30, ]
  normal_trucks <- electric_trucks[electric_trucks$current_soc >= 30, ]
  
  # Sort by urgency
  urgent_trucks <- urgent_trucks[order(urgent_trucks$current_soc), ]
  
  assignments <- list()
  available_chargers <- chargers[!chargers$is_occupied, ]
  
  for (i in seq_len(min(nrow(urgent_trucks), nrow(available_chargers)))) {
    assignments[[length(assignments) + 1]] <- list(
      truck_id = urgent_trucks$id[i],
      charger_id = available_chargers$id[i],
      target_soc = 85, # Stop at 85% to preserve battery SOH and capture downhill regen
      estimated_charge_time_min = ((85 - urgent_trucks$current_soc[i]) / 100 * urgent_trucks$battery_kwh[i]) / available_chargers$power_kw[i] * 60
    )
  }
  return(assignments)
}`
    },
    {
      path: 'R/scheduling/mine_scheduler.R',
      category: 'Scheduling',
      filename: 'mine_scheduler.R',
      description: 'Multi-horizon digital mine production scheduler integrating drilling, blasting, excavation, crushing, and maintenance',
      tags: ['Production Planning', 'Gantt Scheduler', 'Resource Constraints'],
      code: `#' MINING.OS 4.0 - Mine Production Scheduler
#' Generates hourly, shift, and weekly resource-constrained excavation schedules.

generate_shift_schedule <- function(targets_tph, equipment_roster, benches_ready) {
  hours_in_shift <- 12
  schedule_grid <- data.frame(
    hour = 1:hours_in_shift,
    target_production = targets_tph,
    drilling_bench = benches_ready$drill[1],
    excavation_bench_1 = benches_ready$excavate[1],
    excavation_bench_2 = benches_ready$excavate[2],
    crusher_planned_tph = pmin(targets_tph, 3800)
  )
  return(schedule_grid)
}`
    },
    {
      path: 'R/simulation/discrete_event_simulator.R',
      category: 'Simulation',
      filename: 'discrete_event_simulator.R',
      description: 'Discrete-Event Mining Simulator (DES) executing stochastic truck-shovel-crusher loops and breakdown simulations',
      tags: ['Simmer/DES', 'Monte Carlo', 'Queueing Theory', 'Stochastic Breakdown'],
      code: `#' MINING.OS 4.0 - Discrete Event Mining Simulator
#' High-throughput discrete event simulator for what-if scenarios and capacity bottleneck analysis.

simulate_mine_operations <- function(n_trucks = 12, n_shovels = 3, sim_hours = 24, crusher_rate_tph = 3500) {
  # State variables
  time_sec <- 0
  max_time_sec <- sim_hours * 3600
  total_tonnes_moved <- 0
  truck_states <- rep("empty_travel", n_trucks)
  truck_timer <- rexp(n_trucks, rate = 1 / 480) # 8 min travel
  
  shovel_queues <- rep(0, n_shovels)
  crusher_queue <- 0
  
  event_log <- list()
  
  while (time_sec < max_time_sec) {
    # Advance time to nearest truck event
    min_event_idx <- which.min(truck_timer)
    dt <- truck_timer[min_event_idx]
    time_sec <- time_sec + dt
    truck_timer <- truck_timer - dt
    
    # State transitions
    curr_state <- truck_states[min_event_idx]
    if (curr_state == "empty_travel") {
      truck_states[min_event_idx] <- "loading"
      truck_timer[min_event_idx] <- rnorm(1, mean = 210, sd = 25) # ~3.5 min loading
    } else if (curr_state == "loading") {
      truck_states[min_event_idx] <- "loaded_haul"
      truck_timer[min_event_idx] <- rnorm(1, mean = 540, sd = 45) # ~9 min haul
    } else if (curr_state == "loaded_haul") {
      truck_states[min_event_idx] <- "dumping"
      truck_timer[min_event_idx] <- rnorm(1, mean = 90, sd = 15) # 1.5 min dump
      total_tonnes_moved <- total_tonnes_moved + 220 # 220t payload
    } else if (curr_state == "dumping") {
      truck_states[min_event_idx] <- "empty_travel"
      truck_timer[min_event_idx] <- rnorm(1, mean = 480, sd = 40)
    }
  }
  
  return(list(
    total_tonnes = total_tonnes_moved,
    effective_tph = total_tonnes_moved / sim_hours,
    simulated_hours = sim_hours
  ))
}`
    },
    {
      path: 'R/api/industrial_control_api.R',
      category: 'Industrial Control API',
      filename: 'industrial_control_api.R',
      description: 'Validation layer ensuring all algorithmic recommendations pass strict safety constraints before SCADA/PLC dispatch',
      tags: ['Safety Interlock', 'SCADA Gateway', 'Audit Trail', 'Fail-Safe'],
      code: `#' MINING.OS 4.0 - Industrial Control Recommendation & Validation API
#' Ensures mathematical recommendations pass operational safety envelopes before dispatch.

IndustrialControlGateway <- R6::R6Class(
  "IndustrialControlGateway",
  public = list(
    audit_trail = list(),
    safety_envelope = list(
      max_truck_payload_tonnes = 260.0,
      max_ramp_speed_kmh = 45.0,
      min_battery_soc_pct = 12.0,
      max_tire_pressure_psi = 125.0,
      max_hydraulic_temp_c = 95.0
    ),
    
    validate_and_dispatch = function(recommendation) {
      rec_id <- recommendation$id %||% paste0("REC-", as.numeric(Sys.time()))
      machine <- recommendation$machine_id
      action <- recommendation$action
      val_result <- list(
        id = rec_id,
        timestamp = Sys.time(),
        machine_id = machine,
        action = action,
        passed = TRUE,
        status = "VALIDATED_AUTO",
        violations = character()
      )
      
      # Safety Check 1: Speed limit boundary
      if (!is.null(recommendation$target_speed) && recommendation$target_speed > self$safety_envelope$max_ramp_speed_kmh) {
        val_result$passed <- FALSE
        val_result$violations <- c(val_result$violations, "Speed exceeds ramp safety envelope")
      }
      
      # Safety Check 2: Battery threshold
      if (!is.null(recommendation$current_soc) && recommendation$current_soc < self$safety_envelope$min_battery_soc_pct && action != "DIVERT_CHARGER") {
        val_result$passed <- FALSE
        val_result$violations <- c(val_result$violations, "Vehicle SOC below critical lockout threshold")
      }
      
      if (!val_result$passed) {
        val_result$status <- "REJECTED_SAFETY_VIOLATION"
        warning(sprintf("SAFETY GATEWAY REJECTED: %s for %s. Reasons: %s", action, machine, paste(val_result$violations, collapse = "; ")))
      } else {
        val_result$status <- "APPROVED_OPERATOR"
      }
      
      self$audit_trail[[length(self$audit_trail) + 1]] <- val_result
      return(val_result)
    }
  )
)`
    },
    {
      path: 'R/telemetry/model_drift_tracker.R',
      category: 'Machine Learning',
      filename: 'model_drift_tracker.R',
      description: 'Continuous monitoring of ML model prediction errors, Population Stability Index (PSI), and auto-retraining alerts',
      tags: ['Model Drift', 'PSI', 'Rolling RMSE', 'Auto-Retrain'],
      code: `#' MINING.OS 4.0 - Model Drift & Degradation Monitor
#' Tracks prediction residuals and feature distribution drift.

evaluate_model_drift <- function(actuals, predictions, baseline_rmse = 12.5) {
  residuals <- actuals - predictions
  current_rmse <- sqrt(mean(residuals^2, na.rm = TRUE))
  
  drift_ratio <- current_rmse / baseline_rmse
  retrain_flag <- drift_ratio > 1.35 # >35% degradation
  
  return(list(
    current_rmse = current_rmse,
    baseline_rmse = baseline_rmse,
    degradation_pct = round((drift_ratio - 1) * 100, 1),
    retraining_required = retrain_flag,
    status = if (retrain_flag) "DEGRADED - RETRAIN TRIGGERED" else "STABLE"
  ))
}`
    }
  ];

  getAllFiles(): RFile[] {
    return this.rFiles;
  }

  scripts(): RFile[] {
    return this.rFiles;
  }

  getFileByPath(path: string): RFile | undefined {
    return this.rFiles.find((f) => f.path === path);
  }

  getCategories(): string[] {
    return Array.from(new Set(this.rFiles.map((f) => f.category)));
  }
}
