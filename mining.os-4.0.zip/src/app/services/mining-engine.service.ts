import { Injectable, signal, computed } from '@angular/core';
import {
  MineSiteConfig,
  MachineTelemetry,
  RoadNode,
  RoadEdge,
  Stockpile,
  ProcessingPlant,
  OreBlock,
  Recommendation,
  AnomalyAlert,
  MaintenanceWorkOrder,
  IndustrialEvent,
  WhatIfScenarioInput,
  WhatIfScenarioResult,
  ModelDriftStats,
  ScheduleItem,
  ValidationStatus
} from '../models/mining-os.types';

@Injectable({
  providedIn: 'root',
})
export class MiningEngineService {
  // Preset Mineral Sites
  readonly availableSites: MineSiteConfig[] = [
    {
      id: 'SITE-PILBARA-FE',
      name: 'Pilbara Iron Ridge Complex',
      location: 'Western Australia',
      mineralType: 'iron_ore',
      mineralLabel: 'Iron Ore (Hematite/Goethite)',
      primaryGradeUnit: '% Fe',
      targetDailyTPH: 5400,
      miningMethod: 'open_pit',
      dieselCostPerLiter: 1.35,
      electricityCostPerKWh: 0.14,
      cutOffGrade: 56.5,
      targetPlantGrade: 62.4,
    },
    {
      id: 'SITE-ATACAMA-CU',
      name: 'Atacama Porphyry Pit 4',
      location: 'Antofagasta, Chile',
      mineralType: 'copper_gold',
      mineralLabel: 'Copper-Gold Porphyry',
      primaryGradeUnit: '% Cu (0.35g/t Au)',
      targetDailyTPH: 4800,
      miningMethod: 'open_pit',
      dieselCostPerLiter: 1.42,
      electricityCostPerKWh: 0.12,
      cutOffGrade: 0.45,
      targetPlantGrade: 1.25,
    },
    {
      id: 'SITE-GREENBUSH-LI',
      name: 'Greenbushes Spodumene Open-Cut',
      location: 'South West WA',
      mineralType: 'lithium_pegmatite',
      mineralLabel: 'Lithium Spodumene',
      primaryGradeUnit: '% Li2O',
      targetDailyTPH: 3200,
      miningMethod: 'open_pit',
      dieselCostPerLiter: 1.38,
      electricityCostPerKWh: 0.16,
      cutOffGrade: 1.1,
      targetPlantGrade: 2.35,
    },
    {
      id: 'SITE-NEVADA-AU',
      name: 'Carlin Gold Corridor Deep Pit',
      location: 'Nevada, USA',
      mineralType: 'gold_quartz',
      mineralLabel: 'Refractory Gold',
      primaryGradeUnit: 'g/t Au',
      targetDailyTPH: 2900,
      miningMethod: 'open_pit',
      dieselCostPerLiter: 1.28,
      electricityCostPerKWh: 0.11,
      cutOffGrade: 1.2,
      targetPlantGrade: 3.8,
    },
    {
      id: 'SITE-BOWEN-COAL',
      name: 'Bowen Basin Metallurgical Open-Cut',
      location: 'Queensland, Australia',
      mineralType: 'metallurgical_coal',
      mineralLabel: 'Hard Coking Coal',
      primaryGradeUnit: '% Yield (CSN 8.5)',
      targetDailyTPH: 6200,
      miningMethod: 'bench_stripping',
      dieselCostPerLiter: 1.30,
      electricityCostPerKWh: 0.13,
      cutOffGrade: 65.0,
      targetPlantGrade: 84.0,
    }
  ];

  // Reactive State Signals
  readonly activeSite = signal<MineSiteConfig>(this.availableSites[0]);
  readonly isSimulationRunning = signal<boolean>(true);
  readonly simulationSpeed = signal<number>(1); // 1x, 2x, 5x, 10x
  readonly simulationTickCount = signal<number>(0);
  
  // Real-time Mine Digital Twin State
  readonly machines = signal<MachineTelemetry[]>([]);
  readonly roadNodes = signal<RoadNode[]>([]);
  readonly roadEdges = signal<RoadEdge[]>([]);
  readonly stockpiles = signal<Stockpile[]>([]);
  readonly processingPlant = signal<ProcessingPlant>({
    crusherStatus: 'operational',
    crusherThroughputTph: 4950,
    crusherCapacityTph: 5500,
    sagMillPowerKw: 14200,
    flotationRecoveryPct: 92.4,
    stockpileFeedRatio: { 'STK-01': 55, 'STK-02': 35, 'STK-04': 10 },
    totalMilledTodayTonnes: 41200,
    targetMilledTodayTonnes: 60000,
    currentFeedGrade: 62.1,
  });

  readonly oreBlocks = signal<OreBlock[]>([]);
  readonly recommendations = signal<Recommendation[]>([]);
  readonly anomalies = signal<AnomalyAlert[]>([]);
  readonly workOrders = signal<MaintenanceWorkOrder[]>([]);
  readonly eventBus = signal<IndustrialEvent[]>([]);
  readonly modelDriftStats = signal<ModelDriftStats[]>([
    {
      modelName: 'Ore-Grade Kriging Predictor (v3.2)',
      version: '3.2.0',
      rmse: 0.124,
      baselineRmse: 0.118,
      psiScore: 0.082,
      featureDriftDetected: false,
      confidenceMean: 0.94,
      sampleCount: 14200,
      retrainingRecommended: false,
      lastRetrained: '3 days ago',
    },
    {
      modelName: 'Hydraulic Pump Degradation RUL (XGBoost)',
      version: '2.1.4',
      rmse: 14.8,
      baselineRmse: 11.2,
      psiScore: 0.245,
      featureDriftDetected: true,
      confidenceMean: 0.82,
      sampleCount: 8950,
      retrainingRecommended: true,
      lastRetrained: '14 days ago',
    },
    {
      modelName: 'Autonomous Cycle Time Forecaster (RandomForest)',
      version: '4.0.1',
      rmse: 0.42,
      baselineRmse: 0.39,
      psiScore: 0.054,
      featureDriftDetected: false,
      confidenceMean: 0.96,
      sampleCount: 22800,
      retrainingRecommended: false,
      lastRetrained: 'Yesterday',
    }
  ]);

  readonly scheduleItems = signal<ScheduleItem[]>([
    {
      id: 'SCH-01',
      timeSlot: '06:00 - 12:00',
      activity: 'Excavation',
      assignedEquipment: ['SHV-01', 'TRK-101', 'TRK-102', 'TRK-201'],
      benchLocation: 'Bench-03 North Pit (High Grade)',
      targetTonnes: 16500,
      priority: 'high_grade',
    },
    {
      id: 'SCH-02',
      timeSlot: '06:00 - 12:00',
      activity: 'Drilling',
      assignedEquipment: ['DRL-01', 'DRL-02'],
      benchLocation: 'Bench-04 South Face Pattern B',
      targetTonnes: 0,
      priority: 'routine',
    },
    {
      id: 'SCH-03',
      timeSlot: '08:00 - 10:30',
      activity: 'PM Maintenance',
      assignedEquipment: ['TRK-104'],
      benchLocation: 'Main Maintenance Workshop Bay 2',
      targetTonnes: 0,
      priority: 'critical',
    },
    {
      id: 'SCH-04',
      timeSlot: '12:00 - 18:00',
      activity: 'Crushing',
      assignedEquipment: ['CRU-01', 'CNV-01'],
      benchLocation: 'Primary Gyratory Infeed Silo',
      targetTonnes: 32000,
      priority: 'routine',
    }
  ]);

  // Overall KPI Computations
  readonly totalTonnesMovedToday = signal<number>(44800);
  readonly currentTotalTPH = computed(() => {
    const list = this.machines();
    const activeHaulers = list.filter((m) => m.status === 'hauling_loaded');
    return Math.round(activeHaulers.length * 680 + 1200 + (Math.sin(this.simulationTickCount() / 5) * 150));
  });

  readonly averageOreGrade = computed(() => {
    const site = this.activeSite();
    const tick = this.simulationTickCount();
    return +(site.targetPlantGrade + Math.sin(tick / 10) * 0.12).toFixed(2);
  });

  readonly fleetAvailabilityPct = computed(() => {
    const list = this.machines();
    if (list.length === 0) return 94.2;
    const operational = list.filter((m) => !m.status.includes('maintenance') && !m.status.includes('breakdown'));
    return +((operational.length / list.length) * 100).toFixed(1);
  });

  readonly fleetUtilisationPct = computed(() => {
    const list = this.machines();
    if (list.length === 0) return 88.5;
    const productive = list.filter((m) => ['hauling_loaded', 'hauling_empty', 'loading', 'digging', 'drilling'].includes(m.status));
    return +((productive.length / list.length) * 100).toFixed(1);
  });

  readonly fuelIntensityLitersPerTonne = computed(() => {
    const tph = this.currentTotalTPH();
    const totalBurnRate = this.machines()
      .filter((m) => m.type.includes('diesel'))
      .reduce((acc, m) => acc + m.fuelBurnRateLph, 0);
    return +(totalBurnRate / Math.max(1, tph)).toFixed(3);
  });

  readonly energyIntensityKWhPerTonne = computed(() => {
    const tph = this.currentTotalTPH();
    const plantKw = this.processingPlant().sagMillPowerKw;
    const electricHaulKw = this.machines()
      .filter((m) => m.type.includes('electric'))
      .reduce((acc, m) => acc + (m.motorCurrentAmps * 650) / 1000, 0);
    return +((plantKw + electricHaulKw) / Math.max(1, tph)).toFixed(2);
  });

  private timerInterval: ReturnType<typeof setInterval> | null = null;

  constructor() {
    this.initializeSiteModel();
    this.startSimulationLoop();
  }

  setMineSite(siteId: string) {
    const site = this.availableSites.find((s) => s.id === siteId);
    if (site) {
      this.activeSite.set(site);
      this.initializeSiteModel();
      this.addEvent({
        id: `EV-${Date.now()}`,
        timestamp: Date.now(),
        type: 'STOCKPILE_BLENDED',
        message: `Mine site switched to ${site.name} (${site.mineralLabel}). Geological & plant constraints updated.`,
        source: 'CORE_ENGINE',
        severity: 'info'
      });
    }
  }

  setSimulationRunning(running: boolean) {
    this.isSimulationRunning.set(running);
  }

  setSimulationSpeed(speed: number) {
    this.simulationSpeed.set(speed);
    if (this.timerInterval) {
      clearInterval(this.timerInterval);
      this.startSimulationLoop();
    }
  }

  private startSimulationLoop() {
    const intervalMs = Math.max(200, 1000 / this.simulationSpeed());
    this.timerInterval = setInterval(() => {
      if (this.isSimulationRunning()) {
        this.stepSimulation();
      }
    }, intervalMs);
  }

  stepSimulation() {
    this.simulationTickCount.update((c) => c + 1);
    const tick = this.simulationTickCount();

    // 1. Move vehicles along route graph and update machine telemetry
    this.updateMachinesTelemetry();

    // 2. Periodic trigger of Anomaly / Recommendation / Event
    if (tick % 6 === 0) {
      this.evaluateRecommendations();
    }
    if (tick % 10 === 0) {
      this.evaluateAnomalies();
    }
    if (tick % 15 === 0) {
      this.evaluateStockpileBlending();
    }

    // 3. Increment daily tonnage
    this.totalTonnesMovedToday.update((t) => t + Math.round((this.currentTotalTPH() / 3600) * 1.5));
  }

  private initializeSiteModel() {
    const site = this.activeSite();

    // 1. Road Network Nodes (Open Pit & Processing layout)
    const nodes: RoadNode[] = [
      { id: 'N_PIT_FLOOR', name: 'Pit Floor (Bench 04 - High Grade)', x: 180, y: 380, z: -140, type: 'pit_floor' },
      { id: 'N_BENCH_03', name: 'Bench 03 West Face', x: 260, y: 310, z: -90, type: 'bench' },
      { id: 'N_BENCH_02', name: 'Bench 02 North Face', x: 340, y: 240, z: -40, type: 'bench' },
      { id: 'N_RAMP_SWITCH_1', name: 'Main Haul Ramp Switch 1', x: 420, y: 280, z: 0, type: 'ramp_switch' },
      { id: 'N_RAMP_SWITCH_2', name: 'Main Haul Ramp Switch 2', x: 520, y: 210, z: 40, type: 'ramp_switch' },
      { id: 'N_SURFACE_HUB', name: 'Surface Dispatch Hub', x: 620, y: 160, z: 80, type: 'portal' },
      { id: 'N_CRUSHER_INFEED', name: 'Primary Gyratory Crusher Infeed', x: 740, y: 130, z: 85, type: 'crusher_infeed' },
      { id: 'N_WASTE_DUMP_N', name: 'Waste Dump North Ramp', x: 580, y: 410, z: 95, type: 'waste_dump' },
      { id: 'N_STK_HIGH_GRADE', name: 'Stockpile 1 (High Grade ROM)', x: 810, y: 220, z: 82, type: 'stockpile' },
      { id: 'N_STK_MED_GRADE', name: 'Stockpile 2 (Medium Grade Blend)', x: 830, y: 320, z: 82, type: 'stockpile' },
      { id: 'N_CHARGING_BAY', name: 'Ultra-Fast EV Megawatt Charging Bay', x: 670, y: 280, z: 80, type: 'charging_station' },
      { id: 'N_MAINT_WORKSHOP', name: 'Heavy Mobile Equipment Workshop', x: 640, y: 360, z: 80, type: 'maintenance_bay' },
    ];
    this.roadNodes.set(nodes);

    // 2. Road Edges
    const edges: RoadEdge[] = [
      { id: 'E1', fromNodeId: 'N_PIT_FLOOR', toNodeId: 'N_BENCH_03', distanceMeters: 450, gradientPct: 8.5, speedLimitKmh: 35, surfaceConditionIndex: 0.92, trafficLoad: 2, regenerativeAllowed: true },
      { id: 'E2', fromNodeId: 'N_BENCH_03', toNodeId: 'N_BENCH_02', distanceMeters: 380, gradientPct: 9.0, speedLimitKmh: 35, surfaceConditionIndex: 0.88, trafficLoad: 1, regenerativeAllowed: true },
      { id: 'E3', fromNodeId: 'N_BENCH_02', toNodeId: 'N_RAMP_SWITCH_1', distanceMeters: 420, gradientPct: 8.0, speedLimitKmh: 40, surfaceConditionIndex: 0.95, trafficLoad: 3, regenerativeAllowed: true },
      { id: 'E4', fromNodeId: 'N_RAMP_SWITCH_1', toNodeId: 'N_RAMP_SWITCH_2', distanceMeters: 510, gradientPct: 8.2, speedLimitKmh: 45, surfaceConditionIndex: 0.96, trafficLoad: 2, regenerativeAllowed: true },
      { id: 'E5', fromNodeId: 'N_RAMP_SWITCH_2', toNodeId: 'N_SURFACE_HUB', distanceMeters: 480, gradientPct: 7.5, speedLimitKmh: 50, surfaceConditionIndex: 0.98, trafficLoad: 3, regenerativeAllowed: true },
      { id: 'E6', fromNodeId: 'N_SURFACE_HUB', toNodeId: 'N_CRUSHER_INFEED', distanceMeters: 320, gradientPct: 1.2, speedLimitKmh: 40, surfaceConditionIndex: 0.95, trafficLoad: 2, regenerativeAllowed: false },
      { id: 'E7', fromNodeId: 'N_SURFACE_HUB', toNodeId: 'N_WASTE_DUMP_N', distanceMeters: 620, gradientPct: 3.5, speedLimitKmh: 45, surfaceConditionIndex: 0.85, trafficLoad: 1, regenerativeAllowed: false },
      { id: 'E8', fromNodeId: 'N_SURFACE_HUB', toNodeId: 'N_STK_HIGH_GRADE', distanceMeters: 410, gradientPct: 0.5, speedLimitKmh: 35, surfaceConditionIndex: 0.90, trafficLoad: 1, regenerativeAllowed: false },
      { id: 'E9', fromNodeId: 'N_SURFACE_HUB', toNodeId: 'N_CHARGING_BAY', distanceMeters: 290, gradientPct: -0.5, speedLimitKmh: 30, surfaceConditionIndex: 0.98, trafficLoad: 1, regenerativeAllowed: false },
      { id: 'E10', fromNodeId: 'N_SURFACE_HUB', toNodeId: 'N_MAINT_WORKSHOP', distanceMeters: 360, gradientPct: 0.0, speedLimitKmh: 30, surfaceConditionIndex: 0.95, trafficLoad: 0, regenerativeAllowed: false },
    ];
    this.roadEdges.set(edges);

    // 3. Machines Initial State
    const initMachines: MachineTelemetry[] = [
      {
        timestamp: Date.now(),
        machineId: 'TRK-101',
        machineName: 'CAT 797F Ultra-Class (Diesel)',
        type: 'haul_truck_diesel',
        status: 'hauling_loaded',
        x: 420,
        y: 280,
        z: 0,
        targetNodeId: 'N_CRUSHER_INFEED',
        speedKmh: 36.5,
        currentPayloadTonnes: 235.4,
        maxPayloadTonnes: 240.0,
        fuelLevelPct: 76.5,
        fuelBurnRateLph: 165.2,
        batterySocPct: 100,
        batterySohPct: 100,
        batteryTempC: 38.0,
        motorCurrentAmps: 0,
        motorTempC: 0,
        rpm: 1780,
        engineTempC: 89.2,
        hydraulicPressureBar: 285.4,
        hydraulicTempC: 72.1,
        vibrationMmPerSec: 2.1,
        brakeTempC: 112.5,
        tyrePressurePsi: 108.5,
        oilQualityIndexPct: 88.0,
        operatingHours: 6420,
        telemetryQualityPct: 99.4,
        failureRiskPct: 8.5,
        rulHours: 1420,
        assignedShovelId: 'SHV-01',
        assignedDumpId: 'N_CRUSHER_INFEED'
      },
      {
        timestamp: Date.now(),
        machineId: 'TRK-102',
        machineName: 'CAT 797F Ultra-Class (Diesel)',
        type: 'haul_truck_diesel',
        status: 'hauling_empty',
        x: 520,
        y: 210,
        z: 40,
        targetNodeId: 'N_PIT_FLOOR',
        speedKmh: 42.0,
        currentPayloadTonnes: 0.0,
        maxPayloadTonnes: 240.0,
        fuelLevelPct: 62.8,
        fuelBurnRateLph: 95.4,
        batterySocPct: 100,
        batterySohPct: 100,
        batteryTempC: 36.5,
        motorCurrentAmps: 0,
        motorTempC: 0,
        rpm: 1620,
        engineTempC: 87.0,
        hydraulicPressureBar: 278.0,
        hydraulicTempC: 68.4,
        vibrationMmPerSec: 1.8,
        brakeTempC: 88.0,
        tyrePressurePsi: 109.0,
        oilQualityIndexPct: 82.5,
        operatingHours: 8140,
        telemetryQualityPct: 98.9,
        failureRiskPct: 12.0,
        rulHours: 1180,
        assignedShovelId: 'SHV-01',
      },
      {
        timestamp: Date.now(),
        machineId: 'TRK-103',
        machineName: 'Komatsu 930E-5 (Diesel-Electric)',
        type: 'haul_truck_diesel',
        status: 'loading',
        x: 180,
        y: 380,
        z: -140,
        targetNodeId: 'N_PIT_FLOOR',
        speedKmh: 0.0,
        currentPayloadTonnes: 185.0,
        maxPayloadTonnes: 290.0,
        fuelLevelPct: 84.2,
        fuelBurnRateLph: 45.0,
        batterySocPct: 100,
        batterySohPct: 100,
        batteryTempC: 35.0,
        motorCurrentAmps: 180,
        motorTempC: 58.0,
        rpm: 950,
        engineTempC: 82.0,
        hydraulicPressureBar: 290.0,
        hydraulicTempC: 70.0,
        vibrationMmPerSec: 2.8,
        brakeTempC: 75.0,
        tyrePressurePsi: 110.0,
        oilQualityIndexPct: 91.0,
        operatingHours: 4210,
        telemetryQualityPct: 99.8,
        failureRiskPct: 6.2,
        rulHours: 2150,
        assignedShovelId: 'SHV-01',
      },
      {
        timestamp: Date.now(),
        machineId: 'TRK-201',
        machineName: 'Komatsu e-Hauler (100% Battery Electric)',
        type: 'haul_truck_electric',
        status: 'hauling_loaded',
        x: 340,
        y: 240,
        z: -40,
        targetNodeId: 'N_CRUSHER_INFEED',
        speedKmh: 34.0,
        currentPayloadTonnes: 220.0,
        maxPayloadTonnes: 230.0,
        fuelLevelPct: 0,
        fuelBurnRateLph: 0,
        batterySocPct: 68.5,
        batterySohPct: 98.2,
        batteryTempC: 41.2,
        motorCurrentAmps: 840,
        motorTempC: 74.5,
        rpm: 2450,
        engineTempC: 42.0,
        hydraulicPressureBar: 280.0,
        hydraulicTempC: 66.0,
        vibrationMmPerSec: 1.4,
        brakeTempC: 55.0,
        tyrePressurePsi: 112.0,
        oilQualityIndexPct: 96.0,
        operatingHours: 1980,
        telemetryQualityPct: 99.9,
        failureRiskPct: 4.1,
        rulHours: 3200,
        assignedShovelId: 'EXC-02',
        assignedDumpId: 'N_CRUSHER_INFEED'
      },
      {
        timestamp: Date.now(),
        machineId: 'TRK-202',
        machineName: 'Komatsu e-Hauler (100% Battery Electric)',
        type: 'haul_truck_electric',
        status: 'hauling_empty',
        x: 620,
        y: 160,
        z: 80,
        targetNodeId: 'N_PIT_FLOOR',
        speedKmh: 44.0,
        currentPayloadTonnes: 0.0,
        maxPayloadTonnes: 230.0,
        fuelLevelPct: 0,
        fuelBurnRateLph: 0,
        batterySocPct: 74.0, // Regenerating downhill!
        batterySohPct: 97.8,
        batteryTempC: 38.5,
        motorCurrentAmps: -320, // Negative amps = regen braking into battery!
        motorTempC: 62.0,
        rpm: 2100,
        engineTempC: 38.0,
        hydraulicPressureBar: 260.0,
        hydraulicTempC: 60.0,
        vibrationMmPerSec: 1.2,
        brakeTempC: 48.0,
        tyrePressurePsi: 111.5,
        oilQualityIndexPct: 95.0,
        operatingHours: 2340,
        telemetryQualityPct: 99.7,
        failureRiskPct: 5.0,
        rulHours: 2900,
        assignedShovelId: 'SHV-01',
      },
      {
        timestamp: Date.now(),
        machineId: 'SHV-01',
        machineName: 'CAT 7495 Electric Rope Shovel (120t Dipper)',
        type: 'rope_shovel',
        status: 'digging',
        x: 175,
        y: 385,
        z: -140,
        targetNodeId: 'N_PIT_FLOOR',
        speedKmh: 0.0,
        currentPayloadTonnes: 118.0,
        maxPayloadTonnes: 120.0,
        fuelLevelPct: 0,
        fuelBurnRateLph: 0,
        batterySocPct: 100,
        batterySohPct: 100,
        batteryTempC: 32.0,
        motorCurrentAmps: 1450,
        motorTempC: 82.0,
        rpm: 1200,
        engineTempC: 65.0,
        hydraulicPressureBar: 340.0,
        hydraulicTempC: 78.0,
        vibrationMmPerSec: 3.4,
        brakeTempC: 84.0,
        tyrePressurePsi: 0,
        oilQualityIndexPct: 89.0,
        operatingHours: 14800,
        telemetryQualityPct: 99.5,
        failureRiskPct: 18.5,
        rulHours: 850,
      },
      {
        timestamp: Date.now(),
        machineId: 'EXC-02',
        machineName: 'Liebherr R9800 Hydraulic Excavator',
        type: 'hydraulic_excavator',
        status: 'digging',
        x: 265,
        y: 315,
        z: -90,
        targetNodeId: 'N_BENCH_03',
        speedKmh: 0.0,
        currentPayloadTonnes: 85.0,
        maxPayloadTonnes: 90.0,
        fuelLevelPct: 68.0,
        fuelBurnRateLph: 240.0,
        batterySocPct: 0,
        batterySohPct: 0,
        batteryTempC: 0,
        motorCurrentAmps: 0,
        motorTempC: 0,
        rpm: 1850,
        engineTempC: 92.4,
        hydraulicPressureBar: 385.0, // High hydraulic load
        hydraulicTempC: 88.6,
        vibrationMmPerSec: 4.8, // Mild vibration alert
        brakeTempC: 70.0,
        tyrePressurePsi: 0,
        oilQualityIndexPct: 74.0,
        operatingHours: 9200,
        telemetryQualityPct: 98.4,
        failureRiskPct: 38.0,
        rulHours: 320,
      },
      {
        timestamp: Date.now(),
        machineId: 'DRL-01',
        machineName: 'Sandvik DR412i Autonomous Rotary Drill',
        type: 'autonomous_drill',
        status: 'drilling',
        x: 345,
        y: 235,
        z: -40,
        targetNodeId: 'N_BENCH_02',
        speedKmh: 0.0,
        currentPayloadTonnes: 0.0,
        maxPayloadTonnes: 0.0,
        fuelLevelPct: 81.0,
        fuelBurnRateLph: 85.0,
        batterySocPct: 0,
        batterySohPct: 0,
        batteryTempC: 0,
        motorCurrentAmps: 0,
        motorTempC: 0,
        rpm: 1950,
        engineTempC: 84.0,
        hydraulicPressureBar: 290.0,
        hydraulicTempC: 71.0,
        vibrationMmPerSec: 6.2, // Drill bit vibration
        brakeTempC: 50.0,
        tyrePressurePsi: 0,
        oilQualityIndexPct: 92.0,
        operatingHours: 3400,
        telemetryQualityPct: 99.6,
        failureRiskPct: 9.0,
        rulHours: 1800,
      },
      {
        timestamp: Date.now(),
        machineId: 'CRU-01',
        machineName: 'FLSmidth 60x113 Primary Gyratory Crusher',
        type: 'primary_crusher',
        status: 'digging',
        x: 745,
        y: 135,
        z: 85,
        targetNodeId: 'N_CRUSHER_INFEED',
        speedKmh: 0.0,
        currentPayloadTonnes: 4950, // TPH feed
        maxPayloadTonnes: 5500,
        fuelLevelPct: 0,
        fuelBurnRateLph: 0,
        batterySocPct: 100,
        batterySohPct: 100,
        batteryTempC: 30.0,
        motorCurrentAmps: 1120,
        motorTempC: 68.0,
        rpm: 175, // Eccentric shaft
        engineTempC: 62.0,
        hydraulicPressureBar: 210.0,
        hydraulicTempC: 58.0,
        vibrationMmPerSec: 2.2,
        brakeTempC: 45.0,
        tyrePressurePsi: 0,
        oilQualityIndexPct: 94.0,
        operatingHours: 24500,
        telemetryQualityPct: 99.8,
        failureRiskPct: 7.2,
        rulHours: 4200,
      }
    ];
    this.machines.set(initMachines);

    // 4. Stockpiles
    const initStockpiles: Stockpile[] = [
      {
        id: 'STK-01',
        name: 'ROM High-Grade Feed (Silo 1)',
        mineralType: site.mineralType,
        currentMassTonnes: 92400,
        maxCapacityTonnes: 150000,
        currentGrade: +(site.targetPlantGrade * 1.08).toFixed(2),
        targetGrade: site.targetPlantGrade,
        silicaImpurityPct: 2.8,
        moisturePct: 3.2,
        x: 810,
        y: 220,
      },
      {
        id: 'STK-02',
        name: 'Medium-Grade Blending Pile (Silo 2)',
        mineralType: site.mineralType,
        currentMassTonnes: 145000,
        maxCapacityTonnes: 220000,
        currentGrade: +(site.targetPlantGrade * 0.94).toFixed(2),
        targetGrade: site.targetPlantGrade,
        silicaImpurityPct: 4.1,
        moisturePct: 4.0,
        x: 830,
        y: 320,
      },
      {
        id: 'STK-03',
        name: 'Low-Grade Marginal Stockpile',
        mineralType: site.mineralType,
        currentMassTonnes: 340000,
        maxCapacityTonnes: 500000,
        currentGrade: +(site.cutOffGrade * 1.05).toFixed(2),
        targetGrade: site.targetPlantGrade,
        silicaImpurityPct: 6.8,
        moisturePct: 4.5,
        x: 870,
        y: 420,
      },
      {
        id: 'STK-04',
        name: 'Sweetener High-Purity Blend',
        mineralType: site.mineralType,
        currentMassTonnes: 48000,
        maxCapacityTonnes: 80000,
        currentGrade: +(site.targetPlantGrade * 1.22).toFixed(2),
        targetGrade: site.targetPlantGrade,
        silicaImpurityPct: 1.6,
        moisturePct: 2.5,
        x: 780,
        y: 360,
      }
    ];
    this.stockpiles.set(initStockpiles);

    // 5. Ore Blocks Grid for Spatial Modelling
    this.generateOreBlockGrid(site);

    // 6. Initial Recommendations
    this.recommendations.set([
      {
        id: 'REC-8842',
        timestamp: Date.now() - 45000,
        machineId: 'TRK-102',
        machineName: 'CAT 797F (TRK-102)',
        action: 'CHANGE_ROUTE',
        targetId: 'N_PIT_FLOOR',
        targetDescription: 'Reroute to Bench 04 North Shovel SHV-01 via Ramp 1',
        reason: 'Crusher infeed queue projected clear; Shovel 01 queue = 0 trucks (Avoid shovel starvation)',
        confidenceScore: 0.96,
        expiresAt: Date.now() + 180000,
        status: 'VALIDATED_AUTO',
        safetyChecksPassed: true,
        safetyNotes: 'Gradient -8.5% within dry retarding curve. Speed limited to 40 km/h.',
        timeSavingsMinutes: 3.4,
        throughputGainTph: 235
      },
      {
        id: 'REC-8843',
        timestamp: Date.now() - 120000,
        machineId: 'TRK-201',
        machineName: 'Komatsu e-Hauler (TRK-201)',
        action: 'DISPATCH_CRUSHER',
        targetId: 'N_CRUSHER_INFEED',
        targetDescription: 'Direct dump into Primary Gyratory Crusher',
        reason: 'Optimal blend compliance (+1.2% grade boost needed at Silo 1)',
        confidenceScore: 0.94,
        expiresAt: Date.now() + 300000,
        status: 'APPROVED_OPERATOR',
        safetyChecksPassed: true,
        safetyNotes: 'SOC = 68% sufficient for 3 additional return cycles before recharge.',
        energySavingsKwh: 42.0,
      },
      {
        id: 'REC-8844',
        timestamp: Date.now() - 250000,
        machineId: 'EXC-02',
        machineName: 'Liebherr R9800 (EXC-02)',
        action: 'DERATE_SPEED_MAINT',
        targetId: 'N_BENCH_03',
        targetDescription: 'Derate hydraulic pump pressure by 8% & inspect filter',
        reason: 'Hydraulic temperature reached 88.6°C with 4.8 mm/s vibration anomaly',
        confidenceScore: 0.89,
        expiresAt: Date.now() + 600000,
        status: 'VALIDATED_AUTO',
        safetyChecksPassed: true,
        safetyNotes: 'Interlock safe. Prevents catastrophic main pump cavitation failure.',
      }
    ]);

    // 7. Initial Anomalies
    this.anomalies.set([
      {
        id: 'ANOM-109',
        timestamp: Date.now() - 180000,
        machineId: 'EXC-02',
        machineName: 'Liebherr R9800 (EXC-02)',
        parameter: 'hydraulic_temp_c',
        observedValue: 88.6,
        expectedValue: 74.0,
        zScore: 3.42,
        severity: 'warning',
        description: 'Hydraulic fluid temperature 3.42 std deviations above rolling baseline.',
        suggestedAction: 'Clean hydraulic cooler fins and check return filter pressure differential.',
        acknowledged: false,
      },
      {
        id: 'ANOM-110',
        timestamp: Date.now() - 600000,
        machineId: 'DRL-01',
        machineName: 'Sandvik DR412i (DRL-01)',
        parameter: 'vibration_mm_s',
        observedValue: 6.2,
        expectedValue: 3.8,
        zScore: 3.10,
        severity: 'info',
        description: 'Rotary head vibration spike during hard banded iron formation penetration.',
        suggestedAction: 'Auto-adjust pulldown force and rotary RPM to dampen resonant frequency.',
        acknowledged: true,
      }
    ]);

    // 8. Work Orders
    this.workOrders.set([
      {
        id: 'WO-9912',
        machineId: 'EXC-02',
        machineName: 'Liebherr R9800',
        component: 'Hydraulic Main Pump #2 & Cooler Bypass',
        priority: 'high',
        failureRiskPct: 38.0,
        rulHours: 320,
        operatingWindowHours: 48,
        recommendedInspection: 'Inspect hydraulic pump case drain flow, oil contamination, and cooler airflow',
        status: 'recommended',
        createdAt: Date.now() - 3600000,
      },
      {
        id: 'WO-9908',
        machineId: 'SHV-01',
        machineName: 'CAT 7495 Rope Shovel',
        component: 'Crowd Machinery Hoist Cable & Sheave Bearings',
        priority: 'medium',
        failureRiskPct: 18.5,
        rulHours: 850,
        operatingWindowHours: 120,
        recommendedInspection: 'Ultrasonic flaw detection on hoist rope strands & grease line verification',
        status: 'scheduled',
        createdAt: Date.now() - 86400000,
      }
    ]);
  }

  private generateOreBlockGrid(site: MineSiteConfig) {
    const blocks: OreBlock[] = [];
    const benches = ['Bench 01 (Surface)', 'Bench 02 (-40m)', 'Bench 03 (-90m)', 'Bench 04 (-140m)'];
    
    for (let bx = 0; bx < 10; bx++) {
      for (let by = 0; by < 8; by++) {
        for (let bz = 0; bz < benches.length; bz++) {
          const id = `BLK-${bz+1}-${bx}-${by}`;
          // Spatial grade distribution with high-grade core
          const distFromCore = Math.sqrt((bx - 5)**2 + (by - 4)**2);
          const baseGrade = site.targetPlantGrade * (1.25 - distFromCore * 0.12) + (Math.sin(bx * 0.8 + by) * 0.15);
          const clampedGrade = +Math.max(site.cutOffGrade * 0.8, baseGrade).toFixed(2);
          
          let state: 'in_situ' | 'drilled' | 'blasted' | 'excavating' | 'depleted' = 'in_situ';
          if (bz === 0 && bx < 6) state = 'depleted';
          else if (bz === 1 && bx < 4) state = 'excavating';
          else if (bz === 2 && bx === 3 && by === 3) state = 'blasted';
          else if (bz === 2 && bx === 4) state = 'drilled';

          blocks.push({
            id,
            benchId: benches[bz],
            x: 150 + bx * 45,
            y: 120 + by * 40,
            z: -bz * 45,
            rockType: clampedGrade > site.targetPlantGrade ? 'High-Grade Ore' : clampedGrade > site.cutOffGrade ? 'Medium Ore' : 'Waste Rock',
            densityTpm3: 2.85 + (clampedGrade / site.targetPlantGrade) * 0.4,
            gradeValue: clampedGrade,
            confidencePct: Math.round(98 - distFromCore * 4.5),
            hardnessIndex: Math.round(5 + (bx % 4)),
            state,
          });
        }
      }
    }
    this.oreBlocks.set(blocks);
  }

  private updateMachinesTelemetry() {
    this.machines.update((list) => {
      return list.map((m) => {
        // Telemetry noise simulation
        const noise = (Math.random() - 0.5) * 0.1;
        let newPayload = m.currentPayloadTonnes;
        let newStatus = m.status;
        let newX = m.x;
        let newY = m.y;
        let newSpeed = m.speedKmh;
        let newSoc = m.batterySocPct;
        let newFuel = m.fuelLevelPct;

        if (m.type.startsWith('haul_truck')) {
          // Move trucks toward targets
          if (m.status === 'hauling_loaded') {
            newX += (Math.random() * 4 + 2);
            newY -= (Math.random() * 2 + 1);
            if (newX > 720) {
              newStatus = 'dumping';
              newSpeed = 0;
            }
          } else if (m.status === 'dumping') {
            newPayload = Math.max(0, newPayload - 80);
            if (newPayload <= 0) {
              newStatus = 'hauling_empty';
              newSpeed = 40;
            }
          } else if (m.status === 'hauling_empty') {
            newX -= (Math.random() * 5 + 3);
            newY += (Math.random() * 3 + 1);
            if (newX < 200) {
              newStatus = 'loading';
              newSpeed = 0;
            }
          } else if (m.status === 'loading') {
            newPayload = Math.min(m.maxPayloadTonnes, newPayload + 60);
            if (newPayload >= m.maxPayloadTonnes * 0.95) {
              newStatus = 'hauling_loaded';
              newSpeed = 34;
            }
          }

          // Electric battery state update
          if (m.type === 'haul_truck_electric') {
            if (m.status === 'hauling_loaded') {
              newSoc = Math.max(15, +(newSoc - 0.1).toFixed(2));
            } else if (m.status === 'hauling_empty' && m.z > 0) {
              // Downhill regenerative braking
              newSoc = Math.min(98, +(newSoc + 0.08).toFixed(2));
            }
          } else {
            // Diesel burn
            newFuel = Math.max(10, +(newFuel - 0.02).toFixed(2));
          }
        }

        return {
          ...m,
          status: newStatus,
          timestamp: Date.now(),
          x: +newX.toFixed(1),
          y: +newY.toFixed(1),
          speedKmh: +newSpeed.toFixed(1),
          currentPayloadTonnes: +newPayload.toFixed(1),
          batterySocPct: newSoc,
          fuelLevelPct: newFuel,
          rpm: Math.round(m.rpm + noise * 40),
          engineTempC: +(m.engineTempC + noise * 0.5).toFixed(1),
          hydraulicPressureBar: +(m.hydraulicPressureBar + noise * 2.0).toFixed(1),
          vibrationMmPerSec: +(m.vibrationMmPerSec + noise * 0.1).toFixed(2),
          brakeTempC: +(m.brakeTempC + (m.speedKmh > 30 ? 0.2 : -0.3)).toFixed(1),
        };
      });
    });
  }

  private evaluateRecommendations() {
    const list = this.machines();
    const loadedTrucks = list.filter((m) => m.status === 'hauling_loaded');
    
    if (loadedTrucks.length > 0 && Math.random() > 0.6) {
      const chosen = loadedTrucks[Math.floor(Math.random() * loadedTrucks.length)];
      const newRec: Recommendation = {
        id: `REC-${Math.floor(1000 + Math.random() * 9000)}`,
        timestamp: Date.now(),
        machineId: chosen.machineId,
        machineName: chosen.machineName,
        action: 'CHANGE_ROUTE',
        targetId: 'N_STK_HIGH_GRADE',
        targetDescription: 'Divert to Stockpile 01 (High Grade Silo)',
        reason: 'Crusher infeed hopper queue > 3 trucks; divert saves 4.2 min idle queue time',
        confidenceScore: +(0.91 + Math.random() * 0.08).toFixed(2),
        expiresAt: Date.now() + 180000,
        status: 'VALIDATED_AUTO',
        safetyChecksPassed: true,
        safetyNotes: 'Automatic safety gate verified: Speed, payload & road gradient within safe operating limits.',
        timeSavingsMinutes: 4.2,
        throughputGainTph: 180,
      };

      this.recommendations.update((recs) => [newRec, ...recs.slice(0, 19)]);
      this.addEvent({
        id: `EV-${Date.now()}`,
        timestamp: Date.now(),
        type: 'DISPATCH_RECOMMENDED',
        message: `Recommendation generated: ${newRec.action} for ${newRec.machineId} (${newRec.reason}).`,
        source: 'AUTONOMOUS_HAULAGE_OPTIMISER',
        severity: 'info'
      });
    }
  }

  private evaluateAnomalies() {
    const machines = this.machines();
    for (const m of machines) {
      if (m.vibrationMmPerSec > 4.5 && Math.random() > 0.7) {
        const alert: AnomalyAlert = {
          id: `ANOM-${Date.now() % 10000}`,
          timestamp: Date.now(),
          machineId: m.machineId,
          machineName: m.machineName,
          parameter: 'vibration_mm_s',
          observedValue: m.vibrationMmPerSec,
          expectedValue: 2.2,
          zScore: 3.65,
          severity: 'warning',
          description: `Vibration anomaly detected on ${m.machineName} (${m.vibrationMmPerSec} mm/s).`,
          suggestedAction: 'Schedule vibration spectral FFT analysis and check drive shaft couplings.',
          acknowledged: false
        };
        this.anomalies.update((list) => [alert, ...list.slice(0, 14)]);
        this.addEvent({
          id: `EV-${Date.now()}`,
          timestamp: Date.now(),
          type: 'ANOMALY_FLAGGED',
          message: `Vibration anomaly flagged on ${m.machineId}: ${m.vibrationMmPerSec} mm/s`,
          source: 'ANOMALY_DETECTOR',
          severity: 'alert'
        });
        break;
      }
    }
  }

  private evaluateStockpileBlending() {
    this.stockpiles.update((piles) => {
      return piles.map((p) => {
        const delta = (Math.random() - 0.48) * 120;
        return {
          ...p,
          currentMassTonnes: Math.max(1000, Math.min(p.maxCapacityTonnes, Math.round(p.currentMassTonnes + delta)))
        };
      });
    });
  }

  // Industrial API Recommendation Actions
  applyRecommendation(recId: string, approvedByOperator = true) {
    this.recommendations.update((list) =>
      list.map((r) => {
        if (r.id === recId) {
          const status: ValidationStatus = approvedByOperator ? 'EXECUTED_SCADA' : 'VALIDATED_AUTO';
          return { ...r, status };
        }
        return r;
      })
    );

    const rec = this.recommendations().find((r) => r.id === recId);
    if (rec) {
      this.addEvent({
        id: `EV-${Date.now()}`,
        timestamp: Date.now(),
        type: 'DISPATCH_RECOMMENDED',
        message: `Recommendation ${rec.id} (${rec.action}) dispatched to Industrial Control System for machine ${rec.machineId}.`,
        source: 'INDUSTRIAL_CONTROL_GATEWAY',
        severity: 'normal'
      });
    }
  }

  rejectRecommendation(recId: string, reason: string) {
    this.recommendations.update((list) =>
      list.map((r) => {
        if (r.id === recId) {
          return {
            ...r,
            status: 'REJECTED_SAFETY_VIOLATION',
            safetyNotes: `Operator / Safety Interlock override: ${reason}`
          };
        }
        return r;
      })
    );
  }

  acknowledgeAnomaly(id: string) {
    this.anomalies.update((list) =>
      list.map((a) => (a.id === id ? { ...a, acknowledged: true } : a))
    );
  }

  addWorkOrder(wo: Omit<MaintenanceWorkOrder, 'id' | 'createdAt'>) {
    const newWo: MaintenanceWorkOrder = {
      ...wo,
      id: `WO-${Math.floor(1000 + Math.random() * 9000)}`,
      createdAt: Date.now(),
    };
    this.workOrders.update((list) => [newWo, ...list]);
    this.addEvent({
      id: `EV-${Date.now()}`,
      timestamp: Date.now(),
      type: 'MAINTENANCE_TRIGGERED',
      message: `Work Order ${newWo.id} created for ${newWo.machineName} (${newWo.component}).`,
      source: 'PREDICTIVE_MAINTENANCE',
      severity: 'info'
    });
  }

  addEvent(event: IndustrialEvent) {
    this.eventBus.update((list) => [event, ...list.slice(0, 49)]);
  }

  // What-If Scenario Solver
  runWhatIfSimulation(input: WhatIfScenarioInput): WhatIfScenarioResult {
    const site = this.activeSite();
    const totalTrucks = input.truckCountDiesel + input.truckCountElectric;
    const avgPayload = 230; // Tonnes
    const cyclesPerHourPerTruck = 4.2 / input.roadRoughnessFactor;
    
    // Total potential TPH
    const truckCapacityTph = totalTrucks * avgPayload * cyclesPerHourPerTruck;
    const excavatorCapacityTph = input.excavatorCount * 1850;
    const rawTph = Math.min(truckCapacityTph, excavatorCapacityTph, input.plantCapacityTph);
    
    const projectedTph = Math.round(rawTph * input.oreGradeFactor);
    const projectedTotalTonnes = Math.round(projectedTph * input.shiftDurationHours);
    
    // Fuel and energy calculations
    const dieselFuelPerHour = input.truckCountDiesel * 145 * input.roadRoughnessFactor + (input.excavatorCount * 180);
    const electricKwhPerHour = (input.truckCountElectric * 380) + 12500; // Plant + trucks
    
    const totalFuelLiters = dieselFuelPerHour * input.shiftDurationHours;
    const totalEnergyKwh = electricKwhPerHour * input.shiftDurationHours;
    
    const totalCost = (totalFuelLiters * input.fuelPricePerLiter) + (totalEnergyKwh * input.electricityPricePerKwh) + (projectedTotalTonnes * 2.8); // maintenance overhead
    const costPerTonne = +(totalCost / Math.max(1, projectedTotalTonnes)).toFixed(2);
    
    const energyKwhPerTonne = +(totalEnergyKwh / Math.max(1, projectedTotalTonnes)).toFixed(2);
    const fuelLitersPerTonne = +(totalFuelLiters / Math.max(1, projectedTotalTonnes)).toFixed(2);
    
    const fleetUtilisationPct = +Math.min(96, Math.max(65, (projectedTph / Math.max(1, truckCapacityTph)) * 92)).toFixed(1);
    const bottleneckRisk = projectedTph > input.plantCapacityTph * 0.95 ? 88 : projectedTph > input.plantCapacityTph * 0.85 ? 45 : 12;
    
    const mineralPricePerTonne = site.mineralType === 'iron_ore' ? 115 : site.mineralType === 'copper_gold' ? 8400 * 0.012 : 145;
    const revenue = projectedTotalTonnes * mineralPricePerTonne;
    const estimatedProfitability = Math.round(revenue - totalCost);

    return {
      projectedTotalTonnes,
      projectedTph,
      projectedTotalCost: Math.round(totalCost),
      projectedCostPerTonne: costPerTonne,
      projectedEnergyKwhPerTonne: energyKwhPerTonne,
      projectedFuelLitersPerTonne: fuelLitersPerTonne,
      projectedFleetUtilisationPct: fleetUtilisationPct,
      projectedPlantBottleneckRiskPct: bottleneckRisk,
      estimatedProfitability,
      comparisonVsBaselinePct: {
        production: +(((projectedTph - site.targetDailyTPH) / site.targetDailyTPH) * 100).toFixed(1),
        cost: +(((costPerTonne - 8.5) / 8.5) * 100).toFixed(1),
        emissions: -+((input.truckCountElectric / Math.max(1, totalTrucks)) * 42).toFixed(1)
      }
    };
  }
}
