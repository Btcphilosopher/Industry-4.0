import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MiningEngineService } from './mining-engine.service';
import { firstValueFrom } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AiAdvisorService {
  private http = inject(HttpClient);
  private miningEngine = inject(MiningEngineService);

  readonly isLoading = signal<boolean>(false);
  readonly currentAdvice = signal<string>('');
  readonly adviceHistory = signal<{ timestamp: number; prompt: string; response: string }[]>([]);

  async queryAdvisor(customPrompt?: string): Promise<string> {
    this.isLoading.set(true);

    const context = {
      site: this.miningEngine.activeSite(),
      tph: this.miningEngine.currentTotalTPH(),
      targetTph: this.miningEngine.activeSite().targetDailyTPH,
      grade: this.miningEngine.averageOreGrade(),
      fleetAvailability: this.miningEngine.fleetAvailabilityPct(),
      fleetUtilisation: this.miningEngine.fleetUtilisationPct(),
      fuelIntensity: this.miningEngine.fuelIntensityLitersPerTonne(),
      energyIntensity: this.miningEngine.energyIntensityKWhPerTonne(),
      machines: this.miningEngine.machines().map((m) => ({
        id: m.machineId,
        name: m.machineName,
        status: m.status,
        speed: m.speedKmh,
        payload: m.currentPayloadTonnes,
        vibration: m.vibrationMmPerSec,
        hydraulicTemp: m.hydraulicTempC,
        failureRisk: m.failureRiskPct,
        batterySoc: m.batterySocPct,
      })),
      activeRecommendationsCount: this.miningEngine.recommendations().length,
      unacknowledgedAnomalies: this.miningEngine.anomalies().filter((a) => !a.acknowledged).length,
    };

    const promptText =
      customPrompt ||
      `Provide a comprehensive shift operational advisory for ${context.site.name}. Detail throughput optimization, machine health risks (specifically hydraulic temps and bearing vibrations), dynamic haul dispatch recommendations, and energy peak shaving compliance.`;

    try {
      const res = await firstValueFrom(
        this.http.post<{ success: boolean; advice: string }>('/api/ai/advisor', {
          prompt: promptText,
          context,
        })
      );

      const adviceText = res?.advice || 'Analysis complete. All parameters operating within normal safety limits.';
      this.currentAdvice.set(adviceText);
      this.adviceHistory.update((h) => [
        { timestamp: Date.now(), prompt: promptText, response: adviceText },
        ...h.slice(0, 9),
      ]);
      return adviceText;
    } catch (err) {
      console.error('Failed to contact AI advisor endpoint', err);
      const fallback = `### MINING.OS 4.0 Autonomous Operations Briefing (${context.site.name})\n\n**Throughput Status**: Active TPH is ${context.tph} against target ${context.targetTph}.\n**Fleet State**: Fleet OEE at ${context.fleetUtilisation}% with ${context.fleetAvailability}% availability.\n**Dispatch Rationale**: Shovel SHV-01 queues balanced. Recommend maintaining autonomous haulage cycle.`;
      this.currentAdvice.set(fallback);
      return fallback;
    } finally {
      this.isLoading.set(false);
    }
  }
}
