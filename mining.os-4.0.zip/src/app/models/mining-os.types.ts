export type MineralType =
  | 'iron_ore'
  | 'copper_gold'
  | 'lithium_pegmatite'
  | 'gold_quartz'
  | 'metallurgical_coal'
  | 'aggregates'
  | 'polymetallic';

export type MiningMethod =
  | 'open_pit'
  | 'underground_caving'
  | 'quarry'
  | 'bench_stripping';

export interface MineSiteConfig {
  id: string;
  name: string;
  location: string;
  mineralType: MineralType;
  mineralLabel: string;
  primaryGradeUnit: string;
  targetDailyTPH: number;
  miningMethod: MiningMethod;
  dieselCostPerLiter: number;
  electricityCostPerKWh: number;
  cutOffGrade: number;
  targetPlantGrade: number;
}

export type MachineType =
  | 'haul_truck_diesel'
  | 'haul_truck_electric'
  | 'hydraulic_excavator'
  | 'rope_shovel'
  | 'autonomous_drill'
  | 'wheel_loader'
  | 'track_dozer'
  | 'motor_grader'
  | 'primary_crusher'
  | 'conveyor_line';

export type MachineStatus =
  | 'hauling_loaded'
  | 'hauling_empty'
  | 'loading'
  | 'spotting'
  | 'dumping'
  | 'digging'
  | 'drilling'
  | 'charging'
  | 'idle_queue'
  | 'maintenance_standby'
  | 'maintenance_active'
  | 'breakdown_alert';

export interface MachineTelemetry {
  timestamp: number;
  machineId: string;
  machineName: string;
  type: MachineType;
  status: MachineStatus;
  
  // Positional
  x: number;
  y: number;
  z: number;
  targetNodeId: string;
  speedKmh: number;
  currentPayloadTonnes: number;
  maxPayloadTonnes: number;
  
  // Power & Fuel
  fuelLevelPct: number;
  fuelBurnRateLph: number;
  batterySocPct: number; // State of Charge
  batterySohPct: number; // State of Health
  batteryTempC: number;
  motorCurrentAmps: number;
  motorTempC: number;
  
  // Mechanical & Health
  rpm: number;
  engineTempC: number;
  hydraulicPressureBar: number;
  hydraulicTempC: number;
  vibrationMmPerSec: number;
  brakeTempC: number;
  tyrePressurePsi: number;
  oilQualityIndexPct: number;
  operatingHours: number;
  
  // Sensor Meta
  telemetryQualityPct: number; // 0-100
  failureRiskPct: number;
  rulHours: number; // Remaining Useful Life
  assignedShovelId?: string;
  assignedDumpId?: string;
}

export interface RoadNode {
  id: string;
  name: string;
  x: number;
  y: number;
  z: number; // Elevation in meters
  type: 'pit_floor' | 'bench' | 'ramp_switch' | 'crusher_infeed' | 'waste_dump' | 'stockpile' | 'maintenance_bay' | 'charging_station' | 'portal';
}

export interface RoadEdge {
  id: string;
  fromNodeId: string;
  toNodeId: string;
  distanceMeters: number;
  gradientPct: number; // e.g. -8.5% downhill, +10.2% uphill
  speedLimitKmh: number;
  surfaceConditionIndex: number; // 0 (poor) to 1.0 (smooth graded)
  trafficLoad: number; // current vehicles on segment
  regenerativeAllowed: boolean;
}

export interface Stockpile {
  id: string;
  name: string;
  mineralType: MineralType;
  currentMassTonnes: number;
  maxCapacityTonnes: number;
  currentGrade: number; // % or g/t
  targetGrade: number;
  silicaImpurityPct: number;
  moisturePct: number;
  x: number;
  y: number;
}

export interface ProcessingPlant {
  crusherStatus: 'operational' | 'derated' | 'maintenance';
  crusherThroughputTph: number;
  crusherCapacityTph: number;
  sagMillPowerKw: number;
  flotationRecoveryPct: number;
  stockpileFeedRatio: Record<string, number>;
  totalMilledTodayTonnes: number;
  targetMilledTodayTonnes: number;
  currentFeedGrade: number;
}

export interface OreBlock {
  id: string;
  benchId: string;
  x: number;
  y: number;
  z: number;
  rockType: string;
  densityTpm3: number;
  gradeValue: number;
  confidencePct: number;
  hardnessIndex: number; // 1-10 Mohs / Bond Work Index
  state: 'in_situ' | 'drilled' | 'blasted' | 'excavating' | 'depleted';
}

export type RecommendationAction =
  | 'CHANGE_ROUTE'
  | 'DISPATCH_SHOVEL'
  | 'DISPATCH_CRUSHER'
  | 'DISPATCH_DUMP'
  | 'DIVERT_CHARGER'
  | 'DERATE_SPEED_MAINT'
  | 'ADJUST_BLENDING_RATIO'
  | 'DRILL_PATTERN_RESEQUENCE'
  | 'EMERGENCY_DEGRADE_ALERT';

export type ValidationStatus =
  | 'PENDING_VALIDATION'
  | 'VALIDATED_AUTO'
  | 'APPROVED_OPERATOR'
  | 'REJECTED_SAFETY_VIOLATION'
  | 'REJECTED_EXPIRED'
  | 'EXECUTED_SCADA';

export interface Recommendation {
  id: string;
  timestamp: number;
  machineId: string;
  machineName: string;
  action: RecommendationAction;
  targetId: string;
  targetDescription: string;
  reason: string;
  confidenceScore: number; // 0.0 - 1.0
  expiresAt: number;
  status: ValidationStatus;
  safetyChecksPassed: boolean;
  safetyNotes: string;
  energySavingsKwh?: number;
  timeSavingsMinutes?: number;
  throughputGainTph?: number;
}

export interface AnomalyAlert {
  id: string;
  timestamp: number;
  machineId: string;
  machineName: string;
  parameter: string;
  observedValue: number;
  expectedValue: number;
  zScore: number;
  severity: 'info' | 'warning' | 'critical';
  description: string;
  suggestedAction: string;
  acknowledged: boolean;
}

export interface MaintenanceWorkOrder {
  id: string;
  machineId: string;
  machineName: string;
  component: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  failureRiskPct: number;
  rulHours: number;
  operatingWindowHours: number;
  recommendedInspection: string;
  status: 'recommended' | 'scheduled' | 'in_progress' | 'completed';
  createdAt: number;
}

export interface IndustrialEvent {
  id: string;
  timestamp: number;
  type:
    | 'MACHINE_STARTED'
    | 'MACHINE_STOPPED'
    | 'TRUCK_LOADED'
    | 'TRUCK_DUMPED'
    | 'CRUSHER_FEED_UPDATE'
    | 'STOCKPILE_BLENDED'
    | 'DRILL_PATTERN_OPTIMISED'
    | 'MAINTENANCE_TRIGGERED'
    | 'ANOMALY_FLAGGED'
    | 'SAFETY_INTERLOCK_ENGAGED'
    | 'DISPATCH_RECOMMENDED';
  message: string;
  source: string;
  severity: 'normal' | 'info' | 'alert' | 'critical';
}

export interface WhatIfScenarioInput {
  truckCountDiesel: number;
  truckCountElectric: number;
  excavatorCount: number;
  targetTph: number;
  fuelPricePerLiter: number;
  electricityPricePerKwh: number;
  oreGradeFactor: number; // e.g. 1.0 = baseline, 1.2 = +20%
  plantCapacityTph: number;
  roadRoughnessFactor: number; // 1.0 = normal, 1.3 = rough
  shiftDurationHours: number;
}

export interface WhatIfScenarioResult {
  projectedTotalTonnes: number;
  projectedTph: number;
  projectedTotalCost: number;
  projectedCostPerTonne: number;
  projectedEnergyKwhPerTonne: number;
  projectedFuelLitersPerTonne: number;
  projectedFleetUtilisationPct: number;
  projectedPlantBottleneckRiskPct: number;
  estimatedProfitability: number;
  comparisonVsBaselinePct: {
    production: number;
    cost: number;
    emissions: number;
  };
}

export interface ModelDriftStats {
  modelName: string;
  version: string;
  rmse: number;
  baselineRmse: number;
  psiScore: number; // Population Stability Index
  featureDriftDetected: boolean;
  confidenceMean: number;
  sampleCount: number;
  retrainingRecommended: boolean;
  lastRetrained: string;
}

export interface ScheduleItem {
  id: string;
  timeSlot: string; // e.g. '07:00 - 09:00'
  activity: 'Drilling' | 'Blasting' | 'Excavation' | 'Haulage' | 'Crushing' | 'Blending' | 'PM Maintenance' | 'Battery Charging';
  assignedEquipment: string[];
  benchLocation: string;
  targetTonnes: number;
  priority: 'routine' | 'critical' | 'high_grade';
}
