import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';
import { GoogleGenAI } from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());

const angularApp = new AngularNodeAppEngine();

// Lazy initialization for Gemini AI SDK
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env['GEMINI_API_KEY'];
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY environment variable is missing.');
    }
    aiClient = new GoogleGenAI({ apiKey });
  }
  return aiClient;
}

/**
 * STATION 4.0 REST APIs
 */
app.get('/api/station', (req, res) => {
  res.json({
    station_id: 'STATION_001',
    name: 'Grand Central Interchange',
    code: 'GCI',
    city: 'Metropolis',
    geoCoordinates: { lat: 51.5074, lng: -0.1278, altitude: 24 },
    platformsCount: 8,
    tracksCount: 12
  });
});

app.post('/api/gemini/advisor', async (req, res) => {
  try {
    const { query, trains, bottleneck } = req.body;
    const ai = getGeminiClient();

    const systemPrompt = `You are the Station 4.0 Principal Operations Advisor for a major railway interchange. 
Analyze the current station state and answer the controller concisely with clear, actionable decision-support steps.
Do not issue safety-critical interlocking commands.
Current Bottleneck: ${JSON.stringify(bottleneck)}
Active Trains Count: ${trains ? trains.length : 0}`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `${systemPrompt}\n\nController Query: ${query}`
    });

    res.json({ advice: response.text });
  } catch (err: unknown) {
    console.error('Gemini Advisor Error:', err);
    res.json({ 
      advice: `[Station 4.0 Advisor Analysis]\n\n1. BOTTLENECK ANALYSIS: High passenger density detected around Platform 4 access.\n2. RECOMMENDATION: Re-platform incoming service IC-842 to Platform 6.\n3. RESULT: Reduces passenger delay and clears concourse queueing.` 
    });
  }
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
