export type ZoomLevel = 'CITY' | 'STATION' | 'BUILDING' | 'CONCOURSE' | 'PLATFORM' | 'TRACK' | 'ASSET';

export type LanguageCode = 'en' | 'zh-TW' | 'zh-CN' | 'ja' | 'ko' | 'fr' | 'de' | 'es';

export type TrainStatus = 
  | 'APPROACHING' 
  | 'ARRIVING' 
  | 'AT PLATFORM' 
  | 'BOARDING' 
  | 'DEPARTING' 
  | 'DEPARTED' 
  | 'DELAYED' 
  | 'CANCELLED' 
  | 'DIVERTED';

export type PlatformStatus = 
  | 'AVAILABLE' 
  | 'OCCUPIED' 
  | 'BOARDING' 
  | 'CLOSED' 
  | 'MAINTENANCE' 
  | 'RESTRICTED';

export type TrackStatus = 
  | 'AVAILABLE' 
  | 'OCCUPIED' 
  | 'BLOCKED' 
  | 'MAINTENANCE' 
  | 'RESTRICTED';

export type AssetStatus = 'OPERATIONAL' | 'DEGRADED' | 'FAULT' | 'MAINTENANCE';

export type CrowdingLevel = 'NORMAL' | 'BUSY' | 'CROWDED' | 'SEVERE';

export type EventType = 
  | 'TRAIN_ARRIVAL'
  | 'TRAIN_DEPARTURE'
  | 'TRAIN_DELAY'
  | 'TRAIN_CANCELLED'
  | 'PLATFORM_CHANGE'
  | 'PLATFORM_CLOSED'
  | 'TRACK_BLOCKED'
  | 'LIFT_FAILURE'
  | 'ESCALATOR_FAILURE'
  | 'CROWDING_ALERT'
  | 'ASSET_FAILURE'
  | 'MAINTENANCE_EVENT'
  | 'WEATHER_ALERT'
  | 'DISRUPTION_RESOLVED';

export interface GeoLocation {
  lat: number;
  lng: number;
  altitude?: number;
}

export interface Position3D {
  x: number;
  y: number;
  z: number;
}

export interface Dimensions3D {
  width: number;
  length: number;
  height: number;
}

export interface StationBuilding {
  id: string;
  name: string;
  floors: number;
  footprint: Position3D[];
  height: number;
}

export interface TrackSection {
  id: string;
  code?: string;
  name: string;
  associatedPlatformId?: string;
  lengthMeters: number;
  status?: TrackStatus;
  startPoint?: Position3D;
  endPoint?: Position3D;
  occupiedByTrainId?: string;
  maxSpeedKmh: number;
  electrificationType?: string;
  isOccupied?: boolean;
  signallingState?: string;
  speedLimitKmh?: number;
}

export interface Platform {
  id: string;
  number: string;
  code?: string;
  name?: string;
  lengthMeters: number;
  widthMeters?: number;
  capacity: number;
  accessibility?: boolean;
  facilities?: string[];
  associatedTrackIds?: string[];
  currentOccupancy: number; // current passengers on platform
  currentTrainId?: string;
  nextTrainId?: string;
  status: PlatformStatus;
  position?: Position3D;
  level?: string; // e.g. "Platform Level (B2)"
  maxTrainLengthMeters?: number;
  hasPlatformScreenDoors?: boolean;
  isAccessible?: boolean;
  canSubdivide?: boolean;
  assignedTrainId?: string | null;
}

export interface TrainService {
  id: string;
  trainNumber: string;
  operator: string;
  serviceId: string;
  origin: string;
  destination: string;
  scheduledArrival: string; // HH:mm format or ISO
  estimatedArrival: string;
  actualArrival?: string;
  scheduledDeparture: string;
  estimatedDeparture: string;
  actualDeparture?: string;
  platformId: string;
  trainLengthMeters: number;
  carriagesCount: number;
  occupancyPercentage: number;
  delayMinutes?: number;
  status: TrainStatus;
  viaStations?: string[];
  firstClassCarriages?: number[];
  accessibleCarriages?: number[];
  currentTrackSectionId?: string;
  progressPercent?: number; // 0 to 100 on current track/approach
  passengerCount?: number;
  trainType?: string;
  maxCapacity?: number;
  isAccessible?: boolean;
  trackSectionId?: string;
}

export interface PassengerZone {
  id: string;
  name: string;
  type: 'ENTRANCE' | 'TICKET_HALL' | 'CONCOURSE' | 'GATE_LINE' | 'PLATFORM' | 'STAIRS' | 'ESCALATOR' | 'LIFT' | 'WAITING' | 'RETAIL' | 'GATES';
  currentPeople: number;
  capacity: number;
  densityPeoplePerSqm: number;
  level: CrowdingLevel;
  position?: Position3D;
  dimensions?: Dimensions3D;
  flowRateInPaxPerMin?: number;
  flowRateOutPaxPerMin?: number;
}

export interface QueueModel {
  id: string;
  zoneId: string;
  name: string;
  queueLengthCount: number;
  averageWaitTimeMinutes: number;
  arrivalRatePerMin: number;
  serviceRatePerMin: number;
  utilisationPercent: number;
  estimatedClearanceTimeMin: number;
}

export interface StationAsset {
  id: string;
  name: string;
  type: 'LIFT' | 'ESCALATOR' | 'TICKET_GATE' | 'TICKET_MACHINE' | 'CCTV' | 'DISPLAY' | 'HVAC' | 'LIGHTING' | 'POWER' | 'DOORS' | 'SIGNAGE';
  zoneId?: string;
  status: AssetStatus;
  runtimeHours?: number;
  lastMaintenanceDate?: string;
  nextMaintenanceDue?: string;
  faultProbabilityPercent?: number;
  temperatureCelsius?: number;
  vibrationMmSec?: number;
  powerKw?: number;
  position?: Position3D;
  isAccessibleRouteNode?: boolean;
  healthScorePercent?: number;
  temperatureC?: number;
  vibrationMmS?: number;
  cyclesCount?: number;
  activeAlertMessage?: string;
  location?: string;
}

export type AssetTelemetry = StationAsset;

export interface EnergyMetrics {
  totalConsumptionKwh: number;
  currentLoadKw: number;
  peakDemandKw: number;
  energyPerPassengerWh: number;
  energyPerTrainKwh: number;
  lightingKw: number;
  hvacKw: number;
  escalatorsKw: number;
  liftsKw: number;
  displaysKw: number;
  savingModeActive: boolean;
}

export interface EnergyTelemetry {
  timestamp: string;
  totalKw: number;
  hvacKw: number;
  lightingKw: number;
  escalatorsKw: number;
  liftsKw: number;
  displaysKw: number;
  kwhPerPassenger: number;
}

export interface WeatherData {
  temperatureC: number;
  condition: 'CLEAR' | 'RAIN' | 'HEAVY_RAIN' | 'SNOW' | 'WINDY' | 'FOG';
  windSpeedKmh: number;
  visibilityMeters: number;
  passengerImpactFactor: number; // multiplier e.g. 1.15x for rain
  delaysRiskPercent: number;
}

export interface WeatherStatus {
  condition: string;
  temperatureC: number;
  visibilityKm: number;
  windSpeedKmh: number;
  precipitationMm: number;
  impactOnPassengerFlowPercent: number;
}

export interface WayfindingNode {
  id: string;
  name: string;
  type?: 'ENTRANCE' | 'CONCOURSE' | 'GATE' | 'PLATFORM' | 'STAIR' | 'ESCALATOR' | 'LIFT' | 'EXIT';
  position?: Position3D;
  isAccessible: boolean;
  isOpen?: boolean;
  level?: string;
}

export interface WayfindingEdge {
  id: string;
  fromNodeId: string;
  toNodeId: string;
  distanceMeters: number;
  hasStairs: boolean;
  hasLift: boolean;
  hasEscalator: boolean;
  crowdingFactor: number;
  isOpen: boolean;
}

export interface WayfindingRoute {
  pathNodes: WayfindingNode[];
  totalDistanceMeters: number;
  estimatedTimeMin: number;
  isFullyAccessible: boolean;
  hasElevators: boolean;
  hasEscalators: boolean;
  hasStairs: boolean;
}

export interface StationEvent {
  id: string;
  timestamp: string;
  type: EventType | string;
  title: string;
  description: string;
  severity: 'INFO' | 'WARNING' | 'CRITICAL' | 'SUCCESS';
  sourceSystem?: string;
  affectedEntityIds?: string[];
}

export interface DisruptionIncident {
  id: string;
  title: string;
  type?: string;
  startTime: string;
  status: 'ACTIVE' | 'RESOLVED' | 'SIMULATING';
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' | 'MAJOR';
  description: string;
  affectedPlatformIds?: string[];
  affectedTrackIds?: string[];
  affectedServicesCount: number;
  affectedPassengersCount: number;
  recoveryOptions: RecoveryOption[];
}

export interface RecoveryOption {
  id: string;
  title: string;
  type?: 'REPLATFORM' | 'HOLD_CONNECTING' | 'ALTER_SEQUENCE' | 'REROUTE_PASSENGERS' | 'OPEN_AUX_ROUTE';
  description: string;
  recommended: boolean;
  score: number; // 0 to 100
  passengerDelayReductionMin: number;
  throughputGainPercent: number;
  conflictsCreated?: number;
  reason?: string;
}

export interface StationConflict {
  id: string;
  trainAId: string;
  trainBId: string;
  platformId: string;
  overlapStartTime?: string;
  overlapEndTime?: string;
  timeOverlapStart?: string;
  timeOverlapEnd?: string;
  severity: 'WARNING' | 'CRITICAL';
  conflictType?: string;
  proposedResolutionPlatformId?: string;
}

export type ScheduleConflict = StationConflict;

export interface SimulationScenario {
  id: string;
  name: string;
  createdAt: string;
  passengerMultiplier: number; // e.g. 1.2 (+20%)
  closedPlatformIds: string[];
  closedAssetIds?: string[];
  newTrainAdded?: boolean;
  weatherCondition?: 'CLEAR' | 'RAIN' | 'SNOW';
  weatherEvent?: 'CLEAR' | 'RAIN' | 'SNOW';
  // Comparison results
  currentCapacityUtilisation: number;
  simulatedCapacityUtilisation: number;
  currentAvgWalkingTimeMin: number;
  simulatedAvgWalkingTimeMin: number;
  currentCrowdingIndex: number;
  simulatedCrowdingIndex: number;
  currentTrainThroughputPerHour: number;
  simulatedTrainThroughputPerHour: number;
  currentEnergyKw: number;
  simulatedEnergyKw: number;
}

export type StationScenario = SimulationScenario;

export interface StationConfig {
  station_id: string;
  name: string;
  code: string;
  city: string;
  geoCoordinates: GeoLocation;
  platformsCount: number;
  tracksCount: number;
  levels?: { id: string; name: string; elevationMeters: number }[];
  buildings?: StationBuilding[];
  platforms?: Platform[];
  tracks?: TrackSection[];
  assets?: StationAsset[];
}
