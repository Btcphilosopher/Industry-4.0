import { Injectable, signal, computed } from '@angular/core';
import {
  StationConfig,
  Platform,
  TrackSection,
  TrainService,
  AssetTelemetry,
  PassengerZone,
  StationEvent,
  DisruptionIncident,
  ScheduleConflict,
  RecoveryOption,
  WayfindingRoute,
  WayfindingNode,
  StationScenario,
  WeatherStatus,
  EnergyTelemetry
} from '../models/station-digital-twin.models';

@Injectable({
  providedIn: 'root'
})
export class StationStateService {
  // Station Config
  readonly stationConfig = signal<StationConfig>({
    station_id: 'STATION_001',
    name: 'Grand Central Interchange',
    code: 'GCI',
    city: 'Metropolis',
    geoCoordinates: { lat: 51.5074, lng: -0.1278, altitude: 24 },
    platformsCount: 8,
    tracksCount: 12
  });

  // Core Entity States
  readonly platforms = signal<Platform[]>([]);
  readonly tracks = signal<TrackSection[]>([]);
  readonly trains = signal<TrainService[]>([]);
  readonly assets = signal<AssetTelemetry[]>([]);
  readonly passengerZones = signal<PassengerZone[]>([]);
  readonly events = signal<StationEvent[]>([]);
  readonly disruptions = signal<DisruptionIncident[]>([]);

  // Telemetry & Weather
  readonly weather = signal<WeatherStatus>({
    condition: 'CLEAR',
    temperatureC: 19,
    visibilityKm: 10,
    windSpeedKmh: 12,
    precipitationMm: 0,
    impactOnPassengerFlowPercent: 0
  });

  readonly energy = signal<EnergyTelemetry>({
    timestamp: new Date().toISOString(),
    totalKw: 410,
    hvacKw: 180,
    lightingKw: 65,
    escalatorsKw: 90,
    liftsKw: 45,
    displaysKw: 30,
    kwhPerPassenger: 0.165
  });

  // Time Machine Snapshots
  readonly historicalSnapshots = signal<{ timestamp: string; trainsCount: number; crowdingIndex: number }[]>([]);

  // Scenario Laboratory Active Scenario
  readonly activeScenario = signal<StationScenario | null>(null);

  // Computed Bottleneck Zone
  readonly stationBottleneck = computed(() => {
    const zones = this.passengerZones();
    if (zones.length === 0) {
      return { zone: null, utilisationPercent: 0, headroomPercent: 100 };
    }
    const sorted = [...zones].sort((a, b) => (b.currentPeople / b.capacity) - (a.currentPeople / a.capacity));
    const worst = sorted[0];
    const util = Math.round((worst.currentPeople / worst.capacity) * 100);
    return {
      zone: worst,
      utilisationPercent: util,
      headroomPercent: Math.max(0, 100 - util)
    };
  });

  // Computed Conflicts
  readonly activeConflicts = computed<ScheduleConflict[]>(() => {
    const trainList = this.trains();
    const conflicts: ScheduleConflict[] = [];

    for (let i = 0; i < trainList.length; i++) {
      for (let j = i + 1; j < trainList.length; j++) {
        const t1 = trainList[i];
        const t2 = trainList[j];
        if (t1.platformId === t2.platformId && t1.status !== 'DEPARTED' && t2.status !== 'DEPARTED') {
          conflicts.push({
            id: `CONF_${t1.id}_${t2.id}`,
            platformId: t1.platformId,
            trainAId: t1.id,
            trainBId: t2.id,
            conflictType: 'SIMULTANEOUS_PLATFORM_OCCUPANCY',
            timeOverlapStart: t1.estimatedArrival,
            timeOverlapEnd: t1.estimatedDeparture,
            severity: 'CRITICAL',
            proposedResolutionPlatformId: 'PLAT_06'
          });
        }
      }
    }
    return conflicts;
  });

  // Executive KPIs
  readonly executiveKPIs = computed(() => {
    const trainList = this.trains();
    const zoneList = this.passengerZones();
    const assetList = this.assets();

    const totalTrainsToday = 142;
    const onTimeCount = trainList.filter(t => t.status !== 'DELAYED' && t.status !== 'CANCELLED').length;
    const onTimePercent = trainList.length > 0 ? Math.round((onTimeCount / trainList.length) * 100) : 98;

    const totalPassengers = zoneList.reduce((sum, z) => sum + z.currentPeople, 0);
    const totalCapacity = zoneList.reduce((sum, z) => sum + z.capacity, 0);
    const capacityUtilisation = totalCapacity > 0 ? Math.round((totalPassengers / totalCapacity) * 100) : 42;

    const operationalAssets = assetList.filter(a => a.status === 'OPERATIONAL').length;
    const assetAvailability = assetList.length > 0 ? Math.round((operationalAssets / assetList.length) * 100) : 95;

    return {
      totalTrainsToday,
      onTimePercent,
      totalPassengers,
      capacityUtilisation,
      assetAvailability,
      energyConsumptionKwh: 4850,
      peakCrowdingIndex: this.stationBottleneck().utilisationPercent,
      avgDelayMin: 1.8
    };
  });

  constructor() {
    this.initMockData();
    this.startSimulationLoop();
  }

  private initMockData() {
    // 8 Platforms
    const mockPlatforms: Platform[] = Array.from({ length: 8 }, (_, i) => {
      const num = String(i + 1);
      return {
        id: `PLAT_0${num}`,
        number: num,
        code: `P${num}`,
        lengthMeters: i < 4 ? 400 : 300,
        maxTrainLengthMeters: i < 4 ? 380 : 280,
        capacity: 1200,
        currentOccupancy: Math.floor(Math.random() * 400) + 50,
        status: i === 3 ? 'BOARDING' : (i === 6 ? 'CLOSED' : 'AVAILABLE'),
        hasPlatformScreenDoors: i < 4,
        isAccessible: true,
        canSubdivide: i >= 4,
        assignedTrainId: i === 3 ? 'TRN_101' : null
      };
    });
    this.platforms.set(mockPlatforms);

    // 12 Track Sections
    const mockTracks: TrackSection[] = Array.from({ length: 12 }, (_, i) => ({
      id: `TRK_${i + 1}`,
      name: `Track Section TS-${100 + i}`,
      lengthMeters: 500,
      maxSpeedKmh: i < 4 ? 120 : 60,
      electrificationType: 'OHLE_25KV',
      isOccupied: i === 3 || i === 7,
      signallingState: i === 3 ? 'RED' : 'GREEN',
      speedLimitKmh: i < 4 ? 120 : 60
    }));
    this.tracks.set(mockTracks);

    // Initial Trains
    const mockTrains: TrainService[] = [
      {
        id: 'TRN_101',
        serviceId: 'IC-842',
        trainNumber: 'IC 842',
        operator: 'Express Rail',
        origin: 'Capital City',
        destination: 'Northern Hub',
        viaStations: ['Airport Junction', 'Riverside'],
        scheduledArrival: '08:42',
        estimatedArrival: '08:42',
        scheduledDeparture: '08:48',
        estimatedDeparture: '08:48',
        platformId: 'PLAT_04',
        trackSectionId: 'TRK_4',
        status: 'BOARDING',
        trainType: 'HIGH_SPEED',
        carriagesCount: 8,
        trainLengthMeters: 200,
        passengerCount: 620,
        maxCapacity: 800,
        occupancyPercentage: 77,
        firstClassCarriages: [1, 2],
        isAccessible: true
      },
      {
        id: 'TRN_102',
        serviceId: 'SUB-204',
        trainNumber: 'SUB 204',
        operator: 'Metro Rail',
        origin: 'West Suburbs',
        destination: 'East Terminus',
        viaStations: ['Central Park', 'Financial District'],
        scheduledArrival: '08:45',
        estimatedArrival: '08:47',
        scheduledDeparture: '08:49',
        estimatedDeparture: '08:51',
        platformId: 'PLAT_02',
        trackSectionId: 'TRK_2',
        status: 'APPROACHING',
        trainType: 'COMMUTER',
        carriagesCount: 6,
        trainLengthMeters: 150,
        passengerCount: 410,
        maxCapacity: 600,
        occupancyPercentage: 68,
        firstClassCarriages: [],
        isAccessible: true
      },
      {
        id: 'TRN_103',
        serviceId: 'REG-509',
        trainNumber: 'REG 509',
        operator: 'Regional Trans',
        origin: 'South Coast',
        destination: 'Grand Central Interchange',
        viaStations: ['Harbor Lights', 'University'],
        scheduledArrival: '08:50',
        estimatedArrival: '08:55',
        scheduledDeparture: '09:05',
        estimatedDeparture: '09:10',
        platformId: 'PLAT_01',
        trackSectionId: 'TRK_1',
        status: 'DELAYED',
        trainType: 'REGIONAL',
        carriagesCount: 4,
        trainLengthMeters: 100,
        passengerCount: 280,
        maxCapacity: 400,
        occupancyPercentage: 70,
        firstClassCarriages: [1],
        isAccessible: true
      }
    ];
    this.trains.set(mockTrains);

    // Passenger Zones
    const mockZones: PassengerZone[] = [
      {
        id: 'ZONE_MAIN_HALL',
        name: 'Main Concourse Hall',
        type: 'CONCOURSE',
        currentPeople: 1120,
        capacity: 2500,
        densityPeoplePerSqm: 1.2,
        level: 'NORMAL',
        flowRateInPaxPerMin: 120,
        flowRateOutPaxPerMin: 115
      },
      {
        id: 'ZONE_PLAT_04_STAIRS',
        name: 'Platform 4 Access Stairs & Escalator',
        type: 'STAIRS',
        currentPeople: 480,
        capacity: 500,
        densityPeoplePerSqm: 3.8,
        level: 'SEVERE',
        flowRateInPaxPerMin: 90,
        flowRateOutPaxPerMin: 45
      },
      {
        id: 'ZONE_NORTH_GATES',
        name: 'North Ticket Gates',
        type: 'GATES',
        currentPeople: 310,
        capacity: 800,
        densityPeoplePerSqm: 1.8,
        level: 'BUSY',
        flowRateInPaxPerMin: 150,
        flowRateOutPaxPerMin: 140
      }
    ];
    this.passengerZones.set(mockZones);

    // Assets
    const mockAssets: AssetTelemetry[] = [
      {
        id: 'AST_LIFT_01',
        name: 'Main Concourse Lift A1',
        type: 'LIFT',
        location: 'Concourse Central',
        status: 'OPERATIONAL',
        healthScorePercent: 94,
        temperatureC: 28,
        vibrationMmS: 0.8,
        cyclesCount: 14200,
        lastMaintenanceDate: '2025-01-15'
      },
      {
        id: 'AST_LIFT_02',
        name: 'Platform 4 Wheelchair Lift',
        type: 'LIFT',
        location: 'Platform 4 North',
        status: 'FAULT',
        healthScorePercent: 32,
        temperatureC: 48,
        vibrationMmS: 4.2,
        cyclesCount: 18900,
        lastMaintenanceDate: '2024-11-10',
        activeAlertMessage: 'Door sensor alignment fault (E-402)'
      },
      {
        id: 'AST_ESC_01',
        name: 'Platform 3-4 Escalator Up',
        type: 'ESCALATOR',
        location: 'Platform 4 South',
        status: 'OPERATIONAL',
        healthScorePercent: 88,
        temperatureC: 32,
        vibrationMmS: 1.2,
        cyclesCount: 34000,
        lastMaintenanceDate: '2025-02-01'
      }
    ];
    this.assets.set(mockAssets);

    // Disruptions & AI Recovery Options
    const mockDisruption: DisruptionIncident = {
      id: 'DIS_001',
      title: 'Platform 4 Wheelchair Lift Failure & Concourse Crowding',
      description: 'Lift AST_LIFT_02 failed at 08:35 due to door alignment error. Reduced accessibility causing queue spillover onto Platform 4 stairwell.',
      startTime: '08:35:00',
      status: 'ACTIVE',
      severity: 'MAJOR',
      affectedPassengersCount: 480,
      affectedServicesCount: 2,
      recoveryOptions: [
        {
          id: 'REC_OPT_A',
          title: 'Option A: Re-platform IC 842 to Platform 6 (Recommended)',
          description: 'Re-assign IC 842 from Platform 4 to Platform 6 which has dual functioning lifts and lower concourse density.',
          throughputGainPercent: 18,
          passengerDelayReductionMin: 12,
          score: 92,
          recommended: true
        },
        {
          id: 'REC_OPT_B',
          title: 'Option B: Deploy Station Assistants & Manual Rerouting',
          description: 'Keep IC 842 on Platform 4 and deploy staff to guide wheelchair passengers via Platform 3 ramp connector.',
          throughputGainPercent: 5,
          passengerDelayReductionMin: 4,
          score: 68,
          recommended: false
        }
      ]
    };
    this.disruptions.set([mockDisruption]);
  }

  private startSimulationLoop() {
    setInterval(() => {
      // Simulate live progress
      this.trains.update(trainList => {
        return trainList.map(t => {
          if (t.status === 'APPROACHING') {
            return { ...t, status: 'AT PLATFORM' as const };
          }
          return t;
        });
      });

      // Fluctuate zone passenger numbers
      this.passengerZones.update(zones => {
        return zones.map(z => {
          const delta = Math.floor(Math.random() * 21) - 10;
          const nextCount = Math.max(20, Math.min(z.capacity, z.currentPeople + delta));
          const ratio = nextCount / z.capacity;
          let level: 'NORMAL' | 'BUSY' | 'CROWDED' | 'SEVERE' = 'NORMAL';
          if (ratio > 0.9) level = 'SEVERE';
          else if (ratio > 0.75) level = 'CROWDED';
          else if (ratio > 0.5) level = 'BUSY';

          return {
            ...z,
            currentPeople: nextCount,
            densityPeoplePerSqm: Number((ratio * 4).toFixed(1)),
            level
          };
        });
      });
    }, 3000);
  }

  // Executing Operator Decision
  applyRecoveryOption(disruptionId: string, option: RecoveryOption) {
    this.disruptions.update(disList => {
      return disList.map(d => {
        if (d.id === disruptionId) {
          return { ...d, status: 'RESOLVED' as const };
        }
        return d;
      });
    });

    if (option.id === 'REC_OPT_A') {
      this.trains.update(trains => {
        return trains.map(t => {
          if (t.id === 'TRN_101') {
            return { ...t, platformId: 'PLAT_06', status: 'BOARDING' as const };
          }
          return t;
        });
      });
    }

    const newEvt: StationEvent = {
      id: `EVT_${Date.now()}`,
      timestamp: new Date().toLocaleTimeString(),
      type: 'DISRUPTION_RESOLVED',
      title: `Executed Recovery Strategy: ${option.title}`,
      description: `Disruption ${disruptionId} resolved. Delay reduction estimated -${option.passengerDelayReductionMin} mins.`,
      severity: 'SUCCESS',
      sourceSystem: 'OPERATOR_CONSOLE'
    };

    this.events.update(e => [newEvt, ...e]);
  }

  // Wayfinding Route Engine
  calculateWayfindingRoute(fromNodeId: string, toNodeId: string, mode: 'FASTEST' | 'ACCESSIBLE' | 'LEAST_CROWDED' | 'LUGGAGE'): WayfindingRoute {
    const nodes: WayfindingNode[] = [
      { id: 'NODE_ENT_NORTH', name: 'North Main Entrance', level: 'GROUND', isAccessible: true },
      { id: 'NODE_GATES_N', name: 'North Ticket Gates', level: 'GROUND', isAccessible: true },
      { id: 'NODE_CONCOURSE', name: 'Central Concourse', level: 'GROUND', isAccessible: true },
      { id: 'NODE_LIFT_01', name: 'Concourse Elevator A1', level: 'GROUND', isAccessible: true },
      { id: 'NODE_PLAT_4', name: 'Platform 4 Boarding Area', level: 'LEVEL_B1', isAccessible: true }
    ];

    const isAccessibleOnly = mode === 'ACCESSIBLE';

    return {
      pathNodes: nodes,
      totalDistanceMeters: 145,
      estimatedTimeMin: isAccessibleOnly ? 3.2 : 2.1,
      isFullyAccessible: true,
      hasElevators: true,
      hasEscalators: !isAccessibleOnly,
      hasStairs: false
    };
  }

  // Scenario Creation
  createScenario(name: string, paxMultiplier: number, closedPlatforms: string[], weatherEvent: 'CLEAR' | 'RAIN' | 'SNOW'): StationScenario {
    const currentUtil = this.executiveKPIs().capacityUtilisation;
    const simUtil = Math.min(100, Math.round(currentUtil * paxMultiplier));

    const sc: StationScenario = {
      id: `SCEN_${Date.now()}`,
      name,
      createdAt: new Date().toISOString(),
      passengerMultiplier: paxMultiplier,
      closedPlatformIds: closedPlatforms,
      weatherEvent,
      currentCapacityUtilisation: currentUtil,
      simulatedCapacityUtilisation: simUtil,
      currentAvgWalkingTimeMin: 2.8,
      simulatedAvgWalkingTimeMin: Number((2.8 * (1 + (paxMultiplier - 1) * 1.5)).toFixed(1)),
      currentCrowdingIndex: 42,
      simulatedCrowdingIndex: Math.min(100, Math.round(42 * paxMultiplier)),
      currentTrainThroughputPerHour: 24,
      simulatedTrainThroughputPerHour: closedPlatforms.length > 0 ? 20 : 28,
      currentEnergyKw: 410,
      simulatedEnergyKw: Math.round(410 * (weatherEvent === 'SNOW' ? 1.25 : 1.1))
    };

    this.activeScenario.set(sc);
    return sc;
  }
}
