import { Injectable, signal } from '@angular/core';
import { LanguageCode } from '../models/station-digital-twin.models';

type TranslationDictionary = Record<string, Record<string, string>>;

@Injectable({
  providedIn: 'root'
})
export class I18nService {
  readonly currentLanguage = signal<LanguageCode>('en');

  readonly availableLanguages: { code: LanguageCode; label: string; flag: string }[] = [
    { code: 'en', label: 'English', flag: '🇬🇧' },
    { code: 'zh-TW', label: '繁體中文', flag: '🇭🇰' },
    { code: 'zh-CN', label: '简体中文', flag: '🇨🇳' },
    { code: 'ja', label: '日本語', flag: '🇯🇵' },
    { code: 'ko', label: '한국어', flag: '🇰🇷' },
    { code: 'fr', label: 'Français', flag: '🇫🇷' },
    { code: 'de', label: 'Deutsch', flag: '🇩🇪' },
    { code: 'es', label: 'Español', flag: '🇪🇸' }
  ];

  private readonly translations: TranslationDictionary = {
    en: {
      app_title: 'STATION 4.0',
      app_subtitle: 'Railway Station Digital Twin & Operating System',
      digital_twin: '3D Digital Twin',
      control_room: 'Control Room Wall',
      operator_dashboard: 'Operator Console',
      executive_dashboard: 'Executive KPIs',
      public_displays: 'Station Displays',
      scenario_lab: 'Scenario Lab',
      time_machine: 'Time Machine',
      ai_advisor: 'Gemini AI Advisor',
      live_trains: 'Live Trains',
      platform_state: 'Platform States',
      bottlenecks: 'Active Bottlenecks',
      disruptions: 'Disruption & Recovery',
      passenger_crowding: 'Passenger Crowding',
      safety_notice: 'Station 4.0 is decision support software. Certified interlocking & safety critical systems operate separately.'
    },
    'zh-TW': {
      app_title: '車站 4.0',
      app_subtitle: '鐵路車站數位分身與作業系統',
      digital_twin: '3D 數位分身',
      control_room: '行控中心電視牆',
      operator_dashboard: '調度員控制台',
      executive_dashboard: '高階關鍵指標',
      public_displays: '旅客資訊顯示',
      scenario_lab: '情境模擬實驗室',
      time_machine: '數位分身時光機',
      ai_advisor: 'Gemini 智能顧問',
      live_trains: '即時列車',
      platform_state: '月台狀態',
      bottlenecks: '擁擠瓶頸',
      disruptions: '事件與復原',
      passenger_crowding: '人潮密度',
      safety_notice: '車站 4.0 為營運決策支援軟體，連鎖與安全關鍵系統獨立運作。'
    },
    'zh-CN': {
      app_title: '车站 4.0',
      app_subtitle: '铁路车站数字孪生与操作系统',
      digital_twin: '3D 数字孪生',
      control_room: '调度中心电视墙',
      operator_dashboard: '调度员控制台',
      executive_dashboard: '高管关键指标',
      public_displays: '旅客信息显示',
      scenario_lab: '场景模拟实验室',
      time_machine: '数字孪生时光机',
      ai_advisor: 'Gemini 智能顾问',
      live_trains: '实时列车',
      platform_state: '站台状态',
      bottlenecks: '拥堵瓶颈',
      disruptions: '事件与复原',
      passenger_crowding: '人流密度',
      safety_notice: '车站 4.0 为运营决策支持软件，联锁与安全关键系统独立运行。'
    },
    ja: {
      app_title: 'ステーション 4.0',
      app_subtitle: '鉄道駅デジタルツイン＆オペレーティングシステム',
      digital_twin: '3D デジタルツイン',
      control_room: '管制室マルチモニター',
      operator_dashboard: '司令員コンソール',
      executive_dashboard: '経営KPIダッシュボード',
      public_displays: '駅案内表示（PIS）',
      scenario_lab: 'シナリオシミュレーション',
      time_machine: 'タイムマシン再生',
      ai_advisor: 'Gemini AIアドバイザー',
      live_trains: '運行中列車',
      platform_state: 'ホーム状況',
      bottlenecks: '混雑ボトルネック',
      disruptions: '運行障害・復旧',
      passenger_crowding: '混雑度レーダー',
      safety_notice: 'ステーション 4.0は運用支援システムです。インターロッキング安全装置は独立して動作します。'
    },
    ko: {
      app_title: '스테이션 4.0',
      app_subtitle: '철도역 디지털 트윈 및 운영 시스템',
      digital_twin: '3D 디지털 트윈',
      control_room: '종합제어실 비디오월',
      operator_dashboard: '관제사 콘솔',
      executive_dashboard: '경영 KPI 분석',
      public_displays: '전광판 안내 (PIS)',
      scenario_lab: '시나리오 실험실',
      time_machine: '타임머신 복원',
      ai_advisor: 'Gemini AI 어드바이저',
      live_trains: '실시간 열차',
      platform_state: '승강장 현황',
      bottlenecks: '병목 구간',
      disruptions: '지연 및 복구',
      passenger_crowding: '혼잡도 분석',
      safety_notice: '스테이션 4.0은 운용 의사결정 지원 시스템입니다. 연동 장치 및 안전 시스템은 별도로 운영됩니다.'
    },
    fr: {
      app_title: 'STATION 4.0',
      app_subtitle: 'Jumeau Numérique et Système d’Exploitation Ferroviaire',
      digital_twin: 'Jumeau Numérique 3D',
      control_room: 'Mur d’Image PCC',
      operator_dashboard: 'Console Opérateur',
      executive_dashboard: 'KPI Dirigeants',
      public_displays: 'Affichage Voyageurs',
      scenario_lab: 'Laboratoire de Scénarios',
      time_machine: 'Machine à Remonter le Temps',
      ai_advisor: 'Conseiller Gemini IA',
      live_trains: 'Trains en Circulation',
      platform_state: 'État des Quais',
      bottlenecks: 'Goulots d’Étranglement',
      disruptions: 'Perturbations & Reprise',
      passenger_crowding: 'Densité de Flux',
      safety_notice: 'Station 4.0 est un outil d’aide à la décision. L’enclenchement de sécurité fonctionne de manière autonome.'
    },
    de: {
      app_title: 'STATION 4.0',
      app_subtitle: 'Digitale Zwilling- & Betriebssystem für Bahnhöfe',
      digital_twin: '3D Digitaler Zwilling',
      control_room: 'Leitzentrale Videowand',
      operator_dashboard: 'Disponenten-Konsole',
      executive_dashboard: 'Management KPIs',
      public_displays: 'Fahrgastinformation',
      scenario_lab: 'Szenario-Labor',
      time_machine: 'Zeitreise-Replay',
      ai_advisor: 'Gemini KI-Berater',
      live_trains: 'Aktive Züge',
      platform_state: 'Gleis- & Bahnsteigstatus',
      bottlenecks: 'Engpässe',
      disruptions: 'Störungen & Dispo',
      passenger_crowding: 'Passagierdichte',
      safety_notice: 'Station 4.0 ist ein Entscheidungsunterstützungssystem. Stellwerke und Sicherungstechnik arbeiten separat.'
    },
    es: {
      app_title: 'ESTACIÓN 4.0',
      app_subtitle: 'Gemelo Digital y Sistema Operativo Ferroviario',
      digital_twin: 'Gemelo Digital 3D',
      control_room: 'Centro de Control Video Wall',
      operator_dashboard: 'Consola Operativa',
      executive_dashboard: 'KPIs Ejecutivos',
      public_displays: 'Pantallas al Público',
      scenario_lab: 'Laboratorio de Escenarios',
      time_machine: 'Máquina del Tiempo',
      ai_advisor: 'Asesor Gemini IA',
      live_trains: 'Trenes en Vivo',
      platform_state: 'Estado de Andenes',
      bottlenecks: 'Cuellos de Botella',
      disruptions: 'Incidencias y Recuperación',
      passenger_crowding: 'Afluencia de Pasajeros',
      safety_notice: 'Estación 4.0 es un software de apoyo a decisiones. Los enclavamientos de seguridad operan de forma independiente.'
    }
  };

  setLanguage(code: LanguageCode) {
    this.currentLanguage.set(code);
  }

  t(key: string): string {
    const lang = this.currentLanguage();
    const dict = this.translations[lang] || this.translations['en'];
    return dict[key] || this.translations['en'][key] || key;
  }
}
