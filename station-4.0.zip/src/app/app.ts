import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { StationStateService } from './services/station-state.service';
import { I18nService } from './services/i18n.service';
import { LanguageCode } from './models/station-digital-twin.models';

import { DigitalTwin3dComponent } from './components/3d-digital-twin/digital-twin-3d';
import { ControlRoomComponent } from './components/control-room/control-room';
import { OperatorDashboardComponent } from './components/operator-dashboard/operator-dashboard';
import { ExecutiveDashboardComponent } from './components/executive-dashboard/executive-dashboard';
import { PublicDisplaysComponent } from './components/public-displays/public-displays';
import { ScenarioLaboratoryComponent } from './components/scenario-laboratory/scenario-laboratory';
import { TimeMachineComponent } from './components/time-machine/time-machine';
import { AiAdvisorComponent } from './components/ai-advisor/ai-advisor';

export type MainView = 
  | 'DIGITAL_TWIN'
  | 'CONTROL_ROOM'
  | 'OPERATOR_DASHBOARD'
  | 'EXECUTIVE_KPIs'
  | 'PUBLIC_DISPLAYS'
  | 'SCENARIO_LAB'
  | 'TIME_MACHINE'
  | 'AI_ADVISOR';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    FormsModule,
    DigitalTwin3dComponent,
    ControlRoomComponent,
    OperatorDashboardComponent,
    ExecutiveDashboardComponent,
    PublicDisplaysComponent,
    ScenarioLaboratoryComponent,
    TimeMachineComponent,
    AiAdvisorComponent
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  readonly stateService = inject(StationStateService);
  readonly i18n = inject(I18nService);

  readonly activeView = signal<MainView>('DIGITAL_TWIN');
  readonly selectedStationId = signal<string>('STATION_001');

  readonly stationsList = [
    { id: 'STATION_001', name: 'Grand Central Interchange', code: 'GCI', type: 'Major Interchange' },
    { id: 'STATION_002', name: 'Central Terminus', code: 'CTR', type: 'Intercity Terminus' },
    { id: 'STATION_003', name: 'Metro Gateway', code: 'MGW', type: 'High-Frequency Metro' },
    { id: 'STATION_004', name: 'High-Speed Hub', code: 'HSH', type: 'International High-Speed' },
  ];

  onStationChange(e: Event) {
    const newId = (e.target as HTMLSelectElement).value;
    this.selectedStationId.set(newId);
    const stationObj = this.stationsList.find(s => s.id === newId);
    if (stationObj) {
      this.stateService.stationConfig.update(c => ({
        ...c,
        station_id: stationObj.id,
        name: stationObj.name,
        code: stationObj.code
      }));
    }
  }

  onLanguageChange(e: Event) {
    const code = (e.target as HTMLSelectElement).value as LanguageCode;
    this.i18n.setLanguage(code);
  }
}
