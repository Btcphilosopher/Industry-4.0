import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StationStateService } from '../../services/station-state.service';
import { I18nService } from '../../services/i18n.service';

@Component({
  selector: 'app-executive-dashboard',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full w-full bg-[#050505] p-5 overflow-y-auto font-sans text-[#E0E0E0] space-y-5">
      <!-- Title Bar -->
      <div class="flex items-center justify-between border-b border-[#222] pb-3">
        <div>
          <h1 class="text-base font-extrabold text-white flex items-center gap-2">
            <span class="material-icons-outlined text-[#F27D26]">query_stats</span>
            <span>Executive Station Performance KPIs & Analytics</span>
          </h1>
          <p class="text-xs text-[#888] font-mono">Real-Time Operational Efficiency, Passenger Demand Forecasts & Asset Health Summary</p>
        </div>

        <div class="flex items-center gap-2 text-xs font-mono text-[#AAA] bg-[#0A0A0A] px-3 py-1.5 rounded border border-[#222]">
          <span class="w-2.5 h-2.5 rounded-full bg-[#00FF44] shadow-[0_0_8px_#00FF44]"></span>
          <span>Station Twin Sync Active</span>
        </div>
      </div>

      <!-- Key Metrics Overview Grid (4 cards) -->
      <div class="grid grid-cols-4 gap-4">
        <!-- Metric 1: Trains Today & On-Time % -->
        <div class="bg-[#080808] border border-[#222] rounded p-4 shadow-xl space-y-2 font-mono">
          <div class="flex items-center justify-between text-[#888] text-xs">
            <span>DAILY TRAIN SERVICES</span>
            <span class="material-icons-outlined text-[#F27D26] text-base">directions_railway</span>
          </div>
          <div class="flex items-baseline justify-between">
            <span class="text-2xl font-extrabold text-white">{{ kpis().totalTrainsToday }}</span>
            <span class="text-xs font-bold text-[#00FF44] flex items-center gap-0.5">
              <span class="material-icons-outlined text-sm">trending_up</span> {{ kpis().onTimePercent }}% On-Time
            </span>
          </div>
          <div class="w-full bg-[#222] h-1.5 rounded overflow-hidden">
            <div [style.width.%]="kpis().onTimePercent" class="bg-[#00FF44] h-full"></div>
          </div>
          <p class="text-[10px] text-[#666]">Avg Delay: {{ kpis().avgDelayMin }} mins per service</p>
        </div>

        <!-- Metric 2: Passenger Volume & Capacity -->
        <div class="bg-[#080808] border border-[#222] rounded p-4 shadow-xl space-y-2 font-mono">
          <div class="flex items-center justify-between text-[#888] text-xs">
            <span>STATION PASSENGERS</span>
            <span class="material-icons-outlined text-[#00FF44] text-base">groups</span>
          </div>
          <div class="flex items-baseline justify-between">
            <span class="text-2xl font-extrabold text-white">{{ kpis().totalPassengers }}</span>
            <span class="text-xs font-bold text-[#F27D26] flex items-center gap-0.5">
              {{ kpis().capacityUtilisation }}% Capacity
            </span>
          </div>
          <div class="w-full bg-[#222] h-1.5 rounded overflow-hidden">
            <div [style.width.%]="kpis().capacityUtilisation" class="bg-[#F27D26] h-full"></div>
          </div>
          <p class="text-[10px] text-[#666]">Peak hour threshold: 3,500 max pax</p>
        </div>

        <!-- Metric 3: Asset Availability -->
        <div class="bg-[#080808] border border-[#222] rounded p-4 shadow-xl space-y-2 font-mono">
          <div class="flex items-center justify-between text-[#888] text-xs">
            <span>ASSET AVAILABILITY</span>
            <span class="material-icons-outlined text-[#FFB800] text-base">build</span>
          </div>
          <div class="flex items-baseline justify-between">
            <span class="text-2xl font-extrabold text-white">{{ kpis().assetAvailability }}%</span>
            <span class="text-xs text-[#888]">24 total assets</span>
          </div>
          <div class="w-full bg-[#222] h-1.5 rounded overflow-hidden">
            <div [style.width.%]="kpis().assetAvailability" class="bg-[#FFB800] h-full"></div>
          </div>
          <p class="text-[10px] text-[#666]">1 Lift under active maintenance</p>
        </div>

        <!-- Metric 4: Energy Consumption -->
        <div class="bg-[#080808] border border-[#222] rounded p-4 shadow-xl space-y-2 font-mono">
          <div class="flex items-center justify-between text-[#888] text-xs">
            <span>ENERGY LOAD</span>
            <span class="material-icons-outlined text-[#F27D26] text-base">bolt</span>
          </div>
          <div class="flex items-baseline justify-between">
            <span class="text-2xl font-extrabold text-white">{{ kpis().energyConsumptionKwh }} <span class="text-xs font-normal text-[#888]">kWh</span></span>
            <span class="text-xs text-[#F27D26] font-bold">410 kW load</span>
          </div>
          <div class="w-full bg-[#222] h-1.5 rounded overflow-hidden">
            <div [style.width.%]="70" class="bg-[#F27D26] h-full"></div>
          </div>
          <p class="text-[10px] text-[#666]">165 Wh per passenger efficiency</p>
        </div>
      </div>

      <!-- Statistical Models & Predictive Demand Breakdown -->
      <div class="grid grid-cols-12 gap-4">
        <!-- Statistical Engine (7 cols) -->
        <div class="col-span-7 bg-[#080808] border border-[#222] rounded p-4 space-y-3 shadow-xl">
          <h2 class="text-xs font-bold uppercase text-[#F27D26] tracking-widest flex items-center gap-1.5">
            <span class="material-icons-outlined text-base">analytics</span> Statistical Engine & Distribution Metrics
          </h2>

          <div class="grid grid-cols-3 gap-3 font-mono text-xs">
            <div class="bg-[#111] p-3 rounded border border-[#222] space-y-1">
              <span class="text-[#666] text-[10px] block uppercase">MEAN PASSENGER WAIT</span>
              <span class="text-lg font-bold text-white">3.4 min</span>
              <span class="text-[10px] text-[#666] block">Std Dev: ± 1.1 min</span>
            </div>

            <div class="bg-[#111] p-3 rounded border border-[#222] space-y-1">
              <span class="text-[#666] text-[10px] block uppercase">95TH PERCENTILE DELAY</span>
              <span class="text-lg font-bold text-[#FFB800]">8.5 min</span>
              <span class="text-[10px] text-[#666] block">Variance: 4.2 min²</span>
            </div>

            <div class="bg-[#111] p-3 rounded border border-[#222] space-y-1">
              <span class="text-[#666] text-[10px] block uppercase">PREDICTIVE FORECAST</span>
              <span class="text-lg font-bold text-[#00FF44]">+14% Peak</span>
              <span class="text-[10px] text-[#666] block">Confidence: 94.2%</span>
            </div>
          </div>

          <!-- Trend Projection Table -->
          <div class="pt-2">
            <span class="text-xs font-bold text-[#E0E0E0] block mb-2 font-mono uppercase tracking-wider">Hourly Throughput Trend & Forecast (Next 4 Hours):</span>
            <div class="grid grid-cols-4 gap-2 font-mono text-xs">
              <div class="bg-[#111] p-2.5 rounded border border-[#222] text-center">
                <span class="text-[#666] text-[10px] block">09:00 - 10:00</span>
                <span class="font-bold text-white text-sm">3,120 pax</span>
                <span class="text-[9px] text-[#00FF44] block">+6% vs avg</span>
              </div>
              <div class="bg-[#111] p-2.5 rounded border border-[#222] text-center">
                <span class="text-[#666] text-[10px] block">10:00 - 11:00</span>
                <span class="font-bold text-white text-sm">2,480 pax</span>
                <span class="text-[9px] text-[#888] block">Normal flow</span>
              </div>
              <div class="bg-[#111] p-2.5 rounded border border-[#222] text-center">
                <span class="text-[#666] text-[10px] block">11:00 - 12:00</span>
                <span class="font-bold text-white text-sm">2,100 pax</span>
                <span class="text-[9px] text-[#888] block">Off-peak</span>
              </div>
              <div class="bg-[#111] p-2.5 rounded border border-[#222] text-center">
                <span class="text-[#666] text-[10px] block">12:00 - 13:00</span>
                <span class="font-bold text-white text-sm">2,850 pax</span>
                <span class="text-[9px] text-[#FFB800] block">+12% Lunch peak</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Energy Digital Twin Breakdown (5 cols) -->
        <div class="col-span-5 bg-[#080808] border border-[#222] rounded p-4 space-y-3 shadow-xl">
          <h2 class="text-xs font-bold uppercase text-[#00FF44] tracking-widest flex items-center gap-1.5">
            <span class="material-icons-outlined text-base">energy_savings_leaf</span> Energy Digital Twin Subsystems
          </h2>

          <div class="space-y-2 font-mono text-xs">
            <div class="flex justify-between items-center bg-[#111] p-2 rounded border border-[#222]">
              <span class="text-[#AAA]">HVAC Chiller Systems</span>
              <span class="font-bold text-[#F27D26]">{{ stateService.energy().hvacKw }} kW</span>
            </div>
            <div class="flex justify-between items-center bg-[#111] p-2 rounded border border-[#222]">
              <span class="text-[#AAA]">Station Concourse Lighting</span>
              <span class="font-bold text-[#F27D26]">{{ stateService.energy().lightingKw }} kW</span>
            </div>
            <div class="flex justify-between items-center bg-[#111] p-2 rounded border border-[#222]">
              <span class="text-[#AAA]">Escalator Motor Drives</span>
              <span class="font-bold text-[#F27D26]">{{ stateService.energy().escalatorsKw }} kW</span>
            </div>
            <div class="flex justify-between items-center bg-[#111] p-2 rounded border border-[#222]">
              <span class="text-[#AAA]">Elevator Lifts</span>
              <span class="font-bold text-[#F27D26]">{{ stateService.energy().liftsKw }} kW</span>
            </div>
            <div class="flex justify-between items-center bg-[#111] p-2 rounded border border-[#222]">
              <span class="text-[#AAA]">PIS Display Screens</span>
              <span class="font-bold text-[#F27D26]">{{ stateService.energy().displaysKw }} kW</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ExecutiveDashboardComponent {
  readonly stateService = inject(StationStateService);
  readonly i18n = inject(I18nService);

  readonly kpis = this.stateService.executiveKPIs;
}
