import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { StationStateService } from '../../services/station-state.service';
import { I18nService } from '../../services/i18n.service';
import { TrainService, Platform, ScheduleConflict } from '../../models/station-digital-twin.models';

@Component({
  selector: 'app-operator-dashboard',
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full w-full bg-[#050505] p-4 overflow-y-auto font-sans text-[#E0E0E0] space-y-4">
      <!-- Top Title Bar -->
      <div class="flex items-center justify-between border-b border-[#222] pb-3">
        <div>
          <h1 class="text-base font-extrabold text-white flex items-center gap-2">
            <span class="material-icons-outlined text-[#F27D26]">tune</span>
            <span>Station Operations & Decision Support Console</span>
          </h1>
          <p class="text-xs text-[#888] font-mono">Scheduling, Platform Optimisation, Disruption Recovery, and Wayfinding Routing Engine</p>
        </div>

        <div class="flex items-center gap-3">
          <span class="text-xs font-mono text-[#666]">Decision-Support Mode:</span>
          <span class="px-2.5 py-1 rounded bg-[#F27D26]/15 text-[#F27D26] border border-[#F27D26]/30 text-xs font-mono font-bold tracking-wider uppercase">
            RECOMMENDATION ONLY (Safety Interlock Isolated)
          </span>
        </div>
      </div>

      <!-- Conflicts Alert Bar if any -->
      @if (stateService.activeConflicts().length > 0) {
        <div class="bg-[#1A0505] border border-[#FF4444]/40 rounded p-4 flex items-center justify-between shadow-xl">
          <div class="flex items-center gap-3">
            <span class="material-icons-outlined text-[#FF4444] text-2xl animate-bounce">warning</span>
            <div>
              <h3 class="text-xs font-bold text-[#FF4444] uppercase tracking-widest">Schedule Conflict Detected</h3>
              <p class="text-xs text-[#E0E0E0] font-mono mt-0.5">
                Two trains assigned to Platform {{ getPlatformNum(stateService.activeConflicts()[0].platformId) }} simultaneously!
              </p>
            </div>
          </div>
          <button 
            (click)="resolveConflict(stateService.activeConflicts()[0])"
            class="px-3 py-1.5 rounded bg-[#FF4444] hover:bg-red-600 text-black font-extrabold text-xs shadow transition-colors flex items-center gap-1 uppercase tracking-wider">
            <span class="material-icons-outlined text-sm">auto_fix_high</span> Auto-Replatform Conflict
          </button>
        </div>
      }

      <!-- Main 3-Column Operator Workspace -->
      <div class="grid grid-cols-12 gap-4">
        <!-- Column 1: Live Train Scheduling & Platform Allocator (4 cols) -->
        <div class="col-span-4 space-y-4">
          <!-- Live Train Schedule & Platform Optimizer -->
          <div class="bg-[#080808] border border-[#222] rounded p-4 shadow-xl space-y-3">
            <div class="flex items-center justify-between border-b border-[#222] pb-2">
              <h2 class="text-xs font-bold uppercase text-[#F27D26] tracking-widest flex items-center gap-1.5">
                <span class="material-icons-outlined text-base">schedule</span> Train Scheduling & Allocator
              </h2>
              <span class="text-[10px] font-mono text-[#666]">Live Optimization</span>
            </div>

            <div class="space-y-2 max-h-[380px] overflow-y-auto pr-1">
              @for (train of stateService.trains(); track train.id) {
                <button 
                  type="button"
                  [class]="selectedTrain()?.id === train.id ? 'border-[#F27D26] bg-[#F27D26]/10' : 'border-[#222] bg-[#111]'"
                  (click)="selectedTrain.set(train)"
                  class="w-full text-left p-3 rounded border hover:border-[#444] transition-all focus:outline-none">
                  <div class="flex justify-between items-center font-mono">
                    <span class="font-extrabold text-[#F27D26] text-xs">{{ train.trainNumber }}</span>
                    <span class="text-[10px] px-2 py-0.5 rounded bg-[#0A0A0A] border border-[#222] text-[#AAA]">
                      Plat {{ getPlatformNum(train.platformId) }}
                    </span>
                  </div>
                  <div class="text-xs text-[#E0E0E0] mt-1 flex justify-between">
                    <span>{{ train.origin }} → {{ train.destination }}</span>
                    <span class="text-[#888] font-mono text-[11px]">{{ train.scheduledDeparture }}</span>
                  </div>
                  <div class="flex items-center justify-between text-[11px] mt-2 pt-1 border-t border-[#1A1A1A] font-mono">
                    <span [class]="getTrainStatusClass(train.status)" class="font-bold text-[10px]">{{ train.status }}</span>
                    <span class="text-[#666]">{{ train.trainLengthMeters }}m | {{ train.occupancyPercentage }}% pax</span>
                  </div>
                </button>
              }
            </div>
          </div>

          <!-- Platform Allocation Optimization Panel -->
          @if (selectedTrain(); as t) {
            <div class="bg-[#080808] border border-[#F27D26]/40 rounded p-4 shadow-xl space-y-3">
              <div class="flex items-center justify-between border-b border-[#222] pb-2">
                <h3 class="text-xs font-bold text-white uppercase flex items-center gap-1.5 tracking-wider">
                  <span class="material-icons-outlined text-sm text-[#F27D26]">app_registration</span> Platform Optimiser — {{ t.trainNumber }}
                </h3>
              </div>
              <div class="text-xs space-y-2 font-mono text-[#AAA]">
                <p><span class="text-[#666]">Service:</span> {{ t.serviceId }} ({{ t.operator }})</p>
                <p><span class="text-[#666]">Current Assigned:</span> <span class="text-[#FFB800] font-bold">Platform {{ getPlatformNum(t.platformId) }}</span></p>

                <!-- Recommended Platforms Ranking -->
                <div class="pt-2 border-t border-[#222]">
                  <span class="text-[11px] font-bold text-[#00FF44] uppercase tracking-wider">Recommended Alternatives:</span>
                  <div class="space-y-1.5 mt-1.5">
                    @for (plat of getRecommendedPlatforms(t); track plat.id) {
                      <div class="flex items-center justify-between bg-[#111] p-2 rounded border border-[#222] text-[11px]">
                        <div>
                          <span class="font-bold text-white">Platform {{ plat.number }}</span>
                          <span class="text-[10px] text-[#666] ml-2">({{ plat.lengthMeters }}m | Cap: {{ plat.capacity }})</span>
                        </div>
                        <button 
                          (click)="assignPlatform(t, plat.id)"
                          class="px-2.5 py-1 rounded bg-[#F27D26] hover:bg-[#d96a1b] text-black font-extrabold text-[10px] transition-colors uppercase">
                          Assign
                        </button>
                      </div>
                    }
                  </div>
                </div>
              </div>
            </div>
          }
        </div>

        <!-- Column 2: Disruption Simulator & AI Recovery Optimizer (5 cols) -->
        <div class="col-span-5 space-y-4">
          <!-- Active Disruptions Card -->
          <div class="bg-[#080808] border border-[#222] rounded p-4 shadow-xl space-y-3">
            <div class="flex items-center justify-between border-b border-[#222] pb-2">
              <h2 class="text-xs font-bold uppercase text-[#FFB800] tracking-widest flex items-center gap-1.5">
                <span class="material-icons-outlined text-base">report_problem</span> Active Disruptions & Recovery
              </h2>
              <span class="text-[10px] font-mono text-[#666]">{{ stateService.disruptions().length }} registered</span>
            </div>

            <div class="space-y-3">
              @for (dis of stateService.disruptions(); track dis.id) {
                <div [class]="dis.status === 'ACTIVE' ? 'border-[#FFB800]/40 bg-[#1A1505]' : 'border-[#222] bg-[#111]'" class="p-3.5 rounded border space-y-2">
                  <div class="flex items-center justify-between">
                    <span class="font-bold text-xs text-white">{{ dis.title }}</span>
                    <span [class]="dis.status === 'ACTIVE' ? 'bg-[#FFB800]/15 text-[#FFB800] border-[#FFB800]/30' : 'bg-[#00FF44]/15 text-[#00FF44] border-[#00FF44]/30'" class="text-[10px] font-mono px-2 py-0.5 rounded border font-bold uppercase tracking-wider">
                      {{ dis.status }}
                    </span>
                  </div>
                  <p class="text-xs text-[#AAA] leading-relaxed">{{ dis.description }}</p>

                  <div class="flex items-center gap-4 text-[11px] text-[#888] font-mono pt-1">
                    <span>Affected Pax: <strong class="text-[#FFB800]">{{ dis.affectedPassengersCount }}</strong></span>
                    <span>Services: <strong class="text-[#F27D26]">{{ dis.affectedServicesCount }}</strong></span>
                  </div>

                  <!-- AI Generated Recovery Strategies -->
                  @if (dis.status === 'ACTIVE' && dis.recoveryOptions.length > 0) {
                    <div class="pt-2 border-t border-[#222] space-y-2">
                      <span class="text-[11px] font-bold text-[#F27D26] uppercase tracking-widest flex items-center gap-1">
                        <span class="material-icons-outlined text-xs">auto_awesome</span> Evaluated Recovery Options:
                      </span>

                      @for (opt of dis.recoveryOptions; track opt.id) {
                        <div class="bg-[#111] border border-[#222] rounded p-2.5 text-xs space-y-1.5">
                          <div class="flex items-center justify-between">
                            <span class="font-bold text-[#E0E0E0] flex items-center gap-1.5">
                              @if (opt.recommended) {
                                <span class="px-1.5 py-0.2 rounded bg-[#00FF44]/15 text-[#00FF44] border border-[#00FF44]/30 text-[9px] font-mono">RECOMMENDED</span>
                              }
                              {{ opt.title }}
                            </span>
                            <span class="font-mono font-bold text-[#F27D26] text-[11px]">Score: {{ opt.score }}/100</span>
                          </div>
                          <p class="text-[#888] text-[11px]">{{ opt.description }}</p>
                          
                          <div class="flex items-center justify-between pt-1 font-mono text-[10px] text-[#AAA]">
                            <span class="text-[#00FF44]">Delay Savings: -{{ opt.passengerDelayReductionMin }}m</span>
                            <span class="text-[#F27D26]">Throughput: +{{ opt.throughputGainPercent }}%</span>
                            <button 
                              (click)="stateService.applyRecoveryOption(dis.id, opt)"
                              class="px-2.5 py-1 rounded bg-[#F27D26] hover:bg-[#d96a1b] text-black font-extrabold text-[10px] transition-colors uppercase tracking-wider shadow">
                              EXECUTE DECISION
                            </button>
                          </div>
                        </div>
                      }
                    </div>
                  }
                </div>
              }
            </div>
          </div>
        </div>

        <!-- Column 3: Graph Wayfinding & Accessibility Routing Engine (3 cols) -->
        <div class="col-span-3 space-y-4">
          <div class="bg-[#080808] border border-[#222] rounded p-4 shadow-xl space-y-3">
            <div class="flex items-center justify-between border-b border-[#222] pb-2">
              <h2 class="text-xs font-bold uppercase text-[#00FF44] tracking-widest flex items-center gap-1.5">
                <span class="material-icons-outlined text-base">alt_route</span> Wayfinding Engine
              </h2>
            </div>

            <!-- Wayfinding Mode selector -->
            <div class="grid grid-cols-2 gap-1.5 text-[10px] font-semibold font-mono">
              <button 
                (click)="wayfindingMode.set('FASTEST')"
                [class]="wayfindingMode() === 'FASTEST' ? 'bg-[#F27D26] text-black font-bold' : 'bg-[#111] text-[#888] border border-[#222]'"
                class="p-1.5 rounded transition-colors uppercase">
                Fastest Route
              </button>
              <button 
                (click)="wayfindingMode.set('ACCESSIBLE')"
                [class]="wayfindingMode() === 'ACCESSIBLE' ? 'bg-[#F27D26] text-black font-bold' : 'bg-[#111] text-[#888] border border-[#222]'"
                class="p-1.5 rounded transition-colors uppercase">
                Wheelchair / Elevators
              </button>
              <button 
                (click)="wayfindingMode.set('LEAST_CROWDED')"
                [class]="wayfindingMode() === 'LEAST_CROWDED' ? 'bg-[#F27D26] text-black font-bold' : 'bg-[#111] text-[#888] border border-[#222]'"
                class="p-1.5 rounded transition-colors uppercase">
                Least Crowded
              </button>
              <button 
                (click)="wayfindingMode.set('LUGGAGE')"
                [class]="wayfindingMode() === 'LUGGAGE' ? 'bg-[#F27D26] text-black font-bold' : 'bg-[#111] text-[#888] border border-[#222]'"
                class="p-1.5 rounded transition-colors uppercase">
                Heavy Luggage
              </button>
            </div>

            <!-- Route Calculation Result -->
            @if (activeRoute(); as route) {
              <div class="bg-[#111] border border-[#222] rounded p-3 space-y-2 text-xs font-mono">
                <div class="flex justify-between items-center text-[#E0E0E0]">
                  <span>Walk Time: <strong class="text-[#FFB800]">{{ route.estimatedTimeMin }} min</strong></span>
                  <span>Dist: <strong class="text-[#F27D26]">{{ route.totalDistanceMeters }}m</strong></span>
                </div>
                <div class="flex items-center gap-1 text-[11px]">
                  <span class="text-[#666]">Accessible:</span>
                  @if (route.isFullyAccessible) {
                    <span class="text-[#00FF44] font-bold flex items-center gap-1">
                      <span class="material-icons-outlined text-xs">accessible</span> YES (Elevators/Ramps)
                    </span>
                  } @else {
                    <span class="text-[#FFB800] font-bold">NO (Contains Stairs)</span>
                  }
                </div>

                <div class="pt-2 border-t border-[#222] space-y-1 text-[11px]">
                  <span class="text-[#666] block text-[10px] uppercase tracking-wider">Graph Path Steps:</span>
                  @for (node of route.pathNodes; track node.id; let last = $last) {
                    <div class="flex items-center gap-1.5 text-[#AAA]">
                      <span class="material-icons-outlined text-xs text-[#F27D26]">place</span>
                      <span>{{ node.name }}</span>
                      @if (!last) {
                        <span class="text-[#555]">→</span>
                      }
                    </div>
                  }
                </div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `
})
export class OperatorDashboardComponent {
  readonly stateService = inject(StationStateService);
  readonly i18n = inject(I18nService);

  readonly selectedTrain = signal<TrainService | null>(null);
  readonly wayfindingMode = signal<'FASTEST' | 'ACCESSIBLE' | 'LEAST_CROWDED' | 'LUGGAGE'>('ACCESSIBLE');

  getPlatformNum(platformId: string): string {
    const p = this.stateService.platforms().find(plat => plat.id === platformId);
    return p ? p.number : '?';
  }

  getTrainStatusClass(status: string): string {
    switch (status) {
      case 'BOARDING': case 'AT PLATFORM': return 'text-[#F27D26]';
      case 'APPROACHING': case 'ARRIVING': return 'text-[#00FF44]';
      case 'DELAYED': return 'text-[#FFB800]';
      case 'CANCELLED': return 'text-[#FF4444]';
      default: return 'text-[#E0E0E0]';
    }
  }

  getRecommendedPlatforms(train: TrainService): Platform[] {
    const all = this.stateService.platforms();
    return all.filter(p => p.id !== train.platformId && p.status === 'AVAILABLE');
  }

  assignPlatform(train: TrainService, newPlatformId: string) {
    this.stateService.trains.update(trains => {
      return trains.map(t => {
        if (t.id === train.id) {
          return { ...t, platformId: newPlatformId };
        }
        return t;
      });
    });

    this.selectedTrain.set(null);
  }

  resolveConflict(conflict: ScheduleConflict) {
    const targetPlat = conflict.proposedResolutionPlatformId;
    if (targetPlat) {
      this.stateService.trains.update(trains => {
        return trains.map(t => {
          if (t.id === conflict.trainBId) {
            return { ...t, platformId: targetPlat };
          }
          return t;
        });
      });
    }
  }

  activeRoute() {
    return this.stateService.calculateWayfindingRoute('NODE_ENT_NORTH', 'NODE_PLAT_4', this.wayfindingMode());
  }
}

