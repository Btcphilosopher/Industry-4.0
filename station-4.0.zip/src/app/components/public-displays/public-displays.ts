import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StationStateService } from '../../services/station-state.service';
import { I18nService } from '../../services/i18n.service';

@Component({
  selector: 'app-public-displays',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full w-full bg-[#050505] p-5 overflow-y-auto font-sans text-[#E0E0E0] space-y-6">
      <!-- Top Title & Display Selector -->
      <div class="flex items-center justify-between border-b border-[#222] pb-3">
        <div>
          <h1 class="text-base font-extrabold text-white flex items-center gap-2">
            <span class="material-icons-outlined text-[#F27D26]">tv</span>
            <span>Digital Passenger Information System (PIS Display Engine)</span>
          </h1>
          <p class="text-xs text-[#888] font-mono">Public Station Departure Boards, Platform Information Displays & Dynamic Wayfinding Screens</p>
        </div>

        <!-- Display Screen Switcher Tabs -->
        <div class="flex items-center bg-[#0A0A0A] p-1 rounded border border-[#222] text-xs font-mono font-semibold">
          <button 
            (click)="activeTab.set('MAIN_DEPARTURES')"
            [class]="activeTab() === 'MAIN_DEPARTURES' ? 'bg-[#F27D26]/20 text-[#F27D26] border-[#F27D26]/50' : 'text-[#888] hover:text-white'"
            class="px-3 py-1.5 rounded border border-transparent transition-colors flex items-center gap-1.5">
            <span class="material-icons-outlined text-sm">table_chart</span> Main Departure Board
          </button>
          <button 
            (click)="activeTab.set('PLATFORM_DISPLAY')"
            [class]="activeTab() === 'PLATFORM_DISPLAY' ? 'bg-[#F27D26]/20 text-[#F27D26] border-[#F27D26]/50' : 'text-[#888] hover:text-white'"
            class="px-3 py-1.5 rounded border border-transparent transition-colors flex items-center gap-1.5">
            <span class="material-icons-outlined text-sm">filter_1</span> Platform Display
          </button>
          <button 
            (click)="activeTab.set('WAYFINDING_SCREEN')"
            [class]="activeTab() === 'WAYFINDING_SCREEN' ? 'bg-[#F27D26]/20 text-[#F27D26] border-[#F27D26]/50' : 'text-[#888] hover:text-white'"
            class="px-3 py-1.5 rounded border border-transparent transition-colors flex items-center gap-1.5">
            <span class="material-icons-outlined text-sm">map</span> Wayfinding Screen
          </button>
        </div>
      </div>

      <!-- 1. MAIN DEPARTURE BOARD VIEW -->
      @if (activeTab() === 'MAIN_DEPARTURES') {
        <div class="bg-[#000] border-2 border-[#222] rounded p-6 shadow-2xl font-mono space-y-4">
          <!-- Board Header -->
          <div class="flex items-center justify-between border-b border-[#F27D26]/40 pb-3 text-[#F27D26]">
            <div class="flex items-center gap-3">
              <span class="text-xl font-extrabold tracking-widest uppercase">DEPARTURES / 發車資訊</span>
            </div>
            <div class="text-xl font-bold">{{ currentTime() }}</div>
          </div>

          <!-- Table Header -->
          <div class="grid grid-cols-12 text-xs font-bold text-[#666] border-b border-[#111] pb-2 uppercase tracking-wider">
            <div class="col-span-2">TIME</div>
            <div class="col-span-4">DESTINATION</div>
            <div class="col-span-2">SERVICE</div>
            <div class="col-span-2">PLATFORM</div>
            <div class="col-span-2 text-right">STATUS</div>
          </div>

          <!-- Table Rows -->
          <div class="space-y-3">
            @for (train of stateService.trains(); track train.id) {
              <div class="grid grid-cols-12 text-sm md:text-base font-bold items-center py-2 border-b border-[#111] hover:bg-[#0A0A0A] transition-colors">
                <div class="col-span-2 text-[#FFB800] text-lg">{{ train.estimatedDeparture }}</div>
                <div class="col-span-4 text-white uppercase tracking-wide truncate pr-2">
                  {{ train.destination }}
                  @if (train.viaStations && train.viaStations.length > 0) {
                    <span class="text-xs text-[#888] block font-normal">via {{ train.viaStations.join(', ') }}</span>
                  }
                </div>
                <div class="col-span-2 text-[#F27D26] text-sm">{{ train.trainNumber }}</div>
                <div class="col-span-2 text-lg">
                  <span class="px-2 py-0.5 rounded bg-[#F27D26]/10 border border-[#F27D26]/40 text-[#F27D26] font-extrabold">
                    PLAT {{ getPlatformNum(train.platformId) }}
                  </span>
                </div>
                <div class="col-span-2 text-right">
                  <span [class]="getDisplayStatusClass(train.status)" class="text-sm uppercase tracking-wider font-extrabold">
                    {{ train.status }}
                  </span>
                </div>
              </div>
            }
          </div>

          <!-- Ticker Message Footer -->
          <div class="mt-4 pt-3 border-t border-[#F27D26]/40 flex items-center justify-between text-xs text-[#F27D26] overflow-hidden">
            <span class="animate-pulse flex items-center gap-2">
              <span class="material-icons-outlined text-sm">info</span>
              <span>WELCOME TO GRAND CENTRAL INTERCHANGE — PLEASE PREPARE TICKET BEFORE GATE ACCESS</span>
            </span>
            <span class="text-[10px] text-[#666]">PIS DISPLAY ID: GCI-DISP-MAIN-01</span>
          </div>
        </div>
      }

      <!-- 2. PLATFORM DISPLAY VIEW -->
      @if (activeTab() === 'PLATFORM_DISPLAY') {
        <div class="bg-[#000] border-2 border-[#222] rounded p-6 shadow-2xl font-mono space-y-6">
          <div class="flex justify-between items-center border-b border-[#F27D26]/40 pb-4">
            <div class="flex items-center gap-4">
              <span class="text-3xl font-extrabold bg-[#F27D26] text-black px-4 py-1 rounded">PLATFORM 4</span>
              <div>
                <span class="text-xl font-extrabold text-[#F27D26]">NEXT DEPARTURE — 08:48</span>
                <p class="text-xs text-[#888]">Intercity Express Service IC-842</p>
              </div>
            </div>
            <span class="text-xl text-[#00FF44] font-bold">BOARDING NOW</span>
          </div>

          <!-- Carriage Layout & Occupancy Diagram -->
          <div class="space-y-2">
            <span class="text-xs text-[#888] font-mono font-bold uppercase tracking-wider block">Carriage Occupancy & Facilities Diagram:</span>
            <div class="grid grid-cols-8 gap-2">
              @for (car of [1,2,3,4,5,6,7,8]; track car) {
                <div class="bg-[#080808] border border-[#222] rounded p-3 text-center space-y-1">
                  <span class="text-xs text-[#888] block font-bold">CAR {{ car }}</span>
                  <span [class]="car <= 2 ? 'text-[#FFB800]' : 'text-[#F27D26]'" class="text-[10px] font-bold block">
                    {{ car <= 2 ? '1ST CLASS' : 'STD CLASS' }}
                  </span>
                  <div class="w-full bg-[#111] h-2 rounded overflow-hidden mt-1">
                    <div [style.width.%]="car % 2 === 0 ? 88 : 45" [class]="car % 2 === 0 ? 'bg-[#FFB800]' : 'bg-[#00FF44]'" class="h-full"></div>
                  </div>
                  <span class="text-[9px] text-[#666] block">{{ car % 2 === 0 ? 'Busy (88%)' : 'Seats Avail' }}</span>
                </div>
              }
            </div>
          </div>
        </div>
      }

      <!-- 3. WAYFINDING SCREEN -->
      @if (activeTab() === 'WAYFINDING_SCREEN') {
        <div class="bg-[#080808] border border-[#222] rounded p-6 shadow-2xl space-y-4 font-mono">
          <div class="flex justify-between items-center border-b border-[#222] pb-3">
            <div class="flex items-center gap-3">
              <span class="material-icons-outlined text-2xl text-[#00FF44]">location_on</span>
              <div>
                <h2 class="text-base font-bold text-white">CONCOURSE WAYFINDING DISPLAY — YOU ARE HERE</h2>
                <p class="text-xs text-[#888]">Dynamic route updating based on live asset statuses</p>
              </div>
            </div>
          </div>

          <div class="grid grid-cols-3 gap-4">
            <div class="bg-[#111] p-4 rounded border border-[#222] space-y-2">
              <span class="text-xs font-bold text-[#F27D26] block uppercase">Platforms 1 - 3 (High Speed)</span>
              <p class="text-xs text-[#E0E0E0]">Turn left at North Gate Line → Take Elevator A or Escalator 1 down to Level B1</p>
              <span class="inline-block px-2 py-0.5 rounded bg-[#00FF44]/20 text-[#00FF44] text-[10px]">FULLY ACCESSIBLE</span>
            </div>

            <div class="bg-[#111] p-4 rounded border border-[#FFB800]/40 space-y-2">
              <span class="text-xs font-bold text-[#FFB800] block uppercase">Platform 4 (Lift Outage Alert)</span>
              <p class="text-xs text-[#E0E0E0]">Lift AST_LIFT_02 down to Platform 4 is closed. Wheelchair users please reroute via Platform 3 ramp connector.</p>
              <span class="inline-block px-2 py-0.5 rounded bg-[#FFB800]/20 text-[#FFB800] text-[10px]">ACCESSIBLE REROUTE ACTIVE</span>
            </div>

            <div class="bg-[#111] p-4 rounded border border-[#222] space-y-2">
              <span class="text-xs font-bold text-[#F27D26] block uppercase">Platforms 5 - 8 (Commuter)</span>
              <p class="text-xs text-[#E0E0E0]">Turn right at South Gate Line → Direct escalator access to Level B1</p>
              <span class="inline-block px-2 py-0.5 rounded bg-[#00FF44]/20 text-[#00FF44] text-[10px]">NORMAL FLOW</span>
            </div>
          </div>
        </div>
      }
    </div>
  `
})
export class PublicDisplaysComponent {
  readonly stateService = inject(StationStateService);
  readonly i18n = inject(I18nService);

  readonly activeTab = signal<'MAIN_DEPARTURES' | 'PLATFORM_DISPLAY' | 'WAYFINDING_SCREEN'>('MAIN_DEPARTURES');
  readonly currentTime = signal<string>(new Date().toLocaleTimeString());

  constructor() {
    setInterval(() => {
      this.currentTime.set(new Date().toLocaleTimeString());
    }, 1000);
  }

  getPlatformNum(platformId: string): string {
    const p = this.stateService.platforms().find(plat => plat.id === platformId);
    return p ? p.number : '?';
  }

  getDisplayStatusClass(status: string): string {
    switch (status) {
      case 'BOARDING': return 'text-[#F27D26] animate-pulse';
      case 'ON TIME': case 'APPROACHING': return 'text-[#00FF44]';
      case 'DELAYED': return 'text-[#FFB800]';
      case 'CANCELLED': return 'text-[#FF4444]';
      default: return 'text-[#E0E0E0]';
    }
  }
}
