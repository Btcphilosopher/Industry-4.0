import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StationStateService } from '../../services/station-state.service';
import { I18nService } from '../../services/i18n.service';
import { DigitalTwin3dComponent } from '../3d-digital-twin/digital-twin-3d';

@Component({
  selector: 'app-control-room',
  imports: [CommonModule, DigitalTwin3dComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full w-full bg-[#050505] p-3 flex flex-col gap-3 overflow-hidden select-none font-sans text-[#E0E0E0]">
      <!-- Control Room Header Banner -->
      <div class="flex items-center justify-between bg-[#0A0A0A] border border-[#222] rounded px-4 py-2.5 shadow-xl">
        <div class="flex items-center gap-3">
          <div class="w-3 h-3 rounded-full bg-[#FF4444] animate-ping"></div>
          <div>
            <h1 class="text-sm font-extrabold tracking-widest uppercase text-white flex items-center gap-2">
              <span class="text-[#F27D26]">STATION 4.0</span>
              <span class="text-[9px] px-2 py-0.5 rounded bg-[#FF4444]/15 text-[#FF4444] border border-[#FF4444]/30 font-mono font-bold tracking-widest">LIVE CONTROL ROOM WALL</span>
            </h1>
            <p class="text-[10px] text-[#888] font-mono">Integrated Operations Command Center — {{ stateService.stationConfig().name }}</p>
          </div>
        </div>

        <!-- Live Clock & Status Metrics -->
        <div class="flex items-center gap-6 font-mono text-xs">
          <div class="flex items-center gap-2">
            <span class="text-[#666]">PIS SYSTEM:</span>
            <span class="text-[#00FF44] font-bold flex items-center gap-1">
              <span class="w-2 h-2 rounded-full bg-[#00FF44] shadow-[0_0_6px_#00FF44]"></span> SYNCED
            </span>
          </div>
          <div class="flex items-center gap-2">
            <span class="text-[#666]">SAFETY INTERLOCK:</span>
            <span class="text-[#F27D26] font-bold">ISOLATED (ADVISORY)</span>
          </div>
          <div class="bg-[#111] border border-[#222] px-3 py-1 rounded text-[#FFB800] font-bold text-sm tracking-widest">
            {{ currentTime() }}
          </div>
        </div>
      </div>

      <!-- Main Video Wall Grid -->
      <div class="flex-1 grid grid-cols-12 gap-3 min-h-0">
        <!-- Left Panel: Train Board & Platform Matrix (3 cols) -->
        <div class="col-span-3 flex flex-col gap-3 min-h-0">
          <!-- Active Trains Monitor -->
          <div class="flex-1 bg-[#080808] border border-[#222] rounded p-3 flex flex-col min-h-0 shadow-lg">
            <div class="flex items-center justify-between pb-2 border-b border-[#222] mb-2">
              <span class="text-[10px] font-bold text-[#F27D26] uppercase tracking-widest flex items-center gap-1.5">
                <span class="material-icons-outlined text-sm">train</span> Live Schedule
              </span>
              <span class="text-[10px] font-mono text-[#666]">{{ stateService.trains().length }} active</span>
            </div>

            <div class="flex-1 overflow-y-auto space-y-2 pr-1">
              @for (train of stateService.trains(); track train.id) {
                <div class="bg-[#111] border border-[#222] rounded p-2 font-mono text-[11px] hover:border-[#333] transition-colors">
                  <div class="flex items-center justify-between">
                    <span class="font-bold text-[#F27D26]">{{ train.trainNumber }}</span>
                    <span class="text-[10px] px-1.5 py-0.5 rounded bg-[#0A0A0A] border border-[#222] text-[#AAA]">
                      P{{ getPlatformNum(train.platformId) }}
                    </span>
                  </div>
                  <div class="flex justify-between text-[#888] text-[10px] mt-1">
                    <span class="truncate max-w-[120px]">{{ train.destination }}</span>
                    <span class="text-[#E0E0E0]">{{ train.estimatedDeparture }}</span>
                  </div>
                  <div class="flex items-center justify-between mt-1.5 pt-1 border-t border-[#1A1A1A]">
                    <span [class]="getTrainStatusClass(train.status)" class="text-[10px] font-bold">
                      {{ train.status }}
                    </span>
                    <span class="text-[10px] text-[#666]">{{ train.occupancyPercentage }}% pax</span>
                  </div>
                </div>
              }
            </div>
          </div>

          <!-- Platform State Matrix -->
          <div class="h-48 bg-[#080808] border border-[#222] rounded p-3 flex flex-col shadow-lg">
            <div class="flex items-center justify-between pb-2 border-b border-[#222] mb-2">
              <span class="text-[10px] font-bold text-[#E0E0E0] uppercase tracking-widest flex items-center gap-1.5">
                <span class="material-icons-outlined text-sm">view_week</span> Platform States
              </span>
            </div>
            <div class="grid grid-cols-2 gap-2 flex-1 overflow-y-auto font-mono text-[10px]">
              @for (p of stateService.platforms(); track p.id) {
                <div [class]="getPlatformBgClass(p.status)" class="p-2 rounded border flex flex-col justify-between">
                  <div class="flex justify-between items-center font-bold">
                    <span>Plat {{ p.number }}</span>
                    <span class="text-[9px]">{{ p.status }}</span>
                  </div>
                  <div class="text-[9px] text-[#888] mt-1">
                    Occupancy: {{ p.currentOccupancy }} pax
                  </div>
                </div>
              }
            </div>
          </div>
        </div>

        <!-- Center Panel: Large 3D Digital Twin Viewport (6 cols) -->
        <div class="col-span-6 bg-[#050505] border border-[#222] rounded overflow-hidden relative flex flex-col shadow-2xl">
          <app-digital-twin-3d class="w-full h-full flex-1"></app-digital-twin-3d>
        </div>

        <!-- Right Panel: Crowding, Bottleneck, Assets & Disruption Alerts (3 cols) -->
        <div class="col-span-3 flex flex-col gap-3 min-h-0">
          <!-- Active Bottleneck Alert -->
          <div class="bg-[#1A1005] border border-[#422C11] rounded p-3 text-xs font-mono shadow-lg">
            <div class="flex items-center gap-2 text-[#F27D26] font-bold mb-1">
              <span class="material-icons-outlined text-base animate-bounce">warning</span>
              <span class="uppercase tracking-widest text-[10px]">BOTTLENECK DETECTED</span>
            </div>
            @if (stateService.stationBottleneck().zone; as bZone) {
              <div class="text-[#D4B28C] mt-1 space-y-1 text-[11px]">
                <p><span class="text-[#888]">Zone:</span> <span class="font-bold text-white">{{ bZone.name }}</span></p>
                <div class="flex justify-between text-[10px]">
                  <span>Utilisation: <span class="text-[#FF4444] font-bold">{{ stateService.stationBottleneck().utilisationPercent }}%</span></span>
                  <span>Headroom: <span class="text-[#00FF44]">{{ stateService.stationBottleneck().headroomPercent }}%</span></span>
                </div>
              </div>
            }
          </div>

          <!-- Passenger Crowding Radar -->
          <div class="flex-1 bg-[#080808] border border-[#222] rounded p-3 flex flex-col min-h-0 shadow-lg">
            <div class="flex items-center justify-between pb-2 border-b border-[#222] mb-2">
              <span class="text-[10px] font-bold text-[#E0E0E0] uppercase tracking-widest flex items-center gap-1.5">
                <span class="material-icons-outlined text-sm">groups</span> Crowd Densities
              </span>
            </div>
            <div class="flex-1 overflow-y-auto space-y-2 font-mono text-[11px] pr-1">
              @for (zone of stateService.passengerZones(); track zone.id) {
                <div class="bg-[#111] border border-[#222] rounded p-2">
                  <div class="flex justify-between font-medium">
                    <span class="text-[#E0E0E0] text-[10px] truncate max-w-[130px]">{{ zone.name }}</span>
                    <span [class]="getCrowdLevelClass(zone.level)" class="text-[10px] font-bold">{{ zone.level }}</span>
                  </div>
                  <!-- Density Progress Bar -->
                  <div class="w-full bg-[#222] h-1.5 rounded overflow-hidden mt-1.5">
                    <div 
                      [style.width.%]="getZonePercent(zone)"
                      [class]="getZoneBarClass(zone.level)"
                      class="h-full transition-all duration-500">
                    </div>
                  </div>
                  <div class="flex justify-between text-[9px] text-[#666] mt-1">
                    <span>{{ zone.currentPeople }} / {{ zone.capacity }} pax</span>
                    <span>{{ zone.densityPeoplePerSqm }} p/m²</span>
                  </div>
                </div>
              }
            </div>
          </div>

          <!-- Asset Health Matrix -->
          <div class="h-44 bg-[#080808] border border-[#222] rounded p-3 flex flex-col shadow-lg">
            <div class="flex items-center justify-between pb-2 border-b border-[#222] mb-2">
              <span class="text-[10px] font-bold text-[#FFB800] uppercase tracking-widest flex items-center gap-1.5">
                <span class="material-icons-outlined text-sm">construction</span> Asset Health
              </span>
            </div>
            <div class="flex-1 overflow-y-auto space-y-1.5 font-mono text-[10px] pr-1">
              @for (asset of stateService.assets(); track asset.id) {
                <div class="flex items-center justify-between bg-[#111] p-1.5 rounded border border-[#222]">
                  <span class="text-[#AAA] truncate max-w-[140px]">{{ asset.name }}</span>
                  <span [class]="getAssetStatusClass(asset.status)" class="font-bold text-[9px]">
                    {{ asset.status }}
                  </span>
                </div>
              }
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ControlRoomComponent {
  readonly stateService = inject(StationStateService);
  readonly i18n = inject(I18nService);

  readonly currentTime = signal<string>(new Date().toLocaleTimeString());

  constructor() {
    setInterval(() => {
      this.currentTime.set(new Date().toLocaleTimeString());
    }, 1000);
  }

  getPlatformNum(platformId: string): string {
    const p = this.stateService.platforms().find(plat => plat.id === platformId);
    return p ? p.number : '?';
  }

  getTrainStatusClass(status: string): string {
    switch (status) {
      case 'BOARDING': case 'AT PLATFORM': return 'text-[#F27D26]';
      case 'APPROACHING': case 'ARRIVING': return 'text-[#00FF44]';
      case 'DELAYED': return 'text-[#FFB800]';
      case 'CANCELLED': return 'text-[#FF4444]';
      default: return 'text-[#E0E0E0]';
    }
  }

  getPlatformBgClass(status: string): string {
    switch (status) {
      case 'AVAILABLE': return 'bg-[#0A0A0A] border-[#222] text-[#AAA]';
      case 'BOARDING': case 'OCCUPIED': return 'bg-[#F27D26]/15 border-[#F27D26]/40 text-[#F27D26]';
      case 'CLOSED': case 'MAINTENANCE': return 'bg-[#FF4444]/15 border-[#FF4444]/40 text-[#FF4444]';
      default: return 'bg-[#0A0A0A] border-[#222] text-[#AAA]';
    }
  }

  getCrowdLevelClass(level: string): string {
    switch (level) {
      case 'NORMAL': return 'text-[#00FF44]';
      case 'BUSY': return 'text-[#F27D26]';
      case 'CROWDED': return 'text-[#FFB800]';
      case 'SEVERE': return 'text-[#FF4444]';
      default: return 'text-[#AAA]';
    }
  }

  getZoneBarClass(level: string): string {
    switch (level) {
      case 'NORMAL': return 'bg-[#00FF44]';
      case 'BUSY': return 'bg-[#F27D26]';
      case 'CROWDED': return 'bg-[#FFB800]';
      case 'SEVERE': return 'bg-[#FF4444]';
      default: return 'bg-[#555]';
    }
  }

  getZonePercent(zone: { currentPeople: number; capacity: number }): number {
    return Math.min(100, Math.round((zone.currentPeople / zone.capacity) * 100));
  }

  getAssetStatusClass(status: string): string {
    switch (status) {
      case 'OPERATIONAL': return 'text-[#00FF44]';
      case 'DEGRADED': return 'text-[#FFB800]';
      case 'FAULT': return 'text-[#FF4444]';
      default: return 'text-[#666]';
    }
  }
}
