import {
  Component,
  ElementRef,
  ViewChild,
  AfterViewInit,
  OnDestroy,
  ChangeDetectionStrategy,
  inject,
  signal
} from '@angular/core';
import { CommonModule } from '@angular/common';
import * as THREE from 'three';
import { StationStateService } from '../../services/station-state.service';
import { I18nService } from '../../services/i18n.service';

@Component({
  selector: 'app-digital-twin-3d',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-full bg-[#050505] overflow-hidden font-sans">
      <!-- 3D Canvas Viewport -->
      <div #rendererContainer class="w-full h-full cursor-grab active:cursor-grabbing"></div>

      <!-- Live 3D Viewport Controls & Information Overlay -->
      <div class="absolute top-4 left-4 z-10 flex flex-col gap-2">
        <div class="bg-[#0A0A0A] border border-[#222] rounded p-3 shadow-2xl font-mono text-xs text-[#E0E0E0]">
          <div class="flex items-center gap-2 mb-1">
            <span class="w-2.5 h-2.5 rounded-full bg-[#00FF44] shadow-[0_0_8px_#00FF44]"></span>
            <span class="font-bold text-white uppercase tracking-widest text-[11px]">3D DIGITAL TWIN VIEWPORT</span>
          </div>
          <p class="text-[10px] text-[#888]">{{ stateService.stationConfig().name }} ({{ stateService.stationConfig().code }})</p>
        </div>

        <!-- Render Layer Filter Toggles -->
        <div class="bg-[#0A0A0A] border border-[#222] rounded p-2 shadow-2xl flex flex-col gap-1 text-[11px] font-semibold text-[#888]">
          <button 
            (click)="toggleLayer('platforms')"
            [class]="showPlatforms() ? 'bg-[#F27D26]/20 text-[#F27D26] border-[#F27D26]/40' : 'text-[#888] border-transparent hover:text-white hover:bg-[#111]'"
            class="px-2.5 py-1 rounded border text-left flex items-center justify-between gap-2 transition-colors uppercase tracking-wider text-[10px]">
            <span>Platforms & Sub-surface</span>
            <span class="material-icons-outlined text-xs">{{ showPlatforms() ? 'visibility' : 'visibility_off' }}</span>
          </button>

          <button 
            (click)="toggleLayer('trains')"
            [class]="showTrains() ? 'bg-[#F27D26]/20 text-[#F27D26] border-[#F27D26]/40' : 'text-[#888] border-transparent hover:text-white hover:bg-[#111]'"
            class="px-2.5 py-1 rounded border text-left flex items-center justify-between gap-2 transition-colors uppercase tracking-wider text-[10px]">
            <span>Live Trains & Tracks</span>
            <span class="material-icons-outlined text-xs">{{ showTrains() ? 'visibility' : 'visibility_off' }}</span>
          </button>

          <button 
            (click)="toggleLayer('passengers')"
            [class]="showPassengers() ? 'bg-[#F27D26]/20 text-[#F27D26] border-[#F27D26]/40' : 'text-[#888] border-transparent hover:text-white hover:bg-[#111]'"
            class="px-2.5 py-1 rounded border text-left flex items-center justify-between gap-2 transition-colors uppercase tracking-wider text-[10px]">
            <span>Passenger Heat Density</span>
            <span class="material-icons-outlined text-xs">{{ showPassengers() ? 'visibility' : 'visibility_off' }}</span>
          </button>

          <button 
            (click)="toggleLayer('assets')"
            [class]="showAssets() ? 'bg-[#F27D26]/20 text-[#F27D26] border-[#F27D26]/40' : 'text-[#888] border-transparent hover:text-white hover:bg-[#111]'"
            class="px-2.5 py-1 rounded border text-left flex items-center justify-between gap-2 transition-colors uppercase tracking-wider text-[10px]">
            <span>Lifts, Escalators & Gates</span>
            <span class="material-icons-outlined text-xs">{{ showAssets() ? 'visibility' : 'visibility_off' }}</span>
          </button>
        </div>
      </div>

      <!-- Selected Entity Information Card -->
      @if (selectedEntity(); as entity) {
        <div class="absolute bottom-6 right-6 z-10 w-80 bg-[#0A0A0A] border border-[#F27D26]/50 rounded p-4 shadow-2xl font-mono text-xs text-[#E0E0E0] animate-fadeIn">
          <div class="flex items-center justify-between border-b border-[#222] pb-2 mb-2">
            <span class="font-extrabold text-[#F27D26] uppercase tracking-widest text-[11px]">{{ entity.type }} DETAILS</span>
            <button (click)="selectedEntity.set(null)" class="text-[#888] hover:text-white">
              <span class="material-icons-outlined text-sm">close</span>
            </button>
          </div>

          <div class="space-y-1 text-[11px]">
            <p><span class="text-[#888]">ID / Code:</span> <strong class="text-white">{{ entity.id }}</strong></p>
            <p><span class="text-[#888]">Name:</span> <strong class="text-[#FFB800]">{{ entity.name }}</strong></p>
            <p><span class="text-[#888]">Status:</span> <span class="font-bold text-[#00FF44]">{{ entity.status }}</span></p>

            @if (entity.details) {
              <div class="mt-2 pt-2 border-t border-[#222] text-[10px] text-[#AAA] space-y-1">
                @for (detail of entity.details; track detail.label) {
                  <div class="flex justify-between">
                    <span class="text-[#888]">{{ detail.label }}:</span>
                    <span class="font-bold text-[#E0E0E0]">{{ detail.value }}</span>
                  </div>
                }
              </div>
            }
          </div>
        </div>
      }
    </div>
  `
})
export class DigitalTwin3dComponent implements AfterViewInit, OnDestroy {
  @ViewChild('rendererContainer', { static: true }) containerRef!: ElementRef<HTMLDivElement>;

  readonly stateService = inject(StationStateService);
  readonly i18n = inject(I18nService);

  readonly showPlatforms = signal<boolean>(true);
  readonly showTrains = signal<boolean>(true);
  readonly showPassengers = signal<boolean>(true);
  readonly showAssets = signal<boolean>(true);

  readonly selectedEntity = signal<{
    type: string;
    id: string;
    name: string;
    status: string;
    details?: { label: string; value: string }[];
  } | null>(null);

  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animFrameId: number | null = null;

  private platformsGroup = new THREE.Group();
  private trainsGroup = new THREE.Group();
  private passengersGroup = new THREE.Group();
  private assetsGroup = new THREE.Group();

  private raycaster = new THREE.Raycaster();
  private mouse = new THREE.Vector2();

  ngAfterViewInit(): void {
    this.initThree();
    this.buildStationMesh();
    this.animate();
  }

  ngOnDestroy(): void {
    if (this.animFrameId !== null) {
      cancelAnimationFrame(this.animFrameId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  private initThree() {
    const container = this.containerRef.nativeElement;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 600;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x030712); // slate-950
    this.scene.fog = new THREE.FogExp2(0x030712, 0.008);

    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    this.camera.position.set(60, 45, 60);
    this.camera.lookAt(0, 0, 0);

    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    container.appendChild(this.renderer.domElement);

    // Ambient & Directional Lights
    const ambient = new THREE.AmbientLight(0xffffff, 0.7);
    this.scene.add(ambient);

    const dirLight = new THREE.DirectionalLight(0x38bdf8, 1.2);
    dirLight.position.set(50, 80, 50);
    dirLight.castShadow = true;
    this.scene.add(dirLight);

    // Add Groups to Scene
    this.scene.add(this.platformsGroup);
    this.scene.add(this.trainsGroup);
    this.scene.add(this.passengersGroup);
    this.scene.add(this.assetsGroup);

    // Event listeners
    window.addEventListener('resize', this.onWindowResize.bind(this));
    container.addEventListener('click', this.onCanvasClick.bind(this));
  }

  private buildStationMesh() {
    // 1. Concourse Floor Grid & Platform Structures
    const gridHelper = new THREE.GridHelper(120, 30, 0x0284c7, 0x1e293b);
    gridHelper.position.y = -0.1;
    this.scene.add(gridHelper);

    // Build 8 Parallel Platforms
    for (let i = 0; i < 8; i++) {
      const zPos = (i - 3.5) * 12;
      const platGeo = new THREE.BoxGeometry(70, 1.2, 5);
      const platMat = new THREE.MeshStandardMaterial({
        color: i === 3 ? 0x0284c7 : 0x1e293b,
        roughness: 0.4,
        metalness: 0.6
      });
      const platMesh = new THREE.Mesh(platGeo, platMat);
      platMesh.position.set(0, 0.6, zPos);
      platMesh.userData = {
        type: 'PLATFORM',
        id: `PLAT_0${i + 1}`,
        name: `Platform ${i + 1}`,
        status: i === 3 ? 'BOARDING' : 'AVAILABLE'
      };
      this.platformsGroup.add(platMesh);

      // Track rails on both sides
      const railGeo = new THREE.BoxGeometry(80, 0.3, 0.4);
      const railMat = new THREE.MeshStandardMaterial({ color: 0x64748b, metalness: 0.9 });
      const rail1 = new THREE.Mesh(railGeo, railMat);
      rail1.position.set(0, 0.15, zPos - 3.2);
      this.platformsGroup.add(rail1);
    }

    // 2. Trains
    this.renderTrainsMesh();

    // 3. Passenger Density Particle System
    this.renderPassengerParticles();
  }

  private renderTrainsMesh() {
    this.trainsGroup.clear();
    const trainList = this.stateService.trains();

    trainList.forEach((t) => {
      const pNum = Number(t.platformId.replace('PLAT_0', '')) || 1;
      const zPos = (pNum - 4.5) * 12 - 3.2;

      const trainGeo = new THREE.BoxGeometry(28, 2.8, 2.2);
      const trainMat = new THREE.MeshStandardMaterial({
        color: t.status === 'BOARDING' ? 0x06b6d4 : (t.status === 'DELAYED' ? 0xf59e0b : 0x10b981),
        roughness: 0.3,
        metalness: 0.8
      });

      const trainMesh = new THREE.Mesh(trainGeo, trainMat);
      trainMesh.position.set(-10, 1.8, zPos);
      trainMesh.userData = {
        type: 'TRAIN',
        id: t.id,
        name: `${t.trainNumber} (${t.origin} → ${t.destination})`,
        status: t.status,
        details: [
          { label: 'Platform', value: `Platform ${pNum}` },
          { label: 'Occupancy', value: `${t.occupancyPercentage}%` },
          { label: 'Passengers', value: `${t.passengerCount} pax` }
        ]
      };
      this.trainsGroup.add(trainMesh);
    });
  }

  private renderPassengerParticles() {
    this.passengersGroup.clear();
    const particleCount = 400;
    const geometry = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 60;
      positions[i * 3 + 1] = 1.4;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 80;

      colors[i * 3] = 0.1;
      colors[i * 3 + 1] = 0.8;
      colors[i * 3 + 2] = 0.6;
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const material = new THREE.PointsMaterial({
      size: 0.6,
      vertexColors: true,
      transparent: true,
      opacity: 0.8
    });

    const particles = new THREE.Points(geometry, material);
    this.passengersGroup.add(particles);
  }

  toggleLayer(layer: 'platforms' | 'trains' | 'passengers' | 'assets') {
    switch (layer) {
      case 'platforms':
        this.showPlatforms.update(v => !v);
        this.platformsGroup.visible = this.showPlatforms();
        break;
      case 'trains':
        this.showTrains.update(v => !v);
        this.trainsGroup.visible = this.showTrains();
        break;
      case 'passengers':
        this.showPassengers.update(v => !v);
        this.passengersGroup.visible = this.showPassengers();
        break;
      case 'assets':
        this.showAssets.update(v => !v);
        this.assetsGroup.visible = this.showAssets();
        break;
    }
  }

  private animate() {
    this.animFrameId = requestAnimationFrame(() => this.animate());

    // Slow orbital camera rotation
    const time = Date.now() * 0.00015;
    this.camera.position.x = Math.cos(time) * 65;
    this.camera.position.z = Math.sin(time) * 65;
    this.camera.lookAt(0, 0, 0);

    this.renderer.render(this.scene, this.camera);
  }

  private onWindowResize() {
    const container = this.containerRef.nativeElement;
    if (!container) return;
    const width = container.clientWidth;
    const height = container.clientHeight;

    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  private onCanvasClick(event: MouseEvent) {
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(this.mouse, this.camera);
    const intersects = this.raycaster.intersectObjects(this.scene.children, true);

    if (intersects.length > 0) {
      const hit = intersects[0].object;
      if (hit.userData && hit.userData['type']) {
        this.selectedEntity.set({
          type: hit.userData['type'],
          id: hit.userData['id'],
          name: hit.userData['name'],
          status: hit.userData['status'],
          details: hit.userData['details']
        });
      }
    }
  }
}
