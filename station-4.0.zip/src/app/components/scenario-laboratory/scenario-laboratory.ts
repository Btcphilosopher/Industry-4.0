import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { StationStateService } from '../../services/station-state.service';
import { I18nService } from '../../services/i18n.service';

@Component({
  selector: 'app-scenario-laboratory',
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full w-full bg-[#050505] p-5 overflow-y-auto font-sans text-[#E0E0E0] space-y-5">
      <!-- Title Bar -->
      <div class="flex items-center justify-between border-b border-[#222] pb-3">
        <div>
          <h1 class="text-base font-extrabold text-white flex items-center gap-2">
            <span class="material-icons-outlined text-[#F27D26]">science</span>
            <span>Scenario Laboratory & Before / After Simulation Engine</span>
          </h1>
          <p class="text-xs text-[#888] font-mono">Clone current station digital twin, modify operational parameters, and simulate capacity impacts</p>
        </div>

        <button 
          (click)="runNewScenario()"
          class="px-4 py-2 rounded bg-[#F27D26] hover:bg-[#d96a19] text-black font-bold text-xs shadow-lg transition-colors flex items-center gap-2 font-mono uppercase">
          <span class="material-icons-outlined text-sm">play_arrow</span> Run Simulation Scenario
        </button>
      </div>

      <!-- Simulation Parameter Levers Grid -->
      <div class="bg-[#080808] border border-[#222] rounded p-4 shadow-xl space-y-4">
        <h2 class="text-xs font-bold text-[#F27D26] uppercase tracking-widest flex items-center gap-1.5 border-b border-[#222] pb-2 font-mono">
          <span class="material-icons-outlined text-sm">tune</span> Scenario Configuration Levers
        </h2>

        <div class="grid grid-cols-4 gap-4 font-mono text-xs">
          <!-- Lever 1: Passenger Volume Multiplier -->
          <div class="bg-[#111] p-3 rounded border border-[#222] space-y-2">
            <label for="pax-surge-select" class="text-[#888] text-[11px] block">Passenger Surge Multiplier:</label>
            <select id="pax-surge-select" [(ngModel)]="paxMultiplier" class="w-full bg-[#0A0A0A] border border-[#222] text-white p-2 rounded text-xs focus:outline-none focus:border-[#F27D26]">
              <option [value]="1.0">Normal Operation (1.0x)</option>
              <option [value]="1.1">+10% Passenger Surge (1.1x)</option>
              <option [value]="1.2">+20% Evening Peak (1.2x)</option>
              <option [value]="1.5">+50% Major Stadium Event (1.5x)</option>
            </select>
          </div>

          <!-- Lever 2: Platform Closures -->
          <div class="bg-[#111] p-3 rounded border border-[#222] space-y-2">
            <label for="platform-closure-select" class="text-[#888] text-[11px] block">Platform Closure Condition:</label>
            <select id="platform-closure-select" [(ngModel)]="closedPlatform" class="w-full bg-[#0A0A0A] border border-[#222] text-white p-2 rounded text-xs focus:outline-none focus:border-[#F27D26]">
              <option value="NONE">All Platforms Open</option>
              <option value="PLAT_04">Platform 4 Closed (Track Maintenance)</option>
              <option value="PLAT_07">Platform 7 Closed (Refurbishment)</option>
            </select>
          </div>

          <!-- Lever 3: Weather Simulation -->
          <div class="bg-[#111] p-3 rounded border border-[#222] space-y-2">
            <label for="weather-select" class="text-[#888] text-[11px] block">Weather Event:</label>
            <select id="weather-select" [(ngModel)]="weatherEvent" class="w-full bg-[#0A0A0A] border border-[#222] text-white p-2 rounded text-xs focus:outline-none focus:border-[#F27D26]">
              <option value="CLEAR">Clear Weather</option>
              <option value="RAIN">Heavy Rain (+15% Concourse Crowding)</option>
              <option value="SNOW">Heavy Snow & Cold (+25% HVAC Load)</option>
            </select>
          </div>

          <!-- Lever 4: Scenario Preset Quick Select -->
          <div class="bg-[#111] p-3 rounded border border-[#222] space-y-2">
            <label for="scenario-name-input" class="text-[#888] text-[11px] block">Scenario Name:</label>
            <input id="scenario-name-input" type="text" [(ngModel)]="scenarioName" class="w-full bg-[#0A0A0A] border border-[#222] text-white p-2 rounded text-xs focus:outline-none focus:border-[#F27D26]">
          </div>
        </div>
      </div>

      <!-- Before / After Comparison Engine Output -->
      @if (stateService.activeScenario(); as sc) {
        <div class="bg-[#080808] border border-[#222] rounded p-5 shadow-2xl space-y-4">
          <div class="flex items-center justify-between border-b border-[#222] pb-3 font-mono">
            <h2 class="text-xs font-bold text-white uppercase tracking-widest flex items-center gap-2">
              <span class="material-icons-outlined text-[#00FF44]">compare_arrows</span>
              <span>BEFORE / AFTER IMPACT COMPARISON ENGINE — {{ sc.name }}</span>
            </h2>
            <span class="text-xs text-[#888]">Simulated at {{ sc.createdAt | date:'HH:mm:ss' }}</span>
          </div>

          <!-- Comparison Metrics Table -->
          <div class="overflow-x-auto">
            <table class="w-full font-mono text-xs text-left">
              <thead>
                <tr class="text-[#666] border-b border-[#222] uppercase text-[10px]">
                  <th class="pb-3">METRIC</th>
                  <th class="pb-3 text-[#00FF44]">CURRENT STATION (BEFORE)</th>
                  <th class="pb-3 text-[#F27D26]">PROPOSED SCENARIO (AFTER)</th>
                  <th class="pb-3 text-right">VARIANCE / IMPACT</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-[#111]">
                <tr>
                  <td class="py-3 font-bold text-white">Capacity Utilisation</td>
                  <td class="py-3 text-[#AAA]">{{ sc.currentCapacityUtilisation }}%</td>
                  <td class="py-3 text-[#F27D26] font-bold">{{ sc.simulatedCapacityUtilisation }}%</td>
                  <td class="py-3 text-right font-bold text-[#FFB800]">+{{ sc.simulatedCapacityUtilisation - sc.currentCapacityUtilisation }}% Surge</td>
                </tr>
                <tr>
                  <td class="py-3 font-bold text-white">Avg Passenger Walking Time</td>
                  <td class="py-3 text-[#AAA]">{{ sc.currentAvgWalkingTimeMin }} min</td>
                  <td class="py-3 text-[#F27D26] font-bold">{{ sc.simulatedAvgWalkingTimeMin }} min</td>
                  <td class="py-3 text-right font-bold text-[#FF4444]">+{{ (sc.simulatedAvgWalkingTimeMin - sc.currentAvgWalkingTimeMin).toFixed(1) }} min delay</td>
                </tr>
                <tr>
                  <td class="py-3 font-bold text-white">Station Crowding Index</td>
                  <td class="py-3 text-[#AAA]">{{ sc.currentCrowdingIndex }} / 100</td>
                  <td class="py-3 text-[#F27D26] font-bold">{{ sc.simulatedCrowdingIndex }} / 100</td>
                  <td class="py-3 text-right font-bold text-[#FFB800]">+{{ sc.simulatedCrowdingIndex - sc.currentCrowdingIndex }} pts</td>
                </tr>
                <tr>
                  <td class="py-3 font-bold text-white">Train Throughput (per hour)</td>
                  <td class="py-3 text-[#AAA]">{{ sc.currentTrainThroughputPerHour }} trains/hr</td>
                  <td class="py-3 text-[#F27D26] font-bold">{{ sc.simulatedTrainThroughputPerHour }} trains/hr</td>
                  <td class="py-3 text-right font-bold text-[#00FF44]">{{ sc.simulatedTrainThroughputPerHour >= sc.currentTrainThroughputPerHour ? '+' : '' }}{{ sc.simulatedTrainThroughputPerHour - sc.currentTrainThroughputPerHour }} tph</td>
                </tr>
                <tr>
                  <td class="py-3 font-bold text-white">Station Energy Load</td>
                  <td class="py-3 text-[#AAA]">{{ sc.currentEnergyKw }} kW</td>
                  <td class="py-3 text-[#F27D26] font-bold">{{ sc.simulatedEnergyKw }} kW</td>
                  <td class="py-3 text-right font-bold text-[#F27D26]">+{{ sc.simulatedEnergyKw - sc.currentEnergyKw }} kW</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      }
    </div>
  `
})
export class ScenarioLaboratoryComponent {
  readonly stateService = inject(StationStateService);
  readonly i18n = inject(I18nService);

  paxMultiplier = 1.2;
  closedPlatform = 'NONE';
  weatherEvent: 'CLEAR' | 'RAIN' | 'SNOW' = 'RAIN';
  scenarioName = '+20% Evening Peak & Platform Maintenance';

  runNewScenario() {
    const closedList = this.closedPlatform !== 'NONE' ? [this.closedPlatform] : [];
    this.stateService.createScenario(this.scenarioName, this.paxMultiplier, closedList, this.weatherEvent);
  }
}
