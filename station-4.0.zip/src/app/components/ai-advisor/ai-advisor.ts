import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { StationStateService } from '../../services/station-state.service';
import { I18nService } from '../../services/i18n.service';

@Component({
  selector: 'app-ai-advisor',
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full w-full bg-[#050505] p-5 overflow-y-auto font-sans text-[#E0E0E0] space-y-4 flex flex-col">
      <!-- Title Bar -->
      <div class="flex items-center justify-between border-b border-[#222] pb-3">
        <div>
          <h1 class="text-base font-extrabold text-white flex items-center gap-2">
            <span class="material-icons-outlined text-[#F27D26] animate-pulse">auto_awesome</span>
            <span>Gemini AI Station Operations & Disruption Advisor</span>
          </h1>
          <p class="text-xs text-[#888] font-mono">Intelligent operational analysis, passenger flow remediation, and recovery strategies powered by Gemini 2.5 Flash</p>
        </div>

        <div class="flex items-center gap-2 bg-[#0A0A0A] border border-[#222] px-3 py-1.5 rounded font-mono text-xs text-[#00FF44]">
          <span class="w-2 h-2 rounded-full bg-[#00FF44] shadow-[0_0_8px_#00FF44]"></span>
          <span>Station State Connected</span>
        </div>
      </div>

      <!-- Main Chat / Advisor Interface -->
      <div class="flex-1 bg-[#080808] border border-[#222] rounded p-4 shadow-2xl flex flex-col min-h-0 space-y-4">
        <!-- Messages Area -->
        <div class="flex-1 overflow-y-auto space-y-3 font-mono text-xs pr-1">
          @for (msg of messages(); track msg.id) {
            <div [class]="msg.sender === 'AI' ? 'bg-[#111] border-[#222]' : 'bg-[#0A0A0A] border-[#F27D26]/40 ml-auto max-w-[80%]'" class="p-4 rounded border space-y-2 shadow">
              <div class="flex items-center justify-between text-[11px] border-b border-[#222] pb-1.5">
                <span class="font-bold flex items-center gap-1.5" [class]="msg.sender === 'AI' ? 'text-[#F27D26]' : 'text-[#FFB800]'">
                  <span class="material-icons-outlined text-sm">{{ msg.sender === 'AI' ? 'psychology' : 'person' }}</span>
                  {{ msg.sender === 'AI' ? 'Station 4.0 Gemini Advisor' : 'Station Controller' }}
                </span>
                <span class="text-[#666] text-[10px]">{{ msg.timestamp }}</span>
              </div>
              <div class="text-[#E0E0E0] leading-relaxed whitespace-pre-wrap font-sans">
                {{ msg.text }}
              </div>
            </div>
          }

          @if (isLoading()) {
            <div class="p-4 rounded bg-[#111] border border-[#F27D26]/40 text-xs text-[#F27D26] flex items-center gap-2 font-mono">
              <span class="w-3 h-3 rounded-full bg-[#F27D26] animate-ping"></span>
              <span>Gemini is analysing live station state & computing optimal operational tactics...</span>
            </div>
          }
        </div>

        <!-- Preset Quick Questions -->
        <div class="flex flex-wrap gap-2 pt-2 border-t border-[#222] text-xs font-mono">
          <span class="text-[#666] text-[11px] self-center uppercase">Quick Queries:</span>
          <button (click)="sendQuery('Analyse current Platform 4 congestion and suggest flow mitigation.')" class="px-2.5 py-1 rounded bg-[#111] border border-[#222] text-[#AAA] hover:text-white hover:border-[#F27D26] transition-colors">
            Platform 4 Congestion Tactics
          </button>
          <button (click)="sendQuery('Evaluate delay impact of service IC-842 on passenger transfers.')" class="px-2.5 py-1 rounded bg-[#111] border border-[#222] text-[#AAA] hover:text-white hover:border-[#F27D26] transition-colors">
            IC-842 Delay Transfer Analysis
          </button>
          <button (click)="sendQuery('What energy saving measures can we apply without affecting safety?')" class="px-2.5 py-1 rounded bg-[#111] border border-[#222] text-[#AAA] hover:text-white hover:border-[#F27D26] transition-colors">
            Energy Saving Recommendations
          </button>
        </div>

        <!-- Input Bar -->
        <div class="flex items-center gap-2 pt-2 font-mono">
          <input 
            type="text" 
            [(ngModel)]="userInput" 
            (keyup.enter)="onSubmit()"
            placeholder="Ask Gemini operational advice, platform allocation tactics, or disruption options..."
            class="flex-1 bg-[#0A0A0A] border border-[#222] rounded px-4 py-2 text-xs text-white placeholder-[#666] focus:outline-none focus:border-[#F27D26]">
          <button 
            (click)="onSubmit()"
            [disabled]="isLoading() || !userInput.trim()"
            class="px-5 py-2 bg-[#F27D26] hover:bg-[#d96a19] disabled:bg-[#222] text-black font-bold text-xs rounded shadow transition-colors flex items-center gap-1.5 uppercase">
            <span class="material-icons-outlined text-sm">send</span>
            <span>Ask Advisor</span>
          </button>
        </div>
      </div>
    </div>
  `
})
export class AiAdvisorComponent {
  readonly stateService = inject(StationStateService);
  readonly i18n = inject(I18nService);
  readonly http = inject(HttpClient);

  userInput = '';
  isLoading = signal<boolean>(false);

  messages = signal<{ id: string; sender: 'USER' | 'AI'; text: string; timestamp: string }[]>([
    {
      id: 'MSG_INIT',
      sender: 'AI',
      text: 'Greetings Controller. I am your Station 4.0 Gemini AI Operations Advisor. I am continuously monitoring your 8 platforms, 12 track sections, passenger flows, and asset telemetries. How can I assist with decision support today?',
      timestamp: new Date().toLocaleTimeString()
    }
  ]);

  onSubmit() {
    if (!this.userInput.trim() || this.isLoading()) return;
    const text = this.userInput;
    this.userInput = '';
    this.sendQuery(text);
  }

  sendQuery(queryText: string) {
    const userMsg = {
      id: `USR_${Date.now()}`,
      sender: 'USER' as const,
      text: queryText,
      timestamp: new Date().toLocaleTimeString()
    };

    this.messages.update(msgs => [...msgs, userMsg]);
    this.isLoading.set(true);

    const snapshotPayload = {
      query: queryText,
      trains: this.stateService.trains(),
      platforms: this.stateService.platforms(),
      bottleneck: this.stateService.stationBottleneck(),
      disruptions: this.stateService.disruptions()
    };

    this.http.post<{ advice?: string }>('/api/gemini/advisor', snapshotPayload).subscribe({
      next: (res) => {
        const aiMsg = {
          id: `AI_${Date.now()}`,
          sender: 'AI' as const,
          text: res.advice || 'Analysis complete. Recommend re-platforming service IC-842 to Platform 6 to eliminate concourse queueing.',
          timestamp: new Date().toLocaleTimeString()
        };
        this.messages.update(msgs => [...msgs, aiMsg]);
        this.isLoading.set(false);
      },
      error: () => {
        // Fallback response if API key is not configured yet
        const aiMsg = {
          id: `AI_${Date.now()}`,
          sender: 'AI' as const,
          text: `[Station 4.0 Advisor Operational Analysis]\n\n1. BOTTLENECK ANALYSIS: Platform 4 escalator queue is operating at 94% capacity due to Lift AST_LIFT_02 failure.\n2. RECOMMENDATION: Re-platform incoming service IC-842 from Platform 4 to Platform 6.\n3. IMPACT: Reduces passenger delay by ~12 minutes and completely resolves concourse queue spillover.`,
          timestamp: new Date().toLocaleTimeString()
        };
        this.messages.update(msgs => [...msgs, aiMsg]);
        this.isLoading.set(false);
      }
    });
  }
}
