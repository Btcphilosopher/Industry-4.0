import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { StationStateService } from '../../services/station-state.service';
import { I18nService } from '../../services/i18n.service';

@Component({
  selector: 'app-time-machine',
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full w-full bg-[#050505] p-5 overflow-y-auto font-sans text-[#E0E0E0] space-y-5">
      <!-- Title Bar -->
      <div class="flex items-center justify-between border-b border-[#222] pb-3">
        <div>
          <h1 class="text-base font-extrabold text-white flex items-center gap-2">
            <span class="material-icons-outlined text-[#F27D26]">history</span>
            <span>Digital Twin Time Machine — Historical Replay & Incident Audit</span>
          </h1>
          <p class="text-xs text-[#888] font-mono">Reconstruct complete station state, trains, passenger flows, and asset telemetries at any point in history</p>
        </div>

        <div class="flex items-center gap-2 bg-[#0A0A0A] border border-[#222] px-3 py-1.5 rounded font-mono text-xs text-[#F27D26]">
          <span class="w-2 h-2 rounded-full bg-[#F27D26] animate-ping"></span>
          <span>REPLAY TIMESTAMP: {{ selectedPlaybackTime() }}</span>
        </div>
      </div>

      <!-- Playback Controls Console -->
      <div class="bg-[#080808] border border-[#222] rounded p-5 shadow-2xl space-y-4 font-mono">
        <!-- Scrub Timeline -->
        <div class="space-y-2">
          <div class="flex justify-between text-xs text-[#888]">
            <span>08:00:00 (Morning Peak Start)</span>
            <span class="text-[#FFB800] font-bold">CURRENT SCRUB: {{ selectedPlaybackTime() }}</span>
            <span>09:00:00 (Incident Resolved)</span>
          </div>
          <input 
            type="range" 
            min="0" 
            max="60" 
            [value]="sliderVal()" 
            (input)="onSliderChange($event)"
            class="w-full h-2 bg-[#111] rounded appearance-none cursor-pointer accent-[#F27D26]">
        </div>

        <!-- Buttons Controls Bar -->
        <div class="flex items-center justify-between pt-2">
          <!-- Preset Jump Buttons -->
          <div class="flex items-center gap-2">
            <span class="text-xs text-[#888] font-mono">Preset Time Jumps:</span>
            <button (click)="jumpTo('08:00:00', 0)" class="px-2.5 py-1 rounded bg-[#111] border border-[#222] text-xs text-[#AAA] hover:text-white hover:border-[#F27D26]">08:00</button>
            <button (click)="jumpTo('08:15:00', 15)" class="px-2.5 py-1 rounded bg-[#111] border border-[#222] text-xs text-[#AAA] hover:text-white hover:border-[#F27D26]">08:15</button>
            <button (click)="jumpTo('08:30:00', 30)" class="px-2.5 py-1 rounded bg-[#111] border border-[#222] text-xs text-[#AAA] hover:text-white hover:border-[#F27D26]">08:30</button>
            <button (click)="jumpTo('08:45:00', 45)" class="px-2.5 py-1 rounded bg-[#111] border border-[#222] text-xs text-[#AAA] hover:text-white hover:border-[#F27D26]">08:45</button>
          </div>

          <!-- Playback Actions -->
          <div class="flex items-center gap-2">
            <button 
              (click)="togglePlay()"
              [class]="isPlaying() ? 'bg-[#FFB800] text-black' : 'bg-[#F27D26] hover:bg-[#d96a19] text-black'"
              class="px-4 py-2 rounded text-black font-bold text-xs shadow transition-colors flex items-center gap-1.5 font-mono uppercase">
              <span class="material-icons-outlined text-sm">{{ isPlaying() ? 'pause' : 'play_arrow' }}</span>
              {{ isPlaying() ? 'PAUSE REPLAY' : 'START REPLAY' }}
            </button>

            <!-- Speed Multiplier -->
            <div class="flex items-center bg-[#111] border border-[#222] p-1 rounded text-xs">
              <button (click)="speed.set(1)" [class]="speed() === 1 ? 'bg-[#F27D26]/20 text-[#F27D26]' : 'text-[#888]'" class="px-2 py-0.5 rounded">1x</button>
              <button (click)="speed.set(5)" [class]="speed() === 5 ? 'bg-[#F27D26]/20 text-[#F27D26]' : 'text-[#888]'" class="px-2 py-0.5 rounded">5x</button>
              <button (click)="speed.set(10)" [class]="speed() === 10 ? 'bg-[#F27D26]/20 text-[#F27D26]' : 'text-[#888]'" class="px-2 py-0.5 rounded">10x</button>
            </div>
          </div>
        </div>
      </div>

      <!-- Reconstructed Station State Snapshot View -->
      <div class="grid grid-cols-2 gap-4 font-mono text-xs">
        <div class="bg-[#080808] border border-[#222] rounded p-4 space-y-3">
          <h3 class="text-xs font-bold text-[#F27D26] uppercase tracking-widest flex items-center gap-1">
            <span class="material-icons-outlined text-sm">train</span> Train State at {{ selectedPlaybackTime() }}
          </h3>
          <div class="space-y-2 max-h-60 overflow-y-auto">
            @for (t of stateService.trains(); track t.id) {
              <div class="bg-[#111] p-2 rounded border border-[#222] flex justify-between">
                <span>{{ t.trainNumber }} ({{ t.origin }} → {{ t.destination }})</span>
                <span class="text-[#FFB800]">Plat {{ t.platformId }} | {{ t.status }}</span>
              </div>
            }
          </div>
        </div>

        <div class="bg-[#080808] border border-[#222] rounded p-4 space-y-3">
          <h3 class="text-xs font-bold text-[#F27D26] uppercase tracking-widest flex items-center gap-1">
            <span class="material-icons-outlined text-sm">event_note</span> Incident Audit Log
          </h3>
          <div class="space-y-2 max-h-60 overflow-y-auto">
            @for (evt of stateService.events(); track evt.id) {
              <div class="bg-[#111] p-2 rounded border border-[#222] space-y-1">
                <div class="flex justify-between text-[#888]">
                  <span class="text-[#F27D26] font-bold">{{ evt.timestamp }}</span>
                  <span class="text-[#FFB800]">{{ evt.type }}</span>
                </div>
                <p class="text-[#E0E0E0] text-[11px]">{{ evt.title }}</p>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `
})
export class TimeMachineComponent {
  readonly stateService = inject(StationStateService);
  readonly i18n = inject(I18nService);

  readonly sliderVal = signal<number>(30);
  readonly selectedPlaybackTime = signal<string>('08:30:00');
  readonly isPlaying = signal<boolean>(false);
  readonly speed = signal<number>(1);

  private timer: ReturnType<typeof setInterval> | null = null;

  onSliderChange(e: Event) {
    const val = Number((e.target as HTMLInputElement).value);
    this.sliderVal.set(val);
    const mins = String(val).padStart(2, '0');
    this.selectedPlaybackTime.set(`08:${mins}:00`);
  }

  jumpTo(timeStr: string, sliderVal: number) {
    this.selectedPlaybackTime.set(timeStr);
    this.sliderVal.set(sliderVal);
  }

  togglePlay() {
    this.isPlaying.update(v => !v);
    if (this.isPlaying()) {
      this.timer = setInterval(() => {
        let next = this.sliderVal() + 1;
        if (next > 60) next = 0;
        this.sliderVal.set(next);
        const mins = String(next).padStart(2, '0');
        this.selectedPlaybackTime.set(`08:${mins}:00`);
      }, 1000 / this.speed());
    } else if (this.timer) {
      clearInterval(this.timer);
    }
  }
}
