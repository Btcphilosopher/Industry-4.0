package com.port4.app

import kotlinx.coroutines.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable
data class LocalPortCoord(
    val x: Double,
    val y: Double,
    val z: Double = 0.0,
    val headingDeg: Double = 0.0
)

@Serializable
data class CraneModel(
    val id: String,
    val craneType: String,
    val berthId: String?,
    val gantryPosM: Double,
    val trolleyPosM: Double,
    val hoistHeightM: Double,
    val spreaderLatched: Boolean,
    val activeContainerId: String?,
    val status: String,
    val movesCompleted: Int,
    val avgCycleSec: Double,
    val energyKwh: Double,
    val position: LocalPortCoord
)

@Serializable
data class ContainerModel(
    val id: String,
    val isoType: String,
    val grossWeightTonnes: Double,
    val originPort: String,
    val destinationPort: String,
    val status: String,
    val yardBlockId: String?,
    val bay: Int?,
    val row: Int?,
    val tier: Int?,
    val position: LocalPortCoord
)

@Serializable
data class VesselModel(
    val imo: Long,
    val name: String,
    val lengthOverallM: Double,
    val beamM: Double,
    val currentDraftM: Double,
    val capacityTeu: Int,
    val assignedBerthId: String?,
    val status: String,
    val speedKnots: Double,
    val headingDeg: Double,
    val position: LocalPortCoord
)

class DigitalTwinEngine(val portId: String) {
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    val json = Json { ignoreUnknownKeys = true }

    fun startRealtimeStream() {
        println("Connecting Port 4.0 Digital Twin Visual Operating Environment to backend...")
        println("Authoritative Source of Truth: Rust Engine + PostGIS Spatially Normalized Coordinates")
    }
}

fun main() {
    println("=================================================================")
    println(" PORT 4.0 — DIGITAL TWIN & PORT AUTHORITY OPERATING SYSTEM")
    println(" Visual Operating Environment (Kotlin) Initialized")
    println("=================================================================")
    val engine = DigitalTwinEngine("port_rotterdam_gateway")
    engine.startRealtimeStream()
}
