-- ============================================================================
-- PORT 4.0 AUTHORITATIVE POSTGIS & OPERATIONAL DATABASE SCHEMA
-- Multi-Tenant Port Authority Operating System Architecture
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. PORT AUTHORITIES & TENANCY
CREATE TABLE IF NOT EXISTS port_authorities (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    country VARCHAR(64) NOT NULL,
    un_locode VARCHAR(10) NOT NULL UNIQUE,
    crs_epsg INT NOT NULL DEFAULT 4326,
    origin_lat NUMERIC(10, 7) NOT NULL,
    origin_lon NUMERIC(10, 7) NOT NULL,
    boundary GEOMETRY(Polygon, 4326),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. INFRASTRUCTURE & TERMINALS
CREATE TABLE IF NOT EXISTS terminals (
    id VARCHAR(64) PRIMARY KEY,
    port_authority_id VARCHAR(64) REFERENCES port_authorities(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    terminal_type VARCHAR(64) NOT NULL, -- 'CONTAINER', 'BULK', 'RO_RO', 'LIQUID_ENERGY', 'INTERMODAL_RAIL'
    area_sqm NUMERIC(12, 2),
    annual_capacity_teu INT,
    boundary GEOMETRY(MultiPolygon, 4326),
    status VARCHAR(32) DEFAULT 'OPERATIONAL'
);

-- 3. BERTHS & QUAYS
CREATE TABLE IF NOT EXISTS berths (
    id VARCHAR(64) PRIMARY KEY,
    terminal_id VARCHAR(64) REFERENCES terminals(id) ON DELETE CASCADE,
    name VARCHAR(128) NOT NULL,
    length_m NUMERIC(8, 2) NOT NULL,
    depth_chart_m NUMERIC(6, 2) NOT NULL,
    max_draft_m NUMERIC(6, 2) NOT NULL,
    bollard_start_m NUMERIC(8, 2) NOT NULL,
    bollard_end_m NUMERIC(8, 2) NOT NULL,
    shore_power_equipped BOOLEAN DEFAULT TRUE,
    quay_line GEOMETRY(LineString, 4326),
    status VARCHAR(32) DEFAULT 'AVAILABLE'
);

-- 4. CRANES & MATERIAL HANDLING ASSETS
CREATE TABLE IF NOT EXISTS cranes (
    id VARCHAR(64) PRIMARY KEY,
    port_authority_id VARCHAR(64) REFERENCES port_authorities(id) ON DELETE CASCADE,
    terminal_id VARCHAR(64) REFERENCES terminals(id) ON DELETE CASCADE,
    crane_type VARCHAR(64) NOT NULL, -- 'STS_SUPER_POST_PANAMAX', 'RTG_ELECTRIC', 'RMG_AUTOMATED', 'REACH_STACKER'
    rail_gauge_m NUMERIC(6, 2),
    outreach_m NUMERIC(6, 2),
    lift_height_above_rail_m NUMERIC(6, 2),
    safe_working_load_tonnes NUMERIC(6, 2),
    speed_gantry_mps NUMERIC(4, 2),
    speed_trolley_mps NUMERIC(4, 2),
    speed_hoist_mps NUMERIC(4, 2),
    power_kw NUMERIC(8, 2),
    status VARCHAR(32) DEFAULT 'IDLE',
    geom GEOMETRY(Point, 4326)
);

-- 5. CONTAINER YARDS & BLOCKS
CREATE TABLE IF NOT EXISTS yard_blocks (
    id VARCHAR(64) PRIMARY KEY,
    terminal_id VARCHAR(64) REFERENCES terminals(id) ON DELETE CASCADE,
    block_code VARCHAR(32) NOT NULL,
    bays_count INT NOT NULL,
    rows_count INT NOT NULL,
    max_tiers INT NOT NULL,
    block_type VARCHAR(64) DEFAULT 'GENERAL_DRY', -- 'GENERAL_DRY', 'REEFER_PLUGGED', 'HAZMAT_IMO', 'EMPTY_STORAGE'
    orientation_deg NUMERIC(6, 2) DEFAULT 0.0,
    boundary GEOMETRY(Polygon, 4326)
);

-- 6. CONTAINERS (FIRST CLASS ASSET)
CREATE TABLE IF NOT EXISTS containers (
    id VARCHAR(32) PRIMARY KEY, -- BIC / ISO 6346 Container Number
    port_authority_id VARCHAR(64) REFERENCES port_authorities(id) ON DELETE CASCADE,
    iso_type VARCHAR(10) NOT NULL, -- '42G1', '45R1', 'L5G1', '22T1'
    length_ft INT NOT NULL,
    gross_weight_kg NUMERIC(8, 2),
    tare_weight_kg NUMERIC(8, 2),
    cargo_type VARCHAR(64) DEFAULT 'GENERAL',
    hazardous_class VARCHAR(32),
    temperature_setpoint_c NUMERIC(5, 2),
    status VARCHAR(64) NOT NULL, -- 'ON_VESSEL', 'CRANE_LIFT', 'IN_TRANSIT_YARD', 'STACKED', 'RAIL_LOADING', 'GATE_OUT'
    current_asset_id VARCHAR(64),
    yard_block_id VARCHAR(64) REFERENCES yard_blocks(id),
    bay INT,
    row INT,
    tier INT,
    origin_port VARCHAR(10),
    destination_port VARCHAR(10),
    vessel_imo INT,
    geom GEOMETRY(Point, 4326),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. ROADS, RAILWAYS & GATES
CREATE TABLE IF NOT EXISTS road_segments (
    id VARCHAR(64) PRIMARY KEY,
    port_authority_id VARCHAR(64) REFERENCES port_authorities(id),
    road_name VARCHAR(128),
    lanes INT DEFAULT 2,
    speed_limit_kph INT DEFAULT 30,
    is_agv_dedicated BOOLEAN DEFAULT FALSE,
    centerline GEOMETRY(LineString, 4326)
);

CREATE TABLE IF NOT EXISTS railway_tracks (
    id VARCHAR(64) PRIMARY KEY,
    port_authority_id VARCHAR(64) REFERENCES port_authorities(id),
    track_name VARCHAR(128),
    gauge_type VARCHAR(32) DEFAULT 'STANDARD_1435MM',
    electrified BOOLEAN DEFAULT TRUE,
    centerline GEOMETRY(LineString, 4326)
);

-- 8. REAL-TIME TELEMETRY (PARTITIONED BY DAY)
CREATE TABLE IF NOT EXISTS asset_telemetry (
    id BIGSERIAL,
    port_authority_id VARCHAR(64) NOT NULL,
    asset_id VARCHAR(64) NOT NULL,
    timestamp TIMESTAMPTZ NOT NULL,
    latitude NUMERIC(10, 7) NOT NULL,
    longitude NUMERIC(10, 7) NOT NULL,
    speed_mps NUMERIC(6, 2),
    heading_deg NUMERIC(5, 2),
    load_tonnes NUMERIC(6, 2),
    power_kw NUMERIC(8, 2),
    battery_soc_pct NUMERIC(5, 2),
    vibration_rms NUMERIC(6, 3),
    status VARCHAR(32),
    PRIMARY KEY (id, timestamp)
) PARTITION BY RANGE (timestamp);

-- 9. EVENT STREAM (PARTITIONED)
CREATE TABLE IF NOT EXISTS port_events (
    event_id UUID DEFAULT uuid_generate_v4(),
    timestamp TIMESTAMPTZ NOT NULL,
    port_authority_id VARCHAR(64) NOT NULL,
    asset_id VARCHAR(64) NOT NULL,
    event_type VARCHAR(64) NOT NULL,
    location GEOMETRY(Point, 4326),
    payload JSONB,
    PRIMARY KEY (event_id, timestamp)
) PARTITION BY RANGE (timestamp);

-- SPATIAL INDEXES
CREATE INDEX IF NOT EXISTS idx_terminals_boundary ON terminals USING GIST (boundary);
CREATE INDEX IF NOT EXISTS idx_berths_quay_line ON berths USING GIST (quay_line);
CREATE INDEX IF NOT EXISTS idx_cranes_geom ON cranes USING GIST (geom);
CREATE INDEX IF NOT EXISTS idx_yard_blocks_geom ON yard_blocks USING GIST (boundary);
CREATE INDEX IF NOT EXISTS idx_containers_geom ON containers USING GIST (geom);
CREATE INDEX IF NOT EXISTS idx_roads_geom ON road_segments USING GIST (centerline);
CREATE INDEX IF NOT EXISTS idx_railways_geom ON railway_tracks USING GIST (centerline);
