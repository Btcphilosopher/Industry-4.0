use serde::{Deserialize, Serialize};
use chrono::{DateTime, Utc};
use uuid::Uuid;
use crate::geospatial::LocalPortCoord;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum EventType {
    VesselArrived,
    VesselBerthed,
    VesselDeparted,
    ContainerDischarged,
    ContainerLoaded,
    ContainerMoved,
    ContainerStacked,
    ContainerRetrieved,
    TruckArrived,
    TruckDeparted,
    TrainArrived,
    TrainDeparted,
    CraneStarted,
    CraneStopped,
    CraneFault,
    GateOpened,
    GateClosed,
    WeatherAlert,
    MaintenanceRequired,
    SpeedViolation,
    ZoneBreach,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PortEvent {
    pub event_id: Uuid,
    pub timestamp: DateTime<Utc>,
    pub port_id: String,
    pub port_authority_id: String,
    pub asset_id: String,
    pub event_type: EventType,
    pub location: LocalPortCoord,
    pub payload: serde_json::Value,
}

pub struct EventBus {
    sender: tokio::sync::broadcast::Sender<PortEvent>,
}

impl EventBus {
    pub fn new(capacity: usize) -> Self {
        let (sender, _) = tokio::sync::broadcast::channel(capacity);
        Self { sender }
    }

    pub fn publish(&self, event: PortEvent) -> Result<usize, tokio::sync::broadcast::error::SendError<PortEvent>> {
        self.sender.send(event)
    }

    pub fn subscribe(&self) -> tokio::sync::broadcast::Receiver<PortEvent> {
        self.sender.subscribe()
    }
}
