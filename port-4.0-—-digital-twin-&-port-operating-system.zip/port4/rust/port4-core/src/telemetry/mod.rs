use serde::{Deserialize, Serialize};
use chrono::{DateTime, Utc};
use crate::geospatial::LocalPortCoord;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TelemetryPacket {
    pub device_id: String,
    pub asset_id: String,
    pub asset_type: String,
    pub timestamp: DateTime<Utc>,
    pub position: LocalPortCoord,
    pub speed_mps: f64,
    pub heading_deg: f64,
    pub load_tonnes: f64,
    pub power_kw: f64,
    pub battery_soc_pct: Option<f64>,
    pub fuel_level_pct: Option<f64>,
    pub ambient_temp_c: f64,
    pub vibration_rms: f64,
    pub status: String,
    pub fault_codes: Vec<String>,
}
