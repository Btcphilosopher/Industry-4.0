use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct WGS84Coord {
    pub latitude: f64,
    pub longitude: f64,
    pub elevation_m: f64,
}

#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct LocalPortCoord {
    pub x: f64, // Easting in metres relative to port origin
    pub y: f64, // Northing in metres relative to port origin
    pub z: f64, // Altitude/Tier height in metres
    pub heading_deg: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PortGeoTransformer {
    pub origin_lat: f64,
    pub origin_lon: f64,
    pub epsg_code: u32,
    pub rotation_deg: f64,
    pub scale_factor: f64, // 1.0 = 1 metre = 1 scene unit
}

impl PortGeoTransformer {
    pub fn new(origin_lat: f64, origin_lon: f64, epsg_code: u32, rotation_deg: f64) -> Self {
        Self {
            origin_lat,
            origin_lon,
            epsg_code,
            rotation_deg,
            scale_factor: 1.0,
        }
    }

    /// Converts WGS84 coordinates to local metric port coordinate space
    pub fn wgs84_to_local(&self, coord: WGS84Coord) -> LocalPortCoord {
        const EARTH_RADIUS_M: f64 = 6378137.0;
        let lat_rad = (coord.latitude - self.origin_lat).to_radians();
        let lon_rad = (coord.longitude - self.origin_lon).to_radians();
        let avg_lat = (self.origin_lat + coord.latitude) * 0.5 * std::f64::consts::PI / 180.0;

        let dy = lat_rad * EARTH_RADIUS_M;
        let dx = lon_rad * EARTH_RADIUS_M * avg_lat.cos();

        // Apply port grid alignment rotation
        let rot_rad = self.rotation_deg.to_radians();
        let local_x = (dx * rot_rad.cos() - dy * rot_rad.sin()) * self.scale_factor;
        let local_y = (dx * rot_rad.sin() + dy * rot_rad.cos()) * self.scale_factor;

        LocalPortCoord {
            x: local_x,
            y: local_y,
            z: coord.elevation_m,
            heading_deg: 0.0,
        }
    }

    /// Converts local metric port coordinate back to WGS84
    pub fn local_to_wgs84(&self, local: LocalPortCoord) -> WGS84Coord {
        const EARTH_RADIUS_M: f64 = 6378137.0;
        let rot_rad = -self.rotation_deg.to_radians();
        let unscaled_x = local.x / self.scale_factor;
        let unscaled_y = local.y / self.scale_factor;

        let dx = unscaled_x * rot_rad.cos() - unscaled_y * rot_rad.sin();
        let dy = unscaled_x * rot_rad.sin() + unscaled_y * rot_rad.cos();

        let avg_lat_rad = self.origin_lat.to_radians();
        let lat_offset = (dy / EARTH_RADIUS_M).to_degrees();
        let lon_offset = (dx / (EARTH_RADIUS_M * avg_lat_rad.cos())).to_degrees();

        WGS84Coord {
            latitude: self.origin_lat + lat_offset,
            longitude: self.origin_lon + lon_offset,
            elevation_m: local.z,
        }
    }
}
