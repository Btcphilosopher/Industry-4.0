use serde::{Deserialize, Serialize};
use uuid::Uuid;
use chrono::{DateTime, Utc};
use crate::geospatial::LocalPortCoord;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PortAuthority {
    pub id: String,
    pub name: String,
    pub country: String,
    pub un_locode: String,
    pub crs: String,
    pub timezone: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum AssetType {
    ShipToShoreCrane,
    RubberTyredGantry,
    RailMountedGantry,
    ReachStacker,
    TerminalTruck,
    AutomatedGuidedVehicle,
    FreightLocomotive,
    ContainerVessel,
    FeederVessel,
    Barge,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ContainerStatus {
    OnVessel,
    CranePicking,
    CraneMoving,
    CraneDropping,
    TruckLoading,
    InTransit,
    YardStacked,
    RmgMoving,
    RailLoading,
    OnTrain,
    GateExiting,
    Delivered,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ContainerState {
    pub id: String,
    pub iso_type: String, // '20GP', '40HC', '45HC', '20RF', '40RF', 'TANK', 'FLAT'
    pub length_ft: u8,
    pub gross_weight_tonnes: f64,
    pub tare_weight_tonnes: f64,
    pub cargo_type: String, // 'General', 'Reefer', 'Hazardous_Class_3', 'OOG', 'Empty'
    pub origin_port: String,
    pub destination_port: String,
    pub status: ContainerStatus,
    pub current_asset_id: Option<String>,
    pub yard_block_id: Option<String>,
    pub bay: Option<u8>,
    pub row: Option<u8>,
    pub tier: Option<u8>,
    pub position: LocalPortCoord,
    pub last_updated: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum CraneMode {
    Idle,
    Discharging,
    Loading,
    Shifting,
    Maintenance,
    Fault,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CraneState {
    pub id: String,
    pub crane_type: AssetType,
    pub berth_id: Option<String>,
    pub gantry_pos_m: f64,
    pub trolley_pos_m: f64,
    pub hoist_height_m: f64,
    pub boom_angle_deg: f64,
    pub spreader_latched: bool,
    pub active_container_id: Option<String>,
    pub mode: CraneMode,
    pub moves_completed_shift: u32,
    pub avg_cycle_time_sec: f64,
    pub current_power_kw: f64,
    pub cumulative_energy_kwh: f64,
    pub position: LocalPortCoord,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum VesselStatus {
    AtSea,
    Approaching,
    Anchoring,
    Berthing,
    Berthed,
    Loading,
    Unloading,
    Departing,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VesselState {
    pub imo_number: u32,
    pub name: String,
    pub callsign: String,
    pub flag: String,
    pub length_overall_m: f64,
    pub beam_m: f64,
    pub current_draft_m: f64,
    pub max_draft_m: f64,
    pub capacity_teu: u32,
    pub eta: DateTime<Utc>,
    pub etd: DateTime<Utc>,
    pub assigned_berth_id: Option<String>,
    pub status: VesselStatus,
    pub position: LocalPortCoord,
    pub speed_knots: f64,
    pub heading_deg: f64,
    pub containers_to_discharge: u32,
    pub containers_to_load: u32,
    pub allocated_cranes: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BerthState {
    pub id: String,
    pub terminal_id: String,
    pub name: String,
    pub length_m: f64,
    pub depth_m: f64,
    pub max_draft_m: f64,
    pub current_vessel_imo: Option<u32>,
    pub bollard_start_m: f64,
    pub bollard_end_m: f64,
    pub shore_power_active: bool,
}
