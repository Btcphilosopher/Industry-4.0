use axum::{
    routing::{get, post},
    Router, Json, extract::State,
};
use std::sync::Arc;
use tokio::sync::RwLock;
use serde_json::json;

#[derive(Clone)]
pub struct AppState {
    pub port_id: String,
}

pub fn create_router(state: Arc<AppState>) -> Router {
    Router::new()
        .route("/health", get(|| async { Json(json!({"status": "healthy", "service": "port4-core-rust"})) }))
        .route("/port", get(get_port_info))
        .route("/telemetry/ingest", post(ingest_telemetry))
        .with_state(state)
}

async fn get_port_info(State(state): State<Arc<AppState>>) -> Json<serde_json::Value> {
    Json(json!({
        "port_id": state.port_id,
        "engine": "port4-core-rust-v0.4.0",
        "precision": "sub-meter WGS84 geodesic",
        "fps_target": 60,
    }))
}

async fn ingest_telemetry(Json(payload): Json<serde_json::Value>) -> Json<serde_json::Value> {
    Json(json!({"status": "acknowledged", "timestamp": chrono::Utc::now()}))
}
