import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
const angularApp = new AngularNodeAppEngine();

app.use(express.json());

// ==========================================
// PORT 4.0 REST & DIGITAL TWIN API ROUTES
// ==========================================
app.get('/api/health', (req, res) => {
  res.json({
    status: 'OPERATIONAL',
    version: '4.0.0-ENTERPRISE',
    rust_core_status: 'RUNNING',
    python_simulation_status: 'OPTIMAL',
    postgis_spatial_status: 'CONNECTED',
    server_time: new Date().toISOString(),
  });
});

app.get('/api/ports', (req, res) => {
  res.json([
    { id: 'port_rotterdam_gateway', name: 'Port of Rotterdam — Maasvlakte II Intermodal Hub', country: 'Netherlands', unLocode: 'NLRTM', crs: 'EPSG:28992' },
    { id: 'port_felixstowe_trinity', name: 'Port of Felixstowe — Trinity Intermodal Terminal', country: 'United Kingdom', unLocode: 'GBFXT', crs: 'EPSG:27700' },
    { id: 'port_singapore_pasir', name: 'Port of Singapore — Pasir Panjang Automated Terminal', country: 'Singapore', unLocode: 'SGSIN', crs: 'EPSG:3414' },
    { id: 'port_la_pier400', name: 'Port of Los Angeles — Pier 400 APM Terminal', country: 'United States', unLocode: 'USLAX', crs: 'EPSG:2229' }
  ]);
});

app.post('/api/optimise/berths', (req, res) => {
  const vesselsCount = req.body?.vessels?.length ?? 3;
  const berthsCount = req.body?.berths?.length ?? 4;
  res.json({
    status: 'OPTIMAL',
    algorithm: 'Continuous-BAP-QCAP-MIP',
    objectiveCost: 142.8,
    evaluatedEntities: { vesselsCount, berthsCount },
    allocations: [
      { berthId: 'BERTH_01', vesselName: 'EVER GOLDEN', assignedCranes: ['STS-01', 'STS-02'], estimatedTurnaroundHrs: 24.5, waitMins: 0 },
      { berthId: 'BERTH_02', vesselName: 'MAERSK MC-KINNEY MOLLER', assignedCranes: ['STS-03', 'STS-04'], estimatedTurnaroundHrs: 28.0, waitMins: 0 },
      { berthId: 'BERTH_03', vesselName: 'CMA CGM ANTOINE', assignedCranes: ['STS-05'], estimatedTurnaroundHrs: 32.5, waitMins: 15 }
    ]
  });
});

app.post('/api/scenario/evaluate', (req, res) => {
  const { volumeMultiplier = 1.0, disabledCranes = 0, railFactor = 1.0 } = req.body || {};
  const baseTeu = 14850;
  const projectedTeu = Math.round(baseTeu * volumeMultiplier);
  const waitHrs = Number((1.2 * (volumeMultiplier ** 2) + disabledCranes * 4.2).toFixed(1));
  const yardPct = Math.min(98, Math.round(68 * volumeMultiplier + (1.0 - railFactor) * 20));
  const truckMins = Number((24.5 * (1 + (volumeMultiplier - 1) * 0.8 + disabledCranes * 0.15)).toFixed(1));
  const netRevenueUsd = Math.round((projectedTeu - baseTeu) * 85.0 - waitHrs * 15000);

  res.json({
    status: 'SUCCESS',
    projectedDailyTeu: projectedTeu,
    averageVesselWaitHours: waitHrs,
    yardUtilizationPercent: yardPct,
    truckTurnaroundMinutes: truckMins,
    netRevenueImpactUsd: netRevenueUsd,
    co2DeltaTonnes: Number(((projectedTeu - baseTeu) * 0.018).toFixed(1))
  });
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
