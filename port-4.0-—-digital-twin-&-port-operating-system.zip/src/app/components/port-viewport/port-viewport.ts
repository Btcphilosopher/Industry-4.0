import {
  AfterViewInit,
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  HostListener,
  ViewChild,
  effect,
  inject,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { PortEngineService } from '../../services/port-engine.service';
import { GeospatialService } from '../../services/geospatial.service';
import { Crane, Vehicle, Vessel, YardBlock } from '../../models/port.models';

@Component({
  selector: 'app-port-viewport',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-full bg-[#0A0A0A] overflow-hidden select-none">
      <!-- Background subtle technical grid overlay -->
      <div class="absolute inset-0 opacity-20 pointer-events-none bg-tech-grid"></div>

      <!-- Main Canvas -->
      <canvas
        #viewportCanvas
        class="w-full h-full cursor-grab active:cursor-grabbing block relative z-10"
        (mousedown)="onMouseDown($event)"
        (mousemove)="onMouseMove($event)"
        (mouseup)="onMouseUp()"
        (wheel)="onWheel($event)"
        (click)="onClick($event)"
      ></canvas>

      <!-- Viewport Controls & HUD Overlay -->
      <div class="absolute top-3 left-3 flex flex-col gap-2 pointer-events-none z-20">
        <!-- View Mode & Scale Indicator (Technical Toggle) -->
        <div class="flex items-center gap-1.5 bg-[#0F0F0F]/95 border border-zinc-800 px-2.5 py-1 rounded shadow-lg backdrop-blur-md pointer-events-auto">
          <button
            (click)="setViewMode('3D_ISOMETRIC')"
            [class.bg-white]="portEngine.viewMode() === '3D_ISOMETRIC'"
            [class.text-black]="portEngine.viewMode() === '3D_ISOMETRIC'"
            [class.font-bold]="portEngine.viewMode() === '3D_ISOMETRIC'"
            [class.border-white]="portEngine.viewMode() === '3D_ISOMETRIC'"
            [class.bg-zinc-900]="portEngine.viewMode() !== '3D_ISOMETRIC'"
            [class.text-zinc-400]="portEngine.viewMode() !== '3D_ISOMETRIC'"
            [class.border-zinc-800]="portEngine.viewMode() !== '3D_ISOMETRIC'"
            class="px-2.5 py-1 text-xs font-mono rounded border transition flex items-center gap-1.5"
          >
            <span class="w-1.5 h-1.5 rounded-full" [class.bg-emerald-500]="portEngine.viewMode() === '3D_ISOMETRIC'" [class.bg-zinc-600]="portEngine.viewMode() !== '3D_ISOMETRIC'"></span>
            3D TWIN
          </button>
          <button
            (click)="setViewMode('2D_MAP')"
            [class.bg-white]="portEngine.viewMode() === '2D_MAP'"
            [class.text-black]="portEngine.viewMode() === '2D_MAP'"
            [class.font-bold]="portEngine.viewMode() === '2D_MAP'"
            [class.border-white]="portEngine.viewMode() === '2D_MAP'"
            [class.bg-zinc-900]="portEngine.viewMode() !== '2D_MAP'"
            [class.text-zinc-400]="portEngine.viewMode() !== '2D_MAP'"
            [class.border-zinc-800]="portEngine.viewMode() !== '2D_MAP'"
            class="px-2.5 py-1 text-xs font-mono rounded border transition flex items-center gap-1.5"
          >
            <span class="w-1.5 h-1.5 rounded-full" [class.bg-emerald-500]="portEngine.viewMode() === '2D_MAP'" [class.bg-zinc-600]="portEngine.viewMode() !== '2D_MAP'"></span>
            2D MAP
          </button>
        </div>

        <!-- LOD Level Selector -->
        <div class="flex items-center gap-1 bg-[#0F0F0F]/95 border border-zinc-800 p-1 rounded shadow-lg backdrop-blur-md pointer-events-auto text-[10px] font-mono">
          <span class="text-zinc-500 uppercase px-1.5 text-[9px] tracking-wider">LOD:</span>
          @for (lod of lodOptions; track lod.id) {
            <button
              (click)="setLod(lod.id)"
              [class.bg-zinc-800]="portEngine.activeLod() === lod.id"
              [class.text-emerald-400]="portEngine.activeLod() === lod.id"
              [class.font-bold]="portEngine.activeLod() === lod.id"
              [class.border-zinc-700]="portEngine.activeLod() === lod.id"
              [class.text-zinc-500]="portEngine.activeLod() !== lod.id"
              class="px-2 py-0.5 rounded border border-transparent hover:text-zinc-200 transition"
            >
              {{ lod.label }}
            </button>
          }
        </div>
      </div>

      <!-- Top Right Coordinate & Geodetic HUD -->
      <div class="absolute top-3 right-3 flex flex-col items-end gap-1.5 pointer-events-none z-20 font-mono">
        <div class="bg-[#0F0F0F]/95 border border-zinc-800 px-3 py-2 rounded shadow-lg backdrop-blur-md text-right text-xs">
          <div class="text-[9px] text-zinc-500 uppercase tracking-widest">METRIC GRID SCALE</div>
          <div class="text-white font-bold text-xs mt-0.5">1.00m = <span class="text-emerald-400">{{ zoomLevel().toFixed(2) }}px</span></div>
          <div class="text-[10px] text-zinc-400 mt-1 border-t border-zinc-800 pt-1">
            CURSOR: X <span class="text-zinc-200 font-bold">{{ cursorLocal().x.toFixed(1) }}m</span> | Y <span class="text-zinc-200 font-bold">{{ cursorLocal().y.toFixed(1) }}m</span>
          </div>
          <div class="text-[9px] text-zinc-500">
            WGS84: {{ cursorWgs().lat.toFixed(5) }}°N, {{ cursorWgs().lon.toFixed(5) }}°E
          </div>
        </div>

        <!-- Layer Toggles -->
        <div class="flex items-center gap-1 bg-[#0F0F0F]/95 border border-zinc-800 p-1 rounded text-[10px] pointer-events-auto shadow-md">
          <button
            (click)="toggleLayer('cranes')"
            [class.text-emerald-400]="showCranes()"
            [class.border-emerald-500/40]="showCranes()"
            [class.bg-emerald-500/10]="showCranes()"
            [class.text-zinc-500]="!showCranes()"
            [class.border-transparent]="!showCranes()"
            class="px-2 py-0.5 rounded border hover:text-zinc-200 transition font-mono"
          >
            STS Cranes
          </button>
          <button
            (click)="toggleLayer('vehicles')"
            [class.text-emerald-400]="showVehicles()"
            [class.border-emerald-500/40]="showVehicles()"
            [class.bg-emerald-500/10]="showVehicles()"
            [class.text-zinc-500]="!showVehicles()"
            [class.border-transparent]="!showVehicles()"
            class="px-2 py-0.5 rounded border hover:text-zinc-200 transition font-mono"
          >
            AGV Fleet
          </button>
          <button
            (click)="toggleLayer('yard')"
            [class.text-emerald-400]="showYard()"
            [class.border-emerald-500/40]="showYard()"
            [class.bg-emerald-500/10]="showYard()"
            [class.text-zinc-500]="!showYard()"
            [class.border-transparent]="!showYard()"
            class="px-2 py-0.5 rounded border hover:text-zinc-200 transition font-mono"
          >
            Yard Stacks
          </button>
          <button
            (click)="toggleLayer('rail')"
            [class.text-emerald-400]="showRail()"
            [class.border-emerald-500/40]="showRail()"
            [class.bg-emerald-500/10]="showRail()"
            [class.text-zinc-500]="!showRail()"
            [class.border-transparent]="!showRail()"
            class="px-2 py-0.5 rounded border hover:text-zinc-200 transition font-mono"
          >
            Intermodal Rail
          </button>
        </div>
      </div>

      <!-- Bottom-Left Navigation / Zoom Actions -->
      <div class="absolute bottom-3 left-3 flex items-center gap-1 bg-[#0F0F0F]/95 border border-zinc-800 p-1 rounded shadow-lg backdrop-blur-md z-20">
        <button (click)="zoomIn()" class="p-1.5 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded transition" title="Zoom In">
          <span class="material-icons text-sm">add</span>
        </button>
        <button (click)="zoomOut()" class="p-1.5 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded transition" title="Zoom Out">
          <span class="material-icons text-sm">remove</span>
        </button>
        <button (click)="resetCamera()" class="p-1.5 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded transition" title="Reset View">
          <span class="material-icons text-sm">center_focus_strong</span>
        </button>
      </div>

      <!-- Hover tooltip -->
      @if (hoverInfo()) {
        <div
          [style.left.px]="hoverInfo()!.screenX + 15"
          [style.top.px]="hoverInfo()!.screenY + 15"
          class="absolute pointer-events-none bg-[#0F0F0F]/95 border border-zinc-700 text-zinc-100 px-3 py-2 rounded shadow-2xl text-xs z-50 backdrop-blur-md max-w-xs font-mono"
        >
          <div class="font-bold text-white flex items-center justify-between gap-2">
            <span>{{ hoverInfo()!.title }}</span>
            <span class="text-[9px] bg-emerald-500/10 text-emerald-400 px-1.5 py-0.5 rounded border border-emerald-500/30">{{ hoverInfo()!.type }}</span>
          </div>
          <div class="text-[10px] text-zinc-400 mt-1">{{ hoverInfo()!.subtitle }}</div>
          <div class="text-[9px] text-zinc-500 font-mono mt-0.5">{{ hoverInfo()!.stats }}</div>
        </div>
      }
    </div>
  `,
})
export class PortViewport implements AfterViewInit {
  @ViewChild('viewportCanvas', { static: true }) canvasRef!: ElementRef<HTMLCanvasElement>;

  readonly portEngine = inject(PortEngineService);
  readonly geo = inject(GeospatialService);

  readonly zoomLevel = signal<number>(0.85); // pixels per metre
  readonly panOffset = signal<{ x: number; y: number }>({ x: 220, y: 140 });
  readonly cursorLocal = signal<{ x: number; y: number }>({ x: 0, y: 0 });
  readonly cursorWgs = signal<{ lat: number; lon: number }>({ lat: 51.956, lon: 4.015 });
  readonly hoverInfo = signal<{ screenX: number; screenY: number; title: string; type: string; subtitle: string; stats: string } | null>(null);

  readonly showCranes = signal<boolean>(true);
  readonly showVehicles = signal<boolean>(true);
  readonly showYard = signal<boolean>(true);
  readonly showRail = signal<boolean>(true);

  readonly lodOptions = [
    { id: 'PORT_OVERVIEW', label: 'Port (1:1000)' },
    { id: 'TERMINAL_VIEW', label: 'Terminal (1:200)' },
    { id: 'YARD_VIEW', label: 'Yard Stacks' },
    { id: 'ASSET_VIEW', label: 'STS Crane' },
    { id: 'ENGINEERING_VIEW', label: 'Blueprint (Dims)' },
  ] as const;

  private isDragging = false;
  private dragStart = { x: 0, y: 0 };
  private ctx!: CanvasRenderingContext2D;
  private waterOffset = 0;

  constructor() {
    effect(() => {
      // Re-trigger render when state updates
      this.portEngine.cranes();
      this.portEngine.vessels();
      this.portEngine.vehicles();
      this.portEngine.yardBlocks();
      this.portEngine.selectedAsset();
      this.render();
    });
  }

  ngAfterViewInit() {
    const canvas = this.canvasRef.nativeElement;
    this.ctx = canvas.getContext('2d', { alpha: false })!;
    this.resizeCanvas();
    this.startRenderLoop();
  }

  @HostListener('window:resize')
  resizeCanvas() {
    const canvas = this.canvasRef.nativeElement;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * window.devicePixelRatio;
    canvas.height = rect.height * window.devicePixelRatio;
    this.ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
  }

  setViewMode(mode: '2D_MAP' | '3D_ISOMETRIC') {
    this.portEngine.viewMode.set(mode);
  }

  setLod(lod: typeof this.lodOptions[number]['id']) {
    this.portEngine.activeLod.set(lod);
    if (lod === 'PORT_OVERVIEW') {
      this.zoomLevel.set(0.45);
      this.panOffset.set({ x: 80, y: 80 });
    } else if (lod === 'TERMINAL_VIEW') {
      this.zoomLevel.set(0.85);
      this.panOffset.set({ x: 220, y: 140 });
    } else if (lod === 'YARD_VIEW') {
      this.zoomLevel.set(1.6);
      this.panOffset.set({ x: -100, y: -150 });
    } else if (lod === 'ASSET_VIEW') {
      this.zoomLevel.set(2.8);
      this.panOffset.set({ x: 100, y: -40 });
    } else if (lod === 'ENGINEERING_VIEW') {
      this.zoomLevel.set(1.1);
      this.panOffset.set({ x: 150, y: 120 });
    }
  }

  toggleLayer(layer: 'cranes' | 'vehicles' | 'yard' | 'rail') {
    if (layer === 'cranes') this.showCranes.update((v) => !v);
    if (layer === 'vehicles') this.showVehicles.update((v) => !v);
    if (layer === 'yard') this.showYard.update((v) => !v);
    if (layer === 'rail') this.showRail.update((v) => !v);
  }

  zoomIn() {
    this.zoomLevel.update((z) => Math.min(4.5, z * 1.25));
  }

  zoomOut() {
    this.zoomLevel.update((z) => Math.max(0.25, z * 0.8));
  }

  resetCamera() {
    this.zoomLevel.set(0.85);
    this.panOffset.set({ x: 220, y: 140 });
  }

  onMouseDown(e: MouseEvent) {
    this.isDragging = true;
    this.dragStart = { x: e.clientX - this.panOffset().x, y: e.clientY - this.panOffset().y };
  }

  onMouseMove(e: MouseEvent) {
    if (this.isDragging) {
      this.panOffset.set({
        x: e.clientX - this.dragStart.x,
        y: e.clientY - this.dragStart.y,
      });
    }

    // Convert screen coordinates to port local metric coordinates
    const rect = this.canvasRef.nativeElement.getBoundingClientRect();
    const screenX = e.clientX - rect.left;
    const screenY = e.clientY - rect.top;
    const zoom = this.zoomLevel();
    const pan = this.panOffset();

    const localX = (screenX - pan.x) / zoom;
    const localY = (screenY - pan.y) / zoom;

    this.cursorLocal.set({ x: localX, y: localY });
    const wgs = this.geo.localToWgs84({ x: localX, y: localY });
    this.cursorWgs.set({ lat: wgs.latitude, lon: wgs.longitude });

    // Check hover targets
    this.checkHover(localX, localY, screenX, screenY);
  }

  onMouseUp() {
    this.isDragging = false;
  }

  onWheel(e: WheelEvent) {
    e.preventDefault();
    const factor = e.deltaY < 0 ? 1.12 : 0.89;
    this.zoomLevel.update((z) => Math.max(0.25, Math.min(4.5, z * factor)));
  }

  onClick(e: MouseEvent) {
    const rect = this.canvasRef.nativeElement.getBoundingClientRect();
    const screenX = e.clientX - rect.left;
    const screenY = e.clientY - rect.top;
    const zoom = this.zoomLevel();
    const pan = this.panOffset();
    const localX = (screenX - pan.x) / zoom;
    const localY = (screenY - pan.y) / zoom;

    if (this.portEngine.editorModeActive() && this.portEngine.activeEditorTool()) {
      const tool = this.portEngine.activeEditorTool()!;
      if (tool === 'CRANE' || tool === 'YARD') {
        this.portEngine.commitEditorAddition(tool, { x: localX, y: localY });
      }
      return;
    }

    // 1. Check STS Cranes click
    for (const crane of this.portEngine.cranes()) {
      if (Math.abs(localX - crane.gantryPosM) < 40 && Math.abs(localY - 150) < 45) {
        this.portEngine.selectAsset('CRANE', crane.id);
        return;
      }
    }

    // 2. Check Vessels click
    for (const vessel of this.portEngine.vessels()) {
      if (
        localX >= vessel.position.x - vessel.lengthM / 2 &&
        localX <= vessel.position.x + vessel.lengthM / 2 &&
        Math.abs(localY - vessel.position.y) < 40
      ) {
        this.portEngine.selectAsset('VESSEL', vessel.imo.toString());
        return;
      }
    }

    // 3. Check Yard Blocks click
    for (const block of this.portEngine.yardBlocks()) {
      if (
        localX >= block.position.x &&
        localX <= block.position.x + block.widthM &&
        localY >= block.position.y &&
        localY <= block.position.y + block.lengthM
      ) {
        this.portEngine.selectAsset('YARD_BLOCK', block.id);
        return;
      }
    }

    // 4. Check Rail Trains click
    for (const train of this.portEngine.railTrains()) {
      if (Math.abs(localX - train.position.x) < 250 && Math.abs(localY - train.position.y) < 30) {
        this.portEngine.selectAsset('TRAIN', train.id);
        return;
      }
    }

    // 5. Check Vehicles click
    for (const v of this.portEngine.vehicles()) {
      if (Math.abs(localX - v.position.x) < 25 && Math.abs(localY - v.position.y) < 18) {
        this.portEngine.selectAsset('VEHICLE', v.id);
        return;
      }
    }

    // Clear selection if empty space clicked
    this.portEngine.clearSelection();
  }

  private checkHover(localX: number, localY: number, screenX: number, screenY: number) {
    // Cranes
    for (const crane of this.portEngine.cranes()) {
      if (Math.abs(localX - crane.gantryPosM) < 35 && Math.abs(localY - 150) < 40) {
        this.hoverInfo.set({
          screenX,
          screenY,
          title: crane.name,
          type: 'STS CRANE',
          subtitle: `Mode: ${crane.mode} | Moves: ${crane.movesCompletedShift}`,
          stats: `Power: ${Math.round(crane.currentPowerKw)}kW | Cycle: ${crane.avgCycleTimeSec}s`,
        });
        return;
      }
    }

    // Vessels
    for (const vessel of this.portEngine.vessels()) {
      if (
        localX >= vessel.position.x - vessel.lengthM / 2 &&
        localX <= vessel.position.x + vessel.lengthM / 2 &&
        Math.abs(localY - vessel.position.y) < 35
      ) {
        this.hoverInfo.set({
          screenX,
          screenY,
          title: vessel.name,
          type: 'CONTAINER VESSEL',
          subtitle: `IMO: ${vessel.imo} | Flag: ${vessel.flag} | ${vessel.lengthM}m`,
          stats: `Discharge: ${vessel.containersDischarged}/${vessel.containersToDischarge} TEU | Status: ${vessel.status}`,
        });
        return;
      }
    }

    // Yard Blocks
    for (const block of this.portEngine.yardBlocks()) {
      if (
        localX >= block.position.x &&
        localX <= block.position.x + block.widthM &&
        localY >= block.position.y &&
        localY <= block.position.y + block.lengthM
      ) {
        const pct = Math.round((block.occupiedSlots / block.totalCapacity) * 100);
        this.hoverInfo.set({
          screenX,
          screenY,
          title: block.name,
          type: 'YARD STACK',
          subtitle: `${block.baysCount} Bays × ${block.rowsCount} Rows × ${block.maxTiers} Tiers`,
          stats: `Occupancy: ${block.occupiedSlots}/${block.totalCapacity} TEU (${pct}%) | RMG: ${block.assignedRmgId}`,
        });
        return;
      }
    }

    this.hoverInfo.set(null);
  }

  private startRenderLoop() {
    const loop = () => {
      this.render();
      requestAnimationFrame(loop);
    };
    requestAnimationFrame(loop);
  }

  private render() {
    if (!this.ctx) return;
    const canvas = this.canvasRef.nativeElement;
    const width = canvas.width / window.devicePixelRatio;
    const height = canvas.height / window.devicePixelRatio;
    const ctx = this.ctx;

    ctx.clearRect(0, 0, width, height);

    // Background water & land
    const zoom = this.zoomLevel();
    const pan = this.panOffset();
    const is3D = this.portEngine.viewMode() === '3D_ISOMETRIC';
    const isEngineering = this.portEngine.activeLod() === 'ENGINEERING_VIEW';

    this.waterOffset += 0.4;

    ctx.save();
    ctx.translate(pan.x, pan.y);
    ctx.scale(zoom, zoom);

    // 1. Draw Water Channel & Navigational Fairway
    ctx.fillStyle = '#082f49'; // Deep marine water
    ctx.fillRect(-600, -300, 2800, 450);

    // Water wave patterns
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.12)';
    ctx.lineWidth = 1.5;
    for (let wy = -250; wy < 130; wy += 40) {
      ctx.beginPath();
      for (let wx = -500; wx < 2200; wx += 60) {
        const offset = Math.sin((wx + this.waterOffset * 5) * 0.02) * 6;
        ctx.lineTo(wx, wy + offset);
      }
      ctx.stroke();
    }

    // Navigation Fairway Channel Buoys & Safety Lines
    ctx.strokeStyle = 'rgba(234, 179, 8, 0.4)';
    ctx.setLineDash([12, 12]);
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(-500, -100);
    ctx.lineTo(2100, -100);
    ctx.stroke();
    ctx.setLineDash([]);

    // 2. Draw Terminal Quay & Landmass
    ctx.fillStyle = '#0f172a'; // Deep asphalt / concrete terminal apron
    ctx.fillRect(-200, 150, 2000, 750);

    // Quay wall edge
    ctx.fillStyle = '#e2e8f0';
    ctx.fillRect(-100, 146, 1650, 8);
    // Yellow/black warning hazard stripes along bollard line
    ctx.fillStyle = '#eab308';
    for (let k = -100; k < 1550; k += 24) {
      ctx.fillRect(k, 146, 12, 8);
    }

    // 3. Draw Berths & Bollards
    const berths = this.portEngine.portConfig().berths;
    ctx.font = 'bold 12px "JetBrains Mono", monospace';
    berths.forEach((berth) => {
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.3)';
      ctx.lineWidth = 1;
      ctx.strokeRect(berth.bollardStartM, 146, berth.lengthM, 20);

      ctx.fillStyle = '#38bdf8';
      ctx.fillText(`⚓ ${berth.name} (${berth.lengthM}m / Max Draft ${berth.maxDraftM}m)`, berth.bollardStartM + 12, 172);

      // Bollards every 25m
      ctx.fillStyle = '#64748b';
      for (let bx = berth.bollardStartM; bx <= berth.bollardEndM; bx += 25) {
        ctx.beginPath();
        ctx.arc(bx, 150, 2.5, 0, Math.PI * 2);
        ctx.fill();
      }
    });

    // 4. Draw STS Crane Rail Tracks along Quay
    ctx.strokeStyle = '#475569';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(-50, 154);
    ctx.lineTo(1550, 154);
    ctx.moveTo(-50, 185);
    ctx.lineTo(1550, 185);
    ctx.stroke();

    // 5. Draw Road Networks & AGV Transfer Lanes
    ctx.fillStyle = '#1e293b'; // AGV lane
    ctx.fillRect(-50, 186, 1600, 36);

    ctx.fillStyle = '#334155'; // Main perimeter road
    ctx.fillRect(-100, 224, 1700, 32);

    // Lane dashes
    ctx.strokeStyle = '#94a3b8';
    ctx.setLineDash([8, 8]);
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(-100, 240);
    ctx.lineTo(1600, 240);
    ctx.stroke();
    ctx.setLineDash([]);

    // 6. Draw Yard Blocks & Container Stacks
    if (this.showYard()) {
      for (const block of this.portEngine.yardBlocks()) {
        this.renderYardBlock(ctx, block, is3D);
      }
    }

    // 7. Draw Intermodal Rail Lines & Freight Trains
    if (this.showRail()) {
      this.renderRailNetwork(ctx);
    }

    // 8. Draw Vessels Moored and Approaching
    for (const vessel of this.portEngine.vessels()) {
      this.renderVessel(ctx, vessel);
    }

    // 9. Draw Ship-to-Shore (STS) Cranes
    if (this.showCranes()) {
      for (const crane of this.portEngine.cranes()) {
        this.renderCrane(ctx, crane);
      }
    }

    // 10. Draw AGVs & Terminal Trucks
    if (this.showVehicles()) {
      for (const vehicle of this.portEngine.vehicles()) {
        this.renderVehicle(ctx, vehicle);
      }
    }

    // 11. Engineering Dimension Lines Overlay if in Blueprint Mode
    if (isEngineering) {
      this.renderEngineeringDimensions(ctx);
    }

    // 12. Draw Selected Asset Highlight
    const sel = this.portEngine.selectedAsset();
    if (sel && sel.data && typeof sel.data === 'object') {
      const d = sel.data as Record<string, unknown>;
      let targetX: number | null = null;
      let targetY: number | null = null;

      if (d['position'] && typeof d['position'] === 'object') {
        const pos = d['position'] as { x?: number; y?: number };
        if (typeof pos.x === 'number' && typeof pos.y === 'number') {
          targetX = pos.x;
          targetY = pos.y;
        }
      } else if (typeof d['gantryPosM'] === 'number') {
        targetX = d['gantryPosM'] as number;
        targetY = 150;
      }

      if (targetX !== null && targetY !== null) {
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(targetX, targetY, 45, 0, Math.PI * 2);
        ctx.stroke();
      }
    }

    ctx.restore();

    // Radar / Minimap overlay
    this.renderMiniRadar(ctx, width, height);
  }

  private renderVessel(ctx: CanvasRenderingContext2D, v: Vessel) {
    const x = v.position.x;
    const y = v.position.y;
    const halfL = v.lengthM / 2;
    const halfW = v.beamM / 2;

    ctx.save();
    ctx.translate(x, y);
    ctx.rotate((v.headingDeg - 90) * (Math.PI / 180));

    // Ship Hull Outline
    ctx.fillStyle = v.status === 'BERTHED' || v.status === 'UNLOADING' ? '#1e293b' : '#334155';
    ctx.strokeStyle = '#0284c7';
    ctx.lineWidth = 2;

    ctx.beginPath();
    ctx.moveTo(halfL, 0); // Bow point
    ctx.lineTo(halfL - 45, -halfW);
    ctx.lineTo(-halfL + 20, -halfW);
    ctx.lineTo(-halfL, -halfW + 15);
    ctx.lineTo(-halfL, halfW - 15);
    ctx.lineTo(-halfL + 20, halfW);
    ctx.lineTo(halfL - 45, halfW);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Bulbous bow & wake waves if moving
    if (v.speedKnots > 0.5) {
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(halfL + 10, 0, 18, -Math.PI / 2, Math.PI / 2);
      ctx.stroke();
    }

    // Deck container bay stacks
    const bayCount = 14;
    const bayW = (v.lengthM - 120) / bayCount;
    const colors = ['#dc2626', '#2563eb', '#16a34a', '#d97706', '#9333ea'];

    for (let b = 0; b < bayCount; b++) {
      const bx = -halfL + 50 + b * bayW;
      const progressDischarge = v.containersDischarged / (v.containersToDischarge || 1);
      if (b < 4 && progressDischarge > 0.6) continue;

      ctx.fillStyle = colors[b % colors.length];
      ctx.fillRect(bx, -halfW + 6, bayW - 4, v.beamM - 12);
      ctx.strokeStyle = 'rgba(0,0,0,0.4)';
      ctx.strokeRect(bx, -halfW + 6, bayW - 4, v.beamM - 12);
    }

    // Superstructure / Bridge & Funnel at stern
    ctx.fillStyle = '#f8fafc';
    ctx.fillRect(-halfL + 25, -halfW + 10, 22, v.beamM - 20);
    ctx.fillStyle = '#dc2626'; // Funnel
    ctx.fillRect(-halfL + 16, -6, 8, 12);

    // Vessel Name Tag
    ctx.font = 'bold 11px "JetBrains Mono", monospace';
    ctx.fillStyle = '#ffffff';
    ctx.fillText(v.name, -halfL + 60, 4);

    ctx.restore();
  }

  private renderCrane(ctx: CanvasRenderingContext2D, c: Crane) {
    const x = c.gantryPosM;
    const y = 150;

    ctx.save();
    ctx.translate(x, y);

    // Crane Gantry Base on rails
    ctx.fillStyle = '#f59e0b';
    ctx.fillRect(-14, 0, 28, 36);

    // Gantry Legs
    ctx.strokeStyle = '#d97706';
    ctx.lineWidth = 4;
    ctx.strokeRect(-14, 0, 28, 36);

    // Waterside Outreach Boom
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(0, 15);
    ctx.lineTo(0, -65);
    ctx.stroke();

    // Landside Backreach
    ctx.beginPath();
    ctx.moveTo(0, 15);
    ctx.lineTo(0, 50);
    ctx.stroke();

    // Moving Trolley along Boom
    const trolleyY = -60 + (c.trolleyPosM / 70) * 105;
    ctx.fillStyle = '#dc2626';
    ctx.fillRect(-6, trolleyY - 4, 12, 8);

    // Hoist Cable and Spreader
    const hoistLength = 10 + (c.hoistHeightM / 30) * 20;
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(0, trolleyY);
    ctx.lineTo(0, trolleyY + hoistLength);
    ctx.stroke();

    // Spreader bar
    ctx.fillStyle = c.spreaderLatched ? '#22c55e' : '#e2e8f0';
    ctx.fillRect(-8, trolleyY + hoistLength, 16, 4);

    // Latched Container if active
    if (c.spreaderLatched) {
      ctx.fillStyle = '#2563eb';
      ctx.fillRect(-9, trolleyY + hoistLength + 4, 18, 9);
      ctx.strokeStyle = '#ffffff';
      ctx.strokeRect(-9, trolleyY + hoistLength + 4, 18, 9);
    }

    // Crane ID label
    ctx.font = 'bold 10px "JetBrains Mono", monospace';
    ctx.fillStyle = '#0f172a';
    ctx.fillText(c.id, -12, 22);

    // Status Indicator Light
    ctx.fillStyle = c.mode === 'DISCHARGING' || c.mode === 'LOADING' ? '#22c55e' : c.mode === 'MAINTENANCE' ? '#ef4444' : '#eab308';
    ctx.beginPath();
    ctx.arc(0, 5, 3, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }

  private renderYardBlock(ctx: CanvasRenderingContext2D, b: YardBlock, is3D: boolean) {
    ctx.save();
    ctx.translate(b.position.x, b.position.y);

    // Yard Block Pad Base
    ctx.fillStyle = b.type === 'REEFER' ? '#083344' : b.type === 'HAZMAT' ? '#450a0a' : '#1e293b';
    ctx.fillRect(0, 0, b.widthM, b.lengthM);

    ctx.strokeStyle = b.type === 'REEFER' ? '#06b6d4' : b.type === 'HAZMAT' ? '#ef4444' : '#475569';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(0, 0, b.widthM, b.lengthM);

    // Stacking Bays Grid
    const bayWidth = b.widthM / b.baysCount;
    const rowHeight = b.lengthM / b.rowsCount;

    // Draw stacked container voxels
    const colors = ['#2563eb', '#dc2626', '#16a34a', '#d97706', '#9333ea', '#0891b2'];
    for (let bay = 0; bay < b.baysCount; bay++) {
      for (let row = 0; row < b.rowsCount; row++) {
        const seed = (bay * 7 + row * 13) % 100;
        if (seed < 75) {
          const tier = 1 + (seed % b.maxTiers);
          const cx = bay * bayWidth + 1;
          const cy = row * rowHeight + 1;
          const cw = bayWidth - 2;
          const ch = rowHeight - 2;

          ctx.fillStyle = colors[(bay + row) % colors.length];
          ctx.fillRect(cx, cy, cw, ch);

          if (is3D && tier > 1) {
            ctx.fillStyle = `rgba(255, 255, 255, ${tier * 0.1})`;
            ctx.fillRect(cx, cy, cw, 2);
            ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
            ctx.fillRect(cx, cy + ch - 2, cw, 2);
          }
        }
      }
    }

    // RMG Crane Gantry Rails on Yard Block
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 2;
    ctx.strokeRect(-2, -3, b.widthM + 4, b.lengthM + 6);

    // Block ID Label
    ctx.font = 'bold 11px "JetBrains Mono", monospace';
    ctx.fillStyle = '#f8fafc';
    ctx.fillText(`${b.blockCode} (${Math.round((b.occupiedSlots / b.totalCapacity) * 100)}%)`, 6, -6);

    ctx.restore();
  }

  private renderVehicle(ctx: CanvasRenderingContext2D, v: Vehicle) {
    ctx.save();
    ctx.translate(v.position.x, v.position.y);
    ctx.rotate((v.headingDeg - 90) * (Math.PI / 180));

    // Vehicle Chassis
    ctx.fillStyle = v.type === 'AGV' ? '#0284c7' : '#ea580c';
    ctx.fillRect(-10, -5, 20, 10);

    // Wheels
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(-9, -6, 5, 2);
    ctx.fillRect(4, -6, 5, 2);
    ctx.fillRect(-9, 4, 5, 2);
    ctx.fillRect(4, 4, 5, 2);

    // Container on chassis
    if (v.assignedContainerId) {
      ctx.fillStyle = '#2563eb';
      ctx.fillRect(-8, -4, 16, 8);
      ctx.strokeStyle = '#ffffff';
      ctx.strokeRect(-8, -4, 16, 8);
    }

    ctx.restore();
  }

  private renderRailNetwork(ctx: CanvasRenderingContext2D) {
    // 4 Parallel Rail Tracks
    for (let r = 0; r < 4; r++) {
      const ry = 680 + r * 22;
      // Sleepers
      ctx.fillStyle = '#78350f';
      for (let s = -100; s < 1550; s += 8) {
        ctx.fillRect(s, ry - 3, 3, 14);
      }
      // Steel Rails
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(-100, ry);
      ctx.lineTo(1550, ry);
      ctx.moveTo(-100, ry + 8);
      ctx.lineTo(1550, ry + 8);
      ctx.stroke();
    }

    // Rail Freight Trains
    for (const t of this.portEngine.railTrains()) {
      ctx.save();
      ctx.translate(t.position.x, t.position.y);

      // Locomotive
      ctx.fillStyle = '#dc2626';
      ctx.fillRect(0, -6, 32, 16);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(22, -4, 6, 12);

      // Wagons with containers
      const wagonCount = 14;
      for (let w = 1; w <= wagonCount; w++) {
        const wx = -w * 28;
        ctx.fillStyle = '#334155';
        ctx.fillRect(wx, -5, 24, 14);
        ctx.fillStyle = w % 2 === 0 ? '#2563eb' : '#16a34a';
        ctx.fillRect(wx + 2, -4, 20, 12);
      }

      ctx.font = 'bold 10px "JetBrains Mono", monospace';
      ctx.fillStyle = '#f8fafc';
      ctx.fillText(`🚆 ${t.trainNumber}`, 40, 5);

      ctx.restore();
    }
  }

  private renderEngineeringDimensions(ctx: CanvasRenderingContext2D) {
    ctx.strokeStyle = '#f43f5e';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([4, 4]);

    // Quay Total Length Caliper
    ctx.beginPath();
    ctx.moveTo(0, 120);
    ctx.lineTo(1450, 120);
    ctx.stroke();
    ctx.setLineDash([]);

    ctx.font = 'bold 12px "JetBrains Mono", monospace';
    ctx.fillStyle = '#f43f5e';
    ctx.fillText('◄── QUAY OVERALL LENGTH: 1,450.0 METRES ──►', 520, 114);

    // Berth 1 Caliper
    ctx.strokeRect(0, 135, 450, 8);
    ctx.fillText('◄─ BERTH 01: 450m ─►', 140, 132);
  }

  private renderMiniRadar(ctx: CanvasRenderingContext2D, w: number, h: number) {
    const miniW = 160;
    const miniH = 100;
    const miniX = w - miniW - 16;
    const miniY = h - miniH - 16;

    ctx.save();
    ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.5)';
    ctx.lineWidth = 1.5;
    ctx.fillRect(miniX, miniY, miniW, miniH);
    ctx.strokeRect(miniX, miniY, miniW, miniH);

    // Radar beam sweep
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.2)';
    ctx.beginPath();
    ctx.arc(miniX + miniW / 2, miniY + miniH / 2, 40, 0, Math.PI * 2);
    ctx.stroke();

    // Mini Vessel Blips
    for (const v of this.portEngine.vessels()) {
      const bx = miniX + (v.position.x / 1800) * miniW;
      const by = miniY + ((v.position.y + 100) / 900) * miniH;
      ctx.fillStyle = '#38bdf8';
      ctx.beginPath();
      ctx.arc(bx, by, 2.5, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.font = '9px "JetBrains Mono", monospace';
    ctx.fillStyle = '#38bdf8';
    ctx.fillText('TACTICAL RADAR', miniX + 8, miniY + 12);

    ctx.restore();
  }
}
