import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PortEngineService } from '../../services/port-engine.service';
import { ScenarioLab } from '../scenario-lab/scenario-lab';
import { GeospatialEditor } from '../geospatial-editor/geospatial-editor';
import { PortEventLog } from '../../models/port.models';

@Component({
  selector: 'app-telemetry-dock',
  imports: [CommonModule, ScenarioLab, GeospatialEditor],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-64 bg-[#0F0F0F] border-t border-zinc-800 flex flex-col z-20 text-zinc-300 select-none font-sans">
      <!-- Tabs Navigation Bar -->
      <div class="h-9 border-b border-zinc-800 px-4 flex items-center justify-between bg-[#0A0A0A]">
        <div class="flex items-center gap-1 font-mono">
          @for (tab of tabs; track tab.id) {
            <button
              (click)="activeTab.set(tab.id)"
              [class.bg-[#0F0F0F]]="activeTab() === tab.id"
              [class.text-white]="activeTab() === tab.id"
              [class.border-emerald-500]="activeTab() === tab.id"
              [class.text-zinc-500]="activeTab() !== tab.id"
              class="px-3 py-1.5 rounded-t text-xs font-semibold flex items-center gap-1.5 border-b-2 border-transparent hover:text-zinc-200 transition"
            >
              <span class="material-icons text-sm">{{ tab.icon }}</span>
              <span>{{ tab.label }}</span>
              @if (tab.badge) {
                <span
                  class="px-1.5 py-0.2 rounded text-[9px] border font-mono uppercase"
                  [class.bg-emerald-500/10]="activeTab() === tab.id"
                  [class.text-emerald-400]="activeTab() === tab.id"
                  [class.border-emerald-500/30]="activeTab() === tab.id"
                  [class.bg-zinc-900]="activeTab() !== tab.id"
                  [class.text-zinc-500]="activeTab() !== tab.id"
                  [class.border-zinc-800]="activeTab() !== tab.id"
                >
                  {{ tab.badge }}
                </span>
              }
            </button>
          }
        </div>

        <!-- Global Telemetry Status Badges -->
        <div class="hidden sm:flex items-center gap-4 text-[10px] font-mono">
          <div class="flex items-center gap-1.5 text-zinc-400">
            <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            <span>RUST CORE: <span class="text-white">60 FPS</span></span>
          </div>
          <div class="flex items-center gap-1.5 text-zinc-400">
            <span class="w-1.5 h-1.5 rounded-full bg-sky-500"></span>
            <span>PYTHON AI: <span class="text-white">MIP OPTIMAL</span></span>
          </div>
          <div class="flex items-center gap-1.5 text-zinc-400">
            <span class="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
            <span>POSTGIS 3.4 SPATIAL</span>
          </div>
        </div>
      </div>

      <!-- Tab Contents -->
      <div class="flex-1 overflow-hidden bg-[#0A0A0A]">
        <!-- 1. LIVE OPERATIONS & EVENT STREAM -->
        @if (activeTab() === 'EVENTS') {
          <div class="h-full flex flex-col p-3 overflow-hidden text-xs">
            <div class="flex items-center justify-between pb-2 border-b border-zinc-800">
              <div class="flex items-center gap-2">
                <span class="font-bold text-white uppercase tracking-wider font-mono text-xs">Terminal Event Log</span>
                <span class="text-zinc-500 text-[10px] font-mono hidden md:inline">Synchronized TOS & sensor stream</span>
              </div>
              <div class="flex items-center gap-2">
                <input
                  type="text"
                  placeholder="FILTER EVENTS (CRANE, VESSEL, AGV)..."
                  [value]="eventFilter()"
                  (input)="onFilterChange($event)"
                  class="bg-zinc-900 border border-zinc-800 px-2 py-1 rounded text-[11px] font-mono text-zinc-200 placeholder-zinc-600 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>
            </div>

            <div class="flex-1 overflow-y-auto space-y-1 pt-2 font-mono text-[10px]">
              @for (ev of filteredEvents(); track ev.id) {
                <div
                  class="flex items-center justify-between p-1.5 rounded bg-zinc-900/40 hover:bg-zinc-900 border border-zinc-800/80 transition"
                >
                  <div class="flex items-center gap-2.5">
                    <span class="text-zinc-500 font-mono">[{{ ev.timestamp }}]</span>
                    <span
                      class="px-1.5 py-0.2 rounded text-[9px] font-bold border font-mono"
                      [class.bg-sky-500/10]="ev.assetType === 'SHIP_TO_SHORE_CRANE'"
                      [class.text-sky-400]="ev.assetType === 'SHIP_TO_SHORE_CRANE'"
                      [class.border-sky-500/30]="ev.assetType === 'SHIP_TO_SHORE_CRANE'"
                      [class.bg-emerald-500/10]="ev.assetType === 'CONTAINER_VESSEL'"
                      [class.text-emerald-400]="ev.assetType === 'CONTAINER_VESSEL'"
                      [class.border-emerald-500/30]="ev.assetType === 'CONTAINER_VESSEL'"
                      [class.bg-purple-500/10]="ev.assetType === 'YARD_BLOCK'"
                      [class.text-purple-400]="ev.assetType === 'YARD_BLOCK'"
                      [class.border-purple-500/30]="ev.assetType === 'YARD_BLOCK'"
                      [class.bg-amber-500/10]="ev.assetType === 'AUTOMATED_GUIDED_VEHICLE'"
                      [class.text-amber-400]="ev.assetType === 'AUTOMATED_GUIDED_VEHICLE'"
                      [class.border-amber-500/30]="ev.assetType === 'AUTOMATED_GUIDED_VEHICLE'"
                      [class.bg-red-500/10]="ev.severity === 'ALERT'"
                      [class.text-red-400]="ev.severity === 'ALERT'"
                      [class.border-red-500/30]="ev.severity === 'ALERT'"
                    >
                      {{ ev.assetType }}
                    </span>
                    <span class="font-bold text-white">{{ ev.assetId }}:</span>
                    <span class="text-zinc-300">{{ ev.message }}</span>
                  </div>
                  <div class="text-[9px] text-zinc-500 font-mono">{{ ev.location }}</div>
                </div>
              }
            </div>
          </div>
        }

        <!-- 2. WHAT-IF SCENARIO LAB -->
        @if (activeTab() === 'SCENARIOS') {
          <div class="h-full overflow-y-auto">
            <app-scenario-lab></app-scenario-lab>
          </div>
        }

        <!-- 3. GEOSPATIAL DESIGNER -->
        @if (activeTab() === 'DESIGNER') {
          <div class="h-full overflow-y-auto">
            <app-geospatial-editor></app-geospatial-editor>
          </div>
        }

        <!-- 4. GREEN PORT & DECARBONIZATION -->
        @if (activeTab() === 'GREEN') {
          <div class="h-full p-3 overflow-y-auto text-xs space-y-3 font-sans">
            <div class="flex items-center justify-between">
              <h2 class="font-bold text-xs text-white uppercase font-mono tracking-wider">
                Decarbonization & Green Port Intelligence
              </h2>
              <span class="text-zinc-500 text-[10px] font-mono">ISO 14064 Carbon Footprint & Cold-Ironing Grid</span>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-4 gap-2">
              <div class="bg-zinc-900 p-2.5 rounded border border-zinc-800 space-y-1">
                <div class="text-zinc-500 text-[10px] uppercase font-mono">Shore Power (Cold Ironing)</div>
                <div class="font-mono text-xl font-light text-white">3<span class="text-xs text-emerald-400 ml-1">/ 3 Berth</span></div>
                <p class="text-[10px] text-zinc-400 font-mono">-14.2 T CO₂/day via grid hookup.</p>
              </div>
              <div class="bg-zinc-900 p-2.5 rounded border border-zinc-800 space-y-1">
                <div class="text-zinc-500 text-[10px] uppercase font-mono">Avg Energy / Lift</div>
                <div class="font-mono text-xl font-light text-white">3.24<span class="text-xs text-emerald-400 ml-1">kWh</span></div>
                <p class="text-[10px] text-zinc-400 font-mono">Regenerative hoist braking active.</p>
              </div>
              <div class="bg-zinc-900 p-2.5 rounded border border-zinc-800 space-y-1">
                <div class="text-zinc-500 text-[10px] uppercase font-mono">Electrified Fleet</div>
                <div class="font-mono text-xl font-light text-white">88<span class="text-xs text-emerald-400 ml-1">%</span></div>
                <p class="text-[10px] text-zinc-400 font-mono">Autonomous battery swap bays.</p>
              </div>
              <div class="bg-zinc-900 p-2.5 rounded border border-zinc-800 space-y-1">
                <div class="text-zinc-500 text-[10px] uppercase font-mono">Intermodal Split</div>
                <div class="font-mono text-xl font-light text-white">38<span class="text-xs text-cyan-400 ml-1">% Rail</span></div>
                <p class="text-[10px] text-zinc-400 font-mono">&gt;50% non-road hinterland logistics.</p>
              </div>
            </div>
          </div>
        }

        <!-- 5. TIME MACHINE REPLAY -->
        @if (activeTab() === 'REPLAY') {
          <div class="h-full p-4 flex flex-col justify-between text-xs select-none font-mono">
            <div class="flex items-center justify-between">
              <div>
                <span class="font-bold text-xs text-white uppercase tracking-wider">Digital Twin 24H Timeline Replay</span>
                <p class="text-[10px] text-zinc-500">Scrub across operational records to analyze bottlenecks and incident root causes.</p>
              </div>
              <div class="font-mono text-xs font-bold text-emerald-400">
                {{ portEngine.simulationTime() | date:'yyyy-MM-dd HH:mm:ss' }} UTC
              </div>
            </div>

            <div class="space-y-1 py-2">
              <input
                type="range"
                min="0"
                max="86400"
                value="43200"
                class="w-full h-1 bg-zinc-800 rounded appearance-none cursor-pointer accent-emerald-500"
              />
              <div class="flex justify-between text-[9px] font-mono text-zinc-500">
                <span>00:00 [NIGHT]</span>
                <span>06:00 [DAWN INBOUND]</span>
                <span>12:00 [PEAK QUAY]</span>
                <span>18:00 [INTERMODAL RAIL]</span>
                <span>23:59 [HANDOVER]</span>
              </div>
            </div>

            <div class="flex items-center justify-center gap-3">
              <button class="px-3 py-1 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 rounded font-mono text-xs text-zinc-300 flex items-center gap-1">
                <span class="material-icons text-sm">fast_rewind</span>
                -1 Hour
              </button>
              <button
                (click)="portEngine.toggleSimulation()"
                class="px-4 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded font-mono text-xs flex items-center gap-1.5 shadow"
              >
                <span class="material-icons text-sm">{{ portEngine.isSimulationRunning() ? 'pause' : 'play_arrow' }}</span>
                {{ portEngine.isSimulationRunning() ? 'PAUSE' : 'PLAY' }}
              </button>
              <button class="px-3 py-1 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 rounded font-mono text-xs text-zinc-300 flex items-center gap-1">
                +1 Hour
                <span class="material-icons text-sm">fast_forward</span>
              </button>
            </div>
          </div>
        }
      </div>
    </div>
  `,
})
export class TelemetryDock {
  readonly portEngine = inject(PortEngineService);
  readonly activeTab = signal<'EVENTS' | 'SCENARIOS' | 'DESIGNER' | 'GREEN' | 'REPLAY'>('EVENTS');
  readonly eventFilter = signal<string>('');

  readonly tabs = [
    { id: 'EVENTS' as const, label: 'Live Operations Log', icon: 'list_alt', badge: 'Active' },
    { id: 'SCENARIOS' as const, label: 'What-If Scenarios', icon: 'psychology', badge: 'MIP' },
    { id: 'DESIGNER' as const, label: 'GIS Layout Designer', icon: 'architecture', badge: 'PostGIS' },
    { id: 'GREEN' as const, label: 'Green Port Telemetry', icon: 'eco', badge: 'Green' },
    { id: 'REPLAY' as const, label: 'Time Machine Replay', icon: 'history', badge: '24h' },
  ];

  filteredEvents(): PortEventLog[] {
    const filter = this.eventFilter().toLowerCase();
    const events = this.portEngine.eventLogs();
    if (!filter) return events;
    return events.filter(
      (e: PortEventLog) =>
        e.assetType?.toLowerCase().includes(filter) ||
        e.assetId?.toLowerCase().includes(filter) ||
        e.message?.toLowerCase().includes(filter) ||
        e.severity?.toLowerCase().includes(filter)
    );
  }

  onFilterChange(event: Event) {
    this.eventFilter.set((event.target as HTMLInputElement).value);
  }
}

