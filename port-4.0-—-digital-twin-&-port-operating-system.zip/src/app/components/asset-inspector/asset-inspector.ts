import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PortEngineService } from '../../services/port-engine.service';
import { Crane, Container, Vessel, YardBlock } from '../../models/port.models';

@Component({
  selector: 'app-asset-inspector',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (portEngine.selectedAsset()) {
      <div
        class="w-80 md:w-96 bg-[#0F0F0F] border-l border-zinc-800 h-full flex flex-col shadow-2xl z-20 text-zinc-300 overflow-hidden select-none font-sans"
      >
        <!-- Header -->
        <div class="p-3.5 border-b border-zinc-800 flex items-center justify-between bg-[#0A0A0A]">
          <div class="flex items-center gap-2.5">
            <div class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
            <div>
              <div class="text-[9px] uppercase font-mono tracking-widest text-zinc-500">
                {{ portEngine.selectedAsset()?.type }} TELEMETRY
              </div>
              <div class="font-bold text-sm text-white font-mono">
                {{ portEngine.selectedAsset()?.id }}
              </div>
            </div>
          </div>
          <button
            (click)="portEngine.clearSelection()"
            class="p-1 rounded text-zinc-400 hover:text-white hover:bg-zinc-800 transition"
          >
            <span class="material-icons text-sm">close</span>
          </button>
        </div>

        <!-- Body Content based on Asset Type -->
        <div class="flex-1 overflow-y-auto p-4 space-y-4 text-xs">
          <!-- 1. CRANE INSPECTION -->
          @if (asCrane(portEngine.selectedAsset()?.data); as crane) {
            <div class="bg-zinc-900/70 p-3 rounded border border-zinc-800 space-y-2.5">
              <div class="flex justify-between items-center">
                <span class="text-zinc-500 font-mono text-[10px] uppercase">Operational Mode</span>
                <span
                  class="px-1.5 py-0.5 rounded text-[9px] font-mono font-bold uppercase border"
                  [class.bg-emerald-500/10]="crane.mode === 'DISCHARGING' || crane.mode === 'LOADING'"
                  [class.text-emerald-400]="crane.mode === 'DISCHARGING' || crane.mode === 'LOADING'"
                  [class.border-emerald-500/30]="crane.mode === 'DISCHARGING' || crane.mode === 'LOADING'"
                  [class.bg-red-500/10]="crane.mode === 'MAINTENANCE' || crane.mode === 'FAULT'"
                  [class.text-red-400]="crane.mode === 'MAINTENANCE' || crane.mode === 'FAULT'"
                  [class.border-red-500/30]="crane.mode === 'MAINTENANCE' || crane.mode === 'FAULT'"
                  [class.bg-amber-500/10]="crane.mode === 'IDLE' || crane.mode === 'HIGH_WIND_LOCK'"
                  [class.text-amber-400]="crane.mode === 'IDLE' || crane.mode === 'HIGH_WIND_LOCK'"
                  [class.border-amber-500/30]="crane.mode === 'IDLE' || crane.mode === 'HIGH_WIND_LOCK'"
                >
                  {{ crane.mode }}
                </span>
              </div>
              <div class="flex justify-between font-mono text-[11px]">
                <span class="text-zinc-500">Assigned Berth:</span>
                <span class="font-semibold text-zinc-200">{{ crane.berthId || 'Standby' }}</span>
              </div>
              <div class="flex justify-between font-mono text-[11px]">
                <span class="text-zinc-500">Moves (Shift):</span>
                <span class="font-bold text-white">{{ crane.movesCompletedShift }} <span class="text-emerald-400 text-[10px]">TEU</span></span>
              </div>
              <div class="flex justify-between font-mono text-[11px]">
                <span class="text-zinc-500">Avg Cycle Time:</span>
                <span class="text-zinc-200">{{ crane.avgCycleTimeSec }} sec</span>
              </div>
            </div>

            <!-- Position & Telemetry Metrics Grid -->
            <div class="space-y-2">
              <h2 class="text-[10px] uppercase tracking-widest text-zinc-500 font-mono">Terminal Telemetry</h2>
              <div class="grid grid-cols-2 gap-2">
                <div class="bg-zinc-900 p-2 border border-zinc-800 rounded">
                  <div class="text-[10px] text-zinc-500 uppercase font-mono">Power Draw</div>
                  <div class="text-lg font-light text-white font-mono mt-0.5">{{ Math.round(crane.currentPowerKw) }}<span class="text-xs text-amber-400 ml-1">kW</span></div>
                </div>
                <div class="bg-zinc-900 p-2 border border-zinc-800 rounded">
                  <div class="text-[10px] text-zinc-500 uppercase font-mono">Cumulative</div>
                  <div class="text-lg font-light text-white font-mono mt-0.5">{{ Math.round(crane.cumulativeEnergyKwh) }}<span class="text-xs text-emerald-400 ml-1">kWh</span></div>
                </div>
                <div class="bg-zinc-900 p-2 border border-zinc-800 rounded">
                  <div class="text-[10px] text-zinc-500 uppercase font-mono">Motor Temp</div>
                  <div class="text-lg font-light text-white font-mono mt-0.5">{{ crane.tempMotorC.toFixed(1) }}<span class="text-xs text-zinc-500 ml-1">°C</span></div>
                </div>
                <div class="bg-zinc-900 p-2 border border-zinc-800 rounded">
                  <div class="text-[10px] text-zinc-500 uppercase font-mono">Vibration</div>
                  <div class="text-lg font-light text-white font-mono mt-0.5">{{ crane.vibrationRms.toFixed(2) }}<span class="text-xs text-zinc-500 ml-1">mm/s</span></div>
                </div>
              </div>
            </div>

            <!-- Kinematics -->
            <div class="bg-zinc-900/60 p-3 rounded border border-zinc-800 space-y-1.5 font-mono text-[11px]">
              <div class="text-[9px] uppercase tracking-widest text-zinc-500 mb-1">Gantry Kinematics</div>
              <div class="flex justify-between">
                <span class="text-zinc-500">Gantry Pos:</span>
                <span class="text-zinc-200">{{ crane.gantryPosM.toFixed(1) }} m</span>
              </div>
              <div class="flex justify-between">
                <span class="text-zinc-500">Trolley Pos:</span>
                <span class="text-zinc-200">{{ crane.trolleyPosM.toFixed(1) }} m</span>
              </div>
              <div class="flex justify-between">
                <span class="text-zinc-500">Hoist Height:</span>
                <span class="text-zinc-200">{{ crane.hoistHeightM.toFixed(1) }} m</span>
              </div>
              <div class="flex justify-between">
                <span class="text-zinc-500">Spreader Lock:</span>
                <span [class.text-emerald-400]="crane.spreaderLatched" [class.text-zinc-500]="!crane.spreaderLatched">
                  {{ crane.spreaderLatched ? 'ENGAGED' : 'OPEN' }}
                </span>
              </div>
            </div>
          }

          <!-- 2. VESSEL INSPECTION -->
          @if (asVessel(portEngine.selectedAsset()?.data); as vessel) {
            <div class="bg-zinc-900/70 p-3 border-l-2 border-emerald-500 rounded-r border-y border-r border-zinc-800 space-y-2">
              <div class="flex justify-between items-center">
                <span class="text-white font-bold text-sm">{{ vessel.name }}</span>
                <span class="bg-emerald-500/10 text-emerald-500 text-[9px] px-1.5 py-0.5 rounded font-mono font-bold">BERTHED</span>
              </div>
              <div class="text-[10px] text-zinc-500 font-mono">
                IMO {{ vessel.imo }} • {{ vessel.lengthM }}M • CAP: {{ (vessel.capacityTeu / 1000).toFixed(1) }}K TEU
              </div>
              <div class="text-[10px] text-zinc-400 font-mono flex justify-between border-t border-zinc-800 pt-1.5">
                <span>FLAG: {{ vessel.flag }} ({{ vessel.callsign }})</span>
                <span>DRAFT: {{ vessel.currentDraftM }}M</span>
              </div>
            </div>

            <!-- Turnaround Progress Bar -->
            <div class="bg-zinc-900/60 p-3 rounded border border-zinc-800 space-y-2">
              <div class="flex justify-between text-[10px] font-mono">
                <span class="text-zinc-500 uppercase">Discharge Progress</span>
                <span class="text-white font-bold">
                  {{ vessel.containersDischarged }} / {{ vessel.containersToDischarge }} TEU
                  <span class="text-emerald-400 ml-1">({{ Math.round((vessel.containersDischarged / (vessel.containersToDischarge || 1)) * 100) }}%)</span>
                </span>
              </div>
              <div class="h-1.5 w-full bg-zinc-800 rounded-full overflow-hidden">
                <div
                  class="h-full bg-emerald-500 transition-all duration-300"
                  [style.width.%]="(vessel.containersDischarged / (vessel.containersToDischarge || 1)) * 100"
                ></div>
              </div>
            </div>

            <!-- Cargo Manifest Breakdown -->
            <div class="space-y-1.5 font-mono">
              <h2 class="text-[10px] uppercase tracking-widest text-zinc-500">Cargo Manifest</h2>
              <div class="grid grid-cols-3 gap-2 text-center">
                <div class="bg-zinc-900 p-2 rounded border border-zinc-800">
                  <div class="text-[9px] text-zinc-500 uppercase">Dry Cargo</div>
                  <div class="font-bold text-white text-xs mt-0.5">{{ vessel.cargoManifest.dryTeu }}</div>
                </div>
                <div class="bg-zinc-900 p-2 rounded border border-zinc-800">
                  <div class="text-[9px] text-cyan-400 uppercase">Reefers</div>
                  <div class="font-bold text-cyan-300 text-xs mt-0.5">{{ vessel.cargoManifest.reeferTeu }}</div>
                </div>
                <div class="bg-zinc-900 p-2 rounded border border-zinc-800">
                  <div class="text-[9px] text-amber-400 uppercase">Hazmat IMO</div>
                  <div class="font-bold text-amber-300 text-xs mt-0.5">{{ vessel.cargoManifest.hazmatTeu }}</div>
                </div>
              </div>
            </div>
          }

          <!-- 3. CONTAINER LIFECYCLE INSPECTION -->
          @if (asContainer(portEngine.selectedAsset()?.data); as container) {
            <div class="bg-zinc-900/70 p-3 rounded border border-zinc-800 space-y-2 font-mono">
              <div class="flex justify-between items-center">
                <span class="text-zinc-500 text-[10px]">BIC Number:</span>
                <span class="font-bold text-white text-sm">{{ container.id }}</span>
              </div>
              <div class="flex justify-between text-[11px]">
                <span class="text-zinc-500">ISO Type:</span>
                <span class="text-zinc-200">{{ container.isoType }} ({{ container.lengthFt }}ft)</span>
              </div>
              <div class="flex justify-between text-[11px]">
                <span class="text-zinc-500">Gross Weight:</span>
                <span class="text-zinc-200">{{ container.grossWeightTonnes }} Tonnes</span>
              </div>
              <div class="flex justify-between text-[11px]">
                <span class="text-zinc-500">Route:</span>
                <span class="text-zinc-200">{{ container.originPort }} ➔ {{ container.destinationPort }}</span>
              </div>
              <div class="flex justify-between text-[11px]">
                <span class="text-zinc-500">Status:</span>
                <span class="text-emerald-400 font-bold">{{ container.status }}</span>
              </div>
            </div>

            <!-- Lifecycle Journey Trail -->
            <div class="space-y-2">
              <h2 class="text-[10px] uppercase tracking-widest text-zinc-500 font-mono">Digital Chain of Custody</h2>
              <div class="space-y-2 relative pl-4 border-l border-zinc-800 font-mono">
                @for (stage of container.lifecycleHistory; track stage.timestamp) {
                  <div class="relative">
                    <span class="absolute -left-[21px] top-1 w-2.5 h-2.5 rounded-full bg-emerald-500 border-2 border-[#0F0F0F]"></span>
                    <div class="font-bold text-zinc-200 text-xs">{{ stage.stage }}</div>
                    <div class="text-[10px] text-zinc-500">{{ stage.location }} • {{ stage.operatorOrAsset }}</div>
                    <div class="text-[9px] text-zinc-600">{{ stage.timestamp }}</div>
                  </div>
                }
              </div>
            </div>
          }

          <!-- 4. YARD BLOCK INSPECTION -->
          @if (asYardBlock(portEngine.selectedAsset()?.data); as block) {
            <div class="bg-zinc-900/70 p-3 rounded border border-zinc-800 space-y-2 font-mono">
              <div class="flex justify-between items-center">
                <span class="text-zinc-500 text-[10px]">Block Code:</span>
                <span class="font-bold text-white text-sm">{{ block.blockCode }}</span>
              </div>
              <div class="flex justify-between text-[11px]">
                <span class="text-zinc-500">Storage Category:</span>
                <span class="text-zinc-200">{{ block.type }}</span>
              </div>
              <div class="flex justify-between text-[11px]">
                <span class="text-zinc-500">Assigned RMG:</span>
                <span class="text-zinc-200">{{ block.assignedRmgId }}</span>
              </div>
              <div class="flex justify-between text-[11px]">
                <span class="text-zinc-500">Stack Utilization:</span>
                <span class="font-bold text-emerald-400">
                  {{ block.occupiedSlots }} / {{ block.totalCapacity }} TEU
                  ({{ Math.round((block.occupiedSlots / block.totalCapacity) * 100) }}%)
                </span>
              </div>
            </div>
          }
        </div>
      </div>
    }
  `,
})
export class AssetInspector {
  readonly portEngine = inject(PortEngineService);
  readonly Math = Math;

  asCrane(data: unknown): Crane | null {
    return data && typeof data === 'object' && 'mode' in data ? (data as Crane) : null;
  }

  asVessel(data: unknown): Vessel | null {
    return data && typeof data === 'object' && 'imo' in data ? (data as Vessel) : null;
  }

  asContainer(data: unknown): Container | null {
    return data && typeof data === 'object' && 'isoType' in data ? (data as Container) : null;
  }

  asYardBlock(data: unknown): YardBlock | null {
    return data && typeof data === 'object' && 'blockCode' in data ? (data as YardBlock) : null;
  }
}
