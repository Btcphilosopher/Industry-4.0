import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PortEngineService } from '../../services/port-engine.service';

@Component({
  selector: 'app-command-header',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="h-14 bg-[#0F0F0F] border-b border-zinc-800 px-4 flex items-center justify-between shadow-lg z-30 select-none">
      <!-- Left: Port Authority Brand & Multi-Port Switcher -->
      <div class="flex items-center gap-4">
        <div class="flex items-center gap-3">
          <div class="bg-emerald-500 w-2.5 h-2.5 rounded-full animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.7)]"></div>
          <div>
            <div class="flex items-center gap-2">
              <h1 class="text-sm font-bold tracking-tight text-white uppercase font-mono">
                PORT 4.0 <span class="text-zinc-500 font-normal">| DIGITAL TWIN OS</span>
              </h1>
            </div>
            <div class="text-[10px] text-zinc-500 font-mono flex items-center gap-1.5 mt-0.5">
              <span>{{ portEngine.portConfig().name }}</span>
              <span class="text-zinc-700">•</span>
              <span class="text-zinc-400 font-bold">{{ portEngine.portConfig().unLocode }}</span>
            </div>
          </div>
        </div>

        <!-- Port Switcher Dropdown -->
        <div class="relative ml-2">
          <select
            [value]="portEngine.activePortId()"
            (change)="onPortChange($event)"
            class="bg-zinc-900 text-zinc-200 border border-zinc-800 hover:border-zinc-700 px-2.5 py-1 rounded text-xs font-mono font-semibold focus:outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer"
          >
            @for (p of portEngine.availablePorts; track p.id) {
              <option [value]="p.id">
                {{ p.name }} ({{ p.locode }})
              </option>
            }
          </select>
        </div>
      </div>

      <!-- Center: Key Operational Performance Indicators -->
      <div class="hidden lg:flex items-center gap-5 text-xs font-mono">
        <div class="flex flex-col items-end">
          <span class="text-[9px] text-zinc-500 uppercase tracking-widest">TEU / HOUR</span>
          <span class="font-bold text-white text-xs">{{ portEngine.operationalKpis().teuPerHour }} <span class="text-emerald-400 text-[10px]">T/H</span></span>
        </div>
        <div class="h-5 w-px bg-zinc-800"></div>
        <div class="flex flex-col items-end">
          <span class="text-[9px] text-zinc-500 uppercase tracking-widest">BERTH OCCUPANCY</span>
          <span class="font-bold text-white text-xs">
            {{ portEngine.operationalKpis().berthedCount }}/{{ portEngine.portConfig().berths.length }}
            <span class="text-emerald-400 text-[10px]">({{ portEngine.operationalKpis().berthOccupancyPct }}%)</span>
          </span>
        </div>
        <div class="h-5 w-px bg-zinc-800"></div>
        <div class="flex flex-col items-end">
          <span class="text-[9px] text-zinc-500 uppercase tracking-widest">ACTIVE STS CRANES</span>
          <span class="font-bold text-white text-xs">
            {{ portEngine.operationalKpis().activeCranesCount }}/{{ portEngine.cranes().length }}
            <span class="text-amber-400 text-[10px]">(GCR {{ portEngine.portConfig().metrics.craneGcr }})</span>
          </span>
        </div>
        <div class="h-5 w-px bg-zinc-800"></div>
        <div class="flex flex-col items-end">
          <span class="text-[9px] text-zinc-500 uppercase tracking-widest">YARD DENSITY</span>
          <span class="font-bold text-white text-xs">
            {{ portEngine.operationalKpis().yardDensityPct }}<span class="text-zinc-500 text-[10px]">%</span>
          </span>
        </div>
        <div class="h-5 w-px bg-zinc-800"></div>
        <div class="flex flex-col items-end">
          <span class="text-[9px] text-zinc-500 uppercase tracking-widest">INTERMODAL SHARE</span>
          <span class="font-bold text-white text-xs">
            {{ portEngine.operationalKpis().railIntermodalSharePct }}<span class="text-cyan-400 text-[10px]">%</span>
          </span>
        </div>
      </div>

      <!-- Right: Live System Heartbeat & Actions -->
      <div class="flex items-center gap-4">
        <!-- Live Clock & Simulation State -->
        <div class="text-right font-mono hidden sm:flex items-center gap-4 text-xs uppercase">
          <div class="flex flex-col items-end">
            <span class="text-zinc-500 text-[9px]">Simulation State</span>
            <span class="text-emerald-400 font-bold text-[11px] flex items-center gap-1">
              <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
              Live Synchronized
            </span>
          </div>
          <div class="flex flex-col items-end">
            <span class="text-zinc-500 text-[9px]">UTC Time</span>
            <span class="text-white font-bold text-xs font-mono">
              {{ portEngine.simulationTime() | date:'HH:mm:ss' }}
            </span>
          </div>
        </div>

        <!-- Simulation Speed Warp Controls -->
        <div class="flex items-center bg-zinc-900 border border-zinc-800 p-0.5 rounded text-xs">
          <button
            (click)="portEngine.toggleSimulation()"
            [class.text-emerald-400]="portEngine.isSimulationRunning()"
            [class.text-amber-400]="!portEngine.isSimulationRunning()"
            class="p-1 rounded hover:bg-zinc-800 transition"
            [title]="portEngine.isSimulationRunning() ? 'Pause Simulation' : 'Resume Simulation'"
          >
            <span class="material-icons text-sm">{{ portEngine.isSimulationRunning() ? 'pause' : 'play_arrow' }}</span>
          </button>
          @for (s of [1, 10, 100]; track s) {
            <button
              (click)="portEngine.setSpeed(s)"
              [class.bg-zinc-700]="portEngine.simulationSpeed() === s"
              [class.text-white]="portEngine.simulationSpeed() === s"
              [class.text-zinc-400]="portEngine.simulationSpeed() !== s"
              class="px-1.5 py-0.5 rounded text-[10px] font-mono font-semibold hover:text-zinc-200 transition"
            >
              {{ s }}x
            </button>
          }
        </div>

        <!-- Editor Toggle Button -->
        <button
          (click)="toggleEditor()"
          [class.bg-amber-500]="portEngine.editorModeActive()"
          [class.text-black]="portEngine.editorModeActive()"
          [class.border-amber-400]="portEngine.editorModeActive()"
          [class.bg-zinc-900]="!portEngine.editorModeActive()"
          [class.text-zinc-300]="!portEngine.editorModeActive()"
          [class.border-zinc-800]="!portEngine.editorModeActive()"
          class="px-2.5 py-1 rounded border text-xs font-mono font-semibold flex items-center gap-1.5 hover:border-zinc-600 transition"
        >
          <span class="material-icons text-sm">edit_location</span>
          <span class="hidden md:inline">GIS Editor</span>
        </button>
      </div>
    </header>
  `,
})
export class CommandHeader {
  readonly portEngine = inject(PortEngineService);

  onPortChange(event: Event) {
    const val = (event.target as HTMLSelectElement).value;
    this.portEngine.loadPort(val);
  }

  toggleEditor() {
    this.portEngine.editorModeActive.update((v) => !v);
  }
}

