import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PortEngineService } from '../../services/port-engine.service';

@Component({
  selector: 'app-scenario-lab',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col p-3 space-y-3 text-xs select-none font-sans">
      <div class="flex items-center justify-between">
        <div>
          <h2 class="font-bold text-xs text-white uppercase font-mono tracking-wider">
            What-If Scenarios & Logistics Optimizer
          </h2>
          <p class="text-[10px] text-zinc-500 font-mono">
            Simulate disruptions, evaluate mathematical optimization models (BAP/QCAP), and calculate economic & decarbonization deltas.
          </p>
        </div>
        @if (portEngine.activeScenarioId()) {
          <button
            (click)="portEngine.resetToLiveBaseline()"
            class="px-2.5 py-1 bg-red-950 border border-red-800/80 hover:bg-red-900 text-red-300 rounded text-xs font-mono font-semibold flex items-center gap-1 transition"
          >
            <span class="material-icons text-sm">restart_alt</span>
            RESET TO LIVE BASELINE
          </button>
        }
      </div>

      <!-- Scenarios Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-3">
        @for (sc of portEngine.activeScenarios(); track sc.id) {
          <div
            [class.border-emerald-500]="portEngine.activeScenarioId() === sc.id"
            [class.bg-zinc-900]="portEngine.activeScenarioId() === sc.id"
            [class.bg-zinc-900/60]="portEngine.activeScenarioId() !== sc.id"
            class="p-3 rounded border border-zinc-800 flex flex-col justify-between hover:border-zinc-700 transition space-y-2"
          >
            <div>
              <div class="flex items-center justify-between">
                <span class="font-bold text-white font-mono text-xs">{{ sc.name }}</span>
                @if (portEngine.activeScenarioId() === sc.id) {
                  <span
                    class="px-1.5 py-0.2 bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 rounded text-[9px] font-bold uppercase font-mono"
                  >
                    ACTIVE RUN
                  </span>
                }
              </div>
              <p class="text-[10px] text-zinc-400 mt-1 leading-relaxed">{{ sc.description }}</p>
            </div>

            <div class="bg-[#0A0A0A] p-2 rounded border border-zinc-800/80 space-y-1 font-mono text-[10px]">
              <div class="flex justify-between">
                <span class="text-zinc-500">Projected Daily TEU:</span>
                <span class="font-bold text-zinc-200">{{ sc.projectedTeuDaily.toLocaleString() }}</span>
              </div>
              <div class="flex justify-between">
                <span class="text-zinc-500">Vessel Wait Time:</span>
                <span [class.text-red-400]="sc.projectedWaitHours > 5" [class.text-emerald-400]="sc.projectedWaitHours <= 5">
                  {{ sc.projectedWaitHours }} hrs
                </span>
              </div>
              <div class="flex justify-between">
                <span class="text-zinc-500">Yard Stacking Density:</span>
                <span class="text-zinc-300 font-semibold">{{ sc.yardCongestionPct }}%</span>
              </div>
              <div class="flex justify-between">
                <span class="text-zinc-500">Net Revenue Impact:</span>
                <span [class.text-emerald-400]="sc.netRevenueImpactUsd > 0" [class.text-red-400]="sc.netRevenueImpactUsd < 0" class="font-bold">
                  {{ sc.netRevenueImpactUsd > 0 ? '+' : '' }}USD {{ sc.netRevenueImpactUsd.toLocaleString() }}
                </span>
              </div>
              <div class="flex justify-between">
                <span class="text-zinc-500">CO₂ Delta:</span>
                <span [class.text-red-400]="sc.carbonDeltaTonnes > 0" [class.text-emerald-400]="sc.carbonDeltaTonnes <= 0">
                  {{ sc.carbonDeltaTonnes > 0 ? '+' : '' }}{{ sc.carbonDeltaTonnes }} T
                </span>
              </div>
            </div>

            <button
              (click)="portEngine.runScenario(sc.id)"
              [disabled]="portEngine.activeScenarioId() === sc.id"
              class="w-full py-1.5 bg-zinc-800 hover:bg-zinc-700 disabled:bg-zinc-900 disabled:text-zinc-600 disabled:border-zinc-800 border border-zinc-700 text-zinc-200 rounded text-xs font-mono font-semibold flex items-center justify-center gap-1.5 transition"
            >
              <span class="material-icons text-sm">play_arrow</span>
              EXECUTE SIMULATION
            </button>
          </div>
        }
      </div>
    </div>
  `,
})
export class ScenarioLab {
  readonly portEngine = inject(PortEngineService);
}

