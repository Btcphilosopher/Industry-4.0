import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PortEngineService } from '../../services/port-engine.service';

@Component({
  selector: 'app-geospatial-editor',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col p-3 space-y-3 text-xs select-none text-zinc-300 font-sans">
      <div class="flex items-center justify-between">
        <div>
          <h2 class="font-bold text-xs text-white uppercase font-mono tracking-wider">
            Geospatial Infrastructure & Terminal CAD Layout
          </h2>
          <p class="text-[10px] text-zinc-500 font-mono">
            Interactive GIS tool to place STS cranes, expand yard blocks, and configure berths. Click a tool and place on the viewport map.
          </p>
        </div>
        <div class="flex items-center gap-2">
          <button
            (click)="portEngine.editorModeActive.set(false)"
            class="px-2.5 py-1 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 rounded text-xs font-mono transition"
          >
            CLOSE DESIGNER
          </button>
        </div>
      </div>

      <!-- Designer Tools Ribbon -->
      <div class="flex items-center gap-2 bg-zinc-900/90 p-2 rounded border border-zinc-800">
        <span class="text-[10px] font-mono uppercase text-zinc-500 font-bold">Placement Tools:</span>

        <button
          (click)="setTool('CRANE')"
          [class.bg-emerald-500]="portEngine.activeEditorTool() === 'CRANE'"
          [class.text-black]="portEngine.activeEditorTool() === 'CRANE'"
          [class.bg-zinc-800]="portEngine.activeEditorTool() !== 'CRANE'"
          [class.text-zinc-200]="portEngine.activeEditorTool() !== 'CRANE'"
          class="px-2.5 py-1 rounded text-xs font-mono font-semibold flex items-center gap-1.5 border border-zinc-700 hover:border-zinc-500 transition"
        >
          <span class="material-icons text-sm">precision_manufacturing</span>
          Place STS Crane
        </button>

        <button
          (click)="setTool('YARD')"
          [class.bg-emerald-500]="portEngine.activeEditorTool() === 'YARD'"
          [class.text-black]="portEngine.activeEditorTool() === 'YARD'"
          [class.bg-zinc-800]="portEngine.activeEditorTool() !== 'YARD'"
          [class.text-zinc-200]="portEngine.activeEditorTool() !== 'YARD'"
          class="px-2.5 py-1 rounded text-xs font-mono font-semibold flex items-center gap-1.5 border border-zinc-700 hover:border-zinc-500 transition"
        >
          <span class="material-icons text-sm">grid_view</span>
          Place Yard Block
        </button>

        <button
          (click)="setTool('BERTH')"
          [class.bg-emerald-500]="portEngine.activeEditorTool() === 'BERTH'"
          [class.text-black]="portEngine.activeEditorTool() === 'BERTH'"
          [class.bg-zinc-800]="portEngine.activeEditorTool() !== 'BERTH'"
          [class.text-zinc-200]="portEngine.activeEditorTool() !== 'BERTH'"
          class="px-2.5 py-1 rounded text-xs font-mono font-semibold flex items-center gap-1.5 border border-zinc-700 hover:border-zinc-500 transition"
        >
          <span class="material-icons text-sm">anchor</span>
          Extend Berth Bollards
        </button>
      </div>

      <!-- Quick Add Actions & Geo JSON Export -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-3 flex-1 overflow-y-auto font-mono text-[10px]">
        <div class="bg-zinc-900/80 p-3 rounded border border-zinc-800 space-y-2">
          <div class="font-bold text-white text-xs uppercase font-mono">Infrastructure Matrix</div>
          <div class="space-y-1 text-zinc-400">
            <div>Quay Berths: <span class="text-zinc-200">{{ portEngine.portConfig().berths.length }} Berths ({{ portEngine.portConfig().quaysLengthM }}m)</span></div>
            <div>STS Cranes: <span class="text-zinc-200">{{ portEngine.cranes().length }} Megamax Units</span></div>
            <div>Yard Blocks: <span class="text-zinc-200">{{ portEngine.yardBlocks().length }} Stacking Areas</span></div>
            <div>AGV Fleet: <span class="text-zinc-200">{{ portEngine.vehicles().length }} Autonomous Carriers</span></div>
            <div>Spatial CRS: <span class="text-emerald-400">{{ portEngine.portConfig().crs }} ({{ portEngine.portConfig().originLat }}°N, {{ portEngine.portConfig().originLon }}°E)</span></div>
          </div>
        </div>

        <div class="bg-zinc-900/80 p-3 rounded border border-zinc-800 space-y-2">
          <div class="font-bold text-white text-xs uppercase font-mono">Quick Commissioning</div>
          <div class="flex flex-col gap-1.5">
            <button
              (click)="quickAddCrane()"
              class="px-2.5 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded text-left flex items-center justify-between border border-zinc-700 transition"
            >
              <span>+ Commission STS STS-0{{ portEngine.cranes().length + 1 }}</span>
              <span class="text-emerald-400 font-mono">+35 TEU/h</span>
            </button>
            <button
              (click)="quickAddYardBlock()"
              class="px-2.5 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded text-left flex items-center justify-between border border-zinc-700 transition"
            >
              <span>+ Add Yard Block {{ portEngine.yardBlocks().length + 1 }}</span>
              <span class="text-sky-400 font-mono">+1,200 TEU</span>
            </button>
          </div>
        </div>

        <div class="bg-zinc-900/80 p-3 rounded border border-zinc-800 space-y-2">
          <div class="font-bold text-white text-xs uppercase font-mono">PostGIS Spatial Export</div>
          <p class="text-[10px] text-zinc-400 font-mono">
            Export authoritative PostGIS WKT spatial geometry & YAML terminal schema.
          </p>
          <button
            (click)="copyPostGisWkt()"
            class="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 text-zinc-200 rounded text-xs font-mono font-semibold flex items-center gap-1.5 transition"
          >
            <span class="material-icons text-sm">content_copy</span>
            COPY POSTGIS DDL
          </button>
        </div>
      </div>
    </div>
  `,
})
export class GeospatialEditor {
  readonly portEngine = inject(PortEngineService);

  setTool(tool: 'CRANE' | 'YARD' | 'BERTH') {
    this.portEngine.activeEditorTool.set(tool);
  }

  quickAddCrane() {
    const nextGantry = 100 + this.portEngine.cranes().length * 110;
    this.portEngine.commitEditorAddition('CRANE', { x: nextGantry, y: 150 });
  }

  quickAddYardBlock() {
    const nextY = 280 + (this.portEngine.yardBlocks().length % 3) * 110;
    const nextX = 100 + Math.floor(this.portEngine.yardBlocks().length / 3) * 120;
    this.portEngine.commitEditorAddition('YARD', { x: nextX, y: nextY });
  }

  copyPostGisWkt() {
    const sql = `INSERT INTO port_berths (port_id, berth_code, geom) VALUES ('${this.portEngine.portConfig().id}', 'BERTH_EXP', ST_GeomFromText('LINESTRING(4.01 51.95, 4.02 51.96)', 4326));`;
    navigator.clipboard?.writeText(sql);
  }
}

