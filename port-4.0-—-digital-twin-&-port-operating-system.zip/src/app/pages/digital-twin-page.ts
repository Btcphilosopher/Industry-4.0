import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CommandHeader } from '../components/command-header/command-header';
import { PortViewport } from '../components/port-viewport/port-viewport';
import { AssetInspector } from '../components/asset-inspector/asset-inspector';
import { TelemetryDock } from '../components/telemetry-dock/telemetry-dock';
import { PortEngineService } from '../services/port-engine.service';

@Component({
  selector: 'app-digital-twin-page',
  imports: [CommonModule, CommandHeader, PortViewport, AssetInspector, TelemetryDock],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex flex-col w-screen h-screen bg-[#0A0A0A] text-zinc-300 font-sans overflow-hidden select-none">
      <!-- Command Center Header -->
      <app-command-header></app-command-header>

      <!-- Main Central Work Area: Viewport + Slide-Over Inspector -->
      <div class="flex-1 relative flex overflow-hidden bg-[#0A0A0A]">
        <!-- 2D / 3D Canvas Viewport -->
        <div class="flex-1 h-full relative">
          <app-port-viewport></app-port-viewport>
        </div>

        <!-- Slide-Over Inspector for Selected Asset -->
        <app-asset-inspector></app-asset-inspector>
      </div>

      <!-- Bottom Telemetry & Operations Dock -->
      <app-telemetry-dock></app-telemetry-dock>

      <!-- Technical OS Data Grid Footer -->
      <footer class="h-6 bg-[#09090b] border-t border-zinc-800/90 px-3 flex items-center justify-between text-[9px] font-mono text-zinc-500 z-30">
        <div class="flex items-center gap-4">
          <span class="flex items-center gap-1.5 text-zinc-400">
            <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            PORT_CORE v4.0.2 // RUST-MIP-STABLE
          </span>
          <span class="hidden md:inline text-zinc-600">|</span>
          <span class="hidden md:inline text-zinc-500">DATUM: EPSG:3857 (WGS84_MERCATOR)</span>
          <span class="hidden md:inline text-zinc-600">|</span>
          <span class="hidden md:inline text-zinc-500">TOS SYNC: AIS_5HZ // JITTER &lt; 0.4ms</span>
        </div>
        <div class="flex items-center gap-4">
          <span class="text-zinc-500 font-mono hidden sm:inline">LATENCY: 12ms</span>
          <span class="text-emerald-400 font-mono font-semibold">ONLINE [TELNET_SSL]</span>
        </div>
      </footer>
    </div>
  `,
})
export class DigitalTwinPage {
  readonly portEngine = inject(PortEngineService);
}

