export interface LocalPortCoord {
  x: number; // Easting in metres relative to port origin
  y: number; // Northing in metres relative to port origin
  z?: number; // Altitude / Tier height in metres
  headingDeg?: number;
}

export interface WGS84Coord {
  latitude: number;
  longitude: number;
  elevationM?: number;
}

export type AssetType =
  | 'SHIP_TO_SHORE_CRANE'
  | 'RUBBER_TYRED_GANTRY'
  | 'RAIL_MOUNTED_GANTRY'
  | 'REACH_STACKER'
  | 'TERMINAL_TRUCK'
  | 'AUTOMATED_GUIDED_VEHICLE'
  | 'FREIGHT_LOCOMOTIVE'
  | 'CONTAINER_VESSEL'
  | 'FEEDER_VESSEL'
  | 'BARGE';

export type ContainerStatus =
  | 'ON_VESSEL'
  | 'CRANE_PICKING'
  | 'CRANE_MOVING'
  | 'CRANE_DROPPING'
  | 'TRUCK_LOADING'
  | 'IN_TRANSIT'
  | 'YARD_STACKED'
  | 'RMG_MOVING'
  | 'RAIL_LOADING'
  | 'ON_TRAIN'
  | 'GATE_EXITING'
  | 'DELIVERED';

export interface Container {
  id: string; // ISO 6346 BIC code e.g. MSKU-749201-8
  isoType: '20GP' | '40HC' | '45HC' | '20RF' | '40RF' | 'TANK' | 'FLAT';
  lengthFt: 20 | 40 | 45;
  grossWeightTonnes: number;
  tareWeightTonnes: number;
  cargoType: 'General' | 'Reefer' | 'Hazardous_Class_3' | 'Hazardous_Class_8' | 'Empty' | 'HighValue';
  color: string;
  originPort: string;
  destinationPort: string;
  vesselImo?: number;
  assignedVesselName?: string;
  status: ContainerStatus;
  currentAssetId?: string;
  yardBlockId?: string;
  bay?: number;
  row?: number;
  tier?: number;
  position: LocalPortCoord;
  temperatureC?: number;
  dwellDays: number;
  lifecycleHistory: {
    stage: string;
    timestamp: string;
    location: string;
    operatorOrAsset: string;
  }[];
}

export type CraneMode = 'IDLE' | 'DISCHARGING' | 'LOADING' | 'SHIFTING' | 'MAINTENANCE' | 'FAULT' | 'HIGH_WIND_LOCK';

export interface Crane {
  id: string;
  name: string;
  type: 'STS' | 'RTG' | 'RMG';
  berthId?: string;
  yardBlockId?: string;
  railTrackId?: string;
  gantryPosM: number;
  trolleyPosM: number;
  hoistHeightM: number;
  boomAngleDeg: number;
  spreaderLatched: boolean;
  activeContainerId?: string;
  mode: CraneMode;
  movesCompletedShift: number;
  avgCycleTimeSec: number;
  currentPowerKw: number;
  cumulativeEnergyKwh: number;
  maintenanceDueDays: number;
  vibrationRms: number;
  tempMotorC: number;
  position: LocalPortCoord;
  targetPosition?: LocalPortCoord;
  cycleProgress: number; // 0 to 1
}

export type VesselStatus =
  | 'AT_SEA'
  | 'APPROACHING'
  | 'ANCHORING'
  | 'BERTHING'
  | 'BERTHED'
  | 'LOADING'
  | 'UNLOADING'
  | 'DEPARTING';

export interface Vessel {
  imo: number;
  name: string;
  callsign: string;
  flag: string;
  lengthM: number;
  beamM: number;
  currentDraftM: number;
  maxDraftM: number;
  capacityTeu: number;
  eta: string;
  etd: string;
  assignedBerthId?: string;
  status: VesselStatus;
  position: LocalPortCoord;
  speedKnots: number;
  headingDeg: number;
  targetWaypointIndex: number;
  containersToDischarge: number;
  containersDischarged: number;
  containersToLoad: number;
  containersLoaded: number;
  allocatedCranes: string[];
  cargoManifest: {
    dryTeu: number;
    reeferTeu: number;
    hazmatTeu: number;
  };
}

export interface Berth {
  id: string;
  terminalId: string;
  name: string;
  lengthM: number;
  depthM: number;
  maxDraftM: number;
  bollardStartM: number;
  bollardEndM: number;
  currentVesselImo?: number;
  shorePowerActive: boolean;
  status: 'OCCUPIED' | 'AVAILABLE' | 'RESERVED' | 'MAINTENANCE';
  allocatedCranes: string[];
  position: LocalPortCoord;
}

export interface YardBlock {
  id: string;
  blockCode: string;
  name: string;
  type: 'DRY' | 'REEFER' | 'HAZMAT' | 'EMPTY';
  baysCount: number;
  rowsCount: number;
  maxTiers: number;
  position: LocalPortCoord;
  widthM: number;
  lengthM: number;
  occupiedSlots: number;
  totalCapacity: number;
  assignedRmgId: string;
}

export interface Vehicle {
  id: string;
  name: string;
  type: 'AGV' | 'TERMINAL_TRUCK' | 'MAINTENANCE_VAN';
  position: LocalPortCoord;
  headingDeg: number;
  speedMps: number;
  status: 'IDLE' | 'EN_ROUTE_QUAY' | 'LOADING' | 'EN_ROUTE_YARD' | 'UNLOADING' | 'EN_ROUTE_RAIL' | 'EN_ROUTE_GATE';
  assignedContainerId?: string;
  targetCoord?: LocalPortCoord;
  pathWaypoints: LocalPortCoord[];
  currentWaypointIdx: number;
  batterySocPct: number;
  fuelLevelPct: number;
  totalDistanceKm: number;
}

export interface RailTrain {
  id: string;
  trainNumber: string;
  wagonsCount: number;
  locomotiveId: string;
  lengthM: number;
  position: LocalPortCoord;
  headingDeg: number;
  speedKph: number;
  status: 'ARRIVING' | 'STATIONARY_LOADING' | 'DEPARTING' | 'SCHEDULED';
  loadedContainers: string[];
  capacityTeu: number;
  trackId: string;
  departureTime: string;
  destinationDryPort: string;
}

export interface PortEventLog {
  id: string;
  timestamp: string;
  assetId: string;
  assetType: string;
  eventType: string;
  severity: 'INFO' | 'WARNING' | 'ALERT' | 'SUCCESS';
  message: string;
  location: string;
}

export interface PortAuthorityConfig {
  id: string;
  name: string;
  country: string;
  unLocode: string;
  crs: string;
  originLat: number;
  originLon: number;
  rotationDeg: number;
  quaysLengthM: number;
  quaysDepthM: number;
  berths: Berth[];
  cranes: Crane[];
  yardBlocks: YardBlock[];
  weather: {
    temperatureC: number;
    windSpeedKnots: number;
    windDirectionDeg: number;
    visibilityKm: number;
    condition: 'CLEAR' | 'FOG' | 'RAIN' | 'GALE_WARNING';
    tideHeightM: number;
  };
  metrics: {
    teuPerHour: number;
    dailyTeu: number;
    berthUtilizationPct: number;
    craneGcr: number; // Gross Crane Rate
    yardDensityPct: number;
    truckTurnaroundMins: number;
    railIntermodalSharePct: number;
    shorePowerUsageKw: number;
    co2KgPerTeu: number;
    activeVesselsCount: number;
    revenueTodayUsd: number;
  };
}

export interface WhatIfScenario {
  id: string;
  name: string;
  description: string;
  volumeMultiplier: number;
  disabledCranesCount: number;
  railCapacityFactor: number;
  weatherSeverity: 'NORMAL' | 'GALE_WINDS' | 'FOG_RESTRICTION';
  projectedTeuDaily: number;
  projectedWaitHours: number;
  yardCongestionPct: number;
  truckTurnaroundMins: number;
  netRevenueImpactUsd: number;
  carbonDeltaTonnes: number;
}
