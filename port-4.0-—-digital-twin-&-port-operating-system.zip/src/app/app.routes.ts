import { Routes } from '@angular/router';
import { DigitalTwinPage } from './pages/digital-twin-page';

export const routes: Routes = [
  {
    path: '',
    component: DigitalTwinPage,
  },
  {
    path: '**',
    redirectTo: '',
  },
];

