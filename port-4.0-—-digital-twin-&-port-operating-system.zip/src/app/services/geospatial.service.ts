import { Injectable } from '@angular/core';
import { LocalPortCoord, WGS84Coord } from '../models/port.models';

@Injectable({
  providedIn: 'root',
})
export class GeospatialService {
  private originLat = 51.9560; // Rotterdam Maasvlakte II
  private originLon = 4.0150;
  private rotationDeg = -14.5;
  private earthRadiusM = 6378137.0;

  setOrigin(lat: number, lon: number, rotationDeg: number) {
    this.originLat = lat;
    this.originLon = lon;
    this.rotationDeg = rotationDeg;
  }

  /**
   * Converts real-world GPS WGS84 coordinate into metric port coordinates (x metres East, y metres North)
   */
  wgs84ToLocal(coord: WGS84Coord): LocalPortCoord {
    const latRad = ((coord.latitude - this.originLat) * Math.PI) / 180.0;
    const lonRad = ((coord.longitude - this.originLon) * Math.PI) / 180.0;
    const avgLat = ((this.originLat + coord.latitude) * 0.5 * Math.PI) / 180.0;

    const dy = latRad * this.earthRadiusM;
    const dx = lonRad * this.earthRadiusM * Math.cos(avgLat);

    const rotRad = (this.rotationDeg * Math.PI) / 180.0;
    const localX = dx * Math.cos(rotRad) - dy * Math.sin(rotRad);
    const localY = dx * Math.sin(rotRad) + dy * Math.cos(rotRad);

    return {
      x: Math.round(localX * 100) / 100,
      y: Math.round(localY * 100) / 100,
      z: coord.elevationM || 0,
      headingDeg: 0,
    };
  }

  /**
   * Converts metric port coordinates back to WGS84 Latitude/Longitude for GIS export
   */
  localToWgs84(local: LocalPortCoord): WGS84Coord {
    const rotRad = (-this.rotationDeg * Math.PI) / 180.0;
    const dx = local.x * Math.cos(rotRad) - local.y * Math.sin(rotRad);
    const dy = local.x * Math.sin(rotRad) + local.y * Math.cos(rotRad);

    const avgLatRad = (this.originLat * Math.PI) / 180.0;
    const latOffset = (dy / this.earthRadiusM) * (180.0 / Math.PI);
    const lonOffset = (dx / (this.earthRadiusM * Math.cos(avgLatRad))) * (180.0 / Math.PI);

    return {
      latitude: Number((this.originLat + latOffset).toFixed(6)),
      longitude: Number((this.originLon + lonOffset).toFixed(6)),
      elevationM: local.z || 0,
    };
  }

  /**
   * Calculates geodesic distance between two points in metres
   */
  distanceM(p1: LocalPortCoord, p2: LocalPortCoord): number {
    const dx = p2.x - p1.x;
    const dy = p2.y - p1.y;
    return Math.sqrt(dx * dx + dy * dy);
  }

  /**
   * Calculates bearing angle in degrees
   */
  bearingDeg(p1: LocalPortCoord, p2: LocalPortCoord): number {
    const dx = p2.x - p1.x;
    const dy = p2.y - p1.y;
    let angle = (Math.atan2(dx, dy) * 180.0) / Math.PI;
    if (angle < 0) angle += 360;
    return angle;
  }
}
