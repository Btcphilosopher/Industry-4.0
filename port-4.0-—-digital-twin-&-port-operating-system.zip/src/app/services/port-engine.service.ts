import { Injectable, signal, computed, inject } from '@angular/core';
import {
  Container,
  ContainerStatus,
  Crane,
  PortAuthorityConfig,
  PortEventLog,
  RailTrain,
  Vehicle,
  Vessel,
  WhatIfScenario,
  YardBlock,
  LocalPortCoord,
} from '../models/port.models';
import { GeospatialService } from './geospatial.service';

@Injectable({
  providedIn: 'root',
})
export class PortEngineService {
  private readonly geoService = inject(GeospatialService);
  // Master Port Configurations
  readonly availablePorts: { id: string; name: string; country: string; locode: string }[] = [
    {
      id: 'port_rotterdam_gateway',
      name: 'Port of Rotterdam — Maasvlakte II Intermodal Hub',
      country: 'Netherlands',
      locode: 'NLRTM',
    },
    {
      id: 'port_felixstowe_trinity',
      name: 'Port of Felixstowe — Trinity Intermodal Terminal',
      country: 'United Kingdom',
      locode: 'GBFXT',
    },
    {
      id: 'port_singapore_pasir',
      name: 'Port of Singapore — Pasir Panjang Automated Terminal',
      country: 'Singapore',
      locode: 'SGSIN',
    },
    {
      id: 'port_la_pier400',
      name: 'Port of Los Angeles — Pier 400 APM Terminal',
      country: 'United States',
      locode: 'USLAX',
    },
  ];

  // Active state signals
  readonly activePortId = signal<string>('port_rotterdam_gateway');
  readonly simulationSpeed = signal<number>(1); // 1, 10, 100, 1000
  readonly isSimulationRunning = signal<boolean>(true);
  readonly simulationTime = signal<Date>(new Date());
  readonly viewMode = signal<'2D_MAP' | '3D_ISOMETRIC'>('3D_ISOMETRIC');
  readonly activeLod = signal<'PORT_OVERVIEW' | 'TERMINAL_VIEW' | 'YARD_VIEW' | 'ASSET_VIEW' | 'ENGINEERING_VIEW'>('TERMINAL_VIEW');
  readonly selectedAsset = signal<{ type: string; id: string; data: unknown } | null>(null);
  readonly editorModeActive = signal<boolean>(false);
  readonly activeEditorTool = signal<'BERTH' | 'CRANE' | 'YARD' | 'ROAD' | 'RAIL' | 'ZONE' | null>(null);

  // Entities state signals
  readonly portConfig = signal<PortAuthorityConfig>(this.buildDefaultRotterdamConfig());
  readonly vessels = signal<Vessel[]>([]);
  readonly cranes = signal<Crane[]>([]);
  readonly containers = signal<Container[]>([]);
  readonly yardBlocks = signal<YardBlock[]>([]);
  readonly vehicles = signal<Vehicle[]>([]);
  readonly railTrains = signal<RailTrain[]>([]);
  readonly eventLogs = signal<PortEventLog[]>([]);
  readonly activeScenarios = signal<WhatIfScenario[]>(this.buildDefaultScenarios());
  readonly activeScenarioId = signal<string | null>(null);

  // Computed metrics
  readonly operationalKpis = computed(() => {
    const vList = this.vessels();
    const cList = this.cranes();
    const yList = this.yardBlocks();
    const cfg = this.portConfig();

    const berthedCount = vList.filter((v) => v.status === 'BERTHED' || v.status === 'LOADING' || v.status === 'UNLOADING').length;
    const activeCranes = cList.filter((c) => c.mode === 'DISCHARGING' || c.mode === 'LOADING').length;
    const totalYardOccupied = yList.reduce((acc, y) => acc + y.occupiedSlots, 0);
    const totalYardCap = yList.reduce((acc, y) => acc + y.totalCapacity, 0) || 1;

    return {
      activeVesselsCount: vList.length,
      berthedCount,
      berthOccupancyPct: Math.round((berthedCount / (cfg.berths.length || 1)) * 100),
      activeCranesCount: activeCranes,
      craneUtilizationPct: Math.round((activeCranes / (cList.length || 1)) * 100),
      yardDensityPct: Math.round((totalYardOccupied / totalYardCap) * 100),
      teuPerHour: cfg.metrics.teuPerHour,
      dailyTeu: cfg.metrics.dailyTeu,
      truckTurnaroundMins: cfg.metrics.truckTurnaroundMins,
      railIntermodalSharePct: cfg.metrics.railIntermodalSharePct,
      shorePowerKw: cfg.metrics.shorePowerUsageKw,
      co2KgPerTeu: cfg.metrics.co2KgPerTeu,
      revenueTodayUsd: cfg.metrics.revenueTodayUsd,
    };
  });

  private simTimer: ReturnType<typeof setInterval> | null = null;
  private animationFrameId: number | null = null;
  private lastSimTick = Date.now();

  constructor() {
    this.loadPort(this.activePortId());
    this.startSimulationLoop();
  }

  loadPort(portId: string) {
    this.activePortId.set(portId);
    let cfg: PortAuthorityConfig;
    if (portId === 'port_felixstowe_trinity') {
      cfg = this.buildFelixstoweConfig();
    } else if (portId === 'port_singapore_pasir') {
      cfg = this.buildSingaporeConfig();
    } else if (portId === 'port_la_pier400') {
      cfg = this.buildLosAngelesConfig();
    } else {
      cfg = this.buildDefaultRotterdamConfig();
    }

    this.portConfig.set(cfg);
    this.geoService.setOrigin(cfg.originLat, cfg.originLon, cfg.rotationDeg);
    this.seedInitialPortEntities(cfg);
    this.addEventLog('SYSTEM', 'PORT_INITIALIZED', 'SUCCESS', `Port Operating System loaded: ${cfg.name} (${cfg.unLocode})`, 'Command Centre');
  }

  private seedInitialPortEntities(cfg: PortAuthorityConfig) {
    // 1. Berth & Quay Cranes
    const cranes: Crane[] = [];
    const berthList = cfg.berths;

    for (let i = 1; i <= 8; i++) {
      const gantryPos = (i - 1) * 160 + 80;
      cranes.push({
        id: `STS-${i < 10 ? '0' + i : i}`,
        name: `Super Post-Panamax STS ${i}`,
        type: 'STS',
        berthId: i <= 2 ? berthList[0]?.id : i <= 4 ? berthList[1]?.id : i <= 6 ? berthList[2]?.id : berthList[3]?.id,
        gantryPosM: gantryPos,
        trolleyPosM: 35.0,
        hoistHeightM: 22.0,
        boomAngleDeg: 0,
        spreaderLatched: i % 2 === 1,
        mode: i === 6 ? 'MAINTENANCE' : i % 2 === 1 ? 'DISCHARGING' : 'LOADING',
        movesCompletedShift: 240 + i * 28,
        avgCycleTimeSec: 88 + (i % 4) * 4,
        currentPowerKw: 420 + i * 35,
        cumulativeEnergyKwh: 3420 + i * 210,
        maintenanceDueDays: 14 + i * 2,
        vibrationRms: 0.042 + (i % 3) * 0.01,
        tempMotorC: 48.5 + (i % 5) * 2.2,
        position: { x: gantryPos, y: 150, z: 0 },
        cycleProgress: (i * 0.15) % 1,
      });
    }

    // 2. Vessels
    const vessels: Vessel[] = [
      {
        imo: 9811000,
        name: 'EVER GOLDEN',
        callsign: 'H3RC',
        flag: 'Panama',
        lengthM: 400.0,
        beamM: 58.8,
        currentDraftM: 16.2,
        maxDraftM: 16.5,
        capacityTeu: 20124,
        eta: '2026-08-29 04:00 UTC',
        etd: '2026-08-30 18:00 UTC',
        assignedBerthId: berthList[0]?.id,
        status: 'UNLOADING',
        position: { x: 225, y: 85, z: 0 },
        speedKnots: 0,
        headingDeg: 90,
        targetWaypointIndex: 0,
        containersToDischarge: 1840,
        containersDischarged: 924,
        containersToLoad: 1250,
        containersLoaded: 310,
        allocatedCranes: ['STS-01', 'STS-02'],
        cargoManifest: { dryTeu: 14200, reeferTeu: 2400, hazmatTeu: 350 },
      },
      {
        imo: 9632064,
        name: 'MAERSK MC-KINNEY MOLLER',
        callsign: 'OWGQ2',
        flag: 'Denmark',
        lengthM: 399.0,
        beamM: 59.0,
        currentDraftM: 15.8,
        maxDraftM: 16.0,
        capacityTeu: 18270,
        eta: '2026-08-29 08:30 UTC',
        etd: '2026-08-31 02:00 UTC',
        assignedBerthId: berthList[1]?.id,
        status: 'BERTHED',
        position: { x: 650, y: 85, z: 0 },
        speedKnots: 0,
        headingDeg: 90,
        targetWaypointIndex: 0,
        containersToDischarge: 2100,
        containersDischarged: 480,
        containersToLoad: 1600,
        containersLoaded: 120,
        allocatedCranes: ['STS-03', 'STS-04'],
        cargoManifest: { dryTeu: 13500, reeferTeu: 2100, hazmatTeu: 420 },
      },
      {
        imo: 9744647,
        name: 'CMA CGM ANTOINE DE SAINT EXUPERY',
        callsign: 'FMCB',
        flag: 'France',
        lengthM: 400.0,
        beamM: 59.0,
        currentDraftM: 15.5,
        maxDraftM: 16.0,
        capacityTeu: 20954,
        eta: '2026-08-29 11:00 UTC',
        etd: '2026-08-31 16:00 UTC',
        assignedBerthId: berthList[2]?.id,
        status: 'BERTHING',
        position: { x: 1025, y: 85, z: 0 },
        speedKnots: 1.2,
        headingDeg: 90,
        targetWaypointIndex: 0,
        containersToDischarge: 1450,
        containersDischarged: 60,
        containersToLoad: 980,
        containersLoaded: 0,
        allocatedCranes: ['STS-05'],
        cargoManifest: { dryTeu: 15800, reeferTeu: 1950, hazmatTeu: 280 },
      },
      {
        imo: 9839438,
        name: 'HAPAG-LLOYD ROTTERDAM EXPRESS',
        callsign: 'DGBR',
        flag: 'Germany',
        lengthM: 335.0,
        beamM: 48.0,
        currentDraftM: 14.2,
        maxDraftM: 15.0,
        capacityTeu: 13200,
        eta: '2026-08-29 15:45 UTC',
        etd: '2026-08-30 22:00 UTC',
        assignedBerthId: undefined,
        status: 'APPROACHING',
        position: { x: 1650, y: -45, z: 0 },
        speedKnots: 7.4,
        headingDeg: 270,
        targetWaypointIndex: 1,
        containersToDischarge: 890,
        containersDischarged: 0,
        containersToLoad: 650,
        containersLoaded: 0,
        allocatedCranes: [],
        cargoManifest: { dryTeu: 9800, reeferTeu: 1200, hazmatTeu: 150 },
      },
    ];

    // 3. Yard Blocks (24 blocks with distinct codes)
    const blocks: YardBlock[] = [];
    const blockCodes = ['A', 'B', 'C', 'D'];
    for (let cIdx = 0; cIdx < blockCodes.length; cIdx++) {
      const code = blockCodes[cIdx];
      for (let num = 1; num <= 6; num++) {
        const id = `BLOCK_${code}0${num}`;
        const isReefer = code === 'B';
        const isHazmat = code === 'D' && num >= 5;
        const xPos = (num - 1) * 210 + 90;
        const yPos = 240 + cIdx * 110;
        blocks.push({
          id,
          blockCode: `${code}0${num}`,
          name: `Yard Block ${code}0${num} (${isReefer ? 'Reefer Plugs' : isHazmat ? 'Hazmat IMO' : 'Dry Cargo'})`,
          type: isReefer ? 'REEFER' : isHazmat ? 'HAZMAT' : 'DRY',
          baysCount: 28,
          rowsCount: 6,
          maxTiers: 5,
          position: { x: xPos, y: yPos, z: 0 },
          widthM: 180,
          lengthM: 70,
          occupiedSlots: Math.floor(28 * 6 * 5 * (0.55 + ((num + cIdx) % 4) * 0.1)),
          totalCapacity: 28 * 6 * 5,
          assignedRmgId: `RMG-${code}${num}`,
        });
      }
    }

    // 4. Containers (120 active visual sample objects with deep lifecycle tracking)
    const containers: Container[] = [];
    const isoTypes: ('20GP' | '40HC' | '45HC' | '20RF' | '40RF' | 'TANK')[] = ['40HC', '40HC', '20GP', '40RF', '45HC', 'TANK'];
    const colors = ['#2563eb', '#dc2626', '#16a34a', '#d97706', '#9333ea', '#0891b2', '#475569'];

    for (let i = 1; i <= 100; i++) {
      const iso = isoTypes[i % isoTypes.length];
      const isReefer = iso.includes('RF');
      const isHazmat = iso === 'TANK';
      const block = blocks[i % blocks.length];
      const bay = (i % 24) + 1;
      const row = (i % 6) + 1;
      const tier = (i % 4) + 1;
      const prefix = ['MSKU', 'CMAU', 'HLCU', 'ONEU', 'COSU', 'EGLV', 'TEMU'][i % 7];
      const serial = 700000 + i * 137;
      const id = `${prefix}-${serial}-${(i * 3) % 10}`;

      const statusList: ContainerStatus[] = ['YARD_STACKED', 'YARD_STACKED', 'IN_TRANSIT', 'CRANE_MOVING', 'RAIL_LOADING', 'ON_VESSEL'];
      const st = statusList[i % statusList.length];

      let posX = block.position.x + (bay / 28) * 160;
      let posY = block.position.y + (row / 6) * 60;
      const posZ = tier * 2.6;

      if (st === 'ON_VESSEL') {
        posX = 200 + (i % 12) * 20;
        posY = 80 + (i % 3) * 10;
      } else if (st === 'IN_TRANSIT') {
        posX = 150 + (i % 20) * 50;
        posY = 190;
      }

      containers.push({
        id,
        isoType: iso,
        lengthFt: iso.startsWith('20') ? 20 : iso.startsWith('45') ? 45 : 40,
        grossWeightTonnes: 14 + (i % 16) * 1.2,
        tareWeightTonnes: 3.8,
        cargoType: isReefer ? 'Reefer' : isHazmat ? 'Hazardous_Class_3' : 'General',
        color: colors[i % colors.length],
        originPort: ['CNSHA', 'SGSIN', 'KRPUS', 'AEDXB', 'USLAX'][i % 5],
        destinationPort: 'NLRTM',
        vesselImo: 9811000,
        assignedVesselName: 'EVER GOLDEN',
        status: st,
        yardBlockId: block.id,
        bay,
        row,
        tier,
        position: { x: posX, y: posY, z: posZ },
        temperatureC: isReefer ? -18.2 : undefined,
        dwellDays: 1.8 + (i % 5) * 0.6,
        lifecycleHistory: [
          { stage: 'DISCHARGE_PLANNED', timestamp: '2026-08-29 02:00', location: 'EVER GOLDEN Bay 14', operatorOrAsset: 'TOS Core' },
          { stage: 'QUAY_STS_PICK', timestamp: '2026-08-29 06:14', location: 'Berth 01 / STS-02', operatorOrAsset: 'STS-02 Automated Spreader' },
          { stage: 'AGV_CHASSIS_TRANSFER', timestamp: '2026-08-29 06:16', location: 'Quay Transfer Zone 2', operatorOrAsset: 'AGV-08' },
          { stage: 'YARD_BLOCK_STACKING', timestamp: '2026-08-29 06:24', location: `${block.blockCode} Bay ${bay} Row ${row} Tier ${tier}`, operatorOrAsset: block.assignedRmgId },
        ],
      });
    }

    // 5. Vehicles (20 AGVs + 12 Terminal Road Trucks)
    const vehicles: Vehicle[] = [];
    for (let v = 1; v <= 18; v++) {
      const isAgv = v <= 12;
      const id = isAgv ? `AGV-${v < 10 ? '0' + v : v}` : `TRUCK-${v < 10 ? '0' + v : v}`;
      const startX = 100 + (v - 1) * 75;
      const startY = isAgv ? 180 : 205;

      vehicles.push({
        id,
        name: isAgv ? `Automated Guided Vehicle ${v}` : `Internal Terminal Truck ${v}`,
        type: isAgv ? 'AGV' : 'TERMINAL_TRUCK',
        position: { x: startX, y: startY, z: 0 },
        headingDeg: 90,
        speedMps: 6.5,
        status: v % 3 === 0 ? 'LOADING' : v % 3 === 1 ? 'EN_ROUTE_YARD' : 'EN_ROUTE_QUAY',
        assignedContainerId: v % 2 === 0 ? containers[v]?.id : undefined,
        pathWaypoints: [
          { x: 80, y: 180 },
          { x: 1300, y: 180 },
          { x: 1300, y: 220 },
          { x: 80, y: 220 },
        ],
        currentWaypointIdx: v % 4,
        batterySocPct: 78 + (v % 20),
        fuelLevelPct: 85,
        totalDistanceKm: 1420 + v * 45,
      });
    }

    // 6. Intermodal Rail Trains
    const railTrains: RailTrain[] = [
      {
        id: 'TRAIN_RT_4012',
        trainNumber: 'BETUWE-LINE-EXP-4012',
        wagonsCount: 22,
        locomotiveId: 'SIEMENS_VECTRON_193_452',
        lengthM: 640.0,
        position: { x: 380, y: 680, z: 0 },
        headingDeg: 90,
        speedKph: 0,
        status: 'STATIONARY_LOADING',
        loadedContainers: ['MSKU-700137-3', 'CMAU-700274-6', 'HLCU-700411-9'],
        capacityTeu: 88,
        trackId: 'RAIL_TRACK_02',
        departureTime: '2026-08-29 16:30 UTC',
        destinationDryPort: 'Duisburg Intermodal Gateway (DIT), Germany',
      },
      {
        id: 'TRAIN_RT_4015',
        trainNumber: 'ROTTERDAM-MUNICH-SHUTTLE',
        wagonsCount: 18,
        locomotiveId: 'TRAXX_F140_MS',
        lengthM: 520.0,
        position: { x: 890, y: 710, z: 0 },
        headingDeg: 90,
        speedKph: 15.0,
        status: 'ARRIVING',
        loadedContainers: ['ONEU-700548-2'],
        capacityTeu: 72,
        trackId: 'RAIL_TRACK_03',
        departureTime: '2026-08-29 19:15 UTC',
        destinationDryPort: 'Munich Riem Terminal, Germany',
      },
    ];

    this.cranes.set(cranes);
    this.vessels.set(vessels);
    this.yardBlocks.set(blocks);
    this.containers.set(containers);
    this.vehicles.set(vehicles);
    this.railTrains.set(railTrains);
  }

  private buildDefaultRotterdamConfig(): PortAuthorityConfig {
    return {
      id: 'port_rotterdam_gateway',
      name: 'Port of Rotterdam — Maasvlakte II Intermodal Hub',
      country: 'Netherlands',
      unLocode: 'NLRTM',
      crs: 'EPSG:28992',
      originLat: 51.9560,
      originLon: 4.0150,
      rotationDeg: -14.5,
      quaysLengthM: 1450.0,
      quaysDepthM: 20.0,
      berths: [
        {
          id: 'BERTH_RTM_01',
          terminalId: 'APM_TERMINALS_MVII',
          name: 'Maasvlakte Deepwater Berth 1',
          lengthM: 450.0,
          depthM: 20.0,
          maxDraftM: 19.5,
          bollardStartM: 0.0,
          bollardEndM: 450.0,
          currentVesselImo: 9811000,
          shorePowerActive: true,
          status: 'OCCUPIED',
          allocatedCranes: ['STS-01', 'STS-02'],
          position: { x: 225, y: 150 },
        },
        {
          id: 'BERTH_RTM_02',
          terminalId: 'APM_TERMINALS_MVII',
          name: 'Maasvlakte Deepwater Berth 2',
          lengthM: 400.0,
          depthM: 20.0,
          maxDraftM: 19.5,
          bollardStartM: 450.0,
          bollardEndM: 850.0,
          currentVesselImo: 9632064,
          shorePowerActive: true,
          status: 'OCCUPIED',
          allocatedCranes: ['STS-03', 'STS-04'],
          position: { x: 650, y: 150 },
        },
        {
          id: 'BERTH_RTM_03',
          terminalId: 'APM_TERMINALS_MVII',
          name: 'Maasvlakte Deepwater Berth 3',
          lengthM: 350.0,
          depthM: 18.5,
          maxDraftM: 18.0,
          bollardStartM: 850.0,
          bollardEndM: 1200.0,
          currentVesselImo: 9744647,
          shorePowerActive: false,
          status: 'OCCUPIED',
          allocatedCranes: ['STS-05'],
          position: { x: 1025, y: 150 },
        },
        {
          id: 'BERTH_RTM_04',
          terminalId: 'APM_TERMINALS_MVII',
          name: 'Feeder & Short-Sea Berth 4',
          lengthM: 250.0,
          depthM: 14.5,
          maxDraftM: 14.0,
          bollardStartM: 1200.0,
          bollardEndM: 1450.0,
          currentVesselImo: undefined,
          shorePowerActive: true,
          status: 'AVAILABLE',
          allocatedCranes: ['STS-07', 'STS-08'],
          position: { x: 1325, y: 150 },
        },
      ],
      cranes: [],
      yardBlocks: [],
      weather: {
        temperatureC: 18.4,
        windSpeedKnots: 12.6,
        windDirectionDeg: 240,
        visibilityKm: 14.0,
        condition: 'CLEAR',
        tideHeightM: 1.4,
      },
      metrics: {
        teuPerHour: 342,
        dailyTeu: 14850,
        berthUtilizationPct: 75,
        craneGcr: 34.2,
        yardDensityPct: 68,
        truckTurnaroundMins: 24.5,
        railIntermodalSharePct: 38.5,
        shorePowerUsageKw: 4850,
        co2KgPerTeu: 18.4,
        activeVesselsCount: 4,
        revenueTodayUsd: 1262250,
      },
    };
  }

  private buildFelixstoweConfig(): PortAuthorityConfig {
    const rtm = this.buildDefaultRotterdamConfig();
    return {
      ...rtm,
      id: 'port_felixstowe_trinity',
      name: 'Port of Felixstowe — Trinity Intermodal Terminal',
      country: 'United Kingdom',
      unLocode: 'GBFXT',
      crs: 'EPSG:27700',
      originLat: 51.9540,
      originLon: 1.3090,
      rotationDeg: 22.0,
      quaysLengthM: 1200.0,
      weather: {
        ...rtm.weather,
        windSpeedKnots: 18.2,
        condition: 'RAIN',
      },
      metrics: {
        ...rtm.metrics,
        teuPerHour: 280,
        dailyTeu: 11200,
        railIntermodalSharePct: 44.0,
      },
    };
  }

  private buildSingaporeConfig(): PortAuthorityConfig {
    const rtm = this.buildDefaultRotterdamConfig();
    return {
      ...rtm,
      id: 'port_singapore_pasir',
      name: 'Port of Singapore — Pasir Panjang Automated Terminal',
      country: 'Singapore',
      unLocode: 'SGSIN',
      crs: 'EPSG:3414',
      originLat: 1.2850,
      originLon: 103.7750,
      rotationDeg: -5.0,
      quaysLengthM: 1600.0,
      weather: {
        ...rtm.weather,
        temperatureC: 31.0,
        windSpeedKnots: 8.0,
        condition: 'CLEAR',
      },
      metrics: {
        ...rtm.metrics,
        teuPerHour: 510,
        dailyTeu: 22400,
        craneGcr: 39.5,
        yardDensityPct: 82,
      },
    };
  }

  private buildLosAngelesConfig(): PortAuthorityConfig {
    const rtm = this.buildDefaultRotterdamConfig();
    return {
      ...rtm,
      id: 'port_la_pier400',
      name: 'Port of Los Angeles — Pier 400 APM Terminal',
      country: 'United States',
      unLocode: 'USLAX',
      crs: 'EPSG:2229',
      originLat: 33.7220,
      originLon: -118.2530,
      rotationDeg: 45.0,
      quaysLengthM: 1300.0,
      metrics: {
        ...rtm.metrics,
        teuPerHour: 390,
        dailyTeu: 16800,
        truckTurnaroundMins: 38.0,
        railIntermodalSharePct: 32.0,
      },
    };
  }

  private buildDefaultScenarios(): WhatIfScenario[] {
    return [
      {
        id: 'SCENARIO_VOLUME_SURGE',
        name: 'Scenario A: +20% Peak Cargo Volume Surge',
        description: 'Simulates peak holiday season import surge. Evaluates yard stack saturation and gate congestion.',
        volumeMultiplier: 1.2,
        disabledCranesCount: 0,
        railCapacityFactor: 1.0,
        weatherSeverity: 'NORMAL',
        projectedTeuDaily: 17820,
        projectedWaitHours: 2.8,
        yardCongestionPct: 86,
        truckTurnaroundMins: 32.5,
        netRevenueImpactUsd: 252450,
        carbonDeltaTonnes: 54.2,
      },
      {
        id: 'SCENARIO_CRANE_OUTAGE',
        name: 'Scenario B: 2 Quay Cranes Mechanical Outage',
        description: 'Simulates unexpected STS drive gearbox failure on Berths 1 & 2 during mega-vessel turnaround.',
        volumeMultiplier: 1.0,
        disabledCranesCount: 2,
        railCapacityFactor: 1.0,
        weatherSeverity: 'NORMAL',
        projectedTeuDaily: 11900,
        projectedWaitHours: 9.4,
        yardCongestionPct: 74,
        truckTurnaroundMins: 29.0,
        netRevenueImpactUsd: -148500,
        carbonDeltaTonnes: 22.8,
      },
      {
        id: 'SCENARIO_GALE_FORCE_WIND',
        name: 'Scenario C: Severe Gale Force Winds (45+ Knots)',
        description: 'Enforces high-wind safety lockdown on STS boom angles. Vessel maneuvering suspended by harbour master.',
        volumeMultiplier: 1.0,
        disabledCranesCount: 6,
        railCapacityFactor: 0.8,
        weatherSeverity: 'GALE_WINDS',
        projectedTeuDaily: 4200,
        projectedWaitHours: 18.2,
        yardCongestionPct: 88,
        truckTurnaroundMins: 52.0,
        netRevenueImpactUsd: -384000,
        carbonDeltaTonnes: -12.4,
      },
      {
        id: 'SCENARIO_EXPAND_RAIL',
        name: 'Scenario D: Betuwe Intermodal Rail Expansion (+40%)',
        description: 'Models electrification and doubling of rail shuttle departures directly to European hinterland dry ports.',
        volumeMultiplier: 1.15,
        disabledCranesCount: 0,
        railCapacityFactor: 1.4,
        weatherSeverity: 'NORMAL',
        projectedTeuDaily: 17100,
        projectedWaitHours: 0.6,
        yardCongestionPct: 58,
        truckTurnaroundMins: 20.2,
        netRevenueImpactUsd: 310800,
        carbonDeltaTonnes: -86.5,
      },
    ];
  }

  // Real-time animation physics and discrete simulation tick
  private startSimulationLoop() {
    const loop = () => {
      const now = Date.now();
      const dt = (now - this.lastSimTick) / 1000;
      this.lastSimTick = now;

      if (this.isSimulationRunning()) {
        const speed = this.simulationSpeed();
        this.stepSimulation(dt * speed);
      }

      this.animationFrameId = requestAnimationFrame(loop);
    };

    this.animationFrameId = requestAnimationFrame(loop);
  }

  stepSimulation(simDtSeconds: number) {
    // Advance simulation time clock
    const current = this.simulationTime();
    this.simulationTime.set(new Date(current.getTime() + simDtSeconds * 1000));

    // 1. Animate STS Cranes
    this.cranes.update((cranes) =>
      cranes.map((crane) => {
        if (crane.mode === 'MAINTENANCE' || crane.mode === 'FAULT' || crane.mode === 'HIGH_WIND_LOCK') {
          return crane;
        }

        const progress = (crane.cycleProgress + (simDtSeconds / crane.avgCycleTimeSec)) % 1;
        
        // Trolley travels between ship hold (x=10m) and landside AGV lane (x=50m)
        const trolleyM = 15 + Math.sin(progress * Math.PI * 2) * 25 + 25;
        const hoistM = 8 + Math.cos(progress * Math.PI * 2) * 14 + 14;
        const spreaderLatched = progress > 0.25 && progress < 0.75;

        // Incremental moves count trigger
        let completed = crane.movesCompletedShift;
        if (progress < crane.cycleProgress) {
          completed++;
          if (Math.random() < 0.05) {
            this.addEventLog(
              crane.id,
              'CONTAINER_CYCLE_COMPLETE',
              'INFO',
              `${crane.name} completed cycle in ${crane.avgCycleTimeSec}s. Container transferred to AGV.`,
              `Quay Gantry Pos ${Math.round(crane.gantryPosM)}m`
            );
          }
        }

        return {
          ...crane,
          trolleyPosM: Math.round(trolleyM * 10) / 10,
          hoistHeightM: Math.round(hoistM * 10) / 10,
          spreaderLatched,
          cycleProgress: progress,
          movesCompletedShift: completed,
          currentPowerKw: 380 + Math.sin(progress * 10) * 120,
          cumulativeEnergyKwh: crane.cumulativeEnergyKwh + (crane.currentPowerKw * simDtSeconds) / 3600,
        };
      })
    );

    // 2. Animate AGVs & Internal Terminal Road Trucks
    this.vehicles.update((vehicles) =>
      vehicles.map((v) => {
        const speed = v.speedMps * (v.type === 'AGV' ? 1.0 : 1.2);
        let newX = v.position.x + (v.headingDeg === 90 ? speed * simDtSeconds : -speed * simDtSeconds);
        let heading = v.headingDeg;
        let yPos = v.position.y;

        if (newX > 1400) {
          heading = 270;
          newX = 1400;
          yPos = v.type === 'AGV' ? 220 : 250;
        } else if (newX < 60) {
          heading = 90;
          newX = 60;
          yPos = v.type === 'AGV' ? 180 : 205;
        }

        return {
          ...v,
          position: { ...v.position, x: newX, y: yPos },
          headingDeg: heading,
          totalDistanceKm: v.totalDistanceKm + (speed * simDtSeconds) / 1000,
          batterySocPct: Math.max(15, v.batterySocPct - 0.0002 * simDtSeconds),
        };
      })
    );

    // 3. Animate Approaching & Berthing Vessels
    this.vessels.update((vessels) =>
      vessels.map((vessel) => {
        if (vessel.status === 'APPROACHING') {
          const newX = vessel.position.x - (vessel.speedKnots * 0.514 * simDtSeconds);
          if (newX <= 1350) {
            this.addEventLog(
              vessel.name,
              'VESSEL_PILOT_BOARDED',
              'INFO',
              `Harbour Pilot aboard ${vessel.name} (IMO ${vessel.imo}). Tug assistance initiated for Berth 4.`,
              'Fairway Channel'
            );
            return {
              ...vessel,
              position: { ...vessel.position, x: 1350, y: 85 },
              speedKnots: 1.8,
              status: 'BERTHING',
            };
          }
          return {
            ...vessel,
            position: { ...vessel.position, x: newX },
          };
        } else if (vessel.status === 'BERTHING') {
          const newX = vessel.position.x - 0.8 * simDtSeconds;
          if (newX <= 1325) {
            this.addEventLog(
              vessel.name,
              'VESSEL_ALL_FAST_BERTHED',
              'SUCCESS',
              `${vessel.name} safely moored at Feeder Berth 4. Shore power connected.`,
              'Berth 04'
            );
            return {
              ...vessel,
              position: { ...vessel.position, x: 1325 },
              speedKnots: 0,
              status: 'BERTHED',
            };
          }
          return {
            ...vessel,
            position: { ...vessel.position, x: newX },
          };
        } else if (vessel.status === 'UNLOADING' || vessel.status === 'BERTHED') {
          // Progress discharge
          if (vessel.containersDischarged < vessel.containersToDischarge) {
            const add = Math.random() < 0.1 ? 1 : 0;
            return {
              ...vessel,
              containersDischarged: Math.min(vessel.containersToDischarge, vessel.containersDischarged + add),
            };
          }
        }
        return vessel;
      })
    );

    // 4. Animate Rail Freight Movements
    this.railTrains.update((trains) =>
      trains.map((t) => {
        if (t.status === 'ARRIVING') {
          const newX = t.position.x - 4.0 * simDtSeconds;
          if (newX <= 550) {
            return {
              ...t,
              position: { ...t.position, x: 550 },
              speedKph: 0,
              status: 'STATIONARY_LOADING',
            };
          }
          return {
            ...t,
            position: { ...t.position, x: newX },
          };
        }
        return t;
      })
    );
  }

  // Interactive Asset Selection
  selectAsset(type: string, id: string) {
    let data: unknown = null;
    if (type === 'CRANE') {
      data = this.cranes().find((c) => c.id === id);
    } else if (type === 'VESSEL') {
      data = this.vessels().find((v) => v.imo.toString() === id || v.name === id);
    } else if (type === 'CONTAINER') {
      data = this.containers().find((c) => c.id === id);
    } else if (type === 'YARD_BLOCK') {
      data = this.yardBlocks().find((b) => b.id === id || b.blockCode === id);
    } else if (type === 'VEHICLE') {
      data = this.vehicles().find((v) => v.id === id);
    } else if (type === 'BERTH') {
      data = this.portConfig().berths.find((b) => b.id === id);
    } else if (type === 'TRAIN') {
      data = this.railTrains().find((t) => t.id === id);
    }

    this.selectedAsset.set(data ? { type, id, data } : null);
  }

  clearSelection() {
    this.selectedAsset.set(null);
  }

  // Time Engine & Replay
  toggleSimulation() {
    this.isSimulationRunning.update((r) => !r);
    this.addEventLog('SYSTEM', this.isSimulationRunning() ? 'SIM_RESUMED' : 'SIM_PAUSED', 'INFO', `Digital twin time engine: ${this.isSimulationRunning() ? 'RUNNING' : 'PAUSED'}`, 'Local Clock');
  }

  setSpeed(speed: number) {
    this.simulationSpeed.set(speed);
    this.addEventLog('SYSTEM', 'SPEED_CHANGED', 'INFO', `Time acceleration warp set to ${speed}x real-time`, 'Physics Loop');
  }

  rewindToHistorical(hoursAgo: number) {
    const historical = new Date(Date.now() - hoursAgo * 3600 * 1000);
    this.simulationTime.set(historical);
    this.addEventLog('SYSTEM', 'HISTORICAL_REPLAY', 'ALERT', `Reconstructed port operational state for ${historical.toISOString()}`, 'Time Machine');
  }

  // What-If Scenario Execution
  runScenario(scenarioId: string) {
    const sc = this.activeScenarios().find((s) => s.id === scenarioId);
    if (!sc) return;
    this.activeScenarioId.set(scenarioId);

    // Apply scenario parameters to port environment
    if (sc.disabledCranesCount > 0) {
      this.cranes.update((cranes) =>
        cranes.map((c, idx) =>
          idx < sc.disabledCranesCount ? { ...c, mode: 'HIGH_WIND_LOCK' as const } : c
        )
      );
    }

    this.portConfig.update((cfg) => ({
      ...cfg,
      weather: {
        ...cfg.weather,
        condition: sc.weatherSeverity === 'GALE_WINDS' ? 'GALE_WARNING' : 'CLEAR',
        windSpeedKnots: sc.weatherSeverity === 'GALE_WINDS' ? 48.0 : 12.0,
      },
      metrics: {
        ...cfg.metrics,
        dailyTeu: sc.projectedTeuDaily,
        truckTurnaroundMins: sc.truckTurnaroundMins,
        yardDensityPct: sc.yardCongestionPct,
        revenueTodayUsd: cfg.metrics.revenueTodayUsd + sc.netRevenueImpactUsd,
      },
    }));

    this.addEventLog(
      'SCENARIO_ENGINE',
      'WHAT_IF_EXECUTED',
      'ALERT',
      `Applied ${sc.name}. Daily TEU projected at ${sc.projectedTeuDaily} (Net impact: $${sc.netRevenueImpactUsd > 0 ? '+' : ''}${sc.netRevenueImpactUsd})`,
      'Optimization Core'
    );
  }

  resetToLiveBaseline() {
    this.activeScenarioId.set(null);
    this.loadPort(this.activePortId());
    this.addEventLog('SYSTEM', 'LIVE_BASELINE_RESTORED', 'SUCCESS', 'Reset scenario sandbox to live authoritative telemetry feed', 'PostGIS Authoritative DB');
  }

  // Geospatial Editor Commits
  commitEditorAddition(type: 'BERTH' | 'CRANE' | 'YARD' | 'ROAD' | 'RAIL', coord: LocalPortCoord) {
    if (type === 'CRANE') {
      const newId = `STS-${this.cranes().length + 1 < 10 ? '0' + (this.cranes().length + 1) : this.cranes().length + 1}`;
      const newCrane: Crane = {
        id: newId,
        name: `New STS Crane ${newId}`,
        type: 'STS',
        gantryPosM: coord.x,
        trolleyPosM: 30,
        hoistHeightM: 20,
        boomAngleDeg: 0,
        spreaderLatched: false,
        mode: 'IDLE',
        movesCompletedShift: 0,
        avgCycleTimeSec: 90,
        currentPowerKw: 0,
        cumulativeEnergyKwh: 0,
        maintenanceDueDays: 30,
        vibrationRms: 0.02,
        tempMotorC: 25.0,
        position: coord,
        cycleProgress: 0,
      };
      this.cranes.update((list) => [...list, newCrane]);
      this.addEventLog('EDITOR', 'CRANE_COMMITTED', 'SUCCESS', `Created ${newId} at (${Math.round(coord.x)}m, ${Math.round(coord.y)}m) in PostGIS`, 'Spatial Layer');
    } else if (type === 'YARD') {
      const code = `X0${this.yardBlocks().length + 1}`;
      const newBlock: YardBlock = {
        id: `BLOCK_${code}`,
        blockCode: code,
        name: `New Yard Block ${code}`,
        type: 'DRY',
        baysCount: 24,
        rowsCount: 6,
        maxTiers: 5,
        position: coord,
        widthM: 160,
        lengthM: 65,
        occupiedSlots: 0,
        totalCapacity: 24 * 6 * 5,
        assignedRmgId: `RMG-${code}`,
      };
      this.yardBlocks.update((list) => [...list, newBlock]);
      this.addEventLog('EDITOR', 'YARD_BLOCK_COMMITTED', 'SUCCESS', `Constructed Yard Block ${code} in PostGIS geometry table`, 'Spatial Layer');
    }
  }

  addEventLog(assetId: string, eventType: string, severity: 'INFO' | 'WARNING' | 'ALERT' | 'SUCCESS', message: string, location: string) {
    const newLog: PortEventLog = {
      id: Math.random().toString(36).substring(2, 9),
      timestamp: new Date().toTimeString().split(' ')[0],
      assetId,
      assetType: 'PORT_ASSET',
      eventType,
      severity,
      message,
      location,
    };
    this.eventLogs.update((logs) => [newLog, ...logs.slice(0, 49)]);
  }
}
