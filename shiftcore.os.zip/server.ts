import express from 'express';
import path from 'path';
import { GoogleGenAI } from '@google/genai';
import { SEED_EMPLOYEES, SEED_LOCATIONS, SEED_DEPARTMENTS, SEED_ROLES } from './src/data/seedData';
import { generateOptimalSchedule } from './src/engine/scheduler';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get('/api/v1/health', (req, res) => {
    res.json({ status: 'ok', engine: 'SHIFTCORE.OS Rust-First Scheduler Engine v3.5' });
  });

  app.get('/api/v1/employees', (req, res) => {
    res.json(SEED_EMPLOYEES);
  });

  app.get('/api/v1/locations', (req, res) => {
    res.json(SEED_LOCATIONS);
  });

  app.post('/api/v1/schedules/generate', (req, res) => {
    const { locationId, startDate, strategy } = req.body;
    const targetLoc = locationId || 'LOC-104';
    const targetDate = startDate || '2026-09-07';

    const schedule = generateOptimalSchedule(targetLoc, targetDate, SEED_EMPLOYEES, 'ALL', {
      strategy: strategy || 'BALANCED',
    });

    res.json(schedule);
  });

  // AI Operations Manager Assistant using Gemini 2.5 API
  app.post('/api/v1/ai/query', async (req, res) => {
    const { query, activeSchedule } = req.body;

    if (!query) {
      return res.status(400).json({ error: 'Query parameter is required' });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(500).json({
        answer: 'Gemini API key is not configured. (Configure GEMINI_API_KEY in secrets). Using local engine fallback.',
        actionRequired: 'NONE',
      });
    }

    try {
      const ai = new GoogleGenAI({ apiKey });

      const contextSummary = `
You are the AI Operations Manager for SHIFTCORE.OS, an enterprise workforce optimisation engine.
Live System State:
- Store: Metropolis Flagship #104
- Active Employees Count: ${SEED_EMPLOYEES.length}
- Departments: ${SEED_DEPARTMENTS.map(d => d.name).join(', ')}
- Roles: ${SEED_ROLES.map(r => r.name).join(', ')}
- Current Schedule Coverage: ${activeSchedule?.score?.demandCoveragePct || 97.8}%
- Total Labour Cost: $${activeSchedule?.score?.totalLabourCost || 18420.50}
- Overtime Hours: ${activeSchedule?.score?.overtimeHoursTotal || 3.5}h
- Preference Score: ${activeSchedule?.score?.employeePreferencePct || 91.6}%

User Manager Question: "${query}"

Provide a concise, highly professional, data-backed enterprise answer. Be specific about constraints, cost, coverage, and employee availability. Never invent fake data; base answers strictly on the workforce engine context.
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: contextSummary,
      });

      res.json({
        answer: response.text || 'Unable to generate response.',
      });
    } catch (err: any) {
      console.error('Gemini API Error:', err);
      res.status(500).json({
        answer: `ShiftCore AI Error: ${err.message || 'Error processing request'}`,
      });
    }
  });

  // Vite middleware for development vs static build for production
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[SHIFTCORE.OS] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
