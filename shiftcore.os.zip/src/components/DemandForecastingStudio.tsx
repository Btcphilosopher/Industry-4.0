import React, { useState } from 'react';
import { TrendingUp, BarChart3, ShoppingBag, Users, Calendar, Layers, Cpu } from 'lucide-react';
import { generateDemandForecast } from '../engine/demand';
import { SEED_ROLES } from '../data/seedData';

interface DemandForecastingStudioProps {
  locationId: string;
}

export const DemandForecastingStudio: React.FC<DemandForecastingStudioProps> = ({ locationId }) => {
  const [selectedModel, setSelectedModel] = useState<'SEASONAL_REGRESSION' | 'EXPONENTIAL_SMOOTHING' | 'MOVING_AVERAGE' | 'ML_ENSEMBLE'>('SEASONAL_REGRESSION');
  const [growthFactor, setGrowthFactor] = useState<number>(1.0);
  const [selectedDate, setSelectedDate] = useState<string>('2026-09-07');

  const forecast = generateDemandForecast(locationId, selectedDate, selectedModel, growthFactor);

  const totalSalesForecast = forecast.hourlyData.reduce((sum, h) => sum + h.salesForecast, 0);
  const totalFootfall = forecast.hourlyData.reduce((sum, h) => sum + h.customerTraffic, 0);
  const totalTransactions = forecast.hourlyData.reduce((sum, h) => sum + h.transactions, 0);

  return (
    <div className="space-y-6">
      {/* Forecasting Control Panel */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div>
            <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
              <TrendingUp className="w-5 h-5 text-blue-400" />
              <span>Labour Demand & Workload Forecasting Studio</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Transforms business sales, footfall, inventory tasks, and promotional uplift into required staffing headcounts per hour.
            </p>
          </div>

          <div className="flex items-center space-x-3 text-xs">
            {/* Model Selector */}
            <div className="flex items-center space-x-1.5 bg-slate-800 border border-slate-700 px-3 py-1.5 rounded-lg">
              <Cpu className="w-4 h-4 text-indigo-400" />
              <select
                value={selectedModel}
                onChange={e => setSelectedModel(e.target.value as any)}
                className="bg-transparent text-slate-200 font-medium focus:outline-none cursor-pointer"
              >
                <option value="SEASONAL_REGRESSION" className="bg-slate-900">Seasonal Time-Series Regression</option>
                <option value="EXPONENTIAL_SMOOTHING" className="bg-slate-900">Holt-Winters Exponential Smoothing</option>
                <option value="MOVING_AVERAGE" className="bg-slate-900">Weighted Moving Average (4-Wk)</option>
                <option value="ML_ENSEMBLE" className="bg-slate-900">Machine Learning Ensemble (96% Confidence)</option>
              </select>
            </div>

            {/* Date Selector */}
            <input
              type="date"
              value={selectedDate}
              onChange={e => setSelectedDate(e.target.value)}
              className="bg-slate-800 border border-slate-700 text-slate-200 font-mono px-3 py-1.5 rounded-lg focus:outline-none cursor-pointer"
            />
          </div>
        </div>

        {/* Demand Scenario Slider */}
        <div className="flex items-center justify-between bg-slate-950 p-3 rounded-lg border border-slate-850 text-xs">
          <div className="flex items-center space-x-2 text-slate-300 font-medium">
            <BarChart3 className="w-4 h-4 text-emerald-400" />
            <span>Promotional Demand Growth / Footfall Modifier:</span>
            <span className="font-mono font-bold text-emerald-400">
              {growthFactor === 1.0 ? 'Standard Baseline (1.0x)' : `${growthFactor.toFixed(2)}x (${Math.round((growthFactor - 1) * 100)}% Growth)`}
            </span>
          </div>

          <input
            type="range"
            min="0.8"
            max="1.5"
            step="0.05"
            value={growthFactor}
            onChange={e => setGrowthFactor(parseFloat(e.target.value))}
            className="w-48 cursor-pointer accent-emerald-500"
          />
        </div>
      </div>

      {/* Forecast Aggregates */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400 font-medium">Predicted Daily Store Revenue</div>
            <div className="text-2xl font-extrabold text-slate-100 mt-1">${totalSalesForecast.toLocaleString()}</div>
          </div>
          <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-lg">
            <ShoppingBag className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400 font-medium">Predicted Customer Footfall</div>
            <div className="text-2xl font-extrabold text-slate-100 mt-1">{totalFootfall.toLocaleString()} Customers</div>
          </div>
          <div className="p-3 bg-blue-500/10 text-blue-400 rounded-lg">
            <Users className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400 font-medium">POS Transactions Volume</div>
            <div className="text-2xl font-extrabold text-slate-100 mt-1">{totalTransactions.toLocaleString()}</div>
          </div>
          <div className="p-3 bg-indigo-500/10 text-indigo-400 rounded-lg">
            <BarChart3 className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Detailed Hourly Demand Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="p-4 border-b border-slate-800 font-bold text-sm text-slate-100 flex items-center justify-between">
          <span>Continuous Hourly Staffing Headcount Requirements Matrix</span>
          <span className="text-xs text-slate-400 font-mono font-normal">Model: {selectedModel}</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-950 text-slate-400 border-b border-slate-800 font-mono">
                <th className="p-3">Hour</th>
                <th className="p-3">Footfall</th>
                <th className="p-3">Sales ($)</th>
                <th className="p-3">Cashiers Req.</th>
                <th className="p-3">Stockers Req.</th>
                <th className="p-3">Produce Req.</th>
                <th className="p-3">Manager Req.</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {forecast.hourlyData.filter(h => h.hour >= 6 && h.hour <= 22).map(h => (
                <tr key={h.hour} className="hover:bg-slate-850/50">
                  <td className="p-3 font-bold text-slate-200">{String(h.hour).padStart(2, '0')}:00</td>
                  <td className="p-3 text-blue-400">{h.customerTraffic}</td>
                  <td className="p-3 text-emerald-400">${h.salesForecast.toLocaleString()}</td>
                  <td className="p-3 font-bold text-slate-100">{h.requiredStaffHeadcount['ROLE-CASHIER'] || 0}</td>
                  <td className="p-3 font-bold text-slate-100">{h.requiredStaffHeadcount['ROLE-GROC-STOCK'] || 0}</td>
                  <td className="p-3 font-bold text-slate-100">{h.requiredStaffHeadcount['ROLE-PROD-SPEC'] || 0}</td>
                  <td className="p-3 font-bold text-slate-100">{h.requiredStaffHeadcount['ROLE-MGR'] || 0}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
