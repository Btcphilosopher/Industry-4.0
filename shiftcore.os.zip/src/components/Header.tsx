import React from 'react';
import {
  Building2,
  Calendar,
  Sparkles,
  Zap,
  ShieldCheck,
  UserCheck,
  Clock,
  Layers,
  TrendingUp,
  Activity,
  FileSpreadsheet
} from 'lucide-react';
import { Location } from '../types/domain';

interface HeaderProps {
  locations: Location[];
  selectedLocationId: string;
  onSelectLocation: (id: string) => void;
  activeTab: string;
  onTabChange: (tab: string) => void;
  userRole: 'MANAGER' | 'EMPLOYEE';
  onRoleToggle: () => void;
  onOpenAiAssistant: () => void;
  onGenerateScheduleClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  locations,
  selectedLocationId,
  onSelectLocation,
  activeTab,
  onTabChange,
  userRole,
  onRoleToggle,
  onOpenAiAssistant,
  onGenerateScheduleClick,
}) => {
  const currentLoc = locations.find(l => l.id === selectedLocationId) || locations[0];

  const navItems = [
    { id: 'COMMAND', label: 'Command Centre', icon: Activity },
    { id: 'SCHEDULER', label: 'Weekly Scheduler', icon: Calendar },
    { id: 'DEMAND', label: 'Demand & Forecast', icon: TrendingUp },
    { id: 'WHATIF', label: 'What-If & Monte Carlo', icon: Zap },
    { id: 'ROSTER', label: 'Workforce & Skills', icon: UserCheck },
    { id: 'SWAPS', label: 'Open Shifts & Swaps', icon: Layers },
    { id: 'ACTUALS', label: 'Time Clock & Variance', icon: Clock },
    { id: 'AUDIT', label: 'Audit & Versions', icon: ShieldCheck },
  ];

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-slate-100 sticky top-0 z-30 shadow-md">
      {/* Top Utility Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5 flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-800/80">
        <div className="flex items-center space-x-3">
          <div className="bg-blue-600 text-white font-bold p-1.5 rounded-md flex items-center justify-center tracking-wider text-xs shadow-inner">
            <span className="font-mono text-sm px-1">SHIFTCORE</span>
            <span className="bg-slate-900 text-blue-400 text-[10px] px-1 py-0.5 rounded font-mono ml-1">OS 3.5</span>
          </div>
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 hidden sm:inline">
            Enterprise Workforce Optimisation Operating System
          </span>
        </div>

        <div className="flex items-center space-x-3 text-xs">
          {/* Location Switcher */}
          <div className="flex items-center bg-slate-800/90 border border-slate-700 rounded-md px-2.5 py-1 text-slate-200">
            <Building2 className="w-3.5 h-3.5 text-blue-400 mr-1.5" />
            <select
              value={selectedLocationId}
              onChange={e => onSelectLocation(e.target.value)}
              className="bg-transparent border-none text-slate-200 font-medium focus:outline-none cursor-pointer pr-2"
            >
              {locations.map(loc => (
                <option key={loc.id} value={loc.id} className="bg-slate-900 text-slate-200">
                  {loc.name} ({loc.code})
                </option>
              ))}
            </select>
          </div>

          {/* AI Assistant Button */}
          <button
            onClick={onOpenAiAssistant}
            className="flex items-center space-x-1.5 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white px-3 py-1 rounded-md font-medium text-xs shadow transition-all cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>ShiftCore AI</span>
          </button>

          {/* Generate Schedule Primary CTA */}
          <button
            onClick={onGenerateScheduleClick}
            className="flex items-center space-x-1.5 bg-emerald-600 hover:bg-emerald-500 text-white px-3 py-1 rounded-md font-semibold text-xs shadow transition-all cursor-pointer"
          >
            <Zap className="w-3.5 h-3.5 text-emerald-200 fill-current" />
            <span>GENERATE OPTIMAL SCHEDULE</span>
          </button>

          {/* Role Toggle Switcher */}
          <button
            onClick={onRoleToggle}
            className={`px-2.5 py-1 rounded-md font-mono text-[11px] font-semibold border transition-all cursor-pointer ${
              userRole === 'MANAGER'
                ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
            }`}
          >
            ROLE: {userRole}
          </button>
        </div>
      </div>

      {/* Primary Module Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center space-x-1 overflow-x-auto py-1 scrollbar-none">
        {navItems.map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`flex items-center space-x-2 px-3 py-2 rounded-md text-xs font-medium whitespace-nowrap transition-colors cursor-pointer ${
                isActive
                  ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-blue-400' : 'text-slate-400'}`} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
