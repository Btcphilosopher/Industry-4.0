import React, { useState } from 'react';
import { Zap, ShieldAlert, Cpu, BarChart2, Activity, Play, CheckCircle2 } from 'lucide-react';
import { Employee, WhatIfScenario, MonteCarloResult } from '../types/domain';
import { runMonteCarloSimulation, runOptimisationBenchmark, BenchmarkComparison } from '../engine/simulator';

interface WhatIfLabProps {
  locationId: string;
  employees: Employee[];
}

export const WhatIfLab: React.FC<WhatIfLabProps> = ({ locationId, employees }) => {
  const [selectedScenarioType, setSelectedScenarioType] = useState<WhatIfScenario['type']>('ABSENCE_CALLIN');
  const [monteCarloRuns, setMonteCarloRuns] = useState<number>(500);
  const [simResult, setSimResult] = useState<MonteCarloResult | null>(null);
  const [benchmarks, setBenchmarks] = useState<BenchmarkComparison[] | null>(null);
  const [isRunning, setIsRunning] = useState<boolean>(false);

  const handleRunSimulation = () => {
    setIsRunning(true);
    setTimeout(() => {
      const scenario: WhatIfScenario = {
        type: selectedScenarioType,
        params: {},
      };
      const res = runMonteCarloSimulation(locationId, '2026-09-07', employees, scenario, monteCarloRuns);
      const bench = runOptimisationBenchmark(locationId, '2026-09-07', employees);

      setSimResult(res);
      setBenchmarks(bench);
      setIsRunning(false);
    }, 400);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div>
            <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
              <Zap className="w-5 h-5 text-amber-400 fill-current" />
              <span>What-If Scenario & Monte Carlo Workforce Simulation Engine</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Simulates operational disruptions, unscheduled call-ins, demand surges, store closure events, and benchmarks algorithm efficiency.
            </p>
          </div>

          <button
            onClick={handleRunSimulation}
            disabled={isRunning}
            className="flex items-center space-x-2 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-bold px-4 py-2 rounded-lg text-xs shadow transition-all cursor-pointer disabled:opacity-50"
          >
            <Play className={`w-4 h-4 ${isRunning ? 'animate-spin' : ''}`} />
            <span>{isRunning ? 'Running Monte Carlo...' : 'RUN SIMULATION & BENCHMARK'}</span>
          </button>
        </div>

        {/* Scenario Controls */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div>
            <label className="block text-slate-400 font-medium mb-1.5">Select Stress Scenario:</label>
            <select
              value={selectedScenarioType}
              onChange={e => setSelectedScenarioType(e.target.value as any)}
              className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg p-2.5 focus:outline-none cursor-pointer"
            >
              <option value="ABSENCE_CALLIN">Employee Unscheduled Absence / Sick Call-In (15% Absence Rate)</option>
              <option value="DEMAND_SPIKE">Unexpected Customer Traffic & Footfall Spike (+25% Demand Surge)</option>
              <option value="STORE_EARLY_CLOSE">Severe Weather Event / Early Store Closure (-15% Hours)</option>
              <option value="BUDGET_CUT">Labour Budget Cut / Wage Allocation Restriction (-10% Spend)</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-400 font-medium mb-1.5">Monte Carlo Iterations Count:</label>
            <select
              value={monteCarloRuns}
              onChange={e => setMonteCarloRuns(parseInt(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg p-2.5 focus:outline-none cursor-pointer font-mono"
            >
              <option value={100}>100 Stochastic Runs</option>
              <option value={500}>500 Stochastic Runs (Standard)</option>
              <option value={1000}>1,000 High-Precision Runs</option>
            </select>
          </div>
        </div>
      </div>

      {/* Simulation Results Display */}
      {simResult && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-slate-100 flex items-center space-x-2">
              <Activity className="w-4 h-4 text-emerald-400" />
              <span>Monte Carlo Risk Analysis Results ({simResult.iterationsRun} Iterations)</span>
            </h3>
            <span
              className={`px-3 py-1 rounded-full text-xs font-bold ${
                simResult.riskCategory === 'LOW'
                  ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                  : 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
              }`}
            >
              OPERATIONAL RISK LEVEL: {simResult.riskCategory}
            </span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-850">
              <div className="text-slate-400 font-medium">Shift Coverage Probability</div>
              <div className="text-xl font-extrabold text-emerald-400 mt-1 font-mono">
                {Math.round(simResult.coverageProbability * 100)}%
              </div>
            </div>

            <div className="bg-slate-950 p-3 rounded-lg border border-slate-850">
              <div className="text-slate-400 font-medium">Understaffing Probability</div>
              <div className="text-xl font-extrabold text-rose-400 mt-1 font-mono">
                {Math.round(simResult.understaffingProbability * 100)}%
              </div>
            </div>

            <div className="bg-slate-950 p-3 rounded-lg border border-slate-850">
              <div className="text-slate-400 font-medium">Overtime Risk Probability</div>
              <div className="text-xl font-extrabold text-amber-400 mt-1 font-mono">
                {Math.round(simResult.overtimeProbability * 100)}%
              </div>
            </div>

            <div className="bg-slate-950 p-3 rounded-lg border border-slate-850">
              <div className="text-slate-400 font-medium">Mean Labour Spend</div>
              <div className="text-xl font-extrabold text-slate-100 mt-1 font-mono">
                ${simResult.averageLabourCost.toLocaleString()}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Algorithm Benchmark Comparison */}
      {benchmarks && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-slate-100 flex items-center space-x-2">
              <Cpu className="w-4 h-4 text-blue-400" />
              <span>Algorithm Performance Benchmark Suite</span>
            </h3>
            <span className="text-xs text-slate-400">Comparing 4 scheduling approaches</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-950 text-slate-400 border-b border-slate-800 font-mono">
                  <th className="p-3">Algorithm</th>
                  <th className="p-3">Demand Coverage</th>
                  <th className="p-3">Labour Cost</th>
                  <th className="p-3">Overtime Hours</th>
                  <th className="p-3">Preferences</th>
                  <th className="p-3">Hard Violations</th>
                  <th className="p-3">Runtime (ms)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {benchmarks.map((b, i) => (
                  <tr key={i} className={i === 3 ? 'bg-blue-950/20 font-bold' : 'hover:bg-slate-850/50'}>
                    <td className="p-3 text-slate-200 flex items-center space-x-2">
                      {i === 3 && <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />}
                      <span>{b.algorithmName}</span>
                    </td>
                    <td className="p-3 text-emerald-400">{b.coveragePct}%</td>
                    <td className="p-3 text-slate-100">${b.totalLabourCost.toLocaleString()}</td>
                    <td className="p-3 text-rose-400">{b.overtimeHours}h</td>
                    <td className="p-3 text-indigo-400">{b.preferenceScorePct}%</td>
                    <td className="p-3 text-amber-400">{b.hardViolationsCount}</td>
                    <td className="p-3 text-blue-400">{b.runtimeMs}ms</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
