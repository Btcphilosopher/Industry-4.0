import React from 'react';
import {
  Users,
  CheckCircle2,
  AlertTriangle,
  Clock,
  DollarSign,
  TrendingUp,
  Activity,
  ArrowUpRight,
  ShieldAlert,
  Zap,
  Building,
  UserCheck
} from 'lucide-react';
import { ScheduleResult, Employee, HourlyDemandPoint } from '../types/domain';
import { generateDemandCurve } from '../engine/demand';

interface ManagerCommandCentreProps {
  schedule: ScheduleResult;
  employees: Employee[];
  onNavigateTab: (tab: string) => void;
  onGenerateSchedule: () => void;
}

export const ManagerCommandCentre: React.FC<ManagerCommandCentreProps> = ({
  schedule,
  employees,
  onNavigateTab,
  onGenerateSchedule,
}) => {
  const demandCurve: HourlyDemandPoint[] = generateDemandCurve(schedule.locationId, '2026-09-07');

  // Operational Status logic
  const isCritical = schedule.score.unassignedShiftsCount > 5;
  const isAtRisk = schedule.score.unassignedShiftsCount > 0 || schedule.score.overtimeHoursTotal > 10;
  const statusBadge = isCritical ? (
    <span className="flex items-center space-x-1.5 px-3 py-1 rounded-full bg-rose-500/15 text-rose-400 border border-rose-500/30 text-xs font-semibold">
      <ShieldAlert className="w-4 h-4 text-rose-400 animate-pulse" />
      <span>CRITICAL — {schedule.score.unassignedShiftsCount} OPEN COVERAGE GAPS</span>
    </span>
  ) : isAtRisk ? (
    <span className="flex items-center space-x-1.5 px-3 py-1 rounded-full bg-amber-500/15 text-amber-400 border border-amber-500/30 text-xs font-semibold">
      <AlertTriangle className="w-4 h-4 text-amber-400" />
      <span>AT RISK — {schedule.score.unassignedShiftsCount} OPEN SHIFTS / {schedule.score.overtimeHoursTotal}h OVERTIME</span>
    </span>
  ) : (
    <span className="flex items-center space-x-1.5 px-3 py-1 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 text-xs font-semibold">
      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
      <span>COVERED — OPERATIONAL OPTIMUM ACHIEVED</span>
    </span>
  );

  return (
    <div className="space-y-6">
      {/* Top Banner Status */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-3 mb-1">
            <h1 className="text-xl font-bold text-slate-100 tracking-tight">Manager Operations Command Centre</h1>
            {statusBadge}
          </div>
          <p className="text-xs text-slate-400">
            Real-time workforce state, demand curves, and shift constraint telemetry for Metropolis Flagship Store #104
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => onNavigateTab('WHATIF')}
            className="flex items-center space-x-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 px-3 py-2 rounded-lg text-xs font-medium cursor-pointer transition-colors"
          >
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span>Simulate Absence / Spike</span>
          </button>
          <button
            onClick={onGenerateSchedule}
            className="flex items-center space-x-1.5 bg-blue-600 hover:bg-blue-500 text-white px-3.5 py-2 rounded-lg text-xs font-semibold shadow cursor-pointer transition-colors"
          >
            <Activity className="w-3.5 h-3.5" />
            <span>Re-Optimize Engine</span>
          </button>
        </div>
      </div>

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-6 gap-3">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium mb-1">
            <span>Demand Coverage</span>
            <TrendingUp className="w-3.5 h-3.5 text-blue-400" />
          </div>
          <div className="text-2xl font-extrabold text-slate-100">{schedule.score.demandCoveragePct}%</div>
          <div className="text-[11px] text-emerald-400 font-medium mt-1 flex items-center">
            <ArrowUpRight className="w-3 h-3 mr-0.5" />
            Target &gt;95%
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium mb-1">
            <span>Scheduled Labour Spend</span>
            <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="text-2xl font-extrabold text-slate-100">${schedule.score.totalLabourCost.toLocaleString()}</div>
          <div className="text-[11px] text-slate-400 mt-1">Within budget allowance</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium mb-1">
            <span>Open Coverage Gaps</span>
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="text-2xl font-extrabold text-slate-100">{schedule.score.unassignedShiftsCount}</div>
          <div className="text-[11px] text-amber-400 font-medium mt-1">
            {schedule.score.unassignedShiftsCount > 0 ? 'Requires Auto-Fill' : 'Fully Assigned'}
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium mb-1">
            <span>Overtime Hours</span>
            <Clock className="w-3.5 h-3.5 text-rose-400" />
          </div>
          <div className="text-2xl font-extrabold text-slate-100">{schedule.score.overtimeHoursTotal}h</div>
          <div className="text-[11px] text-slate-400 mt-1">1.5x Premium Rate</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium mb-1">
            <span>Preference Score</span>
            <UserCheck className="w-3.5 h-3.5 text-indigo-400" />
          </div>
          <div className="text-2xl font-extrabold text-slate-100">{schedule.score.employeePreferencePct}%</div>
          <div className="text-[11px] text-emerald-400 mt-1">Fairness: {schedule.score.fairnessPct}%</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium mb-1">
            <span>Active Roster</span>
            <Users className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          <div className="text-2xl font-extrabold text-slate-100">{employees.length}</div>
          <div className="text-[11px] text-slate-400 mt-1">100% Validated Skills</div>
        </div>
      </div>

      {/* Continuous Demand Curve vs Staffing Curve */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h2 className="text-sm font-bold text-slate-100 flex items-center space-x-2">
              <Activity className="w-4 h-4 text-blue-400" />
              <span>Continuous Business Demand vs Scheduled Staffing Headcount</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Hourly store footfall, checkout transactions, and required vs scheduled cashier & stocker headcount (06:00 - 22:00)
            </p>
          </div>
          <div className="flex items-center space-x-4 text-xs font-medium">
            <span className="flex items-center text-slate-300">
              <span className="w-3 h-3 bg-blue-500 rounded-sm mr-1.5 inline-block"></span>
              Customer Traffic
            </span>
            <span className="flex items-center text-slate-300">
              <span className="w-3 h-3 bg-emerald-500 rounded-sm mr-1.5 inline-block"></span>
              Scheduled Cashiers
            </span>
          </div>
        </div>

        {/* 24-Hour Bar Curve Diagram */}
        <div className="grid grid-cols-16 gap-1.5 pt-2 items-end h-40">
          {demandCurve.filter(dp => dp.hour >= 6 && dp.hour <= 21).map(dp => {
            const trafficHeightPct = Math.min(100, Math.round((dp.customerTraffic / 500) * 100));
            const cashiersReq = dp.requiredStaffHeadcount['ROLE-CASHIER'] || 0;
            const cashierHeightPct = Math.min(100, Math.round((cashiersReq / 8) * 100));

            return (
              <div key={dp.hour} className="flex flex-col items-center h-full justify-end group relative">
                {/* Hover Tooltip */}
                <div className="absolute bottom-full mb-2 hidden group-hover:block bg-slate-950 border border-slate-700 text-slate-100 text-[10px] p-2 rounded shadow-lg whitespace-nowrap z-20">
                  <div className="font-bold border-b border-slate-800 pb-1 mb-1">{String(dp.hour).padStart(2, '0')}:00</div>
                  <div>Footfall: {dp.customerTraffic} customers</div>
                  <div>Sales Forecast: ${dp.salesForecast.toLocaleString()}</div>
                  <div>Req. Cashiers: {cashiersReq}</div>
                </div>

                <div className="w-full flex space-x-0.5 items-end h-full justify-center">
                  <div
                    style={{ height: `${Math.max(8, trafficHeightPct)}%` }}
                    className="w-1/2 bg-blue-600/80 group-hover:bg-blue-500 rounded-t-sm transition-all"
                  ></div>
                  <div
                    style={{ height: `${Math.max(8, cashierHeightPct)}%` }}
                    className="w-1/2 bg-emerald-500/80 group-hover:bg-emerald-400 rounded-t-sm transition-all"
                  ></div>
                </div>

                <span className="text-[10px] text-slate-400 font-mono mt-1.5">{String(dp.hour).padStart(2, '0')}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Quick Operations Table & Department Status */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Department Coverage Matrix */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
          <h2 className="text-sm font-bold text-slate-100 flex items-center justify-between">
            <span>Department Staffing Telemetry</span>
            <span className="text-xs text-blue-400 font-mono font-normal">7 Departments</span>
          </h2>

          <div className="space-y-2">
            {[
              { name: 'Checkout & POS', staff: '8 Scheduled', coverage: 100, status: 'OPTIMAL', color: 'bg-emerald-500' },
              { name: 'Grocery Replenishment', staff: '6 Scheduled', coverage: 96, status: 'OPTIMAL', color: 'bg-emerald-500' },
              { name: 'Fresh Produce', staff: '3 Scheduled', coverage: 100, status: 'OPTIMAL', color: 'bg-emerald-500' },
              { name: 'Bakery & Deli', staff: '2 Scheduled', coverage: 100, status: 'OPTIMAL', color: 'bg-emerald-500' },
              { name: 'Warehouse & Dock', staff: '4 Scheduled', coverage: 92, status: 'ATTENTION', color: 'bg-amber-500' },
              { name: 'Customer Service', staff: '2 Scheduled', coverage: 100, status: 'OPTIMAL', color: 'bg-emerald-500' },
              { name: 'Duty Management', staff: '2 Scheduled', coverage: 100, status: 'OPTIMAL', color: 'bg-emerald-500' },
            ].map((dept, idx) => (
              <div key={idx} className="flex items-center justify-between p-2.5 bg-slate-950 border border-slate-850 rounded-lg text-xs">
                <div className="flex items-center space-x-2">
                  <span className={`w-2 h-2 rounded-full ${dept.color}`}></span>
                  <span className="font-semibold text-slate-200">{dept.name}</span>
                </div>
                <div className="flex items-center space-x-3 text-slate-400">
                  <span>{dept.staff}</span>
                  <span className="font-mono text-slate-200">{dept.coverage}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Live System Audit Feed */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-100">Live Engine Event Stream</h2>
            <button
              onClick={() => onNavigateTab('AUDIT')}
              className="text-xs text-blue-400 hover:text-blue-300 font-medium cursor-pointer"
            >
              View Full Audit Log &rarr;
            </button>
          </div>

          <div className="space-y-2.5">
            {[
              { time: '10:14 AM', actor: 'Constraint Solver', msg: 'Hard constraints validated: 0 violations found across 42 shifts.' },
              { time: '09:45 AM', actor: 'Demand Engine', msg: 'Updated Saturday footfall model +15% due to local weather forecast.' },
              { time: '08:30 AM', actor: 'Sarah Connor', msg: 'Approved shift swap request for Cashier position #SH-1008.' },
              { time: '07:00 AM', actor: 'Time Clock Terminal', msg: 'Marcus Vance clocked in on-time for Warehouse shift.' },
            ].map((evt, i) => (
              <div key={i} className="p-2.5 bg-slate-950 border border-slate-850 rounded-lg text-xs flex items-start space-x-3">
                <span className="text-[10px] font-mono text-slate-500 whitespace-nowrap pt-0.5">{evt.time}</span>
                <div>
                  <span className="font-bold text-blue-400 mr-2">{evt.actor}:</span>
                  <span className="text-slate-300">{evt.msg}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
