import React, { useState } from 'react';
import { Sparkles, Send, Bot, User, HelpCircle, Loader2 } from 'lucide-react';
import { ScheduleResult } from '../types/domain';

interface ShiftCoreAIModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeSchedule: ScheduleResult;
  onTriggerScheduleGeneration?: () => void;
}

export const ShiftCoreAIModal: React.FC<ShiftCoreAIModalProps> = ({
  isOpen,
  onClose,
  activeSchedule,
  onTriggerScheduleGeneration,
}) => {
  const [query, setQuery] = useState<string>('');
  const [messages, setMessages] = useState<{ sender: 'USER' | 'AI'; text: string }[]>([
    {
      sender: 'AI',
      text: 'Greetings. I am ShiftCore AI — your workforce optimisation assistant. Ask me questions about schedule generation, coverage gaps, overtime risk, or cost calculations.',
    },
  ]);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  if (!isOpen) return null;

  const sampleQuestions = [
    'Why are we understaffed on Saturday 17:00–18:00?',
    'Who can cover Marcus Vance if he calls in sick?',
    'How much would adding two checkout workers to Friday evening cost?',
    'Which employees are under their target contracted hours?',
  ];

  const handleSend = async (textToSend?: string) => {
    const promptText = textToSend || query;
    if (!promptText.trim() || isLoading) return;

    const userMsg = { sender: 'USER' as const, text: promptText };
    setMessages(prev => [...prev, userMsg]);
    setQuery('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/v1/ai/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: promptText,
          activeSchedule,
        }),
      });

      const data = await response.json();
      setMessages(prev => [...prev, { sender: 'AI', text: data.answer || 'No response returned.' }]);
    } catch (err) {
      setMessages(prev => [
        ...prev,
        { sender: 'AI', text: 'Error connecting to ShiftCore AI assistant backend.' },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl h-[600px] flex flex-col shadow-2xl overflow-hidden text-slate-100">
        {/* Top Bar */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 bg-gradient-to-r from-indigo-600 to-blue-600 rounded-lg text-amber-300">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-100 text-sm">ShiftCore AI — Operational Manager Assistant</h3>
              <p className="text-[11px] text-slate-400">Grounded directly in live workforce engine state & constraints</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-200 text-sm font-bold p-1 cursor-pointer">
            ✕
          </button>
        </div>

        {/* Chat History */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3 text-xs">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex items-start space-x-2.5 ${m.sender === 'USER' ? 'justify-end' : 'justify-start'}`}
            >
              {m.sender === 'AI' && (
                <div className="p-1.5 bg-blue-600/20 text-blue-400 border border-blue-500/30 rounded-lg shrink-0">
                  <Bot className="w-4 h-4" />
                </div>
              )}
              <div
                className={`p-3 rounded-xl max-w-[85%] leading-relaxed ${
                  m.sender === 'USER'
                    ? 'bg-blue-600 text-white font-medium'
                    : 'bg-slate-950 border border-slate-800 text-slate-200'
                }`}
              >
                {m.text}
              </div>
              {m.sender === 'USER' && (
                <div className="p-1.5 bg-slate-800 text-slate-300 rounded-lg shrink-0">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}

          {isLoading && (
            <div className="flex items-center space-x-2 text-slate-400 text-xs italic">
              <Loader2 className="w-4 h-4 animate-spin text-blue-400" />
              <span>Analyzing live workforce constraints & calculating metrics...</span>
            </div>
          )}
        </div>

        {/* Quick Sample Questions */}
        <div className="p-2 bg-slate-950 border-t border-slate-800 flex items-center space-x-2 overflow-x-auto text-[11px] scrollbar-none">
          <span className="text-slate-500 whitespace-nowrap pl-2 font-mono flex items-center">
            <HelpCircle className="w-3 h-3 mr-1" />
            Ask:
          </span>
          {sampleQuestions.map((q, i) => (
            <button
              key={i}
              onClick={() => handleSend(q)}
              className="bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 px-2.5 py-1 rounded-full whitespace-nowrap cursor-pointer transition-colors"
            >
              {q}
            </button>
          ))}
        </div>

        {/* Query Input */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 flex items-center space-x-2">
          <input
            type="text"
            placeholder="Ask ShiftCore AI about schedule, coverage, or cost..."
            value={query}
            onChange={e => setQuery(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSend()}
            className="flex-1 bg-slate-900 border border-slate-800 text-slate-100 text-xs px-3 py-2 rounded-lg focus:outline-none focus:border-blue-500"
          />
          <button
            onClick={() => handleSend()}
            disabled={isLoading || !query.trim()}
            className="bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 text-white p-2 rounded-lg cursor-pointer transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
