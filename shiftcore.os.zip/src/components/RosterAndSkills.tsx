import React, { useState } from 'react';
import { UserCheck, ShieldCheck, Award, Clock, Calendar, Mail, AlertTriangle, CheckCircle, Search } from 'lucide-react';
import { Employee } from '../types/domain';
import { SEED_ROLES, SEED_SKILLS, SEED_QUALIFICATIONS } from '../data/seedData';

interface RosterAndSkillsProps {
  employees: Employee[];
}

export const RosterAndSkills: React.FC<RosterAndSkillsProps> = ({ employees }) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(employees[0] || null);

  const filteredEmployees = employees.filter(e =>
    e.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    e.employeeCode.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header & Search */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
            <UserCheck className="w-5 h-5 text-blue-400" />
            <span>Enterprise Workforce Roster, Skills & Qualifications Engine</span>
          </h2>
          <p className="text-xs text-slate-400">
            {employees.length} Active Employees — Contracts, Skills, Availability Windows, and Qualification Compliance.
          </p>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search employee name or code..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="bg-slate-950 border border-slate-800 text-slate-200 text-xs pl-9 pr-4 py-2 rounded-lg w-64 focus:outline-none focus:border-blue-500"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Employee List */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-2 max-h-[600px] overflow-y-auto">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 border-b border-slate-800 pb-2">
            Employee Directory ({filteredEmployees.length})
          </div>

          <div className="space-y-1.5">
            {filteredEmployees.map(emp => {
              const isSelected = selectedEmployee?.id === emp.id;
              return (
                <div
                  key={emp.id}
                  onClick={() => setSelectedEmployee(emp)}
                  className={`p-3 rounded-xl border text-xs cursor-pointer transition-all flex items-center justify-between ${
                    isSelected
                      ? 'bg-blue-600/20 border-blue-500 text-slate-100 shadow-sm'
                      : 'bg-slate-950 border-slate-850 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    {emp.avatarUrl ? (
                      <img src={emp.avatarUrl} alt={emp.name} className="w-8 h-8 rounded-full object-cover border border-slate-700" />
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-slate-800 text-slate-300 flex items-center justify-center font-bold text-xs">
                        {emp.name.split(' ').map(n => n[0]).join('')}
                      </div>
                    )}
                    <div>
                      <div className="font-bold text-slate-100">{emp.name}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{emp.employeeCode} &bull; {emp.contract.type}</div>
                    </div>
                  </div>

                  <span className="text-[10px] bg-slate-800 px-2 py-0.5 rounded font-mono text-blue-300">
                    ${emp.contract.hourlyRate}/h
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Detailed Employee Dossier */}
        {selectedEmployee && (
          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-6">
            <div className="flex items-start justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center space-x-4">
                {selectedEmployee.avatarUrl ? (
                  <img src={selectedEmployee.avatarUrl} alt={selectedEmployee.name} className="w-14 h-14 rounded-full object-cover border-2 border-blue-500" />
                ) : (
                  <div className="w-14 h-14 rounded-full bg-slate-800 text-slate-300 flex items-center justify-center font-bold text-lg">
                    {selectedEmployee.name.split(' ').map(n => n[0]).join('')}
                  </div>
                )}
                <div>
                  <h3 className="text-lg font-bold text-slate-100">{selectedEmployee.name}</h3>
                  <div className="text-xs text-slate-400 font-mono mt-0.5">
                    {selectedEmployee.employeeCode} &bull; {selectedEmployee.email}
                  </div>
                  <div className="flex items-center space-x-2 mt-2">
                    <span className="bg-blue-500/10 text-blue-400 border border-blue-500/30 text-[10px] font-bold px-2 py-0.5 rounded">
                      Seniority Level {selectedEmployee.seniorityLevel}
                    </span>
                    <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold px-2 py-0.5 rounded">
                      {selectedEmployee.contract.type} CONTRACT
                    </span>
                  </div>
                </div>
              </div>

              <div className="text-right">
                <div className="text-xs text-slate-400 font-medium">Hourly Base Rate</div>
                <div className="text-2xl font-extrabold text-emerald-400 font-mono mt-0.5">
                  ${selectedEmployee.contract.hourlyRate.toFixed(2)}/h
                </div>
              </div>
            </div>

            {/* Contract Rules */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-850">
                <div className="text-slate-400">Target Hours / Wk</div>
                <div className="font-bold text-slate-100 text-sm mt-0.5 font-mono">
                  {selectedEmployee.contract.targetHoursPerWeek}h
                </div>
              </div>
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-850">
                <div className="text-slate-400">Max Weekly Limit</div>
                <div className="font-bold text-slate-100 text-sm mt-0.5 font-mono">
                  {selectedEmployee.contract.maxHoursPerWeek}h
                </div>
              </div>
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-850">
                <div className="text-slate-400">Min Rest Period</div>
                <div className="font-bold text-slate-100 text-sm mt-0.5 font-mono">
                  {selectedEmployee.contract.minRestHoursBetweenShifts}h Rest
                </div>
              </div>
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-850">
                <div className="text-slate-400">Max Consecutive Days</div>
                <div className="font-bold text-slate-100 text-sm mt-0.5 font-mono">
                  {selectedEmployee.contract.maxConsecutiveDays} Days
                </div>
              </div>
            </div>

            {/* Qualifications & Certifications */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center space-x-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Verified Qualifications & Certifications</span>
              </h4>

              {selectedEmployee.qualifications.length > 0 ? (
                <div className="space-y-2">
                  {selectedEmployee.qualifications.map(q => (
                    <div key={q.id} className="p-3 bg-slate-950 border border-slate-850 rounded-lg text-xs flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="w-4 h-4 text-emerald-400" />
                        <div>
                          <div className="font-bold text-slate-200">{q.name}</div>
                          <div className="text-[10px] text-slate-400 font-mono">Issued: {q.issuedDate} &bull; Expires: {q.expiryDate}</div>
                        </div>
                      </div>
                      <span className="bg-emerald-500/10 text-emerald-400 text-[10px] font-bold px-2 py-0.5 rounded border border-emerald-500/30">
                        {q.status}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-xs text-slate-500 italic p-3 bg-slate-950 rounded-lg border border-slate-850">
                  No specialized certifications required for assigned entry roles.
                </div>
              )}
            </div>

            {/* Availability Matrix */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center space-x-2">
                <Clock className="w-4 h-4 text-blue-400" />
                <span>Recurring Weekly Availability Windows</span>
              </h4>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
                {selectedEmployee.availability.map((avail, i) => (
                  <div key={i} className="p-2.5 bg-slate-950 border border-slate-850 rounded-lg">
                    <div className="font-bold text-slate-300">{avail.day}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">
                      {avail.preference === 'UNAVAILABLE' ? (
                        <span className="text-rose-400 font-semibold">UNAVAILABLE</span>
                      ) : (
                        `${avail.startTime} - ${avail.endTime}`
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
