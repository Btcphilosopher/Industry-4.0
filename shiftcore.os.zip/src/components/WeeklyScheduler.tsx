import React, { useState } from 'react';
import {
  Calendar,
  Lock,
  Unlock,
  CheckCircle,
  AlertCircle,
  Zap,
  Info,
  UserCheck,
  ChevronRight,
  Sparkles,
  Filter,
  Layers,
  ArrowRight
} from 'lucide-react';
import { ScheduleResult, Shift, Employee, DayOfWeek, ShiftExplanation } from '../types/domain';
import { SEED_DEPARTMENTS, SEED_ROLES } from '../data/seedData';

interface WeeklySchedulerProps {
  schedule: ScheduleResult;
  employees: Employee[];
  onShiftClick: (shift: Shift) => void;
  onGenerateOptimalSchedule: (strategy?: string) => void;
  onLockToggle: (shiftId: string) => void;
  selectedDepartmentFilter: string;
  onDepartmentFilterChange: (deptId: string) => void;
  isGenerating: boolean;
}

export const WeeklyScheduler: React.FC<WeeklySchedulerProps> = ({
  schedule,
  employees,
  onShiftClick,
  onGenerateOptimalSchedule,
  onLockToggle,
  selectedDepartmentFilter,
  onDepartmentFilterChange,
  isGenerating,
}) => {
  const [selectedExplanation, setSelectedExplanation] = useState<ShiftExplanation | null>(null);
  const [activeShiftForDrawer, setActiveShiftForDrawer] = useState<Shift | null>(null);

  const days: { day: DayOfWeek; label: string; dateStr: string }[] = [
    { day: DayOfWeek.MONDAY, label: 'Mon Sep 07', dateStr: '2026-09-07' },
    { day: DayOfWeek.TUESDAY, label: 'Tue Sep 08', dateStr: '2026-09-08' },
    { day: DayOfWeek.WEDNESDAY, label: 'Wed Sep 09', dateStr: '2026-09-09' },
    { day: DayOfWeek.THURSDAY, label: 'Thu Sep 10', dateStr: '2026-09-10' },
    { day: DayOfWeek.FRIDAY, label: 'Fri Sep 11', dateStr: '2026-09-11' },
    { day: DayOfWeek.SATURDAY, label: 'Sat Sep 12', dateStr: '2026-09-12' },
    { day: DayOfWeek.SUNDAY, label: 'Sun Sep 13', dateStr: '2026-09-13' },
  ];

  // Filter employees
  const filteredEmployees = employees.filter(
    e => selectedDepartmentFilter === 'ALL' || e.departmentId === selectedDepartmentFilter
  );

  const handleShiftSelect = (shift: Shift) => {
    setActiveShiftForDrawer(shift);
    if (schedule.explanations && schedule.explanations[shift.id]) {
      setSelectedExplanation(schedule.explanations[shift.id]);
    } else {
      setSelectedExplanation(null);
    }
  };

  return (
    <div className="space-y-4">
      {/* Scheduler Header & Controls */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-blue-600/20 text-blue-400 rounded-lg">
            <Calendar className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
              <span>Weekly Shift Rota & Matrix</span>
              <span className="text-xs font-normal text-slate-400 bg-slate-800 px-2 py-0.5 rounded font-mono">
                Week 37 — Version {schedule.version}
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              Interactive constraint-evaluated shift schedule. Click any shift card to view exact computational explanation.
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          {/* Department Filter */}
          <div className="flex items-center space-x-2 bg-slate-800 border border-slate-700 px-2.5 py-1.5 rounded-lg text-xs">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={selectedDepartmentFilter}
              onChange={e => onDepartmentFilterChange(e.target.value)}
              className="bg-transparent border-none text-slate-200 font-medium focus:outline-none cursor-pointer pr-1"
            >
              <option value="ALL" className="bg-slate-900">All Departments</option>
              {SEED_DEPARTMENTS.map(d => (
                <option key={d.id} value={d.id} className="bg-slate-900">
                  {d.name}
                </option>
              ))}
            </select>
          </div>

          {/* Primary Auto-Generate Button */}
          <button
            onClick={() => onGenerateOptimalSchedule('BALANCED')}
            disabled={isGenerating}
            className="flex items-center space-x-2 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-700 text-white font-semibold px-4 py-2 rounded-lg text-xs shadow transition-all cursor-pointer"
          >
            <Zap className={`w-4 h-4 text-emerald-200 fill-current ${isGenerating ? 'animate-spin' : ''}`} />
            <span>{isGenerating ? 'Solving Engine...' : 'GENERATE OPTIMAL SCHEDULE'}</span>
          </button>
        </div>
      </div>

      {/* Schedule Score Summary Strip */}
      <div className="bg-slate-950 border border-slate-800 rounded-lg p-3 grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
        <div className="flex items-center space-x-2 border-r border-slate-800 pr-3">
          <div className="font-bold text-slate-200">Overall Score:</div>
          <div className="font-mono text-sm font-extrabold text-blue-400">{schedule.score.totalScore}/100</div>
        </div>
        <div className="flex items-center space-x-2 border-r border-slate-800 pr-3">
          <div className="text-slate-400">Demand Coverage:</div>
          <div className="font-mono font-bold text-emerald-400">{schedule.score.demandCoveragePct}%</div>
        </div>
        <div className="flex items-center space-x-2 border-r border-slate-800 pr-3">
          <div className="text-slate-400">Total Labour Cost:</div>
          <div className="font-mono font-bold text-slate-200">${schedule.score.totalLabourCost.toLocaleString()}</div>
        </div>
        <div className="flex items-center space-x-2 border-r border-slate-800 pr-3">
          <div className="text-slate-400">Overtime Hours:</div>
          <div className="font-mono font-bold text-rose-400">{schedule.score.overtimeHoursTotal}h</div>
        </div>
        <div className="flex items-center space-x-2">
          <div className="text-slate-400">Preferences:</div>
          <div className="font-mono font-bold text-indigo-400">{schedule.score.employeePreferencePct}%</div>
        </div>
      </div>

      {/* Rota Matrix Grid */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-x-auto shadow-sm">
        <table className="w-full text-left text-xs border-collapse min-w-[900px]">
          <thead>
            <tr className="bg-slate-950 border-b border-slate-800 text-slate-400 font-semibold uppercase tracking-wider">
              <th className="p-3 w-48 sticky left-0 bg-slate-950 z-10 border-r border-slate-800">Employee & Role</th>
              {days.map(d => (
                <th key={d.dateStr} className="p-3 text-center border-r border-slate-800/60 font-mono">
                  <div>{d.label.split(' ')[0]}</div>
                  <div className="text-[10px] text-slate-500 font-normal">{d.label.slice(4)}</div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {filteredEmployees.map(emp => {
              const empRoleNames = emp.roles
                .map(rid => SEED_ROLES.find(r => r.id === rid)?.name)
                .filter(Boolean)
                .join(', ');

              return (
                <tr key={emp.id} className="hover:bg-slate-850/50 transition-colors">
                  {/* Employee Sticky Column */}
                  <td className="p-3 sticky left-0 bg-slate-900 z-10 border-r border-slate-800 font-medium">
                    <div className="flex items-center space-x-2.5">
                      {emp.avatarUrl ? (
                        <img src={emp.avatarUrl} alt={emp.name} className="w-7 h-7 rounded-full object-cover border border-slate-700" />
                      ) : (
                        <div className="w-7 h-7 rounded-full bg-slate-800 text-slate-300 flex items-center justify-center font-bold text-[10px]">
                          {emp.name.split(' ').map(n => n[0]).join('')}
                        </div>
                      )}
                      <div>
                        <div className="font-bold text-slate-100 leading-snug">{emp.name}</div>
                        <div className="text-[10px] text-slate-400 truncate max-w-[130px]">{empRoleNames}</div>
                      </div>
                    </div>
                  </td>

                  {/* 7 Days Shift Cells */}
                  {days.map(d => {
                    const shiftOnDay = schedule.shifts.find(
                      s => s.assignedEmployeeId === emp.id && s.date === d.dateStr
                    );

                    return (
                      <td key={d.dateStr} className="p-2 border-r border-slate-800/60 align-top h-20 w-32">
                        {shiftOnDay ? (
                          <div
                            onClick={() => handleShiftSelect(shiftOnDay)}
                            className={`p-2 rounded-lg border text-[11px] cursor-pointer transition-all hover:scale-[1.02] shadow-sm relative group ${
                              shiftOnDay.isLocked
                                ? 'bg-amber-950/30 border-amber-500/40 text-amber-200'
                                : 'bg-slate-800/90 border-slate-700 text-slate-200 hover:border-blue-500/60'
                            }`}
                          >
                            <div className="flex items-center justify-between font-mono font-bold text-blue-300 text-[10px]">
                              <span>{shiftOnDay.startTime} - {shiftOnDay.endTime}</span>
                              <button
                                onClick={e => {
                                  e.stopPropagation();
                                  onLockToggle(shiftOnDay.id);
                                }}
                                className="text-slate-400 hover:text-amber-400 p-0.5 cursor-pointer"
                                title={shiftOnDay.isLocked ? 'Unlock Shift' : 'Lock Shift'}
                              >
                                {shiftOnDay.isLocked ? <Lock className="w-3 h-3 text-amber-400" /> : <Unlock className="w-3 h-3 text-slate-500 opacity-0 group-hover:opacity-100" />}
                              </button>
                            </div>
                            <div className="text-[10px] font-medium text-slate-300 mt-1 truncate">
                              {SEED_ROLES.find(r => r.id === shiftOnDay.roleId)?.name || 'Role'}
                            </div>
                            <div className="flex items-center space-x-1 text-[9px] text-slate-400 mt-1">
                              <span className="bg-slate-900 px-1 py-0.2 rounded font-mono">
                                {shiftOnDay.breakMinutes}m break
                              </span>
                            </div>
                          </div>
                        ) : (
                          <div className="h-full flex items-center justify-center text-[10px] text-slate-600 font-mono">
                            OFF
                          </div>
                        )}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Shift Explanation Drawer Modal */}
      {activeShiftForDrawer && selectedExplanation && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs z-50 flex justify-end">
          <div className="w-full max-w-md bg-slate-900 border-l border-slate-800 h-full p-6 overflow-y-auto space-y-5 text-slate-100 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div>
                <span className="text-[10px] uppercase font-mono font-bold tracking-wider text-blue-400">
                  Shift Assignment Explanation
                </span>
                <h3 className="text-lg font-bold text-slate-100 mt-0.5">
                  Why was {selectedExplanation.employeeName} assigned?
                </h3>
              </div>
              <button
                onClick={() => {
                  setActiveShiftForDrawer(null);
                  setSelectedExplanation(null);
                }}
                className="text-slate-400 hover:text-slate-200 text-sm font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400 font-medium">Assignment Fit Score</span>
                <span className="text-lg font-extrabold text-emerald-400 font-mono">
                  {selectedExplanation.overallMatchScore}% Match
                </span>
              </div>
              <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                <div
                  style={{ width: `${selectedExplanation.overallMatchScore}%` }}
                  className="bg-emerald-500 h-full"
                ></div>
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Constraint & Preference Factor Evaluation
              </h4>

              <div className="space-y-2">
                {selectedExplanation.factors.map((f, i) => (
                  <div
                    key={i}
                    className={`p-3 rounded-lg border text-xs flex items-start space-x-3 ${
                      f.passed
                        ? 'bg-slate-950/80 border-slate-800 text-slate-200'
                        : 'bg-rose-950/20 border-rose-500/30 text-rose-200'
                    }`}
                  >
                    {f.passed ? (
                      <CheckCircle className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-rose-400 mt-0.5 shrink-0" />
                    )}
                    <div>
                      <div className="font-bold">{f.factor}</div>
                      <div className="text-[11px] text-slate-400 mt-0.5">{f.detail}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => {
                  setActiveShiftForDrawer(null);
                  setSelectedExplanation(null);
                }}
                className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-4 py-2 rounded-lg text-xs font-medium cursor-pointer"
              >
                Close Explanation
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
