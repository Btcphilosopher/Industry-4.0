import React, { useState } from 'react';
import { Clock, CheckCircle, AlertCircle, Play, Square, Activity, UserCheck } from 'lucide-react';
import { Shift, Employee, TimeClockRecord, VarianceAnalysis } from '../types/domain';
import { calculateShiftVariance } from '../engine/attendance';
import { SEED_ROLES } from '../data/seedData';

interface TimeClockAndVarianceProps {
  shifts: Shift[];
  employees: Employee[];
}

export const TimeClockAndVariance: React.FC<TimeClockAndVarianceProps> = ({ shifts, employees }) => {
  const [selectedEmpId, setSelectedEmpId] = useState<string>(employees[0]?.id || '');
  const [clockInTime, setClockInTime] = useState<string>('08:07');
  const [clockOutTime, setClockOutTime] = useState<string>('16:14');
  const [activeRecords, setActiveRecords] = useState<Record<string, TimeClockRecord>>({});

  const selectedEmp = employees.find(e => e.id === selectedEmpId) || employees[0];
  const empShifts = shifts.filter(s => s.assignedEmployeeId === selectedEmp?.id);

  const handleSimulateClockIn = (shift: Shift) => {
    const record: TimeClockRecord = {
      id: `TC-${Math.floor(100 + Math.random() * 900)}`,
      employeeId: selectedEmp.id,
      shiftId: shift.id,
      clockInTime,
      clockOutTime,
      status: 'COMPLETED',
    };

    setActiveRecords(prev => ({ ...prev, [shift.id]: record }));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
            <Clock className="w-5 h-5 text-blue-400" />
            <span>Time Clock Terminal & Scheduled-vs-Actual Variance Analytics</span>
          </h2>
          <p className="text-xs text-slate-400">
            Real-time clock punches, break tracking, late arrivals, and attendance feedback loop into demand forecasting.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Time Clock Terminal Simulation */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-100 flex items-center space-x-2">
              <Activity className="w-4 h-4 text-emerald-400" />
              <span>Time Clock Terminal</span>
            </h3>
            <span className="text-xs font-mono text-emerald-400 font-bold">ONLINE</span>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block text-slate-400 font-medium mb-1">Select Employee Punching Clock:</label>
              <select
                value={selectedEmpId}
                onChange={e => setSelectedEmpId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg p-2.5 cursor-pointer"
              >
                {employees.map(e => (
                  <option key={e.id} value={e.id} className="bg-slate-900">
                    {e.name} ({e.employeeCode})
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-400 font-medium mb-1">Clock-In Punch Time:</label>
                <input
                  type="text"
                  value={clockInTime}
                  onChange={e => setClockInTime(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg p-2 font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Clock-Out Punch Time:</label>
                <input
                  type="text"
                  value={clockOutTime}
                  onChange={e => setClockOutTime(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg p-2 font-mono"
                />
              </div>
            </div>

            <div className="pt-2">
              <label className="block text-slate-400 font-medium mb-2">Assigned Shifts for {selectedEmp?.name}:</label>
              {empShifts.length > 0 ? (
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {empShifts.map(s => (
                    <div key={s.id} className="p-3 bg-slate-950 border border-slate-850 rounded-lg flex items-center justify-between">
                      <div>
                        <div className="font-bold text-slate-200">{s.date} ({s.startTime}-{s.endTime})</div>
                        <div className="text-[10px] text-slate-400">{SEED_ROLES.find(r => r.id === s.roleId)?.name}</div>
                      </div>
                      <button
                        onClick={() => handleSimulateClockIn(s)}
                        className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3 py-1.5 rounded text-[10px] cursor-pointer"
                      >
                        Simulate Clock
                      </button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-3 bg-slate-950 rounded text-slate-500 italic text-[11px]">
                  No assigned shifts found for this employee this week.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Scheduled vs Actual Variance Analytics Table */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-100 flex items-center space-x-2">
              <UserCheck className="w-4 h-4 text-blue-400" />
              <span>Scheduled vs Actual Attendance Variance Report</span>
            </h3>
            <span className="text-xs text-slate-400 font-mono">Live Time Cards</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-950 text-slate-400 border-b border-slate-800 font-mono">
                  <th className="p-3">Employee</th>
                  <th className="p-3">Scheduled Shift</th>
                  <th className="p-3">Actual Clocked</th>
                  <th className="p-3">Start Variance</th>
                  <th className="p-3">Worked / Sched Hours</th>
                  <th className="p-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {empShifts.map(s => {
                  const rec = activeRecords[s.id] || {
                    id: 'REC-0',
                    employeeId: selectedEmp.id,
                    shiftId: s.id,
                    clockInTime: '08:07',
                    clockOutTime: '16:14',
                    status: 'COMPLETED',
                  };

                  const variance = calculateShiftVariance(s, rec, selectedEmp);

                  return (
                    <tr key={s.id} className="hover:bg-slate-850/50">
                      <td className="p-3 font-bold text-slate-200">{selectedEmp.name}</td>
                      <td className="p-3 text-slate-300">{s.startTime} - {s.endTime}</td>
                      <td className="p-3 text-emerald-400">{variance.actualStart} - {variance.actualEnd}</td>
                      <td className={`p-3 font-bold ${variance.startOffsetMinutes > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                        {variance.startOffsetMinutes > 0 ? `+${variance.startOffsetMinutes}m Late` : 'On Time'}
                      </td>
                      <td className="p-3 text-slate-200">
                        {variance.actualHoursWorked}h / {variance.scheduledHoursWorked}h
                      </td>
                      <td className="p-3">
                        <span className="bg-amber-500/10 text-amber-400 px-2 py-0.5 rounded text-[10px] font-bold border border-amber-500/30">
                          {variance.status}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
