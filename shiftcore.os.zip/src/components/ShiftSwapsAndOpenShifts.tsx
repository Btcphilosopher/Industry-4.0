import React, { useState } from 'react';
import { Layers, ArrowRightLeft, UserCheck, AlertTriangle, CheckCircle, Search, ShieldCheck } from 'lucide-react';
import { Shift, Employee } from '../types/domain';
import { rankEligibleEmployeesForOpenShift, validateShiftSwap } from '../engine/scheduler';
import { SEED_ROLES } from '../data/seedData';

interface ShiftSwapsAndOpenShiftsProps {
  shifts: Shift[];
  employees: Employee[];
  onAssignOpenShift: (shiftId: string, employeeId: string) => void;
}

export const ShiftSwapsAndOpenShifts: React.FC<ShiftSwapsAndOpenShiftsProps> = ({
  shifts,
  employees,
  onAssignOpenShift,
}) => {
  const openShifts = shifts.filter(s => s.status === 'OPEN' || !s.assignedEmployeeId);
  const [selectedOpenShift, setSelectedOpenShift] = useState<Shift | null>(openShifts[0] || null);

  // Shift swap simulator state
  const [swapEmpA, setSwapEmpA] = useState<string>(employees[0]?.id || '');
  const [swapEmpB, setSwapEmpB] = useState<string>(employees[1]?.id || '');
  const [swapValidationResult, setSwapValidationResult] = useState<{ valid: boolean; reasons: string[] } | null>(null);

  const rankedCandidates = selectedOpenShift
    ? rankEligibleEmployeesForOpenShift(selectedOpenShift, employees, shifts)
    : [];

  const handleValidateSwap = () => {
    const empA = employees.find(e => e.id === swapEmpA);
    const empB = employees.find(e => e.id === swapEmpB);

    if (!empA || !empB) return;

    const shiftA = shifts.find(s => s.assignedEmployeeId === empA.id);
    const shiftB = shifts.find(s => s.assignedEmployeeId === empB.id);

    if (!shiftA || !shiftB) {
      setSwapValidationResult({
        valid: false,
        reasons: ['Both employees must have at least one assigned shift to simulate a swap.'],
      });
      return;
    }

    const res = validateShiftSwap(shiftA, empA, shiftB, empB, shifts);
    setSwapValidationResult(res);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
            <Layers className="w-5 h-5 text-blue-400" />
            <span>Open Shift Auto-Fill & Controlled Shift Swap Engine</span>
          </h2>
          <p className="text-xs text-slate-400">
            Ranked candidate recommendations for open shifts and hard-constraint validated peer shift swaps.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Open Shifts Auto-Fill Panel */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-slate-100 flex items-center space-x-2">
              <UserCheck className="w-4 h-4 text-emerald-400" />
              <span>Open Coverage Gaps ({openShifts.length})</span>
            </h3>
            <span className="text-xs text-slate-400 font-mono">Ranked Candidate Search</span>
          </div>

          {openShifts.length > 0 ? (
            <div className="space-y-3">
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {openShifts.map(s => (
                  <div
                    key={s.id}
                    onClick={() => setSelectedOpenShift(s)}
                    className={`p-3 rounded-xl border text-xs cursor-pointer transition-all flex items-center justify-between ${
                      selectedOpenShift?.id === s.id
                        ? 'bg-blue-600/20 border-blue-500 text-slate-100'
                        : 'bg-slate-950 border-slate-850 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div>
                      <div className="font-bold text-slate-100">{s.date} ({s.startTime} - {s.endTime})</div>
                      <div className="text-[10px] text-slate-400">{SEED_ROLES.find(r => r.id === s.roleId)?.name}</div>
                    </div>
                    <span className="bg-amber-500/10 text-amber-400 font-bold px-2 py-0.5 rounded text-[10px] border border-amber-500/30">
                      OPEN GAP
                    </span>
                  </div>
                ))}
              </div>

              {selectedOpenShift && (
                <div className="pt-3 border-t border-slate-800 space-y-3">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    Ranked Eligible Candidates
                  </h4>

                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {rankedCandidates.map((cand, idx) => (
                      <div
                        key={cand.employee.id}
                        className="p-3 bg-slate-950 border border-slate-850 rounded-lg text-xs space-y-1.5"
                      >
                        <div className="flex items-center justify-between">
                          <div className="font-bold text-slate-100">
                            #{idx + 1} {cand.employee.name}
                          </div>
                          <span className={`font-mono font-bold text-xs ${cand.fitScore > 70 ? 'text-emerald-400' : 'text-rose-400'}`}>
                            {cand.fitScore}% Fit
                          </span>
                        </div>

                        {cand.fitScore > 0 ? (
                          <div className="space-y-1">
                            {cand.matchReasons.map((r, i) => (
                              <div key={i} className="text-[10px] text-slate-400 flex items-center space-x-1">
                                <CheckCircle className="w-3 h-3 text-emerald-400 shrink-0" />
                                <span>{r}</span>
                              </div>
                            ))}
                            <button
                              onClick={() => onAssignOpenShift(selectedOpenShift.id, cand.employee.id)}
                              className="mt-2 w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-1.5 rounded text-[11px] cursor-pointer shadow"
                            >
                              Assign {cand.employee.name} to Shift
                            </button>
                          </div>
                        ) : (
                          <div className="text-[10px] text-rose-400 flex items-start space-x-1">
                            <AlertTriangle className="w-3 h-3 text-rose-400 shrink-0 mt-0.5" />
                            <span>Ineligible: {cand.violations[0]}</span>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="p-6 bg-slate-950 rounded-xl text-center text-xs text-slate-400 border border-slate-850">
              <CheckCircle className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
              <span>All shift slots are fully assigned. No open coverage gaps exist!</span>
            </div>
          )}
        </div>

        {/* Shift Swap Validator Panel */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-slate-100 flex items-center space-x-2">
              <ArrowRightLeft className="w-4 h-4 text-blue-400" />
              <span>Controlled Shift Swap Validator</span>
            </h3>
            <span className="text-xs text-slate-400">Hard Constraint & Rest Verification</span>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block text-slate-400 font-medium mb-1">Employee A (Requester):</label>
              <select
                value={swapEmpA}
                onChange={e => setSwapEmpA(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg p-2.5 cursor-pointer"
              >
                {employees.map(e => (
                  <option key={e.id} value={e.id} className="bg-slate-900">
                    {e.name} ({e.contract.type})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1">Employee B (Peer Target):</label>
              <select
                value={swapEmpB}
                onChange={e => setSwapEmpB(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 text-slate-200 rounded-lg p-2.5 cursor-pointer"
              >
                {employees.map(e => (
                  <option key={e.id} value={e.id} className="bg-slate-900">
                    {e.name} ({e.contract.type})
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={handleValidateSwap}
              className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-2 rounded-lg cursor-pointer transition-colors"
            >
              VALIDATE SHIFT SWAP RULES
            </button>

            {swapValidationResult && (
              <div
                className={`p-4 rounded-xl border text-xs space-y-2 ${
                  swapValidationResult.valid
                    ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-200'
                    : 'bg-rose-950/30 border-rose-500/40 text-rose-200'
                }`}
              >
                <div className="font-bold flex items-center space-x-2">
                  {swapValidationResult.valid ? (
                    <ShieldCheck className="w-5 h-5 text-emerald-400" />
                  ) : (
                    <AlertTriangle className="w-5 h-5 text-rose-400" />
                  )}
                  <span>
                    {swapValidationResult.valid ? 'SWAP APPROVED BY ENGINE' : 'SWAP BLOCKED BY CONSTRAINTS'}
                  </span>
                </div>

                <div className="space-y-1 pt-1">
                  {swapValidationResult.reasons.map((r, i) => (
                    <div key={i} className="text-[11px] opacity-90">{r}</div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
