import React from 'react';
import { ShieldCheck, History, ArrowRight, Layers, FileSpreadsheet } from 'lucide-react';
import { auditBus } from '../engine/audit';
import { ScheduleResult } from '../types/domain';

interface AuditLogAndVersionsProps {
  currentSchedule: ScheduleResult;
}

export const AuditLogAndVersions: React.FC<AuditLogAndVersionsProps> = ({ currentSchedule }) => {
  const events = auditBus.getEvents();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
            <ShieldCheck className="w-5 h-5 text-blue-400" />
            <span>Schedule Version History & Immutable Audit Log</span>
          </h2>
          <p className="text-xs text-slate-400">
            Immutable system events, schedule version tracking, and complete managerial change accountability.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Schedule Version History Comparison */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-100 flex items-center space-x-2">
              <History className="w-4 h-4 text-emerald-400" />
              <span>Schedule Versions</span>
            </h3>
            <span className="text-xs text-slate-400 font-mono">Week 37</span>
          </div>

          <div className="space-y-3">
            {[
              { ver: 3, label: 'Version 3 (Active)', coverage: '97.8%', cost: '$18,420.50', status: 'ACTIVE', desc: 'Current optimised schedule with Saturday demand uplift.' },
              { ver: 2, label: 'Version 2 (Draft)', coverage: '94.2%', cost: '$17,910.00', status: 'ARCHIVED', desc: 'Pre-re-optimisation draft before supervisor swap.' },
              { ver: 1, label: 'Version 1 (Initial)', coverage: '89.5%', cost: '$17,200.00', status: 'ARCHIVED', desc: 'Baseline draft generated from demand curve.' },
            ].map(v => (
              <div
                key={v.ver}
                className={`p-3.5 rounded-xl border text-xs space-y-2 ${
                  v.status === 'ACTIVE'
                    ? 'bg-blue-600/15 border-blue-500/40 text-slate-100'
                    : 'bg-slate-950 border-slate-850 text-slate-400'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-100">{v.label}</span>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                      v.status === 'ACTIVE' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {v.status}
                  </span>
                </div>

                <div className="flex items-center justify-between text-[11px] font-mono pt-1 border-t border-slate-800/60">
                  <span>Coverage: {v.coverage}</span>
                  <span>Cost: {v.cost}</span>
                </div>

                <p className="text-[10px] text-slate-400 italic">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Immutable Audit Log Table */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-100 flex items-center space-x-2">
              <ShieldCheck className="w-4 h-4 text-blue-400" />
              <span>Immutable System Audit Event Stream</span>
            </h3>
            <span className="text-xs text-slate-400 font-mono">{events.length} Recorded Events</span>
          </div>

          <div className="space-y-2.5 max-h-[500px] overflow-y-auto pr-1">
            {events.map(evt => (
              <div key={evt.id} className="p-3 bg-slate-950 border border-slate-850 rounded-lg text-xs space-y-1">
                <div className="flex items-center justify-between font-mono text-[10px]">
                  <span className="text-blue-400 font-bold">{evt.id} &bull; {evt.event}</span>
                  <span className="text-slate-500">{new Date(evt.timestamp).toLocaleString()}</span>
                </div>

                <div className="text-slate-200">
                  <span className="font-bold text-slate-300">{evt.actor}</span> executed action on{' '}
                  <span className="font-mono text-emerald-400">{evt.entityType} ({evt.entityId})</span>
                </div>

                {evt.reason && (
                  <div className="text-[11px] text-slate-400 italic mt-0.5">
                    Reason: "{evt.reason}"
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
