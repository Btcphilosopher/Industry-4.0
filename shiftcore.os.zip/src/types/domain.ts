export type EmployeeId = string;
export type LocationId = string;
export type DepartmentId = string;
export type RoleId = string;
export type SkillId = string;
export type QualificationId = string;
export type ShiftId = string;
export type ScheduleId = string;
export type LeaveRequestId = string;

export enum EmploymentType {
  FULL_TIME = 'FULL_TIME',
  PART_TIME = 'PART_TIME',
  TEMPORARY = 'TEMPORARY',
  CASUAL = 'CASUAL',
  CONTRACTOR = 'CONTRACTOR',
  MANAGER = 'MANAGER',
  SUPERVISOR = 'SUPERVISOR',
}

export enum DayOfWeek {
  MONDAY = 'MONDAY',
  TUESDAY = 'TUESDAY',
  WEDNESDAY = 'WEDNESDAY',
  THURSDAY = 'THURSDAY',
  FRIDAY = 'FRIDAY',
  SATURDAY = 'SATURDAY',
  SUNDAY = 'SUNDAY',
}

export interface AvailabilityWindow {
  day: DayOfWeek;
  startTime: string; // e.g. "08:00"
  endTime: string;   // e.g. "17:00"
  preference: 'AVAILABLE' | 'UNAVAILABLE' | 'PREFERRED' | 'PREFERRED_NOT';
}

export interface Contract {
  type: EmploymentType;
  minHoursPerWeek: number;
  maxHoursPerWeek: number;
  targetHoursPerWeek: number;
  hourlyRate: number;
  overtimeRateMultiplier: number; // e.g. 1.5
  maxConsecutiveDays: number;
  minRestHoursBetweenShifts: number;
}

export interface ShiftPreferences {
  preferredShifts?: ('MORNING' | 'AFTERNOON' | 'EVENING' | 'NIGHT')[];
  preferredDays?: DayOfWeek[];
  maxWeekendsPerMonth?: number;
  avoidSplitShifts?: boolean;
}

export interface Qualification {
  id: QualificationId;
  code: string;
  name: string;
  issuedDate: string;
  expiryDate: string;
  status: 'ACTIVE' | 'EXPIRING_SOON' | 'EXPIRED';
}

export interface Skill {
  id: SkillId;
  code: string;
  name: string;
  category: string;
}

export interface LeaveRequest {
  id: LeaveRequestId;
  employeeId: EmployeeId;
  startDate: string; // YYYY-MM-DD
  endDate: string;
  type: 'HOLIDAY' | 'SICK' | 'PERSONAL' | 'TRAINING' | 'UNAVAILABILITY';
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  reason?: string;
}

export interface Employee {
  id: EmployeeId;
  employeeCode: string;
  name: string;
  email: string;
  avatarUrl?: string;
  locationId: LocationId;
  departmentId: DepartmentId;
  roles: RoleId[];
  skills: SkillId[];
  qualifications: Qualification[];
  contract: Contract;
  availability: AvailabilityWindow[];
  preferences: ShiftPreferences;
  leave: LeaveRequest[];
  status: 'ACTIVE' | 'ON_LEAVE' | 'INACTIVE';
  seniorityLevel: number; // 1 (junior) to 5 (senior)
}

export interface Role {
  id: RoleId;
  code: string;
  name: string;
  departmentId: DepartmentId;
  requiredSkills: SkillId[];
  requiredQualifications: QualificationId[];
  baseHourlyRate: number;
}

export interface Department {
  id: DepartmentId;
  locationId: LocationId;
  name: string;
  code: string;
  colorHex: string;
}

export interface Location {
  id: LocationId;
  name: string;
  code: string;
  timezone: string;
  address: string;
  openingTime: string; // e.g. "06:00"
  closingTime: string; // e.g. "22:00"
}

export enum ShiftStatus {
  OPEN = 'OPEN',
  ASSIGNED = 'ASSIGNED',
  CONFIRMED = 'CONFIRMED',
  PUBLISHED = 'PUBLISHED',
  IN_PROGRESS = 'IN_PROGRESS',
  COMPLETED = 'COMPLETED',
  CANCELLED = 'CANCELLED',
}

export interface Shift {
  id: ShiftId;
  locationId: LocationId;
  departmentId: DepartmentId;
  roleId: RoleId;
  date: string; // YYYY-MM-DD
  startTime: string; // "08:00"
  endTime: string;   // "16:00"
  breakMinutes: number;
  requiredSkills: SkillId[];
  assignedEmployeeId: EmployeeId | null;
  status: ShiftStatus;
  isLocked?: boolean;
  notes?: string;
  requiredHeadcount?: number;
}

export interface ShiftTemplate {
  id: string;
  name: string; // e.g., "OPENING_SHIFT", "MORNING_GROCERY"
  startTime: string;
  endTime: string;
  breakMinutes: number;
  departmentId: DepartmentId;
  roleId: RoleId;
  requiredHeadcount: number;
}

export interface HourlyDemandPoint {
  hour: number; // 0 to 23
  salesForecast: number;
  customerTraffic: number;
  transactions: number;
  deliveries: number;
  onlineOrders: number;
  requiredStaffHeadcount: Record<RoleId, number>;
}

export interface DemandForecast {
  locationId: LocationId;
  date: string; // YYYY-MM-DD
  hourlyData: HourlyDemandPoint[];
  forecastModelUsed: 'MOVING_AVERAGE' | 'EXPONENTIAL_SMOOTHING' | 'SEASONAL_REGRESSION' | 'ML_ENSEMBLE';
  confidenceInterval: number; // e.g. 0.95
}

export interface HardConstraintViolation {
  code: string;
  description: string;
  severity: 'CRITICAL' | 'BLOCKING';
  employeeId?: EmployeeId;
  shiftId?: ShiftId;
}

export interface SoftConstraintPenalty {
  code: string;
  description: string;
  penaltyPoints: number;
  employeeId?: EmployeeId;
  shiftId?: ShiftId;
}

export interface ScheduleScore {
  totalScore: number; // 0 - 100
  demandCoveragePct: number;
  employeePreferencePct: number;
  fairnessPct: number;
  skillCoveragePct: number;
  labourEfficiencyPct: number;
  overtimeCompliancePct: number;
  totalLabourCost: number;
  overtimeHoursTotal: number;
  unassignedShiftsCount: number;
  hardViolationsCount: number;
}

export interface ExplanationFactor {
  factor: string;
  passed: boolean;
  weight: number;
  detail: string;
}

export interface ShiftExplanation {
  shiftId: ShiftId;
  employeeId: EmployeeId;
  employeeName: string;
  roleName: string;
  factors: ExplanationFactor[];
  overallMatchScore: number;
}

export interface ScheduleResult {
  scheduleId: ScheduleId;
  version: number;
  locationId: LocationId;
  startDate: string;
  endDate: string;
  status: 'DRAFT' | 'OPTIMISING' | 'PUBLISHED' | 'ARCHIVED';
  shifts: Shift[];
  score: ScheduleScore;
  hardViolations: HardConstraintViolation[];
  softPenalties: SoftConstraintPenalty[];
  explanations: Record<ShiftId, ShiftExplanation>;
  generatedAt: string;
  seedUsed?: number;
  algorithmVersion: string;
}

export interface RankedScheduleOption {
  id: string;
  name: string; // e.g., "Option A: Lowest Cost", "Option B: Max Employee Satisfaction"
  description: string;
  schedule: ScheduleResult;
  isRecommended?: boolean;
}

export interface ShiftSwapRequest {
  id: string;
  requesterShiftId: ShiftId;
  requesterEmployeeId: EmployeeId;
  targetShiftId?: ShiftId;
  targetEmployeeId?: EmployeeId;
  status: 'PENDING_OFFER' | 'ACCEPTED_BY_PEER' | 'APPROVED_BY_MANAGER' | 'REJECTED';
  validations: ExplanationFactor[];
}

export interface TimeClockRecord {
  id: string;
  employeeId: EmployeeId;
  shiftId?: ShiftId;
  clockInTime: string;
  clockOutTime?: string;
  breakStart?: string;
  breakEnd?: string;
  status: 'ACTIVE' | 'COMPLETED' | 'MISSED_CLOCK_OUT' | 'MANAGER_CORRECTED';
  notes?: string;
}

export interface VarianceAnalysis {
  shiftId: ShiftId;
  employeeId: EmployeeId;
  scheduledStart: string;
  scheduledEnd: string;
  actualStart?: string;
  actualEnd?: string;
  startOffsetMinutes: number; // + is late, - is early
  endOffsetMinutes: number;
  actualHoursWorked: number;
  scheduledHoursWorked: number;
  varianceHours: number;
  status: 'ON_TIME' | 'LATE_ARRIVING' | 'EARLY_DEPARTURE' | 'ABSENT' | 'OVERTIME_UNSCHEDULED';
}

export interface AuditEvent {
  id: string;
  timestamp: string;
  actor: string;
  event: string;
  entityType: string;
  entityId: string;
  beforeState?: any;
  afterState?: any;
  reason?: string;
}

export interface WhatIfScenario {
  type: 'ABSENCE_CALLIN' | 'DEMAND_SPIKE' | 'STORE_EARLY_CLOSE' | 'BUDGET_CUT' | 'EQUIPMENT_FAILURE';
  params: Record<string, any>;
}

export interface MonteCarloResult {
  iterationsRun: number;
  coverageProbability: number;
  understaffingProbability: number;
  overtimeProbability: number;
  averageLabourCost: number;
  minLabourCost: number;
  maxLabourCost: number;
  riskCategory: 'LOW' | 'MODERATE' | 'HIGH';
}
