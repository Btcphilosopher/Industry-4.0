import { AuditEvent } from '../types/domain';

class AuditLogBus {
  private events: AuditEvent[] = [];

  constructor() {
    // Initial sample seed events
    this.events = [
      {
        id: 'EV-101',
        timestamp: new Date(Date.now() - 3600000 * 24).toISOString(),
        actor: 'Sarah Connor (Store Manager)',
        event: 'SCHEDULE_GENERATED',
        entityType: 'Schedule',
        entityId: 'SCH-20260907',
        afterState: { coverage: '97.8%', status: 'DRAFT' },
        reason: 'Weekly automated schedule optimization trigger',
      },
      {
        id: 'EV-102',
        timestamp: new Date(Date.now() - 3600000 * 12).toISOString(),
        actor: 'Elena Rostova (Supervisor)',
        event: 'SHIFT_SWAPPED',
        entityType: 'Shift',
        entityId: 'SH-1004',
        beforeState: { assignedEmployeeId: 'EMP-005' },
        afterState: { assignedEmployeeId: 'EMP-008' },
        reason: 'Approved peer shift swap request #SWAP-42',
      },
      {
        id: 'EV-103',
        timestamp: new Date(Date.now() - 3600000 * 2).toISOString(),
        actor: 'System Auto-Engine',
        event: 'DEMAND_FORECAST_UPDATED',
        entityType: 'DemandForecast',
        entityId: 'FCST-LOC-104',
        reason: 'Recalculated demand curve following weekend promotion announcement',
      },
    ];
  }

  public logEvent(
    actor: string,
    event: string,
    entityType: string,
    entityId: string,
    beforeState?: any,
    afterState?: any,
    reason?: string
  ): AuditEvent {
    const newEvent: AuditEvent = {
      id: `EV-${Math.floor(100 + Math.random() * 900)}`,
      timestamp: new Date().toISOString(),
      actor,
      event,
      entityType,
      entityId,
      beforeState,
      afterState,
      reason,
    };
    this.events.unshift(newEvent);
    return newEvent;
  }

  public getEvents(): AuditEvent[] {
    return [...this.events];
  }
}

export const auditBus = new AuditLogBus();
