import { HourlyDemandPoint, DemandForecast, LocationId, DepartmentId, RoleId, Shift } from '../types/domain';
import { SEED_ROLES } from '../data/seedData';

// Generates continuous 24-hour demand curve for a given date and location
export function generateDemandCurve(locationId: LocationId, dateStr: string, multiplier: number = 1.0): HourlyDemandPoint[] {
  const date = new Date(dateStr);
  const dayOfWeek = date.getDay(); // 0 = Sun, 6 = Sat
  const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;

  const points: HourlyDemandPoint[] = [];

  for (let hour = 0; hour < 24; hour++) {
    let baseFootfall = 0;
    let salesFactor = 0;

    if (hour >= 6 && hour <= 21) {
      // Store open hours
      // Bell curve peak at 12:00-13:00 and 17:00-18:00
      const morningPeak = Math.exp(-Math.pow(hour - 12, 2) / 8);
      const eveningPeak = Math.exp(-Math.pow(hour - 17, 2) / 6);
      const combinedCurve = Math.max(morningPeak, eveningPeak * 0.9) + 0.15;

      const weekendMultiplier = isWeekend ? 1.35 : 1.0;
      baseFootfall = Math.round((120 + combinedCurve * 380) * weekendMultiplier * multiplier);
      salesFactor = Math.round(baseFootfall * 28.5);
    } else if (hour >= 4 && hour < 6) {
      // Early morning restocking & bakery prep
      baseFootfall = 10;
      salesFactor = 200;
    }

    const transactions = Math.round(baseFootfall * 0.42);
    const deliveries = (hour === 7 || hour === 14) ? 2 : 0;
    const onlineOrders = Math.round(baseFootfall * 0.12);

    // Calculate required staff headcount per role
    const requiredStaffHeadcount: Record<RoleId, number> = {
      'ROLE-MGR': hour >= 6 && hour <= 22 ? 1 : 0,
      'ROLE-SUPV': hour >= 7 && hour <= 21 ? (transactions > 60 ? 2 : 1) : 0,
      'ROLE-CASHIER': hour >= 7 && hour <= 21 ? Math.max(1, Math.min(8, Math.ceil(transactions / 22))) : 0,
      'ROLE-GROC-STOCK': hour >= 6 && hour <= 20 ? Math.max(1, Math.min(6, Math.ceil(baseFootfall / 80))) : 0,
      'ROLE-PROD-SPEC': hour >= 6 && hour <= 20 ? Math.max(1, Math.min(3, Math.ceil(baseFootfall / 120))) : 0,
      'ROLE-BAKER': hour >= 5 && hour <= 15 ? (hour < 11 ? 2 : 1) : 0,
      'ROLE-WARE-OP': (hour >= 6 && hour <= 18) || deliveries > 0 ? Math.max(1, Math.min(4, Math.ceil((baseFootfall + deliveries * 100) / 100))) : 0,
      'ROLE-CS-SPEC': hour >= 8 && hour <= 20 ? (baseFootfall > 150 ? 2 : 1) : 0,
    };

    points.push({
      hour,
      salesForecast: salesFactor,
      customerTraffic: baseFootfall,
      transactions,
      deliveries,
      onlineOrders,
      requiredStaffHeadcount,
    });
  }

  return points;
}

export function generateDemandForecast(
  locationId: LocationId,
  dateStr: string,
  model: 'MOVING_AVERAGE' | 'EXPONENTIAL_SMOOTHING' | 'SEASONAL_REGRESSION' | 'ML_ENSEMBLE' = 'SEASONAL_REGRESSION',
  growthFactor: number = 1.0
): DemandForecast {
  const hourlyData = generateDemandCurve(locationId, dateStr, growthFactor);
  return {
    locationId,
    date: dateStr,
    hourlyData,
    forecastModelUsed: model,
    confidenceInterval: model === 'ML_ENSEMBLE' ? 0.96 : 0.92,
  };
}

// Convert DemandForecast into candidate shifts required to fulfill peak and coverage demand
export function generateCandidateShiftsFromDemand(
  locationId: LocationId,
  departmentId: DepartmentId,
  forecast: DemandForecast
): Partial<Shift>[] {
  const candidateShifts: Partial<Shift>[] = [];
  const dateStr = forecast.date;

  // Derive shifts based on roles required throughout the day
  SEED_ROLES.filter(r => r.departmentId === departmentId || departmentId === 'ALL').forEach(role => {
    // Determine start and end windows by peak hours
    const hourlyReqs = forecast.hourlyData.map(h => ({ hour: h.hour, req: h.requiredStaffHeadcount[role.id] || 0 }));
    const activeHours = hourlyReqs.filter(h => h.req > 0);

    if (activeHours.length === 0) return;

    const minHour = activeHours[0].hour;
    const maxHour = activeHours[activeHours.length - 1].hour;
    const maxHeadcount = Math.max(...activeHours.map(h => h.req));

    // Create staggered 8-hour shift slots to cover the span
    for (let count = 0; count < maxHeadcount; count++) {
      // Morning shift
      const morningStart = `${String(minHour).padStart(2, '0')}:00`;
      const morningEndHour = Math.min(23, minHour + 8);
      const morningEnd = `${String(morningEndHour).padStart(2, '0')}:00`;

      candidateShifts.push({
        locationId,
        departmentId: role.departmentId,
        roleId: role.id,
        date: dateStr,
        startTime: morningStart,
        endTime: morningEnd,
        breakMinutes: 30,
        requiredSkills: role.requiredSkills,
        assignedEmployeeId: null,
        status: 'OPEN' as any,
      });

      // Afternoon / Evening shift if required active hours extend past 8 hours
      if (maxHour - minHour > 7) {
        const eveStartHour = Math.max(minHour + 4, maxHour - 8);
        const eveStart = `${String(eveStartHour).padStart(2, '0')}:00`;
        const eveEnd = `${String(Math.min(23, eveStartHour + 8)).padStart(2, '0')}:00`;

        candidateShifts.push({
          locationId,
          departmentId: role.departmentId,
          roleId: role.id,
          date: dateStr,
          startTime: eveStart,
          endTime: eveEnd,
          breakMinutes: 30,
          requiredSkills: role.requiredSkills,
          assignedEmployeeId: null,
          status: 'OPEN' as any,
        });
      }
    }
  });

  return candidateShifts;
}
