import { TimeClockRecord, VarianceAnalysis, Shift, Employee } from '../types/domain';
import { timeToMinutes } from './constraints';

export function calculateShiftVariance(
  shift: Shift,
  clockRecord: TimeClockRecord,
  employee: Employee
): VarianceAnalysis {
  const schedStartMins = timeToMinutes(shift.startTime);
  const schedEndMins = timeToMinutes(shift.endTime);
  const scheduledHours = (schedEndMins - schedStartMins - shift.breakMinutes) / 60;

  if (!clockRecord || !clockRecord.clockInTime) {
    return {
      shiftId: shift.id,
      employeeId: employee.id,
      scheduledStart: shift.startTime,
      scheduledEnd: shift.endTime,
      startOffsetMinutes: 0,
      endOffsetMinutes: 0,
      actualHoursWorked: 0,
      scheduledHoursWorked: scheduledHours,
      varianceHours: -scheduledHours,
      status: 'ABSENT',
    };
  }

  const clockInMins = timeToMinutes(clockRecord.clockInTime);
  const clockOutMins = clockRecord.clockOutTime ? timeToMinutes(clockRecord.clockOutTime) : schedEndMins;

  const startOffset = clockInMins - schedStartMins; // >0 is late
  const endOffset = clockOutMins - schedEndMins;

  const actualHours = (clockOutMins - clockInMins - shift.breakMinutes) / 60;
  const varianceHours = Math.round((actualHours - scheduledHours) * 10) / 10;

  let status: VarianceAnalysis['status'] = 'ON_TIME';
  if (startOffset > 5) {
    status = 'LATE_ARRIVING';
  } else if (endOffset < -15) {
    status = 'EARLY_DEPARTURE';
  } else if (varianceHours > 0.5) {
    status = 'OVERTIME_UNSCHEDULED';
  }

  return {
    shiftId: shift.id,
    employeeId: employee.id,
    scheduledStart: shift.startTime,
    scheduledEnd: shift.endTime,
    actualStart: clockRecord.clockInTime,
    actualEnd: clockRecord.clockOutTime,
    startOffsetMinutes: startOffset,
    endOffsetMinutes: endOffset,
    actualHoursWorked: Math.max(0, Math.round(actualHours * 10) / 10),
    scheduledHoursWorked: scheduledHours,
    varianceHours,
    status,
  };
}
