import {
  Employee,
  Shift,
  HardConstraintViolation,
  SoftConstraintPenalty,
  DayOfWeek,
  ExplanationFactor,
} from '../types/domain';
import { SEED_ROLES } from '../data/seedData';

// Convert Date string (YYYY-MM-DD) to DayOfWeek enum
export function getDayOfWeekFromDate(dateStr: string): DayOfWeek {
  const d = new Date(dateStr);
  const days = [
    DayOfWeek.SUNDAY,
    DayOfWeek.MONDAY,
    DayOfWeek.TUESDAY,
    DayOfWeek.WEDNESDAY,
    DayOfWeek.THURSDAY,
    DayOfWeek.FRIDAY,
    DayOfWeek.SATURDAY,
  ];
  return days[d.getDay()];
}

// Convert "HH:MM" string to minutes from midnight
export function timeToMinutes(timeStr: string): number {
  const [h, m] = timeStr.split(':').map(Number);
  return h * 60 + m;
}

// Check if two time intervals overlap on the same date
export function shiftsOverlap(s1: { startTime: string; endTime: string }, s2: { startTime: string; endTime: string }): boolean {
  const start1 = timeToMinutes(s1.startTime);
  const end1 = timeToMinutes(s1.endTime);
  const start2 = timeToMinutes(s2.startTime);
  const end2 = timeToMinutes(s2.endTime);

  return Math.max(start1, start2) < Math.min(end1, end2);
}

// Check hard constraints for assigning an employee to a shift
export function checkHardConstraints(
  employee: Employee,
  shift: Shift,
  allScheduledShiftsForEmployee: Shift[]
): HardConstraintViolation[] {
  const violations: HardConstraintViolation[] = [];

  // 1. Approved Leave Conflict
  const onLeave = employee.leave.some(
    l => l.status === 'APPROVED' && shift.date >= l.startDate && shift.date <= l.endDate
  );
  if (onLeave) {
    violations.push({
      code: 'APPROVED_LEAVE_CONFLICT',
      description: `Employee ${employee.name} is on approved leave on ${shift.date}`,
      severity: 'CRITICAL',
      employeeId: employee.id,
      shiftId: shift.id,
    });
  }

  // 2. Role Eligibility
  if (!employee.roles.includes(shift.roleId)) {
    const roleName = SEED_ROLES.find(r => r.id === shift.roleId)?.name || shift.roleId;
    violations.push({
      code: 'MISSING_REQUIRED_ROLE',
      description: `${employee.name} is not certified for role ${roleName}`,
      severity: 'BLOCKING',
      employeeId: employee.id,
      shiftId: shift.id,
    });
  }

  // 3. Qualifications Verification & Expiry
  const roleObj = SEED_ROLES.find(r => r.id === shift.roleId);
  if (roleObj && roleObj.requiredQualifications.length > 0) {
    for (const reqQualId of roleObj.requiredQualifications) {
      const empQual = employee.qualifications.find(q => q.id === reqQualId);
      if (!empQual) {
        violations.push({
          code: 'MISSING_QUALIFICATION',
          description: `${employee.name} lacks qualification ID ${reqQualId} required for ${roleObj.name}`,
          severity: 'BLOCKING',
          employeeId: employee.id,
          shiftId: shift.id,
        });
      } else if (empQual.status === 'EXPIRED' || empQual.expiryDate < shift.date) {
        violations.push({
          code: 'EXPIRED_QUALIFICATION',
          description: `${employee.name}'s qualification ${empQual.name} expired on ${empQual.expiryDate}`,
          severity: 'BLOCKING',
          employeeId: employee.id,
          shiftId: shift.id,
        });
      }
    }
  }

  // 4. Availability Window
  const day = getDayOfWeekFromDate(shift.date);
  const availWindow = employee.availability.find(a => a.day === day);
  if (!availWindow || availWindow.preference === 'UNAVAILABLE') {
    violations.push({
      code: 'EMPLOYEE_UNAVAILABLE',
      description: `${employee.name} is unavailable on ${day}s`,
      severity: 'BLOCKING',
      employeeId: employee.id,
      shiftId: shift.id,
    });
  } else {
    const availStart = timeToMinutes(availWindow.startTime);
    const availEnd = timeToMinutes(availWindow.endTime);
    const shiftStart = timeToMinutes(shift.startTime);
    const shiftEnd = timeToMinutes(shift.endTime);

    if (availStart !== 0 || availEnd !== 0) {
      if (shiftStart < availStart || shiftEnd > availEnd) {
        violations.push({
          code: 'OUTSIDE_AVAILABILITY_WINDOW',
          description: `Shift (${shift.startTime}-${shift.endTime}) is outside ${employee.name}'s availability window (${availWindow.startTime}-${availWindow.endTime})`,
          severity: 'BLOCKING',
          employeeId: employee.id,
          shiftId: shift.id,
        });
      }
    }
  }

  // 5. Shift Overlap Conflict
  const sameDayShifts = allScheduledShiftsForEmployee.filter(s => s.date === shift.date && s.id !== shift.id);
  for (const existingShift of sameDayShifts) {
    if (shiftsOverlap(existingShift, shift)) {
      violations.push({
        code: 'SHIFT_OVERLAP_CONFLICT',
        description: `${employee.name} is already assigned to shift ${existingShift.startTime}-${existingShift.endTime} on ${shift.date}`,
        severity: 'CRITICAL',
        employeeId: employee.id,
        shiftId: shift.id,
      });
    }
  }

  // 6. Max Weekly Hours Limit
  const shiftDurationHours = (timeToMinutes(shift.endTime) - timeToMinutes(shift.startTime) - shift.breakMinutes) / 60;
  const currentAssignedHours = allScheduledShiftsForEmployee
    .filter(s => s.id !== shift.id)
    .reduce((total, s) => total + (timeToMinutes(s.endTime) - timeToMinutes(s.startTime) - s.breakMinutes) / 60, 0);

  if (currentAssignedHours + shiftDurationHours > employee.contract.maxHoursPerWeek) {
    violations.push({
      code: 'MAX_HOURS_EXCEEDED',
      description: `Assigning this shift (${shiftDurationHours}h) causes ${employee.name} to exceed contract maximum of ${employee.contract.maxHoursPerWeek}h/week`,
      severity: 'BLOCKING',
      employeeId: employee.id,
      shiftId: shift.id,
    });
  }

  // 7. Minimum Rest Period
  for (const existingShift of allScheduledShiftsForEmployee) {
    if (existingShift.id === shift.id) continue;

    // Check rest period between dates
    const shiftDateObj = new Date(shift.date).getTime();
    const existingDateObj = new Date(existingShift.date).getTime();
    const diffDays = Math.abs((shiftDateObj - existingDateObj) / (1000 * 3600 * 24));

    if (diffDays <= 1) {
      // Calculate gap in hours
      let gapHours = 24;
      if (existingShift.date === shift.date) {
        gapHours = Math.abs(timeToMinutes(shift.startTime) - timeToMinutes(existingShift.endTime)) / 60;
      } else if (existingDateObj < shiftDateObj) {
        // existing shift was yesterday
        const existingEndMins = timeToMinutes(existingShift.endTime);
        const shiftStartMins = timeToMinutes(shift.startTime);
        gapHours = (24 * 60 - existingEndMins + shiftStartMins) / 60;
      } else {
        // existing shift is tomorrow
        const shiftEndMins = timeToMinutes(shift.endTime);
        const existingStartMins = timeToMinutes(existingShift.startTime);
        gapHours = (24 * 60 - shiftEndMins + existingStartMins) / 60;
      }

      if (gapHours < employee.contract.minRestHoursBetweenShifts) {
        violations.push({
          code: 'REST_PERIOD_VIOLATION',
          description: `Only ${gapHours.toFixed(1)}h rest between shifts for ${employee.name} (minimum required: ${employee.contract.minRestHoursBetweenShifts}h)`,
          severity: 'BLOCKING',
          employeeId: employee.id,
          shiftId: shift.id,
        });
      }
    }
  }

  return violations;
}

// Calculate Soft Penalties and explanation checkmarks for assigning an employee
export function evaluateSoftConstraints(
  employee: Employee,
  shift: Shift,
  allScheduledShiftsForEmployee: Shift[]
): { penalties: SoftConstraintPenalty[]; explanationFactors: ExplanationFactor[] } {
  const penalties: SoftConstraintPenalty[] = [];
  const factors: ExplanationFactor[] = [];

  const day = getDayOfWeekFromDate(shift.date);
  const availWindow = employee.availability.find(a => a.day === day);

  // 1. Availability Preference
  if (availWindow && availWindow.preference === 'PREFERRED') {
    factors.push({ factor: 'Day Preference', passed: true, weight: 15, detail: `Employee explicitly preferred working on ${day}s` });
  } else if (availWindow && availWindow.preference === 'PREFERRED_NOT') {
    penalties.push({
      code: 'PREFERENCE_DAY_DISLIKED',
      description: `${employee.name} preferred not working on ${day}s`,
      penaltyPoints: 15,
      employeeId: employee.id,
      shiftId: shift.id,
    });
    factors.push({ factor: 'Day Preference', passed: false, weight: 15, detail: `Assigned on a day employee preferred not working (${day})` });
  } else {
    factors.push({ factor: 'Day Availability', passed: true, weight: 10, detail: `Employee is available on ${day}` });
  }

  // 2. Role match
  factors.push({ factor: 'Qualified for Role', passed: true, weight: 20, detail: `Certified for department role` });

  // 3. Contract Target Hours
  const shiftHours = (timeToMinutes(shift.endTime) - timeToMinutes(shift.startTime) - shift.breakMinutes) / 60;
  const totalAssignedHours = allScheduledShiftsForEmployee
    .filter(s => s.id !== shift.id)
    .reduce((sum, s) => sum + (timeToMinutes(s.endTime) - timeToMinutes(s.startTime) - s.breakMinutes) / 60, 0);

  const newTotalHours = totalAssignedHours + shiftHours;
  if (newTotalHours > employee.contract.targetHoursPerWeek) {
    const overtimeHours = newTotalHours - employee.contract.targetHoursPerWeek;
    penalties.push({
      code: 'OVERTIME_RISK',
      description: `Pushes ${employee.name} ${overtimeHours.toFixed(1)}h above target weekly hours (${employee.contract.targetHoursPerWeek}h)`,
      penaltyPoints: Math.round(overtimeHours * 10),
      employeeId: employee.id,
      shiftId: shift.id,
    });
    factors.push({ factor: 'Target Hours Compliance', passed: false, weight: 15, detail: `Exceeds target contract hours by ${overtimeHours.toFixed(1)}h` });
  } else {
    factors.push({ factor: 'Target Hours Compliance', passed: true, weight: 15, detail: `Within target weekly contract hours (${newTotalHours.toFixed(1)} / ${employee.contract.targetHoursPerWeek}h)` });
  }

  // 4. Weekend Fairness Balance
  const isWeekend = day === DayOfWeek.SATURDAY || day === DayOfWeek.SUNDAY;
  if (isWeekend) {
    const existingWeekendShifts = allScheduledShiftsForEmployee.filter(s => {
      const d = getDayOfWeekFromDate(s.date);
      return (d === DayOfWeek.SATURDAY || d === DayOfWeek.SUNDAY) && s.id !== shift.id;
    }).length;

    if (existingWeekendShifts > 1) {
      penalties.push({
        code: 'UNFAIR_WEEKEND_DISTRIBUTION',
        description: `${employee.name} is assigned ${existingWeekendShifts + 1} weekend shifts this week`,
        penaltyPoints: 20,
        employeeId: employee.id,
        shiftId: shift.id,
      });
      factors.push({ factor: 'Weekend Fairness', passed: false, weight: 10, detail: `Assigned multiple weekend shifts` });
    } else {
      factors.push({ factor: 'Weekend Fairness', passed: true, weight: 10, detail: `Balanced weekend shift distribution` });
    }
  }

  // 5. Rest & Schedule Stability
  factors.push({ factor: 'Schedule Continuity & Rest', passed: true, weight: 15, detail: `Complies with minimum rest period between shifts` });

  return { penalties, explanationFactors: factors };
}
