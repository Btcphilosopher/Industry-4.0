import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { ManagerCommandCentre } from './components/ManagerCommandCentre';
import { WeeklyScheduler } from './components/WeeklyScheduler';
import { DemandForecastingStudio } from './components/DemandForecastingStudio';
import { WhatIfLab } from './components/WhatIfLab';
import { RosterAndSkills } from './components/RosterAndSkills';
import { ShiftSwapsAndOpenShifts } from './components/ShiftSwapsAndOpenShifts';
import { TimeClockAndVariance } from './components/TimeClockAndVariance';
import { AuditLogAndVersions } from './components/AuditLogAndVersions';
import { ShiftCoreAIModal } from './components/ShiftCoreAIModal';

import { SEED_LOCATIONS, SEED_EMPLOYEES } from './data/seedData';
import { generateOptimalSchedule, generateRankedScheduleOptions } from './engine/scheduler';
import { ScheduleResult, Shift, Employee, RankedScheduleOption } from './types/domain';
import { auditBus } from './engine/audit';
import { Zap, CheckCircle2, ShieldCheck, Cpu } from 'lucide-react';

export default function App() {
  const [selectedLocationId, setSelectedLocationId] = useState<string>('LOC-104');
  const [activeTab, setActiveTab] = useState<string>('COMMAND');
  const [userRole, setUserRole] = useState<'MANAGER' | 'EMPLOYEE'>('MANAGER');
  const [employees, setEmployees] = useState<Employee[]>(SEED_EMPLOYEES);

  const [activeSchedule, setActiveSchedule] = useState<ScheduleResult>(() =>
    generateOptimalSchedule('LOC-104', '2026-09-07', SEED_EMPLOYEES)
  );

  const [departmentFilter, setDepartmentFilter] = useState<string>('ALL');
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [isAiModalOpen, setIsAiModalOpen] = useState<boolean>(false);

  // Multi-Objective Solver Modal
  const [solverModalOpen, setSolverModalOpen] = useState<boolean>(false);
  const [solverProgressStep, setSolverProgressStep] = useState<number>(0);
  const [rankedOptions, setRankedOptions] = useState<RankedScheduleOption[] | null>(null);

  // Re-generate schedule when location changes
  useEffect(() => {
    const newSchedule = generateOptimalSchedule(selectedLocationId, '2026-09-07', employees);
    setActiveSchedule(newSchedule);
  }, [selectedLocationId]);

  // Handler for "GENERATE OPTIMAL SCHEDULE"
  const handleOpenSolverModal = (strategyName: string = 'BALANCED') => {
    setSolverModalOpen(true);
    setSolverProgressStep(1);
    setIsGenerating(true);

    setTimeout(() => setSolverProgressStep(2), 300);
    setTimeout(() => setSolverProgressStep(3), 600);
    setTimeout(() => {
      setSolverProgressStep(4);
      const options = generateRankedScheduleOptions(selectedLocationId, '2026-09-07', employees);
      setRankedOptions(options);
      setIsGenerating(false);

      auditBus.logEvent(
        'Manager User',
        'SCHEDULE_GENERATED',
        'Schedule',
        `SCH-20260907`,
        null,
        { coverage: `${options[0].schedule.score.demandCoveragePct}%` },
        'Triggered multi-objective schedule solver'
      );
    }, 1000);
  };

  const handleSelectRankedOption = (option: RankedScheduleOption) => {
    setActiveSchedule(option.schedule);
    setSolverModalOpen(false);
    setRankedOptions(null);
  };

  // Lock / Unlock shift
  const handleLockToggle = (shiftId: string) => {
    setActiveSchedule(prev => ({
      ...prev,
      shifts: prev.shifts.map(s => (s.id === shiftId ? { ...s, isLocked: !s.isLocked } : s)),
    }));
  };

  // Open shift assignment handler
  const handleAssignOpenShift = (shiftId: string, employeeId: string) => {
    setActiveSchedule(prev => ({
      ...prev,
      shifts: prev.shifts.map(s => (s.id === shiftId ? { ...s, assignedEmployeeId: employeeId, status: 'ASSIGNED' as any } : s)),
      score: {
        ...prev.score,
        unassignedShiftsCount: Math.max(0, prev.score.unassignedShiftsCount - 1),
        demandCoveragePct: Math.min(100, Math.round((prev.score.demandCoveragePct + 2.5) * 10) / 10),
      },
    }));

    const emp = employees.find(e => e.id === employeeId);
    auditBus.logEvent(
      'Manager User',
      'SHIFT_ASSIGNED',
      'Shift',
      shiftId,
      { assignedEmployeeId: null },
      { assignedEmployeeId: employeeId },
      `Assigned open shift to ${emp?.name}`
    );
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans antialiased selection:bg-blue-600 selection:text-white">
      {/* Top Header */}
      <Header
        locations={SEED_LOCATIONS}
        selectedLocationId={selectedLocationId}
        onSelectLocation={setSelectedLocationId}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        userRole={userRole}
        onRoleToggle={() => setUserRole(r => (r === 'MANAGER' ? 'EMPLOYEE' : 'MANAGER'))}
        onOpenAiAssistant={() => setIsAiModalOpen(true)}
        onGenerateScheduleClick={() => handleOpenSolverModal('BALANCED')}
      />

      {/* Main Module Canvas */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'COMMAND' && (
          <ManagerCommandCentre
            schedule={activeSchedule}
            employees={employees}
            onNavigateTab={setActiveTab}
            onGenerateSchedule={() => handleOpenSolverModal('BALANCED')}
          />
        )}

        {activeTab === 'SCHEDULER' && (
          <WeeklyScheduler
            schedule={activeSchedule}
            employees={employees}
            onShiftClick={() => {}}
            onGenerateOptimalSchedule={handleOpenSolverModal}
            onLockToggle={handleLockToggle}
            selectedDepartmentFilter={departmentFilter}
            onDepartmentFilterChange={setDepartmentFilter}
            isGenerating={isGenerating}
          />
        )}

        {activeTab === 'DEMAND' && (
          <DemandForecastingStudio locationId={selectedLocationId} />
        )}

        {activeTab === 'WHATIF' && (
          <WhatIfLab locationId={selectedLocationId} employees={employees} />
        )}

        {activeTab === 'ROSTER' && (
          <RosterAndSkills employees={employees} />
        )}

        {activeTab === 'SWAPS' && (
          <ShiftSwapsAndOpenShifts
            shifts={activeSchedule.shifts}
            employees={employees}
            onAssignOpenShift={handleAssignOpenShift}
          />
        )}

        {activeTab === 'ACTUALS' && (
          <TimeClockAndVariance
            shifts={activeSchedule.shifts}
            employees={employees}
          />
        )}

        {activeTab === 'AUDIT' && (
          <AuditLogAndVersions currentSchedule={activeSchedule} />
        )}
      </main>

      {/* ShiftCore AI Modal */}
      <ShiftCoreAIModal
        isOpen={isAiModalOpen}
        onClose={() => setIsAiModalOpen(false)}
        activeSchedule={activeSchedule}
      />

      {/* Multi-Objective Solver Execution Progress & Options Modal */}
      {solverModalOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl p-6 space-y-6 text-slate-100 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 bg-emerald-600/20 text-emerald-400 rounded-lg">
                  <Zap className="w-5 h-5 fill-current" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-100 text-base">ShiftCore Constraint & Optimisation Engine</h3>
                  <p className="text-xs text-slate-400">Multi-Objective Rust Solver Execution</p>
                </div>
              </div>
            </div>

            {/* Step Progress Telemetry */}
            <div className="space-y-2 text-xs font-mono">
              <div className={`p-2.5 rounded-lg border flex items-center justify-between ${solverProgressStep >= 1 ? 'bg-slate-950 border-emerald-500/40 text-emerald-400' : 'text-slate-500 border-slate-850'}`}>
                <span>1. Loading Employees, Contracts & Availability Windows (10 Active)</span>
                {solverProgressStep >= 1 && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
              </div>

              <div className={`p-2.5 rounded-lg border flex items-center justify-between ${solverProgressStep >= 2 ? 'bg-slate-950 border-emerald-500/40 text-emerald-400' : 'text-slate-500 border-slate-850'}`}>
                <span>2. Forecasting Demand Curves & Generating Candidate Shifts (42 Slots)</span>
                {solverProgressStep >= 2 && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
              </div>

              <div className={`p-2.5 rounded-lg border flex items-center justify-between ${solverProgressStep >= 3 ? 'bg-slate-950 border-emerald-500/40 text-emerald-400' : 'text-slate-500 border-slate-850'}`}>
                <span>3. Evaluating Hard Constraints (Rest, Overlaps, Max Hours, Qualifications)</span>
                {solverProgressStep >= 3 && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
              </div>

              <div className={`p-2.5 rounded-lg border flex items-center justify-between ${solverProgressStep >= 4 ? 'bg-slate-950 border-emerald-500/40 text-emerald-400' : 'text-slate-500 border-slate-850'}`}>
                <span>4. Scoring Soft Penalties & Multi-Objective Swap Optimisation</span>
                {solverProgressStep >= 4 && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
              </div>
            </div>

            {/* Ranked Options Selection */}
            {rankedOptions && (
              <div className="space-y-3 pt-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Select Generated Schedule Option:
                </h4>

                <div className="space-y-2.5">
                  {rankedOptions.map(opt => (
                    <div
                      key={opt.id}
                      onClick={() => handleSelectRankedOption(opt)}
                      className={`p-3.5 rounded-xl border text-xs cursor-pointer transition-all flex items-center justify-between ${
                        opt.isRecommended
                          ? 'bg-blue-600/15 border-blue-500 text-slate-100 hover:border-blue-400'
                          : 'bg-slate-950 border-slate-850 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <div>
                        <div className="font-bold text-slate-100 flex items-center space-x-2">
                          <span>{opt.name}</span>
                          {opt.isRecommended && (
                            <span className="bg-emerald-500/20 text-emerald-400 text-[9px] px-1.5 py-0.5 rounded font-mono uppercase font-extrabold">
                              RECOMMENDED
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-400 mt-0.5">{opt.description}</div>
                      </div>

                      <div className="text-right font-mono text-[11px] shrink-0 ml-4">
                        <div className="text-emerald-400 font-bold">{opt.schedule.score.demandCoveragePct}% Coverage</div>
                        <div className="text-slate-300">${opt.schedule.score.totalLabourCost.toLocaleString()}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
