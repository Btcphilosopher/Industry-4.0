"""
containers/tracking.py

Container search/tracking API (req. #36) — e.g. look up `CONT-00001234`
and see its origin, destination, current position, current vehicle,
current status, ETA and full transfer history.
"""
from __future__ import annotations

from typing import Optional

from freight_os.containers.container import Container, ContainerStatus


class ContainerTracker:
    def __init__(self) -> None:
        self._containers: dict[str, Container] = {}

    def register(self, container: Container) -> None:
        self._containers[container.container_id] = container

    def get(self, container_id: str) -> Optional[Container]:
        return self._containers.get(container_id)

    def all_containers(self) -> list[Container]:
        return list(self._containers.values())

    def search(self, container_id: str, current_time: float, eta_lookup=None) -> dict:
        """
        Full tracking record for the dashboard / CLI `track <id>` command.
        `eta_lookup` is an optional callable(container) -> float hours, supplied
        by the dispatcher/route optimizer for an in-transit container's ETA.
        """
        c = self.get(container_id)
        if c is None:
            return {"found": False, "container_id": container_id}

        eta = None
        if c.status != ContainerStatus.DELIVERED and eta_lookup is not None:
            eta = eta_lookup(c)

        return {
            "found": True,
            "container_id": c.container_id,
            "origin": c.origin,
            "destination": c.destination,
            "current_position": c.current_location,
            "current_vehicle": c.current_vehicle,
            "current_status": c.status.value,
            "planned_route": c.planned_route,
            "eta_hours_remaining": eta,
            "transfer_history": [
                {
                    "timestamp": h.timestamp,
                    "from": h.from_location,
                    "to": h.to_location,
                    "vehicle_id": h.vehicle_id,
                    "mode": h.mode,
                    "status": h.status.value,
                }
                for h in c.history
            ],
            "as_of": current_time,
        }

    def delivered(self) -> list[Container]:
        return [c for c in self._containers.values() if c.status == ContainerStatus.DELIVERED]

    def in_transit(self) -> list[Container]:
        return [
            c
            for c in self._containers.values()
            if c.status in (ContainerStatus.IN_TRANSIT, ContainerStatus.LOADED, ContainerStatus.TRANSFER)
        ]

    def average_transit_time(self) -> Optional[float]:
        times = [c.transit_time_hours for c in self.delivered() if c.transit_time_hours is not None]
        return sum(times) / len(times) if times else None
