"""
containers/container.py

The container digital twin (req. #3). A `Container` carries its full
lifecycle history so the rest of the platform (tracking, reporting,
dashboards) never has to reconstruct it from event logs alone.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class ContainerStatus(str, Enum):
    BOOKED = "BOOKED"
    LOADED = "LOADED"
    IN_TRANSIT = "IN_TRANSIT"
    AT_TERMINAL = "AT_TERMINAL"
    WAITING = "WAITING"
    TRANSFER = "TRANSFER"
    DELIVERED = "DELIVERED"


class HazardClass(str, Enum):
    NONE = "none"
    CLASS_1_EXPLOSIVES = "class_1_explosives"
    CLASS_2_GASES = "class_2_gases"
    CLASS_3_FLAMMABLE_LIQUIDS = "class_3_flammable_liquids"
    CLASS_9_MISC = "class_9_misc"


@dataclass
class TransferRecord:
    timestamp: float
    from_location: str
    to_location: str
    vehicle_id: Optional[str]
    mode: Optional[str]
    status: ContainerStatus


@dataclass
class Container:
    container_id: str
    origin: str
    destination: str
    weight_kg: float
    volume_m3: float
    cargo_type: str = "general"
    priority: int = 3  # 1 = highest priority, 5 = lowest
    hazard_class: HazardClass = HazardClass.NONE

    current_location: str = ""
    current_vehicle: Optional[str] = None
    status: ContainerStatus = ContainerStatus.BOOKED

    booked_at: float = 0.0
    delivered_at: Optional[float] = None
    planned_route: list[str] = field(default_factory=list)  # node ids, factory->...->warehouse
    planned_modes: list[str] = field(default_factory=list)  # edge modes matching planned_route legs

    history: list[TransferRecord] = field(default_factory=list)

    def __post_init__(self) -> None:
        if not self.current_location:
            self.current_location = self.origin

    # ---------------------------------------------------------------
    def transition(
        self,
        timestamp: float,
        status: ContainerStatus,
        location: Optional[str] = None,
        vehicle_id: Optional[str] = None,
        mode: Optional[str] = None,
    ) -> None:
        from_location = self.current_location
        if location is not None:
            self.current_location = location
        self.current_vehicle = vehicle_id
        self.status = status
        self.history.append(
            TransferRecord(
                timestamp=timestamp,
                from_location=from_location,
                to_location=self.current_location,
                vehicle_id=vehicle_id,
                mode=mode,
                status=status,
            )
        )
        if status == ContainerStatus.DELIVERED:
            self.delivered_at = timestamp

    @property
    def transit_time_hours(self) -> Optional[float]:
        if self.delivered_at is None:
            return None
        return self.delivered_at - self.booked_at

    def as_dict(self) -> dict:
        return {
            "container_id": self.container_id,
            "origin": self.origin,
            "destination": self.destination,
            "weight_kg": self.weight_kg,
            "volume_m3": self.volume_m3,
            "cargo_type": self.cargo_type,
            "priority": self.priority,
            "hazard_class": self.hazard_class.value,
            "current_location": self.current_location,
            "current_vehicle": self.current_vehicle,
            "status": self.status.value,
            "booked_at": self.booked_at,
            "delivered_at": self.delivered_at,
            "transit_time_hours": self.transit_time_hours,
        }
