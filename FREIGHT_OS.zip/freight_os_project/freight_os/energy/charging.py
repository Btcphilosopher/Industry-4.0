"""
energy/charging.py

Charging infrastructure (req. #17): truck/terminal/warehouse/depot chargers,
modelled as SimPy resources so vehicles queue for a charger realistically,
plus simple peak-demand tracking and allocation across depots.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import simpy

from freight_os.core.events import EventLog, EventType


@dataclass
class ChargingStation:
    station_id: str
    location: str
    num_chargers: int
    power_kw: float
    env: simpy.Environment = None
    resource: simpy.Resource = field(default=None, repr=False)
    energy_delivered_kwh: float = 0.0
    _demand_samples: list = field(default_factory=list)

    def bind(self, env: simpy.Environment) -> None:
        self.env = env
        self.resource = simpy.Resource(env, capacity=self.num_chargers)

    def charge_vehicle(self, battery, event_log: EventLog, vehicle_id: str, target_soc: float = 0.9):
        with self.resource.request() as req:
            yield req
            duration_h = battery.time_to_charge_h(target_soc)
            event_log.log(self.env.now, EventType.CHARGING_STARTED, vehicle_id, station=self.station_id)
            needed_kwh = max(0.0, (target_soc - battery.soc) * battery.capacity_kwh)
            self._demand_samples.append((self.env.now, self.power_kw))
            yield self.env.timeout(duration_h)
            battery.charge(needed_kwh)
            self.energy_delivered_kwh += needed_kwh
            event_log.log(self.env.now, EventType.CHARGING_COMPLETED, vehicle_id, station=self.station_id, energy_kwh=needed_kwh)

    def current_load_kw(self, at_time: float, window_h: float = 0.25) -> float:
        return sum(p for t, p in self._demand_samples if abs(t - at_time) <= window_h)

    def peak_demand_kw(self) -> float:
        return self.num_chargers * self.power_kw


@dataclass
class ChargingNetwork:
    stations: dict[str, ChargingStation] = field(default_factory=dict)

    def add_station(self, station: ChargingStation, env: simpy.Environment) -> None:
        station.bind(env)
        self.stations[station.station_id] = station

    def nearest_station(self, location: str):
        for s in self.stations.values():
            if s.location == location:
                return s
        return None

    def total_energy_delivered_kwh(self) -> float:
        return sum(s.energy_delivered_kwh for s in self.stations.values())

    def total_peak_demand_kw(self) -> float:
        """Simultaneous worst-case peak — used to check against grid-connection limits."""
        return sum(s.peak_demand_kw() for s in self.stations.values())
