"""energy/battery.py — battery digital twin for electric vehicles."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Battery:
    capacity_kwh: float
    soc: float = 0.9  # state of charge, 0-1
    charge_power_kw: float = 150.0
    cycle_count: float = 0.0
    degradation_per_cycle_pct: float = 0.0025  # ~0.25% capacity loss per full-equivalent cycle

    @property
    def energy_kwh(self) -> float:
        return self.capacity_kwh * self.soc

    @property
    def usable_capacity_kwh(self) -> float:
        """Capacity after cumulative degradation."""
        return self.capacity_kwh * max(0.6, 1 - self.degradation_per_cycle_pct * self.cycle_count)

    def discharge(self, energy_kwh: float) -> None:
        self.soc = max(0.0, self.soc - energy_kwh / self.capacity_kwh)
        self.cycle_count += energy_kwh / self.capacity_kwh

    def charge(self, energy_kwh: float) -> None:
        self.soc = min(1.0, self.soc + energy_kwh / self.capacity_kwh)

    def time_to_charge_h(self, target_soc: float = 1.0) -> float:
        needed_kwh = max(0.0, (target_soc - self.soc) * self.capacity_kwh)
        return needed_kwh / max(1e-6, self.charge_power_kw)

    def is_low(self, threshold: float = 0.2) -> bool:
        return self.soc <= threshold
