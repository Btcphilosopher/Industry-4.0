"""energy/hydrogen.py — hydrogen tank + depot infrastructure digital twin (req. #18)."""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class HydrogenTank:
    capacity_kg: float
    level_kg: float = 0.0

    def __post_init__(self) -> None:
        if self.level_kg == 0.0:
            self.level_kg = self.capacity_kg * 0.9

    def consume(self, kg: float) -> None:
        self.level_kg = max(0.0, self.level_kg - kg)

    def refuel(self, kg: float) -> None:
        self.level_kg = min(self.capacity_kg, self.level_kg + kg)

    def is_low(self, threshold: float = 0.2) -> bool:
        return self.level_kg <= threshold * self.capacity_kg


@dataclass
class HydrogenDepot:
    depot_id: str
    storage_capacity_kg: float
    production_rate_kg_per_h: float
    stored_kg: float = 0.0
    dispensed_today_kg: float = field(default=0.0)

    def __post_init__(self) -> None:
        if self.stored_kg == 0.0:
            self.stored_kg = self.storage_capacity_kg * 0.8

    def produce(self, hours: float) -> None:
        self.stored_kg = min(self.storage_capacity_kg, self.stored_kg + self.production_rate_kg_per_h * hours)

    def dispense(self, kg: float) -> float:
        """Returns kg actually dispensed (may be less than requested if depot is short)."""
        actual = min(kg, self.stored_kg)
        self.stored_kg -= actual
        self.dispensed_today_kg += actual
        return actual

    def refuelling_capacity_vehicles_per_day(self, avg_fill_kg: float = 30.0) -> float:
        return (self.storage_capacity_kg + self.production_rate_kg_per_h * 24) / max(1e-6, avg_fill_kg)
