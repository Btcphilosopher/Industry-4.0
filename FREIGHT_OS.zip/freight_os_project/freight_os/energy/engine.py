"""
energy/engine.py

EnergyEngine (req. #16): converts distance travelled into energy/fuel
consumption per vehicle, tracks battery/tank state, and accumulates total
network-wide energy use and cost across electric, hydrogen, diesel and
hybrid drivetrains.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from freight_os.core.configuration import EnergySource, SimulationConfig
from freight_os.energy.battery import Battery
from freight_os.energy.hydrogen import HydrogenTank

# reference consumption rates (loaded, ~20t payload equivalent)
DIESEL_L_PER_KM = 0.36
ELECTRIC_KWH_PER_KM = 1.15
HYDROGEN_KG_PER_KM = 0.09
BARGE_L_PER_KM = 3.2
TRAIN_KWH_PER_GROSS_TONNE_KM = 0.03


@dataclass
class EnergyLedgerEntry:
    vehicle_id: str
    energy_source: str
    amount: float          # kWh, litres, or kg depending on source
    cost_gbp: float
    distance_km: float
    timestamp: float


@dataclass
class EnergyEngine:
    config: SimulationConfig
    ledger: list[EnergyLedgerEntry] = field(default_factory=list)
    env: object = None  # simpy.Environment, set after construction for timestamps

    def _price(self, source: EnergySource) -> float:
        return {
            EnergySource.ELECTRIC: self.config.electricity_price_per_kwh,
            EnergySource.DIESEL: self.config.diesel_price_per_litre,
            EnergySource.HYDROGEN: self.config.hydrogen_price_per_kg,
            EnergySource.HYBRID: (self.config.electricity_price_per_kwh + self.config.diesel_price_per_litre) / 2,
        }[source]

    def _now(self) -> float:
        return self.env.now if self.env is not None else 0.0

    # -- trucks --------------------------------------------------------------
    def consume_truck(self, truck, distance_km: float) -> None:
        source = truck.energy_source
        if source == EnergySource.ELECTRIC:
            battery: Battery = truck.energy_state["battery"]
            used = ELECTRIC_KWH_PER_KM * distance_km
            battery.discharge(used)
            truck.energy_state["low_energy"] = battery.is_low()
            amount = used
        elif source == EnergySource.HYDROGEN:
            tank: HydrogenTank = truck.energy_state["tank"]
            used = HYDROGEN_KG_PER_KM * distance_km
            tank.consume(used)
            truck.energy_state["low_energy"] = tank.is_low()
            amount = used
        elif source == EnergySource.HYBRID:
            used_e = 0.5 * ELECTRIC_KWH_PER_KM * distance_km
            used_d = 0.5 * DIESEL_L_PER_KM * distance_km
            truck.energy_state["battery"].discharge(used_e)
            truck.energy_state["fuel_litres"] = truck.energy_state.get("fuel_litres", truck.fuel_tank_litres) - used_d
            amount = used_e  # ledger primarily tracks electric portion; cost below blends both
        else:  # diesel
            used = DIESEL_L_PER_KM * distance_km
            truck.energy_state["fuel_litres"] = truck.energy_state.get("fuel_litres", truck.fuel_tank_litres) - used
            truck.energy_state["low_energy"] = truck.energy_state["fuel_litres"] < 0.15 * truck.fuel_tank_litres
            amount = used

        cost = amount * self._price(source)
        self.ledger.append(EnergyLedgerEntry(truck.vehicle_id, source.value, amount, cost, distance_km, self._now()))

    # -- barges ------------------------------------------------------------
    def consume_barge(self, barge, distance_km: float) -> None:
        source = barge.energy_source
        if source == EnergySource.ELECTRIC:
            battery: Battery = barge.energy_state["battery"]
            used = ELECTRIC_KWH_PER_KM * 6 * distance_km  # barges are much larger loads
            battery.discharge(used)
            amount = used
        else:
            used = BARGE_L_PER_KM * distance_km
            barge.energy_state["fuel_litres"] = barge.energy_state.get("fuel_litres", barge.fuel_tank_litres) - used
            amount = used
        cost = amount * self._price(source)
        self.ledger.append(EnergyLedgerEntry(barge.vehicle_id, source.value, amount, cost, distance_km, self._now()))

    # -- rail ----------------------------------------------------------------
    def consume_train(self, train, distance_km: float, containers: list) -> None:
        gross_tonnes = sum(c.weight_kg for c in containers) / 1000.0 + 200  # + empty train mass approx
        used_kwh = TRAIN_KWH_PER_GROSS_TONNE_KM * gross_tonnes * distance_km
        cost = used_kwh * self.config.electricity_price_per_kwh
        self.ledger.append(EnergyLedgerEntry(train.train_id, "electric", used_kwh, cost, distance_km, self._now()))

    # -- reporting -----------------------------------------------------------
    def total_cost_gbp(self) -> float:
        return sum(e.cost_gbp for e in self.ledger)

    def total_by_source(self) -> dict[str, dict]:
        out: dict[str, dict] = {}
        for e in self.ledger:
            b = out.setdefault(e.energy_source, {"amount": 0.0, "cost_gbp": 0.0, "distance_km": 0.0})
            b["amount"] += e.amount
            b["cost_gbp"] += e.cost_gbp
            b["distance_km"] += e.distance_km
        return out

    def total_kwh_equivalent(self) -> float:
        """Rough common unit for dashboards: electric kWh + diesel litres*9.7 + H2 kg*33.3."""
        total = 0.0
        for e in self.ledger:
            if e.energy_source == "electric":
                total += e.amount
            elif e.energy_source == "diesel":
                total += e.amount * 9.7
            elif e.energy_source == "hydrogen":
                total += e.amount * 33.3
        return total
