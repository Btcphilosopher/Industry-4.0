"""
vehicles/barge.py

Autonomous barge digital twin + BargeSimulator (req. #8). Handles waterway
travel, lock transits, and draft/channel constraints.
"""
from __future__ import annotations

import random
from dataclasses import dataclass

import simpy

from freight_os.containers.container import ContainerStatus
from freight_os.core.configuration import BargeType, EnergySource
from freight_os.core.events import EventLog, EventType
from freight_os.network.graph import EdgeMode, FreightNetwork
from freight_os.network.waterways import WaterwayModel
from freight_os.vehicles.base import AutonomousVehicle, OperatingState


@dataclass
class Barge(AutonomousVehicle):
    barge_type: BargeType = BargeType.CONTAINER_BARGE
    energy_source: EnergySource = EnergySource.DIESEL
    cargo_capacity_teu: int = 96
    draft_m: float = 2.5
    length_m: float = 85.0
    beam_m: float = 11.4
    max_speed_kmh: float = 18.0
    fuel_tank_litres: float = 12_000.0
    battery_capacity_kwh: float = 0.0
    consumption_per_km: float = 0.0
    # Deliberately short: crane/yard handling time (terminal.py) already accounts
    # for the actual container transfer — this is just final lashing/paperwork.
    unloading_time_h: float = 0.3

    def __post_init__(self) -> None:
        self.vehicle_class = "barge"
        self.payload_capacity = self.cargo_capacity_teu


class BargeSimulator:
    def __init__(
        self,
        env: simpy.Environment,
        network: FreightNetwork,
        waterway_model: WaterwayModel,
        event_log: EventLog,
        rng: random.Random,
        loading_time_h: float = 0.3,
        failure_prob_per_trip: float = 0.01,
        repair_time_h: float = 4.0,
    ):
        self.env = env
        self.network = network
        self.waterway_model = waterway_model
        self.event_log = event_log
        self.rng = rng
        self.loading_time_h = loading_time_h
        self.failure_prob_per_trip = failure_prob_per_trip
        self.repair_time_h = repair_time_h

    def travel_leg(self, barge: Barge, u: str, v: str, energy_engine, mode: EdgeMode = EdgeMode.RIVER):
        if not self.waterway_model.vessel_fits(u, v, barge.draft_m):
            self.event_log.log(self.env.now, EventType.ROUTE_BLOCKED, barge.vehicle_id, reason="draft_restriction", edge=f"{u}->{v}")
            return

        barge.operating_state = OperatingState.EN_ROUTE
        edge = self.network.graph[u][v][mode.value]
        distance_km = edge["distance_km"]
        speed = min(barge.max_speed_kmh, barge.max_speed_kmh * (1 - 0.4 * edge["congestion"]))
        travel_time_h = distance_km / max(1.0, speed)

        self.event_log.log(self.env.now, EventType.VEHICLE_DEPARTED, barge.vehicle_id, from_node=u, to_node=v, mode=mode.value)
        yield self.env.timeout(travel_time_h)

        lock = self.waterway_model.lock_for(u, v)
        if lock is not None:
            with lock.resource.request() as req:
                yield req
                yield self.env.timeout(lock.cycle_time_h)

        energy_engine.consume_barge(barge, distance_km)
        barge.position = v
        barge.odometer_km += distance_km
        barge.operating_hours += travel_time_h
        barge.trip_count += 1
        self.event_log.log(self.env.now, EventType.BARGE_ARRIVED, barge.vehicle_id, node=v, distance_km=distance_km)

    def maybe_fail(self, barge: Barge) -> bool:
        if self.rng.random() < self.failure_prob_per_trip:
            barge.operating_state = OperatingState.FAULT
            barge.fault_history.append({"time": self.env.now, "type": "propulsion_fault"})
            self.event_log.log(self.env.now, EventType.VEHICLE_FAULT, barge.vehicle_id, node=barge.position)
            return True
        return False

    def repair(self, barge: Barge):
        self.event_log.log(self.env.now, EventType.MAINTENANCE_STARTED, barge.vehicle_id)
        barge.operating_state = OperatingState.MAINTENANCE
        yield self.env.timeout(self.repair_time_h)
        barge.operating_state = OperatingState.IDLE
        self.event_log.log(self.env.now, EventType.MAINTENANCE_COMPLETED, barge.vehicle_id)

    def load(self, barge: Barge, containers: list):
        barge.operating_state = OperatingState.LOADING
        yield self.env.timeout(self.loading_time_h)
        for c in containers:
            barge.payload.append(c)
            c.transition(self.env.now, ContainerStatus.LOADED, location=barge.position, vehicle_id=barge.vehicle_id, mode="river")
            self.event_log.log(self.env.now, EventType.CONTAINER_LOADED, c.container_id, vehicle_id=barge.vehicle_id)

    def unload(self, barge: Barge, containers: list):
        barge.operating_state = OperatingState.UNLOADING
        yield self.env.timeout(barge.unloading_time_h)
        for c in containers:
            if c in barge.payload:
                barge.payload.remove(c)
            self.event_log.log(self.env.now, EventType.CONTAINER_UNLOADED, c.container_id, vehicle_id=barge.vehicle_id, node=barge.position)
