"""
vehicles/fleet.py

FleetManager (req. #13): tracks every vehicle's availability, location,
payload, energy and utilisation, and assigns idle vehicles to jobs.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from freight_os.vehicles.barge import Barge
from freight_os.vehicles.base import AutonomousVehicle, OperatingState
from freight_os.vehicles.truck import Truck


@dataclass
class FleetManager:
    trucks: dict[str, Truck] = field(default_factory=dict)
    barges: dict[str, Barge] = field(default_factory=dict)

    def register_truck(self, truck: Truck) -> None:
        self.trucks[truck.vehicle_id] = truck

    def register_barge(self, barge: Barge) -> None:
        self.barges[barge.vehicle_id] = barge

    def all_vehicles(self) -> list[AutonomousVehicle]:
        return list(self.trucks.values()) + list(self.barges.values())

    # -- assignment ----------------------------------------------------------
    def nearest_available_truck(self, node_id: str) -> Optional[Truck]:
        """A truck must physically be at `node_id` and idle to be dispatchable —
        vehicles never teleport; every leg (including the empty return) is simulated."""
        at_node = [t for t in self.trucks.values() if t.is_available() and t.position == node_id]
        return at_node[0] if at_node else None

    def nearest_available_barge(self, node_id: str) -> Optional[Barge]:
        at_node = [b for b in self.barges.values() if b.is_available() and b.position == node_id]
        return at_node[0] if at_node else None

    # -- utilisation reporting (feeds optimisation/fleet.py) -----------------
    def utilisation_by_state(self, vehicle_class: Optional[str] = None) -> dict[str, int]:
        vehicles = self.all_vehicles()
        if vehicle_class:
            vehicles = [v for v in vehicles if v.vehicle_class == vehicle_class]
        counts: dict[str, int] = {s.value: 0 for s in OperatingState}
        for v in vehicles:
            counts[v.operating_state.value] += 1
        return counts

    def fleet_utilisation_pct(self, vehicle_class: Optional[str] = None) -> float:
        counts = self.utilisation_by_state(vehicle_class)
        total = sum(counts.values())
        if total == 0:
            return 0.0
        active = total - counts.get(OperatingState.IDLE.value, 0) - counts.get(OperatingState.FAULT.value, 0)
        return 100.0 * active / total

    def underutilised_vehicles(self, min_trip_count: int = 1) -> list[str]:
        return [v.vehicle_id for v in self.all_vehicles() if v.trip_count < min_trip_count]

    def total_empty_km(self) -> float:
        """Requires callers (dispatcher) to tag empty legs; summed from vehicle metadata."""
        return sum(getattr(v, "empty_km", 0.0) for v in self.all_vehicles())
