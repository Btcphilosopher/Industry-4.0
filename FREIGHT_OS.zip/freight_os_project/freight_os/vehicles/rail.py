"""
vehicles/rail.py

Abstract rail layer for intermodal freight (req. #9). Rail is modelled at
a coarser granularity than road/waterway — a `Train` makes scheduled
terminal-to-terminal runs rather than link-by-link motion, which matches
the level of detail actually useful for intermodal comparison.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import simpy

from freight_os.core.events import EventLog, EventType
from freight_os.network.graph import EdgeMode, FreightNetwork


@dataclass
class Train:
    train_id: str
    wagon_count: int = 20
    capacity_per_wagon_teu: int = 2
    max_speed_kmh: float = 90.0
    energy_kwh_per_gross_tonne_km: float = 0.03
    position: str = ""
    payload: list = field(default_factory=list)

    @property
    def capacity_teu(self) -> int:
        return self.wagon_count * self.capacity_per_wagon_teu


class RailSimulator:
    """
    Simplified: rail legs are simulated as a single scheduled transfer
    (terminal_transfer_time + line-haul time), reflecting rail's role as a
    scheduled, high-capacity intermodal leg rather than a freely-routed one.
    """

    def __init__(self, env: simpy.Environment, network: FreightNetwork, event_log: EventLog,
                 terminal_transfer_time_h: float = 1.0):
        self.env = env
        self.network = network
        self.event_log = event_log
        self.terminal_transfer_time_h = terminal_transfer_time_h

    def run_leg(self, train: Train, u: str, v: str, energy_engine, containers: list):
        edge = self.network.graph[u][v][EdgeMode.RAIL.value]
        distance_km = edge["distance_km"]
        travel_time_h = distance_km / max(1.0, train.max_speed_kmh)

        # terminal transfer (loading) at origin
        yield self.env.timeout(self.terminal_transfer_time_h)
        train.payload.extend(containers)
        for c in containers:
            self.event_log.log(self.env.now, EventType.CONTAINER_LOADED, c.container_id, vehicle_id=train.train_id)

        self.event_log.log(self.env.now, EventType.VEHICLE_DEPARTED, train.train_id, from_node=u, to_node=v, mode="rail")
        yield self.env.timeout(travel_time_h)

        energy_engine.consume_train(train, distance_km, containers)
        train.position = v
        for c in containers:
            train.payload.remove(c)
            self.event_log.log(self.env.now, EventType.CONTAINER_UNLOADED, c.container_id, vehicle_id=train.train_id, node=v)

        # terminal transfer (unloading) at destination
        yield self.env.timeout(self.terminal_transfer_time_h)
        self.event_log.log(self.env.now, EventType.VEHICLE_ARRIVED, train.train_id, node=v, mode="rail", distance_km=distance_km)
