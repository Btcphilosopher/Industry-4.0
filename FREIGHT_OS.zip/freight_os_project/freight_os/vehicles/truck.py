"""
vehicles/truck.py

Autonomous truck digital twin + TruckSimulator (req. #7). Motion is a
high-level abstraction — Perception -> Planning -> Decision -> Simulated
Motion — not a real driving controller (req. #7, #44).
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Optional

import simpy

from freight_os.containers.container import ContainerStatus
from freight_os.core.configuration import EnergySource, TruckType
from freight_os.core.events import EventLog, EventType
from freight_os.network.graph import EdgeMode, FreightNetwork
from freight_os.network.roads import TrafficModel
from freight_os.vehicles.base import AutonomousVehicle, OperatingState


@dataclass
class Truck(AutonomousVehicle):
    truck_type: TruckType = TruckType.TRACTOR_UNIT
    energy_source: EnergySource = EnergySource.DIESEL
    max_payload_kg: float = 26_000.0
    container_capacity: int = 2
    mass_kg: float = 18_000.0
    max_speed_kmh: float = 88.0
    acceleration_ms2: float = 0.9
    braking_ms2: float = 1.8

    battery_capacity_kwh: float = 0.0     # electric only
    fuel_tank_litres: float = 0.0          # diesel only
    hydrogen_tank_kg: float = 0.0          # hydrogen only
    range_km: float = 400.0
    consumption_per_km: float = 0.0        # kWh/km, litres/km or kg H2/km depending on source

    def __post_init__(self) -> None:
        self.vehicle_class = "truck"
        self.payload_capacity = self.container_capacity


class TruckSimulator:
    """Owns the physical simulation of truck movement between two network nodes."""

    def __init__(
        self,
        env: simpy.Environment,
        network: FreightNetwork,
        traffic_model: TrafficModel,
        event_log: EventLog,
        rng: random.Random,
        loading_time_h: float = 0.4,
        failure_prob_per_trip: float = 0.02,
        repair_time_h: float = 2.0,
    ):
        self.env = env
        self.network = network
        self.traffic_model = traffic_model
        self.event_log = event_log
        self.rng = rng
        self.loading_time_h = loading_time_h
        self.failure_prob_per_trip = failure_prob_per_trip
        self.repair_time_h = repair_time_h

    # ------------------------------------------------------------------
    def travel_leg(self, truck: Truck, u: str, v: str, energy_engine):
        """SimPy process: drive `truck` from node u to v along a road edge."""
        truck.operating_state = OperatingState.EN_ROUTE
        self.traffic_model.enter_edge(u, v, EdgeMode.ROAD)
        edge = self.network.graph[u][v][EdgeMode.ROAD.value]
        distance_km = edge["distance_km"]

        effective_speed = min(truck.max_speed_kmh, self.traffic_model.average_speed_kmh(u, v, EdgeMode.ROAD, truck.max_speed_kmh))
        travel_time_h = distance_km / max(1.0, effective_speed)

        self.event_log.log(self.env.now, EventType.VEHICLE_DEPARTED, truck.vehicle_id, from_node=u, to_node=v, mode="road")
        try:
            yield self.env.timeout(travel_time_h)
        finally:
            self.traffic_model.exit_edge(u, v, EdgeMode.ROAD)

        energy_engine.consume_truck(truck, distance_km)
        truck.position = v
        truck.odometer_km += distance_km
        truck.operating_hours += travel_time_h
        truck.trip_count += 1
        self.event_log.log(self.env.now, EventType.VEHICLE_ARRIVED, truck.vehicle_id, node=v, mode="road", distance_km=distance_km)

    def maybe_fail(self, truck: Truck):
        """Random failure roll after a completed leg (req. #23). Returns True if a fault occurred."""
        if self.rng.random() < self.failure_prob_per_trip:
            truck.operating_state = OperatingState.FAULT
            truck.fault_history.append({"time": self.env.now, "type": "mechanical_fault"})
            self.event_log.log(self.env.now, EventType.VEHICLE_FAULT, truck.vehicle_id, node=truck.position)
            return True
        return False

    def repair(self, truck: Truck):
        self.event_log.log(self.env.now, EventType.MAINTENANCE_STARTED, truck.vehicle_id)
        truck.operating_state = OperatingState.MAINTENANCE
        yield self.env.timeout(self.repair_time_h)
        truck.operating_state = OperatingState.IDLE
        self.event_log.log(self.env.now, EventType.MAINTENANCE_COMPLETED, truck.vehicle_id)

    def load(self, truck: Truck, containers: list):
        truck.operating_state = OperatingState.LOADING
        yield self.env.timeout(self.loading_time_h)
        for c in containers:
            truck.payload.append(c)
            c.transition(self.env.now, ContainerStatus.LOADED, location=truck.position, vehicle_id=truck.vehicle_id, mode="road")
            self.event_log.log(self.env.now, EventType.CONTAINER_LOADED, c.container_id, vehicle_id=truck.vehicle_id)

    def unload(self, truck: Truck, containers: list):
        truck.operating_state = OperatingState.UNLOADING
        yield self.env.timeout(self.loading_time_h)
        for c in containers:
            if c in truck.payload:
                truck.payload.remove(c)
            self.event_log.log(self.env.now, EventType.CONTAINER_UNLOADED, c.container_id, vehicle_id=truck.vehicle_id, node=truck.position)
