"""
vehicles/base.py

Generic AutonomousVehicle digital twin (req. #6) shared by trucks and
barges. Autonomy is a SIMULATED abstraction only:

    Perception State -> Planning State -> Vehicle Decision -> Simulated Motion

No module in this file (or anywhere in FREIGHT.OS) issues a real steering,
throttle, braking, marine-propulsion or crane command (req. #44).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


class OperatingState(str, Enum):
    IDLE = "IDLE"
    LOADING = "LOADING"
    WAITING = "WAITING"
    EN_ROUTE = "EN_ROUTE"
    DOCKING = "DOCKING"
    UNLOADING = "UNLOADING"
    CHARGING = "CHARGING"
    MAINTENANCE = "MAINTENANCE"
    FAULT = "FAULT"


@dataclass
class AutonomousVehicle:
    vehicle_id: str
    vehicle_class: str  # "truck" | "barge" | "rail"
    position: str = ""  # current node id in the FreightNetwork
    velocity_kmh: float = 0.0
    acceleration_kmh2: float = 0.0
    heading_deg: float = 0.0

    payload: list[Any] = field(default_factory=list)  # list[Container]
    payload_capacity: int = 1

    energy_state: dict = field(default_factory=dict)  # populated by energy/*.py
    route: list[str] = field(default_factory=list)
    destination: Optional[str] = None
    operating_state: OperatingState = OperatingState.IDLE

    # digital-twin / maintenance counters
    odometer_km: float = 0.0
    empty_km: float = 0.0
    operating_hours: float = 0.0
    trip_count: int = 0
    fault_history: list[dict] = field(default_factory=list)

    def payload_free_slots(self) -> int:
        return self.payload_capacity - len(self.payload)

    def is_available(self) -> bool:
        return self.operating_state == OperatingState.IDLE

    # -- the simulated autonomy loop (never touches real actuators) --------
    def perceive(self, network, energy_engine) -> dict:
        """Perception State: what the vehicle 'sees' about its local environment."""
        return {
            "position": self.position,
            "energy_state": dict(self.energy_state),
            "operating_state": self.operating_state,
        }

    def plan(self, perception: dict, target_route: list[str]) -> dict:
        """Planning State: candidate next hop + rationale, purely simulated."""
        next_hop = target_route[1] if len(target_route) > 1 else None
        return {"next_hop": next_hop, "remaining_route": target_route}

    def decide(self, plan: dict) -> str:
        """Vehicle Decision: PROCEED / WAIT / CHARGE / DOCK, simulated only."""
        if plan.get("next_hop") is None:
            return "DOCK"
        if self.energy_state.get("low_energy", False):
            return "CHARGE"
        return "PROCEED"
