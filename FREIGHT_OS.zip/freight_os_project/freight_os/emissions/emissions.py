"""
emissions/emissions.py

EmissionsModel (req. #28): configurable CO2/NOx/PM estimates. Critically,
for zero-tailpipe vehicles (electric, hydrogen) this distinguishes
tailpipe emissions (always zero) from upstream energy emissions (grid
carbon intensity for electricity; production-pathway-dependent for
hydrogen) — electricity and hydrogen are never assumed carbon-free.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from freight_os.core.configuration import SimulationConfig
from freight_os.energy.engine import EnergyEngine, EnergyLedgerEntry


@dataclass
class EmissionsResult:
    tailpipe_co2_kg: float
    upstream_co2_kg: float
    nox_g: float
    pm_g: float

    @property
    def total_co2_kg(self) -> float:
        return self.tailpipe_co2_kg + self.upstream_co2_kg


@dataclass
class EmissionsModel:
    config: SimulationConfig
    energy_engine: EnergyEngine

    def _entry_emissions(self, e: EnergyLedgerEntry) -> EmissionsResult:
        if e.energy_source == "diesel":
            return EmissionsResult(
                tailpipe_co2_kg=e.amount * self.config.diesel_co2_kg_per_litre,
                upstream_co2_kg=0.0,  # upstream fuel-production emissions omitted from this simplified model
                nox_g=e.amount * self.config.diesel_nox_g_per_litre,
                pm_g=e.amount * self.config.diesel_pm_g_per_litre,
            )
        if e.energy_source == "electric":
            return EmissionsResult(
                tailpipe_co2_kg=0.0,
                upstream_co2_kg=e.amount * self.config.grid_carbon_intensity_kg_co2_per_kwh,
                nox_g=0.0,
                pm_g=0.0,
            )
        if e.energy_source == "hydrogen":
            factor = self.config.hydrogen_upstream_co2_kg_per_kg[self.config.hydrogen_pathway]
            return EmissionsResult(
                tailpipe_co2_kg=0.0,
                upstream_co2_kg=e.amount * factor,
                nox_g=0.0,
                pm_g=0.0,
            )
        # hybrid — amount tracked is the electric portion in the ledger; treat as electric-weighted
        return EmissionsResult(
            tailpipe_co2_kg=0.0,
            upstream_co2_kg=e.amount * self.config.grid_carbon_intensity_kg_co2_per_kwh,
            nox_g=0.0,
            pm_g=0.0,
        )

    def total(self) -> EmissionsResult:
        totals = EmissionsResult(0.0, 0.0, 0.0, 0.0)
        for e in self.energy_engine.ledger:
            r = self._entry_emissions(e)
            totals.tailpipe_co2_kg += r.tailpipe_co2_kg
            totals.upstream_co2_kg += r.upstream_co2_kg
            totals.nox_g += r.nox_g
            totals.pm_g += r.pm_g
        return totals

    def by_source(self) -> dict[str, EmissionsResult]:
        out: dict[str, EmissionsResult] = {}
        for e in self.energy_engine.ledger:
            r = self._entry_emissions(e)
            acc = out.setdefault(e.energy_source, EmissionsResult(0.0, 0.0, 0.0, 0.0))
            acc.tailpipe_co2_kg += r.tailpipe_co2_kg
            acc.upstream_co2_kg += r.upstream_co2_kg
            acc.nox_g += r.nox_g
            acc.pm_g += r.pm_g
        return out

    def co2_per_container_kg(self, num_containers: int) -> float:
        return self.total().total_co2_kg / max(1, num_containers)
