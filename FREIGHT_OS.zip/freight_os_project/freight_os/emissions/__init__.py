from freight_os.emissions.emissions import EmissionsModel

__all__ = ["EmissionsModel"]
