from freight_os.analytics.reports import ReportGenerator

__all__ = ["ReportGenerator"]
