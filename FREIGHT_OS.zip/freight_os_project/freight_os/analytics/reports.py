"""
analytics/reports.py

ReportGenerator (req. #39): professional reports covering network
performance, throughput, fleet, port, energy, cost, emissions,
bottlenecks and failures — exportable as CSV, JSON, Parquet and a
print-ready HTML report.
"""
from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path

import pandas as pd

from freight_os.core.simulation import FreightSimulation
from freight_os.optimisation.network import BottleneckAnalyzer


class ReportGenerator:
    def __init__(self, simulation: FreightSimulation):
        self.sim = simulation

    # -- data assembly -------------------------------------------------------
    def full_report_dict(self) -> dict:
        summary = self.sim.summary()
        bottlenecks = BottleneckAnalyzer(self.sim).analyse()
        maintenance = self.sim.maintenance_engine.fleet_risk_report()
        return {
            "scenario_record": self.sim.config.record(),
            "summary": summary,
            "bottlenecks": [asdict(b) for b in bottlenecks],
            "maintenance_risk": [asdict(m) for m in maintenance[:10]],
            "events_count": len(self.sim.event_log),
        }

    def containers_dataframe(self) -> pd.DataFrame:
        return pd.DataFrame([c.as_dict() for c in self.sim.containers])

    def vehicles_dataframe(self) -> pd.DataFrame:
        rows = []
        for v in self.sim.fleet_manager.all_vehicles():
            rows.append({
                "vehicle_id": v.vehicle_id,
                "vehicle_class": v.vehicle_class,
                "state": v.operating_state.value,
                "odometer_km": v.odometer_km,
                "empty_km": v.empty_km,
                "operating_hours": v.operating_hours,
                "trip_count": v.trip_count,
                "faults": len(v.fault_history),
            })
        return pd.DataFrame(rows)

    def events_dataframe(self) -> pd.DataFrame:
        return self.sim.event_log.to_dataframe()

    # -- export ----------------------------------------------------------
    def export_all(self, output_dir: str) -> dict[str, str]:
        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)
        paths = {}

        report = self.full_report_dict()
        json_path = out / "report.json"
        json_path.write_text(json.dumps(report, indent=2, default=str))
        paths["json"] = str(json_path)

        containers_df = self.containers_dataframe()
        vehicles_df = self.vehicles_dataframe()
        events_df = self.events_dataframe()

        containers_df.to_csv(out / "containers.csv", index=False)
        vehicles_df.to_csv(out / "vehicles.csv", index=False)
        events_df.to_csv(out / "events.csv", index=False)
        paths["containers_csv"] = str(out / "containers.csv")
        paths["vehicles_csv"] = str(out / "vehicles.csv")
        paths["events_csv"] = str(out / "events.csv")

        try:
            containers_df.to_parquet(out / "containers.parquet", index=False)
            vehicles_df.to_parquet(out / "vehicles.parquet", index=False)
            paths["containers_parquet"] = str(out / "containers.parquet")
            paths["vehicles_parquet"] = str(out / "vehicles.parquet")
        except (ImportError, ValueError):
            pass  # parquet engine (pyarrow/fastparquet) not installed — CSV/JSON still cover the data

        html_path = out / "report.html"
        html_path.write_text(self._render_html_report(report))
        paths["html"] = str(html_path)

        return paths

    def _render_html_report(self, report: dict) -> str:
        s = report["summary"]
        rows = "".join(f"<tr><td>{k}</td><td>{v}</td></tr>" for k, v in s.items()
                        if isinstance(v, (int, float, str)))
        bottleneck_rows = "".join(
            f"<tr><td>{b['area']}</td><td>{b['metric']}</td><td>{b['value']:.2f}</td><td>{b['recommendation']}</td></tr>"
            for b in report["bottlenecks"]
        ) or "<tr><td colspan='4'>No bottlenecks exceeded threshold in this run.</td></tr>"

        return f"""<!doctype html>
<html><head><meta charset="utf-8"><title>FREIGHT.OS Report — {report['scenario_record']['config']['scenario_name']}</title>
<style>
body {{ font-family: Arial, sans-serif; margin: 32px; color: #111; }}
table {{ border-collapse: collapse; width: 100%; margin-bottom: 32px; }}
td, th {{ border: 1px solid #ccc; padding: 6px 10px; text-align: left; font-size: 13px; }}
th {{ background: #f0f0f0; }}
h1, h2 {{ color: #1a2b4c; }}
</style></head>
<body>
<h1>FREIGHT.OS — Simulation Report</h1>
<p>Seed: {report['scenario_record']['seed']} — Software version: {report['scenario_record']['software_version']}</p>
<h2>Network Performance Summary</h2>
<table><tr><th>Metric</th><th>Value</th></tr>{rows}</table>
<h2>Bottleneck Analysis &amp; Recommendations</h2>
<table><tr><th>Area</th><th>Metric</th><th>Value</th><th>Recommendation</th></tr>{bottleneck_rows}</table>
</body></html>"""
