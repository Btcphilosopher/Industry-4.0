from freight_os.dashboard.dashboard import build_dashboard

__all__ = ["build_dashboard"]
