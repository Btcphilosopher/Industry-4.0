"""
dashboard/dashboard.py

Interactive digital-twin dashboard (req. #33-#36): network map, fleet
status, port KPIs and container tracking, rendered as one self-contained
HTML file (Plotly, JS embedded inline so it works fully offline).
"""
from __future__ import annotations

import plotly.graph_objects as go
from plotly.subplots import make_subplots

from freight_os.core.simulation import FreightSimulation
from freight_os.vehicles.base import OperatingState

NODE_ICON = {"factory": "🏭", "terminal": "🏗️", "warehouse": "🏬"}


def _network_figure(sim: FreightSimulation) -> go.Figure:
    fig = go.Figure()
    positions = {n: sim.network.node_position(n) for n in sim.network.graph.nodes}

    for u, v, data in sim.network.graph.edges(data=True):
        x0, y0 = positions[u]
        x1, y1 = positions[v]
        colour = "#d62728" if data.get("blocked") else "#1f77b4"
        fig.add_trace(go.Scatter(
            x=[x0, x1], y=[y0, y1], mode="lines",
            line=dict(width=2 + 6 * data.get("congestion", 0.0), color=colour),
            hoverinfo="text",
            text=f"{u} -> {v} ({data['mode'].value if hasattr(data['mode'],'value') else data['mode']}): "
                 f"{data['distance_km']:.0f} km, congestion {data.get('congestion',0)*100:.0f}%",
            showlegend=False,
        ))

    node_x = [positions[n][0] for n in positions]
    node_y = [positions[n][1] for n in positions]
    node_text = [f"{n}<br>{sim.network.graph.nodes[n]['node_type'].value}" for n in positions]
    fig.add_trace(go.Scatter(
        x=node_x, y=node_y, mode="markers+text", text=list(positions.keys()),
        textposition="top center", hovertext=node_text, hoverinfo="text",
        marker=dict(size=22, color="#2ca02c"), showlegend=False,
    ))

    # vehicles as an overlay, jittered near their current node
    vx, vy, vtext, vcolor = [], [], [], []
    colour_by_state = {
        OperatingState.EN_ROUTE.value: "#ff7f0e", OperatingState.IDLE.value: "#7f7f7f",
        OperatingState.LOADING.value: "#9467bd", OperatingState.UNLOADING.value: "#8c564b",
        OperatingState.CHARGING.value: "#17becf", OperatingState.MAINTENANCE.value: "#bcbd22",
        OperatingState.FAULT.value: "#d62728", OperatingState.WAITING.value: "#e377c2",
        OperatingState.DOCKING.value: "#1f77b4",
    }
    for v in sim.fleet_manager.all_vehicles():
        if v.position not in positions:
            continue
        x, y = positions[v.position]
        vx.append(x + (hash(v.vehicle_id) % 7 - 3))
        vy.append(y + (hash(v.vehicle_id[::-1]) % 7 - 3))
        state = v.operating_state.value if hasattr(v.operating_state, "value") else v.operating_state
        vtext.append(f"{v.vehicle_id} ({v.vehicle_class}) — {state}")
        vcolor.append(colour_by_state.get(state, "#000000"))
    fig.add_trace(go.Scatter(
        x=vx, y=vy, mode="markers", marker=dict(size=9, color=vcolor, symbol="triangle-up"),
        hovertext=vtext, hoverinfo="text", showlegend=False,
    ))

    fig.update_layout(title="Live Network — Trucks / Barges / Terminals / Warehouse",
                       xaxis=dict(visible=False), yaxis=dict(visible=False), height=500)
    return fig


def _fleet_figure(sim: FreightSimulation) -> go.Figure:
    truck_states = sim.fleet_manager.utilisation_by_state("truck")
    barge_states = sim.fleet_manager.utilisation_by_state("barge")
    fig = go.Figure()
    fig.add_trace(go.Bar(name="Trucks", x=list(truck_states.keys()), y=list(truck_states.values())))
    fig.add_trace(go.Bar(name="Barges", x=list(barge_states.keys()), y=list(barge_states.values())))
    fig.update_layout(barmode="group", title="Fleet Status Breakdown", height=350)
    return fig


def _port_figure(sim: FreightSimulation) -> go.Figure:
    terminals = list(sim.terminals.values())
    fig = go.Figure()
    fig.add_trace(go.Bar(name="Crane utilisation", x=[t.terminal_id for t in terminals],
                          y=[t.crane_utilisation(sim.config.sim_duration_hours) for t in terminals]))
    fig.add_trace(go.Bar(name="Yard utilisation", x=[t.terminal_id for t in terminals],
                          y=[t.yard.utilisation() for t in terminals]))
    fig.add_trace(go.Bar(name="Gate utilisation", x=[t.terminal_id for t in terminals],
                          y=[t.gate_utilisation() for t in terminals]))
    fig.update_layout(barmode="group", title="Port / Terminal Utilisation", yaxis_tickformat=".0%", height=350)
    return fig


def _energy_cost_figure(sim: FreightSimulation) -> go.Figure:
    fig = make_subplots(rows=1, cols=2, specs=[[{"type": "pie"}, {"type": "pie"}]],
                         subplot_titles=("Energy by source", "Cost breakdown"))
    energy = sim.energy_engine.total_by_source()
    fig.add_trace(go.Pie(labels=list(energy.keys()), values=[v["cost_gbp"] for v in energy.values()]), row=1, col=1)
    cost = sim.economic_engine.breakdown(len(sim.containers))
    labels = ["transport_cost_gbp", "energy_cost_gbp", "terminal_cost_gbp", "warehouse_cost_gbp"]
    fig.add_trace(go.Pie(labels=labels, values=[cost[k] for k in labels]), row=1, col=2)
    fig.update_layout(height=350)
    return fig


def build_dashboard(sim: FreightSimulation, output_path: str) -> str:
    """Renders the full digital-twin dashboard to a single self-contained HTML file."""
    summary = sim.summary()

    kpi_html = "".join(
        f'<div class="kpi"><div class="kpi-value">{v}</div><div class="kpi-label">{k}</div></div>'
        for k, v in [
            ("Containers delivered", f"{summary['containers_delivered']} / {summary['containers_total']}"),
            ("Avg delivery time", f"{summary['average_delivery_time_h']:.1f} h"),
            ("Truck utilisation", f"{summary['truck_utilisation_pct']:.0f}%"),
            ("Barge utilisation", f"{summary['barge_utilisation_pct']:.0f}%"),
            ("Total energy", f"{summary['total_energy_kwh_equivalent']:,.0f} kWh-eq"),
            ("Operating cost", f"£{summary['total_operating_cost_gbp']:,.0f}"),
            ("Cost / container", f"£{summary['cost_per_container_gbp']:,.0f}"),
            ("CO2", f"{summary['total_co2_kg']:,.0f} kg"),
            ("Port congestion index", f"{(summary['port_congestion_index'] or 0)*100:.0f}%"),
            ("Vehicle faults", summary["vehicle_faults"]),
        ]
    )

    figs = [_network_figure(sim), _fleet_figure(sim), _port_figure(sim), _energy_cost_figure(sim)]
    figs_html = [f.to_html(full_html=False, include_plotlyjs=(i == 0)) for i, f in enumerate(figs)]

    html = f"""<!doctype html>
<html><head><meta charset="utf-8"><title>FREIGHT.OS Digital Twin Dashboard</title>
<style>
body {{ font-family: -apple-system, Segoe UI, Roboto, sans-serif; margin: 0; padding: 24px; background: #0b1120; color: #e2e8f0; }}
h1 {{ font-weight: 600; }}
.kpis {{ display: flex; flex-wrap: wrap; gap: 12px; margin-bottom: 24px; }}
.kpi {{ background: #111827; border: 1px solid #1f2937; border-radius: 10px; padding: 14px 18px; min-width: 140px; }}
.kpi-value {{ font-size: 22px; font-weight: 700; }}
.kpi-label {{ font-size: 12px; color: #9ca3af; margin-top: 4px; }}
.panel {{ background: #111827; border: 1px solid #1f2937; border-radius: 10px; padding: 8px; margin-bottom: 20px; }}
</style></head>
<body>
<h1>🚛 FREIGHT.OS — Digital Twin Dashboard</h1>
<div class="kpis">{kpi_html}</div>
{''.join(f'<div class="panel">{h}</div>' for h in figs_html)}
</body></html>"""

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)
    return output_path
