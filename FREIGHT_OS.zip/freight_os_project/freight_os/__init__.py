"""
FREIGHT.OS — Autonomous Freight Simulation, Digital Twin & Optimisation Platform.

This is a SIMULATION and DIGITAL-TWIN environment. It does not issue commands
to, or interface directly with, any real vehicle, vessel, crane or piece of
industrial equipment. All "autonomy" here is a simulated Perception -> Planning
-> Decision -> Simulated Action abstraction operating purely on modelled state.
"""

__version__ = "0.1.0"
__all__ = ["__version__"]
