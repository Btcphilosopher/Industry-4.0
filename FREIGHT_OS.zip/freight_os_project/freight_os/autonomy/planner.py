"""
autonomy/planner.py

Planner: the "Planning State" layer — turns a container's origin/destination
into a concrete intermodal route plan using the RouteOptimizer, and writes
that plan onto the container so every downstream component (dispatcher,
tracking, dashboard) shares one source of truth for "what's the plan".
"""
from __future__ import annotations

from freight_os.containers.container import Container
from freight_os.network.routes import RouteOptimizer, RouteOption


class Planner:
    def __init__(self, route_optimizer: RouteOptimizer):
        self.route_optimizer = route_optimizer

    def plan_shipment(self, container: Container, objective: str = "multi", weights: dict | None = None) -> RouteOption | None:
        route = self.route_optimizer.find_route(container.origin, container.destination, objective=objective, weights=weights)
        if route is None:
            return None
        container.planned_route = route.nodes
        container.planned_modes = route.modes
        return route

    def replan(self, container: Container, from_node: str, objective: str = "multi") -> RouteOption | None:
        """Called when a blocked edge or failure forces a mid-journey reroute (req. #23)."""
        route = self.route_optimizer.find_route(from_node, container.destination, objective=objective)
        if route is None:
            return None
        remaining_index = container.planned_route.index(from_node) if from_node in container.planned_route else 0
        container.planned_route = container.planned_route[:remaining_index] + route.nodes
        container.planned_modes = container.planned_modes[:remaining_index] + route.modes
        return route
