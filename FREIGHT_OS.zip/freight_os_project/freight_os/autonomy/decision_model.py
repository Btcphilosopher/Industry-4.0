"""
autonomy/decision_model.py

The simulated autonomy abstraction shared by every vehicle type (req. #7,
#44):

    Perceived Environment -> Planning State -> Vehicle Decision -> Simulated Action

This module only ever returns a *decision label*; nothing here drives a
real actuator, engine, or piece of port/marine equipment.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Optional


class VehicleDecision(str, Enum):
    PROCEED = "PROCEED"
    WAIT = "WAIT"
    REROUTE = "REROUTE"
    DOCK = "DOCK"
    CHARGE = "CHARGE"
    REFUEL = "REFUEL"
    REQUEST_MAINTENANCE = "REQUEST_MAINTENANCE"


@dataclass
class PerceivedEnvironment:
    """What the simulated vehicle 'perceives' about its surroundings this tick."""
    congestion: float = 0.0          # 0-1 on the next edge
    edge_blocked: bool = False
    energy_low: bool = False
    terminal_congested: bool = False
    fault_active: bool = False


@dataclass
class PlanningState:
    next_hop: Optional[str]
    remaining_route: list[str]
    alternative_available: bool = False


def decide(perception: PerceivedEnvironment, plan: PlanningState) -> VehicleDecision:
    """Simple, explainable rule-based decision function (deliberately not a
    black box — every branch below is auditable). This is the hook future
    ML/RL policies (ml/*, optimisation/rl_hooks.py) can be swapped in for."""
    if perception.fault_active:
        return VehicleDecision.REQUEST_MAINTENANCE
    if perception.energy_low:
        return VehicleDecision.CHARGE
    if perception.edge_blocked:
        return VehicleDecision.REROUTE if plan.alternative_available else VehicleDecision.WAIT
    if plan.next_hop is None:
        return VehicleDecision.DOCK
    if perception.terminal_congested and perception.congestion > 0.85:
        return VehicleDecision.WAIT
    return VehicleDecision.PROCEED
