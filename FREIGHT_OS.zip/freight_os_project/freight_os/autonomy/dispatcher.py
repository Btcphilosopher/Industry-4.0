"""
autonomy/dispatcher.py

DispatchEngine (req. #14): given freight orders, current vehicle
availability, network conditions and terminal capacity, produces a vehicle
assignment + route + schedule + ETA for each shipment leg.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from freight_os.containers.container import Container
from freight_os.network.graph import EdgeMode
from freight_os.network.routes import RouteOptimizer
from freight_os.vehicles.fleet import FleetManager


@dataclass
class VehicleAssignment:
    container_ids: list[str]
    vehicle_id: str
    mode: str
    from_node: str
    to_node: str
    scheduled_depart_h: float
    estimated_arrival_h: float


MODE_TO_VEHICLE_CLASS = {
    EdgeMode.ROAD.value: "truck",
    EdgeMode.RIVER.value: "barge",
    EdgeMode.CANAL.value: "barge",
    EdgeMode.SEA.value: "barge",
}


@dataclass
class DispatchEngine:
    fleet_manager: FleetManager
    route_optimizer: RouteOptimizer

    def pick_vehicle(self, from_node: str, mode: str):
        vclass = MODE_TO_VEHICLE_CLASS.get(mode, "truck")
        if vclass == "truck":
            return self.fleet_manager.nearest_available_truck(from_node)
        return self.fleet_manager.nearest_available_barge(from_node)

    def build_assignment(self, containers: list[Container], from_node: str, to_node: str, mode: str, now_h: float) -> Optional[VehicleAssignment]:
        vehicle = self.pick_vehicle(from_node, mode)
        if vehicle is None:
            return None
        edge = self.route_optimizer.network.graph[from_node][to_node][mode]
        distance_km = edge["distance_km"]
        travel_time_h = self.route_optimizer.network.travel_time_h(from_node, to_node, EdgeMode(mode))
        return VehicleAssignment(
            container_ids=[c.container_id for c in containers],
            vehicle_id=vehicle.vehicle_id,
            mode=mode,
            from_node=from_node,
            to_node=to_node,
            scheduled_depart_h=now_h,
            estimated_arrival_h=now_h + travel_time_h,
        )

    def batch_by_capacity(self, containers: list[Container], vehicle) -> list[Container]:
        """Fill a vehicle up to its free payload slots, prioritising higher-priority (lower number) containers first."""
        free = vehicle.payload_free_slots()
        ordered = sorted(containers, key=lambda c: c.priority)
        return ordered[:free]

    def estimate_eta(self, container: Container, objective: str = "multi") -> Optional[float]:
        route = self.route_optimizer.find_route(container.current_location, container.destination, objective=objective)
        return route.total_time_h if route else None
