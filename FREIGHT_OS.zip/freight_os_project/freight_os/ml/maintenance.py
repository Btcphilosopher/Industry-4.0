"""
ml/maintenance.py

MLFailurePredictor: implements the same `FailurePredictor` protocol as
maintenance.predictive.StatisticalWeibullPredictor, so it can be swapped
into `MaintenanceEngine(predictor=...)` with zero changes elsewhere.
Uses scikit-learn's GradientBoosting/RandomForest when available and fit;
otherwise defers to the statistical model (never silently returns nonsense).
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from freight_os.maintenance.predictive import (
    MaintenancePrediction,
    StatisticalWeibullPredictor,
    VehicleWearRecord,
)

try:
    from sklearn.ensemble import RandomForestClassifier
    _HAS_SKLEARN = True
except ImportError:
    _HAS_SKLEARN = False


@dataclass
class MLFailurePredictor:
    fallback: StatisticalWeibullPredictor = field(default_factory=StatisticalWeibullPredictor)
    _model: object = None
    trained: bool = False

    def fit(self, records: list[VehicleWearRecord], failed_within_100h: list[bool]) -> None:
        if not _HAS_SKLEARN or len(records) < 10:
            return  # not enough data / no sklearn -> keep using the statistical fallback
        X = np.array([[r.mileage_km, r.operating_hours, r.energy_cycles, r.fault_count] for r in records])
        y = np.array(failed_within_100h, dtype=int)
        if len(set(y.tolist())) < 2:
            return  # can't train a classifier on a single class
        self._model = RandomForestClassifier(n_estimators=100, random_state=42).fit(X, y)
        self.trained = True

    def predict(self, record: VehicleWearRecord) -> MaintenancePrediction:
        if not self.trained or self._model is None:
            return self.fallback.predict(record)
        X = np.array([[record.mileage_km, record.operating_hours, record.energy_cycles, record.fault_count]])
        prob = float(self._model.predict_proba(X)[0][1])
        stat = self.fallback.predict(record)  # RUL still comes from the wear-based estimator
        return MaintenancePrediction(
            vehicle_id=record.vehicle_id,
            maintenance_probability_next_100h=prob,
            remaining_useful_life_hours=stat.remaining_useful_life_hours,
            wear_index=stat.wear_index,
        )
