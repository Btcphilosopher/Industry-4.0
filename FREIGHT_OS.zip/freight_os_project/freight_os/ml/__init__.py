"""
freight_os.ml — optional ML layer (req. #31).

Every model here degrades gracefully to a plain statistical/heuristic
fallback if scikit-learn is not installed, so the core simulation engine
never depends on ML libraries being present.
"""
from freight_os.ml.eta import ETAPredictor
from freight_os.ml.demand import DemandForecaster
from freight_os.ml.maintenance import MLFailurePredictor

__all__ = ["ETAPredictor", "DemandForecaster", "MLFailurePredictor"]
