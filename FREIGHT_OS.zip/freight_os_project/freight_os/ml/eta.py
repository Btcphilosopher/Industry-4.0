"""
ml/eta.py

ETAPredictor: learns actual-vs-planned transit time from completed
container journeys. Uses scikit-learn's LinearRegression when available,
falling back to a NumPy least-squares fit (still a real regression, just
without the sklearn dependency) so the platform works without ML installed.
"""
from __future__ import annotations

import numpy as np

try:
    from sklearn.linear_model import LinearRegression
    _HAS_SKLEARN = True
except ImportError:
    _HAS_SKLEARN = False


class ETAPredictor:
    """Features: [distance_km, num_legs, avg_congestion] -> transit_time_h."""

    def __init__(self):
        self._coef = None
        self._intercept = 0.0
        self._model = LinearRegression() if _HAS_SKLEARN else None
        self.trained = False

    def fit(self, X: list[list[float]], y: list[float]) -> None:
        X_arr, y_arr = np.array(X, dtype=float), np.array(y, dtype=float)
        if len(X_arr) < 2:
            return
        if _HAS_SKLEARN:
            self._model.fit(X_arr, y_arr)
        else:
            X_design = np.hstack([np.ones((len(X_arr), 1)), X_arr])
            coeffs, *_ = np.linalg.lstsq(X_design, y_arr, rcond=None)
            self._intercept, self._coef = coeffs[0], coeffs[1:]
        self.trained = True

    def predict(self, features: list[float]) -> float:
        if not self.trained:
            # heuristic fallback: distance / 50 km/h average network speed
            return features[0] / 50.0 if features else 0.0
        x = np.array(features, dtype=float).reshape(1, -1)
        if _HAS_SKLEARN:
            return float(self._model.predict(x)[0])
        return float(self._intercept + x @ self._coef)

    @staticmethod
    def training_examples_from_containers(containers) -> tuple[list[list[float]], list[float]]:
        X, y = [], []
        for c in containers:
            if c.transit_time_hours is None:
                continue
            num_legs = max(1, len(c.planned_route) - 1)
            X.append([len(c.planned_route) * 50.0, num_legs, 0.3])  # distance proxy, legs, avg congestion proxy
            y.append(c.transit_time_hours)
        return X, y
