"""
ml/demand.py

DemandForecaster: simple time-series forecast of container booking demand.
Falls back to a moving-average / linear-trend heuristic when scikit-learn
isn't available.
"""
from __future__ import annotations

import numpy as np

try:
    from sklearn.linear_model import LinearRegression
    _HAS_SKLEARN = True
except ImportError:
    _HAS_SKLEARN = False


class DemandForecaster:
    def __init__(self, window: int = 7):
        self.window = window

    def forecast_next(self, history: list[float], horizon: int = 1) -> list[float]:
        if len(history) < 2:
            return [history[-1] if history else 0.0] * horizon

        y = np.array(history[-self.window:], dtype=float)
        x = np.arange(len(y)).reshape(-1, 1)

        if _HAS_SKLEARN:
            model = LinearRegression().fit(x, y)
            future_x = np.arange(len(y), len(y) + horizon).reshape(-1, 1)
            preds = model.predict(future_x)
        else:
            coeffs = np.polyfit(x.flatten(), y, 1)
            future_x = np.arange(len(y), len(y) + horizon)
            preds = np.polyval(coeffs, future_x)

        return [max(0.0, float(p)) for p in preds]
