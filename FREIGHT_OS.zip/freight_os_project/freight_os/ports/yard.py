"""
ports/yard.py

Container yard + autonomous yard vehicles (req. #2 yard vehicles, #12
warehouse-adjacent yard operations). Models stacking/slot occupancy and
yard-tractor movement between gate, stack and quay/crane positions.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import simpy

from freight_os.core.events import EventLog, EventType


@dataclass
class YardVehicle:
    vehicle_id: str
    kind: str = "terminal_tractor"  # terminal_tractor | agv | straddle_carrier
    move_time_minutes: float = 4.0
    moves_completed: int = 0
    resource: simpy.Resource = field(default=None, repr=False)


@dataclass
class Yard:
    terminal_id: str
    total_slots: int = 400
    occupied_slots: int = 0
    yard_vehicles: list[YardVehicle] = field(default_factory=list)
    _vehicle_pool: simpy.Resource = field(default=None, repr=False)

    def bind(self, env: simpy.Environment, num_yard_vehicles: int = 4) -> None:
        self._vehicle_pool = simpy.Resource(env, capacity=num_yard_vehicles)
        self.env = env

    def utilisation(self) -> float:
        return self.occupied_slots / max(1, self.total_slots)

    def has_space(self) -> bool:
        return self.occupied_slots < self.total_slots

    def stack(self, env: simpy.Environment, event_log: EventLog, container_id: str):
        """Move a container from crane/gate to a yard stacking slot via a yard vehicle."""
        with self._vehicle_pool.request() as req:
            yield req
            yield env.timeout(4.0 / 60.0)  # yard-tractor move time
            self.occupied_slots = min(self.total_slots, self.occupied_slots + 1)

    def retrieve(self, env: simpy.Environment, event_log: EventLog, container_id: str):
        """Move a container from a yard slot to gate/crane for onward departure."""
        with self._vehicle_pool.request() as req:
            yield req
            yield env.timeout(4.0 / 60.0)
            self.occupied_slots = max(0, self.occupied_slots - 1)
