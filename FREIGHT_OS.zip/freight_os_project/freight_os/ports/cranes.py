"""
ports/cranes.py

Abstract crane model (req. #11). A crane is a SimPy resource with a
lifting capacity, cycle time and energy draw per lift — high-level enough
to never model real crane control, only its throughput effect.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import simpy

from freight_os.core.events import EventLog, EventType
from freight_os.energy.engine import EnergyLedgerEntry


@dataclass
class Crane:
    crane_id: str
    lifting_capacity_tonnes: float = 65.0
    cycle_time_minutes: float = 2.5
    energy_kwh_per_lift: float = 4.5
    position: str = ""
    lifts_completed: int = 0
    busy_hours: float = 0.0
    resource: simpy.Resource = field(default=None, repr=False)

    def bind(self, env: simpy.Environment) -> None:
        self.resource = simpy.Resource(env, capacity=1)

    def lift(self, env: simpy.Environment, event_log: EventLog, container_id: str, energy_engine=None):
        """SimPy process: pick up -> move -> drop off a single container."""
        with self.resource.request() as req:
            yield req
            event_log.log(env.now, EventType.CRANE_BUSY, self.crane_id, container_id=container_id)
            cycle_h = self.cycle_time_minutes / 60.0
            yield env.timeout(cycle_h)
            self.lifts_completed += 1
            self.busy_hours += cycle_h
            if energy_engine is not None:
                energy_engine.ledger.append(
                    EnergyLedgerEntry(
                        vehicle_id=self.crane_id, energy_source="electric",
                        amount=self.energy_kwh_per_lift,
                        cost_gbp=self.energy_kwh_per_lift * energy_engine.config.electricity_price_per_kwh,
                        distance_km=0.0, timestamp=env.now,
                    )
                )
            event_log.log(env.now, EventType.CRANE_AVAILABLE, self.crane_id, container_id=container_id)

    def utilisation(self, sim_duration_h: float) -> float:
        return min(1.0, self.busy_hours / sim_duration_h) if sim_duration_h > 0 else 0.0
