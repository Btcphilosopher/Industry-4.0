"""
ports/terminal.py

TerminalSimulator (req. #10): container terminal with gates, cranes, berths
and a yard. Answers "which vehicle should move which container to which
location next?" via simple greedy allocation (least-busy crane / least-full
yard) — good enough at this scale; optimisation/terminal.py adds an
assignment-problem solver on top for larger terminals.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import simpy

from freight_os.core.events import EventLog, EventType
from freight_os.ports.cranes import Crane
from freight_os.ports.yard import Yard


@dataclass
class TerminalSimulator:
    terminal_id: str
    location_node: str
    num_cranes: int = 3
    num_gates: int = 2
    num_berths: int = 2
    yard_slots: int = 400
    crane_cycle_time_minutes: float = 2.5

    cranes: list[Crane] = field(default_factory=list)
    yard: Yard = field(init=False)
    gate_resource: simpy.Resource = field(default=None, repr=False)
    berth_resource: simpy.Resource = field(default=None, repr=False)

    truck_turnaround_times: list[float] = field(default_factory=list)
    containers_handled: int = 0
    gate_queue_lengths: list[int] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.yard = Yard(terminal_id=self.terminal_id, total_slots=self.yard_slots)

    def bind(self, env: simpy.Environment) -> None:
        self.env = env
        self.gate_resource = simpy.Resource(env, capacity=self.num_gates)
        self.berth_resource = simpy.Resource(env, capacity=self.num_berths)
        self.cranes = [Crane(crane_id=f"{self.terminal_id}-CRN{i+1}", position=self.terminal_id,
                              cycle_time_minutes=self.crane_cycle_time_minutes) for i in range(self.num_cranes)]
        for c in self.cranes:
            c.bind(env)
        self.yard.bind(env, num_yard_vehicles=max(2, self.num_cranes))

    def least_busy_crane(self) -> Crane:
        return min(self.cranes, key=lambda c: len(c.resource.queue) + len(c.resource.users))

    # -- process: a truck/barge arriving to drop off or pick up containers --
    def process_truck(self, event_log: EventLog, container_ids: list[str], direction: str, energy_engine=None):
        """
        direction: "inbound" (truck drops containers into the yard) or
                   "outbound" (truck picks containers up from the yard).
        Models gate -> crane -> yard (or reverse) and records turnaround time.
        """
        arrival = self.env.now
        with self.gate_resource.request() as gate_req:
            self.gate_queue_lengths.append(len(self.gate_resource.queue))
            yield gate_req
            yield self.env.timeout(3.0 / 60.0)  # gate processing time
            event_log.log(self.env.now, EventType.GATE_PROCESSED, self.terminal_id, containers=container_ids)

            for cid in container_ids:
                crane = self.least_busy_crane()
                yield self.env.process(crane.lift(self.env, event_log, cid, energy_engine))
                if direction == "inbound":
                    yield self.env.process(self.yard.stack(self.env, event_log, cid))
                else:
                    yield self.env.process(self.yard.retrieve(self.env, event_log, cid))
                self.containers_handled += 1

        turnaround = self.env.now - arrival
        self.truck_turnaround_times.append(turnaround)

    def load_vehicle_from_yard(self, event_log: EventLog, container_ids: list[str], energy_engine=None):
        """Vessel-side departure: crane containers from the yard onto a barge at berth (no gate step)."""
        with self.berth_resource.request() as berth:
            yield berth
            for cid in container_ids:
                crane = self.least_busy_crane()
                yield self.env.process(crane.lift(self.env, event_log, cid, energy_engine))
                yield self.env.process(self.yard.retrieve(self.env, event_log, cid))
                self.containers_handled += 1

    def unload_vehicle_to_yard(self, event_log: EventLog, container_ids: list[str], energy_engine=None):
        """Vessel-side arrival: crane containers from a barge at berth into the yard (no gate step)."""
        with self.berth_resource.request() as berth:
            yield berth
            for cid in container_ids:
                crane = self.least_busy_crane()
                yield self.env.process(crane.lift(self.env, event_log, cid, energy_engine))
                yield self.env.process(self.yard.stack(self.env, event_log, cid))
                self.containers_handled += 1

    # -- reporting --------------------------------------------------------
    def crane_utilisation(self, sim_duration_h: float) -> float:
        if not self.cranes:
            return 0.0
        return sum(c.utilisation(sim_duration_h) for c in self.cranes) / len(self.cranes)

    def gate_utilisation(self) -> float:
        if not self.gate_queue_lengths:
            return 0.0
        return min(1.0, (sum(self.gate_queue_lengths) / len(self.gate_queue_lengths)) / self.num_gates)

    def berth_utilisation(self, sim_duration_h: float) -> float:
        if self.berth_resource is None:
            return 0.0
        # approximate from count() of users seen isn't tracked directly by SimPy; use queue proxy
        return min(1.0, len(self.berth_resource.users) / max(1, self.num_berths))

    def average_truck_turnaround_h(self) -> float:
        return sum(self.truck_turnaround_times) / len(self.truck_turnaround_times) if self.truck_turnaround_times else 0.0

    def status(self) -> dict:
        return {
            "terminal_id": self.terminal_id,
            "location": self.location_node,
            "yard_utilisation": self.yard.utilisation(),
            "gate_utilisation": self.gate_utilisation(),
            "containers_handled": self.containers_handled,
            "average_truck_turnaround_h": self.average_truck_turnaround_h(),
        }
