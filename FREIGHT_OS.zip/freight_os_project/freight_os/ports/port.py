"""
ports/port.py

PortSimulator (req. #9): a port as a collection of terminals sharing
quays/roads, plus the dynamic PORT CONGESTION INDEX (req. #21).
"""
from __future__ import annotations

from dataclasses import dataclass, field

from freight_os.ports.terminal import TerminalSimulator


@dataclass
class PortSimulator:
    port_id: str
    terminals: dict[str, TerminalSimulator] = field(default_factory=dict)

    def add_terminal(self, terminal: TerminalSimulator) -> None:
        self.terminals[terminal.terminal_id] = terminal

    def congestion_index(self, sim_duration_h: float) -> dict:
        """
        PORT CONGESTION INDEX: weighted average of berth, crane, yard and gate
        utilisation across all terminals in this port, 0 (empty) to 1 (saturated).
        """
        if not self.terminals:
            return {"index": 0.0, "components": {}}

        berth_u, crane_u, yard_u, gate_u = [], [], [], []
        for t in self.terminals.values():
            berth_u.append(t.berth_utilisation(sim_duration_h))
            crane_u.append(t.crane_utilisation(sim_duration_h))
            yard_u.append(t.yard.utilisation())
            gate_u.append(t.gate_utilisation())

        components = {
            "berth_utilisation": sum(berth_u) / len(berth_u),
            "crane_utilisation": sum(crane_u) / len(crane_u),
            "yard_utilisation": sum(yard_u) / len(yard_u),
            "gate_utilisation": sum(gate_u) / len(gate_u),
        }
        weights = {"berth_utilisation": 0.25, "crane_utilisation": 0.3, "yard_utilisation": 0.25, "gate_utilisation": 0.2}
        index = sum(components[k] * weights[k] for k in components)
        return {"index": index, "components": components}

    def status(self) -> dict:
        return {"port_id": self.port_id, "terminals": [t.status() for t in self.terminals.values()]}
