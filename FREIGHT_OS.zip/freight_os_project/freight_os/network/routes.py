"""
network/routes.py

RouteOptimizer (req. #5): finds candidate origin->destination routes over
the FreightNetwork, scores each on time/cost/energy/emissions/reliability,
and explains why a route was selected — never a black box.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from itertools import islice
from typing import Optional

import networkx as nx

from freight_os.network.graph import EdgeMode, FreightNetwork


@dataclass
class RouteLeg:
    u: str
    v: str
    mode: EdgeMode
    distance_km: float
    time_h: float
    energy_kwh_equiv: float
    cost_gbp: float
    risk: float


@dataclass
class RouteOption:
    nodes: list[str]
    legs: list[RouteLeg]
    total_time_h: float
    total_cost_gbp: float
    total_energy_kwh_equiv: float
    reliability: float  # 0-1
    score: float
    explanation: str = ""

    @property
    def modes(self) -> list[str]:
        return [leg.mode.value for leg in self.legs]


DEFAULT_WEIGHTS = {"time": 0.25, "cost": 0.25, "energy": 0.2, "reliability": 0.3}


class RouteOptimizer:
    """
    Objective can be one of "time", "cost", "energy", "reliability", or
    "multi" (weighted combination of all four, weights configurable).
    """

    def __init__(self, network: FreightNetwork, energy_price_lookup=None):
        self.network = network
        # energy_price_lookup(mode) -> £/kWh-equivalent, defaults to a flat rate
        self.energy_price_lookup = energy_price_lookup or (lambda mode: 0.20)

    # ----------------------------------------------------------------
    def _leg_from_edge(self, u: str, v: str, key: str, data: dict) -> RouteLeg:
        mode = data["mode"]
        time_h = self.network.travel_time_h(u, v, mode)
        distance_km = data["distance_km"]
        energy = distance_km * data["energy_cost_kwh_per_tonne_km"] * 20.0  # ~20t reference load
        cost = (
            distance_km * data["toll_per_km"]
            + energy * self.energy_price_lookup(mode)
        )
        risk = data["risk"] * (1 + data["congestion"])
        return RouteLeg(u=u, v=v, mode=mode, distance_km=distance_km, time_h=time_h,
                         energy_kwh_equiv=energy, cost_gbp=cost, risk=min(1.0, risk))

    def _candidate_paths(self, origin: str, destination: str, k: int = 5) -> list[list[str]]:
        g = self._simple_graph_for_pathfinding()
        try:
            gen = nx.shortest_simple_paths(g, origin, destination, weight="distance_km")
            return list(islice(gen, k))
        except (nx.NetworkXNoPath, nx.NodeNotFound):
            return []

    def _simple_graph_for_pathfinding(self) -> nx.DiGraph:
        """
        `shortest_simple_paths` doesn't support MultiDiGraph, so collapse parallel
        (multi-modal) edges between the same two nodes down to their cheapest
        non-blocked option purely for node-sequence enumeration — the real,
        mode-specific edge data is still looked up separately in `_best_edge`.
        """
        simple = nx.DiGraph()
        simple.add_nodes_from(self.network.graph.nodes)
        for u, v, data in self.network.graph.edges(data=True):
            if data.get("blocked", False):
                continue
            existing = simple.get_edge_data(u, v)
            if existing is None or data["distance_km"] < existing["distance_km"]:
                simple.add_edge(u, v, distance_km=data["distance_km"])
        return simple

    def _best_edge(self, u: str, v: str) -> Optional[tuple[str, dict]]:
        """Choose the least-blocked, then shortest, parallel edge (multi-modal) between u and v."""
        if not self.network.graph.has_edge(u, v):
            return None
        candidates = [
            (key, data)
            for key, data in self.network.graph[u][v].items()
            if not data.get("blocked", False)
        ]
        if not candidates:
            return None
        key, data = min(candidates, key=lambda kd: kd[1]["distance_km"])
        return key, data

    def evaluate_path(self, nodes: list[str]) -> Optional[RouteOption]:
        legs = []
        for u, v in zip(nodes, nodes[1:]):
            best = self._best_edge(u, v)
            if best is None:
                return None
            key, data = best
            legs.append(self._leg_from_edge(u, v, key, data))
        total_time = sum(l.time_h for l in legs)
        total_cost = sum(l.cost_gbp for l in legs)
        total_energy = sum(l.energy_kwh_equiv for l in legs)
        reliability = 1.0
        for l in legs:
            reliability *= (1 - l.risk)
        return RouteOption(
            nodes=nodes, legs=legs, total_time_h=total_time, total_cost_gbp=total_cost,
            total_energy_kwh_equiv=total_energy, reliability=reliability, score=0.0,
        )

    def _normalise(self, options: list[RouteOption], attr: str) -> dict[int, float]:
        vals = [getattr(o, attr) for o in options]
        lo, hi = min(vals), max(vals)
        span = (hi - lo) or 1.0
        return {i: (getattr(o, attr) - lo) / span for i, o in enumerate(options)}

    def find_route(
        self, origin: str, destination: str, objective: str = "multi",
        weights: Optional[dict] = None, k_candidates: int = 5,
    ) -> Optional[RouteOption]:
        candidates = [self.evaluate_path(p) for p in self._candidate_paths(origin, destination, k_candidates)]
        options = [c for c in candidates if c is not None]
        if not options:
            return None

        if objective == "time":
            best = min(options, key=lambda o: o.total_time_h)
            best.explanation = (
                f"Selected for minimum travel time ({best.total_time_h:.1f} h) among "
                f"{len(options)} candidate routes."
            )
            best.score = best.total_time_h
            return best
        if objective == "cost":
            best = min(options, key=lambda o: o.total_cost_gbp)
            best.explanation = (
                f"Selected for minimum cost (£{best.total_cost_gbp:.0f}) among "
                f"{len(options)} candidate routes."
            )
            best.score = best.total_cost_gbp
            return best
        if objective == "energy":
            best = min(options, key=lambda o: o.total_energy_kwh_equiv)
            best.explanation = (
                f"Selected for minimum energy ({best.total_energy_kwh_equiv:.0f} kWh-eq) "
                f"among {len(options)} candidate routes."
            )
            best.score = best.total_energy_kwh_equiv
            return best
        if objective == "reliability":
            best = max(options, key=lambda o: o.reliability)
            best.explanation = (
                f"Selected for maximum reliability ({best.reliability*100:.1f}%) among "
                f"{len(options)} candidate routes."
            )
            best.score = 1 - best.reliability
            return best

        # multi-objective weighted sum on normalised metrics
        w = weights or DEFAULT_WEIGHTS
        time_n = self._normalise(options, "total_time_h")
        cost_n = self._normalise(options, "total_cost_gbp")
        energy_n = self._normalise(options, "total_energy_kwh_equiv")
        rel_n = self._normalise(options, "reliability")  # higher is better -> invert below

        best_i, best_score = None, float("inf")
        for i, o in enumerate(options):
            score = (
                w.get("time", 0) * time_n[i]
                + w.get("cost", 0) * cost_n[i]
                + w.get("energy", 0) * energy_n[i]
                + w.get("reliability", 0) * (1 - rel_n[i])
            )
            o.score = score
            if score < best_score:
                best_score, best_i = score, i

        best = options[best_i]
        others = len(options) - 1
        best.explanation = (
            f"Selected via weighted multi-objective scoring "
            f"(time {w.get('time',0):.0%}, cost {w.get('cost',0):.0%}, "
            f"energy {w.get('energy',0):.0%}, reliability {w.get('reliability',0):.0%}): "
            f"£{best.total_cost_gbp:.0f}, {best.total_time_h:.1f} h, "
            f"{best.total_energy_kwh_equiv:.0f} kWh-eq, {best.reliability*100:.1f}% reliability — "
            f"best weighted score ({best.score:.3f}) of {others + 1} candidates evaluated."
        )
        return best

    def compare_routes(self, origin: str, destination: str, weights: Optional[dict] = None) -> list[RouteOption]:
        """Return all candidate routes scored, for side-by-side comparison (req. #5 example)."""
        candidates = [self.evaluate_path(p) for p in self._candidate_paths(origin, destination)]
        options = [c for c in candidates if c is not None]
        if not options:
            return []
        w = weights or DEFAULT_WEIGHTS
        time_n = self._normalise(options, "total_time_h")
        cost_n = self._normalise(options, "total_cost_gbp")
        energy_n = self._normalise(options, "total_energy_kwh_equiv")
        rel_n = self._normalise(options, "reliability")
        for i, o in enumerate(options):
            o.score = (
                w.get("time", 0) * time_n[i]
                + w.get("cost", 0) * cost_n[i]
                + w.get("energy", 0) * energy_n[i]
                + w.get("reliability", 0) * (1 - rel_n[i])
            )
        options.sort(key=lambda o: o.score)
        return options
