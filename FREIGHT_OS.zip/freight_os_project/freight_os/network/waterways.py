"""
network/waterways.py

Waterway constraints (req. #20): draft restrictions, lock capacity/cycle
time, channel capacity, speed limits. Locks are modelled as SimPy
`Resource`s created lazily per waterway edge so barges queue realistically.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import simpy

from freight_os.network.graph import EdgeMode, FreightNetwork


@dataclass
class Lock:
    lock_id: str
    capacity_vessels: int
    cycle_time_h: float
    resource: Optional[simpy.Resource] = None

    def bind(self, env: simpy.Environment) -> None:
        self.resource = simpy.Resource(env, capacity=self.capacity_vessels)


@dataclass
class WaterwayModel:
    network: FreightNetwork
    max_draft_m: dict[tuple[str, str], float] = field(default_factory=dict)
    locks: dict[tuple[str, str], Lock] = field(default_factory=dict)

    def register_lock(self, u: str, v: str, env: simpy.Environment, capacity_vessels: int, cycle_time_h: float) -> None:
        lock = Lock(lock_id=f"LOCK-{u}-{v}", capacity_vessels=capacity_vessels, cycle_time_h=cycle_time_h)
        lock.bind(env)
        self.locks[(u, v)] = lock
        self.locks[(v, u)] = lock

    def set_max_draft(self, u: str, v: str, draft_m: float) -> None:
        self.max_draft_m[(u, v)] = draft_m
        self.max_draft_m[(v, u)] = draft_m

    def vessel_fits(self, u: str, v: str, vessel_draft_m: float) -> bool:
        limit = self.max_draft_m.get((u, v))
        return limit is None or vessel_draft_m <= limit

    def lock_for(self, u: str, v: str) -> Optional[Lock]:
        return self.locks.get((u, v))

    def channel_utilisation(self, mode: EdgeMode = EdgeMode.RIVER) -> float:
        vals = []
        for _, _, k, d in self.network.graph.edges(keys=True, data=True):
            if k == mode.value:
                vals.append(d["current_load"] / max(1, d["capacity"]))
        return sum(vals) / len(vals) if vals else 0.0
