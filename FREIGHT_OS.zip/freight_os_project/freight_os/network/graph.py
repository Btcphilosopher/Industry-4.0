"""
network/graph.py

Graph-based freight network (req. #4). Wraps a `networkx.MultiDiGraph` so
multiple edges (e.g. road AND rail) can connect the same two nodes, each
carrying its own distance/time/capacity/congestion/energy/toll/risk profile.
"""
from __future__ import annotations

from enum import Enum
from typing import Any, Optional

import networkx as nx


class NodeType(str, Enum):
    FACTORY = "factory"
    WAREHOUSE = "warehouse"
    PORT = "port"
    TERMINAL = "terminal"
    DEPOT = "depot"
    RAIL_TERMINAL = "rail_terminal"
    DISTRIBUTION_CENTRE = "distribution_centre"
    CUSTOMER = "customer"


class EdgeMode(str, Enum):
    ROAD = "road"
    RIVER = "river"
    CANAL = "canal"
    RAIL = "rail"
    SEA = "sea"


class FreightNetwork:
    """
    Nodes carry: node_type, position (x, y) for visualisation, capacity metadata.
    Edges carry: mode, distance_km, base_travel_time_h, capacity, congestion (0-1),
                 energy_cost_kwh_per_tonne_km, toll_per_km, risk (0-1).
    """

    def __init__(self) -> None:
        self.graph = nx.MultiDiGraph()

    # -- construction --------------------------------------------------------
    def add_node(self, node_id: str, node_type: NodeType, position: tuple[float, float] = (0.0, 0.0), **attrs: Any) -> None:
        self.graph.add_node(node_id, node_type=node_type, position=position, **attrs)

    def add_edge(
        self,
        u: str,
        v: str,
        mode: EdgeMode,
        distance_km: float,
        base_travel_time_h: float,
        capacity: int,
        congestion: float = 0.0,
        energy_cost_kwh_per_tonne_km: float = 0.12,
        toll_per_km: float = 0.0,
        risk: float = 0.02,
        bidirectional: bool = True,
        blocked: bool = False,
    ) -> None:
        key = f"{mode.value}"
        attrs = dict(
            mode=mode,
            distance_km=distance_km,
            base_travel_time_h=base_travel_time_h,
            capacity=capacity,
            congestion=congestion,
            energy_cost_kwh_per_tonne_km=energy_cost_kwh_per_tonne_km,
            toll_per_km=toll_per_km,
            risk=risk,
            blocked=blocked,
            current_load=0,
        )
        self.graph.add_edge(u, v, key=key, **attrs)
        if bidirectional:
            self.graph.add_edge(v, u, key=key, **attrs)

    # -- dynamic state ---------------------------------------------------------
    def set_congestion(self, u: str, v: str, mode: EdgeMode, congestion: float) -> None:
        key = mode.value
        if self.graph.has_edge(u, v, key=key):
            self.graph[u][v][key]["congestion"] = max(0.0, min(1.0, congestion))

    def set_blocked(self, u: str, v: str, mode: EdgeMode, blocked: bool) -> None:
        key = mode.value
        for a, b in ((u, v), (v, u)):
            if self.graph.has_edge(a, b, key=key):
                self.graph[a][b][key]["blocked"] = blocked

    def travel_time_h(self, u: str, v: str, mode: EdgeMode) -> float:
        """Congestion-adjusted travel time using a BPR-style penalty."""
        edge = self.graph[u][v][mode.value]
        base = edge["base_travel_time_h"]
        congestion = edge["congestion"]
        # BPR function: t = t0 * (1 + alpha * congestion^beta)
        alpha, beta = 0.6, 4.0
        return base * (1 + alpha * (congestion ** beta))

    # -- queries -----------------------------------------------------------
    def neighbours(self, node_id: str):
        return list(self.graph.successors(node_id))

    def edges_from(self, node_id: str) -> list[tuple[str, str, str, dict]]:
        out = []
        for _, v, key, data in self.graph.out_edges(node_id, keys=True, data=True):
            out.append((node_id, v, key, data))
        return out

    def capacity_summary(self) -> dict:
        by_mode: dict[str, dict] = {}
        for u, v, key, data in self.graph.edges(keys=True, data=True):
            mode = data["mode"].value if hasattr(data["mode"], "value") else data["mode"]
            bucket = by_mode.setdefault(mode, {"capacity": 0, "current_load": 0, "edges": 0})
            bucket["capacity"] += data["capacity"]
            bucket["current_load"] += data["current_load"]
            bucket["edges"] += 1
        return by_mode

    def nodes_of_type(self, node_type: NodeType) -> list[str]:
        return [n for n, d in self.graph.nodes(data=True) if d.get("node_type") == node_type]

    def node_position(self, node_id: str) -> tuple[float, float]:
        return self.graph.nodes[node_id].get("position", (0.0, 0.0))
