"""
network/roads.py

Simplified road traffic model (req. #19). Congestion is derived from a
volume/capacity ratio using the standard Bureau of Public Roads (BPR)
curve, then written back onto the network's road edges so travel times
change dynamically as trucks load the network.
"""
from __future__ import annotations

from dataclasses import dataclass

from freight_os.network.graph import EdgeMode, FreightNetwork


@dataclass
class TrafficModel:
    network: FreightNetwork
    alpha: float = 0.6
    beta: float = 4.0

    def enter_edge(self, u: str, v: str, mode: EdgeMode = EdgeMode.ROAD) -> None:
        edge = self.network.graph[u][v][mode.value]
        edge["current_load"] += 1
        self._recompute_congestion(u, v, mode)

    def exit_edge(self, u: str, v: str, mode: EdgeMode = EdgeMode.ROAD) -> None:
        edge = self.network.graph[u][v][mode.value]
        edge["current_load"] = max(0, edge["current_load"] - 1)
        self._recompute_congestion(u, v, mode)

    def _recompute_congestion(self, u: str, v: str, mode: EdgeMode) -> None:
        edge = self.network.graph[u][v][mode.value]
        vc_ratio = edge["current_load"] / max(1, edge["capacity"])
        congestion = min(1.0, vc_ratio)
        self.network.set_congestion(u, v, mode, congestion)

    def average_speed_kmh(self, u: str, v: str, mode: EdgeMode, free_flow_speed_kmh: float) -> float:
        edge = self.network.graph[u][v][mode.value]
        congestion = edge["congestion"]
        return free_flow_speed_kmh / (1 + self.alpha * (congestion ** self.beta))

    def network_average_congestion(self, mode: EdgeMode = EdgeMode.ROAD) -> float:
        vals = [
            d["congestion"]
            for _, _, k, d in self.network.graph.edges(keys=True, data=True)
            if k == mode.value
        ]
        return sum(vals) / len(vals) if vals else 0.0
