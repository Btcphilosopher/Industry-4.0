"""
economics/costs.py

EconomicEngine (req. #27): rolls up transport, energy, labour-equivalent,
depreciation, maintenance, terminal, warehouse and toll costs, and derives
cost-per-container / per-tonne / per-km / per-shipment.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from freight_os.core.configuration import SimulationConfig
from freight_os.energy.engine import EnergyEngine


@dataclass
class EconomicEngine:
    config: SimulationConfig
    energy_engine: EnergyEngine
    terminal_containers_handled: int = 0
    warehouse_containers_handled: int = 0
    total_truck_km: float = 0.0
    total_barge_km: float = 0.0
    total_vehicle_hours: float = 0.0

    def transport_cost_gbp(self) -> float:
        depreciation = self.total_truck_km * self.config.truck_depreciation_per_km
        maintenance = self.total_truck_km * self.config.maintenance_cost_per_km
        tolls = self.total_truck_km * self.config.toll_cost_per_km_road
        labour = self.total_vehicle_hours * self.config.driver_labour_cost_per_hour
        barge_depreciation = (self.total_barge_km / 15.0) * self.config.barge_depreciation_per_hour  # approx hours from km/speed
        return depreciation + maintenance + tolls + labour + barge_depreciation

    def energy_cost_gbp(self) -> float:
        return self.energy_engine.total_cost_gbp()

    def terminal_cost_gbp(self) -> float:
        return self.terminal_containers_handled * self.config.terminal_handling_cost_per_container

    def warehouse_cost_gbp(self) -> float:
        return self.warehouse_containers_handled * self.config.warehouse_handling_cost_per_container

    def total_operating_cost_gbp(self) -> float:
        return (
            self.transport_cost_gbp()
            + self.energy_cost_gbp()
            + self.terminal_cost_gbp()
            + self.warehouse_cost_gbp()
        )

    def cost_per_container(self, num_containers: int) -> float:
        return self.total_operating_cost_gbp() / max(1, num_containers)

    def cost_per_tonne(self, total_tonnes: float) -> float:
        return self.total_operating_cost_gbp() / max(1e-6, total_tonnes)

    def cost_per_km(self) -> float:
        total_km = self.total_truck_km + self.total_barge_km
        return self.total_operating_cost_gbp() / max(1e-6, total_km)

    def breakdown(self, num_containers: int) -> dict:
        return {
            "transport_cost_gbp": self.transport_cost_gbp(),
            "energy_cost_gbp": self.energy_cost_gbp(),
            "terminal_cost_gbp": self.terminal_cost_gbp(),
            "warehouse_cost_gbp": self.warehouse_cost_gbp(),
            "total_operating_cost_gbp": self.total_operating_cost_gbp(),
            "cost_per_container_gbp": self.cost_per_container(num_containers),
            "cost_per_km_gbp": self.cost_per_km(),
        }
