"""
optimisation/routing.py

Route comparison / explanation reporting built on top of
network.routes.RouteOptimizer (req. #5 worked example: Route A vs Route B).
Kept separate from network/routes.py so the algorithm (there) stays
decoupled from presentation (here).
"""
from __future__ import annotations

from freight_os.network.routes import RouteOptimizer, RouteOption


def format_route_summary(route: RouteOption, label: str = "Route") -> str:
    modes = " -> ".join(dict.fromkeys(route.modes))  # de-duplicate consecutive repeats, preserve order
    return (
        f"{label}: {' -> '.join(route.nodes)}\n"
        f"  Modes:        {modes}\n"
        f"  Cost:         £{route.total_cost_gbp:,.0f}\n"
        f"  Time:         {route.total_time_h:.1f} h\n"
        f"  Energy:       {route.total_energy_kwh_equiv:,.0f} kWh-eq\n"
        f"  Reliability:  {route.reliability*100:.1f}%\n"
        f"  Why:          {route.explanation}"
    )


def compare_and_explain(route_optimizer: RouteOptimizer, origin: str, destination: str, weights: dict | None = None) -> str:
    options = route_optimizer.compare_routes(origin, destination, weights=weights)
    if not options:
        return f"No viable route found between {origin} and {destination}."
    lines = [f"Candidate routes {origin} -> {destination} ({len(options)} evaluated):\n"]
    for i, opt in enumerate(options, 1):
        lines.append(format_route_summary(opt, label=f"Route {chr(64+i)}"))
        lines.append("")
    lines.append(f"SELECTED: Route A ({' -> '.join(options[0].nodes)}) — lowest weighted score.")
    return "\n".join(lines)
