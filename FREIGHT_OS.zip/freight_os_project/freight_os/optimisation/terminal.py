"""
optimisation/terminal.py

TerminalOptimizer (req. #10, #11): solves crane-to-job assignment as a
linear assignment problem (Hungarian algorithm via SciPy) to minimise
total handling time/distance, and suggests yard-slot placement to balance
congestion.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.optimize import linear_sum_assignment

from freight_os.ports.terminal import TerminalSimulator


@dataclass
class TerminalOptimizer:
    terminal: TerminalSimulator

    def optimal_crane_assignment(self, job_positions: list[tuple[float, float]]) -> dict:
        """
        Assign each job (given as an (x, y) yard position) to a crane, minimising
        total travel distance, via the Hungarian algorithm.
        Returns {job_index: crane_id}.
        """
        cranes = self.terminal.cranes
        if not cranes or not job_positions:
            return {}
        # cranes are positioned along the quay; approximate crane x-position by index
        crane_positions = [(float(i) * 40.0, 0.0) for i in range(len(cranes))]
        n = max(len(cranes), len(job_positions))
        cost = np.full((n, n), fill_value=1e6)
        for i, job in enumerate(job_positions):
            for j, cp in enumerate(crane_positions):
                cost[i, j] = float(np.hypot(job[0] - cp[0], job[1] - cp[1]))
        row_ind, col_ind = linear_sum_assignment(cost)
        assignment = {}
        for r, c in zip(row_ind, col_ind):
            if r < len(job_positions) and c < len(cranes):
                assignment[r] = cranes[c].crane_id
        return assignment

    def recommend_crane_addition(self, sim_duration_h: float, throughput_gain_per_crane_pct: float = 12.0) -> str | None:
        util = self.terminal.crane_utilisation(sim_duration_h)
        if util > 0.85:
            return (
                f"Terminal {self.terminal.terminal_id} crane utilisation is {util*100:.0f}% "
                f"(> 85% threshold). Adding one crane is estimated to increase simulated "
                f"throughput by roughly {throughput_gain_per_crane_pct:.0f}% based on observed queueing."
            )
        return None

    def yard_congestion_recommendation(self) -> str | None:
        util = self.terminal.yard.utilisation()
        if util > 0.8:
            return (
                f"Terminal {self.terminal.terminal_id} yard utilisation is {util*100:.0f}% "
                f"(> 80% threshold) — containers are dwelling in the yard longer than average; "
                f"consider additional yard slots or faster onward vehicle dispatch."
            )
        return None
