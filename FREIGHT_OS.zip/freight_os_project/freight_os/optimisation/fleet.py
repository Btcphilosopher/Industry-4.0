"""
optimisation/fleet.py

FleetOptimizer (req. #15): multi-vehicle optimisation across hundreds to
thousands of simulated vehicles — utilisation, empty miles, duplicate
routes, empty-return detection — plus a lightweight genetic-algorithm
research hook for fleet-sizing (req. #32: GA support, not a hard
dependency of the core simulator).
"""
from __future__ import annotations

import random
from dataclasses import dataclass

from freight_os.vehicles.fleet import FleetManager


@dataclass
class FleetOptimizer:
    fleet_manager: FleetManager

    def underutilised_vehicles(self, min_trips: int = 2) -> list[str]:
        return self.fleet_manager.underutilised_vehicles(min_trip_count=min_trips)

    def utilisation_report(self) -> dict:
        return {
            "truck_utilisation_pct": self.fleet_manager.fleet_utilisation_pct("truck"),
            "barge_utilisation_pct": self.fleet_manager.fleet_utilisation_pct("barge"),
            "truck_states": self.fleet_manager.utilisation_by_state("truck"),
            "barge_states": self.fleet_manager.utilisation_by_state("barge"),
        }

    def duplicate_route_pairs(self) -> list[tuple[str, str]]:
        """Two vehicles currently assigned identical remaining routes — a
        signal of an avoidable duplicate journey."""
        seen: dict[tuple, str] = {}
        duplicates = []
        for v in self.fleet_manager.all_vehicles():
            key = tuple(v.route)
            if not key:
                continue
            if key in seen:
                duplicates.append((seen[key], v.vehicle_id))
            else:
                seen[key] = v.vehicle_id
        return duplicates

    # -- genetic-algorithm research hook (optional, not required for core sim) --
    def ga_optimise_fleet_size(
        self,
        demand_containers: int,
        cost_per_truck: float,
        avg_containers_per_truck_per_day: float,
        min_trucks: int = 1,
        max_trucks: int = 200,
        population_size: int = 24,
        generations: int = 40,
        seed: int = 42,
    ) -> dict:
        """
        Tiny, dependency-free GA that searches for the fleet size minimising
        (fleet cost + unmet-demand penalty). Demonstrates the research hook
        called for in req. #32 without pulling in an external GA library.
        """
        rng = random.Random(seed)

        def fitness(n_trucks: int) -> float:
            capacity = n_trucks * avg_containers_per_truck_per_day
            unmet = max(0, demand_containers - capacity)
            fleet_cost = n_trucks * cost_per_truck
            penalty = unmet * cost_per_truck * 3  # unmet demand penalised heavily
            return fleet_cost + penalty

        population = [rng.randint(min_trucks, max_trucks) for _ in range(population_size)]
        best_n, best_score = None, float("inf")

        for _ in range(generations):
            scored = sorted(population, key=fitness)
            if fitness(scored[0]) < best_score:
                best_n, best_score = scored[0], fitness(scored[0])
            survivors = scored[: population_size // 2]
            children = []
            while len(children) < population_size - len(survivors):
                a, b = rng.choice(survivors), rng.choice(survivors)
                child = (a + b) // 2
                if rng.random() < 0.3:
                    child += rng.randint(-3, 3)
                child = max(min_trucks, min(max_trucks, child))
                children.append(child)
            population = survivors + children

        return {"optimal_truck_count": best_n, "estimated_cost_gbp": best_score}
