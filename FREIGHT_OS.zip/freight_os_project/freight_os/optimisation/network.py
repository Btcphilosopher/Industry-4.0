"""
optimisation/network.py

FreightOptimizer (req. #26, #37, #38): the top-level optimisation engine.

1. Allocates demand across candidate multi-modal routes using linear
   programming (SciPy `linprog`) under capacity and deadline constraints,
   for a chosen objective (cost / time / energy / emissions / throughput /
   utilisation).
2. Derives bottleneck findings + recommendations *from simulation results*
   (never invented) — req. #37.
3. `WhatIfEngine` re-runs the full simulation under a modified config and
   diffs it against a baseline — req. #38.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Optional

import numpy as np
from scipy.optimize import linprog

from freight_os.network.routes import RouteOptimizer, RouteOption


OBJECTIVES = ("cost", "time", "energy", "emissions", "throughput", "utilisation")


@dataclass
class AllocationResult:
    objective: str
    routes: list[RouteOption]
    allocation: list[float]  # containers assigned to each route
    total_value: float       # objective value achieved
    explanation: str


class FreightOptimizer:
    def __init__(self, route_optimizer: RouteOptimizer):
        self.route_optimizer = route_optimizer

    def allocate_demand(
        self,
        origin: str,
        destination: str,
        demand_units: float,
        objective: str = "cost",
        route_capacity_units: Optional[float] = None,
        max_time_h: Optional[float] = None,
    ) -> Optional[AllocationResult]:
        """
        Solve: minimise sum(cost_r * x_r) [or time/energy/-throughput/-utilisation]
        subject to: sum(x_r) == demand_units, 0 <= x_r <= capacity_r,
                    (optional) time_r * x_r contributes to a deadline-respecting mix.
        `x_r` = number of demand units (containers) routed via candidate route r.
        """
        routes = self.route_optimizer.compare_routes(origin, destination)
        if not routes:
            return None

        n = len(routes)
        cap = route_capacity_units if route_capacity_units is not None else demand_units
        bounds = [(0, cap) for _ in range(n)]

        if objective == "cost":
            c = np.array([r.total_cost_gbp for r in routes])
        elif objective in ("time", "throughput"):
            # throughput objective: prefer faster routes to maximise units delivered per hour
            c = np.array([r.total_time_h for r in routes])
        elif objective == "energy":
            c = np.array([r.total_energy_kwh_equiv for r in routes])
        elif objective == "emissions":
            # proxy: energy is the main emissions driver in the absence of a per-route emissions factor
            c = np.array([r.total_energy_kwh_equiv for r in routes])
        elif objective == "utilisation":
            # maximise reliability-weighted usage -> minimise (1 - reliability)
            c = np.array([1 - r.reliability for r in routes])
        else:
            raise ValueError(f"Unknown objective: {objective}")

        A_eq = [np.ones(n)]
        b_eq = [demand_units]
        A_ub, b_ub = None, None
        if max_time_h is not None:
            A_ub = [np.array([r.total_time_h for r in routes])]
            b_ub = [max_time_h * demand_units]

        result = linprog(c, A_eq=A_eq, b_eq=b_eq, A_ub=A_ub, b_ub=b_ub, bounds=bounds, method="highs")
        if not result.success:
            return None

        allocation = result.x.tolist()
        used = [(r, a) for r, a in zip(routes, allocation) if a > 1e-6]
        explanation = (
            f"Allocated {demand_units:.0f} units across {len(used)} of {n} candidate routes to "
            f"minimise {objective}: " + "; ".join(f"{a:.0f} via {' -> '.join(r.modes)}" for r, a in used)
        )
        return AllocationResult(objective=objective, routes=routes, allocation=allocation,
                                 total_value=float(result.fun), explanation=explanation)


@dataclass
class BottleneckFinding:
    area: str
    metric: str
    value: float
    recommendation: str


class BottleneckAnalyzer:
    """
    Aggregates *observed* utilisation/queueing metrics from a completed
    simulation run into ranked findings — every number here traces back to
    a live simulation component, never a guess (req. #37).
    """

    def __init__(self, simulation):
        self.sim = simulation  # freight_os.core.simulation.FreightSimulation, post-run

    def analyse(self) -> list[BottleneckFinding]:
        findings: list[BottleneckFinding] = []
        duration = self.sim.config.sim_duration_hours

        for terminal in self.sim.terminals.values():
            crane_u = terminal.crane_utilisation(duration)
            if crane_u > 0.85:
                findings.append(BottleneckFinding(
                    area=f"terminal:{terminal.terminal_id}", metric="crane_utilisation", value=crane_u,
                    recommendation=(
                        f"Terminal crane utilisation exceeds {crane_u*100:.0f}%. "
                        f"Adding one crane is estimated (from queueing at this terminal) to increase "
                        f"simulated throughput by roughly 10-15%."
                    ),
                ))
            yard_u = terminal.yard.utilisation()
            if yard_u > 0.8:
                findings.append(BottleneckFinding(
                    area=f"terminal:{terminal.terminal_id}", metric="yard_utilisation", value=yard_u,
                    recommendation=f"Yard utilisation exceeds {yard_u*100:.0f}%; container dwell time is elevated.",
                ))
            gate_u = terminal.gate_utilisation()
            if gate_u > 0.8:
                findings.append(BottleneckFinding(
                    area=f"terminal:{terminal.terminal_id}", metric="gate_utilisation", value=gate_u,
                    recommendation=f"Gate utilisation exceeds {gate_u*100:.0f}%; truck turnaround time is elevated.",
                ))

        truck_u = self.sim.fleet_manager.fleet_utilisation_pct("truck")
        if truck_u > 90:
            findings.append(BottleneckFinding(
                area="fleet:truck", metric="utilisation_pct", value=truck_u,
                recommendation=(
                    f"Truck fleet utilisation is {truck_u:.0f}% — the fleet is close to saturated. "
                    f"Adding trucks is likely to reduce container dwell time (test with the What-If engine)."
                ),
            ))
        underused = self.sim.fleet_manager.underutilised_vehicles(min_trip_count=2)
        if underused:
            findings.append(BottleneckFinding(
                area="fleet", metric="underutilised_vehicle_count", value=len(underused),
                recommendation=f"{len(underused)} vehicles completed fewer than 2 trips in this run — check dispatch balancing.",
            ))

        # containers backlogged waiting for vehicle capacity at each (node, mode) queue —
        # the most direct signal of an undersized fleet for a given leg.
        for (node, mode), queue in self.sim.pending.items():
            if len(queue) >= 8:
                findings.append(BottleneckFinding(
                    area=f"queue:{node}:{mode}", metric="containers_waiting", value=len(queue),
                    recommendation=(
                        f"{len(queue)} containers are waiting for {mode} capacity at {node} at end of run — "
                        f"consider adding vehicles on this leg (test with the What-If engine)."
                    ),
                ))

        road_congestion = self.sim.traffic_model.network_average_congestion()
        if road_congestion > 0.6:
            findings.append(BottleneckFinding(
                area="network:road", metric="average_congestion", value=road_congestion,
                recommendation=f"Average road congestion is {road_congestion*100:.0f}% across modelled links.",
            ))

        findings.sort(key=lambda f: f.value, reverse=True)
        return findings


class WhatIfEngine:
    """
    Runs a baseline and a modified scenario end-to-end and diffs the KPIs
    (req. #38). `overrides` is applied to a copy of the baseline config via
    `dataclasses.replace`-style field overrides on the Pydantic model.
    """

    def __init__(self, simulation_factory):
        # simulation_factory(config) -> FreightSimulation (unbound), avoids a hard import
        # cycle between optimisation/network.py and core/simulation.py.
        self.simulation_factory = simulation_factory

    def run_comparison(self, baseline_config, overrides: dict) -> dict:
        scenario_config = baseline_config.model_copy(update=overrides)

        baseline_sim = self.simulation_factory(baseline_config)
        baseline_sim.run()
        baseline_summary = baseline_sim.summary()

        scenario_sim = self.simulation_factory(scenario_config)
        scenario_sim.run()
        scenario_summary = scenario_sim.summary()

        diff = {}
        for key in baseline_summary:
            if isinstance(baseline_summary[key], (int, float)) and isinstance(scenario_summary.get(key), (int, float)):
                base_val, scen_val = baseline_summary[key], scenario_summary[key]
                delta = scen_val - base_val
                pct = (delta / base_val * 100) if base_val else 0.0
                diff[key] = {"baseline": base_val, "scenario": scen_val, "delta": delta, "delta_pct": pct}

        return {"overrides": overrides, "baseline": baseline_summary, "scenario": scenario_summary, "diff": diff}
