"""
warehouses/warehouse.py

WarehouseSimulator (req. #12): receiving -> storage -> picking -> packing
-> dispatch, with autonomous warehouse vehicles (AGVs) modelled as a
shared SimPy resource pool for internal moves.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import simpy

from freight_os.containers.container import ContainerStatus
from freight_os.core.events import EventLog, EventType


@dataclass
class WarehouseSimulator:
    warehouse_id: str
    location_node: str
    storage_capacity: int = 500
    dock_doors: int = 4
    num_agvs: int = 6

    stored_units: int = 0
    dock_resource: simpy.Resource = field(default=None, repr=False)
    agv_pool: simpy.Resource = field(default=None, repr=False)
    receiving_time_h: float = 0.25
    putaway_time_h: float = 0.1
    pick_pack_time_h: float = 0.2
    dispatch_time_h: float = 0.15

    received_count: int = 0
    dispatched_count: int = 0

    def bind(self, env: simpy.Environment) -> None:
        self.env = env
        self.dock_resource = simpy.Resource(env, capacity=self.dock_doors)
        self.agv_pool = simpy.Resource(env, capacity=self.num_agvs)

    def receive_and_store(self, event_log: EventLog, container):
        """Receiving -> storage. Final delivery point for the demo network."""
        with self.dock_resource.request() as dock:
            yield dock
            yield self.env.timeout(self.receiving_time_h)
            with self.agv_pool.request() as agv:
                yield agv
                yield self.env.timeout(self.putaway_time_h)
                self.stored_units = min(self.storage_capacity, self.stored_units + 1)
                self.received_count += 1
        container.transition(self.env.now, ContainerStatus.DELIVERED, location=self.location_node, vehicle_id=None, mode=None)
        event_log.log(self.env.now, EventType.CONTAINER_DELIVERED, container.container_id, warehouse=self.warehouse_id)

    def pick_pack_dispatch(self, event_log: EventLog, container_id: str):
        """Outbound flow (available for scenarios where the warehouse is an origin, not just a sink)."""
        with self.agv_pool.request() as agv:
            yield agv
            yield self.env.timeout(self.pick_pack_time_h)
        with self.dock_resource.request() as dock:
            yield dock
            yield self.env.timeout(self.dispatch_time_h)
            self.stored_units = max(0, self.stored_units - 1)
            self.dispatched_count += 1

    def utilisation(self) -> float:
        return self.stored_units / max(1, self.storage_capacity)

    def status(self) -> dict:
        return {
            "warehouse_id": self.warehouse_id,
            "storage_utilisation": self.utilisation(),
            "received_count": self.received_count,
            "dispatched_count": self.dispatched_count,
        }
