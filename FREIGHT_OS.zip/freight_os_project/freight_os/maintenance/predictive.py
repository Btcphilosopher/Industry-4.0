"""
maintenance/predictive.py

MaintenanceEngine (req. #22): tracks vehicle age/hours/mileage/energy
cycles/fault history and predicts maintenance probability + remaining
useful life (RUL).

Uses a statistical Weibull hazard model out of the box. The `FailurePredictor`
protocol is the seam for future ML integration (see ml/maintenance.py) —
swap in `MLFailurePredictor` without touching the rest of the engine.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Protocol


@dataclass
class VehicleWearRecord:
    vehicle_id: str
    age_hours: float = 0.0        # time since "manufacture" (sim start, for the demo)
    operating_hours: float = 0.0
    mileage_km: float = 0.0
    energy_cycles: float = 0.0    # battery cycles / engine-hours-equivalent
    fault_count: int = 0

    def component_wear_index(self) -> float:
        """0 (new) .. 1+ (well past design life). Purely a function of usage, not calendar time."""
        return (
            0.35 * min(1.0, self.mileage_km / 300_000)
            + 0.35 * min(1.0, self.operating_hours / 20_000)
            + 0.20 * min(1.0, self.energy_cycles / 2_000)
            + 0.10 * min(1.0, self.fault_count / 5)
        )


@dataclass
class MaintenancePrediction:
    vehicle_id: str
    maintenance_probability_next_100h: float
    remaining_useful_life_hours: float
    wear_index: float


class FailurePredictor(Protocol):
    def predict(self, record: VehicleWearRecord) -> MaintenancePrediction: ...


@dataclass
class StatisticalWeibullPredictor:
    """
    Weibull hazard model: h(t) = (k/lambda) * (t/lambda)^(k-1)
    k > 1 => increasing failure rate with wear (typical of mechanical wear-out).
    `t` here is the component wear index scaled onto a 0-10 "wear age" axis.
    """
    shape_k: float = 2.2
    scale_lambda: float = 6.0

    def predict(self, record: VehicleWearRecord) -> MaintenancePrediction:
        wear = record.component_wear_index()
        t = wear * 10.0
        if t <= 0:
            hazard = 0.0
        else:
            hazard = (self.shape_k / self.scale_lambda) * (t / self.scale_lambda) ** (self.shape_k - 1)
        # convert instantaneous hazard into an approximate probability over the next 100 operating hours
        prob_next_100h = 1 - math.exp(-hazard * 1.0)
        prob_next_100h = max(0.0, min(1.0, prob_next_100h))

        # RUL: hours until wear index would reach 1.0 at current wear-accrual rate
        accrual_rate = wear / max(1.0, record.operating_hours) if record.operating_hours > 0 else 0.0001
        rul_hours = (1.0 - wear) / accrual_rate if accrual_rate > 0 else float("inf")
        rul_hours = max(0.0, min(rul_hours, 100_000.0))

        return MaintenancePrediction(
            vehicle_id=record.vehicle_id,
            maintenance_probability_next_100h=prob_next_100h,
            remaining_useful_life_hours=rul_hours,
            wear_index=wear,
        )


@dataclass
class MaintenanceEngine:
    predictor: FailurePredictor = field(default_factory=StatisticalWeibullPredictor)
    records: dict[str, VehicleWearRecord] = field(default_factory=dict)

    def track(self, vehicle_id: str) -> VehicleWearRecord:
        return self.records.setdefault(vehicle_id, VehicleWearRecord(vehicle_id=vehicle_id))

    def update_from_vehicle(self, vehicle) -> None:
        rec = self.track(vehicle.vehicle_id)
        rec.age_hours = vehicle.operating_hours  # demo horizon: age == operating hours since sim start
        rec.operating_hours = vehicle.operating_hours
        rec.mileage_km = vehicle.odometer_km
        rec.energy_cycles = getattr(vehicle.energy_state.get("battery"), "cycle_count", 0.0) if vehicle.energy_state else 0.0
        rec.fault_count = len(vehicle.fault_history)

    def predict(self, vehicle_id: str) -> MaintenancePrediction:
        return self.predictor.predict(self.track(vehicle_id))

    def fleet_risk_report(self) -> list[MaintenancePrediction]:
        return sorted(
            (self.predict(vid) for vid in self.records),
            key=lambda p: p.maintenance_probability_next_100h,
            reverse=True,
        )
