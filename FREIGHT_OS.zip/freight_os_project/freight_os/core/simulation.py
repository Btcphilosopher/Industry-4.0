"""
core/simulation.py

FreightSimulation: the orchestrator that wires network, containers,
vehicles, terminals, warehouse, energy, economics, emissions and
maintenance into one coherent, deterministic, event-driven SimPy
simulation (req. #47's end-to-end pipeline):

    CREATE NETWORK -> CREATE CONTAINERS -> CREATE TRUCKS + BARGES ->
    GENERATE DEMAND -> ASSIGN VEHICLES -> OPTIMISE ROUTES -> SIMULATE
    MOVEMENT -> TRANSFER CONTAINERS -> HANDLE CONGESTION -> TRACK ENERGY
    -> CALCULATE COST -> DELIVER CONTAINERS -> GENERATE REPORT

This module builds and runs the req. #45 demonstration network:

    FACTORY -> [truck] -> PORT_TERMINAL -> [barge] -> INLAND_TERMINAL
             -> [truck] -> WAREHOUSE
"""
from __future__ import annotations

import simpy

from freight_os.containers.container import Container, ContainerStatus
from freight_os.containers.tracking import ContainerTracker
from freight_os.core.configuration import EnergySource, SimulationConfig
from freight_os.core.events import EventLog, EventType
from freight_os.core.state import DigitalTwinState
from freight_os.autonomy.dispatcher import DispatchEngine
from freight_os.autonomy.planner import Planner
from freight_os.economics.costs import EconomicEngine
from freight_os.emissions.emissions import EmissionsModel
from freight_os.energy.battery import Battery
from freight_os.energy.charging import ChargingNetwork, ChargingStation
from freight_os.energy.engine import EnergyEngine
from freight_os.energy.hydrogen import HydrogenTank
from freight_os.maintenance.predictive import MaintenanceEngine
from freight_os.network.graph import EdgeMode, FreightNetwork, NodeType
from freight_os.network.roads import TrafficModel
from freight_os.network.routes import RouteOptimizer
from freight_os.network.waterways import WaterwayModel
from freight_os.ports.port import PortSimulator
from freight_os.ports.terminal import TerminalSimulator
from freight_os.vehicles.barge import Barge, BargeSimulator
from freight_os.vehicles.base import OperatingState
from freight_os.vehicles.fleet import FleetManager
from freight_os.vehicles.truck import Truck, TruckSimulator
from freight_os.warehouses.warehouse import WarehouseSimulator

FIRST_MILE = ("FACTORY", "PORT_TERMINAL")
WATERWAY_LEG = ("PORT_TERMINAL", "INLAND_TERMINAL")
LAST_MILE = ("INLAND_TERMINAL", "WAREHOUSE")


class FreightSimulation:
    def __init__(self, config: SimulationConfig):
        self.config = config
        self.env = simpy.Environment()
        self.rng = config.make_rng()
        self.py_random = config.seed_stdlib_random()

        self.network = FreightNetwork()
        self.state = DigitalTwinState()
        self.event_log = EventLog()
        self.container_tracker = ContainerTracker()

        self.energy_engine = EnergyEngine(config=config, env=self.env)
        self.fleet_manager = FleetManager()
        self.terminals: dict[str, TerminalSimulator] = {}       # keyed by terminal_id
        self.warehouses: dict[str, WarehouseSimulator] = {}     # keyed by warehouse_id
        self.node_to_terminal: dict[str, TerminalSimulator] = {}   # keyed by network node id
        self.node_to_warehouse: dict[str, WarehouseSimulator] = {}  # keyed by network node id
        self.maintenance_engine = MaintenanceEngine()

        self.pending: dict[tuple[str, str], list[Container]] = {}
        self.pending_arrival_time: dict[str, float] = {}
        self.containers: list[Container] = []

        self.port: PortSimulator | None = None
        self.traffic_model: TrafficModel | None = None
        self.waterway_model: WaterwayModel | None = None
        self.route_optimizer: RouteOptimizer | None = None
        self.planner: Planner | None = None
        self.dispatch_engine: DispatchEngine | None = None
        self.truck_sim: TruckSimulator | None = None
        self.barge_sim: BargeSimulator | None = None
        self.economic_engine: EconomicEngine | None = None
        self.emissions_model: EmissionsModel | None = None
        self.charging_network: ChargingNetwork | None = None

        self._built = False

    # ------------------------------------------------------------------
    # CREATE NETWORK
    # ------------------------------------------------------------------
    def _build_demo_network(self) -> None:
        self.network.add_node("FACTORY", NodeType.FACTORY, position=(0, 0))
        self.network.add_node("PORT_TERMINAL", NodeType.TERMINAL, position=(50, 0))
        self.network.add_node("INLAND_TERMINAL", NodeType.TERMINAL, position=(50, 80))
        self.network.add_node("WAREHOUSE", NodeType.WAREHOUSE, position=(0, 80))

        self.network.add_edge(*FIRST_MILE, EdgeMode.ROAD, distance_km=45, base_travel_time_h=45 / 70,
                               capacity=40, toll_per_km=0.04, risk=0.01)
        self.network.add_edge(*WATERWAY_LEG, EdgeMode.RIVER, distance_km=70, base_travel_time_h=70 / 20,
                               capacity=8, energy_cost_kwh_per_tonne_km=0.04, risk=0.015)
        self.network.add_edge(*LAST_MILE, EdgeMode.ROAD, distance_km=30, base_travel_time_h=30 / 70,
                               capacity=40, toll_per_km=0.04, risk=0.01)

        self.state.set_network(self.network)
        self.traffic_model = TrafficModel(self.network)
        self.waterway_model = WaterwayModel(self.network)
        self.waterway_model.register_lock(*WATERWAY_LEG, self.env,
                                           capacity_vessels=self.config.lock_capacity_vessels,
                                           cycle_time_h=self.config.lock_cycle_time_minutes / 60.0)
        self.waterway_model.set_max_draft(*WATERWAY_LEG, draft_m=3.5)

        self.route_optimizer = RouteOptimizer(self.network)
        self.planner = Planner(self.route_optimizer)
        self.dispatch_engine = DispatchEngine(self.fleet_manager, self.route_optimizer)

        self.truck_sim = TruckSimulator(
            self.env, self.network, self.traffic_model, self.event_log, self.py_random,
            failure_prob_per_trip=self.config.truck_failure_prob_per_trip,
        )
        self.barge_sim = BargeSimulator(
            self.env, self.network, self.waterway_model, self.event_log, self.py_random,
            failure_prob_per_trip=self.config.barge_failure_prob_per_trip,
        )
        self.economic_engine = EconomicEngine(config=self.config, energy_engine=self.energy_engine)
        self.emissions_model = EmissionsModel(config=self.config, energy_engine=self.energy_engine)

    # ------------------------------------------------------------------
    # CREATE TRUCKS + BARGES
    # ------------------------------------------------------------------
    def _make_energy_state(self, source: EnergySource) -> dict:
        state: dict = {"low_energy": False}
        if source in (EnergySource.ELECTRIC, EnergySource.HYBRID):
            state["battery"] = Battery(capacity_kwh=450.0, charge_power_kw=150.0)
        if source in (EnergySource.DIESEL, EnergySource.HYBRID):
            state["fuel_litres"] = 600.0
        if source == EnergySource.HYDROGEN:
            state["tank"] = HydrogenTank(capacity_kg=40.0)
        return state

    def _build_fleet(self) -> None:
        sources = list(self.config.truck_energy_mix.keys())
        weights = list(self.config.truck_energy_mix.values())
        half = self.config.num_trucks // 2

        for i in range(self.config.num_trucks):
            idx = int(self.rng.choice(len(sources), p=weights))
            source = sources[idx]
            start_node = "FACTORY" if i < half else "INLAND_TERMINAL"
            truck = Truck(
                vehicle_id=f"TRK-{i+1:03d}", vehicle_class="truck", position=start_node,
                energy_source=source, battery_capacity_kwh=450.0, fuel_tank_litres=600.0,
                hydrogen_tank_kg=40.0, container_capacity=2,
            )
            truck.energy_state = self._make_energy_state(source)
            self.fleet_manager.register_truck(truck)
            self.state.register_vehicle(truck)
            self.maintenance_engine.track(truck.vehicle_id)

        for i in range(self.config.num_barges):
            barge = Barge(
                vehicle_id=f"BRG-{i+1:03d}", vehicle_class="barge", position="PORT_TERMINAL",
                energy_source=EnergySource.DIESEL, cargo_capacity_teu=48,
            )
            barge.energy_state = self._make_energy_state(EnergySource.DIESEL)
            self.fleet_manager.register_barge(barge)
            self.state.register_vehicle(barge)
            self.maintenance_engine.track(barge.vehicle_id)

    # ------------------------------------------------------------------
    # CREATE TERMINALS + WAREHOUSE + CHARGING INFRASTRUCTURE
    # ------------------------------------------------------------------
    def _build_terminals_and_warehouse(self) -> None:
        for terminal_id, node in (("PORT_TERMINAL", "PORT_TERMINAL"), ("INLAND_TERMINAL", "INLAND_TERMINAL")):
            terminal = TerminalSimulator(
                terminal_id=terminal_id, location_node=node,
                num_cranes=self.config.cranes_per_terminal, num_gates=self.config.gates_per_terminal,
                num_berths=self.config.berths_per_terminal, yard_slots=self.config.yard_slots_per_terminal,
                crane_cycle_time_minutes=self.config.crane_cycle_time_minutes,
            )
            terminal.bind(self.env)
            self.terminals[terminal_id] = terminal
            self.node_to_terminal[node] = terminal
            self.state.register_terminal(terminal)

        self.port = PortSimulator(port_id="PORT_OF_DEMO")
        self.port.add_terminal(self.terminals["PORT_TERMINAL"])

        warehouse = WarehouseSimulator(
            warehouse_id="WAREHOUSE_1", location_node="WAREHOUSE",
            storage_capacity=self.config.warehouse_storage_capacity, dock_doors=self.config.warehouse_dock_doors,
        )
        warehouse.bind(self.env)
        self.warehouses[warehouse.warehouse_id] = warehouse
        self.node_to_warehouse[warehouse.location_node] = warehouse
        self.state.register_warehouse(warehouse)

        self.charging_network = ChargingNetwork()
        for node in ("FACTORY", "PORT_TERMINAL", "INLAND_TERMINAL", "WAREHOUSE"):
            station = ChargingStation(station_id=f"CHG-{node}", location=node, num_chargers=4, power_kw=150.0)
            self.charging_network.add_station(station, self.env)

    # ------------------------------------------------------------------
    # GENERATE FREIGHT DEMAND
    # ------------------------------------------------------------------
    def _generate_demand(self) -> None:
        for i in range(self.config.num_containers):
            weight = float(self.rng.uniform(4000, 24000))
            volume = float(self.rng.uniform(20, 33))
            priority = int(self.rng.integers(1, 6))
            booked_at = float(self.rng.uniform(0, self.config.sim_duration_hours * 0.6))
            container = Container(
                container_id=f"CONT-{i+1:08d}", origin="FACTORY", destination="WAREHOUSE",
                weight_kg=weight, volume_m3=volume, priority=priority, booked_at=booked_at,
            )
            self.planner.plan_shipment(container, objective="multi")
            self.event_log.log(0.0, EventType.CONTAINER_BOOKED, container.container_id, booked_at=booked_at)
            self.state.register_container(container)
            self.container_tracker.register(container)
            self.containers.append(container)

    def build(self) -> None:
        if self._built:
            return
        self._build_demo_network()
        self._build_fleet()
        self._build_terminals_and_warehouse()
        self._generate_demand()
        self._built = True

    # ------------------------------------------------------------------
    # ASSIGN VEHICLES / SIMULATE MOVEMENT / TRANSFER CONTAINERS
    # ------------------------------------------------------------------
    def _enqueue(self, container: Container, node: str, mode: str) -> None:
        status = ContainerStatus.TRANSFER if node in self.node_to_terminal else ContainerStatus.WAITING
        container.transition(self.env.now, status, location=node)
        self.pending.setdefault((node, mode), []).append(container)
        self.pending_arrival_time[container.container_id] = self.env.now

    def _enqueue_next_leg(self, container: Container, node: str) -> None:
        idx = container.planned_route.index(node)
        if idx + 1 >= len(container.planned_route):
            return
        next_mode = container.planned_modes[idx]
        self._enqueue(container, node, next_mode)

    def _next_hop(self, container: Container, node: str) -> str:
        idx = container.planned_route.index(node)
        return container.planned_route[idx + 1]

    def _container_lifecycle(self, container: Container):
        yield self.env.timeout(container.booked_at)
        self._enqueue(container, container.origin, container.planned_modes[0])

    def _record_leg_economics(self, vehicle, u: str, v: str, mode: str) -> None:
        edge = self.network.graph[u][v][mode]
        distance = edge["distance_km"]
        time_h = self.network.travel_time_h(u, v, EdgeMode(mode))
        if vehicle.vehicle_class == "truck":
            self.economic_engine.total_truck_km += distance
        else:
            self.economic_engine.total_barge_km += distance
        self.economic_engine.total_vehicle_hours += time_h

    def _maybe_recharge(self, vehicle):
        """If an electric vehicle is low on charge, queue it at the nearest
        charging station before it re-enters the available pool (req. #17)."""
        battery = vehicle.energy_state.get("battery")
        if battery is None or not battery.is_low(0.25):
            return None
        station = self.charging_network.nearest_station(vehicle.position)
        if station is None:
            return None
        vehicle.operating_state = OperatingState.CHARGING
        return self.env.process(station.charge_vehicle(battery, self.event_log, vehicle.vehicle_id))

    def _run_leg(self, vehicle, containers: list[Container], from_node: str, to_node: str, mode: str):
        is_truck = vehicle.vehicle_class == "truck"
        sim = self.truck_sim if is_truck else self.barge_sim

        # -- departure-side terminal handling: retrieve containers from the yard --
        if from_node in self.node_to_terminal:
            terminal = self.node_to_terminal[from_node]
            ids = [c.container_id for c in containers]
            if is_truck:
                yield self.env.process(terminal.process_truck(self.event_log, ids, "outbound", self.energy_engine))
            else:
                yield self.env.process(terminal.load_vehicle_from_yard(self.event_log, ids, self.energy_engine))

        yield self.env.process(sim.load(vehicle, containers))
        for c in containers:
            c.transition(self.env.now, ContainerStatus.IN_TRANSIT, vehicle_id=vehicle.vehicle_id)

        yield self.env.process(sim.travel_leg(vehicle, from_node, to_node, self.energy_engine))
        self._record_leg_economics(vehicle, from_node, to_node, mode)

        faulted = sim.maybe_fail(vehicle)
        if faulted:
            self.event_log.log(self.env.now, EventType.MAINTENANCE_REQUIRED, vehicle.vehicle_id, node=vehicle.position)

        yield self.env.process(sim.unload(vehicle, containers))

        # -- arrival-side handling --
        if to_node in self.node_to_terminal:
            terminal = self.node_to_terminal[to_node]
            ids = [c.container_id for c in containers]
            if is_truck:
                yield self.env.process(terminal.process_truck(self.event_log, ids, "inbound", self.energy_engine))
            else:
                yield self.env.process(terminal.unload_vehicle_to_yard(self.event_log, ids, self.energy_engine))
            for c in containers:
                c.transition(self.env.now, ContainerStatus.AT_TERMINAL, location=to_node)
                self.economic_engine.terminal_containers_handled += 1
                self._enqueue_next_leg(c, to_node)
        elif to_node in self.node_to_warehouse:
            warehouse = self.node_to_warehouse[to_node]
            for c in containers:
                yield self.env.process(warehouse.receive_and_store(self.event_log, c))
                self.economic_engine.warehouse_containers_handled += 1

        self.maintenance_engine.update_from_vehicle(vehicle)

        if faulted:
            self.env.process(sim.repair(vehicle))
            return

        # -- empty return so the vehicle is repositioned for its next job (req. #15) --
        yield self.env.process(sim.travel_leg(vehicle, to_node, from_node, self.energy_engine))
        vehicle.empty_km += self.network.graph[to_node][from_node][mode]["distance_km"]
        self._record_leg_economics(vehicle, to_node, from_node, mode)
        self.maintenance_engine.update_from_vehicle(vehicle)

        charge_process = self._maybe_recharge(vehicle)
        if charge_process is not None:
            yield charge_process
        vehicle.operating_state = OperatingState.IDLE

    # A truck leg is short and frequent, so a short consolidation wait keeps
    # dwell time low; a barge leg is long (many hours) and infrequent, so it
    # is worth waiting longer to fill the boat rather than sailing near-empty.
    MAX_WAIT_BY_MODE = {"road": 1.0, "river": 3.0, "canal": 3.0, "sea": 6.0, "rail": 3.0}

    def _dispatch_monitor(self):
        dispatch_interval_h = 0.1
        while True:
            for key in list(self.pending.keys()):
                node, mode = key
                queue = self.pending[key]
                if not queue:
                    continue
                vehicle = self.dispatch_engine.pick_vehicle(node, mode)
                if vehicle is None:
                    continue
                batch = self.dispatch_engine.batch_by_capacity(queue, vehicle)
                if not batch:
                    continue
                max_wait_h = self.MAX_WAIT_BY_MODE.get(mode, 1.5)
                oldest_wait = self.env.now - min(self.pending_arrival_time[c.container_id] for c in batch)
                near_end = self.env.now > self.config.sim_duration_hours - 2
                if len(batch) >= vehicle.payload_capacity or oldest_wait >= max_wait_h or near_end:
                    for c in batch:
                        queue.remove(c)
                    vehicle.operating_state = OperatingState.LOADING
                    to_node = self._next_hop(batch[0], node)
                    self.env.process(self._run_leg(vehicle, batch, node, to_node, mode))
            yield self.env.timeout(dispatch_interval_h)

    # ------------------------------------------------------------------
    # HANDLE CONGESTION / FAILURES (req. #19, #20, #23)
    # ------------------------------------------------------------------
    def _crane_downtime(self, crane):
        with crane.resource.request() as req:
            yield req
            yield self.env.timeout(self.py_random.uniform(0.5, 2.0))

    def _charger_downtime(self, station):
        with station.resource.request() as req:
            yield req
            yield self.env.timeout(self.py_random.uniform(0.5, 2.0))

    def _road_closure(self, u: str, v: str):
        self.network.set_blocked(u, v, EdgeMode.ROAD, True)
        self.event_log.log(self.env.now, EventType.ROUTE_BLOCKED, f"{u}-{v}", mode="road")
        yield self.env.timeout(self.py_random.uniform(0.5, 3.0))
        self.network.set_blocked(u, v, EdgeMode.ROAD, False)
        self.event_log.log(self.env.now, EventType.ROUTE_REPLANNED, f"{u}-{v}", mode="road", reopened=True)

    def _waterway_closure(self, u: str, v: str):
        self.network.set_blocked(u, v, EdgeMode.RIVER, True)
        self.event_log.log(self.env.now, EventType.ROUTE_BLOCKED, f"{u}-{v}", mode="river")
        yield self.env.timeout(self.py_random.uniform(1.0, 5.0))
        self.network.set_blocked(u, v, EdgeMode.RIVER, False)
        self.event_log.log(self.env.now, EventType.ROUTE_REPLANNED, f"{u}-{v}", mode="river", reopened=True)

    def _weather_disruption(self):
        duration = self.py_random.uniform(1.0, 4.0)
        self.event_log.log(self.env.now, EventType.WEATHER_DISRUPTION, "NETWORK", duration_h=duration)
        for u, v, mode in (FIRST_MILE, LAST_MILE):
            self.network.set_congestion(u, v, EdgeMode.ROAD, 0.9)
        yield self.env.timeout(duration)
        for u, v in (FIRST_MILE, LAST_MILE):
            self.traffic_model._recompute_congestion(u, v, EdgeMode.ROAD)

    def _failure_injector(self):
        while True:
            yield self.env.timeout(1.0)
            if self.py_random.random() < self.config.road_closure_prob_per_hour:
                u, v = self.py_random.choice([FIRST_MILE, LAST_MILE])
                self.env.process(self._road_closure(u, v))
            if self.py_random.random() < self.config.waterway_closure_prob_per_hour:
                self.env.process(self._waterway_closure(*WATERWAY_LEG))
            if self.py_random.random() < self.config.weather_disruption_prob_per_hour:
                self.env.process(self._weather_disruption())
            for terminal in self.terminals.values():
                for crane in terminal.cranes:
                    if self.py_random.random() < self.config.crane_failure_prob_per_hour:
                        self.env.process(self._crane_downtime(crane))
            for station in self.charging_network.stations.values():
                if self.py_random.random() < self.config.charger_failure_prob_per_hour:
                    self.env.process(self._charger_downtime(station))

    # ------------------------------------------------------------------
    def run(self) -> None:
        """Runs the full pipeline end to end for `config.sim_duration_hours`."""
        self.build()
        self.env.process(self._dispatch_monitor())
        for container in self.containers:
            self.env.process(self._container_lifecycle(container))
        if self.config.enable_failures:
            self.env.process(self._failure_injector())
        self.env.run(until=self.config.sim_duration_hours)

    # ------------------------------------------------------------------
    # GENERATE REPORT
    # ------------------------------------------------------------------
    def summary(self) -> dict:
        delivered = self.container_tracker.delivered()
        avg_transit = self.container_tracker.average_transit_time()
        energy_by_source = self.energy_engine.total_by_source()
        emissions_total = self.emissions_model.total()
        cost_breakdown = self.economic_engine.breakdown(len(self.containers))
        congestion = self.traffic_model.network_average_congestion()
        faults = sum(len(v.fault_history) for v in self.fleet_manager.all_vehicles())
        empty_km = self.fleet_manager.total_empty_km()

        return {
            "containers_total": len(self.containers),
            "containers_delivered": len(delivered),
            "delivery_rate_pct": 100.0 * len(delivered) / max(1, len(self.containers)),
            "average_delivery_time_h": avg_transit or 0.0,
            "truck_utilisation_pct": self.fleet_manager.fleet_utilisation_pct("truck"),
            "barge_utilisation_pct": self.fleet_manager.fleet_utilisation_pct("barge"),
            "total_energy_kwh_equivalent": self.energy_engine.total_kwh_equivalent(),
            "total_operating_cost_gbp": cost_breakdown["total_operating_cost_gbp"],
            "cost_per_container_gbp": cost_breakdown["cost_per_container_gbp"],
            "total_co2_kg": emissions_total.total_co2_kg,
            "average_road_congestion_pct": congestion * 100,
            "vehicle_faults": faults,
            "empty_km": empty_km,
            "port_congestion_index": self.port.congestion_index(self.config.sim_duration_hours)["index"] if self.port else None,
            "terminal_status": [t.status() for t in self.terminals.values()],
            "warehouse_status": [w.status() for w in self.warehouses.values()],
            "energy_by_source": energy_by_source,
            "cost_breakdown": cost_breakdown,
        }
