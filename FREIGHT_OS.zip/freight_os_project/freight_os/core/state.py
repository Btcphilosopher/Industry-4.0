"""
core/state.py

The central digital-twin registry. At any simulation timestep this answers
(req. #24):

    WHERE IS EVERY VEHICLE?
    WHERE IS EVERY CONTAINER?
    WHERE IS EVERY SHIPMENT?
    WHAT IS EVERY TERMINAL DOING?
    WHERE ARE THE BOTTLENECKS?
    HOW MUCH ENERGY IS AVAILABLE?
    WHAT IS THE NETWORK CAPACITY?

It deliberately holds plain references (typed `Any` to avoid import cycles
between vehicles/containers/ports and core) rather than copies, so it is
always live — querying it never returns stale data mid-simulation.
"""
from __future__ import annotations

from typing import Any, Dict


class DigitalTwinState:
    def __init__(self) -> None:
        self.vehicles: Dict[str, Any] = {}
        self.containers: Dict[str, Any] = {}
        self.terminals: Dict[str, Any] = {}
        self.warehouses: Dict[str, Any] = {}
        self.network: Any = None

    # -- registration -----------------------------------------------------
    def register_vehicle(self, vehicle: Any) -> None:
        self.vehicles[vehicle.vehicle_id] = vehicle

    def register_container(self, container: Any) -> None:
        self.containers[container.container_id] = container

    def register_terminal(self, terminal: Any) -> None:
        self.terminals[terminal.terminal_id] = terminal

    def register_warehouse(self, warehouse: Any) -> None:
        self.warehouses[warehouse.warehouse_id] = warehouse

    def set_network(self, network: Any) -> None:
        self.network = network

    # -- digital twin queries ----------------------------------------------
    def where_is_vehicle(self, vehicle_id: str) -> dict:
        v = self.vehicles[vehicle_id]
        return {
            "vehicle_id": vehicle_id,
            "position": v.position,
            "state": v.operating_state.value if hasattr(v.operating_state, "value") else v.operating_state,
            "payload_containers": [c.container_id for c in getattr(v, "payload", [])],
        }

    def where_is_container(self, container_id: str) -> dict:
        c = self.containers[container_id]
        return {
            "container_id": container_id,
            "current_location": c.current_location,
            "current_vehicle": c.current_vehicle,
            "status": c.status.value if hasattr(c.status, "value") else c.status,
        }

    def vehicle_snapshot(self) -> list[dict]:
        return [self.where_is_vehicle(vid) for vid in self.vehicles]

    def container_snapshot(self) -> list[dict]:
        return [self.where_is_container(cid) for cid in self.containers]

    def terminal_snapshot(self) -> list[dict]:
        return [t.status() for t in self.terminals.values()]

    def network_capacity_snapshot(self) -> dict:
        if self.network is None:
            return {}
        return self.network.capacity_summary()

    def full_snapshot(self, timestamp: float) -> dict:
        """One dict answering all seven digital-twin questions at once."""
        return {
            "timestamp": timestamp,
            "vehicles": self.vehicle_snapshot(),
            "containers": self.container_snapshot(),
            "terminals": self.terminal_snapshot(),
            "network_capacity": self.network_capacity_snapshot(),
        }
