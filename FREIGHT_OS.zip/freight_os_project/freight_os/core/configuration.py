"""
core/configuration.py

Central, reproducible simulation configuration.

Every scenario is defined entirely by a `SimulationConfig`. Two runs created
with the same config (including `seed`) must produce identical results —
this is what `record_config()` captures for reproducibility (req. #43).
"""
from __future__ import annotations

import random
from enum import Enum
from typing import Optional

import numpy as np
from pydantic import BaseModel, ConfigDict, Field

from freight_os import __version__ as SOFTWARE_VERSION


class EnergySource(str, Enum):
    ELECTRIC = "electric"
    HYDROGEN = "hydrogen"
    DIESEL = "diesel"
    HYBRID = "hybrid"


class TruckType(str, Enum):
    TRACTOR_UNIT = "tractor_unit"
    RIGID_TRUCK = "rigid_truck"
    CONTAINER_CHASSIS = "container_chassis"


class BargeType(str, Enum):
    CONTAINER_BARGE = "container_barge"
    RIVER_BARGE = "river_barge"
    CANAL_VESSEL = "canal_vessel"
    SHORT_SEA_VESSEL = "short_sea_vessel"


class HydrogenPathway(str, Enum):
    """Where the hydrogen actually comes from — used so H2 is never assumed carbon-free."""
    GREY = "grey"   # steam methane reforming, high upstream CO2
    BLUE = "blue"    # SMR + carbon capture, lower upstream CO2
    GREEN = "green"  # electrolysis from renewable electricity, near-zero upstream CO2


class SimulationConfig(BaseModel):
    """
    Reproducible configuration for one FREIGHT.OS scenario run.

    Pass the same config (same `seed`) to get bit-for-bit identical
    simulation outcomes — this is the contract `FreightSimulation` relies on.
    """

    scenario_name: str = "demo_first_mile_last_mile"
    seed: int = 42
    software_version: str = SOFTWARE_VERSION

    # --- simulation horizon -------------------------------------------------
    sim_duration_hours: float = 24.0
    time_step_hours: float = 0.05  # granularity used by periodic monitors

    # --- demo network sizing (req. #45) -------------------------------------
    num_containers: int = 100
    num_trucks: int = 20
    num_barges: int = 5
    num_terminals: int = 2
    num_warehouses: int = 1

    # --- vehicle mix ----------------------------------------------------------
    truck_energy_mix: dict[EnergySource, float] = Field(
        default_factory=lambda: {
            EnergySource.ELECTRIC: 0.5,
            EnergySource.DIESEL: 0.4,
            EnergySource.HYDROGEN: 0.1,
        }
    )

    # --- energy prices (£) ----------------------------------------------------
    electricity_price_per_kwh: float = 0.28
    diesel_price_per_litre: float = 1.55
    hydrogen_price_per_kg: float = 9.50

    # --- emissions factors ----------------------------------------------------
    grid_carbon_intensity_kg_co2_per_kwh: float = 0.193  # GB grid average, configurable
    diesel_co2_kg_per_litre: float = 2.68
    diesel_nox_g_per_litre: float = 8.9
    diesel_pm_g_per_litre: float = 0.15
    hydrogen_pathway: HydrogenPathway = HydrogenPathway.GREY
    hydrogen_upstream_co2_kg_per_kg: dict[HydrogenPathway, float] = Field(
        default_factory=lambda: {
            HydrogenPathway.GREY: 10.0,
            HydrogenPathway.BLUE: 3.5,
            HydrogenPathway.GREEN: 0.9,
        }
    )

    # --- terminal / crane capacity ---------------------------------------------
    cranes_per_terminal: int = 3
    gates_per_terminal: int = 2
    berths_per_terminal: int = 2
    yard_slots_per_terminal: int = 400
    crane_cycle_time_minutes: float = 2.5
    lock_capacity_vessels: int = 1
    lock_cycle_time_minutes: float = 20.0

    # --- warehouse capacity ------------------------------------------------
    warehouse_storage_capacity: int = 500
    warehouse_dock_doors: int = 4

    # --- failure model ----------------------------------------------------
    enable_failures: bool = True
    truck_failure_prob_per_trip: float = 0.02
    barge_failure_prob_per_trip: float = 0.01
    crane_failure_prob_per_hour: float = 0.002
    charger_failure_prob_per_hour: float = 0.001
    road_closure_prob_per_hour: float = 0.004
    waterway_closure_prob_per_hour: float = 0.003
    weather_disruption_prob_per_hour: float = 0.004

    # --- economics ----------------------------------------------------------
    driver_labour_cost_per_hour: float = 24.0  # labour-equivalent supervisory cost
    truck_depreciation_per_km: float = 0.18
    barge_depreciation_per_hour: float = 45.0
    maintenance_cost_per_km: float = 0.05
    terminal_handling_cost_per_container: float = 35.0
    warehouse_handling_cost_per_container: float = 12.0
    toll_cost_per_km_road: float = 0.04

    model_config = ConfigDict(use_enum_values=False)

    # ------------------------------------------------------------------
    def make_rng(self) -> np.random.Generator:
        """Deterministic NumPy Generator seeded from this config."""
        return np.random.default_rng(self.seed)

    def seed_stdlib_random(self) -> random.Random:
        """Deterministic stdlib Random instance (used by SimPy processes)."""
        return random.Random(self.seed)

    def record(self) -> dict:
        """
        Snapshot of everything needed to reproduce this run: seed, full
        configuration, and software version (req. #43).
        """
        return {
            "software_version": self.software_version,
            "seed": self.seed,
            "config": self.model_dump(mode="json"),
        }
