"""
core/events.py

Event-driven simulation backbone (req. #25). Every state change in the
digital twin is recorded as an immutable `Event` on the `EventLog`, which
doubles as the audit trail used by analytics/reports.py and dashboard/dashboard.py.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional

import pandas as pd


class EventType(str, Enum):
    VEHICLE_DEPARTED = "VehicleDeparted"
    VEHICLE_ARRIVED = "VehicleArrived"
    CONTAINER_BOOKED = "ContainerBooked"
    CONTAINER_LOADED = "ContainerLoaded"
    CONTAINER_UNLOADED = "ContainerUnloaded"
    CONTAINER_TRANSFERRED = "ContainerTransferred"
    CONTAINER_DELIVERED = "ContainerDelivered"
    TRUCK_DELAYED = "TruckDelayed"
    BARGE_ARRIVED = "BargeArrived"
    BARGE_DEPARTED = "BargeDeparted"
    CRANE_AVAILABLE = "CraneAvailable"
    CRANE_BUSY = "CraneBusy"
    CHARGING_STARTED = "ChargingStarted"
    CHARGING_COMPLETED = "ChargingCompleted"
    REFUELLING_STARTED = "RefuellingStarted"
    REFUELLING_COMPLETED = "RefuellingCompleted"
    MAINTENANCE_REQUIRED = "MaintenanceRequired"
    MAINTENANCE_STARTED = "MaintenanceStarted"
    MAINTENANCE_COMPLETED = "MaintenanceCompleted"
    VEHICLE_FAULT = "VehicleFault"
    ROUTE_BLOCKED = "RouteBlocked"
    ROUTE_REPLANNED = "RouteReplanned"
    GATE_PROCESSED = "GateProcessed"
    TERMINAL_CONGESTED = "TerminalCongested"
    WEATHER_DISRUPTION = "WeatherDisruption"


@dataclass(frozen=True)
class Event:
    timestamp: float  # simulation hours since t=0
    event_type: EventType
    entity_id: str
    details: dict[str, Any] = field(default_factory=dict)


class EventLog:
    """Append-only log of everything that happened in the simulation."""

    def __init__(self) -> None:
        self._events: list[Event] = []

    def log(self, timestamp: float, event_type: EventType, entity_id: str, **details: Any) -> Event:
        evt = Event(timestamp=timestamp, event_type=event_type, entity_id=entity_id, details=details)
        self._events.append(evt)
        return evt

    def __len__(self) -> int:
        return len(self._events)

    def __iter__(self):
        return iter(self._events)

    def by_type(self, event_type: EventType) -> list[Event]:
        return [e for e in self._events if e.event_type == event_type]

    def by_entity(self, entity_id: str) -> list[Event]:
        return [e for e in self._events if e.entity_id == entity_id]

    def to_dataframe(self) -> pd.DataFrame:
        if not self._events:
            return pd.DataFrame(columns=["timestamp", "event_type", "entity_id", "details"])
        return pd.DataFrame(
            [
                {
                    "timestamp": e.timestamp,
                    "event_type": e.event_type.value,
                    "entity_id": e.entity_id,
                    **e.details,
                }
                for e in self._events
            ]
        )
