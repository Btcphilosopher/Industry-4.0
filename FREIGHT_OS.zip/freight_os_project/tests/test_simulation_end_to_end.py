from freight_os.core.configuration import SimulationConfig
from freight_os.core.simulation import FreightSimulation
from freight_os.optimisation.network import BottleneckAnalyzer


def _run(seed: int = 42, hours: float = 18.0, containers: int = 20, trucks: int = 8, barges: int = 3) -> dict:
    config = SimulationConfig(seed=seed, sim_duration_hours=hours, num_containers=containers,
                               num_trucks=trucks, num_barges=barges)
    sim = FreightSimulation(config)
    sim.run()
    return sim.summary()


def test_simulation_runs_end_to_end_and_delivers_containers():
    summary = _run()
    assert summary["containers_total"] == 20
    assert summary["containers_delivered"] >= 1  # at least some containers complete the full journey
    assert summary["total_operating_cost_gbp"] > 0
    assert summary["total_energy_kwh_equivalent"] > 0


def test_same_seed_is_deterministic():
    summary_a = _run(seed=7)
    summary_b = _run(seed=7)
    assert summary_a["containers_delivered"] == summary_b["containers_delivered"]
    assert summary_a["total_operating_cost_gbp"] == summary_b["total_operating_cost_gbp"]
    assert summary_a["total_energy_kwh_equivalent"] == summary_b["total_energy_kwh_equivalent"]


def test_different_seed_can_change_outcome():
    # not a strict requirement that outcomes differ, but the RNG stream must differ
    config_a = SimulationConfig(seed=1, sim_duration_hours=8, num_containers=15, num_trucks=6, num_barges=2)
    config_b = SimulationConfig(seed=2, sim_duration_hours=8, num_containers=15, num_trucks=6, num_barges=2)
    sim_a = FreightSimulation(config_a)
    sim_a.build()
    sim_b = FreightSimulation(config_b)
    sim_b.build()
    weights_a = [c.weight_kg for c in sim_a.containers]
    weights_b = [c.weight_kg for c in sim_b.containers]
    assert weights_a != weights_b


def test_bottleneck_analyzer_returns_grounded_findings():
    config = SimulationConfig(seed=42, sim_duration_hours=10, num_containers=20, num_trucks=8, num_barges=3)
    sim = FreightSimulation(config)
    sim.run()
    findings = BottleneckAnalyzer(sim).analyse()
    # every finding must reference a real simulation quantity, not be fabricated
    for f in findings:
        assert isinstance(f.value, (int, float))
        assert f.recommendation
