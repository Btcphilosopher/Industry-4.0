from freight_os.network.graph import EdgeMode, FreightNetwork, NodeType
from freight_os.network.routes import RouteOptimizer


def _small_network() -> FreightNetwork:
    net = FreightNetwork()
    net.add_node("A", NodeType.FACTORY)
    net.add_node("B", NodeType.TERMINAL)
    net.add_node("C", NodeType.WAREHOUSE)
    net.add_edge("A", "B", EdgeMode.ROAD, distance_km=50, base_travel_time_h=0.8, capacity=10, toll_per_km=0.05)
    net.add_edge("B", "C", EdgeMode.ROAD, distance_km=30, base_travel_time_h=0.5, capacity=10, toll_per_km=0.05)
    net.add_edge("A", "C", EdgeMode.RAIL, distance_km=110, base_travel_time_h=1.5, capacity=5, risk=0.005)
    return net


def test_find_route_returns_valid_path():
    net = _small_network()
    opt = RouteOptimizer(net)
    route = opt.find_route("A", "C", objective="time")
    assert route is not None
    assert route.nodes[0] == "A" and route.nodes[-1] == "C"
    assert route.total_time_h > 0


def test_compare_routes_ranks_multiple_candidates():
    net = _small_network()
    opt = RouteOptimizer(net)
    options = opt.compare_routes("A", "C")
    assert len(options) >= 2
    assert options == sorted(options, key=lambda o: o.score)


def test_blocked_edge_is_excluded():
    net = _small_network()
    net.set_blocked("A", "B", EdgeMode.ROAD, True)
    opt = RouteOptimizer(net)
    route = opt.find_route("A", "C", objective="time")
    assert route is not None
    assert "B" not in route.nodes  # only the direct rail route remains viable
