from freight_os.core.configuration import EnergySource, SimulationConfig
from freight_os.energy.battery import Battery
from freight_os.energy.engine import EnergyEngine
from freight_os.economics.costs import EconomicEngine
from freight_os.emissions.emissions import EmissionsModel
from freight_os.vehicles.truck import Truck


def _config() -> SimulationConfig:
    return SimulationConfig(seed=42, sim_duration_hours=1)


def test_battery_discharge_and_charge_roundtrip():
    b = Battery(capacity_kwh=400.0, soc=1.0, charge_power_kw=100.0)
    b.discharge(100.0)
    assert 0.74 < b.soc < 0.76
    time_to_full = b.time_to_charge_h(1.0)
    b.charge(100.0)
    assert b.soc == 1.0
    assert time_to_full > 0


def test_energy_engine_tracks_diesel_and_electric_separately():
    config = _config()
    engine = EnergyEngine(config=config)
    diesel_truck = Truck(vehicle_id="TRK-D", vehicle_class="truck", energy_source=EnergySource.DIESEL)
    diesel_truck.energy_state = {"fuel_litres": 600.0, "low_energy": False}
    electric_truck = Truck(vehicle_id="TRK-E", vehicle_class="truck", energy_source=EnergySource.ELECTRIC)
    electric_truck.energy_state = {"battery": Battery(capacity_kwh=450.0), "low_energy": False}

    engine.consume_truck(diesel_truck, distance_km=100.0)
    engine.consume_truck(electric_truck, distance_km=100.0)

    by_source = engine.total_by_source()
    assert "diesel" in by_source and "electric" in by_source
    assert engine.total_cost_gbp() > 0


def test_emissions_distinguish_tailpipe_from_upstream():
    config = _config()
    engine = EnergyEngine(config=config)
    diesel_truck = Truck(vehicle_id="TRK-D", vehicle_class="truck", energy_source=EnergySource.DIESEL)
    diesel_truck.energy_state = {"fuel_litres": 600.0, "low_energy": False}
    electric_truck = Truck(vehicle_id="TRK-E", vehicle_class="truck", energy_source=EnergySource.ELECTRIC)
    electric_truck.energy_state = {"battery": Battery(capacity_kwh=450.0), "low_energy": False}
    engine.consume_truck(diesel_truck, distance_km=100.0)
    engine.consume_truck(electric_truck, distance_km=100.0)

    model = EmissionsModel(config=config, energy_engine=engine)
    by_source = model.by_source()
    assert by_source["diesel"].tailpipe_co2_kg > 0
    assert by_source["diesel"].upstream_co2_kg == 0
    assert by_source["electric"].tailpipe_co2_kg == 0
    assert by_source["electric"].upstream_co2_kg > 0  # never assumed carbon-free


def test_economic_engine_cost_per_container():
    config = _config()
    engine = EnergyEngine(config=config)
    econ = EconomicEngine(config=config, energy_engine=engine)
    econ.total_truck_km = 500.0
    econ.total_vehicle_hours = 10.0
    econ.terminal_containers_handled = 20
    econ.warehouse_containers_handled = 20
    breakdown = econ.breakdown(num_containers=20)
    assert breakdown["total_operating_cost_gbp"] > 0
    assert breakdown["cost_per_container_gbp"] == breakdown["total_operating_cost_gbp"] / 20
