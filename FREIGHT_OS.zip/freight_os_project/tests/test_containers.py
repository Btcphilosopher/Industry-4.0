from freight_os.containers.container import Container, ContainerStatus


def test_container_lifecycle_transitions():
    c = Container(container_id="CONT-00000001", origin="FACTORY", destination="WAREHOUSE",
                   weight_kg=12000, volume_m3=28, booked_at=0.0)
    assert c.status == ContainerStatus.BOOKED
    assert c.current_location == "FACTORY"

    c.transition(1.0, ContainerStatus.WAITING, location="FACTORY")
    c.transition(1.4, ContainerStatus.LOADED, vehicle_id="TRK-001", mode="road")
    c.transition(1.4, ContainerStatus.IN_TRANSIT, vehicle_id="TRK-001")
    c.transition(2.0, ContainerStatus.AT_TERMINAL, location="PORT_TERMINAL")
    c.transition(2.0, ContainerStatus.DELIVERED, location="WAREHOUSE")

    assert c.status == ContainerStatus.DELIVERED
    assert c.delivered_at == 2.0
    assert c.transit_time_hours == 2.0
    assert len(c.history) == 5
    assert c.history[0].from_location == "FACTORY"
