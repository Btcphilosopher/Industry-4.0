from freight_os.maintenance.predictive import MaintenanceEngine, VehicleWearRecord, StatisticalWeibullPredictor


def test_wear_index_increases_with_usage():
    fresh = VehicleWearRecord(vehicle_id="V1")
    worn = VehicleWearRecord(vehicle_id="V2", mileage_km=250_000, operating_hours=18_000, energy_cycles=1800, fault_count=4)
    assert worn.component_wear_index() > fresh.component_wear_index()


def test_predictor_flags_worn_vehicle_as_higher_risk():
    predictor = StatisticalWeibullPredictor()
    fresh = predictor.predict(VehicleWearRecord(vehicle_id="V1"))
    worn = predictor.predict(VehicleWearRecord(vehicle_id="V2", mileage_km=280_000, operating_hours=19_000,
                                                energy_cycles=1900, fault_count=5))
    assert worn.maintenance_probability_next_100h >= fresh.maintenance_probability_next_100h
    assert worn.remaining_useful_life_hours <= fresh.remaining_useful_life_hours


def test_maintenance_engine_fleet_risk_report_is_ranked():
    engine = MaintenanceEngine()
    engine.track("V1")
    engine.track("V2")
    engine.records["V2"].mileage_km = 300_000
    engine.records["V2"].operating_hours = 20_000
    report = engine.fleet_risk_report()
    assert report[0].vehicle_id == "V2"
