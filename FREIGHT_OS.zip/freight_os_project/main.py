#!/usr/bin/env python3
"""
FREIGHT.OS — first demonstration (project prompt req. #45).

Runs the canonical intermodal network:

    FACTORY -> [autonomous truck] -> PORT TERMINAL -> [container yard] ->
    [autonomous barge] -> INLAND TERMINAL -> [autonomous truck] -> WAREHOUSE

with 100 containers, 20 trucks, 5 barges, 2 terminals and 1 warehouse over
a 24-hour simulated day (seed = 42, fully reproducible), then prints the
report and writes CSV/JSON/Parquet/HTML exports plus an interactive
dashboard.

Usage:
    python main.py                     # run the default demo scenario
    python main.py --hours 12          # shorter run
    python main.py --seed 7            # different reproducible scenario
    python main.py --no-dashboard      # skip the Plotly HTML dashboard
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from freight_os.core.configuration import SimulationConfig
from freight_os.core.simulation import FreightSimulation
from freight_os.analytics.reports import ReportGenerator
from freight_os.optimisation.network import BottleneckAnalyzer
from freight_os.optimisation.routing import compare_and_explain


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="FREIGHT.OS demonstration run")
    p.add_argument("--hours", type=float, default=24.0, help="simulation horizon in hours")
    p.add_argument("--seed", type=int, default=42, help="reproducibility seed")
    p.add_argument("--containers", type=int, default=100)
    p.add_argument("--trucks", type=int, default=20)
    p.add_argument("--barges", type=int, default=5)
    p.add_argument("--out", type=str, default="output", help="output directory for reports")
    p.add_argument("--no-dashboard", action="store_true", help="skip building the Plotly dashboard")
    p.add_argument("--track", type=str, default=None, help="print the tracking record for one container id and exit")
    return p.parse_args()


def print_summary(summary: dict) -> None:
    print("\n" + "=" * 64)
    print(" FREIGHT.OS — SIMULATION SUMMARY")
    print("=" * 64)
    print(f" Containers delivered:     {summary['containers_delivered']} / {summary['containers_total']} "
          f"({summary['delivery_rate_pct']:.1f}%)")
    print(f" Average delivery time:    {summary['average_delivery_time_h']:.2f} h")
    print(f" Truck fleet utilisation:  {summary['truck_utilisation_pct']:.1f}%")
    print(f" Barge fleet utilisation:  {summary['barge_utilisation_pct']:.1f}%")
    print(f" Total energy consumed:    {summary['total_energy_kwh_equivalent']:,.0f} kWh-equivalent")
    print(f" Total operating cost:     £{summary['total_operating_cost_gbp']:,.2f}")
    print(f" Cost per container:       £{summary['cost_per_container_gbp']:,.2f}")
    print(f" Total CO2:                {summary['total_co2_kg']:,.0f} kg")
    print(f" Average road congestion:  {summary['average_road_congestion_pct']:.1f}%")
    print(f" Port congestion index:    {(summary['port_congestion_index'] or 0)*100:.1f}%")
    print(f" Vehicle faults recorded:  {summary['vehicle_faults']}")
    print(f" Empty (repositioning) km: {summary['empty_km']:.0f} km")
    print("-" * 64)
    for t in summary["terminal_status"]:
        print(f" Terminal {t['terminal_id']:<16} yard {t['yard_utilisation']*100:5.1f}%  "
              f"gate {t['gate_utilisation']*100:5.1f}%  containers handled {t['containers_handled']:>4}  "
              f"avg truck turnaround {t['average_truck_turnaround_h']:.2f} h")
    for w in summary["warehouse_status"]:
        print(f" Warehouse {w['warehouse_id']:<15} storage {w['storage_utilisation']*100:5.1f}%  "
              f"received {w['received_count']:>4}")
    print("=" * 64 + "\n")


def main() -> int:
    args = parse_args()

    config = SimulationConfig(
        seed=args.seed,
        sim_duration_hours=args.hours,
        num_containers=args.containers,
        num_trucks=args.trucks,
        num_barges=args.barges,
    )

    print(f"FREIGHT.OS — building & running scenario '{config.scenario_name}' "
          f"(seed={config.seed}, {config.sim_duration_hours:.0f}h horizon)...")

    sim = FreightSimulation(config)
    sim.build()

    print("\nRoute optimiser explanation for FACTORY -> WAREHOUSE:\n")
    print(compare_and_explain(sim.route_optimizer, "FACTORY", "WAREHOUSE"))

    sim.run()

    if args.track:
        record = sim.container_tracker.search(args.track, sim.env.now)
        print(json.dumps(record, indent=2, default=str))
        return 0

    summary = sim.summary()
    print_summary(summary)

    findings = BottleneckAnalyzer(sim).analyse()
    if findings:
        print("Bottleneck analysis (derived from this run's simulated utilisation/queueing):")
        for f in findings:
            print(f"  - [{f.area}] {f.recommendation}")
    else:
        print("No bottlenecks exceeded threshold in this run.")

    out_dir = Path(args.out)
    report_gen = ReportGenerator(sim)
    paths = report_gen.export_all(str(out_dir))
    print(f"\nReports written to: {out_dir.resolve()}")
    for kind, path in paths.items():
        print(f"  {kind:<20} {path}")

    if not args.no_dashboard:
        from freight_os.dashboard.dashboard import build_dashboard
        dash_path = build_dashboard(sim, str(out_dir / "dashboard.html"))
        print(f"  {'dashboard':<20} {dash_path}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
