# FREIGHT.OS

**A modular simulation, digital-twin and optimisation platform for autonomous
intermodal freight — trucks, barges, rail, ports, terminals, warehouses and
energy infrastructure, modelled as one continuously simulated logistics
system.**

> ⚠️ **Safety boundary.** FREIGHT.OS is a *simulation and digital-twin*
> platform only. Nothing in this codebase issues commands to a real vehicle,
> vessel, crane, or piece of port/marine equipment. Every "autonomous"
> decision is a simulated abstraction:
> `Perceived Environment -> Planning -> Decision -> Simulated Action`
> (see `freight_os/autonomy/decision_model.py`).

---

## What this is

FREIGHT.OS simulates freight moving through an entire intermodal network —
not one autonomous vehicle in isolation — and answers:

> *How can freight move from origin to destination with the minimum
> combination of time, cost, energy, congestion and operational risk?*

It is a coherent, event-driven simulation built on **SimPy**, with a
**NetworkX** graph for the freight network, **SciPy**/linear programming for
optimisation, and an optional **scikit-learn**-backed ML layer that the core
simulator never depends on.

## Quickstart

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

python main.py
```

This runs the **first demonstration** (project spec §45): 100 containers,
20 autonomous trucks, 5 autonomous barges, 2 terminals and 1 warehouse over a
24-hour simulated day, seeded (`--seed 42`) for full reproducibility. It
prints a summary, a route-optimiser explanation, bottleneck findings derived
from the run, then writes:

```
output/report.json         # full report: summary, bottlenecks, maintenance risk
output/report.html         # print-ready HTML report
output/containers.csv/.parquet
output/vehicles.csv/.parquet
output/events.csv          # full event log (req. #25)
output/dashboard.html      # interactive Plotly digital-twin dashboard
```

Useful flags:

```bash
python main.py --hours 12 --seed 7          # shorter, different reproducible run
python main.py --trucks 40 --barges 10      # bigger fleet — see optimisation/fleet.py's
                                             # What-If engine for a scripted A/B version
python main.py --track CONT-00000042        # print one container's tracking record and exit
python main.py --no-dashboard               # skip the Plotly HTML build (faster)
```

Run the tests:

```bash
pip install pytest
pytest tests/ -v
```

## The demonstration network

```
FACTORY --[autonomous truck]--> PORT_TERMINAL --[container yard + cranes]-->
  --[autonomous barge]--> INLAND_TERMINAL --[autonomous truck]--> WAREHOUSE
```

Trucks and barges run genuine SimPy processes with resource contention
(gates, berths, cranes, yard slots, lock capacity) — nothing is precomputed.
Every leg, including the **empty return** each vehicle makes to reposition
itself for its next job, is simulated and costed (this is also how
`empty_km` / underutilisation are measured for req. #15).

At the default settings, the **barge corridor (5 barges) is the throughput
bottleneck** for a 24h horizon — not every container completes the full
journey in one simulated day. This is intentional: it is a genuine,
simulation-derived finding (see the bottleneck/backlog output), not a bug,
and it's exactly the kind of thing `optimisation/network.py`'s
`BottleneckAnalyzer` and `WhatIfEngine` (req. #37/#38) exist to surface —
try `python main.py --barges 10` or a longer `--hours` and compare.

## Project structure

Mirrors the brief's spec exactly:

```
freight_os/
├── core/            simulation.py (orchestrator), events.py, state.py (digital twin), configuration.py
├── vehicles/         truck.py, barge.py, rail.py, fleet.py (+ base.py: AutonomousVehicle)
├── containers/        container.py (digital twin), tracking.py (search/ETA)
├── network/           graph.py, roads.py (traffic/BPR), waterways.py (locks/draft), routes.py (RouteOptimizer)
├── ports/              port.py, terminal.py, cranes.py, yard.py
├── warehouses/         warehouse.py
├── autonomy/            planner.py, dispatcher.py (DispatchEngine), decision_model.py (Perceive→Plan→Decide)
├── energy/               battery.py, hydrogen.py, charging.py, engine.py (EnergyEngine)
├── optimisation/          routing.py, fleet.py, terminal.py, network.py (FreightOptimizer, BottleneckAnalyzer, WhatIfEngine)
├── maintenance/            predictive.py (MaintenanceEngine, statistical + ML-ready)
├── economics/               costs.py (EconomicEngine)
├── emissions/                emissions.py (tailpipe vs upstream CO2/NOx/PM)
├── ml/                        eta.py, demand.py, maintenance.py (optional, sklearn with NumPy fallback)
├── dashboard/                  dashboard.py (Plotly digital-twin dashboard)
├── analytics/                   reports.py (CSV/JSON/Parquet/HTML export)
├── data/                        (sample_config.json)
└── tests/
```

## Key design decisions worth knowing

- **Deterministic by construction.** Every scenario is a `SimulationConfig`
  (Pydantic) with a `seed`; `config.record()` captures the full config +
  software version for exact reproducibility (req. #43). Two runs built from
  the same config produce identical KPIs — see `tests/test_simulation_end_to_end.py`.
- **Vehicles never teleport.** `FleetManager` only ever returns a vehicle
  that is physically at the requested node; every reposition, including
  empty-return legs, is a simulated `travel_leg`. This is what makes
  "empty miles" and fleet-balancing findings meaningful rather than assumed.
- **Route-optimiser cost vs. fleet-wide cost are two different numbers, on
  purpose.** `RouteOptimizer`/`optimisation/routing.py` produce a fast,
  single-shipment cost/time/energy/reliability estimate used to *select and
  explain* a route (req. #5's worked example). The simulation's own
  `EconomicEngine`/`EnergyEngine` (fed by actually-simulated legs, crane
  cycles, congestion, and failures) produce the authoritative fleet-wide
  totals in the final report. Don't expect them to match to the pound —
  planning estimates and realised outcomes diverging is itself realistic.
- **Electricity and hydrogen are never assumed carbon-free.**
  `emissions/emissions.py` always reports tailpipe (zero, for EV/H2) *and*
  upstream emissions (grid carbon intensity; hydrogen production pathway —
  grey/blue/green, configurable) separately.
- **Statistical-first, ML-ready.** `maintenance/predictive.py` ships a
  Weibull hazard model behind a `FailurePredictor` protocol;
  `ml/maintenance.py`'s `MLFailurePredictor` implements the same protocol
  and can be swapped in with zero other changes once you have failure-labelled
  data to fit it on. Same pattern for ETA (`ml/eta.py`) and demand
  (`ml/demand.py`) — both fall back to plain NumPy regression if
  scikit-learn isn't installed, so the core simulator has no hard ML dependency.
- **Known simplifications** (documented rather than hidden): diesel and
  hydrogen vehicles track fuel/H2 level but this build does not yet gate
  dispatch on it or route them to refuel (only electric vehicles fully use
  the charging-station process) — over a much longer run than the 24h demo,
  tank levels could go negative. Rail (`vehicles/rail.py`) is modelled as a
  scheduled terminal-to-terminal transfer rather than link-by-link motion,
  which is the right level of detail for intermodal comparison but means it
  isn't wired into the demo network's dispatch loop yet — `RouteOptimizer`
  and `EnergyEngine` both already support it for anyone extending the demo
  network with a rail edge.

## Scaling beyond the demo

The same `FreightSimulation` class handles 10 vehicles or 10,000+: SimPy's
event queue only advances on state changes (not fixed time steps), and every
resource (gates, cranes, chargers, locks) is a `simpy.Resource` with a
capacity, so cost scales with *activity*, not with a hardcoded per-tick loop
over the whole fleet. For very large batch/parallel scenario sweeps (req.
#42: parallel scenario execution), run multiple `FreightSimulation` instances
in separate processes — each is fully self-contained and holds no global state.

## Extending the network

Add nodes/edges to `FreightNetwork` (`network/graph.py`), give the
`RouteOptimizer` a new origin/destination pair, and add a matching branch in
`FreightSimulation._build_demo_network`/`_generate_demand` — everything
downstream (dispatch, terminals, energy, cost, emissions, dashboard,
reporting) already generalises over however many nodes/edges/vehicles exist.
