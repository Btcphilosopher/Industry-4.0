import React from 'react';
import { 
  History, 
  Play, 
  Pause, 
  RotateCcw, 
  Clock, 
  FastForward, 
  AlertTriangle,
  Flame,
  Activity,
  Zap
} from 'lucide-react';
import { SimulationState } from '../services/simulation.service';

interface ReplayViewProps {
  state: SimulationState;
  onSetSimTime: (seconds: number) => void;
  onTogglePlay: () => void;
}

export const ReplayView: React.FC<ReplayViewProps> = ({
  state,
  onSetSimTime,
  onTogglePlay
}) => {
  const currentSeconds = state.simTimeSeconds;
  const startSeconds = 8 * 3600; // 08:00
  const endSeconds = 24 * 3600;  // 24:00

  const historicalEvents = [
    { time: '09:15', label: 'EAF-01 Scrap Batch #1 Charged (88.5t)', type: 'INFO' },
    { time: '11:40', label: 'VD-01 Deep Vacuum Achieved (<0.85 mbar)', type: 'INFO' },
    { time: '13:20', label: 'FORGE-01 30MN Press First Ingot Reduction', type: 'INFO' },
    { time: '14:28', label: 'CNC-04 Tool T14 Wear Advisory Triggered', type: 'WARN' }
  ];

  return (
    <div className="h-full flex flex-col bg-steel-950 p-4 gap-4 overflow-y-auto select-none">
      {/* Header */}
      <div className="bg-steel-900 border border-steel-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-zinc-700 text-zinc-300 text-xs font-mono font-bold border border-zinc-600">
              FORENSIC DIGITAL TWIN REPLAY
            </span>
            <h2 className="text-lg font-bold font-industrial text-zinc-100">
              Shift Incident Time Machine & Telemetry Sync
            </h2>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Scrub back through continuous 24-hour plant operations to investigate metallurgical anomalies, trips, or bottlenecks.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="font-mono-num text-xl font-bold text-sky-400 bg-steel-950 px-3 py-1 rounded-xl border border-steel-800">
            {state.simTimeString}
          </div>
        </div>
      </div>

      {/* Main Timeline Scrubber */}
      <div className="bg-steel-900 border border-steel-800 rounded-2xl p-6 space-y-6">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold font-industrial uppercase text-zinc-300 flex items-center gap-2">
            <Clock className="w-4 h-4 text-sky-400" />
            24-Hour Forensic Master Time Track
          </h3>
          <div className="text-xs font-mono text-zinc-400">
            08:00:00 (Shift Start) → 24:00:00 (Night Turn)
          </div>
        </div>

        {/* Large Slider */}
        <div className="space-y-2">
          <input
            type="range"
            min={startSeconds}
            max={endSeconds}
            step="10"
            value={currentSeconds}
            onChange={(e) => onSetSimTime(parseInt(e.target.value, 10))}
            className="w-full accent-sky-500 h-3 bg-steel-950 rounded-lg cursor-pointer border border-steel-700"
          />

          <div className="flex justify-between text-xs font-mono text-zinc-400">
            <span>08:00</span>
            <span>12:00</span>
            <span className="text-sky-400 font-bold">14:32 (Current)</span>
            <span>18:00</span>
            <span>24:00</span>
          </div>
        </div>

        {/* Shift Milestone Markers */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
          {historicalEvents.map((evt, idx) => (
            <div key={idx} className="p-3 bg-steel-950 rounded-xl border border-steel-800 space-y-1">
              <div className="flex justify-between items-center text-xs font-mono">
                <span className="text-sky-400 font-bold">{evt.time}</span>
                <span className={`px-1.5 py-0.2 rounded text-[9px] font-bold ${
                  evt.type === 'WARN' ? 'bg-amber-500/20 text-amber-300' : 'bg-steel-800 text-zinc-400'
                }`}>
                  {evt.type}
                </span>
              </div>
              <p className="text-[11px] text-zinc-300">{evt.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Synchronized Snapshot at Current Replay Point */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 bg-steel-900 rounded-2xl border border-steel-800 space-y-2">
          <div className="text-xs font-bold font-industrial uppercase text-zinc-300 flex items-center gap-2">
            <Flame className="w-4 h-4 text-orange-400" />
            EAF Thermal State @ {state.simTimeString}
          </div>
          <div className="text-2xl font-bold font-mono text-orange-400">
            {state.machines.find(m => m.id === 'EAF-01')?.temperatureC}°C
          </div>
          <div className="text-xs text-zinc-400">
            Arc Power: {state.machines.find(m => m.id === 'EAF-01')?.powerDrawMW.toFixed(1)} MW
          </div>
        </div>

        <div className="p-4 bg-steel-900 rounded-2xl border border-steel-800 space-y-2">
          <div className="text-xs font-bold font-industrial uppercase text-zinc-300 flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-400" />
            Grid Total Load @ {state.simTimeString}
          </div>
          <div className="text-2xl font-bold font-mono text-amber-400">
            {state.energy.totalGridDrawMW.toFixed(1)} MW
          </div>
          <div className="text-xs text-zinc-400">
            Power Factor: {state.energy.powerFactor.toFixed(2)}
          </div>
        </div>

        <div className="p-4 bg-steel-900 rounded-2xl border border-steel-800 space-y-2">
          <div className="text-xs font-bold font-industrial uppercase text-zinc-300 flex items-center gap-2">
            <Activity className="w-4 h-4 text-emerald-400" />
            Robot TCP Speed @ {state.simTimeString}
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-400">
            {state.robot.tcpSpeedMmS} mm/s
          </div>
          <div className="text-xs text-zinc-400">
            Target: {state.robot.targetWaypoint}
          </div>
        </div>
      </div>
    </div>
  );
};
