import React, { useState } from 'react';
import { 
  Cpu, 
  Play, 
  RotateCcw, 
  ShieldCheck, 
  ShieldAlert, 
  Activity, 
  Sliders, 
  CheckCircle2,
  Maximize2,
  Navigation,
  Compass
} from 'lucide-react';
import { SimulationState } from '../services/simulation.service';
import { ROBOT_17_LIMITS, checkWorkspaceLimits, inverseKinematicsNumerical } from '../services/kinematics.service';

interface RoboticsViewProps {
  state: SimulationState;
  onJogJoint: (jointIndex: number, deltaDeg: number) => void;
  onExecuteWaypoint: (waypointId: string) => void;
}

export const RoboticsView: React.FC<RoboticsViewProps> = ({
  state,
  onJogJoint,
  onExecuteWaypoint
}) => {
  const robot = state.robot;
  const workspaceCheck = checkWorkspaceLimits(robot.cartesianTCP);
  const [ikTarget, setIkTarget] = useState({ x: 1400, y: -300, z: 800 });

  const handleRunIK = () => {
    const solvedJoints = inverseKinematicsNumerical(ikTarget, robot.jointAnglesDeg);
    solvedJoints.forEach((val, idx) => {
      onJogJoint(idx, val - robot.jointAnglesDeg[idx]);
    });
  };

  return (
    <div className="h-full flex flex-col bg-steel-950 p-4 gap-4 overflow-y-auto select-none">
      {/* Header */}
      <div className="bg-steel-900 border border-steel-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-sky-500/20 text-sky-400 text-xs font-mono font-bold border border-sky-500/30">
              ROBOTIC MANIPULATOR CELL
            </span>
            <h2 className="text-lg font-bold font-industrial text-zinc-100">
              ROBOT-17 6-Axis Kinematics & Trajectory Engine
            </h2>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Certified ISO 10218-1 offline programming, collision envelope detection, and forward/inverse kinematics.
          </p>
        </div>

        {/* Safety Envelope Status */}
        <div className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border ${
          workspaceCheck.safetyViolation 
            ? 'bg-rose-950/80 text-rose-300 border-rose-700 animate-pulse' 
            : 'bg-emerald-950/80 text-emerald-300 border-emerald-700'
        }`}>
          {workspaceCheck.safetyViolation ? (
            <ShieldAlert className="w-4 h-4 text-rose-400" />
          ) : (
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          )}
          <span className="text-xs font-bold font-mono">
            {workspaceCheck.safetyViolation ? 'SAFETY VIOLATION' : 'ENVELOPE SECURE'}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left: Joint Angles (J1..J6) Jogging Sliders */}
        <div className="bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-steel-800 pb-2">
            <h3 className="text-xs font-bold font-industrial uppercase text-zinc-200 flex items-center gap-2">
              <Sliders className="w-4 h-4 text-sky-400" />
              6-Axis Joint Position Telemetry
            </h3>
            <span className="text-[10px] font-mono text-zinc-400">Deg / Torque</span>
          </div>

          <div className="space-y-4">
            {robot.jointAnglesDeg.map((angle, idx) => {
              const limits = ROBOT_17_LIMITS[idx];
              const torque = robot.jointTorquesNm[idx];
              const temp = robot.jointTempsC[idx];

              return (
                <div key={idx} className="space-y-1.5 bg-steel-950 p-2.5 rounded-xl border border-steel-800">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-bold text-zinc-300 font-mono">J{idx + 1} Joint</span>
                    <div className="flex items-center gap-2 font-mono text-[11px]">
                      <span className="text-zinc-400">{temp}°C</span>
                      <span className="text-amber-400">{torque} Nm</span>
                      <span className="font-bold text-sky-400 w-14 text-right">{angle.toFixed(1)}°</span>
                    </div>
                  </div>

                  {/* Range Slider */}
                  <input
                    type="range"
                    min={limits.min}
                    max={limits.max}
                    step="0.5"
                    value={angle}
                    onChange={(e) => {
                      const newAngle = parseFloat(e.target.value);
                      onJogJoint(idx, newAngle - angle);
                    }}
                    className="w-full accent-sky-500 h-1.5 bg-steel-800 rounded-lg cursor-pointer"
                  />

                  <div className="flex justify-between text-[10px] font-mono text-zinc-400">
                    <span>{limits.min}°</span>
                    <div className="flex gap-1">
                      <button
                        onClick={() => onJogJoint(idx, -5)}
                        className="px-1.5 py-0.5 bg-steel-800 hover:bg-steel-700 text-zinc-300 rounded text-[9px]"
                      >
                        -5°
                      </button>
                      <button
                        onClick={() => onJogJoint(idx, 5)}
                        className="px-1.5 py-0.5 bg-steel-800 hover:bg-steel-700 text-zinc-300 rounded text-[9px]"
                      >
                        +5°
                      </button>
                    </div>
                    <span>{limits.max}°</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Center: Tool Center Point (TCP) & Inverse Kinematics Calculator */}
        <div className="bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-steel-800 pb-2">
            <h3 className="text-xs font-bold font-industrial uppercase text-zinc-200 flex items-center gap-2">
              <Compass className="w-4 h-4 text-teal-400" />
              Cartesian Tool Center Point (TCP)
            </h3>
            <span className="text-[10px] font-mono text-emerald-400">{robot.tcpSpeedMmS} mm/s</span>
          </div>

          {/* Real-time TCP Position Display */}
          <div className="grid grid-cols-3 gap-2">
            <div className="p-3 bg-steel-950 rounded-xl border border-steel-800 text-center">
              <div className="text-[10px] font-mono text-zinc-400 uppercase">X Coord</div>
              <div className="text-base font-bold font-mono-num text-zinc-100 mt-0.5">
                {robot.cartesianTCP.x} mm
              </div>
            </div>
            <div className="p-3 bg-steel-950 rounded-xl border border-steel-800 text-center">
              <div className="text-[10px] font-mono text-zinc-400 uppercase">Y Coord</div>
              <div className="text-base font-bold font-mono-num text-zinc-100 mt-0.5">
                {robot.cartesianTCP.y} mm
              </div>
            </div>
            <div className="p-3 bg-steel-950 rounded-xl border border-steel-800 text-center">
              <div className="text-[10px] font-mono text-zinc-400 uppercase">Z Coord</div>
              <div className="text-base font-bold font-mono-num text-zinc-100 mt-0.5">
                {robot.cartesianTCP.z} mm
              </div>
            </div>
          </div>

          {/* Orientation Rx, Ry, Rz */}
          <div className="grid grid-cols-3 gap-2">
            <div className="p-2.5 bg-steel-950 rounded-lg border border-steel-800 text-center">
              <span className="text-[10px] text-zinc-400">Rx: </span>
              <span className="text-xs font-mono font-bold text-sky-400">{robot.cartesianTCP.rx}°</span>
            </div>
            <div className="p-2.5 bg-steel-950 rounded-lg border border-steel-800 text-center">
              <span className="text-[10px] text-zinc-400">Ry: </span>
              <span className="text-xs font-mono font-bold text-sky-400">{robot.cartesianTCP.ry}°</span>
            </div>
            <div className="p-2.5 bg-steel-950 rounded-lg border border-steel-800 text-center">
              <span className="text-[10px] text-zinc-400">Rz: </span>
              <span className="text-xs font-mono font-bold text-sky-400">{robot.cartesianTCP.rz}°</span>
            </div>
          </div>

          {/* Inverse Kinematics Target Planner */}
          <div className="p-4 bg-steel-950 rounded-xl border border-steel-800 space-y-3">
            <div className="text-xs font-bold font-industrial uppercase text-zinc-300">
              Inverse Kinematics (IK) Cartesian Solver
            </div>
            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="text-[10px] text-zinc-400 font-mono">Target X</label>
                <input
                  type="number"
                  value={ikTarget.x}
                  onChange={(e) => setIkTarget({ ...ikTarget, x: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-steel-900 border border-steel-700 rounded p-1 text-xs font-mono text-white"
                />
              </div>
              <div>
                <label className="text-[10px] text-zinc-400 font-mono">Target Y</label>
                <input
                  type="number"
                  value={ikTarget.y}
                  onChange={(e) => setIkTarget({ ...ikTarget, y: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-steel-900 border border-steel-700 rounded p-1 text-xs font-mono text-white"
                />
              </div>
              <div>
                <label className="text-[10px] text-zinc-400 font-mono">Target Z</label>
                <input
                  type="number"
                  value={ikTarget.z}
                  onChange={(e) => setIkTarget({ ...ikTarget, z: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-steel-900 border border-steel-700 rounded p-1 text-xs font-mono text-white"
                />
              </div>
            </div>
            <button
              onClick={handleRunIK}
              className="w-full py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-bold font-mono transition-all shadow-md"
            >
              SOLVE & MOVE TCP
            </button>
          </div>

          {/* Safety Envelope Diagnostics */}
          <div className="p-3 bg-steel-950 rounded-xl border border-steel-800 text-xs space-y-1">
            <div className="flex justify-between text-zinc-400">
              <span>Radial Arm Reach</span>
              <span className="font-mono text-zinc-200">{workspaceCheck.reachMm} mm / {workspaceCheck.maxReachMm} mm</span>
            </div>
            <div className="text-[11px] text-zinc-400">
              {workspaceCheck.details}
            </div>
          </div>
        </div>

        {/* Right: Waypoint Program & Trajectory Generator */}
        <div className="bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-steel-800 pb-2">
            <h3 className="text-xs font-bold font-industrial uppercase text-zinc-200 flex items-center gap-2">
              <Navigation className="w-4 h-4 text-emerald-400" />
              Automated Waypoint Sequences
            </h3>
            <span className="text-[10px] font-mono text-sky-400">
              {robot.gripperState}
            </span>
          </div>

          <div className="space-y-2">
            {robot.waypointProgram.map((wp, idx) => {
              const isCurrent = robot.targetWaypoint === wp.name;
              return (
                <div
                  key={wp.id}
                  className={`p-3 rounded-xl border transition-all ${
                    isCurrent
                      ? 'bg-sky-950/60 border-sky-600 shadow-md'
                      : 'bg-steel-950 border-steel-800 hover:border-steel-700'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="font-bold font-mono text-zinc-200">
                      #{idx + 1} {wp.name}
                    </span>
                    <button
                      onClick={() => onExecuteWaypoint(wp.id)}
                      className="px-2.5 py-1 bg-sky-600 hover:bg-sky-500 text-white rounded text-[11px] font-mono font-bold transition-all"
                    >
                      EXECUTE
                    </button>
                  </div>
                  <div className="flex items-center justify-between text-[11px] font-mono text-zinc-400">
                    <span>Pos: ({wp.x}, {wp.y}, {wp.z})</span>
                    <span className="text-emerald-400">{wp.speed} mm/s</span>
                  </div>
                  <div className="text-[10px] text-zinc-400 mt-1">
                    Action: {wp.action}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Cell Gripper Telemetry */}
          <div className="p-3 bg-steel-950 rounded-xl border border-steel-800 text-xs space-y-1.5">
            <div className="flex justify-between">
              <span className="text-zinc-400">Current Payload</span>
              <span className="font-mono font-bold text-amber-400">{robot.payloadKg} kg (Heavy Billet)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-zinc-400">Cycle Time</span>
              <span className="font-mono text-zinc-200">{robot.cycleTimeSeconds}s</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
