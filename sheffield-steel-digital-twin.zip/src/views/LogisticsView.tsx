import React from 'react';
import { 
  Truck, 
  Layers, 
  Flame, 
  ShieldCheck, 
  Compass, 
  Activity,
  Box
} from 'lucide-react';
import { SimulationState } from '../services/simulation.service';

interface LogisticsViewProps {
  state: SimulationState;
}

export const LogisticsView: React.FC<LogisticsViewProps> = ({ state }) => {
  const scrapBunkers = [
    { code: 'BIN-HMS1', name: 'Heavy Melting Scrap #1', fillPct: 82, weightTonnes: 1450, density: '0.85 t/m³', radiationCheck: 'CLEAR_PASS' },
    { code: 'BIN-HMS2', name: 'Heavy Melting Scrap #2', fillPct: 64, weightTonnes: 920, density: '0.72 t/m³', radiationCheck: 'CLEAR_PASS' },
    { code: 'BIN-SHRED', name: 'Clean Shredded Auto Scrap', fillPct: 91, weightTonnes: 1820, density: '0.95 t/m³', radiationCheck: 'CLEAR_PASS' },
    { code: 'BIN-FECR', name: 'High-Carbon Ferro-Chrome', fillPct: 45, weightTonnes: 210, density: '4.20 t/m³', radiationCheck: 'VERIFIED' },
    { code: 'BIN-FEMO', name: 'Ferro-Molybdenum Briquettes', fillPct: 38, weightTonnes: 85, density: '5.10 t/m³', radiationCheck: 'VERIFIED' },
    { code: 'BIN-NICKEL', name: 'Pure Electrolytic Nickel Crowns', fillPct: 52, weightTonnes: 120, density: '8.90 t/m³', radiationCheck: 'VERIFIED' }
  ];

  const coolingBeds = [
    { pitId: 'PIT-01 (Insulated)', grade: '4140 Alloy', count: 12, currentTempC: 480, targetUnloadC: 150, coolingRate: '15°C/hr (Slow)' },
    { pitId: 'PIT-02 (Ambient)', grade: 'S355J2', count: 24, currentTempC: 220, targetUnloadC: 80, coolingRate: '45°C/hr (Free Air)' },
    { pitId: 'PIT-03 (Insulated)', grade: 'H13 Tool Steel', count: 8, currentTempC: 620, targetUnloadC: 120, coolingRate: '12°C/hr (Flake Safe)' }
  ];

  return (
    <div className="h-full flex flex-col bg-steel-950 p-4 gap-4 overflow-y-auto select-none">
      {/* Header */}
      <div className="bg-steel-900 border border-steel-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-400 text-xs font-mono font-bold border border-blue-500/30">
              YARD & LOGISTICS
            </span>
            <h2 className="text-lg font-bold font-industrial text-zinc-100">
              Scrap Inventory, Bloom Buffers & Gantry Crane Fleets
            </h2>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Bulk scrap yard classification, alloy bunker telemetry, and insulated slow-cooling pit thermal decay management.
          </p>
        </div>
      </div>

      {/* Scrap Bunkers Grid */}
      <div className="bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-4">
        <h3 className="text-xs font-bold font-industrial uppercase text-zinc-200 flex items-center gap-2">
          <Truck className="w-4 h-4 text-blue-400" />
          Raw Scrap & Ferro-Alloy Yard Bunkers
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {scrapBunkers.map(b => (
            <div key={b.code} className="p-3.5 bg-steel-950 rounded-xl border border-steel-800 space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-bold text-zinc-200">{b.name}</span>
                <span className="font-mono text-[10px] text-sky-400">{b.code}</span>
              </div>

              <div className="flex justify-between items-baseline text-xs font-mono">
                <span className="text-zinc-400">Stock Weight</span>
                <span className="font-bold text-zinc-100">{b.weightTonnes} Tonnes</span>
              </div>

              {/* Bunker Fill Bar */}
              <div className="w-full bg-steel-800 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-blue-500 h-full transition-all duration-300"
                  style={{ width: `${b.fillPct}%` }}
                />
              </div>

              <div className="flex justify-between text-[10px] font-mono text-zinc-400 pt-1">
                <span>Density: {b.density}</span>
                <span className="text-emerald-400">{b.radiationCheck}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Hot Bloom Buffer Pits */}
      <div className="bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-4">
        <h3 className="text-xs font-bold font-industrial uppercase text-zinc-200 flex items-center gap-2">
          <Flame className="w-4 h-4 text-orange-400" />
          Hot Bloom Retention & Slow Cooling Pits
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {coolingBeds.map(c => (
            <div key={c.pitId} className="p-4 bg-steel-950 rounded-xl border border-steel-800 space-y-3">
              <div className="flex justify-between items-center text-xs">
                <span className="font-bold font-mono text-orange-300">{c.pitId}</span>
                <span className="px-2 py-0.5 rounded bg-orange-500/20 text-orange-400 font-mono text-[10px] font-bold">
                  {c.count} Blooms
                </span>
              </div>

              <div className="text-xs text-zinc-300 font-semibold">
                Alloy: {c.grade}
              </div>

              <div className="grid grid-cols-2 gap-2 text-center text-xs font-mono">
                <div className="p-2 bg-steel-900 rounded-lg border border-steel-800">
                  <div className="text-[10px] text-zinc-400">Current Temp</div>
                  <div className="font-bold text-orange-400 mt-0.5">{c.currentTempC}°C</div>
                </div>
                <div className="p-2 bg-steel-900 rounded-lg border border-steel-800">
                  <div className="text-[10px] text-zinc-400">Cooling Rate</div>
                  <div className="font-bold text-zinc-200 mt-0.5">{c.coolingRate}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
