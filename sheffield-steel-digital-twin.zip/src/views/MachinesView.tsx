import React, { useState } from 'react';
import { 
  Activity, 
  Zap, 
  Thermometer, 
  AlertTriangle, 
  CheckCircle2, 
  Sliders, 
  Wrench, 
  Filter,
  BarChart2
} from 'lucide-react';
import { SimulationState } from '../services/simulation.service';
import { MachineTwin, MachineState } from '../types/twin.types';

interface MachinesViewProps {
  state: SimulationState;
  onSelectMachine: (id: string) => void;
  onSetMachineState: (id: string, state: MachineState) => void;
}

export const MachinesView: React.FC<MachinesViewProps> = ({
  state,
  onSelectMachine,
  onSetMachineState
}) => {
  const [filterState, setFilterState] = useState<string>('ALL');

  const filteredMachines = state.machines.filter(m => {
    if (filterState === 'ALL') return true;
    return m.state === filterState;
  });

  return (
    <div className="h-full flex flex-col bg-steel-950 p-4 gap-4 overflow-y-auto select-none">
      {/* Header & Filter Controls */}
      <div className="bg-steel-900 border border-steel-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-xs font-mono font-bold border border-emerald-500/30">
              ASSET HEALTH & TELEMETRY
            </span>
            <h2 className="text-lg font-bold font-industrial text-zinc-100">
              Plant Machinery Telemetry Matrix (12 Digital Twins)
            </h2>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Real-time multi-variable telemetry, condition monitoring, ISO 10816 vibration norms, and remote PLC overrides.
          </p>
        </div>

        {/* State Filter Pills */}
        <div className="flex items-center gap-1.5 bg-steel-950 p-1.5 rounded-xl border border-steel-800">
          <Filter className="w-3.5 h-3.5 text-zinc-400 ml-1 mr-1" />
          {['ALL', 'MELTING', 'ROLLING', 'FORGING', 'MACHINING', 'INSPECTING', 'HEATING'].map(f => (
            <button
              key={f}
              onClick={() => setFilterState(f)}
              className={`px-2.5 py-1 text-xs font-mono rounded-lg transition-all ${
                filterState === f
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* High Density Machine Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filteredMachines.map(m => {
          const isSelected = m.id === state.selectedMachineId;
          const hasAlarms = m.alarms.length > 0;

          return (
            <div
              key={m.id}
              onClick={() => onSelectMachine(m.id)}
              className={`bg-steel-900 border rounded-2xl p-4 cursor-pointer transition-all hover:scale-101 space-y-3 ${
                isSelected
                  ? 'border-sky-500 shadow-xl ring-1 ring-sky-500/40'
                  : hasAlarms
                  ? 'border-rose-800/80 bg-rose-950/20'
                  : 'border-steel-800 hover:border-steel-700'
              }`}
            >
              {/* Card Header */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-steel-800 flex items-center justify-center border border-steel-700 font-mono font-bold text-xs text-sky-400">
                    {m.code.slice(0, 3)}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold font-industrial text-zinc-100">{m.code}</h3>
                    <p className="text-[11px] text-zinc-400 truncate max-w-48">{m.name}</p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                    m.state === 'MELTING' || m.state === 'FORGING' || m.state === 'ROLLING' || m.state === 'MACHINING'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : m.state === 'EMERGENCY_STOP'
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                      : 'bg-zinc-800 text-zinc-400'
                  }`}>
                    {m.state}
                  </span>
                </div>
              </div>

              {/* 3 Metrics Row */}
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="bg-steel-950 p-2 rounded-xl border border-steel-800">
                  <div className="text-[10px] font-mono text-zinc-400">Power</div>
                  <div className="text-xs font-mono font-bold text-amber-400 mt-0.5">
                    {m.powerDrawMW.toFixed(1)} MW
                  </div>
                </div>
                <div className="bg-steel-950 p-2 rounded-xl border border-steel-800">
                  <div className="text-[10px] font-mono text-zinc-400">Temp</div>
                  <div className="text-xs font-mono font-bold text-orange-400 mt-0.5">
                    {m.temperatureC}°C
                  </div>
                </div>
                <div className="bg-steel-950 p-2 rounded-xl border border-steel-800">
                  <div className="text-[10px] font-mono text-zinc-400">Vibration</div>
                  <div className={`text-xs font-mono font-bold mt-0.5 ${
                    m.vibrationRmsMmS > 4.5 ? 'text-rose-400' : 'text-zinc-200'
                  }`}>
                    {m.vibrationRmsMmS.toFixed(1)} mm/s
                  </div>
                </div>
              </div>

              {/* Key Telemetry Snippet */}
              <div className="bg-steel-950 p-2.5 rounded-xl border border-steel-800 text-xs space-y-1">
                {Object.entries(m.telemetry).slice(0, 2).map(([k, v]) => (
                  <div key={k} className="flex justify-between text-[11px]">
                    <span className="text-zinc-400 truncate pr-2">{k}</span>
                    <span className="font-mono font-bold text-zinc-200">{String(v)}</span>
                  </div>
                ))}
              </div>

              {/* Footer: Health & Hours */}
              <div className="flex items-center justify-between text-[11px] font-mono text-zinc-400 pt-1 border-t border-steel-800">
                <span>Health: <strong className="text-emerald-400">{m.healthScore}%</strong></span>
                <span>Hours: {m.operationalHoursTotal.toLocaleString()}h</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
