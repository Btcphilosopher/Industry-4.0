import React, { useState } from 'react';
import { 
  BookOpen, 
  Flame, 
  Layers, 
  Activity, 
  Compass, 
  CheckCircle2, 
  Share2,
  Calculator,
  Search
} from 'lucide-react';
import { SHEFFIELD_STEEL_GRADES } from '../data/sheffield-grades';
import { calculateCEV, calculatePREN, calculateMsTemp, SteelGrade } from '../types/metallurgy.types';
import { KNOWLEDGE_GRAPH_NODES } from '../services/metallurgy-engine.service';

export const KnowledgeView: React.FC = () => {
  const [selectedGrade, setSelectedGrade] = useState<SteelGrade>(SHEFFIELD_STEEL_GRADES[1]); // S355J2
  const [calcChemistry, setCalcChemistry] = useState({ ...selectedGrade.nominalChemistry });
  const [selectedNodeId, setSelectedNodeId] = useState<string>('NODE-S355');

  const cev = calculateCEV(calcChemistry);
  const pren = calculatePREN(calcChemistry);
  const ms = calculateMsTemp(calcChemistry);

  const selectedNode = KNOWLEDGE_GRAPH_NODES.find(n => n.id === selectedNodeId) || KNOWLEDGE_GRAPH_NODES[0];

  return (
    <div className="h-full flex flex-col bg-steel-950 p-4 gap-4 overflow-y-auto select-none">
      {/* Header */}
      <div className="bg-steel-900 border border-steel-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-400 text-xs font-mono font-bold border border-cyan-500/30">
              METALLURGICAL KNOWLEDGE ENGINE
            </span>
            <h2 className="text-lg font-bold font-industrial text-zinc-100">
              Sheffield Metallurgy Encyclopedia & Phase Transformation Models
            </h2>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Centuries of Sheffield advanced alloy metallurgy, continuous cooling transformation kinetics, and empirical formula calculators.
          </p>
        </div>

        {/* Grade Selector */}
        <div className="flex items-center gap-1.5 overflow-x-auto">
          {SHEFFIELD_STEEL_GRADES.map(g => (
            <button
              key={g.id}
              onClick={() => {
                setSelectedGrade(g);
                setCalcChemistry({ ...g.nominalChemistry });
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-mono transition-all border ${
                selectedGrade.id === g.id
                  ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50 font-bold'
                  : 'bg-steel-800 text-zinc-400 border-steel-700 hover:text-zinc-200'
              }`}
            >
              {g.id}
            </button>
          ))}
        </div>
      </div>

      {/* Grade Details */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left 2 Cols: Grade Specs & Heritage */}
        <div className="lg:col-span-2 bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-5">
          <div className="flex items-center justify-between border-b border-steel-800 pb-3">
            <div>
              <div className="text-xs font-mono text-cyan-400 font-bold">{selectedGrade.standard}</div>
              <h3 className="text-lg font-bold font-industrial text-zinc-100">
                {selectedGrade.name}
              </h3>
            </div>
            <span className="px-2.5 py-1 rounded-lg text-xs font-mono font-bold bg-steel-800 text-zinc-300 border border-steel-700">
              {selectedGrade.category}
            </span>
          </div>

          {/* Sheffield Heritage Note */}
          <div className="p-4 rounded-xl bg-cyan-950/20 border border-cyan-800/40 text-xs text-zinc-300">
            <span className="font-bold text-cyan-300 font-industrial uppercase mr-2">Sheffield Heritage Note:</span>
            {selectedGrade.sheffieldHeritageNote}
          </div>

          {/* Mechanical Properties Grid */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold font-industrial uppercase text-zinc-300">
              Mechanical & Thermal Properties
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center text-xs font-mono">
              <div className="p-3 bg-steel-950 rounded-xl border border-steel-800">
                <div className="text-[10px] text-zinc-400">Yield Strength</div>
                <div className="text-base font-bold text-emerald-400 mt-0.5">{selectedGrade.mechanicalProperties.yieldStrengthMpa} MPa</div>
              </div>
              <div className="p-3 bg-steel-950 rounded-xl border border-steel-800">
                <div className="text-[10px] text-zinc-400">Tensile Strength</div>
                <div className="text-base font-bold text-sky-400 mt-0.5">{selectedGrade.mechanicalProperties.tensileStrengthMpa} MPa</div>
              </div>
              <div className="p-3 bg-steel-950 rounded-xl border border-steel-800">
                <div className="text-[10px] text-zinc-400">Elongation A5</div>
                <div className="text-base font-bold text-zinc-100 mt-0.5">{selectedGrade.mechanicalProperties.elongationPercent}%</div>
              </div>
              <div className="p-3 bg-steel-950 rounded-xl border border-steel-800">
                <div className="text-[10px] text-zinc-400">Charpy V-Notch</div>
                <div className="text-base font-bold text-teal-400 mt-0.5">{selectedGrade.mechanicalProperties.charpyVNotchJoules} J</div>
              </div>
            </div>
          </div>

          {/* Heat Treatment Profile */}
          <div className="p-4 bg-steel-950 rounded-xl border border-steel-800 space-y-2 text-xs font-mono">
            <div className="font-bold text-zinc-200 font-sans">Recommended Heat Treatment Cycle</div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1 text-zinc-400">
              <div>Austenitising: <strong className="text-orange-400">{selectedGrade.heatTreatment.austenitisingTempC}°C</strong></div>
              <div>Quench Medium: <strong className="text-sky-400">{selectedGrade.heatTreatment.quenchMedium}</strong></div>
              <div>Target Hardness: <strong className="text-emerald-400">{selectedGrade.heatTreatment.targetHardness}</strong></div>
            </div>
          </div>
        </div>

        {/* Right Col: Interactive CEV / PREN / Ms Calculator */}
        <div className="bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-4">
          <h3 className="text-xs font-bold font-industrial uppercase text-zinc-200 flex items-center gap-2">
            <Calculator className="w-4 h-4 text-cyan-400" />
            Live Metallurgical Formula Engine
          </h3>

          <div className="space-y-3">
            {/* CEV */}
            <div className="p-3.5 bg-steel-950 rounded-xl border border-steel-800 space-y-1">
              <div className="flex justify-between items-center text-xs">
                <span className="text-zinc-300 font-bold">Carbon Equivalent (IIW CEV)</span>
                <span className="font-mono text-base font-bold text-cyan-400">{cev.toFixed(3)}</span>
              </div>
              <div className="text-[10px] font-mono text-zinc-400">
                Formula: C + Mn/6 + (Cr+Mo+V)/5 + (Ni+Cu)/15
              </div>
            </div>

            {/* PREN */}
            <div className="p-3.5 bg-steel-950 rounded-xl border border-steel-800 space-y-1">
              <div className="flex justify-between items-center text-xs">
                <span className="text-zinc-300 font-bold">Pitting Resistance (PREN)</span>
                <span className="font-mono text-base font-bold text-emerald-400">{pren.toFixed(1)}</span>
              </div>
              <div className="text-[10px] font-mono text-zinc-400">
                Formula: Cr + 3.3×Mo + 16×N (aim &gt; 24 for marine/nuclear)
              </div>
            </div>

            {/* Andrews Ms */}
            <div className="p-3.5 bg-steel-950 rounded-xl border border-steel-800 space-y-1">
              <div className="flex justify-between items-center text-xs">
                <span className="text-zinc-300 font-bold">Martensite Start Temp (Ms)</span>
                <span className="font-mono text-base font-bold text-orange-400">{ms}°C</span>
              </div>
              <div className="text-[10px] font-mono text-zinc-400">
                Andrews Empirical Transformation Equation
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Interactive Metallurgy Knowledge Graph */}
      <div className="bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-4">
        <h3 className="text-xs font-bold font-industrial uppercase text-zinc-200 flex items-center gap-2">
          <Share2 className="w-4 h-4 text-cyan-400" />
          Interactive Sheffield Metallurgy Knowledge Graph
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-1.5">
            {KNOWLEDGE_GRAPH_NODES.map(node => (
              <button
                key={node.id}
                onClick={() => setSelectedNodeId(node.id)}
                className={`w-full text-left p-2.5 rounded-xl border text-xs transition-all flex items-center justify-between ${
                  selectedNodeId === node.id
                    ? 'bg-cyan-950/60 border-cyan-600 text-cyan-200 font-bold'
                    : 'bg-steel-950 border-steel-800 text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <span>{node.name}</span>
                <span className="text-[9px] font-mono uppercase text-zinc-400">[{node.category}]</span>
              </button>
            ))}
          </div>

          <div className="md:col-span-2 p-4 bg-steel-950 rounded-xl border border-steel-800 space-y-3">
            <div className="flex justify-between items-center border-b border-steel-800 pb-2">
              <h4 className="text-sm font-bold text-cyan-300 font-industrial">{selectedNode.name}</h4>
              <span className="px-2 py-0.5 rounded bg-steel-800 text-[10px] font-mono text-zinc-300">{selectedNode.category}</span>
            </div>
            <p className="text-xs text-zinc-300 leading-relaxed">
              {selectedNode.description}
            </p>
            <div className="pt-2">
              <div className="text-[10px] font-mono text-zinc-400 uppercase mb-1">Ontological Relations / Process Links:</div>
              <div className="flex flex-wrap gap-1.5">
                {selectedNode.links.map(l => (
                  <span key={l} className="px-2 py-1 rounded bg-steel-900 border border-steel-700 text-[10px] font-mono text-zinc-300">
                    → {l}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
