import React from 'react';
import { 
  FlaskConical, 
  AlertTriangle, 
  Zap, 
  Activity, 
  ShieldAlert, 
  Play, 
  RotateCcw,
  Flame,
  CheckCircle2
} from 'lucide-react';
import { SimulationState } from '../services/simulation.service';

interface ScenariosViewProps {
  state: SimulationState;
  onApplyScenario: (scenarioId: string) => void;
}

export const ScenariosView: React.FC<ScenariosViewProps> = ({
  state,
  onApplyScenario
}) => {
  const scenarios = [
    {
      id: 'BASE',
      name: 'Scenario 0: Nominal Base Production (Steady State)',
      category: 'NORMAL',
      desc: 'All 12 assets running nominal setpoints with S355J2 and 316L orders on schedule. Triad tariff deadband clear.',
      impacts: ['EAF 58.4 MW power', 'Vibration 2.4 mm/s nominal', 'Alloy residual Cu 0.16%'],
      color: 'border-emerald-500/50'
    },
    {
      id: 'COPPER_TRAMP',
      name: 'Scenario 1: Scrap Copper Tramp Contamination (+0.38% Cu)',
      category: 'METALLURGY',
      desc: 'Shredded auto scrap charge introduced unwanted copper wire, causing Cu to spike to 0.38% (limit 0.20%), risking hot shortness.',
      impacts: ['Liquid metal embrittlement risk', 'Requires LF pig iron dilution', 'Ni:Cu ratio compensation'],
      color: 'border-rose-500/50'
    },
    {
      id: 'POWER_TARIFF_CAP',
      name: 'Scenario 2: National Grid Triad Peak Demand Cap (44 MW)',
      category: 'ENERGY',
      desc: 'Grid operator issues red triad surcharge alert. EAF power throttled to 44MW maximum to avoid £65k/MW peak penalty.',
      impacts: ['Tap-to-tap time extends +18 min', 'Peak tariff penalty avoided', 'Schedules dynamically balanced'],
      color: 'border-amber-500/50'
    },
    {
      id: 'CNC_VIBRATION',
      name: 'Scenario 3: 5-Axis CNC Spindle Bearing Degradation',
      category: 'MAINTENANCE',
      desc: 'Severe 420Hz harmonic surge detected on CNC-04 front spindle bearing (7.4 mm/s RMS), triggering ISO 10816 alarm.',
      impacts: ['Automatic feed rate derate 50%', 'RUL reduced to 18 hours', 'Work order generated'],
      color: 'border-rose-500/50'
    }
  ];

  return (
    <div className="h-full flex flex-col bg-steel-950 p-4 gap-4 overflow-y-auto select-none">
      {/* Header */}
      <div className="bg-steel-900 border border-steel-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-pink-500/20 text-pink-400 text-xs font-mono font-bold border border-pink-500/30">
              WHAT-IF SIMULATION TESTBED
            </span>
            <h2 className="text-lg font-bold font-industrial text-zinc-100">
              Scenario Lab & Industrial Fault Injection
            </h2>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Test plant resilience against tramp element metallurgical contamination, electrical grid tariff caps, and machine failures.
          </p>
        </div>

        <div className="px-3 py-1.5 bg-steel-800 rounded-xl border border-steel-700 text-xs font-mono text-pink-400 font-bold">
          Active: {state.activeScenarioId}
        </div>
      </div>

      {/* Scenarios Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {scenarios.map(sc => {
          const isActive = state.activeScenarioId === sc.id;
          return (
            <div
              key={sc.id}
              className={`bg-steel-900 border rounded-2xl p-5 space-y-4 transition-all ${
                isActive
                  ? 'border-pink-500 shadow-xl bg-pink-950/20 ring-1 ring-pink-500/50'
                  : 'border-steel-800 hover:border-steel-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold font-industrial text-zinc-100">
                  {sc.name}
                </h3>
                <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                  isActive ? 'bg-pink-500 text-white' : 'bg-steel-800 text-zinc-400'
                }`}>
                  {isActive ? 'ACTIVE' : sc.category}
                </span>
              </div>

              <p className="text-xs text-zinc-300 leading-relaxed">
                {sc.desc}
              </p>

              <div className="space-y-1.5">
                <div className="text-[10px] font-mono text-zinc-400 uppercase">Simulated Physics Impacts:</div>
                <div className="flex flex-wrap gap-1.5">
                  {sc.impacts.map((imp, idx) => (
                    <span key={idx} className="px-2 py-1 bg-steel-950 border border-steel-800 rounded text-[11px] font-mono text-zinc-300">
                      • {imp}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  onClick={() => onApplyScenario(sc.id)}
                  className={`px-4 py-2 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-2 ${
                    isActive
                      ? 'bg-steel-800 text-zinc-400 cursor-default'
                      : 'bg-pink-600 hover:bg-pink-500 text-white shadow-md'
                  }`}
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>{isActive ? 'SCENARIO LOADED' : 'INJECT SCENARIO'}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
