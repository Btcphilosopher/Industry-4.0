import React, { useState } from 'react';
import { 
  Wrench, 
  Activity, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Calendar,
  Layers,
  Zap
} from 'lucide-react';
import { SimulationState } from '../services/simulation.service';

interface MaintenanceViewProps {
  state: SimulationState;
}

export const MaintenanceView: React.FC<MaintenanceViewProps> = ({ state }) => {
  const [selectedMachineId, setSelectedMachineId] = useState<string>('CNC-04');
  const machine = state.machines.find(m => m.id === selectedMachineId) || state.machines[0];

  // FFT Vibration Spectrum (40 frequency bins: 0 to 1000 Hz)
  const fftFrequencies = Array.from({ length: 40 }, (_, i) => {
    const freq = i * 25;
    // Harmonic peaks at 1X (70Hz shaft), 2X (140Hz), and bearing defect BPFO (420Hz if CNC)
    let amp = Math.random() * 0.4 + 0.1;
    if (freq === 75) amp += 1.8;
    if (freq === 150) amp += 0.9;
    if (freq === 425 && selectedMachineId === 'CNC-04' && machine.vibrationRmsMmS > 5) {
      amp += 5.2; // High BPFO fault peak!
    }
    return { freq, amp: Math.round(amp * 10) / 10 };
  });

  return (
    <div className="h-full flex flex-col bg-steel-950 p-4 gap-4 overflow-y-auto select-none">
      {/* Header */}
      <div className="bg-steel-900 border border-steel-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-400 text-xs font-mono font-bold border border-indigo-500/30">
              PREDICTIVE MAINTENANCE & RUL
            </span>
            <h2 className="text-lg font-bold font-industrial text-zinc-100">
              Vibration FFT Spectrum & Equipment Degradation Models
            </h2>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Harmonic bearing fault detection (BPFO/BPFI/BSF), ISO 10816-3 severity thresholds, and Remaining Useful Life (RUL).
          </p>
        </div>

        {/* Machine Selector */}
        <select
          value={selectedMachineId}
          onChange={(e) => setSelectedMachineId(e.target.value)}
          className="bg-steel-800 border border-steel-700 text-zinc-200 text-xs font-mono rounded-xl px-3 py-2 cursor-pointer"
        >
          {state.machines.map(m => (
            <option key={m.id} value={m.id}>
              {m.code} - {m.name}
            </option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left 2 Cols: FFT Vibration Spectrum Analysis */}
        <div className="lg:col-span-2 bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-steel-800 pb-3">
            <div>
              <h3 className="text-sm font-bold font-industrial text-zinc-100 flex items-center gap-2">
                <Activity className="w-4 h-4 text-indigo-400" />
                {machine.code} Spindle Bearing Vibration FFT Spectrum (0 - 1000 Hz)
              </h3>
              <p className="text-xs text-zinc-400">Piezoelectric Accelerometer Channel 1 (RMS = {machine.vibrationRmsMmS.toFixed(1)} mm/s)</p>
            </div>
            <span className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold ${
              machine.vibrationRmsMmS > 4.5
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
            }`}>
              {machine.vibrationRmsMmS > 4.5 ? 'ZONE C/D RESTRICTED' : 'ZONE A/B NOMINAL'}
            </span>
          </div>

          {/* FFT Spectrum Bars */}
          <div className="p-4 bg-steel-950 rounded-xl border border-steel-800 space-y-2">
            <div className="h-52 flex items-end gap-1 bg-[#0a0d0f] p-3 rounded-lg border border-steel-800 relative">
              {/* ISO 10816 Alarm line */}
              <div className="absolute left-0 right-0 top-16 border-t border-dashed border-rose-500/70 z-10 flex justify-end pr-2">
                <span className="text-[10px] font-mono text-rose-400 bg-steel-950/80 px-1">ISO Alarm Limit (4.5 mm/s)</span>
              </div>

              {fftFrequencies.map((f, i) => (
                <div key={i} className="flex-1 bg-steel-800/40 h-full flex flex-col justify-end items-center group relative">
                  <div
                    className={`w-full transition-all duration-300 rounded-t ${
                      f.amp > 4.5 
                        ? 'bg-rose-500 glow-orange' 
                        : f.amp > 2.0 
                        ? 'bg-amber-500' 
                        : 'bg-indigo-500'
                    }`}
                    style={{ height: `${Math.min(100, (f.amp / 6.0) * 100)}%` }}
                  />
                </div>
              ))}
            </div>

            <div className="flex justify-between text-[10px] font-mono text-zinc-400 pt-1">
              <span>0 Hz (DC)</span>
              <span>1X Running Speed (70 Hz)</span>
              <span>BPFO Defect (420 Hz)</span>
              <span>1000 Hz</span>
            </div>
          </div>

          {/* Fault Diagnosis Interpretation */}
          <div className="p-4 bg-steel-950 rounded-xl border border-steel-800 space-y-2 text-xs">
            <div className="font-bold text-zinc-200 font-industrial uppercase flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              Automated Signal Diagnosis
            </div>
            <p className="text-[11px] text-zinc-300">
              {machine.vibrationRmsMmS > 4.5
                ? 'CRITICAL HARMONIC ANOMALY: Significant 420 Hz peak corresponds to Ball Pass Frequency Outer Race (BPFO) defect on the front spindle angular contact bearing. Schedule replacement within 72 hours.'
                : 'NOMINAL BASELINE: Vibration amplitudes across 1X, 2X, and bearing defect frequencies remain within ISO 10816-3 Zone A continuous unrestricted operation.'}
            </p>
          </div>
        </div>

        {/* Right Col: RUL & Maintenance Planning */}
        <div className="bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-4">
          <h3 className="text-xs font-bold font-industrial uppercase text-zinc-200">
            Degradation & Health Scoring
          </h3>

          <div className="p-4 bg-steel-950 rounded-xl border border-steel-800 text-center space-y-2">
            <div className="text-[10px] font-mono text-zinc-400 uppercase">Health Score</div>
            <div className="text-3xl font-bold font-mono-num text-emerald-400">
              {machine.healthScore}%
            </div>
            <div className="text-xs text-zinc-400 font-mono">
              Remaining Useful Life: <strong>{machine.hoursUntilService} operating hours</strong>
            </div>
          </div>

          <div className="space-y-2.5 text-xs font-mono">
            <div className="p-3 bg-steel-950 rounded-xl border border-steel-800 flex justify-between">
              <span className="text-zinc-400">Total Lifetime Hours</span>
              <span className="text-zinc-100 font-bold">{machine.operationalHoursTotal.toLocaleString()} h</span>
            </div>
            <div className="p-3 bg-steel-950 rounded-xl border border-steel-800 flex justify-between">
              <span className="text-zinc-400">Lubrication Condition</span>
              <span className="text-emerald-400 font-bold">ISO VG 68 Clean</span>
            </div>
            <div className="p-3 bg-steel-950 rounded-xl border border-steel-800 flex justify-between">
              <span className="text-zinc-400">Next Planned Service</span>
              <span className="text-sky-400 font-bold">14-Oct-2026</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
