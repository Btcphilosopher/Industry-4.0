import React from 'react';
import { 
  Layers, 
  Flame, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  ArrowRight, 
  FileText, 
  QrCode,
  ShieldCheck,
  Truck
} from 'lucide-react';
import { SimulationState } from '../services/simulation.service';

interface ProductionViewProps {
  state: SimulationState;
  onSelectOrder: (orderId: string) => void;
  onOpenPassport: () => void;
}

export const ProductionView: React.FC<ProductionViewProps> = ({
  state,
  onSelectOrder,
  onOpenPassport
}) => {
  const selectedOrder = state.productionOrders.find(o => o.id === state.selectedOrderId) || state.productionOrders[0];

  return (
    <div className="h-full flex flex-col bg-steel-950 p-4 gap-4 overflow-y-auto select-none">
      {/* Header */}
      <div className="bg-steel-900 border border-steel-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 text-xs font-mono font-bold border border-amber-500/30">
              MES & PRODUCTION SCHEDULING
            </span>
            <h2 className="text-lg font-bold font-industrial text-zinc-100">
              Factory Digital Thread & Production Routing
            </h2>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            End-to-end genealogy tracking from scrap charge heat to CNC machined component and DPP dispatch.
          </p>
        </div>

        <button
          onClick={onOpenPassport}
          className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold font-industrial transition-all shadow-md"
        >
          <QrCode className="w-4 h-4" />
          <span>VIEW DIGITAL PASSPORT</span>
        </button>
      </div>

      {/* Production Orders Table & Selected Order Drilldown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left: Orders List */}
        <div className="bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-steel-800 pb-2">
            <h3 className="text-xs font-bold font-industrial uppercase text-zinc-200 flex items-center gap-2">
              <Layers className="w-4 h-4 text-amber-400" />
              Active Works Orders ({state.productionOrders.length})
            </h3>
            <span className="text-[10px] font-mono text-zinc-400">ISO 9001 / AS9100</span>
          </div>

          <div className="space-y-3">
            {state.productionOrders.map(order => {
              const isSelected = order.id === selectedOrder.id;
              return (
                <div
                  key={order.id}
                  onClick={() => onSelectOrder(order.id)}
                  className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-amber-950/40 border-amber-600 shadow-md'
                      : 'bg-steel-950 border-steel-800 hover:border-steel-700'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="font-mono font-bold text-zinc-100">
                      {order.orderNumber}
                    </span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                      order.status === 'IN_PROGRESS' 
                        ? 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                        : order.status === 'INSPECTION'
                        ? 'bg-teal-500/20 text-teal-300 border border-teal-500/30'
                        : 'bg-zinc-800 text-zinc-300'
                    }`}>
                      {order.status}
                    </span>
                  </div>

                  <div className="text-xs text-zinc-300 font-semibold truncate mb-1">
                    {order.componentType}
                  </div>

                  <div className="flex items-center justify-between text-[11px] font-mono text-zinc-400">
                    <span>Grade: {order.steelGrade}</span>
                    <span>Qty: {order.quantity} pcs ({order.weightTonnes}t)</span>
                  </div>

                  {/* Progress Bar */}
                  <div className="w-full bg-steel-800 h-1.5 rounded-full overflow-hidden mt-2">
                    <div
                      className="bg-amber-500 h-full transition-all duration-300"
                      style={{ width: `${order.progressPercent}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Center & Right: Detailed Process Route & Digital Genealogy */}
        <div className="lg:col-span-2 bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-5">
          <div className="flex items-center justify-between border-b border-steel-800 pb-3">
            <div>
              <div className="text-xs font-mono text-amber-400 font-bold">{selectedOrder.orderNumber}</div>
              <h3 className="text-base font-bold font-industrial text-zinc-100">
                {selectedOrder.componentType}
              </h3>
              <p className="text-xs text-zinc-400">Client: {selectedOrder.clientName}</p>
            </div>
            <div className="text-right">
              <div className="text-[10px] font-mono text-zinc-400">Target Delivery</div>
              <div className="text-xs font-mono font-bold text-zinc-200">{selectedOrder.deliveryDate}</div>
            </div>
          </div>

          {/* Key Parameters */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 bg-steel-950 rounded-xl border border-steel-800">
              <div className="text-[10px] font-mono text-zinc-400 uppercase">Steel Grade</div>
              <div className="text-sm font-bold font-mono text-sky-400 mt-0.5">{selectedOrder.steelGrade}</div>
            </div>
            <div className="p-3 bg-steel-950 rounded-xl border border-steel-800">
              <div className="text-[10px] font-mono text-zinc-400 uppercase">Scrap Heat ID</div>
              <div className="text-sm font-bold font-mono text-orange-400 mt-0.5">{selectedOrder.scrapHeatId}</div>
            </div>
            <div className="p-3 bg-steel-950 rounded-xl border border-steel-800">
              <div className="text-[10px] font-mono text-zinc-400 uppercase">Total Weight</div>
              <div className="text-sm font-bold font-mono text-zinc-100 mt-0.5">{selectedOrder.weightTonnes} Tonnes</div>
            </div>
            <div className="p-3 bg-steel-950 rounded-xl border border-steel-800">
              <div className="text-[10px] font-mono text-zinc-400 uppercase">Route Progress</div>
              <div className="text-sm font-bold font-mono text-emerald-400 mt-0.5">{selectedOrder.progressPercent}%</div>
            </div>
          </div>

          {/* Digital Thread Sequential Route */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold font-industrial uppercase text-zinc-300">
              Digital Thread Process Route (ISO 23247 Architecture)
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {selectedOrder.routeSteps.map((step) => {
                const isDone = step.status === 'COMPLETED';
                const isCurrent = step.status === 'IN_PROGRESS';
                return (
                  <div
                    key={step.step}
                    className={`p-3 rounded-xl border flex items-center justify-between text-xs ${
                      isDone
                        ? 'bg-emerald-950/20 border-emerald-800/80 text-emerald-200'
                        : isCurrent
                        ? 'bg-sky-950/40 border-sky-600 text-sky-200 shadow-md'
                        : 'bg-steel-950 border-steel-800 text-zinc-400'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className={`w-6 h-6 rounded-full flex items-center justify-center font-mono text-xs font-bold ${
                        isDone ? 'bg-emerald-600 text-white' : isCurrent ? 'bg-sky-600 text-white' : 'bg-steel-800 text-zinc-400'
                      }`}>
                        {step.step}
                      </div>
                      <div>
                        <div className="font-semibold text-zinc-200">{step.name}</div>
                        <div className="text-[10px] font-mono text-zinc-400">Asset: {step.machineCode}</div>
                      </div>
                    </div>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                      isDone ? 'bg-emerald-500/20 text-emerald-300' : isCurrent ? 'bg-sky-500/20 text-sky-300 animate-pulse' : 'bg-steel-800 text-zinc-400'
                    }`}>
                      {step.status}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
