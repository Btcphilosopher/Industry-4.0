import React from 'react';
import { 
  TrendingUp, 
  BarChart2, 
  Activity, 
  CheckCircle2, 
  Clock,
  Layers,
  Zap
} from 'lucide-react';
import { SimulationState } from '../services/simulation.service';

interface AnalyticsViewProps {
  state: SimulationState;
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({ state }) => {
  // 20 Sample X-bar Diameter Measurements (aim 450.000mm)
  const spcSamples = [
    450.002, 449.998, 450.004, 450.001, 450.003, 449.997, 450.005, 450.000, 
    450.002, 449.999, 450.003, 450.006, 450.001, 449.998, 450.002, 450.004,
    449.999, 450.001, 450.003, 450.002
  ];

  const nominal = 450.000;
  const ucl = 450.015;
  const lcl = 449.985;
  const cpk = 1.68; // Capable process

  const oeeCells = [
    { cell: 'EAF-01 Melting', availability: 92.4, performance: 95.8, quality: 99.1, oee: 87.7 },
    { cell: 'FORGE-01 30MN Press', availability: 88.5, performance: 91.2, quality: 98.6, oee: 79.6 },
    { cell: 'MILL-01 Rolling Stand', availability: 94.1, performance: 93.4, quality: 99.4, oee: 87.4 },
    { cell: 'CNC-04 5-Axis Milling', availability: 86.2, performance: 94.0, quality: 99.8, oee: 80.8 },
    { cell: 'ROBOT-17 Handling Cell', availability: 98.4, performance: 97.2, quality: 100.0, oee: 95.6 }
  ];

  return (
    <div className="h-full flex flex-col bg-steel-950 p-4 gap-4 overflow-y-auto select-none">
      {/* Header */}
      <div className="bg-steel-900 border border-steel-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-400 text-xs font-mono font-bold border border-purple-500/30">
              INDUSTRIAL STATISTICAL CONTROL
            </span>
            <h2 className="text-lg font-bold font-industrial text-zinc-100">
              Statistical Process Control (SPC) & Overall Equipment Effectiveness (OEE)
            </h2>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            X-bar & R control charts, Cpk / Ppk capability indices, and plant-wide OEE waterfall analytics.
          </p>
        </div>

        <div className="px-3 py-1.5 bg-steel-800 rounded-xl border border-steel-700 font-mono text-xs text-emerald-400 font-bold">
          Process Capability Cpk = {cpk.toFixed(2)} (Six-Sigma Capable)
        </div>
      </div>

      {/* SPC X-Bar Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-steel-800 pb-3">
            <div>
              <h3 className="text-sm font-bold font-industrial text-zinc-100 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-purple-400" />
                X-Bar Control Chart: Shaft Bearing Journal Diameter (mm)
              </h3>
              <p className="text-xs text-zinc-400">Sample Subgroups N=20 (UCL: 450.015mm, LCL: 449.985mm)</p>
            </div>
            <span className="px-2.5 py-1 rounded-lg text-xs font-mono font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
              IN STATISTICAL CONTROL
            </span>
          </div>

          {/* SPC Chart Bars / Points */}
          <div className="p-4 bg-steel-950 rounded-xl border border-steel-800 space-y-2">
            <div className="h-44 flex items-center gap-2 bg-[#0a0d0f] p-3 rounded-lg border border-steel-800 relative">
              {/* UCL Line */}
              <div className="absolute left-0 right-0 top-6 border-t border-dashed border-rose-500/60 z-10 flex justify-end pr-2">
                <span className="text-[10px] font-mono text-rose-400 bg-steel-950/80 px-1">UCL (+0.015)</span>
              </div>
              {/* Nominal Line */}
              <div className="absolute left-0 right-0 top-1/2 border-t border-steel-600/80 z-10 flex justify-end pr-2">
                <span className="text-[10px] font-mono text-sky-400 bg-steel-950/80 px-1">Nominal (450.000)</span>
              </div>
              {/* LCL Line */}
              <div className="absolute left-0 right-0 bottom-6 border-t border-dashed border-rose-500/60 z-10 flex justify-end pr-2">
                <span className="text-[10px] font-mono text-rose-400 bg-steel-950/80 px-1">LCL (-0.015)</span>
              </div>

              {spcSamples.map((val, idx) => {
                const diff = val - nominal;
                const normalizedY = 50 - (diff / 0.015) * 40; // 50% is center
                return (
                  <div key={idx} className="flex-1 h-full flex flex-col justify-center items-center relative z-20">
                    <div
                      className="w-2.5 h-2.5 rounded-full bg-purple-400 glow-cyan border border-white shadow transition-all duration-300"
                      style={{ transform: `translateY(${-((val - nominal) / 0.015) * 45}px)` }}
                      title={`Sample #${idx + 1}: ${val.toFixed(3)} mm`}
                    />
                  </div>
                );
              })}
            </div>

            <div className="flex justify-between text-[10px] font-mono text-zinc-400 pt-1">
              <span>Sample 1</span>
              <span>Process Mean: 450.002 mm</span>
              <span>Sample 20</span>
            </div>
          </div>
        </div>

        {/* Right: SPC Indices Summary */}
        <div className="bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-4">
          <h3 className="text-xs font-bold font-industrial uppercase text-zinc-200">
            Process Capability Indices
          </h3>

          <div className="grid grid-cols-2 gap-3 text-center">
            <div className="p-3 bg-steel-950 rounded-xl border border-steel-800">
              <div className="text-[10px] font-mono text-zinc-400 uppercase">Cp Potential</div>
              <div className="text-xl font-bold font-mono text-emerald-400 mt-0.5">1.74</div>
            </div>
            <div className="p-3 bg-steel-950 rounded-xl border border-steel-800">
              <div className="text-[10px] font-mono text-zinc-400 uppercase">Cpk Capability</div>
              <div className="text-xl font-bold font-mono text-emerald-400 mt-0.5">1.68</div>
            </div>
            <div className="p-3 bg-steel-950 rounded-xl border border-steel-800">
              <div className="text-[10px] font-mono text-zinc-400 uppercase">Pp Overall</div>
              <div className="text-xl font-bold font-mono text-sky-400 mt-0.5">1.65</div>
            </div>
            <div className="p-3 bg-steel-950 rounded-xl border border-steel-800">
              <div className="text-[10px] font-mono text-zinc-400 uppercase">Ppk Index</div>
              <div className="text-xl font-bold font-mono text-sky-400 mt-0.5">1.59</div>
            </div>
          </div>

          <div className="p-3 bg-steel-950 rounded-xl border border-steel-800 text-xs text-zinc-300">
            Process demonstrates robust 1.68 Cpk capability (&gt; 1.33 requirement). Estimated defect rate &lt; 0.23 PPM.
          </div>
        </div>
      </div>

      {/* OEE Table */}
      <div className="bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-4">
        <h3 className="text-xs font-bold font-industrial uppercase text-zinc-200 flex items-center gap-2">
          <BarChart2 className="w-4 h-4 text-purple-400" />
          Overall Equipment Effectiveness (OEE) by Cell
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-steel-950 font-mono text-zinc-400 border-b border-steel-800">
              <tr>
                <th className="p-3">Cell / Asset</th>
                <th className="p-3">Availability (%)</th>
                <th className="p-3">Performance (%)</th>
                <th className="p-3">Quality Rate (%)</th>
                <th className="p-3">Total OEE (%)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-steel-800 font-mono">
              {oeeCells.map((c, i) => (
                <tr key={i} className="hover:bg-steel-850/50">
                  <td className="p-3 text-zinc-200 font-sans font-bold">{c.cell}</td>
                  <td className="p-3 text-zinc-300">{c.availability.toFixed(1)}%</td>
                  <td className="p-3 text-zinc-300">{c.performance.toFixed(1)}%</td>
                  <td className="p-3 text-emerald-400">{c.quality.toFixed(1)}%</td>
                  <td className="p-3">
                    <span className="px-2.5 py-1 rounded-lg bg-purple-500/20 text-purple-300 font-bold">
                      {c.oee.toFixed(1)}%
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
