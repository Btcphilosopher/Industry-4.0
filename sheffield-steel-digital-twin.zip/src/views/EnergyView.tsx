import React from 'react';
import { 
  Zap, 
  Leaf, 
  TrendingDown, 
  AlertTriangle, 
  DollarSign, 
  Wind, 
  Droplet,
  Flame,
  Activity
} from 'lucide-react';
import { SimulationState } from '../services/simulation.service';

interface EnergyViewProps {
  state: SimulationState;
}

export const EnergyView: React.FC<EnergyViewProps> = ({ state }) => {
  const energy = state.energy;

  return (
    <div className="h-full flex flex-col bg-steel-950 p-4 gap-4 overflow-y-auto select-none">
      {/* Header */}
      <div className="bg-steel-900 border border-steel-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-yellow-500/20 text-yellow-400 text-xs font-mono font-bold border border-yellow-500/30">
              SUBSTATION & SUSTAINABILITY
            </span>
            <h2 className="text-lg font-bold font-industrial text-zinc-100">
              Plant Energy Management & Decarbonisation Dashboard
            </h2>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            132kV National Grid Triad peak demand tracking, power factor compensation, and Scope 1 & 2 carbon intensity.
          </p>
        </div>

        {/* Peak Demand Status Badge */}
        <div className={`px-3 py-1.5 rounded-xl border text-xs font-mono font-bold flex items-center gap-2 ${
          energy.peakDemandPenaltyActive
            ? 'bg-rose-950/80 text-rose-300 border-rose-700 animate-pulse'
            : 'bg-emerald-950/80 text-emerald-300 border-emerald-700'
        }`}>
          <Zap className="w-4 h-4" />
          <span>{energy.peakDemandPenaltyActive ? 'TRIAD PEAK TARIFF ACTIVE' : 'NOMINAL GRID TARIFF'}</span>
        </div>
      </div>

      {/* Main Grid: 4 Top KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-steel-900 border border-steel-800 rounded-2xl p-4 space-y-1">
          <div className="text-[10px] font-mono text-zinc-400 uppercase flex items-center justify-between">
            <span>Total Active Demand</span>
            <Zap className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold font-mono-num text-zinc-100">
            {energy.totalGridDrawMW.toFixed(1)} <span className="text-sm font-normal text-zinc-400">MW</span>
          </div>
          <div className="text-[11px] text-zinc-400">
            EAF: {energy.eafDrawMW.toFixed(1)} MW • Mill: {energy.rollingDrawMW.toFixed(1)} MW
          </div>
        </div>

        <div className="bg-steel-900 border border-steel-800 rounded-2xl p-4 space-y-1">
          <div className="text-[10px] font-mono text-zinc-400 uppercase flex items-center justify-between">
            <span>Specific Energy</span>
            <Activity className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-2xl font-bold font-mono-num text-sky-300">
            {energy.specificEnergyKwhTonne} <span className="text-sm font-normal text-zinc-400">kWh/t</span>
          </div>
          <div className="text-[11px] text-zinc-400">
            Target: &lt; {energy.targetSpecificEnergyKwhTonne} kWh/t melted
          </div>
        </div>

        <div className="bg-steel-900 border border-steel-800 rounded-2xl p-4 space-y-1">
          <div className="text-[10px] font-mono text-zinc-400 uppercase flex items-center justify-between">
            <span>Carbon Intensity</span>
            <Leaf className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold font-mono-num text-emerald-400">
            {energy.carbonIntensityKgCO2Ton} <span className="text-sm font-normal text-zinc-400">kg CO₂e/t</span>
          </div>
          <div className="text-[11px] text-zinc-400">
            -68% vs Blast Furnace route (1,850 kg/t)
          </div>
        </div>

        <div className="bg-steel-900 border border-steel-800 rounded-2xl p-4 space-y-1">
          <div className="text-[10px] font-mono text-zinc-400 uppercase flex items-center justify-between">
            <span>Power Factor (cos φ)</span>
            <TrendingDown className="w-4 h-4 text-teal-400" />
          </div>
          <div className="text-2xl font-bold font-mono-num text-zinc-100">
            {energy.powerFactor.toFixed(2)}
          </div>
          <div className="text-[11px] text-zinc-400">
            SVC Capacitor Bank Online
          </div>
        </div>
      </div>

      {/* Energy Breakdown & Utilities Telemetry */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-4">
          <h3 className="text-sm font-bold font-industrial uppercase text-zinc-200">
            Plant-Wide Power Demand Breakdown (MW)
          </h3>

          <div className="space-y-3">
            {[
              { name: 'EAF-01 Electric Arc Furnace', mw: energy.eafDrawMW, total: 75, color: 'bg-orange-500' },
              { name: 'MILL-01 Heavy Rolling Mill', mw: energy.rollingDrawMW, total: 15, color: 'bg-purple-500' },
              { name: 'FORGE-01 30MN Hydraulic Press', mw: 4.2, total: 10, color: 'bg-indigo-500' },
              { name: 'CNC-04 & Robotic Machining Cells', mw: energy.machiningDrawMW, total: 5, color: 'bg-emerald-500' },
              { name: 'Auxiliary & Cooling Water Pumps', mw: energy.auxiliaryDrawMW, total: 5, color: 'bg-sky-500' }
            ].map(item => (
              <div key={item.name} className="space-y-1">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-zinc-300">{item.name}</span>
                  <span className="font-bold text-zinc-100">{item.mw.toFixed(1)} MW</span>
                </div>
                <div className="w-full bg-steel-950 h-2.5 rounded-full overflow-hidden border border-steel-800">
                  <div 
                    className={`${item.color} h-full transition-all duration-500`}
                    style={{ width: `${(item.mw / 75) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Fluid & Gas Utilities */}
        <div className="bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-4">
          <h3 className="text-sm font-bold font-industrial uppercase text-zinc-200">
            Factory Utility Distribution
          </h3>

          <div className="space-y-2.5 text-xs font-mono">
            <div className="p-3 bg-steel-950 rounded-xl border border-steel-800 flex justify-between items-center">
              <span className="text-zinc-400 flex items-center gap-2">
                <Flame className="w-3.5 h-3.5 text-orange-400" />
                Natural Gas Flow
              </span>
              <span className="font-bold text-zinc-100">{energy.naturalGasFlowNm3H} Nm³/h</span>
            </div>

            <div className="p-3 bg-steel-950 rounded-xl border border-steel-800 flex justify-between items-center">
              <span className="text-zinc-400 flex items-center gap-2">
                <Wind className="w-3.5 h-3.5 text-sky-400" />
                Compressed Air Ring
              </span>
              <span className="font-bold text-zinc-100">{energy.compressedAirPressureBar.toFixed(1)} bar</span>
            </div>

            <div className="p-3 bg-steel-950 rounded-xl border border-steel-800 flex justify-between items-center">
              <span className="text-zinc-400 flex items-center gap-2">
                <Droplet className="w-3.5 h-3.5 text-teal-400" />
                Furnace Cooling Water
              </span>
              <span className="font-bold text-zinc-100">{energy.coolingWaterFlowM3H} m³/h</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
