import React, { useState } from 'react';
import { 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  Activity, 
  ShieldCheck, 
  FileCheck, 
  Search,
  Maximize2
} from 'lucide-react';
import { SimulationState } from '../services/simulation.service';

interface QualityViewProps {
  state: SimulationState;
}

export const QualityView: React.FC<QualityViewProps> = ({ state }) => {
  const [selectedTab, setSelectedTab] = useState<'CMM' | 'ULTRASONIC' | 'MECHANICAL'>('CMM');

  // CMM Inspection Points (Nominal vs Actual)
  const cmmFeatures = [
    { feature: 'Shaft Main Bearing Diameter ØA', nominal: 450.000, actual: 450.003, tolLow: -0.015, tolHigh: 0.015, dev: 0.003, status: 'PASS' },
    { feature: 'Flange Coupling Pitch Circle ØB', nominal: 680.000, actual: 679.994, tolLow: -0.020, tolHigh: 0.020, dev: -0.006, status: 'PASS' },
    { feature: 'Drive Keyway Width W1', nominal: 45.000, actual: 45.008, tolLow: 0.000, tolHigh: 0.025, dev: 0.008, status: 'PASS' },
    { feature: 'Journal Cylindricity / Roundness', nominal: 0.000, actual: 0.004, tolLow: 0.000, tolHigh: 0.008, dev: 0.004, status: 'PASS' },
    { feature: 'Total Axial Runout (TIR)', nominal: 0.000, actual: 0.006, tolLow: 0.000, tolHigh: 0.012, dev: 0.006, status: 'PASS' }
  ];

  // Ultrasonic A-Scan simulated waveform (50 points)
  const aScanWaveform = [
    5, 12, 85, 20, 8, 4, 3, 2, 2, 3, 4, 2, 3, 2, 4, 6, 8, 12, 10, 8, 5, 4, 3, 4,
    5, 8, 12, 8, 4, 3, 2, 2, 3, 4, 6, 10, 14, 95, 28, 12, 6, 4, 3, 2, 2, 3, 2, 1, 0, 0
  ];

  return (
    <div className="h-full flex flex-col bg-steel-950 p-4 gap-4 overflow-y-auto select-none">
      {/* Header */}
      <div className="bg-steel-900 border border-steel-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-teal-500/20 text-teal-400 text-xs font-mono font-bold border border-teal-500/30">
              QUALITY ASSURANCE & METROLOGY
            </span>
            <h2 className="text-lg font-bold font-industrial text-zinc-100">
              Dimensional Inspection, NDT & Mechanical Testing Lab
            </h2>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Bridge CMM coordinate verification (ISO 10360), phased array ultrasonic flaw detection, and Charpy impact certs.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {(['CMM', 'ULTRASONIC', 'MECHANICAL'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setSelectedTab(tab)}
              className={`px-3 py-1.5 rounded-xl text-xs font-mono font-medium transition-all border ${
                selectedTab === tab
                  ? 'bg-teal-500/20 text-teal-300 border-teal-500/50 font-bold'
                  : 'bg-steel-800 text-zinc-400 border-steel-700 hover:text-zinc-200'
              }`}
            >
              {tab === 'CMM' ? '3D CMM Report' : tab === 'ULTRASONIC' ? 'Ultrasonic NDT' : 'Tensile & Impact'}
            </button>
          ))}
        </div>
      </div>

      {/* Tab 1: CMM 3D Coordinate Report */}
      {selectedTab === 'CMM' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-steel-800 pb-3">
              <div>
                <h3 className="text-sm font-bold font-industrial text-zinc-100 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  CMM-02 Bridge Coordinate Metrology Report (Part #SPW-26-0917-0042)
                </h3>
                <p className="text-xs text-zinc-400">Class 1 Temperature Controlled Lab @ 20.02°C</p>
              </div>
              <span className="px-2.5 py-1 rounded-lg text-xs font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                100% DIMENSIONAL PASS
              </span>
            </div>

            {/* Tolerances Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-steel-950 font-mono text-zinc-400 border-b border-steel-800">
                  <tr>
                    <th className="p-2.5">Feature / Dimension</th>
                    <th className="p-2.5">Nominal (mm)</th>
                    <th className="p-2.5">Actual (mm)</th>
                    <th className="p-2.5">Tolerance</th>
                    <th className="p-2.5">Deviation</th>
                    <th className="p-2.5">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-steel-800 font-mono">
                  {cmmFeatures.map((f, i) => (
                    <tr key={i} className="hover:bg-steel-850/50">
                      <td className="p-2.5 text-zinc-200 font-sans font-medium">{f.feature}</td>
                      <td className="p-2.5 text-zinc-400">{f.nominal.toFixed(3)}</td>
                      <td className="p-2.5 text-zinc-100 font-bold">{f.actual.toFixed(3)}</td>
                      <td className="p-2.5 text-zinc-400">[{f.tolLow.toFixed(3)}, +{f.tolHigh.toFixed(3)}]</td>
                      <td className="p-2.5 text-sky-400 font-bold">{f.dev >= 0 ? `+${f.dev.toFixed(3)}` : f.dev.toFixed(3)}</td>
                      <td className="p-2.5">
                        <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold text-[10px]">
                          {f.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-4">
            <h4 className="text-xs font-bold font-industrial uppercase text-zinc-300">
              Metrology Traceability
            </h4>
            <div className="space-y-3 text-xs">
              <div className="p-3 bg-steel-950 rounded-xl border border-steel-800 space-y-1">
                <div className="text-zinc-400">Laser Calibration Standard</div>
                <div className="font-mono text-zinc-200 font-bold">ISO 10360-2 (0.8 + L/400 µm)</div>
              </div>
              <div className="p-3 bg-steel-950 rounded-xl border border-steel-800 space-y-1">
                <div className="text-zinc-400">Probe Scanning Head</div>
                <div className="font-mono text-zinc-200 font-bold">Renishaw REVO-2 5-Axis Infinite</div>
              </div>
              <div className="p-3 bg-steel-950 rounded-xl border border-steel-800 space-y-1">
                <div className="text-zinc-400">Inspecting Metrologist</div>
                <div className="font-mono text-zinc-200 font-bold">D. Thornton (Lead QA Officer)</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Ultrasonic NDT */}
      {selectedTab === 'ULTRASONIC' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-steel-800 pb-3">
              <div>
                <h3 className="text-sm font-bold font-industrial text-zinc-100 flex items-center gap-2">
                  <Activity className="w-4 h-4 text-teal-400" />
                  NDT-01 Phased Array Ultrasonic Immersion A-Scan (5.0 MHz)
                </h3>
                <p className="text-xs text-zinc-400">Class A Aerospace Defect-Free Acoustic Gate Verification</p>
              </div>
              <span className="px-2.5 py-1 rounded-lg text-xs font-mono font-bold bg-teal-500/20 text-teal-300 border border-teal-500/30">
                CLASS A SOUND
              </span>
            </div>

            {/* A-Scan Waveform Visualization */}
            <div className="p-4 bg-steel-950 rounded-xl border border-steel-800 space-y-2">
              <div className="flex justify-between text-xs font-mono text-zinc-400">
                <span>Front Surface Echo (Gate A: 85%)</span>
                <span className="text-amber-400">Backwall Echo (Gate B: 95%)</span>
              </div>

              {/* Bar waveform */}
              <div className="h-44 flex items-end gap-1 bg-[#0a0d0f] p-3 rounded-lg border border-steel-800">
                {aScanWaveform.map((amp, idx) => (
                  <div key={idx} className="flex-1 bg-steel-800 h-full flex items-end">
                    <div
                      className={`w-full transition-all duration-300 ${
                        amp > 80 ? 'bg-teal-400 glow-cyan' : amp > 10 ? 'bg-sky-500' : 'bg-steel-600'
                      }`}
                      style={{ height: `${amp}%` }}
                    />
                  </div>
                ))}
              </div>

              <div className="flex justify-between text-[10px] font-mono text-zinc-400">
                <span>0 mm (Probe Face)</span>
                <span>Depth: 225 mm (Central Axis)</span>
                <span>450 mm (Backwall)</span>
              </div>
            </div>
          </div>

          <div className="bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-4">
            <h4 className="text-xs font-bold font-industrial uppercase text-zinc-300">
              NDT Scan Settings
            </h4>
            <div className="space-y-3 text-xs font-mono">
              <div className="p-3 bg-steel-950 rounded-xl border border-steel-800 flex justify-between">
                <span className="text-zinc-400">Transducer Frequency</span>
                <span className="text-zinc-100 font-bold">5.0 MHz</span>
              </div>
              <div className="p-3 bg-steel-950 rounded-xl border border-steel-800 flex justify-between">
                <span className="text-zinc-400">Receiver Gain</span>
                <span className="text-zinc-100 font-bold">42.5 dB</span>
              </div>
              <div className="p-3 bg-steel-950 rounded-xl border border-steel-800 flex justify-between">
                <span className="text-zinc-400">Subsurface Flaws</span>
                <span className="text-emerald-400 font-bold">0 Detected</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Mechanical Testing */}
      {selectedTab === 'MECHANICAL' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-4">
            <h3 className="text-sm font-bold font-industrial text-zinc-100 flex items-center gap-2">
              <FileCheck className="w-4 h-4 text-sky-400" />
              Tensile & Charpy V-Notch Mechanical Test Results
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
              <div className="p-3 bg-steel-950 rounded-xl border border-steel-800">
                <div className="text-[10px] font-mono text-zinc-400 uppercase">Yield Strength</div>
                <div className="text-base font-bold font-mono-num text-emerald-400 mt-1">372 MPa</div>
                <div className="text-[10px] text-zinc-400">Min 355 MPa</div>
              </div>
              <div className="p-3 bg-steel-950 rounded-xl border border-steel-800">
                <div className="text-[10px] font-mono text-zinc-400 uppercase">Tensile Strength</div>
                <div className="text-base font-bold font-mono-num text-sky-400 mt-1">528 MPa</div>
                <div className="text-[10px] text-zinc-400">Aim 510-600 MPa</div>
              </div>
              <div className="p-3 bg-steel-950 rounded-xl border border-steel-800">
                <div className="text-[10px] font-mono text-zinc-400 uppercase">Elongation A5</div>
                <div className="text-base font-bold font-mono-num text-zinc-100 mt-1">24.5%</div>
                <div className="text-[10px] text-zinc-400">Min 22.0%</div>
              </div>
              <div className="p-3 bg-steel-950 rounded-xl border border-steel-800">
                <div className="text-[10px] font-mono text-zinc-400 uppercase">Charpy @ -20°C</div>
                <div className="text-base font-bold font-mono-num text-teal-400 mt-1">54 Joules</div>
                <div className="text-[10px] text-zinc-400">Min 27 Joules</div>
              </div>
            </div>
          </div>

          <div className="bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-4">
            <h4 className="text-xs font-bold font-industrial uppercase text-zinc-300">
              Certifying Standard
            </h4>
            <div className="p-3 bg-steel-950 rounded-xl border border-steel-800 text-xs space-y-2">
              <div className="font-bold text-zinc-200">BS EN 10204 3.1 Inspection Certificate</div>
              <p className="text-[11px] text-zinc-400">
                Authorized independent Sheffield test laboratory verification for Lloyd’s Register / DNV-GL marine certification.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
