import React, { useState } from 'react';
import { 
  Flame, 
  Zap, 
  Droplet, 
  Wind, 
  Gauge, 
  Play, 
  CheckCircle2, 
  AlertTriangle,
  Layers,
  Thermometer,
  ShieldAlert,
  ArrowRight
} from 'lucide-react';
import { SimulationState } from '../services/simulation.service';
import { calculateCEV } from '../types/metallurgy.types';

interface SteelmakingViewProps {
  state: SimulationState;
  onSetEafPower: (mw: number) => void;
  onTrimAlloy: (heatId: string, element: 'C' | 'Mn' | 'Cr' | 'Ni' | 'Mo' | 'V', amountKg: number) => void;
  onSelectHeat: (heatId: string) => void;
}

export const SteelmakingView: React.FC<SteelmakingViewProps> = ({
  state,
  onSetEafPower,
  onTrimAlloy,
  onSelectHeat
}) => {
  const [activeTab, setActiveTab] = useState<'EAF' | 'LF' | 'VD' | 'CCM'>('EAF');
  const activeHeat = state.heats.find(h => h.id === state.selectedHeatId) || state.heats[0];
  const eaf = state.machines.find(m => m.id === 'EAF-01');
  const lf = state.machines.find(m => m.id === 'LF-01');
  const vd = state.machines.find(m => m.id === 'VD-01');
  const ccm = state.machines.find(m => m.id === 'CCM-01');

  const cev = calculateCEV(activeHeat.chemistry);

  return (
    <div className="h-full flex flex-col bg-steel-950 p-4 gap-4 overflow-y-auto select-none">
      {/* Top Selector & Active Heat Header */}
      <div className="bg-steel-900 border border-steel-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-orange-500/20 text-orange-400 text-xs font-mono font-bold border border-orange-500/30">
              HEAT DISPATCH TRACKER
            </span>
            <h2 className="text-lg font-bold font-industrial text-zinc-100">
              Primary & Secondary Metallurgical Operating Station
            </h2>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Real-time thermal equilibrium, chemical trimming, slag basicity & vacuum degassing kinetics.
          </p>
        </div>

        {/* Heat Selector */}
        <div className="flex items-center gap-2">
          {state.heats.map(h => (
            <button
              key={h.id}
              onClick={() => onSelectHeat(h.id)}
              className={`px-3 py-2 rounded-xl text-xs font-mono transition-all flex items-center gap-2 border ${
                h.id === activeHeat.id
                  ? 'bg-orange-500/20 text-orange-300 border-orange-500/50 shadow-sm'
                  : 'bg-steel-800 text-zinc-400 border-steel-700 hover:text-zinc-200'
              }`}
            >
              <Flame className="w-3.5 h-3.5" />
              <div>
                <div className="font-bold">{h.id}</div>
                <div className="text-[10px] text-zinc-400">{h.gradeId} ({h.stage})</div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Process Tabs */}
      <div className="flex items-center gap-2 border-b border-steel-800 pb-2">
        {(
          [
            { id: 'EAF', label: 'EAF-01 Electric Arc Furnace', icon: <Zap className="w-4 h-4 text-orange-400" /> },
            { id: 'LF', label: 'LF-01 Ladle Refining & Trimming', icon: <Layers className="w-4 h-4 text-sky-400" /> },
            { id: 'VD', label: 'VD-01 Tank Vacuum Degasser', icon: <Wind className="w-4 h-4 text-teal-400" /> },
            { id: 'CCM', label: 'CCM-01 Continuous Bloom Caster', icon: <Droplet className="w-4 h-4 text-red-400" /> }
          ] as const
        ).map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 rounded-xl text-xs font-medium flex items-center gap-2 transition-all border ${
              activeTab === tab.id
                ? 'bg-steel-800 text-white font-bold border-steel-600 shadow-md'
                : 'text-zinc-400 border-transparent hover:bg-steel-900 hover:text-zinc-200'
            }`}
          >
            {tab.icon}
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Tab 1: EAF Electric Arc Furnace */}
      {activeTab === 'EAF' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Main Melting Controls */}
          <div className="lg:col-span-2 bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold font-industrial text-zinc-100 flex items-center gap-2">
                  <Flame className="w-4 h-4 text-orange-400" />
                  EAF-01 90-Tonne AC Melting Vessel
                </h3>
                <p className="text-xs text-zinc-400">75MW Water-Cooled Transformer & Foaming Slag Controller</p>
              </div>
              <span className="px-2.5 py-1 rounded-lg text-xs font-mono font-bold bg-orange-500/20 text-orange-300 border border-orange-500/30">
                STAGE: {activeHeat.stage}
              </span>
            </div>

            {/* Arc Power Slider & Tap Temp Gauge */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-steel-950 p-4 rounded-xl border border-steel-800">
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-zinc-400">Active Arc Power</span>
                  <span className="font-mono font-bold text-amber-400">{eaf?.powerDrawMW.toFixed(1)} MW / 75.0 MW</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="75"
                  step="0.5"
                  value={eaf?.powerDrawMW || 0}
                  onChange={(e) => onSetEafPower(parseFloat(e.target.value))}
                  className="w-full accent-orange-500 h-2 bg-steel-800 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[10px] font-mono text-zinc-400 mt-1">
                  <span>0 MW (Idle)</span>
                  <span>45 MW (Refine)</span>
                  <span>75 MW (Max Bore-In)</span>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-zinc-400">Bath Melt Temperature</span>
                  <span className="font-mono font-bold text-orange-400">{activeHeat.currentTemp}°C</span>
                </div>
                <div className="w-full bg-steel-800 h-2 rounded-lg overflow-hidden relative">
                  <div 
                    className="bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 h-full transition-all duration-300"
                    style={{ width: `${(activeHeat.currentTemp / 1700) * 100}%` }}
                  />
                  {/* Tap Line marker */}
                  <div 
                    className="absolute top-0 bottom-0 w-0.5 bg-white shadow-sm"
                    style={{ left: `${(activeHeat.targetTapTemp / 1700) * 100}%` }}
                    title="Tap Target: 1640°C"
                  />
                </div>
                <div className="flex justify-between text-[10px] font-mono text-zinc-400 mt-1">
                  <span>1400°C (Liquidus)</span>
                  <span className="text-white font-bold">Tap: {activeHeat.targetTapTemp}°C</span>
                  <span>1700°C (Max)</span>
                </div>
              </div>
            </div>

            {/* Live Electrical & Chemical Telemetry Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 bg-steel-950 rounded-xl border border-steel-800">
                <div className="text-[10px] font-mono text-zinc-400 uppercase">Phase A Current</div>
                <div className="text-base font-bold font-mono-num text-zinc-100 mt-0.5">
                  {eaf?.telemetry['Phase A Current (kA)']} kA
                </div>
              </div>
              <div className="p-3 bg-steel-950 rounded-xl border border-steel-800">
                <div className="text-[10px] font-mono text-zinc-400 uppercase">Phase B Current</div>
                <div className="text-base font-bold font-mono-num text-zinc-100 mt-0.5">
                  {eaf?.telemetry['Phase B Current (kA)']} kA
                </div>
              </div>
              <div className="p-3 bg-steel-950 rounded-xl border border-steel-800">
                <div className="text-[10px] font-mono text-zinc-400 uppercase">Specific Energy</div>
                <div className="text-base font-bold font-mono-num text-amber-400 mt-0.5">
                  {activeHeat.specificEnergyKwhTon} kWh/t
                </div>
              </div>
              <div className="p-3 bg-steel-950 rounded-xl border border-steel-800">
                <div className="text-[10px] font-mono text-zinc-400 uppercase">Slag Basicity</div>
                <div className="text-base font-bold font-mono-num text-emerald-400 mt-0.5">
                  {activeHeat.slagBasicity.toFixed(2)}
                </div>
              </div>
            </div>

            {/* Tap Readiness Banner */}
            <div className="p-4 rounded-xl bg-orange-950/40 border border-orange-800/60 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 text-orange-400" />
                <div>
                  <div className="text-xs font-bold text-orange-200">Tap Status: {eaf?.telemetry['Tap Readiness']}</div>
                  <div className="text-[11px] text-zinc-400">Scrap charge completely dissolved; dephosphorisation slag skimmed.</div>
                </div>
              </div>
              <button 
                onClick={() => alert(`Simulated: Heat ${activeHeat.id} tapped into 90t pre-heated transfer ladle.`)}
                className="px-4 py-2 bg-orange-600 hover:bg-orange-500 text-white rounded-lg text-xs font-bold font-industrial transition-all shadow-md"
              >
                TAP TO LADLE
              </button>
            </div>
          </div>

          {/* Chemistry Panel */}
          <div className="bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-steel-800 pb-2">
              <h4 className="text-xs font-bold font-industrial uppercase text-zinc-300">
                OES Spectrometer Chemistry
              </h4>
              <span className="text-[10px] font-mono text-sky-400">Sample #4 @ 14:30</span>
            </div>

            <div className="space-y-2 text-xs">
              {Object.entries(activeHeat.chemistry).filter(([k]) => !k.includes('_ppm')).map(([elem, val]) => {
                const target = activeHeat.targetChemistry[elem as keyof typeof activeHeat.targetChemistry] as number;
                const diff = (val as number) - target;
                return (
                  <div key={elem} className="flex items-center justify-between p-2 bg-steel-950 rounded-lg border border-steel-800">
                    <span className="font-mono font-bold text-zinc-300">{elem}</span>
                    <div className="flex items-center gap-3 font-mono">
                      <span className="text-zinc-400 text-[11px]">Aim: {target}%</span>
                      <span className="font-bold text-zinc-100">{val}%</span>
                      <span className={`text-[10px] ${Math.abs(diff) < 0.02 ? 'text-emerald-400' : 'text-amber-400'}`}>
                        {diff >= 0 ? `+${diff.toFixed(3)}` : diff.toFixed(3)}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Calculated Indices */}
            <div className="p-3 bg-steel-950 rounded-xl border border-steel-800 space-y-2">
              <div className="flex justify-between text-xs">
                <span className="text-zinc-400">Carbon Equivalent (IIW CEV)</span>
                <span className="font-mono font-bold text-zinc-200">{cev.toFixed(3)}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-zinc-400">Dissolved Hydrogen [H]</span>
                <span className="font-mono font-bold text-teal-400">{activeHeat.chemistry.H_ppm} ppm</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-zinc-400">Dissolved Nitrogen [N]</span>
                <span className="font-mono font-bold text-sky-400">{activeHeat.chemistry.N_ppm} ppm</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Ladle Refining & Trimming */}
      {activeTab === 'LF' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold font-industrial text-zinc-100 flex items-center gap-2">
                  <Layers className="w-4 h-4 text-sky-400" />
                  LF-01 18MVA Ladle Refining Station
                </h3>
                <p className="text-xs text-zinc-400">Argon Porous Plug Bubbling, Calcium-Aluminate Desulfurisation & Wire Injection</p>
              </div>
              <span className="px-2.5 py-1 rounded-lg text-xs font-mono font-bold bg-sky-500/20 text-sky-300 border border-sky-500/30">
                STIRRING: {lf?.telemetry['Argon Bottom Flow (NL/min)']} NL/min
              </span>
            </div>

            {/* Interactive Alloy Wire Trimming Buttons */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold font-industrial uppercase text-zinc-300">
                Automated Cored Wire Injection Feeders
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {(
                  [
                    { element: 'C', label: 'Carbon (C Wire)', current: activeHeat.chemistry.C },
                    { element: 'Mn', label: 'Ferro-Manganese (FeMn)', current: activeHeat.chemistry.Mn },
                    { element: 'Cr', label: 'Ferro-Chrome (FeCr)', current: activeHeat.chemistry.Cr },
                    { element: 'Mo', label: 'Ferro-Moly (FeMo)', current: activeHeat.chemistry.Mo },
                    { element: 'V', label: 'Ferro-Vanadium (FeV)', current: activeHeat.chemistry.V },
                    { element: 'Ni', label: 'Nickel Briquettes (Ni)', current: activeHeat.chemistry.Ni }
                  ] as const
                ).map(item => (
                  <div key={item.element} className="p-3 bg-steel-950 rounded-xl border border-steel-800 space-y-2">
                    <div className="flex justify-between items-baseline">
                      <span className="font-bold text-xs text-zinc-200">{item.label}</span>
                      <span className="font-mono text-xs text-sky-400">{item.current}%</span>
                    </div>
                    <div className="flex gap-1.5">
                      <button
                        onClick={() => onTrimAlloy(activeHeat.id, item.element, 20)}
                        className="flex-1 py-1 bg-steel-800 hover:bg-steel-700 text-sky-300 rounded text-[11px] font-mono transition-all"
                      >
                        +20kg
                      </button>
                      <button
                        onClick={() => onTrimAlloy(activeHeat.id, item.element, 50)}
                        className="flex-1 py-1 bg-steel-800 hover:bg-steel-700 text-sky-300 rounded text-[11px] font-mono transition-all"
                      >
                        +50kg
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Desulfurization Kinetics */}
            <div className="p-4 bg-steel-950 rounded-xl border border-steel-800 space-y-2">
              <div className="flex justify-between text-xs">
                <span className="text-zinc-300 font-bold">Desulfurisation Progress (Target S &lt; 0.008%)</span>
                <span className="font-mono text-emerald-400 font-bold">Current: {activeHeat.chemistry.S}%</span>
              </div>
              <div className="w-full bg-steel-800 h-2 rounded-full overflow-hidden">
                <div 
                  className="bg-emerald-500 h-full transition-all duration-500"
                  style={{ width: `${Math.max(10, 100 - (activeHeat.chemistry.S / 0.03) * 100)}%` }}
                />
              </div>
              <div className="text-[11px] text-zinc-400">
                Synthetic slag composition: 56.2% CaO, 28.5% Al2O3, 6.8% SiO2 (Basicity = {activeHeat.slagBasicity.toFixed(2)})
              </div>
            </div>
          </div>

          <div className="bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-4">
            <h4 className="text-xs font-bold font-industrial uppercase text-zinc-300">
              Ladle Station Telemetry
            </h4>
            <div className="space-y-2 text-xs">
              {Object.entries(lf?.telemetry || {}).map(([k, v]) => (
                <div key={k} className="flex justify-between p-2.5 bg-steel-950 rounded-lg border border-steel-800">
                  <span className="text-zinc-400 text-[11px]">{k}</span>
                  <span className="font-mono font-bold text-zinc-100">{String(v)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Vacuum Degassing */}
      {activeTab === 'VD' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold font-industrial text-zinc-100 flex items-center gap-2">
                  <Wind className="w-4 h-4 text-teal-400" />
                  VD-01 Tank Vacuum Degasser
                </h3>
                <p className="text-xs text-zinc-400">Deep Vacuum Gas Extraction (&lt;1.0 mbar) for Hydrogen Flake Prevention</p>
              </div>
              <span className="px-2.5 py-1 rounded-lg text-xs font-mono font-bold bg-teal-500/20 text-teal-300 border border-teal-500/30">
                CHAMBER: {vd?.telemetry['Chamber Pressure (mbar)']} mbar
              </span>
            </div>

            {/* Degassing Gauges */}
            <div className="grid grid-cols-3 gap-3">
              <div className="p-3 bg-steel-950 rounded-xl border border-steel-800 text-center">
                <div className="text-[10px] font-mono text-zinc-400 uppercase">Hydrogen [H]</div>
                <div className="text-xl font-bold font-mono-num text-teal-400 mt-1">
                  {activeHeat.chemistry.H_ppm} ppm
                </div>
                <div className="text-[10px] text-zinc-400 mt-0.5">Aim &lt; 1.5 ppm</div>
              </div>
              <div className="p-3 bg-steel-950 rounded-xl border border-steel-800 text-center">
                <div className="text-[10px] font-mono text-zinc-400 uppercase">Nitrogen [N]</div>
                <div className="text-xl font-bold font-mono-num text-sky-400 mt-1">
                  {activeHeat.chemistry.N_ppm} ppm
                </div>
                <div className="text-[10px] text-zinc-400 mt-0.5">Aim &lt; 70 ppm</div>
              </div>
              <div className="p-3 bg-steel-950 rounded-xl border border-steel-800 text-center">
                <div className="text-[10px] font-mono text-zinc-400 uppercase">Total Oxygen [O]</div>
                <div className="text-xl font-bold font-mono-num text-amber-400 mt-1">
                  {activeHeat.chemistry.O_ppm} ppm
                </div>
                <div className="text-[10px] text-zinc-400 mt-0.5">Aim &lt; 20 ppm</div>
              </div>
            </div>

            <div className="p-4 bg-teal-950/30 border border-teal-800/60 rounded-xl space-y-2">
              <div className="flex items-center gap-2 text-teal-300 font-bold text-xs">
                <CheckCircle2 className="w-4 h-4" />
                Degassing Cycle Complete & Cleared for Casting
              </div>
              <p className="text-[11px] text-zinc-300">
                Hydris immersion probe verified [H] = 1.4 ppm. Ingot will meet BS EN ISO 683-17 / Rolls-Royce aerospace flaking limits.
              </p>
            </div>
          </div>

          <div className="bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-4">
            <h4 className="text-xs font-bold font-industrial uppercase text-zinc-300">
              Steam Ejector & Vacuum Status
            </h4>
            <div className="space-y-2 text-xs">
              {Object.entries(vd?.telemetry || {}).map(([k, v]) => (
                <div key={k} className="flex justify-between p-2.5 bg-steel-950 rounded-lg border border-steel-800">
                  <span className="text-zinc-400 text-[11px]">{k}</span>
                  <span className="font-mono font-bold text-zinc-100">{String(v)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Continuous Casting */}
      {activeTab === 'CCM' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold font-industrial text-zinc-100 flex items-center gap-2">
                  <Droplet className="w-4 h-4 text-red-400" />
                  CCM-01 2-Strand Continuous Bloom Caster
                </h3>
                <p className="text-xs text-zinc-400">Curved Mould with Electromagnetic Stirring & Dynamic Secondary Cooling</p>
              </div>
              <span className="px-2.5 py-1 rounded-lg text-xs font-mono font-bold bg-red-500/20 text-red-300 border border-red-500/30">
                CAST SPEED: {ccm?.telemetry['Strand 1 Casting Speed (m/min)']} m/min
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 bg-steel-950 rounded-xl border border-steel-800">
                <div className="text-[10px] font-mono text-zinc-400 uppercase">Tundish Superheat</div>
                <div className="text-base font-bold font-mono-num text-orange-400 mt-0.5">
                  {activeHeat.tundishSuperheatC}°C
                </div>
              </div>
              <div className="p-3 bg-steel-950 rounded-xl border border-steel-800">
                <div className="text-[10px] font-mono text-zinc-400 uppercase">Mould Oscillation</div>
                <div className="text-base font-bold font-mono-num text-zinc-100 mt-0.5">
                  {ccm?.telemetry['Mould Oscillation Frequency (cpm)']} cpm
                </div>
              </div>
              <div className="p-3 bg-steel-950 rounded-xl border border-steel-800">
                <div className="text-[10px] font-mono text-zinc-400 uppercase">Exit Surface Temp</div>
                <div className="text-base font-bold font-mono-num text-red-400 mt-0.5">
                  {ccm?.telemetry['Strand Surface Exit Temp (°C)']}°C
                </div>
              </div>
              <div className="p-3 bg-steel-950 rounded-xl border border-steel-800">
                <div className="text-[10px] font-mono text-zinc-400 uppercase">Torch Cutter Status</div>
                <div className="text-xs font-bold font-mono text-emerald-400 mt-1 truncate">
                  {ccm?.telemetry['Torch Cut Sequence']}
                </div>
              </div>
            </div>
          </div>

          <div className="bg-steel-900 border border-steel-800 rounded-2xl p-5 space-y-4">
            <h4 className="text-xs font-bold font-industrial uppercase text-zinc-300">
              Casting Parameters
            </h4>
            <div className="space-y-2 text-xs">
              {Object.entries(ccm?.telemetry || {}).map(([k, v]) => (
                <div key={k} className="flex justify-between p-2.5 bg-steel-950 rounded-lg border border-steel-800">
                  <span className="text-zinc-400 text-[11px]">{k}</span>
                  <span className="font-mono font-bold text-zinc-100">{String(v)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
