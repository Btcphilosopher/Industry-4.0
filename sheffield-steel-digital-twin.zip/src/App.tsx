import React, { useEffect, useState } from 'react';
import { simulationEngine, SimulationState, SimSpeed } from './services/simulation.service';
import { ViewMode, MachineState } from './types/twin.types';
import { Topbar } from './components/Topbar';
import { Navigation } from './components/Navigation';
import { TwinViewport } from './components/TwinViewport';
import { AssetInspector } from './components/AssetInspector';
import { TimelineStrip } from './components/TimelineStrip';
import { DigitalPassportModal } from './components/DigitalPassportModal';
import { EngineeringAssistModal } from './components/EngineeringAssistModal';

import { SteelmakingView } from './views/SteelmakingView';
import { RoboticsView } from './views/RoboticsView';
import { ProductionView } from './views/ProductionView';
import { MachinesView } from './views/MachinesView';
import { QualityView } from './views/QualityView';
import { EnergyView } from './views/EnergyView';
import { MaintenanceView } from './views/MaintenanceView';
import { LogisticsView } from './views/LogisticsView';
import { AnalyticsView } from './views/AnalyticsView';
import { KnowledgeView } from './views/KnowledgeView';
import { ScenariosView } from './views/ScenariosView';
import { ReplayView } from './views/ReplayView';

export function App() {
  const [state, setState] = useState<SimulationState>(simulationEngine.getState());
  const [currentView, setCurrentView] = useState<ViewMode>('TWIN');
  const [isInspectorOpen, setIsInspectorOpen] = useState(true);
  const [isPassportOpen, setIsPassportOpen] = useState(false);
  const [isAssistOpen, setIsAssistOpen] = useState(false);

  useEffect(() => {
    const unsubscribe = simulationEngine.subscribe((newState) => {
      setState({ ...newState });
    });
    return () => unsubscribe();
  }, []);

  const selectedMachine = state.machines.find(m => m.id === state.selectedMachineId) || null;
  const activeAlarmsCount = state.machines.reduce((acc, m) => acc + m.alarms.length, 0);

  return (
    <div className="h-screen w-screen flex flex-col bg-[#0d1114] text-zinc-100 overflow-hidden font-sans">
      {/* 1. Global Top Industrial Control Bar */}
      <Topbar
        state={state}
        onTogglePlay={() => simulationEngine.togglePlayPause()}
        onSetSpeed={(s: SimSpeed) => simulationEngine.setSpeed(s)}
        onStep={() => simulationEngine.stepOnce()}
        onEmergencyStop={() => simulationEngine.triggerEmergencyStop()}
        onOpenAssistant={() => setIsAssistOpen(true)}
        onOpenPassport={() => setIsPassportOpen(true)}
      />

      {/* 2. Global Navigation Tabs */}
      <Navigation
        currentView={currentView}
        onSelectView={(v) => setCurrentView(v)}
        alarmCount={activeAlarmsCount}
      />

      {/* 3. Main Operational Workspace & Inspector */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* View Routing */}
        <main className="flex-1 h-full overflow-hidden relative">
          {currentView === 'TWIN' && (
            <TwinViewport
              state={state}
              onSelectMachine={(id) => {
                simulationEngine.selectMachine(id);
                setIsInspectorOpen(true);
              }}
            />
          )}

          {currentView === 'STEEL' && (
            <SteelmakingView
              state={state}
              onSetEafPower={(mw) => simulationEngine.setEafPower(mw)}
              onTrimAlloy={(heatId, elem, amt) => simulationEngine.trimAlloy(heatId, elem, amt)}
              onSelectHeat={(heatId) => simulationEngine.selectHeat(heatId)}
            />
          )}

          {currentView === 'ROBOTICS' && (
            <RoboticsView
              state={state}
              onJogJoint={(idx, delta) => simulationEngine.jogRobotJoint(idx, delta)}
              onExecuteWaypoint={(wpId) => simulationEngine.executeRobotWaypoint(wpId)}
            />
          )}

          {currentView === 'PRODUCTION' && (
            <ProductionView
              state={state}
              onSelectOrder={(orderId) => simulationEngine.selectOrder(orderId)}
              onOpenPassport={() => setIsPassportOpen(true)}
            />
          )}

          {currentView === 'MACHINES' && (
            <MachinesView
              state={state}
              onSelectMachine={(id) => {
                simulationEngine.selectMachine(id);
                setIsInspectorOpen(true);
              }}
              onSetMachineState={(id, st) => simulationEngine.setMachineState(id, st)}
            />
          )}

          {currentView === 'QUALITY' && <QualityView state={state} />}

          {currentView === 'ENERGY' && <EnergyView state={state} />}

          {currentView === 'MAINTENANCE' && <MaintenanceView state={state} />}

          {currentView === 'LOGISTICS' && <LogisticsView state={state} />}

          {currentView === 'ANALYTICS' && <AnalyticsView state={state} />}

          {currentView === 'KNOWLEDGE' && <KnowledgeView />}

          {currentView === 'SCENARIOS' && (
            <ScenariosView
              state={state}
              onApplyScenario={(id) => simulationEngine.applyScenario(id)}
            />
          )}

          {currentView === 'REPLAY' && (
            <ReplayView
              state={state}
              onSetSimTime={(sec) => simulationEngine.setSimTime(sec)}
              onTogglePlay={() => simulationEngine.togglePlayPause()}
            />
          )}
        </main>

        {/* Right Side Asset Telemetry Inspector (Collapsible) */}
        {isInspectorOpen && selectedMachine && (
          <AssetInspector
            machine={selectedMachine}
            onClose={() => setIsInspectorOpen(false)}
            onSetState={(st: MachineState) => simulationEngine.setMachineState(selectedMachine.id, st)}
            onAckAlarm={(alarmId) => simulationEngine.ackAlarm(alarmId)}
          />
        )}
      </div>

      {/* 4. Streaming Industrial Timeline Strip */}
      <TimelineStrip
        events={state.events}
        onAckEvent={(id) => simulationEngine.ackAlarm(id)}
        onSelectZone={(zoneId) => {
          simulationEngine.selectZone(zoneId);
        }}
      />

      {/* 5. Modals */}
      <DigitalPassportModal
        isOpen={isPassportOpen}
        onClose={() => setIsPassportOpen(false)}
      />

      <EngineeringAssistModal
        isOpen={isAssistOpen}
        onClose={() => setIsAssistOpen(false)}
        state={state}
      />
    </div>
  );
}

export default App;
