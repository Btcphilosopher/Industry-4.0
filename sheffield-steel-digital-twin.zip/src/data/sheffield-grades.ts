import { SteelGrade } from '../types/metallurgy.types';

export const SHEFFIELD_STEEL_GRADES: SteelGrade[] = [
  {
    id: 'S275JR',
    name: 'S275JR Structural Carbon Steel',
    category: 'STRUCTURAL',
    standard: 'BS EN 10025-2:2019',
    sheffieldHeritageNote: 'Workhorse structural carbon-manganese steel developed in Yorkshire mills for bridge and civil frame engineering.',
    nominalChemistry: {
      C: 0.21,
      Si: 0.25,
      Mn: 1.30,
      P: 0.025,
      S: 0.025,
      Cr: 0.08,
      Ni: 0.05,
      Mo: 0.02,
      V: 0.005,
      Cu: 0.15,
      Al: 0.025,
      N_ppm: 85,
      H_ppm: 2.1,
      O_ppm: 28
    },
    minChemistry: { C: 0.16, Mn: 1.10, Si: 0.15 },
    maxChemistry: { C: 0.24, Mn: 1.50, P: 0.035, S: 0.035 },
    mechanicalProperties: {
      yieldStrengthMpa: 275,
      tensileStrengthMpa: 430,
      elongationPercent: 23,
      hardnessHB: 135,
      charpyVNotchJoules: 27,
      densityKgM3: 7850,
      youngsModulusGpa: 210
    },
    thermalProperties: {
      meltingRangeC: [1490, 1525],
      ac1TempC: 724,
      ac3TempC: 865,
      msTempC: 410,
      mfTempC: 280,
      thermalConductivityWmK: 51.5
    },
    heatTreatment: {
      austenitisingTempC: 890,
      quenchMedium: 'AIR_BLAST',
      temperingRangeC: [550, 620],
      targetHardness: '130 - 150 HB',
      stressReliefTempC: 580
    },
    typicalApplications: ['Heavy architectural structural beams', 'Offshore platform jackets', 'Rail car side frames']
  },
  {
    id: 'S355J2',
    name: 'S355J2 High-Yield Structural Alloy',
    category: 'STRUCTURAL',
    standard: 'BS EN 10025-2 / Norsok M-120',
    sheffieldHeritageNote: 'Micro-alloyed fine-grain steel providing 355 MPa minimum yield strength with verified -20°C Charpy toughness for North Sea energy infrastructure.',
    nominalChemistry: {
      C: 0.18,
      Si: 0.35,
      Mn: 1.50,
      P: 0.018,
      S: 0.012,
      Cr: 0.12,
      Ni: 0.10,
      Mo: 0.04,
      V: 0.045,
      Cu: 0.18,
      Al: 0.035,
      N_ppm: 70,
      H_ppm: 1.8,
      O_ppm: 20
    },
    minChemistry: { C: 0.14, Mn: 1.35, Si: 0.25, V: 0.03 },
    maxChemistry: { C: 0.20, Mn: 1.65, P: 0.025, S: 0.025 },
    mechanicalProperties: {
      yieldStrengthMpa: 355,
      tensileStrengthMpa: 510,
      elongationPercent: 22,
      hardnessHB: 165,
      charpyVNotchJoules: 45,
      densityKgM3: 7850,
      youngsModulusGpa: 210
    },
    thermalProperties: {
      meltingRangeC: [1485, 1520],
      ac1TempC: 730,
      ac3TempC: 875,
      msTempC: 395,
      mfTempC: 260,
      thermalConductivityWmK: 49.0
    },
    heatTreatment: {
      austenitisingTempC: 910,
      quenchMedium: 'AIR_BLAST',
      temperingRangeC: [580, 650],
      targetHardness: '155 - 180 HB',
      stressReliefTempC: 600
    },
    typicalApplications: ['Marine propulsion shaft forgings', 'Wind turbine tower flanges', 'Mobile crane booms']
  },
  {
    id: '304',
    name: 'AISI 304 / 1.4301 "Brearley" Stainless',
    category: 'AUSTENITIC_STAINLESS',
    standard: 'BS EN 10088-3 / ASTM A276',
    sheffieldHeritageNote: 'Direct descendant of Harry Brearley’s pioneering 1913 Sheffield invention of rustless chromium steel at the Brown Firth Research Laboratories.',
    nominalChemistry: {
      C: 0.045,
      Si: 0.45,
      Mn: 1.60,
      P: 0.028,
      S: 0.010,
      Cr: 18.25,
      Ni: 8.40,
      Mo: 0.20,
      V: 0.02,
      Cu: 0.25,
      Al: 0.015,
      N_ppm: 450,
      H_ppm: 2.5,
      O_ppm: 35
    },
    minChemistry: { Cr: 17.50, Ni: 8.00 },
    maxChemistry: { C: 0.07, Cr: 19.50, Ni: 10.50 },
    mechanicalProperties: {
      yieldStrengthMpa: 230,
      tensileStrengthMpa: 600,
      elongationPercent: 48,
      hardnessHB: 170,
      charpyVNotchJoules: 100,
      densityKgM3: 7930,
      youngsModulusGpa: 193
    },
    thermalProperties: {
      meltingRangeC: [1400, 1450],
      ac1TempC: 0, // Austenitic at all temps
      ac3TempC: 0,
      msTempC: -50,
      mfTempC: -196,
      thermalConductivityWmK: 16.2
    },
    heatTreatment: {
      austenitisingTempC: 1060,
      quenchMedium: 'WATER',
      temperingRangeC: [0, 0], // Solution Annealed
      targetHardness: '160 - 185 HB',
      stressReliefTempC: 400
    },
    typicalApplications: ['Sheffield precision surgical instruments', 'Chemical process tanks', 'Cryogenic vessels']
  },
  {
    id: '316L',
    name: 'AISI 316L / 1.4404 Marine Grade Stainless',
    category: 'AUSTENITIC_STAINLESS',
    standard: 'BS EN 10088-3 / ASTM A479',
    sheffieldHeritageNote: 'Molybdenum-enhanced low-carbon austenitic stainless providing pitting corrosion resistance in harsh North Sea saltwater and pharmaceutical environments.',
    nominalChemistry: {
      C: 0.022,
      Si: 0.40,
      Mn: 1.55,
      P: 0.025,
      S: 0.008,
      Cr: 16.80,
      Ni: 10.40,
      Mo: 2.15,
      V: 0.02,
      Cu: 0.20,
      Al: 0.012,
      N_ppm: 550,
      H_ppm: 2.0,
      O_ppm: 30
    },
    minChemistry: { Cr: 16.50, Ni: 10.00, Mo: 2.00 },
    maxChemistry: { C: 0.030, Cr: 18.00, Ni: 13.00, Mo: 2.50 },
    mechanicalProperties: {
      yieldStrengthMpa: 245,
      tensileStrengthMpa: 580,
      elongationPercent: 45,
      hardnessHB: 165,
      charpyVNotchJoules: 105,
      densityKgM3: 8000,
      youngsModulusGpa: 193
    },
    thermalProperties: {
      meltingRangeC: [1375, 1400],
      ac1TempC: 0,
      ac3TempC: 0,
      msTempC: -70,
      mfTempC: -210,
      thermalConductivityWmK: 15.0
    },
    heatTreatment: {
      austenitisingTempC: 1080,
      quenchMedium: 'WATER',
      temperingRangeC: [0, 0],
      targetHardness: '155 - 175 HB',
      stressReliefTempC: 450
    },
    typicalApplications: ['Nuclear coolant piping', 'Offshore subsea manifolds', 'Orthopaedic surgical implants']
  },
  {
    id: '4140',
    name: '42CrMo4 / AISI 4140 Chromium-Moly Alloy',
    category: 'ENGINEERING_ALLOY',
    standard: 'BS EN 10083-3:2018',
    sheffieldHeritageNote: 'Sheffield aerospace and defence benchmark chromium-molybdenum through-hardening alloy with outstanding strength-to-toughness ratio.',
    nominalChemistry: {
      C: 0.41,
      Si: 0.28,
      Mn: 0.75,
      P: 0.015,
      S: 0.010,
      Cr: 1.05,
      Ni: 0.15,
      Mo: 0.22,
      V: 0.01,
      Cu: 0.12,
      Al: 0.025,
      N_ppm: 60,
      H_ppm: 1.5,
      O_ppm: 18
    },
    minChemistry: { C: 0.38, Cr: 0.90, Mo: 0.15, Mn: 0.60 },
    maxChemistry: { C: 0.45, Cr: 1.20, Mo: 0.30, Mn: 0.90 },
    mechanicalProperties: {
      yieldStrengthMpa: 750,
      tensileStrengthMpa: 1000,
      elongationPercent: 14,
      hardnessHB: 300,
      hardnessHRC: 32,
      charpyVNotchJoules: 35,
      densityKgM3: 7850,
      youngsModulusGpa: 210
    },
    thermalProperties: {
      meltingRangeC: [1415, 1460],
      ac1TempC: 735,
      ac3TempC: 780,
      msTempC: 330,
      mfTempC: 190,
      thermalConductivityWmK: 42.6
    },
    heatTreatment: {
      austenitisingTempC: 860,
      quenchMedium: 'OIL',
      temperingRangeC: [540, 680],
      targetHardness: '28 - 36 HRC',
      stressReliefTempC: 560
    },
    typicalApplications: ['Heavy CNC transmission crankshafts', 'Aircraft landing gear pins', 'High-pressure hydraulic cylinder rods']
  },
  {
    id: 'H13',
    name: 'AISI H13 / 1.2344 Hot Work Tool Steel',
    category: 'HOT_WORK_TOOL_STEEL',
    standard: 'BS EN ISO 4957',
    sheffieldHeritageNote: 'Premium vacuum-degassed Sheffield tool steel engineered with 5% chromium and vanadium for thermal shock resistance in hot die forging presses.',
    nominalChemistry: {
      C: 0.39,
      Si: 1.00,
      Mn: 0.40,
      P: 0.012,
      S: 0.003,
      Cr: 5.20,
      Ni: 0.20,
      Mo: 1.30,
      V: 0.95,
      Cu: 0.10,
      Al: 0.015,
      N_ppm: 40,
      H_ppm: 1.2,
      O_ppm: 14
    },
    minChemistry: { C: 0.37, Cr: 4.80, Mo: 1.20, V: 0.85 },
    maxChemistry: { C: 0.42, Cr: 5.50, Mo: 1.50, V: 1.15 },
    mechanicalProperties: {
      yieldStrengthMpa: 1350,
      tensileStrengthMpa: 1620,
      elongationPercent: 9,
      hardnessHB: 500,
      hardnessHRC: 50,
      charpyVNotchJoules: 18,
      densityKgM3: 7800,
      youngsModulusGpa: 215
    },
    thermalProperties: {
      meltingRangeC: [1425, 1475],
      ac1TempC: 850,
      ac3TempC: 900,
      msTempC: 300,
      mfTempC: 150,
      thermalConductivityWmK: 28.5
    },
    heatTreatment: {
      austenitisingTempC: 1025,
      quenchMedium: 'VACUUM_GAS',
      temperingRangeC: [550, 650], // Double/Triple temper
      targetHardness: '46 - 52 HRC',
      stressReliefTempC: 620
    },
    typicalApplications: ['30MN Hydraulic Forging Press die blocks', 'Aluminium extrusion tooling', 'Plastic injection mold cores']
  },
  {
    id: '52100',
    name: 'AISI 52100 / 100Cr6 High-Carbon Bearing Steel',
    category: 'BEARING_STEEL',
    standard: 'BS EN ISO 683-17 / ASTM A295',
    sheffieldHeritageNote: 'Vacuum-degassed ultra-pure bearing steel processed with sub-micron inclusion control for high contact fatigue endurance.',
    nominalChemistry: {
      C: 0.98,
      Si: 0.25,
      Mn: 0.35,
      P: 0.010,
      S: 0.005,
      Cr: 1.50,
      Ni: 0.08,
      Mo: 0.05,
      V: 0.01,
      Cu: 0.10,
      Al: 0.020,
      N_ppm: 35,
      H_ppm: 1.0,
      O_ppm: 10
    },
    minChemistry: { C: 0.93, Cr: 1.40, Mn: 0.25 },
    maxChemistry: { C: 1.05, Cr: 1.65, Mn: 0.45 },
    mechanicalProperties: {
      yieldStrengthMpa: 1900,
      tensileStrengthMpa: 2200,
      elongationPercent: 5,
      hardnessHB: 650,
      hardnessHRC: 62,
      charpyVNotchJoules: 12,
      densityKgM3: 7810,
      youngsModulusGpa: 210
    },
    thermalProperties: {
      meltingRangeC: [1420, 1465],
      ac1TempC: 750,
      ac3TempC: 840,
      msTempC: 220,
      mfTempC: 50,
      thermalConductivityWmK: 33.0
    },
    heatTreatment: {
      austenitisingTempC: 845,
      quenchMedium: 'OIL',
      temperingRangeC: [160, 200],
      targetHardness: '60 - 64 HRC',
      stressReliefTempC: 180
    },
    typicalApplications: ['Heavy industrial wind turbine slewing rings', 'High-speed spindle ball bearings', 'Precision CNC linear ball screws']
  }
];
