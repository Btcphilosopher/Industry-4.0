import React from 'react';
import { 
  X, 
  QrCode, 
  ShieldCheck, 
  FileCheck, 
  Leaf, 
  CheckCircle2, 
  Printer, 
  ExternalLink,
  Flame,
  Layers
} from 'lucide-react';
import { DigitalProductPassport } from '../types/twin.types';

interface DigitalPassportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DigitalPassportModal: React.FC<DigitalPassportModalProps> = ({
  isOpen,
  onClose
}) => {
  if (!isOpen) return null;

  const passport: DigitalProductPassport = {
    passportId: 'EU-DPP-UK-SHF-2026-004291',
    partNumber: 'SPW-26-0917-0042',
    description: 'Marine Propulsion Intermediate Transmission Shaft (Ø450mm x 4200mm)',
    serialNumber: 'SN-SHF-8894-0012',
    steelGrade: 'S355J2 Fine-Grain Structural Alloy',
    standard: 'BS EN 10025-2:2019 / Norsok M-120',
    heatId: 'HEAT-2026-8894',
    meltDate: '2026-09-17 14:32 UTC',
    finishDate: '2026-09-24 11:15 UTC',
    batchYieldPct: 98.4,
    carbonFootprintKgCO2: 345,
    recycledScrapContentPct: 94.5,
    ultrasonicCert: 'ISO 10893-11 Class A Defect-Free (Sound Velocity 5920 m/s)',
    cmmCert: 'ISO 10360-2 Verified (Max TIR Deviation +0.006mm)',
    tensileCert: 'Yield 372 MPa / Tensile 528 MPa / Charpy 54J @ -20°C',
    heatTreatmentProfile: 'Normalized 910°C / Stress Relieved 600°C',
    destinationClient: 'BAE Systems Maritime / Rolls-Royce Marine (Type 26 Frigate)',
    verifiedSignature: 'SHA256: 8f9b2c34e109d7a229bcae918451f22e831c94473b12984029482fba8941032a'
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 z-50 select-none">
      <div className="bg-steel-950 border border-steel-700 rounded-3xl max-w-3xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="p-5 border-b border-steel-800 flex items-center justify-between bg-steel-900">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold font-industrial text-zinc-100 uppercase">
                  Digital Product Passport (DPP)
                </h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  ISO 23247 / EU DPP COMPLIANT
                </span>
              </div>
              <p className="text-xs font-mono text-zinc-400">
                {passport.passportId}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-200 hover:bg-steel-800 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* Part Overview Banner */}
          <div className="p-4 bg-steel-900 rounded-2xl border border-steel-800 space-y-2">
            <div className="text-xs font-mono text-emerald-400 font-bold">
              Part No: {passport.partNumber} • Serial: {passport.serialNumber}
            </div>
            <h3 className="text-base font-bold text-zinc-100 font-industrial">
              {passport.description}
            </h3>
            <div className="flex flex-wrap gap-2 text-xs font-mono text-zinc-400 pt-1">
              <span>Grade: <strong className="text-sky-300">{passport.steelGrade}</strong></span>
              <span>•</span>
              <span>Standard: <strong className="text-zinc-200">{passport.standard}</strong></span>
              <span>•</span>
              <span>Melt Heat: <strong className="text-orange-400">{passport.heatId}</strong></span>
            </div>
          </div>

          {/* Sustainability & Circularity Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-4 bg-steel-900 rounded-2xl border border-steel-800 space-y-1">
              <div className="text-xs font-mono text-zinc-400 flex items-center justify-between">
                <span>Recycled Scrap Content</span>
                <Leaf className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-2xl font-bold font-mono text-emerald-400">
                {passport.recycledScrapContentPct}%
              </div>
              <div className="text-[11px] text-zinc-400">
                Circular economy Sheffield electric arc recycling
              </div>
            </div>

            <div className="p-4 bg-steel-900 rounded-2xl border border-steel-800 space-y-1">
              <div className="text-xs font-mono text-zinc-400 flex items-center justify-between">
                <span>Product Carbon Footprint</span>
                <ShieldCheck className="w-4 h-4 text-sky-400" />
              </div>
              <div className="text-2xl font-bold font-mono text-sky-300">
                {passport.carbonFootprintKgCO2} <span className="text-xs font-normal text-zinc-400">kg CO₂e / tonne</span>
              </div>
              <div className="text-[11px] text-zinc-400">
                Scope 1 & 2 cradle-to-gate verified
              </div>
            </div>
          </div>

          {/* Verified Quality & NDT Certificates */}
          <div className="bg-steel-900 rounded-2xl border border-steel-800 p-4 space-y-3">
            <h4 className="text-xs font-bold font-industrial uppercase text-zinc-300 flex items-center gap-2">
              <FileCheck className="w-4 h-4 text-teal-400" />
              Genealogical Quality & Non-Destructive Testing Passports
            </h4>

            <div className="space-y-2 text-xs font-mono">
              <div className="p-2.5 bg-steel-950 rounded-xl border border-steel-800 flex justify-between">
                <span className="text-zinc-400">Ultrasonic NDT:</span>
                <span className="text-zinc-200 font-bold">{passport.ultrasonicCert}</span>
              </div>
              <div className="p-2.5 bg-steel-950 rounded-xl border border-steel-800 flex justify-between">
                <span className="text-zinc-400">3D CMM Inspection:</span>
                <span className="text-zinc-200 font-bold">{passport.cmmCert}</span>
              </div>
              <div className="p-2.5 bg-steel-950 rounded-xl border border-steel-800 flex justify-between">
                <span className="text-zinc-400">Tensile Verification:</span>
                <span className="text-zinc-200 font-bold">{passport.tensileCert}</span>
              </div>
              <div className="p-2.5 bg-steel-950 rounded-xl border border-steel-800 flex justify-between">
                <span className="text-zinc-400">Heat Treatment Profile:</span>
                <span className="text-zinc-200 font-bold">{passport.heatTreatmentProfile}</span>
              </div>
            </div>
          </div>

          {/* Cryptographic Digital Signature */}
          <div className="p-3.5 bg-steel-900 rounded-2xl border border-steel-800 text-[11px] font-mono space-y-1">
            <div className="text-zinc-400 uppercase">Cryptographic Audit Signature (Tamper-Evident Ledger):</div>
            <div className="text-sky-400 break-all">{passport.verifiedSignature}</div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-steel-800 bg-steel-900 flex items-center justify-between">
          <span className="text-xs font-mono text-zinc-400">Client: {passport.destinationClient}</span>
          <button
            onClick={() => window.print()}
            className="flex items-center gap-2 px-4 py-2 bg-steel-800 hover:bg-steel-700 text-zinc-200 rounded-xl text-xs font-mono font-bold transition-all"
          >
            <Printer className="w-4 h-4" />
            <span>EXPORT / PRINT PASSPORT</span>
          </button>
        </div>
      </div>
    </div>
  );
};
