import React from 'react';
import { 
  Play, 
  Pause, 
  FastForward, 
  SkipForward, 
  AlertTriangle, 
  Zap, 
  Flame, 
  ShieldAlert, 
  BookOpen, 
  QrCode,
  Activity,
  RotateCcw
} from 'lucide-react';
import { SimulationState, SimSpeed } from '../services/simulation.service';

interface TopbarProps {
  state: SimulationState;
  onTogglePlay: () => void;
  onSetSpeed: (speed: SimSpeed) => void;
  onStep: () => void;
  onEmergencyStop: () => void;
  onOpenAssistant: () => void;
  onOpenPassport: () => void;
}

export const Topbar: React.FC<TopbarProps> = ({
  state,
  onTogglePlay,
  onSetSpeed,
  onStep,
  onEmergencyStop,
  onOpenAssistant,
  onOpenPassport
}) => {
  return (
    <header className="h-16 bg-steel-950 border-b border-steel-800 px-4 flex items-center justify-between select-none z-30">
      {/* Brand & Industrial Identity */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-orange-500 to-amber-600 flex items-center justify-center shadow-md glow-orange">
            <Flame className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-bold tracking-wider font-industrial text-zinc-100 uppercase">
                Sheffield Steelworks Digital Twin
              </h1>
              <span className="px-1.5 py-0.5 text-[10px] font-mono font-bold bg-steel-800 text-sky-400 border border-steel-700 rounded">
                SSDT v4.2
              </span>
            </div>
            <p className="text-[10px] font-mono text-zinc-400 tracking-wider">
              DIGITAL TWIN / STEELMAKING / ROBOTICS / PRECISION MANUFACTURING
            </p>
          </div>
        </div>
      </div>

      {/* Center: Deterministic Industrial Simulation Controls */}
      <div className="flex items-center gap-3 bg-steel-900/90 border border-steel-700 px-3 py-1.5 rounded-xl shadow-inner">
        {/* Clock & Status */}
        <div className="flex items-center gap-2 border-r border-steel-700 pr-3">
          <span className="relative flex h-2.5 w-2.5">
            <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
              state.eStopActive ? 'bg-rose-400' : state.isRunning ? 'bg-emerald-400' : 'bg-amber-400'
            }`}></span>
            <span className={`relative inline-flex rounded-full h-2.5 w-2.5 ${
              state.eStopActive ? 'bg-rose-500' : state.isRunning ? 'bg-emerald-500' : 'bg-amber-500'
            }`}></span>
          </span>
          <div className="font-mono-num font-bold text-base text-zinc-100 tracking-wider">
            {state.simTimeString}
          </div>
        </div>

        {/* Play / Pause / Step Controls */}
        <div className="flex items-center gap-1">
          <button
            onClick={onTogglePlay}
            title={state.isRunning ? "Pause Simulation" : "Resume Simulation"}
            className={`p-1.5 rounded-lg transition-all ${
              state.isRunning 
                ? 'bg-amber-500/20 text-amber-300 hover:bg-amber-500/30' 
                : 'bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30'
            }`}
          >
            {state.isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </button>
          <button
            onClick={onStep}
            title="Single Step Tick (1s)"
            className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-200 hover:bg-steel-800 transition-all"
          >
            <SkipForward className="w-4 h-4" />
          </button>
        </div>

        {/* Speed Multipliers */}
        <div className="flex items-center gap-1 border-l border-steel-700 pl-2">
          {([0.5, 1, 2, 5] as const).map(s => (
            <button
              key={s}
              onClick={() => onSetSpeed(s)}
              className={`px-2 py-0.5 text-xs font-mono rounded transition-all ${
                state.speed === s && state.isRunning
                  ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40 font-bold'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-steel-800'
              }`}
            >
              {s}x
            </button>
          ))}
        </div>
      </div>

      {/* Right Side: Key Power Telemetry & Quick Action Modals */}
      <div className="flex items-center gap-3">
        {/* Plant Total MW */}
        <div className="hidden lg:flex items-center gap-2 bg-steel-900 border border-steel-800 px-3 py-1.5 rounded-lg">
          <Zap className="w-4 h-4 text-amber-400" />
          <div>
            <div className="text-[10px] font-mono text-zinc-400 uppercase">Grid Load</div>
            <div className="text-xs font-mono-num font-bold text-zinc-200">
              {state.energy.totalGridDrawMW.toFixed(1)} MW
            </div>
          </div>
        </div>

        {/* Engineering Assist Button */}
        <button
          onClick={onOpenAssistant}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-steel-800 hover:bg-steel-700 text-sky-300 border border-sky-500/30 rounded-lg text-xs font-medium transition-all shadow-sm"
        >
          <BookOpen className="w-4 h-4 text-sky-400" />
          <span className="hidden sm:inline">Engineering Assist</span>
        </button>

        {/* Digital Product Passport Button */}
        <button
          onClick={onOpenPassport}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-steel-800 hover:bg-steel-700 text-emerald-300 border border-emerald-500/30 rounded-lg text-xs font-medium transition-all shadow-sm"
        >
          <QrCode className="w-4 h-4 text-emerald-400" />
          <span className="hidden sm:inline">Digital Passport</span>
        </button>

        {/* Plant-wide Emergency Stop (E-Stop) Button */}
        <button
          onClick={onEmergencyStop}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold font-industrial uppercase transition-all shadow-md ${
            state.eStopActive
              ? 'bg-rose-600 text-white animate-pulse shadow-rose-600/50'
              : 'bg-rose-950/80 hover:bg-rose-900 text-rose-300 border border-rose-700/60'
          }`}
        >
          <ShieldAlert className="w-4 h-4 text-rose-400" />
          <span>{state.eStopActive ? 'E-STOP TRIPPED' : 'E-STOP'}</span>
        </button>
      </div>
    </header>
  );
};
