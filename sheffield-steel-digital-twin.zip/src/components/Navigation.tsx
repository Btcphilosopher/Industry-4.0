import React from 'react';
import { 
  Box, 
  Flame, 
  Cpu, 
  Layers, 
  Activity, 
  CheckCircle2, 
  Zap, 
  Wrench, 
  Truck, 
  TrendingUp, 
  BookOpen, 
  FlaskConical, 
  History 
} from 'lucide-react';
import { ViewMode } from '../types/twin.types';

interface NavigationProps {
  currentView: ViewMode;
  onSelectView: (view: ViewMode) => void;
  alarmCount: number;
}

export const Navigation: React.FC<NavigationProps> = ({
  currentView,
  onSelectView,
  alarmCount
}) => {
  const navItems: { id: ViewMode; label: string; icon: React.ReactNode; badge?: string | number; badgeColor?: string }[] = [
    { id: 'TWIN', label: '3D Twin', icon: <Box className="w-4 h-4" /> },
    { id: 'STEEL', label: 'Steelmaking', icon: <Flame className="w-4 h-4 text-orange-400" /> },
    { id: 'ROBOTICS', label: 'Robotics Studio', icon: <Cpu className="w-4 h-4 text-sky-400" /> },
    { id: 'PRODUCTION', label: 'Orders & Heats', icon: <Layers className="w-4 h-4 text-amber-400" /> },
    { id: 'MACHINES', label: 'Machines & Telemetry', icon: <Activity className="w-4 h-4 text-emerald-400" />, badge: alarmCount > 0 ? alarmCount : undefined, badgeColor: 'bg-rose-500' },
    { id: 'QUALITY', label: 'Quality & NDT', icon: <CheckCircle2 className="w-4 h-4 text-teal-400" /> },
    { id: 'ENERGY', label: 'Energy & Carbon', icon: <Zap className="w-4 h-4 text-yellow-400" /> },
    { id: 'MAINTENANCE', label: 'Maintenance & FFT', icon: <Wrench className="w-4 h-4 text-indigo-400" /> },
    { id: 'LOGISTICS', label: 'Yard & Logistics', icon: <Truck className="w-4 h-4 text-blue-400" /> },
    { id: 'ANALYTICS', label: 'SPC & OEE', icon: <TrendingUp className="w-4 h-4 text-purple-400" /> },
    { id: 'KNOWLEDGE', label: 'Metallurgy Knowledge', icon: <BookOpen className="w-4 h-4 text-cyan-400" /> },
    { id: 'SCENARIOS', label: 'Scenario Lab', icon: <FlaskConical className="w-4 h-4 text-pink-400" /> },
    { id: 'REPLAY', label: 'Forensic Replay', icon: <History className="w-4 h-4 text-zinc-400" /> }
  ];

  return (
    <nav className="h-11 bg-steel-900 border-b border-steel-800 px-3 flex items-center gap-1 overflow-x-auto select-none no-scrollbar">
      {navItems.map(item => {
        const isActive = currentView === item.id;
        return (
          <button
            key={item.id}
            onClick={() => onSelectView(item.id)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
              isActive
                ? 'bg-steel-750 text-white font-semibold shadow-sm border border-steel-600'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-steel-800/60'
            }`}
          >
            {item.icon}
            <span>{item.label}</span>
            {item.badge !== undefined && (
              <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold text-white ${item.badgeColor || 'bg-sky-500'}`}>
                {item.badge}
              </span>
            )}
          </button>
        );
      })}
    </nav>
  );
};
