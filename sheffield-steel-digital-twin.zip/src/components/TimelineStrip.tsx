import React from 'react';
import { 
  AlertTriangle, 
  Info, 
  AlertCircle, 
  Check, 
  Filter,
  Radio
} from 'lucide-react';
import { IndustrialEvent, AlarmSeverity } from '../types/twin.types';

interface TimelineStripProps {
  events: IndustrialEvent[];
  onAckEvent: (id: string) => void;
  onSelectZone: (zoneId: string) => void;
}

export const TimelineStrip: React.FC<TimelineStripProps> = ({
  events,
  onAckEvent,
  onSelectZone
}) => {
  const getSeverityIcon = (sev: AlarmSeverity) => {
    switch (sev) {
      case 'ALARM':
        return <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />;
      case 'CRITICAL':
        return <AlertCircle className="w-3.5 h-3.5 text-orange-400" />;
      case 'WARNING':
        return <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />;
      case 'INFO':
      default:
        return <Info className="w-3.5 h-3.5 text-sky-400" />;
    }
  };

  const getSeverityBadge = (sev: AlarmSeverity) => {
    switch (sev) {
      case 'ALARM':
        return 'bg-rose-950/80 text-rose-300 border-rose-800';
      case 'CRITICAL':
        return 'bg-orange-950/80 text-orange-300 border-orange-800';
      case 'WARNING':
        return 'bg-amber-950/80 text-amber-300 border-amber-800';
      case 'INFO':
      default:
        return 'bg-steel-800 text-sky-300 border-steel-700';
    }
  };

  return (
    <footer className="h-14 bg-steel-950 border-t border-steel-800 px-4 flex items-center justify-between gap-4 select-none z-20">
      {/* Event Stream Label */}
      <div className="flex items-center gap-2 flex-shrink-0 border-r border-steel-800 pr-3">
        <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
        <span className="text-xs font-bold font-industrial text-zinc-300 uppercase">
          Plant Stream
        </span>
        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-steel-800 text-zinc-400">
          LIVE
        </span>
      </div>

      {/* Horizontal Scrolling Events */}
      <div className="flex-1 flex items-center gap-3 overflow-x-auto no-scrollbar py-1">
        {events.slice(0, 10).map(evt => (
          <div
            key={evt.id}
            className={`flex items-center gap-2 px-2.5 py-1 rounded-lg border text-xs whitespace-nowrap transition-all ${getSeverityBadge(evt.severity)}`}
          >
            {getSeverityIcon(evt.severity)}
            <span className="font-mono text-[10px] text-zinc-400">
              {evt.timestamp}
            </span>
            <button
              onClick={() => onSelectZone(evt.zone)}
              className="font-mono font-bold text-zinc-200 hover:underline cursor-pointer"
            >
              [{evt.source}]
            </button>
            <span className="text-zinc-300 truncate max-w-xs text-[11px]">
              {evt.message}
            </span>
            {!evt.ack && (
              <button
                onClick={() => onAckEvent(evt.id)}
                title="Acknowledge event"
                className="ml-1 p-0.5 rounded hover:bg-steel-700 text-zinc-400 hover:text-emerald-400 transition-colors"
              >
                <Check className="w-3 h-3" />
              </button>
            )}
          </div>
        ))}
      </div>

      {/* Quick Summary Counts */}
      <div className="hidden sm:flex items-center gap-2 text-xs font-mono text-zinc-400 flex-shrink-0 border-l border-steel-800 pl-3">
        <span className="text-rose-400 font-bold">
          {events.filter(e => e.severity === 'ALARM' || e.severity === 'CRITICAL').length} High Alerts
        </span>
      </div>
    </footer>
  );
};
