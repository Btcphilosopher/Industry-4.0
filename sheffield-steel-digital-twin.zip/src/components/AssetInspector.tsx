import React from 'react';
import { 
  X, 
  Activity, 
  AlertTriangle, 
  CheckCircle, 
  Wrench, 
  Zap, 
  Thermometer, 
  Clock, 
  Sliders,
  ShieldAlert,
  BarChart2
} from 'lucide-react';
import { MachineTwin, MachineState } from '../types/twin.types';

interface AssetInspectorProps {
  machine: MachineTwin | null;
  onClose: () => void;
  onSetState: (state: MachineState) => void;
  onAckAlarm: (alarmId: string) => void;
}

export const AssetInspector: React.FC<AssetInspectorProps> = ({
  machine,
  onClose,
  onSetState,
  onAckAlarm
}) => {
  if (!machine) return null;

  const stateColors: Record<MachineState, { bg: string; text: string; border: string }> = {
    IDLE: { bg: 'bg-zinc-800', text: 'text-zinc-300', border: 'border-zinc-700' },
    READY: { bg: 'bg-sky-950', text: 'text-sky-300', border: 'border-sky-700' },
    HEATING: { bg: 'bg-amber-950', text: 'text-amber-300', border: 'border-amber-700' },
    MELTING: { bg: 'bg-orange-950', text: 'text-orange-300', border: 'border-orange-700' },
    CASTING: { bg: 'bg-red-950', text: 'text-red-300', border: 'border-red-700' },
    ROLLING: { bg: 'bg-purple-950', text: 'text-purple-300', border: 'border-purple-700' },
    FORGING: { bg: 'bg-indigo-950', text: 'text-indigo-300', border: 'border-indigo-700' },
    MACHINING: { bg: 'bg-emerald-950', text: 'text-emerald-300', border: 'border-emerald-700' },
    INSPECTING: { bg: 'bg-teal-950', text: 'text-teal-300', border: 'border-teal-700' },
    MAINTENANCE: { bg: 'bg-yellow-950', text: 'text-yellow-300', border: 'border-yellow-700' },
    EMERGENCY_STOP: { bg: 'bg-rose-950', text: 'text-rose-300', border: 'border-rose-700' }
  };

  const currentStyle = stateColors[machine.state] || stateColors.IDLE;

  return (
    <aside className="w-84 bg-steel-950/95 backdrop-blur-md border-l border-steel-800 flex flex-col h-full overflow-hidden select-none z-20">
      {/* Header */}
      <div className="p-4 border-b border-steel-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded bg-steel-800 flex items-center justify-center border border-steel-700">
            <Activity className="w-4 h-4 text-sky-400" />
          </div>
          <div>
            <h2 className="text-sm font-bold font-industrial text-zinc-100">
              {machine.code}
            </h2>
            <p className="text-[11px] text-zinc-400 truncate w-48">
              {machine.name}
            </p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded text-zinc-400 hover:text-zinc-200 hover:bg-steel-800 transition-all"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* State & Health Score Banner */}
        <div className="grid grid-cols-2 gap-2">
          <div className={`p-2.5 rounded-xl border ${currentStyle.bg} ${currentStyle.border}`}>
            <div className="text-[10px] font-mono text-zinc-400 uppercase">State</div>
            <div className={`text-xs font-bold font-mono uppercase mt-0.5 ${currentStyle.text}`}>
              {machine.state}
            </div>
          </div>
          <div className="p-2.5 rounded-xl bg-steel-900 border border-steel-800">
            <div className="text-[10px] font-mono text-zinc-400 uppercase">Health Score</div>
            <div className="text-xs font-bold font-mono-num text-emerald-400 mt-0.5 flex items-center justify-between">
              <span>{machine.healthScore}%</span>
              <span className="text-[10px] font-normal text-zinc-400">RUL: {machine.hoursUntilService}h</span>
            </div>
          </div>
        </div>

        {/* Primary Sensor Gauges */}
        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="bg-steel-900 p-2 rounded-lg border border-steel-800">
            <Zap className="w-3.5 h-3.5 text-amber-400 mx-auto mb-1" />
            <div className="text-[10px] text-zinc-400">Power</div>
            <div className="text-xs font-mono font-bold text-zinc-200">
              {machine.powerDrawMW.toFixed(1)} MW
            </div>
          </div>
          <div className="bg-steel-900 p-2 rounded-lg border border-steel-800">
            <Thermometer className="w-3.5 h-3.5 text-orange-400 mx-auto mb-1" />
            <div className="text-[10px] text-zinc-400">Temp</div>
            <div className="text-xs font-mono font-bold text-zinc-200">
              {machine.temperatureC}°C
            </div>
          </div>
          <div className="bg-steel-900 p-2 rounded-lg border border-steel-800">
            <BarChart2 className="w-3.5 h-3.5 text-sky-400 mx-auto mb-1" />
            <div className="text-[10px] text-zinc-400">Vibration</div>
            <div className="text-xs font-mono font-bold text-zinc-200">
              {machine.vibrationRmsMmS.toFixed(1)} mm/s
            </div>
          </div>
        </div>

        {/* Active Alarms Section */}
        {machine.alarms.length > 0 && (
          <div className="space-y-2">
            <div className="text-xs font-bold font-industrial uppercase text-rose-400 flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5" />
              Active Alarms ({machine.alarms.length})
            </div>
            {machine.alarms.map(alarm => (
              <div 
                key={alarm.id} 
                className="p-2.5 rounded-lg bg-rose-950/60 border border-rose-800/80 text-xs space-y-1.5"
              >
                <div className="flex items-center justify-between text-[11px] font-mono">
                  <span className="font-bold text-rose-300">{alarm.code}</span>
                  <span className="text-rose-400/80">{alarm.timestamp}</span>
                </div>
                <p className="text-[11px] text-zinc-300">
                  {alarm.description}
                </p>
                <div className="flex items-center justify-between pt-1">
                  <span className="text-[10px] font-mono text-zinc-400">
                    Val: {alarm.currentValue} (Lim: {alarm.limitValue})
                  </span>
                  {!alarm.acknowledged && (
                    <button
                      onClick={() => onAckAlarm(alarm.id)}
                      className="px-2 py-0.5 bg-rose-800 hover:bg-rose-700 text-white rounded text-[10px] font-semibold transition-all"
                    >
                      Acknowledge
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Telemetry Dictionary */}
        <div className="space-y-2">
          <div className="text-xs font-bold font-industrial uppercase text-zinc-300 flex items-center justify-between">
            <span>Process Telemetry</span>
            <span className="text-[10px] font-mono text-zinc-400">{Object.keys(machine.telemetry).length} channels</span>
          </div>
          <div className="bg-steel-900 rounded-xl border border-steel-800 divide-y divide-steel-800/60 overflow-hidden">
            {Object.entries(machine.telemetry).map(([key, val]) => (
              <div key={key} className="px-3 py-2 flex items-center justify-between text-xs">
                <span className="text-zinc-400 text-[11px] pr-2 truncate">{key}</span>
                <span className="font-mono font-semibold text-zinc-200 text-right">
                  {String(val)}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Manual State Override Controls */}
        <div className="space-y-2 pt-2 border-t border-steel-800">
          <div className="text-xs font-bold font-industrial uppercase text-zinc-300 flex items-center gap-1.5">
            <Sliders className="w-3.5 h-3.5 text-zinc-400" />
            Manual State Control
          </div>
          <div className="grid grid-cols-2 gap-1.5">
            {(['IDLE', 'READY', 'HEATING', 'MAINTENANCE'] as MachineState[]).map(st => (
              <button
                key={st}
                onClick={() => onSetState(st)}
                className={`py-1.5 px-2 rounded-lg text-xs font-mono font-medium transition-all ${
                  machine.state === st
                    ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40 font-bold'
                    : 'bg-steel-900 hover:bg-steel-800 text-zinc-400 border border-steel-800'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        {/* Asset Operational Summary */}
        <div className="p-3 bg-steel-900/60 rounded-xl border border-steel-800 text-[11px] space-y-1.5">
          <div className="flex justify-between text-zinc-400">
            <span>Total Operating Time</span>
            <span className="font-mono text-zinc-200">{machine.operationalHoursTotal.toLocaleString()} hrs</span>
          </div>
          <div className="flex justify-between text-zinc-400">
            <span>Asset Zone</span>
            <span className="font-mono text-zinc-200">{machine.zoneId}</span>
          </div>
        </div>
      </div>
    </aside>
  );
};
