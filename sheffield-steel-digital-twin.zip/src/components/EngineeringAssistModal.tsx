import React, { useState } from 'react';
import { 
  X, 
  BookOpen, 
  Send, 
  Cpu, 
  Activity, 
  Flame, 
  CheckCircle2, 
  Calculator,
  HelpCircle
} from 'lucide-react';
import { SimulationState } from '../services/simulation.service';
import { diagnoseMetallurgicalIssue } from '../services/metallurgy-engine.service';

interface EngineeringAssistModalProps {
  isOpen: boolean;
  onClose: () => void;
  state: SimulationState;
}

export const EngineeringAssistModal: React.FC<EngineeringAssistModalProps> = ({
  isOpen,
  onClose,
  state
}) => {
  const [query, setQuery] = useState<string>('How does tramp copper contamination affect S355J2 rolling?');
  const [response, setResponse] = useState<ReturnType<typeof diagnoseMetallurgicalIssue> | null>(() => 
    diagnoseMetallurgicalIssue('How does tramp copper contamination affect S355J2 rolling?', state.heats[0]?.chemistry)
  );

  if (!isOpen) return null;

  const handleAsk = (text?: string) => {
    const q = text || query;
    if (!q.trim()) return;
    const activeHeat = state.heats.find(h => h.id === state.selectedHeatId) || state.heats[0];
    const diag = diagnoseMetallurgicalIssue(q, activeHeat?.chemistry);
    setResponse(diag);
  };

  const sampleQuestions = [
    'How does tramp copper contamination affect S355J2 rolling?',
    'What vacuum level is required in VD-01 to prevent hydrogen flaking?',
    'Calculate weldability and Carbon Equivalent (CEV) for active heat',
    'Explain BPFO harmonic vibration peak on CNC spindle bearing'
  ];

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 z-50 select-none">
      <div className="bg-steel-950 border border-steel-700 rounded-3xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-steel-800 flex items-center justify-between bg-steel-900">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-sky-500/20 text-sky-400 border border-sky-500/30 flex items-center justify-center">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold font-industrial text-zinc-100 uppercase">
                Sheffield Engineering & Metallurgical Advisor
              </h2>
              <p className="text-xs font-mono text-zinc-400">
                Restrained plant-connected engineering diagnostics & scientific consultation
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-200 hover:bg-steel-800 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* Quick Prompts */}
          <div className="space-y-1.5">
            <div className="text-[10px] font-mono text-zinc-400 uppercase">Standard Diagnostic Inquiries:</div>
            <div className="flex flex-wrap gap-1.5">
              {sampleQuestions.map((q, i) => (
                <button
                  key={i}
                  onClick={() => {
                    setQuery(q);
                    handleAsk(q);
                  }}
                  className="px-2.5 py-1 bg-steel-900 hover:bg-steel-800 border border-steel-800 rounded-lg text-xs font-mono text-zinc-300 transition-all text-left truncate max-w-full"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>

          {/* Diagnostic Result */}
          {response && (
            <div className="p-5 bg-steel-900 rounded-2xl border border-steel-800 space-y-4">
              <div className="flex items-center justify-between border-b border-steel-800 pb-2">
                <h3 className="text-sm font-bold font-industrial text-sky-300">
                  {response.headline}
                </h3>
                <span className="text-[10px] font-mono text-emerald-400">VERIFIED METALLURGY</span>
              </div>

              <p className="text-xs text-zinc-300 leading-relaxed">
                {response.analysis}
              </p>

              {/* Recommendations */}
              <div className="space-y-1.5">
                <div className="text-[10px] font-mono text-zinc-400 uppercase">Plant Action Recommendations:</div>
                <div className="space-y-1">
                  {response.recommendations.map((rec, i) => (
                    <div key={i} className="flex items-start gap-2 text-xs text-zinc-200 font-mono bg-steel-950 p-2 rounded-lg border border-steel-800/80">
                      <span className="text-sky-400 font-bold">{i + 1}.</span>
                      <span>{rec}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Empirical Equations */}
              {response.equations.length > 0 && (
                <div className="space-y-1.5 pt-1">
                  <div className="text-[10px] font-mono text-zinc-400 uppercase">Empirical Model Equations:</div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono">
                    {response.equations.map((eq, i) => (
                      <div key={i} className="p-2.5 bg-steel-950 rounded-lg border border-steel-800">
                        <div className="text-zinc-400 text-[10px]">{eq.name}</div>
                        <div className="text-sky-400 font-bold mt-0.5">{eq.result}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Input Bar */}
        <div className="p-4 border-t border-steel-800 bg-steel-900 flex items-center gap-2">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleAsk()}
            placeholder="Ask metallurgical or process diagnostic question..."
            className="flex-1 bg-steel-950 border border-steel-700 rounded-xl px-4 py-2.5 text-xs text-zinc-100 placeholder-zinc-500 focus:outline-none focus:border-sky-500 font-mono"
          />
          <button
            onClick={() => handleAsk()}
            className="px-4 py-2.5 bg-sky-600 hover:bg-sky-500 text-white rounded-xl text-xs font-mono font-bold transition-all shadow-md flex items-center gap-1.5"
          >
            <Send className="w-3.5 h-3.5" />
            <span>ASK</span>
          </button>
        </div>
      </div>
    </div>
  );
};
