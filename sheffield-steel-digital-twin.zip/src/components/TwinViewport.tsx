import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { SimulationState } from '../services/simulation.service';
import { 
  Maximize2, 
  Eye, 
  Layers, 
  Flame, 
  Activity, 
  RotateCcw,
  Zap,
  Cpu,
  ShieldCheck,
  Compass
} from 'lucide-react';

interface TwinViewportProps {
  state: SimulationState;
  onSelectMachine: (id: string) => void;
}

export const TwinViewport: React.FC<TwinViewportProps> = ({ state, onSelectMachine }) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [viewPreset, setViewPreset] = useState<'OVERVIEW' | 'MELT_SHOP' | 'FORGE_MILL' | 'ROBOTICS_CNC' | 'METROLOGY'>('OVERVIEW');
  const [renderMode, setRenderMode] = useState<'REALISTIC' | 'THERMAL' | 'SAFETY_ENVELOPES'>('REALISTIC');
  const [hoveredAsset, setHoveredAsset] = useState<string | null>(null);

  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const robotGroupRef = useRef<THREE.Group | null>(null);
  const eafArcLightRef = useRef<THREE.PointLight | null>(null);
  const casterStrandRef = useRef<THREE.Mesh | null>(null);
  const craneRef = useRef<THREE.Group | null>(null);
  const isDraggingRef = useRef(false);
  const previousMousePos = useRef({ x: 0, y: 0 });
  const cameraTarget = useRef(new THREE.Vector3(0, 0, 0));

  useEffect(() => {
    if (!mountRef.current) return;

    const container = mountRef.current;
    const width = container.clientWidth;
    const height = container.clientHeight;

    // 1. Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0e1215);
    scene.fog = new THREE.FogExp2(0x0e1215, 0.008);
    sceneRef.current = scene;

    // 2. Camera
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.5, 500);
    camera.position.set(0, 45, 65);
    camera.lookAt(0, 5, 0);
    cameraRef.current = camera;

    // 3. Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // 4. Lighting
    const ambientLight = new THREE.AmbientLight(0x2a333d, 1.8);
    scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xe2e8f0, 2.2);
    sunLight.position.set(30, 60, 40);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.width = 2048;
    sunLight.shadow.mapSize.height = 2048;
    sunLight.shadow.camera.near = 10;
    sunLight.shadow.camera.far = 150;
    sunLight.shadow.camera.left = -60;
    sunLight.shadow.camera.right = 60;
    sunLight.shadow.camera.top = 60;
    sunLight.shadow.camera.bottom = -60;
    scene.add(sunLight);

    // EAF Arc Light
    const arcLight = new THREE.PointLight(0x38bdf8, 5.0, 30);
    arcLight.position.set(-35, 10, -15);
    scene.add(arcLight);
    eafArcLightRef.current = arcLight;

    // Furnace glow
    const furnaceGlow = new THREE.PointLight(0xf97316, 4.0, 25);
    furnaceGlow.position.set(35, 5, -15);
    scene.add(furnaceGlow);

    // 5. Floor & Bay Trusses
    createFactoryEnvironment(scene);

    // 6. Build Equipment 3D Meshes
    buildEquipmentMeshes(scene);

    // 7. Overhead Crane
    const crane = createOverheadCrane();
    scene.add(crane);
    craneRef.current = crane;

    // 8. Animation Loop
    let animationFrameId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      // EAF Arc flicker
      if (eafArcLightRef.current) {
        const flicker = Math.sin(elapsedTime * 35) * 0.4 + Math.random() * 0.5;
        eafArcLightRef.current.intensity = 3.5 + flicker;
      }

      // Overhead Crane motion
      if (craneRef.current) {
        craneRef.current.position.x = Math.sin(elapsedTime * 0.2) * 25;
      }

      // Hot strand glow pulsing
      if (casterStrandRef.current) {
        const mat = casterStrandRef.current.material as THREE.MeshStandardMaterial;
        mat.emissiveIntensity = 0.8 + Math.sin(elapsedTime * 2) * 0.2;
      }

      renderer.render(scene, camera);
    };

    animate();

    // Resize Handler
    const handleResize = () => {
      if (!container || !camera || !renderer) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
    };
  }, []);

  // Update robot kinematic angles dynamically
  useEffect(() => {
    if (!robotGroupRef.current) return;
    const joints = state.robot.jointAnglesDeg;
    // Joint 1: Base rotation around Y
    robotGroupRef.current.rotation.y = (joints[0] * Math.PI) / 180;
  }, [state.robot.jointAnglesDeg]);

  // Update Camera Target based on Preset
  useEffect(() => {
    if (!cameraRef.current) return;
    const camera = cameraRef.current;

    switch (viewPreset) {
      case 'OVERVIEW':
        camera.position.set(0, 50, 70);
        cameraTarget.current.set(0, 4, 0);
        break;
      case 'MELT_SHOP':
        camera.position.set(-30, 22, 10);
        cameraTarget.current.set(-30, 6, -15);
        break;
      case 'FORGE_MILL':
        camera.position.set(25, 20, 30);
        cameraTarget.current.set(25, 5, 5);
        break;
      case 'ROBOTICS_CNC':
        camera.position.set(-30, 16, 25);
        cameraTarget.current.set(-28, 3, 10);
        break;
      case 'METROLOGY':
        camera.position.set(-28, 14, 40);
        cameraTarget.current.set(-28, 2, 25);
        break;
    }
    camera.lookAt(cameraTarget.current);
  }, [viewPreset]);

  // Mouse Interaction (Orbit / Pan)
  const handleMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = true;
    previousMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current || !cameraRef.current) return;
    const deltaX = e.clientX - previousMousePos.current.x;
    const deltaY = e.clientY - previousMousePos.current.y;
    previousMousePos.current = { x: e.clientX, y: e.clientY };

    const camera = cameraRef.current;
    
    // Orbit around target
    const radius = camera.position.distanceTo(cameraTarget.current);
    const theta = Math.atan2(camera.position.x - cameraTarget.current.x, camera.position.z - cameraTarget.current.z) - deltaX * 0.006;
    let phi = Math.atan2(camera.position.y - cameraTarget.current.y, Math.sqrt((camera.position.x - cameraTarget.current.x)**2 + (camera.position.z - cameraTarget.current.z)**2)) + deltaY * 0.006;
    phi = Math.max(0.1, Math.min(Math.PI / 2 - 0.05, phi));

    camera.position.x = cameraTarget.current.x + radius * Math.sin(theta) * Math.cos(phi);
    camera.position.y = cameraTarget.current.y + radius * Math.sin(phi);
    camera.position.z = cameraTarget.current.z + radius * Math.cos(theta) * Math.cos(phi);
    camera.lookAt(cameraTarget.current);
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  const handleWheel = (e: React.WheelEvent) => {
    if (!cameraRef.current) return;
    const camera = cameraRef.current;
    const zoomFactor = e.deltaY > 0 ? 1.08 : 0.92;
    const dist = camera.position.distanceTo(cameraTarget.current);
    if ((dist > 15 && e.deltaY < 0) || (dist < 120 && e.deltaY > 0)) {
      camera.position.sub(cameraTarget.current).multiplyScalar(zoomFactor).add(cameraTarget.current);
    }
  };

  // Environment Construction Helper
  const createFactoryEnvironment = (scene: THREE.Scene) => {
    // Floor Slab
    const floorGeo = new THREE.PlaneGeometry(120, 80);
    const floorMat = new THREE.MeshStandardMaterial({ 
      color: 0x181e24, 
      roughness: 0.82, 
      metalness: 0.15 
    });
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    scene.add(floor);

    // Floor Grid lines
    const grid = new THREE.GridHelper(120, 40, 0x3b82f6, 0x242c35);
    grid.position.y = 0.02;
    scene.add(grid);

    // Safety Walkways (Yellow markings)
    const walkwayMat = new THREE.MeshBasicMaterial({ color: 0xeab308 });
    const lineGeoX = new THREE.BoxGeometry(100, 0.04, 0.4);
    const line1 = new THREE.Mesh(lineGeoX, walkwayMat);
    line1.position.set(0, 0.03, -2);
    scene.add(line1);

    const line2 = new THREE.Mesh(lineGeoX, walkwayMat);
    line2.position.set(0, 0.03, 18);
    scene.add(line2);

    // Steel Structural Trusses & Columns
    const steelColumnMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.8, roughness: 0.3 });
    const colGeo = new THREE.BoxGeometry(1.2, 28, 1.2);

    for (let x = -50; x <= 50; x += 25) {
      // North Wall Columns
      const colN = new THREE.Mesh(colGeo, steelColumnMat);
      colN.position.set(x, 14, -38);
      colN.castShadow = true;
      scene.add(colN);

      // South Wall Columns
      const colS = new THREE.Mesh(colGeo, steelColumnMat);
      colS.position.set(x, 14, 38);
      colS.castShadow = true;
      scene.add(colS);

      // Roof Truss Beams
      const trussGeo = new THREE.BoxGeometry(1.0, 1.0, 76);
      const truss = new THREE.Mesh(trussGeo, steelColumnMat);
      truss.position.set(x, 27.5, 0);
      scene.add(truss);
    }
  };

  // Build 3D Machinery
  const buildEquipmentMeshes = (scene: THREE.Scene) => {
    // 1. EAF-01 (Electric Arc Furnace)
    const eafGroup = new THREE.Group();
    eafGroup.position.set(-35, 0, -15);

    // Lower Shell Bowl
    const shellGeo = new THREE.CylinderGeometry(5.5, 4.5, 6, 24);
    const shellMat = new THREE.MeshStandardMaterial({ color: 0x27272a, roughness: 0.6, metalness: 0.7 });
    const shell = new THREE.Mesh(shellGeo, shellMat);
    shell.position.y = 3;
    shell.castShadow = true;
    shell.receiveShadow = true;
    eafGroup.add(shell);

    // Roof Dome
    const roofGeo = new THREE.SphereGeometry(5.6, 24, 12, 0, Math.PI * 2, 0, Math.PI / 3);
    const roofMat = new THREE.MeshStandardMaterial({ color: 0x3f3f46, roughness: 0.5, metalness: 0.8 });
    const roof = new THREE.Mesh(roofGeo, roofMat);
    roof.rotation.x = Math.PI;
    roof.position.y = 7.5;
    eafGroup.add(roof);

    // 3 Graphite Electrodes
    const elecGeo = new THREE.CylinderGeometry(0.35, 0.35, 8, 16);
    const elecMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.9 });
    for (let i = 0; i < 3; i++) {
      const angle = (i * Math.PI * 2) / 3;
      const elec = new THREE.Mesh(elecGeo, elecMat);
      elec.position.set(Math.cos(angle) * 1.8, 8, Math.sin(angle) * 1.8);
      eafGroup.add(elec);
    }

    // Tap Spout
    const spoutGeo = new THREE.BoxGeometry(2, 1, 3);
    const spout = new THREE.Mesh(spoutGeo, shellMat);
    spout.position.set(0, 1.5, 5);
    eafGroup.add(spout);

    scene.add(eafGroup);

    // 2. Continuous Caster (CCM-01)
    const ccmGroup = new THREE.Group();
    ccmGroup.position.set(15, 0, -15);

    // Tundish Structure
    const tundishGeo = new THREE.BoxGeometry(10, 3.5, 4);
    const ccmMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.6, roughness: 0.4 });
    const tundish = new THREE.Mesh(tundishGeo, ccmMat);
    tundish.position.set(0, 7, 0);
    tundish.castShadow = true;
    ccmGroup.add(tundish);

    // Curved Casting Strand (Glowing hot steel)
    const strandGeo = new THREE.BoxGeometry(1.4, 0.8, 20);
    const hotSteelMat = new THREE.MeshStandardMaterial({
      color: 0xff3b00,
      emissive: 0xff5500,
      emissiveIntensity: 0.9,
      roughness: 0.3
    });
    const strand = new THREE.Mesh(strandGeo, hotSteelMat);
    strand.position.set(0, 1.5, 6);
    ccmGroup.add(strand);
    casterStrandRef.current = strand;

    scene.add(ccmGroup);

    // 3. Reheat Furnace (RHF-01)
    const rhfGroup = new THREE.Group();
    rhfGroup.position.set(35, 0, -15);
    const rhfBoxGeo = new THREE.BoxGeometry(14, 6, 8);
    const rhfMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.5 });
    const rhfBox = new THREE.Mesh(rhfBoxGeo, rhfMat);
    rhfBox.position.y = 3;
    rhfBox.castShadow = true;
    rhfGroup.add(rhfBox);

    // Furnace glow opening
    const windowGeo = new THREE.PlaneGeometry(8, 2.5);
    const windowMat = new THREE.MeshBasicMaterial({ color: 0xff7700 });
    const rhfWindow = new THREE.Mesh(windowGeo, windowMat);
    rhfWindow.position.set(0, 3, 4.05);
    rhfGroup.add(rhfWindow);

    scene.add(rhfGroup);

    // 4. 30MN Hydraulic Forging Press (FORGE-01)
    const forgeGroup = new THREE.Group();
    forgeGroup.position.set(15, 0, 10);

    // Columns
    const pressColGeo = new THREE.CylinderGeometry(0.4, 0.4, 10, 16);
    const colMat = new THREE.MeshStandardMaterial({ color: 0x64748b, metalness: 0.8 });
    for (let cx of [-3, 3]) {
      for (let cz of [-2.5, 2.5]) {
        const pCol = new THREE.Mesh(pressColGeo, colMat);
        pCol.position.set(cx, 5, cz);
        pCol.castShadow = true;
        forgeGroup.add(pCol);
      }
    }

    // Top Crosshead
    const topGeo = new THREE.BoxGeometry(8, 2.5, 6);
    const top = new THREE.Mesh(topGeo, ccmMat);
    top.position.y = 9.5;
    forgeGroup.add(top);

    // Hydraulic Ram
    const ramGeo = new THREE.CylinderGeometry(1.2, 1.2, 4, 20);
    const ram = new THREE.Mesh(ramGeo, colMat);
    ram.position.y = 6.5;
    forgeGroup.add(ram);

    // Anvil Bed
    const anvilGeo = new THREE.BoxGeometry(4, 1.8, 3.5);
    const anvil = new THREE.Mesh(anvilGeo, shellMat);
    anvil.position.y = 0.9;
    forgeGroup.add(anvil);

    scene.add(forgeGroup);

    // 5. CNC-04 (5-Axis Machining Centre)
    const cncGroup = new THREE.Group();
    cncGroup.position.set(-20, 0, 10);
    const cncEnclosureGeo = new THREE.BoxGeometry(7, 5, 6);
    const cncMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.7, roughness: 0.3 });
    const cncEnclosure = new THREE.Mesh(cncEnclosureGeo, cncMat);
    cncEnclosure.position.y = 2.5;
    cncEnclosure.castShadow = true;
    cncGroup.add(cncEnclosure);

    // Polycarbonate blue tinted door window
    const glassGeo = new THREE.PlaneGeometry(4, 3);
    const glassMat = new THREE.MeshStandardMaterial({ 
      color: 0x0284c7, 
      transparent: true, 
      opacity: 0.6, 
      roughness: 0.1 
    });
    const glass = new THREE.Mesh(glassGeo, glassMat);
    glass.position.set(0, 2.5, 3.05);
    cncGroup.add(glass);

    scene.add(cncGroup);

    // 6. ROBOT-17 (6-Axis Manipulator)
    const robotGroup = new THREE.Group();
    robotGroup.position.set(-35, 0, 10);

    // Base Pedestal
    const baseGeo = new THREE.CylinderGeometry(1.0, 1.2, 1.2, 20);
    const robotOrangeMat = new THREE.MeshStandardMaterial({ color: 0xe11d48, roughness: 0.4, metalness: 0.6 });
    const robotBase = new THREE.Mesh(baseGeo, robotOrangeMat);
    robotBase.position.y = 0.6;
    robotBase.castShadow = true;
    robotGroup.add(robotBase);

    // Lower Arm
    const arm1Geo = new THREE.BoxGeometry(0.8, 3.2, 0.8);
    const arm1 = new THREE.Mesh(arm1Geo, robotOrangeMat);
    arm1.position.set(0, 2.6, 0.4);
    arm1.rotation.x = -0.3;
    robotGroup.add(arm1);

    // Forearm
    const arm2Geo = new THREE.BoxGeometry(0.6, 2.8, 0.6);
    const arm2 = new THREE.Mesh(arm2Geo, robotOrangeMat);
    arm2.position.set(0, 4.4, -0.2);
    arm2.rotation.x = 0.6;
    robotGroup.add(arm2);

    // Wrist & Gripper Holding Hot Billet
    const gripGeo = new THREE.BoxGeometry(0.8, 0.4, 0.8);
    const gripper = new THREE.Mesh(gripGeo, colMat);
    gripper.position.set(0, 5.2, 0.8);
    robotGroup.add(gripper);

    const billetGeo = new THREE.CylinderGeometry(0.3, 0.3, 2.2, 16);
    const billetMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, emissive: 0xd97706, emissiveIntensity: 0.6 });
    const billet = new THREE.Mesh(billetGeo, billetMat);
    billet.rotation.z = Math.PI / 2;
    billet.position.set(0, 5.2, 1.6);
    robotGroup.add(billet);

    robotGroupRef.current = robotGroup;
    scene.add(robotGroup);
  };

  const createOverheadCrane = (): THREE.Group => {
    const craneGroup = new THREE.Group();
    craneGroup.position.set(0, 26, 0);

    const bridgeGeo = new THREE.BoxGeometry(4, 2, 74);
    const craneYellowMat = new THREE.MeshStandardMaterial({ color: 0xfacc15, roughness: 0.5 });
    const bridge = new THREE.Mesh(bridgeGeo, craneYellowMat);
    craneGroup.add(bridge);

    // Trolley & Cable Hoist
    const hoistGeo = new THREE.BoxGeometry(3, 2, 3);
    const hoist = new THREE.Mesh(hoistGeo, craneYellowMat);
    hoist.position.set(0, -1.5, 0);
    craneGroup.add(hoist);

    const cableGeo = new THREE.CylinderGeometry(0.05, 0.05, 14, 8);
    const cableMat = new THREE.MeshBasicMaterial({ color: 0x94a3b8 });
    const cable = new THREE.Mesh(cableGeo, cableMat);
    cable.position.set(0, -9, 0);
    craneGroup.add(cable);

    return craneGroup;
  };

  return (
    <div className="relative w-full h-full bg-[#0d1114] overflow-hidden select-none">
      {/* 3D WebGL Canvas */}
      <div 
        ref={mountRef} 
        className="w-full h-full cursor-grab active:cursor-grabbing"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onWheel={handleWheel}
      />

      {/* Top Floating View Controls & Presets */}
      <div className="absolute top-4 left-4 right-4 flex items-center justify-between pointer-events-none">
        {/* View Camera Presets */}
        <div className="flex items-center gap-1.5 bg-steel-900/90 backdrop-blur-md p-1.5 rounded-xl border border-steel-700 shadow-xl pointer-events-auto">
          <span className="text-[11px] font-mono text-zinc-400 px-2 flex items-center gap-1.5 border-r border-steel-700 mr-1">
            <Compass className="w-3.5 h-3.5 text-sky-400" />
            CAMERA
          </span>
          {(
            [
              { id: 'OVERVIEW', label: 'Full Works' },
              { id: 'MELT_SHOP', label: 'Melt Shop (EAF/LF)' },
              { id: 'FORGE_MILL', label: 'Forge & Rolling' },
              { id: 'ROBOTICS_CNC', label: 'Machining & Robot' },
              { id: 'METROLOGY', label: 'Metrology Lab' }
            ] as const
          ).map(p => (
            <button
              key={p.id}
              onClick={() => setViewPreset(p.id)}
              className={`px-2.5 py-1 text-xs font-medium rounded-lg transition-all ${
                viewPreset === p.id 
                  ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40 shadow-sm' 
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-steel-800'
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>

        {/* Viewport Rendering Layers */}
        <div className="flex items-center gap-2 bg-steel-900/90 backdrop-blur-md p-1.5 rounded-xl border border-steel-700 shadow-xl pointer-events-auto">
          <button
            onClick={() => setRenderMode('REALISTIC')}
            className={`px-3 py-1 text-xs font-medium rounded-lg flex items-center gap-1.5 transition-all ${
              renderMode === 'REALISTIC' ? 'bg-zinc-800 text-zinc-100 border border-zinc-600' : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Eye className="w-3.5 h-3.5 text-zinc-300" />
            3D Realistic
          </button>
          <button
            onClick={() => setRenderMode('THERMAL')}
            className={`px-3 py-1 text-xs font-medium rounded-lg flex items-center gap-1.5 transition-all ${
              renderMode === 'THERMAL' ? 'bg-orange-500/20 text-orange-300 border border-orange-500/40' : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Flame className="w-3.5 h-3.5 text-orange-400" />
            Thermal IR
          </button>
          <button
            onClick={() => setRenderMode('SAFETY_ENVELOPES')}
            className={`px-3 py-1 text-xs font-medium rounded-lg flex items-center gap-1.5 transition-all ${
              renderMode === 'SAFETY_ENVELOPES' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            Safety Envelopes
          </button>
        </div>
      </div>

      {/* Floating HUD Live Telemetry Overlays */}
      <div className="absolute bottom-6 left-6 flex items-end gap-3 pointer-events-none">
        {/* EAF Mini Overlay */}
        <div 
          onClick={() => onSelectMachine('EAF-01')}
          className="pointer-events-auto bg-steel-900/90 backdrop-blur-md p-3 rounded-xl border border-steel-700 hover:border-orange-500/50 cursor-pointer shadow-xl transition-all hover:scale-102 w-52"
        >
          <div className="flex items-center justify-between text-xs text-zinc-400 mb-1">
            <span className="font-mono text-orange-400 font-semibold flex items-center gap-1">
              <Zap className="w-3.5 h-3.5" />
              EAF-01
            </span>
            <span className="px-1.5 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              MELTING
            </span>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-bold font-mono-num text-zinc-100">
              {state.machines.find(m => m.id === 'EAF-01')?.temperatureC}°C
            </span>
            <span className="text-xs font-mono text-zinc-400">
              {state.machines.find(m => m.id === 'EAF-01')?.powerDrawMW.toFixed(1)} MW
            </span>
          </div>
          <div className="w-full bg-steel-800 h-1.5 rounded-full overflow-hidden mt-2">
            <div 
              className="bg-orange-500 h-full transition-all duration-300"
              style={{ width: `${((state.machines.find(m => m.id === 'EAF-01')?.temperatureC || 1500) / 1680) * 100}%` }}
            />
          </div>
        </div>

        {/* ROBOT-17 Mini Overlay */}
        <div 
          onClick={() => onSelectMachine('ROBOT-17')}
          className="pointer-events-auto bg-steel-900/90 backdrop-blur-md p-3 rounded-xl border border-steel-700 hover:border-sky-500/50 cursor-pointer shadow-xl transition-all hover:scale-102 w-52"
        >
          <div className="flex items-center justify-between text-xs text-zinc-400 mb-1">
            <span className="font-mono text-sky-400 font-semibold flex items-center gap-1">
              <Cpu className="w-3.5 h-3.5" />
              ROBOT-17
            </span>
            <span className="px-1.5 py-0.5 rounded text-[10px] bg-sky-500/20 text-sky-300 border border-sky-500/30">
              AUTO
            </span>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-sm font-bold font-mono-num text-zinc-200">
              X:{state.robot.cartesianTCP.x.toFixed(0)} Y:{state.robot.cartesianTCP.y.toFixed(0)}
            </span>
            <span className="text-xs font-mono text-zinc-400">
              {state.robot.tcpSpeedMmS} mm/s
            </span>
          </div>
          <div className="text-[10px] font-mono text-zinc-400 mt-1 truncate">
            Target: {state.robot.targetWaypoint}
          </div>
        </div>

        {/* CNC-04 Mini Overlay */}
        <div 
          onClick={() => onSelectMachine('CNC-04')}
          className="pointer-events-auto bg-steel-900/90 backdrop-blur-md p-3 rounded-xl border border-steel-700 hover:border-emerald-500/50 cursor-pointer shadow-xl transition-all hover:scale-102 w-52"
        >
          <div className="flex items-center justify-between text-xs text-zinc-400 mb-1">
            <span className="font-mono text-emerald-400 font-semibold flex items-center gap-1">
              <Activity className="w-3.5 h-3.5" />
              CNC-04
            </span>
            <span className={`px-1.5 py-0.5 rounded text-[10px] ${
              (state.machines.find(m => m.id === 'CNC-04')?.vibrationRmsMmS || 0) > 5
                ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
            }`}>
              {(state.machines.find(m => m.id === 'CNC-04')?.vibrationRmsMmS || 0) > 5 ? 'FAULT' : 'RUNNING'}
            </span>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-lg font-bold font-mono-num text-zinc-100">
              {state.machines.find(m => m.id === 'CNC-04')?.vibrationRmsMmS.toFixed(1)} mm/s
            </span>
            <span className="text-xs font-mono text-zinc-400">
              Vib RMS
            </span>
          </div>
          <div className="text-[10px] font-mono text-zinc-400 mt-1">
            Spindle: 4,200 RPM (Load 68%)
          </div>
        </div>
      </div>

      {/* Viewport Instructions Overlay */}
      <div className="absolute bottom-6 right-6 bg-steel-900/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-steel-700 text-[11px] font-mono text-zinc-400">
        Left Click + Drag: Orbit • Scroll: Zoom • Click Machines: Telemetry Focus
      </div>
    </div>
  );
};
