export interface JointLimits {
  min: number;
  max: number;
  maxSpeedDegS: number;
}

export const ROBOT_17_LIMITS: JointLimits[] = [
  { min: -180, max: 180, maxSpeedDegS: 120 }, // J1: Base rotation
  { min: -100, max: 135, maxSpeedDegS: 110 }, // J2: Shoulder
  { min: -200, max: 70, maxSpeedDegS: 120 },  // J3: Elbow
  { min: -270, max: 270, maxSpeedDegS: 180 }, // J4: Forearm roll
  { min: -125, max: 125, maxSpeedDegS: 180 }, // J5: Wrist pitch
  { min: -360, max: 360, maxSpeedDegS: 260 }  // J6: Flange roll
];

// Link lengths in mm (Heavy industrial handling manipulator model)
export const LINK_LENGTHS = {
  d1: 650,  // Base height to J2
  a1: 250,  // J1 offset
  a2: 1050, // Upper arm length (J2 to J3)
  a3: 350,  // Elbow offset
  d4: 1150, // Forearm length (J3 to J5)
  d6: 220   // Tool flange offset
};

export interface CartesianPose {
  x: number;
  y: number;
  z: number;
  rx: number;
  ry: number;
  rz: number;
}

export function forwardKinematics(jointsDeg: [number, number, number, number, number, number]): CartesianPose {
  const rad = jointsDeg.map(d => (d * Math.PI) / 180);
  const [q1, q2, q3, q4, q5, q6] = rad;

  // Geometric forward kinematics calculation
  const l1 = LINK_LENGTHS.d1;
  const l2 = LINK_LENGTHS.a2;
  const l3 = LINK_LENGTHS.d4;
  const ltool = LINK_LENGTHS.d6;

  // Planar arm extension in J1 plane
  const planarDist = LINK_LENGTHS.a1 + l2 * Math.cos(q2) + l3 * Math.cos(q2 + q3) + ltool * Math.cos(q2 + q3 + q5);
  const x = Math.cos(q1) * planarDist;
  const y = Math.sin(q1) * planarDist;
  const z = l1 + l2 * Math.sin(q2) + l3 * Math.sin(q2 + q3) + ltool * Math.sin(q2 + q3 + q5);

  // Approximate Euler angles
  const rx = Math.round((jointsDeg[4] * Math.sin(rad[0]) + jointsDeg[3] * Math.cos(rad[0])) * 10) / 10;
  const ry = Math.round((jointsDeg[1] + jointsDeg[2] + jointsDeg[4]) * 10) / 10;
  const rz = Math.round((jointsDeg[0] + jointsDeg[5]) * 10) / 10;

  return {
    x: Math.round(x * 10) / 10,
    y: Math.round(y * 10) / 10,
    z: Math.round(z * 10) / 10,
    rx,
    ry,
    rz
  };
}

export function checkWorkspaceLimits(pose: CartesianPose): {
  inWorkspace: boolean;
  reachMm: number;
  maxReachMm: number;
  safetyViolation: boolean;
  details: string;
} {
  const maxReach = 2550; // mm
  const minReach = 450;  // mm safety keep-out cylinder around base
  const floorLevel = 50;  // mm minimum Z clearance

  const radialDist = Math.sqrt(pose.x * pose.x + pose.y * pose.y);
  const totalDist = Math.sqrt(pose.x * pose.x + pose.y * pose.y + (pose.z - LINK_LENGTHS.d1) ** 2);

  const inWorkspace = totalDist <= maxReach && radialDist >= minReach && pose.z >= floorLevel;
  const safetyViolation = radialDist < minReach || pose.z < floorLevel || totalDist > (maxReach - 50);

  let details = 'Within certified ISO 10218-1 safety envelope.';
  if (radialDist < minReach) details = 'CRITICAL: Base keep-out cylinder breach (<450mm).';
  else if (pose.z < floorLevel) details = 'WARNING: Proximity to floor boundary (<50mm).';
  else if (totalDist > maxReach) details = 'ERROR: Exceeds maximum radial reach of 2,550mm.';

  return {
    inWorkspace,
    reachMm: Math.round(totalDist),
    maxReachMm: maxReach,
    safetyViolation,
    details
  };
}

export function inverseKinematicsNumerical(
  target: { x: number; y: number; z: number },
  currentJoints: [number, number, number, number, number, number]
): [number, number, number, number, number, number] {
  // Simple geometric inverse kinematics for heavy 6-axis industrial arm
  const q1 = Math.atan2(target.y, target.x) * (180 / Math.PI);
  const r = Math.sqrt(target.x * target.x + target.y * target.y) - LINK_LENGTHS.a1;
  const zRel = target.z - LINK_LENGTHS.d1;
  const dist = Math.sqrt(r * r + zRel * zRel);

  const l2 = LINK_LENGTHS.a2;
  const l3 = LINK_LENGTHS.d4;

  // Law of cosines for elbow
  const cosQ3 = (dist * dist - l2 * l2 - l3 * l3) / (2 * l2 * l3);
  const clampedCosQ3 = Math.max(-1, Math.min(1, cosQ3));
  const q3Rad = Math.acos(clampedCosQ3) - Math.PI / 2;
  const q3 = q3Rad * (180 / Math.PI);

  // Shoulder angle
  const phi1 = Math.atan2(zRel, r);
  const phi2 = Math.atan2(l3 * Math.sin(q3Rad + Math.PI / 2), l2 + l3 * Math.cos(q3Rad + Math.PI / 2));
  const q2 = (phi1 - phi2) * (180 / Math.PI);

  const q4 = currentJoints[3];
  const q5 = -(q2 + q3); // Keep tool level
  const q6 = currentJoints[5];

  return [
    Math.round(q1 * 10) / 10,
    Math.round(q2 * 10) / 10,
    Math.round(q3 * 10) / 10,
    Math.round(q4 * 10) / 10,
    Math.round(q5 * 10) / 10,
    Math.round(q6 * 10) / 10
  ];
}
