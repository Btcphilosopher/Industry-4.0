import { 
  MachineTwin, 
  PlantZone, 
  Heat, 
  ProductionOrder, 
  IndustrialEvent, 
  EnergyState, 
  RobotTelemetry, 
  MachineState,
  QualityRecord
} from '../types/twin.types';
import { INITIAL_MACHINES, INITIAL_PLANT_ZONES, INITIAL_HEATS, INITIAL_PRODUCTION_ORDERS, INITIAL_EVENTS } from '../data/plant-zones';
import { forwardKinematics, checkWorkspaceLimits } from './kinematics.service';

export type SimSpeed = 0 | 0.5 | 1 | 2 | 5;

export interface SimulationState {
  simTimeSeconds: number; // Seconds since midnight: 14:32:08 = 52328
  simTimeString: string;
  speed: SimSpeed;
  isRunning: boolean;
  tickCount: number;
  machines: MachineTwin[];
  zones: PlantZone[];
  heats: Heat[];
  productionOrders: ProductionOrder[];
  events: IndustrialEvent[];
  energy: EnergyState;
  robot: RobotTelemetry;
  selectedMachineId: string | null;
  selectedZoneId: string | null;
  selectedHeatId: string;
  selectedOrderId: string;
  activeScenarioId: string;
  eStopActive: boolean;
}

export class IndustrialSimulationEngine {
  private state: SimulationState;
  private listeners: Set<(state: SimulationState) => void> = new Set();
  private intervalTimer: ReturnType<typeof setInterval> | null = null;

  constructor() {
    const initialJoints: [number, number, number, number, number, number] = [14.2, -32.5, 48.0, 0.0, 74.5, 12.0];
    const initialPose = forwardKinematics(initialJoints);

    this.state = {
      simTimeSeconds: 14 * 3600 + 32 * 60 + 8, // 14:32:08
      simTimeString: '14:32:08',
      speed: 1,
      isRunning: true,
      tickCount: 0,
      machines: JSON.parse(JSON.stringify(INITIAL_MACHINES)),
      zones: JSON.parse(JSON.stringify(INITIAL_PLANT_ZONES)),
      heats: JSON.parse(JSON.stringify(INITIAL_HEATS)),
      productionOrders: JSON.parse(JSON.stringify(INITIAL_PRODUCTION_ORDERS)),
      events: JSON.parse(JSON.stringify(INITIAL_EVENTS)),
      energy: {
        totalGridDrawMW: 71.3,
        eafDrawMW: 58.4,
        rollingDrawMW: 8.9,
        machiningDrawMW: 2.3,
        auxiliaryDrawMW: 1.7,
        powerFactor: 0.95,
        gridTariffPenceKWh: 14.8,
        peakDemandPenaltyActive: false,
        naturalGasFlowNm3H: 1450,
        compressedAirPressureBar: 7.2,
        coolingWaterFlowM3H: 3800,
        carbonIntensityKgCO2Ton: 345,
        dailyEnergyMWh: 482.4,
        specificEnergyKwhTonne: 431,
        targetSpecificEnergyKwhTonne: 420
      },
      robot: {
        jointAnglesDeg: initialJoints,
        cartesianTCP: initialPose,
        tcpSpeedMmS: 450,
        tcpAccelerationMmS2: 1200,
        payloadKg: 125,
        cycleTimeSeconds: 32.4,
        targetWaypoint: 'WP-FORGE-FEED-02',
        trajectoryState: 'TRAJECTORY_EXECUTION',
        safetyEnvelopeViolated: false,
        collisionWarning: false,
        jointTorquesNm: [240, 580, 420, 110, 85, 30],
        jointTempsC: [38.2, 42.1, 40.5, 36.4, 35.8, 34.2],
        gripperState: 'CLAMPED',
        waypointProgram: [
          { id: 'WP-01', name: 'HOME_POSITION', x: 1200, y: 0, z: 900, speed: 600, action: 'VERIFY_SAFETY_ZONE' },
          { id: 'WP-02', name: 'PICK_BLOOM_BUFFER', x: 1650, y: -450, z: 420, speed: 350, action: 'ENGAGE_CLAMP_140KN' },
          { id: 'WP-03', name: 'TRANSFER_ARC', x: 1420, y: -320, z: 850, speed: 500, action: 'TRAJECTORY_SMOOTH' },
          { id: 'WP-04', name: 'FEED_FORGE_PRESS', x: 1850, y: 350, z: 580, speed: 250, action: 'SYNCHRONIZE_HYDRAULICS' },
          { id: 'WP-05', name: 'LASER_INSPECTION_PASS', x: 1350, y: 600, z: 750, speed: 200, action: 'SCAN_BARCODE_PROFILE' }
        ]
      },
      selectedMachineId: 'EAF-01',
      selectedZoneId: 'ZONE-04',
      selectedHeatId: 'HEAT-2026-8894',
      selectedOrderId: 'PO-1042',
      activeScenarioId: 'BASE',
      eStopActive: false
    };

    this.startClock();
  }

  public subscribe(listener: (state: SimulationState) => void): () => void {
    this.listeners.add(listener);
    listener(this.state);
    return () => this.listeners.delete(listener);
  }

  private notify(): void {
    this.listeners.forEach(l => l(this.state));
  }

  public getState(): SimulationState {
    return this.state;
  }

  public setSpeed(speed: SimSpeed): void {
    this.state.speed = speed;
    this.state.isRunning = speed > 0;
    this.notify();
  }

  public togglePlayPause(): void {
    if (this.state.isRunning) {
      this.state.isRunning = false;
    } else {
      this.state.isRunning = true;
      if (this.state.speed === 0) this.state.speed = 1;
    }
    this.notify();
  }

  public stepOnce(): void {
    this.updatePhysicsTick(1);
    this.notify();
  }

  public setSimTime(seconds: number): void {
    this.state.simTimeSeconds = Math.max(8 * 3600, Math.min(24 * 3600, seconds));
    this.state.simTimeString = this.formatTime(this.state.simTimeSeconds);
    this.notify();
  }

  public selectMachine(id: string | null): void {
    this.state.selectedMachineId = id;
    if (id) {
      const machine = this.state.machines.find(m => m.id === id);
      if (machine) {
        this.state.selectedZoneId = machine.zoneId;
      }
    }
    this.notify();
  }

  public selectZone(id: string | null): void {
    this.state.selectedZoneId = id;
    this.notify();
  }

  public selectHeat(id: string): void {
    this.state.selectedHeatId = id;
    this.notify();
  }

  public selectOrder(id: string): void {
    this.state.selectedOrderId = id;
    this.notify();
  }

  public triggerEmergencyStop(): void {
    this.state.eStopActive = !this.state.eStopActive;
    if (this.state.eStopActive) {
      this.state.machines.forEach(m => {
        if (m.state !== 'IDLE' && m.state !== 'MAINTENANCE') {
          m.state = 'EMERGENCY_STOP';
        }
      });
      this.addEvent({
        source: 'SAFETY_SYSTEM',
        zone: 'ZONE-19',
        severity: 'ALARM',
        message: 'PLANT-WIDE EMERGENCY STOP TRIGGERED. All hydraulic drives and high-voltage arcs interlocked.',
        parameter: 'E_STOP',
        value: 'ACTIVE'
      });
    } else {
      this.state.machines.forEach(m => {
        if (m.state === 'EMERGENCY_STOP') {
          m.state = 'READY';
        }
      });
      this.addEvent({
        source: 'SAFETY_SYSTEM',
        zone: 'ZONE-19',
        severity: 'INFO',
        message: 'Plant safety interlocks reset. Operators confirmed area clear.',
        parameter: 'E_STOP',
        value: 'CLEARED'
      });
    }
    this.notify();
  }

  public setMachineState(machineId: string, state: MachineState): void {
    const machine = this.state.machines.find(m => m.id === machineId);
    if (machine) {
      machine.state = state;
      this.addEvent({
        source: machine.code,
        zone: machine.zoneId,
        severity: 'INFO',
        message: `Machine state manually transitioned to ${state}`,
        parameter: 'State',
        value: state
      });
      this.notify();
    }
  }

  public setEafPower(powerMW: number): void {
    const eaf = this.state.machines.find(m => m.id === 'EAF-01');
    if (eaf) {
      eaf.powerDrawMW = Math.max(0, Math.min(75, powerMW));
      this.state.energy.eafDrawMW = eaf.powerDrawMW;
      this.state.energy.totalGridDrawMW = eaf.powerDrawMW + this.state.energy.rollingDrawMW + this.state.energy.machiningDrawMW + 3.5;
      this.notify();
    }
  }

  public trimAlloy(heatId: string, element: 'C' | 'Mn' | 'Cr' | 'Ni' | 'Mo' | 'V', deltaWeightKg: number): void {
    const heat = this.state.heats.find(h => h.id === heatId);
    if (heat) {
      // 100kg in 88t bath changes alloy by approx 100 / 88000 = 0.11%
      const deltaPercent = deltaWeightKg / (heat.scrapWeightTonnes * 10);
      heat.chemistry[element] = Math.round((heat.chemistry[element] + deltaPercent) * 1000) / 1000;
      this.addEvent({
        source: 'LF-01',
        zone: 'ZONE-05',
        severity: 'INFO',
        message: `Wire injection trim: +${deltaWeightKg}kg ${element} alloy added to ${heat.id}. New ${element}: ${heat.chemistry[element]}%`,
        parameter: element,
        value: `${heat.chemistry[element]}%`
      });
      this.notify();
    }
  }

  public jogRobotJoint(jointIndex: number, deltaDeg: number): void {
    const current = [...this.state.robot.jointAnglesDeg] as [number, number, number, number, number, number];
    current[jointIndex] = Math.round((current[jointIndex] + deltaDeg) * 10) / 10;
    
    const newPose = forwardKinematics(current);
    const limits = checkWorkspaceLimits(newPose);

    this.state.robot.jointAnglesDeg = current;
    this.state.robot.cartesianTCP = newPose;
    this.state.robot.safetyEnvelopeViolated = limits.safetyViolation;
    this.state.robot.collisionWarning = limits.reachMm > 2500;

    const robotTwin = this.state.machines.find(m => m.id === 'ROBOT-17');
    if (robotTwin) {
      robotTwin.telemetry['TCP Position X (mm)'] = newPose.x;
      robotTwin.telemetry['TCP Position Y (mm)'] = newPose.y;
      robotTwin.telemetry['TCP Position Z (mm)'] = newPose.z;
    }

    this.notify();
  }

  public executeRobotWaypoint(waypointId: string): void {
    const wp = this.state.robot.waypointProgram.find(w => w.id === waypointId);
    if (wp) {
      this.state.robot.targetWaypoint = wp.name;
      this.state.robot.trajectoryState = 'TRAJECTORY_EXECUTION';
      
      // Interpolate towards waypoint coordinates
      this.state.robot.cartesianTCP.x = wp.x;
      this.state.robot.cartesianTCP.y = wp.y;
      this.state.robot.cartesianTCP.z = wp.z;

      this.addEvent({
        source: 'ROBOT-17',
        zone: 'ZONE-15',
        severity: 'INFO',
        message: `Executing trajectory segment to waypoint ${wp.name} (${wp.action})`,
        parameter: 'Waypoint',
        value: wp.name
      });
      this.notify();
    }
  }

  public applyScenario(scenarioId: string): void {
    this.state.activeScenarioId = scenarioId;

    if (scenarioId === 'COPPER_TRAMP') {
      const activeHeat = this.state.heats.find(h => h.id === 'HEAT-2026-8894');
      if (activeHeat) {
        activeHeat.chemistry.Cu = 0.38; // Contamination above 0.20% max
      }
      this.addEvent({
        source: 'OES-SPECTROMETER',
        zone: 'ZONE-04',
        severity: 'ALARM',
        message: 'SCENARIO ACTIVE: Copper tramp element contamination detected (Cu=0.38%). Exceeds S355J2 ceiling of 0.20%. Dilution required.',
        parameter: 'Cu_Content',
        value: '0.38%'
      });
    } else if (scenarioId === 'POWER_TARIFF_CAP') {
      this.setEafPower(44.0);
      this.state.energy.peakDemandPenaltyActive = true;
      this.addEvent({
        source: 'ENERGY_MANAGEMENT',
        zone: 'ZONE-19',
        severity: 'WARNING',
        message: 'SCENARIO ACTIVE: National Grid Triad peak tariff alert. EAF power throttled to 44 MW peak cap.',
        parameter: 'GridPowerCap',
        value: '44 MW'
      });
    } else if (scenarioId === 'CNC_VIBRATION') {
      const cnc = this.state.machines.find(m => m.id === 'CNC-04');
      if (cnc) {
        cnc.vibrationRmsMmS = 7.4;
        cnc.healthScore = 64;
        cnc.alarms.push({
          id: 'ALM-CNC-VIB-01',
          timestamp: this.state.simTimeString,
          code: 'VIB_BEARING_BPFO',
          severity: 'CRITICAL',
          description: 'Spindle outer race harmonic peak (BPFO 420Hz) exceeding ISO 10816-3 threshold (7.4 mm/s).',
          acknowledged: false,
          sourceVariable: 'Spindle_Vibration',
          limitValue: '4.5 mm/s',
          currentValue: '7.4 mm/s'
        });
      }
      this.addEvent({
        source: 'CNC-04',
        zone: 'ZONE-14',
        severity: 'CRITICAL',
        message: 'SCENARIO ACTIVE: Spindle bearing harmonic vibration surge (7.4 mm/s). Predictive maintenance flag.',
        parameter: 'Vibration',
        value: '7.4 mm/s'
      });
    } else if (scenarioId === 'BASE') {
      const cnc = this.state.machines.find(m => m.id === 'CNC-04');
      if (cnc) {
        cnc.vibrationRmsMmS = 2.4;
        cnc.healthScore = 88;
        cnc.alarms = [];
      }
      this.state.energy.peakDemandPenaltyActive = false;
      this.addEvent({
        source: 'SIMULATION_CORE',
        zone: 'ZONE-01',
        severity: 'INFO',
        message: 'Scenario reset to BASE nominal steady-state Sheffield works profile.',
        parameter: 'Scenario',
        value: 'BASE_NOMINAL'
      });
    }

    this.notify();
  }

  public ackAlarm(alarmId: string): void {
    this.state.machines.forEach(m => {
      const alarm = m.alarms.find(a => a.id === alarmId);
      if (alarm) alarm.acknowledged = true;
    });
    const evt = this.state.events.find(e => e.id === alarmId);
    if (evt) evt.ack = true;
    this.notify();
  }

  private startClock(): void {
    if (this.intervalTimer) clearInterval(this.intervalTimer);
    this.intervalTimer = setInterval(() => {
      if (this.state.isRunning && !this.state.eStopActive) {
        this.updatePhysicsTick(this.state.speed);
        this.notify();
      }
    }, 1000);
  }

  private updatePhysicsTick(timeDeltaFactor: number): void {
    if (timeDeltaFactor === 0) return;

    this.state.tickCount++;
    this.state.simTimeSeconds += Math.round(1 * timeDeltaFactor);
    if (this.state.simTimeSeconds >= 24 * 3600) {
      this.state.simTimeSeconds = 8 * 3600;
    }
    this.state.simTimeString = this.formatTime(this.state.simTimeSeconds);

    // EAF Physics simulation
    const eaf = this.state.machines.find(m => m.id === 'EAF-01');
    const activeHeat = this.state.heats.find(h => h.id === 'HEAT-2026-8894');
    if (eaf && activeHeat && eaf.state === 'MELTING') {
      // Small thermal increase proportional to MW
      const tempDelta = (eaf.powerDrawMW / 60) * 0.15 * timeDeltaFactor;
      activeHeat.currentTemp = Math.min(1660, Math.round((activeHeat.currentTemp + tempDelta) * 10) / 10);
      eaf.temperatureC = activeHeat.currentTemp;
      activeHeat.powerConsumedMWh += (eaf.powerDrawMW / 3600) * timeDeltaFactor;
      activeHeat.specificEnergyKwhTon = Math.round((activeHeat.powerConsumedMWh * 1000) / activeHeat.scrapWeightTonnes);

      // Arc noise flicker
      const jitter = (Math.random() - 0.5) * 1.5;
      eaf.telemetry['Phase A Current (kA)'] = Math.round((62.4 + jitter) * 10) / 10;
      eaf.telemetry['Phase B Current (kA)'] = Math.round((63.8 + jitter * 0.8) * 10) / 10;
      eaf.telemetry['Phase C Current (kA)'] = Math.round((61.9 - jitter) * 10) / 10;

      if (activeHeat.currentTemp >= 1640 && activeHeat.stage === 'MELTING') {
        eaf.telemetry['Tap Readiness'] = 'READY_TO_TAP_1640C';
      }
    }

    // Robot joint motion simulation
    if (this.state.robot.trajectoryState === 'TRAJECTORY_EXECUTION') {
      const j1 = this.state.robot.jointAnglesDeg[0];
      const targetJ1 = (this.state.tickCount % 20 > 10) ? 22 : 12;
      const stepJ1 = (targetJ1 - j1) * 0.1;
      this.state.robot.jointAnglesDeg[0] = Math.round((j1 + stepJ1) * 10) / 10;
      this.state.robot.cartesianTCP = forwardKinematics(this.state.robot.jointAnglesDeg);
    }

    // Update machine history buffers periodically (every 10 ticks)
    if (this.state.tickCount % 10 === 0) {
      const timeLabel = this.state.simTimeString.slice(0, 5);
      this.state.machines.forEach(m => {
        m.history.push({
          timestamp: timeLabel,
          power: m.powerDrawMW,
          temp: m.temperatureC,
          vibration: m.vibrationRmsMmS,
          health: m.healthScore
        });
        if (m.history.length > 20) m.history.shift();
      });
    }
  }

  private addEvent(evt: Omit<IndustrialEvent, 'id' | 'timestamp' | 'ack'>): void {
    const id = `EVT-${Math.floor(1000 + Math.random() * 9000)}`;
    const newEvent: IndustrialEvent = {
      id,
      timestamp: this.state.simTimeString,
      ack: false,
      ...evt
    };
    this.state.events.unshift(newEvent);
    if (this.state.events.length > 50) this.state.events.pop();
  }

  private formatTime(totalSeconds: number): string {
    const h = Math.floor(totalSeconds / 3600);
    const m = Math.floor((totalSeconds % 3600) / 60);
    const s = totalSeconds % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  }
}

export const simulationEngine = new IndustrialSimulationEngine();
