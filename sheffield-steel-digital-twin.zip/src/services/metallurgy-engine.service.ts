import { SteelChemistry } from '../types/twin.types';
import { SHEFFIELD_STEEL_GRADES } from '../data/sheffield-grades';
import { calculateCEV, calculatePREN, calculateMsTemp, SteelGrade } from '../types/metallurgy.types';

export interface KnowledgeNode {
  id: string;
  name: string;
  category: 'GRADE' | 'PROCESS' | 'MICROSTRUCTURE' | 'DEFECT' | 'HEAT_TREAT' | 'STANDARD';
  description: string;
  links: string[];
}

export const KNOWLEDGE_GRAPH_NODES: KnowledgeNode[] = [
  {
    id: 'NODE-S355',
    name: 'S355J2 Structural Steel',
    category: 'GRADE',
    description: 'Fine grain structural steel microalloyed with Vanadium for North Sea offshore & marine shaft forgings.',
    links: ['NODE-EAF', 'NODE-LF', 'NODE-FORGE', 'NODE-FERRITE_PEARLITE', 'NODE-EN10025']
  },
  {
    id: 'NODE-316L',
    name: '316L Marine Austenitic Stainless',
    category: 'GRADE',
    description: '17Cr-12Ni-2.5Mo low-carbon stainless providing PREN > 24 for nuclear coolant valve bodies.',
    links: ['NODE-EAF', 'NODE-VD', 'NODE-AUSTENITE', 'NODE-SOL_ANNEAL', 'NODE-EN10088']
  },
  {
    id: 'NODE-H13',
    name: 'H13 Hot Work Tool Steel',
    category: 'GRADE',
    description: '5% Cr-Mo-V vacuum-degassed tool steel with extreme resistance to thermal fatigue and heat checking.',
    links: ['NODE-VD', 'NODE-FORGE', 'NODE-MARTENSITE', 'NODE-TRIPLE_TEMPER', 'NODE-ISO4957']
  },
  {
    id: 'NODE-EAF',
    name: 'Electric Arc Furnace Melting',
    category: 'PROCESS',
    description: 'Primary scrap recycling via 75MW graphite electrode AC arc, eccentric bottom tapping, and foaming slag.',
    links: ['NODE-SLAG_FOAM', 'NODE-DEPHOSPHORISATION', 'NODE-LF']
  },
  {
    id: 'NODE-LF',
    name: 'Ladle Refining Furnace (LF)',
    category: 'PROCESS',
    description: 'Synthetic calcium-aluminate slag desulfurisation (S < 0.005%) and precision cored wire alloying.',
    links: ['NODE-DESULFURISATION', 'NODE-INCLUSION_CLEAN', 'NODE-VD']
  },
  {
    id: 'NODE-VD',
    name: 'Tank Vacuum Degassing',
    category: 'PROCESS',
    description: 'Sub-1.0 mbar vacuum degassing removing dissolved hydrogen (H < 1.5 ppm) to eliminate flake defects.',
    links: ['NODE-HYDROGEN_FLAKE', 'NODE-CCM']
  },
  {
    id: 'NODE-FORGE',
    name: '30MN Hydraulic Forging Press',
    category: 'PROCESS',
    description: 'Heavy open-die ingot reduction breaking cast dendritic structures into isotropic forged grain flow.',
    links: ['NODE-GRAIN_REFINEMENT', 'NODE-CNC']
  },
  {
    id: 'NODE-FERRITE_PEARLITE',
    name: 'Ferrite-Pearlite Microstructure',
    category: 'MICROSTRUCTURE',
    description: 'Ductile bcc alpha-iron matrix interleaved with cementite lamellae, ideal for general structural steels.',
    links: ['NODE-S355', 'NODE-NORMALISING']
  },
  {
    id: 'NODE-MARTENSITE',
    name: 'Tempered Martensite',
    category: 'MICROSTRUCTURE',
    description: 'Diffusionless shear transformation phase offering high yield strength (up to 1900 MPa) and wear resistance.',
    links: ['NODE-H13', 'NODE-4140', 'NODE-QUENCH']
  },
  {
    id: 'NODE-HYDROGEN_FLAKE',
    name: 'Hydrogen Induced Flaking',
    category: 'DEFECT',
    description: 'Internal micro-cracking in thick forgings caused by trapped atomic hydrogen during rapid cooling.',
    links: ['NODE-VD', 'NODE-SLOW_COOLING']
  }
];

export interface DiagnosticQuery {
  topic: string;
  contextData?: any;
}

export function diagnoseMetallurgicalIssue(query: string, currentChemistry?: SteelChemistry): {
  headline: string;
  analysis: string;
  recommendations: string[];
  equations: { name: string; formula: string; result: string }[];
} {
  const q = query.toLowerCase();

  if (q.includes('copper') || q.includes('tramp') || q.includes('cu')) {
    const cuVal = currentChemistry ? currentChemistry.Cu : 0.38;
    return {
      headline: 'Tramp Copper Contamination & Hot Shortness Risk',
      analysis: `Analytical spectrometry records Cu = ${cuVal} wt%. Copper has zero solubility in iron oxide scale during reheating at 1150-1250°C. Residual molten copper accumulates at austenite grain boundaries, leading to liquid metal embrittlement ('hot shortness') and edge cracking during rolling or forging.`,
      recommendations: [
        'Dilute melt immediately in Ladle Furnace with 15t prime low-residual pig iron or DRI pellets.',
        'Increase nickel addition to maintain Ni:Cu ratio >= 1.5:1 to increase copper solubility in austenite.',
        'Reduce reheat furnace drop-out temperature from 1250°C to 1180°C to minimize scale formation kinetics.'
      ],
      equations: [
        { name: 'Ni/Cu Solubility Ratio', formula: 'Ni_wt% / Cu_wt% >= 1.5', result: `${((currentChemistry?.Ni || 0.10) / cuVal).toFixed(2)} (Target >= 1.50)` }
      ]
    };
  }

  if (q.includes('hydrogen') || q.includes('degass') || q.includes('flake') || q.includes('vd')) {
    return {
      headline: 'Hydrogen Control & Vacuum Degassing Kinetics',
      analysis: `Dissolved hydrogen in liquid steel at tap is typically 4.0-7.0 ppm. For thick-section rotor forgings (e.g. S355 / 4140 > 300mm diameter), residual hydrogen above 1.8 ppm causes internal hair-line flaking due to molecular H2 recombination under high triaxial residual stress.`,
      recommendations: [
        'Maintain Tank Vacuum Degasser (VD-01) at < 1.0 mbar for minimum 18 minutes with 300 NL/min argon bottom purge.',
        'Direct hot blooms immediately into insulated cooling hoods (Zone 09) for controlled slow cooling (< 20°C/hr).',
        'Verify hydrogen content < 1.5 ppm via Hydris immersion probe prior to tundish open-pour.'
      ],
      equations: [
        { name: 'Sieverts Law for Hydrogen', formula: '[H]_ppm = K_H * sqrt(P_H2_mbar)', result: 'P < 1.0 mbar -> [H] < 1.4 ppm' }
      ]
    };
  }

  if (q.includes('weld') || q.includes('cev') || q.includes('carbon equivalent')) {
    const chem = currentChemistry || SHEFFIELD_STEEL_GRADES[1].nominalChemistry;
    const cev = calculateCEV(chem);
    return {
      headline: 'Weldability & Carbon Equivalent Assessment',
      analysis: `Calculated Carbon Equivalent (IIW CEV) is ${cev.toFixed(3)}. For structural steels (BS EN 1011-2), a CEV < 0.45 indicates good weldability with standard preheat. Above 0.45, hydrogen-assisted cold cracking (HACC) risk increases in the Heat Affected Zone (HAZ).`,
      recommendations: [
        cev > 0.45 ? 'Mandate preheating to 150°C and low-hydrogen electrodes (HDM < 5 ml/100g).' : 'Standard workshop welding without high preheat acceptable.',
        'Control heat input between 1.2 and 2.5 kJ/mm to prevent excessive austenite grain coarsening.'
      ],
      equations: [
        { name: 'IIW Carbon Equivalent', formula: 'CEV = C + Mn/6 + (Cr+Mo+V)/5 + (Ni+Cu)/15', result: `CEV = ${cev.toFixed(3)}` }
      ]
    };
  }

  // Default general diagnosis
  const chem = currentChemistry || SHEFFIELD_STEEL_GRADES[1].nominalChemistry;
  const cev = calculateCEV(chem);
  const pren = calculatePREN(chem);
  const ms = calculateMsTemp(chem);

  return {
    headline: 'Sheffield Metallurgical Process Evaluation',
    analysis: `Process telemetry confirms nominal alloy matrix with balanced deoxidation and slag basicity. Grain refinement achieved through microalloy precipitation and controlled thermo-mechanical rolling.`,
    recommendations: [
      'Maintain tundish superheat within 25-35°C window for optimum equiaxed bloom central zone.',
      'Verify CMM geometric deviations and ultrasonic A-scan reflection gates prior to final release.'
    ],
    equations: [
      { name: 'IIW CEV', formula: 'C + Mn/6 + (Cr+Mo+V)/5 + (Ni+Cu)/15', result: cev.toFixed(3) },
      { name: 'PREN Corrosion Index', formula: 'Cr + 3.3*Mo + 16*N', result: pren.toFixed(1) },
      { name: 'Andrews Ms Temp', formula: 'Ms (°C)', result: `${ms} °C` }
    ]
  };
}
