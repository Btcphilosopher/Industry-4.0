import { SteelChemistry } from './twin.types';

export interface SteelGrade {
  id: string;
  name: string;
  category: 'STRUCTURAL' | 'AUSTENITIC_STAINLESS' | 'ENGINEERING_ALLOY' | 'HOT_WORK_TOOL_STEEL' | 'BEARING_STEEL';
  standard: string;
  sheffieldHeritageNote: string;
  nominalChemistry: SteelChemistry;
  minChemistry: Partial<SteelChemistry>;
  maxChemistry: Partial<SteelChemistry>;
  mechanicalProperties: {
    yieldStrengthMpa: number;
    tensileStrengthMpa: number;
    elongationPercent: number;
    hardnessHB: number;
    hardnessHRC?: number;
    charpyVNotchJoules: number;
    densityKgM3: number;
    youngsModulusGpa: number;
  };
  thermalProperties: {
    meltingRangeC: [number, number];
    ac1TempC: number;
    ac3TempC: number;
    msTempC: number;
    mfTempC: number;
    thermalConductivityWmK: number;
  };
  heatTreatment: {
    austenitisingTempC: number;
    quenchMedium: 'WATER' | 'OIL' | 'POLYMERIC' | 'AIR_BLAST' | 'VACUUM_GAS';
    temperingRangeC: [number, number];
    targetHardness: string;
    stressReliefTempC: number;
  };
  typicalApplications: string[];
}

export interface TransformationPoint {
  timeSeconds: number;
  temperatureC: number;
  phase: 'AUSTENITE' | 'FERRITE' | 'PEARLITE' | 'BAINITE' | 'MARTENSITE';
}

export function calculateCEV(chem: SteelChemistry): number {
  // IIW Carbon Equivalent formula: CEV = C + Mn/6 + (Cr+Mo+V)/5 + (Ni+Cu)/15
  return chem.C + (chem.Mn / 6) + ((chem.Cr + chem.Mo + chem.V) / 5) + ((chem.Ni + chem.Cu) / 15);
}

export function calculatePREN(chem: SteelChemistry): number {
  // Pitting Resistance Equivalent: PREN = Cr + 3.3*Mo + 16*N (with N in wt%)
  const nPercent = chem.N_ppm / 10000;
  return chem.Cr + (3.3 * chem.Mo) + (16 * nPercent);
}

export function calculateMsTemp(chem: SteelChemistry): number {
  // Andrews product formula: Ms (°C) = 512 - 453*C - 16.9*Ni + 15*Cr - 9.5*Mo + 217*(C^2) - 71.5*(C*Mn) - 67.6*(C*Cr)
  const ms = 512 - (453 * chem.C) - (16.9 * chem.Ni) + (15 * chem.Cr) - (9.5 * chem.Mo) 
             + (217 * Math.pow(chem.C, 2)) - (71.5 * chem.C * chem.Mn) - (67.6 * chem.C * chem.Cr);
  return Math.round(ms);
}
