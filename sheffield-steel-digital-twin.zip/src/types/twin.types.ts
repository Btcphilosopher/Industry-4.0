export type MachineState = 
  | 'IDLE' 
  | 'HEATING' 
  | 'MELTING' 
  | 'CASTING' 
  | 'ROLLING' 
  | 'FORGING' 
  | 'MACHINING' 
  | 'INSPECTING' 
  | 'MAINTENANCE' 
  | 'EMERGENCY_STOP' 
  | 'READY';

export type ViewMode = 
  | 'TWIN' 
  | 'STEEL' 
  | 'ROBOTICS' 
  | 'PRODUCTION' 
  | 'MACHINES' 
  | 'QUALITY' 
  | 'ENERGY' 
  | 'MAINTENANCE' 
  | 'LOGISTICS' 
  | 'ANALYTICS' 
  | 'KNOWLEDGE' 
  | 'SCENARIOS' 
  | 'REPLAY';

export type AlarmSeverity = 'INFO' | 'WARNING' | 'CRITICAL' | 'ALARM';

export interface PlantZone {
  id: string;
  code: string;
  name: string;
  plantArea: 'MELT_SHOP' | 'SECONDARY_METALLURGY' | 'CASTING_HOT_WORKING' | 'PRECISION_MANUFACTURING' | 'QUALITY_LOGISTICS' | 'UTILITIES';
  description: string;
  activeAssetCount: number;
  safetyLevel: 'LEVEL_1_GENERAL' | 'LEVEL_2_RESTRICTED' | 'LEVEL_3_HIGH_VOLTAGE' | 'LEVEL_4_MOLTEN_METAL';
  currentTemp: number; // °C ambient in zone
  powerDrawMW: number;
  operatorsOnShift: number;
}

export interface MachineAlarm {
  id: string;
  timestamp: string;
  code: string;
  severity: AlarmSeverity;
  description: string;
  acknowledged: boolean;
  sourceVariable: string;
  limitValue: number | string;
  currentValue: number | string;
}

export interface MachineTwin {
  id: string;
  code: string;
  name: string;
  zoneId: string;
  type: 
    | 'ELECTRIC_ARC_FURNACE'
    | 'LADLE_FURNACE'
    | 'VACUUM_DEGASSER'
    | 'CONTINUOUS_CASTER'
    | 'REHEAT_FURNACE'
    | 'ROLLING_MILL'
    | 'HYDRAULIC_FORGE_PRESS'
    | 'HEAT_TREATMENT_QUENCH'
    | 'ROBOTIC_MANIPULATOR'
    | 'CNC_5AXIS_MILLING'
    | 'COORDINATE_MEASURING'
    | 'ULTRASONIC_NDT';
  state: MachineState;
  healthScore: number; // 0 - 100
  powerDrawMW: number;
  temperatureC: number;
  utilizationPercent: number;
  vibrationRmsMmS: number;
  operationalHoursTotal: number;
  hoursUntilService: number;
  telemetry: Record<string, number | string | boolean>;
  alarms: MachineAlarm[];
  position3D: [number, number, number];
  dimensions3D: [number, number, number];
  history: {
    timestamp: string;
    power: number;
    temp: number;
    vibration: number;
    health: number;
  }[];
}

export interface SteelChemistry {
  C: number;
  Si: number;
  Mn: number;
  P: number;
  S: number;
  Cr: number;
  Ni: number;
  Mo: number;
  V: number;
  Cu: number;
  Al: number;
  N_ppm: number;
  H_ppm: number;
  O_ppm: number;
}

export interface Heat {
  id: string; // e.g. "HEAT-2026-8894"
  heatNumber: number;
  orderId: string;
  gradeId: string;
  scrapWeightTonnes: number;
  targetTapTemp: number; // e.g. 1640°C
  currentTemp: number;
  powerConsumedMWh: number;
  specificEnergyKwhTon: number;
  stage: 
    | 'SCRAP_CHARGING' 
    | 'MELTING' 
    | 'REFINING' 
    | 'DEGASSING' 
    | 'CASTING' 
    | 'COOLING' 
    | 'COMPLETED';
  chemistry: SteelChemistry;
  targetChemistry: SteelChemistry;
  slagBasicity: number; // CaO / SiO2 ratio, target 2.2 - 2.8
  argonFlowNlMin: number;
  vacuumMbar: number;
  durationMinutes: number;
  tundishSuperheatC: number;
  strandSpeedMMin: number;
}

export interface ProductionOrder {
  id: string;
  orderNumber: string;
  clientName: string;
  componentType: string;
  steelGrade: string;
  quantity: number;
  weightTonnes: number;
  requiredDimensions: string;
  orderDate: string;
  deliveryDate: string;
  status: 'PLANNED' | 'IN_PROGRESS' | 'QUALITY_HOLD' | 'INSPECTION' | 'COMPLETED' | 'DISPATCHED';
  currentZone: string;
  currentMachineId: string;
  progressPercent: number;
  scrapHeatId: string;
  digitalPassportId: string;
  routeSteps: {
    step: number;
    name: string;
    machineCode: string;
    status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'FAILED';
    completedAt?: string;
  }[];
}

export interface RobotTelemetry {
  jointAnglesDeg: [number, number, number, number, number, number];
  cartesianTCP: {
    x: number;
    y: number;
    z: number;
    rx: number;
    ry: number;
    rz: number;
  };
  tcpSpeedMmS: number;
  tcpAccelerationMmS2: number;
  payloadKg: number;
  cycleTimeSeconds: number;
  targetWaypoint: string;
  trajectoryState: 'IDLE' | 'TRAJECTORY_EXECUTION' | 'PICK_ENGAGED' | 'PLACE_RELEASE' | 'INSPECT_DWELL' | 'SAFETY_HALT';
  safetyEnvelopeViolated: boolean;
  collisionWarning: boolean;
  jointTorquesNm: [number, number, number, number, number, number];
  jointTempsC: [number, number, number, number, number, number];
  gripperState: 'OPEN' | 'CLAMPED' | 'VACUUM_HOLD';
  waypointProgram: {
    id: string;
    name: string;
    x: number;
    y: number;
    z: number;
    speed: number;
    action: string;
  }[];
}

export interface QualityRecord {
  id: string;
  partSerial: string;
  heatId: string;
  orderId: string;
  timestamp: string;
  cmmResults: {
    feature: string;
    nominal: number;
    actual: number;
    tolLower: number;
    tolUpper: number;
    deviation: number;
    status: 'PASS' | 'WARN' | 'FAIL';
  }[];
  ndtUltrasonic: {
    gateA_amplitudePercent: number;
    gateB_amplitudePercent: number;
    flawDetected: boolean;
    flawDepthMm: number;
    aScanData: number[]; // 50 amplitude data points
    frequencyMhz: number;
    gainDb: number;
  };
  mechanicalTests: {
    yieldStrengthMpa: number;
    tensileStrengthMpa: number;
    elongationPercent: number;
    hardnessHRC: number;
    charpyImpactJoules: number;
  };
  status: 'APPROVED' | 'SCRAP' | 'REWORK_REQUIRED';
  releaseEngineer: string;
}

export interface IndustrialEvent {
  id: string;
  timestamp: string;
  source: string;
  zone: string;
  severity: AlarmSeverity;
  message: string;
  parameter?: string;
  value?: string | number;
  ack: boolean;
}

export interface EnergyState {
  totalGridDrawMW: number;
  eafDrawMW: number;
  rollingDrawMW: number;
  machiningDrawMW: number;
  auxiliaryDrawMW: number;
  powerFactor: number;
  gridTariffPenceKWh: number;
  peakDemandPenaltyActive: boolean;
  naturalGasFlowNm3H: number;
  compressedAirPressureBar: number;
  coolingWaterFlowM3H: number;
  carbonIntensityKgCO2Ton: number;
  dailyEnergyMWh: number;
  specificEnergyKwhTonne: number;
  targetSpecificEnergyKwhTonne: number;
}

export interface DigitalProductPassport {
  passportId: string;
  partNumber: string;
  description: string;
  serialNumber: string;
  steelGrade: string;
  standard: string;
  heatId: string;
  meltDate: string;
  finishDate: string;
  batchYieldPct: number;
  carbonFootprintKgCO2: number;
  recycledScrapContentPct: number;
  ultrasonicCert: string;
  cmmCert: string;
  tensileCert: string;
  heatTreatmentProfile: string;
  destinationClient: string;
  verifiedSignature: string;
}
