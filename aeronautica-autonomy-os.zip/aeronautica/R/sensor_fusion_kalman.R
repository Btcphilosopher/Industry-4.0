#' Sensor Fusion Extended Kalman Filter with Chi-Square Innovation Check
#' @description Fuses Triple-INS, Multi-GNSS, Pitot-Static Air Data, and Radar Altimeter telemetry.
#' @import R6
#' @export
SensorFusionKalman <- R6::R6Class(
  "SensorFusionKalman",
  public = list(
    x_hat = c(0, 0, 0, 0, 0, 0), # [pos_n, pos_e, alt, vel_n, vel_e, vel_d]
    P = diag(c(10.0, 10.0, 5.0, 0.5, 0.5, 0.2)), # Covariance matrix
    Q = diag(c(0.1, 0.1, 0.05, 0.01, 0.01, 0.005)), # Process noise
    R_gps = diag(c(2.5, 2.5, 5.0)), # GPS measurement noise
    R_ins = diag(c(0.2, 0.2, 0.2)), # INS measurement noise
    innovation_threshold = 7.815, # Chi-square 95% threshold for 3-DOF

    initialize = function() {
      self$reset_filter()
    },

    reset_filter = function() {
      self$x_hat <- c(0, 0, 11582.4, 247.0 * cos(1.466), 247.0 * sin(1.466), 0)
      self$P <- diag(c(10.0, 10.0, 5.0, 0.5, 0.5, 0.2))
    },

    predict = function(dt) {
      # State transition matrix F
      F_mat <- diag(6)
      F_mat[1, 4] <- dt
      F_mat[2, 5] <- dt
      F_mat[3, 6] <- dt

      self$x_hat <- as.vector(F_mat %*% self$x_hat)
      self$P <- F_mat %*% self$P %*% t(F_mat) + self$Q * dt
      invisible(self$x_hat)
    },

    update_gps = function(z_gps) {
      # Measurement matrix H for position [pos_n, pos_e, alt]
      H <- matrix(0, nrow = 3, ncol = 6)
      H[1, 1] <- 1
      H[2, 2] <- 1
      H[3, 3] <- 1

      # Innovation y
      y <- z_gps - (H %*% self$x_hat)
      S <- H %*% self$P %*% t(H) + self$R_gps
      
      # Chi-square innovation statistic: d2 = y^T * S^-1 * y
      d2 <- as.numeric(t(y) %*% solve(S) %*% y)
      
      if (d2 > self$innovation_threshold) {
        # Measurement rejected due to sensor spoofing / multipath spike
        return(list(accepted = FALSE, chi_sq = d2, status = "REJECTED_OUTLIER"))
      }

      # Kalman Gain
      K <- self$P %*% t(H) %*% solve(S)
      self$x_hat <- self$x_hat + as.vector(K %*% y)
      self$P <- (diag(6) - K %*% H) %*% self$P

      list(accepted = TRUE, chi_sq = d2, status = "FUSED_NOMINAL")
    }
  )
)
