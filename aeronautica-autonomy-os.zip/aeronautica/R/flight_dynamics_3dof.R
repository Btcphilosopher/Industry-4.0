#' Flight Dynamics 3-DOF and 6-DOF Equations of Motion
#' @description Solves point-mass and rigid-body aircraft equations of motion with aerodynamic polars and atmosphere model.
#' @import R6
#' @export
FlightDynamics3DOF <- R6::R6Class(
  "FlightDynamics3DOF",
  public = list(
    mass_kg = 89000,
    wing_area_m2 = 122.6,
    cd0 = 0.0165,
    oswald_e = 0.85,
    aspect_ratio = 9.8,
    g0 = 9.80665,
    rho0 = 1.225,
    t0_k = 288.15,
    lapse_rate = 0.0065,

    state = list(
      lat = 56.45,
      lon = -38.22,
      alt_m = 11582.4, # 38,000 ft
      tas_mps = 247.0, # ~480 kts
      heading_rad = 1.466, # 84 deg
      gamma_rad = 0.0,
      pitch_rad = 0.0366, # 2.1 deg
      roll_rad = 0.0,
      fuel_mass_kg = 18450
    ),

    initialize = function(mass_kg = 89000, wing_area_m2 = 122.6) {
      self$mass_kg <- mass_kg
      self$wing_area_m2 <- wing_area_m2
    },

    get_isa_atmosphere = function(alt_m) {
      if (alt_m <= 11000) {
        temp_k <- self$t0_k - self$lapse_rate * alt_m
        pressure_pa <- 101325 * (temp_k / self$t0_k)^5.25588
      } else {
        temp_k <- 216.65
        pressure_pa <- 22632 * exp(-self$g0 * (alt_m - 11000) / (287.05 * temp_k))
      }
      density_kgm3 <- pressure_pa / (287.05 * temp_k)
      speed_of_sound_mps <- sqrt(1.4 * 287.05 * temp_k)
      
      list(
        temperature_k = temp_k,
        pressure_pa = pressure_pa,
        density_kgm3 = density_kgm3,
        mach_1_mps = speed_of_sound_mps
      )
    },

    compute_aerodynamics = function(tas_mps, alt_m, thrust_n, load_factor = 1.0) {
      atm <- self$get_isa_atmosphere(alt_m)
      q_inf <- 0.5 * atm$density_kgm3 * tas_mps^2
      
      # Lift coefficient required for load factor
      cl_req <- (self$mass_kg * self$g0 * load_factor) / (q_inf * self$wing_area_m2)
      
      # Induced drag and total drag coefficient
      k <- 1 / (pi * self$aspect_ratio * self$oswald_e)
      cd <- self$cd0 + k * cl_req^2
      
      drag_n <- cd * q_inf * self$wing_area_m2
      lift_n <- cl_req * q_inf * self$wing_area_m2
      
      mach <- tas_mps / atm$mach_1_mps
      
      list(
        cl = cl_req,
        cd = cd,
        lift_n = lift_n,
        drag_n = drag_n,
        mach = mach,
        dynamic_pressure_pa = q_inf,
        excess_thrust_n = thrust_n - drag_n
      )
    },

    step_rk4 = function(dt_sec, target_heading_rad, target_alt_m, target_mach) {
      atm <- self$get_isa_atmosphere(self$state$alt_m)
      target_tas <- target_mach * atm$mach_1_mps
      
      # Guidance response
      heading_err <- target_heading_rad - self$state$heading_rad
      alt_err <- target_alt_m - self$state$alt_m
      
      # Roll command based on heading error
      cmd_roll <- max(-0.436, min(0.436, heading_err * 1.5)) # max 25 deg bank
      self$state$roll_rad <- self$state$roll_rad + (cmd_roll - self$state$roll_rad) * min(1.0, dt_sec * 0.8)
      
      # Heading turn rate: dpsi/dt = (g / V) * tan(phi)
      turn_rate <- (self$g0 / max(50, self$state$tas_mps)) * tan(self$state$roll_rad)
      self$state$heading_rad <- (self$state$heading_rad + turn_rate * dt_sec) %% (2 * pi)
      
      # Vertical rate
      cmd_vs <- max(-15.0, min(12.0, alt_err * 0.05))
      self$state$alt_m <- max(0, self$state$alt_m + cmd_vs * dt_sec)
      
      # Velocity response
      speed_err <- target_tas - self$state$tas_mps
      self$state$tas_mps <- self$state$tas_mps + speed_err * min(1.0, dt_sec * 0.1)
      
      # Kinematic position propagation
      v_north <- self$state$tas_mps * cos(self$state$heading_rad)
      v_east <- self$state$tas_mps * sin(self$state$heading_rad)
      
      # 1 deg lat ~ 111,139 m
      dlat_deg <- (v_north * dt_sec) / 111139
      dlon_deg <- (v_east * dt_sec) / (111139 * cos(self$state$lat * pi / 180))
      
      self$state$lat <- self$state$lat + dlat_deg
      self$state$lon <- self$state$lon + dlon_deg
      
      # Fuel burn
      fuel_flow_kg_sec <- (self$mass_kg * 0.000035) * (self$state$tas_mps / 240)
      self$state$fuel_mass_kg <- max(0, self$state$fuel_mass_kg - fuel_flow_kg_sec * dt_sec)
      self$mass_kg <- self$mass_kg - fuel_flow_kg_sec * dt_sec
      
      invisible(self$state)
    }
  )
)
