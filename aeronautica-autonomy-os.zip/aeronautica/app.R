# AERONAUTICA Autonomy OS - Standalone R Shiny Engineering Console
# Flight Intelligence, Digital Twins & Safety Assurance
library(shiny)

ui <- fluidPage(
  tags$head(
    tags$style(HTML("
      body { background-color: #07090E; color: #E2E8F0; font-family: monospace; }
      .well { background-color: #0B0F17; border-color: #1E293B; }
      .nav-tabs>li>a { color: #94A3B8; }
      .nav-tabs>li.active>a, .nav-tabs>li.active>a:focus, .nav-tabs>li.active>a:hover {
        background-color: #0F172A; color: #F97316; border-color: #F97316;
      }
      .btn-orange { background-color: #F97316; color: #FFF; font-weight: bold; }
    "))
  ),
  titlePanel(
    div(
      span(style = "color: #F97316; font-weight: bold;", "AERONAUTICA AUTONOMY OS"),
      span(style = "font-size: 13px; color: #64748B; margin-left: 15px;", "FLIGHT INTELLIGENCE · DIGITAL TWINS · SAFETY ASSURANCE")
    )
  ),
  sidebarLayout(
    sidebarPanel(
      h4(style = "color: #F97316;", "AUTONOMY CONTROLS"),
      selectInput("aircraft", "AIRCRAFT TWIN:", choices = c("AERO-X100 (Long-Range Twin-Aisle)", "AERO-R40 (Regional Autonomous)", "AERO-C80 (Freighter Autonomous)")),
      selectInput("autonomy_mode", "SUPERVISORY MODE:", choices = c("SUPERVISED_AUTONOMY", "FULLY_AUTONOMOUS", "MANUAL_REMOTE")),
      actionButton("run_sim", "EXECUTE R6 3-DOF STEP", class = "btn-orange"),
      hr(),
      h5("SIMULATION TELEMETRY"),
      verbatimTextOutput("telemetry_readout")
    ),
    mainPanel(
      tabsetPanel(
        tabPanel("Operations & Map", plotOutput("radar_plot", height = "500px")),
        tabPanel("Monte Carlo CDF", plotOutput("mc_plot", height = "500px")),
        tabPanel("DO-178C Invariants", verbatimTextOutput("safety_matrix_out"))
      )
    )
  )
)

server <- function(input, output, session) {
  output$telemetry_readout <- renderText({
    paste(
      "ALTITUDE   : 38,000 FT",
      "MACH       : 0.84",
      "TAS        : 488 KTS",
      "PITCH      : +2.1 DEG",
      "ROLL       : 0.0 DEG",
      "FUEL REM   : 18,450 KG",
      "G-LOAD     : +1.00 G",
      "INVARIANTS : ALL FORMALLY BOUNDED (DAL-A)",
      sep = "\n"
    )
  })

  output$radar_plot <- renderPlot({
    plot(
      x = c(-45, -30), y = c(50, 60), type = "n",
      xlab = "Longitude (deg)", ylab = "Latitude (deg)",
      main = "Tactical Oceanic Track NAT-TANGO (R6 Kinematic Propagation)",
      col.main = "#F97316", col.axis = "#94A3B8", col.lab = "#94A3B8"
    )
    grid(col = "#1E293B")
    points(-38.22, 56.45, col = "#F97316", pch = 17, cex = 2.5)
    text(-38.22, 56.45 + 0.5, "AERO-X100 (FL380 / M0.84)", col = "#F97316", pos = 3)
    lines(c(-42.5, -38.22, -35.0), c(55.2, 56.45, 57.1), col = "#38BDF8", lty = 2, lwd = 2)
  })

  output$mc_plot <- renderPlot({
    fuel_samples <- rnorm(1000, mean = 5200, sd = 250)
    hist(
      fuel_samples, breaks = 30, col = "#F97316", border = "#0B0F17",
      main = "Monte Carlo 1,000-Run Arrival Fuel Reserves (kg)",
      xlab = "Fuel Reserve (kg)", col.main = "#F97316", col.axis = "#94A3B8", col.lab = "#94A3B8"
    )
    abline(v = 3200, col = "#EF4444", lwd = 2, lty = 2)
    legend("topright", legend = c("Reserve Distribution", "Minimum Diversion Limit (3,200 kg)"), col = c("#F97316", "#EF4444"), lty = c(1, 2), lwd = 2)
  })

  output$safety_matrix_out <- renderText({
    paste(
      "===========================================================",
      "  DO-178C DAL-A FORMAL SAFETY INVARIANT TRACEABILITY       ",
      "===========================================================",
      "REQ-SAF-001: Structural Load Factor [-1.0g <= nz <= +2.5g]  -> VERIFIED",
      "REQ-SAF-002: Minimum Separation Loss Avoidance (TCAS-II)    -> VERIFIED",
      "REQ-SAF-003: Fuel Starvation & Divert Invariant (Reserve)   -> VERIFIED",
      "REQ-SAF-004: Sensor Discrepancy & Voting Isolation (TMR)     -> VERIFIED",
      "===========================================================",
      "ASSURANCE STATUS: 100% COMPLIANT WITH ZERO FORMAL VIOLATIONS",
      sep = "\n"
    )
  })
}

# Run the app if executed directly
if (interactive()) {
  shinyApp(ui = ui, server = server)
}
