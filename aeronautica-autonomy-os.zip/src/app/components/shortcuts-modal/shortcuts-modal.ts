import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../core/services/simulation.service';

@Component({
  selector: 'app-shortcuts-modal',
  imports: [CommonModule, MatIconModule],
  template: `
    @if (sim.isShortcutsModalOpen()) {
      <div 
        role="dialog"
        aria-modal="true"
        aria-label="Keyboard Shortcuts"
        (click)="close()"
        (keydown.escape)="close()"
        tabindex="-1"
        class="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 select-none">
        
        <div 
          (click)="$event.stopPropagation()"
          (keydown)="$event.stopPropagation()"
          tabindex="0"
          class="w-full max-w-lg bg-[#0B0F17] border border-slate-700 rounded-xl shadow-2xl p-5 flex flex-col gap-4 font-mono text-xs">
          
          <div class="flex items-center justify-between border-b border-slate-800 pb-2.5">
            <div class="flex items-center gap-2 text-orange-400 font-bold text-sm">
              <mat-icon class="!text-[18px] !w-4.5 !h-4.5">keyboard</mat-icon>
              <span>KEYBOARD SHORTCUTS</span>
            </div>
            <button 
              type="button"
              (click)="close()"
              class="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800">
              <mat-icon class="!text-[16px] !w-4 !h-4">close</mat-icon>
            </button>
          </div>

          <div class="space-y-2">
            <div class="flex items-center justify-between py-1.5 border-b border-slate-800/60">
              <span class="text-slate-300">Command Palette</span>
              <kbd class="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-orange-400 font-bold">Ctrl + K / ⌘K</kbd>
            </div>
            <div class="flex items-center justify-between py-1.5 border-b border-slate-800/60">
              <span class="text-slate-300">Play / Pause Simulation Clock</span>
              <kbd class="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-orange-400 font-bold">Space</kbd>
            </div>
            <div class="flex items-center justify-between py-1.5 border-b border-slate-800/60">
              <span class="text-slate-300">Reset Scenario</span>
              <kbd class="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-orange-400 font-bold">Ctrl + R</kbd>
            </div>
            <div class="flex items-center justify-between py-1.5 border-b border-slate-800/60">
              <span class="text-slate-300">Close Open Modal / Dialog</span>
              <kbd class="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300">ESC</kbd>
            </div>
          </div>

          <div class="pt-2 border-t border-slate-800 flex justify-end">
            <button 
              type="button"
              (click)="close()"
              class="px-4 py-1.5 rounded bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs transition-colors">
              CLOSE
            </button>
          </div>
        </div>
      </div>
    }
  `
})
export class ShortcutsModal {
  public sim = inject(SimulationService);

  public close(): void {
    this.sim.isShortcutsModalOpen.set(false);
  }
}
