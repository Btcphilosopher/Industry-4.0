import { Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../core/services/simulation.service';

@Component({
  selector: 'app-flight-map',
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="relative w-full h-full min-h-[460px] bg-[#070A0F] border border-slate-800 rounded-lg overflow-hidden flex flex-col select-none">
      <!-- Map Top HUD Bar -->
      <div class="absolute top-2 left-2 right-2 z-10 flex items-center justify-between pointer-events-none">
        <div class="pointer-events-auto flex items-center gap-2 bg-[#0C111A]/90 backdrop-blur border border-slate-700/80 px-3 py-1.5 rounded text-xs font-mono text-slate-300">
          <div class="flex items-center gap-1.5 text-orange-400 font-bold">
            <span class="w-2 h-2 rounded-full bg-orange-500 animate-pulse"></span>
            <span>TACTICAL AIRSPACE RADAR</span>
          </div>
          <span class="text-slate-600">|</span>
          <span>RANGE: <strong class="text-white">160 NM</strong></span>
          <span class="text-slate-600">|</span>
          <span>HDG: <strong class="text-orange-400">{{ sim.aircraftState().heading_deg }}°</strong></span>
          <span class="text-slate-600">|</span>
          <span>POS: <strong class="text-slate-200">{{ sim.aircraftState().lat }}°N, {{ Math.abs(sim.aircraftState().lon) }}°W</strong></span>
        </div>

        <!-- Layer Toggles -->
        <div class="pointer-events-auto flex items-center gap-1 bg-[#0C111A]/90 backdrop-blur border border-slate-700/80 p-1 rounded text-xs font-mono">
          <button 
            (click)="showWeather.set(!showWeather())"
            class="px-2 py-1 rounded text-[11px] transition-colors flex items-center gap-1"
            [class.bg-orange-500]="showWeather()"
            [class.text-white]="showWeather()"
            [class.text-slate-400]="!showWeather()">
            <mat-icon class="!text-[12px] !w-3 !h-3">storm</mat-icon>
            <span>WEATHER</span>
          </button>

          <button 
            (click)="showTraffic.set(!showTraffic())"
            class="px-2 py-1 rounded text-[11px] transition-colors flex items-center gap-1"
            [class.bg-orange-500]="showTraffic()"
            [class.text-white]="showTraffic()"
            [class.text-slate-400]="!showTraffic()">
            <mat-icon class="!text-[12px] !w-3 !h-3">radar</mat-icon>
            <span>TRAFFIC</span>
          </button>

          <button 
            (click)="showAirways.set(!showAirways())"
            class="px-2 py-1 rounded text-[11px] transition-colors flex items-center gap-1"
            [class.bg-orange-500]="showAirways()"
            [class.text-white]="showAirways()"
            [class.text-slate-400]="!showAirways()">
            <mat-icon class="!text-[12px] !w-3 !h-3">route</mat-icon>
            <span>WAYPOINTS</span>
          </button>

          <button 
            (click)="showDivertRoute.set(!showDivertRoute())"
            class="px-2 py-1 rounded text-[11px] transition-colors flex items-center gap-1"
            [class.bg-amber-500]="showDivertRoute()"
            [class.text-slate-900]="showDivertRoute()"
            [class.text-slate-400]="!showDivertRoute()">
            <mat-icon class="!text-[12px] !w-3 !h-3">alt_route</mat-icon>
            <span>DIVERSION</span>
          </button>

          <button 
            (click)="showTerrain.set(!showTerrain())"
            class="px-2 py-1 rounded text-[11px] transition-colors flex items-center gap-1"
            [class.bg-orange-500]="showTerrain()"
            [class.text-white]="showTerrain()"
            [class.text-slate-400]="!showTerrain()">
            <mat-icon class="!text-[12px] !w-3 !h-3">terrain</mat-icon>
            <span>TERRAIN</span>
          </button>
        </div>
      </div>

      <!-- Main SVG Canvas Viewport -->
      <div class="relative flex-1 w-full h-full overflow-hidden bg-[#070A0F] cursor-crosshair">
        <svg 
          #mapSvg
          class="w-full h-full"
          viewBox="0 0 1000 600"
          preserveAspectRatio="xMidYMid slice">
          
          <defs>
            <!-- Radar sweep gradient -->
            <radialGradient id="radarGrad" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stop-color="#F97316" stop-opacity="0.05" />
              <stop offset="60%" stop-color="#F97316" stop-opacity="0.02" />
              <stop offset="100%" stop-color="#070A0F" stop-opacity="0.8" />
            </radialGradient>

            <!-- Storm cell gradient -->
            <radialGradient id="stormGrad" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stop-color="#DC2626" stop-opacity="0.85" />
              <stop offset="35%" stop-color="#EA580C" stop-opacity="0.65" />
              <stop offset="70%" stop-color="#CA8A04" stop-opacity="0.45" />
              <stop offset="100%" stop-color="#16A34A" stop-opacity="0.0" />
            </radialGradient>

            <!-- Moderate Storm cell gradient -->
            <radialGradient id="modStormGrad" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stop-color="#EA580C" stop-opacity="0.75" />
              <stop offset="50%" stop-color="#EAB308" stop-opacity="0.45" />
              <stop offset="100%" stop-color="#16A34A" stop-opacity="0.0" />
            </radialGradient>

            <!-- Aircraft Marker Glow -->
            <filter id="glowOrange" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          <!-- Background coordinate grid -->
          <g class="grid-lines" stroke="#1E293B" stroke-width="0.5" stroke-dasharray="2,4">
            @for (y of [50, 100, 150, 200, 250, 300, 350, 400, 450, 500, 550]; track y) {
              <line x1="0" [attr.y1]="y" x2="1000" [attr.y2]="y" />
            }
            @for (x of [100, 200, 300, 400, 500, 600, 700, 800, 900]; track x) {
              <line [attr.x1]="x" y1="0" [attr.x2]="x" y2="600" />
            }
          </g>

          <!-- Latitude / Longitude ticks -->
          <g class="text-[10px] font-mono fill-slate-600 select-none">
            <text x="15" y="150">62°N</text>
            <text x="15" y="300">58°N</text>
            <text x="15" y="450">54°N</text>
            <text x="250" y="585">20°W</text>
            <text x="500" y="585">10°W</text>
            <text x="750" y="585">00°W</text>
          </g>

          <!-- Synthetic Coastline & Oceanic Boundary Polygon -->
          @if (showTerrain()) {
            <g class="terrain-layer">
              <!-- Synthetic UK & Scottish High ground -->
              <path d="M 680,360 Q 720,380 750,440 Q 780,500 770,580 L 850,580 L 850,300 Q 750,310 680,360 Z" 
                    fill="#0F172A" stroke="#334155" stroke-width="1.2" opacity="0.6" />
              <!-- Synthetic Faroe / Iceland sector -->
              <path d="M 280,110 Q 320,80 390,120 Q 360,180 290,160 Z" 
                    fill="#0F172A" stroke="#334155" stroke-width="1.2" opacity="0.6" />
              <path d="M 460,180 Q 480,160 510,190 Q 490,220 450,210 Z" 
                    fill="#0F172A" stroke="#334155" stroke-width="1.2" opacity="0.6" />
            </g>
          }

          <!-- Range rings centered on active aircraft -->
          <g class="range-rings" stroke="#F97316" stroke-width="0.75" stroke-opacity="0.25" fill="none">
            <circle [attr.cx]="aircraftCoord().x" [attr.cy]="aircraftCoord().y" r="60" stroke-dasharray="3,3" />
            <circle [attr.cx]="aircraftCoord().x" [attr.cy]="aircraftCoord().y" r="120" stroke-dasharray="3,3" />
            <circle [attr.cx]="aircraftCoord().x" [attr.cy]="aircraftCoord().y" r="180" />
            <text [attr.x]="aircraftCoord().x + 65" [attr.y]="aircraftCoord().y - 4" class="text-[9px] font-mono fill-orange-500/60">25 NM</text>
            <text [attr.x]="aircraftCoord().x + 125" [attr.y]="aircraftCoord().y - 4" class="text-[9px] font-mono fill-orange-500/60">50 NM</text>
            <text [attr.x]="aircraftCoord().x + 185" [attr.y]="aircraftCoord().y - 4" class="text-[9px] font-mono fill-orange-500/60">100 NM</text>
          </g>

          <!-- Candidate Diversion Route (North Detour) -->
          @if (showDivertRoute() && sim.flightPlan().candidate_divert_route) {
            <g class="divert-route-layer">
              <polyline
                [attr.points]="divertRoutePolyline()"
                fill="none"
                stroke="#F59E0B"
                stroke-width="2"
                stroke-dasharray="6,4"
                opacity="0.85" />
              
              <!-- Divert waypoints -->
              @for (wp of sim.flightPlan().candidate_divert_route; track wp.id) {
                @let pos = projectGeo(wp.lat, wp.lon);
                <circle [attr.cx]="pos.x" [attr.cy]="pos.y" r="3.5" fill="#F59E0B" stroke="#000" stroke-width="1" />
                <text [attr.x]="pos.x + 6" [attr.y]="pos.y + 3" class="text-[10px] font-mono fill-amber-300 font-semibold select-none">
                  {{ wp.name }}
                </text>
              }
            </g>
          }

          <!-- Planned Primary Flight Route Line -->
          @if (showAirways()) {
            <g class="primary-route-layer">
              <polyline
                [attr.points]="primaryRoutePolyline()"
                fill="none"
                stroke="#F97316"
                stroke-width="2.5"
                stroke-opacity="0.9" />
              
              <!-- Flight plan waypoints -->
              @for (wp of sim.flightPlan().route; track wp.id; let idx = $index) {
                @let pos = projectGeo(wp.lat, wp.lon);
                <g class="cursor-pointer group">
                  <polygon
                    [attr.points]="getDiamondPoints(pos.x, pos.y, 5)"
                    [attr.fill]="idx === sim.aircraftState().active_waypoint_index ? '#F97316' : '#64748B'"
                    stroke="#0B0F17"
                    stroke-width="1.5" />
                  <text 
                    [attr.x]="pos.x + 8" 
                    [attr.y]="pos.y + 4" 
                    class="text-[10px] font-mono select-none"
                    [class.fill-orange-400]="idx === sim.aircraftState().active_waypoint_index"
                    [class.fill-slate-400]="idx !== sim.aircraftState().active_waypoint_index"
                    [class.font-bold]="idx === sim.aircraftState().active_waypoint_index">
                    {{ wp.name }}
                  </text>
                </g>
              }
            </g>
          }

          <!-- Synthetic Airports Markers -->
          <g class="airports-layer">
            @for (apt of sim.airports(); track apt.id) {
              @let pos = projectGeo(apt.lat, apt.lon);
              <g class="airport-marker cursor-pointer">
                <circle [attr.cx]="pos.x" [attr.cy]="pos.y" r="5" fill="#0284C7" stroke="#38BDF8" stroke-width="1.5" />
                <circle [attr.cx]="pos.x" [attr.cy]="pos.y" r="2" fill="#FFFFFF" />
                <text [attr.x]="pos.x + 8" [attr.y]="pos.y - 4" class="text-[11px] font-mono font-bold fill-cyan-300 select-none">
                  {{ apt.icao }}
                </text>
                <text [attr.x]="pos.x + 8" [attr.y]="pos.y + 7" class="text-[9px] font-mono fill-slate-400 select-none">
                  {{ apt.name.split(' ')[0] }}
                </text>
              </g>
            }
          </g>

          <!-- Weather Storm Cells -->
          @if (showWeather()) {
            <g class="weather-cells-layer">
              @for (cell of sim.weatherCells(); track cell.id) {
                @let pos = projectGeo(cell.lat, cell.lon);
                @let r_px = cell.radius_nm * 2.2;
                <g class="weather-cell">
                  <!-- Outer danger ring -->
                  <circle
                    [attr.cx]="pos.x"
                    [attr.cy]="pos.y"
                    [attr.r]="r_px"
                    [attr.fill]="cell.severity === 'SEVERE' ? 'url(#stormGrad)' : 'url(#modStormGrad)'"
                    stroke="#EF4444"
                    stroke-width="1.2"
                    stroke-dasharray="4,2"
                    class="animate-pulse" />
                  
                  <!-- Cell Core & Label -->
                  <circle [attr.cx]="pos.x" [attr.cy]="pos.y" r="4" fill="#EF4444" />
                  <text [attr.x]="pos.x - 30" [attr.y]="pos.y - r_px - 6" class="text-[10px] font-mono font-bold fill-rose-400">
                    ⚡ {{ cell.name }} (FL{{ cell.top_fl }})
                  </text>
                  <text [attr.x]="pos.x - 30" [attr.y]="pos.y + r_px + 12" class="text-[9px] font-mono fill-amber-300">
                    TURB: {{ cell.turbulence }} · LTG: {{ cell.lightning_rate_per_min }}/min
                  </text>
                </g>
              }
            </g>
          }

          <!-- Synthetic Air Traffic Aircraft -->
          @if (showTraffic()) {
            <g class="traffic-layer">
              @for (traf of sim.trafficList(); track traf.id) {
                @let pos = projectGeo(traf.lat, traf.lon);
                <g class="traffic-target">
                  <!-- Velocity vector leader -->
                  <line 
                    [attr.x1]="pos.x" 
                    [attr.y1]="pos.y" 
                    [attr.x2]="pos.x + Math.sin(traf.heading_deg * Math.PI / 180) * 20" 
                    [attr.y2]="pos.y - Math.cos(traf.heading_deg * Math.PI / 180) * 20" 
                    stroke="#38BDF8" 
                    stroke-width="1" />
                  
                  <!-- Traffic diamond marker -->
                  <polygon 
                    [attr.points]="getDiamondPoints(pos.x, pos.y, 4)" 
                    [attr.fill]="traf.conflict_level === 'ADVISORY' ? '#F59E0B' : '#0284C7'" 
                    stroke="#FFFFFF" 
                    stroke-width="1" />
                  
                  <!-- Callsign & Flight Level Block -->
                  <text [attr.x]="pos.x + 7" [attr.y]="pos.y - 2" class="text-[9px] font-mono font-bold fill-sky-300">
                    {{ traf.callsign }}
                  </text>
                  <text [attr.x]="pos.x + 7" [attr.y]="pos.y + 7" class="text-[9px] font-mono fill-slate-300">
                    FL{{ Math.round(traf.alt_ft / 100) }} · {{ traf.tas_kts }}KT
                  </text>
                </g>
              }
            </g>
          }

          <!-- Active Aircraft Position (A-900X) -->
          <g class="active-aircraft" filter="url(#glowOrange)">
            @let ac = aircraftCoord();
            
            <!-- Historical trail breadcrumbs -->
            @for (pt of historicalPoints(); track pt.sim_time_sec) {
              @let hPos = projectGeo(pt.lat, pt.lon);
              <circle [attr.cx]="hPos.x" [attr.cy]="hPos.y" r="1.5" fill="#F97316" opacity="0.4" />
            }

            <!-- Heading Velocity Vector Leader (10 min projection) -->
            <line
              [attr.x1]="ac.x"
              [attr.y1]="ac.y"
              [attr.x2]="ac.x + Math.sin(sim.aircraftState().heading_deg * Math.PI / 180) * 45"
              [attr.y2]="ac.y - Math.cos(sim.aircraftState().heading_deg * Math.PI / 180) * 45"
              stroke="#F97316"
              stroke-width="2"
              stroke-dasharray="4,2" />

            <!-- Aircraft Vector Glyph -->
            <g [attr.transform]="'translate(' + ac.x + ',' + ac.y + ') rotate(' + sim.aircraftState().heading_deg + ')'">
              <!-- Jet silhouette shape -->
              <path 
                d="M 0,-14 L 3,-4 L 14,2 L 14,5 L 3,3 L 2,10 L 6,13 L 6,15 L 0,13 L -6,15 L -6,13 L -2,10 L -3,3 L -14,5 L -14,2 L -3,-4 Z" 
                fill="#F97316" 
                stroke="#FFFFFF" 
                stroke-width="1.2" />
            </g>

            <!-- Position readout tag -->
            <g [attr.transform]="'translate(' + (ac.x + 16) + ',' + (ac.y - 12) + ')'">
              <rect x="0" y="0" width="94" height="26" fill="#0C111A" stroke="#F97316" stroke-width="1" rx="2" />
              <text x="6" y="11" class="text-[10px] font-mono font-bold fill-orange-400">{{ sim.aircraftState().callsign }}</text>
              <text x="6" y="21" class="text-[9px] font-mono fill-slate-300">FL{{ Math.round(sim.aircraftState().alt_ft / 100) }} · M{{ sim.aircraftState().mach }}</text>
            </g>
          </g>

        </svg>

        <!-- Bottom Left Legend & Map Controls -->
        <div class="absolute bottom-2 left-2 z-10 flex items-center gap-2 bg-[#0C111A]/90 backdrop-blur border border-slate-700/80 px-2.5 py-1 rounded text-[10px] font-mono text-slate-400">
          <div class="flex items-center gap-1">
            <span class="w-3 h-0.5 bg-orange-500 inline-block"></span>
            <span class="text-slate-300">PLANNED ROUTE</span>
          </div>
          <div class="flex items-center gap-1">
            <span class="w-3 h-0.5 bg-amber-400 inline-block border-b border-dashed"></span>
            <span class="text-slate-300">DIVERSION CANDIDATE</span>
          </div>
          <div class="flex items-center gap-1">
            <span class="w-2 h-2 rounded-full bg-red-500 inline-block"></span>
            <span class="text-slate-300">CONVECTIVE HAZARD</span>
          </div>
        </div>
      </div>
    </div>
  `
})
export class FlightMap {
  public sim = inject(SimulationService);
  public Math = Math;

  public showWeather = signal<boolean>(true);
  public showTraffic = signal<boolean>(true);
  public showAirways = signal<boolean>(true);
  public showDivertRoute = signal<boolean>(true);
  public showTerrain = signal<boolean>(true);

  // Geo projection mapping: Lat 50 to 66 -> Y (550 to 50), Lon -25 to 5 -> X (80 to 920)
  public projectGeo(lat: number, lon: number): { x: number; y: number } {
    const minLat = 50.0;
    const maxLat = 66.0;
    const minLon = -25.0;
    const maxLon = 5.0;

    const xNorm = (lon - minLon) / (maxLon - minLon);
    const yNorm = (maxLat - lat) / (maxLat - minLat);

    const x = 80 + xNorm * (920 - 80);
    const y = 50 + yNorm * (550 - 50);

    return { x: Math.round(x * 10) / 10, y: Math.round(y * 10) / 10 };
  }

  public aircraftCoord = computed(() => {
    const s = this.sim.aircraftState();
    return this.projectGeo(s.lat, s.lon);
  });

  public historicalPoints = computed(() => {
    return this.sim.telemetryHistory().slice(-30);
  });

  public primaryRoutePolyline = computed(() => {
    return this.sim
      .flightPlan()
      .route.map(wp => {
        const p = this.projectGeo(wp.lat, wp.lon);
        return `${p.x},${p.y}`;
      })
      .join(' ');
  });

  public divertRoutePolyline = computed(() => {
    const dRoute = this.sim.flightPlan().candidate_divert_route;
    if (!dRoute) return '';
    return dRoute
      .map(wp => {
        const p = this.projectGeo(wp.lat, wp.lon);
        return `${p.x},${p.y}`;
      })
      .join(' ');
  });

  public getDiamondPoints(cx: number, cy: number, r: number): string {
    return `${cx},${cy - r} ${cx + r},${cy} ${cx},${cy + r} ${cx - r},${cy}`;
  }
}
