import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../core/services/simulation.service';

@Component({
  selector: 'app-attitude-director',
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="relative w-full bg-[#080C14] border border-slate-800 rounded-lg p-3 flex flex-col gap-2 font-mono select-none">
      <!-- PFD Top Status Header -->
      <div class="flex items-center justify-between text-xs pb-1 border-b border-slate-800">
        <div class="flex items-center gap-2">
          <span class="text-orange-400 font-bold">PFD / ADI</span>
          <span class="text-slate-500">·</span>
          <span class="text-emerald-400 font-semibold">{{ sim.aircraftState().phase }}</span>
        </div>
        <div class="flex items-center gap-2">
          <span class="text-[10px] text-slate-400">AUTONOMY:</span>
          <span class="text-orange-300 font-semibold text-[11px]">{{ sim.aircraftState().autonomy_mode }}</span>
        </div>
      </div>

      <!-- Main Artificial Horizon Display Area -->
      <div class="relative w-full h-[220px] bg-slate-950 rounded overflow-hidden border border-slate-800 flex items-center justify-center">
        <!-- Sky / Ground Pitch & Roll Rotating Canvas -->
        <div 
          class="absolute w-[360px] h-[360px] flex flex-col transition-transform duration-75 ease-out"
          [style.transform]="'rotate(' + (-sim.aircraftState().roll_deg) + 'deg) translateY(' + (sim.aircraftState().pitch_deg * 4) + 'px)'">
          <!-- Sky Blue/Slate -->
          <div class="w-full h-1/2 bg-gradient-to-t from-[#1E293B] to-[#0F172A] border-b border-white"></div>
          <!-- Ground Earth Brown/Graphite -->
          <div class="w-full h-1/2 bg-gradient-to-b from-[#292524] to-[#1C1917]"></div>
          
          <!-- Pitch Ladder Lines -->
          <div class="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
            <!-- +10 deg pitch -->
            <div class="absolute top-[140px] flex items-center gap-4 text-[9px] text-white">
              <span class="w-6 h-px bg-white"></span>
              <span>10</span>
              <span class="w-6 h-px bg-white"></span>
            </div>
            <!-- +5 deg pitch -->
            <div class="absolute top-[160px] flex items-center gap-3 text-[8px] text-slate-300">
              <span class="w-4 h-px bg-white/70"></span>
              <span>5</span>
              <span class="w-4 h-px bg-white/70"></span>
            </div>
            <!-- Horizon Center Line -->
            <div class="absolute top-[180px] w-48 h-[1.5px] bg-white"></div>
            <!-- -5 deg pitch -->
            <div class="absolute top-[200px] flex items-center gap-3 text-[8px] text-slate-300">
              <span class="w-4 h-px bg-white/70 border-dashed"></span>
              <span>-5</span>
              <span class="w-4 h-px bg-white/70 border-dashed"></span>
            </div>
            <!-- -10 deg pitch -->
            <div class="absolute top-[220px] flex items-center gap-4 text-[9px] text-white">
              <span class="w-6 h-px bg-white border-dashed"></span>
              <span>-10</span>
              <span class="w-6 h-px bg-white border-dashed"></span>
            </div>
          </div>
        </div>

        <!-- Static Aircraft Boresight Reference Crosshair -->
        <div class="absolute z-10 pointer-events-none flex items-center justify-center">
          <div class="w-8 h-1 bg-orange-500 rounded-l shadow-sm shadow-orange-500/50"></div>
          <div class="w-3 h-3 rounded-full border-2 border-orange-500 bg-black/40 mx-1"></div>
          <div class="w-8 h-1 bg-orange-500 rounded-r shadow-sm shadow-orange-500/50"></div>
        </div>

        <!-- Roll Arc Pointer at Top -->
        <div class="absolute top-2 z-10 flex flex-col items-center pointer-events-none">
          <div class="w-0 h-0 border-l-[5px] border-l-transparent border-r-[5px] border-r-transparent border-t-[8px] border-t-orange-400"></div>
          <div class="text-[9px] text-orange-400 font-bold mt-0.5">{{ sim.aircraftState().roll_deg }}°</div>
        </div>

        <!-- Left Speed Tape Overlay -->
        <div class="absolute left-1 top-2 bottom-2 w-16 bg-[#0B0F17]/90 border border-slate-700/80 rounded flex flex-col items-center justify-between py-1 z-10 text-xs">
          <span class="text-[9px] text-slate-400">TAS KT</span>
          <div class="flex flex-col items-center gap-1 text-[10px] text-slate-400">
            <span>{{ sim.aircraftState().tas_kts + 20 }}</span>
            <span>{{ sim.aircraftState().tas_kts + 10 }}</span>
            <div class="bg-orange-500 text-white font-bold px-1 py-0.5 rounded text-[11px] shadow">
              {{ sim.aircraftState().tas_kts }}
            </div>
            <span>{{ sim.aircraftState().tas_kts - 10 }}</span>
            <span>{{ sim.aircraftState().tas_kts - 20 }}</span>
          </div>
          <div class="text-[10px] text-orange-400 font-bold">M {{ sim.aircraftState().mach }}</div>
        </div>

        <!-- Right Altitude Tape Overlay -->
        <div class="absolute right-1 top-2 bottom-2 w-16 bg-[#0B0F17]/90 border border-slate-700/80 rounded flex flex-col items-center justify-between py-1 z-10 text-xs">
          <span class="text-[9px] text-slate-400">ALT FT</span>
          <div class="flex flex-col items-center gap-1 text-[10px] text-slate-400">
            <span>{{ Math.round((sim.aircraftState().alt_ft + 500) / 100) }}00</span>
            <div class="bg-orange-500 text-white font-bold px-1 py-0.5 rounded text-[11px] shadow">
              {{ Math.round(sim.aircraftState().alt_ft / 100) }}00
            </div>
            <span>{{ Math.round((sim.aircraftState().alt_ft - 500) / 100) }}00</span>
          </div>
          <div class="text-[9px] font-bold" [class.text-emerald-400]="sim.aircraftState().vertical_speed_fpm >= 0" [class.text-amber-400]="sim.aircraftState().vertical_speed_fpm < 0">
            {{ sim.aircraftState().vertical_speed_fpm >= 0 ? '+' : '' }}{{ sim.aircraftState().vertical_speed_fpm }}
          </div>
        </div>
      </div>

      <!-- Bottom Telemetry Metric Readouts -->
      <div class="grid grid-cols-4 gap-1.5 pt-1 text-[11px]">
        <div class="bg-slate-900/90 border border-slate-800 p-1.5 rounded">
          <div class="text-[9px] text-slate-500">HEADING</div>
          <div class="text-xs font-bold text-orange-400">{{ sim.aircraftState().heading_deg }}° MAG</div>
        </div>
        <div class="bg-slate-900/90 border border-slate-800 p-1.5 rounded">
          <div class="text-[9px] text-slate-500">G-LOAD</div>
          <div class="text-xs font-bold text-slate-200">{{ sim.aircraftState().g_load }} G</div>
        </div>
        <div class="bg-slate-900/90 border border-slate-800 p-1.5 rounded">
          <div class="text-[9px] text-slate-500">AoA (α)</div>
          <div class="text-xs font-bold text-slate-200">{{ sim.aircraftState().angle_of_attack_deg }}°</div>
        </div>
        <div class="bg-slate-900/90 border border-slate-800 p-1.5 rounded">
          <div class="text-[9px] text-slate-500">ENVELOPE</div>
          <div class="text-xs font-bold text-emerald-400">{{ sim.aircraftState().envelope_status }}</div>
        </div>
      </div>
    </div>
  `
})
export class AttitudeDirector {
  public sim = inject(SimulationService);
  public Math = Math;
}
