import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../core/services/simulation.service';

@Component({
  selector: 'app-failure-modal',
  imports: [CommonModule, MatIconModule],
  template: `
    @if (sim.isFailureModalOpen()) {
      <div 
        role="dialog"
        aria-modal="true"
        aria-label="Failure Injection Dialog"
        (click)="close()"
        (keydown.escape)="close()"
        tabindex="-1"
        class="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 select-none">
        
        <div 
          (click)="$event.stopPropagation()"
          (keydown)="$event.stopPropagation()"
          tabindex="0"
          class="w-full max-w-2xl bg-[#0B0F17] border border-slate-700 rounded-xl shadow-2xl p-5 flex flex-col gap-4 font-mono text-xs max-h-[85vh] overflow-hidden">
          
          <div class="flex items-center justify-between border-b border-slate-800 pb-2.5">
            <div class="flex items-center gap-2 text-amber-400 font-bold text-sm">
              <mat-icon class="!text-[18px] !w-4.5 !h-4.5">warning_amber</mat-icon>
              <span>INJECT HARDWARE OR ENVIRONMENTAL FAILURE</span>
            </div>
            <button 
              type="button"
              (click)="close()"
              class="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800">
              <mat-icon class="!text-[16px] !w-4 !h-4">close</mat-icon>
            </button>
          </div>

          <div class="space-y-2.5 overflow-y-auto max-h-[60vh] pr-1">
            @for (fail of sim.injectedFailures(); track fail.id) {
              <div 
                class="bg-slate-950 border rounded-lg p-3 flex items-center justify-between gap-3"
                [class.border-rose-500]="fail.is_active"
                [class.border-slate-800]="!fail.is_active">
                <div class="flex-1">
                  <div class="flex items-center gap-2">
                    <span class="font-bold text-white">{{ fail.name }}</span>
                    <span 
                      class="text-[9px] font-bold px-1.5 py-0.2 rounded"
                      [class.bg-rose-950]="fail.severity === 'HAZARDOUS' || fail.severity === 'CATASTROPHIC_SIM'"
                      [class.text-rose-400]="fail.severity === 'HAZARDOUS' || fail.severity === 'CATASTROPHIC_SIM'"
                      [class.bg-amber-950]="fail.severity === 'MAJOR'"
                      [class.text-amber-400]="fail.severity === 'MAJOR'">
                      {{ fail.severity }}
                    </span>
                  </div>
                  <p class="text-[11px] text-slate-400 mt-1">{{ fail.description }}</p>
                </div>

                <div>
                  @if (!fail.is_active) {
                    <button 
                      type="button"
                      (click)="inject(fail.id)"
                      class="px-3 py-1.5 rounded bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs transition-colors flex items-center gap-1 shadow">
                      <mat-icon class="!text-[14px] !w-3.5 !h-3.5">bolt</mat-icon>
                      <span>INJECT</span>
                    </button>
                  } @else {
                    <button 
                      type="button"
                      (click)="sim.clearFailure(fail.id)"
                      class="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs transition-colors flex items-center gap-1 border border-slate-700">
                      <mat-icon class="!text-[14px] !w-3.5 !h-3.5">check</mat-icon>
                      <span>RESOLVE</span>
                    </button>
                  }
                </div>
              </div>
            }
          </div>

          <div class="pt-2 border-t border-slate-800 flex justify-end">
            <button 
              type="button"
              (click)="close()"
              class="px-4 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-colors">
              DONE
            </button>
          </div>
        </div>
      </div>
    }
  `
})
export class FailureModal {
  public sim = inject(SimulationService);

  public inject(id: string): void {
    this.sim.injectFailure(id);
    this.close();
  }

  public close(): void {
    this.sim.isFailureModalOpen.set(false);
  }
}
