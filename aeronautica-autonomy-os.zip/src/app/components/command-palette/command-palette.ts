import { Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../core/services/simulation.service';

interface PaletteCommand {
  id: string;
  title: string;
  subtitle: string;
  category: string;
  icon: string;
  action: () => void;
}

@Component({
  selector: 'app-command-palette',
  imports: [CommonModule, MatIconModule],
  template: `
    @if (sim.isCommandPaletteOpen()) {
      <div 
        role="dialog"
        aria-modal="true"
        aria-label="Simulation Command Palette"
        (click)="close()"
        (keydown.escape)="close()"
        tabindex="-1"
        class="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-start justify-center pt-24 px-4 select-none">
        
        <div 
          (click)="$event.stopPropagation()"
          (keydown)="$event.stopPropagation()"
          tabindex="0"
          class="w-full max-w-2xl bg-[#0B0F17] border border-slate-700 rounded-xl shadow-2xl overflow-hidden flex flex-col font-mono text-xs animate-in fade-in zoom-in-95 duration-150">
          
          <!-- Search Input Header -->
          <div class="flex items-center gap-3 px-4 py-3 border-b border-slate-800 bg-[#0E1420]">
            <mat-icon class="!text-orange-400 !text-[20px] !w-5 !h-5">search</mat-icon>
            <input
              type="text"
              [value]="query()"
              (input)="onInputChange($event)"
              placeholder="Search actions, views, failure injections, scenarios... (e.g. 'storm', 'monte', 'gps')"
              class="flex-1 bg-transparent text-slate-100 placeholder-slate-500 focus:outline-none text-sm font-mono" />
            <button 
              type="button"
              (click)="close()"
              class="text-slate-400 hover:text-white px-1.5 py-0.5 rounded text-[11px] border border-slate-700">
              ESC
            </button>
          </div>

          <!-- Command Items List -->
          <div class="max-h-80 overflow-y-auto divide-y divide-slate-800/60 p-1">
            @for (cmd of filteredCommands(); track cmd.id) {
              <button
                type="button"
                (click)="execute(cmd)"
                class="w-full text-left px-3 py-2.5 hover:bg-slate-800/80 rounded cursor-pointer flex items-center justify-between transition-colors focus:bg-slate-800 focus:outline-none">
                <div class="flex items-center gap-2.5">
                  <mat-icon class="!text-[16px] !w-4 !h-4 text-orange-400">{{ cmd.icon }}</mat-icon>
                  <div>
                    <div class="text-white font-bold">{{ cmd.title }}</div>
                    <div class="text-[10px] text-slate-400">{{ cmd.subtitle }}</div>
                  </div>
                </div>
                <span class="text-[10px] text-slate-500 bg-slate-900 border border-slate-800 px-2 py-0.5 rounded">
                  {{ cmd.category }}
                </span>
              </button>
            }

            @if (filteredCommands().length === 0) {
              <div class="p-6 text-center text-slate-500">
                No matching command or simulation target found for "{{ query() }}"
              </div>
            }
          </div>

          <!-- Footer Tips -->
          <div class="px-4 py-2 bg-[#090C12] border-t border-slate-800 flex items-center justify-between text-[10px] text-slate-500">
            <span>Use ↑↓ to navigate · Enter to select</span>
            <span>AERONAUTICA AUTONOMY OS</span>
          </div>
        </div>
      </div>
    }
  `
})
export class CommandPalette {
  public sim = inject(SimulationService);
  public query = signal<string>('');

  public commands: PaletteCommand[] = [
    // Navigation Views
    { id: 'view_ops', title: 'Open Flight Operations Centre', subtitle: 'Live primary flight display & tactical map', category: 'VIEW', icon: 'flight', action: () => this.sim.activeTab.set('operations') },
    { id: 'view_ac', title: 'View Aircraft Fleet & Digital Twin', subtitle: 'Aerodynamic polars, mass/balance', category: 'VIEW', icon: 'airplanemode_active', action: () => this.sim.activeTab.set('aircraft') },
    { id: 'view_sys', title: 'Inspect Subsystems & TMR Redundancy', subtitle: 'FMS, hydraulics, electrical channels', category: 'VIEW', icon: 'account_tree', action: () => this.sim.activeTab.set('systems') },
    { id: 'view_aut', title: 'Inspect 6-Layer Autonomy Stack', subtitle: 'Decision explainer & rejected alternatives', category: 'VIEW', icon: 'psychology', action: () => this.sim.activeTab.set('autonomy') },
    { id: 'view_nav', title: 'Open 4D Navigation & Flight Planner', subtitle: 'Waypoints & alternate airports', category: 'VIEW', icon: 'explore', action: () => this.sim.activeTab.set('navigation') },
    { id: 'view_sens', title: 'Open Perception & Sensor Fusion', subtitle: 'Kalman filter covariance & raw signals', category: 'VIEW', icon: 'sensors', action: () => this.sim.activeTab.set('perception') },
    { id: 'view_wx', title: 'Open Meteorology & Weather Hazards', subtitle: 'Convective storm cells & jetstream', category: 'VIEW', icon: 'storm', action: () => this.sim.activeTab.set('weather') },
    { id: 'view_traf', title: 'Open Airspace & Traffic Separation', subtitle: 'TCAS-II conflict advisory scope', category: 'VIEW', icon: 'radar', action: () => this.sim.activeTab.set('airspace') },
    { id: 'view_dyn', title: 'Open Flight Dynamics & V-n Envelope', subtitle: 'Buffet boundaries & load factor', category: 'VIEW', icon: 'speed', action: () => this.sim.activeTab.set('flight_dynamics') },
    { id: 'view_saf', title: 'Open Safety Assurance Matrix', subtitle: 'Formal invariants & DO-178C evidence', category: 'VIEW', icon: 'verified_user', action: () => this.sim.activeTab.set('safety') },
    { id: 'view_fail', title: 'Open Failure Injection Laboratory', subtitle: 'Component degradation & recovery', category: 'VIEW', icon: 'pest_control', action: () => this.sim.activeTab.set('failures') },
    { id: 'view_mc', title: 'Open Monte Carlo Stochastic Engine', subtitle: '1,000 run statistical CDFs', category: 'VIEW', icon: 'scatter_plot', action: () => this.sim.activeTab.set('monte_carlo') },
    { id: 'view_fdr', title: 'Open Flight Data Recorder (FDR)', subtitle: 'Blackbox timeline scrubbing & CSV export', category: 'VIEW', icon: 'video_settings', action: () => this.sim.activeTab.set('fdr') },
    { id: 'view_rlab', title: 'Open R Scientific Data Laboratory', subtitle: 'R6 script generator & SQL console', category: 'VIEW', icon: 'terminal', action: () => this.sim.activeTab.set('data_lab') },
    { id: 'view_rep', title: 'Open Reports & Immutable Audit Trail', subtitle: 'Printable flight test dossier', category: 'VIEW', icon: 'description', action: () => this.sim.activeTab.set('reports') },
    { id: 'view_hlth', title: 'Open System Health & Solver Diagnostics', subtitle: '50 Hz tick stability & allocations', category: 'VIEW', icon: 'monitor_heart', action: () => this.sim.activeTab.set('health') },

    // Actions & Injections
    { id: 'act_play_pause', title: 'Toggle Play / Pause Simulation', subtitle: 'Resume or pause simulation clock', category: 'CONTROL', icon: 'play_arrow', action: () => this.sim.togglePlayPause() },
    { id: 'act_reset', title: 'Reset Active Scenario', subtitle: 'Reinitialize baseline telemetry', category: 'CONTROL', icon: 'replay', action: () => this.sim.resetSimulation() },
    { id: 'act_fail_gps', title: 'Inject GNSS Multipath / Noise Burst', subtitle: 'Trigger Layer 1 Kalman innovation test', category: 'FAULT', icon: 'sensors_off', action: () => { this.sim.injectFailure('FAIL_GPS_NOISE'); this.sim.activeTab.set('perception'); } },
    { id: 'act_fail_eng', title: 'Inject Engine 1 Flameout & Drift-Down', subtitle: 'Simulate thrust asymmetry & drift-down', category: 'FAULT', icon: 'local_fire_department', action: () => { this.sim.injectFailure('FAIL_ENG_1_FLAMEOUT'); this.sim.activeTab.set('systems'); } },
    { id: 'act_fail_wx', title: 'Inject Convective Supercell Intercept', subtitle: 'Trigger Layer 4 dynamic detour solver', category: 'FAULT', icon: 'storm', action: () => { this.sim.injectFailure('FAIL_WEATHER_SQUALL'); this.sim.activeTab.set('operations'); } },
    { id: 'act_mc_run', title: 'Execute Monte Carlo 1,000 Runs', subtitle: 'Calculate statistical safety margins', category: 'EXPERIMENT', icon: 'scatter_plot', action: () => { this.sim.activeTab.set('monte_carlo'); this.sim.runMonteCarloBatch(1000); } }
  ];

  public filteredCommands = computed(() => {
    const q = this.query().toLowerCase().trim();
    if (!q) return this.commands;
    return this.commands.filter(
      c => c.title.toLowerCase().includes(q) || c.subtitle.toLowerCase().includes(q) || c.category.toLowerCase().includes(q)
    );
  });

  public onInputChange(event: Event): void {
    const target = event.target as HTMLInputElement | null;
    if (target) {
      this.query.set(target.value);
    }
  }

  public execute(cmd: PaletteCommand): void {
    cmd.action();
    this.close();
  }

  public close(): void {
    this.sim.isCommandPaletteOpen.set(false);
    this.query.set('');
  }
}
