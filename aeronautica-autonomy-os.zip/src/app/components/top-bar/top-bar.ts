import { Component, inject, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../core/services/simulation.service';

@Component({
  selector: 'app-top-bar',
  imports: [CommonModule, MatIconModule],
  template: `
    <!-- Top Persistent Safety Boundary Banner -->
    <div class="bg-[#111622] border-b border-orange-500/30 px-4 py-1 flex items-center justify-between text-[11px] font-mono tracking-wider select-none">
      <div class="flex items-center gap-2 text-orange-400">
        <span class="inline-block w-2 h-2 rounded-full bg-orange-500 animate-pulse"></span>
        <span class="font-bold">RESEARCH SIMULATION</span>
        <span class="text-slate-500">·</span>
        <span class="text-slate-300">SYNTHETIC FLIGHT DATA</span>
        <span class="text-slate-500">·</span>
        <span class="text-amber-400 font-semibold">NOT FOR OPERATIONAL AVIATION</span>
      </div>

      <div class="flex items-center gap-4 text-slate-400">
        <div class="flex items-center gap-1.5">
          <span class="text-slate-500">SEED:</span>
          <span class="text-slate-200 font-mono">{{ sim.simSeed() }}</span>
        </div>
        <div class="flex items-center gap-1.5">
          <span class="text-slate-500">MODEL:</span>
          <span class="text-orange-300">R6-AERODYN-v4.2</span>
        </div>
        <button 
          (click)="sim.isShortcutsModalOpen.set(true)"
          class="text-slate-400 hover:text-orange-400 transition-colors flex items-center gap-1 px-1.5 py-0.5 rounded bg-slate-800/60 border border-slate-700 text-[10px]"
          title="Keyboard shortcuts">
          <mat-icon class="!text-[12px] !w-3 !h-3">keyboard</mat-icon>
          <span>SHORTCUTS</span>
        </button>
      </div>
    </div>

    <!-- Main Mission Control Header Status Bar -->
    <header class="bg-[#0B0F17] border-b border-slate-800 px-4 py-2 flex flex-wrap items-center justify-between gap-3 select-none">
      <!-- Left: Logo & Product Identity -->
      <div class="flex items-center gap-3">
        <div class="flex items-center gap-2">
          <div class="w-8 h-8 rounded bg-gradient-to-br from-orange-500 to-amber-600 flex items-center justify-center shadow-md shadow-orange-500/20 border border-orange-400/40">
            <mat-icon class="!text-white !text-[20px] !w-5 !h-5">flight_takeoff</mat-icon>
          </div>
          <div>
            <div class="flex items-center gap-2">
              <span class="text-base font-bold tracking-wider text-white font-display">AERONAUTICA</span>
              <span class="text-[10px] font-mono text-orange-400 bg-orange-950/60 border border-orange-500/30 px-1.5 py-0.2 rounded">AUTONOMY OS</span>
            </div>
            <div class="text-[9px] tracking-widest text-slate-400 uppercase font-mono">
              FLIGHT INTELLIGENCE · DIGITAL TWINS · SAFETY ASSURANCE
            </div>
          </div>
        </div>

        <div class="h-6 w-px bg-slate-800 mx-1 hidden lg:block"></div>

        <!-- Telemetry Status Ribbon -->
        <div class="hidden xl:flex items-center gap-3 text-xs font-mono">
          <div class="bg-slate-900/90 border border-slate-800 px-2.5 py-1 rounded flex items-center gap-2">
            <span class="text-slate-500 text-[10px]">SIMULATION:</span>
            <span class="font-bold flex items-center gap-1.5" [class.text-emerald-400]="sim.isRunning()" [class.text-amber-400]="!sim.isRunning()">
              <span class="w-1.5 h-1.5 rounded-full" [class.bg-emerald-500]="sim.isRunning()" [class.bg-amber-500]="!sim.isRunning()" [class.animate-ping]="sim.isRunning()"></span>
              {{ sim.isRunning() ? 'RUNNING' : 'PAUSED' }}
            </span>
          </div>

          <div class="bg-slate-900/90 border border-slate-800 px-2.5 py-1 rounded flex items-center gap-2">
            <span class="text-slate-500 text-[10px]">SCENARIO:</span>
            <span class="font-semibold text-orange-400">{{ sim.currentScenario().code }}</span>
          </div>

          <div class="bg-slate-900/90 border border-slate-800 px-2.5 py-1 rounded flex items-center gap-2">
            <span class="text-slate-500 text-[10px]">AIRCRAFT:</span>
            <span class="font-semibold text-slate-200">{{ sim.selectedAircraft().id }}</span>
          </div>

          <div class="bg-slate-900/90 border border-slate-800 px-2.5 py-1 rounded flex items-center gap-2">
            <span class="text-slate-500 text-[10px]">FLIGHT:</span>
            <span class="font-semibold text-slate-300">{{ sim.flightPlan().flight_number }}</span>
          </div>

          <div class="bg-slate-900/90 border border-slate-800 px-2.5 py-1 rounded flex items-center gap-2">
            <span class="text-slate-500 text-[10px]">SIM TIME:</span>
            <span class="font-bold text-orange-400 tabular-nums">{{ sim.formatSimTime(sim.simTimeSec()) }}</span>
          </div>

          <div class="bg-slate-900/90 border border-slate-800 px-2 py-1 rounded flex items-center gap-1">
            <span class="text-slate-500 text-[10px]">SCALE:</span>
            <div class="flex items-center gap-0.5">
              @for (scale of [1, 5, 10, 50, 100]; track scale) {
                <button 
                  (click)="sim.setTimeScale(scale)"
                  class="px-1.5 py-0.5 rounded text-[10px] font-semibold transition-colors"
                  [class.bg-orange-500]="sim.timeScale() === scale"
                  [class.text-white]="sim.timeScale() === scale"
                  [class.text-slate-400]="sim.timeScale() !== scale"
                  [class.hover:text-slate-200]="sim.timeScale() !== scale">
                  {{ scale }}×
                </button>
              }
            </div>
          </div>
        </div>
      </div>

      <!-- Right: Interactive Actions & Controls -->
      <div class="flex items-center gap-2">
        <!-- Play / Pause -->
        <button 
          (click)="sim.togglePlayPause()"
          class="flex items-center gap-1.5 px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-semibold text-white transition-colors"
          [title]="sim.isRunning() ? 'Pause Simulation (Space)' : 'Resume Simulation (Space)'">
          <mat-icon class="!text-[16px] !w-4 !h-4 text-orange-400">{{ sim.isRunning() ? 'pause' : 'play_arrow' }}</mat-icon>
          <span>{{ sim.isRunning() ? 'PAUSE' : 'RESUME' }}</span>
        </button>

        <!-- Step Tick -->
        <button 
          (click)="sim.stepTick(10)"
          class="flex items-center gap-1 px-2.5 py-1.5 rounded bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs font-medium text-slate-300 transition-colors"
          title="Step forward +10s">
          <mat-icon class="!text-[14px] !w-3.5 !h-3.5 text-slate-400">skip_next</mat-icon>
          <span>STEP</span>
        </button>

        <!-- Reset -->
        <button 
          (click)="sim.resetSimulation()"
          class="flex items-center gap-1 px-2.5 py-1.5 rounded bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs font-medium text-slate-300 transition-colors"
          title="Reset current scenario">
          <mat-icon class="!text-[14px] !w-3.5 !h-3.5 text-slate-400">replay</mat-icon>
          <span>RESET</span>
        </button>

        <!-- Inject Failure Quick Trigger -->
        <button 
          (click)="sim.isFailureModalOpen.set(true)"
          class="flex items-center gap-1.5 px-3 py-1.5 rounded bg-amber-950/40 hover:bg-amber-900/60 border border-amber-600/40 text-xs font-semibold text-amber-300 transition-colors">
          <mat-icon class="!text-[16px] !w-4 !h-4 text-amber-400">warning_amber</mat-icon>
          <span>INJECT FAILURE</span>
        </button>

        <!-- Command Palette Button -->
        <button 
          (click)="sim.isCommandPaletteOpen.set(true)"
          class="flex items-center gap-1.5 px-2.5 py-1.5 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-mono text-slate-300 transition-colors">
          <mat-icon class="!text-[15px] !w-4 !h-4 text-orange-400">search</mat-icon>
          <span class="text-[10px] text-slate-400 border border-slate-700 rounded px-1">⌘K</span>
        </button>
      </div>
    </header>

    <!-- Secondary Navigation Menu Bar (Dense Aerospace Navigation) -->
    <nav class="bg-[#0D121B] border-b border-slate-800 px-4 py-1.5 overflow-x-auto flex items-center gap-1 scrollbar-none select-none">
      @for (tab of navTabs; track tab.id) {
        <button
          (click)="sim.activeTab.set(tab.id)"
          class="flex items-center gap-1.5 px-3 py-1 rounded text-xs font-medium transition-all whitespace-nowrap"
          [class.bg-orange-500]="sim.activeTab() === tab.id"
          [class.text-white]="sim.activeTab() === tab.id"
          [class.font-semibold]="sim.activeTab() === tab.id"
          [class.shadow-sm]="sim.activeTab() === tab.id"
          [class.text-slate-400]="sim.activeTab() !== tab.id"
          [class.hover:text-slate-200]="sim.activeTab() !== tab.id"
          [class.hover:bg-slate-800/60]="sim.activeTab() !== tab.id">
          <mat-icon class="!text-[14px] !w-3.5 !h-3.5" [class.text-orange-400]="sim.activeTab() !== tab.id">{{ tab.icon }}</mat-icon>
          <span>{{ tab.label }}</span>
          @if (tab.badge) {
            <span class="text-[9px] px-1 rounded font-mono" [class.bg-orange-950]="sim.activeTab() === tab.id" [class.text-orange-200]="sim.activeTab() === tab.id" [class.bg-slate-800]="sim.activeTab() !== tab.id" [class.text-slate-400]="sim.activeTab() !== tab.id">
              {{ tab.badge }}
            </span>
          }
        </button>
      }
    </nav>
  `
})
export class TopBar {
  public sim = inject(SimulationService);

  public navTabs = [
    { id: 'operations', label: 'FLIGHT OPERATIONS', icon: 'flight', badge: 'LIVE' },
    { id: 'aircraft', label: 'AIRCRAFT & FLEET', icon: 'airplanemode_active' },
    { id: 'systems', label: 'DIGITAL TWIN & SYSTEMS', icon: 'account_tree' },
    { id: 'autonomy', label: 'AUTONOMY STACK', icon: 'psychology', badge: '6-L' },
    { id: 'navigation', label: 'NAVIGATION & MISSION', icon: 'explore' },
    { id: 'perception', label: 'PERCEPTION & SENSORS', icon: 'sensors' },
    { id: 'weather', label: 'METEOROLOGY', icon: 'storm' },
    { id: 'airspace', label: 'AIRSPACE & TRAFFIC', icon: 'radar' },
    { id: 'flight_dynamics', label: 'FLIGHT DYNAMICS', icon: 'speed' },
    { id: 'safety', label: 'SAFETY ASSURANCE', icon: 'verified_user', badge: 'DO-178C' },
    { id: 'failures', label: 'FAILURE LABORATORY', icon: 'pest_control' },
    { id: 'monte_carlo', label: 'MONTE CARLO ENGINE', icon: 'scatter_plot' },
    { id: 'fdr', label: 'FLIGHT RECORDER (FDR)', icon: 'video_settings' },
    { id: 'data_lab', label: 'R DATA LABORATORY', icon: 'terminal' },
    { id: 'reports', label: 'REPORTS & AUDIT', icon: 'description' },
    { id: 'health', label: 'SYSTEM HEALTH', icon: 'monitor_heart' }
  ];

  @HostListener('window:keydown', ['$event'])
  handleKeyboardEvent(event: KeyboardEvent) {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
      event.preventDefault();
      this.sim.isCommandPaletteOpen.update(v => !v);
      return;
    }

    if (event.key === ' ' && (event.target as HTMLElement).tagName !== 'INPUT' && (event.target as HTMLElement).tagName !== 'TEXTAREA') {
      event.preventDefault();
      this.sim.togglePlayPause();
      return;
    }

    if (event.key === 'Escape') {
      this.sim.isCommandPaletteOpen.set(false);
      this.sim.isShortcutsModalOpen.set(false);
      this.sim.isFailureModalOpen.set(false);
      return;
    }

    // Keyboard 2-key sequence handler like G O, G A, etc.
    if (event.key.toLowerCase() === 'r' && (event.ctrlKey || event.altKey)) {
      event.preventDefault();
      this.sim.resetSimulation();
    }
  }
}
