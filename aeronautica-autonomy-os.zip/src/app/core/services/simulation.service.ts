import { Injectable, signal } from '@angular/core';
import {
  AircraftConfig,
  AircraftState,
  Airport,
  AuditLogEntry,
  AutonomyDecision,
  AutonomyMode,
  FlightPlan,
  FlightScenario,
  InjectedFailure,
  MonteCarloRunConfig,
  MonteCarloSummary,
  SafetyRequirement,
  SensorChannel,
  Subsystem,
  TelemetryFrame,
  TrafficAircraft,
  WeatherCell
} from '../models/aeronautica.types';
import {
  AVAILABLE_FAILURES,
  CANDIDATE_DIVERT_WAYPOINTS_NORTH,
  DEFAULT_SCENARIOS,
  INITIAL_SENSOR_CHANNELS,
  INITIAL_SUBSYSTEMS,
  INITIAL_WAYPOINTS,
  SAFETY_REQUIREMENTS_MATRIX,
  SYNTHETIC_AIRCRAFT_FLEET,
  SYNTHETIC_AIRPORTS
} from '../data/synthetic-dataset';

@Injectable({
  providedIn: 'root'
})
export class SimulationService {
  // Current active navigation view
  public activeTab = signal<string>('operations');

  // Simulation clock & state
  public isRunning = signal<boolean>(true);
  public timeScale = signal<number>(10); // 1x, 5x, 10x, 50x, 100x
  public simTimeSec = signal<number>(38537); // e.g. 10:42:17 in seconds
  public simSeed = signal<number>(420918);

  // Selected aircraft & scenario
  public aircraftFleet = signal<AircraftConfig[]>(SYNTHETIC_AIRCRAFT_FLEET);
  public selectedAircraft = signal<AircraftConfig>(SYNTHETIC_AIRCRAFT_FLEET[0]);
  public scenarios = signal<FlightScenario[]>(DEFAULT_SCENARIOS);
  public currentScenario = signal<FlightScenario>(DEFAULT_SCENARIOS[0]);

  // Airspace & Network
  public airports = signal<Airport[]>(SYNTHETIC_AIRPORTS);
  public flightPlan = signal<FlightPlan>({
    id: 'FP_ATLAS_042',
    flight_number: 'SIM-2026-0918-001',
    aircraft_id: 'A-900X',
    origin_icao: 'EGLN',
    dest_icao: 'ENAH',
    alternate_icao: 'BIRK',
    cruise_altitude_ft: 38000,
    cruise_speed_mach: 0.78,
    planned_payload_kg: 14200,
    block_fuel_kg: 18400,
    reserve_fuel_kg: 4200,
    route: [...INITIAL_WAYPOINTS],
    candidate_divert_route: [...CANDIDATE_DIVERT_WAYPOINTS_NORTH],
    estimated_flight_time_min: 145
  });

  // Dynamic state
  public aircraftState = signal<AircraftState>({
    aircraft_id: 'A-900X',
    callsign: 'AERO-900X',
    sim_time_sec: 38537,
    timestamp_iso: '2026-09-23T10:42:17Z',
    phase: 'CRUISE',
    autonomy_mode: 'SUPERVISED_AUTONOMY',
    lat: 57.50,
    lon: -5.80,
    alt_ft: 38000,
    alt_target_ft: 38000,
    terrain_alt_ft: 420,
    height_agl_ft: 37580,
    tas_kts: 448,
    ias_kts: 242,
    gs_kts: 462,
    mach: 0.78,
    vertical_speed_fpm: 420,
    heading_deg: 274,
    track_deg: 276,
    drift_angle_deg: 2,
    pitch_deg: 2.1,
    roll_deg: 0.0,
    yaw_deg: 0.0,
    angle_of_attack_deg: 2.4,
    sideslip_beta_deg: 0.2,
    g_load: 1.01,
    lift_kn: 592.4,
    drag_kn: 34.8,
    thrust_kn: 35.1,
    weight_kn: 592.4,
    total_mass_kg: 60400,
    fuel_remaining_kg: 16950,
    fuel_pct: 68.4,
    fuel_burn_rate_kgh: 2410,
    battery_pct: 91.2,
    battery_drain_kw: 14.2,
    center_of_gravity_pct_mac: 28.4,
    distance_to_dest_nm: 342,
    distance_flown_nm: 218,
    eta_utc_string: 42100,
    active_waypoint_index: 3,
    cross_track_error_nm: 0.04,
    overall_health: 'NOMINAL',
    envelope_status: 'NOMINAL'
  });

  // Weather cells
  public weatherCells = signal<WeatherCell[]>([
    {
      id: 'WX_CELL_01',
      name: 'SQUALL LINE CHARLIE',
      lat: 59.40,
      lon: -9.80,
      radius_nm: 48,
      top_fl: 480,
      severity: 'SEVERE',
      turbulence: 'EXTREME',
      icing_index: 0.88,
      lightning_rate_per_min: 34,
      drift_speed_kts: 24,
      drift_dir_deg: 75,
      synthetic_source: 'X-BAND WEATHER RADAR DOPPLER SYNTHESIS'
    },
    {
      id: 'WX_CELL_02',
      name: 'ISOLATED CB BRAVO',
      lat: 61.80,
      lon: -18.20,
      radius_nm: 25,
      top_fl: 390,
      severity: 'MODERATE',
      turbulence: 'MODERATE',
      icing_index: 0.45,
      lightning_rate_per_min: 8,
      drift_speed_kts: 18,
      drift_dir_deg: 80,
      synthetic_source: 'SYNTHETIC GEO-SATELLITE MULTI-SPECTRAL'
    }
  ]);

  // Airspace Traffic
  public trafficList = signal<TrafficAircraft[]>([
    {
      id: 'TRF_01',
      callsign: 'NORDIC-412',
      squawk: '4217',
      category: 'HEAVY',
      lat: 58.20,
      lon: -4.10,
      alt_ft: 39000,
      tas_kts: 460,
      heading_deg: 95,
      vertical_speed_fpm: 0,
      origin: 'ENAH',
      dest: 'EGLN',
      conflict_level: 'NONE',
      horizontal_sep_nm: 44.2,
      vertical_sep_ft: 1000,
      time_to_cpa_sec: 380
    },
    {
      id: 'TRF_02',
      callsign: 'CARGO-780F',
      squawk: '6320',
      category: 'AUTONOMOUS_CARGO',
      lat: 57.85,
      lon: -6.90,
      alt_ft: 38000,
      tas_kts: 450,
      heading_deg: 185,
      vertical_speed_fpm: -300,
      origin: 'BIRK',
      dest: 'EDDB',
      conflict_level: 'ADVISORY',
      horizontal_sep_nm: 18.5,
      vertical_sep_ft: 0,
      time_to_cpa_sec: 142
    },
    {
      id: 'TRF_03',
      callsign: 'VOLT-09',
      squawk: '1200',
      category: 'REGIONAL',
      lat: 56.40,
      lon: -3.80,
      alt_ft: 22000,
      tas_kts: 290,
      heading_deg: 320,
      vertical_speed_fpm: 1200,
      origin: 'EGLN',
      dest: 'BIRK',
      conflict_level: 'NONE',
      horizontal_sep_nm: 82.0,
      vertical_sep_ft: 16000,
      time_to_cpa_sec: 840
    },
    {
      id: 'TRF_04',
      callsign: 'AERO-TEST-02',
      squawk: '7001',
      category: 'HEAVY',
      lat: 61.10,
      lon: -11.40,
      alt_ft: 41000,
      tas_kts: 480,
      heading_deg: 260,
      vertical_speed_fpm: 0,
      origin: 'EDDB',
      dest: 'KNYE',
      conflict_level: 'NONE',
      horizontal_sep_nm: 112.0,
      vertical_sep_ft: 3000,
      time_to_cpa_sec: 1200
    }
  ]);

  // Subsystems & Sensors
  public subsystems = signal<Subsystem[]>(INITIAL_SUBSYSTEMS);
  public sensorChannels = signal<SensorChannel[]>(INITIAL_SENSOR_CHANNELS);
  public injectedFailures = signal<InjectedFailure[]>(AVAILABLE_FAILURES);

  // Autonomy Stack Decisions & Trace
  public decisions = signal<AutonomyDecision[]>([
    {
      id: 'DEC_AUT_000184',
      timestamp_sim_sec: 38530,
      timestamp_iso: '2026-09-23T10:42:10Z',
      trigger_event: 'WEATHER_CELL_INTERCEPT',
      layer: 'LAYER_4_PLANNING',
      selected_action: 'PROPOSE DIVERSION NORTH VIA DEV-NORTH-ALPHA (HDG 312°)',
      action_summary: 'Lateral deviation +14° North around convective squall line Charlie with 24 NM safety clearance.',
      reason_prose: 'Synthetic Doppler Radar cell CB-92 intersects nominal flight path at 60N010W. Cloud top FL480 exceeds aircraft maximum certified altitude FL450; step climb is prohibited by aerodynamic buffet margin. Lateral detour preserves 24.2 NM buffer and preserves 48 min fuel reserve upon arrival at ENAH / alternate BIRK.',
      rejected_alternatives: [
        {
          action: 'CONTINUE NOMINAL ROUTE THROUGH CELL',
          rejection_reason: 'Severe convective turbulence (EPE > 0.65) and structural gust exceedance risk violate REQ-SAF-003.',
          violated_constraint: 'CONVECTIVE_CELL_BUFFER < 20 NM'
        },
        {
          action: 'STEP CLIMB TO FL430 OVER CELL',
          rejection_reason: 'Cell cloud top is FL480; high altitude overflight does not clear tops and reduces stall buffet margin to 0.03M.',
          violated_constraint: 'AERODYNAMIC_BUFFET_MARGIN < 0.05M'
        },
        {
          action: 'SOUTH DIVERSION VIA 55N020W',
          rejection_reason: 'Estimated fuel consumption increases by 2,840 kg; reserve at alternate BIRK drops below statutory 45-min minimum.',
          violated_constraint: 'CONTINGENCY_FUEL_FLOOR < 3,200 KG'
        }
      ],
      active_constraints: [
        'MAX_ALTITUDE: 45,000 ft',
        'MIN_WEATHER_SEPARATION: 20.0 NM',
        'BUFFET_MARGIN_MIN: 0.05 Mach',
        'MIN_RESERVE_FUEL: 3,200 kg'
      ],
      uncertainty_bounds: 'Trajectory Position Covariance: 0.18 NM · Weather Cell Growth Uncertainty: ±12% / 30min',
      requires_human_approval: true,
      approval_state: 'PENDING',
      approval_timeout_sec: 48,
      executed: false
    }
  ]);

  // Safety Requirements Matrix
  public safetyRequirements = signal<SafetyRequirement[]>(SAFETY_REQUIREMENTS_MATRIX);

  // Monte Carlo Engine State
  public monteCarloConfig = signal<MonteCarloRunConfig>({
    iterations: 1000,
    wind_shear_variance_pct: 18,
    sensor_noise_sigma: 1.2,
    traffic_density_multiplier: 1.5,
    failure_probability_pct: 3.5,
    human_response_delay_sec: 12,
    seed: 420918
  });

  public isRunningMonteCarlo = signal<boolean>(false);
  public monteCarloProgress = signal<number>(100);
  public monteCarloResults = signal<MonteCarloSummary | null>({
    run_id: 'MC-RUN-20260923-01',
    total_runs: 1000,
    completed_runs: 1000,
    arrival_success_rate_pct: 99.8,
    min_fuel_reserve_kg: 3410,
    avg_fuel_reserve_kg: 4620,
    max_fuel_reserve_kg: 5890,
    max_cross_track_deviation_nm: 1.42,
    envelope_violation_count: 0,
    diversion_count: 82,
    loss_of_separation_count: 0,
    fuel_distribution_bins: [
      { bin: '3.0-3.5t', count: 12 },
      { bin: '3.5-4.0t', count: 98 },
      { bin: '4.0-4.5t', count: 340 },
      { bin: '4.5-5.0t', count: 380 },
      { bin: '5.0-5.5t', count: 145 },
      { bin: '> 5.5t', count: 25 }
    ],
    duration_distribution_bins: [
      { bin: '135-140m', count: 85 },
      { bin: '140-145m', count: 480 },
      { bin: '145-150m', count: 320 },
      { bin: '150-155m', count: 95 },
      { bin: '> 155m', count: 20 }
    ],
    trajectory_points: []
  });

  // Flight Data Recorder (FDR) Blackbox History
  public telemetryHistory = signal<TelemetryFrame[]>([]);
  public fdrScrubIndex = signal<number>(-1); // -1 = live, >= 0 = historical playback

  // Audit Log Entries
  public auditTrail = signal<AuditLogEntry[]>([
    {
      id: 'AUD_001',
      timestamp_sim_sec: 38400,
      timestamp_iso: '2026-09-23T10:40:00Z',
      actor: 'SCENARIO_ENGINE',
      action_type: 'SIM_CONTROL',
      details: 'Scenario ATLAS-042 loaded with aircraft A-900X Stratos Twin on flight SIM-2026-0918-001.',
      scenario_seed: 420918
    },
    {
      id: 'AUD_002',
      timestamp_sim_sec: 38450,
      timestamp_iso: '2026-09-23T10:40:50Z',
      actor: 'AUTONOMY_CORE',
      action_type: 'MODE_CHANGE',
      details: 'Autonomy mode initialized to SUPERVISED_AUTONOMY with triple-redundant voting enabled.',
      previous_state: 'MANUAL_REFERENCE',
      new_state: 'SUPERVISED_AUTONOMY',
      scenario_seed: 420918
    },
    {
      id: 'AUD_003',
      timestamp_sim_sec: 38530,
      timestamp_iso: '2026-09-23T10:42:10Z',
      actor: 'AUTONOMY_CORE',
      action_type: 'ROUTE_MODIFICATION',
      details: 'Autonomous re-route proposed due to convective squall line Charlie; submitted for human oversight approval.',
      scenario_seed: 420918
    }
  ]);

  // Command Palette & UI modal states
  public isCommandPaletteOpen = signal<boolean>(false);
  public isShortcutsModalOpen = signal<boolean>(false);
  public isFailureModalOpen = signal<boolean>(false);

  // Active loop timer
  private intervalId: ReturnType<typeof setInterval> | null = null;

  constructor() {
    this.seedInitialTelemetry();
    this.startSimulationLoop();
  }

  private seedInitialTelemetry(): void {
    const history: TelemetryFrame[] = [];
    const baseTime = this.simTimeSec() - 300;
    for (let i = 0; i < 300; i += 5) {
      const t = baseTime + i;
      const progress = i / 300;
      history.push({
        sim_time_sec: t,
        lat: 55.0 + progress * 2.5,
        lon: -3.0 - progress * 2.8,
        alt_ft: 38000 + Math.sin(i * 0.1) * 20,
        tas_kts: 448 + Math.sin(i * 0.05) * 3,
        gs_kts: 462 + Math.cos(i * 0.05) * 4,
        mach: 0.78,
        vs_fpm: Math.round(Math.sin(i * 0.1) * 60),
        heading_deg: 274,
        pitch_deg: 2.1,
        roll_deg: 0.0,
        fuel_pct: 70.2 - progress * 1.8,
        battery_pct: 92.5 - progress * 1.3,
        phase: 'CRUISE',
        autonomy_mode: 'SUPERVISED_AUTONOMY',
        envelope_margin_pct: 94.2,
        sensor_health_pct: 99.2,
        active_events: i > 250 ? ['WEATHER_CELL_INTERCEPT'] : []
      });
    }
    this.telemetryHistory.set(history);
  }

  private startSimulationLoop(): void {
    if (this.intervalId) clearInterval(this.intervalId);

    // 100ms real-time step for smooth UI updates
    this.intervalId = setInterval(() => {
      if (!this.isRunning()) return;

      const dt = 0.1 * this.timeScale(); // simulated seconds elapsed in this tick
      this.tickSimulation(dt);
    }, 100);
  }

  private tickSimulation(dt_sec: number): void {
    const currentSimTime = this.simTimeSec() + dt_sec;
    this.simTimeSec.set(currentSimTime);

    const s = this.aircraftState();
    const ac = this.selectedAircraft();

    // Flight physics calculations (3DOF dynamic equations)
    // Altitude standard atmosphere density rho(h)
    const h_m = (s.alt_ft * 0.3048);
    const T_kelvin = Math.max(216.65, 288.15 - 0.0065 * h_m);
    const p_pa = 101325 * Math.pow(T_kelvin / 288.15, 5.25588);
    const rho = p_pa / (287.058 * T_kelvin); // kg/m^3

    // Airspeed conversions
    const V_ms = s.tas_kts * 0.514444;
    const speed_of_sound = Math.sqrt(1.4 * 287.058 * T_kelvin);
    const mach = V_ms / speed_of_sound;
    const q_pa = 0.5 * rho * V_ms * V_ms; // Dynamic pressure

    // Lift & Drag
    const S = ac.specs.wing_area_m2;
    const mass_kg = s.total_mass_kg;
    const weight_N = mass_kg * 9.80665;
    const CL = weight_N / Math.max(1, q_pa * S);
    const k_drag = 1.0 / (Math.PI * ac.specs.aspect_ratio * ac.specs.oswald_e);
    const CD = ac.specs.cd0 + k_drag * CL * CL;
    const drag_N = CD * q_pa * S;
    const thrust_N = drag_N; // Cruise steady state approximation

    // Fuel burn rate TSFC
    const fuel_burn_kgh = (thrust_N / 1000) * ac.specs.tsfc_kg_per_kn_hr * ac.specs.engines_count;
    const fuel_burned_kg = (fuel_burn_kgh / 3600) * dt_sec;
    const new_fuel_kg = Math.max(0, s.fuel_remaining_kg - fuel_burned_kg);
    const new_fuel_pct = (new_fuel_kg / ac.specs.fuel_capacity_kg) * 100;
    const new_mass_kg = ac.specs.oew_kg + 14200 + new_fuel_kg;

    // Movement along track
    const dist_nm_travelled = (s.gs_kts / 3600) * dt_sec;
    const heading_rad = (s.heading_deg * Math.PI) / 180;
    const dLat = (dist_nm_travelled * Math.cos(heading_rad)) / 60;
    const dLon = (dist_nm_travelled * Math.sin(heading_rad)) / (60 * Math.cos((s.lat * Math.PI) / 180));

    let new_lat = s.lat + dLat;
    let new_lon = s.lon + dLon;

    // Boundary constraints for synthetic demo corridor
    if (new_lon < -25) new_lon = -5.80; // loop back seamlessly for continuous simulation
    if (new_lat > 65) new_lat = 57.50;

    // Distance to destination (ENAH lat 62.195, lon -7.072)
    const dist_to_dest = this.calculateGreatCircleNm(new_lat, new_lon, 62.195, -7.072);

    // Minor atmospheric turbulence perturbation
    const pitch_delta = Math.sin(currentSimTime * 0.5) * 0.15;
    const roll_delta = Math.sin(currentSimTime * 0.3) * 0.2;
    const vs_delta = Math.round(Math.sin(currentSimTime * 0.4) * 40);

    // Format ISO string
    const dateObj = new Date(1774350000000 + (currentSimTime - 38400) * 1000);
    const timeIso = dateObj.toISOString();

    const updatedState: AircraftState = {
      ...s,
      sim_time_sec: currentSimTime,
      timestamp_iso: timeIso,
      lat: Number(new_lat.toFixed(4)),
      lon: Number(new_lon.toFixed(4)),
      mach: Number(mach.toFixed(2)),
      vertical_speed_fpm: 0 + vs_delta,
      pitch_deg: Number((2.1 + pitch_delta).toFixed(2)),
      roll_deg: Number(roll_delta.toFixed(2)),
      total_mass_kg: Math.round(new_mass_kg),
      fuel_remaining_kg: Math.round(new_fuel_kg),
      fuel_pct: Number(new_fuel_pct.toFixed(1)),
      fuel_burn_rate_kgh: Math.round(fuel_burn_kgh),
      battery_pct: Number(Math.max(10, s.battery_pct - (dt_sec * 0.001)).toFixed(1)),
      lift_kn: Number((weight_N / 1000).toFixed(1)),
      drag_kn: Number((drag_N / 1000).toFixed(1)),
      thrust_kn: Number((thrust_N / 1000).toFixed(1)),
      distance_to_dest_nm: Math.round(dist_to_dest),
      distance_flown_nm: Math.round(s.distance_flown_nm + dist_nm_travelled)
    };

    this.aircraftState.set(updatedState);

    // Push to FDR history every 2 seconds of sim time
    if (Math.floor(currentSimTime) % 2 === 0) {
      const frame: TelemetryFrame = {
        sim_time_sec: currentSimTime,
        lat: updatedState.lat,
        lon: updatedState.lon,
        alt_ft: updatedState.alt_ft,
        tas_kts: updatedState.tas_kts,
        gs_kts: updatedState.gs_kts,
        mach: updatedState.mach,
        vs_fpm: updatedState.vertical_speed_fpm,
        heading_deg: updatedState.heading_deg,
        pitch_deg: updatedState.pitch_deg,
        roll_deg: updatedState.roll_deg,
        fuel_pct: updatedState.fuel_pct,
        battery_pct: updatedState.battery_pct,
        phase: updatedState.phase,
        autonomy_mode: updatedState.autonomy_mode,
        envelope_margin_pct: 94.5,
        sensor_health_pct: updatedState.overall_health === 'NOMINAL' ? 99.4 : 78.5,
        active_events: this.decisions().filter(d => d.approval_state === 'PENDING').map(d => d.trigger_event)
      };

      this.telemetryHistory.update(hist => {
        const next = [...hist, frame];
        if (next.length > 600) next.shift(); // keep last 600 points
        return next;
      });
    }

    // Dynamic timeout decrement for pending autonomy decisions
    this.decisions.update(decs =>
      decs.map(dec => {
        if (dec.approval_state === 'PENDING' && dec.approval_timeout_sec > 0) {
          const nextSec = Math.max(0, dec.approval_timeout_sec - dt_sec);
          if (nextSec === 0) {
            return {
              ...dec,
              approval_state: 'EXPIRED',
              action_summary: 'DECISION EXPIRED: Auto-transitioned to safe holding pattern.'
            };
          }
          return { ...dec, approval_timeout_sec: nextSec };
        }
        return dec;
      })
    );
  }

  // Great circle distance in nautical miles
  public calculateGreatCircleNm(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 3440.065; // Earth radius in NM
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) *
        Math.cos((lat2 * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  // Simulation Controls
  public togglePlayPause(): void {
    this.isRunning.update(r => !r);
    this.logAudit(
      'HUMAN_OPERATOR',
      'SIM_CONTROL',
      `Simulation ${this.isRunning() ? 'RESUMED' : 'PAUSED'} at sim time ${this.simTimeSec()}s`
    );
  }

  public setTimeScale(scale: number): void {
    this.timeScale.set(scale);
    this.logAudit('HUMAN_OPERATOR', 'SIM_CONTROL', `Simulation time scale adjusted to ${scale}×`);
  }

  public stepTick(seconds = 10): void {
    this.tickSimulation(seconds);
    this.logAudit('HUMAN_OPERATOR', 'SIM_CONTROL', `Single step manual tick +${seconds}s executed`);
  }

  public resetSimulation(): void {
    this.loadScenario(this.currentScenario());
    this.logAudit('HUMAN_OPERATOR', 'SIM_CONTROL', `Simulation reset to scenario ${this.currentScenario().code} baseline.`);
  }

  public loadScenario(scenario: FlightScenario): void {
    this.currentScenario.set(scenario);
    const ac = this.aircraftFleet().find(a => a.id === scenario.aircraft_id) || this.aircraftFleet()[0];
    this.selectedAircraft.set(ac);

    this.simTimeSec.set(38537);
    this.aircraftState.update(s => ({
      ...s,
      aircraft_id: ac.id,
      callsign: `AERO-${ac.code}`,
      phase: scenario.initial_phase,
      autonomy_mode: scenario.autonomy_mode,
      alt_ft: scenario.initial_alt_ft,
      mach: scenario.initial_speed_mach,
      fuel_pct: scenario.initial_fuel_pct,
      heading_deg: 274,
      overall_health: 'NOMINAL',
      envelope_status: 'NOMINAL'
    }));

    // Reset subsystems and sensor states
    this.subsystems.set(INITIAL_SUBSYSTEMS);
    this.sensorChannels.set(INITIAL_SENSOR_CHANNELS);
    this.injectedFailures.update(fails => fails.map(f => ({ ...f, is_active: false })));

    // Reconfigure decisions based on scenario
    if (scenario.id === 'SCEN_ATLAS_042') {
      this.decisions.set([
        {
          id: 'DEC_AUT_000184',
          timestamp_sim_sec: 38530,
          timestamp_iso: '2026-09-23T10:42:10Z',
          trigger_event: 'WEATHER_CELL_INTERCEPT',
          layer: 'LAYER_4_PLANNING',
          selected_action: 'PROPOSE DIVERSION NORTH VIA DEV-NORTH-ALPHA (HDG 312°)',
          action_summary: 'Lateral deviation +14° North around convective squall line Charlie with 24 NM safety clearance.',
          reason_prose: 'Synthetic Doppler Radar cell CB-92 intersects nominal flight path. Cloud top FL480 exceeds aircraft ceiling. Lateral detour preserves 24.2 NM buffer and preserves 48 min fuel reserve.',
          rejected_alternatives: [
            {
              action: 'CONTINUE NOMINAL ROUTE',
              rejection_reason: 'Severe convective turbulence and structural gust exceedance violate REQ-SAF-003.',
              violated_constraint: 'CONVECTIVE_CELL_BUFFER < 20 NM'
            },
            {
              action: 'STEP CLIMB TO FL430',
              rejection_reason: 'Cell cloud top is FL480; reduces stall buffet margin to 0.03M.',
              violated_constraint: 'AERODYNAMIC_BUFFET_MARGIN < 0.05M'
            }
          ],
          active_constraints: ['MAX_ALTITUDE: 45,000 ft', 'MIN_WEATHER_SEPARATION: 20.0 NM', 'BUFFET_MARGIN_MIN: 0.05M'],
          uncertainty_bounds: 'Pos Covariance: 0.18 NM · WX Growth: ±12%',
          requires_human_approval: true,
          approval_state: 'PENDING',
          approval_timeout_sec: 50,
          executed: false
        }
      ]);
    } else if (scenario.id === 'SCEN_ORBIT_017') {
      this.injectFailure('FAIL_GPS_NOISE');
    }

    this.seedInitialTelemetry();
    this.logAudit('SCENARIO_ENGINE', 'SIM_CONTROL', `Scenario ${scenario.code}: ${scenario.title} initialized successfully.`);
  }

  // Autonomy Human Supervision actions
  public approveDecision(decisionId: string): void {
    this.decisions.update(decs =>
      decs.map(d => {
        if (d.id === decisionId) {
          // Alter flight plan route to candidate route
          const fp = this.flightPlan();
          if (fp.candidate_divert_route) {
            this.flightPlan.update(plan => ({
              ...plan,
              route: [...plan.candidate_divert_route!]
            }));
            this.aircraftState.update(s => ({
              ...s,
              heading_deg: 312,
              track_deg: 314
            }));
          }
          return {
            ...d,
            approval_state: 'APPROVED',
            executed: true,
            operator_notes: 'Approved by Flight Director. Executed autonomous northern diversion waypoint insertion.'
          };
        }
        return d;
      })
    );

    this.logAudit(
      'HUMAN_OPERATOR',
      'HUMAN_APPROVAL',
      `Decision ${decisionId} APPROVED. Aircraft heading re-vectored to 312° via DEV-NORTH-ALPHA.`
    );
  }

  public rejectDecision(decisionId: string, reason = 'Operator command override to remain on clearance.'): void {
    this.decisions.update(decs =>
      decs.map(d => {
        if (d.id === decisionId) {
          return {
            ...d,
            approval_state: 'REJECTED',
            executed: false,
            operator_notes: `Rejected by Operator: ${reason}`
          };
        }
        return d;
      })
    );

    this.logAudit('HUMAN_OPERATOR', 'HUMAN_APPROVAL', `Decision ${decisionId} REJECTED by operator.`);
  }

  public setAutonomyMode(mode: AutonomyMode): void {
    const prev = this.aircraftState().autonomy_mode;
    this.aircraftState.update(s => ({ ...s, autonomy_mode: mode }));
    this.logAudit(
      'HUMAN_OPERATOR',
      'MODE_CHANGE',
      `Autonomy mode changed from ${prev} to ${mode}`,
      prev,
      mode
    );
  }

  // Failure Injection Engine
  public injectFailure(failureId: string): void {
    const fail = this.injectedFailures().find(f => f.id === failureId);
    if (!fail) return;

    this.injectedFailures.update(fails =>
      fails.map(f => (f.id === failureId ? { ...f, is_active: true, inject_timestamp_sec: this.simTimeSec() } : f))
    );

    // Propagate failure through subsystems and sensors
    if (failureId === 'FAIL_GPS_NOISE') {
      this.sensorChannels.update(chans =>
        chans.map(c =>
          c.id === 'SENS_GPS_B'
            ? { ...c, status: 'DEGRADED', is_spoofed: true, noise_sigma: 8.5, confidence_pct: 42.0 }
            : c
        )
      );
      this.subsystems.update(subs =>
        subs.map(s =>
          s.id === 'SYS_NAV'
            ? {
                ...s,
                status: 'DEGRADED',
                health_pct: 74,
                active_failure: 'GNSS B Spoofing/Noise Delta Exceedance'
              }
            : s
        )
      );
      this.decisions.update(decs => [
        {
          id: `DEC_FAIL_${Date.now()}`,
          timestamp_sim_sec: this.simTimeSec(),
          timestamp_iso: new Date().toISOString(),
          trigger_event: 'SENSOR_DISAGREEMENT',
          layer: 'LAYER_1_ESTIMATION',
          selected_action: 'ISOLATE GNSS CHANNEL B · ENGAGE DUAL IMU/GNSS A VOTING FILTER',
          action_summary: 'Sensor Fusion Layer 1 isolated Channel B receiver due to 3.8-sigma pseudo-range discrepancy.',
          reason_prose: 'GNSS receiver B indicated 3.8 NM lateral jump in 1.2s while IMU A/B/C consensus remained nominal at 0.04°/hr drift. Kalman innovation residual test rejected GNSS B.',
          rejected_alternatives: [
            {
              action: 'ACCEPT AVERAGED GNSS POSITION',
              rejection_reason: 'Corrupts fused state estimation with spoofed offset.',
              violated_constraint: 'SENSOR_INNOVATION_THRESHOLD > 3.0-sigma'
            }
          ],
          active_constraints: ['TMR_VOTING_CONSENSUS: 2/3 REQUIRED', 'MAX_POS_UNCERTAINTY: 0.5 NM'],
          uncertainty_bounds: 'Fused Pos Uncertainty: 0.14 NM',
          requires_human_approval: false,
          approval_state: 'APPROVED',
          approval_timeout_sec: 0,
          executed: true
        },
        ...decs
      ]);
    } else if (failureId === 'FAIL_ENG_1_FLAMEOUT') {
      this.subsystems.update(subs =>
        subs.map(s =>
          s.id === 'SYS_PROP_L'
            ? {
                ...s,
                status: 'FAILED',
                health_pct: 0,
                operating_value: 'N1 0.0% / EGT 210°C / Flameout',
                active_failure: 'Engine 1 Core Flameout'
              }
            : s
        )
      );
      this.aircraftState.update(s => ({
        ...s,
        overall_health: 'CAUTION',
        vertical_speed_fpm: -680,
        fuel_burn_rate_kgh: Math.round(s.fuel_burn_rate_kgh * 0.55)
      }));
    } else if (failureId === 'FAIL_WEATHER_SQUALL') {
      this.weatherCells.update(cells => [
        ...cells,
        {
          id: `WX_${Date.now()}`,
          name: 'EXPLOSIVE CONVECTIVE SUPERCELL',
          lat: 58.6,
          lon: -7.2,
          radius_nm: 35,
          top_fl: 510,
          severity: 'SEVERE',
          turbulence: 'EXTREME',
          icing_index: 0.95,
          lightning_rate_per_min: 48,
          drift_speed_kts: 30,
          drift_dir_deg: 90,
          synthetic_source: 'SYNTHETIC X-BAND DOPPLER'
        }
      ]);
    }

    this.logAudit('FAILURE_INJECTOR', 'FAILURE_INJECTION', `Failure '${fail.name}' injected into ${fail.target_subsystem}`);
  }

  public clearFailure(failureId: string): void {
    this.injectedFailures.update(fails =>
      fails.map(f => (f.id === failureId ? { ...f, is_active: false } : f))
    );
    this.subsystems.set(INITIAL_SUBSYSTEMS);
    this.sensorChannels.set(INITIAL_SENSOR_CHANNELS);
    this.aircraftState.update(s => ({ ...s, overall_health: 'NOMINAL' }));
    this.logAudit('HUMAN_OPERATOR', 'FAILURE_INJECTION', `Failure '${failureId}' cleared. Subsystems restored to NOMINAL.`);
  }

  // Stochastic Monte Carlo Engine execution
  public runMonteCarloBatch(iterations: 10 | 100 | 1000 | 10000 = 1000): void {
    this.isRunningMonteCarlo.set(true);
    this.monteCarloProgress.set(10);

    setTimeout(() => {
      this.monteCarloProgress.set(45);
      setTimeout(() => {
        this.monteCarloProgress.set(85);
        setTimeout(() => {
          // Generate realistic statistical distribution
          const avgFuel = 4580 + (Math.random() * 200 - 100);
          const minFuel = 3380 + (Math.random() * 150 - 75);
          const maxFuel = 5820 + (Math.random() * 200 - 100);
          const successRate = iterations > 1000 ? 99.85 : 99.9;
          const diversions = Math.round(iterations * 0.08);

          this.monteCarloResults.set({
            run_id: `MC-${Date.now()}`,
            total_runs: iterations,
            completed_runs: iterations,
            arrival_success_rate_pct: successRate,
            min_fuel_reserve_kg: Math.round(minFuel),
            avg_fuel_reserve_kg: Math.round(avgFuel),
            max_fuel_reserve_kg: Math.round(maxFuel),
            max_cross_track_deviation_nm: 1.38,
            envelope_violation_count: 0,
            diversion_count: diversions,
            loss_of_separation_count: 0,
            fuel_distribution_bins: [
              { bin: '3.0-3.5t', count: Math.round(iterations * 0.015) },
              { bin: '3.5-4.0t', count: Math.round(iterations * 0.10) },
              { bin: '4.0-4.5t', count: Math.round(iterations * 0.34) },
              { bin: '4.5-5.0t', count: Math.round(iterations * 0.38) },
              { bin: '5.0-5.5t', count: Math.round(iterations * 0.14) },
              { bin: '> 5.5t', count: Math.round(iterations * 0.025) }
            ],
            duration_distribution_bins: [
              { bin: '135-140m', count: Math.round(iterations * 0.08) },
              { bin: '140-145m', count: Math.round(iterations * 0.48) },
              { bin: '145-150m', count: Math.round(iterations * 0.32) },
              { bin: '150-155m', count: Math.round(iterations * 0.09) },
              { bin: '> 155m', count: Math.round(iterations * 0.03) }
            ],
            trajectory_points: []
          });

          this.isRunningMonteCarlo.set(false);
          this.monteCarloProgress.set(100);

          this.logAudit(
            'HUMAN_OPERATOR',
            'EXPERIMENT_EXEC',
            `Monte Carlo stochastic batch completed: ${iterations} iterations with 0 safety violations.`
          );
        }, 300);
      }, 300);
    }, 300);
  }

  // Audit Logger
  public logAudit(
    actor: AuditLogEntry['actor'],
    action_type: AuditLogEntry['action_type'],
    details: string,
    prev?: string,
    next?: string
  ): void {
    const entry: AuditLogEntry = {
      id: `AUD_${Date.now()}`,
      timestamp_sim_sec: this.simTimeSec(),
      timestamp_iso: new Date().toISOString(),
      actor,
      action_type,
      details,
      previous_state: prev,
      new_state: next,
      scenario_seed: this.simSeed()
    };
    this.auditTrail.update(trail => [entry, ...trail].slice(0, 200));
  }

  // Format time helpers
  public formatSimTime(seconds: number): string {
    const total = Math.floor(seconds);
    const hrs = Math.floor(total / 3600) % 24;
    const mins = Math.floor((total % 3600) / 60);
    const secs = total % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }

  // Export R Script code
  public generateRScript(): string {
    const s = this.aircraftState();
    const ac = this.selectedAircraft();
    return `# ==============================================================================
# AERONAUTICA AUTONOMY OS — REPRODUCIBLE R SIMULATION MODEL
# Flight Intelligence, Digital Twins & Safety Assurance
# Scenario: ${this.currentScenario().code} | Aircraft: ${ac.id} (${ac.name})
# Timestamp: ${new Date().toISOString()} | Deterministic Seed: ${this.simSeed()}
# NOTE: RESEARCH SIMULATION · SYNTHETIC FLIGHT DATA · NOT FOR OPERATIONAL AVIATION
# ==============================================================================

library(R6)
library(data.table)
library(dplyr)
library(ggplot2)
library(sf)

# 1. AIRCRAFT DIGITAL TWIN DEFINITION (R6 Class)
AircraftTwin <- R6Class("AircraftTwin",
  public = list(
    id = "${ac.id}",
    mtow_kg = ${ac.specs.mtow_kg},
    oew_kg = ${ac.specs.oew_kg},
    wing_area_m2 = ${ac.specs.wing_area_m2},
    aspect_ratio = ${ac.specs.aspect_ratio},
    cd0 = ${ac.specs.cd0},
    oswald_e = ${ac.specs.oswald_e},
    cruise_mach = ${ac.specs.cruise_mach},
    
    initialize = function() {
      cat("[AERONAUTICA R] Initialized Digital Twin:", self$id, "\\n")
    },
    
    compute_aerodynamics = function(altitude_ft, tas_kts, mass_kg) {
      # Standard Atmosphere Density
      h_m <- altitude_ft * 0.3048
      T_k <- max(216.65, 288.15 - 0.0065 * h_m)
      p_pa <- 101325 * (T_k / 288.15)^5.25588
      rho <- p_pa / (287.058 * T_k)
      
      V_ms <- tas_kts * 0.514444
      q_pa <- 0.5 * rho * V_ms^2
      
      weight_N <- mass_kg * 9.80665
      CL <- weight_N / (q_pa * self$wing_area_m2)
      k_induced <- 1.0 / (pi * self$aspect_ratio * self$oswald_e)
      CD <- self$cd0 + k_induced * CL^2
      drag_N <- CD * q_pa * self$wing_area_m2
      
      return(data.table(
        altitude_ft = altitude_ft,
        rho_kg_m3 = rho,
        CL = CL,
        CD = CD,
        drag_kN = drag_N / 1000,
        thrust_req_kN = drag_N / 1000
      ))
    }
  )
)

# 2. RUN FLIGHT DYNAMICS ODE STEP
twin <- AircraftTwin$new()
aero_state <- twin$compute_aerodynamics(
  altitude_ft = ${s.alt_ft},
  tas_kts = ${s.tas_kts},
  mass_kg = ${s.total_mass_kg}
)
print(aero_state)

# 3. SAFETY ASSURANCE VERIFICATION SUMMARY
# SIMULATION RESULT · NOT A CERTIFICATION CLAIM
cat("\\n=======================================================\\n")
cat("SAFETY VERIFICATION STATUS: PASSED SIMULATION INVARIANTS\\n")
cat("Flight Envelope Margin: NOMINAL\\n")
cat("Minimum Fuel Floor: ${this.monteCarloResults()?.min_fuel_reserve_kg || 3410} kg\\n")
cat("=======================================================\\n")
`;
  }
}
