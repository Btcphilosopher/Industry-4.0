export type FlightPhase =
  | 'PARKED'
  | 'PUSHBACK'
  | 'TAXI'
  | 'TAKEOFF_ROLL'
  | 'ROTATION'
  | 'CLIMB'
  | 'CRUISE'
  | 'DESCENT'
  | 'APPROACH'
  | 'LANDING'
  | 'TAXI_IN'
  | 'SHUTDOWN';

export type AutonomyMode =
  | 'MANUAL_REFERENCE'
  | 'AUTOMATION_ASSIST'
  | 'SUPERVISED_AUTONOMY'
  | 'HIGH_AUTOMATION_RESEARCH'
  | 'EMERGENCY_SIMULATION';

export type SystemStatus = 'NOMINAL' | 'DEGRADED' | 'CAUTION' | 'CRITICAL' | 'FAILED' | 'OFFLINE';

export type ApprovalState = 'PENDING' | 'APPROVED' | 'REJECTED' | 'EXPIRED' | 'OVERRIDDEN';

export interface AircraftConfig {
  id: string;
  name: string;
  code: string;
  category: 'LONG_RANGE_RESEARCH' | 'REGIONAL_AUTONOMOUS' | 'ELECTRIC_VTOL_CTOL' | 'HEAVY_CARGO' | 'UNMANNED_TECH_DEMO';
  description: string;
  specs: {
    mtow_kg: number;
    oew_kg: number;
    max_payload_kg: number;
    wingspan_m: number;
    wing_area_m2: number;
    cd0: number; // zero-lift drag coefficient
    oswald_e: number; // Oswald efficiency
    aspect_ratio: number;
    cl_max: number;
    cl_alpha: number; // per rad
    max_altitude_ft: number;
    cruise_mach: number;
    mmo: number;
    vmo_kts: number;
    stall_speed_kts: number;
    max_climb_rate_fpm: number;
    max_descent_rate_fpm: number;
    max_bank_angle_deg: number;
    g_limit_pos: number;
    g_limit_neg: number;
    engines_count: number;
    engine_type: 'TURBOFAN_HIGH_BYPASS' | 'HYBRID_TURBOPROP' | 'ELECTRIC_DISTRIBUTED' | 'GEARED_TURBOFAN';
    max_thrust_kn_per_eng: number;
    tsfc_kg_per_kn_hr: number;
    fuel_capacity_kg: number;
    battery_capacity_kwh: number;
    min_runway_length_m: number;
    redundancy_channels: number;
  };
  imagePath?: string;
}

export interface AircraftState {
  aircraft_id: string;
  callsign: string;
  sim_time_sec: number;
  timestamp_iso: string;
  phase: FlightPhase;
  autonomy_mode: AutonomyMode;
  
  // Position & Altitude
  lat: number;
  lon: number;
  alt_ft: number;
  alt_target_ft: number;
  terrain_alt_ft: number;
  height_agl_ft: number;
  
  // Velocities & Aerodynamics
  tas_kts: number;
  ias_kts: number;
  gs_kts: number;
  mach: number;
  vertical_speed_fpm: number;
  heading_deg: number;
  track_deg: number;
  drift_angle_deg: number;
  pitch_deg: number;
  roll_deg: number;
  yaw_deg: number;
  angle_of_attack_deg: number;
  sideslip_beta_deg: number;
  g_load: number;
  
  // Forces (kN)
  lift_kn: number;
  drag_kn: number;
  thrust_kn: number;
  weight_kn: number;
  
  // Energy & Weight
  total_mass_kg: number;
  fuel_remaining_kg: number;
  fuel_pct: number;
  fuel_burn_rate_kgh: number;
  battery_pct: number;
  battery_drain_kw: number;
  center_of_gravity_pct_mac: number;
  
  // Distance & Waypoints
  distance_to_dest_nm: number;
  distance_flown_nm: number;
  eta_utc_string: number;
  active_waypoint_index: number;
  cross_track_error_nm: number;
  
  // Health
  overall_health: SystemStatus;
  envelope_status: 'NOMINAL' | 'CAUTION' | 'LIMIT' | 'VIOLATION';
}

export interface Waypoint {
  id: string;
  name: string;
  lat: number;
  lon: number;
  alt_restriction_ft: number;
  speed_restriction_kts: number;
  is_flyover: boolean;
  type: 'DEPARTURE' | 'ENROUTE' | 'WAYPOINT' | 'ARRIVAL' | 'INITIAL_APPROACH' | 'MISSED_APPROACH' | 'HOLDING';
}

export interface Airport {
  id: string;
  icao: string;
  name: string;
  country: string;
  lat: number;
  lon: number;
  elevation_ft: number;
  runways: {
    id: string;
    heading_deg: number;
    length_m: number;
    width_m: number;
    surface: 'ASPHALT' | 'CONCRETE';
    ils_frequency?: string;
    status: 'OPEN' | 'CLOSED_MAINTENANCE' | 'CROSSWIND_LIMIT' | 'EMERGENCY_ONLY';
  }[];
  metar: {
    raw: string;
    wind_dir_deg: number;
    wind_spd_kts: number;
    vis_km: number;
    temp_c: number;
    qnh_hpa: number;
    clouds: string;
  };
  is_synthetic: boolean;
  diversion_suitability: 'PRIMARY' | 'SUITABLE' | 'RESTRICTED' | 'UNAVAILABLE';
}

export interface FlightPlan {
  id: string;
  flight_number: string;
  aircraft_id: string;
  origin_icao: string;
  dest_icao: string;
  alternate_icao: string;
  cruise_altitude_ft: number;
  cruise_speed_mach: number;
  planned_payload_kg: number;
  block_fuel_kg: number;
  reserve_fuel_kg: number;
  route: Waypoint[];
  candidate_divert_route?: Waypoint[];
  estimated_flight_time_min: number;
}

export interface WeatherCell {
  id: string;
  name: string;
  lat: number;
  lon: number;
  radius_nm: number;
  top_fl: number;
  severity: 'LIGHT' | 'MODERATE' | 'HIGH' | 'SEVERE';
  turbulence: 'LIGHT' | 'MODERATE' | 'SEVERE' | 'EXTREME';
  icing_index: number; // 0-1
  lightning_rate_per_min: number;
  drift_speed_kts: number;
  drift_dir_deg: number;
  synthetic_source: string;
}

export interface TrafficAircraft {
  id: string;
  callsign: string;
  squawk: string;
  category: 'HEAVY' | 'MEDIUM' | 'REGIONAL' | 'AUTONOMOUS_CARGO';
  lat: number;
  lon: number;
  alt_ft: number;
  tas_kts: number;
  heading_deg: number;
  vertical_speed_fpm: number;
  origin: string;
  dest: string;
  conflict_level: 'NONE' | 'ADVISORY' | 'CAUTION' | 'RESOLUTION_ADVISORY';
  horizontal_sep_nm: number;
  vertical_sep_ft: number;
  time_to_cpa_sec: number;
}

export interface SensorChannel {
  id: string;
  name: string;
  type: 'IMU' | 'GNSS' | 'PITOT_STATIC' | 'RADAR_ALTIMETER' | 'WEATHER_RADAR' | 'AIRSPACE_LIDAR' | 'EO_CAMERA';
  channel: 'A' | 'B' | 'C';
  status: SystemStatus;
  noise_sigma: number;
  drift_rate_per_hr: number;
  bias: number;
  latency_ms: number;
  confidence_pct: number;
  is_failed: boolean;
  is_spoofed: boolean;
  value_raw: number;
  value_filtered: number;
  unit: string;
}

export interface Subsystem {
  id: string;
  name: string;
  category: 'AVIONICS' | 'PROPULSION' | 'ELECTRICAL' | 'HYDRAULICS' | 'FLIGHT_CONTROLS' | 'ENVIRONMENTAL' | 'SENSORS';
  status: SystemStatus;
  health_pct: number;
  redundancy_config: 'TRIPLE_TMR' | 'DUAL_FAIL_PASSIVE' | 'HOT_STANDBY' | 'INDEPENDENT';
  operating_value: string;
  nominal_range: string;
  active_failure?: string;
  channel_states: {
    channel_a: SystemStatus;
    channel_b: SystemStatus;
    channel_c?: SystemStatus;
  };
}

export interface AutonomyDecision {
  id: string;
  timestamp_sim_sec: number;
  timestamp_iso: string;
  trigger_event: string;
  layer: 'LAYER_1_ESTIMATION' | 'LAYER_2_SITUATION' | 'LAYER_3_CONSTRAINTS' | 'LAYER_4_PLANNING' | 'LAYER_5_EXPLAINER' | 'LAYER_6_SUPERVISION';
  selected_action: string;
  action_summary: string;
  reason_prose: string;
  rejected_alternatives: {
    action: string;
    rejection_reason: string;
    violated_constraint: string;
  }[];
  active_constraints: string[];
  uncertainty_bounds: string;
  requires_human_approval: boolean;
  approval_state: ApprovalState;
  approval_timeout_sec: number;
  operator_notes?: string;
  executed: boolean;
}

export interface SafetyRequirement {
  id: string;
  title: string;
  category: 'AIRWORTHINESS' | 'FLIGHT_ENVELOPE' | 'SITUATION_AWARENESS' | 'CONTINGENCY_FAILOVER' | 'HUMAN_SUPERVISION';
  description: string;
  target_subsystem: string;
  verification_method: 'SIMULATION_MONTE_CARLO' | 'FAULT_INJECTION' | 'FORMAL_INVARIANT' | 'FLIGHT_TEST_REPLAY';
  test_case_id: string;
  status: 'PASSED_SIMULATION' | 'CAUTION' | 'BLOCKED' | 'PENDING';
  evidence_summary: string;
  coverage_pct: number;
  reviewer: string;
  last_evaluated: string;
}

export interface InjectedFailure {
  id: string;
  name: string;
  category: 'SENSOR' | 'PROPULSION' | 'ENVIRONMENT' | 'TRAFFIC' | 'SYSTEM' | 'COMMUNICATION';
  description: string;
  severity: 'MINOR' | 'MAJOR' | 'HAZARDOUS' | 'CATASTROPHIC_SIM';
  target_subsystem: string;
  is_active: boolean;
  inject_timestamp_sec?: number;
  recovery_action: string;
}

export interface MonteCarloRunConfig {
  iterations: 10 | 100 | 1000 | 10000;
  wind_shear_variance_pct: number;
  sensor_noise_sigma: number;
  traffic_density_multiplier: number;
  failure_probability_pct: number;
  human_response_delay_sec: number;
  seed: number;
}

export interface MonteCarloSummary {
  run_id: string;
  total_runs: number;
  completed_runs: number;
  arrival_success_rate_pct: number;
  min_fuel_reserve_kg: number;
  avg_fuel_reserve_kg: number;
  max_fuel_reserve_kg: number;
  max_cross_track_deviation_nm: number;
  envelope_violation_count: number;
  diversion_count: number;
  loss_of_separation_count: number;
  fuel_distribution_bins: { bin: string; count: number }[];
  duration_distribution_bins: { bin: string; count: number }[];
  trajectory_points: { lat: number; lon: number; density: number }[];
}

export interface AuditLogEntry {
  id: string;
  timestamp_sim_sec: number;
  timestamp_iso: string;
  actor: 'AUTONOMY_CORE' | 'HUMAN_OPERATOR' | 'FAILURE_INJECTOR' | 'SCENARIO_ENGINE';
  action_type: 'ROUTE_MODIFICATION' | 'MODE_CHANGE' | 'FAILURE_INJECTION' | 'HUMAN_APPROVAL' | 'SAFETY_BREACH' | 'SIM_CONTROL' | 'EXPERIMENT_EXEC';
  details: string;
  previous_state?: string;
  new_state?: string;
  scenario_seed: number;
}

export interface TelemetryFrame {
  sim_time_sec: number;
  lat: number;
  lon: number;
  alt_ft: number;
  tas_kts: number;
  gs_kts: number;
  mach: number;
  vs_fpm: number;
  heading_deg: number;
  pitch_deg: number;
  roll_deg: number;
  fuel_pct: number;
  battery_pct: number;
  phase: FlightPhase;
  autonomy_mode: AutonomyMode;
  envelope_margin_pct: number;
  sensor_health_pct: number;
  active_events: string[];
}

export interface FlightScenario {
  id: string;
  code: string;
  title: string;
  subtitle: string;
  description: string;
  aircraft_id: string;
  flight_number: string;
  origin_icao: string;
  dest_icao: string;
  alternate_icao: string;
  initial_alt_ft: number;
  initial_speed_mach: number;
  initial_phase: FlightPhase;
  autonomy_mode: AutonomyMode;
  weather_preset: string;
  traffic_count: number;
  initial_fuel_pct: number;
  events_timeline: {
    sim_time_sec: number;
    event_type: 'WEATHER_BURST' | 'SENSOR_DISAGREEMENT' | 'ENGINE_DEGRADATION' | 'TRAFFIC_CONVERGE' | 'RUNWAY_CLOSE';
    title: string;
    description: string;
  }[];
}
