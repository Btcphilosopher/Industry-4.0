import {
  AircraftConfig,
  Airport,
  FlightScenario,
  SafetyRequirement,
  Waypoint,
  InjectedFailure,
  Subsystem,
  SensorChannel
} from '../models/aeronautica.types';

export const SYNTHETIC_AIRCRAFT_FLEET: AircraftConfig[] = [
  {
    id: 'A-900X',
    name: 'A-900X Stratos Research Twin',
    code: 'A900X',
    category: 'LONG_RANGE_RESEARCH',
    description: 'Long-range high-altitude autonomous aerodynamic research testbed with composite aero-elastic wings and triple-modular digital flight computer.',
    specs: {
      mtow_kg: 78500,
      oew_kg: 41200,
      max_payload_kg: 18500,
      wingspan_m: 42.6,
      wing_area_m2: 154.0,
      cd0: 0.0162,
      oswald_e: 0.86,
      aspect_ratio: 11.78,
      cl_max: 1.62,
      cl_alpha: 5.72,
      max_altitude_ft: 45000,
      cruise_mach: 0.78,
      mmo: 0.84,
      vmo_kts: 340,
      stall_speed_kts: 118,
      max_climb_rate_fpm: 3400,
      max_descent_rate_fpm: 4500,
      max_bank_angle_deg: 33,
      g_limit_pos: 2.5,
      g_limit_neg: -1.0,
      engines_count: 2,
      engine_type: 'GEARED_TURBOFAN',
      max_thrust_kn_per_eng: 142.0,
      tsfc_kg_per_kn_hr: 0.51,
      fuel_capacity_kg: 24800,
      battery_capacity_kwh: 120,
      min_runway_length_m: 1950,
      redundancy_channels: 3
    }
  },
  {
    id: 'A-420R',
    name: 'A-420R Regional Falcon',
    code: 'A420R',
    category: 'REGIONAL_AUTONOMOUS',
    description: '80-seat regional high-efficiency passenger transport configured with full envelope protection and autonomous terminal area navigation.',
    specs: {
      mtow_kg: 42800,
      oew_kg: 24500,
      max_payload_kg: 9800,
      wingspan_m: 29.4,
      wing_area_m2: 89.2,
      cd0: 0.0185,
      oswald_e: 0.84,
      aspect_ratio: 9.69,
      cl_max: 1.74,
      cl_alpha: 5.45,
      max_altitude_ft: 39000,
      cruise_mach: 0.74,
      mmo: 0.80,
      vmo_kts: 310,
      stall_speed_kts: 110,
      max_climb_rate_fpm: 2900,
      max_descent_rate_fpm: 3800,
      max_bank_angle_deg: 30,
      g_limit_pos: 2.5,
      g_limit_neg: -1.0,
      engines_count: 2,
      engine_type: 'TURBOFAN_HIGH_BYPASS',
      max_thrust_kn_per_eng: 98.0,
      tsfc_kg_per_kn_hr: 0.54,
      fuel_capacity_kg: 12400,
      battery_capacity_kwh: 60,
      min_runway_length_m: 1650,
      redundancy_channels: 3
    }
  },
  {
    id: 'E-220E',
    name: 'E-220E VoltAir Hybrid Testbed',
    code: 'E220E',
    category: 'ELECTRIC_VTOL_CTOL',
    description: 'Distributed hybrid-electric propulsion demonstrator equipped with dual turbogenerator architecture and 8 wingtip electric fan nacelles.',
    specs: {
      mtow_kg: 14200,
      oew_kg: 8900,
      max_payload_kg: 2400,
      wingspan_m: 19.8,
      wing_area_m2: 38.5,
      cd0: 0.0210,
      oswald_e: 0.88,
      aspect_ratio: 10.18,
      cl_max: 1.88,
      cl_alpha: 5.90,
      max_altitude_ft: 25000,
      cruise_mach: 0.48,
      mmo: 0.56,
      vmo_kts: 240,
      stall_speed_kts: 76,
      max_climb_rate_fpm: 2400,
      max_descent_rate_fpm: 2600,
      max_bank_angle_deg: 28,
      g_limit_pos: 2.8,
      g_limit_neg: -1.0,
      engines_count: 8,
      engine_type: 'ELECTRIC_DISTRIBUTED',
      max_thrust_kn_per_eng: 12.5,
      tsfc_kg_per_kn_hr: 0.22,
      fuel_capacity_kg: 2100,
      battery_capacity_kwh: 480,
      min_runway_length_m: 900,
      redundancy_channels: 4
    }
  },
  {
    id: 'C-780F',
    name: 'C-780F Heavy Autonomous Freighter',
    code: 'C780F',
    category: 'HEAVY_CARGO',
    description: 'Autonomous widebody transatlantic cargo aircraft designed for 24/7 autonomous logistics network with automated contingency diversion.',
    specs: {
      mtow_kg: 195000,
      oew_kg: 92000,
      max_payload_kg: 68000,
      wingspan_m: 60.3,
      wing_area_m2: 368.0,
      cd0: 0.0155,
      oswald_e: 0.87,
      aspect_ratio: 9.88,
      cl_max: 1.58,
      cl_alpha: 5.60,
      max_altitude_ft: 43000,
      cruise_mach: 0.82,
      mmo: 0.87,
      vmo_kts: 350,
      stall_speed_kts: 132,
      max_climb_rate_fpm: 2800,
      max_descent_rate_fpm: 4000,
      max_bank_angle_deg: 30,
      g_limit_pos: 2.5,
      g_limit_neg: -1.0,
      engines_count: 2,
      engine_type: 'GEARED_TURBOFAN',
      max_thrust_kn_per_eng: 330.0,
      tsfc_kg_per_kn_hr: 0.49,
      fuel_capacity_kg: 84000,
      battery_capacity_kwh: 200,
      min_runway_length_m: 2600,
      redundancy_channels: 3
    }
  },
  {
    id: 'U-100C',
    name: 'U-100C SkySentinel UAS',
    code: 'U100C',
    category: 'UNMANNED_TECH_DEMO',
    description: 'High-altitude long-endurance (HALE) unmanned aerial platform for BVLOS autonomous flight dynamics testing and sensor fusion experiments.',
    specs: {
      mtow_kg: 5600,
      oew_kg: 2800,
      max_payload_kg: 1200,
      wingspan_m: 26.0,
      wing_area_m2: 32.0,
      cd0: 0.0135,
      oswald_e: 0.92,
      aspect_ratio: 21.12,
      cl_max: 1.65,
      cl_alpha: 6.10,
      max_altitude_ft: 52000,
      cruise_mach: 0.52,
      mmo: 0.60,
      vmo_kts: 220,
      stall_speed_kts: 64,
      max_climb_rate_fpm: 1800,
      max_descent_rate_fpm: 2100,
      max_bank_angle_deg: 25,
      g_limit_pos: 3.0,
      g_limit_neg: -1.2,
      engines_count: 1,
      engine_type: 'HYBRID_TURBOPROP',
      max_thrust_kn_per_eng: 38.0,
      tsfc_kg_per_kn_hr: 0.38,
      fuel_capacity_kg: 2200,
      battery_capacity_kwh: 150,
      min_runway_length_m: 1100,
      redundancy_channels: 3
    }
  }
];

export const SYNTHETIC_AIRPORTS: Airport[] = [
  {
    id: 'APT_EGLN',
    icao: 'EGLN',
    name: 'LONDON NORTH AEROSPACE HUB',
    country: 'United Kingdom (Synthetic)',
    lat: 51.874,
    lon: -0.368,
    elevation_ft: 526,
    runways: [
      { id: '08R/26L', heading_deg: 82, length_m: 3250, width_m: 45, surface: 'ASPHALT', ils_frequency: '109.50', status: 'OPEN' },
      { id: '08L/26R', heading_deg: 82, length_m: 2800, width_m: 45, surface: 'CONCRETE', ils_frequency: '110.30', status: 'OPEN' }
    ],
    metar: {
      raw: 'EGLN 230700Z 24014KT 9999 FEW035 BKN220 14/09 Q1018 NOSIG',
      wind_dir_deg: 240,
      wind_spd_kts: 14,
      vis_km: 10,
      temp_c: 14,
      qnh_hpa: 1018,
      clouds: 'FEW 3,500 ft, BKN 22,000 ft'
    },
    is_synthetic: true,
    diversion_suitability: 'PRIMARY'
  },
  {
    id: 'APT_ENAH',
    icao: 'ENAH',
    name: 'NORTH ATLANTIC OCEAN HUB',
    country: 'North Atlantic Sector (Synthetic)',
    lat: 62.195,
    lon: -7.072,
    elevation_ft: 280,
    runways: [
      { id: '12/30', heading_deg: 124, length_m: 3400, width_m: 60, surface: 'CONCRETE', ils_frequency: '108.90', status: 'OPEN' }
    ],
    metar: {
      raw: 'ENAH 230700Z 29022G34KT 8000 -RA SCT018 BKN040 07/04 Q1002 TEMPO 4000 SHRA',
      wind_dir_deg: 290,
      wind_spd_kts: 22,
      vis_km: 8,
      temp_c: 7,
      qnh_hpa: 1002,
      clouds: 'SCT 1,800 ft, BKN 4,000 ft'
    },
    is_synthetic: true,
    diversion_suitability: 'PRIMARY'
  },
  {
    id: 'APT_BIRK',
    icao: 'BIRK',
    name: 'REYKJAVIK CENTRAL TESTWAY',
    country: 'Iceland (Synthetic)',
    lat: 64.130,
    lon: -21.940,
    elevation_ft: 48,
    runways: [
      { id: '01/19', heading_deg: 14, length_m: 3100, width_m: 45, surface: 'ASPHALT', ils_frequency: '109.90', status: 'OPEN' },
      { id: '06/24', heading_deg: 62, length_m: 2450, width_m: 45, surface: 'ASPHALT', ils_frequency: '111.10', status: 'OPEN' }
    ],
    metar: {
      raw: 'BIRK 230700Z 02008KT CAVOK 04/M02 Q1022 NOSIG',
      wind_dir_deg: 20,
      wind_spd_kts: 8,
      vis_km: 15,
      temp_c: 4,
      qnh_hpa: 1022,
      clouds: 'CAVOK Nil Significant'
    },
    is_synthetic: true,
    diversion_suitability: 'SUITABLE'
  },
  {
    id: 'APT_KNYE',
    icao: 'KNYE',
    name: 'NEW YORK EAST SEABOARD',
    country: 'United States (Synthetic)',
    lat: 40.640,
    lon: -73.780,
    elevation_ft: 13,
    runways: [
      { id: '04L/22R', heading_deg: 44, length_m: 3680, width_m: 60, surface: 'CONCRETE', ils_frequency: '109.50', status: 'OPEN' },
      { id: '13R/31L', heading_deg: 134, length_m: 4400, width_m: 60, surface: 'CONCRETE', ils_frequency: '110.90', status: 'OPEN' }
    ],
    metar: {
      raw: 'KNYE 230700Z 18012KT 10SM SCT045 BKN100 18/12 A3012',
      wind_dir_deg: 180,
      wind_spd_kts: 12,
      vis_km: 16,
      temp_c: 18,
      qnh_hpa: 1020,
      clouds: 'SCT 4,500 ft, BKN 10,000 ft'
    },
    is_synthetic: true,
    diversion_suitability: 'SUITABLE'
  },
  {
    id: 'APT_EDDB',
    icao: 'EDDB',
    name: 'BERLIN INTERNATIONAL DYNAMICS',
    country: 'Germany (Synthetic)',
    lat: 52.362,
    lon: 13.501,
    elevation_ft: 157,
    runways: [
      { id: '07L/25R', heading_deg: 69, length_m: 3600, width_m: 45, surface: 'ASPHALT', ils_frequency: '108.35', status: 'OPEN' },
      { id: '07R/25L', heading_deg: 69, length_m: 4000, width_m: 60, surface: 'CONCRETE', ils_frequency: '109.15', status: 'OPEN' }
    ],
    metar: {
      raw: 'EDDB 230700Z 27010KT CAVOK 16/08 Q1015 NOSIG',
      wind_dir_deg: 270,
      wind_spd_kts: 10,
      vis_km: 12,
      temp_c: 16,
      qnh_hpa: 1015,
      clouds: 'CAVOK'
    },
    is_synthetic: true,
    diversion_suitability: 'SUITABLE'
  },
  {
    id: 'APT_EPWA',
    icao: 'EPWA',
    name: 'WARSAW CENTRAL AERODROME',
    country: 'Poland (Synthetic)',
    lat: 52.165,
    lon: 20.967,
    elevation_ft: 362,
    runways: [
      { id: '11/29', heading_deg: 110, length_m: 2800, width_m: 50, surface: 'CONCRETE', ils_frequency: '110.30', status: 'OPEN' }
    ],
    metar: {
      raw: 'EPWA 230700Z 12006KT 9999 SCT025 15/07 Q1019 NOSIG',
      wind_dir_deg: 120,
      wind_spd_kts: 6,
      vis_km: 10,
      temp_c: 15,
      qnh_hpa: 1019,
      clouds: 'SCT 2,500 ft'
    },
    is_synthetic: true,
    diversion_suitability: 'SUITABLE'
  },
  {
    id: 'APT_WSSS',
    icao: 'WSSS',
    name: 'SINGAPORE EAST PACIFIC GATE',
    country: 'Singapore (Synthetic)',
    lat: 1.350,
    lon: 103.994,
    elevation_ft: 22,
    runways: [
      { id: '02L/20R', heading_deg: 23, length_m: 4000, width_m: 60, surface: 'ASPHALT', ils_frequency: '109.70', status: 'OPEN' }
    ],
    metar: {
      raw: 'WSSS 230700Z 06008KT 9000 FEW018CB BKN030 30/26 Q1009',
      wind_dir_deg: 60,
      wind_spd_kts: 8,
      vis_km: 9,
      temp_c: 30,
      qnh_hpa: 1009,
      clouds: 'FEW 1,800 ft CB, BKN 3,000 ft'
    },
    is_synthetic: true,
    diversion_suitability: 'SUITABLE'
  },
  {
    id: 'APT_RJTT',
    icao: 'RJTT',
    name: 'TOKYO PACIFIC AIR CORRIDOR',
    country: 'Japan (Synthetic)',
    lat: 35.552,
    lon: 139.779,
    elevation_ft: 21,
    runways: [
      { id: '16L/34R', heading_deg: 157, length_m: 3360, width_m: 60, surface: 'CONCRETE', ils_frequency: '111.90', status: 'OPEN' }
    ],
    metar: {
      raw: 'RJTT 230700Z 04015KT 9999 FEW030 22/16 Q1014',
      wind_dir_deg: 40,
      wind_spd_kts: 15,
      vis_km: 10,
      temp_c: 22,
      qnh_hpa: 1014,
      clouds: 'FEW 3,000 ft'
    },
    is_synthetic: true,
    diversion_suitability: 'SUITABLE'
  },
  {
    id: 'APT_CYTZ',
    icao: 'CYTZ',
    name: 'TORONTO NORTH SECTOR',
    country: 'Canada (Synthetic)',
    lat: 43.627,
    lon: -79.396,
    elevation_ft: 251,
    runways: [
      { id: '08/26', heading_deg: 83, length_m: 2200, width_m: 45, surface: 'ASPHALT', ils_frequency: '109.10', status: 'OPEN' }
    ],
    metar: {
      raw: 'CYTZ 230700Z 32014KT 15SM FEW050 11/02 A3008',
      wind_dir_deg: 320,
      wind_spd_kts: 14,
      vis_km: 24,
      temp_c: 11,
      qnh_hpa: 1018,
      clouds: 'FEW 5,000 ft'
    },
    is_synthetic: true,
    diversion_suitability: 'SUITABLE'
  },
  {
    id: 'APT_OMDB',
    icao: 'OMDB',
    name: 'DUBAI INTERNATIONAL CORRIDOR',
    country: 'United Arab Emirates (Synthetic)',
    lat: 25.253,
    lon: 55.364,
    elevation_ft: 62,
    runways: [
      { id: '12L/30R', heading_deg: 120, length_m: 4450, width_m: 60, surface: 'ASPHALT', ils_frequency: '110.10', status: 'OPEN' }
    ],
    metar: {
      raw: 'OMDB 230700Z 35010KT CAVOK 36/18 Q1008 NOSIG',
      wind_dir_deg: 350,
      wind_spd_kts: 10,
      vis_km: 10,
      temp_c: 36,
      qnh_hpa: 1008,
      clouds: 'CAVOK'
    },
    is_synthetic: true,
    diversion_suitability: 'SUITABLE'
  }
];

export const INITIAL_WAYPOINTS: Waypoint[] = [
  { id: 'WP_EGLN', name: 'EGLN-DEP', lat: 51.874, lon: -0.368, alt_restriction_ft: 5000, speed_restriction_kts: 250, is_flyover: false, type: 'DEPARTURE' },
  { id: 'WP_LAM', name: 'LAMBA', lat: 53.200, lon: -2.100, alt_restriction_ft: 18000, speed_restriction_kts: 300, is_flyover: false, type: 'ENROUTE' },
  { id: 'WP_GOW', name: 'GOWEN', lat: 55.850, lon: -4.300, alt_restriction_ft: 28000, speed_restriction_kts: 320, is_flyover: false, type: 'ENROUTE' },
  { id: 'WP_RATSU', name: 'RATSU', lat: 57.500, lon: -5.800, alt_restriction_ft: 38000, speed_restriction_kts: 440, is_flyover: false, type: 'WAYPOINT' },
  { id: 'WP_60N10', name: '60N010W', lat: 60.000, lon: -10.000, alt_restriction_ft: 38000, speed_restriction_kts: 450, is_flyover: false, type: 'WAYPOINT' },
  { id: 'WP_61N15', name: '61N015W', lat: 61.200, lon: -15.500, alt_restriction_ft: 38000, speed_restriction_kts: 450, is_flyover: false, type: 'WAYPOINT' },
  { id: 'WP_NAT', name: 'ATL-HUB', lat: 62.195, lon: -7.072, alt_restriction_ft: 10000, speed_restriction_kts: 250, is_flyover: false, type: 'ARRIVAL' },
  { id: 'WP_ENAH_RW', name: 'ENAH-RW12', lat: 62.195, lon: -7.072, alt_restriction_ft: 280, speed_restriction_kts: 135, is_flyover: true, type: 'INITIAL_APPROACH' }
];

export const CANDIDATE_DIVERT_WAYPOINTS_NORTH: Waypoint[] = [
  { id: 'WP_RATSU', name: 'RATSU', lat: 57.500, lon: -5.800, alt_restriction_ft: 38000, speed_restriction_kts: 440, is_flyover: false, type: 'WAYPOINT' },
  { id: 'WP_DEV_N1', name: 'DEV-NORTH-ALPHA', lat: 59.800, lon: -6.500, alt_restriction_ft: 38000, speed_restriction_kts: 445, is_flyover: false, type: 'WAYPOINT' },
  { id: 'WP_DEV_N2', name: 'DEV-NORTH-BRAVO', lat: 62.800, lon: -12.200, alt_restriction_ft: 38000, speed_restriction_kts: 445, is_flyover: false, type: 'WAYPOINT' },
  { id: 'WP_BIRK_ARR', name: 'BIRK-NORTHGATE', lat: 64.130, lon: -21.940, alt_restriction_ft: 3000, speed_restriction_kts: 180, is_flyover: true, type: 'ARRIVAL' }
];

export const DEFAULT_SCENARIOS: FlightScenario[] = [
  {
    id: 'SCEN_ATLAS_042',
    code: 'ATLAS-042',
    title: 'Transoceanic Storm Front & Autonomous Re-route',
    subtitle: 'High-Altitude Severe Weather Squall Line with Constrained Diversion Evaluation',
    description: 'Long-range autonomous test aircraft A-900X encounters an unforecast convective cell line across NAT track Charlie. The autonomy engine evaluates lateral vs vertical vs holding alternatives, synthesizes aerodynamic margins, and submits a diversion package to human supervision.',
    aircraft_id: 'A-900X',
    flight_number: 'SIM-2026-0918-001',
    origin_icao: 'EGLN',
    dest_icao: 'ENAH',
    alternate_icao: 'BIRK',
    initial_alt_ft: 38000,
    initial_speed_mach: 0.78,
    initial_phase: 'CRUISE',
    autonomy_mode: 'SUPERVISED_AUTONOMY',
    weather_preset: 'CONVECTIVE_STORM_SQUALL',
    traffic_count: 18,
    initial_fuel_pct: 68.4,
    events_timeline: [
      {
        sim_time_sec: 15,
        event_type: 'WEATHER_BURST',
        title: 'Synthetic Storm Cell CB-92 Alpha Detected',
        description: 'Multi-spectral synthetic radar detects severe convective cell top FL480 with extreme turbulence index and lightning rate 28/min directly intersecting track.'
      }
    ]
  },
  {
    id: 'SCEN_ORBIT_017',
    code: 'ORBIT-017',
    title: 'Navigation Sensor Disagreement & Redundancy Failover',
    subtitle: 'Inertial Drift vs GNSS Multipath Spoofing Inconsistency',
    description: 'Channel A IMU experiences slow gyroscopic drift while GNSS receiver B experiences pseudo-range noise burst. Layer 1 State Estimator detects cross-channel divergence exceeding 3-sigma thresholds, invokes voting logic, down-rates confidence, and requests supervisory intervention.',
    aircraft_id: 'A-900X',
    flight_number: 'SIM-2026-0922-004',
    origin_icao: 'EGLN',
    dest_icao: 'ENAH',
    alternate_icao: 'BIRK',
    initial_alt_ft: 38000,
    initial_speed_mach: 0.78,
    initial_phase: 'CRUISE',
    autonomy_mode: 'SUPERVISED_AUTONOMY',
    weather_preset: 'STANDARD_ATMOSPHERE_CLEAR',
    traffic_count: 12,
    initial_fuel_pct: 65.0,
    events_timeline: [
      {
        sim_time_sec: 10,
        event_type: 'SENSOR_DISAGREEMENT',
        title: 'IMU Channel A / GNSS Channel B Divergence',
        description: 'Cross-track position estimate discrepancy exceeds 2.8 nautical miles. State covariance ellipse expands by 340%.'
      }
    ]
  },
  {
    id: 'SCEN_A_ENG',
    code: 'SCEN-A',
    title: 'Engine Core Degradation During High Cruise',
    subtitle: 'Thermal Exceedance & Reduced Single-Engine Ceiling',
    description: 'Engine 1 ITT temperature rises 48°C above nominal research threshold with 18% loss of N1 fan speed. Autonomy checks single-engine drift-down ceiling (FL240) and fuel reserves.',
    aircraft_id: 'A-900X',
    flight_number: 'SIM-ENG-001',
    origin_icao: 'EGLN',
    dest_icao: 'ENAH',
    alternate_icao: 'BIRK',
    initial_alt_ft: 38000,
    initial_speed_mach: 0.78,
    initial_phase: 'CRUISE',
    autonomy_mode: 'SUPERVISED_AUTONOMY',
    weather_preset: 'STANDARD_ATMOSPHERE',
    traffic_count: 8,
    initial_fuel_pct: 72.0,
    events_timeline: [
      {
        sim_time_sec: 20,
        event_type: 'ENGINE_DEGRADATION',
        title: 'Engine 1 EGT High & Thrust Rollback',
        description: 'Thrust output down 38%. Autonomy initiates controlled drift-down to single-engine level-off altitude.'
      }
    ]
  },
  {
    id: 'SCEN_E_RWY',
    code: 'SCEN-E',
    title: 'Destination Runway Closure & Alternate Diversion',
    subtitle: 'Synthetic NOTAM Injection with ETOPS Fuel Audit',
    description: 'Destination airport ENAH reports runway blockage. Autonomy calculates fuel burn to alternate BIRK with 45-minute contingency reserve compliance.',
    aircraft_id: 'A-900X',
    flight_number: 'SIM-RWY-005',
    origin_icao: 'EGLN',
    dest_icao: 'ENAH',
    alternate_icao: 'BIRK',
    initial_alt_ft: 38000,
    initial_speed_mach: 0.78,
    initial_phase: 'CRUISE',
    autonomy_mode: 'SUPERVISED_AUTONOMY',
    weather_preset: 'OVERCAST_TURBULENCE',
    traffic_count: 14,
    initial_fuel_pct: 54.0,
    events_timeline: [
      {
        sim_time_sec: 12,
        event_type: 'RUNWAY_CLOSE',
        title: 'ENAH Runway 12 Closed by Operations',
        description: 'Destination unusable. Diversion matrix to REYKJAVIK (BIRK) activated.'
      }
    ]
  },
  {
    id: 'SCEN_G_TRAFFIC',
    code: 'SCEN-G',
    title: 'Converging Autonomous Traffic Conflict',
    subtitle: 'TCAS-II Resolution Advisory (RA) Autonomous Resolution',
    description: 'Traffic freighter C780F on crossing track altitude FL380 creates 42-second collision time-to-closest approach. Autonomy plans coordinated step-climb +2,000 ft.',
    aircraft_id: 'A-900X',
    flight_number: 'SIM-TRAF-007',
    origin_icao: 'EGLN',
    dest_icao: 'ENAH',
    alternate_icao: 'BIRK',
    initial_alt_ft: 38000,
    initial_speed_mach: 0.78,
    initial_phase: 'CRUISE',
    autonomy_mode: 'SUPERVISED_AUTONOMY',
    weather_preset: 'CAVOK',
    traffic_count: 22,
    initial_fuel_pct: 68.0,
    events_timeline: [
      {
        sim_time_sec: 15,
        event_type: 'TRAFFIC_CONVERGE',
        title: 'TCAS Resolution Advisory: CLIMB, CLIMB',
        description: 'Predicted vertical separation < 350 ft in 38 seconds. Autonomous vertical separation maneuver triggered.'
      }
    ]
  }
];

export const INITIAL_SUBSYSTEMS: Subsystem[] = [
  {
    id: 'SYS_FMS',
    name: 'Flight Management & Trajectory Generator',
    category: 'AVIONICS',
    status: 'NOMINAL',
    health_pct: 100,
    redundancy_config: 'TRIPLE_TMR',
    operating_value: 'RNP 0.3 / 4D Trajectory Synchronized',
    nominal_range: 'RNP 0.1 - 1.0 NM',
    channel_states: { channel_a: 'NOMINAL', channel_b: 'NOMINAL', channel_c: 'NOMINAL' }
  },
  {
    id: 'SYS_NAV',
    name: 'Integrated Navigation & GNSS/INS Unit',
    category: 'AVIONICS',
    status: 'NOMINAL',
    health_pct: 98,
    redundancy_config: 'TRIPLE_TMR',
    operating_value: 'HDOP 0.82 / 14 SVs Locked / IMU Drift 0.008°/hr',
    nominal_range: 'HDOP < 2.0 / Drift < 0.05°/hr',
    channel_states: { channel_a: 'NOMINAL', channel_b: 'NOMINAL', channel_c: 'NOMINAL' }
  },
  {
    id: 'SYS_ENVELOPE',
    name: 'Flight Envelope Protection & Buffet Limiter',
    category: 'AVIONICS',
    status: 'NOMINAL',
    health_pct: 100,
    redundancy_config: 'TRIPLE_TMR',
    operating_value: 'Buffet Margin +0.14M / Stall Margin +24 kts / 1.02G',
    nominal_range: 'Buffet > 0.05M / Stall Margin > 15 kts',
    channel_states: { channel_a: 'NOMINAL', channel_b: 'NOMINAL', channel_c: 'NOMINAL' }
  },
  {
    id: 'SYS_PROP_L',
    name: 'Left Engine (ENG 1) Geared Turbofan',
    category: 'PROPULSION',
    status: 'NOMINAL',
    health_pct: 99,
    redundancy_config: 'DUAL_FAIL_PASSIVE',
    operating_value: 'N1 88.4% / EGT 642°C / Oil Press 48 psi',
    nominal_range: 'N1 20-102% / EGT < 820°C',
    channel_states: { channel_a: 'NOMINAL', channel_b: 'NOMINAL' }
  },
  {
    id: 'SYS_PROP_R',
    name: 'Right Engine (ENG 2) Geared Turbofan',
    category: 'PROPULSION',
    status: 'NOMINAL',
    health_pct: 99,
    redundancy_config: 'DUAL_FAIL_PASSIVE',
    operating_value: 'N1 88.3% / EGT 640°C / Oil Press 49 psi',
    nominal_range: 'N1 20-102% / EGT < 820°C',
    channel_states: { channel_a: 'NOMINAL', channel_b: 'NOMINAL' }
  },
  {
    id: 'SYS_ELEC',
    name: 'Electrical Distribution & Battery Buffer',
    category: 'ELECTRICAL',
    status: 'NOMINAL',
    health_pct: 97,
    redundancy_config: 'TRIPLE_TMR',
    operating_value: '115V AC 400Hz / 28V DC Bus / Batt 91.2%',
    nominal_range: '110-120V AC / Batt > 30%',
    channel_states: { channel_a: 'NOMINAL', channel_b: 'NOMINAL', channel_c: 'NOMINAL' }
  },
  {
    id: 'SYS_HYD',
    name: 'Hydraulic Triple Power System (Green/Blue/Yellow)',
    category: 'HYDRAULICS',
    status: 'NOMINAL',
    health_pct: 98,
    redundancy_config: 'TRIPLE_TMR',
    operating_value: '3,010 psi / 3,025 psi / 2,990 psi',
    nominal_range: '2,800 - 3,200 psi',
    channel_states: { channel_a: 'NOMINAL', channel_b: 'NOMINAL', channel_c: 'NOMINAL' }
  },
  {
    id: 'SYS_FCS',
    name: 'Fly-By-Wire Primary Flight Controls (Ailerons/Elevators/Rudder)',
    category: 'FLIGHT_CONTROLS',
    status: 'NOMINAL',
    health_pct: 100,
    redundancy_config: 'TRIPLE_TMR',
    operating_value: 'Actuator Delta 0.04° / Servo Latency 8ms',
    nominal_range: 'Latency < 20ms',
    channel_states: { channel_a: 'NOMINAL', channel_b: 'NOMINAL', channel_c: 'NOMINAL' }
  },
  {
    id: 'SYS_SENS_RADAR',
    name: 'Forward Multi-Mode Weather & Traffic Radar',
    category: 'SENSORS',
    status: 'NOMINAL',
    health_pct: 96,
    redundancy_config: 'DUAL_FAIL_PASSIVE',
    operating_value: 'Scan Range 160 NM / Doppler Turbulence Enabled',
    nominal_range: 'Range 20 - 320 NM',
    channel_states: { channel_a: 'NOMINAL', channel_b: 'NOMINAL' }
  },
  {
    id: 'SYS_SENS_LIDAR',
    name: 'Airspace Optical LiDAR & Clear-Air Detector',
    category: 'SENSORS',
    status: 'NOMINAL',
    health_pct: 95,
    redundancy_config: 'DUAL_FAIL_PASSIVE',
    operating_value: 'Range 18 NM / Point Density 12k pts/sec',
    nominal_range: 'Laser Power 98%',
    channel_states: { channel_a: 'NOMINAL', channel_b: 'NOMINAL' }
  }
];

export const INITIAL_SENSOR_CHANNELS: SensorChannel[] = [
  { id: 'SENS_IMU_A', name: 'IMU Primary Gyro/Accel', type: 'IMU', channel: 'A', status: 'NOMINAL', noise_sigma: 0.01, drift_rate_per_hr: 0.005, bias: 0.001, latency_ms: 4, confidence_pct: 99.4, is_failed: false, is_spoofed: false, value_raw: 274.1, value_filtered: 274.0, unit: 'deg' },
  { id: 'SENS_IMU_B', name: 'IMU Secondary Gyro/Accel', type: 'IMU', channel: 'B', status: 'NOMINAL', noise_sigma: 0.012, drift_rate_per_hr: 0.007, bias: 0.002, latency_ms: 5, confidence_pct: 99.1, is_failed: false, is_spoofed: false, value_raw: 274.2, value_filtered: 274.0, unit: 'deg' },
  { id: 'SENS_IMU_C', name: 'IMU Standby Solid-State', type: 'IMU', channel: 'C', status: 'NOMINAL', noise_sigma: 0.015, drift_rate_per_hr: 0.009, bias: -0.001, latency_ms: 6, confidence_pct: 98.8, is_failed: false, is_spoofed: false, value_raw: 273.9, value_filtered: 274.0, unit: 'deg' },
  { id: 'SENS_GPS_A', name: 'GNSS Multi-Constellation L1/L5', type: 'GNSS', channel: 'A', status: 'NOMINAL', noise_sigma: 0.8, drift_rate_per_hr: 0.0, bias: 0.1, latency_ms: 40, confidence_pct: 99.8, is_failed: false, is_spoofed: false, value_raw: 57.501, value_filtered: 57.500, unit: 'lat°' },
  { id: 'SENS_GPS_B', name: 'GNSS Multi-Constellation Receiver 2', type: 'GNSS', channel: 'B', status: 'NOMINAL', noise_sigma: 0.9, drift_rate_per_hr: 0.0, bias: -0.1, latency_ms: 42, confidence_pct: 99.6, is_failed: false, is_spoofed: false, value_raw: 57.499, value_filtered: 57.500, unit: 'lat°' },
  { id: 'SENS_PITOT_A', name: 'Air Data SmartProbe Left', type: 'PITOT_STATIC', channel: 'A', status: 'NOMINAL', noise_sigma: 0.3, drift_rate_per_hr: 0.0, bias: 0.0, latency_ms: 8, confidence_pct: 99.5, is_failed: false, is_spoofed: false, value_raw: 442.1, value_filtered: 442.0, unit: 'kts TAS' },
  { id: 'SENS_PITOT_B', name: 'Air Data SmartProbe Right', type: 'PITOT_STATIC', channel: 'B', status: 'NOMINAL', noise_sigma: 0.4, drift_rate_per_hr: 0.0, bias: 0.2, latency_ms: 8, confidence_pct: 99.3, is_failed: false, is_spoofed: false, value_raw: 441.8, value_filtered: 442.0, unit: 'kts TAS' },
  { id: 'SENS_RADAR_ALT', name: 'Frequency-Modulated Radar Altimeter', type: 'RADAR_ALTIMETER', channel: 'A', status: 'NOMINAL', noise_sigma: 1.2, drift_rate_per_hr: 0.0, bias: 0.0, latency_ms: 12, confidence_pct: 99.7, is_failed: false, is_spoofed: false, value_raw: 38012, value_filtered: 38000, unit: 'ft AGL' }
];

export const AVAILABLE_FAILURES: InjectedFailure[] = [
  {
    id: 'FAIL_GPS_NOISE',
    name: 'GNSS Signal Multipath & Spoofing Noise',
    category: 'SENSOR',
    description: 'Injects high pseudo-range noise and 3.5 NM lateral offset into GNSS Channel B to test Kalman filter rejection.',
    severity: 'MAJOR',
    target_subsystem: 'SYS_NAV',
    is_active: false,
    recovery_action: 'Sensor fusion isolates Channel B, switches to Channel A GNSS + Triple INS voting.'
  },
  {
    id: 'FAIL_PITOT_ICING',
    name: 'Pitot Tube A Dynamic Pressure Icing Freeze',
    category: 'SENSOR',
    description: 'Simulates heating element degradation and uncommanded airspeed decay on left SmartProbe.',
    severity: 'HAZARDOUS',
    target_subsystem: 'SYS_ENVELOPE',
    is_active: false,
    recovery_action: 'Autonomy cross-compares Probe A vs Probe B and GPS ground speed to declare unreliable airspeed.'
  },
  {
    id: 'FAIL_ENG_1_FLAMEOUT',
    name: 'Engine 1 Core Flameout & Thrust Loss',
    category: 'PROPULSION',
    description: 'Uncommanded fuel valve cutoff on Left Engine, creating 50% total thrust loss and asymmetric yaw moment.',
    severity: 'HAZARDOUS',
    target_subsystem: 'SYS_PROP_L',
    is_active: false,
    recovery_action: 'Autonomy trims rudder, initiates drift-down to single-engine ceiling FL240, and verifies alternate diversion fuel.'
  },
  {
    id: 'FAIL_HYD_LEAK',
    name: 'Green Hydraulic Circuit Pressure Depletion',
    category: 'SYSTEM',
    description: 'Rupture in Green hydraulic reservoir reduces pressure from 3,000 psi to 250 psi in 18 seconds.',
    severity: 'MAJOR',
    target_subsystem: 'SYS_HYD',
    is_active: false,
    recovery_action: 'Blue and Yellow systems power flight controls with zero loss of control authority.'
  },
  {
    id: 'FAIL_WEATHER_SQUALL',
    name: 'Sudden Explosive Convective Thunderstorm Cell',
    category: 'ENVIRONMENT',
    description: 'Weather radar detects rapid cell development directly along active flight track with cloud top FL480.',
    severity: 'MAJOR',
    target_subsystem: 'SYS_FMS',
    is_active: false,
    recovery_action: 'Autonomy executes dynamic A* detour with +14° heading alteration and submits plan to operator.'
  },
  {
    id: 'FAIL_DEST_RWY_CLOSED',
    name: 'Destination Runway Sudden Emergency Closure',
    category: 'ENVIRONMENT',
    description: 'NOTAM broadcast closes primary and secondary runways at destination airport.',
    severity: 'MAJOR',
    target_subsystem: 'SYS_FMS',
    is_active: false,
    recovery_action: 'Autonomy selects alternate airport (BIRK) and generates descent profile with fuel reserve safety audit.'
  },
  {
    id: 'FAIL_COMMS_BLACKOUT',
    name: 'BVLOS Satellite Data Link Interruption',
    category: 'COMMUNICATION',
    description: 'Loss of C2 link for 90+ seconds to test autonomous contingency mission execution under isolation.',
    severity: 'HAZARDOUS',
    target_subsystem: 'SYS_FMS',
    is_active: false,
    recovery_action: 'Aircraft transitions to HIGH_AUTOMATION_RESEARCH autonomous contingency hold or continues clearance.'
  }
];

export const SAFETY_REQUIREMENTS_MATRIX: SafetyRequirement[] = [
  {
    id: 'REQ-SAF-001',
    title: 'Flight Envelope Speed Exceedance Protection',
    category: 'FLIGHT_ENVELOPE',
    description: 'The autonomous guidance system shall reject any trajectory command that causes Mach to exceed MMO (0.84M) or calibrated airspeed to exceed VMO (340 kts) under any aerodynamic gust scenario.',
    target_subsystem: 'SYS_ENVELOPE',
    verification_method: 'SIMULATION_MONTE_CARLO',
    test_case_id: 'TC-ENV-014',
    status: 'PASSED_SIMULATION',
    evidence_summary: '10,000 Monte Carlo runs with ±35kt gust shear showed 0% boundary violations; peak Mach was 0.814M (margin 0.026M).',
    coverage_pct: 100,
    reviewer: 'Dr. H. Vance (Lead Flight Dynamics)',
    last_evaluated: '2026-09-18 14:22 UTC'
  },
  {
    id: 'REQ-SAF-002',
    title: 'Multi-Sensor Divergence Fault Isolation',
    category: 'SITUATION_AWARENESS',
    description: 'The state estimation layer shall detect, isolate, and exclude any single sensor channel whose error exceeds 3-sigma within 350 milliseconds without disrupting trajectory tracking.',
    target_subsystem: 'SYS_NAV',
    verification_method: 'FAULT_INJECTION',
    test_case_id: 'TC-NAV-029',
    status: 'PASSED_SIMULATION',
    evidence_summary: 'Injected 4.2 NM GPS jump; Kalman residual test triggered in 180ms; channel isolated; navigation error stayed < 0.12 NM.',
    coverage_pct: 100,
    reviewer: 'M. Lindqvist (Avionics Safety Engineer)',
    last_evaluated: '2026-09-20 09:15 UTC'
  },
  {
    id: 'REQ-SAF-003',
    title: 'Severe Convective Weather Avoidance Buffer',
    category: 'CONTINGENCY_FAILOVER',
    description: 'The autonomous mission planner shall maintain at least 20 nautical miles lateral separation from any convective cell with top exceeding FL350 or lightning rate > 10/min.',
    target_subsystem: 'SYS_FMS',
    verification_method: 'SIMULATION_MONTE_CARLO',
    test_case_id: 'TC-WX-008',
    status: 'PASSED_SIMULATION',
    evidence_summary: 'Verified in 500 stochastic storm cell simulations; minimum closest point of approach was 22.4 NM.',
    coverage_pct: 99.2,
    reviewer: 'E. Moreau (Meteorology & Autonomy Lead)',
    last_evaluated: '2026-09-21 16:40 UTC'
  },
  {
    id: 'REQ-SAF-004',
    title: 'Loss of Thrust Single-Engine Drift-Down Safe Ceiling',
    category: 'CONTINGENCY_FAILOVER',
    description: 'Upon single-engine failure at cruise, the system shall compute optimum descent rate to maintain stall margin > 20 kts while preserving terrain clearance and alternate reachability.',
    target_subsystem: 'SYS_PROP_L',
    verification_method: 'FAULT_INJECTION',
    test_case_id: 'TC-PROP-003',
    status: 'PASSED_SIMULATION',
    evidence_summary: 'Simulated flameout at FL380; descent rate stabilized at -720 fpm; reached single-engine ceiling FL240 with +31kt stall margin.',
    coverage_pct: 100,
    reviewer: 'Dr. K. Arisawa (Propulsion Dynamics)',
    last_evaluated: '2026-09-22 11:30 UTC'
  },
  {
    id: 'REQ-SAF-005',
    title: 'Human Supervision Action Request Timeout',
    category: 'HUMAN_SUPERVISION',
    description: 'When operating in SUPERVISED_AUTONOMY mode, if an emergency safety-critical reroute is not approved by human oversight within 60 seconds, the system shall transition to fail-safe contingency path.',
    target_subsystem: 'SYS_FMS',
    verification_method: 'FLIGHT_TEST_REPLAY',
    test_case_id: 'TC-HUM-002',
    status: 'PASSED_SIMULATION',
    evidence_summary: 'Timeout handler triggered at T+60.0s; automatically transitioned to pre-approved holding pattern at RATSU with safety alert broadcast.',
    coverage_pct: 100,
    reviewer: 'S. Al-Mansoor (Human-Machine Interface)',
    last_evaluated: '2026-09-22 18:05 UTC'
  },
  {
    id: 'REQ-SAF-006',
    title: 'Loss of Separation TCAS Conflict Resolution',
    category: 'SITUATION_AWARENESS',
    description: 'Autonomous collision avoidance shall resolve 100% of synthetic crossing conflicts within 15 seconds of Resolution Advisory with minimum vertical separation 800 ft.',
    target_subsystem: 'SYS_FMS',
    verification_method: 'SIMULATION_MONTE_CARLO',
    test_case_id: 'TC-TRAF-019',
    status: 'PASSED_SIMULATION',
    evidence_summary: '1,000 Monte Carlo crossing traffic geometry tests; 0 collision breaches; minimum miss distance 1,150 ft vertical / 3.2 NM horizontal.',
    coverage_pct: 99.8,
    reviewer: 'J. Dupont (Airspace Autonomy Systems)',
    last_evaluated: '2026-09-23 00:01 UTC'
  }
];
