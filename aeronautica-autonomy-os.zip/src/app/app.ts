import { ChangeDetectionStrategy, Component, HostListener, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SimulationService } from './core/services/simulation.service';
import { TopBar } from './components/top-bar/top-bar';
import { CommandPalette } from './components/command-palette/command-palette';
import { ShortcutsModal } from './components/shortcuts-modal/shortcuts-modal';
import { FailureModal } from './components/failure-modal/failure-modal';

import { ViewOperations } from './views/operations/operations';
import { ViewAircraft } from './views/aircraft/aircraft';
import { ViewSystems } from './views/systems/systems';
import { ViewAutonomy } from './views/autonomy/autonomy';
import { ViewNavigation } from './views/navigation/navigation';
import { ViewPerception } from './views/perception/perception';
import { ViewWeather } from './views/weather/weather';
import { ViewAirspace } from './views/airspace/airspace';
import { ViewFlightDynamics } from './views/flight-dynamics/flight-dynamics';
import { ViewSafety } from './views/safety/safety';
import { ViewFailures } from './views/failures/failures';
import { ViewMonteCarlo } from './views/monte-carlo/monte-carlo';
import { ViewFlightRecorder } from './views/flight-recorder/flight-recorder';
import { ViewDataLab } from './views/data-lab/data-lab';
import { ViewReports } from './views/reports/reports';
import { ViewSystemHealth } from './views/system-health/system-health';

@Component({
  selector: 'app-root',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    TopBar,
    CommandPalette,
    ShortcutsModal,
    FailureModal,
    ViewOperations,
    ViewAircraft,
    ViewSystems,
    ViewAutonomy,
    ViewNavigation,
    ViewPerception,
    ViewWeather,
    ViewAirspace,
    ViewFlightDynamics,
    ViewSafety,
    ViewFailures,
    ViewMonteCarlo,
    ViewFlightRecorder,
    ViewDataLab,
    ViewReports,
    ViewSystemHealth
  ],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  public sim = inject(SimulationService);

  @HostListener('window:keydown', ['$event'])
  handleKeyDown(event: KeyboardEvent): void {
    // Check for Command Palette Ctrl+K or Cmd+K
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
      event.preventDefault();
      this.sim.isCommandPaletteOpen.update(v => !v);
      return;
    }

    // Spacebar to pause/resume simulation (unless typing in input)
    if (event.key === ' ' && !(event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement)) {
      event.preventDefault();
      this.sim.togglePlayPause();
      return;
    }

    // Escape closes modals
    if (event.key === 'Escape') {
      this.sim.isCommandPaletteOpen.set(false);
      this.sim.isShortcutsModalOpen.set(false);
      this.sim.isFailureModalOpen.set(false);
    }
  }
}
