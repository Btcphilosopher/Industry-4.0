import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../core/services/simulation.service';

@Component({
  selector: 'app-view-monte-carlo',
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full w-full p-4 flex flex-col gap-4 overflow-y-auto select-none font-mono">
      <!-- Section Top Banner -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-[#0B0F17] border border-slate-800 p-4 rounded-lg">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-orange-400 font-bold text-sm">STOCHASTIC MONTE CARLO BATCH RUNNER & SAFETY BOUNDS</span>
            <span class="text-xs text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded font-bold">
              1,000 RUNS EVALUATED (99.8% SUCCESS)
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Empirical probability distribution of trajectory bounds, fuel reserve margins, and extreme wind shear encounter limits.
          </p>
        </div>

        <!-- Iteration Execution Controls -->
        <div class="flex items-center gap-2">
          <span class="text-xs text-slate-400">BATCH SIZE:</span>
          @for (n of batchSizes; track n) {
            <button
              (click)="runBatch(n)"
              [disabled]="sim.isRunningMonteCarlo()"
              class="px-2.5 py-1 rounded text-xs font-bold transition-all"
              [class.bg-orange-500]="n === 1000"
              [class.text-white]="n === 1000"
              [class.bg-slate-900]="n !== 1000"
              [class.text-slate-300]="n !== 1000"
              [class.hover:bg-slate-800]="n !== 1000">
              {{ n }} RUNS
            </button>
          }
        </div>
      </div>

      <!-- Execution Progress Bar (if running) -->
      @if (sim.isRunningMonteCarlo()) {
        <div class="bg-slate-900 border border-slate-800 p-3 rounded-lg flex flex-col gap-2">
          <div class="flex justify-between items-center text-xs">
            <span class="text-orange-400 font-bold animate-pulse">EXECUTING STOCHASTIC SOLVER PIPELINE...</span>
            <span class="text-slate-300 font-bold">{{ sim.monteCarloProgress() }}%</span>
          </div>
          <div class="w-full h-2 bg-slate-950 rounded overflow-hidden">
            <div 
              class="h-full bg-gradient-to-r from-orange-500 to-amber-400 transition-all duration-300"
              [style.width.%]="sim.monteCarloProgress()"></div>
          </div>
        </div>
      }

      <!-- High-Level Statistical KPIs -->
      @if (sim.monteCarloResults(); as res) {
        <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3 text-xs">
          <div class="bg-[#0B0F17] border border-slate-800 p-3 rounded-lg">
            <div class="text-[10px] text-slate-500">TOTAL RUNS</div>
            <div class="text-sm font-bold text-white tabular-nums">{{ res.total_runs.toLocaleString() }}</div>
          </div>
          <div class="bg-[#0B0F17] border border-slate-800 p-3 rounded-lg">
            <div class="text-[10px] text-slate-500">ARRIVAL SUCCESS</div>
            <div class="text-sm font-bold text-emerald-400 tabular-nums">{{ res.arrival_success_rate_pct }}%</div>
          </div>
          <div class="bg-[#0B0F17] border border-slate-800 p-3 rounded-lg">
            <div class="text-[10px] text-slate-500">MIN FUEL RESERVE</div>
            <div class="text-sm font-bold text-orange-400 tabular-nums">{{ res.min_fuel_reserve_kg }} kg</div>
          </div>
          <div class="bg-[#0B0F17] border border-slate-800 p-3 rounded-lg">
            <div class="text-[10px] text-slate-500">AVG FUEL RESERVE</div>
            <div class="text-sm font-bold text-slate-200 tabular-nums">{{ res.avg_fuel_reserve_kg }} kg</div>
          </div>
          <div class="bg-[#0B0F17] border border-slate-800 p-3 rounded-lg">
            <div class="text-[10px] text-slate-500">MAX CROSS-TRACK</div>
            <div class="text-sm font-bold text-cyan-400 tabular-nums">{{ res.max_cross_track_deviation_nm }} NM</div>
          </div>
          <div class="bg-[#0B0F17] border border-slate-800 p-3 rounded-lg">
            <div class="text-[10px] text-slate-500">ENVELOPE VIOLATIONS</div>
            <div class="text-sm font-bold text-emerald-400 tabular-nums">{{ res.envelope_violation_count }} (0.00%)</div>
          </div>
        </div>

        <!-- Distributions Grid -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <!-- Fuel Reserve Distribution Histogram -->
          <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-3">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <span class="text-xs font-bold text-orange-400">ARRIVAL FUEL RESERVE DISTRIBUTION (HISTOGRAM)</span>
              <span class="text-[10px] text-slate-400">STATISTICAL CDF</span>
            </div>

            <div class="w-full h-48 bg-slate-950 rounded border border-slate-800 p-2 flex items-center justify-center">
              <svg class="w-full h-full" viewBox="0 0 300 140">
                <!-- Axes -->
                <line x1="30" y1="110" x2="280" y2="110" stroke="#334155" stroke-width="1" />
                <line x1="30" y1="10" x2="30" y2="110" stroke="#334155" stroke-width="1" />
                <text x="110" y="128" class="text-[8px] fill-slate-400 font-mono">FUEL RESERVE BINS</text>
                <text x="5" y="60" class="text-[8px] fill-slate-400 font-mono" transform="rotate(-90 15,60)">FREQUENCY</text>

                <!-- Bars -->
                @for (bin of res.fuel_distribution_bins; track bin.bin; let idx = $index) {
                  @let x = 40 + idx * 38;
                  @let barH = (bin.count / (res.total_runs * 0.45)) * 90;
                  <rect 
                    [attr.x]="x" 
                    [attr.y]="110 - barH" 
                    width="28" 
                    [attr.height]="barH" 
                    fill="#F97316" 
                    fill-opacity="0.8" 
                    rx="1" />
                  <text [attr.x]="x + 2" y="122" class="text-[7px] fill-slate-400 font-mono">{{ bin.bin }}</text>
                  <text [attr.x]="x + 4" [attr.y]="105 - barH" class="text-[7px] fill-orange-300 font-mono font-bold">{{ bin.count }}</text>
                }
              </svg>
            </div>
          </div>

          <!-- Duration Distribution Histogram -->
          <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-3">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <span class="text-xs font-bold text-orange-400">FLIGHT TIME VARIANCE UNDER WIND SHEAR (MINUTES)</span>
              <span class="text-[10px] text-slate-400">GAUSSIAN DISTRIBUTION</span>
            </div>

            <div class="w-full h-48 bg-slate-950 rounded border border-slate-800 p-2 flex items-center justify-center">
              <svg class="w-full h-full" viewBox="0 0 300 140">
                <!-- Axes -->
                <line x1="30" y1="110" x2="280" y2="110" stroke="#334155" stroke-width="1" />
                <line x1="30" y1="10" x2="30" y2="110" stroke="#334155" stroke-width="1" />
                <text x="110" y="128" class="text-[8px] fill-slate-400 font-mono">FLIGHT DURATION</text>

                <!-- Bars -->
                @for (bin of res.duration_distribution_bins; track bin.bin; let idx = $index) {
                  @let x = 40 + idx * 44;
                  @let barH = (bin.count / (res.total_runs * 0.55)) * 90;
                  <rect 
                    [attr.x]="x" 
                    [attr.y]="110 - barH" 
                    width="32" 
                    [attr.height]="barH" 
                    fill="#38BDF8" 
                    fill-opacity="0.8" 
                    rx="1" />
                  <text [attr.x]="x + 2" y="122" class="text-[7px] fill-slate-400 font-mono">{{ bin.bin }}</text>
                  <text [attr.x]="x + 6" [attr.y]="105 - barH" class="text-[7px] fill-sky-300 font-mono font-bold">{{ bin.count }}</text>
                }
              </svg>
            </div>
          </div>
        </div>
      }
    </div>
  `
})
export class ViewMonteCarlo {
  public sim = inject(SimulationService);
  public readonly batchSizes = [10, 100, 1000, 10000] as const;

  public runBatch(iterations: 10 | 100 | 1000 | 10000): void {
    this.sim.runMonteCarloBatch(iterations);
  }
}
