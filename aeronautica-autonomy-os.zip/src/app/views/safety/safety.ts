import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../core/services/simulation.service';

@Component({
  selector: 'app-view-safety',
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full w-full p-4 flex flex-col gap-4 overflow-y-auto select-none font-mono">
      <!-- Section Top Banner -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-[#0B0F17] border border-slate-800 p-4 rounded-lg">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-orange-400 font-bold text-sm">SAFETY ASSURANCE, VERIFICATION MATRIX & FORMAL INVARIANTS</span>
            <span class="text-xs text-amber-400 bg-amber-950/60 border border-amber-500/30 px-2 py-0.5 rounded font-bold">
              SIMULATION RESULT · NOT A CERTIFICATION CLAIM
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Traceability from high-level safety invariants (DO-178C / DO-254 synthetic objectives) through fault injection test evidence.
          </p>
        </div>

        <div class="flex items-center gap-3 text-xs">
          <div class="bg-slate-900 border border-slate-800 px-3 py-1.5 rounded flex items-center gap-2">
            <span class="text-slate-500">REQUIREMENTS VERIFIED:</span>
            <span class="font-bold text-emerald-400">6 / 6 (100% COVERAGE)</span>
          </div>
        </div>
      </div>

      <!-- Requirements Traceability Matrix Table -->
      <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-3">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <span class="text-xs font-bold text-orange-400">SAFETY INVARIANTS TRACEABILITY MATRIX</span>
          <span class="text-[10px] text-slate-400">FORMAL SPECIFICATIONS</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs border-collapse">
            <thead>
              <tr class="border-b border-slate-800 text-[10px] text-slate-500 uppercase tracking-wider">
                <th class="py-2 px-2">Req ID</th>
                <th class="py-2 px-2">Title</th>
                <th class="py-2 px-2">Category</th>
                <th class="py-2 px-2">Target Subsystem</th>
                <th class="py-2 px-2">Verification Method</th>
                <th class="py-2 px-2">Test Case</th>
                <th class="py-2 px-2">Reviewer</th>
                <th class="py-2 px-2 text-right">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
              @for (req of sim.safetyRequirements(); track req.id) {
                <tr class="hover:bg-slate-900/50 transition-colors">
                  <td class="py-2.5 px-2 font-bold text-orange-400 font-mono text-[11px]">{{ req.id }}</td>
                  <td class="py-2.5 px-2 font-semibold text-slate-200">{{ req.title }}</td>
                  <td class="py-2.5 px-2 text-[10px] text-slate-400">{{ req.category }}</td>
                  <td class="py-2.5 px-2 font-mono text-[11px] text-cyan-400">{{ req.target_subsystem }}</td>
                  <td class="py-2.5 px-2 font-mono text-[11px] text-slate-300">{{ req.verification_method }}</td>
                  <td class="py-2.5 px-2 font-mono text-[11px] text-slate-400">{{ req.test_case_id }}</td>
                  <td class="py-2.5 px-2 text-[10px] text-slate-400">{{ req.reviewer.split('(')[0] }}</td>
                  <td class="py-2.5 px-2 text-right text-[10px]">
                    <span class="bg-emerald-950 text-emerald-400 font-bold px-2 py-0.5 rounded border border-emerald-500/40">
                      {{ req.status }}
                    </span>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- Evidence Summaries Cards -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        @for (req of sim.safetyRequirements(); track req.id) {
          <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-3.5 flex flex-col gap-2 text-xs">
            <div class="flex items-center justify-between border-b border-slate-800 pb-1.5">
              <div class="flex items-center gap-2">
                <span class="text-orange-400 font-bold">{{ req.id }}</span>
                <span class="text-slate-200 font-semibold text-[11px]">{{ req.title }}</span>
              </div>
              <span class="text-[9px] text-emerald-400 font-bold">100% PASS</span>
            </div>

            <p class="text-[11px] text-slate-400 leading-relaxed">
              {{ req.description }}
            </p>

            <div class="bg-slate-950 p-2 rounded border border-slate-900 mt-1">
              <span class="text-[9px] text-slate-500 font-bold uppercase">Simulation Verification Evidence</span>
              <p class="text-[10px] text-emerald-300 mt-0.5">
                {{ req.evidence_summary }}
              </p>
            </div>

            <div class="flex items-center justify-between text-[9px] text-slate-500 pt-1">
              <span>Reviewed by: {{ req.reviewer }}</span>
              <span>Last Evaluated: {{ req.last_evaluated }}</span>
            </div>
          </div>
        }
      </div>
    </div>
  `
})
export class ViewSafety {
  public sim = inject(SimulationService);
}
