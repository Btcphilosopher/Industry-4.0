import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../core/services/simulation.service';
import { FlightMap } from '../../components/flight-map/flight-map';
import { AttitudeDirector } from '../../components/attitude-director/attitude-director';

@Component({
  selector: 'app-view-operations',
  imports: [CommonModule, MatIconModule, FlightMap, AttitudeDirector],
  template: `
    <div class="h-full w-full p-3 flex flex-col gap-3 overflow-y-auto">
      <!-- Top Operational Control Room Strip -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-[#0B0F17] border border-slate-800 px-4 py-2 rounded-lg text-xs font-mono select-none">
        <div class="flex items-center gap-4">
          <div class="flex items-center gap-2">
            <span class="text-slate-500">OPERATIONS ROOM:</span>
            <span class="font-bold text-white tracking-wide">FLIGHT OPERATIONS CENTRE</span>
          </div>
          <span class="text-slate-700">|</span>
          <div class="flex items-center gap-2">
            <span class="text-slate-500">ACTIVE SCENARIO:</span>
            <span class="text-orange-400 font-bold">{{ sim.currentScenario().code }} — {{ sim.currentScenario().title }}</span>
          </div>
        </div>

        <div class="flex items-center gap-3">
          <div class="flex items-center gap-1.5 bg-slate-900 px-2.5 py-1 rounded border border-slate-800">
            <span class="text-slate-500">MISSION STATUS:</span>
            <span class="text-emerald-400 font-bold flex items-center gap-1">
              <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              NOMINAL CRUISE
            </span>
          </div>
          <div class="flex items-center gap-1.5 bg-slate-900 px-2.5 py-1 rounded border border-slate-800">
            <span class="text-slate-500">REDUNDANCY:</span>
            <span class="text-cyan-400 font-bold">3 / 3 CHANNELS</span>
          </div>
        </div>
      </div>

      <!-- Main Three-Panel Control Room Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-3 flex-1 min-h-[580px]">
        <!-- LEFT PANEL — AIRCRAFT STATUS & TELEMETRY (3 cols) -->
        <div class="lg:col-span-3 flex flex-col gap-3">
          <!-- Primary Flight Display -->
          <app-attitude-director />

          <!-- Aircraft Status Card -->
          <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-3 flex flex-col gap-2.5 font-mono text-xs">
            <div class="flex items-center justify-between pb-1.5 border-b border-slate-800">
              <span class="text-orange-400 font-bold">AIRCRAFT STATUS</span>
              <span class="text-slate-400 text-[10px]">A-900X STRATOS</span>
            </div>

            <div class="space-y-1.5 text-[11px]">
              <div class="flex justify-between items-center py-0.5 border-b border-slate-800/60">
                <span class="text-slate-500">Type</span>
                <span class="text-slate-200 font-medium">LONG-RANGE AUTONOMOUS TEST</span>
              </div>
              <div class="flex justify-between items-center py-0.5 border-b border-slate-800/60">
                <span class="text-slate-500">Position</span>
                <span class="text-slate-200 tabular-nums">{{ sim.aircraftState().lat }}°N, {{ Math.abs(sim.aircraftState().lon) }}°W</span>
              </div>
              <div class="flex justify-between items-center py-0.5 border-b border-slate-800/60">
                <span class="text-slate-500">Altitude</span>
                <span class="text-slate-200 tabular-nums font-bold">{{ Math.round(sim.aircraftState().alt_ft / 100) * 100 }} ft (FL{{ Math.round(sim.aircraftState().alt_ft / 100) }})</span>
              </div>
              <div class="flex justify-between items-center py-0.5 border-b border-slate-800/60">
                <span class="text-slate-500">Airspeed</span>
                <span class="text-slate-200 tabular-nums font-bold">Mach {{ sim.aircraftState().mach }} ({{ sim.aircraftState().tas_kts }} kts TAS)</span>
              </div>
              <div class="flex justify-between items-center py-0.5 border-b border-slate-800/60">
                <span class="text-slate-500">Heading / Track</span>
                <span class="text-slate-200 tabular-nums">{{ sim.aircraftState().heading_deg }}° / {{ sim.aircraftState().track_deg }}°</span>
              </div>
              <div class="flex justify-between items-center py-0.5 border-b border-slate-800/60">
                <span class="text-slate-500">Vertical Speed</span>
                <span class="tabular-nums" [class.text-emerald-400]="sim.aircraftState().vertical_speed_fpm >= 0" [class.text-amber-400]="sim.aircraftState().vertical_speed_fpm < 0">
                  {{ sim.aircraftState().vertical_speed_fpm >= 0 ? '+' : '' }}{{ sim.aircraftState().vertical_speed_fpm }} ft/min
                </span>
              </div>
              <div class="flex justify-between items-center py-0.5 border-b border-slate-800/60">
                <span class="text-slate-500">Fuel Remaining</span>
                <span class="text-orange-400 font-bold tabular-nums">{{ sim.aircraftState().fuel_pct }}% ({{ sim.aircraftState().fuel_remaining_kg }} kg)</span>
              </div>
              <div class="flex justify-between items-center py-0.5 border-b border-slate-800/60">
                <span class="text-slate-500">Battery Reserve</span>
                <span class="text-cyan-400 font-bold tabular-nums">{{ sim.aircraftState().battery_pct }}%</span>
              </div>
              <div class="flex justify-between items-center py-0.5 border-b border-slate-800/60">
                <span class="text-slate-500">Flight Phase</span>
                <span class="text-emerald-400 font-bold">{{ sim.aircraftState().phase }}</span>
              </div>
              <div class="flex justify-between items-center py-0.5 border-b border-slate-800/60">
                <span class="text-slate-500">Autonomy Mode</span>
                <span class="text-orange-300 font-bold">{{ sim.aircraftState().autonomy_mode }}</span>
              </div>
              <div class="flex justify-between items-center py-0.5">
                <span class="text-slate-500">Human Oversight</span>
                <span class="text-emerald-400 font-bold">AVAILABLE</span>
              </div>
            </div>
          </div>
        </div>

        <!-- CENTRE — LIVE 2D / 3D-LIKE TACTICAL FLIGHT MAP (6 cols) -->
        <div class="lg:col-span-6 flex flex-col gap-2">
          <app-flight-map class="flex-1" />
        </div>

        <!-- RIGHT PANEL — AUTONOMY STATUS & DECISION EXPLAINER (3 cols) -->
        <div class="lg:col-span-3 flex flex-col gap-3">
          <!-- Autonomy Stack Health Matrix -->
          <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-3 flex flex-col gap-2.5 font-mono text-xs">
            <div class="flex items-center justify-between pb-1.5 border-b border-slate-800">
              <span class="text-orange-400 font-bold">AUTONOMY STATUS</span>
              <span class="text-emerald-400 text-[10px] font-bold">LAYER 1-6 NOMINAL</span>
            </div>

            <div class="space-y-1.5 text-[11px]">
              <div class="flex justify-between items-center py-0.5 border-b border-slate-800/60">
                <span class="text-slate-500">Navigation</span>
                <span class="text-emerald-400 font-semibold">NOMINAL</span>
              </div>
              <div class="flex justify-between items-center py-0.5 border-b border-slate-800/60">
                <span class="text-slate-500">Perception</span>
                <span class="text-emerald-400 font-semibold">NOMINAL</span>
              </div>
              <div class="flex justify-between items-center py-0.5 border-b border-slate-800/60">
                <span class="text-slate-500">Weather Interpretation</span>
                <span class="text-emerald-400 font-semibold">NOMINAL</span>
              </div>
              <div class="flex justify-between items-center py-0.5 border-b border-slate-800/60">
                <span class="text-slate-500">Traffic Assessment</span>
                <span class="text-emerald-400 font-semibold">NOMINAL</span>
              </div>
              <div class="flex justify-between items-center py-0.5 border-b border-slate-800/60">
                <span class="text-slate-500">Mission Planning</span>
                <span class="text-emerald-400 font-semibold">NOMINAL</span>
              </div>
              <div class="flex justify-between items-center py-0.5 border-b border-slate-800/60">
                <span class="text-slate-500">Flight-Envelope Monitor</span>
                <span class="text-emerald-400 font-semibold">NOMINAL</span>
              </div>
              <div class="flex justify-between items-center py-0.5 border-b border-slate-800/60">
                <span class="text-slate-500">Redundancy</span>
                <span class="text-cyan-400 font-bold">3 / 3</span>
              </div>
              <div class="flex justify-between items-center py-0.5">
                <span class="text-slate-500">Human Oversight</span>
                <span class="text-emerald-400 font-bold">AVAILABLE</span>
              </div>
            </div>
          </div>

          <!-- Active Autonomy Decision Card with Human Approval Action Bar -->
          @for (dec of sim.decisions(); track dec.id) {
            <div class="bg-[#0F141F] border border-orange-500/40 rounded-lg p-3 flex flex-col gap-2 font-mono text-xs shadow-lg shadow-orange-950/20">
              <div class="flex items-center justify-between pb-1 border-b border-slate-800">
                <div class="flex items-center gap-1.5 text-orange-400 font-bold">
                  <mat-icon class="!text-[14px] !w-3.5 !h-3.5">psychology</mat-icon>
                  <span>DECISION #{{ dec.id }}</span>
                </div>
                <span 
                  class="text-[10px] font-bold px-1.5 py-0.5 rounded"
                  [class.bg-amber-950]="dec.approval_state === 'PENDING'"
                  [class.text-amber-400]="dec.approval_state === 'PENDING'"
                  [class.border]="dec.approval_state === 'PENDING'"
                  [class.border-amber-500]="dec.approval_state === 'PENDING'"
                  [class.bg-emerald-950]="dec.approval_state === 'APPROVED'"
                  [class.text-emerald-400]="dec.approval_state === 'APPROVED'"
                  [class.bg-rose-950]="dec.approval_state === 'REJECTED'"
                  [class.text-rose-400]="dec.approval_state === 'REJECTED'">
                  {{ dec.approval_state }}
                </span>
              </div>

              <!-- Selected Action -->
              <div>
                <div class="text-[10px] text-slate-500 uppercase">Selected Action</div>
                <div class="text-xs font-bold text-orange-300">{{ dec.selected_action }}</div>
              </div>

              <!-- Decision Explanation -->
              <div>
                <div class="text-[10px] text-slate-500 uppercase">Decision Explanation</div>
                <div class="text-[11px] text-slate-300 leading-relaxed">{{ dec.reason_prose }}</div>
              </div>

              <!-- Rejected Alternatives -->
              <div>
                <div class="text-[10px] text-slate-500 uppercase mb-1">Rejected Alternatives</div>
                <div class="space-y-1">
                  @for (alt of dec.rejected_alternatives; track alt.action) {
                    <div class="bg-slate-900/80 border border-slate-800 p-1.5 rounded text-[10px]">
                      <div class="text-rose-400 font-semibold line-through">✖ {{ alt.action }}</div>
                      <div class="text-slate-400 text-[9px] mt-0.5">Reason: {{ alt.rejection_reason }}</div>
                    </div>
                  }
                </div>
              </div>

              <!-- Human Approval Action Bar -->
              @if (dec.approval_state === 'PENDING') {
                <div class="pt-2 border-t border-slate-800 flex flex-col gap-1.5">
                  <div class="flex items-center justify-between text-[10px] text-amber-300">
                    <span>HUMAN APPROVAL REQUIRED</span>
                    <span class="font-bold tabular-nums">TIMEOUT: {{ Math.round(dec.approval_timeout_sec) }}s</span>
                  </div>
                  <div class="grid grid-cols-2 gap-2">
                    <button 
                      (click)="sim.approveDecision(dec.id)"
                      class="flex items-center justify-center gap-1 px-3 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow transition-colors">
                      <mat-icon class="!text-[14px] !w-3.5 !h-3.5">check</mat-icon>
                      <span>APPROVE</span>
                    </button>
                    <button 
                      (click)="sim.rejectDecision(dec.id)"
                      class="flex items-center justify-center gap-1 px-3 py-1.5 rounded bg-rose-600/80 hover:bg-rose-500 text-white font-bold text-xs shadow transition-colors">
                      <mat-icon class="!text-[14px] !w-3.5 !h-3.5">close</mat-icon>
                      <span>REJECT</span>
                    </button>
                  </div>
                </div>
              } @else {
                <div class="text-[10px] text-slate-400 bg-slate-900 p-1.5 rounded border border-slate-800 mt-1">
                  {{ dec.operator_notes || 'Action registered in flight audit trace.' }}
                </div>
              }
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class ViewOperations {
  public sim = inject(SimulationService);
  public Math = Math;
}
