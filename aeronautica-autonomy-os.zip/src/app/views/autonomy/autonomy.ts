import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../core/services/simulation.service';
import { AutonomyMode } from '../../core/models/aeronautica.types';

@Component({
  selector: 'app-view-autonomy',
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full w-full p-4 flex flex-col gap-4 overflow-y-auto select-none font-mono">
      <!-- Autonomy Architecture Top Header -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-[#0B0F17] border border-slate-800 p-4 rounded-lg">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-orange-400 font-bold text-sm">6-LAYER TRANSPARENT AUTONOMY PIPELINE</span>
            <span class="text-xs text-cyan-400 bg-cyan-950/60 border border-cyan-500/30 px-2 py-0.5 rounded font-bold">
              FORMALLY VERIFIED ARCHITECTURE
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Hierarchical autonomy stack: State Estimation → Situation Awareness → Constraint Monitor → Mission Planner → Decision Explainer → Human Supervision.
          </p>
        </div>

        <!-- Autonomy Mode Switcher -->
        <div class="flex items-center gap-1.5 bg-slate-900 border border-slate-800 p-1 rounded text-xs">
          <span class="text-slate-500 text-[11px] px-2">MODE:</span>
          @for (mode of autonomyModes; track mode) {
            <button
              (click)="sim.setAutonomyMode(mode)"
              class="px-2.5 py-1 rounded text-[11px] font-bold transition-all"
              [class.bg-orange-500]="sim.aircraftState().autonomy_mode === mode"
              [class.text-white]="sim.aircraftState().autonomy_mode === mode"
              [class.text-slate-400]="sim.aircraftState().autonomy_mode !== mode"
              [class.hover:text-slate-200]="sim.aircraftState().autonomy_mode !== mode">
              {{ mode.replace('_', ' ') }}
            </button>
          }
        </div>
      </div>

      <!-- Main 6-Layer Architecture Pipeline Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-6 gap-3">
        @for (layer of layers; track layer.index) {
          <button 
            type="button"
            (click)="selectedLayerIndex.set(layer.index)"
            class="text-left cursor-pointer bg-[#0D121C] border rounded-lg p-3 transition-all flex flex-col justify-between focus:outline-none"
            [class.border-orange-500]="selectedLayerIndex() === layer.index"
            [class.bg-orange-950/20]="selectedLayerIndex() === layer.index"
            [class.border-slate-800]="selectedLayerIndex() !== layer.index"
            [class.hover:border-slate-700]="selectedLayerIndex() !== layer.index">
            <div>
              <div class="flex items-center justify-between text-xs pb-1 border-b border-slate-800 w-full">
                <span class="font-bold text-orange-400">LAYER {{ layer.index }}</span>
                <span class="text-[9px] text-emerald-400 font-bold">100% NOMINAL</span>
              </div>
              <div class="text-[11px] font-bold text-white mt-1.5">{{ layer.name }}</div>
              <div class="text-[10px] text-slate-400 mt-1 leading-relaxed">{{ layer.summary }}</div>
            </div>

            <div class="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400 w-full">
              <span>LATENCY: {{ layer.latency }}</span>
              <span class="text-cyan-300 font-bold">{{ layer.rate }}</span>
            </div>
          </button>
        }
      </div>

      <!-- Detailed Layer Inspector & Decision Explainer Trace -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <!-- Left: Selected Layer Diagnostics (6 cols) -->
        <div class="lg:col-span-6 flex flex-col gap-4">
          <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-3">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <span class="text-xs font-bold text-orange-400">LAYER {{ selectedLayer().index }}: {{ selectedLayer().name }} DIAGNOSTICS</span>
              <span class="text-[10px] text-slate-400">FORMAL INVARIANT MONITOR</span>
            </div>

            <div class="space-y-2 text-xs">
              <div class="bg-slate-950 p-2.5 rounded border border-slate-900 flex flex-col gap-1">
                <span class="text-[10px] text-slate-500 uppercase font-bold">Mathematical Core & Algorithm</span>
                <span class="text-slate-200 font-bold">{{ selectedLayer().algorithm }}</span>
                <span class="text-[11px] text-slate-400">{{ selectedLayer().description }}</span>
              </div>

              <!-- Mathematical Equations Reference -->
              <div class="bg-slate-950 p-2.5 rounded border border-slate-900 flex flex-col gap-1">
                <span class="text-[10px] text-slate-500 uppercase font-bold">Active Equation State</span>
                <div class="p-2 bg-slate-900/90 rounded border border-slate-800 font-mono text-[11px] text-orange-300">
                  {{ selectedLayer().mathFormula }}
                </div>
              </div>

              <!-- Real-time metrics -->
              <div class="grid grid-cols-3 gap-2 pt-1">
                <div class="bg-slate-900 p-2 rounded border border-slate-800 text-[11px]">
                  <div class="text-[9px] text-slate-500">CONFIDENCE</div>
                  <div class="font-bold text-emerald-400">99.8%</div>
                </div>
                <div class="bg-slate-900 p-2 rounded border border-slate-800 text-[11px]">
                  <div class="text-[9px] text-slate-500">EXECUTION LOAD</div>
                  <div class="font-bold text-cyan-400">3.4% CPU</div>
                </div>
                <div class="bg-slate-900 p-2 rounded border border-slate-800 text-[11px]">
                  <div class="text-[9px] text-slate-500">REJECTED DRIFTS</div>
                  <div class="font-bold text-slate-200">0 / 10s</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Right: Real-Time Decision Explainer Trace (6 cols) -->
        <div class="lg:col-span-6 flex flex-col gap-4">
          <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-3">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <span class="text-xs font-bold text-orange-400">DECISION EXPLAINER & REJECTED ALTERNATIVES</span>
              <span class="text-[10px] text-amber-400 font-bold">EXPLAINABLE AI AUDIT</span>
            </div>

            @for (dec of sim.decisions(); track dec.id) {
              <div class="bg-slate-950 p-3 rounded border border-slate-800 flex flex-col gap-2 text-xs">
                <div class="flex items-center justify-between pb-1 border-b border-slate-800/80">
                  <span class="text-orange-400 font-bold">{{ dec.selected_action }}</span>
                  <span class="text-[10px] text-slate-400">{{ dec.approval_state }}</span>
                </div>

                <div class="text-[11px] text-slate-300 leading-relaxed">
                  {{ dec.reason_prose }}
                </div>

                <!-- Active constraints table -->
                <div class="mt-1 pt-2 border-t border-slate-900">
                  <div class="text-[10px] text-slate-500 uppercase font-bold mb-1">Active Safety Constraints Enforced</div>
                  <div class="flex flex-wrap gap-1.5">
                    @for (cons of dec.active_constraints; track cons) {
                      <span class="text-[10px] px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-slate-300">
                        {{ cons }}
                      </span>
                    }
                  </div>
                </div>

                <!-- Alternatives Rejection Proofs -->
                <div class="mt-1 pt-2 border-t border-slate-900">
                  <div class="text-[10px] text-slate-500 uppercase font-bold mb-1">Rejected Alternatives Audit</div>
                  <div class="space-y-1.5">
                    @for (alt of dec.rejected_alternatives; track alt.action) {
                      <div class="bg-slate-900/90 border border-slate-800 p-2 rounded text-[11px]">
                        <div class="text-rose-400 font-bold line-through">✖ {{ alt.action }}</div>
                        <div class="text-slate-300 text-[10px] mt-0.5">Constraint Violated: <strong class="text-amber-400">{{ alt.violated_constraint }}</strong></div>
                        <div class="text-slate-400 text-[10px] mt-0.5">{{ alt.rejection_reason }}</div>
                      </div>
                    }
                  </div>
                </div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `
})
export class ViewAutonomy {
  public sim = inject(SimulationService);

  public autonomyModes: AutonomyMode[] = [
    'MANUAL_REFERENCE',
    'AUTOMATION_ASSIST',
    'SUPERVISED_AUTONOMY',
    'HIGH_AUTOMATION_RESEARCH',
    'EMERGENCY_SIMULATION'
  ];

  public selectedLayerIndex = signal<number>(4);

  public layers = [
    {
      index: 1,
      name: 'State Estimation & Fusion',
      summary: 'Extended Kalman Filter fusing multi-channel INS, GNSS, Pitot-Static with 3-sigma innovation voting.',
      latency: '2.5 ms',
      rate: '50 Hz',
      algorithm: '15-State Quaternion Extended Kalman Filter (EKF)',
      description: 'Maintains optimal fused state estimate and covariance matrix P. Rejects noisy, drifting, or spoofed sensor signals.',
      mathFormula: 'x_k = f(x_{k-1}, u_{k-1}) + w_{k-1}  |  K_k = P_k H_k^T (H_k P_k H_k^T + R_k)^{-1}'
    },
    {
      index: 2,
      name: 'Situational Awareness',
      summary: 'Synthetic radar Doppler parsing, 3D convective cell modeling, and TCAS collision envelopes.',
      latency: '8.0 ms',
      rate: '10 Hz',
      algorithm: 'Multi-Object Tracking & Convective Hazard Interceptor',
      description: 'Generates spatial obstacle occupancy grids and closest point of approach (CPA) time matrices.',
      mathFormula: 't_{CPA} = -(\\vec{r} \\cdot \\vec{v}) / ||\\vec{v}||^2  |  d_{CPA} = ||\\vec{r} + \\vec{v} t_{CPA}||'
    },
    {
      index: 3,
      name: 'Constraint Monitor',
      summary: 'Enforces aerodynamic buffet limits, VMO/MMO boundaries, ETOPS fuel reserves, and structural G-load limits.',
      latency: '1.2 ms',
      rate: '50 Hz',
      algorithm: 'Flight Envelope Protection & Invariant Guard',
      description: 'Computes real-time margin vectors. Automatically vetoes high-risk trajectories.',
      mathFormula: 'M \\le M_{MO} (0.84) \\land V \\le V_{MO} (340 kt) \\land \\Delta n_z \\in [-1.0G, +2.5G]'
    },
    {
      index: 4,
      name: 'Mission Planner',
      summary: '4D Trajectory Generator executing continuous A* reroutes and dynamic waypoint insertion.',
      latency: '18.0 ms',
      rate: '2 Hz',
      algorithm: '4D Spatiotemporal A* with Aerodynamic Cost Optimization',
      description: 'Generates fuel-optimal, hazard-free candidate trajectories evaluated against alternate airports.',
      mathFormula: 'J(\\Gamma) = \\int_{t_0}^{t_f} [\\dot{m}_{fuel}(t) + \\lambda_{hazard} C_{risk}(\\vec{x}(t))] dt'
    },
    {
      index: 5,
      name: 'Decision Explainer',
      summary: 'Synthesizes quantitative proof traces, constraints verified, and reasons for rejected alternatives.',
      latency: '4.0 ms',
      rate: 'Event-driven',
      algorithm: 'Counterfactual Trace Generator & Explainability Reasoner',
      description: 'Produces human-readable aerospace rationales explaining why optimal trajectory was chosen over alternatives.',
      mathFormula: 'Proof(Action^*) = \\forall a \\in A \\setminus \\{Action^*\\}: \\exists c \\in Constraints: Violated(a, c)'
    },
    {
      index: 6,
      name: 'Human Supervision Cockpit',
      summary: 'Oversight interface with configurable countdown timeouts, override triggers, and audit logging.',
      latency: '< 1 ms',
      rate: 'Live',
      algorithm: 'Fail-Safe Supervisory Agreement Protocol',
      description: 'Ensures human-in-the-loop or human-on-the-loop authority with fallback to safe holding patterns upon timeout.',
      mathFormula: 'Status = if (Timeout \\le 0) AutoContingencyHold() else AwaitOperatorSignature()'
    }
  ];

  public selectedLayer = () => {
    const idx = this.selectedLayerIndex();
    return this.layers.find(l => l.index === idx) || this.layers[3];
  };
}
