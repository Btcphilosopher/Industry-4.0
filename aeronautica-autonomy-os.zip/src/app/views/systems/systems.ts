import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../core/services/simulation.service';
import { Subsystem, SystemStatus } from '../../core/models/aeronautica.types';

@Component({
  selector: 'app-view-systems',
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full w-full p-4 flex flex-col gap-4 overflow-y-auto select-none font-mono">
      <!-- Top Systems Status Banner -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-[#0B0F17] border border-slate-800 p-4 rounded-lg">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-orange-400 font-bold text-sm">DIGITAL TWIN SUBSYSTEMS & REDUNDANCY ARCHITECTURE</span>
            <span class="text-xs text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded font-bold">
              TRIPLE MODULAR REDUNDANCY (TMR) ACTIVE
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Real-time health monitoring, sensor channel voting, cross-lane discrepancy detection, and automated failover isolation.
          </p>
        </div>

        <div class="flex items-center gap-3 text-xs">
          <div class="bg-slate-900 border border-slate-800 px-3 py-1.5 rounded flex items-center gap-2">
            <span class="text-slate-500">FLEET OVERALL HEALTH:</span>
            <span class="font-bold text-emerald-400">98.6% NOMINAL</span>
          </div>
        </div>
      </div>

      <!-- Category Filter Tabs -->
      <div class="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        @for (cat of categories; track cat) {
          <button
            (click)="selectedCategory.set(cat)"
            class="px-3 py-1.5 rounded text-xs font-semibold transition-colors flex items-center gap-1.5 whitespace-nowrap"
            [class.bg-orange-500]="selectedCategory() === cat"
            [class.text-white]="selectedCategory() === cat"
            [class.bg-slate-900]="selectedCategory() !== cat"
            [class.text-slate-400]="selectedCategory() !== cat"
            [class.hover:bg-slate-800]="selectedCategory() !== cat">
            <span>{{ cat }}</span>
          </button>
        }
      </div>

      <!-- Subsystems Cards Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4">
        @for (sys of filteredSubsystems(); track sys.id) {
          <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-3">
            <div class="flex items-start justify-between border-b border-slate-800 pb-2.5">
              <div>
                <div class="flex items-center gap-2">
                  <span class="text-xs font-bold text-white">{{ sys.name }}</span>
                  <span class="text-[9px] font-bold px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 border border-slate-700">
                    {{ sys.id }}
                  </span>
                </div>
                <div class="text-[10px] text-slate-400 mt-0.5">{{ sys.category }} · {{ sys.redundancy_config }}</div>
              </div>

              <div class="flex items-center gap-2">
                <span 
                  class="text-[10px] font-bold px-2 py-0.5 rounded"
                  [class.bg-emerald-950]="sys.status === 'NOMINAL'"
                  [class.text-emerald-400]="sys.status === 'NOMINAL'"
                  [class.border]="sys.status === 'NOMINAL'"
                  [class.border-emerald-600]="sys.status === 'NOMINAL'"
                  [class.bg-amber-950]="sys.status === 'DEGRADED'"
                  [class.text-amber-400]="sys.status === 'DEGRADED'"
                  [class.bg-rose-950]="sys.status === 'FAILED'"
                  [class.text-rose-400]="sys.status === 'FAILED'">
                  {{ sys.status }}
                </span>
                <span class="text-xs font-bold tabular-nums text-slate-200">{{ sys.health_pct }}%</span>
              </div>
            </div>

            <!-- Operating Parameters -->
            <div class="bg-slate-950 p-2.5 rounded border border-slate-900 flex flex-col gap-1 text-xs">
              <div class="flex justify-between items-center text-[11px]">
                <span class="text-slate-500">Live Operating Value</span>
                <span class="text-orange-400 font-bold tabular-nums">{{ sys.operating_value }}</span>
              </div>
              <div class="flex justify-between items-center text-[10px]">
                <span class="text-slate-500">Nominal Calibration Range</span>
                <span class="text-slate-400">{{ sys.nominal_range }}</span>
              </div>
              @if (sys.active_failure) {
                <div class="text-[10px] text-rose-400 font-bold mt-1 bg-rose-950/40 p-1 rounded border border-rose-900 flex items-center gap-1">
                  <mat-icon class="!text-[12px] !w-3 !h-3">error_outline</mat-icon>
                  <span>Active Fault: {{ sys.active_failure }}</span>
                </div>
              }
            </div>

            <!-- Triple Modular Redundancy Channels -->
            <div class="flex flex-col gap-1.5 pt-1">
              <div class="text-[10px] text-slate-400 font-bold uppercase tracking-wider flex items-center justify-between">
                <span>Redundant Voting Lanes</span>
                <span class="text-[9px] text-slate-500">2-of-3 CONSENSUS REQUIRED</span>
              </div>

              <div class="grid grid-cols-3 gap-2">
                <!-- Channel A -->
                <div class="bg-slate-900/90 border border-slate-800 p-2 rounded flex flex-col gap-1">
                  <div class="flex items-center justify-between text-[10px]">
                    <span class="text-slate-400">CH A</span>
                    <span class="w-2 h-2 rounded-full" [class.bg-emerald-500]="sys.channel_states.channel_a === 'NOMINAL'" [class.bg-amber-500]="sys.channel_states.channel_a !== 'NOMINAL'"></span>
                  </div>
                  <div class="text-[11px] font-bold text-slate-200">{{ sys.channel_states.channel_a }}</div>
                  <button 
                    (click)="toggleChannelStatus(sys, 'channel_a')"
                    class="mt-1 px-1.5 py-0.5 rounded text-[9px] bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors">
                    ISOLATE
                  </button>
                </div>

                <!-- Channel B -->
                <div class="bg-slate-900/90 border border-slate-800 p-2 rounded flex flex-col gap-1">
                  <div class="flex items-center justify-between text-[10px]">
                    <span class="text-slate-400">CH B</span>
                    <span class="w-2 h-2 rounded-full" [class.bg-emerald-500]="sys.channel_states.channel_b === 'NOMINAL'" [class.bg-rose-500]="sys.channel_states.channel_b !== 'NOMINAL'"></span>
                  </div>
                  <div class="text-[11px] font-bold text-slate-200">{{ sys.channel_states.channel_b }}</div>
                  <button 
                    (click)="toggleChannelStatus(sys, 'channel_b')"
                    class="mt-1 px-1.5 py-0.5 rounded text-[9px] bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors">
                    ISOLATE
                  </button>
                </div>

                <!-- Channel C -->
                <div class="bg-slate-900/90 border border-slate-800 p-2 rounded flex flex-col gap-1">
                  <div class="flex items-center justify-between text-[10px]">
                    <span class="text-slate-400">CH C</span>
                    <span class="w-2 h-2 rounded-full" [class.bg-emerald-500]="sys.channel_states.channel_c === 'NOMINAL' || !sys.channel_states.channel_c" [class.bg-amber-500]="sys.channel_states.channel_c && sys.channel_states.channel_c !== 'NOMINAL'"></span>
                  </div>
                  <div class="text-[11px] font-bold text-slate-200">{{ sys.channel_states.channel_c || 'STANDBY' }}</div>
                  <button 
                    (click)="toggleChannelStatus(sys, 'channel_c')"
                    class="mt-1 px-1.5 py-0.5 rounded text-[9px] bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors">
                    ISOLATE
                  </button>
                </div>
              </div>
            </div>
          </div>
        }
      </div>
    </div>
  `
})
export class ViewSystems {
  public sim = inject(SimulationService);

  public categories = ['ALL SYSTEMS', 'AVIONICS', 'PROPULSION', 'ELECTRICAL', 'HYDRAULICS', 'FLIGHT_CONTROLS', 'SENSORS'];
  public selectedCategory = signal<string>('ALL SYSTEMS');

  public filteredSubsystems = () => {
    const cat = this.selectedCategory();
    const subs = this.sim.subsystems();
    if (cat === 'ALL SYSTEMS') return subs;
    return subs.filter(s => s.category === cat);
  };

  public toggleChannelStatus(sys: Subsystem, channel: 'channel_a' | 'channel_b' | 'channel_c'): void {
    const current = sys.channel_states[channel];
    const next: SystemStatus = current === 'NOMINAL' ? 'DEGRADED' : 'NOMINAL';

    this.sim.subsystems.update(subs =>
      subs.map(s => {
        if (s.id === sys.id) {
          const updatedChannels = { ...s.channel_states, [channel]: next };
          const hasDegraded = Object.values(updatedChannels).some(v => v !== 'NOMINAL');
          return {
            ...s,
            channel_states: updatedChannels,
            status: hasDegraded ? 'DEGRADED' : 'NOMINAL',
            health_pct: hasDegraded ? 78 : 100
          };
        }
        return s;
      })
    );

    this.sim.logAudit(
      'HUMAN_OPERATOR',
      'FAILURE_INJECTION',
      `Subsystem ${sys.id} ${channel.toUpperCase()} set to ${next} by operator.`
    );
  }
}
