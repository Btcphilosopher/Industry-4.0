import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../core/services/simulation.service';

@Component({
  selector: 'app-view-flight-dynamics',
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full w-full p-4 flex flex-col gap-4 overflow-y-auto select-none font-mono">
      <!-- Top Section Banner -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-[#0B0F17] border border-slate-800 p-4 rounded-lg">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-orange-400 font-bold text-sm">FLIGHT DYNAMICS, V-N DIAGRAM & ENVELOPE PROTECTION</span>
            <span class="text-xs text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded font-bold">
              PROTECTION ACTIVE (0 EXCEEDANCES)
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Aerodynamic 3DOF/6DOF numerical equations of motion, structural load factor bounds, Mach buffet boundaries, and total energy state.
          </p>
        </div>

        <div class="flex items-center gap-2 text-xs">
          <div class="bg-slate-900 border border-slate-800 px-3 py-1.5 rounded flex items-center gap-2">
            <span class="text-slate-500">G-LOAD:</span>
            <span class="font-bold text-orange-400 tabular-nums">{{ sim.aircraftState().g_load }} G</span>
          </div>
          <div class="bg-slate-900 border border-slate-800 px-3 py-1.5 rounded flex items-center gap-2">
            <span class="text-slate-500">BUFFET MARGIN:</span>
            <span class="font-bold text-emerald-400 tabular-nums">+0.14 M</span>
          </div>
        </div>
      </div>

      <!-- Flight Dynamics Charts Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <!-- V-n Structural Maneuver Diagram (6 cols) -->
        <div class="lg:col-span-6 bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-3">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <span class="text-xs font-bold text-orange-400">V-N FLIGHT ENVELOPE (MANEUVERING LOAD FACTOR)</span>
            <span class="text-[10px] text-slate-400">+2.5G / -1.0G STRUCTURAL LIMITS</span>
          </div>

          <div class="w-full h-56 bg-slate-950 rounded border border-slate-800 p-2 flex items-center justify-center">
            <svg class="w-full h-full" viewBox="0 0 320 180">
              <!-- Axes -->
              <line x1="40" y1="110" x2="300" y2="110" stroke="#334155" stroke-width="1" />
              <line x1="40" y1="20" x2="40" y2="160" stroke="#334155" stroke-width="1" />
              <text x="140" y="125" class="text-[9px] fill-slate-400 font-mono">CALIBRATED AIRSPEED (KTS)</text>
              <text x="10" y="70" class="text-[9px] fill-slate-400 font-mono" transform="rotate(-90 20,70)">LOAD FACTOR n_z (G)</text>

              <!-- V-n Envelope Boundary -->
              <polygon points="40,110 80,40 260,40 290,110 260,150 110,150 40,110" fill="#F97316" fill-opacity="0.12" stroke="#F97316" stroke-width="1.8" />

              <!-- +2.5G / -1.0G limit lines -->
              <line x1="80" y1="40" x2="260" y2="40" stroke="#EF4444" stroke-width="1" stroke-dasharray="2,2" />
              <text x="265" y="44" class="text-[8px] fill-rose-400 font-mono">+2.5G</text>

              <line x1="110" y1="150" x2="260" y2="150" stroke="#EF4444" stroke-width="1" stroke-dasharray="2,2" />
              <text x="265" y="154" class="text-[8px] fill-rose-400 font-mono">-1.0G</text>

              <!-- Current Operating Point -->
              <circle cx="170" cy="108" r="4.5" fill="#10B981" stroke="#FFFFFF" stroke-width="1.5" class="animate-pulse" />
              <text x="180" y="105" class="text-[9px] fill-emerald-400 font-mono font-bold">1.01G &#64; 242 kts</text>
            </svg>
          </div>

          <div class="flex items-center justify-between text-[10px] text-slate-400">
            <span>Vs (Stall): {{ sim.selectedAircraft().specs.stall_speed_kts }} kts</span>
            <span>Va (Maneuver): 215 kts</span>
            <span>Vmo (Max Operating): {{ sim.selectedAircraft().specs.vmo_kts }} kts</span>
          </div>
        </div>

        <!-- High-Altitude Buffet Boundary Chart (6 cols) -->
        <div class="lg:col-span-6 bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-3">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <span class="text-xs font-bold text-orange-400">COFFIN CORNER & BUFFET BOUNDARY (ALTITUDE vs MACH)</span>
            <span class="text-[10px] text-emerald-400 font-bold">SAFE MARGIN (COFFIN CORNER BUFFER 0.18M)</span>
          </div>

          <div class="w-full h-56 bg-slate-950 rounded border border-slate-800 p-2 flex items-center justify-center">
            <svg class="w-full h-full" viewBox="0 0 320 180">
              <!-- Axes -->
              <line x1="40" y1="150" x2="300" y2="150" stroke="#334155" stroke-width="1" />
              <line x1="40" y1="20" x2="40" y2="150" stroke="#334155" stroke-width="1" />
              <text x="140" y="168" class="text-[9px] fill-slate-400 font-mono">MACH NUMBER</text>
              <text x="10" y="90" class="text-[9px] fill-slate-400 font-mono" transform="rotate(-90 20,90)">ALTITUDE (FT)</text>

              <!-- Low-speed stall boundary & High-speed Mach buffet curve forming envelope apex -->
              <path d="M 60,150 Q 140,80 200,30 Q 240,80 280,150" fill="#F97316" fill-opacity="0.12" stroke="#F97316" stroke-width="1.8" />

              <!-- Active point -->
              <circle cx="210" cy="50" r="4.5" fill="#10B981" stroke="#FFFFFF" stroke-width="1.5" />
              <text x="150" y="45" class="text-[9px] fill-emerald-400 font-mono font-bold">FL380 &#64; M 0.78</text>
            </svg>
          </div>

          <div class="flex items-center justify-between text-[10px] text-slate-400">
            <span>Low-Speed Buffet Limit: M 0.64</span>
            <span>High-Speed MMO Limit: M {{ sim.selectedAircraft().specs.mmo }}</span>
            <span>Current Mach: M {{ sim.aircraftState().mach }}</span>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ViewFlightDynamics {
  public sim = inject(SimulationService);
}
