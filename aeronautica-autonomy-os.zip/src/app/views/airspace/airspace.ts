import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../core/services/simulation.service';

@Component({
  selector: 'app-view-airspace',
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full w-full p-4 flex flex-col gap-4 overflow-y-auto select-none font-mono">
      <!-- Section Top Banner -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-[#0B0F17] border border-slate-800 p-4 rounded-lg">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-orange-400 font-bold text-sm">AIRSPACE SEPARATION & TCAS-II CONFLICT RADAR</span>
            <span class="text-xs text-cyan-400 bg-cyan-950/60 border border-cyan-500/30 px-2 py-0.5 rounded font-bold">
              ADS-B / RADAR SURVEILLANCE ACTIVE
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Synthetic traffic monitoring, closest point of approach (CPA) predictors, autonomous vertical/lateral separation maneuvers.
          </p>
        </div>

        <div class="flex items-center gap-2">
          <span class="text-xs text-slate-400 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded">
            TOTAL TRACKS: <strong class="text-white">{{ sim.trafficList().length }} TARGETS</strong>
          </span>
        </div>
      </div>

      <!-- Traffic Targets Radar Scope Table -->
      <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-3">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <span class="text-xs font-bold text-orange-400">SURVEILLANCE RADAR TRACK TABLE</span>
          <span class="text-[10px] text-slate-400">ENROUTE SEPARATION ENVELOPE (5 NM / 1,000 FT)</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs border-collapse">
            <thead>
              <tr class="border-b border-slate-800 text-[10px] text-slate-500 uppercase tracking-wider">
                <th class="py-2 px-2">Callsign</th>
                <th class="py-2 px-2">Squawk</th>
                <th class="py-2 px-2">Category</th>
                <th class="py-2 px-2">Altitude</th>
                <th class="py-2 px-2">Speed</th>
                <th class="py-2 px-2">Heading</th>
                <th class="py-2 px-2">Route</th>
                <th class="py-2 px-2">Horiz Sep</th>
                <th class="py-2 px-2">Vert Sep</th>
                <th class="py-2 px-2">Time to CPA</th>
                <th class="py-2 px-2 text-right">Conflict Level</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
              @for (traf of sim.trafficList(); track traf.id) {
                <tr class="hover:bg-slate-900/50 transition-colors">
                  <td class="py-2 px-2 font-bold text-cyan-300">{{ traf.callsign }}</td>
                  <td class="py-2 px-2 font-mono text-slate-400 text-[11px]">{{ traf.squawk }}</td>
                  <td class="py-2 px-2 text-[10px] text-slate-400">{{ traf.category }}</td>
                  <td class="py-2 px-2 font-mono text-[11px] font-bold text-slate-200">FL{{ Math.round(traf.alt_ft / 100) }}</td>
                  <td class="py-2 px-2 font-mono text-[11px] text-slate-300">{{ traf.tas_kts }} kts</td>
                  <td class="py-2 px-2 font-mono text-[11px] text-slate-300">{{ traf.heading_deg }}°</td>
                  <td class="py-2 px-2 font-mono text-[11px] text-slate-400">{{ traf.origin }} → {{ traf.dest }}</td>
                  <td class="py-2 px-2 font-mono text-[11px] text-slate-200">{{ traf.horizontal_sep_nm }} NM</td>
                  <td class="py-2 px-2 font-mono text-[11px] text-slate-200">{{ traf.vertical_sep_ft }} ft</td>
                  <td class="py-2 px-2 font-mono text-[11px] font-bold text-orange-400">{{ traf.time_to_cpa_sec }}s</td>
                  <td class="py-2 px-2 text-right text-[10px]">
                    <span 
                      class="px-2 py-0.5 rounded font-bold"
                      [class.bg-emerald-950]="traf.conflict_level === 'NONE'"
                      [class.text-emerald-400]="traf.conflict_level === 'NONE'"
                      [class.bg-amber-950]="traf.conflict_level === 'ADVISORY'"
                      [class.text-amber-400]="traf.conflict_level === 'ADVISORY'"
                      [class.border]="traf.conflict_level === 'ADVISORY'"
                      [class.border-amber-500]="traf.conflict_level === 'ADVISORY'">
                      {{ traf.conflict_level }}
                    </span>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class ViewAirspace {
  public sim = inject(SimulationService);
  public Math = Math;
}
