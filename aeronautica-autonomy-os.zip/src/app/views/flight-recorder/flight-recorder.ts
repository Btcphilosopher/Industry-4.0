import { Component, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../core/services/simulation.service';

@Component({
  selector: 'app-view-flight-recorder',
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full w-full p-4 flex flex-col gap-4 overflow-y-auto select-none font-mono">
      <!-- Section Top Banner -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-[#0B0F17] border border-slate-800 p-4 rounded-lg">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-orange-400 font-bold text-sm">DIGITAL FLIGHT DATA RECORDER (DFDR / BLACKBOX)</span>
            <span class="text-xs text-orange-400 bg-orange-950/60 border border-orange-500/30 px-2 py-0.5 rounded font-bold">
              SYNCHRONIZED MULTI-CHANNEL BUFFER
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Deterministic parameter history, flight dynamics wave tracing, event marker correlation, and downloadable flight logs.
          </p>
        </div>

        <div class="flex items-center gap-2">
          <button 
            (click)="exportData('csv')"
            class="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 border border-slate-700 transition-colors flex items-center gap-1.5">
            <mat-icon class="!text-[14px] !w-3.5 !h-3.5 text-orange-400">download</mat-icon>
            <span>EXPORT CSV</span>
          </button>
          <button 
            (click)="exportData('json')"
            class="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 border border-slate-700 transition-colors flex items-center gap-1.5">
            <mat-icon class="!text-[14px] !w-3.5 !h-3.5 text-cyan-400">data_object</mat-icon>
            <span>EXPORT JSON</span>
          </button>
        </div>
      </div>

      <!-- Synchronized Multi-Parameter Waveform Canvas -->
      <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-3">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <div class="flex items-center gap-3">
            <span class="text-xs font-bold text-orange-400">TIME-SERIES PARAMETER WAVEFORMS</span>
            <span class="text-[10px] text-slate-400">{{ frames().length }} RECORDED SAMPLES (2 Hz SAMPLING)</span>
          </div>

          <div class="flex items-center gap-3 text-[10px] text-slate-400">
            <div class="flex items-center gap-1">
              <span class="w-3 h-0.5 bg-orange-500 inline-block"></span>
              <span>ALTITUDE (FL)</span>
            </div>
            <div class="flex items-center gap-1">
              <span class="w-3 h-0.5 bg-cyan-400 inline-block"></span>
              <span>TAS (KTS)</span>
            </div>
            <div class="flex items-center gap-1">
              <span class="w-3 h-0.5 bg-amber-400 inline-block"></span>
              <span>FUEL (%)</span>
            </div>
          </div>
        </div>

        <!-- Waveform SVG Canvas -->
        <div class="w-full h-64 bg-slate-950 rounded border border-slate-800 p-2 flex items-center justify-center">
          <svg class="w-full h-full" viewBox="0 0 600 200" preserveAspectRatio="none">
            <!-- Grid Lines -->
            @for (y of [30, 70, 110, 150, 190]; track y) {
              <line x1="0" [attr.y1]="y" x2="600" [attr.y2]="y" stroke="#1E293B" stroke-width="0.5" stroke-dasharray="2,4" />
            }

            <!-- Altitude Path (Orange) -->
            <path [attr.d]="altPath()" fill="none" stroke="#F97316" stroke-width="2" />

            <!-- Airspeed TAS Path (Cyan) -->
            <path [attr.d]="tasPath()" fill="none" stroke="#38BDF8" stroke-width="1.5" />

            <!-- Fuel % Path (Amber) -->
            <path [attr.d]="fuelPath()" fill="none" stroke="#F59E0B" stroke-width="1.5" />
          </svg>
        </div>

        <!-- Scrubber Range Control -->
        <div class="flex items-center gap-4 pt-1">
          <span class="text-xs text-slate-500">PLAYHEAD:</span>
          <input 
            type="range" 
            min="0" 
            [max]="frames().length - 1" 
            [value]="frames().length - 1"
            class="flex-1 accent-orange-500 cursor-pointer" />
          <span class="text-xs font-bold text-orange-400 tabular-nums">LIVE (T={{ sim.formatSimTime(sim.simTimeSec()) }})</span>
        </div>
      </div>

      <!-- Raw Log Frame Inspector Table -->
      <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-3">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <span class="text-xs font-bold text-orange-400">RECENT TELEMETRY FRAMES (TAIL 10)</span>
          <span class="text-[10px] text-slate-400">DETERMINISTIC REPLAY CAPABLE</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs border-collapse">
            <thead>
              <tr class="border-b border-slate-800 text-[10px] text-slate-500 uppercase tracking-wider">
                <th class="py-1.5 px-2">Sim Time</th>
                <th class="py-1.5 px-2">Lat / Lon</th>
                <th class="py-1.5 px-2">Alt (ft)</th>
                <th class="py-1.5 px-2">TAS (kt)</th>
                <th class="py-1.5 px-2">GS (kt)</th>
                <th class="py-1.5 px-2">Mach</th>
                <th class="py-1.5 px-2">Pitch</th>
                <th class="py-1.5 px-2">Fuel %</th>
                <th class="py-1.5 px-2 text-right">Phase</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
              @for (fr of recentFrames(); track fr.sim_time_sec) {
                <tr class="hover:bg-slate-900/50 transition-colors">
                  <td class="py-1.5 px-2 font-mono text-orange-400 text-[11px]">{{ sim.formatSimTime(fr.sim_time_sec) }}</td>
                  <td class="py-1.5 px-2 font-mono text-slate-300 text-[11px]">{{ fr.lat }}°N, {{ Math.abs(fr.lon) }}°W</td>
                  <td class="py-1.5 px-2 font-mono text-slate-200 font-bold text-[11px]">{{ fr.alt_ft }}</td>
                  <td class="py-1.5 px-2 font-mono text-cyan-300 text-[11px]">{{ fr.tas_kts }}</td>
                  <td class="py-1.5 px-2 font-mono text-slate-300 text-[11px]">{{ fr.gs_kts }}</td>
                  <td class="py-1.5 px-2 font-mono text-slate-200 text-[11px]">M {{ fr.mach }}</td>
                  <td class="py-1.5 px-2 font-mono text-slate-300 text-[11px]">{{ fr.pitch_deg }}°</td>
                  <td class="py-1.5 px-2 font-mono text-amber-400 font-bold text-[11px]">{{ fr.fuel_pct }}%</td>
                  <td class="py-1.5 px-2 text-right text-[10px] text-emerald-400 font-bold">{{ fr.phase }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class ViewFlightRecorder {
  public sim = inject(SimulationService);
  public Math = Math;

  public frames = computed(() => this.sim.telemetryHistory());
  public recentFrames = computed(() => this.sim.telemetryHistory().slice(-10).reverse());

  public altPath = computed(() => {
    const list = this.frames();
    if (list.length < 2) return '';
    return list
      .map((f, i) => {
        const x = (i / (list.length - 1)) * 600;
        const y = 200 - ((f.alt_ft - 35000) / 10000) * 160 - 20;
        return `${i === 0 ? 'M' : 'L'} ${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(' ');
  });

  public tasPath = computed(() => {
    const list = this.frames();
    if (list.length < 2) return '';
    return list
      .map((f, i) => {
        const x = (i / (list.length - 1)) * 600;
        const y = 200 - ((f.tas_kts - 400) / 100) * 160 - 20;
        return `${i === 0 ? 'M' : 'L'} ${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(' ');
  });

  public fuelPath = computed(() => {
    const list = this.frames();
    if (list.length < 2) return '';
    return list
      .map((f, i) => {
        const x = (i / (list.length - 1)) * 600;
        const y = 200 - (f.fuel_pct / 100) * 160 - 20;
        return `${i === 0 ? 'M' : 'L'} ${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(' ');
  });

  public exportData(type: 'csv' | 'json'): void {
    const data = this.frames();
    let blob: Blob;
    let filename: string;

    if (type === 'json') {
      blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      filename = `aeronautica_fdr_${Date.now()}.json`;
    } else {
      const header = 'sim_time_sec,lat,lon,alt_ft,tas_kts,gs_kts,mach,vs_fpm,heading_deg,fuel_pct,phase\n';
      const rows = data.map(d => `${d.sim_time_sec},${d.lat},${d.lon},${d.alt_ft},${d.tas_kts},${d.gs_kts},${d.mach},${d.vs_fpm},${d.heading_deg},${d.fuel_pct},${d.phase}`).join('\n');
      blob = new Blob([header + rows], { type: 'text/csv' });
      filename = `aeronautica_fdr_${Date.now()}.csv`;
    }

    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }
}
