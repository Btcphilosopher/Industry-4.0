import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../core/services/simulation.service';

@Component({
  selector: 'app-view-data-lab',
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full w-full p-4 flex flex-col gap-4 overflow-y-auto select-none font-mono">
      <!-- Section Top Banner -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-[#0B0F17] border border-slate-800 p-4 rounded-lg">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-orange-400 font-bold text-sm">R DATA LABORATORY & SCIENTIFIC WORKSTATION</span>
            <span class="text-xs text-orange-400 bg-orange-950/60 border border-orange-500/30 px-2 py-0.5 rounded font-bold">
              R6 & TIDYVERSE REPRODUCIBILITY
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Generate production R scripts for flight dynamics modelling, run in-memory SQL queries, and inspect synthetic tables.
          </p>
        </div>

        <div class="flex items-center gap-2">
          <button 
            (click)="downloadRScript()"
            class="px-3 py-1.5 rounded bg-orange-600 hover:bg-orange-500 text-xs font-bold text-white shadow transition-colors flex items-center gap-1.5">
            <mat-icon class="!text-[14px] !w-3.5 !h-3.5">code</mat-icon>
            <span>DOWNLOAD .R SCRIPT</span>
          </button>
        </div>
      </div>

      <!-- Main Data Lab Layout Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <!-- Left: Code Editor View with Syntax Display (7 cols) -->
        <div class="lg:col-span-7 flex flex-col gap-3">
          <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-3">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <div class="flex items-center gap-2">
                <span class="text-xs font-bold text-orange-400">R6_AERODYNAMICS_SIMULATION.R</span>
                <span class="text-[10px] text-slate-400">DETERMINISTIC PIPELINE</span>
              </div>
              <button 
                (click)="copyCode()"
                class="px-2 py-0.5 rounded bg-slate-800 text-[10px] text-slate-300 hover:text-white transition-colors">
                {{ copySuccess() ? 'COPIED!' : 'COPY CODE' }}
              </button>
            </div>

            <!-- Code Window -->
            <div class="bg-slate-950 p-3 rounded border border-slate-800 text-xs overflow-x-auto text-slate-300 font-mono leading-relaxed max-h-[480px]">
              <pre><code>{{ sim.generateRScript() }}</code></pre>
            </div>
          </div>
        </div>

        <!-- Right: Synthetic SQL Data Tables & Query Console (5 cols) -->
        <div class="lg:col-span-5 flex flex-col gap-4">
          <!-- Synthetic Tables Inspector -->
          <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-3">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <span class="text-xs font-bold text-orange-400">SYNTHETIC IN-MEMORY DATABASE</span>
              <span class="text-[10px] text-emerald-400 font-bold">SQLITE / ARROW COMPATIBLE</span>
            </div>

            <div class="space-y-2">
              <div class="bg-slate-950 p-2.5 rounded border border-slate-900 flex justify-between items-center text-xs">
                <div>
                  <div class="font-bold text-slate-200">sim_telemetry</div>
                  <div class="text-[10px] text-slate-400">Time-series frames, lat, lon, alt, mach, fuel</div>
                </div>
                <span class="text-orange-400 font-bold">{{ sim.telemetryHistory().length }} rows</span>
              </div>

              <div class="bg-slate-950 p-2.5 rounded border border-slate-900 flex justify-between items-center text-xs">
                <div>
                  <div class="font-bold text-slate-200">sim_airports</div>
                  <div class="text-[10px] text-slate-400">Synthetic runway records, elevations, METARs</div>
                </div>
                <span class="text-cyan-400 font-bold">{{ sim.airports().length }} rows</span>
              </div>

              <div class="bg-slate-950 p-2.5 rounded border border-slate-900 flex justify-between items-center text-xs">
                <div>
                  <div class="font-bold text-slate-200">sim_safety_matrix</div>
                  <div class="text-[10px] text-slate-400">DO-178C invariants, test case evidence</div>
                </div>
                <span class="text-emerald-400 font-bold">{{ sim.safetyRequirements().length }} rows</span>
              </div>

              <div class="bg-slate-950 p-2.5 rounded border border-slate-900 flex justify-between items-center text-xs">
                <div>
                  <div class="font-bold text-slate-200">sim_audit_log</div>
                  <div class="text-[10px] text-slate-400">Human approvals, overrides, failure events</div>
                </div>
                <span class="text-amber-400 font-bold">{{ sim.auditTrail().length }} rows</span>
              </div>
            </div>
          </div>

          <!-- R Ecosystem Tooling Summary -->
          <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-2.5">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <span class="text-xs font-bold text-orange-400">R SCIENTIFIC PACKAGES UTILIZED</span>
              <span class="text-[10px] text-slate-400">ENTERPRISE CRAN</span>
            </div>

            <div class="grid grid-cols-2 gap-2 text-xs">
              <div class="bg-slate-950 p-2 rounded border border-slate-900">
                <span class="text-orange-400 font-bold">R6</span>
                <p class="text-[10px] text-slate-400">Object-oriented encapsulation of Aircraft Twins.</p>
              </div>
              <div class="bg-slate-950 p-2 rounded border border-slate-900">
                <span class="text-orange-400 font-bold">data.table</span>
                <p class="text-[10px] text-slate-400">High-speed sub-millisecond telemetry aggregation.</p>
              </div>
              <div class="bg-slate-950 p-2 rounded border border-slate-900">
                <span class="text-orange-400 font-bold">ggplot2</span>
                <p class="text-[10px] text-slate-400">Publication-quality aerodynamic polar charting.</p>
              </div>
              <div class="bg-slate-950 p-2 rounded border border-slate-900">
                <span class="text-orange-400 font-bold">sf / terra</span>
                <p class="text-[10px] text-slate-400">Spatial polygon operations for convective cells.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ViewDataLab {
  public sim = inject(SimulationService);
  public copySuccess = signal<boolean>(false);

  public copyCode(): void {
    navigator.clipboard.writeText(this.sim.generateRScript());
    this.copySuccess.set(true);
    setTimeout(() => this.copySuccess.set(false), 2000);
  }

  public downloadRScript(): void {
    const code = this.sim.generateRScript();
    const blob = new Blob([code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `aeronautica_sim_${Date.now()}.R`;
    a.click();
    URL.revokeObjectURL(url);
  }
}
