import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../core/services/simulation.service';

@Component({
  selector: 'app-view-perception',
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full w-full p-4 flex flex-col gap-4 overflow-y-auto select-none font-mono">
      <!-- Section Top Banner -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-[#0B0F17] border border-slate-800 p-4 rounded-lg">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-orange-400 font-bold text-sm">PERCEPTION & MULTI-SENSOR KALMAN FUSION</span>
            <span class="text-xs text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded font-bold">
              KALMAN FILTER CONVERGED (σ = 0.12 NM)
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Raw IMU accelerations, multi-constellation GNSS pseudo-ranges, pitot-static pressure, and optical sensor stream fusion.
          </p>
        </div>

        <div class="flex items-center gap-2">
          <button 
            (click)="sim.injectFailure('FAIL_GPS_NOISE')"
            class="px-3 py-1.5 rounded bg-amber-950/60 border border-amber-600/50 text-xs font-bold text-amber-300 hover:bg-amber-900/60 transition-colors flex items-center gap-1.5">
            <mat-icon class="!text-[14px] !w-3.5 !h-3.5">sensors_off</mat-icon>
            <span>INJECT GNSS NOISE BURST</span>
          </button>
        </div>
      </div>

      <!-- Sensor Channels Live Table -->
      <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-3">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <span class="text-xs font-bold text-orange-400">ACTIVE SENSOR CHANNELS & VOTING HEALTH</span>
          <span class="text-[10px] text-slate-400">{{ sim.sensorChannels().length }} INDEPENDENT SENSORS ONLINE</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs border-collapse">
            <thead>
              <tr class="border-b border-slate-800 text-[10px] text-slate-500 uppercase tracking-wider">
                <th class="py-2 px-2">ID</th>
                <th class="py-2 px-2">Sensor Name</th>
                <th class="py-2 px-2">Type</th>
                <th class="py-2 px-2">Lane</th>
                <th class="py-2 px-2">Raw Reading</th>
                <th class="py-2 px-2">Fused State</th>
                <th class="py-2 px-2">Noise (σ)</th>
                <th class="py-2 px-2">Latency</th>
                <th class="py-2 px-2">Confidence</th>
                <th class="py-2 px-2 text-right">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
              @for (sens of sim.sensorChannels(); track sens.id) {
                <tr class="hover:bg-slate-900/50 transition-colors">
                  <td class="py-2 px-2 font-mono text-slate-400 text-[11px]">{{ sens.id }}</td>
                  <td class="py-2 px-2 font-bold text-slate-200">{{ sens.name }}</td>
                  <td class="py-2 px-2 text-[10px] text-slate-400">{{ sens.type }}</td>
                  <td class="py-2 px-2 font-bold text-cyan-400">CH-{{ sens.channel }}</td>
                  <td class="py-2 px-2 font-mono text-[11px] text-slate-300">{{ sens.value_raw }} {{ sens.unit }}</td>
                  <td class="py-2 px-2 font-mono text-[11px] font-bold text-orange-400">{{ sens.value_filtered }} {{ sens.unit }}</td>
                  <td class="py-2 px-2 font-mono text-[11px] text-slate-400">{{ sens.noise_sigma }}</td>
                  <td class="py-2 px-2 font-mono text-[11px] text-slate-400">{{ sens.latency_ms }} ms</td>
                  <td class="py-2 px-2 font-mono text-[11px] font-bold" [class.text-emerald-400]="sens.confidence_pct > 90" [class.text-amber-400]="sens.confidence_pct <= 90">
                    {{ sens.confidence_pct }}%
                  </td>
                  <td class="py-2 px-2 text-right text-[10px]">
                    <span 
                      class="px-1.5 py-0.5 rounded font-bold"
                      [class.bg-emerald-950]="sens.status === 'NOMINAL'"
                      [class.text-emerald-400]="sens.status === 'NOMINAL'"
                      [class.bg-rose-950]="sens.status !== 'NOMINAL'"
                      [class.text-rose-400]="sens.status !== 'NOMINAL'">
                      {{ sens.status }}
                    </span>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- Sensor Fusion Visualizer & Covariance Ellipse -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <div class="lg:col-span-6 bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-3">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <span class="text-xs font-bold text-orange-400">KALMAN ESTIMATION COVARIANCE BOUND (P)</span>
            <span class="text-[10px] text-emerald-400 font-bold">ELLIPSE BOUNDED</span>
          </div>

          <div class="w-full h-48 bg-slate-950 rounded border border-slate-800 p-2 flex items-center justify-center">
            <svg class="w-full h-full" viewBox="0 0 300 160">
              <!-- Grid -->
              <line x1="150" y1="10" x2="150" y2="150" stroke="#1E293B" stroke-width="1" />
              <line x1="10" y1="80" x2="290" y2="80" stroke="#1E293B" stroke-width="1" />
              
              <!-- Covariance 3-sigma ellipse -->
              <ellipse cx="150" cy="80" rx="60" ry="35" fill="#F97316" fill-opacity="0.1" stroke="#F97316" stroke-width="1.5" stroke-dasharray="3,3" />
              <!-- 1-sigma core -->
              <ellipse cx="150" cy="80" rx="25" ry="15" fill="#F97316" fill-opacity="0.25" stroke="#F97316" stroke-width="2" />
              
              <!-- Sensor raw points -->
              <circle cx="145" cy="78" r="3" fill="#38BDF8" />
              <text x="148" y="74" class="text-[8px] fill-sky-300 font-mono">IMU A</text>

              <circle cx="158" cy="84" r="3" fill="#38BDF8" />
              <text x="162" y="88" class="text-[8px] fill-sky-300 font-mono">GNSS A</text>

              <circle cx="152" cy="79" r="3" fill="#38BDF8" />
              <text x="156" y="74" class="text-[8px] fill-sky-300 font-mono">IMU B</text>

              <!-- Optimal fused center -->
              <circle cx="150" cy="80" r="4" fill="#F97316" stroke="#FFFFFF" stroke-width="1.5" />
              <text x="150" y="105" class="text-[9px] fill-orange-400 font-mono font-bold text-center" text-anchor="middle">FUSED STATE (x̂)</text>
            </svg>
          </div>
          <div class="flex items-center justify-between text-[10px] text-slate-400">
            <span>Lateral Uncertainty (1σ): 0.04 NM</span>
            <span>Vertical Uncertainty (1σ): 12 ft</span>
            <span>Voting Consensus: 3 / 3</span>
          </div>
        </div>

        <div class="lg:col-span-6 bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-3">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <span class="text-xs font-bold text-orange-400">SENSOR SUITE SATELLITE & RADAR TELEMETRY</span>
            <span class="text-[10px] text-slate-400">MULTI-SPECTRAL</span>
          </div>

          <div class="relative w-full h-48 bg-slate-950 rounded border border-slate-800 overflow-hidden group">
            <img 
              src="/src/assets/images/aero_sensor_fusion_1790147011099.jpg" 
              alt="Perception Radar Fusion" 
              referrerpolicy="no-referrer"
              class="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-500" />
            <div class="absolute inset-0 bg-gradient-to-t from-[#0B0F17] via-transparent to-transparent"></div>
            <div class="absolute bottom-2 left-3 right-3 flex items-center justify-between text-[10px] text-slate-200">
              <span class="text-orange-400 font-bold">FORWARD OPTICAL & LIDAR POINT CLOUD</span>
              <span class="bg-black/60 px-2 py-0.5 rounded border border-slate-700">12k PTS/SEC</span>
            </div>
          </div>
          <p class="text-[11px] text-slate-300">
            Active synthetic LiDAR scans the forward flight corridor for clear-air turbulence, non-cooperative aerial targets, and high-altitude microbursts.
          </p>
        </div>
      </div>
    </div>
  `
})
export class ViewPerception {
  public sim = inject(SimulationService);
}
