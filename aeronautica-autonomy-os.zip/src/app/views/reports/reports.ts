import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../core/services/simulation.service';

@Component({
  selector: 'app-view-reports',
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full w-full p-4 flex flex-col gap-4 overflow-y-auto select-none font-mono">
      <!-- Section Top Banner -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-[#0B0F17] border border-slate-800 p-4 rounded-lg">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-orange-400 font-bold text-sm">FLIGHT TEST REPORTS & AUDIT TRAIL EVIDENCE</span>
            <span class="text-xs text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded font-bold">
              AUDIT TRAIL COMPLETE & IMMUTABLE
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Complete flight test event dossier, operator interactions, autonomy mode transitions, and formal verification evidence.
          </p>
        </div>

        <div class="flex items-center gap-2">
          <button 
            (click)="printReport()"
            class="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 border border-slate-700 transition-colors flex items-center gap-1.5">
            <mat-icon class="!text-[14px] !w-3.5 !h-3.5 text-orange-400">print</mat-icon>
            <span>PRINT DOSSIER</span>
          </button>
        </div>
      </div>

      <!-- Formal Flight Test Executive Summary Card -->
      <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-5 flex flex-col gap-3 text-xs">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <div class="text-sm font-bold text-white">FLIGHT TEST CAMPAIGN SUMMARY: {{ sim.currentScenario().code }}</div>
            <div class="text-[11px] text-slate-400 mt-0.5">Aircraft: {{ sim.selectedAircraft().name }} ({{ sim.selectedAircraft().id }}) · Flight: {{ sim.flightPlan().flight_number }}</div>
          </div>
          <div class="text-right">
            <div class="text-[10px] text-emerald-400 font-bold bg-emerald-950 px-2 py-0.5 rounded border border-emerald-600/40">PASSED ALL SIMULATION INVARIANTS</div>
            <div class="text-[9px] text-slate-500 mt-1">SIMULATION RESULT · NOT A CERTIFICATION CLAIM</div>
          </div>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 py-2">
          <div class="bg-slate-950 p-2.5 rounded border border-slate-900">
            <div class="text-[10px] text-slate-500">PLANNED CRUISE</div>
            <div class="font-bold text-slate-200 mt-0.5">FL380 / M 0.78</div>
          </div>
          <div class="bg-slate-950 p-2.5 rounded border border-slate-900">
            <div class="text-[10px] text-slate-500">BLOCK FUEL</div>
            <div class="font-bold text-slate-200 mt-0.5">{{ sim.flightPlan().block_fuel_kg.toLocaleString() }} kg</div>
          </div>
          <div class="bg-slate-950 p-2.5 rounded border border-slate-900">
            <div class="text-[10px] text-slate-500">ARRIVAL FUEL MARGIN</div>
            <div class="font-bold text-emerald-400 mt-0.5">+{{ sim.aircraftState().fuel_remaining_kg }} kg ({{ sim.aircraftState().fuel_pct }}%)</div>
          </div>
          <div class="bg-slate-950 p-2.5 rounded border border-slate-900">
            <div class="text-[10px] text-slate-500">MAX G-LOAD RECORDED</div>
            <div class="font-bold text-slate-200 mt-0.5">{{ sim.aircraftState().g_load }} G (LIMIT 2.5G)</div>
          </div>
        </div>
      </div>

      <!-- Immutable Audit Trail Table -->
      <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-3">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <span class="text-xs font-bold text-orange-400">IMMUTABLE AUDIT TRAIL EVENT LOG</span>
          <span class="text-[10px] text-slate-400">{{ sim.auditTrail().length }} SYSTEM EVENTS REGISTERED</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs border-collapse">
            <thead>
              <tr class="border-b border-slate-800 text-[10px] text-slate-500 uppercase tracking-wider">
                <th class="py-2 px-2">Sim Time</th>
                <th class="py-2 px-2">Timestamp (ISO)</th>
                <th class="py-2 px-2">Actor</th>
                <th class="py-2 px-2">Action Type</th>
                <th class="py-2 px-2">Details</th>
                <th class="py-2 px-2 text-right">Seed</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
              @for (entry of sim.auditTrail(); track entry.id) {
                <tr class="hover:bg-slate-900/50 transition-colors">
                  <td class="py-2 px-2 font-mono text-orange-400 text-[11px]">{{ sim.formatSimTime(entry.timestamp_sim_sec) }}</td>
                  <td class="py-2 px-2 font-mono text-slate-400 text-[10px]">{{ entry.timestamp_iso }}</td>
                  <td class="py-2 px-2 font-bold text-cyan-400">{{ entry.actor }}</td>
                  <td class="py-2 px-2">
                    <span class="text-[10px] bg-slate-800 px-1.5 py-0.5 rounded text-slate-300 font-mono">
                      {{ entry.action_type }}
                    </span>
                  </td>
                  <td class="py-2 px-2 text-slate-300 text-[11px]">{{ entry.details }}</td>
                  <td class="py-2 px-2 font-mono text-right text-slate-500 text-[11px]">{{ entry.scenario_seed }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class ViewReports {
  public sim = inject(SimulationService);

  public printReport(): void {
    window.print();
  }
}
