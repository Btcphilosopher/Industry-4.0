import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../core/services/simulation.service';

@Component({
  selector: 'app-view-navigation',
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full w-full p-4 flex flex-col gap-4 overflow-y-auto select-none font-mono">
      <!-- Top Flight Plan Summary Bar -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-[#0B0F17] border border-slate-800 p-4 rounded-lg">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-orange-400 font-bold text-sm">4D FLIGHT PLANNER & DIVERSION ENGINE</span>
            <span class="text-xs text-slate-400 bg-slate-800 px-2 py-0.5 rounded">RNP 0.3 RNAV/VNAV</span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            4D spatiotemporal waypoint sequences, altitude step-climb profiles, oceanic NAT tracks, and ETOPS alternate reachability.
          </p>
        </div>

        <div class="flex items-center gap-3 text-xs">
          <div class="bg-slate-900 border border-slate-800 px-3 py-1.5 rounded flex items-center gap-2">
            <span class="text-slate-500">ORIGIN / DEST:</span>
            <span class="font-bold text-cyan-400">{{ sim.flightPlan().origin_icao }} → {{ sim.flightPlan().dest_icao }}</span>
          </div>
          <div class="bg-slate-900 border border-slate-800 px-3 py-1.5 rounded flex items-center gap-2">
            <span class="text-slate-500">ALTERNATE:</span>
            <span class="font-bold text-amber-400">{{ sim.flightPlan().alternate_icao }} (REYKJAVIK)</span>
          </div>
        </div>
      </div>

      <!-- Main Navigation Layout Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <!-- Left: Waypoint Sequence Table (7 cols) -->
        <div class="lg:col-span-7 flex flex-col gap-3">
          <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-3">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <span class="text-xs font-bold text-orange-400">ACTIVE WAYPOINT SEQUENCE</span>
              <span class="text-[10px] text-slate-400">{{ sim.flightPlan().route.length }} FIXES LOADED</span>
            </div>

            <div class="overflow-x-auto">
              <table class="w-full text-left text-xs border-collapse">
                <thead>
                  <tr class="border-b border-slate-800 text-[10px] text-slate-500 uppercase tracking-wider">
                    <th class="py-2 px-2">Seq</th>
                    <th class="py-2 px-2">Waypoint</th>
                    <th class="py-2 px-2">Type</th>
                    <th class="py-2 px-2">Coordinates</th>
                    <th class="py-2 px-2">Altitude</th>
                    <th class="py-2 px-2">Speed</th>
                    <th class="py-2 px-2 text-right">Status</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-slate-800/60">
                  @for (wp of sim.flightPlan().route; track wp.id; let idx = $index) {
                    <tr 
                      class="transition-colors"
                      [class.bg-orange-950/30]="idx === sim.aircraftState().active_waypoint_index"
                      [class.text-orange-300]="idx === sim.aircraftState().active_waypoint_index"
                      [class.hover:bg-slate-900/60]="idx !== sim.aircraftState().active_waypoint_index">
                      <td class="py-2 px-2 font-mono text-[11px] text-slate-500">{{ idx + 1 }}</td>
                      <td class="py-2 px-2 font-bold flex items-center gap-1.5">
                        @if (idx === sim.aircraftState().active_waypoint_index) {
                          <span class="w-1.5 h-1.5 rounded-full bg-orange-500 animate-ping"></span>
                        }
                        <span>{{ wp.name }}</span>
                      </td>
                      <td class="py-2 px-2 text-[10px] text-slate-400">{{ wp.type }}</td>
                      <td class="py-2 px-2 font-mono text-[11px] text-slate-300">{{ wp.lat }}°N, {{ Math.abs(wp.lon) }}°W</td>
                      <td class="py-2 px-2 font-mono text-[11px] font-bold text-slate-200">FL{{ Math.round(wp.alt_restriction_ft / 100) }}</td>
                      <td class="py-2 px-2 font-mono text-[11px] text-slate-300">{{ wp.speed_restriction_kts }} kts</td>
                      <td class="py-2 px-2 text-right text-[10px]">
                        @if (idx < sim.aircraftState().active_waypoint_index) {
                          <span class="text-slate-500">OVERFLOWN</span>
                        } @else if (idx === sim.aircraftState().active_waypoint_index) {
                          <span class="text-orange-400 font-bold bg-orange-950/80 px-1.5 py-0.5 rounded border border-orange-500/40">TO (ACTIVE)</span>
                        } @else {
                          <span class="text-slate-400">NEXT</span>
                        }
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>

            <!-- Altitude Profile Visualization -->
            <div class="mt-2 pt-3 border-t border-slate-800 flex flex-col gap-1.5">
              <div class="flex items-center justify-between text-xs">
                <span class="text-orange-400 font-bold">VNAV VERTICAL ALTITUDE PROFILE</span>
                <span class="text-[10px] text-slate-400">CRUISE STEP-CLIMB FL380</span>
              </div>

              <div class="w-full h-32 bg-slate-950 rounded border border-slate-800 p-2 flex items-center justify-center">
                <svg class="w-full h-full" viewBox="0 0 400 100">
                  <!-- Axis -->
                  <line x1="30" y1="85" x2="380" y2="85" stroke="#334155" stroke-width="1" />
                  <line x1="30" y1="10" x2="30" y2="85" stroke="#334155" stroke-width="1" />
                  <text x="5" y="20" class="text-[8px] fill-slate-500 font-mono">FL400</text>
                  <text x="5" y="85" class="text-[8px] fill-slate-500 font-mono">GND</text>

                  <!-- Climb, Cruise, Descent Profile Path -->
                  <path d="M 35,85 L 80,25 L 290,25 L 340,65 L 375,85" fill="none" stroke="#F97316" stroke-width="2" />
                  <path d="M 35,85 L 80,25 L 290,25 L 340,65 L 375,85 L 375,85 L 35,85 Z" fill="#F97316" fill-opacity="0.08" />

                  <!-- Current Aircraft Position on Profile -->
                  <circle cx="160" cy="25" r="4" fill="#F97316" stroke="#FFFFFF" stroke-width="1.5" class="animate-pulse" />
                  <text x="170" y="22" class="text-[9px] fill-orange-300 font-mono font-bold">A-900X (FL380)</text>
                </svg>
              </div>
            </div>
          </div>
        </div>

        <!-- Right: Airport Diversion Matrix & ETOPS Fuel Audit (5 cols) -->
        <div class="lg:col-span-5 flex flex-col gap-4">
          <!-- Synthetic Airport Diversion Matrix -->
          <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-3">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <span class="text-xs font-bold text-orange-400">SYNTHETIC DIVERSION AIRPORTS</span>
              <span class="text-[10px] text-emerald-400 font-bold">ALL AVAILABLE</span>
            </div>

            <div class="space-y-2">
              @for (apt of sim.airports(); track apt.id) {
                <div class="bg-slate-950 p-2.5 rounded border border-slate-800/80 flex flex-col gap-1 text-xs">
                  <div class="flex items-center justify-between">
                    <div class="flex items-center gap-2">
                      <span class="font-bold text-cyan-400">{{ apt.icao }}</span>
                      <span class="text-[11px] text-slate-200">{{ apt.name }}</span>
                    </div>
                    <span 
                      class="text-[9px] font-bold px-1.5 py-0.5 rounded"
                      [class.bg-emerald-950]="apt.diversion_suitability === 'PRIMARY'"
                      [class.text-emerald-400]="apt.diversion_suitability === 'PRIMARY'"
                      [class.bg-slate-800]="apt.diversion_suitability === 'SUITABLE'"
                      [class.text-slate-300]="apt.diversion_suitability === 'SUITABLE'">
                      {{ apt.diversion_suitability }}
                    </span>
                  </div>

                  <div class="text-[10px] text-slate-400 flex items-center justify-between pt-0.5">
                    <span>Elevation: {{ apt.elevation_ft }} ft</span>
                    <span>Runways: {{ apt.runways.length }} ({{ apt.runways[0].length_m }}m {{ apt.runways[0].surface }})</span>
                  </div>

                  <div class="text-[9px] text-slate-500 font-mono mt-0.5">
                    METAR: {{ apt.metar.raw }}
                  </div>
                </div>
              }
            </div>
          </div>

          <!-- Fuel Reserves & ETOPS Contingency Status -->
          <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-2.5">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <span class="text-xs font-bold text-orange-400">FUEL & ETOPS CONTINGENCY AUDIT</span>
              <span class="text-[10px] text-emerald-400 font-bold">COMPLIANT</span>
            </div>

            <div class="space-y-1.5 text-xs">
              <div class="flex justify-between items-center py-0.5 border-b border-slate-800/60">
                <span class="text-slate-400">Total Fuel Remaining</span>
                <span class="text-orange-400 font-bold tabular-nums">{{ sim.aircraftState().fuel_remaining_kg }} kg ({{ sim.aircraftState().fuel_pct }}%)</span>
              </div>
              <div class="flex justify-between items-center py-0.5 border-b border-slate-800/60">
                <span class="text-slate-400">Required Reserve at Destination</span>
                <span class="text-slate-200 font-bold tabular-nums">3,200 kg</span>
              </div>
              <div class="flex justify-between items-center py-0.5 border-b border-slate-800/60">
                <span class="text-slate-400">Contingency Buffer Margin</span>
                <span class="text-emerald-400 font-bold tabular-nums">+1,420 kg (48 min)</span>
              </div>
              <div class="flex justify-between items-center py-0.5">
                <span class="text-slate-400">Alternate REYKJAVIK (BIRK) Reachable</span>
                <span class="text-emerald-400 font-bold">YES · 100% CONFIDENCE</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ViewNavigation {
  public sim = inject(SimulationService);
  public Math = Math;
}
