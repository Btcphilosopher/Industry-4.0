import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../core/services/simulation.service';

@Component({
  selector: 'app-view-failures',
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full w-full p-4 flex flex-col gap-4 overflow-y-auto select-none font-mono">
      <!-- Section Top Banner -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-[#0B0F17] border border-slate-800 p-4 rounded-lg">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-orange-400 font-bold text-sm">FAULT INJECTION LABORATORY & DEGRADATION SIMULATOR</span>
            <span class="text-xs text-rose-400 bg-rose-950/60 border border-rose-500/30 px-2 py-0.5 rounded font-bold">
              SYSTEM ISOLATION & FAILOVER ENGINE
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Simulate realistic component degradation, sensor spoofing, pitot dynamic icing, single-engine flameout, and hydraulic pressure loss.
          </p>
        </div>

        <div class="flex items-center gap-2">
          <button 
            (click)="clearAllFailures()"
            class="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 transition-colors flex items-center gap-1.5 border border-slate-700">
            <mat-icon class="!text-[14px] !w-3.5 !h-3.5 text-slate-400">restart_alt</mat-icon>
            <span>CLEAR ALL FAULTS</span>
          </button>
        </div>
      </div>

      <!-- Failure Cards Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        @for (fail of sim.injectedFailures(); track fail.id) {
          <div 
            class="bg-[#0B0F17] border rounded-lg p-4 flex flex-col justify-between gap-3 transition-all"
            [class.border-rose-500]="fail.is_active"
            [class.bg-rose-950/20]="fail.is_active"
            [class.border-slate-800]="!fail.is_active">
            <div>
              <div class="flex items-center justify-between border-b border-slate-800 pb-2">
                <span class="text-xs font-bold" [class.text-rose-400]="fail.is_active" [class.text-white]="!fail.is_active">
                  {{ fail.name }}
                </span>
                <span 
                  class="text-[9px] font-bold px-1.5 py-0.5 rounded uppercase"
                  [class.bg-rose-950]="fail.severity === 'HAZARDOUS' || fail.severity === 'CATASTROPHIC_SIM'"
                  [class.text-rose-400]="fail.severity === 'HAZARDOUS' || fail.severity === 'CATASTROPHIC_SIM'"
                  [class.bg-amber-950]="fail.severity === 'MAJOR'"
                  [class.text-amber-400]="fail.severity === 'MAJOR'">
                  {{ fail.severity }}
                </span>
              </div>

              <div class="text-[10px] text-cyan-400 mt-1">Target: {{ fail.target_subsystem }} · {{ fail.category }}</div>

              <p class="text-[11px] text-slate-300 mt-2 leading-relaxed">
                {{ fail.description }}
              </p>

              <div class="bg-slate-950 p-2 rounded border border-slate-900 mt-2 text-[10px]">
                <span class="text-slate-500 uppercase font-bold">Autonomy Recovery Action:</span>
                <p class="text-emerald-400 mt-0.5">{{ fail.recovery_action }}</p>
              </div>
            </div>

            <div class="pt-2 border-t border-slate-800 flex items-center justify-between">
              <span class="text-[10px] font-mono" [class.text-rose-400]="fail.is_active" [class.text-slate-500]="!fail.is_active">
                {{ fail.is_active ? '● FAULT ACTIVE' : '○ INACTIVE' }}
              </span>

              @if (!fail.is_active) {
                <button 
                  (click)="sim.injectFailure(fail.id)"
                  class="px-3 py-1 rounded bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow transition-colors flex items-center gap-1">
                  <mat-icon class="!text-[14px] !w-3.5 !h-3.5">bolt</mat-icon>
                  <span>INJECT FAULT</span>
                </button>
              } @else {
                <button 
                  (click)="sim.clearFailure(fail.id)"
                  class="px-3 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 transition-colors flex items-center gap-1">
                  <mat-icon class="!text-[14px] !w-3.5 !h-3.5">check_circle</mat-icon>
                  <span>RESOLVE</span>
                </button>
              }
            </div>
          </div>
        }
      </div>
    </div>
  `
})
export class ViewFailures {
  public sim = inject(SimulationService);

  public clearAllFailures(): void {
    this.sim.injectedFailures().forEach(f => {
      if (f.is_active) this.sim.clearFailure(f.id);
    });
  }
}
