import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../core/services/simulation.service';
import { AircraftConfig } from '../../core/models/aeronautica.types';

@Component({
  selector: 'app-view-aircraft',
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full w-full p-4 flex flex-col gap-4 overflow-y-auto select-none font-mono">
      <!-- Section Header -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-[#0B0F17] border border-slate-800 p-4 rounded-lg">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-orange-400 font-bold text-sm">AIRCRAFT DIGITAL TWIN FLEET</span>
            <span class="text-xs text-slate-400 bg-slate-800 px-2 py-0.5 rounded">R6 DYNAMICS MODELLED</span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Aerodynamic configurations, structural envelopes, mass/balance polars, and multi-redundant propulsion systems.
          </p>
        </div>

        <div class="flex items-center gap-2">
          <span class="text-xs text-slate-500">SELECTED ACTIVE TWIN:</span>
          <span class="text-xs font-bold text-orange-400 bg-orange-950/60 border border-orange-500/40 px-2.5 py-1 rounded">
            {{ sim.selectedAircraft().id }} — {{ sim.selectedAircraft().name }}
          </span>
        </div>
      </div>

      <!-- Aircraft Fleet Cards Selection Grid -->
      <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-3">
        @for (ac of sim.aircraftFleet(); track ac.id) {
          <button 
            type="button"
            (click)="selectAircraft(ac)"
            class="text-left cursor-pointer bg-[#0D121C] border rounded-lg p-3 transition-all flex flex-col justify-between focus:outline-none"
            [class.border-orange-500]="sim.selectedAircraft().id === ac.id"
            [class.bg-orange-950/20]="sim.selectedAircraft().id === ac.id"
            [class.border-slate-800]="sim.selectedAircraft().id !== ac.id"
            [class.hover:border-slate-700]="sim.selectedAircraft().id !== ac.id">
            <div>
              <div class="flex items-center justify-between text-xs pb-1 border-b border-slate-800">
                <span class="font-bold" [class.text-orange-400]="sim.selectedAircraft().id === ac.id" [class.text-slate-200]="sim.selectedAircraft().id !== ac.id">{{ ac.id }}</span>
                <span class="text-[9px] text-slate-400">{{ ac.specs.engines_count }} ENG</span>
              </div>
              <div class="text-[11px] font-semibold text-white mt-1.5 line-clamp-1">{{ ac.name }}</div>
              <div class="text-[10px] text-slate-400 mt-0.5">{{ ac.category }}</div>
            </div>

            <div class="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400 w-full">
              <span>MTOW {{ Math.round(ac.specs.mtow_kg / 1000) }}t</span>
              <span class="text-orange-300 font-bold">M {{ ac.specs.cruise_mach }}</span>
            </div>
          </button>
        }
      </div>

      <!-- Detailed Active Aircraft Twin Inspector -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <!-- Left: Digital Twin Render & Primary Aerodynamic Polars (5 cols) -->
        <div class="lg:col-span-5 flex flex-col gap-4">
          <!-- Digital Twin Visual Card -->
          <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-3">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <span class="text-xs font-bold text-orange-400">DIGITAL TWIN VISUALIZATION</span>
              <span class="text-[10px] text-emerald-400 font-bold">SYNCHRONIZED WITH SIM</span>
            </div>

            <div class="relative w-full h-52 bg-slate-950 rounded border border-slate-800 overflow-hidden flex items-center justify-center group">
              <!-- Background Grid & Twin Asset -->
              <img 
                src="/src/assets/images/aero_a900x_twin_1790146986521.jpg" 
                alt="A-900X Digital Twin" 
                referrerpolicy="no-referrer"
                class="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-500" />
              
              <div class="absolute inset-0 bg-gradient-to-t from-[#0B0F17] via-transparent to-transparent"></div>

              <!-- HUD Overlay Over Picture -->
              <div class="absolute bottom-2 left-3 right-3 flex items-center justify-between text-[10px] text-slate-200">
                <span class="font-bold text-orange-400 font-display text-sm">{{ sim.selectedAircraft().name }}</span>
                <span class="bg-black/60 px-2 py-0.5 rounded border border-slate-700">WINGSPAN: {{ sim.selectedAircraft().specs.wingspan_m }}m</span>
              </div>
            </div>

            <p class="text-xs text-slate-300 leading-relaxed">
              {{ sim.selectedAircraft().description }}
            </p>
          </div>

          <!-- Aerodynamic Polar Curve Lift vs Drag CL/CD (Interactive SVG) -->
          <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-2">
            <div class="flex items-center justify-between border-b border-slate-800 pb-1.5">
              <span class="text-xs font-bold text-orange-400">AERODYNAMIC DRAG POLAR (C_L vs C_D)</span>
              <span class="text-[10px] text-slate-400">PARABOLIC DRAG POLAR</span>
            </div>

            <div class="w-full h-44 bg-slate-950 rounded border border-slate-800 p-2 flex items-center justify-center">
              <svg class="w-full h-full" viewBox="0 0 300 150">
                <!-- Grid -->
                <line x1="40" y1="120" x2="280" y2="120" stroke="#334155" stroke-width="1" />
                <line x1="40" y1="10" x2="40" y2="120" stroke="#334155" stroke-width="1" />
                <text x="140" y="142" class="text-[9px] fill-slate-400 font-mono">DRAG COEFFICIENT C_D</text>
                <text x="10" y="70" class="text-[9px] fill-slate-400 font-mono" transform="rotate(-90 20,70)">LIFT C_L</text>

                <!-- Drag Polar Curve -->
                <path d="M 50,115 Q 70,80 120,40 Q 180,25 260,20" fill="none" stroke="#F97316" stroke-width="2" />
                
                <!-- Current operating point -->
                <circle cx="120" cy="40" r="4" fill="#F97316" stroke="#FFFFFF" stroke-width="1.5" class="animate-pulse" />
                <text x="130" y="38" class="text-[9px] fill-orange-300 font-mono font-bold">OPERATING (M 0.78)</text>
              </svg>
            </div>
            <div class="flex items-center justify-between text-[10px] text-slate-400 pt-1">
              <span>C_D0: {{ sim.selectedAircraft().specs.cd0 }}</span>
              <span>Oswald e: {{ sim.selectedAircraft().specs.oswald_e }}</span>
              <span>Aspect Ratio: {{ sim.selectedAircraft().specs.aspect_ratio }}</span>
            </div>
          </div>
        </div>

        <!-- Right: Comprehensive Specification Matrices (7 cols) -->
        <div class="lg:col-span-7 flex flex-col gap-4">
          <!-- Technical Parameters Table -->
          <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-3">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <span class="text-xs font-bold text-orange-400">FULL SPECIFICATION MATRIX</span>
              <span class="text-[10px] text-slate-400">ENGINEERING BENCHMARK</span>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-2 text-xs">
              <div class="flex justify-between items-center py-1 border-b border-slate-800/60">
                <span class="text-slate-400">Max Takeoff Weight (MTOW)</span>
                <span class="text-slate-200 font-bold tabular-nums">{{ sim.selectedAircraft().specs.mtow_kg.toLocaleString() }} kg</span>
              </div>
              <div class="flex justify-between items-center py-1 border-b border-slate-800/60">
                <span class="text-slate-400">Operating Empty Weight (OEW)</span>
                <span class="text-slate-200 font-bold tabular-nums">{{ sim.selectedAircraft().specs.oew_kg.toLocaleString() }} kg</span>
              </div>
              <div class="flex justify-between items-center py-1 border-b border-slate-800/60">
                <span class="text-slate-400">Max Structural Payload</span>
                <span class="text-slate-200 font-bold tabular-nums">{{ sim.selectedAircraft().specs.max_payload_kg.toLocaleString() }} kg</span>
              </div>
              <div class="flex justify-between items-center py-1 border-b border-slate-800/60">
                <span class="text-slate-400">Wing Reference Area</span>
                <span class="text-slate-200 font-bold tabular-nums">{{ sim.selectedAircraft().specs.wing_area_m2 }} m²</span>
              </div>
              <div class="flex justify-between items-center py-1 border-b border-slate-800/60">
                <span class="text-slate-400">Cruise Speed / Mach Limit</span>
                <span class="text-orange-400 font-bold tabular-nums">M {{ sim.selectedAircraft().specs.cruise_mach }} (MMO {{ sim.selectedAircraft().specs.mmo }})</span>
              </div>
              <div class="flex justify-between items-center py-1 border-b border-slate-800/60">
                <span class="text-slate-400">Max Velocity (VMO)</span>
                <span class="text-slate-200 font-bold tabular-nums">{{ sim.selectedAircraft().specs.vmo_kts }} kts IAS</span>
              </div>
              <div class="flex justify-between items-center py-1 border-b border-slate-800/60">
                <span class="text-slate-400">Stall Speed (Vs) Clean</span>
                <span class="text-slate-200 font-bold tabular-nums">{{ sim.selectedAircraft().specs.stall_speed_kts }} kts IAS</span>
              </div>
              <div class="flex justify-between items-center py-1 border-b border-slate-800/60">
                <span class="text-slate-400">Max Certified Ceiling</span>
                <span class="text-slate-200 font-bold tabular-nums">{{ sim.selectedAircraft().specs.max_altitude_ft.toLocaleString() }} ft</span>
              </div>
              <div class="flex justify-between items-center py-1 border-b border-slate-800/60">
                <span class="text-slate-400">Max Rate of Climb</span>
                <span class="text-emerald-400 font-bold tabular-nums">+{{ sim.selectedAircraft().specs.max_climb_rate_fpm }} ft/min</span>
              </div>
              <div class="flex justify-between items-center py-1 border-b border-slate-800/60">
                <span class="text-slate-400">G-Load Envelope</span>
                <span class="text-slate-200 font-bold tabular-nums">{{ sim.selectedAircraft().specs.g_limit_pos }}G / {{ sim.selectedAircraft().specs.g_limit_neg }}G</span>
              </div>
              <div class="flex justify-between items-center py-1 border-b border-slate-800/60">
                <span class="text-slate-400">Propulsion Type</span>
                <span class="text-orange-300 font-bold">{{ sim.selectedAircraft().specs.engine_type }}</span>
              </div>
              <div class="flex justify-between items-center py-1 border-b border-slate-800/60">
                <span class="text-slate-400">Thrust per Engine</span>
                <span class="text-slate-200 font-bold tabular-nums">{{ sim.selectedAircraft().specs.max_thrust_kn_per_eng }} kN</span>
              </div>
              <div class="flex justify-between items-center py-1 border-b border-slate-800/60">
                <span class="text-slate-400">Specific Fuel Consumption (TSFC)</span>
                <span class="text-slate-200 font-bold tabular-nums">{{ sim.selectedAircraft().specs.tsfc_kg_per_kn_hr }} kg/(kN·h)</span>
              </div>
              <div class="flex justify-between items-center py-1 border-b border-slate-800/60">
                <span class="text-slate-400">Total Fuel Capacity</span>
                <span class="text-orange-400 font-bold tabular-nums">{{ sim.selectedAircraft().specs.fuel_capacity_kg.toLocaleString() }} kg</span>
              </div>
              <div class="flex justify-between items-center py-1 border-b border-slate-800/60">
                <span class="text-slate-400">Battery Buffer Storage</span>
                <span class="text-cyan-400 font-bold tabular-nums">{{ sim.selectedAircraft().specs.battery_capacity_kwh }} kWh</span>
              </div>
              <div class="flex justify-between items-center py-1 border-b border-slate-800/60">
                <span class="text-slate-400">Redundancy Channels</span>
                <span class="text-emerald-400 font-bold tabular-nums">{{ sim.selectedAircraft().specs.redundancy_channels }}× TRIPLE TMR</span>
              </div>
            </div>
          </div>

          <!-- Mass & Balance CG Limit Envelope Chart -->
          <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-2">
            <div class="flex items-center justify-between border-b border-slate-800 pb-1.5">
              <span class="text-xs font-bold text-orange-400">CENTER OF GRAVITY (CG) & MASS ENVELOPE</span>
              <span class="text-[10px] text-emerald-400 font-bold">WITHIN ENVELOPE (28.4% MAC)</span>
            </div>

            <div class="w-full h-36 bg-slate-950 rounded border border-slate-800 p-2 flex items-center justify-center">
              <svg class="w-full h-full" viewBox="0 0 300 120">
                <!-- Axes -->
                <line x1="40" y1="100" x2="280" y2="100" stroke="#334155" stroke-width="1" />
                <line x1="40" y1="10" x2="40" y2="100" stroke="#334155" stroke-width="1" />
                <text x="130" y="116" class="text-[9px] fill-slate-400 font-mono">% MAC (CG POSITION)</text>
                <text x="10" y="60" class="text-[9px] fill-slate-400 font-mono" transform="rotate(-90 20,60)">MASS (t)</text>

                <!-- CG Envelope Polygon -->
                <polygon points="70,90 85,30 220,30 250,90" fill="#F97316" fill-opacity="0.15" stroke="#F97316" stroke-width="1.5" />
                
                <!-- Current CG Point -->
                <circle cx="150" cy="55" r="4" fill="#10B981" stroke="#FFFFFF" stroke-width="1.5" />
                <text x="160" y="58" class="text-[9px] fill-emerald-400 font-mono font-bold">CURRENT: 60.4t &#64; 28.4% MAC</text>
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ViewAircraft {
  public sim = inject(SimulationService);
  public Math = Math;

  public selectAircraft(ac: AircraftConfig): void {
    this.sim.selectedAircraft.set(ac);
    this.sim.aircraftState.update(s => ({
      ...s,
      aircraft_id: ac.id,
      callsign: `AERO-${ac.code}`,
      mach: ac.specs.cruise_mach,
      tas_kts: Math.round(ac.specs.cruise_mach * 575)
    }));
    this.sim.logAudit('HUMAN_OPERATOR', 'SIM_CONTROL', `Active digital twin switched to ${ac.id} (${ac.name})`);
  }
}
