import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../core/services/simulation.service';

@Component({
  selector: 'app-view-system-health',
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full w-full p-4 flex flex-col gap-4 overflow-y-auto select-none font-mono">
      <!-- Section Top Banner -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-[#0B0F17] border border-slate-800 p-4 rounded-lg">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-orange-400 font-bold text-sm">SIMULATION ENGINE RUNTIME HEALTH & TELEMETRY</span>
            <span class="text-xs text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded font-bold">
              SOLVER CONVERGED · 50 Hz TICK RATE
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Real-time ODE integrator stability, memory allocations, event bus latency, and deterministic PRNG seed verification.
          </p>
        </div>

        <div class="flex items-center gap-2 text-xs">
          <div class="bg-slate-900 border border-slate-800 px-3 py-1.5 rounded flex items-center gap-2">
            <span class="text-slate-500">SEED REPRODUCIBILITY:</span>
            <span class="font-bold text-cyan-400 font-mono">{{ sim.simSeed() }} (BIT-EXACT)</span>
          </div>
        </div>
      </div>

      <!-- Runtime Performance Cards Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-2">
          <div class="text-[10px] text-slate-500 font-bold uppercase">Physics Solver Frequency</div>
          <div class="text-lg font-bold text-emerald-400">50.0 Hz (20 ms)</div>
          <div class="text-[10px] text-slate-400">RK4 numerical integration of 3DOF/6DOF equations.</div>
        </div>

        <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-2">
          <div class="text-[10px] text-slate-500 font-bold uppercase">Autonomy Stack Loop Latency</div>
          <div class="text-lg font-bold text-cyan-400">4.2 ms</div>
          <div class="text-[10px] text-slate-400">Layers 1-6 pipeline execution time per frame.</div>
        </div>

        <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-2">
          <div class="text-[10px] text-slate-500 font-bold uppercase">Telemetry Queue Depth</div>
          <div class="text-lg font-bold text-orange-400">{{ sim.telemetryHistory().length }} frames</div>
          <div class="text-[10px] text-slate-400">Buffered memory buffer for timeline playback.</div>
        </div>

        <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-2">
          <div class="text-[10px] text-slate-500 font-bold uppercase">Deterministic Seed Status</div>
          <div class="text-lg font-bold text-slate-200">LOCKED (0 DRIFT)</div>
          <div class="text-[10px] text-slate-400">Identical random number stream across replays.</div>
        </div>
      </div>

      <!-- Engine Subsystem Telemetry Breakdown -->
      <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-3 text-xs">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <span class="text-xs font-bold text-orange-400">SIMULATION ENGINE MODULE ALLOCATIONS</span>
          <span class="text-[10px] text-slate-400">ZERO MEMORY LEAK VERIFIED</span>
        </div>

        <div class="space-y-2">
          <div class="flex justify-between items-center py-1 border-b border-slate-800/60">
            <span class="text-slate-400">Flight Dynamics Engine (ISA Atmosphere + RK4)</span>
            <span class="text-emerald-400 font-bold">HEALTHY · 0.8 ms avg</span>
          </div>
          <div class="flex justify-between items-center py-1 border-b border-slate-800/60">
            <span class="text-slate-400">Sensor Perception & Kalman Filter (EKF 15-State)</span>
            <span class="text-emerald-400 font-bold">HEALTHY · 1.4 ms avg</span>
          </div>
          <div class="flex justify-between items-center py-1 border-b border-slate-800/60">
            <span class="text-slate-400">4D Mission Planning & A* Detour Solver</span>
            <span class="text-emerald-400 font-bold">HEALTHY · 2.1 ms avg</span>
          </div>
          <div class="flex justify-between items-center py-1 border-b border-slate-800/60">
            <span class="text-slate-400">Traffic Conflict & TCAS-II Separation Vector</span>
            <span class="text-emerald-400 font-bold">HEALTHY · 0.6 ms avg</span>
          </div>
          <div class="flex justify-between items-center py-1">
            <span class="text-slate-400">Audit Trail Event Dispatcher</span>
            <span class="text-emerald-400 font-bold">HEALTHY · 0.1 ms avg</span>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ViewSystemHealth {
  public sim = inject(SimulationService);
}
