import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SimulationService } from '../../core/services/simulation.service';

@Component({
  selector: 'app-view-weather',
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full w-full p-4 flex flex-col gap-4 overflow-y-auto select-none font-mono">
      <!-- Section Top Banner -->
      <div class="flex flex-wrap items-center justify-between gap-3 bg-[#0B0F17] border border-slate-800 p-4 rounded-lg">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-orange-400 font-bold text-sm">METEOROLOGY & CONVECTIVE HAZARDS INTERCEPTOR</span>
            <span class="text-xs text-rose-400 bg-rose-950/60 border border-rose-500/30 px-2 py-0.5 rounded font-bold">
              SEVERE STORM SQUALL ACTIVE
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Doppler radar reflectivity (dBZ), high-altitude icing envelopes, clear-air jetstream turbulence slices, and autonomous detour envelopes.
          </p>
        </div>

        <div class="flex items-center gap-2">
          <button 
            (click)="sim.injectFailure('FAIL_WEATHER_SQUALL')"
            class="px-3 py-1.5 rounded bg-orange-600 hover:bg-orange-500 text-xs font-bold text-white transition-colors flex items-center gap-1.5">
            <mat-icon class="!text-[14px] !w-3.5 !h-3.5">storm</mat-icon>
            <span>INJECT EXPLOSIVE SUPERCELL</span>
          </button>
        </div>
      </div>

      <!-- Active Weather Cells Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        @for (cell of sim.weatherCells(); track cell.id) {
          <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-3">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <div class="flex items-center gap-2">
                <span class="text-xs font-bold text-rose-400">⚡ {{ cell.name }}</span>
                <span class="text-[10px] text-slate-400 bg-slate-800 px-1.5 py-0.2 rounded">{{ cell.id }}</span>
              </div>
              <span class="text-xs font-bold text-rose-400 bg-rose-950/60 border border-rose-600/40 px-2 py-0.5 rounded">
                {{ cell.severity }}
              </span>
            </div>

            <div class="grid grid-cols-2 gap-2 text-xs">
              <div class="bg-slate-950 p-2 rounded border border-slate-900">
                <span class="text-[10px] text-slate-500">CLOUD TOP</span>
                <div class="font-bold text-orange-400">FL{{ cell.top_fl }} ({{ cell.top_fl * 100 }} ft)</div>
              </div>
              <div class="bg-slate-950 p-2 rounded border border-slate-900">
                <span class="text-[10px] text-slate-500">RADIUS BUFFER</span>
                <div class="font-bold text-slate-200">{{ cell.radius_nm }} NM</div>
              </div>
              <div class="bg-slate-950 p-2 rounded border border-slate-900">
                <span class="text-[10px] text-slate-500">TURBULENCE</span>
                <div class="font-bold text-rose-400">{{ cell.turbulence }} (EDR > 0.6)</div>
              </div>
              <div class="bg-slate-950 p-2 rounded border border-slate-900">
                <span class="text-[10px] text-slate-500">LIGHTNING RATE</span>
                <div class="font-bold text-amber-300">{{ cell.lightning_rate_per_min }} strikes / min</div>
              </div>
              <div class="bg-slate-950 p-2 rounded border border-slate-900">
                <span class="text-[10px] text-slate-500">ICING SEVERITY</span>
                <div class="font-bold text-cyan-400">{{ Math.round(cell.icing_index * 100) }}% SEVERE</div>
              </div>
              <div class="bg-slate-950 p-2 rounded border border-slate-900">
                <span class="text-[10px] text-slate-500">CELL DRIFT VECTOR</span>
                <div class="font-bold text-slate-200">{{ cell.drift_speed_kts }} kts &#64; {{ cell.drift_dir_deg }}°</div>
              </div>
            </div>

            <div class="text-[10px] text-slate-500">
              Source: {{ cell.synthetic_source }}
            </div>
          </div>
        }
      </div>

      <!-- Radar Reflectivity Scale & Jetstream Cross-Section -->
      <div class="bg-[#0B0F17] border border-slate-800 rounded-lg p-4 flex flex-col gap-3">
        <div class="flex items-center justify-between border-b border-slate-800 pb-2">
          <span class="text-xs font-bold text-orange-400">ATMOSPHERIC WIND VECTOR & JETSTREAM PROFILE (FL380)</span>
          <span class="text-[10px] text-slate-400">NORTH ATLANTIC POLAR JET</span>
        </div>

        <div class="w-full h-36 bg-slate-950 rounded border border-slate-800 p-2 flex items-center justify-center">
          <svg class="w-full h-full" viewBox="0 0 400 120">
            <!-- Grid -->
            <line x1="20" y1="100" x2="380" y2="100" stroke="#334155" stroke-width="1" />
            
            <!-- Wind velocity vectors along latitude -->
            @for (x of [50, 90, 130, 170, 210, 250, 290, 330, 370]; track x) {
              <line [attr.x1]="x" y1="50" [attr.x2]="x + 24" y2="40" stroke="#38BDF8" stroke-width="1.5" />
              <polygon [attr.points]="(x+24) + ',40 ' + (x+16) + ',36 ' + (x+18) + ',43'" fill="#38BDF8" />
              <text [attr.x]="x" y="70" class="text-[8px] fill-sky-300 font-mono">85 KT</text>
            }
            <text x="30" y="25" class="text-[9px] fill-orange-400 font-mono font-bold">JETSTREAM CORE (275° / 85 kts TAILWIND COMPONENT)</text>
          </svg>
        </div>
      </div>
    </div>
  `
})
export class ViewWeather {
  public sim = inject(SimulationService);
  public Math = Math;
}
