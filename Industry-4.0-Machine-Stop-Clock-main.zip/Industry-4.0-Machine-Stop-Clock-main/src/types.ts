/**
 * Industry 4.0 Machine Stop Clock & Downtime Intelligence Platform Types
 */

export type MachineState =
  | 'RUNNING'
  | 'STOPPED'
  | 'IDLE'
  | 'STARVED'
  | 'BLOCKED'
  | 'FAULT'
  | 'SETUP'
  | 'CHANGEOVER'
  | 'MAINTENANCE'
  | 'CLEANING'
  | 'NO_MATERIAL'
  | 'NO_OPERATOR'
  | 'PLANNED_BREAK'
  | 'DISCONNECTED'
  | 'UNKNOWN';

export type EventType =
  | 'STATE_CHANGE'
  | 'CYCLE_COMPLETE'
  | 'PIECE_PRODUCED'
  | 'REJECT_DETECTED'
  | 'FAULT_TRIGGERED'
  | 'CLASSIFICATION'
  | 'SIGNAL_RAW'
  | 'OPERATOR_OVERRIDE'
  | 'MAINTENANCE_LOGGED';

export type EventSource =
  | 'PLC'
  | 'OPC_UA'
  | 'MODBUS'
  | 'MQTT'
  | 'DIGITAL_IO'
  | 'SENSOR'
  | 'MANUAL'
  | 'API'
  | 'SIMULATION';

export interface ReasonCode {
  category: 'Mechanical' | 'Electrical' | 'Material' | 'Changeover' | 'Operator' | 'Maintenance' | 'Quality' | 'Process' | 'Other';
  subcategory: string;
  code: string;
  name: string;
  description?: string;
  defaultCostRatePerHour?: number;
}

export interface MachineEvent {
  id: string;
  machine_id: string;
  timestamp: string; // ISO 8601 UTC
  monotonic_ns: number; // Monotonic nanoseconds for sub-second precision
  event_type: EventType;
  previous_state: MachineState;
  new_state: MachineState;
  reason_code?: ReasonCode;
  source: EventSource;
  metadata: Record<string, string>;
  ingestion_time: string;
  processing_time: string;
}

export interface StopRecord {
  id: string;
  machine_id: string;
  start_time: string;
  end_time?: string;
  duration_sec: number;
  is_micro_stop: boolean;
  is_planned: boolean;
  state: MachineState;
  reason?: ReasonCode;
  classified_by?: string;
  classified_at?: string;
  notes?: string;
  estimated_cost_loss: number;
  parts_lost_estimate: number;
}

export interface CycleRecord {
  id: string;
  machine_id: string;
  timestamp: string;
  cycle_time_sec: number;
  ideal_cycle_time_sec: number;
  is_good: boolean;
  is_slow: boolean;
  is_abnormal: boolean;
  part_number?: string;
}

export interface MachineThresholds {
  running_threshold_rpm: number;
  stop_threshold_rpm: number;
  micro_stop_seconds: number; // default e.g. 120s
  fault_confirmation_ms: number;
  ideal_cycle_time_sec: number;
  target_parts_per_hour: number;
}

export interface FinancialConfig {
  machine_value_per_hour: number; // e.g. £150/hr
  production_value_per_part: number; // e.g. £12/part
  labour_cost_per_hour: number; // e.g. £35/hr
  scrap_cost_per_part: number; // e.g. £8/part
}

export interface MachineConfig {
  id: string;
  code: string;
  name: string;
  department: string;
  line_id: string;
  cell_id: string;
  asset_path: string; // Enterprise -> Site -> Area -> Line -> Cell -> Machine
  thresholds: MachineThresholds;
  financials: FinancialConfig;
  signal_source: EventSource;
}

export interface OeeMetrics {
  availability: number; // 0.0 to 1.0 (or percentage)
  performance: number;
  quality: number;
  oee: number;
  planned_production_time_sec: number;
  operating_time_sec: number;
  ideal_time_for_total_count_sec: number;
}

export interface CycleStats {
  min_sec: number;
  max_sec: number;
  mean_sec: number;
  median_sec: number;
  p95_sec: number;
  p99_sec: number;
  stddev_sec: number;
  total_cycles: number;
  slow_cycles_count: number;
  ideal_cycle_time_sec: number;
}

export interface ProductionCounts {
  total_produced: number;
  good_count: number;
  reject_count: number;
  scrap_count: number;
  target_count: number;
  remaining_count: number;
  parts_per_hour: number;
}

export interface ReliabilityMetrics {
  mtbf_hours: number;
  mttr_minutes: number;
  failure_frequency_per_day: number;
  repair_frequency_per_day: number;
  health_score: number; // 0 - 100
  anomaly_score: number; // 0 - 100
  failure_warning?: string;
}

export interface SixBigLosses {
  equipment_failure_min: number;
  setup_adjustment_min: number;
  small_stops_min: number; // micro-stops
  reduced_speed_min: number;
  startup_rejects_min: number;
  production_rejects_min: number;
  total_loss_min: number;
  estimated_cost_loss: number;
}

export interface MachineMetrics {
  machine_id: string;
  name: string;
  code: string;
  line_id: string;
  current_state: MachineState;
  state_start_time: string;
  current_run_duration_sec: number;
  current_stop_duration_sec: number;
  current_reason?: ReasonCode;
  
  // Downtime summary
  total_runtime_sec: number;
  total_downtime_sec: number;
  planned_downtime_sec: number;
  unplanned_downtime_sec: number;
  
  // Stop counts
  stop_count: number;
  avg_stop_duration_sec: number;
  longest_stop_sec: number;
  shortest_stop_sec: number;
  
  // Micro-stops
  micro_stops_count: number;
  micro_stop_time_sec: number;
  avg_micro_stop_sec: number;
  micro_stops_per_hour: number;
  
  // Engines
  cycle_stats: CycleStats;
  production: ProductionCounts;
  oee: OeeMetrics;
  reliability: ReliabilityMetrics;
  losses: SixBigLosses;
  financials: {
    downtime_cost_per_hour: number;
    total_downtime_cost: number;
    scrap_cost: number;
    total_financial_loss: number;
  };
  last_event_time: string;
}

export interface DowntimeParetoItem {
  category: string;
  subcategory: string;
  code: string;
  reason_name: string;
  occurrences: number;
  total_duration_sec: number;
  percentage_of_downtime: number;
  estimated_cost: number;
}

export interface AlertItem {
  id: string;
  machine_id: string;
  machine_name: string;
  severity: 'critical' | 'warning' | 'info';
  code: string;
  message: string;
  timestamp: string;
  acknowledged: boolean;
}

export interface ShiftInfo {
  id: string;
  name: string; // 'Shift A (Morning)', 'Shift B (Afternoon)', 'Shift C (Night)'
  start_time: string; // '06:00'
  end_time: string;   // '14:00'
  planned_breaks_min: number;
  active: boolean;
}

export interface FactorySummary {
  factory_name: string;
  overall_oee: number;
  availability: number;
  performance: number;
  quality: number;
  total_downtime_sec: number;
  active_machines_count: number;
  total_machines_count: number;
  stopped_machines_count: number;
  faulted_machines_count: number;
  running_machines_count: number;
  total_loss_cost_today: number;
  current_shift: ShiftInfo;
}

export type UserRole = 'operator' | 'engineer' | 'manager' | 'administrator';

export interface TimelineBlock {
  id: string;
  state: MachineState;
  start_time: string;
  end_time: string;
  duration_sec: number;
  reason?: ReasonCode;
  is_micro_stop?: boolean;
}
