import React, { useState, useEffect } from 'react';
import {
  Play,
  Pause,
  AlertTriangle,
  Wrench,
  PackageX,
  UserCheck,
  CheckCircle2,
  Tag,
  FileText,
  Clock,
  Layers,
  ChevronRight,
  Zap,
} from 'lucide-react';
import { MachineMetrics, ReasonCode, UserRole } from '../types';

interface StopClockViewProps {
  machines: MachineMetrics[];
  selectedMachineId: string;
  setSelectedMachineId: (id: string) => void;
  reasons: ReasonCode[];
  onOverrideState: (machineId: string, action: any, reasonCode?: string, notes?: string) => void;
  onClassifyStop: (machineId: string, stopId: string, reasonCode: string, notes?: string) => void;
  role: UserRole;
}

export const StopClockView: React.FC<StopClockViewProps> = ({
  machines,
  selectedMachineId,
  setSelectedMachineId,
  reasons,
  onOverrideState,
  onClassifyStop,
  role,
}) => {
  const machine = machines.find((m) => m.machine_id === selectedMachineId) || machines[0];
  const [showClassifyModal, setShowClassifyModal] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('Mechanical');
  const [customNotes, setCustomNotes] = useState('');

  // Ticking sub-second stop clock counter
  const [elapsedSec, setElapsedSec] = useState(0);

  useEffect(() => {
    if (!machine) return;
    const isStopped = machine.current_state !== 'RUNNING';
    const initialElapsed = isStopped
      ? machine.current_stop_duration_sec
      : machine.current_run_duration_sec;

    setElapsedSec(initialElapsed);

    const timer = setInterval(() => {
      setElapsedSec((prev) => prev + 0.1);
    }, 100);

    return () => clearInterval(timer);
  }, [machine?.machine_id, machine?.current_state, machine?.state_start_time]);

  if (!machine) {
    return <div className="p-8 text-center text-slate-400 font-mono">No machines available.</div>;
  }

  const formatStopWatch = (sec: number) => {
    const totalMs = Math.floor(sec * 1000);
    const hours = Math.floor(totalMs / (1000 * 60 * 60));
    const minutes = Math.floor((totalMs % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((totalMs % (1000 * 60)) / 1000);
    const tenths = Math.floor((totalMs % 1000) / 100);

    const pad = (n: number) => n.toString().padStart(2, '0');

    if (hours > 0) {
      return `${pad(hours)}:${pad(minutes)}:${pad(seconds)}.${tenths}`;
    }
    return `${pad(minutes)}:${pad(seconds)}.${tenths}`;
  };

  const isStopped = machine.current_state !== 'RUNNING';

  const categories = Array.from(new Set(reasons.map((r) => r.category)));

  return (
    <div className="max-w-[1400px] mx-auto p-4 md:p-6 space-y-6">
      {/* Top Machine Selector Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900/90 border border-slate-800 p-4 rounded-xl font-mono">
        <div className="flex items-center space-x-3">
          <span className="text-slate-400 text-xs">SELECT MACHINE:</span>
          <select
            value={machine.machine_id}
            onChange={(e) => setSelectedMachineId(e.target.value)}
            className="bg-slate-950 text-slate-100 border border-slate-700 px-4 py-2 rounded-lg font-bold text-sm focus:outline-none focus:border-emerald-500 cursor-pointer"
          >
            {machines.map((m) => (
              <option key={m.machine_id} value={m.machine_id}>
                {m.code} — {m.name} ({m.current_state})
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center space-x-6 text-xs text-slate-400">
          <div>
            <span>DEPARTMENT: </span>
            <span className="text-slate-200 font-bold">MACHINING CELL 01</span>
          </div>
          <div>
            <span>OEE TODAY: </span>
            <span
              className={`font-bold ${
                machine.oee.oee >= 0.85 ? 'text-emerald-400' : 'text-amber-400'
              }`}
            >
              {(machine.oee.oee * 100).toFixed(1)}%
            </span>
          </div>
          <div>
            <span>SHIFT TARGET: </span>
            <span className="text-slate-200 font-bold">
              {machine.production.good_count} / {machine.production.target_count} parts
            </span>
          </div>
        </div>
      </div>

      {/* Flagship Industrial Stopwatch Card */}
      <div
        className={`relative overflow-hidden rounded-2xl border transition-all duration-500 p-8 md:p-12 text-center ${
          isStopped
            ? 'bg-gradient-to-b from-red-950/40 via-slate-950 to-slate-950 border-red-600/50 shadow-2xl shadow-red-950/30'
            : 'bg-gradient-to-b from-emerald-950/30 via-slate-950 to-slate-950 border-emerald-600/40 shadow-2xl shadow-emerald-950/20'
        }`}
      >
        {/* Glow Ring Indicator */}
        <div
          className={`absolute top-0 left-1/2 -translate-x-1/2 w-96 h-1 rounded-full blur-sm ${
            isStopped ? 'bg-red-500 animate-pulse' : 'bg-emerald-500'
          }`}
        />

        <div className="space-y-6 max-w-4xl mx-auto">
          {/* Machine Name & Asset Path */}
          <div>
            <span className="text-xs font-mono tracking-widest text-slate-400 uppercase">
              {machine.code} • MACHINE STOP CLOCK
            </span>
            <h1 className="text-2xl md:text-3xl font-mono font-bold text-slate-100 mt-1">
              {machine.name}
            </h1>
          </div>

          {/* Machine Status Badge */}
          <div className="flex justify-center">
            <span
              className={`inline-flex items-center space-x-2 px-6 py-2 rounded-full font-mono font-bold text-sm border shadow-lg ${
                isStopped
                  ? 'bg-red-500/20 text-red-400 border-red-500/40 shadow-red-900/30 animate-pulse'
                  : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40 shadow-emerald-900/30'
              }`}
            >
              <span
                className={`w-3 h-3 rounded-full ${
                  isStopped ? 'bg-red-500 animate-ping' : 'bg-emerald-500'
                }`}
              />
              <span>{machine.current_state}</span>
            </span>
          </div>

          {/* HUGE VISUALLY DOMINANT ELAPSED TIME STOPWATCH DISPLAY */}
          <div className="py-4">
            <div className="font-mono font-black text-6xl sm:text-7xl md:text-8xl lg:text-9xl tracking-tight text-slate-100 drop-shadow-lg select-none">
              {formatStopWatch(elapsedSec)}
            </div>
            <p className="text-xs font-mono text-slate-400 uppercase tracking-widest mt-2">
              {isStopped ? 'ELAPSED DOWNTIME DURATION' : 'CONTINUOUS RUN DURATION'}
            </p>
          </div>

          {/* Reason Code Display & Classification Prompt */}
          <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-xl inline-block max-w-xl mx-auto text-left font-mono">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
              <span>ACTIVE CLASSIFICATION:</span>
              <span className="text-slate-500">ID: {machine.current_reason?.code || 'OTH-001'}</span>
            </div>
            <div className="flex items-center space-x-3">
              <Tag className="w-5 h-5 text-amber-400" />
              <div>
                <div className="text-base font-bold text-slate-100">
                  {machine.current_reason?.name || 'MATERIAL SHORTAGE / UNCLASSIFIED'}
                </div>
                <div className="text-xs text-slate-400">
                  {machine.current_reason?.category || 'Other'} &gt;{' '}
                  {machine.current_reason?.subcategory || 'General'}
                </div>
              </div>
            </div>
          </div>

          {/* Quick Operator Action Reason Buttons */}
          <div className="pt-4 border-t border-slate-800/80">
            <p className="text-xs font-mono text-slate-400 mb-3 uppercase tracking-wider">
              QUICK OPERATOR CLASSIFICATION & ACTION
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2 font-mono text-xs">
              <button
                onClick={() => onOverrideState(machine.machine_id, 'RUN')}
                className="flex flex-col items-center justify-center p-3 rounded-xl bg-emerald-950/60 hover:bg-emerald-900/80 text-emerald-300 border border-emerald-600/40 transition cursor-pointer group"
              >
                <Play className="w-5 h-5 mb-1 text-emerald-400 group-hover:scale-110 transition" />
                <span className="font-bold">[RUN]</span>
              </button>

              <button
                onClick={() => onOverrideState(machine.machine_id, 'FAULT', 'MCH-004')}
                className="flex flex-col items-center justify-center p-3 rounded-xl bg-red-950/60 hover:bg-red-900/80 text-red-300 border border-red-600/40 transition cursor-pointer group"
              >
                <AlertTriangle className="w-5 h-5 mb-1 text-red-400 group-hover:scale-110 transition" />
                <span className="font-bold">JAM</span>
              </button>

              <button
                onClick={() => onOverrideState(machine.machine_id, 'MATERIAL_SHORTAGE', 'MAT-001')}
                className="flex flex-col items-center justify-center p-3 rounded-xl bg-amber-950/60 hover:bg-amber-900/80 text-amber-300 border border-amber-600/40 transition cursor-pointer group"
              >
                <PackageX className="w-5 h-5 mb-1 text-amber-400 group-hover:scale-110 transition" />
                <span className="font-bold">NO MAT</span>
              </button>

              <button
                onClick={() => onOverrideState(machine.machine_id, 'MAINTENANCE', 'MNT-001')}
                className="flex flex-col items-center justify-center p-3 rounded-xl bg-blue-950/60 hover:bg-blue-900/80 text-blue-300 border border-blue-600/40 transition cursor-pointer group"
              >
                <Wrench className="w-5 h-5 mb-1 text-blue-400 group-hover:scale-110 transition" />
                <span className="font-bold">FITTER</span>
              </button>

              <button
                onClick={() => onOverrideState(machine.machine_id, 'CHANGEOVER', 'CHO-001')}
                className="flex flex-col items-center justify-center p-3 rounded-xl bg-purple-950/60 hover:bg-purple-900/80 text-purple-300 border border-purple-600/40 transition cursor-pointer group"
              >
                <Layers className="w-5 h-5 mb-1 text-purple-400 group-hover:scale-110 transition" />
                <span className="font-bold">CHANGE</span>
              </button>

              <button
                onClick={() => onOverrideState(machine.machine_id, 'STOP', 'OPR-001')}
                className="flex flex-col items-center justify-center p-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 transition cursor-pointer group"
              >
                <UserCheck className="w-5 h-5 mb-1 text-slate-400 group-hover:scale-110 transition" />
                <span className="font-bold">BREAK</span>
              </button>

              <button
                onClick={() => setShowClassifyModal(true)}
                className="col-span-2 sm:col-span-1 flex flex-col items-center justify-center p-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-400 border border-slate-600 transition cursor-pointer group"
              >
                <Tag className="w-5 h-5 mb-1 group-hover:scale-110 transition" />
                <span className="font-bold">TREE...</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Machine Telemetry Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 font-mono text-xs">
        <div className="bg-slate-900/80 border border-slate-800 p-4 rounded-xl">
          <div className="text-slate-400 mb-1">TOTAL DOWNTIME TODAY</div>
          <div className="text-2xl font-bold text-red-400">
            {Math.floor(machine.total_downtime_sec / 3600)}h{' '}
            {Math.floor((machine.total_downtime_sec % 3600) / 60)}m
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Unplanned: {Math.floor(machine.unplanned_downtime_sec / 60)} min
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-4 rounded-xl">
          <div className="text-slate-400 mb-1">ESTIMATED FINANCIAL LOSS</div>
          <div className="text-2xl font-bold text-amber-400">
            £{machine.financials.total_financial_loss.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Rate: £{machine.financials.downtime_cost_per_hour}/hr
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-4 rounded-xl">
          <div className="text-slate-400 mb-1">MICRO-STOPS COUNT</div>
          <div className="text-2xl font-bold text-amber-300">
            {machine.micro_stops_count} stops
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Total lost: {Math.round(machine.micro_stop_time_sec)} sec ({machine.micro_stops_per_hour}/hr)
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-4 rounded-xl">
          <div className="text-slate-400 mb-1">CYCLE TIME / SPEED</div>
          <div className="text-2xl font-bold text-emerald-400">
            {machine.cycle_stats.mean_sec}s
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Ideal: {machine.cycle_stats.ideal_cycle_time_sec}s | Slow cycles: {machine.cycle_stats.slow_cycles_count}
          </div>
        </div>
      </div>

      {/* Hierarchical Downtime Classification Modal */}
      {showClassifyModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full p-6 space-y-6 font-mono text-slate-100 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center space-x-2 text-amber-400 font-bold text-base">
                <Tag className="w-5 h-5" />
                <span>HIERARCHICAL DOWNTIME CLASSIFICATION TREE</span>
              </div>
              <button
                onClick={() => setShowClassifyModal(false)}
                className="text-slate-400 hover:text-slate-200 text-lg cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Category Tabs */}
            <div className="flex items-center space-x-2 overflow-x-auto pb-2 scrollbar-none text-xs">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 rounded-lg whitespace-nowrap cursor-pointer transition ${
                    selectedCategory === cat
                      ? 'bg-amber-500 text-slate-950 font-bold'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Reason Code Items */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-60 overflow-y-auto p-1">
              {reasons
                .filter((r) => r.category === selectedCategory)
                .map((r) => (
                  <button
                    key={r.code}
                    onClick={() => {
                      onOverrideState(machine.machine_id, 'STOP', r.code, customNotes);
                      setShowClassifyModal(false);
                    }}
                    className="flex flex-col text-left p-3 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-amber-500/50 transition cursor-pointer group"
                  >
                    <div className="flex items-center justify-between text-xs font-bold text-amber-300 group-hover:text-amber-400">
                      <span>{r.name}</span>
                      <span className="text-[10px] text-slate-500">{r.code}</span>
                    </div>
                    <div className="text-[11px] text-slate-400 mt-1 line-clamp-1">
                      {r.description || r.subcategory}
                    </div>
                  </button>
                ))}
            </div>

            {/* Custom Notes */}
            <div>
              <label className="block text-xs text-slate-400 mb-1">OPERATOR NOTES / ROOT CAUSE:</label>
              <textarea
                value={customNotes}
                onChange={(e) => setCustomNotes(e.target.value)}
                placeholder="Enter shift notes or specific component fault details..."
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs text-slate-200 focus:outline-none focus:border-amber-500"
                rows={2}
              />
            </div>

            <div className="flex justify-end space-x-3 pt-2">
              <button
                onClick={() => setShowClassifyModal(false)}
                className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs cursor-pointer"
              >
                CANCEL
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
