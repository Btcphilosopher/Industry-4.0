import React, { useState } from 'react';
import { RotateCcw, Play, Pause, FastForward, CheckCircle2, Clock } from 'lucide-react';
import { MachineEvent, MachineMetrics } from '../types';

interface EventReplayViewProps {
  machines: MachineMetrics[];
}

export const EventReplayView: React.FC<EventReplayViewProps> = ({ machines }) => {
  const [selectedMachineId, setSelectedMachineId] = useState(machines[0]?.machine_id || '');
  const [fromTime, setFromTime] = useState('2026-08-20T06:00');
  const [toTime, setToTime] = useState('2026-08-20T14:00');
  const [replayedEvents, setReplayedEvents] = useState<MachineEvent[]>([]);
  const [isReplaying, setIsReplaying] = useState(false);
  const [replayIndex, setReplayIndex] = useState(0);

  const handleFetchReplay = async () => {
    try {
      const res = await fetch('/api/replay', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          machine_id: selectedMachineId,
          from: new Date(fromTime).toISOString(),
          to: new Date(toTime).toISOString(),
        }),
      });
      const data = await res.json();
      setReplayedEvents(data.events || []);
      setReplayIndex(0);
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="max-w-[1700px] mx-auto p-4 md:p-6 space-y-6 font-mono text-[#E1E1E6]">
      {/* Title */}
      <div className="flex items-center justify-between bg-[#0F0F12] border border-[#1F1F23] p-4 rounded-xl">
        <div className="flex items-center space-x-3">
          <RotateCcw className="w-6 h-6 text-[#34C759]" />
          <div>
            <h1 className="text-base font-bold text-white uppercase tracking-wider">
              HISTORICAL EVENT REPLAY ENGINE
            </h1>
            <p className="text-xs text-[#8E8E93]">
              Reconstruct machine states, OEE, downtime, and alerts from immutable event logs
            </p>
          </div>
        </div>
      </div>

      {/* Query Bar */}
      <div className="bg-[#0F0F12] border border-[#1F1F23] p-4 rounded-2xl flex flex-wrap items-center gap-4 text-xs">
        <div>
          <label className="block text-[#636366] font-bold uppercase mb-1">MACHINE:</label>
          <select
            value={selectedMachineId}
            onChange={(e) => setSelectedMachineId(e.target.value)}
            className="bg-[#0A0A0B] text-white border border-[#1F1F23] px-3 py-1.5 rounded-lg focus:outline-none focus:border-[#F27D26] cursor-pointer font-bold"
          >
            {machines.map((m) => (
              <option key={m.machine_id} value={m.machine_id}>
                {m.code} — {m.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[#636366] font-bold uppercase mb-1">FROM (UTC):</label>
          <input
            type="datetime-local"
            value={fromTime}
            onChange={(e) => setFromTime(e.target.value)}
            className="bg-[#0A0A0B] border border-[#1F1F23] rounded-lg p-1.5 text-white focus:outline-none focus:border-[#F27D26] font-bold"
          />
        </div>

        <div>
          <label className="block text-[#636366] font-bold uppercase mb-1">TO (UTC):</label>
          <input
            type="datetime-local"
            value={toTime}
            onChange={(e) => setToTime(e.target.value)}
            className="bg-[#0A0A0B] border border-[#1F1F23] rounded-lg p-1.5 text-white focus:outline-none focus:border-[#F27D26] font-bold"
          />
        </div>

        <div className="pt-5">
          <button
            onClick={handleFetchReplay}
            className="px-4 py-2 bg-[#34C759]/10 border border-[#34C759]/30 hover:bg-[#34C759]/20 text-[#34C759] font-bold rounded-lg transition cursor-pointer"
          >
            FETCH EVENT REPLAY STREAM
          </button>
        </div>
      </div>

      {/* Replay Stream Results */}
      <div className="bg-[#0F0F12] border border-[#1F1F23] p-6 rounded-2xl space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-bold uppercase tracking-widest text-[#636366]">
            RECONSTRUCTED EVENT LOG STREAM ({replayedEvents.length} EVENTS)
          </h2>
        </div>

        <div className="max-h-96 overflow-y-auto space-y-2 text-xs font-mono">
          {replayedEvents.length === 0 ? (
            <div className="text-[#636366] py-12 text-center font-bold">
              Click &quot;Fetch Event Replay Stream&quot; to reconstruct historical state timeline.
            </div>
          ) : (
            replayedEvents.map((ev) => (
              <div
                key={ev.id}
                className="bg-[#0A0A0B] border border-[#1F1F23] p-3 rounded-lg flex items-center justify-between"
              >
                <div>
                  <div className="text-[#34C759] font-bold">
                    [{ev.event_type}] {ev.previous_state} → {ev.new_state}
                  </div>
                  <div className="text-[#8E8E93] text-[11px] mt-0.5">
                    Reason: {ev.reason_code?.name || 'Normal Transition'} ({ev.source})
                  </div>
                </div>

                <div className="text-[#8E8E93] text-[11px] font-bold">
                  {new Date(ev.timestamp).toISOString()}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
