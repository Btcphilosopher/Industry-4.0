import React, { useState } from 'react';
import { Sliders, Play, Pause, Zap, AlertTriangle, Radio } from 'lucide-react';
import { MachineMetrics, ReasonCode } from '../types';

interface SimulatorControlsProps {
  machines: MachineMetrics[];
  reasons: ReasonCode[];
  onOverrideState: (machineId: string, action: any, reasonCode?: string, notes?: string) => void;
}

export const SimulatorControls: React.FC<SimulatorControlsProps> = ({
  machines,
  reasons,
  onOverrideState,
}) => {
  const [selectedMachineId, setSelectedMachineId] = useState(machines[0]?.machine_id || '');
  const [selectedAction, setSelectedAction] = useState<any>('FAULT');
  const [selectedReasonCode, setSelectedReasonCode] = useState('MCH-004');
  const [notes, setNotes] = useState('');

  const handleInject = () => {
    onOverrideState(selectedMachineId, selectedAction, selectedReasonCode, notes);
  };

  return (
    <div className="max-w-[1700px] mx-auto p-4 md:p-6 space-y-6 font-mono text-[#E1E1E6]">
      {/* Title */}
      <div className="flex items-center justify-between bg-[#0F0F12] border border-[#1F1F23] p-4 rounded-xl">
        <div className="flex items-center space-x-3">
          <Sliders className="w-6 h-6 text-[#F27D26]" />
          <div>
            <h1 className="text-base font-bold text-white uppercase tracking-wider">
              INDUSTRIAL EDGE & HARDWARE SIGNAL SIMULATOR
            </h1>
            <p className="text-xs text-[#8E8E93]">
              Inject PLC, OPC-UA, Modbus, MQTT signals and test offline event buffering
            </p>
          </div>
        </div>
      </div>

      {/* Manual Signal Injection Box */}
      <div className="bg-[#0F0F12] border border-[#1F1F23] p-6 rounded-2xl space-y-4 max-w-2xl">
        <h2 className="text-xs font-bold uppercase tracking-widest text-[#636366] flex items-center space-x-2">
          <Radio className="w-4 h-4 text-[#34C759]" />
          <span>MANUAL HARDWARE SIGNAL INJECTION</span>
        </h2>

        <div className="space-y-3 text-xs font-bold">
          <div>
            <label className="block text-[#636366] uppercase mb-1">TARGET MACHINE:</label>
            <select
              value={selectedMachineId}
              onChange={(e) => setSelectedMachineId(e.target.value)}
              className="w-full bg-[#0A0A0B] text-white border border-[#1F1F23] p-2 rounded-lg focus:outline-none focus:border-[#F27D26] cursor-pointer"
            >
              {machines.map((m) => (
                <option key={m.machine_id} value={m.machine_id}>
                  {m.code} — {m.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[#636366] uppercase mb-1">STATE ACTION:</label>
            <select
              value={selectedAction}
              onChange={(e) => setSelectedAction(e.target.value)}
              className="w-full bg-[#0A0A0B] text-white border border-[#1F1F23] p-2 rounded-lg focus:outline-none focus:border-[#F27D26] cursor-pointer"
            >
              <option value="RUN">RUNNING (Machine Speed &gt; Threshold)</option>
              <option value="STOP">STOPPED (Speed &lt; Threshold)</option>
              <option value="FAULT">FAULT (PLC Trip / Mechanical Jam)</option>
              <option value="MATERIAL_SHORTAGE">MATERIAL SHORTAGE (Infeed Empty)</option>
              <option value="MAINTENANCE">MAINTENANCE (Fitter Onsite)</option>
              <option value="CHANGEOVER">CHANGEOVER (Tool Swap)</option>
            </select>
          </div>

          <div>
            <label className="block text-[#636366] uppercase mb-1">REASON CODE:</label>
            <select
              value={selectedReasonCode}
              onChange={(e) => setSelectedReasonCode(e.target.value)}
              className="w-full bg-[#0A0A0B] text-white border border-[#1F1F23] p-2 rounded-lg focus:outline-none focus:border-[#F27D26] cursor-pointer"
            >
              {reasons.map((r) => (
                <option key={r.code} value={r.code}>
                  {r.code} — {r.name} ({r.category})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[#636366] uppercase mb-1">SIMULATED SIGNAL NOTES:</label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Photo-eye pulse dropped on conveyor track..."
              className="w-full bg-[#0A0A0B] border border-[#1F1F23] rounded-lg p-2 text-white focus:outline-none focus:border-[#F27D26]"
            />
          </div>

          <button
            onClick={handleInject}
            className="w-full py-2.5 bg-[#F27D26] hover:bg-[#F27D26]/90 text-black font-bold rounded-lg transition cursor-pointer uppercase tracking-wider"
          >
            INJECT HARDWARE SIGNAL NOW
          </button>
        </div>
      </div>
    </div>
  );
};
