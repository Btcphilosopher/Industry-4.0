import React, { useState, useEffect } from 'react';
import {
  BarChart3,
  PoundSterling,
  AlertTriangle,
  TrendingDown,
  Layers,
  PieChart,
} from 'lucide-react';
import { DowntimeParetoItem, MachineMetrics } from '../types';

interface ParetoAnalyticsProps {
  machines: MachineMetrics[];
}

export const ParetoAnalytics: React.FC<ParetoAnalyticsProps> = ({ machines }) => {
  const [paretoItems, setParetoItems] = useState<DowntimeParetoItem[]>([]);

  useEffect(() => {
    fetch('/api/analytics/pareto')
      .then((res) => res.json())
      .then((data) => setParetoItems(data))
      .catch((err) => console.error(err));
  }, []);

  const totalDowntimeSec = paretoItems.reduce((acc, p) => acc + p.total_duration_sec, 0);
  const totalCostLost = paretoItems.reduce((acc, p) => acc + p.estimated_cost, 0);

  const topLoss = paretoItems[0];

  return (
    <div className="max-w-[1700px] mx-auto p-4 md:p-6 space-y-6 font-mono text-[#E1E1E6]">
      {/* Title Header */}
      <div className="flex items-center justify-between bg-[#0F0F12] border border-[#1F1F23] p-4 rounded-xl">
        <div className="flex items-center space-x-3">
          <BarChart3 className="w-6 h-6 text-[#F27D26]" />
          <div>
            <h1 className="text-base font-bold text-white uppercase tracking-wider">
              FACTORY DOWNTIME PARETO & COST INTELLIGENCE
            </h1>
            <p className="text-xs text-[#8E8E93]">
              Root-cause downtime ranking and real-time economic loss analysis
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-6 text-xs font-bold">
          <div>
            <span className="text-[#636366] uppercase">TOP CAUSE: </span>
            <span className="text-[#F27D26]">{topLoss?.reason_name || 'N/A'}</span>
          </div>
          <div>
            <span className="text-[#636366] uppercase">TOTAL COST TODAY: </span>
            <span className="text-[#FF3B30]">£{totalCostLost.toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Top Loss Spotlight Banner */}
      {topLoss && (
        <div className="bg-[#0F0F12] border border-[#F27D26]/40 p-6 rounded-2xl flex flex-wrap items-center justify-between gap-6 shadow-xl relative overflow-hidden">
          <div className="space-y-1 z-10">
            <div className="text-xs text-[#F27D26] font-bold uppercase tracking-wider">
              #1 PRIMARY LOSS DRIVER
            </div>
            <div className="text-2xl font-bold text-white">{topLoss.reason_name}</div>
            <div className="text-xs text-[#8E8E93]">
              Category: {topLoss.category} &gt; {topLoss.subcategory} ({topLoss.code})
            </div>
          </div>

          <div className="flex items-center space-x-8 text-center text-xs z-10">
            <div>
              <div className="text-[#636366] font-bold uppercase">TOTAL DURATION</div>
              <div className="text-xl font-bold text-[#FF3B30] mt-1">
                {Math.round(topLoss.total_duration_sec / 60)} mins
              </div>
            </div>

            <div>
              <div className="text-[#636366] font-bold uppercase">% OF DOWNTIME</div>
              <div className="text-xl font-bold text-[#F27D26] mt-1">
                {topLoss.percentage_of_downtime}%
              </div>
            </div>

            <div>
              <div className="text-[#636366] font-bold uppercase">ESTIMATED FINANCIAL LOSS</div>
              <div className="text-xl font-bold text-[#34C759] mt-1">
                £{topLoss.estimated_cost.toLocaleString()}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Pareto Table & Ranking */}
      <div className="bg-[#0F0F12] border border-[#1F1F23] p-6 rounded-2xl space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-bold uppercase tracking-widest text-[#636366]">
            DOWNTIME CAUSE PARETO RANKING (80/20 ANALYSIS)
          </h2>
          <span className="text-xs text-[#636366] font-bold">RANKED BY TOTAL TIME LOST</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-[#1F1F23] text-[#636366] uppercase font-bold">
                <th className="py-3 px-2">RANK</th>
                <th className="py-3 px-2">CODE</th>
                <th className="py-3 px-2">REASON NAME</th>
                <th className="py-3 px-2">CATEGORY</th>
                <th className="py-3 px-2">OCCURRENCES</th>
                <th className="py-3 px-2">TOTAL DURATION</th>
                <th className="py-3 px-2">% DOWNTIME</th>
                <th className="py-3 px-2">EST. COST (£)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1F1F23]">
              {paretoItems.map((item, idx) => (
                <tr key={item.code} className="hover:bg-[#1F1F23]/40 transition">
                  <td className="py-3 px-2 font-bold text-[#F27D26]">#{idx + 1}</td>
                  <td className="py-3 px-2 text-[#8E8E93]">{item.code}</td>
                  <td className="py-3 px-2 font-bold text-white">{item.reason_name}</td>
                  <td className="py-3 px-2 text-[#8E8E93]">{item.category}</td>
                  <td className="py-3 px-2 text-[#E1E1E6]">{item.occurrences} stops</td>
                  <td className="py-3 px-2 font-bold text-[#FF3B30]">
                    {Math.round(item.total_duration_sec / 60)} mins
                  </td>
                  <td className="py-3 px-2 text-[#F27D26] font-bold">
                    {item.percentage_of_downtime}%
                  </td>
                  <td className="py-3 px-2 font-bold text-[#34C759]">
                    £{item.estimated_cost.toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
