import React from 'react';
import { Cpu, ShieldCheck, AlertTriangle, Activity, HeartPulse } from 'lucide-react';
import { MachineMetrics } from '../types';

interface ReliabilityAnalyticsProps {
  machines: MachineMetrics[];
}

export const ReliabilityAnalytics: React.FC<ReliabilityAnalyticsProps> = ({ machines }) => {
  return (
    <div className="max-w-[1700px] mx-auto p-4 md:p-6 space-y-6 font-mono text-[#E1E1E6]">
      {/* Title Header */}
      <div className="flex items-center justify-between bg-[#0F0F12] border border-[#1F1F23] p-4 rounded-xl">
        <div className="flex items-center space-x-3">
          <Cpu className="w-6 h-6 text-[#34C759]" />
          <div>
            <h1 className="text-base font-bold text-white uppercase tracking-wider">
              RELIABILITY ANALYTICS & PREDICTIVE MACHINE HEALTH
            </h1>
            <p className="text-xs text-[#8E8E93]">
              MTBF, MTTR, cycle drift detection, and probabilistic anomaly scores
            </p>
          </div>
        </div>
      </div>

      {/* Machine Reliability Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {machines.map((m) => {
          const health = m.reliability.health_score;
          const isHealthy = health >= 80;

          return (
            <div
              key={m.machine_id}
              className="bg-[#0F0F12] border border-[#1F1F23] rounded-2xl p-5 space-y-4"
            >
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-base font-bold text-white">{m.code}</div>
                  <div className="text-xs text-[#8E8E93]">{m.name}</div>
                </div>

                <div
                  className={`px-3 py-1 rounded-full text-xs font-bold border flex items-center space-x-1 ${
                    isHealthy
                      ? 'bg-[#34C759]/10 text-[#34C759] border-[#34C759]/30'
                      : 'bg-[#F27D26]/10 text-[#F27D26] border-[#F27D26]/30'
                  }`}
                >
                  <HeartPulse className="w-3.5 h-3.5" />
                  <span>HEALTH: {health}/100</span>
                </div>
              </div>

              {/* Metrics */}
              <div className="grid grid-cols-2 gap-3 text-xs bg-[#0A0A0B] p-3 rounded-xl border border-[#1F1F23]">
                <div>
                  <div className="text-[#636366] text-[10px] font-bold uppercase">MTBF</div>
                  <div className="text-sm font-bold text-white mt-0.5">
                    {m.reliability.mtbf_hours} hours
                  </div>
                </div>

                <div>
                  <div className="text-[#636366] text-[10px] font-bold uppercase">MTTR</div>
                  <div className="text-sm font-bold text-[#F27D26] mt-0.5">
                    {m.reliability.mttr_minutes} mins
                  </div>
                </div>

                <div>
                  <div className="text-[#636366] text-[10px] font-bold uppercase">ANOMALY SCORE</div>
                  <div className="text-sm font-bold text-[#F27D26] mt-0.5">
                    {m.reliability.anomaly_score}/100
                  </div>
                </div>

                <div>
                  <div className="text-[#636366] text-[10px] font-bold uppercase">STOP FREQUENCY</div>
                  <div className="text-sm font-bold text-white mt-0.5">
                    {m.stop_count} stops today
                  </div>
                </div>
              </div>

              {/* Warning Alert if any */}
              {m.reliability.failure_warning ? (
                <div className="bg-[#F27D26]/10 border border-[#F27D26]/30 p-2.5 rounded-lg flex items-center space-x-2 text-xs text-[#F27D26]">
                  <AlertTriangle className="w-4 h-4 text-[#F27D26] flex-shrink-0" />
                  <span className="font-bold">{m.reliability.failure_warning}</span>
                </div>
              ) : (
                <div className="bg-[#34C759]/10 border border-[#34C759]/20 p-2.5 rounded-lg flex items-center space-x-2 text-xs text-[#34C759]">
                  <ShieldCheck className="w-4 h-4 text-[#34C759] flex-shrink-0" />
                  <span className="font-bold">Normal operating patterns detected</span>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
