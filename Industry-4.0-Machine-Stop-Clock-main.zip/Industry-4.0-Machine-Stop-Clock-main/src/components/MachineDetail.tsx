import React, { useState, useEffect } from 'react';
import {
  Activity,
  BarChart3,
  Clock,
  RotateCcw,
  Tag,
  ZoomIn,
  ZoomOut,
  Calendar,
  Layers,
  ChevronRight,
  ShieldAlert,
} from 'lucide-react';
import {
  MachineMetrics,
  TimelineBlock,
  MachineEvent,
  DowntimeParetoItem,
  ReasonCode,
} from '../types';
import { MachineStateMachine } from '../../server/engine/state_machine';

interface MachineDetailProps {
  machines: MachineMetrics[];
  selectedMachineId: string;
  setSelectedMachineId: (id: string) => void;
  reasons: ReasonCode[];
  onOverrideState: (machineId: string, action: any, reasonCode?: string, notes?: string) => void;
}

export const MachineDetail: React.FC<MachineDetailProps> = ({
  machines,
  selectedMachineId,
  setSelectedMachineId,
  reasons,
  onOverrideState,
}) => {
  const machine = machines.find((m) => m.machine_id === selectedMachineId) || machines[0];

  const [timelineBlocks, setTimelineBlocks] = useState<TimelineBlock[]>([]);
  const [eventLog, setEventLog] = useState<MachineEvent[]>([]);
  const [paretoData, setParetoData] = useState<DowntimeParetoItem[]>([]);
  const [timelineZoom, setTimelineZoom] = useState<'SHIFT' | 'HOUR' | '15MIN'>('SHIFT');

  useEffect(() => {
    if (!machine) return;

    // Fetch timeline blocks
    fetch(`/api/machines/${machine.machine_id}/timeline`)
      .then((res) => res.json())
      .then((data) => setTimelineBlocks(data))
      .catch((err) => console.error(err));

    // Fetch event log
    fetch(`/api/machines/${machine.machine_id}/events?limit=50`)
      .then((res) => res.json())
      .then((data) => setEventLog(data))
      .catch((err) => console.error(err));

    // Fetch pareto
    fetch(`/api/machines/${machine.machine_id}/pareto`)
      .then((res) => res.json())
      .then((data) => setParetoData(data))
      .catch((err) => console.error(err));
  }, [machine?.machine_id, machine?.last_event_time]);

  if (!machine) return null;

  const formatSec = (sec: number) => {
    const hours = Math.floor(sec / 3600);
    const mins = Math.floor((sec % 3600) / 60);
    if (hours > 0) return `${hours}h ${mins}m`;
    return `${mins}m`;
  };

  return (
    <div className="max-w-[1700px] mx-auto p-4 md:p-6 space-y-6 font-mono">
      {/* Top Selector & Asset Breadcrumb */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#0F0F12] border border-[#1F1F23] p-4 rounded-xl text-xs">
        <div className="flex items-center space-x-3">
          <span className="text-[#636366] font-bold uppercase tracking-wider">MACHINE:</span>
          <select
            value={machine.machine_id}
            onChange={(e) => setSelectedMachineId(e.target.value)}
            className="bg-[#0A0A0B] text-white border border-[#1F1F23] px-4 py-2 rounded-lg font-bold text-sm focus:outline-none focus:border-[#F27D26] cursor-pointer"
          >
            {machines.map((m) => (
              <option key={m.machine_id} value={m.machine_id}>
                {m.code} — {m.name}
              </option>
            ))}
          </select>
        </div>

        <div className="text-[#8E8E93]">
          <span className="text-[#636366] font-bold uppercase tracking-wider">ASSET PATH: </span>
          <span className="text-white font-bold">{machine.code} • Enterprise / Site 1 / Machining Line 01</span>
        </div>
      </div>

      {/* Machine Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3 text-xs">
        <div className="bg-[#0F0F12] border border-[#1F1F23] p-4 rounded-xl">
          <div className="text-[#636366] text-[10px] font-bold uppercase tracking-widest">CURRENT STATE</div>
          <div
            className={`text-lg font-bold mt-1 ${
              machine.current_state === 'RUNNING'
                ? 'text-[#34C759]'
                : machine.current_state === 'FAULT'
                ? 'text-[#FF3B30]'
                : 'text-[#F27D26]'
            }`}
          >
            {machine.current_state}
          </div>
          <div className="text-[10px] text-[#636366] mt-0.5">
            Dur: {Math.floor(machine.current_stop_duration_sec || machine.current_run_duration_sec)}s
          </div>
        </div>

        <div className="bg-[#0F0F12] border border-[#1F1F23] p-4 rounded-xl">
          <div className="text-[#636366] text-[10px] font-bold uppercase tracking-widest">RUNTIME TODAY</div>
          <div className="text-lg font-bold text-white mt-1">
            {formatSec(machine.total_runtime_sec)}
          </div>
          <div className="text-[10px] text-[#636366] mt-0.5">Operating Time</div>
        </div>

        <div className="bg-[#0F0F12] border border-[#1F1F23] p-4 rounded-xl">
          <div className="text-[#636366] text-[10px] font-bold uppercase tracking-widest">DOWNTIME TODAY</div>
          <div className="text-lg font-bold text-[#FF3B30] mt-1">
            {formatSec(machine.total_downtime_sec)}
          </div>
          <div className="text-[10px] text-[#636366] mt-0.5">
            {machine.stop_count} stops
          </div>
        </div>

        <div className="bg-[#0F0F12] border border-[#1F1F23] p-4 rounded-xl">
          <div className="text-[#636366] text-[10px] font-bold uppercase tracking-widest">OEE TODAY</div>
          <div
            className={`text-lg font-bold mt-1 ${
              machine.oee.oee >= 0.85 ? 'text-[#34C759]' : 'text-[#F27D26]'
            }`}
          >
            {(machine.oee.oee * 100).toFixed(1)}%
          </div>
          <div className="text-[10px] text-[#636366] mt-0.5">
            A:{(machine.oee.availability * 100).toFixed(0)}% P:
            {(machine.oee.performance * 100).toFixed(0)}% Q:
            {(machine.oee.quality * 100).toFixed(0)}%
          </div>
        </div>

        <div className="bg-[#0F0F12] border border-[#1F1F23] p-4 rounded-xl">
          <div className="text-[#636366] text-[10px] font-bold uppercase tracking-widest">MTBF</div>
          <div className="text-lg font-bold text-white mt-1">
            {machine.reliability.mtbf_hours} hrs
          </div>
          <div className="text-[10px] text-[#636366] mt-0.5">Mean Time Between Failures</div>
        </div>

        <div className="bg-[#0F0F12] border border-[#1F1F23] p-4 rounded-xl">
          <div className="text-[#636366] text-[10px] font-bold uppercase tracking-widest">MTTR</div>
          <div className="text-lg font-bold text-[#F27D26] mt-1">
            {machine.reliability.mttr_minutes} mins
          </div>
          <div className="text-[10px] text-[#636366] mt-0.5">Mean Time To Repair</div>
        </div>

        <div className="bg-[#0F0F12] border border-[#1F1F23] p-4 rounded-xl">
          <div className="text-[#636366] text-[10px] font-bold uppercase tracking-widest">PRODUCED PARTS</div>
          <div className="text-lg font-bold text-[#34C759] mt-1">
            {machine.production.good_count}
          </div>
          <div className="text-[10px] text-[#636366] mt-0.5">
            Rejects: {machine.production.reject_count}
          </div>
        </div>
      </div>

      {/* High-Resolution Horizontal Timeline */}
      <div className="bg-[#0F0F12] border border-[#1F1F23] p-5 rounded-2xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Clock className="w-4 h-4 text-[#F27D26]" />
            <h2 className="text-xs uppercase tracking-widest font-bold text-[#636366]">
              HIGH-RESOLUTION MACHINE PRODUCTION TIMELINE
            </h2>
          </div>

          {/* Zoom controls */}
          <div className="flex items-center space-x-1 bg-[#0A0A0B] border border-[#1F1F23] p-1 rounded-lg text-xs">
            <span className="text-[#636366] mr-2 px-1 font-bold">ZOOM:</span>
            {(['SHIFT', 'HOUR', '15MIN'] as const).map((z) => (
              <button
                key={z}
                onClick={() => setTimelineZoom(z)}
                className={`px-2.5 py-1 rounded transition cursor-pointer font-bold ${
                  timelineZoom === z
                    ? 'bg-[#F27D26] text-black'
                    : 'text-[#8E8E93] hover:text-white'
                }`}
              >
                {z}
              </button>
            ))}
          </div>
        </div>

        {/* Timeline Horizontal Axis */}
        <div className="space-y-2">
          <div className="h-12 bg-[#0A0A0B] rounded-xl border border-[#1F1F23] flex overflow-hidden relative">
            {timelineBlocks.length === 0 ? (
              <div className="w-full flex items-center justify-center text-slate-600 text-xs">
                Generating live timeline blocks...
              </div>
            ) : (
              timelineBlocks.map((block) => {
                const color = MachineStateMachine.getStateColor(block.state);
                return (
                  <div
                    key={block.id}
                    style={{
                      flexGrow: Math.max(1, block.duration_sec),
                      backgroundColor: color,
                    }}
                    title={`${block.state} (${block.duration_sec}s) — ${
                      block.reason?.name || 'Running'
                    }`}
                    className="h-full border-r border-slate-950/40 hover:opacity-80 transition cursor-pointer"
                  />
                );
              })
            )}
          </div>

          {/* Time Labels */}
          <div className="flex justify-between text-[10px] text-[#636366] px-1 font-bold">
            <span>06:00 (Shift Start)</span>
            <span>08:00</span>
            <span>10:00</span>
            <span>12:00</span>
            <span>14:00 (Shift End)</span>
          </div>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap items-center gap-4 text-[11px] text-[#8E8E93] pt-2 border-t border-[#1F1F23]">
          <LegendItem color="#34C759" label="RUNNING" />
          <LegendItem color="#F27D26" label="STOPPED" />
          <LegendItem color="#FF3B30" label="FAULT" />
          <LegendItem color="#AF52DE" label="CHANGEOVER" />
          <LegendItem color="#007AFF" label="MAINTENANCE" />
          <LegendItem color="#FF9500" label="MICRO-STOP / IDLE" />
        </div>
      </div>

      {/* Pareto & Event Log Side-by-Side */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Downtime Pareto Chart */}
        <div className="bg-[#0F0F12] border border-[#1F1F23] p-5 rounded-2xl space-y-4">
          <div className="flex items-center space-x-2">
            <BarChart3 className="w-4 h-4 text-[#F27D26]" />
            <h2 className="text-xs font-bold uppercase tracking-widest text-[#636366]">
              DOWNTIME PARETO — TOP LOSS CAUSES
            </h2>
          </div>

          <div className="space-y-3">
            {paretoData.length === 0 ? (
              <div className="text-[#636366] text-xs py-8 text-center font-bold">
                No downtime recorded yet.
              </div>
            ) : (
              paretoData.slice(0, 5).map((p, idx) => (
                <div key={p.code} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-white font-bold">
                      {idx + 1}. {p.reason_name} ({p.code})
                    </span>
                    <span className="text-[#F27D26] font-bold">
                      {Math.round(p.total_duration_sec / 60)} min ({p.percentage_of_downtime}%) — £
                      {p.estimated_cost}
                    </span>
                  </div>
                  <div className="h-2 bg-[#0A0A0B] rounded-full overflow-hidden border border-[#1F1F23]">
                    <div
                      style={{ width: `${Math.min(100, p.percentage_of_downtime)}%` }}
                      className="h-full bg-[#F27D26] rounded-full"
                    />
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Append-Only Event Store Log */}
        <div className="bg-[#0F0F12] border border-[#1F1F23] p-5 rounded-2xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Activity className="w-4 h-4 text-[#34C759]" />
              <h2 className="text-xs font-bold uppercase tracking-widest text-[#636366]">
                APPEND-ONLY TIME-SERIES EVENT LOG
              </h2>
            </div>
            <span className="text-[10px] text-[#636366] font-bold">IMMUTABLE LOG</span>
          </div>

          <div className="max-h-64 overflow-y-auto space-y-2 pr-1 text-xs">
            {eventLog.length === 0 ? (
              <div className="text-[#636366] text-xs py-8 text-center font-bold">
                No events recorded yet.
              </div>
            ) : (
              eventLog.map((ev) => (
                <div
                  key={ev.id}
                  className="bg-[#0A0A0B] border border-[#1F1F23] p-2.5 rounded-lg flex items-center justify-between text-[11px]"
                >
                  <div>
                    <div className="text-white font-bold">
                      {ev.previous_state} → {ev.new_state}
                    </div>
                    <div className="text-[#8E8E93] text-[10px]">
                      {ev.reason_code?.name || 'Normal Transition'} ({ev.source})
                    </div>
                  </div>

                  <div className="text-right text-[#8E8E93] font-mono text-[10px] font-bold">
                    {new Date(ev.timestamp).toLocaleTimeString()}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const LegendItem: React.FC<{ color: string; label: string }> = ({ color, label }) => (
  <div className="flex items-center space-x-1.5">
    <span className="w-3 h-3 rounded" style={{ backgroundColor: color }} />
    <span>{label}</span>
  </div>
);
