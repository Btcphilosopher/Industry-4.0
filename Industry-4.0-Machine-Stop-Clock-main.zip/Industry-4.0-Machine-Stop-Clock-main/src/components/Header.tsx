import React, { useState, useEffect } from 'react';
import {
  Factory,
  Clock,
  Activity,
  BarChart3,
  Cpu,
  Monitor,
  RotateCcw,
  Sliders,
  Shield,
  Download,
  Flame,
} from 'lucide-react';
import { FactorySummary, UserRole } from '../types';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  summary: FactorySummary | null;
  role: UserRole;
  setRole: (role: UserRole) => void;
  onOpenExport: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  summary,
  role,
  setRole,
  onOpenExport,
}) => {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 250);
    return () => clearInterval(timer);
  }, []);

  const formatUtcTime = (d: Date) => {
    return d.toISOString().replace('T', ' ').substring(0, 22) + ' UTC';
  };

  return (
    <header className="bg-slate-950 border-b border-slate-800 text-slate-100 sticky top-0 z-50">
      {/* Top Banner */}
      <div className="max-w-[1700px] mx-auto px-4 py-2.5 flex flex-wrap items-center justify-between gap-4">
        {/* Brand Logo & Name */}
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-lg bg-emerald-950 border border-emerald-500/40 flex items-center justify-center text-emerald-400 font-mono font-bold shadow-lg shadow-emerald-900/20">
            <Flame className="w-6 h-6 text-emerald-400" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-mono font-black tracking-wider text-base text-slate-100">
                RUST INDUSTRY 4.0
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/30">
                EDGE ENGINE v2.4
              </span>
            </div>
            <p className="text-xs text-slate-400 font-mono">
              Machine Stop Clock & Downtime Intelligence
            </p>
          </div>
        </div>

        {/* Live Clock & UTC Monotonic Engine */}
        <div className="hidden lg:flex items-center space-x-6 bg-slate-900/80 px-4 py-1.5 rounded-lg border border-slate-800 font-mono text-xs">
          <div className="flex items-center space-x-2">
            <Clock className="w-4 h-4 text-emerald-400 animate-pulse" />
            <span className="text-slate-300 font-medium">HIGH-PRECISION CLOCK:</span>
            <span className="text-emerald-300 font-bold tracking-tight">
              {formatUtcTime(time)}
            </span>
          </div>
          <div className="h-4 w-px bg-slate-800" />
          <div className="flex items-center space-x-2 text-slate-400">
            <span>MONOTONIC:</span>
            <span className="text-slate-200">ACTIVE (ns)</span>
          </div>
        </div>

        {/* Factory Quick Status & Role Selector */}
        <div className="flex items-center space-x-3">
          {summary && (
            <div className="hidden sm:flex items-center space-x-3 bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-800 text-xs font-mono">
              <div>
                <span className="text-slate-400">OEE: </span>
                <span className={`font-bold ${summary.overall_oee >= 0.85 ? 'text-emerald-400' : 'text-amber-400'}`}>
                  {(summary.overall_oee * 100).toFixed(1)}%
                </span>
              </div>
              <div className="text-slate-700">|</div>
              <div>
                <span className="text-slate-400">ACTIVE: </span>
                <span className="text-slate-200 font-bold">
                  {summary.active_machines_count} / {summary.total_machines_count}
                </span>
              </div>
            </div>
          )}

          {/* Role selector */}
          <div className="flex items-center space-x-1 bg-slate-900 border border-slate-800 rounded-lg p-1 text-xs">
            <Shield className="w-3.5 h-3.5 text-slate-400 ml-1" />
            <select
              value={role}
              onChange={(e) => setRole(e.target.value as UserRole)}
              className="bg-transparent text-slate-200 font-mono text-xs focus:outline-none cursor-pointer pr-1"
            >
              <option value="operator">Operator</option>
              <option value="engineer">Engineer</option>
              <option value="manager">Manager</option>
              <option value="administrator">Admin</option>
            </select>
          </div>

          <button
            onClick={onOpenExport}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 text-xs font-mono transition cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-slate-400" />
            <span className="hidden sm:inline">EXPORT</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="border-t border-slate-900 bg-slate-950/90 px-4">
        <div className="max-w-[1700px] mx-auto flex items-center space-x-1 overflow-x-auto py-1 scrollbar-none font-mono text-xs">
          <NavTab
            id="overview"
            label="FACTORY BOARD"
            icon={<Factory className="w-4 h-4" />}
            active={activeTab === 'overview'}
            onClick={() => setActiveTab('overview')}
          />
          <NavTab
            id="stopclock"
            label="STOP CLOCK"
            icon={<Clock className="w-4 h-4" />}
            active={activeTab === 'stopclock'}
            onClick={() => setActiveTab('stopclock')}
            badge="LIVE"
          />
          <NavTab
            id="analytics"
            label="MACHINE DETAIL"
            icon={<Activity className="w-4 h-4" />}
            active={activeTab === 'analytics'}
            onClick={() => setActiveTab('analytics')}
          />
          <NavTab
            id="pareto"
            label="DOWNTIME PARETO"
            icon={<BarChart3 className="w-4 h-4" />}
            active={activeTab === 'pareto'}
            onClick={() => setActiveTab('pareto')}
          />
          <NavTab
            id="reliability"
            label="RELIABILITY & AI"
            icon={<Cpu className="w-4 h-4" />}
            active={activeTab === 'reliability'}
            onClick={() => setActiveTab('reliability')}
          />
          <NavTab
            id="andon"
            label="DIGITAL ANDON"
            icon={<Monitor className="w-4 h-4" />}
            active={activeTab === 'andon'}
            onClick={() => setActiveTab('andon')}
          />
          <NavTab
            id="replay"
            label="EVENT REPLAY"
            icon={<RotateCcw className="w-4 h-4" />}
            active={activeTab === 'replay'}
            onClick={() => setActiveTab('replay')}
          />
          <NavTab
            id="simulator"
            label="SIGNALS & SIMULATOR"
            icon={<Sliders className="w-4 h-4" />}
            active={activeTab === 'simulator'}
            onClick={() => setActiveTab('simulator')}
          />
        </div>
      </div>
    </header>
  );
};

interface NavTabProps {
  id: string;
  label: string;
  icon: React.ReactNode;
  active: boolean;
  onClick: () => void;
  badge?: string;
}

const NavTab: React.FC<NavTabProps> = ({ label, icon, active, onClick, badge }) => (
  <button
    onClick={onClick}
    className={`flex items-center space-x-2 px-3 py-2 rounded-md font-mono text-xs font-medium transition cursor-pointer whitespace-nowrap ${
      active
        ? 'bg-slate-800 text-emerald-400 border border-slate-700 shadow-sm'
        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
    }`}
  >
    <span>{icon}</span>
    <span>{label}</span>
    {badge && (
      <span className="ml-1 text-[9px] font-bold px-1.5 py-0.2 rounded bg-red-500/20 text-red-400 border border-red-500/30 animate-pulse">
        {badge}
      </span>
    )}
  </button>
);
