import React from 'react';
import { Download, FileSpreadsheet, FileJson, X } from 'lucide-react';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const handleDownload = (format: 'csv' | 'json') => {
    window.open(`/api/export?format=${format}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 font-mono">
      <div className="bg-[#0F0F12] border border-[#1F1F23] rounded-2xl max-w-md w-full p-6 space-y-6 text-[#E1E1E6] shadow-2xl">
        <div className="flex items-center justify-between border-b border-[#1F1F23] pb-3">
          <div className="flex items-center space-x-2 text-[#34C759] font-bold text-xs uppercase tracking-wider">
            <Download className="w-5 h-5 text-[#F27D26]" />
            <span className="text-white">EXPORT FACTORY DOWNTIME REPORT</span>
          </div>
          <button onClick={onClose} className="text-[#8E8E93] hover:text-white cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-xs text-[#8E8E93]">
          Download structured time-series report containing state transitions, OEE calculations, micro-stops, and financial loss metrics.
        </p>

        <div className="space-y-3 font-bold">
          <button
            onClick={() => handleDownload('csv')}
            className="w-full flex items-center justify-between p-4 bg-[#0A0A0B] hover:bg-[#1F1F23] border border-[#1F1F23] hover:border-[#34C759]/50 rounded-xl transition cursor-pointer group"
          >
            <div className="flex items-center space-x-3">
              <FileSpreadsheet className="w-6 h-6 text-[#34C759]" />
              <div className="text-left">
                <div className="text-xs font-bold text-white">CSV EXPORT (.csv)</div>
                <div className="text-[10px] text-[#636366]">Excel / PowerBI compatible table</div>
              </div>
            </div>
            <span className="text-xs text-[#34C759] font-bold">DOWNLOAD</span>
          </button>

          <button
            onClick={() => handleDownload('json')}
            className="w-full flex items-center justify-between p-4 bg-[#0A0A0B] hover:bg-[#1F1F23] border border-[#1F1F23] hover:border-[#F27D26]/50 rounded-xl transition cursor-pointer group"
          >
            <div className="flex items-center space-x-3">
              <FileJson className="w-6 h-6 text-[#F27D26]" />
              <div className="text-left">
                <div className="text-xs font-bold text-white">JSON EXPORT (.json)</div>
                <div className="text-[10px] text-[#636366]">Full time-series objects & metrics</div>
              </div>
            </div>
            <span className="text-xs text-[#F27D26] font-bold">DOWNLOAD</span>
          </button>
        </div>

        <div className="flex justify-end pt-2">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-[#1F1F23] hover:bg-[#2C2C2E] text-white rounded-lg text-xs font-bold cursor-pointer"
          >
            CLOSE
          </button>
        </div>
      </div>
    </div>
  );
};
