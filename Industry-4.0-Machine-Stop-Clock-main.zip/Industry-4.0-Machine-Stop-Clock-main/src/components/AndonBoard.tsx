import React, { useState, useEffect } from 'react';
import { Monitor, Maximize2, Minimize2, Flame } from 'lucide-react';
import { MachineMetrics } from '../types';

interface AndonBoardProps {
  machines: MachineMetrics[];
}

export const AndonBoard: React.FC<AndonBoardProps> = ({ machines }) => {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatSec = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const secs = Math.floor(sec % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div
      className={`bg-[#0A0A0B] font-mono text-[#E1E1E6] ${
        isFullscreen ? 'fixed inset-0 z-50 p-8 overflow-y-auto' : 'max-w-[1700px] mx-auto p-4 md:p-6 space-y-6'
      }`}
    >
      {/* Top Andon Header */}
      <div className="flex items-center justify-between border-b border-[#1F1F23] pb-4">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-[#0F0F12] border border-[#F27D26]/40 rounded-xl flex items-center justify-center text-[#F27D26]">
            <Flame className="w-8 h-8" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white tracking-wider uppercase">
              SHOP FLOOR DIGITAL ANDON BOARD
            </h1>
            <p className="text-xs text-[#8E8E93]">
              REAL-TIME FACTORY LINE STATUS & STOP CLOCKS
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-6">
          <div className="text-right">
            <div className="text-[10px] text-[#636366] font-bold uppercase tracking-wider">FACTORY TIME (UTC)</div>
            <div className="text-xl font-bold text-[#34C759]">
              {now.toLocaleTimeString()}
            </div>
          </div>

          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-3 bg-[#0F0F12] border border-[#1F1F23] rounded-xl hover:bg-[#1F1F23] text-white transition cursor-pointer"
          >
            {isFullscreen ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* High Visibility Overhead Line Banners */}
      <div className="space-y-4 pt-2">
        {machines.map((m) => {
          const isRunning = m.current_state === 'RUNNING';
          const isFault = m.current_state === 'FAULT';

          return (
            <div
              key={m.machine_id}
              className={`p-6 rounded-2xl border flex flex-wrap items-center justify-between gap-4 transition-all duration-300 ${
                isRunning
                  ? 'bg-[#0F0F12] border-[#34C759]/40 text-[#34C759]'
                  : isFault
                  ? 'bg-[#0F0F12] border-[#FF3B30] text-[#FF3B30] shadow-xl shadow-[#FF3B30]/10 animate-pulse'
                  : 'bg-[#0F0F12] border-[#F27D26]/40 text-[#F27D26]'
              }`}
            >
              {/* Machine Code & Line */}
              <div className="flex items-center space-x-6">
                <div className="text-2xl font-bold text-white">{m.code}</div>
                <div>
                  <div className="text-sm font-bold text-white">{m.name}</div>
                  <div className="text-xs text-[#8E8E93]">
                    Reason: {m.current_reason?.name || (isRunning ? 'Running Normal' : 'Unclassified Stop')}
                  </div>
                </div>
              </div>

              {/* State Indicator */}
              <div className="flex items-center space-x-6">
                <div className="text-center">
                  <div className="text-[10px] text-[#636366] font-bold uppercase tracking-widest">STATE</div>
                  <div className="text-xl font-bold">{m.current_state}</div>
                </div>

                <div className="text-center min-w-[120px]">
                  <div className="text-[10px] text-[#636366] font-bold uppercase tracking-widest">
                    {isRunning ? 'RUN TIME' : 'STOP TIME'}
                  </div>
                  <div className="text-3xl font-mono font-bold">
                    {formatSec(isRunning ? m.current_run_duration_sec : m.current_stop_duration_sec)}
                  </div>
                </div>

                <div className="text-center">
                  <div className="text-[10px] text-[#636366] font-bold uppercase tracking-widest">OEE</div>
                  <div className="text-xl font-bold">
                    {(m.oee.oee * 100).toFixed(1)}%
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
