import React, { useState } from 'react';
import {
  Factory,
  CheckCircle2,
  AlertOctagon,
  Clock,
  PoundSterling,
  Search,
  Filter,
  Play,
  Pause,
  ChevronRight,
  TrendingUp,
} from 'lucide-react';
import { FactorySummary, MachineMetrics, MachineState } from '../types';

interface FactoryOverviewProps {
  summary: FactorySummary | null;
  machines: MachineMetrics[];
  onSelectMachine: (id: string) => void;
  onOverrideState: (id: string, action: any) => void;
}

export const FactoryOverview: React.FC<FactoryOverviewProps> = ({
  summary,
  machines,
  onSelectMachine,
  onOverrideState,
}) => {
  const [filterState, setFilterState] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filtered = machines.filter((m) => {
    if (filterState !== 'ALL' && m.current_state !== filterState) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        m.name.toLowerCase().includes(q) ||
        m.code.toLowerCase().includes(q) ||
        m.line_id.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const formatSec = (sec: number) => {
    if (sec <= 0) return '--';
    const mins = Math.floor(sec / 60);
    const secs = Math.floor(sec % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="max-w-[1700px] mx-auto p-4 md:p-6 space-y-6 font-mono">
      {/* KPI Overview Banner */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-[#0F0F12] border border-[#1F1F23] p-4 rounded-xl shadow-sm">
          <div className="text-[#636366] text-[10px] font-bold uppercase tracking-widest">FACTORY OEE</div>
          <div className="text-2xl font-bold text-[#34C759] mt-1">
            {summary ? (summary.overall_oee * 100).toFixed(1) : '84.7'}%
          </div>
          <div className="text-[10px] text-[#636366] mt-1 flex items-center">
            <TrendingUp className="w-3 h-3 text-[#34C759] mr-1" /> Target: 85.0%
          </div>
        </div>

        <div className="bg-[#0F0F12] border border-[#1F1F23] p-4 rounded-xl shadow-sm">
          <div className="text-[#636366] text-[10px] font-bold uppercase tracking-widest">AVAILABILITY</div>
          <div className="text-2xl font-bold text-white mt-1">
            {summary ? (summary.availability * 100).toFixed(1) : '91.2'}%
          </div>
          <div className="text-[10px] text-[#636366] mt-1">Operating vs Planned</div>
        </div>

        <div className="bg-[#0F0F12] border border-[#1F1F23] p-4 rounded-xl shadow-sm">
          <div className="text-[#636366] text-[10px] font-bold uppercase tracking-widest">PERFORMANCE</div>
          <div className="text-2xl font-bold text-white mt-1">
            {summary ? (summary.performance * 100).toFixed(1) : '93.8'}%
          </div>
          <div className="text-[10px] text-[#636366] mt-1">Actual Speed vs Ideal</div>
        </div>

        <div className="bg-[#0F0F12] border border-[#1F1F23] p-4 rounded-xl shadow-sm">
          <div className="text-[#636366] text-[10px] font-bold uppercase tracking-widest">QUALITY</div>
          <div className="text-2xl font-bold text-white mt-1">
            {summary ? (summary.quality * 100).toFixed(1) : '99.0'}%
          </div>
          <div className="text-[10px] text-[#636366] mt-1">Good vs Total Count</div>
        </div>

        <div className="bg-[#0F0F12] border border-[#1F1F23] p-4 rounded-xl shadow-sm">
          <div className="text-[#636366] text-[10px] font-bold uppercase tracking-widest">ACTIVE DOWNTIME</div>
          <div className="text-2xl font-bold text-[#FF3B30] mt-1">
            {summary ? formatSec(summary.total_downtime_sec) : '03:42'}
          </div>
          <div className="text-[10px] text-[#636366] mt-1">Cumulative Today</div>
        </div>

        <div className="bg-[#0F0F12] border border-[#1F1F23] p-4 rounded-xl shadow-sm">
          <div className="text-[#636366] text-[10px] font-bold uppercase tracking-widest">CURRENT LOSSES</div>
          <div className="text-2xl font-bold text-[#F27D26] mt-1">
            £{summary ? summary.total_loss_cost_today.toLocaleString() : '3,241'}
          </div>
          <div className="text-[10px] text-[#636366] mt-1">Financial Impact</div>
        </div>
      </div>

      {/* Filtering Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#0F0F12] border border-[#1F1F23] p-3 rounded-xl text-xs">
        {/* Filter Pills */}
        <div className="flex items-center space-x-1 overflow-x-auto scrollbar-none py-1">
          <span className="text-[#636366] mr-2 flex items-center font-bold uppercase tracking-wider">
            <Filter className="w-3.5 h-3.5 mr-1" /> STATE:
          </span>
          {[
            'ALL',
            'RUNNING',
            'STOPPED',
            'FAULT',
            'MAINTENANCE',
            'CHANGEOVER',
            'NO_MATERIAL',
          ].map((st) => (
            <button
              key={st}
              onClick={() => setFilterState(st)}
              className={`px-3 py-1 rounded-md transition cursor-pointer font-bold ${
                filterState === st
                  ? 'bg-[#F27D26] text-black'
                  : 'text-[#8E8E93] hover:text-white hover:bg-[#1F1F23]'
              }`}
            >
              {st}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative min-w-[220px]">
          <Search className="w-4 h-4 text-[#636366] absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search code, name, line..."
            className="w-full bg-[#0A0A0B] border border-[#1F1F23] rounded-lg pl-9 pr-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#F27D26]"
          />
        </div>
      </div>

      {/* Machine Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((m) => {
          const isRunning = m.current_state === 'RUNNING';
          const isFault = m.current_state === 'FAULT';
          const isStopped = !isRunning;

          return (
            <div
              key={m.machine_id}
              className={`bg-[#0F0F12] rounded-2xl border transition-all duration-300 p-5 flex flex-col justify-between space-y-4 hover:border-[#F27D26]/40 ${
                isFault
                  ? 'border-[#FF3B30]/50 shadow-lg shadow-[#FF3B30]/10'
                  : isStopped
                  ? 'border-[#F27D26]/30'
                  : 'border-[#1F1F23]'
              }`}
            >
              {/* Card Header */}
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="font-bold text-white text-base">{m.code}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-[#1F1F23] text-[#8E8E93] border border-[#1F1F23] font-bold">
                      {m.line_id.toUpperCase()}
                    </span>
                  </div>
                  <div className="text-xs text-[#8E8E93] mt-0.5">{m.name}</div>
                </div>

                {/* State Badge */}
                <span
                  className={`px-3 py-1 rounded-full text-xs font-bold border flex items-center space-x-1.5 ${
                    isRunning
                      ? 'bg-[#34C759]/10 text-[#34C759] border-[#34C759]/30'
                      : isFault
                      ? 'bg-[#FF3B30]/20 text-[#FF3B30] border-[#FF3B30]/40 animate-pulse'
                      : 'bg-[#F27D26]/10 text-[#F27D26] border-[#F27D26]/30'
                  }`}
                >
                  <span
                    className={`w-2 h-2 rounded-full ${
                      isRunning ? 'bg-[#34C759]' : isFault ? 'bg-[#FF3B30]' : 'bg-[#F27D26]'
                    }`}
                  />
                  <span>{m.current_state}</span>
                </span>
              </div>

              {/* Stop Clock Display */}
              <div className="bg-[#0A0A0B] border border-[#1F1F23] p-4 rounded-xl text-center">
                <div className="text-[10px] text-[#636366] uppercase tracking-widest font-bold mb-1">
                  {isStopped ? 'CURRENT STOP DURATION' : 'RUNNING DURATION'}
                </div>
                <div
                  className={`text-3xl font-mono font-bold ${
                    isStopped ? 'text-[#F27D26]' : 'text-[#34C759]'
                  }`}
                >
                  {formatSec(isStopped ? m.current_stop_duration_sec : m.current_run_duration_sec)}
                </div>
                <div className="text-xs text-[#8E8E93] mt-1 line-clamp-1">
                  {m.current_reason?.name || (isRunning ? 'Normal Operation' : 'Unclassified Stop')}
                </div>
              </div>

              {/* OEE & Metrics Row */}
              <div className="grid grid-cols-3 gap-2 text-center text-xs border-t border-b border-[#1F1F23] py-3">
                <div>
                  <div className="text-[#636366] text-[10px] font-bold uppercase">OEE</div>
                  <div
                    className={`font-bold text-sm ${
                      m.oee.oee >= 0.85 ? 'text-[#34C759]' : 'text-[#F27D26]'
                    }`}
                  >
                    {(m.oee.oee * 100).toFixed(1)}%
                  </div>
                </div>

                <div>
                  <div className="text-[#636366] text-[10px] font-bold uppercase">SPEED / CYCLE</div>
                  <div className="font-bold text-white text-sm">
                    {m.cycle_stats.mean_sec}s
                  </div>
                </div>

                <div>
                  <div className="text-[#636366] text-[10px] font-bold uppercase">PARTS TODAY</div>
                  <div className="font-bold text-white text-sm">
                    {m.production.good_count}
                  </div>
                </div>
              </div>

              {/* Action Bar */}
              <div className="flex items-center justify-between pt-1">
                <button
                  onClick={() => onSelectMachine(m.machine_id)}
                  className="flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-[#1F1F23] hover:bg-[#2C2C2E] text-white text-xs font-bold transition cursor-pointer"
                >
                  <span>STOP CLOCK / DETAIL</span>
                  <ChevronRight className="w-3.5 h-3.5 text-[#8E8E93]" />
                </button>

                <div className="flex items-center space-x-1">
                  {isStopped ? (
                    <button
                      onClick={() => onOverrideState(m.machine_id, 'RUN')}
                      className="px-2.5 py-1.5 rounded-lg bg-[#34C759]/10 text-[#34C759] border border-[#34C759]/30 hover:bg-[#34C759]/20 text-xs font-bold transition cursor-pointer"
                    >
                      [START]
                    </button>
                  ) : (
                    <button
                      onClick={() => onOverrideState(m.machine_id, 'STOP')}
                      className="px-2.5 py-1.5 rounded-lg bg-[#FF3B30]/10 text-[#FF3B30] border border-[#FF3B30]/30 hover:bg-[#FF3B30]/20 text-xs font-bold transition cursor-pointer"
                    >
                      [STOP]
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
