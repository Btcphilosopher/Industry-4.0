import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { FactoryOverview } from './components/FactoryOverview';
import { StopClockView } from './components/StopClockView';
import { MachineDetail } from './components/MachineDetail';
import { ParetoAnalytics } from './components/ParetoAnalytics';
import { ReliabilityAnalytics } from './components/ReliabilityAnalytics';
import { AndonBoard } from './components/AndonBoard';
import { EventReplayView } from './components/EventReplayView';
import { SimulatorControls } from './components/SimulatorControls';
import { ExportModal } from './components/ExportModal';
import { FactorySummary, MachineMetrics, ReasonCode, UserRole } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [role, setRole] = useState<UserRole>('operator');
  const [summary, setSummary] = useState<FactorySummary | null>(null);
  const [machines, setMachines] = useState<MachineMetrics[]>([]);
  const [selectedMachineId, setSelectedMachineId] = useState<string>('');
  const [reasons, setReasons] = useState<ReasonCode[]>([]);
  const [isExportOpen, setIsExportOpen] = useState<boolean>(false);

  // Fetch initial factory data
  const fetchData = async () => {
    try {
      const [sumRes, machRes, reasRes] = await Promise.all([
        fetch('/api/factory/summary'),
        fetch('/api/machines'),
        fetch('/api/analytics/reasons'),
      ]);

      const sumData = await sumRes.json();
      const machData: MachineMetrics[] = await machRes.json();
      const reasData = await reasRes.json();

      setSummary(sumData);
      setMachines(machData);
      setReasons(reasData);

      if (!selectedMachineId && machData.length > 0) {
        setSelectedMachineId(machData[0].machine_id);
      }
    } catch (err) {
      console.error('[App] Error fetching factory data:', err);
    }
  };

  useEffect(() => {
    fetchData();

    // SSE Stream for real-time telemetry updates
    const eventSource = new EventSource('/api/stream');

    eventSource.addEventListener('telemetry_tick', (e) => {
      try {
        const updatedMachines: MachineMetrics[] = JSON.parse(e.data);
        setMachines(updatedMachines);
      } catch (err) {
        // SSE parse error
      }
    });

    // Also poll summary every 2 seconds
    const interval = setInterval(() => {
      fetch('/api/factory/summary')
        .then((res) => res.json())
        .then((data) => setSummary(data))
        .catch(() => {});
    }, 2000);

    return () => {
      eventSource.close();
      clearInterval(interval);
    };
  }, []);

  const handleOverrideState = async (
    machineId: string,
    action: any,
    reasonCode?: string,
    notes?: string
  ) => {
    try {
      await fetch(`/api/machines/${machineId}/override`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, reason_code: reasonCode, notes }),
      });
      fetchData();
    } catch (e) {
      console.error(e);
    }
  };

  const handleClassifyStop = async (
    machineId: string,
    stopId: string,
    reasonCode: string,
    notes?: string
  ) => {
    try {
      await fetch(`/api/machines/${machineId}/classify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ stop_id: stopId, reason_code: reasonCode, notes }),
      });
      fetchData();
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-slate-950">
      {/* Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        summary={summary}
        role={role}
        setRole={setRole}
        onOpenExport={() => setIsExportOpen(true)}
      />

      {/* Main View Router */}
      <main className="flex-1 pb-12">
        {activeTab === 'overview' && (
          <FactoryOverview
            summary={summary}
            machines={machines}
            onSelectMachine={(id) => {
              setSelectedMachineId(id);
              setActiveTab('stopclock');
            }}
            onOverrideState={handleOverrideState}
          />
        )}

        {activeTab === 'stopclock' && (
          <StopClockView
            machines={machines}
            selectedMachineId={selectedMachineId}
            setSelectedMachineId={setSelectedMachineId}
            reasons={reasons}
            onOverrideState={handleOverrideState}
            onClassifyStop={handleClassifyStop}
            role={role}
          />
        )}

        {activeTab === 'analytics' && (
          <MachineDetail
            machines={machines}
            selectedMachineId={selectedMachineId}
            setSelectedMachineId={setSelectedMachineId}
            reasons={reasons}
            onOverrideState={handleOverrideState}
          />
        )}

        {activeTab === 'pareto' && <ParetoAnalytics machines={machines} />}

        {activeTab === 'reliability' && <ReliabilityAnalytics machines={machines} />}

        {activeTab === 'andon' && <AndonBoard machines={machines} />}

        {activeTab === 'replay' && <EventReplayView machines={machines} />}

        {activeTab === 'simulator' && (
          <SimulatorControls
            machines={machines}
            reasons={reasons}
            onOverrideState={handleOverrideState}
          />
        )}
      </main>

      {/* Export Modal */}
      <ExportModal isOpen={isExportOpen} onClose={() => setIsExportOpen(false)} />
    </div>
  );
}
