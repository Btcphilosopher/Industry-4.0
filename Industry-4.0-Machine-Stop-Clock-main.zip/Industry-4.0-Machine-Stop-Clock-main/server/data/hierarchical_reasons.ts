import { ReasonCode } from '../../src/types.js';

export const REASON_TREE: ReasonCode[] = [
  // Mechanical
  { category: 'Mechanical', subcategory: 'Drive System', code: 'MCH-001', name: 'Bearing Failure', description: 'Main spindle or conveyor bearing overheating/seizure', defaultCostRatePerHour: 220 },
  { category: 'Mechanical', subcategory: 'Drive System', code: 'MCH-002', name: 'Motor Overload', description: 'Drive motor thermal trip or mechanical overload', defaultCostRatePerHour: 180 },
  { category: 'Mechanical', subcategory: 'Belts & Chains', code: 'MCH-003', name: 'Belt Snap / Slippage', description: 'Drive belt broken or tension lost', defaultCostRatePerHour: 150 },
  { category: 'Mechanical', subcategory: 'Feed Mechanism', code: 'MCH-004', name: 'Mechanical Jam', description: 'Parts or swarf jammed in feed track/chute', defaultCostRatePerHour: 200 },
  { category: 'Mechanical', subcategory: 'Tooling', code: 'MCH-005', name: 'Tool Breakage', description: 'Cutting tool or die worn out or snapped', defaultCostRatePerHour: 250 },

  // Electrical
  { category: 'Electrical', subcategory: 'Power', code: 'ELE-001', name: 'Main Power Outage', description: 'Inbound power dip or breaker tripped', defaultCostRatePerHour: 300 },
  { category: 'Electrical', subcategory: 'Sensors', code: 'ELE-002', name: 'Photo-eye Sensor Fault', description: 'Optical sensor blocked, misaligned or failed', defaultCostRatePerHour: 140 },
  { category: 'Electrical', subcategory: 'PLC & Controllers', code: 'ELE-003', name: 'PLC Comm Fault / Fault Code', description: 'Loss of fieldbus or PLC fault flag', defaultCostRatePerHour: 280 },
  { category: 'Electrical', subcategory: 'Actuators', code: 'ELE-004', name: 'Solenoid Valve Fault', description: 'Pneumatic solenoid valve failed to trigger', defaultCostRatePerHour: 160 },

  // Material
  { category: 'Material', subcategory: 'Supply', code: 'MAT-001', name: 'No Material at Infeed', description: 'Upstream hopper or pallet empty', defaultCostRatePerHour: 180 },
  { category: 'Material', subcategory: 'Quality', code: 'MAT-002', name: 'Out-of-Spec Raw Material', description: 'Material dimensions or alloy incorrect', defaultCostRatePerHour: 210 },
  { category: 'Material', subcategory: 'Packaging', code: 'MAT-003', name: 'Carton/Film Jam', description: 'Packaging material wrapped incorrectly', defaultCostRatePerHour: 130 },

  // Changeover
  { category: 'Changeover', subcategory: 'Tooling', code: 'CHO-001', name: 'Die / Tool Swap', description: 'Planned changeover for new product tooling', defaultCostRatePerHour: 120 },
  { category: 'Changeover', subcategory: 'Calibration', code: 'CHO-002', name: 'Recipe Calibration', description: 'Adjusting parameters for new production batch', defaultCostRatePerHour: 110 },
  { category: 'Changeover', subcategory: 'First-Off', code: 'CHO-003', name: 'First-Off Quality Approval', description: 'Waiting for CMM / QA approval on sample', defaultCostRatePerHour: 140 },

  // Operator
  { category: 'Operator', subcategory: 'Break', code: 'OPR-001', name: 'Operator Meal/Tea Break', description: 'Scheduled operator rest break', defaultCostRatePerHour: 80 },
  { category: 'Operator', subcategory: 'Unattended', code: 'OPR-002', name: 'No Operator Present', description: 'Machine stopped waiting for line operator', defaultCostRatePerHour: 160 },
  { category: 'Operator', subcategory: 'Training', code: 'OPR-003', name: 'On-Shift Operator Training', description: 'Slower speed or stop due to training', defaultCostRatePerHour: 90 },

  // Maintenance
  { category: 'Maintenance', subcategory: 'PM', code: 'MNT-001', name: 'Preventive Maintenance', description: 'Scheduled lube, filter change, inspection', defaultCostRatePerHour: 100 },
  { category: 'Maintenance', subcategory: 'Repair', code: 'MNT-002', name: 'Unplanned Maintenance Repair', description: 'Fitter or electrician on-site performing fix', defaultCostRatePerHour: 220 },

  // Process & Quality
  { category: 'Process', subcategory: 'Starvation', code: 'PRC-001', name: 'Line Starvation', description: 'Waiting for upstream machine to deliver parts', defaultCostRatePerHour: 190 },
  { category: 'Process', subcategory: 'Blockage', code: 'PRC-002', name: 'Line Blockage / Backup', description: 'Downstream buffer full, machine auto-blocked', defaultCostRatePerHour: 190 },
  { category: 'Process', subcategory: 'Scrap Rate', code: 'PRC-003', name: 'High Defect Rate Inspection', description: 'Machine halted due to 3 consecutive rejects', defaultCostRatePerHour: 240 },

  // Other
  { category: 'Other', subcategory: 'Unclassified', code: 'OTH-001', name: 'Unclassified Stop', description: 'Stop awaiting operator classification', defaultCostRatePerHour: 150 },
  { category: 'Other', subcategory: 'Cleaning', code: 'OTH-002', name: 'End-of-Shift Clean Down', description: 'Swabbing down and clearing swarf', defaultCostRatePerHour: 90 },
];

export function findReasonByCode(code: string): ReasonCode | undefined {
  return REASON_TREE.find((r) => r.code === code);
}
