import express, { Request, Response } from 'express';
import { globalEventStore } from './engine/event_store.js';
import { StopDetector } from './engine/stop_detector.js';
import { MachineSimulator, DEFAULT_MACHINES } from './engine/simulator.js';
import { REASON_TREE } from './data/hierarchical_reasons.js';
import { FactorySummary, ShiftInfo, AlertItem } from '../src/types.js';

export const stopDetector = new StopDetector(globalEventStore);
export const simulator = new MachineSimulator(stopDetector, globalEventStore);

// Start hardware simulator
simulator.start();

export const apiRouter = express.Router();
apiRouter.use(express.json());

// SSE Clients List
const sseClients: Response[] = [];

// Broadcast function for SSE clients
function broadcastSseEvent(eventType: string, payload: any) {
  const data = `event: ${eventType}\ndata: ${JSON.stringify(payload)}\n\n`;
  for (const client of sseClients) {
    try {
      client.write(data);
    } catch (e) {
      // client disconnected
    }
  }
}

// Broadcast periodic telemetry tick
setInterval(() => {
  const metrics = stopDetector.getAllMetrics();
  broadcastSseEvent('telemetry_tick', metrics);
}, 1000);

/**
 * GET /api/factory/summary
 */
apiRouter.get('/factory/summary', (req: Request, res: Response) => {
  const allMetrics = stopDetector.getAllMetrics();
  const totalMachines = allMetrics.length;

  let sumOee = 0;
  let sumAvail = 0;
  let sumPerf = 0;
  let sumQual = 0;
  let totalDowntimeSec = 0;
  let runningCount = 0;
  let stoppedCount = 0;
  let faultedCount = 0;
  let totalLossCost = 0;

  for (const m of allMetrics) {
    sumOee += m.oee.oee;
    sumAvail += m.oee.availability;
    sumPerf += m.oee.performance;
    sumQual += m.oee.quality;
    totalDowntimeSec += m.total_downtime_sec;
    totalLossCost += m.financials.total_financial_loss;

    if (m.current_state === 'RUNNING') runningCount++;
    else if (m.current_state === 'FAULT') faultedCount++;
    else stoppedCount++;
  }

  const currentShift: ShiftInfo = {
    id: 'shift-a',
    name: 'Shift A (Day Shift)',
    start_time: '06:00',
    end_time: '14:00',
    planned_breaks_min: 30,
    active: true,
  };

  const summary: FactorySummary = {
    factory_name: 'Precision Engineering Plant 01',
    overall_oee: Number((totalMachines > 0 ? sumOee / totalMachines : 0).toFixed(4)),
    availability: Number((totalMachines > 0 ? sumAvail / totalMachines : 0).toFixed(4)),
    performance: Number((totalMachines > 0 ? sumPerf / totalMachines : 0).toFixed(4)),
    quality: Number((totalMachines > 0 ? sumQual / totalMachines : 0).toFixed(4)),
    total_downtime_sec: Math.round(totalDowntimeSec),
    active_machines_count: runningCount,
    total_machines_count: totalMachines,
    stopped_machines_count: stoppedCount,
    faulted_machines_count: faultedCount,
    running_machines_count: runningCount,
    total_loss_cost_today: Math.round(totalLossCost),
    current_shift: currentShift,
  };

  res.json(summary);
});

/**
 * GET /api/machines
 */
apiRouter.get('/machines', (req: Request, res: Response) => {
  res.json(stopDetector.getAllMetrics());
});

/**
 * GET /api/machines/:id
 */
apiRouter.get('/machines/:id', (req: Request, res: Response) => {
  const m = stopDetector.getMetrics(req.params.id);
  if (!m) {
    res.status(404).json({ error: 'Machine not found' });
    return;
  }
  res.json(m);
});

/**
 * GET /api/machines/:id/timeline
 */
apiRouter.get('/machines/:id/timeline', (req: Request, res: Response) => {
  const { from, to } = req.query as { from?: string; to?: string };
  const blocks = globalEventStore.getTimelineBlocks(req.params.id, from, to);
  res.json(blocks);
});

/**
 * GET /api/machines/:id/events
 */
apiRouter.get('/machines/:id/events', (req: Request, res: Response) => {
  const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
  const events = globalEventStore.getEventsForMachine(req.params.id, limit);
  res.json(events);
});

/**
 * GET /api/machines/:id/stops
 */
apiRouter.get('/machines/:id/stops', (req: Request, res: Response) => {
  const stops = globalEventStore.getStopsForMachine(req.params.id);
  res.json(stops);
});

/**
 * GET /api/machines/:id/cycles
 */
apiRouter.get('/machines/:id/cycles', (req: Request, res: Response) => {
  const cycles = globalEventStore.getCyclesForMachine(req.params.id);
  res.json(cycles);
});

/**
 * GET /api/machines/:id/pareto
 */
apiRouter.get('/machines/:id/pareto', (req: Request, res: Response) => {
  const pareto = globalEventStore.getDowntimePareto(req.params.id);
  res.json(pareto);
});

/**
 * POST /api/machines/:id/classify
 */
apiRouter.post('/machines/:id/classify', (req: Request, res: Response) => {
  const { stop_id, reason_code, notes } = req.body;
  if (!stop_id || !reason_code) {
    res.status(400).json({ error: 'Missing stop_id or reason_code' });
    return;
  }

  const reason = REASON_TREE.find((r) => r.code === reason_code);
  if (!reason) {
    res.status(400).json({ error: 'Invalid reason code' });
    return;
  }

  stopDetector.classifyStop(req.params.id, stop_id, reason, notes);
  res.json({ success: true, message: 'Stop classified successfully' });
});

/**
 * POST /api/machines/:id/override
 */
apiRouter.post('/machines/:id/override', (req: Request, res: Response) => {
  const { action, reason_code, notes } = req.body;
  if (!action) {
    res.status(400).json({ error: 'Missing action' });
    return;
  }

  simulator.injectManualEvent(req.params.id, action, reason_code, notes);
  const updated = stopDetector.getMetrics(req.params.id);
  res.json({ success: true, metrics: updated });
});

/**
 * GET /api/analytics/reasons
 */
apiRouter.get('/analytics/reasons', (req: Request, res: Response) => {
  res.json(REASON_TREE);
});

/**
 * GET /api/analytics/pareto
 */
apiRouter.get('/analytics/pareto', (req: Request, res: Response) => {
  const pareto = globalEventStore.getDowntimePareto();
  res.json(pareto);
});

/**
 * POST /api/replay
 */
apiRouter.post('/replay', (req: Request, res: Response) => {
  const { machine_id, from, to } = req.body;
  if (!machine_id || !from || !to) {
    res.status(400).json({ error: 'Missing machine_id, from, or to' });
    return;
  }

  const replayed = globalEventStore.replayEvents(machine_id, from, to);
  res.json({
    machine_id,
    from,
    to,
    event_count: replayed.length,
    events: replayed,
  });
});

/**
 * GET /api/export
 */
apiRouter.get('/export', (req: Request, res: Response) => {
  const format = (req.query.format as string) || 'csv';
  const allMetrics = stopDetector.getAllMetrics();

  if (format === 'json') {
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', 'attachment; filename="factory-downtime-export.json"');
    res.json(allMetrics);
    return;
  }

  // CSV
  let csv = 'Machine Code,Machine Name,State,Runtime (sec),Downtime (sec),OEE %,Availability %,Performance %,Quality %,Stops Count,Total Loss Cost (£)\n';
  for (const m of allMetrics) {
    csv += `"${m.code}","${m.name}","${m.current_state}",${m.total_runtime_sec},${m.total_downtime_sec},${(m.oee.oee * 100).toFixed(1)},${(m.oee.availability * 100).toFixed(1)},${(m.oee.performance * 100).toFixed(1)},${(m.oee.quality * 100).toFixed(1)},${m.stop_count},${m.financials.total_financial_loss}\n`;
  }

  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="factory-downtime-export.csv"');
  res.send(csv);
});

/**
 * GET /api/stream - Server-Sent Events Realtime Stream
 */
apiRouter.get('/stream', (req: Request, res: Response) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  sseClients.push(res);

  // Initial connection payload
  res.write(`event: connected\ndata: ${JSON.stringify({ time: new Date().toISOString() })}\n\n`);

  req.on('close', () => {
    const idx = sseClients.indexOf(res);
    if (idx >= 0) sseClients.splice(idx, 1);
  });
});
