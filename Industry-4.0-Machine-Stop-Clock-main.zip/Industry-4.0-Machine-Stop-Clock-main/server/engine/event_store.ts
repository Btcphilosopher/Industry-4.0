import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import {
  MachineEvent,
  MachineState,
  ReasonCode,
  StopRecord,
  CycleRecord,
  DowntimeParetoItem,
  TimelineBlock,
  EventType,
  EventSource,
} from '../../src/types.js';
import { REASON_TREE } from '../data/hierarchical_reasons.js';

const DATA_DIR = path.join(process.cwd(), 'data');
const EVENTS_FILE = path.join(DATA_DIR, 'events.jsonl');
const STOPS_FILE = path.join(DATA_DIR, 'stops.json');
const CYCLES_FILE = path.join(DATA_DIR, 'cycles.json');

export class EventStore {
  private events: MachineEvent[] = [];
  private stops: StopRecord[] = [];
  private cycles: CycleRecord[] = [];
  private eventIdsSet: Set<string> = new Set();
  private monotonicBaseNs: number = Date.now() * 1_000_000;
  private hrTimeStart: [number, number] = process.hrtime();

  constructor() {
    this.ensureDataDirectory();
    this.loadFromStorage();
  }

  private ensureDataDirectory() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
  }

  /**
   * Generates high-precision monotonic nanosecond timestamp
   */
  public getMonotonicNs(): number {
    const diff = process.hrtime(this.hrTimeStart);
    const diffNs = diff[0] * 1_000_000_000 + diff[1];
    return this.monotonicBaseNs + diffNs;
  }

  /**
   * Appends an immutable machine event to the append-only time series store
   */
  public appendEvent(eventData: Omit<MachineEvent, 'id' | 'monotonic_ns' | 'ingestion_time' | 'processing_time'> & { id?: string }): MachineEvent {
    const nowIso = new Date().toISOString();
    const event: MachineEvent = {
      id: eventData.id || crypto.randomUUID(),
      machine_id: eventData.machine_id,
      timestamp: eventData.timestamp || nowIso,
      monotonic_ns: this.getMonotonicNs(),
      event_type: eventData.event_type,
      previous_state: eventData.previous_state,
      new_state: eventData.new_state,
      reason_code: eventData.reason_code,
      source: eventData.source,
      metadata: eventData.metadata || {},
      ingestion_time: nowIso,
      processing_time: new Date().toISOString(),
    };

    // Duplicate event protection
    if (this.eventIdsSet.has(event.id)) {
      console.warn(`[EventStore] Duplicate event ID ignored: ${event.id}`);
      return this.events.find((e) => e.id === event.id)!;
    }

    this.eventIdsSet.add(event.id);
    this.events.push(event);

    // Sort late / out-of-order events by timestamp
    this.sortEvents();

    // Persist to WAL append file
    this.writeEventToWal(event);

    return event;
  }

  /**
   * Records or updates a stop record (creates delta entry)
   */
  public saveStopRecord(stop: StopRecord): void {
    const idx = this.stops.findIndex((s) => s.id === stop.id);
    if (idx >= 0) {
      this.stops[idx] = stop;
    } else {
      this.stops.push(stop);
    }
    this.persistStops();
  }

  /**
   * Appends a cycle record
   */
  public addCycleRecord(cycle: CycleRecord): void {
    this.cycles.push(cycle);
    // Keep max 5,000 recent cycles in memory
    if (this.cycles.length > 5000) {
      this.cycles = this.cycles.slice(-5000);
    }
    this.persistCycles();
  }

  /**
   * Sorts events chronologically by UTC timestamp
   */
  private sortEvents(): void {
    this.events.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  }

  /**
   * Gets all events for a machine
   */
  public getEventsForMachine(machineId: string, limit = 100): MachineEvent[] {
    return this.events
      .filter((e) => e.machine_id === machineId)
      .slice(-limit)
      .reverse();
  }

  /**
   * Gets all stop records for a machine
   */
  public getStopsForMachine(machineId: string, fromIso?: string, toIso?: string): StopRecord[] {
    let filtered = this.stops.filter((s) => s.machine_id === machineId);
    if (fromIso) {
      const fromMs = new Date(fromIso).getTime();
      filtered = filtered.filter((s) => new Date(s.start_time).getTime() >= fromMs);
    }
    if (toIso) {
      const toMs = new Date(toIso).getTime();
      filtered = filtered.filter((s) => new Date(s.start_time).getTime() <= toMs);
    }
    return filtered;
  }

  /**
   * Gets cycles for a machine
   */
  public getCyclesForMachine(machineId: string, limit = 500): CycleRecord[] {
    return this.cycles.filter((c) => c.machine_id === machineId).slice(-limit);
  }

  /**
   * Generates Downtime Pareto analysis for machine or factory-wide
   */
  public getDowntimePareto(machineId?: string, costPerHour = 180): DowntimeParetoItem[] {
    const targetStops = this.stops.filter(
      (s) => (!machineId || s.machine_id === machineId) && !s.is_micro_stop && s.duration_sec > 0
    );

    const totalDowntimeSec = targetStops.reduce((acc, s) => acc + s.duration_sec, 0) || 1;

    const map = new Map<string, { reason: ReasonCode; count: number; totalDuration: number }>();

    for (const stop of targetStops) {
      const reason = stop.reason || REASON_TREE.find((r) => r.code === 'OTH-001')!;
      const key = reason.code;
      const existing = map.get(key);
      if (existing) {
        existing.count += 1;
        existing.totalDuration += stop.duration_sec;
      } else {
        map.set(key, {
          reason,
          count: 1,
          totalDuration: stop.duration_sec,
        });
      }
    }

    const result: DowntimeParetoItem[] = Array.from(map.values()).map((item) => {
      const pct = (item.totalDuration / totalDowntimeSec) * 100;
      const rate = item.reason.defaultCostRatePerHour || costPerHour;
      const cost = Math.round((item.totalDuration / 3600) * rate);

      return {
        category: item.reason.category,
        subcategory: item.reason.subcategory,
        code: item.reason.code,
        reason_name: item.reason.name,
        occurrences: item.count,
        total_duration_sec: Math.round(item.totalDuration),
        percentage_of_downtime: Number(pct.toFixed(1)),
        estimated_cost: cost,
      };
    });

    return result.sort((a, b) => b.total_duration_sec - a.total_duration_sec);
  }

  /**
   * Generates horizontal timeline state blocks for a machine
   */
  public getTimelineBlocks(machineId: string, fromIso?: string, toIso?: string): TimelineBlock[] {
    const machineEvents = this.events.filter((e) => e.machine_id === machineId);
    if (machineEvents.length === 0) return [];

    const blocks: TimelineBlock[] = [];
    const now = new Date().toISOString();

    for (let i = 0; i < machineEvents.length; i++) {
      const currentEvent = machineEvents[i];
      const nextEvent = machineEvents[i + 1];
      const startTime = currentEvent.timestamp;
      const endTime = nextEvent ? nextEvent.timestamp : now;

      const durationSec = Math.max(
        1,
        (new Date(endTime).getTime() - new Date(startTime).getTime()) / 1000
      );

      // Find associated stop record if any
      const matchingStop = this.stops.find(
        (s) => s.machine_id === machineId && s.start_time === startTime
      );

      blocks.push({
        id: currentEvent.id,
        state: currentEvent.new_state,
        start_time: startTime,
        end_time: endTime,
        duration_sec: Math.round(durationSec),
        reason: currentEvent.reason_code || matchingStop?.reason,
        is_micro_stop: matchingStop?.is_micro_stop || false,
      });
    }

    return blocks;
  }

  /**
   * Event Replay reconstructor
   */
  public replayEvents(machineId: string, fromIso: string, toIso: string): MachineEvent[] {
    const fromMs = new Date(fromIso).getTime();
    const toMs = new Date(toIso).getTime();

    return this.events.filter((e) => {
      const t = new Date(e.timestamp).getTime();
      return e.machine_id === machineId && t >= fromMs && t <= toMs;
    });
  }

  private writeEventToWal(event: MachineEvent): void {
    try {
      fs.appendFileSync(EVENTS_FILE, JSON.stringify(event) + '\n', 'utf-8');
    } catch (err) {
      console.error('[EventStore] Error appending to WAL:', err);
    }
  }

  private persistStops(): void {
    try {
      fs.writeFileSync(STOPS_FILE, JSON.stringify(this.stops, null, 2), 'utf-8');
    } catch (err) {
      console.error('[EventStore] Error persisting stops:', err);
    }
  }

  private persistCycles(): void {
    try {
      // Save last 1000 cycles
      fs.writeFileSync(CYCLES_FILE, JSON.stringify(this.cycles.slice(-1000), null, 2), 'utf-8');
    } catch (err) {
      console.error('[EventStore] Error persisting cycles:', err);
    }
  }

  private loadFromStorage(): void {
    try {
      if (fs.existsSync(EVENTS_FILE)) {
        const lines = fs.readFileSync(EVENTS_FILE, 'utf-8').split('\n').filter(Boolean);
        for (const line of lines) {
          try {
            const ev: MachineEvent = JSON.parse(line);
            this.events.push(ev);
            this.eventIdsSet.add(ev.id);
          } catch (e) {
            // Ignore malformed line
          }
        }
        this.sortEvents();
      }

      if (fs.existsSync(STOPS_FILE)) {
        this.stops = JSON.parse(fs.readFileSync(STOPS_FILE, 'utf-8'));
      }

      if (fs.existsSync(CYCLES_FILE)) {
        this.cycles = JSON.parse(fs.readFileSync(CYCLES_FILE, 'utf-8'));
      }
    } catch (err) {
      console.error('[EventStore] Error loading storage:', err);
    }
  }
}

export const globalEventStore = new EventStore();
