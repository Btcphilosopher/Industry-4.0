import { MachineState } from '../../src/types.js';

/**
 * Formal Industry 4.0 Machine State Machine Matrix
 */
const VALID_TRANSITIONS: Record<MachineState, MachineState[]> = {
  RUNNING: [
    'STOPPED',
    'IDLE',
    'STARVED',
    'BLOCKED',
    'FAULT',
    'SETUP',
    'CHANGEOVER',
    'MAINTENANCE',
    'CLEANING',
    'NO_MATERIAL',
    'NO_OPERATOR',
    'PLANNED_BREAK',
    'DISCONNECTED',
  ],
  STOPPED: [
    'RUNNING',
    'IDLE',
    'FAULT',
    'SETUP',
    'CHANGEOVER',
    'MAINTENANCE',
    'CLEANING',
    'NO_MATERIAL',
    'NO_OPERATOR',
    'PLANNED_BREAK',
    'DISCONNECTED',
  ],
  IDLE: ['RUNNING', 'STOPPED', 'STARVED', 'BLOCKED', 'FAULT', 'DISCONNECTED'],
  STARVED: ['RUNNING', 'IDLE', 'STOPPED', 'NO_MATERIAL', 'DISCONNECTED'],
  BLOCKED: ['RUNNING', 'IDLE', 'STOPPED', 'DISCONNECTED'],
  FAULT: ['MAINTENANCE', 'STOPPED', 'RUNNING', 'DISCONNECTED'],
  SETUP: ['RUNNING', 'STOPPED', 'FAULT', 'DISCONNECTED'],
  CHANGEOVER: ['SETUP', 'RUNNING', 'STOPPED', 'FAULT', 'DISCONNECTED'],
  MAINTENANCE: ['STOPPED', 'RUNNING', 'CLEANING', 'FAULT', 'DISCONNECTED'],
  CLEANING: ['RUNNING', 'STOPPED', 'MAINTENANCE', 'DISCONNECTED'],
  NO_MATERIAL: ['RUNNING', 'STOPPED', 'STARVED', 'DISCONNECTED'],
  NO_OPERATOR: ['RUNNING', 'STOPPED', 'PLANNED_BREAK', 'DISCONNECTED'],
  PLANNED_BREAK: ['RUNNING', 'STOPPED', 'NO_OPERATOR', 'DISCONNECTED'],
  DISCONNECTED: [
    'RUNNING',
    'STOPPED',
    'IDLE',
    'FAULT',
    'UNKNOWN',
    'MAINTENANCE',
    'CHANGEOVER',
  ],
  UNKNOWN: [
    'RUNNING',
    'STOPPED',
    'IDLE',
    'STARVED',
    'BLOCKED',
    'FAULT',
    'SETUP',
    'CHANGEOVER',
    'MAINTENANCE',
    'CLEANING',
    'NO_MATERIAL',
    'NO_OPERATOR',
    'PLANNED_BREAK',
    'DISCONNECTED',
  ],
};

export class MachineStateMachine {
  /**
   * Validates if transition from `fromState` to `toState` is allowed
   */
  static isValidTransition(
    fromState: MachineState,
    toState: MachineState,
    forceOverride = false
  ): boolean {
    if (forceOverride) return true;
    if (fromState === toState) return true; // No-op transition
    const allowed = VALID_TRANSITIONS[fromState];
    return allowed ? allowed.includes(toState) : true;
  }

  /**
   * Categorizes if state is considered Operating (Planned running state)
   */
  static isOperatingState(state: MachineState): boolean {
    return state === 'RUNNING';
  }

  /**
   * Categorizes if state is considered Unplanned Downtime
   */
  static isUnplannedDowntime(state: MachineState): boolean {
    return [
      'STOPPED',
      'FAULT',
      'STARVED',
      'BLOCKED',
      'NO_MATERIAL',
      'NO_OPERATOR',
      'UNKNOWN',
    ].includes(state);
  }

  /**
   * Categorizes if state is considered Planned Downtime
   */
  static isPlannedDowntime(state: MachineState): boolean {
    return [
      'SETUP',
      'CHANGEOVER',
      'MAINTENANCE',
      'CLEANING',
      'PLANNED_BREAK',
    ].includes(state);
  }

  /**
   * State color hex code for UI & Timelines
   */
  static getStateColor(state: MachineState): string {
    switch (state) {
      case 'RUNNING':
        return '#10B981'; // Green
      case 'STOPPED':
        return '#EF4444'; // Red
      case 'FAULT':
        return '#DC2626'; // Deep Red
      case 'IDLE':
        return '#F59E0B'; // Amber
      case 'STARVED':
        return '#F97316'; // Orange
      case 'BLOCKED':
        return '#EAB308'; // Yellow
      case 'CHANGEOVER':
      case 'SETUP':
        return '#8B5CF6'; // Purple
      case 'MAINTENANCE':
        return '#3B82F6'; // Blue
      case 'CLEANING':
        return '#06B6D4'; // Cyan
      case 'NO_MATERIAL':
      case 'NO_OPERATOR':
        return '#EC4899'; // Pink
      case 'PLANNED_BREAK':
        return '#64748B'; // Slate
      case 'DISCONNECTED':
        return '#475569'; // Dark Slate
      default:
        return '#94A3B8';
    }
  }
}
