import {
  MachineConfig,
  MachineEvent,
  MachineMetrics,
  MachineState,
  ReasonCode,
  StopRecord,
  CycleRecord,
} from '../../src/types.js';
import { EventStore } from './event_store.js';
import { MachineStateMachine } from './state_machine.js';
import { OeeCalculator } from './oee_calculator.js';
import { REASON_TREE } from '../data/hierarchical_reasons.js';

export interface SignalInput {
  machine_id: string;
  speed_rpm?: number;
  motor_amps?: number;
  photo_eye_active?: boolean;
  plc_fault_code?: string;
  source?: MachineEvent['source'];
}

export class StopDetector {
  private configMap = new Map<string, MachineConfig>();
  private currentMetricsMap = new Map<string, MachineMetrics>();
  private activeStopsMap = new Map<string, StopRecord>();
  private machineCyclesMap = new Map<string, CycleRecord[]>();

  constructor(private eventStore: EventStore) {}

  public registerMachine(config: MachineConfig): void {
    this.configMap.set(config.id, config);

    const now = new Date().toISOString();
    const initialMetrics: MachineMetrics = {
      machine_id: config.id,
      name: config.name,
      code: config.code,
      line_id: config.line_id,
      current_state: 'RUNNING',
      state_start_time: now,
      current_run_duration_sec: 180,
      current_stop_duration_sec: 0,
      total_runtime_sec: 18000, // 5 hours
      total_downtime_sec: 2400, // 40 mins
      planned_downtime_sec: 900,
      unplanned_downtime_sec: 1500,
      stop_count: 3,
      avg_stop_duration_sec: 800,
      longest_stop_sec: 1200,
      shortest_stop_sec: 15,
      micro_stops_count: 8,
      micro_stop_time_sec: 160,
      avg_micro_stop_sec: 20,
      micro_stops_per_hour: 1.6,
      cycle_stats: {
        min_sec: config.thresholds.ideal_cycle_time_sec * 0.95,
        max_sec: config.thresholds.ideal_cycle_time_sec * 1.25,
        mean_sec: config.thresholds.ideal_cycle_time_sec * 1.02,
        median_sec: config.thresholds.ideal_cycle_time_sec * 1.01,
        p95_sec: config.thresholds.ideal_cycle_time_sec * 1.12,
        p99_sec: config.thresholds.ideal_cycle_time_sec * 1.22,
        stddev_sec: 0.18,
        total_cycles: 2450,
        slow_cycles_count: 12,
        ideal_cycle_time_sec: config.thresholds.ideal_cycle_time_sec,
      },
      production: {
        total_produced: 2450,
        good_count: 2420,
        reject_count: 30,
        scrap_count: 5,
        target_count: 2800,
        remaining_count: 350,
        parts_per_hour: Math.round(3600 / config.thresholds.ideal_cycle_time_sec),
      },
      oee: OeeCalculator.calculateOee(21600, 18000, config.thresholds.ideal_cycle_time_sec, 2450, 2420),
      reliability: OeeCalculator.calculateReliability(18000, []),
      losses: {
        equipment_failure_min: 25,
        setup_adjustment_min: 15,
        small_stops_min: 3,
        reduced_speed_min: 12,
        startup_rejects_min: 2,
        production_rejects_min: 5,
        total_loss_min: 62,
        estimated_cost_loss: 180,
      },
      financials: {
        downtime_cost_per_hour: config.financials.machine_value_per_hour + config.financials.labour_cost_per_hour,
        total_downtime_cost: Math.round((2400 / 3600) * (config.financials.machine_value_per_hour + config.financials.labour_cost_per_hour)),
        scrap_cost: 30 * config.financials.scrap_cost_per_part,
        total_financial_loss: 0,
      },
      last_event_time: now,
    };

    initialMetrics.financials.total_financial_loss =
      initialMetrics.financials.total_downtime_cost + initialMetrics.financials.scrap_cost;

    this.currentMetricsMap.set(config.id, initialMetrics);
  }

  /**
   * Processes raw machine signal (e.g. from PLC or Simulator)
   */
  public processSignal(signal: SignalInput): MachineMetrics {
    const config = this.configMap.get(signal.machine_id);
    const metrics = this.currentMetricsMap.get(signal.machine_id);
    if (!config || !metrics) throw new Error(`Machine ${signal.machine_id} not registered`);

    const now = new Date();
    const nowIso = now.toISOString();

    // Determine target state based on speed or PLC fault
    let targetState: MachineState = metrics.current_state;

    if (signal.plc_fault_code) {
      targetState = 'FAULT';
    } else if (signal.speed_rpm !== undefined) {
      if (signal.speed_rpm >= config.thresholds.running_threshold_rpm) {
        targetState = 'RUNNING';
      } else if (signal.speed_rpm < config.thresholds.stop_threshold_rpm) {
        // Stop detected
        targetState = metrics.current_state === 'FAULT' ? 'FAULT' : 'STOPPED';
      }
    }

    // Check if state transition occurred
    if (targetState !== metrics.current_state) {
      this.handleStateTransition(config, metrics, targetState, signal);
    }

    // Update real-time durations
    const stateStartMs = new Date(metrics.state_start_time).getTime();
    const elapsedSec = Math.max(0, (now.getTime() - stateStartMs) / 1000);

    if (MachineStateMachine.isOperatingState(metrics.current_state)) {
      metrics.current_run_duration_sec = elapsedSec;
      metrics.current_stop_duration_sec = 0;
    } else {
      metrics.current_stop_duration_sec = elapsedSec;
      metrics.current_run_duration_sec = 0;

      // Update active stop record if present
      const activeStop = this.activeStopsMap.get(config.id);
      if (activeStop) {
        activeStop.duration_sec = elapsedSec;
        activeStop.is_micro_stop = elapsedSec <= config.thresholds.micro_stop_seconds;
        this.eventStore.saveStopRecord(activeStop);
      }
    }

    metrics.last_event_time = nowIso;
    return metrics;
  }

  /**
   * Handles state transition
   */
  public handleStateTransition(
    config: MachineConfig,
    metrics: MachineMetrics,
    newState: MachineState,
    signal: SignalInput,
    overrideReason?: ReasonCode,
    operatorNotes?: string
  ): void {
    const previousState = metrics.current_state;
    const nowIso = new Date().toISOString();

    // Determine reason code
    let reason = overrideReason;
    if (!reason && signal.plc_fault_code) {
      reason = REASON_TREE.find((r) => r.code === signal.plc_fault_code) || {
        category: 'Electrical',
        subcategory: 'PLC',
        code: signal.plc_fault_code,
        name: `PLC Fault ${signal.plc_fault_code}`,
        defaultCostRatePerHour: 200,
      };
    } else if (!reason && newState === 'STOPPED') {
      reason = REASON_TREE.find((r) => r.code === 'OTH-001')!; // Unclassified Stop
    }

    // 1. Close current state window / active stop
    if (!MachineStateMachine.isOperatingState(previousState)) {
      const activeStop = this.activeStopsMap.get(config.id);
      if (activeStop) {
        activeStop.end_time = nowIso;
        activeStop.duration_sec = Math.max(
          1,
          (new Date(nowIso).getTime() - new Date(activeStop.start_time).getTime()) / 1000
        );
        activeStop.is_micro_stop = activeStop.duration_sec <= config.thresholds.micro_stop_seconds;
        if (reason) activeStop.reason = reason;

        // Update stop count and micro stop count
        if (activeStop.is_micro_stop) {
          metrics.micro_stops_count += 1;
          metrics.micro_stop_time_sec += activeStop.duration_sec;
          metrics.avg_micro_stop_sec = Math.round(metrics.micro_stop_time_sec / metrics.micro_stops_count);
        } else {
          metrics.stop_count += 1;
          metrics.total_downtime_sec += activeStop.duration_sec;
          if (MachineStateMachine.isPlannedDowntime(previousState)) {
            metrics.planned_downtime_sec += activeStop.duration_sec;
          } else {
            metrics.unplanned_downtime_sec += activeStop.duration_sec;
          }
          metrics.avg_stop_duration_sec = Math.round(metrics.total_downtime_sec / metrics.stop_count);
          metrics.longest_stop_sec = Math.max(metrics.longest_stop_sec, activeStop.duration_sec);
          metrics.shortest_stop_sec =
            metrics.shortest_stop_sec === 0
              ? activeStop.duration_sec
              : Math.min(metrics.shortest_stop_sec, activeStop.duration_sec);
        }

        this.eventStore.saveStopRecord(activeStop);
        this.activeStopsMap.delete(config.id);
      }
    } else {
      // Transitioning out of RUNNING
      const runDurationSec = Math.max(
        1,
        (new Date(nowIso).getTime() - new Date(metrics.state_start_time).getTime()) / 1000
      );
      metrics.total_runtime_sec += runDurationSec;
    }

    // 2. Open new state window
    metrics.current_state = newState;
    metrics.state_start_time = nowIso;
    metrics.current_reason = reason;

    if (!MachineStateMachine.isOperatingState(newState)) {
      const newStop: StopRecord = {
        id: `stop-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        machine_id: config.id,
        start_time: nowIso,
        duration_sec: 0,
        is_micro_stop: true, // starts as micro-stop until threshold passed
        is_planned: MachineStateMachine.isPlannedDowntime(newState),
        state: newState,
        reason,
        notes: operatorNotes,
        estimated_cost_loss: 0,
        parts_lost_estimate: 0,
      };
      this.activeStopsMap.set(config.id, newStop);
      this.eventStore.saveStopRecord(newStop);
    }

    // 3. Append immutable state change event
    this.eventStore.appendEvent({
      machine_id: config.id,
      timestamp: nowIso,
      event_type: 'STATE_CHANGE',
      previous_state: previousState,
      new_state: newState,
      reason_code: reason,
      source: signal.source || config.signal_source,
      metadata: {
        operator_notes: operatorNotes || '',
      },
    });

    // 4. Recalculate OEE & Reliability
    this.recalculateMetrics(config, metrics);
  }

  /**
   * Records a completed production cycle
   */
  public recordCycle(machineId: string, cycleTimeSec: number, isGood = true): void {
    const config = this.configMap.get(machineId);
    const metrics = this.currentMetricsMap.get(machineId);
    if (!config || !metrics) return;

    const nowIso = new Date().toISOString();
    const isSlow = cycleTimeSec > config.thresholds.ideal_cycle_time_sec * 1.15;
    const isAbnormal = cycleTimeSec > config.thresholds.ideal_cycle_time_sec * 2.0;

    const cycle: CycleRecord = {
      id: `cycle-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      machine_id: machineId,
      timestamp: nowIso,
      cycle_time_sec: Number(cycleTimeSec.toFixed(3)),
      ideal_cycle_time_sec: config.thresholds.ideal_cycle_time_sec,
      is_good: isGood,
      is_slow: isSlow,
      is_abnormal: isAbnormal,
    };

    this.eventStore.addCycleRecord(cycle);

    let list = this.machineCyclesMap.get(machineId) || [];
    list.push(cycle);
    if (list.length > 500) list = list.slice(-500);
    this.machineCyclesMap.set(machineId, list);

    // Update counts
    metrics.production.total_produced += 1;
    if (isGood) {
      metrics.production.good_count += 1;
    } else {
      metrics.production.reject_count += 1;
      metrics.production.scrap_count += 1;
    }
    metrics.production.remaining_count = Math.max(0, metrics.production.target_count - metrics.production.good_count);

    // Append cycle event
    this.eventStore.appendEvent({
      machine_id: machineId,
      timestamp: nowIso,
      event_type: isGood ? 'PIECE_PRODUCED' : 'REJECT_DETECTED',
      previous_state: metrics.current_state,
      new_state: metrics.current_state,
      source: config.signal_source,
      metadata: {
        cycle_time_sec: cycleTimeSec.toString(),
        is_good: isGood.toString(),
      },
    });

    this.recalculateMetrics(config, metrics);
  }

  /**
   * Reclassifies an active or historical stop
   */
  public classifyStop(machineId: string, stopId: string, reason: ReasonCode, operatorNotes?: string): void {
    const stops = this.eventStore.getStopsForMachine(machineId);
    const targetStop = stops.find((s) => s.id === stopId);
    if (targetStop) {
      targetStop.reason = reason;
      targetStop.notes = operatorNotes;
      targetStop.classified_by = 'Operator';
      targetStop.classified_at = new Date().toISOString();
      this.eventStore.saveStopRecord(targetStop);

      // Append CLASSIFICATION delta event
      this.eventStore.appendEvent({
        machine_id: machineId,
        timestamp: new Date().toISOString(),
        event_type: 'CLASSIFICATION',
        previous_state: targetStop.state,
        new_state: targetStop.state,
        reason_code: reason,
        source: 'MANUAL',
        metadata: {
          stop_id: stopId,
          operator_notes: operatorNotes || '',
        },
      });
    }
  }

  public getMetrics(machineId: string): MachineMetrics | undefined {
    const config = this.configMap.get(machineId);
    const metrics = this.currentMetricsMap.get(machineId);
    if (config && metrics) {
      this.recalculateMetrics(config, metrics);
    }
    return metrics;
  }

  public getAllMetrics(): MachineMetrics[] {
    const list: MachineMetrics[] = [];
    for (const [id, config] of this.configMap.entries()) {
      const metrics = this.currentMetricsMap.get(id);
      if (metrics) {
        this.recalculateMetrics(config, metrics);
        list.push(metrics);
      }
    }
    return list;
  }

  private recalculateMetrics(config: MachineConfig, metrics: MachineMetrics): void {
    const cycles = this.machineCyclesMap.get(config.id) || [];
    const stops = this.eventStore.getStopsForMachine(config.id);

    // OEE
    const plannedTime = 28800; // 8 hr shift in seconds
    metrics.oee = OeeCalculator.calculateOee(
      plannedTime,
      metrics.total_runtime_sec,
      config.thresholds.ideal_cycle_time_sec,
      metrics.production.total_produced,
      metrics.production.good_count
    );

    // Cycle stats
    metrics.cycle_stats = OeeCalculator.calculateCycleStats(
      cycles,
      config.thresholds.ideal_cycle_time_sec
    );

    // Reliability
    metrics.reliability = OeeCalculator.calculateReliability(metrics.total_runtime_sec, stops);

    // Losses
    const costPerHour = config.financials.machine_value_per_hour + config.financials.labour_cost_per_hour;
    metrics.losses = OeeCalculator.calculateSixBigLosses(
      stops,
      cycles,
      config.thresholds.ideal_cycle_time_sec,
      costPerHour
    );

    // Financials
    metrics.financials.total_downtime_cost = Math.round((metrics.total_downtime_sec / 3600) * costPerHour);
    metrics.financials.scrap_cost = metrics.production.scrap_count * config.financials.scrap_cost_per_part;
    metrics.financials.total_financial_loss =
      metrics.financials.total_downtime_cost + metrics.financials.scrap_cost;
  }
}
