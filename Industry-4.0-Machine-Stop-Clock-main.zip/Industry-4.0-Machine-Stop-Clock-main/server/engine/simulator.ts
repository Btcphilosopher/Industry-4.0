import { MachineConfig, MachineState } from '../../src/types.js';
import { EventStore } from './event_store.js';
import { StopDetector } from './stop_detector.js';
import { REASON_TREE } from '../data/hierarchical_reasons.js';

export const DEFAULT_MACHINES: MachineConfig[] = [
  {
    id: 'cnc-01',
    code: 'CNC-01',
    name: '5-Axis Spindle CNC Machine',
    department: 'Machining',
    line_id: 'line-01',
    cell_id: 'cell-01',
    asset_path: 'Enterprise / Site 1 / Machining / Line 01 / CNC Cell / CNC-01',
    thresholds: {
      running_threshold_rpm: 50,
      stop_threshold_rpm: 10,
      micro_stop_seconds: 120,
      fault_confirmation_ms: 500,
      ideal_cycle_time_sec: 4.2,
      target_parts_per_hour: 850,
    },
    financials: {
      machine_value_per_hour: 180,
      production_value_per_part: 14,
      labour_cost_per_hour: 40,
      scrap_cost_per_part: 8,
    },
    signal_source: 'OPC_UA',
  },
  {
    id: 'cnc-02',
    code: 'CNC-02',
    name: 'High Speed Milling Lathe',
    department: 'Machining',
    line_id: 'line-01',
    cell_id: 'cell-01',
    asset_path: 'Enterprise / Site 1 / Machining / Line 01 / CNC Cell / CNC-02',
    thresholds: {
      running_threshold_rpm: 40,
      stop_threshold_rpm: 10,
      micro_stop_seconds: 120,
      fault_confirmation_ms: 500,
      ideal_cycle_time_sec: 5.5,
      target_parts_per_hour: 650,
    },
    financials: {
      machine_value_per_hour: 160,
      production_value_per_part: 12,
      labour_cost_per_hour: 38,
      scrap_cost_per_part: 7,
    },
    signal_source: 'PLC',
  },
  {
    id: 'press-03',
    code: 'PRESS-03',
    name: '150-Ton Hydraulic Stamping Press',
    department: 'Stamping',
    line_id: 'line-01',
    cell_id: 'cell-02',
    asset_path: 'Enterprise / Site 1 / Stamping / Line 01 / Press Cell / PRESS-03',
    thresholds: {
      running_threshold_rpm: 15,
      stop_threshold_rpm: 5,
      micro_stop_seconds: 90,
      fault_confirmation_ms: 300,
      ideal_cycle_time_sec: 3.8,
      target_parts_per_hour: 920,
    },
    financials: {
      machine_value_per_hour: 220,
      production_value_per_part: 18,
      labour_cost_per_hour: 45,
      scrap_cost_per_part: 12,
    },
    signal_source: 'MODBUS',
  },
  {
    id: 'robot-04',
    code: 'ROBOT-04',
    name: '6-Axis Robotic Welding Arm',
    department: 'Welding',
    line_id: 'line-01',
    cell_id: 'cell-02',
    asset_path: 'Enterprise / Site 1 / Welding / Line 01 / Robot Cell / ROBOT-04',
    thresholds: {
      running_threshold_rpm: 30,
      stop_threshold_rpm: 5,
      micro_stop_seconds: 120,
      fault_confirmation_ms: 500,
      ideal_cycle_time_sec: 6.0,
      target_parts_per_hour: 600,
    },
    financials: {
      machine_value_per_hour: 190,
      production_value_per_part: 22,
      labour_cost_per_hour: 42,
      scrap_cost_per_part: 15,
    },
    signal_source: 'MQTT',
  },
  {
    id: 'line-05',
    code: 'LINE-05',
    name: 'Automated Conveyor & Inspection Line',
    department: 'Assembly',
    line_id: 'line-02',
    cell_id: 'cell-03',
    asset_path: 'Enterprise / Site 1 / Packaging / Line 02 / Assembly Cell / LINE-05',
    thresholds: {
      running_threshold_rpm: 20,
      stop_threshold_rpm: 5,
      micro_stop_seconds: 120,
      fault_confirmation_ms: 500,
      ideal_cycle_time_sec: 2.5,
      target_parts_per_hour: 1400,
    },
    financials: {
      machine_value_per_hour: 150,
      production_value_per_part: 8,
      labour_cost_per_hour: 35,
      scrap_cost_per_part: 5,
    },
    signal_source: 'DIGITAL_IO',
  },
  {
    id: 'pack-06',
    code: 'PACK-06',
    name: 'High-Speed Automated Case Packer',
    department: 'Packaging',
    line_id: 'line-02',
    cell_id: 'cell-03',
    asset_path: 'Enterprise / Site 1 / Packaging / Line 02 / Packing Cell / PACK-06',
    thresholds: {
      running_threshold_rpm: 25,
      stop_threshold_rpm: 5,
      micro_stop_seconds: 90,
      fault_confirmation_ms: 400,
      ideal_cycle_time_sec: 3.2,
      target_parts_per_hour: 1100,
    },
    financials: {
      machine_value_per_hour: 170,
      production_value_per_part: 10,
      labour_cost_per_hour: 38,
      scrap_cost_per_part: 6,
    },
    signal_source: 'SENSOR',
  },
];

export class MachineSimulator {
  private timer: NodeJS.Timeout | null = null;
  private isRunning = false;
  private speedMultiplier = 1;

  constructor(
    private stopDetector: StopDetector,
    private eventStore: EventStore
  ) {
    // Register default machines
    for (const m of DEFAULT_MACHINES) {
      this.stopDetector.registerMachine(m);
    }
  }

  public start(): void {
    if (this.isRunning) return;
    this.isRunning = true;
    console.log('[Simulator] Starting Industry 4.0 Machine Hardware Simulator...');

    // Tick every 1 second
    this.timer = setInterval(() => {
      this.tick();
    }, 1000);
  }

  public stop(): void {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
    this.isRunning = false;
  }

  public setSpeedMultiplier(mult: number): void {
    this.speedMultiplier = Math.max(1, Math.min(50, mult));
  }

  /**
   * Main simulation tick
   */
  private tick(): void {
    const machines = this.stopDetector.getAllMetrics();

    for (const m of machines) {
      const config = DEFAULT_MACHINES.find((c) => c.id === m.machine_id);
      if (!config) continue;

      // Random state perturbation logic
      const roll = Math.random();

      if (m.current_state === 'RUNNING') {
        // Record cycle
        const variance = (Math.random() - 0.45) * 0.4; // slight cycle noise
        const actualCycleTime = Math.max(0.5, config.thresholds.ideal_cycle_time_sec + variance);
        const isGood = Math.random() > 0.015; // 98.5% quality

        this.stopDetector.recordCycle(m.machine_id, actualCycleTime, isGood);

        // Chance of stop
        if (roll < 0.018) {
          // Trigger micro-stop or major fault
          if (roll < 0.005) {
            // Fault
            this.stopDetector.processSignal({
              machine_id: m.machine_id,
              speed_rpm: 0,
              plc_fault_code: 'MCH-004', // Mechanical jam
            });
          } else {
            // Stop / Idle
            this.stopDetector.processSignal({
              machine_id: m.machine_id,
              speed_rpm: 0,
            });
          }
        } else {
          // Keep running
          this.stopDetector.processSignal({
            machine_id: m.machine_id,
            speed_rpm: config.thresholds.running_threshold_rpm + Math.floor(Math.random() * 20),
          });
        }
      } else {
        // Currently stopped/faulted
        // Chance of recovering
        if (roll < 0.15) {
          this.stopDetector.processSignal({
            machine_id: m.machine_id,
            speed_rpm: config.thresholds.running_threshold_rpm,
          });
        } else {
          // Continue in stopped state
          this.stopDetector.processSignal({
            machine_id: m.machine_id,
            speed_rpm: 0,
          });
        }
      }
    }
  }

  /**
   * Manual event injection helper for testing & demonstrations
   */
  public injectManualEvent(
    machineId: string,
    action: 'RUN' | 'STOP' | 'FAULT' | 'MAINTENANCE' | 'CHANGEOVER' | 'MATERIAL_SHORTAGE',
    reasonCode?: string,
    operatorNotes?: string
  ): void {
    const config = DEFAULT_MACHINES.find((c) => c.id === machineId);
    if (!config) return;

    let targetState = mStateFromAction(action);
    let reason = reasonCode ? REASON_TREE.find((r) => r.code === reasonCode) : undefined;

    if (!reason) {
      if (action === 'MATERIAL_SHORTAGE') {
        reason = REASON_TREE.find((r) => r.code === 'MAT-001');
      } else if (action === 'MAINTENANCE') {
        reason = REASON_TREE.find((r) => r.code === 'MNT-001');
      } else if (action === 'CHANGEOVER') {
        reason = REASON_TREE.find((r) => r.code === 'CHO-001');
      } else if (action === 'FAULT') {
        reason = REASON_TREE.find((r) => r.code === 'MCH-001');
      }
    }

    const metrics = this.stopDetector.getMetrics(machineId);
    if (metrics) {
      this.stopDetector.handleStateTransition(
        config,
        metrics,
        targetState,
        { machine_id: machineId, source: 'MANUAL' },
        reason,
        operatorNotes
      );
    }
  }
}

function mStateFromAction(
  action: 'RUN' | 'STOP' | 'FAULT' | 'MAINTENANCE' | 'CHANGEOVER' | 'MATERIAL_SHORTAGE'
): MachineState {
  switch (action) {
    case 'RUN':
      return 'RUNNING';
    case 'STOP':
      return 'STOPPED';
    case 'FAULT':
      return 'FAULT';
    case 'MAINTENANCE':
      return 'MAINTENANCE';
    case 'CHANGEOVER':
      return 'CHANGEOVER';
    case 'MATERIAL_SHORTAGE':
      return 'NO_MATERIAL';
    default:
      return 'STOPPED';
  }
}
