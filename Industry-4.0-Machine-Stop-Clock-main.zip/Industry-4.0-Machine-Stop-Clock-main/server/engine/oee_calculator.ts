import {
  CycleStats,
  OeeMetrics,
  ProductionCounts,
  ReliabilityMetrics,
  SixBigLosses,
  StopRecord,
  CycleRecord,
  MachineThresholds,
} from '../../src/types.js';

export class OeeCalculator {
  /**
   * Calculates OEE (Availability x Performance x Quality)
   */
  static calculateOee(
    plannedProductionTimeSec: number,
    operatingTimeSec: number,
    idealCycleTimeSec: number,
    totalProducedCount: number,
    goodCount: number
  ): OeeMetrics {
    // 1. Availability
    const availability =
      plannedProductionTimeSec > 0
        ? Math.min(1.0, Math.max(0.0, operatingTimeSec / plannedProductionTimeSec))
        : 0;

    // 2. Performance
    // Operating time in seconds. Ideal parts = Operating time / Ideal Cycle Time.
    const idealPartsCount =
      idealCycleTimeSec > 0 ? operatingTimeSec / idealCycleTimeSec : 0;
    const performance =
      idealPartsCount > 0
        ? Math.min(1.2, Math.max(0.0, totalProducedCount / idealPartsCount))
        : 0;

    // 3. Quality
    const quality =
      totalProducedCount > 0
        ? Math.min(1.0, Math.max(0.0, goodCount / totalProducedCount))
        : 1.0;

    // OEE = A * P * Q
    const oee = availability * performance * quality;

    return {
      availability: Number(availability.toFixed(4)),
      performance: Number(performance.toFixed(4)),
      quality: Number(quality.toFixed(4)),
      oee: Number(oee.toFixed(4)),
      planned_production_time_sec: Math.round(plannedProductionTimeSec),
      operating_time_sec: Math.round(operatingTimeSec),
      ideal_time_for_total_count_sec: Math.round(totalProducedCount * idealCycleTimeSec),
    };
  }

  /**
   * Calculates Cycle-Time statistics (min, max, mean, median, P95, P99, stddev, slow cycles)
   */
  static calculateCycleStats(
    cycles: CycleRecord[],
    idealCycleTimeSec: number
  ): CycleStats {
    if (cycles.length === 0) {
      return {
        min_sec: 0,
        max_sec: 0,
        mean_sec: idealCycleTimeSec,
        median_sec: idealCycleTimeSec,
        p95_sec: idealCycleTimeSec,
        p99_sec: idealCycleTimeSec,
        stddev_sec: 0,
        total_cycles: 0,
        slow_cycles_count: 0,
        ideal_cycle_time_sec: idealCycleTimeSec,
      };
    }

    const times = cycles.map((c) => c.cycle_time_sec).sort((a, b) => a - b);
    const total = times.length;
    const sum = times.reduce((acc, v) => acc + v, 0);
    const mean = sum / total;

    const min = times[0];
    const max = times[total - 1];

    // Median
    const midIndex = Math.floor(total / 2);
    const median =
      total % 2 !== 0
        ? times[midIndex]
        : (times[midIndex - 1] + times[midIndex]) / 2;

    // Percentiles
    const p95Index = Math.min(total - 1, Math.floor(total * 0.95));
    const p99Index = Math.min(total - 1, Math.floor(total * 0.99));
    const p95 = times[p95Index];
    const p99 = times[p99Index];

    // Variance & Standard Deviation
    const variance =
      times.reduce((acc, v) => acc + Math.pow(v - mean, 2), 0) / total;
    const stddev = Math.sqrt(variance);

    // Slow cycles (> 1.15x ideal cycle time)
    const slowThreshold = idealCycleTimeSec * 1.15;
    const slowCount = cycles.filter((c) => c.cycle_time_sec > slowThreshold).length;

    return {
      min_sec: Number(min.toFixed(3)),
      max_sec: Number(max.toFixed(3)),
      mean_sec: Number(mean.toFixed(3)),
      median_sec: Number(median.toFixed(3)),
      p95_sec: Number(p95.toFixed(3)),
      p99_sec: Number(p99.toFixed(3)),
      stddev_sec: Number(stddev.toFixed(3)),
      total_cycles: total,
      slow_cycles_count: slowCount,
      ideal_cycle_time_sec: idealCycleTimeSec,
    };
  }

  /**
   * Calculates MTBF (Mean Time Between Failures) and MTTR (Mean Time To Repair)
   */
  static calculateReliability(
    operatingTimeSec: number,
    stops: StopRecord[]
  ): ReliabilityMetrics {
    const failureStops = stops.filter(
      (s) => !s.is_micro_stop && (s.state === 'FAULT' || s.state === 'STOPPED')
    );
    const failureCount = failureStops.length;

    const totalDowntimeSec = failureStops.reduce((acc, s) => acc + s.duration_sec, 0);

    // MTBF in hours = Operating Hours / Failure Count
    const operatingHours = operatingTimeSec / 3600;
    const mtbfHours =
      failureCount > 0 ? operatingHours / failureCount : operatingHours || 24;

    // MTTR in minutes = Total Downtime Minutes / Failure Count
    const totalDowntimeMinutes = totalDowntimeSec / 60;
    const mttrMinutes =
      failureCount > 0 ? totalDowntimeMinutes / failureCount : 0;

    const daysFraction = Math.max(1 / 24, operatingHours / 24);
    const failureFreq = failureCount / daysFraction;
    const repairFreq = failureCount > 0 ? (totalDowntimeMinutes > 0 ? (failureCount / (totalDowntimeMinutes / 60)) : 1) : 0;

    // Machine Health Score (100 base, penalize high failure count & high MTTR)
    let healthScore = 100 - failureCount * 5 - Math.min(30, mttrMinutes * 0.5);
    healthScore = Math.max(20, Math.min(100, Math.round(healthScore)));

    // Anomaly score (0-100)
    let anomalyScore = Math.min(100, Math.round(failureCount * 12 + (mttrMinutes > 30 ? 25 : 0)));

    let warning: string | undefined;
    if (failureCount >= 3) {
      warning = `High stop frequency detected (${failureCount} unplanned stops today)`;
    } else if (mttrMinutes > 45) {
      warning = `High mean time to repair (${mttrMinutes.toFixed(1)} mins/fault)`;
    }

    return {
      mtbf_hours: Number(mtbfHours.toFixed(2)),
      mttr_minutes: Number(mttrMinutes.toFixed(1)),
      failure_frequency_per_day: Number(failureFreq.toFixed(1)),
      repair_frequency_per_day: Number(repairFreq.toFixed(1)),
      health_score: healthScore,
      anomaly_score: anomalyScore,
      failure_warning: warning,
    };
  }

  /**
   * Calculates Six Big Losses (Breakdowns, Setup, Micro-Stops, Reduced Speed, Startup Scrap, Reject Scrap)
   */
  static calculateSixBigLosses(
    stops: StopRecord[],
    cycles: CycleRecord[],
    idealCycleTimeSec: number,
    financialCostPerHour: number
  ): SixBigLosses {
    let equipmentFailureSec = 0;
    let setupSec = 0;
    let microStopsSec = 0;

    for (const stop of stops) {
      if (stop.is_micro_stop) {
        microStopsSec += stop.duration_sec;
      } else if (stop.state === 'SETUP' || stop.state === 'CHANGEOVER') {
        setupSec += stop.duration_sec;
      } else if (stop.state === 'FAULT' || stop.state === 'STOPPED') {
        equipmentFailureSec += stop.duration_sec;
      }
    }

    // Reduced speed loss: calculate extra time spent above ideal cycle time
    let reducedSpeedSec = 0;
    let rejectCount = 0;
    for (const cycle of cycles) {
      if (cycle.cycle_time_sec > idealCycleTimeSec) {
        reducedSpeedSec += cycle.cycle_time_sec - idealCycleTimeSec;
      }
      if (!cycle.is_good) {
        rejectCount++;
      }
    }

    const startupRejectsSec = Math.round(rejectCount * 0.3 * idealCycleTimeSec);
    const productionRejectsSec = Math.round(rejectCount * 0.7 * idealCycleTimeSec);

    const totalLossSec =
      equipmentFailureSec +
      setupSec +
      microStopsSec +
      reducedSpeedSec +
      startupRejectsSec +
      productionRejectsSec;

    const totalLossMin = Math.round(totalLossSec / 60);
    const estimatedCostLoss = Math.round((totalLossSec / 3600) * financialCostPerHour);

    return {
      equipment_failure_min: Math.round(equipmentFailureSec / 60),
      setup_adjustment_min: Math.round(setupSec / 60),
      small_stops_min: Math.round(microStopsSec / 60),
      reduced_speed_min: Math.round(reducedSpeedSec / 60),
      startup_rejects_min: Math.round(startupRejectsSec / 60),
      production_rejects_min: Math.round(productionRejectsSec / 60),
      total_loss_min: totalLossMin,
      estimated_cost_loss: estimatedCostLoss,
    };
  }
}
